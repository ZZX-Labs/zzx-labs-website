SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efafbbcb6822f54da544ed3fd3868fdcfad7031b524ad9103bdffd46f7eb3ac0',1986,'','','communications',5,'Railroads: 9.6 km (single eect 1.524-meter
gauge,.spur of Soviet line from Kushka -
(USSR) to Towraghondt and.from Termez
(USSR) to Kheyrabad Transhipment Point
(15 km) on south bank Amu Darys (govern-
ment owned)
Highways: 21,000 pie total (1984); 2,800 a
hard surface, 1,650 km bituminous treated
gravel and improved earth, 16,550 km un-
improved earth and tracks
Inland-waterways: total navigability 1,200
km; chiefly Amu Darya, which handles
steamers up to about 500 metric tons
Pineliviee: er, gas, 180 km
Ports: 3 minor river ports; largest Shir Khan
Civil air: 5 major transport aircraft
Airfields: 41 total, 34 usable; 12 with
permanent-surface runways; 8 with run-
ways 2,440-3,659 m, 16 with runways
1,220-2,4389 m :
Telecommunications: limited telephone,
telegraph, and radiobroadcast services; tele-
vision introduced in 1980; 31,200 telephones
(0.2 per 100 popl.); 5 AM and no FM stations,
1 TV station, 1 earth satellite station’ ©
Defense Forces
Branches: Armed Forces, Air and Defense -
Forces, border guard forces, Defense of the
Revolution Force, National Police Force,
Government Information Service, People’s
Militia, operational battalions
Military manpower: males 15-49, about __
3,657,000; 2,030,000 fit for military service;
about 149,000 reach military age (22) annu-
ally _
Supply: dependent on foreign sources, al-
most erclusiwely the USSR |
Military badiset: fa scaly year Snding 20.
March 1984, $210 million, about 63% of cen-
tral government budget :','4ba1d312a0465ff859f811007e86264a801ca8471b16c80d211e691de1f47288','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5466e80df4f37ea57317e945174aadf96e84afea1c0c0833649523a76845daa2',1986,'AL','Albania','communications',6,'Adriatic
Durre
Sea
Sazang
lonian Sea
See regional map V
Land
28,748 km?; slightly ines than Maryland;
43% forest and wood; 21% arable; 19%
meadows and pasture; 5% permanent crop;-
5% inland water; 7% other
Land boundaries: 716 km
Water
Limits of territorial waters (claimed): 15
nm :
Coastline: 418 km (including Sazan Island)','d35fb5c768989f19bd223fa678fb3a52c36123292bc25342e902b02d03134c45','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d747fb7e5dea446435ad2bb27ef1e0156de36d3fe7f9d240fbf8aed59830d035',1986,'FR','France','communications',11,'Railroads: 228 km 1.435-meter standard
gauge, single track, government owned
(1980 est.); claims over 400 km (1983); line
connecting Titograd, Yugoslavia, and
Shkodev, Albania, to be completed in 1986
Highways: 4,989 km total; 1,287 km paved,
1,609 km crushed stone and/or gravel, 2,098
km improved or unimproved earth (1975)
Inland waterways: 48 km plus Albanian
sections of Lake Scutari, Lake Ohrid, and
Lake Prespa (1979) ;
Pipelines: crude oil 117 km; refined prod-
ucts, 65 km; natural gas, 64 km
Freight carried: rail—2.8 million metric
tons, 180 million metric ton/km (1971);
highways 39 million metric tons, 900 million
metric ton/km (1971)
Ports: 1 major (Durres), 3 minor (1979)
Civil air: no civil airline
Defense Forces. so
Branches: Albanian People’s. ‘Amy, Frontier
Troops, Interior Troops, Albanian Coastal
Defense Command, Air rand Air Defense
Force
Military manpower: males 15-49, 806,000;
667,000 fit for military service; 32,000 reach
military age (19) annually
Military budget: announced for fiscal''year
ending 31 December 1985, 1 billion leks;
10.9% of total budget
French Guiana‘
Bay of
Biscay
P * Bordeaux
Bilbao’ =
sooner
“ Barcelona
Balearic
{Sevilla Isla
Mediterranean
,Malaga
ow" < .
Strait of Gibraltar Gibraltar
(U.K.)
Scale,1: 19,000,000','6aeab65c4bd6b38139c7cd3f833131346354cfae6862536e71bf6f546b0c1e55','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6ccae64a48a8935d069e155d7e64bd20291e1ca0047bfd6a5e6dc0a833b95d7',1986,'DZ','Algeria','communications',12,'“500 km . ‘Mediterranean Sea
o
See regional map Vi
Land - . _ ;
2,381,471 ‘km? ; more than three times the
size of Texas; 80% désert, waste, or urban;
16% pasture and meadows; 3% cultivated;
1% forest _
Land birders: 6,260 km
Water = |
Limits of fe teritoral waters (claimed): 12 |
nm : :
Coastline:.1,183km _
Railroads: 3,950 km total; 2, 690 km stand:
ard gauge (1.435 m); 1,140 km 1.055-meter
gauge, 120 km 1.000-meter gauge; 320 km
electrified; 193 km double track
Highways: 78,410 km total; 45,070 km con-
crete or bituminous, 33,340 km gravel,
crushed stone, unimproved earth
Pipelines: crude oil, 6,612 km; refined prod-
ucts, 298 km; natural gas, 2,948 km
Ports: 6 major, 6 secondary, 10 minor
Civil air: 42 major transport aircraft
Airfields: 155 total, 149 usable; 56 with
permanent-surface runways; 28 with run-
ways 2,440-3,659 m; 73 with runways
1,220-2,439 m
Defense Forces
Branches: Armed Forces, Aras Navy, Air
Force, National Gendarmerie
Military rnanpower: males 15-49, 4,892,000;
3,024,000 fit for military service; 248,000
reach military age (19) annually
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
bee
een a Mat
eo cad
ee
‘Sem eeee ee
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Andorra‘
Angola -
«Tindouf
oe of ak : Algiers ~!
i ret Xeniet j °
angler fe Constantine
Rabat Oran','386d0ff6a52c827a4ebbf3de2a84d72d6a17a6277fac57e75093c2231824c072','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a1aca475b648ed94fec53dd6e9168df422ef30dc44893bae46de1f8280826c9',1986,'AD','Andorra','communications',16,'See regional map V_
Land ;
466 km?; half the size ee New York City
Land boundaries: Be km;
Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft. :
Airfields: none
Telecommunications: international landline
circuits to Spain and France; 1 AM station;
aboiit 12,800 telephones (43.5 per 100 por. )
(1982)
Defense Forces
Defense is the responsibility of Spain and
France ;
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4','4c3fa81964ef5fbbf72f55c841943c116c0b2eb8a241a03a689c2904e21444ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c2b9d94b36e8b815dddbc0fcf61c7d5f862ba6500cd43979e249136c80962fb',1986,'AO','Angola','communications',20,'a : saat
South
Atlantic
Ocean
See regional map VII
ES
Land \\
1,246,700 km?; larger than California and
Texas combined; 44% forest; 22% meadow |
and pasture; 1% cultivated; 33% other (in-
cluding fallow)
Land boundaries: 5,070 km
Water ts
Limits of territorial waters (claimed): 20
nm (fishing 200 nm)
Coastline: 1,600 km
Railroads: 3,189 km total; 2,879 km 1.067-
meter gauge, 310 km 0.600-meter gauge
Highways: 73,828 km total; 8,577 km
bituminous-surface treatment, 29,350 km
crushed stone, gravel, or improved earth,
remainder unimproved earth
Inland waterways: 1,165 km navigable
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
i I ac a ele le eg I NR eile I, el a Ae Ola: ye eng
fo jai?
Tn a a ne Te
Declassified and Approved For Release 2012/08/29 - CIA-RDP08-00534R000100170001-4 |
Ports: 3 major (Luanda, Lobito, Namibe):.5.
minor 7 ;
Pipelines: crude oil, 179 km
Civil air: 22 major transport aircraft
Airfields: 351 total; 263 usable; 25 with - .
permanent-surface runways; l.withrun- :
ways over 8,659 m, 12 with runways 2,440- -
3, 6591 m, 69 with runways 1,220-2,439 m
Telecommunications: fair system of w wire,
radio-relay, and troposcatter routes; high -.
frequency used extensively for military/ .
Cuban links; 2 Atlantic Ocean satellite sta-
tions; 40,300 telephones (0.7 per 100 popl.):
16 AM, 13 FM, and 2 TV stations
Defense Forces
Branches: Army, Navy, Air Force/ Air De-.
fense; paramilitary forces—People’s Police
Corps, People’s Defense Organization and
Territorial Troops, Frontier Guard
Military manpower: males 15-49, 1,973,000;
998,000 fit for military service; 83,000 reach
military age(18)annually .
Military budget: for fiscal year ending 31. ~
December 1983; $587 million; 25% of cen- ©
tral government budget
Lobito, Luena®
Namibe/ Menongue
Scale 1:40,000,000
0 500
0 500
1000 Kilometers
1000 Nautical Miles
Boundary representation is, aot necessarily authoritative. \\
H
800544 (545531) 4-86
ar xe','f8a816c66376bbf1a875bee1ceb61ab2881faf00a8488ffc59fa570c4cab3984','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90ba3d0c5b2f5a17f9eb94247e0540f2ef5fd1c6f1bca1f1a0323a777c681d9c',1986,'AI','Anguilla','communications',24,'20 km
_ Sombrero . .
9
Caribbean
Sea
. a aod Scrubisland..:
Prickly Pear Ca ¥Sp 2
- THE VALLEYZ:
Blowing Point
See regional map III
Land
Anguilla, 91 km?; about one- half the size of
Washington, D. C.; Sombrero,.5 km? . .
Railroads: none
Highways: approximately 60 km surfaced
Inland waterways: none
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Anguilla (continued)
Ports: | major (Road Bay), I minor (Blowing
Point) .
Civil air: nd major transport aircraft
Airfield: | with permanent-surface runways
of 1,100 mat Wallblake Airport
Telecommunications: modern internal tele-
phone system; 890 telephones (13.6 per 100
popl.); 1 FM and 2 AM stations; radio-relay
link to St. Martin’s Island
Defense Forces
External defense i is the responsibility of UK
Branches: Police','17f65fb0f0349ac7f390c956692cfbce7317e72ee734aa6ba51ac42dc31b9cdc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f5a2b02ac832056c27c8e052b4c599cd817d85b30af39293af939cd218e30a5',1986,'AG','Antigua and Barbuda','communications',27,'20k _
a rington
14 apo Ue.
‘Caribbean Sea —
SAINT JOHN''S, ee
~ g Antigua
o Redonda .., - toro
See regional map Ii
Land
280 km?; less than two-thirds the size of New
York City; 54% arable; 18% waste and built
on; 14% forest; 9% unused but potentially
productive; 5% pasture; the islands of Re- |
donda (less than 2.6 km and uninhabited)
and Barbuda (161 km) are dependencies
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 153 km
Railroads: 64 km 0.760-metet narrow gauge,
13 km 0.610-meter gauge, employed almost
exclusively for handling cane
Highways: 240 km main
Ports: 1 major (St. John’s), 1 minor’ -
Civil air: 10 major transport aircraft :','c15cff417e7da313c8e455116a33dca409385a77aff42be1f05cd6f021e41412','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af9d9263b643fb353a3d2b709863a897f62abe5317b0bbb628fe600daddc28dd',1986,'AR','Argentina','communications',31,'Airfields: 2 total, 1 usable; 1 with
permanent-surface runways; | with run- 1000 km __
ways 2,440-3,659 m
Telecommunications: good automatic tele-
phone system; 6,700 telephones (9.2 per 100 ef
popl.); tropospheric scatter links with Saba UENOS AIRES
and Guadeloupe; 6 AM and 2 FM stations; 1 gy
TV station; 1 coaxial submarine cable; ! sat- neo | Mar. det Plate
ellite ground station de Bariloche seein Anarwie
Defense Forces
Branches: Antigua and Barbuda Defense
Force, Royal Antigua and Barbuda Police
Force
Boundary representation is
Not necessarily authoritative
See regional map IV
Sasa
Major ground units: Defense Force
Aircraft: none : Land
2,766,889 km?; four times the size of Texas;
57% agricultural (46% natural meadow, 11%
crop, improved pasture, and fallow); 25%
forest; 18% mountain, urban, or waste
Land boundaries: 9,414 km
Water :
Limits of territorial waters (claimed): 200 ''
nm (continental shelf, including sovereignty
over superjacent waters); overflight and nav-
igation permitted beyond 12 nm
Coastline: 4,989 km
Railroads: 35,476 km total; 3,086 km 1.435-
meter standard gauge, 22,788 km 1.676-
meter broad gauge, 13,461 km 1.000-meter
gauge, 408 km 0.750-meter gauge; of total in
country, 142 km are electrified
Highways: 208,100 km total, of which
47,550 km paved, 39,500 km gravel, 101,000
km improved earth, 20,300 km unimproved
earth
Inland waterways: 11,000 km navigable
Pipelines: 4,090 km crude oil; 2,200 km re-
fined products; 9,918 km natural gas
Ports: 7 major, 30 minor
Civil air: 54 major transport aircraft
Airfields: 1,827 total, 1,663 usable; 125 with
permanent-surface runways; 1 with run-
ways over 3,695 m, 32 with runways
2,440-3,659 m, 327 with runways 1,220-
2,489 m
Telecommunications: extensive modern
system; 3.23 million telephones (10.3 per 100
popl.), radio relay widely used; 2 satellite
stations with 3 Atlantic Ocean antennas; 163
AM and 190 TV stations; 30-station domestic
satellite network
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Defense Forces
Branches: Argentine ees Navy of the:
Argentine Republic, Argentine Air Force,
National Gendarmerie, Argentine Naval .
Prefecture, National Aeronautical Police
Military manpower: males 15-49, 7,719,000;
6,264,000 fit for military service; 255,000
reach military age (20) annually |
M ilitary budget: revised defense budget for ~
fiscal year ending 31 December 1985, $1.0
billion; 7% of central government budget,
Msntevideo
Bahla Blanca, ~Mar del Plata
San Carlos
«de Bariloche
Puerto Monit
Scale 1:35,000,000
500 Kilometers
A Comodora Rivadatia 500 Nautical Miles
Boundary representation is
not necessarily authoritative.
y Stanley
Fatkland Istands
(Istes Malvinas)
(administered by U.K..
claimed by ARGENTINA)
Strait of
South Georgia
60 (Faikland Istands)
o 4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 :
2 Jan Mayen
(NORWAY)
ay
orshavn ¥ Faroe Islands
(DENMARK)
Shetiand
Islands cg
Rockall,
NK Islands
North
Atlantic
(6) cean Dublin
Guernsey (U.K.) «
Jersey (U.K.)°
Bornholm
&venmar
. pha H ostock|
& Hamburg: GER.
|
Havre
e
Son
Paris
is
Na tes oil
y/ Stuttgart My
Strasbourg r GERM NY ee.
Munich”','175f07e521dca6d4ec6a5cd340d065d950ae1982440a5b9c7a25c55e2b248a35','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bb865c45b4fe93e7b9e2533b014bbc7eaccbb61eeb0c5599919e350c3681753',1986,'AW','Aruba','communications',35,'Deui : 4 .
-Caribbean
: Sea...
ORANJESTA
Nicolaas
"See regional map me pS aE:
Land
193 km*: larger than Washington, D.C.','8300780006e318f5c54637e09ec68f9a373d09c375e0a1cbe832be8817618de0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f432c728efdd2ecf7bdd0f615790005ed14fb9bb347018280c42c0a63591a8',1986,'AU','Australia','communications',41,'Railroads: 42,855 km total (1980); 9,689 km
1.600-meter gauge, 15,783 km 1.435-meter
standard gauge, 17,383 km 1.067-meter
gauge; 900 km electrified (June 1979): gov-
ernment owned (except for a few. hundred
kilometers of privately owned track)
Highways: 837,872 km seal (1980); 243,750
km paved, 228,396 km gravel, crushed
stone, or stabilized soil surface, 365, 726 km
unimproved earth
Inland waterways: 8,368 km; mainly by
small, shallow-draft craft
Pipelines: crude oil, 2,400 km; refined prod-
ucts, 500 km; natural gas, 5,600 km
Ports: 12 major, numerous minor
Civil air: : around 150 major Transport air-
craft
Airfields: 1,052 total; 1,009 usable; 221 with °
permanent-surface runways, 2 with run-
ways over 3,659 m; 18 with runways"
2,440-3,659 m, 498 with runways 1,220-
2,439 m
Telecommunications: very good interna-
tional and domestic service; 7.4 million tele-
phones (52 per 100 popl.); 223 AM, 5 FM,
and 11] TV stations; 3 earth satellite sta- -
tions; submarine cables to New Zealand,
Papua New Guinea, Singapore, Malaysia,
Hong Kong, and Guam
Declassified and Approved For Release 2012/08/29 :
Defense Forces :
Branches: Royal Australian Air Force, Royal
Australian Navy, Australian Army.
Military manpower: males 15-49, 4,194,000;
3,542,000 fit for military service; 140,000
reach military age (17) annually
Military budget: for fiscal year ending 30
June 1986, $4.4 billion; about 9.5% of total
central government budget
13
. Austria
See regional map V
Land
83,835 km?; slightly smaller than Maine;
38% forest; 26% meadow and pasture; 20%
cultivated; 15% waste or urban; 1% inland
water
Land boundaries: 2,582 km
Railroads: 6,497 km total; 5.857 km govern-
ment owned; 5,403 km 1.435-meter stand-
ard gauge of which 3,017 km electrified and
1,520 km double tracked; 454 km 0.760-
meter narrow gauge of which 91 km electri-
fied; 640 km privately owned 1.435- and
1.000-meter gauge
Highways: 95,412 km total; 34,612 km are
the classified network (including 1,012 km of
autobahn, 10,400 km of federal, and 23,200
km of provincial roads); of this number, ap-
proximately 21,812 km are paved and
12,800 km are unpaved; additionally, there
are 60,800 km of communal roads (mostly
gravel, crushed stone, earth)
Inland waterways: 427 km
Ports: 2 major river (Vienna, Linz) _
Pipelines: 554 km crude oil; 2,611 km natu-
ral gas; 171 km refined products
Civil air: 25 major transport aircraft
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Seopa PS eS ne ee ee ea,
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Airfields: 56 total, 54 usable; 18-with
permanent-surface runways; 5 with run-
ways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: highly developed and
efficient; extensive TV and radiobroadcast
systems with 9 AM, 669 FM, and 988 TV
stations; 1 Atlantic Ocean INTELSAT sta-
tion; 3.47 million telephones (45.9 per 100
popl.)
Defense Forces
Branches: Army, Flying Division
Military manpower: males 15-49, 1,946,000;
1,647,000 fit for military service; 65,000
reach military age (19) annually
Military budget: for fiscal year ending 81
December 1984, $849 million; about 3.9% of
the proposed federal budget
The Bahamas
200 km _
North
: g Great Abaco Atlantic
? Ocean
. Eleuthera
- i S Island
Cay. $a! Andros ®& 4 . 9
= Island $§
ta “ig Island
North , va omy
Atlantic
Ocean
°
* Great Inagia
See regional map III .
aaa
13,934 km?; about the size of Connecticut;
an archipelago of some 700 islands and keys;
29% forest; 1% cultivated; 70% built on,
wasteland, and other
Water
Limits of territorial waters (claimed): 3nm
(fishing 200 nm)
Coastline: 3,542 km (New Providence
Island, 76 km)
Railroads: none
Highways: 80 km of roads, including 53 km
of sealed roads; remainder are earth formed
or coral surfaced
Inlarid waterways: no water on Neapean
and Philip
Ports: none; loading jetties at Kingston and
Cascade
Airfields: 1 (Australian-owned airport) with
runway 1,220-2,429 m
Telecommunications: 1,500 radio receivers
(1982); radio link service between island and
Sydney; 987 telephones (1982)
Defense Forces
Defense is the responsibility of Australia','358b968e79a591eb7c701b0b3a02c840ec37e70eec3fc952f7d7a9deb00404b7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6d3f50d255315ee68b1a8871903a455c6de84c012ef1c99bf9da25c9b32b9d8',1986,'BS','Bahamas','communications',44,'Railroads: none
Highways: 2,400 km total; 1,350 km paved,
1,050 km gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air-9 major transport aircraft
Airfields: 61 total, 56 usable; 29 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 23 with runways
1,220-2,439 m
Telecommunications: telecom facilities
highly developed, including 84,000 tele-
phones (37.9 per 100 popl.) in totally auto-
matic system; tropospheric scatter and cable
links with Florida; 3 AM and 2 FM stations;
1 TV station; 3 coaxial submarine cables;
satellite ground station under construction
Defense Forces
Branches: Royal Bahamas Defense Force (a
coast guard element only), Royal Bahamas
Police Force
Military budget: for fiscal year ending 31
December 1982 $9.2 million, about 2.5% of
the total budget
16','f693638a1fa12a3ff7ae7d95b6ceb24d24857165e780a123509d6eff01545c2d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('166f800fd1245eaa2340955f0b3ff2bad6c17860faa0e48bf66a47ce1f9bc0d8',1986,'BH','Bahrain','communications',45,'orc A
Persian Gulf
Hawai Islands are *
sputed between
Bahrain and Qatar. ~
Gulf of
4 1Okm
See regional map VI
Land : .
676 km? plus group of 32 smaller islands;
snialler than New York City; 5% cultivated, -
negligible forest; remainder desert, waste, or
urban ;
Water =
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Railroads: none
Highways: 225 km bituminous surfaced;
undetermined kilometers of natural surface
tracks; 25 km bridge-causeway to Saudi
Arabia is under construction with comple-
tion scheduled for January 1986
Ports: | major (Mina’ Sulman), 1 minor
(Mina’ al Manamah), 1 petroleum, oil, and
lubricant terminal (Sitrah)
Pipelines: crude oil, 56 km; refined prod-
ucts, 16 km; natural gas, 32 km
Civil air: 8 major transport aircraft
Airfields: 3 total, 2 usable; 2 with
permanent-surface runways; | with run-
ways over 3,659 m; 1 with runways
1,220-2,439 m
Telecommunications: excellent interna-
tional telecommunications; adequate do-
mestic services; 98,000 telephones (25.4 per
100 popl.); 2 AM, 1 FM, and 2 TV stations; 1
Atlantic Ocean, } Indian Ocean, and 1 Arab
satellite station; tropospheric scatter and
microwave to Qatar, United Arab Emirates,
Saudi Arabia; submarine cable to Qatar and','050144a65b00d3460c9ea549b5978d7875b25b5f5b5ba59fa8835a9eaa511882','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27aeeb0d966318a7c8f183b3eed2e2913a9341d829eb564678f74618d4498cd9',1986,'AE','United Arab Emirates','communications',47,'Defense Forces
Branches: Army, Naval Wing, Air Wing
Military manpower: males 15-49, 125,000;
73,000 fit for military service
Supply: from several West European coun-
tries, especially France and UK
17','2141e58e8ed2c5608febc63b26a8efc11ca6c7762bfab1e0ee8b4455fa999978','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fd3910b03787bbae14c437017d2277e75f8775750c3636cdb5c8a8e04a3a4e4',1986,'BD','Bangladesh','communications',48,'. 150 km:
+ Boundary representation is
not necessarily authoritative
ittagong
Bay of Bengal |
See regional map VIIT
Land .
148 998 km’; slightly ease than sa eoai
sin; 66% arable (including cultivated and
fallow), 18% uncultivated (not available),.
16% forest
Land boundaries: 2,535 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone) .
Coastline: 580 km
Railroads: 4,085 km total (198s) 1, 912 km,
1.000-meter gauge, 978 km 1.676-meter
broad gauge; government owned
Highways: 45,633 km total (1985); 4,076 km
paved, 2,693 km gravel, 38,864 km earth
Inland waterways: 7,000 km; river steamers
navigate main waterways
Ports:-2. sea (Chittagong; Chalna), 7 inland”
Pipelines: 650 km natural gas
Civil air: 15 major transport aircraft
Airfields: 18 total, 13 usable; 14 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m, 7 with runways
1,220-2,439 m iat
PeleconiinicaHans: adequate interna-
tional radio communications and landline
service; fair domestic wire and microwave
service; fair broadcast service; 100,000 (est.)
telephones (0.1 per 100 popl.); 9 AM, 6-FM, 8 °
TV stations, and 1 ground satellite station
Defense Forces
Branches: Army, Navy, Air Force;:paramili-
tary forces—Bangladesh Rifles, Bangladesh
Ansars, Armed Police Reserve, Coastal Po-
lice
Military manpower: males 15-49,
24,622,000; 15,144,000 fit for military ser-
vice ;
Military budget: for fiscal year ending 30°
June 1986, $285 million; about 15% of cen-
tral government budgét
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
. st
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','9248d5c1514df3fa205de16b0ad392b804e04896503232bfa27c2ed58c62f79c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb9218f68d8ffd50988f20a987f22cdf3ffa071d5679d431fabae79c15c4b554',1986,'BB','Barbados','communications',52,'5 km
-North
Atlantic
Caribbean
Sea
See regional map II _ ea: ee
Land a =
430 km2; about half the size of New York
City; 60% crop; 30% unused, built on, or
waste; 10% meadow
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 97 km
Railroads: none
Highways: 1,570 km total; 1,475 km paved,
95 km gravel and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 2 major transport aircraft
Airfields: 1 with permanent-surface run-
ways 2,440-3,659 m
Telecommunications: islandwide automatic
telephone system with 75,000 telephones
(30.0 per 100 popl.); tropospheric scatter link
to Trinidad and St. Lucia; 2 AMstations, 1
FM station, 1 TV station; 1 Atlantic Ocean
satellite station
Defense Forces
Branches: Barbados Defense Force, Royal
Barbados Police Force
Major ground units: Defense Force
Military manpower: males 15-49, 67,000; .
48,000 fit for military service; no conscrip-
tion .
Military budget: for fiscal year 1985, $10.1
million; 3% of central government budget
"
ate','81059ea820346654bb254075e701dfca8158e5e9163ab52c048187d9b9a7b47f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('793f831a7e66fa0a81bc8fc663b0f8450ddbd2df0eb0ee44800efb22da7051d6',1986,'BE','Belgium','communications',56,'50 km
See regional map V
Land
30,540 km?; slightly larger than Maryland;
28% cultivated; 24% meadow and pasture;
20% forest; 28% waste, urban, or other _
Land boundaries: 1,377 km
Water e :
Limits of territorial waters (claimed): 3 nm
(200 nm fishing zone, with equidistant lines
between neighboring countries)
Coastline: 64 km
Railroads: Belgian National Railways
(SNCB) operates 3,471 km 1.435-meter stand-
ard gauge, government owned; 2,563 km
double track; 1,907 km electrified; 191 km
21°
1.000-meter gauge, government owned and
electrified
Highways: 103,396 km total; approximately
1,317 km limited access, divided autoroute;
11,717 km national highway; 1,362 km pro-
vincial road; approximately 38,000 km other
paved; approximately 51,000 km-unpaved
rural
Inland waterways: 2,043 km, of which 1,528
km are in regular use by commercial trans-
port
Ports: 5 major, 1 minor.
Pipelines: refined products, 1,115 km;.
crude, 161 km; natural gas, 3,218km *
Civil air: 47 major transport aircraft
Airfields: 44 total, 43 usable; 25 with - .
permanent-surface rtinways;.14 with run-
ways 2,440-3,659 m, 8 with runways
1,220-2,439 m
Telecommunications: excellent domestic
and international telephone and telegraph
facilities; 4.11 million telephones (41.7 per:
100 popl.); 7 AM,.37 FM, 32 TV stations; 6
submarine cables; 2 Atlantic Ocean
INTELSAT stations
Defense Forces ;
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 2,500,000;
2,115,000 fit for military service; 80,000
reach military age (19) annually
Military budget: for-fiscal year ending 31
December''].984, $2.5 billion; 8.2% of the
central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','9c5a3c85441d7f57fa97dbda58dbf6d4184ea3eaf4cce8156ca52de307081625','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddd69c21cf9af0e8aca7698eb4faac8ad259471921970f02a77c2657eac131ee',1986,'BZ','Belize','communications',60,'(formerly British Honduras)
150 km
Punta Gorda
See regional map II
Land ©
22,963 km2; slightly larger than Massachu-
setts; 46% exploitable forest, 38% agricul-
tural (5% cultivated); 16% urban, waste, wa-
ter: offshore islands, or other
''
Land boundaries: 515 km
Water
Limits of territorial waters (claiméd): 3 nm
Coastline: 386 km
Railroads: none
Highways: 2,575 km total; 340 km paved,
1,190 km gravel, 735 km improved earth,
and 310km unimproved earth
Inland waterways: 825 km tiver network
used by shallow- draft craft; seasonally navi-
gable
Ports: 2 major. + (Belize C City, Belize Ons :
southwest) 5 minor’
Civil air: no ) major transport ee
Airfields: 41 total, 36 usable; 4 with -
permanent-surface runways; 3 with run-
ways 1,220-2,439 m
Telecommunications: 8,650 telephones; (4.5 -
per 100 popl.); above average system based °
on radio-relay; 5 AM and 5 FM stations; 1
Atlantic Ocean INTELSAT station
Defense Forces A.
Branches: British Forces Belize, Belize De-
fense Force, Police Department
Military manpower: males 15-49, 41,000:
25,000 fit for military service; 1,800 reach
military age (18) annually; the nucleus of the
Belize Defense Force (BDF) is the former
Special Force of the Belize Police, which.
was transferred intact to the new organiza-
tion; the bulk of the early recruits were
drawn from the Belize Volunteer Guard, a
home guard force that had previously acted
as a police reserve; the BDF currently con-
sists of full-time soldiers known as the
“Regulars” and an essentially reserve group,
which has maintained the “Volunteer
Guard” name; recruitment is voluntary and
the terms of service vary
Military budget: for fiscal year sendin 31.
March 1986, $3.5 million; 3.3% of central
government budget -','d6e626c824b59479bf675002014075f13215ed85ca9854dcd1bff9c9d51b4a2d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('539b671143c59fa00041e351ed7af768a39dde5df32b41b15d10daa037ae042e',1986,'BJ','Benin','communications',64,'(formerly Dahomey)
150km
Bight of Benin
See regional map VII
Land
112,622 km?; slightly smaller than Pennsyl-
vania; southern third of country is most fer-"
tile; 80% arable land (11% actually culti-
vated); 19% forest and game. preserves; 1% _
nonarable
Land boundaries: 1,963 km
Water
Limits of territorial waters (claimed): 200
nm
Coastline: 121 km .
Railroads: 580 km, all 1.000-meter gauge
Highways: 8,550 km total; 828 km paved,
5,722 km improved earth
Inland waterways: small sections, only im-
portant locally
Declassified and Approved For Release 2012/08/29
Ports: 1 major (Cotonou)
Civil air: 8 major transport aircraft
Airfields: 9 total, 8 usable; 1 with ©
permanent-surface runways; 4 with run-
ways 1,220-2,489 m
Ficcniinsinicdiions: fair system of open
wire and radio relay; 16,200 telephones (0.5
per 100 popl.); 2 AM, 2 FM stations; 1 TV
station; 1 Atlantic Ocean satellite ground:
station ‘ :
Defense Forces’
Branches: Army, Navy, Air Force
Military manpower: eligible 15-49,
1,814,000; of-the 894,000 males 15-49,
453,000 are fit for military service; of the -
920,000 females 15-49, 465,000 are fit for
military service; about 41,000 males and
42,000 females reach military age (18).annu-.
ally; both sexes are liable for military service
24
Gulf of Guinea
See regional map Vu
Land © :
923,768 km?; more than vice the si size or
California; 35% forest; 24% arable (13% of
total land area under cultivation); 41%
desert, waste, urban, or other
Land boundaries: 4,034 km
Water | ;
Limits of territorial waters aati ): 30
nm (200 nm exclusive economic zone)
Coastline: 853 km:
Railroads: 3,505 km 1.067-meter. gauge ”
Highways: 107,990 km total 30,019 FRE
paved (mostly bituminous surface treat-- -
ment); 25,411 km laterite, gravel, crushed -:
stone, improved earth;:52,560-km-unim- -
proved .
Inland waterways: 8,575 km consisting of
Niger and Benue rivers and smaller rivers
and creeks AS
Pipelines: 2,042 km crude oil: 120 km natu-..
ral gas; 3,000 km refined products
Ports: 6 major (Lagos, Port Harcourt, Cala-
bar, Warri, Onne, Sapele), 9 minor
Civil air: 72 major transport aircraft
Airfields: 89 total, 85 usable; 30 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 14 with runways 2,440-.
3,659 m, 22 with runways 1,220-2,439 m
Telecommunications:.above-average sys- ©:
tem limited by poor maintenance; major .
expansion in progress; radio-relay and cable
routes; 155,000 telephones (0.2 per 100
popl.); 37 AM, 9 FM, 34 TV stations; satellite
station with Atlantic and Indian Ocean an-. .
tennas, domestic ’satellite. system with 19
stations; 1 coaxial submarine cable ....
Defense Forces. 2 a
Branches: Army, Navy, Air Force, paramili-
tary Police Force. : ;
Military manpower: males 15-495": . > .
22,607,000; 12,999,000 fit for military ser-
vice; 1,081,000 reach POY age eine) annu-
ally . :','7f326cb04c1b955c7f736af76adb40d3ea54b1a841f772269128d51847d2c1a2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a341c9bf5afd5ebe1b02f685386483fc2ea007c960daf0d0055ef6e3bd09da7b',1986,'BM','Bermuda','communications',68,'Saint Georg a .
North Atlantic Ocean
North Atlantic Ocean
See regional map u
Land re vs ;
53.3 km?, ee one- third ted size et Wash-_
ington, D. C.; consists of about 360 small -
coral islands; 60% forest; 21% built on, waste ,
land, and other; 11% leased for air and naval-.
bases; 8% arable
Water, -: : :
Limits of territorial waters ielatined’: 8nm
(fishing 200 nm)
Coastline: 108 km
People 15) Sua
Population: 59,000 (J le 1986), average an-
nual growth rate 0.6%
Nationality: ain teeeane );adjiec-
tive—Bermudian
Ethnic Hipision®: 61% black, 39% white and.
other
Religion: 37% Anglican, 21% other Protes-
tant, 14% Roman Catholic, 28% Black Mus-
lim and other
Language: English
Infant mortality rate: 7:1/1,000 (1985) -
Life expectancy: men 69, women 76
Literacy: 98%
Labor force: 32,000 employed (1984); 25%
clerical, 22% services, 21% laborers, 13% . ..
: CIA-RDP08-00534R000100170001-4
. woe
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
professional and technical, 10% admiinistra-
tive and managerial, 7% sales, 2% agricul-.
ture and fishing
Deaaee labor: 8,700 members; largest.
union is Bermuda Industrial Union
Railroads: none
Highways: 210 km public roads, all paved
(approximately 400 km of private roads)
Ports: 8 major (Hamilton, St. George)
Civil air: 16 maior transport aircraft
Airfields: 1 with permanent-surface run-
ways 2,440-3,659 m
25°
Telecommunications: modern telecom sys-
tem, includes fully automatic telephone sys-
tem with 46,290 sets (84.6 per 100 popl.); 4:
AM, 3 FM, 2 TV stations; 3 submarine ca- —
bles; 2 Atlantic Ocean satellite antennas: ‘. -
Defense Horses é
Defense is the responsibility of United King
dom
Branches: The Bermuda Régiment
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
- Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','e5821b1ca2291994504daf01337c0b008ebe3ed86490e34175d9b3f40f05a7e5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5c471e6b47ec62fce52fde00ea0ee9e2b83c3c05455f551f2eeeee0bdd20c74',1986,'BT','Bhutan','communications',71,'75 km
See regional. map VIN
Land :
46,620 km?; the size of Vermont and New
Hampshire combined; 70% forest; 15% agri-
cultural; 15% desert; waste, urban -
Land boundaries: about 870 km :
Highways: 1,304 km total; 418 km surfaced,
515 km improved, 371 km unimproved
earth
Civil air: no major transport aircraft; in Feb-
ruary 1983 Druk Air began direct flights
between Paro and Calcutta
Airfields: 2 total; 2 usable; 2 with
permanent-surface runways; 1 with run-.
ways 1,220-2,439 m
Telecommunications: facilities inadequate;
1,300 telephones (0.1 per 100 popl.); 11,000
est. radio sets; no TV sets; 20 AM stations; no
TV stations .
Defense Forces
Branches: Royal Bhutan ety
Military manpower: males 15-49, 357,000,
192,000 fit for military service; about 17,000
reach military age. (18) annually
Supply: dependent on India
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Bolivia
See regional map IV
Land
1,098,581 km?2; hed size of Texas and Califor
nia combined; 45% urban, desert, waste, or -
other; 40% forest; 11% pasture and-meadow;
2% cultivated and fallow; 2% inland water
Land boundaries: 6,083 km
Railroads: 3,675 km total; 3,538 km 1.000-
meter gauge and 32 km 0.760-meter gauge,
all government owned, single track; 105 km
],000-meter gauge, privately owned
Highways: 38,830 km total; 1,300 km paved,
* 6,700 km gravel, 30,886 km improved and
unimproved earth
Inland waterways: officially estimated to be
10,000 km of commercially navigable wa-
terways
Pipelines: crude oil, 1,670 km; refined prod-
ucts, 1,495 km; natural gas, 580 km
Ports: none (Bolivian cargo moved through
‘Arica and Antofagasta, Chile, and Matarani,
Péru)
Civil air: 56 major transport aircraft
Airfields: 592 total, 527 usable; 9 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 8 with runways
2,440-3,659 m, 128 with runways
],220-2,489 m
Telecommunications: radio-relay system
being expanded; improved international
services; 144,300 telephones (2.6 per 100
popl.); 160 AM, 29 FM, 42 TV stations; 1
Atlantic Ocean INTELSAT station
Defense Forces
Branches: Bolivian Army, Bolivian Navy,
Bolivian Air Force (literally, the Army of the
Nation, the Navy of the Nation, the Air
Force of the Nation)
Military manpower: males 15-49, 1,416,000;
927,000 fit for military service; 65,000 reach
military age (19) annually
Military budget: estimated for fiscal year
ending 31 December 1984, $273.0 million;
22.8% of central government budget
28
Bolivia','43e12efd993cfb88773b8e61f8233c77131479cd6813c9c651adde7888543d74','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9c4278d6db0e2363d6a44aecdbeefe080fb1b403daf3dd4aef1351a27417fc',1986,'BW','Botswana','communications',75,'Boundary representation is
not necessarily authoritative.
See regional map VII
Land
600,372 km?; slightly smaller than Texas;
about 6% arable; less than 1% cultivated;
mostly desert
Land boundaries: 3,774 km
Railroads: 726 km 1.0 67-meter gauge
Highways: 11,500 km total; 1,600 km paved;
1,700 km crushed stone or gravel; 5,177 km
29
improved earth and 3,037 km unimproved
earth . :
Civil air: 5 major transport aircraft
Airfields: 108 total, 95 usable; 9 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 24 with runways
1,220-2,439 m
Telecommunications: the small system is a
combination of open-wire lines, radio-relay
links, and a few radiocommunication sta-
tions; 17,900 telephones (1.8 per 100 popl.); 3
AM, 2 FM, 2 TV stations; 1 Indian Ocean
satellite ground station
Defense Forces
Branches: Army, Air Wing, Botswana Police
Military manpower: males 15-49, 211,000;
112,000 fit for military service; 12,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
March 1984, $26.6 million; 7% of central
government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Brazil. .0.8 4 otis ay
iE Foot tthe
North Atlantic
Ocean
Luis
de Janeiro
Bound va sntation is. Sao Paulo
nol necess: sips eit na
” South Atlantic
Ocean
—1000 km_ Porto Alegre
See regional map IV
Land
8,512,100 k2m; larger than contiguous, US:
60% forest; 23% built-on area, waste, and,
other; 138% pasture; 4% cultivated ;
Land ue 13,076 ‘km, ;
Water
Limits of territorial waters (claimed ): 200,
nm
Coastline: 7,491 km
Railroads: 29,300 km total; 25,500 kimi 1.000-
meter gauge, 3,500 km 1.600-meter gauge, ;
200 km 1.435-meter standard gauge, 2,400
km 0.760-meter gauge; 879 km electrified
Highways: 1,498,000 km total; 48,000 km
paved, 1,400,000 km gravel or earth |
Inland waterways: 50,000 km navigable
Ports: 8 maior, 23 significant minor
Pipelines: crude oil, 2,000 km; refined prod-
ucts, 465 km; natural gas, 257 km
Civil air: 176 major transport aircraft
Airfields: 4,188 total, 3,168 usable; 306 with
permanent-surface runways; 1 with run-
ways over 3,659 m; 23 with runways
2,440-3,659 m; 449 with runways
1,220-2,439 m
Telecommunications: good telecom system;
extensive radio relay facilities; 2 Atlantic
Ocean INTELSAT stations with total of 3
antennas: 64 domestic satellite stations: 9.86 .
million telephones (7.3 per 100 popl.); 1,500 :
AM, 200 TV stations; 3 coanal submanag
cables
Defense Forces * Pn
Branches: Brazilian'' Army; Navy of Brazil, ‘
Brazilian Air Force
Military manpower: males 15-49, ;
35,989,000; 24,344,000 fit for military ser-
vice; 1,527,000 reach military age (18) annu-
ally ;
Military budget: estimated for fiscal year
ending 31 December 1986, $3.0 billion; 6. 5%
of central government budget ;
31
British Indian Ocean Territory -—
: _75''km fet .
; tals “"Salomon Islands
Peros Banhos” ~
Chagos
- Archipelago
‘Eagle Islands
‘
~ Egmont Islands
‘Indian Ocean.
ae Garcia
See regional map I
Land
60 km?; one-third the size of Washington,
D. C.; 2,300 islands of the Chagos Archipel-
‘ago, including the coral atolls Diego Garcia
(36 km?), Peros Banhos (29 islands), Salomon
ue islands), Eagle, and Egmont
Water
Coastline: ranges from ee than 1 km to ap-
proximately 100 km around atoll of Diego
Garcia
Limits of territorial waters ipamed), 38nm
(200 nm fishing)','601768ea14e8f557c851a4902ca64ca79717b53c3ca9069390e840e1b1fccb33','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9d5d1249649d6fcab881d2e0372265c40a4a4df04f00aa07e5a44e6f090b49b',1986,'IO','British Indian Ocean Territory','communications',81,'Railroads: noné
Highways: short stretch of paved road be-
tween port and airfield on Diego Garcia
Inland waterways: none
Ports: 1 major (Diego Garcia)
Airfields: 1 usable with permanent-stirface
runways over 3,659 m on Diego Garcia
Télecommunications: minimal telecommu-
nications facilities; US Navy operates 1 AM,
1 FM, and 1 TV station
Defense Forces
United States and United inedom defense —
facilities
British Virgin Islands.
10 km
North “+ Anegada NN
Atlantic: ms yo See
Ocean
- Virgin
Gorda
ST artols ae
Caribbean Sea
See regional map III
Land
153 km?; about the size of Wahington, D. C.;
consists of more than 40 islands; main islands
are Tortola, Anegada, Virgin Gorda, and Jost
Van Dyke .
Water
Limits of territorial waters (claimed): 3nm
(200 nm fishing)
Coastline: about 80 km
Railroads: none
Highways: 106 km motorable roads (1983). -
Inland waterways: none :
Ports: | major (Road Town) |
Airfields: 3 total; 3 usable; 2:with--
permanent-surface runways’
Telecommunications: 3,000 telephones—
worldwide external telephone service and
cable communication links; 1 AM and 1 TV
station ;
Defense Forces
Defense is the responsibility of the United
Kingdom
Brunei
25 km
BANDAR puera
oe A SERI BEG :
_ South China Brunei Bay
Sea
See regional map IX
Land
5,788 km?; slightly larger than Delaware;:
75% forest; 22% industry, waste, urban, or
other; 3% cultivable, of which only 10% is -~
cultivated
Land boundaries: 381 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm fishing zone or median line)
Comin, 161 km
Railroads: 13 km 0. 610- meter narrow-gauge
private line :
Highways: 1,090 km sel: 370 ii paved
(bituminous treated) and another 52 km un- .
der construction, 720 km gravel or unim-
proved .
I ‘Maia nee ae 209 km; navigable by-
craft doe less than a meters
Porti: ‘T major (Muara), 4 ‘minor
Pipelines: wade oil, 185 km; refined er
ucts, 418 km; natural gas, 920 km ;
Civil air: 3 major transport aircraft
Airfields: 2 total, 2 usable; 1 with
permanent-surface runways; | with run-
ways over 3,659 m; 1 with runways
1,220-2,439 m
Féelecommunicationsss service throughout
country is adequate for present needs; inter-
national service good to adjacent Sabah and
Sarawak; radiobroadcast coverage good;
17,930 telephones (8.0 per 100 popl.); Radio
Brunei broadcasts from 6 AM/FM stations
and 1 TV station; 32,000 radio receivers; 1 :
satellite station
Defense Forces °
Branches: Royal Brunei Armed Forces, in-
cluding air wing, navy, and ground forces;
British Gurkha Battalion; Royal Brunei Po-
lice; Gurkha Reserve Unit
Military manpower: males 15-49, 61,000;
37,000 fit for military service; about 3,300
reach military‘age (18) annually
Military budget: for fiscal year ending 31
December 1985, $160.1 million; about 17%
of central government budget
34
Bulgaria —
125 km
See regional map V
Land
110,912 km?; slightly larger than Ohio; 41%
arable; 33% forest; 15% other; 11% agricul-
tural
Land boundaries: 1,883 km
Water
Limits of territorial waters (claimed): 12
nm
Coastline: 354 km’
Railroads: 4,278 km total; all government
owned (1983); about 4,033 km 1.435-meter
standard gauge, 245 km narrow gauge; 770
km double track; 1,994 km electrified
Highways: 36,292 km total; 2,923 km trunk °
roads, 3,740 km class I concrete, asphalkt,. .’
stone block; 5,915 km class II asphalt
treated, gravel, crushed stone; 20,064 km
class III earth; 3,650 km other (1983) © ~
Inland waterways: 471 km (1981)
Pipelines: crude, 193 km; eeied product,
418 km; natural gas, 1,120km
Freight carried: rail—83.4 million metric
tons, 18.1 billion metric ton/km (1985);
highway—900 million metric tons, 16.9 bil-
lion metric ton/km (1985); waterway—4.9
million metric tons, 2.6 billion metric
ton/km (excluding international transit
traffic; 1985)
Ports:3 major (Varna, Varna West, Burgas),
6 minor (1981); principal river ports are
Ruse and Lom (1984)
Defense Forces ; ;
Branches: Bulgarian Péople’ s Army, Fron-
tier Troops, Air and Air Defense Forces,
Bulgarian Navy
Military manpower: males 15-49, 2,172,000;
1,822,000 fit for military.service;.65,000
reach military age (19) sonvally
M ilitary Bidet: est. fa fiscal year. aie
31 December 1985, 1.2 billion leva; 6. 2% of
total budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Burkina
(formerly Upper Volta)
200 km
Boundary representation is
not necessarily authoritative
See regional map VIT
Land
240,200 km?2; the size of Colorado; 50% pas-
ture, 21% fallow, 10% cultivated, 9% forest
and:scrub, 10% waste and other
Land boundaries: 3,307 km
Railroads: 1,173 km Ouagadougou to
Abidjan (Ivory Coast line); 516 km 1.000-
meter gauge, single track i in Burkina
Hichauiga 16;500 km total; 967 kim paved,
7,733 km improved, 7,800 km unimproved
Civil air! 1 major transport aircraft
Airfields: 55 total, 51 usable; 2 with - §
permanent-surface runways; | with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecomimiunications: all services only fair;
radio relay, wire, radio communication sta-
tions in use; 8,600 telephones (under 0.14 per
100 popl.); 2 AM, 2 FM, 2 TV stations; } At-
lantic Ocean INTELSAT station
Defense Forces
Branches: Army, Air Force
Military manpower: males 15-49, 1,582,000;
797,000 fit for militias service; no coriscrip-
tion
Supply: mainly dependent on France, FRG,
and UK
Military budget: for fiscal year ending 31
December 1984, $26.9 million; about 18.1%
of central government budget
Burma
-. 500 km.
Sittwe
Bay of
Bengal
Andaman
_ Sea
See régional map VIII and EX
Land
676,552 km?; nearly as large as Texas; 62%
forest; 28% arable, of which 12%.is-culti-
vated, 10% aban aud other
ee bei ates = 5, 850 ke
Water
Limits of territorial waters (ddienedy 12
nm (24 nm security zone and 200 nm eco-
nomic zone, including fishing)
Coastline: 3,060 km
Railroads: 4,353 km total; all government
owned; 3,878 km 1.000-meter gauge, 113
km narrow-gauge industrial lines; 362 km _ -
double track’
Highways: 27,000 km total; 3,200 km bitu-
minous, 17,700 km improved earth or
gravel, 6,100 km unimproved earth.
Inland waterways: 12, 800 km; 3,200 km
navigable by large. commercial vessels
Pipelines: crude, 680! km; natural gas, 11 km
Ports: 4 maior, 6 minor
Civil air: 17 major transport aircraft (includ-
ing 3 helicopters).
Airfields: 89 total, 83 usable; 29 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 37 with runways
1,220-2,439 m.
Telecommunications: meets minimum re-
quirements for local and intercity service;
international service is good; radiobroadcast
coverage is limited to the most populous ;
areas; 49,597 telephones (1982/83; 1 per
1,000 popl.); 1 AM station, no FM stations, 2
TV stations (December 1982); 1 ground sat-
ellite station ,
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: eligible 15-49,
17,410,000; of the 8,684,000 males 15- 49,
4,806,000 are fit for military service; of the ,
8,726,000 females 15-49, 4,816,000 are fit |
for military service; about 411,000 males
and 401,000 females reach military age (18)
annually; both sexes are liable for military _
service , ,
Military budget: for fiscal year ending 31.
March 1986, $228.29 million; about 22.2% of
central government budget
38','e7043caf0d4d11fed16a5c08a6075e24c855c908978e66ba480fd97bdde805f4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e33639d3d9351b495ef84e55057d9d2ba719202f5a79dae28334f23e192ab27',1986,'BI','Burundi','communications',83,'See regional map Vil
Land _ ;
27,834 km?; the size of Maryland; about 37%
arable (about 66% cultivated); 23% pasture;
10% scrub and forest; 30% other
Land boundaries: 974 km
hqWoads: none
Highways: 5, 900 ‘kin’ total; 400 km paved,
2,500 km gravel or laterite, 3,000 km''im- .
proved or unimproved earth ‘
Inland waterways: Lake Tanganyika; 1 lake
port, at ‘Bujumbura, connects to transporta-
tion systems of Zaire and Tanzania
Civil air: | major ae aircraft
39
Airfields: 8 total, 7 usable; 1 with
permanent-surface runways; ] with run-
ways 2,440-3,659 m
Telecommunications: sparse system of wire
and low-capacity radio-relay links; about
6,000 telephones (0. 1 per 100 popl.); 2 AM, p)
FM, no TV stations; 1 Indian Ocean satellite
ground station
Defense Forces
Branches: Army (including naval and air
units); paramilitary Gendarmerie
Military manpower: males 15-49, 1,095, 000;
569,000 fit for military service; 53,000 reach
military age (16) annually
Military budget: for fiscal year ending 31
December 1985, $33.8 million; about 18% of
central government budget.
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','03b133d7b850cf09eb7d032cbbdfca93827d950a3cb6d5deac0f9c32ff4fdfa8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc7cb91ce76135b86e764ddcc37cb45baf3383226af53bc460c95151816caa32',1986,'KH','Cambodia','communications',87,'(formerly Kampuchea)
"125 km
Gulf of
Thailand Boundary representation ts
Aol Necessarily authoritative
See regional map 1X
Land
181,035 km*; the size of Missouri; 74% for-
est; 16% cultivated; 10% built on, waste, and
other
Land boundaries: dc km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone).
_ Coastline: about 443 km
Railroads: 612 km 1.000-meter gauge; gov-
ernment owned
Highways: 13,351 km total; 2,622 km bitu- —
minous, 7,105 km crushed stone, gravel, or
improved earth; and 3,624 km unimproved
earth; some roads in disrepair
Inland waterways: 3,700 km navigable all
year to craft drawing 0.6 meters; 282 km
navigable to craft drawing 1.8 meters
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Ports: 2 major, 5 minor _
Airfields: 33 total, 14 usable; 8 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: service barely ade-
quate for government requirements and
virtually nonexistent for general public; in-
ternational service limited to Vietnam:and _
other adjacent countries; radiobroadcasts °
limited to 1 station; 1 TV station
Defense Forces
Branches: CGDK consists of National Army
of Democratic Cambodia, Khmer Peoples
National Liberation Front, and Sihanoukist
National Army; PRK——People’s Republic of
Cambodia Armed Forces
Military manpower: males 15-49, 1,749,000;
939,000 fit for military service; about 82,000
reach military age (18) annually','680475128d4591168446755dd824078b895c346181b87f46282186912152330a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f6da40d4effda4cb978c58f3cd9407fdb961941a3eed704ee6f333214b6f10',1986,'CM','Cameroon','communications',91,'300 km
Gulf of Guinea |.
See regional map VII
Land
475,439 krn?; somewhat larger than Califor-
nia; 50% forest; 18% meadow; 13% fallow;
4% cultivated; 15% other |
Land boundaries: 4,554 km
Water
Limits of territorial waters (claimed): 50
nm
Coastline: 402 km |
People a &
Population: 10,009,000 (July 1986), average
annual growth rate 2.8%
Nationality: noun—Cameroonian(s); adjec-
tive—Cameroonian
Ethnic divisions: over 200 tribes of widely
differing background; 31% Cameroon High-
landers, 19% Equatorial Bantu, 11% Kirdi,
10% Fulani, 8% Northwestern Bantu, 7%
Eastern Nigritic, 13% other African, less
than 1% non-African
Religion: 51% indigenous beliefs, 33% Chris-
tian, 16% Muslim
Language: English and French (official), 24
major African language groups
Infant mortality rate: 113/1,000 (1985)
Life expectancy: 47
4]
Literacy: 65% |
Labor force: (1983) 74.4% agriculture, 11.4%
industry and transport, 9.7% other services
Organized labor: under 45% of wage labor...
force : ;
Railroads: 1,173 km total; 858 km 1.000-
meter gauge, 145 km 0.600-meter gauge
Highways: approximately 65,000 km total,
including 2,682 km bituminous, 30,000 km
unimproved earth, 32,318 km gravel, earth,
and improved earth
Inland waterways: 2,090 km; of decreasing
importance
Ports: 1 major (Douala), 3 minor
Civil air: 6 major transport aircraft
Airfields: 62 total, 57 usable; 7 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m, 24 with runways
1,220-2,489 m
Telecommunications: good system of open
wire and radio relay; 47,200 telephones (0.5
per 100 popl.); 10 AM, 1 FM, no TV stations;
1 Atlantic Ocean satellite station; planned
TV network
Defense Forces
Branches: Army, Navy, Air Force; paramili-
tary.Gendarmerie.
Military manpower: males 15-49, 2,223,000;
1,119,000 fit for military service; about
92,000 reach military age (18) annually
Military budget: for fiscal year ending 30
June 1985, $130 million; 9. 1% of central gov-
ernment budget _
42
Douala
* Yaoundé
Apnobon-
South
Atlantic
Ascension”
(St. Helena)
Ocean
St. Helena’
WK)
Pointe-Noirdy,
GA8ON CONGO,
Brazzaville
* Kinshasa
oer a
Luanda
» Malanje','79c58226b08f19d6633882394969febc498d1e7f0ea2225b3a63c66c521715c0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('123917ae1a7db724d1aa66051a3148246537da6eba5fa1bb74a6a72dc91186b5',1986,'CA','Canada','communications',93,'1200 km
Arctic Ocean sf
ey
ancouver
Lake Superior
Lake Huron ¥SToronto
See regional map II
Land
9,970,610 km?; slightly larger than the US;
44% forest; 42% waste or urban; 8% inland
water; 4% cultivated; 2% meadow and pas-
ture
Land boundaries: 9,010 km
Water , : ;
Limits of territorial waters (claimed): 12
m (fishing 200 nm)
Coastline: 58,808 km coastline, 243,791 km
including all islands
People 1s
Population: 25,644,000 (July 1986), average
annual growth rate 1.0%
Nationality: noun—Canadian(s),
adjective—Canadian
Ethnic divisions: 45% British Isles origin,
29% French origin, 23% other European,
1.5% indigenous Indian arid Eskimo
Religion: 46% Roman Catholic, 16% United
Church, 10% Anglican
Language: English and French (official)
Infant mortality rate: 9.1/1,000 (1982)
Life expectancy: men 71.9, women 79
Literacy: 99%
: CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: 12.6 million (1985 average);
68% services (37% government, 23% trade
and finance, 8% transportation), 18% manu-
facturing, 6% construction, 3.8% agriculture,
5% other; 10.6% unemployment (1985 aver-
age); 10.2% unemployment (November
1985) .
Organized labor: 30.6% of labor forbes;
89.6% of nonagricultural paid workers
Railroads: 81,607 km total; 80,258 km 1.435-
meter standard gauge, 129 km electrified;
1,171 km 1. 067- meter gauge (in New-
ene) 178 3km 0.91:4-meter gauge
Highaays: 884, 272 km Fatal 712, 936 km
surfaced (250, 028 kim mpaved) 171,336 km
earth '' a
Inland ane 3,000''km
Pipelines: oil, 23, 564 km total crude and
refined; natural gas, 74, 980 km
Ports: 25-deep, water, numerous minor
Civil air: 636 maior transport aircraft
Airfields: 1,472:total, 1,252 usable; 408 with
permanent-surface runways; 4 with run-
ways over 3,659 m, 31 with runways
2,440-3,659 m, 324 with runways 1,220-
2,489 m
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Canada (continued)
Telecommunications: excellent service pro-
vided by modern telecom media; 16.6 mil-
lion telephones (66.4 per 100 popl.); country-
wide AM, FM, and TV coverage, including
900 AM, 80 FM, 1,100 TV stations; 6 coaxial
submarine cables; 3 satellite stations with a
total of 5 antennas and 100 domestic satellite
stations
Defense Forces
Branches: Mobile Command, Maritime
Command, Air Command, Communica-
tions Command, Canadian Forces Europe,
Training Command
Military manpower: males 15-49, 6,961,000;
6,072,000 fit for military service; 199,000
reach military age (17) annually
Military budget: for fiscal year ending 31
March 1985, $6.6 billion; about 10.0% of
central government budget.
Cape Verde
Nicolau
North Atlantic Ocean
9 Sota vento
nas 4
a"
BravaQ
See regional map VII
Land
4,040 km?, divided among 10 islands and
several islets; slightly larger than Rhode
Island
Water
Limits of territorial waters: 12 nm (200 nm
exclusive economic zone); maritime limits
measured from claimed “archipelagic
baselines” that generally connect the outer-
most points of outer islands or drying reefs
Coastline: 965 km
Ports: 2 major (Mindelo and Praia), 2 minor |‘.
Civil air: 2 niajor transport aircraft
Airfields: 6 total, 6 usable; 4 with
permanent-surfacée runways; | with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: interisland radio-
relay system, high frequency radio to main-
land Portugal and Guinea-Bissau, about
1,740 telephones (0.6 per 100 popl.); 2 FM 2
AM, stations; 1 small TV station; 2 coaxial
submarine cables; 1 Atlantic Ocean satellite
ground station
Defense Forces
Branches: People’s Revolutionary Armed
Forces (FARP); Army, Navy, and Air Force
are separate components of FARP
M ilitary manpoiber: males 15-49, 87,000; °
50,000 fit for military service
Military budget: for fiscal year ending 31
December 1980, $15 million, about 5% of
central government budget
45
Cayman Islands)
50 km :
g Grand Cayman
GEORGE TOWN
Caribbean Sea
See regional map lil
Land
260 km’; about one-third the size of New
York City; consists of three low-lying islands .
formed of calcareous rock, with maximum
elevations of 12 m (Little Cayman); 18m
(Grand Cayman), and 42.7 m(Cayman
Brac); about two-thirds of land consists of
mangrove swamps
Water
Limits of territorial waters (claimed): 3 nm
Coastline: about 160 km
Cape Verde','50498bf94ec93f38b8c4ecb7548493e0af5d96fb41b47926a955f2e0a63611b4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('524059cead6471cee21f515c653173bf9f0e778b54064bfc06032f8f57c8d745',1986,'CF','Central African Republic','communications',99,'Railroads: none
. Highways: 20,800 km total; 454 km bitumi-
nous, 7,656 km improved earth, 12,690 Okm
unimproved earth
47
Inland waterways: 800 km; traditional trade
carried on by means of shallow-draft dug-. ,
outs
Civil air: 3 major transport aircraft,
Airfields: 67 total, 59 usable; 4 with |...
permanent-surface runways; 2 with run-.
ways 2,440-3,659 m, 21 with runways
1,220-2,439 m..
Telecommunications: facilities are meager; »
network is composed of low-capacity, low- .
powered radiocommunication stations and
radio-relay links; 6,000 telephones (0.2 per.
100 popl.); 1 AM station, 1 FM station, 1 TV
station; 1 Atlantic Ocean satellite ground . e
station
Defense Forces _ . _
Branches: ney, Air Force
Military manpower: males 15- 49. 608, 000:
312,000 fit for military service
Military bideer: for Rscal year spending 31 7
December 1983; $12.2 million; about 14. 5%
of central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','79f4ec8b5c981e5bba6d610791f041f03f23810433fa3afd6010db4d979452b1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c1a763b21108454dc50bfcb07b7aff468b72810a37027fa33bac05fbe01a8eb',1986,'TD','Chad','communications',100,'400 km
See regional map VII
Land ''
1,284,634 km?; about thes sizeof Texas, Okla-
homa, and New Mexico combined; 35% pas-
ture; 17% arable; 2% forest and scrub; 46%
other use and waste -.-
Land boundaries: 5,987 km
Railroads: none
Highways: 31,300 km total; 28 km bitumi- -
nous,''7,300 km gravel and laterite, remain-
der bnumeroved
Inland waterways: approximately 2,000 km
navigable —
Civil air: 3 major transport aircraft
Airfields: 80 total, 70 usable; 5 with
permanent-surface runways; 1 with run-
ways over 3,659''m, 2 with runways 2,440-
3,659 m, 26 with runways 1,220-2,439 m
Telecommunications: fair system of
radiocommunication stations for intercity ~
links; 5,000 telephones (0.1 per 100 popl.); 1
FM, 3 AM stations; many facilities, includ-
ing satellite ground station, inoperative
Defense Forces
Branches: Army, Air Force, paramilitary
Gendarmerie, Presidential Guard
Military manpower: males 15-49, 1,194,000;
616,000 fit for military service; about 49,000
reach mpiltary. age (20) annually :
Sai eee dependent on France
Military budget: for fiscal year ending 31
December 1984, $8.7 million; about 25% of
total budget
Maiduguri*','a6f38ce5ba163522a827d4a73a8dc2ac62bda842472573b9f5f79b48b13518f0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e36ccb6381f84ade357cd66f89a8b03afeb292080bf988d746a2ea9d1ed98147',1986,'CL','Chile','communications',104,'* :_ 1000 km
La Serenaf
South
Pacific ANTIAGO
Ocean
Concepci6n
Punta Arenasé¢ 3
Boundary representation ts
See regional map IV not necessarily authoritative.
Land - ©
756,945 km?; larger than Texas; 47% barren
mountain, desert, ‘and urban; 29% forest;
15% permanent pasture, meadow; 7% other |
arable; 2% ulated: ;
Land boundaries: 6,325 km
Water
Limits of territorial waters (claimed ): 3m
Coastline: 6,435 km
China, People’s
Republic of','21887820d2afe12f2a29fa44cf827274cb171c4c8814c27d5ab57781568fd9ea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43f177a212dac0f61b627e0fdb69b52cb9cec6972d0d73dfe6937ca3cd3ee54d',1986,'CN','China','communications',110,'Railroads: networks total about 52,500 route
km common carrier lines; about 600 km
1.000-meter gauge; rest 1.435-meter stand-
ard gauge; all single track except approxi-
mately9,500 km double track on standard
gauge lines; approximately 4,200 km electri-
fied; about 10,000 km industrial lines (gauges
range from 0.762 to 1.067 meters)
Highways: about 950,000 km all types roads;
about 240,000 km''unimproved natural earth
roads and tracks, 540,000 km improved
earth roads, 150,000 km paved roads
Inland waterways: 138,600 km; about
108,900 km navigable
Pipelines: criide, 6,500 kim; refined prod-
ucts, 1,100 kim; natural gas, 4,200 km
Ports: 15 major, approximately 180 minor
Airfields: 325 total; 266 with permanent-
surface runways; 11 with runways 3,500 m
and over; 80 with runways 2,500 to 3,499 m;
203 with runways 1,200 to 2,499 m; 28 with
runways less than 1,200 m; 2 seaplane sta-
tions; 4 heliports, 5 airfields under construc:
tion ;
Telecommunications: domestic and inter-
national services exist primarily for official
purposes; unevenly distributed internal sys-
tem serves principal cities, industrial cen-
ters, and most townships; services in interior
and border regions limited; nearly 3 million
equipped telephone exchange lines, includ-
ing 30,000 long-distance telephone exchange
lines with direct, automatic service to 24
cities; 5.2 million telephones (3-5 telephones
per 100 popl. in large cities, 1 telephone per
200 popl. national average); 50,000 post and
telegraph offices with about 700 main tele-
graph centers capable of general message
service at the county level and above;sub-
scriber teleprinter exchange (telex) services
available in 25 main metropolitan areas;
unknown number of facsimile and data iii- ©
formation transfer points; domestic audio
radio broadcast coverage provided by 122
main AM centers and about 525 transmitter’
relay stations; unknown number of FM ra-
dio and wired rebroadcast stations with 215
million receivers; at least 52 TV centers;
about 400 local.and network TV relay trans-
mitter stations; 7,000 supplementary video
recorder and redistribution facilities; 40 mil-
lion monochrome and color TV receiver sets;
2 major international switching centers; sat-
ellite communications, long-haul point-to-
‘point radio circuits, regional cable and wire
landlines, directional radio-relay, and sea-
bed coaxial telephone cable (damaged) per-
mit linkage with most countries; direct voice
and message communications with 46 coun-
tries and regions; TV exchange to major cit-
ies on 5 continents through INTELSAT Pa-
cific and Indian Ocean earth satellite; AM
radio broadcasts in 38 languages to 140
countries and regions
Defense Forces
Branches: Chinese People’s Liberation
Army (CPLA), CPLA Navy (including ma-
rines), CPLA Air Force
Military manpower: males 15-49,
291,558,000; 162,738,000 fit for military
service; 13,270,000 reach military age (18)
annually :
52
Railroads: 21,387 km total (1982); 1,835 km
1.435-meter standard gauge, 19,552 km pre-
dominantly ].067-meter narrow gauge,
5,690 km double- and multitrack sections,
8,830 km 1.067-meter narrow-gauge electri-
fied, 1,804 km 1.435-meter standard gauge
electrified
Highways: 1,113,388 km total (1980);
510,904 km paved, 602,484 km gravel,
crushed stone, or unpaved; 2,579 km na- |
tional expressways, 40,212 km national high-
ways, 43,907 km principal local roads,
86,930 km prefectural roads, 939,760 km
municipal roads
Inland waterways: approx. 1,770 km; sea-
going craft ply all coastal inland seas’
Pipelines: crude oil, 84 km; natural gas,
1,800 km; refined products, 322 km
Ports: 17 Japanese Port Association specifi-
cally designated major ports, 110 other ma-
jor ports, over 2,000 minor ports
129
Civil air: 265 major transport aircraft
Airfields: 180 total, 160 usable; 126 with
permanent-surface runways; 2 with run-
ways over 3,659 m; 26 with runways
2,440-3,659 m, 49 with runways 1,220-
2,439 m.
Telecommunications: excellent domestic
and international service; 64.0 million tele-_
phones (53.0 per 100 popl.); 318.AM stations,
58 FM stations plus 436 relay stations; about
12,350 TV stations (196 major—1 kw or
greater), and 2 ground satellite stations; sub-
marine cables to US (via Guam), Philippines,
China, and USSR
Defense Forces
Branches: Japan Ground Self-Defense Force
(army), Japan Maritime Self-Defense Force °
(navy), Japan Air Self-Defense Force (air .
force), Maritime Safety Agency (coast guard)
Military manpower: males 15-49,
31,702,000; 26,438,000 fit for military ser-
vice; about 870,000 reach military age (18) .
annually
Personnel: Ground Self-Defense Force,
156,000; Maritime Self-Defense Force, _
42,100 (including 11,900 air arm); Air Self-
Defense Force, 43,400; Maritime Safety
Agency, 11,200
Missiles: 6 operational NIKE-Hercules .
groups, 8 operational HA WK groups (NIKE
in air force, HAWK in ground force)
Supply: defense industry potenticz is large, ‘
with capability of producing the most so-
phisticated equipment; manufactured
equipment includes small arms artillery,
armored vehicles, and other types of ground
forces materiel, aircraft (jet and prop), naval
vessels (submarines, guided missile and other
destroyers, patrol craft, mine warfare ships,
and other minor craft, including amphibi-
ous, auxiliaries, service craft, and small sup-
port ships), small amounts of all types of
army materiel; several missile systems are
produced under US license, and a vigorous
domestic missile development program
exists
Military budget: actual for fiscal year end-
ing 31 March 1987, $16.7 billion; 7.8% of
total budget
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Railroads: 2,834 km total; 2,262-1.000-meter
gauge, 130 km standard gauge, 230 km dual
gauge, 212 km unoperable
Highways: 41,191 km total; 5,471 km bitu-
iminous, 27,030 km gravel or improved
earth, 8,690 km unimproved earth
264
Pipelines: 150 km, refined products
Inland waterways: about 17,702 km naviga-
ble; more than 5,149 km navigable at all
times by vessels up to 1.8-m draft
Ports: 9 major, 23 minor
Civil air: controlled by military
Airfields: 217 total, 128 usable; 46 with =" *
permanent-surface runways; 12 with run-
ways 2,440-3,659 m, 28 with runways
1,220-2,439 m
Defense Forces os
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
14,619,000; 9,290,000 fit for military service;
687,000 reach military age (17). annually
Military budget: no expenditure estimates, *~
are available; military.aid from the USSR; :. -
has been so extensive that actual allocation .
of Vietnam’s domestic resources to defense
has not been indicative of total military ef-. . -
fort
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Bay of on
Bengal Andaman
Lakshadweep , tslands
Andaman
pa sane f a
ea i
“2 Nicobar
af : 9 Islands
MALDIVES 3 & =
a Scale 1:46,000,000
& :
Ste ° 500 1000 Kilometers
as Re
fe ; 500 1000 Nautical Miles SS a
ee eo
800545 (545532) 4-86 Map VIII
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Southeast Asia
TT T
20-
» 130 140
.
Butad, 2 ,
f % :
sajna :
r os
Wuntho i ot
— Boe an tah lly pig mathe Pas ene Tropic of Cancer
a +Falam J Lastio,
rh) 3
De , Mandalay
i ¥ :
fe URMA Hanoiy
My \\, kyab ¥Yenangyaung leon ‘ Batan Islands
Fe 5 Strait, is
: <S Babuyan istands
Chiang | ce
Mai Apart
, Paracel aan
Moujmein THAILAND ‘- Islande . Pid ie :
} [Nakhon ae ilippine
. Preparis Island awan nt
\\ Ratchathani South |
Coco Istands Ss |
Coca Channel «Bangkok Ji ea
5 : ay China a
: Meigdl, shal
= Sea -.Ay, Samar
ey i) if 4 @geatbatogan
Andaman 4% Ho Chi-Minh City, : ‘ 2. g <i
sy ea pratiy er ql
-10 Sea “Wt | Gull of Islands .
.f S23) Thailand ee '' 7 vy
° , i
Surat % 2
fee besThani & . ‘Con Dao ‘
of Phuket§¢
% ze ‘ G Songkhia a > : 1
hannel - fs *
rset Chane ui ae Kota Kinabatu, ais h N olrt h
Banda Aceh! George Town ,f ay ; ¥ eacewant eeu . Pulau Miangas
=louh zd : BRUNE! *| Archipelago aoa 3 Paclitic
a ; F epulauan :
AMAL A YS $ _ Talaud
%, % Kuala Lompur ». Kepulauan MALAYSIA ti
a %, . ve Natuna > aeskan we letes (Kepolauan ee Beak Oclean
Pulau Simeulue». oN Mataka\\ m +Sibu ea ¢ Sangihe 0
SINGAPORE eBuchita x
Pulau Wiad Abia Halmal
%
-o i Borneo Molucca _*,
* Pontianak
Samarinda* Palyy
Sea Esa .
Gun eral Fakfal
Kendari aS
mbon [| ™
fd Pulau 4 is
ye Kokenag
Buton
* nda Sea : New
Bawa? ** Be
‘ : . ‘Kepulauenthe™ i
woe | eae JN D-O|IN E SIA joe” &
°°
Bengkulu Parepara\\
Tanjungkarang- xt cian
et Java Sea Z jungpandang
Setat Sunda
‘
Kepulauan
Aru
Pulau Siberut My en Makassar oe Le
“| Bangka Strait or ys Cone io p =. ‘
Kepulauan Ss ay Coramy See |<: \\ Weren Jayapura’;
Mentawai \\ Palembang* : aiaca Banjarmasin F :
ps Java |semarang ‘f3aranaya Flore | Sen! Be Be “f/Jreputauan ''
a <Yogyakarta Bali Lombok Fl ; — eo) i j
ok, ° fee Seert 3 tome oO) YX Tanimbar el
fe) ae, a . “Bit | Merauke
Creva p Selat Lombok ‘umbawa __| ig Arafura Sea
46 Was has ane Savu Sea Timor i Torres |
E > 4 :
Christmas Island - Sumba 2 BP Repang ee s,
(AUSTL.)
Cocos
(Keeling) - Scale 1:23,000,000
Islands
(AUSTL.) i} 500 Kilometers
oO $00 Nautical Miles
Boundary representation is not necessarily authoritative.
Names in Vietnam are shown withayt dincritieal marks,
110
Ll
800546 (545533) 4-86 Map IX
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Oceania
180 * midway Islands
ws)
Hawaiian
Istands yu
geval UNITED
Oahu
lula 3pq, Maui STATES
— =e mar ——
ws)
Philippine 3 Mariana t
& Islands H Johnston Atolt 2
Saipany . WS.) | i
Sea i .
Guam %, ig it ‘
4.8) "Agana North Pacific) Ocean :
Enoyetek @ 6.
Yee a Trust Territory of ihe Pacific: Islands Kw oy 2 aah 7
° er CO oe Ws) 2: x 8 islands .
a 2 ae? Truk jslands *e m
@ Palau tslands se "Oe 8 Fo eo Kingman Reef 1
"Caroline ° Islands | WS)5
$ e : oe 8 5 i
o . Patmyra Atoll +
e WS) .
Tarewat Howland Istand echetstmes
Equator Gilbert (US) § Baker Istand { o4
° Yaren® se ciane - islands ws) Jarvis tstand’ {
at Set aw NAURU "49°? ws) |
CBs ytg °° KIREBATI Phoenix islands Line
bg Nei? Kei ee a Islands
Bilin WySoveainvils °
PAPUA NEW GUINEA oN o 8 i
‘ssisnied* Bet 2 SOLOMON TUVALUe’ Tokelau KIRIBAT! ; a Mos
ren \\ ISLANDS Funatuti® {REW ZEALANDD > 24a Marquises
Aratura Sea Toi 7 NE ‘at e 7 :
ar - trait : be 7 =
imor Sea ys 48 Sgrigcee, . * om ; ;
re and > * Rotumas Wallis and WESTERN American i
shmors and Futuna» SAMOA Samoa s l
(qUSTRAUAY > (PRENCEMata 4 em SoS? Le ; .
. “Ue AP Bee Coo} ages >
: Vanua Pago S00»
Indian Ocean i i . Islands Bem 88.2, a4
Cains 3s Coral S t Ful ioc! (NEW ZEALAND) oy Mae en R 2" » Hlos/ruamotu
se oral Sea port via VANUATU viathicbe? ies deta q spPapdete s''* 9.0 ,| >
Coral Sea Levu o* SOY ‘. 7 Socisté "Tahiti oS], 88
“ ae, Alofi ghtue © as
Townsville Islands a s (WeW ZEALAND) os of 2?
-20: ounevite = ik i 20-
qausTRatiay ; New TONGA Saige ; = =
i ''3_|Caledonii <Cevad-fa *Nukwalofa £ < French Polynesia ory
; . ange (FRANCE) % J
ae pic of Capricorn i {es Tie Le ota
“alice eS eae Sn eee hoe ae ety
Springs Adamstown pitcaitn tstands
rina)
AUSTRALIA a i
Brisbane jy : Rapa
3
{Geraldton Kingston® Norfolk tsiand me ‘
ak (AUSTRALIAD Eh caas ae :
+Kalgoorlio 3 stands South |Pacific Ojcean
LPerth Lord Howe *
| tsland
JEseerance, wayalla Hl
sey .
Great Australian i
tomes i
Bight Auckland''e@}{, North {island :
Melbourne, - * :
Pl mouth, rr ‘
Tasman | Sea iyenions isborne:
° :
a0 Base NEW ms 2 a
| PRG ZEALAND |
sCainceston Rigtinaton \\
Hoven, {Tasmania Greymouth
a ristehureh
Injdian Ocean *Egnatnam Scale 1:38,000,000
'' -Dislangs t
South Island 0} 500 1000 Kilometers
ivorcaf gi Dunesin o | 500 1000 Nautical Miles
0 !
420 160 ‘Stewart Island 160 140
800547 (545534) 4-86
140
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Map X
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
180
North Pacific
B enng
ati
ONT: pihTe Sv 4
Fairbanks,
hes)
seh
sy ce
swiangel
g Island
a ae
cS average minimum
‘
extent of sea ice East Siberian
i Sea
t
!
‘
1
Siberian
Banks tstands
Island
Severnaya A
Zemlya \\ Xx
Stags Battin
land§ Bay oy
Pi
fy 3 in a.
Og ae ae
Deterareuses
7 Davis \\
Strait
Godthab
(Nuuk)
Ocean
PSG
hee
Scale 1:43,000,000
500 1000 Kilometers
800548 (545666) 4-86
AL
;
Novaya
\\ Zemlya
x Longyearbygn, Fee gwoRway) S \\
Greefhtland Barents Sea
(DENMARK) H \\ >
Bjgrngya\\','f1b9521912d0a4c6c51303a7d1fcef3e4c24ce7362eec860219841e7ce12117c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('add68e9476f23462d0101d36b486ea8494a5114ada706f4c00663e54779b490f',1986,'CX','Christmas Island','communications',111,'ES
Skm Indian Ocean
THE SETTLEMENT
Indian Ocean
"See regional map 1X
Land
135 km? slightly smaller than Washington,
D.C.; mostly tropical] rain forest
Water: —
Limits of territorial waters (claimed): 3 nm
(200 nm fishing)
Railroads: none
Ports: Flying Fish Cove .
Airfields: 1 usable with permanent-surface
runway 1,220-2,439
Telecommunications: 4,000 padio: receivers
(1982)
Defense Forces
Defense is the cepanebilitg of Australia
Colombia .
Caribbean
Sea
Barranquil
Puerto
North ; Carrefhio
Pacific Ma
Ocean
San Felipe
See regional map IV
Land
1,138,914 km?2; about the size of Texas and
New Mexico combined; 72% unsettled
(mostly forest and savannah); 28% settled
(consisting of 5% crop and fallow; 14% pas-
ture, 6% forest, swamp, and water; 3% urban
and other)
Land aac 6,035 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 2,414 km
Railroads: 3,563 km, all 0.914-meter gauge,
single track .
Highways: 75,450 km total; 9,350 km paved,
66,100 km earth and gravel surfaces
Inland waterways: 14,300 km, navigable by
river boats
Pipelines: crude oil, 3,585 km; refined prod-
ucts, 1,350 km; natural gas, 830 km; natural
gas liquids, 125 km
Ports: 6 major (Barranquilla, Buenaventura,
Cartagena, San Andrés, Santa Marta,
Tumaco)
Civil air: 106 major transport aircraft
Airfields: 634 total, 618 usable; 65 with.
permanent-: sairtane runways; ] with r run-_
ways over 3,660 m; 10 with runways 2,440-
3,659 m, 96 with runways 1,220-2,439 m ,
Telecommunications: nationwide radio- “*
relay system; 1 Atlantic Ocean satellite sta-
tion with 2 antennas and 11 domestic satel- ~
lite stations; 1.89 million telephones (6.5 per. ''
100 popl.); 404 AM.and 85 TV stations
54
Defense Forces
Branches: Army of Colombia, Colombian
Air Force, National Navy
Military manpower: males 15-49, 7,763,000;
5,504,000 fit for military service; about
861,000 reach muliiary age ae annually
Military budget: os fiscal year ending 1986,
$310.6 million; 7% of the central govern-
ment budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','c33d0849f7932bd7cc691409cd8dd26e07fad20694dd898f22323ce82a7065de','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c32148f78654486273f809c12f6b489dccde4b463866603c7c747b2fb3931af2',1986,'KM','Comoros','communications',115,'50 km__-
Indian Ocean
RONI a
rande Comore .
Mutsamud:
* Mayotte ee
Mozambique Administered by France.
Channel ° claimed by Comoros S
See regional map VII
Land
2,171 km?; half the size of Delaware; 4 main
islands; 48% cultivated, 29% uncultivated, -
16% forest, 7% pasture
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 340 km
Railroads: none
Highways: 1,110 km total; approximately. he
400 km bituminous, remainder crushed .
stone or gravel
Ports: 1 major (Mutsamudu on Anjouan
Island); 2 minor
Civil air: 4 major transport aircraft
Airfields: 4 total, 4 usable; 4 with —-
permanent-surface runways; | with run-
ways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: sparse system of
radio-relay and high frequency radio com-..°
munication stations for interisland and ex-
ternal communications to Madagascar and
Reunion; 1,800 telephones (0.4 per 100
popl.); 2 AM stations, 1 FM station, no TV
stations :
Defense Forces dae
Branches: Army, Presidential Guard, .. _
Gendarmerie
Military manpower: nals 15- 49, 93,000;
55,000 fit for military service
Military budget: for fiscal year ending 31: one
December 1981, $2.9 million; about 16% of
the central government budget ..
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','0f483c7c6ac7b5a33849c0249a6c31ffe9de8096a86c3d1e99c31150446637c3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70537b6e2e4daeffd250b0d42d5e18089a8fdc887bbec34d2a5abd78b06a829f',1986,'GN','Guinea','communications',119,'inte
Noire
See regional map VII
Land
342,000 km?; slightly smaller than Montana;
63% dense-forest or wood, 31% meadow, 4%
urban or waste, 2% cultivated (est.)
Land boundaries: 4,514 km
Water
Limits of territorial waters (claimed): 200
nm
Coastline: 169 km
Railroads: 727 km, L 067- meter gauge, -
single track i
Highways: 11,970 km a''s 555 km bitumi- °
nous surface treated; 848 km gravel, laterite,
5,347 km improved earth, and 5,220 km
unimproved roads ,
Inland waterways: the Congo and Ubangi’
Rivers provide 1,120 km of commercially
navigable water transport: the remainder of
the inland waterways are used for local
traffic only :
Pipelines: crude oil 25 km
Forts: 1 major Fomte: Nowe)
ag air: 6 major transport euciatt
Airfields: 55 ran 51 eae ‘4 oT
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 21 with runways
1,220-2,489 m
Telecommunications: services adequate for
government use; primary network is com-
posed of radio-relay routes and coaxial -
cables; key centers are Brazzaville, Poirite--
Noire, and Loubomo; 18,100 telephones (1.1
per 100 popl.); 3 AM, 1 FM, 4 TV stations; 1
Atlantic Ocean satellite station
Defense Forces
Branches: Army, Navy, Air Force, paramili-
tary Natenal People’ Ss Militia
Military manpower: males 15- 49, 410,000;
206,000 fit for military service; about 19,000-
reach military age (20) annually
Railroads: none
Highways: Rio Muni—2,460 km, including
approx. 185 km bituminous, remainder
gravel and earth; Bioko—-300-km, including
146 km bituminous, remainder gravel and
earth
Inland waterways: no significant waterways:
Ports: 1 major (Malabo), 3 minor -
Civil air: 1 major transport aircraft.
73
Airfields: 3 total, 2 usable; 2 with
permanent-surface runways; | with run- ©
ways 2,440-3,659 m, 1 with runways
1,220-2,489 m- = }
Telecommunications: poor system with ad-
equate government services; international
communications from Bata and-Malabo to’
African and European countries; 2,000 tele-
phones (0.6 per 100 popl.); 2 AM stations, no
FM stations, 1-TV station -:
Defense Forces :
Branches: Army, Navy, and possibly Air
Force
Military manpower: males 15-49, 79,000;
89,000 fit for military service
Military budget: for fiscal year ending 31
March 1981, $6.2 million; 21% of central
government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
-
pe
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
See regional map VIE
Land
267,667 km?; the size eof Colorado; 75% for-
est, 15% savanna, 9% urban and waste, less
than 1% cultivated _
Land boundaries: 2,422 km’
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 885 ira
Railroads: 970 km 1. 437- meter standard _
gauge. under construction; 338 km aré com-. +
pleted ;
Haha: 7,393 km total; 300 km paved,
3,493 km gravel and improved, 3,600 km
unimproved .
Inland waterways: approximately 1,600 km
perennially navigable
Pipelines: crude oil, 270 km
Ports: 2 major (Owendo and Port- Gentil, 3
minor ;
Civil air: 12 major transport aircraft
Airfields: 79 total, 73 usable; 9 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 21 with runways.
1,220-2,439 m
Telecommunications: adequate system of
open-wire, radio-relay, tropospheric scatter
links and radiocommunication stations; _
13,800 telephones (1.2 per 100 popl.); 6 AM,’
6 FM, 8 TV stations; 2 Atlantic Ocean satel-
lite stations
Defense Forces a
Branches: Army, Navy, Air Force, paramili-
tary Gendarmerie
Military manpower: males 15-49, 241,000;
125,000 fit for military service; 7,000 reach
military age (20) annually
M ilitary budget: for fiscal year ending 31 -
December 1984, $73.4 million; 4.9% of cen- -
tral government budget ee
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
The Cainbis
75 km
North
Atlantic
Mansa Konka
Boundary representation is
not necessarily authoritative.
See regional! map VII
Land ;
11,295 km?; twice the size of Delaware; 55%
upland cultivable, built on, and other; 25%
uncultivated savanna; 16% swamp; 4% for-
est park
Land boundaries: 740 km
Water
Limits of territorial waters (claimed): 200
nm
Coastline: 80 km
Railroads: none
Highways: 3, 083 km total; 431 km paved,
501 km gravel/laterite, an 2,151 km unim-
proved earth ae
Inland waterways: 400 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent- surface ;
runways 2,440-3,659 m _ .
‘
Telecommunications: adequate network of
radio relay and wire; 3,500 telephones (0.5 ..
per 100 popl.); 2 FM, 3 AM, no TV stations;
1 Atlantic Ocean satellite station ,
Defense Forces
Branches: Army, paramilitary Gendarmerie
M ilitary manpower: males 15-49, 172,000;
88,000 fit for military service
Military budget: for fiscal year ending 30 - °
June 1981, $2.4 million; 6.2% of central gov-
ernment budget; includes fire and police
expenditures
German Democratic
Republic
‘Baltic Sea
Sch ;
The final borders of
Germany have not
beeh established.
100 km
SeeregionaimapV
Land - ;
108,178 km?, the size of Virginia; 43% ara-
ble, 27% forest, 15% meadow and pasture,
15% other
Land boundaries: 2;309 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm fishing zone)
Coastline: 901 km (including islands)
Railroads: 14,226 km total (1984); 18, 938 km
1.435-meter standard gatige (1984), 293 km: °
1.000-meter or other narrow gauge, 3,830
(est.) km 1.435-meter double track standard
gauge; 2,321 km overhead electrified (1984)
Highways: 120,433 km total; 47,380 km con-
crete, asphalt, stone block, of which 1,887 ©
km are autobahn and limited access roads;
over 73,000 km asphalt treated, gravel,
crushed stone, and earth (1983)
Inland waterways: 2,319 km (1984)
Freight carried: rail—338 million metric
tons, 56.654 billion metric ton/km (1984);
highway—560.7 million metric tons, 14.491
billion metric ton/km (1984); waterway—
18.7 million metric tons, 2.642 billion metric
ton/km (excluding international transit
traffic) (1984)
Pipelines: oil, 1,301 km; refined products,
500 kim; natural gas 1,700 km | =
Ports: 4 major (Rostock, Wismar, Stralsund, -
Sassnitz), 13 minor; principal inland: water-
way ports are E. Berlin, Riesa, Magdeburg,.
and Eisenhttenstadt ,
Telecommunications: 3.527 million tele-
phones in use ( 1984)
90
Defense Forces _
Branches: National People’s Army, Border
Troops, Ministry of State Security Guard -
Regiment, Air and Air Defense Command,
People’s Navy ''
M ey naupoue males 15-49, 4,299,000;
3,447,000 fit for military service; 121,000
reach military age (18) annually ; -
Military budget: aineuneed for fiscal year
ending 31 December 1986, 14. 05 billion
marks; 5.79% of total budget.
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Germany, Federal
Republic of
—200km_ ‘ § KielBay —
North Sea
been established.
See regional map V -
Land
248,577 km? (including West Berlin); the
size of Wyoming; 33% cultivated, 29% for-
est, 23% meadow and pasture, 13% waste or
urban, 2% inland water
Land boundaries: 4,232 km
Water
Limits of territorial waters (claimed): 3
nm—the FRG territorial sea extends at one
point to 16 nautical miles in the Helgolander
Bucht; (fishing to median lines)
Coastline: 1,488 km (approx.)
Railroads: 32,555 km total; 28,533 km 1.435-
meter government owned, standard gauge,
12,491 km double track; 11,272 km electri-
fied; 4,022 km nongovernment owned; 3,598
km 1.435-meter standard gauge; 214 km
electrified, 424 km 1.000-meter gauge; 186
km electrified
Highways: 466,305 km total; 169,568 km
classified, includes 6,485 km autobahn,
32,460 km national highways (Bundesstras-
sen), 65,425 km state highways (Landesstras-
sen), 65,248 km county roads (Kreisstrassen);
296,737 km of unclassified communal roads.
(Gemeindestrassen)
Inland waterways: 5,222 km, of which al-
most 70% usable by craft of 990-metric-ton
capacity or larger
Pipelines: crude oil, 2,348 km; refined prod-
ucts, 3,389 km; natural gas, 95,414 km
Ports: 10 major, 11 minor
Civil air: 194 major transport aircraft
Airfields: 477 total, 440 usable; 232 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 33 with runways 2,440-
8,659 m, 42 with runways 1,220-2,439 m
Telecommunications: highly developed,
modern telecommunication service to all
parts of the country; fully adequate in all
respects; 35.1 million telephones (57.1 per
100 popl.); 96 AM, 482 FM, and 5,995 TV
stations; 6 submarine coaxial cables; 2 satel-
lite stations with total of 8 antennas
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
16,488,000; 13,769,000 fit for military ser-
vice; 522,000 reach military age (18) annu-
ally
Military budget: for fiscal year ending 31
_ December 1984, $21.2 billion; 22.4% of the
proposed central government budget
92
200 km
CONAKRY*
North
Atlantic
Ocean
See regional map VII
Land
245, 957 ‘km; slightly smaller than Oren: ‘
10% forest, 15% under cultivation; 60-70%
unused _
Land.boundaries: 3,476 km
Water
Limits of territorial waters Weaied 12.
nm (200 nm exclusive economic zone)
Coastline: 346 km
Railroads: 1,045 km; 806 km 1.000-meter
gauge, 239 km 1.435-meter standard gauge
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Guinea (continued)
Highways: 30,000 km total; 1,087 km paved,
13,013 km gravel or laterite, 16,000 km un-
improved earth
Inland waterways: 1,295 km navigable by
shallow-draft native craft
Ports: 1 major (Conakry), 2 minor
Civil air: 7 major transport aircraft
Airfields: 17 total, 17 usable; 5 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 9 with runways
1,220-2,439 m
Defense Forces
Branches: Army (ground forces), Navy (acts
primarily as a coast guard), Air Force, para-
military National Gendaramerie
Military manpower: males 15-49, 1,282, 000,
645,000 fit for military service ° .
Guinea-Bissau .
(formerly Portuguese Guinea)
100 km
oO
Pe cat +
dos Bijagds
North Atlantic Ocean
See regional map VE
Land
36,260 km? (includes Bijagos archipelago);
about the size of New Hampshire and Con-
necticut combined
Land boundaries: 740 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 274 km
Railroads: none |
Highways: approx. 3,218 km (418 km bitu-
minous, remainder earth)
Inland waterways: scattered stretchés are: .
important to coastal commerce
Ports: 1 major (Bissau)
Civil air: 2 major transport aircraft
Airfields: 54 total, 46 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 6 with ruriways _
1,220-2,439 m
. Telecommunications: limited system of
open-wire lines, radio-relay links, and
radiocommunication stations; 3,000 tele-
phones (0.5 per 100 popl.); 1 AM station, 1
FM station, no TV stations —
Defense Forces
Branches: People’s Revolutionary Armed
Force (FARP); Ariny, Navy, and Air Force
are eeparate components
Military manpower: saiales 15-49, 201,000;
117,000 fit for military service
105.
Neves, sAo TOME
Ilha de
Sao Tomé
Santa Cruz
See regional map VII
Land
963 km? (Sdo Tomé, 855 km? and Principe,
109 km?; including small islets of Pedras
Tinhosas); slightly larger than New York
City
Water :
Limits of territorial waters: 12 nm (200 nm
exclusive economic zone); maritime limits
measured from claimed “‘archipelagic
baselines,” which generally connect the out-
ermost points of outer islands or drying reefs
Coastline: estimated 209 km
Railroads: none
Highways: 300 km, of which two-thirds is
paved; roads on Principe are mostly
unpaved and in need of repair
Ports: 1 major (Sio'' Tomé), 1 minor
Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 2 with
permanent-surface pinviays 1,220-2,489 m
Telecommunications: minimal system;
2,200 telephones (1.7 per 100 popl. );1 AM, 2
FM, no TV stations; 1 Atlantic Ocean satel-
lite ground station
Defense Forces
Branches: Army, Navy
215','1a2257451b109b3d2cf9405f6829ca8d507a31154692abbd82177b09c0c6d3b8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36120fcda15bf1dd9679a17c336939aa6c0b5f3e6cc2e2a3d1597a64c71d3fec',1986,'CK','Cook Islands','communications',123,'Rakahanga , Penrhyn
unepuke. “Manihiki
"Nassau
“ fsland *.
Suwarrow
South Pacitic Ocean
Palmerston,
Aitutaki, Manuae
. .Mitiaro
Takutea .
Mauke
400 km ++—*AVARUA
. Rarotonga
See regional map X Mangaia
Land
About 240 km?
Water
Limits of territorial waters: 12 nm (200 nm
exclusive economic zone)
Coastline: about 120 km
Railroads: none
Highways: 187 km total (1980); 35 km
paved, 35 km gravel, 84 km improved. earth, :
33 km unimproved earth
Inland ealetnuye none
Ports: 2 minor
Civil air: no major transport nigeratt
Airfields: 7 total, 6 usable; 1 with
permanent-surface runways; 2 with run-:
ways 1,220-2,439 m
Telecommunications: 6 AM, no FM, no TV .
stations; 7,000 radio receivers; 1,186 tele-
phones (1.8 per 100 popl.)','99b4a86a386a317348497e0ad947a40773dc8c7da7ff122b4fb2283d5d6c374c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a827f66ea61d754cfb44d125b281d0a200e08163388b788ea332c4b8b3d1cf4',1986,'CR','Costa Rica','communications',127,': + 1100 km.
Cabo Gracias,
Sea
- North Pacific. Ocean
_ See regional map III
7
Land. or
50,700 kini?, alia than V West oe
60% forest; 30% agricultural. (22% meadow.
and pasture, 8% cultivated); 10% waste, ur-: :
ban, and other
Land boundaries: 670 km os
Water.
Limits of territorial waters (claimed): 12 . ..
nm (200 nm exclusive economic zone),
Coastline: 1,290 km ><','e5ef9a8fc5c177d9aec89c79407fb39721294f049a26884d3a3bd19e111fc01c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('330c7a520381749aa2458017aada2888ccbbf48e38e22273efa72d447dc041ec',1986,'CU','Cuba','communications',134,'Railroads: 14,925 km total; Cuban National -
Railways operates 5,295 km of 1.435-meter .
gauge track; 199 km electrified; 9,630 km of ''
sugar plantation lines of 0.914-1.435-meter
gauge ;
Highways: approximately 21,000 km total;
9,000 km paved, 12,000 km gravel and earth
surfaced
Inland waterways: 240 km
Ports: 7 major (including US Naval Base at
Guantanamo), 40 minor
Civil air: 47 major transport aircraft
Airfields: 208 total, 191 usable; 65 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 11 with runways’
2,440-3,659 m, 19 with runways 1,220-2,489
Defense Forces
Branches: Revolutionary Armed Forces,
Ground Forces, Revolutionary Navy, Air
and Air Defense Force, Ministry of Interior
Special Troops, Border Guard Troops, Terri-
torial Militia Troops, Youth Labor Army
Military- manpower: eligible 15-49,
5,519,000; of the 2,896,000 males 15-49,
1,818,000 are fit for military service; of the
2,823,000 females:15-49, 1,772,000 are fit
for military service; 117,000 males and
115,000 females réach military age (17) an-
nually
|
Cyprus + | | : te
Czechoslovakia
|
Denmark |
Djibouti | a
Dominica { = si
a
she','a7a3a21cdf4ea51f740a5d15332e3f86b0ce506c1703b43cc8e8850910857175','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('145d0c94c8a502fc06552650e589ebc18ba559b6abd27cb1c35ef13c0c060e08',1986,'CY','Cyprus','communications',135,'50 km
Mediterranean Sea
Rizokarpaso
United Nation:
Buffer Zone
Famagusta
Vasilikos
Mediterranean Sea
See regional map VI
Land |
9,251 km?; smaller than Connecticut; 60% -
arable (including permanent crop); 25%
waste, urban areas, and other; 15% forest
Water | : ;
Limits of territorial waters (claimed): 12
nm
Coastline: approximately 648 km
Railroads: none
Highways: 10,778 km total; 5,169 km bitu-
minous surface treated; 5,609 km gravel,
crushed stone, and earth :
Ports: 3 major (Famagusta, Larnaca, Limas-
sol), 2 secondary (Vasilikos, Kyrenia) under
development, 6 minor; Famagusta and
Kyrenia under Turkish Cypriot control
Civil air: 8 major transport aircraft
Airfields: 14 total, 13 usable; 11 with
permanent-surface runways; 6 with run-
ways 2,440-3,659 m; 2 with runways
1,220-2,489 m 7...
Telecomniunitations: moderately good
telecommunication system in both Greek
and Turkish sectors; 164,000 telephones (25
per 100 popl.); 10 AM, 6 FM, and 29 TV sta-
tions; tropospheric scatter circuits to Greece
and Turkey; 3 submarine coaxial cables; 1
Atlantic Ocean satellite antenna and 1 In-
dian Ocean antenna
Defense Forces
Branches: Cyprus National Guard; Turkish
sector—Turkish Cypriot Security Force
Military manpower: males 15-49, 182,000,
127,000 fit for military service; about 5,000
reach military age oe annually
Military budget: for se year ending 31
December 1984, $60 million; 11.6% of cen-
tral government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Czechoslovakia
See regional map V
Land ss
127,870 km?; the size of New York; 53% .
agricultural, 36% forest, 11% other
Land boundaries: 3,540 km
Railroads: 13,141 km total; 12,883 km 1.435-
meter standard gauge, 102 km 1.524-meter
broad gauge, 156 km 0.750- and 0.760-
meter narrow gauge; 2,866 km double track;
3,221 km electrified; government owned
(1983)
Highways: 74,064 km total; 60,765 km on
crete, asphalt, stone block; 13,299 km gravel,
crushed stone (1983)
Inland waterways: 475 km (1983)
Pipelines: crude oil, 1,448 km; refined prod-
ucts, 1,500 km; natural gas, 7,500 km
Freight carried: rail—298.8 million metric
tons (1984); highway 1,376 million metric
tons, 20.3 billion metric ton/km (1983); ‘
waterway 11.40 million metric tons (1984),
3.9 billion metric ton/km (excluding inter-
national transit traffic) (1983)
Ports: no maritime ports; outlets are Gdynia,
Gdansk, and Szczecin in Poland; Rijeka and
Koper in Yugoslavia; Hamburg, FRG; Ros-
tock, GDR; principal river ports are Prague,
Détin, Komarno, Bratislava (1979)
Defense Forces
Branches: Czechoslovak People’s Army,
Frontier Guard, Air and Air Defense Forces
Military manpower: males 15-49, 3,798,000;
2,924,000 fit for military service; 110,000
reach military age (18) annually
Military budget: announced for fiscal year
ending 31 December 1985, 25.7 billion
koronas, 7.5% of total budget','f6c22fea0762a0e453e3125c76421f724693f92f85e7c84303b20110883f3176','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbdea9530ed02609f130e963b78c315f2e5b3874cc45d33e002e56a8c1889225',1986,'DK','Denmark','communications',138,'Skagerrak Pa, Oe 100 km
5 . Kattegat
COPENHAGEN
Bornholm &
Baltic
Sea
See regional map V
Land
43,076 km? (exclusive of Greenland and
Faroe Islands); the size of Massachusetts and
New Hampshire combined; 64% arable,
11% forest, 8% meadow and pasture, 17%
other
Land boundaries: 68 km
Water
Limits of territorial waters (claimed): 3 nm
(200 nm fishing zone or to median line)
Coastline: 3,379 km
Railroads: 2,770 km 1.435-meter standard .
gauge; Danish State Railways (DSB) operate
2,120 km (1,999 km rail line and 121 km rail
ferry services); 97 km electrified, 730 km
double tracked; 650 km of standard-gauge
lines are privately owned and operated
Highways: approximately 66,482 km total;
64,551 km concrete, bitumen, or stone -
block; 1,931 km gravel; crushed stone, im-
proved earth
Inland waterways: 417 km
Pipelines: crude oil, 110 km; refined prod-
ucts, 418 km; natural gas, 549 km
Ports: 10 major, 50 minor
Civil air: 58 major transport aircraft
Airfields: 131 total, 116 usable; 25 with
permanent-surface runways; 9 with run-
ways 2,440-3,659 m, 7 with runways
1,220-2,439 m
Telecommunications: excellent telephone,
telegraph, and broadcast services; 3.67 mil-
lion telephones (71.8 per 100 popl.); 2 AM,
46 FM, 34 TV stations; 13 submarine coaxial
cables; 7 satellite earth stations for domestic
service
Defense Forces ;
Branches: Royal Danish Army, Royal Dan-
ish Navy, Royal Danish Air Force
Military manpower: males 15-49, 1,312,000;
1,105,000 fit for military service; 41 000
reach military age (20) annually
Military budget: for fiscal year ending 31
December 1985, $1.4 billion; 6.7% of central
government budget 00; 1,105,000 fit for mil-
itary service; 41,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1985, $1.4 billion; 6.7% of central
government budget 00; 1,105,000 fit for mil-
itary service; 41,000 reach eniliteny, age (20)
annually
Military budget: for fiscal year ending 31
December 1985, $1.4 billion; 6.7% of central
government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','6cd43f270655e67da9620d55a5f6f8992d6fcbe58bfaf081453a7bf33dfb0ac7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('932193ad533bf50c6540e68b54629cfa28271ff353e3f417b937fde7d233170a',1986,'DJ','Djibouti','communications',140,'50 km
4
Golfe de Tadjoura
* See regional map VII
Land. ;
22,000 km?; : about the size of N New Hamp-
shire; 89% desat waste, 10% permanent
pasture, less than 1%. cultivated
Land boundaries:517 km ~
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 314 km (includes offshore islands)
Railroads: the Ethiopian- Djibouti railroad
extends for 97 km through Djibouti
Highways: 2,800 km total; 279 km bitumi-
nous surface, 229 km improved earth, 2,292
km unimproved earth
Ports: 1 major (Djibouti)
Civil air: 1 major transport aircraft
Airfields: 12 total, 10 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,489 m | ~
Telecommunications: fair system of urban
facilities in Djibouti and radio-relay stations
at outlying places; 7,200 telephones (2.0 per
100 popl.); 2 AM stations, 1 FM station, 2 TV
stations; 1 Indian Ocean satellite ground
station, 1 Arab satellite station, 1 submarine
cable to Saudi Arabia under construction
Defense Forces
Branches: Army, Navy, Air Force; paramili-
tary National Security Force
Military manpower: males 15-49, about
66,000; about 39,000 fit for military service
Military budget: for fiscal year ending 31 .
December 1984, $27.8 million; about 22% of
central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','9ada375f69d400d7402d6d78f026a9e9202eca18a28d006a568270ba7603e1d0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec20542aefb54bae3c73f50c07bd637529c2192cbf674910aa3f60482b71000b',1986,'DM','Dominica','communications',145,'10km
Caribbean
Caribbean
Sea.
ea
See regional map ITI
Land
752.7 km?; ABs one-fourth the size of
Rhode Island; 67% forest; 7a arable; 2% -
pasture; 7% other .
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 148 km
Railroads: none
Highways: 750 km total;:370 km paved, 380
km gravel and earth
Ports: 1 major (Roseau), 1 minor
(Portsmouth): - *%
Civil air: unknown number of major trans- _
port aircraft
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Dominica (continued)
Airfields: 2 total, 2 usable; 2 with
permanent-surface runways; 1 with run-
ways 1,220-2,439.m
Telecommunications: 4,600 telephones in
fully automatic network (5.6 per 100 popl.):
VHF and UHF link to St. Lucia; new SHF
links to Martinique and Guadeloupe; 3 AM
stations, 1 FM station, 1 cable TV station
- Defense Forces ~
Branches: Commonwealth of Dominica Po-
lice Force
Military budget: proposed for fiscal year
1986, $2.9 million; 4.6% of the central gov-
ernment budget','d145df38d9e6a554a8e404d8e1f3a3e7d881c814784f1beb7c3772e4db4c426b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d94fe8252490050f7a41505d94afc37cc446075c61754f77905391f0a2ac5bc',1986,'DO','Dominican Republic','communications',149,'/
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 :
q
|
a 100. km
North Atlantic Ocean
Puerto Plata
Z
Samana
San Pedro®
de Macoris
Barahon
Caribbean Sea
See regional map HI
Land
48,734 km?; the size of New Hampshire and
Vermont combined; 45% forest, 20% built
on or waste, 17% meadow and pasture, 14%
cultivated, 4% fallow: Detect.
Land boundaries: 361 kin
Water ;
Limits of territorial waters (elalmed): 6nm
(200 nm exclusive economic zone)
Coastline: 1,288 km
Railroads: 375 km total of 1.485-meter
gauge, privately owned
Highways: 12,000 km total; 5,800 km paved,
5,600 km gravel and improved earth, 600
km unimproved
Pipelines: crude.oil, 96 km; refined prod-
ucts, 8 km
Ports: 4 major (Santo Domingo, Haina, San
Pedro de Macoris, Puerto Plata), 17 minor
Civil air: 14 major transport aircraft
Airfields: 47 total, 34 usable; 14 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 9 with runways
1,220-2,439 m
Telecommunications: relatively efficient
domestic system based on islandwide radio-
relay network; 190,000 telephones (3 per 100
popl.); 126 AM, 18 TV stations; 1 coaxial
submarine cable; 1 Atlantic Ocean satellite
station
Defense Forces
Branches: Army, Naw; Air Force
Military manpower: males 15-49, 1,686,000;
1,112,000 fit for military service; 84,000
reach military age(18) annually
69
=
Ecuador ~y +
Egypt | se
E]! Salvador _]','c674966bd0ed71614e731a9dedc512df7bb1e8e96542790642824159691c5f86','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cfe818163222f2ac0b0691facb843fd1f254a103ca2ab3ca10eab05cb80a742',1986,'EC','Ecuador','communications',153,'Boundary representation is
nol necessarily authontative
Pacific
Ocean
Golfo : islands not shown in true
de geographical position.
Guayaquil ;
Galapagos Islands
See regional map1V
Land
283,561 km? (including Galapagos Islands),
the size of Colorado; 55% forest; 11% culti-
vated; 8% meadow and pasture; 26% waste,
urban, or other (excludes the Oriente and
the Galapagos Islands, for which informa-
tion is not available)
Land boundaries: 1,931 km
Water
Limits of territorial waters (claimed): 200
nm
Coastline: 2,237 km (includes Galapagos
Islands)
Railroads: 965 km total; all 1.067-meter
gauge single track
Highways: 28,000 km total; 3,600 km paved,
17,400 km gravel and improved earth, 7,000
km unimproved earth
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Inland waterways: 1 500 km —
Pipelines: ida oil 800 kan; refined prod-
ucts, 1,358 km
Ports: 4 major (Cuayaauill, Manta, Puerto 4s
Bolivar, Esmeraldas), 6 minor
Civil air: 44 major transport aircraft
Airfields: 177 total, 174 usable; 29 with
permanent-surface runways; 1 withrun-.
ways over 3,659 m, 6 with runways 2,440-
3,659 m, 21 with runways 1,220-2,439 m_
Telecommunications: domestic facilities
generally adequate; 1 Atlantié Ocean satel-
lite station; 318,000 telephones (3.9 per 100
popl.); 285 AM, 24 TV. stations _
Defense Forces
Branches: Ecuadorean Army, Ecuadorean
Air Force, Ecuadorean Navy |
Military manpower: tales 15-49, 2,203, 000;
1,497,000 fit for military service; 101, 000 |
reach military age (20); annually
Military budget: estimated’ for the fiscal,
year ending 31 December 1986, $345 mil-
lion; about 10.9% of the central government
budget |','9fa340860485f9da27d4e7fd9f4559af9f7b8fd982bdf38c73e8e8f3401b2896','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2783e85e89b4b6980ccc822498d3288e13e0d8ede19f97ff0f8c36ff5cc8ab1d',1986,'EG','Egypt','communications',157,'MediterraneanSea 200 km
Boundary representation is*
not necessarity ‘authoritative
See regional map VI: and VU :
Land.
1,001,449 km2; the size of Texas‘and Oregon
combined; 96.5% desert, waste, or urban;
2.8% cultivated (of which about 70% is mul-.
tiple crop); 0. 7% inland: water
Land boundaries: npprollinaiely 9,580 km °
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone) -
Coastline: 2,450 km (1967)
Railroads: 4,857 km total; 951 km double —
track; 25 km electrified; 4,510 km 1,435-
meter standard gauge, 347 km 0.750-meter
gauge :
Highways: 28,500 km total; 15,000 km sur-
faced, 13,500 km unsurfaced
Inland waterways: 3,360 km (including the
Nile River, Lake Nasser, Alexandria-Cairo
Waterway, the Ismailia Canal, and numer-
ous smaller canals in the Delta); Suez Canal,
195 km long, used by.oceangoing vessels
drawing up to 16.1 meters of water
Freight carried: Suez Canal (1984) 260 mil-
lion metric tons, of which 98 million metric
tons were petroleums, oils, and lubricants
Pipelines: crude oil, 930 km; refined prod-
ucts, 596 km; natural gas, 460 km
Ports: 4 major (Alexandria, Port Said, Suez,
Bar Safajah); 15 minor; 8 petroleum, oil, and
lubricant terminals
Civil air: 43 maior transport aircraft
Airfields: 97 total, 80 usable; 64 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 44 with runways
2,440-3,659 m, 22. with runways 1,220-
2,439 m ‘
72
Telecommunications: system is large but ~
still inadequate for needs; principal centers
are Alexandria, Cairo, Al Mansarah,
Ismailia, and Tanta; intercity connections by
coaxial cable and microwave; extensive up-
grading in progress; est. 600,000 telephones
(1.3 per 100 popl.); 25 AM, 5 FM, 47 TV sta-
tions; 1 Atlantic Ocean and 1 Indian Oceari
satellite station; 3 submarine coaxial cables,
tropospheric scatter to Sudan; radio-relay to','48fd66e6eae6703814c00672497382204b6285465cc1c215789a9eda03084e47','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0444c197c918b10941a5411ce6c7a39e12e7a70a90c0a821f05d8a82708a491',1986,'LY','Libya','communications',161,'Defense Forces
Branches: Army, Navy, Air Force, Air De-
fense Command
Military manpower: males 15-49,
12,588,000; 8,209,000 fit for military service;
about 518,000 reach military age (20) annu-
ally ,
Military budget: operating expenditures for
fiscal year ending 30 June 1985, $3.4 billion;:
13% of central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
EI Salvador
Boundary representation is
not necessarily authoritative.
North Pacific Ocean
See regional map IIT
Land
21,041 km?; the size of Massachusetts; 32%
crop (9% corn, 7% coffee, 5% cotton, 11%
other), 31% nonagricultural, 26% meadow
and pasture, 11% forest
Land boundaries: 515 km
Water
Limits of territorial waters (claimed): 200
nm (overflight and navigation permitted
beyond 12 nautical miles)
Coastline: 307 km
Railroads: 602 km 0. 91441 meter gauge, single
track
Highways: 10,000 km total; 1,500 km paved,
4,100 km gravel, 4,400 km improved and
unimproved earth
Inland waterways: Lempa River partially _
navigable :
Ports: 2 major (Acajutla, La Unién), | minor
Civil air: 7 major transport aircraft
Airfields: 166 total, 188 usable; 6 with
permanent-surface runways; ] with run-
ways 2,440-3,659 m; 6 with runways
1,220-2,439 m
Telecommunications: nationwide trunk
radio-relay system; connection into Central
American microwave net; 116,000
telephones (2.3 per 100 popl.); 75 AM, 5 TV
stations; 1 Ailaniie Ocean satellite station
Defense Forces :
Branches: Army, Navy, Air Force, National
Guard; National Police, Treasury Police .
Military manpower: males 15-49, 1,162,000;
738,000 fit for military service; 60,000 reach
military age (18) annually
Military budget: estimated for fiscal year
ending 31 December 1986, $153.6 million;
about 28.3% of the central government bud-
get
74
Mediterranean Sea
POLI
400 km
See regional map VII
Land : .
1,759,540 km?; larger than Alaska; 93%
desert, waste, or urban; 6% agricultural; 1%
forest
Land boundaries: 4,345 km
Water :
Limits of territorial waters (claimed): 12
nm (except for Gulf of Sidra where sover-
eignty is claimed and northern limit of juris-
diction fixed at 32°30°N)
Coastline: 1,770 km
Railroads: none
145
Highways: 19,300 km total; 10,800 km bitu-
minous and bituminous treated, 8,500 km
gravel, crushed stone and earth
Pipelines: crude oil 3,893 km; natural gas
938 km; refined products 443 km {includes
217 km liquid petroleurn gas)
Ports: 4 major (Tobruk, Tripoli, Banghazi,
Misratah), 2 secondary, 15 minor, and 6 pe-
troleum terminals
Civil air: 76 major transport aircraft
Airfields: 118 total, 107 usable; 37 with
permanent-surface runways, 8 with run-
ways over 3,659 m, 24 with runways -
2,440-3,659 m, 3p with runways 1 ou
2,489 m
Defense Forces
Branches: Armed Forces of the Libyan Arab
Jamahariya (including Army, Arab Air
Force, Air Defense Command, Arab Navy): °
Military manpower: males 15-49, 936,000;
551,000 fit for military service; about 39,000
reach military age (17) annually; conscrip-
tion now being implemented ©
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','8e41ec24857c49f36ad2a4b7aaae62675a518755ada9396d42b5d391c977b6f3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d5dac2b4f348b4abde63b88800476dc4fc364eaf644206306e0b0ca2d44c225',1986,'GQ','Equatorial Guinea','communications',165,', “Bioko
Gulf of Guinea
‘sland not
shown in true
geographical
position.
Annobén
° Acal
See regional map VII
Land .
28,051 km?; the size of cee Rio Mani
about 25,900 km?, largely forest; Bioko (for-
merly known as Fernando Po), about 2,072.
km
Land boundaries: 539 kin
Water
Limits of seetonal waters fa(elaimed ): 12
nm a
Coastline: 296 km
Ethiopia es OE) ee oe
a Inter-American Development Bank : » Islamic Development Bank: ¢ Not a member of UN
284
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
United Nations Organizations
OAU OECD OIC OPEC SELA WFTU FAO GATT IAEA IBRD ICAO IC] IDA IFAD IFC ILO IMF IMO ITU UNESCO -UPU WHO WMO
: Soe es eg es oe ae * eee
| Se (Ce co ee OCP el el ( aE
ed pele eed el oe cn ee Pea
e ° e ca . = . i e [- J+ [Je]
4 Ceased to participate in 1961 ¢ Suspended _ T Excluded sirice 1962
285
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Country |','9f00534ce2e885f62990ce6727411aa4a7c43f2165a6a474e488ab554d71a0cb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b331016cdf7f567d9e6ddc774da96f2ac5351641bfa979fc41392dce51e5b5b0',1986,'ET','Ethiopia','communications',167,'409 km
"Red Sea
Boundary representation 1s
not necessarily authoritative.
See regional map Vil
Land
1,221,900 km?; four-fifths the size of Alaska;
55% meadow and natural pasture; 10% crop
and orchard; 6% forest and wood; 29%
wasteland, urban, or other
Land boundaries: 5,198 km
Water
Limits of territorial waters (claimed): 12
nm
Coastline: 1,094 km (includes offshore is-
lands)
Railroads: 1,089 km total; 782 km 1.000-
meter gauge, of which 97 km are in Djibouti;
307 km.0.950-meter gauge
Highways: 44,300 km total; 3,888 km bitu-
minous, 8,344 km gravel, 2,456 km
improved earth, 29,612 km unimproved
earth
Ports: 2 major (Aseb, Mits’iwa)
Civil air: 22 major transport aircraft
Airfields: 167 total, 132 usable; 7 with
permanent-surface runways; | with run-
ways over 3,659 m, 9 with runways 2,440-
3,659 m, 49 with runways 1,220-2,439 m
Defense Forces
Branches: Army, Navy, Air Force, Air De-
fense; paramilitary Emergency Strike Force
Police
Military manpower: males 15-49, 9,941,000;
5,340,000 fit for military service; 507,000
reach military age (18) annually
Military budget: for fiscal year ending 7 July
1984, $420.1 million; 25.1% of central gov-
ernment budget
Falkland Islands
(Islas Malvinas)
South Sandwich Islands.
South Georgia. Shag, and —0km
Clerke Rocks are not shown
wy South Atlantic Ocean
eae
West 4
Falkland 4)
Administered by U.K.,
claimed by Argentina.
East Falkland —
a
. Scotia Sea
See regional map IV .
NOTE: The possession of the Falkland Is-
lands has been disputed by the UK and
Argentina (which refers to them as the Islas
Malvinas) since 1833.
Land
Colony—16,654 km?; about the size of Con-
necticut; area consists of some 200 small is-
lands and two principal islands, East
Falkland (6,680 km?) and West Falkland
(5,276 km?); dependencies—South Sandwich
Islands, South Georgia, and the Shag and
Clerke Rocks
Water
Limits of territorial waters (claimed): 3 nm
Coastline: 1,288 km
Railroads: none
Highways: 510 km total; 30 km paved, 80.
km gravel, and 400 km unimproved earth —
Ports: 1 major (Port Stanley), 4minor..
Civil air: no major transport aireratt
Airfields: 5 total, 5 usable, 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m; 1 with runways
1,220-2,439
Telecommunications: government-
operated radiotelephone networks providing
effective service to almost all points on both...
islands; approximately 590.telephones (est. . -
24.2 per 100 popl.); 1 AM station, 1 FM sta-..
tion, 1 Atlantic satellite station
Defense Roices : ;
Defense is the responsibility of ihe United
Kingdom','12b7cf0fad8474b922b9e00c0307c85df411444d6edaeadc738015d8a61e408b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ceeee3e5e09062c567d1e41edecc7cacc69011c5263de0b24d60ca5690fb6b',1986,'FO','Faroe Islands','communications',171,'Mykines —
Sea
North
Atlantic i ry
Ocean
See regional map V
Land
1,340 km?; slightly larger than Rhode Island;
less than 5% arable, of which only a fraction
is cultivated; archipelago consisting of 18 .
inhabited islands and a few uninhabited .
islets
Water
Limits of territorial waters (claimed): 8 nm.
(200 nm fishing zone)
Coastline: 764 km
Railroads: none
Highways: 200 km
Ports: 2 major, 8 minot: - ;
Airfields: 1 ‘isibte with permanent- surface
runways 1 ;220-2,439 m °
Telecommunications: good international
communications; fair domestic facilities;
20,400 telephones (46.3 per 100 popl.); 1
AM, 3 FM stations; 3 coos! submarine
cables : :
Defense Forces ©
Defense is the responsibility of Denmark
Military. manpower: males 15-49:included
with Denmark :','2bb6ed1315031f213cc1d487eb5222ffd89152e0a48e783b98fc846b18695652','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c4af7e61bfd644036f54512bdba3c79f494500ec09615b648cf92429c4ec58c',1986,'FJ','Fiji','communications',174,'™* Rotuma
South Pacific Ocean
Vanua Levu
Viti Levu ~~
fe
Kandavu
Ceva-i-Ra
See regional map X
Land
18,376 km?; the size of Massachusetts; con-
sists of more than 300 islands and many
more coral atolls and cays; the larger
islands—Vanua Levu, Viti Levu, ‘Taveuni,
and Kandavu—are mountainous and volca-
nic in origin, with peaks rising over 1,210
meters; land ownership—83.6% Fijians,
7.2% European, 6.4% government, 1.7%
Indians, 1.1% other; about 30% of land‘area: -
is suitable for farming
Water
Limits of territorial waters (claimed): 12
nm (200''nm exclusive economic zone); mari-
time limits measured from claimed “‘archi-
pelagic baselines,” which generally connect
the outermost points of outer islands or dry-
ing reefs
Coastline: 1,129 km
Railroads: 644 km 0.610-meter narrow
gauge; owned by Fiji Sugar Corp., Ltd.
Highways: 2,960 km total (1981); 390 km -
paved, 2,150 km gravel, crushed stone, or
stabilized soil surface; 420 unimproved
earth
Inland waterways: 203 km; 122 km naviga-
ble by motorized craft and 200-metric-ton —
barges
Ports: 1 major, 6 minor
Civil air: 1 DC-3 and 1 light aircraft
Airfields: 27 total, 26 usable; 2 with
permanent-surface runways, 1 with run-
ways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: modern local, inter-
island, and international (wire/radio inte-
grated) public and special-purpose
telephone, telegraph, and teleprinter facili-
ties; regional radio center; importarit COM- —
PAC cable link between US/Canada and ©
New Zealand/ Australia; 37,515 telephones
(6.0 per 100 popl.); 7 AM, 2 FM, no TV sta-
tions; 1 ground satellite station
Defense Forces
Branches: integrated ground and naval
forces
Military manpower: males 15-49, 187,000,
103,000 fit for military service; 7,000 reach
military age (18) annually
80
International Organizations ; 7 : .
ADB ARAB ASEAN CACM CARICOM CEMA: EC: G-77 GCC IDB’ IDB® -INTELSAT LAIA NAM NATO OAPEC OAS
eel','2dfeeb0cd41c724e94a834f1efaad982c83724c3385663d053f075b48caf03e2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f21605090a37cd38f9f305f36fc6f4f34116ee259f20830da89a50b2262324d',1986,'FI','Finland','communications',178,'Gulf of
Bothnia
Vaasa
Aland
islands
ey
See regional map V HELSINSKI
Land
337,113 km?; slightly smaller than Montana;
58% forest, 34% other, 8% parable :
Land boundaries: 9,584 ken ae
Water
Limits of territorial waters (claimed): 4nm;
fishing 12 nm; Aland Islands, 3 nm
Coastline: 1,126 km (approx.) excludes is-
lands and coastal indentations
Railroads: 6,071 km total; Finnish State
Railways (VR) operate a total of 6,010 km
1.524-meter gauge, of which 480 km are
multiple track and 1,257 km are electrified
Highways: about 103,000 km total, includ-
ing 35,000 km paved (bituminous, concrete,
bitumirious-treated surface) and 38,000 km
unpaved (stabilized gravel , gravel, earth); —
additional 30,000 km of private (state subsi-
dized) roads
Inland waterways: 6,675 km total (including
Saimaa Canal); 3,700 km suitable fos
steamers
Pipelines: natural gas, 161 km
Ports: 11 major, 34 minor
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Finland (continued)
Civil air: 89 major transport
Airfields: 168 total, 160 usable; 47 with
permanent-surface runways; 20 with run-_.
ways 2,440-3,659 m, 22 with runways
1,220-2,439 m :
Telecommunications: good telecom service
from cable and radio-relay network; 2.78
million telephones (57 per 100 popl.); 6 AM,
99 FM, 193 TV stations; 3 submarine cables -
Defense Forces :
Branches: Army, Navy, Air Fores
Military manpower: sales 15-49, 1,329,000; -
1,022,000 fit for military service; 35,000...
reach military age (17) annually
Military budget: fiscal year ending 31 De-
cember 1984, $785 million; 5.6% of central
government budget
France,
English Channel
Bay of
Biscay
Marseille
Corsic
ay ; f . Mediterranean
See regional map V ; Sea
Land
547,026 km?; four- fifths the size - Téxas; os
34% cultivated; 24% meadow and pasture; _
27% forest; 15% waste, urban, or other
Fund boundaries: 2,888 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 3,427. km (includes Corsica, 644
km) :
Railroads: Frerich National Railways
(SNCF) operates 34,678 km 1.435-meter
standard gauge; 11,219 km electrified,
15,132 km double or multiple track; 2,138
km of various gauges (1.000-meter to 1.440-
meter), privately owned and operated
Highways: 1,533,940 km total; 33,400 km
national highway; 347,000 kin departmental
highway; 421,000 km community roads;
750,000 km rural roads; 5,209 km of
controlled-access divided ‘“‘autoroutes”’; ap-
prox. 803,000 km paved
Inland waterways: 14,932 km; 6,969 km
heavily traveled
Pipelines: crude oil, 3,458 km; refined prod-
ucts, 4,344 km; natural gas, 24,746 km
Ports: 8 major, 16 secondary
Civil air: 355 major transport aircraft (1982)
Airfields: 468 total, 454 usable; 248 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 34 with runways
2,440-3,659 m, 130 with runways
1,220-2,439 m
Telecommunications: highly developed
system provides satisfactory telephone, tele-
graph, and radio and TV broadcast services;
33.0 million telephones (60 per 100 popl.); 38
AM, 591 FM, 9,300 TV stations; 23 subma-
rine coaxial cables; 2 communication satel-
lite ground stations with total of 9 antennas
Declassified and Approved For Release 201 2/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
France (continued)
Defense Forces
Branches: Army of the Ground, Navy, Army
of the Air, National Gendarmerie
Military manpower: males 15-49,
14,034,000; fit for military service
11,895,000; 431,000 reach military age (18)
annually
Military budget: proposed for fiscal year
ending 31 December 1984, $20 billion;
about 18.1% of proposed central govern-
ment budget','b5537957a7b6f9d7c76e3288e2114609dd8fa7a31c12707a1fb54adf34265574','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ba9abbb8fe1bae4532ddefd43fafb9d7896a39aaabfa0aa343c8839c2519d11',1986,'GF','French Guiana','communications',182,'Boundary representation is’
See regional map IV not necessarily authoritative
Land
90,909 km2; slightly smaller than Maine;
90% forest; 10% waste, built on, inland wa: |
ter, and other, of which 05% i is cultivated
and pasture
Land boundaries: 1,183 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone) |
Coastline: 378 km
Railroads: none
Highways: 680 km total; 510 km paved, 170
km improved and unimproved earth
Inland waterways: 460 km, navigable by
small oceangoing vessels and river and
coastal steamers; 3,300 km possibly naviga-
ble by native craft
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 11 total; 11 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: fair open-wire and
radio-relay system with about 18,100 tele-
phones (27.2 per 100 popl.); 3 AM; 6 FM, 9
TV stations; 1 Atlantic Ocean satellite sta-
tion
Defense Forces
Defense is the responsibility of France
Military manpower: males 15-49, 21,000::
15,000 fit for military.service
85','2033c8aa877ab645fe9539f1efff6fbf7c553ed90087b4bcd3ffc10fe4533010','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6765cca76c99b15eaf7ba7f7d3e1243ec108cea70969dc456d9bcc9c0e703121',1986,'PF','French Polynesia','communications',186,'.
‘e-
“#8.
~ ’
He Marquises
South Pacific Ocean
- Hes
ore ae Tuamotu
les de - *® “as zc
la Société
lles
Tubuai
500 km
See regional map X
_ Land
About 4,000 km?; larger than Rhode Island
Water |
Limits of territorial waters: 12.nm (200 nm
exclusive economic zone) ,
Coastline: about 2,525 km
Railroads: none _
Highways: 3,700 km
Inland waterways: none
Ports: | major (Papeete), 6 minor
Airfields: 41 total, 41 usable; 25 with
permanent-surface runways, 2 with run-
ways 2,440-3,659 m, 14 with runways.
1,220-2,439 m ?
Civil air: about 6 major transport aircraft —
Telecommunications: 17,302 telephones -
(12.9 per 100 popl.); 72,000 radio and 14,000
TV sets; 5 AM, 2 FM, 6 TV stations; 1
ground satellite station
Defense Forces
Defense is responsibility of France
86','9e22882a15c78228dc6f3573251e8157f4ff952c6ddc24d13dc3826fc030fe22','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ee614599359097d36b67fd520dc453b5fb65058c2b33f78bfbf2c9245de921a',1986,'GA','Gabon','communications',190,'“150 km
Guilt of
Gambia, The
German Democratic
+
Republic
Germany, Federal :
Republic o! ; |
Ghana as
Greece = aay
Grenada | oe]
Guadeloupes eee eee ore Beas ees ee
Guatemala zi i a eae Ee
Guinea he ea re
Guinea-Bissau | ae eae CS ees
Guyana tt} ff} 4
Haiti ae a a eae
Honduras }—} +f} =f}, + *
Hong Kongs Se a ee ae es Se ee
Hungary ca ee
Iceland De Se ee |
India . CS a a ae a ee (ee es ee a a ee ee
Indonesia - 7 |. | ae
— oe ee ee ee ee a
Iraq | |
Israel | | | (ee Es eet ee
italy ee Sel A see es eS ae el
Ivory Coast as ee a ae ee ee ee ee a a ee ee ee es ee
Jamaica | * | . ee eee
Japan ae | | fT]
Jordan | | ; a ae eee ee es ee a es
Kenya a ae Ee a a }—} +} +1
Kiribati Gee tear aoe 2 es (esas anal
Korea, Northe | a oneal odie +—_-—- | |
Korea, South he Le : 7 | Bal
Kuwait se eS oc
Lacs az ees ps le see
Lebanon ele es ee ae
Lesotho fad
vier (aes ee ees ee pe eee fae ees Gee
re os CE Cae ae SEE EN eres de pe ee
Liechtenstein ae ok ca (OR ry
Tinea al El MN a Mca a Deel aE ET
Madagascar seems ie Cg (ies ee Be ee
Malawi Sean Ge RT (el nae A OC (SG FC Gy a
Malaysia ic ca lad = iz ia eee
Maldives ~ secs ae
Mali : es eS eee a a [eps ee Eee ee ee
286
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
United Nations Organizations
QAU OECD OIC OPEC SELA WFIU FAO GATT IAEA IBRD ICAO IC] IDA IFAD IFC ILO IMF IMO. ITU UNESCO UPU WHO WMO
287
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Country','d5d166c6b2529248183c9577c43496221372d3f78f8bcf255e5d2f26f9d32fb5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03191d46f4072c169d1b2a254cd169efbe12d6727a062ca3967b110262053aff',1986,'GH','Ghana','communications',191,'150 km
See regional map VI
Land
238,538 km?; slightly smaller than Oregon;
60% forest and brush, 19% agricultural, 21%
other ;
Land boundaries: 2,285 km
Water
Coastline: 539 km
Limits of territorial waters (claimed): 200
nm
Railroads: 953 km, all 1.067-meter gauge; 32
km double track; diesel locomotives gradu-
ally replacing steam engines
93
Highways: 32,250 km total; 6,084 km con-
crete or bituminous surface, 26,166 km
gravel or laterite
Inland waterways: Volta, Ankobra, and
Tano rivers provide 168 km of perennial
’ navigation for launches and lighters; Lake
Volta reservoir provides 1,125 km of arterial
and feeder waterways ©
Pipelines: refined products, 3 km
Ports: 2 major (Tema, Takoradi)
Civil air: 7 major transport aircraft
Airfields: 10 total, 9 usable; 5 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 6’ with runways.
1,220-2,439 m
Telecommunications: fair system of open-
wire and cable, radio-relay links: 68,900
telephones (0.6 per 100 popl.); 6 AM, 9 TV
stations; 1 Atlantic Ocean satellite ground
station ,
Defense Forces
Branches: Army, Navy, Air Force, paramili-
tary Palace Guard, paramilitary People’s
Militia ; ws
Military manpower: males 15-49, 2,917,000,
1,624,000 fit for military service; 140,000
reach military age (18) annually
Military budget: for fiscal year ending 30
June 1984, $75.8 million; 5.5% of central
government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','30536c46991715ae642ab8e8e39088458feb44100fb0a366685b2d82c983bd4b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd58eb625a5b7b62b1129f7c96c4cdcdd1b61760f033e55a3cb864c82dd09152',1986,'GI','Gibraltar','communications',194,'_ Mediterranean -
Sea
Strait of Gibraltar. ea
See regional map V Lighthouse
re
Land
6.5 km?; smaller than Washington, D. C.
Land boundaries: 1.6 km
Water
Limits of territorial waters (claimed): 3 nm
Coastline: 12 km
Railroads: 1.000-meter gauge system in
dockyard area only
Highways: 50 km, mostly good bitumen and
concrete
Ports: 1 major (Gibraltar)
Civil air: 1 major transport aireraft
Airfields: 1 usable with permanent-surface
runways 1,220-2,439 m
Telecommunications: adequate interna-
tional radiocommunication facilities; auto-
matic telephone system serving 9,400 tele-
phones (31.5 per 100.popl.); 1 AM, 6 FM, 4
TV stations; 1 Atlantic Ocean satellite sta-
tion
Defense Forces
Defense is the responsibility of dis United
Kingdom
Branches: Gibraltar Regiment
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
[
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','aa36fcd0ebd4173578eac3a63147ec33951bdc6fc411f3597027e5de78085660','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efd2613532beaf3c463cf262b58281c43c452899b428cfd5df0c7f1c0e612130',1986,'GR','Greece','communications',198,'L-3
7 &Ff Limnos
at Qylésvos ;
&- Aegee Sea -
S)nios
fonian
3
Mediterranean Sea”
See regional map V
Land
131,944 km?; the s size of. New York; 40%
meadow and pasture; 29% arable and per-
manent crop; 20% forests 11% waste, urban,
and other | :
Land boundaries: 1,191 km
Water: ;
Limits of sewiiorate waters ‘clatved)s 6nm
Goasitine: 13,676 km
Railroads: 2,089 km total; 503 1:435- meter
km standard gauge; 1,586-km 1.000-meter
gauge, 18km 1. 000-meter gauge double ,
track
Highways: 17,700 km total; 9,100 km bitu-
minous; 8,600 km improved and |
unimproved earth
Pipelines: 797 kin crude oil; 86 km refined
products; 742 km natural gas
Ports: 5 major, 14 minor; eae oils,
and lubricants terminal
Ctwil air: 19 major transport aircraft ,
Airfields: 29 total, 27 usable; 13 with
permanent-surface runways; 6 with run-
ways 2,440-3,659''m; 8 with runways
l, net 2,439 m
Telecommunications: the system is above
the African average; facilities consist of
open-wire lines, multiconductor cable, and
radio relay; key centers are. Safaais; Sisah,
Bizerte, and Tanis; 232,000 telephones (3.4
per 100 popl.); 18 AM, 4 FM, 14: TV stations;
4 submarine cables; ARABSAT satellite
back-up control station under construction;
coaxial cable to Algeria; radio- relay to Alge-
ria, Libya, and Italy
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 1,794,000;
1,002,000 fit for military service; about -
84,000 reach military age (20) annually
M ilitary budget: for fiscal year ending 31
December 1985, $284 million; 7.4% of cen-
ae government budget :
Turkey
400 km
Black Sea
Mediterranean
Sea
See regional map VI
ce aaibanimmmmmemmmemneinennmmmmmsmee eee]
Land
780,576 km?; twice the size of California;
35% crop, 25% meadow and pasture, 23%
forest, 11% other
le iene 2,574km -
Water .
Limits of territorial waters (claimed): 6 nm,
except in Black and Mediterranean Seas,
where it is 12 nm
Coastline: 7,200 km','553e13819c267df5ea191c6a79fdbc72eb2f6edd0f703d2ece856dee391e2e4d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b78f56b8e01ec2415527e6562f574a3e9bb8ce43fcc8a05725adc27d5bab7d35',1986,'GL','Greenland','communications',204,'Railroads: none
Highways: 80 km
Ports: 1 maior, 9 minor, 7 secondary
Civil air: 2 major transport aircraft
Airfields: 10 total, 7 usable; 5 with
permanent-surface runways; 2 with run-
ways 2;440-3,659 m, 2 with runways
1,220-2,439 m , ;
Telecommunications: adequate dbmnestie
and international service provided by cables
and radio relay; 17,900 telephones (31.0 per
100 popl.); 7 AM, 24 FM, 9 TV stations; 2
coaxial submarine cables; 1 Atlantic Ocean
satellite station ;
Defense Forces ©
Defense i is responsibility of Denmark
Military baer included with Den-
mark
97
LADEN.
Arctic
180
Ocean
185
DEN) |
sdvier
UNION
ayaa
s18 mc
eas and
i
ViMiddie East
ve x
As
so WEE,
(DENMARK)
Queen Elizabeth
F islands Ms _7 Denmark
5 p pet ‘ Strait
+ “Resolute
R yy Frobisher’,
i : Jeux Bay... RY
Qagortoq
Prem ‘ . Labrador Sea
‘Slave Lake C. N K D
Uranium City ’
2 - | udson Bay =
Athabasca .
Goose* j
Bay J
!churchitl® Schefferville,
* Newfoundland
Fort George ; g \\i-
a \\\\ Ti ot St "St, Pierre
and Miquelon
(FRANCE)
rs Sydney
Edmonton
Lake a \\$ J ge, Lawrence \\
* Winnipeg Moosonee®
| P RSt. John’s
Regina,
Winnipeg. Quebec
PAG mS uperior
Gan MissoUn Bue, | 2 % Leke Montreal
Falls i a Huron \\ Ottawa®
s ; < Peed 3 Boston
f Minneapolis* Lake >,
7 . aa Michigan) : ake ee ae
s ae Za) Cie Nort
t te : ;
Late Nb, Salt Leke City Chicago Late"*cieVeland _ a -ehiadelphia
ve '' Erie Lb 7 ‘
\\ spies
‘
\\ Nortotky;
tlantic
Ocean
"Ono RN
“YNITEDL STATES oe ) “Bermude
\\ (WK)
2. i 1
:
rf
Albuquerque
Phoenix querd
\\
ACharleston
Nogales
«Hermosilio
Chihuahua
Torreon, ee
Monterrey
.Durango Gulf of Mexico
MEXICO]
Leén
“Guadalajara i
‘sTampico
Mexico*® \\ Veracruz
Puebla ‘ss
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
\\
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Central America and the Caribbean) d
90 1 70 60
\\ 8 Grand ‘
i 7.4 Bahama |
“ i Freeport, {
!
"} + ‘Bimini | North
Gulf of Mexico . ‘ fe Islands 1!
Quy Eleuthera : ;
’ i Atlantic
s Straits |
i Cat Island +
4 of i
Pace at r en
Si ee oS basen Tropi Florida
--- 2 Pleo Cancer mb tas OS es errno
a ‘Matanza’ i
fo alee Crooked Mog
= 5 .Cay Lobos Island “ é Mayaguana -
¢ ~Cientuegos (TNE BaleaMas) faccklins'' ¥
Yucat oan : ‘ ‘stand caleos stands
‘ucatan ; a
Channel eae Sw OK)
CUB 6 7 Grind
reat Inagua ba Turk
Y Holguin, o :
3 Windward 20-
Santiago :
de Cuba,
‘Cayman Islands :
Pa :
wk) itis
George Town DOMINICAN vette anogada
REPUBLIC San Juan (xa > Passage
Montego Bay, “ Mona +e
a We ‘ ae Passage = Viegin Is. .)
7 ™ ing Isla? by Antites:
JAMAICA MecastoOm Mona Puerto Rico, GAP cnet SANTIGUA AND BARBUDA
Swan ” “ WS) Basseterré ~ St. John''s
Isiands ST. CHRISTOPHER Ss
(HONDURAS? AND NEVIS ‘s
: Montserrat Guadetoupe
Nad “ERANCE)
Basse-Terre ® vrarie Galea
Coban,
3 Isla Aves*
GUATEMALA oemzuen — POMNEAN
f Quezaltenango i ic Martini
. 5 . ; jartinique
Guatemala . HONDURAS Caribbean Sea : Fort-do-Francsny’" Rance)
Tegucigalpa *. { Castrie:
* Cayos \\ ST. LUCIA’
Miskitos
(uicaraguay igs j a BARBADOS.
. Providencia| ST. VINCENT AND * ridgetown
a .Matagalpa (COLOMBIA) : THE GRENADINES *.“inastown
ei < Lambs Netherlands Antilles .
‘orinto®. R (NETH.) .
ea NICARAGUA qj "sla de San Andrés Curacao "'' St. George''s $ GRENADA
Managua ~ Bluefieldsd —istas «COLOMBEA) b : yBonaire
Granada}, del Maiz . i\\ Willemstad * ae °
, | L\\ i _ Todago,
: TRINIDAD] AND
a Port-of Spai TOBAGO
a7 ; ini |
Trinidad 10-
yr __ au
North fe
Pacific
iy
Ocean
fi
tsia det Coco,
, (COSTA RICA)
Scale 1:12,500,000 «
ae
° 500 Kilometers q :
1 a4 r
° 500 Nautical Miles Hi |
: eA 8 !
90 Boundary representation is not nece: ily authoritative. ff
800540 (545527) 4-86 Map Ill
t
i :
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ista de Maipelo +
(COLOMBIA)
Equator
-0
100 *
800541 (545528) 4-86
South America
40
Caribbean Sea
Barranquillagyf
Ista San Félix’ |*tsta San Ambrosio
(CHILE) (CHILE)
Archipiélago
Juan Fernandez
(CHILE) ¢
Concepcién
North
aracaibo
Atlantic
Sobel roe cise /
ees! VENEZUELA Guayana
GUYANA }
Boa Vista®
Ocean
} Georgetown
Paramaribo
fiw French Guiana
(FRANCE)
Caye nag
Sty ae
<7 20% 4b
Amenas” | nt Belém
on Fonte Boa >
Santarém
S40 Luis
Fortaleza
Teresina,
Natal
Rio «Pérto Velho
A Branco, venci jRecite
Aracaju
ae
“Salvador
xerasilia
Goiania,
Belo
eHorizonte
Vitoria 7
sang he ONE Pe ae eo, Rio de Janeiro,
—Ant 2 Sao Paulos et
San Miguel Curitiba*
de Tucuman
Resistencia
Florianépolis
f South
ip Pérto Alegre,
re bsan’ Ly Atlantic
URUGUAY 4
Cérdoba,
.Mendoza Rosario Ocean
Buenas Aires
ea (NORWAY) \\
; \\
tseqqortoormiit Hammarteatf
ian Mayen','94e7331b85bb5902f1a862a78a457139ca7332a8bd81317ab09fac5c9bc2519e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8022cace923197d76c992f7b98b8d374be3af422b1c0086430a7446e4be3563',1986,'GD','Grenada','communications',205,'‘45km_
; S
Caribbean &
Sea _ &
Caribbean —
Sea
See regional map ul
Land
344 km? (Grenada and southern
Grenadines); twice the size of Washington,
D.C.; 44% cultivated; 17% unused but po- .
tentially productive; 12% forest; 4% pasture;
23% built on, waste, and other
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 121 km
Railroads: none
Highways: 1,000 km total; 600 km paved,
300 km otherwise improved; 100 km unim-
proved .
Ports: 1 major (St. George’s),-1 minor
Civil air: no maior transport aircraft ‘
Airfields: 3 total, 3 usable; 2 with -
permanent-: surface runways, 1 with run-
ways 2,440-3,659 m, 1 with ronays
1,220-2, 439 m : 4
Telecommunications: automatic,
islandwide telephone system with 5,650 tele-
phones (5.1 per 100 popl.); new SHF links to
Trinidad and Tobago and St. Vincent; VHF
and UHF links to Trinidad and Cartiacou; 1
AM station, 1 TV station ,
Defense Forces
Branches: Royal Grenada Police F. orce|
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','daab706ac95c2574f6db223c739f217ccec035ff39e81e69ecb72e0040591bae','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e2f43f12a87a1bcebaed9099446a5041923d7027cf97bf568f7f69bcd1a0c7b',1986,'GP','Guadeloupe','communications',208,'‘20 kin :
=) ee 5
Caribbean
RRE
jles des Saintes’ :
2,
OP
- St. Martin and St. Barthélemy
are not shown.
See regional map III .
Land = eee
1,779 km?; more than twice the size of New
York City; area consists of two islands; 47%
waste and built o on, 24% crop,. 16% forest, 9%
pasture, 4% potential crop"
Water 4 -
Limits of territorial waters (claimed): 12°
nm (200 nm exclusive economic zone)
Coastline: 306 km
Railroads: privately owned, narrow-gauge
plantation lines —
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Guadeloupe (continued)
Highways: 1,954 km total; 1,600 km paved,
340 km gravel and earth
Ports: 1 major (Pointe-a4-Pitre), 3 minor
Civil air: 2 major transport aircraft
Airfields: 9 total, 9 usable, 8 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439
Telecommunications: domestic facilities
inadequate; 57,300 telephones (17.4 per 100
popl.); interisland radio-relay to Antigua and
Barbuda, Dominica, and Martinique; 2 AM,
3 FM, 9 TV stations; 1 INTELSAT satellite
station
Defense Forces
Defense is responsibility of France
Military manpower: males 15-49, 89,000','2378a286fd5b7e975d1c52e8da7d5f8445a886561af34fc45b081efd252861ff','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7896b6237cd2a7e703951689059588ddfc75e15d8389f9d355990d68ea0a7a52',1986,'GT','Guatemala','communications',212,'100 km
Bahia de
Amatique
omas
astilla
North
Pacific
Ocean
See regional map III
Land
108,780 kin*; the size of Tennessee; 57% for-
est; 14% cultivated; 10% pasture;.19% other -
Land boundaries: 1,625 km.
Water :
Limits of ieinionala waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 400 km
Railroads: 870 km 0.914-meter gauge, single
track; 780 km government owned, 90 km
privately owned
Highways: 26,429 km total; 2,868 km paved,
11,421 km gravel, and 12,140 unimproved
101
Inland waterways: 260 km navigable year
round; additional 730 km navigable during’
high-water season
Pipelines: crude oil, 48 km
Ports: 2 major (San José East [Puerto
Quetzal], Santo Tomas de Castilla), 3 minor
Civil air: 10 major transport aircraft
Airfields: 498 total, 452 usable; 11 with
permanent-surface runways; 3 with run- -
ways 2,440-3,659 m, 2] with runways |
1,220-2,439 m ;
Telecommunications: fairly modern
telecom network centered on Guatemala;
97,670 telephones (1.6 per 100 popl.); 93
AM, 24 TV stations; connection into Central
American microwave net; 1 Atlantic Ocean
satellite station
Defense Forees
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 1,985,000;
1,347,000 fit for military service; about
77,000 reach military age (18) annually
Military budget: proposed for fiscal year
ending 31 December 1985, $198.4 million;
15.5% of central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','908c3a53e76cd91c26ac195eaf98370efcf0c411c888592510dfcbc80961d303','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb511d4fc65137aad64d25431a35ddc7ff2be3fb7224f715fffd63acf63afb14',1986,'GG','Guernsey','communications',216,'“Skm 7 Burhots LE :
Alderney
English Channel
St. Sampson
YHerm
Yeth ou
Brecqhous
Ss. ark
Little Sark™,
See regional map V
Land
194 km?; larger than Washington, D. C.;
part of the Channel Islands, includes de-
pendencies of Guernsey—Alderney, Br-
ecqhou, Sark, Little Sark, Herm, Jethou, and
Lihou Island _
Water
Limits of territorial waters (claimed): 3 nm,
(200 nm fishing)
Coastline: about 50 km
Railroads: none
Ports: St. Peter Port, St. Sampson''s
Airfields: airport at La Villiaze, Guernsey,
has tarmac runway of 1,463.04 m; there is
also an airport on Alderney
Telecommunications: 1 AM radio station,
which broadcasts 24 hours a week; 1 TV sta-
tion; 41,900 telephones (74.8 per 100 popl.): -
Defense Forces .
Defense is the esponsibality of the United
Kingdom
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','5aff742d8f16a04fe82456f72d7415a49d7744a99af76e304552af700b33d270','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fb8518bd6d6f42a670f453fcea18672c59c6e19b4ff57f41dda536f4e4ebda7',1986,'GY','Guyana','communications',220,'200 km ; North Atlantic
arumMa
Ocean
EORGETOWN
Boundary representation is
nol necessarily authontative
See regional map IV
Land
214,970 km?; the size of Idaho; 66% forest;
22% water, urban, and waste; 8% savanna;
3% pasture; 1% cropland
Land boundaries: 2,575 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 459 km
Railroads: 187 km total, all single track
0.914-meter gauge
Highways: 7,665 km total; 550 km paved,
5,000 km gravel, 1,525 km on 590 a
unimproved
Inland-waterways: 6,000 km total of naviga-
ble waterways; Berbice, Demerara, and Es-
sequibo Rivers are navigable by oceangoing
vessels for 150 km, 100 km, and 80 km, re-
spectively
Ports: 1 major (Georgetown), 6 minor
Civil air: 5 major transport aircraft
Airfields: 70 total, 67 usable; 6 with
permanent-surface runways; 12 with run-
ways 1,220-2,439 m
Telecommunications: fair telecom system
with radio-relay network and over 27,000 —
telephones (3.3 per 100 popl.); tropospheric
scatter link to Trinidad; 3 AM, 3 FM; no TV
stations; 1 Atlantic Ocean satellite station
Defense Forces ee
Branches: Guyana Defense Force (including
Maritime Corps and ‘Air Gorps), Guyaria”
Police Force, Guyana People’ s Milita,
Guyana National Service ee
Military manpower: males 15- 49, 199, 000;
158,000 fit for military service
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','04c49a101ca703938fae40a925bee585d16a09f1f3f3ddfc3e90b039c9da80cd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb2f7cbdb890904645a2f5019c5e9c78b64cff810b7a4187ba2aa0ac85d6e60a',1986,'HT','Haiti','communications',224,'North Atlantic Ocean.
Ile de la Tortuga zy,
Golfe de la Gonave
lle de ta Gonave §
érémie
G2
PORT-AU-PRINCE,
Caribbean Sea
See regional map IIT
Land Eee
27,749 km?; the size of Maryland; 44% un-
productive, 31% cultivated, 18% rough pas-
ture, 7% forest
Land boundary: 361 km
Water “a.
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 1,771 km
Railroads: 40 km 0.760-meter narrow gauge,
single-track, privately owned industrial line
Highways: 4,000 km total; 950 km paved,
900 km otherwise improved, 2,150 km un-
improved
Inland waterways: negligible; less than 100
km navigable
Ports: 2 major (Port-au-Prince,
Cap-Haitien), 12 minor
Civil air: 4 major transport aircraft
Airfields: 15 total, 11 usable; 3 with
permanent-surface runways; | with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,489 m
Telecommunications: domestic facilities
barely adequate, international facilities
slightly better; 36,000 telephones (0.5 per
100 popl.); 31 AM, 32 TV stations; 1 Atlantic
Ocean satellite station
Defense Forces
Branches: Army, Navy, Air Corps
Military manpower: males 15-49, 1,317,000;
733,000 fit for military service; about 63,000
reach military age (18) annually','b49653c2bf1a530d7ebc07bfb932ffa38d043cfe5e131e0c61a96f6dbaa9bccd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('246c28815c416b8bed2134602c9c6cbe24dd1774f3d1761762e6d49e0b643ce2',1986,'HN','Honduras','communications',228,'150 km
Caribbean Sea
whe fie P
~ “Islas de la Bahia
Puerto Cortés
Golfo de
Fonseca
Boundary representation is
not necessarity authoritative
See regional map III
Land
112,088 km?; slightly larger than Tennessee;
36% waste and built on, 30% pasture, 27%. _
forest,7% crop 7
Land boundaries: 1,530 km.
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 820 km
People | ma OP os
Population: 4,648,000 (July 1986), average
annual growth rate 3.3%
Nationality: noun—Honduran(s); adjec-
tive—Honduran
Ethnic divisions: 90% mestizo (mixed Indian
and European), 7% Indian, 2% black, 1%
white ‘
Religion: about 97% Roman Catholic; small
Protestant minority. .
Language: Spanish, Indian dialects
Infant mortality rate: 78/1,000 (1984)
Life expectancy: 58.7 -
_ Literacy: 56%
Labor force: 1.3 million (1985); 62% agricul-
ture, 20% services, 9% manufacturing, 3%
108
construction, 5% other; 25% unemployed;
25% underemployed
Organized labor: 40% of urban labor force,
20% of rural work force (1985)
Railroads: 1,207 km total; 444 km 1.067-
meter gauge, 763 km 0.914-meter gauge
Highways: 8,950 km total; 1,700 km paved,
5,000 km otherwise improved, 2,250 km
unimproved earth
Inland waterways: 465 km navigable by
small craft
Ports: 1 major (Puerto Cortés), 4 minor
Civil air: 9 major transport aircraft
Airfields: 195 total, 179 usable; 7 with
_ permanent-surface runways; 4 with run-
ways 2,440-3,659 m; 8 with runways
1,220-2,439 m
4
109
Telecommunications: improved, but still
inadequate; connection into Central Ameri-
can microwave net; 35,100 telephones (0.9
per 100 popl.); 160 AM, 67 TV stations; 2
Atlantic Ocean satellite ground stations
Defense Forces ; . :
Branches: Armed Forces, Naval Forces, Air
Force
Military manpower: miales 15-49, 1,021,000;
608,000 fit for military service; about 51,000
reach military age (18) annually
Military budget: for the fiscal year ending
31 December 1986, $67.5 million; about 7%
of the central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','4b3d0124097efebfb4b995ed13a05ac54ff8f5f54f13a6559d8b982711f2ecae','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b664a276a9e45e74ca4400ebf8d1cdcbd8e2f6ad24773f01334fc7d282dd8f7a',1986,'HK','Hong Kong','communications',231,'15. km
Lema Channel |
See regional map vill
Land
1,060 km2; about one and one-third times
the size of New York City; 14% arable, 10%
forest, 76% other (mainly grass, shrub, steep
hill country) - ,
Land boundaries: 24 km
Water
Limits of territorial waters (claimed): 3 nm
Coastline:733km
Railroads: 35 km 1:435-meter standard
gauge, government owned
Highways: 1,160 km total; 794 km paved,
306 km gravel, crushed stone, or earth —
Ports: | major (Hong Kong)
Civil air: 16 major transport aircraft
Airfields: 2 total; 2 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: modern facilities pro-
vide excellent domestic and international -
services; 62 telephone exchanges, 1.5 million
telephones; 5 AM and 9 FM radiobroadcast
stations with 11 transmitters; 5 TV stations;
2.5 million radio and 1.1 million TV receiv-
ers; 10,100 Telex subscriber lines with direct
connections to 47 countries; 2 INTELSAT
ground stations with access to Pacific and
Indian Ocean satellites; coaxial cable to
Guangzhou (Canton), China; 3 international
submarine cables; troposcatter to Taiwan
available but inactive
Defense Forces
Defense is the responsibility of United King-
dom
Branches: Headquarters of British Forces,
Gurkha Field F orces, Royal Navy, Royal Air
Force, Royal Hong Kong Auxiliary Air
Force, Royal Hong Kong Police Force
Military manpower: males 15- 49, 1,620,000;
1,274,000 fit for military service; about
53,000 reach military age (18) annually
Military budget: est. for fiscal year ending
30 June 1984, $195.3 million; about 4.3% of
central government budget and 1% of GDP','b9c28d8381539a2a6ad2f5aa47cc9a4c1ec7ff6589f0d7fdcc9602dc842c254d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a92bc4adb4f240660a0a9f07588dd31a648ca3e383ec278b3ce42d07e03cff91',1986,'HU','Hungary','communications',234,'125 km
See regional map V.
a
Land
93,030 km?; slightly smaller than Indiana;
70.5% agricultural and pastureland, 17.6%
forest, i. 9% other
Land boundaries: 2,242 km
Railroads: 7,869 km total; 7, 620 km 1. 435-
meter standard gauge, 214 km narrow gauge
(mostly 0.760-meter), 35 km 1.524-meter |
broad gauge, 1,119 km double track, 1, 807 |
km electrified; government owned (1983).
Highways: 29,684 km total; 25,922 km con-
crete, asphalt, stone block; 3, 213 km asphalt, .
treated, gravel, crushed stone; 549 km earth
(1982)
Inland waterways: 1,622 km (1983)
Pipelines: crude oil, 1,160 km; natural gas,
8,732 km (1984)
Freight carried: rail—124 million metric
tons, 23.1 billion metric ton/km (1983);
highway—235 million metric tons, 6.5 bil-
lion metric ton/km (1983); waterway——est.
3.2 million metric tons, 1.7 billion metric
ton/km (public and private use) (1983)
River ports: 2 principal (Budapest,
Dunativaros); no maritime ports; outlets are
Rostock, GDR; Gdatisk, Gdynia, and
Szczecin in Poland; and Galati and Braila in
Romania (1978) ;
Defense Forces
Branches: Hungarian People’s Army, Fron-
tier Guard, Air and Air Defense Command
Military manpower: males 15-49, 2,588,000;
2,074,000 fit for military service; about
75,000 reach military age (18) annually
Military budget: announced for fiscal year
ending 31 December 1985, 23.3 billion
forints; 3.8% of total budget
112','58b525d8c5b4bf9f5f655c747ed3e5bc849673b90272ec16ae0794d969c90d2c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8ab76d7a0bf673b7dd083bb055cd34fd35090598ce68e52ee187bd1f68fb4d5',1986,'IS','Iceland','communications',238,'North Atlantic Ocean
See regional map V
Land
102,845 km?; the size of Virginia; arable and .
forest negligible, 22% meadow and pasture,
78% ee
Water .. ;
Limits. of territorial waters jelitinedl 12
nm (200 nm exclusive economic zone).
Coastline: 4,988 kn
Railroads: none
Highways: 12,343 km total; 166 km bitumen
and concrete; 1,284 km bituminous treated .
and gravel; 10,893 km earth |
Ports: | major (Reykjavik), 8 secondary
(Akureyri, Hafnarfjérdhur,
Seydhisfjérdhur), and numerous minor
Civil air: 20 major transport aircraft _
Airfields: 98 total, 91 usable; 3 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 11 with runways
1,220-2,439 m
Telecommunications: adequate domestic
service, wire and radio communication sys-
tem; 125,000 telephones (52.5 per 100 popl.’;
4 AM, 33 FM, and 129 TV stations; 2 subma-
rine cables; 1 satellite station with 2 Atlantic
Ocean antennas :
Defense Pances ;
Branches: Police, Coast Gis:
Military manpower: males 15-49, 64,000;
55,000 fit for military service (Iceland has no
conscription or compulsory military service) .
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Reykjav’ en
Térshavn ‘*
Arctic Circle
roe, <
Islands Trondhetr Helbinkix:
(DENMARK) E avieX ar
~ tslands
ate | Shetland ¢ Bergen...
ee
by /
/
1000 Nauticat Miles
Arctic Region
\\ ;
\\S OMLET
7 \\ \\ Tura. _——j
c \\
SOF tm
UNION
i sNoril''sk Yenise
: Y,
Leningrad
A + e
4 (SWEDEN, \\Tampere ‘Cadoga
si \\ LK
The United States Government has not recognized
the incorporation of Estonia, Latvia, and Lithuania
into the Soviet Union. Other boundary representation
is not necessarily authoritative. -
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
arse as eae oy See
radi anne nr ay Aha aR I gL eR gene
ipaliay, ap ae Ska ake on
eee ie
ow
a
ee pee ie ee ee LE
Ey nee f
pares arene
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Antarctic Region
\\ a iN
— O SS
/ \\
é %|
a
Atlantic
2
Islands
vist ae p
slan UPS 7
borer ad Arturo Prat o oxe= we A? >A
Passage afc Weddell td ™ eBélley
Palmer ¥4 WK)
(U.S.) ©
VF Pty
= —piareentinsh, A
Rothera’® ~y
WKY
S
bs ntexanaen 97 3) Ice a: Be Ne
ei LA a
j ; vs, aS
"Sé
me
(W.S) Amundsen-Scott ® South
(.s.) Fale
Georg vone/
7 —“Neumayér
AS (FED. at GER.)
Tad
Molodezhnaya he
(SOVIET UNION) G uC
y ‘
\\
By
Amery fee Shelf
‘ TEOavis
-g (AUSTRALIA)
Mirnyy
(SOVIET UNION)$ Shackleton
. Nice Shelf
Vostok ao
{SOVIET UNION) $—
3
Casey
(AUSTRALIA)
VA a Cott gg ‘Ss.
“£ averige minimum ee yy
extent of sea ee 4
ists (ET pl OF
So th Nt, gf d''Urville
Letingradskaya (FRANCE)
; ; (SOVIET ‘Wnion <4
2 i ae ee ~ Scott Island Sie &.
“9° OOP ES ~“Balleény tslands a Yr)
Ocea
= Selected year-round research station
a,
7,
yo Scale 1:55,000,000
\\ 0 500 1000 Kilometers
Py
‘ ) 500 1000 Nautical Miles
— AS ie
800549 (545666) 4-86
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
aa
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Standard Time Zones of the World
3
es,
135 185 180
ra
fn
it
3
e
\\ET { UNION
pana
i
a
FH
|
i | NOTED onruah 8
TATES 9, 5
j
1 m °
| Atlalntic
- ° a =z
z | 30
Ocean io. Ocdan fe)
7 5011 e
: ‘a yne anants Se P|
e! y i eo,
aes ‘Caan coutcsn
use ‘ ey? haurianta ° 7
Sree ae xeso seaka a ra
Sato iganacun 7h cine L
| Paya pro and ronaco cue oon sibirach 24 Fours
7 Nventzue roan | srenna Lede cow.
oe siuen Pithen cana Twatton | |
- bee 3
L oe ey ime Oa |
* EcUgoOR i
on {
< '' e
Pent BRAZIL |
BOLIVIA) of
100 chan
) 3
spe eoauth Iakecud? South o(] 3
KK, Gees c) °
° Patitic Atlantic ° i
fe
> ch fr F
Odean Ocean + |g
3 3
° i
z
|
i) | +),
CAR. -CENTRAL AFRICAN REPUBLIC & 19%
FRG “FEDERAL ReFUaLIC OF GERMANY 3
GDR, -Genwan oemocharic Nerul ponies
PDRY_ PEOPLES DEMOCHATIC REPUBLIC OF YEMEN % Meant A
UAE. -UNITED ARAB EMIRATE fe x pia Number indicates standard time.
YAR. —YEMEN ARAB REPUBLIC | ] | Mer: in zone when itis 12 000, GMT }
sun 2 oN Sun at, | sun
ot 200 “300 400 8.00 6.00 700 8.00 00 10.0 soo | 188: 1200 1400 13100 1600 280 | £86
4 io 3 7 é 3 4 a 2 fi 0 4 2 3 4 ie |
; ra ee a a a cr oe es ee ee aL Bei
‘800550 (545036) 4-66
‘Ad ine zone number to oc tine to cbiin GMT tract timezone number om lca moto obain GMT Map XII
‘Subtract time zoné number trom GMT 10 obtain tocal time WEST EAST jag time zone number to GMT to obtsin focal time ia
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','eddde619e918ecdcc18d1e3552f72fb5e287c8dba318972ae81250fd3b778d9c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed8203aaa8ec9ac461cd5dbd0f481ac9e85852aa08e00a0dbb9d634480f42715',1986,'IN','India','communications',241,'DN
Jammu and. Chineseline .. ae
2, of control 500 km
indian : :
claim
Arabian
Sea
nA 7 Boundary representation is
not necessarily authoritative.
Bay of
Calicut! Bengal net f
S Andamant
durai “Islands «
Laccadive “peo os
Sea Nicobar:
See regional map VIII istands ®
|
Land
3,287,590 km? (includes Jammu and
Kashmir, the Indian-annexed part of the
former state of Jammu and Kashmir); one-
third the size of the US; 50% arable; 22%
forest; 20% desert, waste, or urban; 5% per-
manent meadow and pasture; 3% inland
water .
Land boundaries: 12,700 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 7,000 km (includes offshore is-
lands)','e4d47ecf1128d1deed0f7d4da66ec61a85555dd122d1d937a3814677544a2a3c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddcfe89e988464a9c82b32fda3d17fef255fdb482e6c34b0654e562cb3056407',1986,'ID','Indonesia','communications',247,'Railroads: 6,964 km total; 6,389 km 1. 067-
meter gauge, 497 km 0.750-meter gauge, 78
km 0.600-meter gauge; 211 km double
track; 101 km electrified; government
owned
Highways: 93,063 km total; 26,583 km
paved, 41,521] km gravel or crushed stone,
24,959 km improved or unimproved earth
Inland waterways: 21,579 km; Sumatra
5,471 km, Java and Madura 820 km, Borneo
10,460 km, Celebes 241 km, and''Trian Jaya
~ 4,587 km
Pipelines: crude oil, 2,450 km; refined prod-
ucts, 456 km; natural gas, 450 km
Ports: 15 ocean ports
Civil air: approximately 150 major transport
aircraft
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Airfields: 416 total, 393 usable; 95 with
permanent-surface runways; | with run-
ways over 3,659 m, 11 with runways 2,440-
8,659 m, 68 with runways 1,220-2,489 m
Telecommunications: interisland micro-
wave system and HF police net; domestic
service fair, international service good;
radio-broadcast coverage good; 392,563 tele-
phones (0.2 per 100 popl.); 251 AM, 1 FM, 14
TV stations; 1 interriational ground satellite
station (1 Indian Ocean antenna and 1 Pa-
cific Ocean antenna), and a domestic satel-
lite communications system
Defense Forces
Branches: Army, Navy, Air Force, National
Police
Military manpower: males 15-49,
44,809,000; 26,513,000 fit for military ser-
vice; about 1,955,000 reach military age (18)
annually
Iran
400 km
Caspian
Sea
Strait of :
Hormuz ” dar
Gulf Beheshi
See regional map VI , Onn
Land
1,648,000 krn2; smaller thain Alaska and
Washington combined; 51% desert, waste, or
urban; 30% arable (16% cultivable with ade-
quate irrigation; 14% agricultural; 11.5%
cultivated); 11% forest; 8% migratory graz-
ing and other
Land boundaries: 5;318 km (including areas
belonging to Iran and now occupied by Iraq
during continuing border war)
Water
Limits of territorial waters (claimed): 12
nm (fishing 50 nm or median line)
Coastline: 3,180 km, includingislands, with
676 km ,
Railroads: 2,145 km total; 1 ,645 km 1.435- -
meter standard gauge, 520 km 1.000-meter
gauge “a4
Highways: 20,800 km total; 6,490 km paved, -
4,654 km improved earth, 9,656 km unim- ; -
proved earth
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Iraq (continued)
Inland waterways: 1,015 km; Shatt al Arab
navigable by maritime traffic for about 104
km (closed since September 1980 because of
Iran-Iraq war); Tigris and Euphrates naviga-
ble by shallow-draft steamers (of little im-
portance); Shatt al Basrah canal navigable by
shallow-draft vessels
Ports: 3 maior (Al Basrah [closed], Umm
Qasr, Al Faw); none in operation due to war
Pipelines: crude oil, 3,950 km; 725 km re-
fined products; 1,360 km natural gas
Civil air: 16 major transport aircraft
Airfields: 108 total, 94 usable; 56 with
permanent-surface runways; 6 with run-
ways over 3,659 m, 50 with runways 2,440-
3,659 m, 12 with runways 1,220-2,489 m
Telecommunications: good network consists
of coaxial cables, radio-relay links, and
radiocommunication stations; about 632,000
telephones (4.3 per 100 popl.); 9 AM, no FM,
81 TV stations; 1 Atlantic Ocean, 1 Indian
Ocean, and 1 Intersputnik satellite station;
coaxial cable and radio-relay to Kuwait, Jor-
dan, Syria, and Turkey
Defense Forces
Branches: Army, Navy, Air Force, Border
Guard Force, mobile police force
Military manpower: males 15-49, 3,662,000;
2,105,000 fit for military service; about
177,000 reach military age (18) annually
Military budget: estimated for fiscal year
ending 31 December 1983, $14.0 billion','bc3e04f433d76ff35fda69ffd99d1f0eec90ae221cd763243b2ef422eadb5da3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8477d25237ec5c8a87718e512218ab34c90c791880203e53afcb640c6055014',1986,'IE','Ireland','communications',248,'See regional map
Land
70,282 km?; larger than West Virginia; 51%
meadow and pasture, 27% waste or urban,
17% arable, 3% forest, 2% inland water
Land boundaries: 360 km
Water —
Limits of territorial waters (claimed): 3 nm
(fishing 200 nm)
Coastline: 1,448 km
Railroads: trish National Railways (CIE)
operates 1,942 km 1.600-mieter gauge, gov-
ernment owned; 485 km double; 38 km elec-
trified track
Highways: 92,294 km total; 87,422 km sur-
faced, 4,872-km gravel or crushed stone,
Inland waterways: limited for commercial
traffic
Pipelines: natural gas, 225 km
Ports: 2 major, 6 secondary, 38 minor
Civil air: 23 major transport aircraft
Airfields: 41 total, 37 usable; 16 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: small, modern system
using cable and radio-relay circuits; 824,000
telephones (23.5 per 100-popl.); 24 AM, 20
FM, 84 TV stations; 4 coaxial submarine
cables; 1 satellite ground station
Defense Forces
Branches: Army, Naval Service, Army Air
Corps
Military manpower: males 15-49, 852,000;
698,000 fit for military service; about 27,000
reach military age (17) annually
12]
Major ground units: 4 infantry brigades and
2 independent battalions
Supply: UK and France are the principal.
suppliers of army materiel; UK provides
105-mm light guns and Scorpion light tanks, -
and France provides MILAN antitank mis-
siles and Panhard reconnaissance vehicles;
Sweden also provides weapon systems; in-
cluding RBS-70 surface-to-air missiles, re- °- -
coilless rifles, and armored personnel carri-
ers :
Military budget: for fiscal year ending 31
December 1985, $256.955 million; about
2.5% of the central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','87a3f76628057eba13714c2495cd8f50fc3e657ac26f18c155ebd6bff7d8b01d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50085bb4db26af143a6f1a3816dce01f650f68c3026a198363a2ca11d948b8ec',1986,'IL','Israel','communications',252,'(West Bank and Gaza Strip
listed at end of table)
100 km
Lake
Tiberias *
Sea
Boundary representation is
not necessarily authoritative
See regional map VI
NOTE: the Arab territories occupied by
Israel since the 1967 war are not included
in the data below; as stated in the 1978
Camp David Accords and reaffirmed by. .
the President’s 1 September 1982 peace ...
initiative, the final status of the West Bank.
and Gaza Strip, their relationship with
their neighbors, and a peace treaty be-
tween Israel and Jordan are to be negoti-
ated among the concerned parties; Camp«
David further specifies that these negotia-
tions will resolve the location of the re- .
spective boundaries; pending the comple-
- tion of this process, it is US policy that the
final status of the West Bank and Gaza
Strip has yet to be determined (see West
Bank and Gaza Strip Factsheet”); on 25
April 1982 Israel relinquished control of
the Sinai to Egypt; statistics for the Israeli-
occupied Golan Heights are included in
the Syria “Factsheet.”
Land
20,720 km?; the size of Massachusetts; 40%
pasture and meadow; 29% unsurveyed
(mostly desert); 20% cultivated; 4% forest;
4% desert, waste, or urban; 3% inland water
Land boundaries: 1,036 km (before 1967
war)
Water
Limits of territorial waters (claimed): 6 nm
Coastline: 273 km (before 1967 war)
Railroads: 516 km 1.435- meter gauge single
track; diesel operated
Highways: 4,500 km; majority i is bituminous
surfaced ;
Inland waterways: none -
Pipelines: crude oil, 708 km; refined prod-
ucts, 290 km; natural gas, 89 km
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Civil air: 26 major transport aircraft
123 |
Airfields: 66 total, 52 usable; 27 with
permanent-surface runways; 6 with run-
ways 2,440-3,659 m, 11 with runways
1,220-2,439 m
Telecommunications: most highly devel-.
oped in the Middle East though not the larg-
est; good system of coaxial cable and radio
relay; 1,500,000 telephones (34.7 per 100
popl.); 11 AM, 24 FM, 54 TV stations; 2 sub-
marine cables;,2 Atlantic Ocean satellite
stations; | Indian Ocean satellite station
Defense Forces
Branches: Israel Defense Forces; historically
there have been no separate Israeli military
services; ground, air, and naval components
are part of Israel Defense Forces
Military manpower: eligible 15-49,
1,999,000; of 1,008,000 males 15-49, 635,000
fit for military service; of 991,000 females
15-49, 621,000 fit for military service;
38,000 males‘and 36,000 females reach mili-
tary age (18)annually; both sexes liable for
military service
Military budget: for fiscal year ending 31
March.1985, $4.1 billion; about 24% of cen-
tral government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','75c86d0b2761ff39cf036d3091faf28c650ed3fbcad0838941311a0f1dcffbec','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ececab6eb345b3d40bc20cb3f7a24495a1c25cf6eaa9b08206499285a57fdc34',1986,'IT','Italy','communications',255,'300 km
na
Adriatic
Sea
inia
Tyrrhenian
Sea
7 ‘ Paler
Mediterranean
Sea
See regional map V
Land
301 ,223 km2; slightly larger than Arizona;
50% cultivated, 21% forest, 17% meadow
and pasture, 9% waste or urban; 3% unused
but potentially productive
Land boundaries: 1,702 km
Water
Limits of territorial waters (claimed): 12
nm
Coastline: 4,996 km
Railroads: 20,085 km total; 16,140 km 1.435-
meter government-owned standard gauge,
8,812 km electrified; 3,945 km privately
owned—2,100 km 1.435-meter standard
gauge, 1,155 km electrified, and 1,845 km
0. 950-meter narrow gauge, 380 km electri-
fied
Declassified and Approved For Release 2012/08/29
Highways: 294,410 km total; autos—trade
5,900 km, state highways 45,170 km, provin-
cial highways 101,680 km, communal highb-
ways 141,660 km; 260,500 km concrete, bi-
tuminous, or stone block, 26,900 km gravel
and crushed stone, 7,010 km earth
Inland waterways: 1,600 km for various
types of commercial traffic
Pipelines: crude oil, 1,703 km; refined prod-
ucts, 2,148 km; natural gas, 16,660 km
Ports: 9 major, 11 secondary, 40 minor
Civil air: 182 major transport aircraft
Airfields: 148 total, 141 usable; 84 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 34 with runways 2,440-
3,659 m, 38 with runways 1,220-2,439 m
Telecommunications: well engineered, well
constructed, and efficiently operated; 23
million telephones (40.4 per 100 popl.); 140
AM, 1,837 FM, 1,367 TV stations; 20 subma-
rine cables; 2 communication satellite
ground stations with a total of 6 antennas
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
14,206,000; 11,976,000 fit for military ser-
vice; 462,000 reach military age (18) annu-
ally
Military budget: for fiscal year ending 31
December 1984, $9.6 billion; about 4.7% of
central government budget
125
Ivory Coast
Gulf of Guinea
See regional map VII
Land
322,463 km2; slightly larger than New Mex-
ico; 52% grazing, fallow, and waste; 40%
forest and wood; 8% cultivated; 322 km of
lagoons and connecting canals extend east-
west along eastern part of the coast
Land boundaries: 3,227 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
’ Coastline: 515 km
Railroads: 657 km of the 1,175 km Abidjan
to Ouagadougou, Burkina Faso, line, all sin-
gle track 1.000-meter gauge; only diesel
locomotives in use _
Highways: 46,600 km total; 3,600 km bitu-
minous and bituminous-treated surface;
$2,000 km gravel, crushed stone, laterite,
and improved earth; 11,000 km unimproved
Inland waterways: 740 km navigable rivers
and numerous coastal lagoons
Ports: 2 major (Abidjan, San-Pédro), 2 minor
Civil air: 25 major transport aircraft, includ-
ing multinationally owned Air Afrique fleet
Airfields: 49 total, 45 usable; 3 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m; 13 with runways
1,220-2,439 m
Telecommunications: system above African
average; consists of open-wire lines and
radio-relay links; 87,700 telephones (1. 3 per
100 popl.); 3 AM, 17 FM,.11 TV stations; 2
Atlantic Ocean satellite stations; 2 coaxial
submarine cables
Defense Forces
Branches: Army, Navy, Air Pores: paramili-
tary Gendarmerie
Military manpower: males 15-49, 2,531,000;
1,300,000 fit for military service; 98,000
males reach military age (18) annually
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','53a4c5bc25b048309d221637cc46ddab6e2f724c85a49b667d93b1d76fd338d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65c089c9abff18d9fb8c4e356c51e87515a54840cf544a8621e593708ceb92e2',1986,'JM','Jamaica','communications',259,'50 km
Caribbean Sea
Ocho Rios’
Caribbean Sea
See regional map HI
Land ee ee: :
10,991 km?; slightly smaller teh Connecti-
cut; 23% meadow and pasture; 21% arable;
19% forest; 37% waste, urban, or other
Water
Limits of territorial waters (claimed): 12
nm eRe ide Cae :
Coastline: 1,022 km','9d8bc6cdd301ed7edad8e88bcce95666108dac1bcb38a4f808312232a1357511','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('727972bc2fb504362ccf481728d98a0f1f1bac43539e693742cf96c7f128a748',1986,'JE','Jersey','communications',264,'5 km
English Channel
‘English Channel
See regional map V
Land
117 km?; more than half the size of Wash-
ington D. C.; part of the Channel Islands;
about 58% of land under cultivation
Water
Limits of territorial waters (claimed ): 3nm
(200 nm fishing)
Calitics about 70 km
Railroads: none
Ports: St. Helier, Gorey, St. Aubin
Airfields: airport at St. Peter
Telecommunications: telephones in service,
61,400 (80.9 per 100 popl.); radio station,
independent TV station a ae
Defense Warees
Defense‘is the responsibility ob the United -
Kingdom: ae ae
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','4fead491b2ae4f705b976589b4556f8461d66753543fd7ef98638a0ee8462a08','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c29d616bc41ebc4e07ad4cc71f66dad1d554f61401c27701478eceb5173ced1',1986,'JO','Jordan','communications',268,'(West Bank and Gaza Strip
listed at end of table)
Boundary representation is +.
not necessarily authoritative. *
See regional map VI ; J , 4 S - ee
NOTE: the war between Israel ond the’
Arab states in June 1967 ended with Israel
in control of the West Bank; as stated in
the 1978 Camp David Accords and reaf-
firmed by the President’s 1 September
1982 peace initiative, the final status of the
West Bank and Gaza Strip, their relation-
ship with their neighbors, and a peace
treaty between Israel and Jordan are to be
negotiated among the concerned parties;
Camp David further specifies that these
negotiations will resolve the location of the
respective boundaries; pending the com-,
pletion of this process, it is US policy that
the final status of the West Bank and Gaza
Strip has yet to be determined (see West
Bank and Gaza Strip “Factsheet”’).
Land
90,650 km?; larger than Minnesota; 88%
desert, waste, or urban; 11% agricultural; 1%
forest
| Land boundaries: 1,770 km (1967)
Water
Limits of territorial waters (claimed): 3 nm
|
|
| Coastline: 26 km
Railroads: 817 km 1.050-meter gauge, single.
track
Highways: 6,332 km total; 4,837 km paved,
1,495 km gravel and crushed stone
Pipelines: crude oil, 209 km
Ports: 1 major (Al ‘Aqabah)
Civil air: 28 major transport aircraft
Airfields: 21 total, 19 usable; 14 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 13 with runways
2,440-3,659 m, 1 with runways 1,220-2,439
m
Telecommunications: adequate system of
radio-relay, cable, and radio; 81,500 tele-
phones (3 per 100 popl.); 3 AM, 2 FM, 24 TV
stations; 1 Atlantic Ocean satellite station, 1
Indian Ocean satellite station; 1 Arab satel-
lite station; coaxial cable and radio-relay to
Iraq, Saudi Arabia, and Syria; radio-relay to
Lebanon inactive
Defense Forces
Branches: Jordan Arab Army, Royal Jorda-
nian Air Force, Royal Jordanian Coast
Guard
Military manpower: males 15-49, 621,000; ©
439,000 fit for military service; 39,000 reach.
military age (18) annually','02c8630e7ccb3fed08fec2e8745705a9fb332447bec6d5030716411ca5db89ca','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('674e2fdeb0af39b4d4db4d6f9a1c6c20384385d8910d5ddb1c0fe7f92774fec7',1986,'KE','Kenya','communications',272,'Victoria *
indian
Ocean
200 km
See regional map VII
Land
582,646 km?; slightly saiiee es Texas;
64% mainly grassland adequate for grazing;
21% forest and wood; 17% arable, 13% suit-
able for agriculture
Land boundaries: 3,368 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 586 km
Railroads: 2,040 km 1.000- meter gauge
Highways: 55,400 km total; 7,000 es paved,
4,150 km gravel, remainder improved earth
Inland waterways: part of Lake Victoria
system is within boundaries of Kenya; prin-
cipal inland port is at Kisumu
Pipelines; refined products, 483 km
Ports: 1 major (Mombasa) -
Civil air: 9 major transport aircraft -
Airfields: 217 total, 197 usable; 14 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 4 with runways
2,440-3,659 m, 47 with runways 1,220-
2,439 m
Telecommunications: in top group of Afri-
can systems; consists of radio-relay links,
open-wire lines, and radiocommunication
stations; 231,000 telephones (1.3 per 100
popl.); 11 AM, 4 FM, 4 TV stations; 1 Atlan-
tic and 1 Indian Ocean satellite station
Defense Forces
Branches: Kenya Army, Kenya Navy, Air
Force; paramilitary General Service Unit -
Military manpower: males 15-49, 4,185,000;
2,576,000 fit for military service; no con-
scription
133
Banaba al
Railroads: none’
Highways: 5,000 km total; 460 km paved,
1,725 km gravel and/or improved earth,
2,700 km unimproved
Inland waterways: Lake Kivu navigable by
shallow draft barges and native craft
Civil air: 1 major transport aircraft
208
Airfields: 8 total; 8 usable; 2 with
permanent- -surface runways; l with run-
ways 2,440-3, 659 m, 2 with runways
1,220-2,489m
seianeniiene fair system with low-
capacity radio-relay system centered on
Kigali; 4,600 telephones (0.1 per 100 popl.); 2
AM, 5 FM, no TV stations; SYMPHONIE
satellite station, 1 Indian Ocean satellite sta-
tion ~ ;
Defense Forces
Branches: Army, paramilitary, Gendar- .
merie
Military manpower: males 15-49, 1, 386,000;
702, 000 fit for military service; no conscrip-
tion
_ Military budget: for fiscal yeat ending 31
- December 1983, $34.4 million;14% of cen- -
tral government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
St. Christopher and Nevis
“10 km
Saint 5
Christopher. ..
Caribbean Sea
See regional map II
Land —_
261 km?; about one-third the size of New
York City;.40% arable, 33% waste and built
on,-17% forest, 10%:pasture
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 135 km
Railroads: 58 km 0.760-meter narrow gauge
on St. Christopher for sugarcane
Highways: 300 km total; 125 km paved, 125
km otherwise improved, 50:km unimproved
earth
Ports: 1 major—Basseterre, St. Christopher,
and 1 minor—Charlestown, Nevis
Civil air: no major transport aircraft
Airfields: 2 total,.2 usable; 2with
‘permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: good interisland
VHF/UHF/SHF radio connections and .
international link via Antigua and Barbuda
arid St. Martin; about 2,400 telephones (5.0.
per 100 popl.); 2 AM, 4 TV''stations
Defense Forces:
Branches: Royal St. Christopher and Nevis
Police Force
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
St. Helena
"_Skm ay Be eee ae. Tet
South
Atlantic
Ocean
da Cunha rslands are
. Notshowna” + 5
See regional map VIS
ton, D. C.; 88 km? Ascension Island; 104 km?
Ascension and Trsian y+.
.Tristan da Cunha; 243 hectares cultivable” °
land; islands are of volcanic origin andi in- 7”
clude St. Helena, Ascension Island (no wa-"
ter), and the Tristan da Cunha island group |
Water
Limits of territorial waters (claimed): 3.nm._
(200 nm fishing zone)
Coastline: about 60 km
Railroads: none
Highways: 760 km total; 500 km paved; 260
km otherwise improved
Ports: 1 maior (Castries), 1 minor
Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 2 with’
permanent- surface runways, 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439
Telecommunications: fully automatic tele-
phone system with 9,500 telephones (8.0 per
100 pop!.); direct radio-relay link with Mar-
tinique and St. Vincent. and the Grenadines;
interisland troposcatter link to Barbados; 3
AM stations, 1 cable TV station ''
Defense Forces
Branches: Royal St. Lucia Police Force
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
St. Vincent and
the Grenadines
Bequia ,
Caribbean ot
Sea 5 @mustique
*
&
oo wv Canouan
‘Union Island
See regional map III
Land
389 km? (including northern Grenadines);
about twice the size of Washington, D. C.;
50% arable, 44% forest, 3% pasture, 3%
waste and built on
Water
Limits of territorial waters (claimed): 3 nm
(fishing 12 nm)
Coastline: 84 km
Railroads: none
Highways: approx. 1,000 km total; 300 km
paved; 400 km improved; 300 km unim--
’ proved
Ports: 1 major (Kingstown), 1 minor
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 3 with
-permanent-surface runways, 1 with run-
ways 1,220-2,439 m |
Telecommunications: islandwide fully au-
tomatic telephone system with 6,500 sets (4.6
per 100 popl.); VHF/UHF interisland links
to Barbados and the Grenadines; new SHF
links to Grenada and St. Lucia; 2 AM sta-
tions
Defense Forces
Branches: Royal St. Vincent and the Gre-
nadines Police Force
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ee NN DESL NE ELLSN ESL A LLL SL LALLLSA LDL ALLELES ELAR A tile: Ni Nt iA AA iii! ite site
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4','df92dc5cd39a84cae9983f43409c8aa0bdfe67f915661914f2ac03349ba77434','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91059f8537fc798b4e241d697fa88a2ae0ade285ae9847145cf17a44c6f8ada6',1986,'KI','Kiribati','communications',276,'(formerly Gilbert Islands)
1200 km
North Pacific Ocean
-<..
. ‘ 26
¢>-* TARAWA Kiritimati” -
(Christmas) S
: a”
eee P “OS, o-
Kiribati coe . +
(Gilbert Rawaki . o
islands) {Phoenix 2 a
Islands)
South Pacific Ocean
See regional map X
Land :
719 km?; slightly tialleg than New York
City
Water :
Limits of territorial waters: 12 nm 200 nm
fishing zone)
Coastline: about 1,143 km
Railroads: none
Highways: 483 km of motorable roads
Inland waterways: small network of canals,
totaling 5 km, in Line Islands
Ports: 8 minor
Civil air: 2 Trislanders no major transport ;
aircraft
Airfields: 19 total; 16 usable; 4 with
permanent-surface runways, 4 with run-
ways 1,220-2, 439 m
halen ioe 1 AM broadcast sta-
tion; 1,400 telephones (2.33 per 100 popl.)
134 .-
Korea, North
“150 km
Boundary representation 1s
not nucessarily authoritative.
Najin
See regional map VIII
Land ahaa.
121,129 km? slightly smaller than Missis-.
sippi; 74% forest, scrub, and brush; 17% ara-
ble and cultivated; remainder waste and
urban
Land boundaries: 1,675 km
Water
Limits of territorial. waters (claimed): 12
nm (200 nm exclusive economic zone; 50 nm
“military boundary line” from which all
foreign vessels and aircraft without permis-
sion are banned)
Coastline: 2,495 km —
Railroads: 4,535 km total operating in 1980:
3,870 km 1.435-meter standard gauge, 665°
km 0.762-meter narrow gauge, 159 km dou-
ble track: about 3,175:km electrified; gov-
ernment owned
Highways: about 20,280 km (1980); 98.5%
gravel, crushed stone, or earth surface; 1.5%
concrete or ikiminens
Inland waterways: 2,253 km; mostly naviga-
ble by small craft only
Pipelines: crude oil, 37 km
Ports: 6 major, 26 minor
Defense Forces OM
Branches: North Korean People’ s ani
iconsists of the army, navy, and air Hater)
Military manpoiver: males 15-49, 4, 748, 000;
2,909,000 fit for military service; 260,000
reach.military age (18) annually
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Korea, South
Boundary representation is
150 km Knot necessarily authoritative
Ulling-do
3
‘ ae Strait
See regional map VIII
Land
98,500 km*; slightly larger than Tadiang:
66% forest, 23% arable (22% one 10%
urban and other
Land boundaries: 241 km
Water
Limits of territorial waters: 12 nm—3-nm .
in Korea Strait (200 nm exclusive economic
zone)
Coastline: 2,413 km
Railroads: 3,106.5 km operating in 1983;
3,059.4 km 1.435-meter standard gauge,
46.9 km.0.610-meter narrow gauge, 712.5
km double-track, 417.9 km electrified; gov-
ernment owned
Highways: 53,936 km total (1982); 13,476
km national highway, 49,460 km provincial
and local roads
Inland waterways: 1,609 km; use restricted
to small native craft
Freight carried: rail (1983) 51 million metric
tons; highway 126 million metric tons; air
(1983) 47,000 metric tons (domestic)
Pipelines: 294 km refined products
t
Ports: 11 major, 32 minor
Civil air: 93 major transport aircraft
Airfields: 121 total, 109 usable; 67 with
permanent-surface runways; 23 with run-
ways 2,440-3,659 m, 12 with runways
1,220-2,489 m
Telecommunications: adequate domestic
and international services; 4.8 million tele-
phones (121 per 100 popl.); 79 AM, 46 FM,
256 TV stations (57 of 1 kW or greater); 1
ground satellite station ;
Defense Forces
Branches: Army, Navy, Air Force, Naval
Marine Force ?
Military manpower: males 15-49,
12,055,000; 8,129,000 fit for military service;
464,000 reach military age (18) annually
Military budget: proposed for fiscal year
ending 31 December 1986, $4.7 billion;
about 31.2% of central government budget
137','d1d04334a8d3103fb0142d286d1378505f79f7668d821d4fe7e3cf19fccc1b02','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72df280c9af38c51aa3faf164196944a3f552fbadc2b5e94d9d9f2efc2f7b0df',1986,'KW','Kuwait','communications',280,'abubiyan
Persian
Guif
50 km
See regional map VI
Land
17,818 km? (excluding neutral zone but in-
cluding islands); slightly smaller than New
Jersey; nearly all desert, waste, or urban;
insignificant forest; 1% cultivated
Land boundaries: 459 km
Water
Limits of territorial waters (claimed): 12
nm
Coastline: 499 km
Railroads: none
138
Highways: 2;600 km total; 2,300 km bitumi-
nous; 300 km earth, sand, light gravel
Pipelines: crude oil, 877 km; refined prod-
ucts, 40 km; natural gas, 121 km
Ports: 8 major (Ash Shuwaykh, Ash -
Shu‘aybah, Mina’ al Abmady 6 minor
Civil air: 26 major. transport siveiatt
Airfields: 9 total, 4 usable; 4 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m
Telecommunications: excellent interna-
tional and adequate domestic telecommuni-
cation facilities; 258,000 telephones (16 per
100 popl.); 2 AM, 2 FM, 3 TV stations; 1 In-. .
dian Ocean and 2 Atlantic Ocean satellite
stations, 1 INMARSAT satellite station; 1
Arab satellite station; coaxial cable and
radio-relay to Iraq and Saudi Arabia
Defense Forces
Branches: Army, Navy, Air Force, >, National
Police Force, National Guard
Military manpower: males 15-49, about
438,000; about 266,000 fit for muliy ser-
vice .
Military budget: operating expenditures for
fiscal year ending 30 June 1985, $865 mil-
lion; 7.3% of central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Laos
#200 km
See regional map 1X ;
reer
Land
236,804 km/?; slightly larger than Utah; ¢ 60%.
forest; 8% agricultural; 32% urban, waste, or:
other; except in limited areas, soil is poor;
most of forested area is not exploitable - —
Land boundaries: 5,053 km . -
Highways: about 21,300 km total; 1,300 km
bituminous or bituminous treated; 5,900 km
gravel, crushed stone, or improved earth;
14,100 km unimproved earth and often im-
passable during rainy season mid-May to
mid-September
Inland waterways: about 4,587 km, pri-
marily Mekong and tributaries; 2;897 addi-
tional kilometers are sectionally navigable
by craft drawing less than 0.5 m
Pipelines: 136 km, refined products
Ports (river): 5 major, 4 minor
Airfields: 66 total,-50 usable; 9 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 11 with runways
1,220-2,439 m
Telecommunications: service to general
public considered poor; radio network pro- -
vides generally erratic service to govern-
ment users; approx. 10 AM stations; 1 TV
station; over 5,000 telephones; 1 ground sat-
ellite station :
Defense Forces
Branches: Lao People’s Army (LPA, which
consists of an army with naval, aviation, and
militia elements), Air Force, National Police
Department ;
Military manpower: males 15-49, 878,000;
469,000 fit for military service; 43,000 reach
military age (18) annually; no conscription
age specified ,','d5994a9f8d2c85a2305819b864f1ed8b3d49c3d0736ea9788292891222b8a635','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b1f35f50cbbdd255d1aafb305c2c6ab8a7322ef9f1f4c73f84da1b8cb732c26',1986,'LB','Lebanon','communications',284,'50 km
Mediterranean
Sea
Boundary representation is
not necessarily authoritative
See regional map VI
Land
10,360 km?; smaller than Connecticut; 64%
desert, waste, or urban; 27% agricultural; 9%
forest; 400,000 hectares under cultivation
Land boundaries: 531 km
Water
Limits of territorial waters (claimed): 12
nm :
Coastline: 225 km
People ae
Population: 2,675,000 (July 1986), average
annual growth rate 2.1%
Nationality: noun—Lebanese (sing., pl.);
adjective—Lebanese
Ethnic divisions: 938% Arab, 6% Armenian,
1% other
Religion: 57% Muslim (Sunni and Shi''a) and
Druze, 42% Christian (Maronite, Greek
Orthodox and Catholic, Roman Catholic,
Protestant), 1% other (official estimates), ©
Muslims, in fact, constitute a majority
Language: Arabic (official); French is widely
spoken; Armenian, English :
Infant mortality rate: 48/1 ,000 (1983)
Life expectancy: men 63, women 67
Literacy: 75%
140
Labor force: 650,000 (1985); 79% industry,
commerce, and services, 11% agriculture,
10% goverment; high unemployment
Organized labor: about 65,000
Government 4
NOTE: Between early 1975 and late 1976
Lebanon was torn by civil war between its
Christians—then aided by Syrian troops— .
and its Muslims and their Palestinian allies.
The cease-fire established in October 1976
between the domestic political groups gener-
ally held for about six years, despite occa-
sional fighting. Syrian troops constituted as
the Arab Deterrent Force by the Arab
League have remained in Lebanon. Syria’s
move toward supporting the Lebanese Mus-
lims and the Palestinians and Israel’s grow-
ing support for Lebanese Christians brought
the two sides into rough equilibrium, but no
progress was made toward national reconcil-
iation or political reforms—the original
cause of the war.
Continuing Israeli concern about the Pales-
tinian presence in Lebanon led to the Israeli
invasion of Lebanon in June 1982. Israeli -
forces occupied all of the southern portion of
the country and mounted a summer-long
seige of Beirut, which resulted in the evacua-
tion of the PLO from Beirut in September
under the supervision of a multinational
force made up of US, French, and Italian
troops.
Within days of the departure of the multina-
tional force (MNF), Lebanon’s newly elected
president, Bashir Gemayel, was assassinated.
In the wake of his death, Christian militia- -
men massacred hundreds of Palestinian ref-
ugees in two Beirut camps. This prompted °
the return of the MNF to ease the security
burden on Lebanon’s weak army and secu-
rity forces. In late March 1984 the last MNF
units withdrew.
Lebanon continues to be partially occupied
by Syrian troops. Israel withdrew the bulk of
its forces from the south in 1985, retaining a _
10-km deep security zone just north of the
1949 Armistice Line. Israel continues to arm
and train the Army of South Lebanon (ASL),
which opposes the return of Palestinian
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ghters to South Lebanon. The ASL has in-
creasingly been involved in confronting
Shi''a as well as leftist militias sponsored by
Syria.
Syria maintains troops in the Riyaq area of
the Bekaa, while Special Forces units are
stationed in the Matn, and in the Tripoli ar-
eas, north and northeast. In late 1985 the
Syrian regime successfully negotiated a tri-
partite agreement among the three major
rival Christian, Druze, and Shi‘a militias, but
implementation remains a distant possibil-
ity. The Christian and Muslim communities
are deeply split from within over specific
points in the agteement:
Israel and Lebanon signed a withdrawal
agreement on 17 May 1983. The agreement
was never implemented and was
subsequently voided. A partial Israeli with-
drawal and government attempts to extend
authority have led to renewed factional
fighting. The following description is based
on the present constitutional and customary
practices of the Lebanese system.
Official name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 4 provinces’
Legal system: mixture of Ottoman law,
canon law, and civil law system; constitution
mandated in 1926; no judicial review of leg-
islative acts; legal-education at Lebanese
University; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 22
November
Branches: power lies with the President,
. who is elected by unicameral legislature
(National Assembly); Cabinet appointed by
President, approved by legislature; indepen-
dent secular courts on French pattern; reli-
gious courts for matters of marriage,
divorce, inheritance, etc.; by custom, the
President is a Maronite Christian, the Prime
Minister is a Sunni Muslim, and the presi-
dent of legislature is a Shi‘a Muslim; each of
nine religious communities are represented
in the legislature in proportion -to their na-
tional numerical strength
Government leader: Amine Pierre
GEMAYEL, President (since September
1982), Rashid KARAMI, Prime Minister
(since May 1984)
Suffrage: compulsory for all males over 21:
authorized for women over 2] with elemen-
tary education
Elections: National Assembly held every
four years or within three months of dissolu-
tion of Chamber; security conditions have
prevented parliamentary elections since
April 1972
Political parties and leaders: political party
activity is organized along largely sectarian
lines; numerous political groupings exist,
consisting of individual political figures and
followers motivated by religious, clan, and
economic considerations; most parties have
well-armed militias, which are stil] involved
in occasional clashes
Communists: the Lebanese Communist -
Party was legalized in 1970; members and
sympathizers estimated at 2,000-3,000
Member of: Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IPU, ITU,
[WC—International Wheat Council, NAM,
OIC, UN, UNESCO, UPU, WFTU, WHO,
WMO, WSG, WTO
Railroads: 390 km total; 305 km 1.435-meter
standard gauge, 85 km 1.050-meter gauge;
all single track; system almost inoperable
Highways: 7,370 km total; 6,270 km paved,
450 km gravel and crushed stone, 650 km
improved earth
Pipelines: crude oil, 72 km
Ports: 3 major (Beirut, Tripoli, Sidon), 5 mi-
nor
Civil air: 28 major transport aircraft
Airfields: 10 total, 9 usable; 6 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m; 3 with runways
1,220-2,439 m; major military airfields are
Riyaa, Kleiat, and al-Fidar Air Strip
Telecommunications: rebuilding program
disrupted; had fair system of radio relay,
cable; approx 150,400 telephones (5.0 per
100 popl.); 3 FM, 5 AM, 15 TV stations; 1
Indian Ocean and 1 Atlantic Ocean statellite
station, both inactive; 3 submarine coaxial
cable (inactive); radio-relay to Jordan and
Syria inoperable
Defense Forces
Branches: Army, Navy, Air Force
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','670fd0c03545ac9704cf6b29be08577e37f92972eeb96e81c6edf60351768aad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d76da1e178da83cbfc5d4a6f9318ad706b64fbc25fe70f6e56d99455ab9a491b',1986,'LS','Lesotho','communications',286,'See regional map VII
Land
30,460 km?: slightly larger than sawhad:
15% cultivable, 13% arable, largely moun- .
tainous ‘
Land boundaries: 805 km
People ‘ ae
Population: 1,552,000 (July’ 1986); average
annual growth rate 2.6%
Nationality: noun—Mosotho (sing.), Basotho
(pl.); adjective—Basotho
Ethnic divisions: 99.7% Sotho; 1,600 Euro-
peans, 800 Asians
Religion: 80% Christian, rest indigenous
beliefs
Language: Sesotho (southern Sotho) and.En-
glish (official); also Zulu and Xhosa -
Infant mortality rate: 104.3/1,000 (1983)
Life expectancy: 51.5
Literacy: 60%
Labor force: 426,000 economically active
(1976); 87.4% of resident population
engaged in subsistenice agriculture;
150,000-250,000 spend from six months to
many years as wage earners in South Africa
Organized labor: negligible
Railroads: 1.6 km; owned, operated,.and
included in the statistics of the Republic of
South Africa. | «.
Highways: approx. 4,221 km total; 508 km
paved; 1,585 km crushed stone, gravel, or. .
stabilized soil; 946 km improved, 2,128 km -
unimproved earth
Civil air: 1 major transport aircraft’
Airfields: 28 total, 28 usable; 1 with perma-
nent surface runways; 1 with runways
2,440-3,659 m, 3 with runways 1,220-
2,439 m Bi 1a mee .
Telecommunications: system a modest one
consisting of a few land lines, a small radio-
relay system, and minor radiocommunica-
tion-stations; 5,920 telephones (0.3 per 100°
popl.); 2 AM, 2 FM stations; 1 TV station
planned; 1 Atlantic Ocean satellite station
Defense Forces
Branches: Army, Army Air Wing, Police
Department .-
Military manpower: males 15-49, 353,000;
189,000 fit for military service
ba 9" ort Elizabeth
20
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
eens Union, East and South Asia
on
46 60 80 * 120 340 16
~~
2. a
The United States Government has not recognized . tiet if ''o c\\ean oe
the incorporation of Estonia, Latvia, and Lithuania
into the Soviet Union. Other boundary ad \\ oi Josét {stand
Od
is not necessarily authoritative.
F East Siberian
H
Barents /Sea
oA New Siberian
stands
Novaya G f Zi
Zemlya
Evensk?
eke 9
«Minsk : ‘ Nort’ ’ ” Petropaviovsk- «
~ —Vorkuta Ski
“Lvov Se rv} ; a Kamchatskly,
Moscow Be aan S
Kiev, WA Urengoy* y
Kirov, ‘
or''kiy ~~ , S
Sea of Okhotsk *
Kuril Islands’
i yy
Kishinév Fi (admin. by SOVIET UNION)
~*Odessa .harkov
Kama ° . ¢ Sakhalin ’
Donetsk :
* 2. Volga, occupied hy sopiet
vo
4 a UNION since 1945,
‘sick Kuybyshev " \\ claimed ape
BC:
Sea ‘Volgograd
ie Orenburg*
‘Novosibirs!
Tbilisi é eis
Yerevan
nae Caspian Karaganda,
‘ snr bas
Baku Sea
Khabarovsk,
Krasnoyarsk
Lake oak : *.
Baikhash 1 * Changchun*
\\ Worth
Shenyang, aie pDamarcatlon
vi Line
aovang
ie eset (7
* i J y-
«Dushanbe . See P Lo fe y- Tianjl ; YY eo
im. : "S3 te wfey cooper Ree EE Pon ; a
{ Fy Ly
Samatkand®
“ AFGHANISTAN nee i
fa * i " i : yang.
< Kabul N gag claim Gotmud, by “Zhengzhou
SGandehar*
Ok Se?
Islafabad nrarsek
ahore.~
2 :
PAKISTAN 7 nest 63
j Chengdu, bf \\ ae
7 a N f Chongqing? , fs ‘ Saad
; ew Delhi, oe tase aang: T pei ~
. NE ; q i
BHUTAN Taiwan
Guiyang
Konming) TN Seton
ao oManning wi Macau
(PORTUGAL)
BANGLA
rape ‘
Arabian
Sea \\ “Vishakhapatnam \\
“ ?: . ; South','40d80ad6cbbda87c80513c551b8c37849cadc59688a1a2e68a5b978ad3949df8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e75f7ef552740e09735014834c1f7ed0ad81624aece8b0f88ce056930faf77',1986,'LR','Liberia','communications',289,'North Atlantic Ocean
See regional map VII Harper
a
Land :
111,370 km?; slightly smaller than Pennsyl-
vania; 40% forest, 30% jungle and swamp, .
20% agricultural, 10% other ~
Land boundaries: 1,336 km -
Water =
Limits of territorial waters (claimed):
200 nm
Coastline: 579 km
Railroads: 487 km total; 342 km 1.435-meter
standard gauge, 145 km 1.067-meter narrow
gauge; all lines single track; rail systems
owned and operated by foreign steel and
financial interests in conjunction with Liber-
ian Government
Highways: 10,087 km total; 603 km bitumi-
nous treated, 2,848 km all-weather, 4,313
km dry-weather
Inland waterways: no significant waterways
Ports: 1 major (Monrovia), 4 minor
Civil air: 2 major transport aircraft
Airfields: 80 total, 75 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: telephone and tele-
graph service via radio-relay network; main
center is Monrovia; 7,700 telephones (0.5 per
100 popl.); 3 AM, 4 FM, 5 TV stations; 1 At-
lantic Ocean satellite station
Defense Forces
Branches: Armed Forces of Liberia, Liberia ~
National Coast Guard
Military manpower: males 15-49, 498,000;
269,000 fit for military service; no conscrip-
tion
144','685ef1c30ff47a8542f1a7aa77c26d5a4549fd6a7ec525309f7e1510af700004','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('552ae0eb49244c0d286b27ce63941bcb21e53aa891657b54d1f78ac6c91ec8a0',1986,'LI','Liechtenstein','communications',293,'See regional map ¥
Land
160 km?; the size of Withington: D.C.
Land boundaries: 76 km
Railroads: 18.5 km 1.485-meter. daar
gauge; electrified; owned, operated,-and -
included in statistics of Austrian Federal
Railways —
Highways: 130.66 ee main foade 192.27
km byronds :
Civil air: no transport aircraft
Airfields: none
Telecommunications: automatic telephone -.
system serving about 20,020 telephones (77.0
per 100 popl.); no broadcast facilities -
Defense Forces. ys
Defense is Tesponnbility of Switvarlind
Branches: Police Department','9c8986b82ba19b8174ac34a7cff3e4908512defbe2cdc16b61109accf89465a0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42b22b566508deaf1933a58d9b56f2a50847a59d7a2e78f7e0d3d218e84ebf1e',1986,'LU','Luxembourg','communications',296,'—20km
See regional map V —
Land
2,586 km?; smaller iad Rhode Island: 43. 9% . :
arable, 33% forest, 27% meadow and pas-.
ture, 15% waste or urban, negligible inland.
water
Land boundaries: 356 km.
Railroads: Luxembourg National Railways
(CFL) operates 270 km 1.435-meter stan-
dard gauge; 162 km double track; 163 km
electrified
Highways: 5,108 km total; 4,995 km paved,
57 km gravel, 56 km earth; about 80 km
limited access divided highway
Inland waterways: 37 km; Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 13 major transport aircraft
Airfields: 2 total, 2 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: adequate and effi-
cient systern, mainly buried cables; 210,000
telephones (55 per 100 popl:); 2 AM; 3 FM, 3
TV stations
Defense Forces
Branches: Army
Military manpower: males 15-49, 96,000;
80,000 fit for military service; about 2,000
reach military age (19) annually
148
Macau
2km
Zhujiang
Kou
causeway
liha de Taipa
Ilha de Coloa
See regional map VIIE. >
Land
15.5 km?; smaller than Washington, D. C.,
90% urban, 10% agricultural
Land boundaries: 201 m
Water
Limits of territorial waters (claimed): 6 nm
(12 nim fishing zone) :
Coastline: 40 km
Highways: 42 km paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern com-
munication facilities maintained for domes-
tic and international services; 13,000 tele- —
phones; 4 AM and 3 FM radio broadcast
transmitters; est. 75,000 radio receivers; in
international high frequency radio commu-
nication facility; access to international com-
munications carriers provided via Hong
Kong and China
Defense Forces
Defense is responsibility of Portugal
Military manpower: males 15-49, 109,000;
63,000 fit for military service
149','2e7eb41592d5efaf59864cde00f3418d7e30898ba937b9c22fbd07a9e47cffce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79d9232947c9435e9be6d3d7d3a47d81a6afc6208d3be87ad43fdd73f5e75c4b',1986,'MG','Madagascar','communications',300,'300 km
Port Rodrigues
hauls MADRS plac pies
Bulawayo
Pretoria Maputo
Johannesburg hbabane
7
SWAZILAND
SOUTH
‘ArRiCn Co” ae','31450a9f79778cf4372daa808e3e5a0557cbf5e89f111148872a8a4822214b67','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8df31c71ae109914df7cf1ea60a005de6e8bd84378ab406bcfc3a7d94898fdf2',1986,'MZ','Mozambique','communications',301,'Channel
Indian
ANT Ocean
Morondav:
Manakara’ -~
Faradofay
See regional map VII
Land
592,900 km?: slightly smaller than Texas;
58% pasture, 21% forest, 8% waste, 5% culti-
vated, 2% rivers and lakes, 6% other
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 4,828 km
Railroads: 1 ,020 kin 1. GOmaneters gauge
Highways: 40,000 km total; 4,694 km paved,
811 km crushed stone, gravel, or stabilized
soil; remainder improved and‘unimproved
earth (est.)
Inland waterways: of local importance only;
isolated streams and small portions of Canal.
des Pangalanes .
Ports: 4 major (Toamasina, Antsiranana,
Mahajanga, Toliary)
Civil air: 6 major transport aircraft .
Airfields: 152 total, 125 usable; 28 with
permanent-surface runways; 8 with run-:-
ways 2,440-3,659 m, 42 with runways
1,220-2, ee n
Telecommunications: fair system includes
open-wire lines, coaxial cables, and radio-
relay links; 1 Indian Ocean satellite station;
38,200 telephones (0.4 per 100 popl.); 14
AM, no FM, 24 TV stations
Defense Forces .. . :
Branches: Popular Army, pee Fc orces
(includes Navy and Air Force), paramilitary.
Gendarmerie
Military manpower: males 15-49, 2,260,000;
1,383,000 fit for military service; 93,000
reach military age (20) ponually:
Military budget: isk fiscal year ee 3l
December 1985; $60,000; about :01% of cen-
tral government budget
400 km
Channel
ilanculos
Inhambane
See regional map VIE
Land
783,030:km?2; larger than Texas; 56% wood
and forest; 30% arable; .of which 1% culti-
vated; 14% waste and inland water
Land boundaries: 4,627 km
Water :
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 2,470 km
Railroads: 3,436 km total; 3,288 km 1.067-
meter gauge; 148 km 0.750-meter narrow
gauge ;
Highways: 26,498 km total; 4,593 km paved;
829 km gravel, crushed stone, stabilized soil;
21,076 km unimproved earth
Inland waterways: approx. 3,750 km of nav-
igable routes ; f
Pipelines: crude oil, 306 km (not operating);
refined products, 280 km
Ports: 8 major (Maputo, Beira, Nacala), 2
significant minor
Declassified and Approved For Release 2012/08/29
Civil air: 7 major transport aircraft
Airfields: 239 total, 210 usable; 28 with
permanent-surface runways; 6 with run-
ways 2,440-3,659 m; 31 with runways
1,220-2,439 m
Telecommunications: fair system of
troposcatter, open-wire lines, and radio re-
lay; 57,400 telephones (0.5 per 100 popl.); 9
AM, 3 FM stations; 1 TV station; 1 Atlantic
Ocean satellite station
Defense Forces
Branches: Mozambique Armed Forces (in-
cluding Army, Border Guard, Naval Com-
mand, Air Force)
Military manpower: males 15-49, 3,084,000;
1,823,000 fit for military service
Military budget: for fiscal year ending 31
December 1985, $240 million; 38% of cen-
tral government budget
172
Namibia‘
Naurus','b3ddbeb8caadb05cd45cf177650567326b20b6071d796361ba7b5770cdc39c7c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dba34bfb9b5666f40c35664df670da5d3085180422b990c11883dba8cf1b519',1986,'MW','Malawi','communications',305,'Chisa milla Island
Likoma fsland |
See regional map VII
Land .
118,484 km?; the size of Pansy anid: 34% :
of land area arable (of which 86% is culti-
vated), nearly 25% forest, 6% meadow and «
pasture, 35% other -
eda ihe 2,881km *
Railroads: 789 km-1.067-meter gauge
Highways: 13,135 km total; 2,364 km paved;
_ 251 km crushed stone, gravel, or stabilized
soil; 10,520:km.earth and improved earth
Inland waterways: Lake Nyasa, 23,300 km?,
Shire River, 144 km, 4 lake ports
Civil air: 4 major transport aircraft;
Airfields: 50 total, 49 usable; 6 with
permanent-surface runways; | with run-
ways 2,440-3,659 m; 9 with runways: °
1,220-2,489 m
Telecommunications: fair system-of open-
wire lines, radio-relay links, and radio com-_.
munication stations; 36,800 telephones (0.5
per 100 popl.);.7 AM, 13 FM, no TV stations;
1 Indian Ocean and 1 atlaoile Ocean satel-:
lite station
Defense Forces
Branches: Army, Army Air Wing, Army
Naval Detachment, paramilitary Police Mo-
bile Unit
Military manpower: males 15-49, 1,548,000; .
about 883,000 fit for military service -- -
152','dccd24a9776b72be147ccd1d570f81780051a7bcedb23ff1086d5febefd93d3c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6131c02fa2badc6b10961792c3998bdba4f5906e50f1c844abbf729cd5fce22',1986,'MY','Malaysia','communications',308,'500km_
: : .
See regional map 1X
Land |
NOTE: established on 16 September 1963,
Malaysia consists of Peninsular Malaysia,:
which includes 11 states of the former Fed- .-
eration of Malaya, plus East Malaysia, which
includes the two former colonies of North -
Borneo (renamed Sabah) and Sarawak
Peninsular Malaysia: 131,313 km?; larger
than New Mexico; 26% forest reserve, ae ia
cultivated, 54% other;
Sabah: 76,146 km?2; smaller than Nebraska;
34% forest reserve, 13% cultivated, 53%
other
Sarawak: 125,097 km?; larger than New
Mexico; 24% forest reserves, 21% cultivated, .
55% sorher:
iid beaten 509 kin par iessine Ma-
Jaysia, 1,786 km East Malaysia
Water | ;
Limits of territorial waters (claimed): 12°
nm (200 nm exclave economic zone)
Coastline: 2 068 km Besincalss Malaysia,
2, 607 km East Malaysia ,
People -* 7 a :
Population: 15, 820, 000 (July 1986), 2 average
annual growth rate 2.3% .
Peninsular Malaysia: 13,002,000 (July
1986), average annual growth rate 2.1%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Sabah: 1,293,000 (July 1986), average anol
growth rate 3.9% :
Sarawak: 1,525,000 (July 1986), average an-
nual growth rate 2.5%
Nationality: noun—Malaysian(s); adjec-
tive—Malaysian
Ethnic divisions: 50% Malay, 36% Chinese,
10% Indian, 4% other
Religion: Peninsular Malaysia: Malays
nearly all Muslim, Chinese predominantly
Buddhists, Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% .
other
Sarawak: 35% tribal religion, 24% Buddhist:
and Confucianist, 20%. Muslim: 16% Chris- °
tian, 2% other
nena Peninsular Malaysia: Malay °
(official); English, Chinese dialects, Tamil
Sabah; English, Malay, numerous tribal dia--.
lects, Mandarin and Hakka dialects predom-
inate among Chinese
Sarawak: English; Malay,. Mandarin, numer--
ous tribal languages
Infant mortality) rate: 25 / ] Pontes?)
Life expectancy: 67. 7
Literacy: 72% overall Penmaulat Malaysia:
75% :
Sabah: 58%
Sarawak: eee
Labor force: ee 5, 95 eile (1985);
33% agriculture; 22% manufacturing, 15% ©
Railroads: Peninsular Malaysia: 1,665 km
1.04-meter gauge; 13 km double track; gov-
ernment owned
‘East Malaysia: 136 km 1.000-meter gauge in
Sabah
Highways: Peninsular Malaysia: 19,753 km
total; 15,900 km hard surfaced (mostly bitu-
minous surface treatment), 3,000 km
crushed stone/gravel, 883 km improved or
unimproved earth ,
154
East Malaysia: about 5,426 km total (1,644.
km in Sarawak, 3,782 km in Sabah); 819 km -
hard surfaced (mostly bituminous surface .
treatment), 2;:936km gravel or-crushed.
stone, 1,671 km earth
I nland waterways: : Peninsular M. alaysia:
3,209 km
East Malaysia: 4,200 km (1,569 km in Sa-: --.
bah, 2,518 km in Sarawak). «
Ports: Peninsular M alaysia: 3 maior, 14 mi-
nor
East M alaysia: 3 major, 12 minor (2 major, 3
minor in Sabah; 1 major, 9 minor in Sar- .
awak}
Civil air: approximately 28 major transport
aircraft
Pipelines: crude oil, 707 km; natural gas,
379 km
Airfields: 136 total, 134 usable; 30 with
permanent-surface runways; 7 with run-
ways 2,440-3,659 m, 19 with runways
1,220-2,439 m
Telecommunications: Peninsular Malaysia:
good intercity service provided mainly by
microwave relay; international service good;
good coverage by radio and television broad-
casts; 609,288 telephones (5.13 per 100
popl.); 26 AM, 1 FM, 20 TV stations,
IOCON submarine cables extend to India;
connected to SEACOM submarine cable
terminal at Singapore by microwave relay; 2
international ground satellite stations; 1 do-
mestic ground satellite station
Sabah: adequate intercity radio-relay net-
work extends to Sarawak via Brunei; 43,000
telephones (3.94 per 100 popl.); 14 AM, 1
FM, 7 TV stations, SEACOM submarine
cable links to Hong Kong and Singapore; 1
ground satellite station
Sarawak: adequate intercity radio-relay
network extends to Sabah via Brunei; 64,512
telephones (4.65 per 100 popl.); 5 AM sta-
tions, no FM, 6 TV stations
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Defense Forces © oe ;
Branches: Royal Malaysian ee Royal
Malaysian Navy, Royal Malaysian Air
Force, Royal Malaysian Police Force
Military manpower: males 15-49, 4,037 1000;
2,560,000 fit for military service: 176, 000 .
reach military age (21) annually
External defense dependent on loose Five ©
Power Defense Agreement (FPDA), which
replaced Anglo-Malayan Defense Agree-
ment of 1957 as amended in 1963
Military budget: for fiscal year ending 31
December 1986, $1.8 billion; about’ 14% a
central government budget .-* | .','1cf39bb4d9c9af3d116e14aa6f1116995ab788eb8ffa01df5513d0c90ad3da01','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbd748cfdd099025292eacc78acdd4c018bdad0edce758d467e256a786329a62',1986,'MV','Maldives','communications',311,'200 km _ +
Male Atoll
. Arabian * MALE
Sea
Laccadive
’ Sea
“Gan
See regional map VIII
Land
298 km?; twice the size of si achitGe D. G,;
2,000 islands grouped into 19 atolls; about
220 islands inbabied
Water ;
Limits of territorial waters (claimed): the
land and sea between latitudes 7°9’N and .
0°45’S and between longitudes 72°30''E and
73°48’E; these coordinates form a rectangle
of approximately 37,000 nm; territorial sea
ranges from 2.75 to 55 nm; fishing, approxi-
mately 100 nm; 37 to 310 nm exclusive eco-
nomic zone
Coastline: 644 km (approx.)
Railroads: none
Highways: none
Ports: 2 minor (Male, Gan) .
Civil air: | major transport aircraft
Airfields: 2 total, 2 usable; 2 with
_ permanent-surface runways; 2 with run-
ways 2,440-3,659 m
Telecommunications: minimal domestic
and international telecommunication facili-
ties; 1,060 telephones (0.7 per 100 popl.); 1
TV, 1 FM, 2 AM stations; 1 Indian Ocean
INTELSAT station
Military budget: for fiscal: year ending 31
December 1984, about $1.8 million','3fe29653970d5b094eed643a830df246691fdd3f766f5707259ffad13a20197c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e537e95387a957dae93f43f6bc0375e99c52dae919553c213a0a7655706d4fec',1986,'ML','Mali','communications',314,'400 km
Boundary representation is
not necessarily authoritative.
See regional map VII
Land
1,240,000 km?; larger than Texas and Calli-
fornia combined; 75% sparse pasture or
desert, about 25% arable, negligible forest
Land boundaries: 7,459 km
Railroads: 642 km 1.000-meter gauge
Highways: approximately 15,700 km total;
1,670 km bituminous, 3,670 km gravel and
improved earth, 10,360 km unimproved
earth
Inland waterways: 1,815 km navigable —
Civil air:5 major transport aircraft
Airfields: 38 total, 31 usable; 8 with
-permanent-surface runways; 6 with run-
ways 2,440-3,659 m, 9 with runways
1,220-2,489 m
Telecommunications: domestic system poor
and provides only minimal service; radio-
relay, wire, and radio communications sta-
tions in use; expansion of radio relay in
progress; 8,000 telephones (0.1 per 100
popl.); 2 AM, 2 FM, no TV stations; 1 Atlan-
tic and 1 Indian Ocean satellite ground s sta-
tion
Defense Forces
Branches: Army, Air Force; paramilitary,
Gendarmerie, Republican Guard, National
Guard
Military manpower: males 15-49, 1,727,000,
872,000 fit for military service; no conscrip-
tion
Military budget: for fiscal year ending 31 -.
December 1984, $24.8 million; about 22:2%
of central government budget
157
Malta —~
10 km
‘ Mediterranean
Kemmuna Sea
Mediterranean
Sea
* Filfla
See regional map V
Land
313 km?; twice the size of Washington,
D. C.; 45% agricultural; negligible forest;
remainder urban, waste, or other
Water :
Limits of ieieanal waters dawned 12
nm (fishing 25 nm)
Coastline: 140 km
Highways: 1,292 km total; 1,179 km paved
(asphalt), 77 km crushed stone or gravel, 35
km improved and unimproved earth
Ports: 2 major (Valletta, Marsaxlokk [under :
development] ), 1 secondary, 1 minor
Civil air: 8 major.transport aircraft
runways 2,440-38,659 m
Telecommunications: modern automatic
telecom system centered in Valletta; 113,000
telephones (34.6 per 100 popl.);6 AM, 5 FM, -
2 TV stations; 1 coaxial submarine cable
Defense Forces
Branches: Armed Forces, Police, Task
Force, Paramilitary Dejima Force
Military manpower: males 15-49, 89, 000;
73,000 fit for military service
Supply: various facilities and sSiipntent
turned over by the UK in 1965; has received
2 patrol boats, helicopters, small arms, and
mortars from Libya; vehicles and engineer
equipment from:Italy; patrol boats and heli-
copters from FRG :
Military budget: for fiscal year ending 31.. -
December 1984, $12.2 million; about 2.5%
of central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Man, Isle of
10 km.
_ trish Sea
Irish Sea
/
See regional map V
astletownt
Land
588 km?; smaller than New. York City: ex-
tensive fatal arable land and forests
Water”:
Limits of iain ‘waters (claimed): 3nm-.
(200 nm fishing)
Coastline 0S km i 3: :
People: .° ae
Population:.65 000 (July. 1986) average an-
nual growth rate 1.2%
Nationality: noun—Manxman, adjective—
Manx 4 :
Ethnic divisions: native Manx of Norse-
Celtic descent; British
Religion: Anglican, Roman Catholic, Meth-
odist, Baptist, Presbyterian, Society of
Friends
Language: English, Manx Gaelic
Literacy: compulsory education between
ages of 5 and 15
Labor force: 25,864; manufacturing 3,467,
construction 2,921, transport and communi-
cation 2,300, retail 2,687, professional and
scientific services 3,737 (1981); unemploy-
ment 8% (1984)
Organized labor: 22 labor unions patterned
along British lines (1971)','e70eb1ff01f118b884d2d3799885423c2605a40fdb48eafafea59efae38ca5b5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d17df439ef0919e96e81fa4c6b25e0111ba5afbf35f0ee0dab8d8d0ec64b6d4',1986,'MQ','Martinique','communications',321,'Railroads: none
Highways: 1,680 km total; 1,300 km paved,
380 km gravel and earth
Ports: | major (Fort-de-France), 5 minor
| Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Civil air: no major transport-aircraft
Airfields: 4 total; 3 usable; 1 with
permanent-surface runways; 1 with run- -
ways 2,440-3,659 m e
Telecommunications: domestic facilities are
adequate; 68,900 telephones (21.5 per 100
popl.); interisland radio-relay links to Guad-
eloupe, Dominica, and St. Lucia; 2 Atlantic
Ocean satellite antennas; 1 AM, 5 FM, 10
TV stations
Defense Forces te
Defense is responsibility of France .
Military manpower: males 15-49, 84,000','61ae083a9af1803748c7d57f37824811b2347438154c19b20dbec07a61b43071','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31320dfdc5baff982904dc36871e00ab43ab2e4b447ec4c47fd3184fb0f629b1',1986,'MR','Mauritania','communications',322,'300 km
North
Atlantic-’
Ocean
See regional map VII
Land
1,030,700 km?; the size of Texas afd Califor-
nia combined; “almost 90% desert, 10% pas-
ture, less than 1% suitable for crops
Land boundaries: 5,118 km
Water :
Limits of territorial waters (claimed): 70 -
nm (200 nm exclusive economic zone)
Coastline: 754km
Railroads: 740 km 1.435-meter aatidard
gauge, single track, privately owned
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 |
Highways: 7,540 km total; 1,350 km paved; °
710 km gravel, crushed stone, or otherwise
improved; 5,480 km unimproved
Inland-waterways: 800 km
Ports: 2 major (Nouadhibou and
Nouakchott) ~
Civil air: 5 major transport aircraft -
Airfields:''31 total,-31 usable; 10 with | -
permanent-surface runways; 4 with run- ©
ways 2,440-3,659 m; 16 with runways
1,220-2,439 m
Telecommunications: poor system of cable
and open-wire lines, minor radio-relay links,
and radio communications stations; 5,200
telephones (0.2 per 100 popl.); 2 AM, no FM
or TV stations; 2 satellite ground stations —
under construction -
Defense Forces
Branches: Army, Navy, Air Force, paramili-
tary Gendarmerie, paramilitary National
Guard, paramilitary National Police
Military manpower: males 15-49, 369,000;
179,000 fit for military service; conscription
law not: muplermented
Susety rte deeetac on France; has
also received material from Algeria, UK, ‘-
Spain, and Romania; West Germany fur-
nishes unspecified military cooperation/aid;
military students being trained in France,
Algeria, Libya, US, Morocco, Canada, Saudi
Arabia, Iraq, Senegal, Burkina, and Zaire -
162
International Organizations
ADB ARAB ASEAN CACM
- LEAGUE
CARICOM CEMA EC G-77 ‘cc IDB? IDB® INTELSAT LAIA NAM
4
3
°
>
a)
isa]
Oo
°
>
nH','53068125864bfc7ba4bcc0b670b3fc52f4688d905f06b53222b1846c2b624bf5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('499d4f7a75bdaa5a23373178ba0ebeaa94eabcddb152e9e7460dc66ea0175c38',1986,'MU','Mauritius','communications',325,'Agalega Islands.: Cargados.
Carajos Shoals, and ''
; Rodrigues are not shown.
indian
Ocean {:
See regional map VII.
Land
1,865 km?; aaniee a Rhode sland Hex
cluding dependencies); 50% agricultural}
intensely cultivated; 39% forest, wood, *”
mountain, rivers, and natural resources; 5%
lakes; 3% built on; 2%.roads and tracks; 1%.
waste
Water - ; :
Limits of territorial waters (ewan 12
nm ny nm exclusive economic zone) -
Castine: 177-km :-
Highways: 2,000 km total; 1,200 km paved, -
800 km earth
Ports: 1 major (Port Louis)
Civil air: 1 major transport aircraft
Airfields: 5 total,’ ‘4 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440- 3,659 m -
Telecommunications: ‘small system with
good service; new-microwave link to Re-
union; high-frequency radio links to several
countries; 2 AM, no FM, 4 TV stations; .
48,000 telephones (5.0 per''100 popl.); 1 In-
dian Ocean satellite station
Defense Forces
Branches: paramilitary Special Mobile ;
Force, Police Riot Units, and Police Force
Military manpower: males 15-49, 272,000;
142,000 fit for military service |.
Military budget: for fiscal year. ending 30. __
June 1983, $13.45 million; 3.2% of central .
government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Mayotte :
pile MZambourou _10km
Administered by France,
claimed by Comoros.
See regional map VII Mozambique Channet
Land
375 km?; more than twice the size of Wash-
ington, D. C.; part of the Comoro archipel-
ago; the main island is within an offshore
coral reef with-many breaks and passages
and is surrounded by at least six small satel-
lite islands
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: about 165 km (not including is-
lets)
People Z a
Population: 63,000 (July 1986), average an-
nual growth rate 2.8%
Nationality: noun—Mahorais (sing., pl.); .
adjective—Mahoran.-
Religion: 99% Muslim; remainder Christian,
mostly Roman Catholic
Language: Mahorian (a Swahili dialect),
French :
Literacy: probably high
Railroads: none
Highways: 85 km tarred
Inland waterways: none
Ports: none
Airfields: none
Telecommunications: small system admin-
istered by French Department of Posts and
Telecommunications; incliides radio-relay
and high-frequency radiocommunications
for links with Comoros and for internatiorial
communications; 450 telephones (9 per 100
popl.); 1 AM station
Defense Forces .
Defense is the responsibility of France
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','fbc75fead16fe333e1db0f8f8ad8ae23178b5de14f181e83047f1a12ad0594d8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4bc481c35d077e7c4dd300ff3268616ec661f283971e586cf825b8f7469a91b',1986,'MX','Mexico','communications',329,'1000 km
Tijuana
Matamoros
Gulf of Mexico
Pacific
Ocean
_ See regional map II
Land
1,972,547 km?; three times the size of Texas;
40% pasture; 22% forest; 12% crop; 26%
other, including waste, urban areas and pub-
lic lands
Land boundaries: 4,220 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 9,330 km
Monaco‘','ec4b34d7e1d0e683342edd899df5cc185e3c2fafc314e53ee70e9f7559e0b54d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d701a68b42a35b41f4af91ac9d1a1bf44bd965191fb61486874372ce4a5417cd',1986,'MC','Monaco','communications',336,'Railroads: 1.6 kay 1. 435-1 meter gauge
Highways: none; city streets
Ports: 1 minor
Civil air: no major-transport erereit
Ateelds: 1 ‘eile airfield with permanent» ;
surface runways ~
Telecommunications: served by the Frerich-
communications system; automatic tele-
phone system with about 34,600:telephones *
(123.6 per 100 popl.);3 AM, 4 FM, 4 TV sta-
tions
Defense Forces
Defense is the responsibility of Fr rance vend
167
Marseille~
Corsica
Sardinia
om
nds
Sea','63e0c1d924f8e043fcdbd484e24072fbc143941dfdb8d46edfdca68973869fbe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3816c26555426b5feec6061e45e9f4eec8b28315a3288f0d80e1db4a6fbb8710',1986,'MN','Mongolia','communications',337,': 500 km_.
See regional map VIII
Land .
1,564,619 km?; more‘than twice the size at
Texas; almost 90% of land area is pasture or ©
desert waste, varying in usefulness; 10% for-
est;:less. than 1% arable
Land boundaries: 8,000 km
Railroads: 1,600 km (1981); all 1.524-meter
broad gauge
Highways: 46,700 krn total; 700 km hard
surface; 46,000 km other surfaces (1981)
Inland waterways: 397 km of principal.
routes (1981)
Freight carried: rail—10.7 million metric
tons, 3,609 million metric ton/km (1981);
highway—27.8 million metric tons,.1,624
million metric ton/km (1981); waterway—
0.04 million metric tons, 4.7 million metric
ton/km (1981)
Defense Forces
Branches: Mongolian People’ s Army, Air
Force ~ :
Military manpower: males 15-49, 454,000;
296,000 fit for military service; 21, 000 reach
military age (18) annually
Supply: military equipment sancled by.
USSR
M ilitary wdeas for fiscal year ending 31
December 1977, 405 million tugriks, 12% of
total budget
168','b09cfd74cd5cf12e4f969ab66842fb7b99e84893757a2bca0a2f34e03007fc8e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6203dcb4d7cf2431ebf870ca479274462b3f1d81ce4f71ec4a5f1ed8c3d86bee',1986,'MS','Montserrat','communications',339,'Caribbean
Sea
See regional map III.
See el
Land
102 km?; a little over half the size of Wash-
ington, D. C.; part of the Leeward Islands
group of the Lesser Antilles in the Eastern
Caribbean; entirely volcanic, consisting of
three main mountain ranges; some arable
land with 5,000 acres of fotest
Water - -
Limits of satntonal waters (claimed): 3 nm
(200 nm fishing zone) ‘ :
Coastline: 40 km
Railroads: none
Highways: 200 km total; approximately 200
km paved, 80 km gravel and earth
Inland waterways: none
Ports: 1 major (Plymouth)
Airfields: 1 with permanent-surface runway’
1,036.32 m
Telecommunications: 3,000 telephones, 26
telex (1984); 3 AM, 1 FM, 2 TV stations
Defense Forces .
Defense is the responsibility of the United
Kingdom
169','c7ac9e8b9917fffc044b0d65fd0521cb1caa122cf12081fc12b587aa5e021c1a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('548f5ac48046f550d1f653a9141428176ddf95e4443a48d3f920dad59a6586be',1986,'MA','Morocco','communications',343,'300 km Mediterranean Sea
< euta (Sp.)
Tangiers: Melilla (Sp.)
North RABAT
Atlantic Arfa
Ocean
See regional map VII
Land .
446,550 km?; larger than California; 51% -
desert, waste, or urban; about 32% arable
and grazing; 17% forest and esparto grass
Land boundaries: 1,996 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 1,885 km
ij (','0c03ed7f3f7bdc7f55d9fc35de11f6d711ec6ad359982731902e59466e1d07ad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf6750b4cd21f109fe8e76b033bffc8a6d3b76c592fe019d0b86d7b192304cbe',1986,'SA','Saudi Arabia','communications',347,'Railroads: 1,785 km 1.435-meter standard
gauge, 161 km double track; 708 km electri-
fied
Highways: 58,000 km total; 25,750 km bitu-
minous treated, 32,250 km gravel, crushed
stone, improved earth, and unimproved
earth
Pipelines: 8362 km crude oil; 491 km (aban-
doned) refined products; 241 km natural gas
Ports: 10 major (including
Spanish-controlled Ceuta and Melilla), 14
minor
Civil air: 19 major transport aircraft
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Airfields: 79 total, 75 usable; 26 with - |
permanent-surface runways; 2 with run-
ways over 3,659 m, 14 with runways
2,440-3;659 m, 29 with Tunways 1,220-
2,489 m
Telecommunications: good system com-
posed of wire lines, cables, and radio-relay --
links; principal centers Casablanca and Ra-
bat, secondary centers Fés, Marrakech, ° . -.
Quida, Tangier and-Tétouan; 270,100 tele--°
phones (1.3 per 100 popl.); 14 AM, 6 FM, 47 -
TV stations; 5 submarine cables; 2 Atlantic
Ocean satellite stations; radio-relay to Gibr- ''
altar, Spain, and Western Sahara; coaxial
cable to Algeria
Defense Forces
Branches: Royal Moroccan Army, Royal
Moroccan Navy, Royal Moroccan Air Force
Military manpower: males 15-49, 5,222,000;
8,225,000 fit for military service; 256,000
reach military age (18) annually; limited
conscription
500 km
Persian’
Gulf...
d Dammam
Red
Sea
Jiddah
(Jeddah)
Boundary representation is
not necessarily authoruatve
See regional map VJ
——_—
Land ate
Estimated at about 2, 149, 690 km? (bound-
aries undefined and disputed); one-third the, -
size of the US; 98% desert, waste, or urban;
1% agricultural; 1% forest
Land boundaries: 4,537 km __ .
Water
Limits of territorial waters (claimed): 12
nm (6 nm “necessary supervision zone”) _
Coastline: 2,510 km
Railroads: 886 km 1.435-meter standard
gauge
Highways: 67,000 km total; 28,000 km bitu-
minous, 39,000 km gravel and improved
earth .
Pipelines: 6,400 km crude oil; 150 km re-
fined products; 2,200 km natural gas, in-
cludes 1,600 km of natural gas liquids
Ports: 7 major (Jiddah [Jeddah], Ad
Dammam, Ras Tanura, Jizan, Al Jubayl,
Yanbu‘ al Bahr, Yanbu‘ ag Sina ‘Tyah), 17 mi-
nor
Civil air: 181 major transport aircraft
Airfields: 202 total, 170 usable; 59 with
permanent-surface runways: 10 with run-
ways over 3,659 m, 25 with runways
2,440-3,659 m, 96 with runways 1, 220.
2,489 m
Telecommunications: good system exists,
major expansion program completed with -
extensive microwave and coaxial cable sys-
tems; 960,000 telephones (14.0 per 100
216.
popl.); 21 AM; 2:FM, 63 TV stations; 2 Atlan-.
tic and 2 Indian Ocean satellite-stations, 1
Arab satellite control station; radio-relay to
Bahrain, Jordan, Kuwait, Qatar, UAE, and
Sudan; coaxial cable to Kuwait; submarine
cable to Djibouti under construction
Defense Forces
Branches: Saudi Arabian Land Forces,
Royal Saudi Naval Forces, Royal Saudi Air
Force, Air Defense Force, Saudi Arabian
National Guard, Frontier Force, Coast -
Guard, Special Security Force, Public Secu-
rity Force
Military manpower: males 15-49, 3,079,000;
1,760,000 fit for military service; about
106,000 reach military age (18) annually
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Defense Forces
Branches: Army, Navy, Ait Force, Central
Military Command, Federal Police Force
Military manpower: malés''15-49, 549,000;
381,000 fit for military service
Military budget: for fiscal year ending 31
December 1984, $1.9'' billion; 45% of central °
government budget
255
NIA
ge od ERESELESERES
Seychelles | ae aa
aa PH
Singapore ® a ee
Solomon Islands i
Somalia ee ee ee
South Africa ae hee ae
Spain bjt |
Sri Lanka ee aa (ey (eee cae ee FE
Sudan a ee ee ee ee
288
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
United Nations Organizations
FAQ GA IAEA IBRD ICA
5 —— —— 7 —— - :
ae *iete BEE ECEESSBBEESEOCEEoooE ele ey «[e[elef ede] ol e%ele
°
Go oje ole e e A A
2 A ele . else _eje ele z ae a
=) E . | | La i
Q
: F
z
|
=)
E | | |
°
=
tu 4
=
8 e. e,e e e te
a H s cj ds L. a
Oo ele .
i= I J
a
<a ° e e e e ° e e e e ° e e e
289
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Country International Organizations
akc et Sh a cae en re
ADB ARAB ASEAN CACM CARICOM CEMA EC G-77 ccc 1pB? =pBo INTELSAT LAIA NAM NATO OAPEC OAS
LEAGUE','1ff90a92b46ef5138a67209f03042ee2a81742c0ce11c030214a370d3ffc6a9b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3460ac483d5287e15f660f3f42ed814d01ac0596acfa863f59490027c9d8b020',1986,'NA','Namibia','communications',348,'(South-West Africa)
Swakopmund
Boundary
representation is
not necessarily
authoritative
South
Atlantic
Ocean
300 km
See regional map VIT
Land
824,296 km?: twice the size of California;
mostly desert except for interior plateau and
area along northern border
Land boundaries: 3,798 km
Water
Limits of territorial waters (claimed): 6 nm
(fishing 12 nm)
Coastline: 1,489 km
Railroads: 2,340 km 1.067-meter gauge, sin-
gle track
Highways: 54,500 km; 4,079 km paved,
2,540 gravel, remainder earth roads and
tracks
Ports: 2 major (Walvis Bay and Lderitz)
Civil air: 8 major transport aircraft
Airfields: 15] total, 141 usable; 21 with
permanent-surface runways; | with run-
ways over 3,659 m; 4 with runways 2,440-
3,659 m, 63 with runways 1,220-2,439 m
Telecommunications: good urban, fair rural
services; radio relay connects major towns,
wires extend to other population centers;
57,400 telephones (6.0 per 100 popl.); 2 AM,
13 FM, 8 TV stations
Defense Forces
Defense is responsibility of Republic of
South Africa; however, a South: West Afri-
can Territory Force was established 1 Au-
gust 1980 (includes an air element)
M ilitary manpower: males 15-49, about
256,000; about 153,000 fit for military ser-
vice
M ilitary budget: for fiscal year ending 31
March 1984, $128.3; 8% of central govern-
ment budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
SOUTH AFRICAN
{Walvis Bay)
*
Windhoek,
YLuderitz
Orang)
Cape Town
AFRICAN REPUBLIC
Congo.
Bata
Libreville
ZAIRE
Al Fashir
SUD
Gulf of Aden
ETHIOPIA 7
Provisional /” SOMALIA
“ney”
Pond
‘Mogadishu
Equator
Nairobi 7
RWANDA; Indian
Reba
Victor
BURUND! ke tumbura jombasa Ocean
Victoria
_Kananga Kalemie\\
per ee Sales SEYCHELLES
yMiwara in
COMOROS cioesotatanas (nance)
Antsiranana
~ Agatega Islands
(MAURITIUS)
Moroni + *
‘Mayotte ,
{admin, by FRANC!
Nacala claimed by COMOR!
. Teometin Istand
(FRANCE)
"si 4
MO. ayorGve| femanceh
sBeira ‘Mozambique
Channel 5
Jains" Reunion Ssaint-
da india "| europa Beunion Saint
(FRANCED | + Istond
CERANCED \\Toliary 23 _Tropic of Capricorn
Corgados
+/Carajos
Shoals
| AURITIUS)
Antananarivo
ZIMBABWE 4 i','2dd437a63aefc7738d726c2fa3df446116ea6dd333c9c111f75b74ce58a9e616','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99a6ad214da8dc745101fd2833c3604656a3476dd58f81b82265649e05f041bf',1986,'NR','Nauru','communications',352,'ikm
South
Pacific
Ocean
” South
Pacific -
Ocean -
See regional map X
Land
20.7 km?; Jess than one-eighth the size of
Washington, D. C.; insignificant arable land,
no urban areas
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone) °
Coastline: 24 km
Railroads: none
Highways: about 27 km total; 2] km paved,
6 km improved earth a
Inland waterways: none
Ports: 1 minor. .
Civil air: 3 maior transport aircraft, one on
order
Airfields: 1 usable with permanent-surface
runways 1,220-2,439 m
Telecommunications: adequate intraisland
and international radio: communications
provided via Australian facilities; 1,500 tele-
phones (20.8 per 100 popl:); 3,600 radio re-
ceivers, 1 AM, no FM or: TV stations; 1
ground satellite station
Defense Forces
No formal defense structure and) no regular °
armed forces gee
Military manpower: males 15-49, about
1,800; fit for military service, about 1,000;
about 100 reach military-age (18) annually
Declassified and Approved For Release 201 2/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4','0b627538799839f143ab31b37010fd19e4a05e6c6296b116e40618f7b7d86abe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b85440c8d62c87e6e49326a7b4be82a8721fd2582dcafbf543d7104fabcd006',1986,'NP','Nepal','communications',356,'200 km
*
See regional map VII
Land .
140,791 km?; the size tek North Carolina; -
38% alpine land (nonarable), waste, or ur-
ban; 32% forest; 16% agricultural; 14% per-
manent meadow and pasture.
Land boundaries: 2,800 km
Railroads: 169 km (1985), allo. 762-meter
narrow gauge; all in Terai close to Indian
border; 10 km from Raxaul to Birganj is gov-:
ernment owned
Highways: 5,270 km total (1985); 2,322 km
paved, 556 km gravel or crushed stone,
1,829 km improved and unimproved earth;
additionally 241 km of seasonally motorable
tracks
Civil air: 5 major and 11 minor transport
aircraft
Airfields: 38 total, 38 usable; 5 with
permanent-surface runways; | with run-
ways 2,440-3,659 m, 8 with runways
1,220-2,439 m
Telecommunications: poor telephone and
telegraph service; fair radiocommunication
and broadcast service; international]
radiocommunication service is poor; 10,000
telephones (less than 0.1 per 100 popl.); 3
AM, no FM or TV stations
Defense Forces
Branches: Royal Nepalese Army, Royal Ne-
palese Army Air Service, Nepalese Police
Force
Military manpower: males 15-49, 4,186,000;
2,114,000 fit for military service; 196,000
reach military age (17) annually
Military budget: for fiscal year ending 15
July 1986, $62.0 million; 9.6% of central
government budget','d6687d1964c72c8fd69a0f5e6ba9dbe0fd728661a86eb82b9fd4848da1703499','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('365e02846939866b799ca078c0a21385692ff9bb6e0922c4698bb0580f19d89b',1986,'NL','Netherlands','communications',359,'See regional map V
Land
40,844 km?; the size of Massachusetts, Con-
necticut, and Rhode Island combined; 70%
cultivated, 8% forest, 8% inland water, ed
waste, 9% other
Land boundaries: 1,022 km
Water
Limits of territorial waters (clawed 12
nm (200 nm fishing zone) .
Coastline: 451 km
Railroads: Netherlands Railvage (N S)o oper-
ates 2,867. km 1.435-meter standard gauge;
8,033 km total trackage; 1,810 km electri-.
fied, 1,800 km double track; 166 km pri-
vately owned
Highways: 108,360 km total; 92,525 km
paved (including 2,185 km of limited access,
divided highways); 15,835 km gravel,
crushed stone
Inland waterways: 6,340 km, of which 35% .
is usable by craft of 900 metric ton capacity. .
or larger
Pipelines: 418 km crude oil; 965 km refined.
products; 10,230 km natural gas
Ports: 8 major, 10 minor
Civil air: 98 major transport air craft
Airfields: 29 total, 28 usable; 19 with
permanent-surface runways; 12 with run- .
ways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: highly developed, .
well maintained, and integrated; extensive
system of multiconductor cables, supple-
mented by radio-relay links; 8.27 million
telephones (57.5 per 100 popl.); 7.AM, 38
FM, 29 TV stations; 9 submarine cables; 1
satellite station with 2 Atlantic Ocean and 2
Indian Ocean antennas
Defense F ‘orces
Branches: Royal N etherlands Army, Raval
Netherlands Navy/Marine Corps, Royal
Netherlands Air Force
Military manpower: males 15-49, 4,004,000;
8,397,000 fit for military service; 132,000
reach military age (20) annually
Military budget: for fiscal year ending 31
December 1984, $4.1 billion; about 9.2% of
central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Netherlands Antilles
—50km
Islands‘not shown in true
geographical position
paint Martin
Caribbean Sea Philipsburg
Saba
zo)
Sint Eustatius
Sabana
Westpunt
See regional map IIT
Land :
1,821 km?; more than one and one- “half
times the size of New York City; 95% waste,
urban, or other; 5% arable
Water
Limits of territorial waters (claimed ): 3 nm
(200 nm fishing zone)
Coastline: 364 km
Railroads: none
Highways: 950 km total; 300 km paved,.650
km gravel and earth
Ports: 4 major (Willemstad, Oranjestad,
Philipsburg, Kralendijk); 6 minor (of which 4
are significant ports for petroleum tankers):
Civil air: 5 major transport aircraft
Airfields: 7 total, 7 usable; 7 with
permanent-surface runways; 2 with run-
ways .2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: generally adequate
telecom facilities; extensive interisland
radio-relay links; 65,000 telephones (24.6
per 100 popl.); 12 AM; 7 FM, 3 TV stations; 2
submarine cables; 2 Atlantic Ocean satellite
antennas
Defense Forces
Defense is responsibility.of eis Natharlatids
Military manpower: males 15-49, 58,000;
33,000 fit for military service: about 2,400
reach military age (20) annually
Netherlands Antilles¢
New Caledonia¢','25cedcdd67572729494fa742394e04de7bb133f1275786b9afadbaf73c72b6c0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eae233b16fe6c43d446b1717a99bc5b91d1de047060704cde917663fe68f4b7',1986,'NC','New Caledonia','communications',363,'150 km
Coral Sea
~ Hes -
Caledoni aa South
Pacific
Ocean
Coral Sea ‘ile des Pins
Islands of Huon and
: - Chesterfield are not shown.’
See regional map X
Land ©
22,139 km?; larger than Wie dichueis: 20%
pasture, 15% forest, 6% arable, 57% waste or
other
Water
Limits of territorial waters is (claimed 12
nm (200 nm exclusive economic zone)
Coastline: 2,254 km
Railroads: none
Highways: 5,399 km total (1979); 558 km
paved, 2,251 km improved earth, 2;639 km
unimproved earth
Inland waterways: none
Ports: | major (Nouméa), 21 minor
Civil air: no major transport aircraft
Airfields: 31 total, 30 usable; 4 with -
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runway
1,220-2,439 m
Telecommunications: 23,000 telephones (17
per 100 popl.); 5 AM, no FM, 7 TV stations; 1
earth satellite station
Defense Forces
Defense is the responsibility of France
mo','a93985ad049f53cd221882ddf673ded33c73c9b2ea23e569928631a3f50250cc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea21ea8f8836304b3db80716b32cb23668362c485726fb8a9e7b4315c11b3d38',1986,'NZ','New Zealand','communications',367,'Pa oa a -_ —
§00 km Kermadec , ,
Islands *
South
Pacific
e Ocean
North Island
“3. Chatham
Islands
See regional map xX .
Land
268,676 kin?; the size of Colorado; 50% pas-
ture; 16% forest; 10% park and reserve; 3%
cultivated; 1% urban; 20% waste, water, or
other; 4 principal islands, 2 minor inhabited
islands, several minor uninhabited islands
Water ;
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: about 15,134 km
Railroads: 4,716 km total (1980); all 1.067-
meter gauge; 274 km double track; 113 km
electrified; over.99% goverriment owned
Highways: 93,137 km total (December
1980); 47,236 km paved: 45;901 km gravel or
crushed stone
Inland waterways: 1,609,km; of little impor-
tance to transportation
Pipelines: natural gas, 1,000 km; refined
products, 160 km; condensate, 150’‘km
Ports: 3 major
Civil air: about 40 majortransport aircraft
Airfields: 205 total, 197- usable; 26 with
pérmanent-surface-runways; 2 with run-
ways 2,440-3,659-m; 51 with runways
1,220-2,439''m
Telecommunications: excellent interna-
tional and domestic systems;.1.7 million tele-
phones (55 per 100 popl.); 64 AM, no FM, 14
TV stations, and: 1.29 repeaters; submarine
cables extend to Australia and Fiji Islands; 1
ground satellite station
Defense Forces
Branches: Royal New Zealand. Air Force,
Royal New Zealand Navy, New Zealand
Army
’ Military manpower: males 15-49, 881,000;
633,000 fit for military service;.about 30, 000
reach military age (20) annually
Military budget: for fiscal year ending 31
March 1986, $500 million; about 5.1% of
central government budget
181','e907b97c42d399b46d106b323b119c629824762b60aec985828d34cbafff14f0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb807cdcf2b8ca9bf05dc246173fc43248ecfd0197527c319126ff7c4071318a',1986,'NI','Nicaragua','communications',371,'y, oe
j Cayos
Miskitos
Caribbean
Sea
Islas del
Maiz
North
Pacific
Ocean
See regional map Il
Land
130,000 km?; about the size of Iowa; 50%
forest; 7% arable; 7% prairie and pasture;
86% urban, waste, or other
Land boundaries: 1,220km °
Water
Limits of territorial waters (claimed):
200 nm
Coastline: 910 km
Railroads: 344 km 1.067- meter gauge, gov-
ernment owned; majority of system not op-
erating; 3 km ].435-meter gauge line at
Puerto Cabezas (does not connect with
mainline)
Highways: 23,585 km total; 1,655 km paved,
2,170 km gravel or crushed stone, 5,425 km -
earth or graded earth, 14,335: km
unimproved
Inland waterways: 2,220 km; including 2
large lakes :
Pipelines: crude oil; 56:km ~::
Ports: 1 major (Corinto), 7 minor
Civil air: 12 major transport aircraft
Airfields: 296 total, 261 usable; 8 with ‘
permanent-surface runways; 2 with run-
ways.2,440-3,659 m;-11 math runways
1,220-2,439 m
Pasa low-capacity radio-.
relay and wire system being expanded; con-
nection into Central American microwave
net; Atlantic Ocean satellite station; 60,000
telephones (2.2 per 100 popl.); 42 AM, 6 TV
stations; Intersputnik communications satel-
lite facility planned :
Defense Forces:
Branches: Sandinista People’s Army, Sandi-
nista Navy, Sandinista Air Force / Air De-
fense, Sandinista People’s Militia
Military manpower: males 15-49, 678,000;
419,000 fit for military service; 33,000 reach
military age (18) annually
Military budget: estimated for fiscal year
ending 81 December 1985, $1.4 billion; 50%
of central government budget (includes both
defense and security expenditures)
183','e34b93d033827f0aa1281ffa849fd34e95cc180b6767a1a6552e965f7f1c4b70','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a54e11f182dbdef989a5b47021464126d39ef5464085a5ce1052c673d2d5cd2d',1986,'NE','Niger','communications',375,'$00 km__.
See regional map VII
Land : .
1,267,000 km2; almost three times ; the size of
California; 7.6% permanent meadow and
pasture, 2.6% arable, 2.3% forest and wood.
land, .02% inland water, 87% other
Land boundaries: 5,745 km .
Railroads: none
184 -
Highways: 36,500 km total; 2,800 km bitu-
minous, 10,700 km gravel and laterite, ,
23, 000 km tracks”
Inland mataniaue: Niger River navigable
300 km from Niamey to Gaya on the Benin
frontier from mid-December through
March . :
Civil air:8 major transport aircraft
Airfields: 63 total, 58.usable; 7 with -
permanent-surface runways; 1 with run-~
ways 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: small system of wire .
and radio-relay links concentrated in south-
western area; 9,800 telephones (0.2 per 100.
popl.); 9 AM, 2 FM, 12 TV stations; 2 Atlan= -
tic Ocean satellite stations, 4 domestic anten-
nas :
Defense Forces
Branches: Army, Air Force, paramilitary
Gendarmerie, paramilitary Republican
Guard, paramilitary Presidential Guard,
paramilitary‘National Police
Military manpower: males 15-49, 1,456,000;
785,000 fit for military service; about 66,000
reach military age (18) annually
: CIA-RDP08-00534R0001001 70001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','1a479dd6782919ca61ed98288b6a49871d8acd438af514b8c9ead646627dae92','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('699da142b1e4a5b58d17e4cd0ce1b05387cdc5fa9035cdabc64345e94e386b0b',1986,'NU','Niue','communications',378,'South
Pacitic
Ocean
See regional map X
a ES
Land
259 km2; about twice the size of Washing-
ton, D. C.; 20% forest
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 64 km .
Railroads: none
Highways: 123''kim all-weather roads; 106
kma access and plantation roads ©
Ports: no harbor; open roadstead offers an-
chorage offshore from Alofi, from where
servicing is by small boat’ ~°
Airfields: 1 with permanent-surface runway
of 1,650 m capable of taking intermediate--
size jet aircraft
Telecommunications: single-line telephone —
system connects all villages on island; est.
1,000 radio receivers in use (8); 1 radio
station;no TV service ~~
Defense Forces
Defense is the responsibility of New Zealand
rcs','886b1914150cb0d27300c66f2088cca37753320acb859395b8394d8786813faf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f26ecd5496a5082a8c3670879a2467464c499e0dd563cf04c5789c2589c20d0',1986,'NF','Norfolk Island','communications',382,'@Nepean
South
Pacific
Ocean
Philip island
See regional map X
Land
34.5 km?; less than one-third the size of
Washington, D. C.; consists of Norfolk, Ne-
pean, and Philip Island (the last two are un--
inhabited); 400 hectares arable land .
Water
Limits of territorial waters 8 (claimed ):3nm -
(200 nm fishing zone)
Coastline: 32 km (mostly inaccessible cliffs)','a1dc38a175a25f48c733b52938f519c55899af99e167d99686078d3164a88c11','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7429a79fcb215a3e50e41da26b73d86b483a13ae64446db901435ed6c68d53fd',1986,'NO','Norway','communications',385,'400 km
Norwegian
Sea
Jan Mayen and Svalbard
are not shown.
See regional map V
Land
Continental Norway, 324,219 km; slightly
larger than New Mexico; Svalbard, 62,160
km?; Jan Mayen, 373 km?; 21% forest; 3%
arable, 2% meadow and pasture; 74% other
Land boundaries: 2,579 km
Water
Limits of territorial waters (claimed): 4 nm
(200 nm exclusive economic zone)
Coastline: mainland 3,419 km; islands 2,413
km (excludes long fjords and numerous small
islands and minor indentations, which total
as much as 16,093 km overall)
Railroads: 4,257 km 1.435-meter standard
gauge; Norwegian State Railways (NSB) op-
erates 4,242 km (2,448 km electrified and 94
km double track); 16 km privately owned
and electrified
Highways: 78,116 km total; 17,699 km con-
crete and bitumen; 19,277 km bituminous
treated; 41,140 km gravel, crushed stone,
and earth
189
Inland waterways: 1,577 km; 1.5-2.4m
draft vessels maximum
Pipelines: refined products, 53 km
Ports: 9 major, 69 minor
Civil air: 62 major transport aircraft
Airfields: 96 total, 95 usable; 54 with
permanent-surface runways; 12 with run-
ways 2,440-3,659 m, 14 with runways
1,220-2,439 m
Telecommunications: high-quality domes-
tic and international telephone, telegraph,
and telex services; 2.39 million telephones
(57.9 per 100 popl.); 8 AM, 843 FM, 1,744
TV stations; 4 coaxial submarine cables; 6
domestic satellite stations
Defense Forces.
Branches: Royal Norwegian Army, Royal
Norwegian Navy, Royal Norwegian Air
Force
Military manpower: males 15-49, 1,049,000;
852,000 fit for military service; 33,000 reach
military age (20) annually
Military budget: for fiscal year ending 31
December 1984, $1.6 billion; 10.6% of cen-
tral government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','5e351ef54abfd66df184dbef639a7332c40d6d958cff925d7ba5ed9470f736d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ad46be94b953b8bc015733513b7100cbff0c43082a89224aa681335c52c4da9',1986,'OM','Oman','communications',389,'300 km b Musandam
Y Peninsula
Boundary representation is
not necessarily authoritative
Ma rah: bee
ip Mas
Arabian
Sea
See regional map VI
a a eS
Land
About 212,380 km?; about he size a New
Mexico; negligible amount forested; remain-
der desert, waste, or urban
Land boundaries: 1,384 km
Water ;
Limits of territorial waters (claimed): 12
nm (200 nm éxclusive economic zone)
Coastline: 2,092 km
Railroads: none
Highways: 16,900 km total; 2,200 km bitu-
minous surface, 14,700 km motorable track
Pipelines: crude oil 1,300 km; Hatural gas
1,080 km
Ports: 2 major (Mina’ Qabiis, Mina’
Raysut), 5 minor
Civil air; 26 major transport aircraft, includ-
ing multinationally owned Gulf Air Fleet
Airfields: 125 total, 119 usable; 6 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 4 with runways 2,440-
3,659 m, 58 with runways 1,220-2,439 m
Telecommunications: fair system of open-
wire, radio-relay, and radio communications
stations; 23,000 telephones (2.2 per 100
popl.); 3 AM, 3 FM, 11 TV stations; 1 Indian
Ocean satellite station, 8 domestic satellite
stations, ] Arab satellite station
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Defense Forces :
Branches: Army, Navy, Air Force, Royal
Oman Police
Military manpower: males 15-49, 285,000;
162,000 fit for military service
Military budget: for fiscal year ending 31
December 1985, $2.075 billion; 87.4% of
central Eavemment budget"
Arabian Sea
See regional map VIII
Land
803,943 km? (excludes Northern Areas is
Azad Kashmir, the Pakistani-controlled ‘
parts of the former state of Jammu and ''‘’
Kashmir); larger than Texas; 40% arable,
including 24% cultivated; 34% probably - :
mostly waste; 23% unsuitable for cultivation;
3% forested
Land boundaries: 5,900 km
Water beget
Limits of territorial waters (claimed 1 12
nm (200 nm exclusive economic zone)
Coastline: 1,046 km
Railroads: (1984) 8,822 km 1.676-meter
broad.gauge, 535 km 1.000-meter gauge,
and 610 km 0.762-meter narrow gauge; _
1,037 km broad gauge double track and 286
km electrified; government owned
192
Highways: 98,000 km total (1984); 40,000.
km paved, 23,000 km gravel, 29,000 im-
proved earth, and unimproved earth road
sand tracks:
Inland waterways: negligible
Pipelines: 250 km crude oil; 2,269.km natu-
ral gas; 750 km refined products
Ports: 2 major, 4 minor
Civil air: 30 major transport aircraft
Airfields: 117 total, 98 usable; 69 with
permanent-surface runways; 1 with run-. .
ways over 3,659 m, 29 with runways 2,440-
3,659 m, 41 with runways 1,200-2,439 m
Telecommunications: good international ~
radiocommunication service over micro- -
wave and INTELSAT satellite; domestic °
radio communications poor; broadcast ser-
vice good; 314,000 telephones (0.3 per 100
popl.); 27 AM, no FM, 16:TY stations; 1
ground satellite station
Defense Forces
Branches: Army, Air Force Navy, Civil
Armed Forces, National Guards
Military manpower: males 15-49,
24,519,000; 16,686,000 fit for military ser-
vice; 1,234, 000 reach raulitary age (17) annu-
ally
Military budget: for-fiscal year ending 30
June 1986, $2.19 billion; about 26% of cen-
tral government budget s, National Guards
Military manpower: males 15-49,
24,519,000; 16,686,000 fit for military ser-
vice; 1,234,000 reach military age (17) annu-
ally
Military budget: for fiscal year ending 30
June 1986, $2.19 billion; about 26% of cen-
tral government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Panama |
Caribbean Sea
¢Bocas de! Toro
}o
Gulf of
Panama _
North Pacific Océan
See regional! map IIT
Land
77,080 km?; slightly larger than West Vir-
ginia; 24% agricultural‘land (11% pasture,
9% fallow, 4% crop); 20% exploitable forest;
56% other forest, usben or waste
Land pinta 630km .
Water
Limits of territorial waters (claimed): 200
nm : : x
Coastline: 2,490 km
Railroads: 238 km total; 78 km 1.524-meter
gauge, 160 km 0.914-meter gauge
Highways: 8,530 km total; 2,745 km paved,
3,270 km gravel or crushed stone, 2,515 km
improved and unimproved earth
Inland waterways: 800 km navigable by
shallow draft vessels; 82 km Panama Canal
Pipelines: crude oil, 130 km
Ports:2 major (Cristobal and Balboa), 8 mi-
nor -
Civil air: 16 major transport aircraft
Airfields: 132 total, 128 usable; 42 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m; 18 with runways
1,220-2,439 m
Telecommunications: domestic and inter-
national telecom facilities well developed;
connection into Central American micro-
wave net; 2 Atlantic Ocean satellite anten-
nas; 220,000 telephones (10.5 per 100 popl.);
80 AM, 12 TV station: ] coaxial submarine
cable
Defense Forces
Branches: Defense Forces of the Republic of
Panama (formerly known as the National
Guard) includes military ground forces (still
designated National Guard), Panamanian
Air Force, National Navy, Panama Canal
Defense Force, police force, traffic police/
highway patrol, National Department of
Investigation, Department of Immigration
Military manpower: males 15-49, 571,000;
893,000 fit for military service; no conscrip-
tion
Military budget: for fiscal year beginning 1°
January 1985, $99 million; 3.6% of central _
government budget
194
Bown
. . i
; £ 4 o-|
| CANADA 1
| i Soviet Union, East and South A
i North America "map vin * |
i Mapit ‘ MS
'' a
os ax re
i - |
TED STATES orth Turkey Werth
i i
Atlantic ofocco Pacific |
ALGERIA ae Oeean | |
a
%
ermop ut
ams
‘tenes kote,
ell
loaen Soha','f227abec617fc7bbbc25ea7fe56c95ab3b411b33415791f113fc64842d35bf07','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e92d77a03cf1aa265f28c66cb9b844d9eaa7b3bce1e491a1722046358276066',1986,'PG','Papua New Guinea','communications',393,'“500Km
South Pacific Ocean
s .
om New Ireland
8 ..
‘New Qgovooinviti
: Britain.
PORT
MORESBY
Coral Sea
See regional map X
Land
461,691 km?; slightly larger fan California;
70% forest, 3% cultivated; 2% pasture, 25%”
other
Land boundaries: 966 km
Water &
Limits of territorial waters died’ 12°
nm (200 nm exclusive economic zone); mari-
time limits measured from claimed “archi- *
pelagic baselines,” which generally connect
the otitermost points of the outer islands or
drying reefs
Coastline: about 5,152km
Railroads: none |
Highways: 19,200 km total; 640 km paved,
10,960 km gravel, crushed stone, or stabi-
lized soil surface, 7,600 km unimproved
earth
Inland waterways: 10,940 km
Ports: 5 principal, 9 minor
Civil air: about 15 major transport aircraft
Airfields: 534 total, 433 usable; 15 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m; 36 with runways
1,220-2;439 :m
Telecommunications: Papua New Guinea
telecom services are adequate and are being
improved; facilities provide radicbroadcast,
radiotelephone and telegraph, coastal radio,,
aeronautical radio and international
radiocommunication services; submarine
cables extend from Madang to Australia and
Guam; 45,274 telephones (1.5 per 100 pop!.);
31 AM, no FM, or TV stations
Defense Horces
Branches: Papua New Ciinda Defense
Force
M ilitary manpower: males 15-49, 817,000;
about 452,000 fit for military service
Supply: dependent on Australia
Military budget: for fiscal-year ending 31
December 1985, $33.4 million; about 3% of |
central government budget :
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','fa5224048555e78137761be9579a2d97a7b519dedc0fd4e45b66fb21d99da461','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95afbd65573031ec734e917a00051892dcaffe678c1355de1add0168b57ceb51',1986,'PY','Paraguay','communications',396,'Boundary representation is
not necessarily authoritative.
Encarnacion
See regional map IV
Land
406,750 km?; the size of California; 52% for-
est; 24% meadow and pasture; 22% urban,
waste, and other; 2% crop
Land boundaries: 3,444 km
Railroads: 970 km total; 440 km 1.435-meter
standard gauge, 60 km 1.000-meter gauge,
470 km various narrow gauge (privately
owned)
Highways: 21,960 km total; 1,788 km paved,
474 km gravel, and 19,698 km earth
Inland waterways: 3,100 km
Ports: 1 major (Asunci6n), 9 minor (all river)
Civil air: 4 major transport aircraft
Airfields: 880 total, 770 usable; 6 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 29 with runways
1,220-2,439 m
Telecommunications: principal center in
Asuncion, fair intercity microwave net;
78,300 telephones (2.3 per 100 popl.); 40
AM, 6 TV stations; 1 Atlantic Ocean satellite
station
Defense Forces
Branches: Paraguayan Army, Paraguayan
Navy, Paraguayan Air Force
M ilitary manpower: males 15-49, 979,000;
778,000 fit for military service; 48,000.reach
military age (17) annually
Military budget: for fiscal year ending 31
December 1985, $76.4 million, 17.2% of
central government budget','c329ad53d8715d4010d1ed880b9c54d067bbae15542cf4b8d2114970e76b8485','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66ce9b6d69fde4094dceac20c4c3c204c2890c6180dfa9666281f340e4a7f865',1986,'PE','Peru','communications',400,'500 km _
South
Pacific
Ocean .
Lago
Titicaca
Boundary representation 1s
not necessarily aulboritahve.
See regional map IV
Land
1,285,216 km (other estimates range as low
as 1,248,380 km); five-sixths the:size of
Alaska; 55% forest; 14% meadow and pas-
ture; 2% crop; 29% urban, waste, or other
Land boundaries: 6,131 km_ -:
Water :
Limits of territorial waters (claimed): 200
nm
Coastline: 2,414 km
Railroads: 1,876 km total; 1,576 km 1.435- -
meter standard gauge, 300 km 0.914-meter
gauge
Highways: 56,645 km.total; 6,030 km paved,
11,865 km gravel, 14,610 km improved
earth, 24,140 km unimproved earth
Inland waterways: 8,600 km of navigable
tributaries of Amazon River system and 208
km Lago Titicaca
Pipelines: crude oil, 800 km; natural gas and
natural gas liquids, 64 km
Ports: 7 major, 25 minor
Civil air: 27 major transport aircraft .
Airfields: 246 total, 228 usable; 32 with
permanent-surface runways; 2 with run-
ways over 3,659 .m, 25 with runways
2,440-3,659.m, 43 with runways 1,220-
2,439 m
Telecommunications: fairly adequate for
most requirements; nationwide radio-relay
system; 2 Atlantic Ocean satellite stations, 12
domestic antennas; 544,000 telephones (2.9
per 100 popl.); 250 AM, 138 TV stations
Defense Forces —
Branches: Peruvian Army, Peruvian Navy,
Peruvian Air Force.
Military manpower: males 15-49, 4,843,000;
3,282,000 fit for military service; 188,000
reach military age (20) annually
198','dfdb247f898cfe24e06df275dd810cabf3bd9e1cca176345f090338f3e44c0d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7902c4c56696117485c6f75349d57d568f6890ced51aaedae0a8a107fd680959',1986,'PH','Philippines','communications',404,'500 km :
Philippine
South Sea
China ; oy
Sea = Samar
Palawan .
Negros
B ‘s ulu Sea f
&
Zamboangaf/ ") Mindanao
toe
. * Celebes Sea
See regional map IX
Land
800,440 km?; slightly larger than Nevada;
53% forest, 30% ae 5% pasture, 12%
other
Water
Limits of territorial waters (claimed): up to
285 nm, based on limits described in the
Treaty of Paris, 10 December 1898, the US-
Spain Treaty of 7 November 1900, and the
US-UK Treaty of 2 January 1930, are con-
sidered to be the territorial sea (200 nm ex-
clusive economic zone)
Coastline: about 22,540 km
F
i
x
‘Southeast
px.
Asia
South Ameri.
Pacific |
Bouiay Map IV
Ocean i
AR. ~CENTRAL AFRICAN REPUBLIC
R.
D.R.Y.-PEOPLE''S DEMOCRATIC REPUBLIC OF YEMEN
WE, UNITED ARAB EMIRATES.
‘AR. YEMEN ARAB REPUBLIC
i H Antarctic Region
Map XII +
c.
ER. Mu
G.D.R_ -GERMAN DEMOCRATIC REPUBLIC
5
v.
vy
Oceania
(Map x |
800528 (545038) 4-86
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 :
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
bei Barrow
Bering t 2,
Strat
“ Prudhoe Bay
(Alaska)
Fairbanks®
Poem ea
“Valdez /
Te
Junéails
rite
Ketchi ahs
vO
*
Los Angeless
‘
San Diegoe
ScaleM:38,700,000
i 500 Kilometers
(0) 500 Nautical Miles
Boundary representation is
not necessarily authoritative.
800539 (545526) 4-86
js
a A Saskatoon
ara oCalgary .
Ssoaiioys
North America
7 i 1 \\ AN
140 120 100 80 60
BS','9f14fd564da0d0faea92b149d607ae6a2c51f1ac061c73060d1366978c3eb7ae','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2fe83a835f5e87ef5f3d931b1622798cd8ed925709c908a53ba2088709cba64',1986,'PN','Pitcairn','communications',410,'Railroads: none
Highways: 6.4 km dirt roads
Ports: boat harbor and jetty at Bounty Bay
Airfields: epne
Telecommunications: party line telephone
service on the island; radio station at ““Taro
Ground”; diesel generator provides electric-
ity :
Defense Forces .
Defense is the esronsibility: of the United.
Kingdom
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
NE ne, a ee
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','7129e27402b4a8eff64311dab69764d70c5ed534b37f1b2bf75761ccec787cea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aaf192c97cbde6e9f8482ecac62aa7ae90bca53fc8c6433e5fd28b9fd6fe118',1986,'PL','Poland','communications',411,'Baltic Sea —180 km
Boundary representation is
not necessarily authoritative.
See regional map V
Land
312,612 km?; smaller than New Mexico; 49%
arable; 27% forest, 14% other agricultural,
10% other . :
Land boundaries: 3,090 km
Water
Limits of territorial waters (claimed): 12
nm (6 nm contiguous zone claimed in addi-
tion to the territorial sea; 200 nm fishing
zone, with lateral limits based on geographic
coordinates)
Coastline: 491 km
Railroads: 27,176 km total; 23,969 km 1.435-
meter standard gauge, 397 km 1.524-meter
broad gauge, 2,810 km narrow gauge; 8,843
km double track; 8,307 km electrified; gov-
ernment Gwned (1984)
Highways: 254,000 km total; 57, 353 km con-
crete, asphalt, stone block; 97,561 km
crushed stone, gravel; 99,086 km earth
(1983)
Inland waterways: 4,017 km navigable riv-
ers and canals os
Pipelinés: 4,500 km for anita gas; 1,986
km for crude oil (1984), 822 km for refined
products ,
Freight carried: rail—425.5 million metric
tons, 123.5 billion metric ton/km (1985);
highway—1,420 million metric tons, 36.5
billion metric ton/km (1985); inland water-
way—15.45 million metric tons, 1.44 billion
metric ton/km (1985); ocean193.4 billion
metric ton/km (1985) ~. :
Ports: 4 major (Gdansk, ‘Gdynia, Szczecin,
Swinouiscie), 12 minor (1979); principal in-
land waterway ports are Gliwice; Wroclaw,
and Warsaw (1979)
Defense Forces
Branches: Ground Forces, National Air De-
fense Forces, Air Force Command, Navy
Military manpower: males 15-49, 9,392,000;
7,454,000 fit for military service; 258,000
reach military age (19) annually
Military budget: announced for fiscal year
ending 31 December 1985, 307 billion
zlotys; 7.7% of total budget','cb0c2e376d0ef86b1777fe9159511486e16109d67637b75a9cdcdcb78a97fda3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81d4f4be18e55ecaa8e2e8eb4716d8d19feac1d35fad8668b33d8c9b196fba72',1986,'PT','Portugal','communications',415,'125 km
North
Atlantic
Ocean
LISB
Azores and Madeira
Islands are not shown
See regional map V and VII
Land
Portugal, 92,082 km2, including the Azores
and Madeira Islands; slightly smaller than
Indiana; 49% arable; 31% forest; 6%
meadow and pasture; 14% waste, urban,
inland water, or other
Land boundaries: 1,207 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 860 km; excludes Azores (708 km)
and Madeira Islands (225 km)
Railroads: 3,630 km total: state-owned Por-
tuguese Railroad Co. (CP) operates 2,858 km
1.665-meter gauge (434 km electrified and
426 km double track), 760 km 1.000-meter
gauge; 12 km (1.435-meter gauge) electri-
fied, double, nongovernment owned
203
Highways: 57,499 km total; 49,537 km
paved (bituminous, gravel, and crushed
stone), including 140 km of limited-access
divided highway; 7,962 km improved earth;
plus an additional 4,100 km of unimproved
earth roads (motorable tracks)
Inland waterways: 820 km navigable; rela-
tively unimportant to national economy,
used by shallow-draft craft limited to 297-
metric-ton cargo capacity
Pipelines: crude oil, 11 km
Ports: 7 major, 34 minor
Civil air: 34 major transport aircraft
Airfields (including Azores and Madeira
Islands): 69 total, 66 usable; 35 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 9 with runways 2,440-
3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: facilities are gener-
ally adequate; 1.68 million telephones (16.6
per 100 popl.); 50 AM, 52 FM, 66 TV sta- .
tions; 6 submarine cables; 3 Atlantic Ocean
satellite antennas (on mainland and Azores)
Detsase Roser,
Branches: Army, ‘Navy, Air Force
Military manpower: males 15-49, 2,430,000;
1,989,000 fit for military service; 90,000
reach military age (20) annually
Military budget: for fiscal year ending 31
December 1984, $652 million; about 10% of
central government, budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','bbf92d8f6b89bb67bdd448ce7ecbce548746dbb035f0050e72fb4dbac0ff0094','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1230dac759e9a991d02e0c394d1bf1cbb7e005f5a14bed74ee0069e5588a4638',1986,'QA','Qatar','communications',418,'50km
Persian
Gulf
Hawar Islands are. 4,
disputed between Go
Bahrain and Qatar iy
See regional map V.
Land
About 11,000 km2; smaller than Connecti-
cut; negligible forest; mostly desert, waste,
or urban
Land boundaries: 56 km
Water
Limits of territorial waters (claimed): 3 nm
(exclusive economic zone to median line)
Coastline: 563 km
Railroads: none
Highways: 840 km total; 490 km bitumi-
nous; 350 km gravel; undetermined mileage
of earth tracks
Pipelines: crude oil, 235 km; natural gas,
400 km ;
Ports: 2 major (Doha, Musay‘id), 1 minor
Civil air: 3 major transport aircraft
Airfields: 8 total, 3 usable; 2 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: modern system cen-
tered in Doha; 96,000 telephones (37 per 100
popl.); 1 Atlantic Ocean and.1 Indian Ocean
satellite station; 1 Arab satellite station un-
der construction; tropospheric scatter to
Bahrain; radio-relay to Saudi Arabia; sub-
marine cable to Bahrain and UAE; 2 AM, 1
FM, 3 TV stations
Defense Forces
Branches: Army, Sea Arm, Air Force, Police
Department
Military manpower: males 15-49, 130,000;
70,000 fit for military service
Military budget: for fiscal year ending 31
December 1978, $157 million; 7.3% of cen-
tral government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
quae
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Reunion
SAINT-DENIS —lokm__
indian
Ocean
Indian Ocean -
See regional map VII
Land
2,512 km?; about three times the size of New
York City; two-thirds of island extremely
rugged, consisting of volcanic mountains;
48,600 hectares (less than one-fifth of the
land) under cultivation
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 201 km
Railroads: none
Highways: 2,800 km total; 2,200 km paved,
600 km gravel, crushed stone, or stabilized
earth
Ports: 1 major (Port de la Pointe des Galets
at Le Pon)
Civil air: | major transport aircraft
Airfields: 2 total, 2 usable; 2 with
permanent-surface runways; 1 with run-
ways 2;440-3,659 m, 1 with runways
1,220-2,439 m ,
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Reunion (continued)
Telecommunications: adequate system for
needs; modern open-wire line and radio-
relay network; principal center Saint-Denis;
radiocommunication to Comoros Islands,
France, Madagascar; new radio-relay route.
to Mauritius; 71,500 telephones (14.0 per
100 popl.); 2AM, 9 FM stations; 1 TV station
with 17 relay transmitters; 1 Indian Ocean
satellite station .
Defense Forces
Defense is the responsibility of France
Military manpower: pamales 15- 49, 156,000;
81,000 fit for military service; 7, 000 Bod
military age (18) annually
Reunion‘','46ec8966d5b8d3a9841c39224e4ef4d1629159259b9fdc84b0f98067a6481968','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a31981eb34ee06369f7282531de415fbdf02ce263d36a19f312042d5a8852fe8',1986,'RO','Romania','communications',422,'200 km
See regional map V
Land
237,499 km; slightly smaller than Oregon; “
44% arable, 27% forest, 19% other agricul-
tural, 10% other
Land boundary: 2,969 km
Water :
Limits of territorial waters (claimed): 12
nm : ‘ :
Coastline: 225 km
Railroads: 11,106 km total; 10, 589 km 1.435-
meter standard gauge, 472 km narrow
gauge, 45:km broad gauge; 3,113 km electri-
fied, 2,642 km double track; government
owned (1983)
Highways: 73,369 km total; 29,233 km con-
crete, asphalt, stone block; 38,880 km as-
phalt treated, gravel, crushed stone; 5, 256
km other (1983)
Inland waterways: 1,724 km (1984)
Pipelines: 2,800 km crude oil; 1,429 km re
fined products; 6,400 km natural gas
Freight carried: rail—270.5 million metric
tons (1985), 72.3 billion metric ton/km
(1983); highway—469.2 million metric tons
(1983), 8.3 billion metric ton/km (1983); wa- °
terway—14.6 million metric tons (1983), 2.3
billion metric ton/km (1983)
Ports: 4 major (Constanta, Galati, Braila,
Mangalia), 7 minor; principal inland water-
way ports are Giurgiu, Turnu Severin, and
Orsova :
Defense Forces
Branches: Romanian People’s Army, Secu- . -
rity Troops; Patriotic Guard, Air and Air
Defense Forces, Romanian Navy
Military manpower: males 15-49, 5,630,000; .
4,758,000 fit for military service; 202,000
reach military age (20) annually
Military budget: announced for fiscal year
ending 31 December 1985, 12.8 billion lei;
about 3.4% of total budget
207
Bucharest
*
ab ——
Belgrade™','bb7391339f9a1f7d60f8fe99caa1677f769f96db8ee286e9f854bb78ecf5f0ae','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d38a5fa499ab8e20b5277c19ee453d761cd2354b7b5d74e96df31b70d169f2e7',1986,'RW','Rwanda','communications',426,'Kagitumba .
See regional map VII
Land
26,338 km?; the size of Maryland; almost all
arable land; about 33% cultivated; about
33% pasture; 9% forest
Land boundaries: 877 km
St. Christopher and Nevis
St. Lucia
St. Vincent and
the Grenadines
San Marino*','ab32b17515a654e499c71433870e2a3357164058d744db2ad369f1f0f3ad5fd3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('353e7a3cdced5dd9999b10d6b76294683ddeb8f94f72de3d2ca8e16a74e71e7e',1986,'SM','San Marino','communications',430,'2km
See regional map V.
Land .
62 km?; about one-third the size of Washing-
ton, D. C.; 74% cultivated, 22% meadow and
pasture, 4% built on ~
Land boundaries: 34 km
Railroads: none
Highways: about 104 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic ilaphene
system serving 7,700 telephones (25.7 per
100 popl.); no radiobroadcasting or televi- -
sion facilities','d876d4ce1b0c59fdb91dc32264aec8c9cbbe2206981724fbd8027ca6bd888dc4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('540db0a1aa1001edd72ea5b4574497858fcc0005c268a41d274a355d8d6c5ea4',1986,'SN','Senegal','communications',436,'North
Atiantic
Ocean
Boundary representation is
not necessarily authoritative
“See regional map VII
Land
196,192 km?; the size of South Dakota; 40%
agricultural (12% cultivated); 13% forest;
47% built up, waste, or other
Land boundaries: 2,680 km
Water
Limits of territorial waters (claimed)
12nm
Coastline: 531 km
Railroads: 1,034 km 1. 000-meter gauge; 70
km double track ,
Highways: 13,898 km total; 3,461 km ci
6,741 km gravel or graded earth, 3,696 km ;
of unimproved roads
Inland waterways: 1,505 km
Ports: 1 major (Dakar), 2 minor
Civil air: 3 major transport aircraft
Airfields: 25 total, 21 usable; 10 with
permanent-surface runways; 1 withrun- , |
ways 2,440-3,659 m, 16 with runways
1,220-2,439 m
Telecommunications: above-average urban
system, using radio-relay and cable; 40,200
telephones (0.8 per 100 popl.); 8 AM , no FM
stations; 1 TV station; 3 submarine cables; 1
Atlantic Ocean satellite station ;
Defense Forces 3
Branches: Army, Navy, Air Force, paramili-
tary Gendarmerie
Military manpower: males 15-49, ‘L, 551, 000;
782,000 fit for military service; '' 72,000 reach
military age (18) annually
Military budget: for fiscal year ending 30
June 1985, $66.9 million; about 8.8% of cen-
tral government budget.','ba20d5b927804ee21942e28f6b1a0826d57509c8a86dafb6b0ebb9b6ea94b2a0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c203cb968e40764ac8aafe1070dbac7bcc6ab1c337c75f45e4fc08ddd650ef0a',1986,'SC','Seychelles','communications',439,'“300km__.
VICTORIAS ©
i : Mahé
Amirante *
Isles es Islend
Indian Ocean
Aldabra
yisiands 7
me fiw
tx Cosmoledo Farquhar
Group + Group
See regional map VII
Land
280 km2; less than two-thirds the size of New
York City; 54% arable land, nearly all culti-
vated; 17% woods and forest; 29% other -
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 50 or more
coralline islands
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone); mari-
time limits measured from claimed “archi-
pelagic baselines,” which generally connect
the outermost points of outer islands or dry-
ing reefs
Coastline: 491 km (Mahé Island 93 km)
Railroads: none
Highways: 215 km total; 145 km bitumi-
nous, 70 km crushed stone or earth
Ports: 1 port (Victoria); development under-
way will double capacity
Civil air: 1 major transport aircraft
Airfields: 14 total, 14 usable; 2 with
permanent-surface runways; | with run-
ways 2,440-3,659 m
Telecommunications: direct radio commu-
nications with adjacent islands and African:
coastal countries; 9;100 telephones (14.1 per
100 popl.); 2 AM, no FM stations; 1 TV sta-
tion; 1 Indian Ocean satellite station; USAF
tracking station
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 16,000;
8,000 fit for military service ~
Military budget: for fiscal year ending 31
December 1985, $8.5 million, 9.5% of cen- ~
tral government budget
219','666a58418bbb2d007c6c87b1132717b20f0c2c37f845a5077c26e415858959c0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('921a7e82ff3bed923aec1b8bff1ff370593841212485cefdf0f6a6e5501b472d',1986,'SL','Sierra Leone','communications',443,'North
Atlantic
‘Ocean
See regional map VIE. | Sulima te
Land
71,740 km?; slightly smaller than Seaitl.
Carolina; 65% arable (6% cultivated), 27%
pasture, 4% swamp, 4% forest
Land boundaries: 933 km
Water fs
Limits of territorial waters (claimed 3
200 nm
Coastline: 402 km~:
Railroads: about 84 km 1.067-meter narrow
gauge privately owned mineral line oper-
ated by the Sierra Leone Development
Company
Highways: 7,460 km total; 1,225 km bitumi-
nous, 490 km laterite (some gravel), re-
mainder improved earth
Inland waterways: 800 kin; 600 km naviga-
ble year round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft
Airfields: 14 total, 11 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: fair telephone and
telegraph service; 16,000 telephones (0.5 per
100 popl.); 1 INTELSAT Atlantic Ocean
satellite ground station; 3 AM, 1 FM, 2 TV
stations
Defense Forces
Branches: Army, Navy
Military manpower: males 15-49, 876,000;
425,000 fit for military service; no conscrip-
tion
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','ca4dbf9a81e54bb2adbd38dbd69737a8eec631730ee703cea7d7d078f50516b6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fecf23cc7eb111a6432e0de1fcb0433fcf25b6aa8e3750d347076a24ef779f3c',1986,'SG','Singapore','communications',446,'Johore
Strait
S$ sentose
> *
Singapore Strait
S
oo
Se
Main Strait
See regional map IX
Land
618 km2; smaller than New York City; 31%
built on, roads, railroads, and airfields; 22%
agricultural; 47% other
Water
Limits of territorial waters (claimed): 3 nm
(fishing, as defined by treaties and practices)
Coastline: 193 km
Railroads: 38 km.of 1. 000-meter | gauge -
Highways: 2,314 km total (1980); 2,006. km
paved, 308 km crushed stone or improved _
earth.
Inland waterways: none
Ports: 3 major, 2minor:
Civil air: approx. 30 major transport aircraft:
Airfields: 6 total, 6 usable; 6 with 3
permanent-surface runways; 2 with run-
ways over 3,659.m, 2 with runways
2,440-3,659 m, 1 with runways 1,220-
2,439 m
Telecommunications: good domestic facili-
ties; good international:service; good radio,
and television broadcast coverage; 700, 000
telephones (26.5 per 100 popl.); 13 AM, 4
FM, 2 TV stations; submarine cables extend .
to Hong Kong via Sabah (Malaysia), Philip-
pines; 1 ground station to Hong Kong via
Sabah (Malaysia); 1 ground satellitestation
Hagia s
Defense Forces a
Branches: Army, Navy, Air For orce, : Aeany
Reserve, Singapore Armed Forces (SAF).
Military manpower: males 15-49, 771,000;
604,000 fit for military service. - .
Military budget: announced for fiscal yea
ending 31 March 1986, $1.1 billion; about:
11.4% of central government. budget','ce34049b0bebe609eb4d802356b8c96a61b8949707719194d27e776ef5d4b15f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa1c69ed07df94aa526160305a968f92dd988ec06c9451743ab29153ca8bdf29',1986,'SB','Solomon Islands','communications',450,'- South
Pacific
Ocean
Choiseul
ae Santa Isabel
anta Isabe
Gi ~, Xx
, id oS a Qwereite
Yanding GAY
HONIARA ot, '' sone
cad fur
*D con
“ Cristobal ‘g islands.
Coral Sea
See regional map X
Land
NOTE: This archipelagic nation includes -
the southern Solomon Islands, primarily
Guadalcanal, Malaita, San Cristobal, Santa
Isabel, and Choiseul; the northern Solomon
Islands constitute part of Papua New
Guinea.
Land
About 29,785 km; slightly larger than
Maryland
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: about 5,313 km
Railroad: none
Highwavs: 834 km total: 241 km sealed or
all-weather’
Inland waterways: none _
Ports: 5 minor (including Honiara, Gizo,
Yandina) *:
Civil air: no major transport aircraft
Airfields: 24 total, 22 usable; 2 with
permanent-surface r runways; 4 with run-
ways 1,220-2,439m*
Telecommunications: 2,000 telephones; 4
AM, no FM, no TV stations; no TV sets; one
ground satellite station |','8d8184f5d5c8ac439334e2e71698ebee1cb9e01c0901949b5fe27bd6eaf415e2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d112dce208371f263572a3ca3e32ffa3ff5fb399d4001f961183f2df7befc247',1986,'SO','Somalia','communications',454,'2 : : . : fan ne oe
Gulf of Aden
300 km
Boundary representation 1s
nol necessarily authoritative.
indian Ocean
MOGADISHU
i ‘Chisimayu
See regional map VII
Land
637,657 km?; slightly smaller than Texas;
32% grazing; 14% scrub and forest; 13% ara-
ble (0.3% cultivated); 41% mainly desert,
urban, or other’ a
Land boundaries: 2,263 km
Water
Limits of territorial waters (claimed): 200
nm :
Coastline: 3,025 km
Railroads: none
Highways: 17,215 km total; 2,335 km bitu-
minous surface, 2,880 km gravel, and 12,000
km improved earth or stabilized soil
Pipelines: 15 km crude oil
Ports: 3 major (Mogadishu, Berbera,
Chisimayu) - -
_Civil air: 5 major transport aircraft
Airfields: 68 total, 49 usable; 6 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 5 with runways
2,440-3,659 m; 19 with runways 1,220-
2,439 m
Telecommunications: poor telephone and.
telegraph service; radio-relay system cen-
tered on Mogadishu connects a few towns;
6,000 telephones (0.2 per 100 popl.); 1 Indian
Ocean satellite station; 2 AM, no FM sta-
tions; 1 TV station
Defense Forces
Branches: Somali National Army (including
Navy, Air Force, and Air Defense Force),
National Police Force : :
Military manpower: males 15-49, 1,528,000;
825,000 fit for military service; no conscrip-
tion
224
4 400 km -','2d7a44fd65156ca81f19ffbb4ba76ee84380ff482a0d3f4fb789b47038ba8582','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('221cafdec478d1e0d78f92652f1a77ba4e2bf9267e3a49f00a19ce27b096c146',1986,'ZA','South Africa','communications',458,'Awatvis Bay
South
Atlantic
Ocean.
CapeiTown Port Elizabeth
osselbaai
indian ‘Ocean
See regional map VII
Land 2 eo ‘
1,221,037 km? (includes erehivé of- Walvis
Bay, 1,124 km?; Transkei, 44,000 km?, and
Bophuthatswana, 38,000 km2); four-fifths
the-size of Alaska; 86% desert, waste, or ur-
ban; 12% cultivable; 2% forest
Land boundaries: 2,044 km
Water
Limits of aitoniil waters (claimed): 12°
nm (200 nm fishing zone)
Coastline: 2,881 kin, including Transkei
Railroads: 36,499 km total (includes Nam-
ibia); 35,793 km 1.067-meter gauge, of
which 6,830 km are multiple track, 16,271
km electrified; 706 km single track
Highways: 229,690 km total; 80,796 km
paved, 148,894 km crushed stone, gravel, or
improved earth
Pipélines: 931 km crude oil; 1,748 km re-
fined products; 322 km natural gas
Ports: 7 major (Durban, Cape Town, Port
Elizabeth, Richards Bay, Saldanha Bay, East
London, and Mosselbaai)
Civil air: 76 major transport aircraft
Airfields: 922 total, 829 usable; 112 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 10 with runways
2,440-3,659 m, 207 with runways
1,220-2,439 m
Telecommunications: the system is the best
developed, most modern, and highest capac-
ity in Africa and consists of carrier-equipped
open-wire lines, coaxial cables, radio-relay
links, and radiocommunication stations; key
centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and
Pretoria; 3.47 million telephones (13.4 per
100 popl.); 14 AM, 286 FM, 67 main TV sta-
tions with 450 relay transmitters; 1 subma-
rine cable; 1 satellite station with 1 Indian
Ocean and 2 Atlantic Ocean antennas
Defense Forces ©
Branches: Army, Navy, Air Force, Medical
Services
Military manpower: males 15-49, 7,917,000;
4,770,000 fit for military service; 286,000
reach military age (18) annually; obligation
for service in Citizen Force or Commandos
begins at 18; volunteers for service in perma-
nent force must be 17; national service obli-
gation is two years; figures do not include
Bophuthatswana, Transkei, and Venda
Soviet Union
2000 km
Arctic Ocean
“©
x
Baltic Sea
Black
Sea Viadivostok
Baku
The United States Governmen thas not recognized
the incorporation of Estonia, Latvia, and Lithuama
into the Soviet Union. Other boundary representation
. 18 Aot necessarily authortalive.
See regional map VIEH
NOTE: The US Government does not rec-
ognize the incorporation of the Baltic -
States Estonia, Latvia, and Lithuania it into
the Soviet Union.
Land
22,402,200 km?, nearly two and one-half
times the size of the US; 35.5% forest, 16.7%
pasture and hay, 10.1% cultivated, 37.7%
other
Land boundaries: 20,619 km
Water — ‘
Limits of territorial waters elelannals 12
nm (200 nm exclusive economic zone)
Coastline: 46,670 km (incl. Sakhalin)','45283ee32e7b7f81f6c40d38297dce112758590b95842ae92d484272ad551034','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43c21b88535d2c7e761464c898028a31602f8b64c14dadff040647433735944f',1986,'ES','Spain','communications',464,'Railroads: 16,295 km total; Seach National
Railways (RENFE) operates 13,556 km
1.668-meter gauge, 6,156 km electrified, and
2,295 km double track; FEVE (government-
owned narrow-gauge railways) operates
1,821 km of predominantly 1.000-meter
gauge and 441-km electrified; privately
owned railways. operate 918 km of predomi-
nantly 1.000-meter gauge, 512 km electri-
fied, and 56 km double track.
Highways: 150,306 km total; 82,070 km na-
tiorial 2,433 km limited-access divided high-
way, 63,042 km bituminous treated, 17,038
km intermediate bituminous, concrete, or’
stone block; the remaining 68,326 km are
. provincial or local roads (bituminous
treated, intermediate bituminous, or stone
block)
229
Inland waterways: 1,045 km; of mirior im:
portance as transport arteries and contribute
little to economy
Pipelines: 265 km crude oil; 1,862 km re-
fined products; 1,130 km natural gas
Ports: 23 major, 175 minor
Civil air: 142 major transport aircraft
Airfields: (including Balearic and Canary
Islands) 118 total, 114 usable; 61 with
permanent-surface runways; 4 with run-
ways Over 3,659 m, 21 with runways
9,440-3,659 m, 32 with runways 1,220-
2,439 m
Telecommunicatioris: generally adequate,
modern facilities; 18.8 million telephones
(34.5 per 100 popl.); 180°AM, 391 FM, 1,378
TV stations; 2:1 coaxial submarine cables; 2 -
satellite stations with total of 5 antennas
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 9,417,000;
7,652,000 fit for military servicé; 348,000
reach military age (20) anriually .
Military budget: for fiscal year ending 31
December 1984, $3.5 billion; 10.2% of the
central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','492529e0ea7e5967a9397cd3d6580e8e43019ea14dc3c5112ca7919d6b9f9cff','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2185c31d0dd75f5b139db56428fe5ba0cd8278e25bf953a7a7f8b24e33706ad4',1986,'LK','Sri Lanka','communications',465,'100 km.
. Patk
Bay
Mannar®.
Gulf
of
Mannar
See regional map VII indian Ocean
Land
65,610 km2; about one-half the size of North
Carolina; 44% forest; 31% waste, urban, or
other; 25% cultivated
Water :
Limits of territorial waters (claimed): 12
m (200 nm exclusive economic zone).
Coastline: 1,840 km','28e8d76c0ee39d8205bec1416edc59ea754698edf00dbe424b970d1481200e4a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae44b52b6d304e1887b2f9c0533c034ea948b6f016f19b52b0b4faabba811331',1986,'SD','Sudan','communications',472,'Railroads: 5,516 km total; 4,800 km 1.067-
meter gauge, 716 km 1.6096-meter gauge
plantation line
Highways: 20,000 km total; 2,000 km bitu-
minous treated, 4,000 km gravel, 2,304 km
improved earth; remainder unimproved
earth and track .
Inland. waterways: 5,310 km navigable
Pipelines: refined pene 815km
Ports: 1 major (Port Sudan)
Civil air: 13 major transport aircraft
Airfields: 89 total, 77 usable; 9 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m, 29 with runways
1,220-2,489 m
Telecommunications: large system by Afri-
can standards, but barely adequate; consists
of radio relay, cables, radio communica-
tions, and troposcatter; domestic satellite
system with 14 stations; 68,500 telephones
(0.4 per 100 popl.); 4 AM, 1 FM, 2 TV sta- -
tions; 1 Atlantic Ocean satellite station
Defense Forces *%
Branches: Army, Navy, Air Force, Air De-
fense Force
Military manpower: males 15-49, 5,275,000;
3,224,000 fit for military service; 241,000
reach military age.(18) annually
Military budget: for fiscal year ending 30
June 1985, $534.1 million; 17.7% of central
government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4 ~
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','9ce450caf9d50bbc63b0fc873258ce48f48e9ed4c4f2b66056f85174aea98f23','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9540510b904a4046dbce8aa25fa5ec46137748fe17c6184fb68f7d22c8ceee21',1986,'SR','Suriname','communications',473,'North Atlantic Ocean
See regional mapIV
Land
163,265 km? slightly larger than Georgia;
negligible arable land, meadow and pasture;
76% forest; 16% built on, waste, or other; 8%:
unused but potentially productive
Land boundaries: 1,561 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 386 km
Railroads: 166 km total; 86 km 1.000-meter
gauge, government owned, and 80 km
1.435-meter standard gauge; all single track
Highways: 8,300 km total: 500 km paved;
5,400 km bauxite gravel, crushed stone, or
improved earth; 2,400 km sand or ‘clay
Inland waterways: 1,200 km; most impor-
tant means of transport; oceangoing vessels
with drafts ranging from 4.2 m to 7 m can
navigate many of the principal waterways
while native canoes navigate upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 2 major transport aircraft
Airfields: 42 total, 40 usable; 4 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,489 m
Telecommunications: international facili- _
ties good; domestic radio-relay system;
27,500 telephones (6.3 per 100 popl.); 4 AM,
4 FM stations; 1 TV station; 2 Atlantic satel-
lite stations
Defense Forces
Branches: National Army (including Infan-
try Battalion, Military Police Brigade, Navy
[company-size]; Air Force)
Military manpower: males 15-49;72,000;"°
43,000 fit for military service ©
Military budget: 1988, $41.8 million; 8.2% _
of central government budget
Swaziland
50 km
See regional map Vil
Land
17,363 km?; slightly smaller than New Jer-
sey; mostly crop or pasture
Land boundaries: 435 km
Railroads: 515 km 1.067-meter gauge, single
track
Highways: 2,853 km total; 510 km paved,
1,230 km crushed stone, gravel, or stabilized
soil, and 1,113 km improved earth
Swaziland','a8ec22403909e9e1f1a00859c19b1c5ded835211755837924a59b44be95b5dca','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6436bee9a158f080ea8abec5cbecc7d2f473b624a79b7a0b3530fe2b2b458564',1986,'SE','Sweden','communications',477,'Civil air: 6 major transport aircraft reearerre:
—400 km
Airfields: 27 total, 27 usable; 1 with runways
2,440-3,659, 1 with runways 1,220-2,439 m
: : Tarnaby, ulea
Telecommunications: system consists of
carrier-equipped open-wire lines and low Baie
capacity radio-relay links; 15,400 telephones me
(2.3 per 100 popl.); 4:AM, 8 FM, 11 TV sta- as
tions; Atlantic Ocean satellite station
Defense Forces’ OU diarlatoaks
Branches: Umbutfo Swaziland Defense Goteborg} eae
soe tee Baltic Sea
Force, Royal Swaziland Police Force Kattegat
Malm¢e
Karlskrona
See regional map V - :
Military manpower: males 15-49, 151,000;
87,000 fit for military service
Land | ;
449, 964 km?; larger than California; 55%
forest, 7% arable, 2% meadow and pasture,
86% other ;
Land boundaries: 2196 km
Water 4 yee DS
Limits of territorial waters (claimed): 12
nm (fishing 200 nm)
Coastline: eal
People oF
Population: 8, 357 000 (J uly igae average
annual growth rate 0.1%.
Nationality: noun—Swede(s ); adjective—
Swedish 7
E white distor: homogeneous white popu-
lation; small Lappish minority; est. 12% for-
eign born or first generation immigrants.
(Finns, Yugoslavs, Danes, Norwegians,
Greeks)
Rélision: 93.5% Evangelical Lutheran, 1.0%.
Roman Catholic, 5.5% other
Language: Swedish, small Lapp- and
Finnish-speaking minorities; immigrants
speak native languages
Infant mortality rate: 7/1,000 (1983)
Life expectancy: men 75, women 81
235
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Sweden (continued)
Literacy: 99%
Labor force: 4.41 million (1984); 32.8% pri-
vate services; 30.0% government services;
22.0% mining and manufacturing; 5.9% con-
struction; 5.0% agriculture, forestry, and
fishing; 0.9% electricity, gas, and water-
works; 3.1% unemployed (1984 average)
Organized labor: 90% of labor force (1985
est.)
Railroads: 12,518 km total; Swedish State
Railways (SJ)—11,179 km 1.435-meter
standard gauge, 6,959 km electrified and
1,152 km double track; 182 km 0.891-meter
gauge; 117 km rail ferry service; privately
owned railways—511 km 1.435-meter
standard gauge, 332 km electrified; 371 km
0.891-meter gauge electrified
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Highways: classified network, 97,400 km, of
which 51,899 km paved; 20,659 km gravel;
24,842 km‘unimproved earth
Inland waterways: 2,052 km navigable for
small steamers and barges
1Pipelines: 84 km natural gas
Ports: 17 major and 30 minor
Civil air: 65 major transports
Airfields: 263 total, 259 usable; 135 with
permanent-surface runways; 9 with run-
ways 2,440-3,659 m, 88 with runways
1,220-2,439 m
- Telecommunications: excellent domestic
and international facilities; 7.41 million tele-
phones (89.0 per 100 popl.); 4 AM, 345 FM,
810 TV stations; 9 submarine coaxial cables,
2 Atlantic Ocean satellite antennas, 1 Eu-
telsat antenna
Defense Forces
Branches: Royal Swedish Army, Royal
Swedish Air Force, Royal Swedish Navy
Military manpower: males 15-49, 2,091,000;
1,465,000 fit for military service; 62,000:
reach military age (19) annually
Military budget: for fiscal year ending 30
June 1985, $2.5 billion; 6.5% of central gov-
ernment budget','322f5d6ba699fe9256e9cc48fb4a1261f21195d738bdd62c50208370738e0d9e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed789dbd48f621cbea6e648c57e4083df931b5ba0bf4bf67fb5558d272834905',1986,'CH','Switzerland','communications',480,'Schaffhausen
Bodensee
See regional map V
Land
41,228 km; the size of Massachusetts, Con-
necticut, and Rhode Island combined; 438%
meadow and pasture, 24% forest, 20% waste
or urban, 3% inland water
Land boundaries: 1,884 km
Railroads: 5,155 km total; 2,952 km govern-
ment owned (SBB), 2,879 km 1.435-meter
standard gauge; 74 km 1.000-meter narrow |
gauge; 1,432 km double track, 99% electri-
fied; 2,203 km nongovernment owned, 710
krn 1.435-meter standard gauge, 1,418 km
1.000-meter gauge, 75 km 0.790-meter
gauge, 100% electrified
Highways: 62,145 km total (all paved), of
which 18,620 km are canton and 1,057 km
are national highways (740 km autobahn);
42,468 km are communal roads
Pipelines: 314 km crude oil; 1,046 km natu-
ral gas
Inland waterways: 65 km; Rhine River—
Basel to Rheinfelden, Schaffhausen to
Bodensee; in addition, there are 12 naviga~
ble lakes «
Ports: 1 major (Basel), 2 minor (all inland)
Civil air: 89 major transport aircraft
Airfields: 73 total, 71 usable; 42 with
permanent-surface runways; 2 with run-
ways over 3,660 m, 6 with runways
2,440-3,659 m, 16 with runways 1,220-
2,439 m
238
Telecommunications: vexcellent domestic,
international, and broadcast services; 5. ll
million telephones (78.9 per 100 popl.); 6
AM, 250 FM, 1,253 TV stations; 1 satellite
station with 3 Atlantic Ocean antennas
Defense Forces
Branches: Army, Air Force
Military manpower: males 15-49, 1,695,000;
1,465,000 fit for military service; 50,000
reach military age (20)annually —
Military budget: proposed for fiscal year
ending 31 December 1984, $1.9 billion;
20.6% of proposed central government bud-
get
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Syria
150 km
Boundary representation is
not necessarily authoritative
See regional map we
Land
185,180 km? (including 1,295 km? of Israeli-
occupied territory); the size of North Da-
_kota; 48% arable, 29% grazing, 21% desert,
2% forest
Land boundaries: 2,196 km (1967); excludes
2,156 km occupied area
Water -
Limits of territorial waters (claimed):
35 nm
Coastline: 193 km
Railroads: 1,543 km total; 1,281 km stan-
dard gauge, 262 km 1.050-meter narrow
gauge
Highways: 16,939 km total; 12,051 km
paved, 2,625 km gravel or crushed stone,
2,263 km improved earth
Inland waterways: 672 km; of little impor-
tance
Pipelines: 1,304 km crude oil; 515 km re-
fined products
Ports: 8 major (Tartus, Latakia, Baniyas), 2
minor
Civil air: 14 maior transport aircraft
Airfields: 95 total, 90 usable; 27 with
permanent-surface runways; 21 with run-
ways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: fair system currently
undergoing significant improvement;
512,600 telephones (5.3 per 100 popl.); 9
AM, no FM, 40 TV stations; 1 Indian Ocean
satellite station; ] Intersputnik satellite sta-
tion under construction; 1 submarine cable;
coaxial cable and radio-relay to Iraq, Jordan,
Turkey, and Lebanon (inactive)
Defense Forces
Branches: Syrian Arab Army, Syrian Arab
Air Force, Syrian Arab Navy
Military manpower: males 15-49, 2,403,000;
1,347,000 fit for military service; about
113,000 reach military age (19) annually
Tanzania
300 km _
Pemba
a
Lake
Nyasa
See regional map VII
Land 5
942,623 km? (including islands of Zanzibar
and Pemba, 2,642 km2); more than twice the
size of California; forest 45%, meadow and .
pasture 37%, inland water 6%, arable 4%,
crop 1%, other 7%
Land boundaries: 3,883 km
Water ; :
Limits of territorial waters (claimed):
50nm— faa 3
Coastline: 1,424 km (this includes 113 km
Mafia Island, 177 km Pemba Island, and 212
km Zanzibar) ; ;
Railroads: 3,555 km. total; 960 Gi 1.067-
meter gauge; 2,595 km’ 1.000-meter gauge,
6.4 km double track, 962 km Tan-Zam Rail-
road 1.067-meter gauge in Tanzania; 115
km 1.000-meter gauge planned by end of
decade
Highways: total 34,500 km, 3,600 km paved;
5,600 km gravel or crushed stone; remainder
improved and unimproved earth
Pipelines: 982 km crude oil
Inland waterways: several thousand km
navigable on Lakes Tanganyika, Victoria,
and Malawi; principal inland waterway
ports are Mwanza on Lake Victoria and
Kigoma on Lake Tanganyika .
Ports: 3 major (Dar es Salaam, Mtwara,
Tanga)
Civil air: 7-major transport aircraft
Airfields: 100 total; 93 usable; 12 with
permanent-surface runways; 3 with run-
ways 2,440-8,659 m, 45 with runways
] ,220- 2,439 m .
241°
Telecommunications: fair system of open
wire, radio relay, and troposcatter; 103,800
telephones (0.6 per 100 popl.); 6 AM, no FM, :
2 TV stations; 1 Indian Ocean satellite sta-
tion
Détensé Forces
Branches: Tanzanian People’ s Berens
Force includes Army, Navy, and Air Force;
paramilitary Police Field Force Unit
Military manpower: males 15-49, 4,712,000; .
2,706,000 fit for military service
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Syria
Tanzania','a5c956b9fa81b452e03fb734ee5aa740b2a15dea2fb49cde208cf138f6520bc0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d9cab56867b37a8186d20d22569fedda8075fe059f6f3b818bda000a5b35f74',1986,'TH','Thailand','communications',484,'Gulf of
Andaman, Thailand .
Sea
Phuket ¥&
See regional map IX
eal
Land
514,820 km?; about the size of Texas: 56% |
forest, 24% farm, 20% other .
Land boundaries: 4,868 km
Water ;
Limits of territorial waters jeuiniady, 12 -
nm (200-nm exclusive economic zone)
Comin’: 3,219 km
Railroads: 3,940 km 1.000-meter gauge, 99
km double track
Highways: 44,534 km total; 28,016 km
paved, 5,132 km earth surface, 11,386 km
under development , .
Inland waterways: 3,999 km principal wa-
terways; 3,701 km with navigable depths of
0.9 m or more throughout the year; numer-
ous minor waterways navigable by shallow-
drat native craft
Pichade natural gas, 350 km; refined Lied:
ucts, 67 km
Pon 2 major, 16 minor
Civil air: 30 (plus 2 teased) major transport *
aircraft :
Airfields: 131 total, 104 usable; 57 with
permanent-surface runways; 1 with run- «
ways over 3,659 m, 13 with runways
2,440-3,659 m,:27 with runways 1,220-
2,439 m
Telecommunications: service to general’
public adequate; bulk of service to govern-
ment activities provided by multichannel
cable and radio-relay network; satellite
ground station; domestic satellite system -
being developed; 496,558 telephones (1.1
per 100 popl.); approx. 150 AM, 20 FM, 10
TV transmitters in government- controlled
networks
Defense Forces
Branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps),
Royal Thai Air Force
Military manpower: males 15-49,
13,536,000; 8,307,000 fit for military service;
about 631,000 reach military age (18) annu-
ally
Military budget: for fiscal year ending 30°
September 1986, $1.5 million (est.); 18.9% of
central government budget
Jogo
See regional map vit " Bight of Benin, :
Land : oe
56,980 km2; slightly aioe than West Vir :
ginia; nearly 50% arable, under 15% pul :
vated :
Land boundaries: i 46k ee
Water
Limits of enriterial waters (claimed): 30
nm (200 nm rexclusive economic ¢ zone)
Coastline: 56 km
People a
Population: 8, 118,000 uly 1986) average
annual growth rate 3.1%
Nationality: sone ree lees (sing. and pl.); *
adjective—Togolese ;
Ethnic divisions: 37 tribes; largest and most
important are Ewe, Mina, and Kabyé; under
1% European and Syrian-Lebanese
Religion: about 70% indigenous beliefs, 20%
Christian, 10% Muslim
Language: French, both official and lan- ”
guage of commerce; major African =
languages are Ewe and Mina in the south
and Dagomba and Kabyé in the north’.
Infant mortality rate: 112/1,000 (1983)
Life expectancy: 47 -_
Literacy: 18%...
- 243
Labor force: 78% agriculture, 22% industry;
about 88,600 wage earners, evenly divided
between public and private sectors
Organized labor: one national union, the
National Federation of Togolese Workers','60f8707162c3298811d94abc34ac70885552bc126ca92e8dadebf92a7c36a664','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('339642454409be693260d7c3aaa30040245ab6766b178ca0127bbec8c025dc58',1986,'TK','Tokelau','communications',491,'Railroads: none... -...
Ports: no harbor facilities; off-shore anchor-
ages
Airfields: none; lagoon landings by amphibi-
ous aircraft from Samoa
Telecommunications: telephone service
links islands to each other and to Western
Samoa (1985)
Defense Forces
Defense is the responsibility of New Zealand
245','c2d291dae08072a2377f8ad7e03d179b20a62989d022a88a65f2e1209a67e95a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4074aa49b463f8b2edf500102ceb4be59efd523430b9f3797ecc78ab9e6053d0',1986,'TO','Tonga','communications',492,'a
200 km __ * Nivato’ou : Tafahi
Niuatoputapu
Vava''u-,
Group wNeiafu
Ha‘apai bs
Group * +33
NUKU‘ALOFA® |
7
Tongatapu
Group
7 Minerva Reef not shown
See regional map x
Land
997 km? (169 islands, only 36 inhabited);
smaller than New York City; 77% arable,
13% forest, 3% pasture, 3% inland water, 4%
other
Water he ee |
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 419 km (est.) 3
Railroads: none
Highways: 198 km sealed road (Tongatapu);
74 km (Vava’u); 94 km Hnseded roads usable
only in dry weather
Inland waterways: none
Ports: 2 minor (Nuku''alofa, Neiafu)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 1 with
permanent-surface runways 1;220-2,439 m-
Telecommunications: 2,608 telephones (1.4
per 100 popl.); 65,000''radio sets; no TV sets;
1 AM station; 1 ground satellite station -
Defense Forces
Branches: Land Force, Maritime Force ~
246,','35742798942a6d56d57a993f316a92ddb7e80113eee3b8b328681f49cb9b6c35','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e97b2675934b855e8fa02b2b909a397caeb2cf7a2aea16f2a7e3f6d9fd42ec1',1986,'TT','Trinidad and Tobago','communications',496,'Z 50 km
1 Caribbean Sea
To
PORT-OF- SPAIN''
Guilt of Paria
Guayaguayare
See regional map II”
Land. » 2
5,128 km the size of ielawvares ‘41.9% farm
(25.7% euldvated or fallow, 10.6% forest,
4.1% unused or built on, and 1.5% pasture);
58.1% grassland, forést, built on, wasteland,
and other
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive économic zone)
Coastline: 362 km
People Bes
Population: 1,204, 000 0 uly 1986), average
annual Brome rate 1.5%
Nationality: contenant ),
Tobagan(s); adjective—Trinidadian,
Tobagan ;
Ethnic divisions: 43% black, 40% East In- -
dian, 14% mixed, 1% white, 1% Chinese, 1%
other
Religion: 36.2% Roman Catholic, 23.0%
Hindu, 13.1%, Protestant, 6. 0% Muslim,
21.7% unknown
Language: English (official), Hindi, French,
Spanish :
infant morta rate: 191/ 1,000 (1982)
Life speouaney men 65. women 70
Literacy: 89%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Scarborough
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: about 470,900 (est. 1984); 16.6%
mining, quarrying, and manufacturing;. -
22.7% commerce; 20.9% construction and
utilities; 8.3% agriculture; 7.8% transporta-
tion and communication; 23.7% other ser-.
vices (1983); 12% Aremployment rate (1984
est.)
Organized labor: 40% of labor force (1984)
Railroads: minimal derieultutal system n near’
San Fernando een
Highways: 8,000 km total; 4,000 km paved,-..
1,000 km improved earth,.3,000 km-unim- | ..
proved earth
Pipelines: 1,082 km crude oil; 19 km refined ;
products; 904 km natural gas
Ports: 1 major (Port-of-Spain), 8 minor
Civil air: 14 major transport aircraft we ; .
Airfields: 7 total, 5 usable; 3'' with ee
permanent-surface runways: 1 withrun-
ways 2,440-3,659 m, 3 with runways”
1,220-2,439 m og
Welecdrninuiications excellent interna-
tional service via tropospheric-scatter links ..”.
to Barbados and Guyana; good local service;
1 Atlantic Ocean satellite station; 109,000...
telephones (9.6 per. 100 popl.); 2 AM, 3.FM, 5.
TV stations | Booed ee ee
Defense Forces
Branches: Trinidad and Tobago Defense ,.. ;
Force, Trinidad and Tobago Police Service
Military manpower: males 15-49, 345,000;
247,000 fit for military service
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','bc39b504d2053316c2d1fff08a12e9155ecdb6f549f71d94c5746eec5e7b0820','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef259d8e6f07b7b9d606763ee5c760525ad46780fbf433049a5ffeb1871d2a13',1986,'TN','Tunisia','communications',499,'a Bizerte
200 km
Nabul
Susah
5 Mediterranean
Sea
Ta
See regional map VII
Land
163,610 km2; about the size of Missouri; 48%
desert, waste, or urban; 28% arable and tree
crop; 23% range and esparto grass; 6% forest
Land boundarieés:.1,408 km
Water
Limits of territorial waters (claimed):
12 nm
Coastline: 1,148 km (includes offshore is-
lands)
Turkey ; -
Tuvalu ¢
Mediterranean Sea
glelpoli
CIA-RDP08-00534R000100170001-4
Africa
40
Banghi
Al Jawf. . -
Alexendtfa
Cairo¥
Tropic of Cancel — —
_ MAURITANIA
Im,
f Nouakchott
.
Dakar,
eri .
Banjul
GAMBIA} |
Biss BURKINA
GUINEA*:- 5 te
gissau GUINEA” Ouagadougou : Kano,
Conakry"
Freetown S
SIERRA LEQNE IVORY pO
a coast {GHANA
Monrovia®.
LIBERIA) apidjan, 1, Accra
: =
EQUATORIAL,
Gulflof Guinea GquinEa
SAO TOME AND +
PRINCIPE
Séo Tomé »
Faya-*
Largeau','9f40582a8190c3eb63f8a6f5fc4c38c7902f918160204c74aa5acf0dd0ba8b1d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('144cab213e0a36c11cd6329a352814fd5ed3ba055e33d75524f04e4ff8ea98ed',1986,'TC','Turks and Caicos Islands','communications',506,'Railroads: none’
Highways: 121 km, including 24 km tarmac
Ports: 4 major (Grand Turk, Salt Cay,
Providenciales, Cockburn Harbor)
Civil-air: Air Turks and Caicos (passenger
service) and Turks Air Ltd. (cargo service)
Aitfields: 8 total,’7 usable; 4 with
permanent-surface runways; 4 with run-
ways 1,220-2,489 m
Telecomminications: fair cable and.radio
services; 1,400''telephones (16.9 per 100
popl:); 1 AM station; 2 submarine’cables, 1
satellite ground station ;
Defense Forces
Defense is the responsibility of the United
Kingdom 2
Branches: police
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4 |','c5c43766c5abd989d3516e2d06fbbea1323a60d57a2bad266f0cfee47d8f1a95','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40e96c65604236c755c2e05eba52562bf11243001e05214125c1193cd909d061',1986,'TV','Tuvalu','communications',507,'(formerly Ellice Islands)
Nanumea 150 km
Niutao
°
*Nanumanga
Nui
° .
,Vaitupu
Nukufetaug
FUNAFUTI &—>-0
Funafuti
South
Pacific :
Ocean Nukulaelae
Nurakita -
See regional map X bs
NOTE: On 1 October 1975, by Constitu-
tional Order, the Ellice Islands were for-
mally separated from the British colony of
Gilbert and Ellice Islands, thus forming
the colony of Tuvalu. The remaining is-
lands in the former Gilbert and Ellice Is-
lands Colony are now named Kiribati.
Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao,
Vaitupu, and the four islands of the
Tuvalu group formerly claimed by the
United States—Funafuti, Nukufetau,
Nukulaelae, and Niulakita
Land
26 km2; less than one-half the size of Man-
hattan; low-lying atolls composed of coral
reefs _
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 2 minor (Funafuti, Nukufetau)
Civil air: no major transport aircraft
Airfields: 1 usable with runways 1,220-...
2,439 m
Telecommunications: 1 AM station; about
300 radio telephones (0.5 per 100 popl.);
4,000 radio sets :
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','96622f467b1a4ee94b75c5b56ddfd9b6a74d050160d56e32318c7350183434b8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ada970e55c6ebf9810b75227be947b53138c3f061c76c2124ded552f4eb5499',1986,'UG','Uganda','communications',511,'4 Lake
Victoria
See regional map VII
Land
235,885 km?; slightly smaller than Oregon;
45% forest, wood, and grass; 21% inland wa-
ter and swamp, including territorial waters
of Lake Victoria; about 21% cultivated; 18%
national park, forest, and game reserve
Land boundaries: 2,680 km
Railroads: 1,300 km, 1.000-meter gauge sin-
gle track
Highways: 30,500 km total; 3,500 km paved;
7,000 km crushed stone, gravel, and laterite;
remainder earth roads and tracks
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Uganda (continued) -
sacibeasbah Vang oS
Inland waterways: Lake Victoria, Lake ;
Albert, Lake Kyoga, Lake George, Lake
Edward; Victoria Nile, Albert Nile; princi-
pal inland water ports are at Jinja.and Port
Bell, both on Lake ahora a
Civil air: 5 ma {Ox transport aircraft
Airfields: 39 aut 34 usable; 5 sath
permanent-surface runways; 1 with run-
ways over 3,659 m, 3 with runways
2,440-3,659 m, 11 with runways 1,220-
2,439 m
Telecommunications: fair system with’. |.
radio-relay and radio communications sta-
tions in use; 61,600 telephones (0.5 per 100
popl.); 9 AM, no FM, 9 TV stations; 1 Atlan- .
tic Ocean INTELSAT station.
Defense Forces
Branches: new government plans to reorga-
nize national army; formerly, the defense...
forces consisted of the Uganda National Lib:
eration Army (including army and air force) .
and a paramilitary Police Special Force
Military manpower: males 15-49, about “s''
3,316,000; about 1,785,000 fit for military.
service
United Arab Emirates |
125km |
Boundary representation is
not Necessarily authoritative.
See regional map VI
Land.
83,600 km?; the size of Maine; almost. ail | ;
desert, waste, or urban
Land boundaries: 1,094 km (does not in-
clude boundaries between adjacent UAE’
states)
Water
Limits of territorial waters (claimed): to
agreed center boundaries or median lines
Coastline: 1,448 km
Railroads: none
Highways: 2,000 km total; 1,800 km bitumi-
nous, 200 km gravel and gradedearth
Pipelines: 830 km crude oil; 870 km natural
gas, including natural gas liquids
Ports: 7 major, 25 minor
Civil air: 4 major transport aircraft
Airfields: 42 total, 31 usable; 19 with’
permanent-surface runways; 5 with run-
ways over 3,659 m, 4 with runways
2,440-3,659 m, 6 with runways 1,220-
2,439 m
Toleconunanieaiions: adequate system of ©
radio-relay and coaxial cable: key centers
are Abu Dhabi and Dubayy; 281,000 tele-
phones (25.0 per 100 popl.); 8 AM, 3 FM, 9
TV stations; 3 INTELSAT stations with |
Atlantic and 2’ ‘Indian Ocean antennas; Arab
satellite ‘station under construction; subma-
riné-cable to Qatar and Bahrain; planed sub-
marine.cables-to India and Pakistan; tropo-*:
spheric scatter to Bahrain; radio-relay to.»
Union of Soviet Socialist
Republics','965ea0f4a28533efb62759710b0e9bcec0a9f631c5ae236da03f5ee1e7f51f9c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05bf944509dd04d2f38e68d004a2f5746e34be7d5efcf99cc284b15d43b37d1',1986,'GB','United Kingdom','communications',515,'__300.km__. : ‘Shetland
: : Islands
: : ¢ Onkiiey
* : Islands
Hebrides (2
‘ North
_ North Sea
Atlantic
Ocean
[:} Newcastle
English Channel
See regional map Vv
Land :
243,977 km2; slightly smaller than Oregon; ~
50% meadow and pasture, 30% arable, 12%
waste or urban, 7% forest, 1% inland water
Land boundaries: 860 km
Water
Limits of territorial waters (claimed): 3 nm
(fishing 200 nm)
Coastline: 12,429 km','a9831428e887050ccd48a439e06c42b962375b08cb887565db49baa7576b1d1d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5d89a5ceaff0f427f3d56da97761f2ddc6202812610701c7e831b3877321627',1986,'UY','Uruguay','communications',522,'Railroads: 3,000 km, all! 1.435-meter stan-
dard gauge (1.435 m) and government
‘owned
Highways: 49,900 km total; 6,700 km paved,
8,000 km gravel, 40,200 km earth
Inland tbaterivays: 1,600 km; used by
coastal and shallow-draft river craft
Ports: | major (Montevideo), 9 minor
Civil air: 14 major transport aircraft
Airfields: 93 total, 89 usable; 14 with
permanent-surface runways; 2 with run-
ways 2;440-3,659 m, 14 with runways
1,220-2,439 m
Telecommunications: most modern facili-
ties concentrated in Montevideo; new na-
tionwide radio-relay network 337,000 tele-
phones (11.8 per 100 popl.); 100 AM, 36 TV
stations; 2 Atlantic Ocean satellite stations
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 682,000;
554,000 fit for military service; no conscrip-
tion','aa9d66dedec903f4a9e6dec12529d5726f950fdf48bc75b14648c0046aba1fce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caf9ed8e56213dde9d0fdc684bfc150faee5e2cda1c0031e8cb8518e334a05fe',1986,'VU','Vanuatu','communications',523,'(formerly New Hebrides)
. : 200 km
South
. Pacific Ocean
Epi .*
ne faté
PORT- VILA
Coral Sea
Qe rromango
Tanna’
Anatom
See regional map X ma? .
Land
About 14,763 km?; about the size of Con-
necticut; over 80 islands
Water
Limits of territorial waters: 12 nm (200 nm”
exclusive economic zone); maritime limits
measured from claimed “archipelagic
baselines; which generally connect the out-
ermost points of outer islands or drying reefs
Coastline: about 2,528 km
Railroads: none
Highways: at least 240 km sealed or
all-weather roads
Inland waterways: none
Ports: 2 minor (Port-Vila, Santo)
Civil air: no major transport aircraft
Airfields: 31 total, 25 usable; 2 with
permanent-surface runways, 2 with run-
ways 1,220-2,439 m
Telecommunications: 2 AM stations; 2,400
telephones (2.4 per 100 popl.); 1 ground sat-
ellite station under construction
Defense Forces
Personnel: no military forces maintained;
however, a paramilitary force is responsible
for internal and external security
Vatican City
250 meters
See regional map v
Land
0.438 km?
Land boundaries: 3 km
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 2 AM and 2 FM sta- :
tions; 2,000- line automatic telephone ex-
change
Defense Forces iz :
Defense is the responsibility of Italy a
Venezuela
oo
400km
Caribbean Sea . .
Boundary representation is «
not necessarily authoritati
See regional map IV" | ¢
Land +.
912,050 km?; more than twice the size of
California; 21% forest;''18% pasture; 4%
cropland; 57% urban, waste, or other
Land boundaries: 4,181 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 2,800 km
People hi
Population: 17, 791 000 July 1986), average
annual growth rate 2. 7%
Nationality: noun—Venezuelan(s); adjec-
tive—Venezuelan
Ethnic divisions: 67% mestizo, 21% white,
10% black, 2%, Indian
Religion: 96% nominally Roman Catholic,
2% Protestant
Language: Spanish (Gtficial) jhdian dialeats
spoken by about 200,000 Amerindians in the
remote interior
Infant mortality rate: 36.2/1,000 (1984)
Life expectancy: men 64.0, women 69.0
Literacy: 85.6%
262
Labor force:''5.9 million (1985), 27% services;
22% commerce; 16% agriculture; 16% man-
ufacturing; 9% construction; 7% transporta-
tion; 3% petroleum, utilities, and other;
13.4% ‘unemployment (1984)
Organized. labor: 32% of Jabor force
Vatican City* =
Venezuela |
Vietnam ° |
Western Samoa .
Yemen Arab Republic J «
TEE
Yemen, People’s Demo-
cratic Republic of
Yugoslavia
ie ]
Zaire + =
Zambia ; |
Zimbabwe It |
Taiwan ¢ spet- |
290
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
United Nations Organizations
FAO GATT IAEA
UPU WHO: ‘WMO
ITU UNESCO
IMO
IDA IFAD IFC ILO IMF
IBRD ICAO .IC]
OPEC SELA WFTU
OAU OECD OIC
291
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
The World (Guide to Regional Maps)
L','64b692f438e5b4ee9652d0c876860a898605afc7b3ae6db3249d273d7a67d84f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2b88dfbc1e4aee48c3ddbd3b04a9d3cae8dded3c7a463c60178d58d24e1c92c',1986,'WF','Wallis and Futuna','communications',527,'50km
MATA-UTU,
ite uvéat 4
South Pacific Ocean
fle Futuna
qieava
en
He Alofi
See regional map X
Land
About 207 km?; about the size of New York
City
Water
Limits of territorial waters: 12 nm (200 nm
exclusive economic zone)
Coastline: about 129 km
Railroads: none
Highways: 100 km of improved road on
Uvea Island (1977)
Inland waterways: none
Ports: 2 minor
Airfields: 2 total; 2 usable; 1 with
permanent- -surface runways 1,220-2,439 m
Telecommunications: 148 telephones (1.2
per 100 popl.)
Defense Forces
Defense is the responsibility of France
265
Western Sahara _
(formerly Spanish Sahara)
200 km
North
Atlantic
Ocean
See regional map VI!
Land
266,770 km?; Jarger than Utah; nearly all
desert
Land boundaries: 2,086 km
Water
Limits of territorial waters (claimed): 6 nm.
(fishing 12 nm)
Coastline: 1,110 km
Railroads: none
Highways: 6,100 km total; 1,350 km sur-
faced, 4,750 km improved and unimproved
earth roads and tracks
Ports: 2 secondary (El Aaitin, Ad Dakhla)
Airfields: 16 total, 16 usable; 3 with
permanent-surface runways, 3 with run-
ways 2,440-3,659 m, 7 with runways
1,220-2,439 m
266
Western Samoa
$0 km
South Pacific Ocean
South Pacific Ocean
See regional map X
Land .
2,934 km? the size of Rhode Island; com-
prises of 2 large islands of Savai’i and Upolu
and several smaller islands, including
Manono and Apolima; 65% forest; 24% culti-.
vated; 11% industry, waste, or urban .
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 403km.. -
Railroads: none
Highways: 784 km total; 375 km bitumi-
nous, remainder mostly gravel, crushed
stone, or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 3 major transport aircraft
Airfields: 4 total, 4 usable; 1 with
permanent-surface runways 1,220-2,439 m
Telecommunications: 3,800 telephones (2.5
per 100 popl.0; 50,000 radio receivers; 1 AM
station
Defense Forces
Military manpower: males 15-49, 39,000;
20,000 fit for military service
267
(mixed)
Yemen Arab Republic.
(North Yemen)
km
Boundary representation is
not necessarily authoritative.
See regional map VI ::.
Land
194,250 km? (parts of border with Saudi —
Arabia and People’s Democratic Republic of
Yemen undefined); slightly smaller than
South Dakota; 79% desert, waste, or urban;
20% agricultural; 1% forest
Land boundaries: 1,528 km
Water... -
Limits of iationGh waters unned ):
12nm
Coastline: 523-km. ie
Railroads: none
Highways: 4,000 km total; 1, 775 km biturni-
nous; 500 km crushed stone and gravel;
1,725 km earth, sand, and light gravel
Ports: 1 major (Al Hudaydah), 3 minor
Civil air: 9 major.transport aircraft
Airfields: 20 total, 14 usable; 4 with
permanent-surface runways; 6 with run-
ways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: system poor but im-
proving; new radio-relay and cable
networks; 50,000.telephones (0.9 per 100
popl.); 8 AM, no FM, 5 TV stations; 1 Indian
Ocean, ] Atlantic Ocean, and 1 Arab satel-
lite station; tropospheric scatter to South','077bf0545fa13878f2e86c7e94e7c4df8836dbbea28ea88fa56311ee9fbd2db7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10ddb893accb7c8e4bd21e5fccdfd7b68a5742d5f9027b538f38fa6c8d8e73cc',1986,'YE','Yemen','communications',531,'Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 1,193,000,
664,000 fit for military service; about 69,000
reach military age (18) annually
~ 268
Yemen, People’s
Democratic Republic
of (South Yemen)
300 km
Boundary representation is
not necessarily authoritative.
Arabian
Sea
e
Kamaran
Socotra
* ADEN a
Gulf of Aden
Perim
See regional map VI
Land
322,968 km?; the size of Nevada; (border
with Saudi Arabia and Yeman Arab Repub-
lic undefined); only about 1% arable (of
which less than 25% cultivated)
Land boundaries: 1,802 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 1,383 km
Railroads: none
Highways: 5,600 km total; 1,700 km bitumi-
nous treated, 680 km crushed stone and
gravel, 3,270 km motorable track -
Pipelines: refined products, 32 km -
Ports: 1 major (Aden), 5 minor
Civil air:9 major transport aircraft
Airfields: 41 total, 30 usable; 7 with
permanent-surface runways; 10 with run-
ways 2,440-3,659 m, 12 with runways
1,220-2,439 m :
269
Telecommunications: small system of open-
wire, radio-relay, multiconductor cable, and
radio communications stations; only center
Aden; estimated 15,000 telephones (0.6 per
100 popl.); 1 AM, no FM, 5 TV stations; 1
Indian Ocean satellite antenna; tropospheric
scatter to North Yemen
Defense Forces
Branches: Army, Navy, Air Force, People’s
Militia, People’s Police :
Military manpower: males 15-49, 498,000;
276,000 fit for military service
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Yugoslavia
150 km
See regional map V
wee ie
Land
255,804 km?; the size of Wyoming; 34% for.
est, 32% arable 25% meadow and pasture,
9% other
Land boundaries: 3,001 km >
Water
Limits of territorial waters (claimed): 12
nm ¢ ane
Coastline: 1,521 km (mainland), plus 2, 414
km (offshore islands).
Railroads: 9,399 km total; 9,399 km 1. 435-
meter standard gauge; 890 km double track;
8,451 km electrified (1983)
Highways: 116,400 km total; 63,100 km as-
phalt, concrete, stone block; 35,000 km as-
phalt treated, gravel, crushed stone; 18,300
km earth (1983)
Inland waterways: 2,600 km (1982)
Freight carried: tail—89.6 million metric
tons, 27.9 billion metric ton/km (1983);
highway—177.2 million metric tons, 19.1
billion metric ton/km (1983); waterway—
20.9 million metric tons, 4.1 billion metric —
ton/km (excluding international transit
traffic) (1983) _
Pipelines: 1,373 km crude oil; 2,760 km nat-
ural gas; 150 km refined products
Ports: 9 major (most important: Rijeka, Split,
Koper, Bar, and Ploée), 24 minor; principal
inland water port is Belgrade
Defense Forces | fo
Branches: Yugoslav People’s Army—
Ground Forces, Naval Forces, Airand Air.
Defense Forces, Frontier Guard, Territorial
Defense Force
Military manpower: males 15-49, 6,005,000;
4,850,000 fit for military service; 184,000
reach military age (19) annually
Military budget: announced for fiscal year ~
ending 31 December 1985, 391.3 billion di-
nars; about 4.8% of national i income .
271
Zaire
Boundary representation is
not necessarily authoritative.
See regional map VH-- -
Land
2,345,409 km?; one-fourth the size of the US;
45% forest, 22% agricultural (2% cultivated
or pasture), 33% other
Land boundaries: 9,902 km ;
Water
Limits of territorial waters (claimed): 12
nm (200 nm fishing)
Coastline: 37 lek
Railroads: 5,254 km total; 3,968 km 1.067-
meter gauge (851 km electrified); 125 km
1,000-meter gauge; 136 km 0.615-meter
gauge; 1,025 km 0.600-meter gauge
Highways: 145,050 km total; 2,350 km bitu-
minous, 46,230 km gravel and improved
earth; remainder unimproved earth
Inland waterways: comprising the Congo,
its tributaries, and unconnected lakes, the
waterway system affords over 15, 000 km of
navigable routes
Pipelines: refined products, 390 km
Ports: 2 major (Matadi, Boma), 1 minor -
Civil air: 52 major transport aircraft
Airfields: 335 total, 296 usable; 25 with
permanent-surface runways; 1 with run-
ways over 3,699 m, 6 with runways
2,440-3,659 m, 70 with runways 1,220-
2,439 m .
Telecommunications: barely adequate wire
and radio-relay service, 31,200 telephones
(0.1 per 100 popl.); 10 AM, 3 FM,-17 TV sta--
tions; 1 Atlantic Ocean satellite station and
13 domestic satellite stations -
Defense Forces
Branches: Army, Navy, Air Force, National
Gendarmerie, Logistics Corps, Special Presi-
dential Brigade
Military manpower: males 15-49, 7,045,000;
3,560,000 fit for military service -
Declassified and Approved For Release 2012/08/29 CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 .
Facahia
300 km
Lak
Tanganyika
Boundary representation is
not necessarily authoritative
Livingstone
See regional map VII
Land :
752,614 km?; larger than Tei: 61% scat-
tered wood and grass, 13% dense forest, 10%
grazing, 6% marsh, 5% arable and under
cultivation :
Land boundaries: 6,003 km','021002bbe8545f11b17f1a66c6dd9141a2d6928cf109fd7a1f021441c9b9577d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2d9c69ca444b252a9b556762eb3c5c3bf74cb108a9e134eafefdcf13159f0c',1986,'ZW','Zimbabwe','communications',538,'Railroads: about 1,075 km common carrier
lines and over 3,800 km industrial lines;
common carrier lines consist of the 1.067-
meter gauge 708 km West Line and the 367
km East Line; a 98.25 km South Link Line
connection is under construction; common
carrier lines owned by the government and
operated by the Railway Administration
under Ministry of Communications; indus-
trial lines owned and operated by govern-
ment enterprises -
Highways: network totals 18,800 km (15,800
km are bituminous or concrete surface);
2.500 km are crushed stone or gravel sur-
face; and 500 km are graded earth
Pipelines: 615 km refined products, 97 km
natural gas
Poxies3 major (Kao-hsiung, Chi-lung, Hua-
lien, Su-ao, and T’ai-tung), 4 minor (Tan-
shui, T’ai-nan, Ta-p’eng, and Ma-kung)
Airfields: 41 total; 38 usable; 34 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 17 with runways
2,440-3,659 m, 7 with runways 1,220-
2,439 m
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Telecommunications: very good interna-
tional and domestic service; 5.1 million tele-
phones (1 per 3.5 popl.); about 100 radio
broadcast stations with 270 AM and 12 FM
transmitters; 12 TV stations and 6 repeaters;
8 million radio receivers and 3.6 million TV
receivers; 2 INTELSAT ground stations;
tropospheric scatter links to Hong Kong and
the Philippines available but inactive; sub-
marine cables to Okinawa (Japan), the. Phil-
ippines, Guam, Singapore, and Hong Kong
Defense Forces
Branches: Army, Navy (including Marines),
Air Force, Combined Services Force
Military manpower: males 15-49, 5,301,000;
4,167,000 fit for military service; about -‘
215,000 currently reach military age (19) -
annually :
Military budget: announced expenditures _
for national defense for fiscal year ending 30
June 1986, $4.0 billion; about 39.1% of cen-
tral government budget; however, total mili-
tary expenditures may be closer to $4.7 bil-
lion or about 50% of the central government
budget ,
West Bank and
Gaza Strip
5Q0 km
Boundary representation is
not necessarily authoritative.
Sea
{(lsraeli occupied —
Status to be
determined)
See regional map.VI
NOTE: the war between Israel and the
Arab states in June 1967 ended with Israel
_in control of the West Bank and the Gaza
Strip, the Sinai, and the Golan Heights. As
stated in the 1978 Camp David Accords
and reaffirmed by the President’s 1 Sep-
tember 1982 peace initiative, the final sta-
tus of the West Bank and the Gaza Strip,
their relationship with their neighbors, and
a peace treaty between Israel and Jordan
are to be negotiated among the concerned
parties. Camp David further specifies that
these negotiations will resolve the respec-
tive boundaries. Pending the completion of
this process, it is US policy that the final
status of the West Bank and the Gaza
Strip has yet to be determined. In the
view of the United States, the term “West
Bank” describes all of the area west of the
Jordan River under Jordanian administra-
tion before the 1967 Arab-Israeli war.
However, with respect to negotiations evis-
aged in the framework agreement, it is US
policy that.a distinction must be made _
between Jerusalem and the rest of the
West Bank because of the city’s special
status and circumstances. Therefore, a ne-
gotiated solution for the final status of
Jerusalém could be different in character
from that of the rest of the West Bank.
Land )
West Bank—5,858.1 km? (includes West
- Bank, East Jerusalem, Latrun Salient and
“Jerusalem No Man’s Land,” and the north-
west quarter of (ie Dead Sea; excludes Mt.
>
277
Scopus); less than one-half the size of North
Carolina; Gaza Strip —363.3 km?; slightly
larger than Washington, D. C.
Land boundaries: West Bank—480.2 km;
Gaza Strip—72.1 km
Water 2k hl a :
Coastline: West Bank—none; Gaza Strip—
39.7 km
Railroads: West Bank—none; Gaza Strip—
one abandoned line throughout the entire
territory
Highways: West Bank: small, poorly devel-
oped indigenous road network; Israelis have
improved major axial highways
Gaza Strip: small, poorly developed indige-
nous road network; Israelis have improved
major axial highways
Ports: facilities for small boats at Gaza
Airfields: Gaza Strip has 1 usable with
permanent-surface runway; airfield in occu-
pied territory north of East Jerusalem
Telecommunications: West Bank—planned
telephone system currently being upgraded;
no local radio or TV stations; Gaza Strip—no
local radio or TV stations
278
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Main committees =
Standing and procedural o—
committees
Other subsidiary organs of the
General Assembly
Appendix A
The United Nations System
UNDOF: United Nations
. Disengagement Observer Force
UNFICYP: United Nations vos
Force in Cyprus :
UNIFIL: United Nations Interim,
Forces in Lebanon |
UNMOGIP: United Nations
Military Observer Group in a
India and Pakistan re ts
very
Security Council ©’. |———— UNTSO: United Nations Truce |”
- ae a Supervision Organization beats
: , Military Staff Committee :
Trusteeship Council
UNRWA: United Nations Relief
and Works Agency for Palestine
Refugees in the Near East
UNCTAD: United Nations —_
Conference on Trade and
Development
International Court
of Justice
iC) IAEA: International Atomic
Energy Agency
‘Secretariat
r~ — C1 GATT: General Agreement on
Tariffs and Trade
a ILO: International Labor "
UNICEF: United Nations
Children’s Fund
UNHCR: United Nations Office
of High Commissioner for
Refugees
WFP: World Food Program
UNITAR: United Nations
Institute for Training and
Research
UNDP: United Nations
Development Program
UNIDO: United Nations
Industrial Development
Organization
UNEP: United Nations
Environment Program
UNU: United Nations °
University .
HABITAT: United Nations —
Center for Human Settlements
UNFPA: United Nations Fund
for Population Activities
United Nations Special Fund
World Food Council °
Based on a chart from the UN Chronicle
Organization
\\—o FAO: Food and Agriculture |” *
; Organization of. the United -..-.
Nations
‘Economic and
Social Council
Regional Commissions
UNESCO: Daited Saat ow
: ar Educational, Scientific, an ~
Functional Commissions Cultural Organization cele!
Sessional, standing, and ad
hoc committees WHO: World Health
Organization
© IMF; Intérnational Monetary -- +
Fund gait, es
IDA: International
Development Association
IBRD: International Bank for’.
Reconstruction and a
Development ‘ ~
IFC: International Finance ny
Corporation eee
‘ICAO: international ‘Civil
Aviation Organization
-O UPU: Universal Postal Union
: = ITU: International
Telecommunication Union
WMO: World Meteorological
f Principal organs of the United Organization
Nations C IMO: International Maritime _, -
© Other United Nations organs ‘Organization = a
‘WIPO: World Intellectual
CO) Specialized agencies and other Property. Organization
autonomous organizations
within the system —O IFAD: International Fund for
Agricultural Development
279
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Appendix B
Selected UN
Organizations
Principal Organs GA General Assembly
SC Security Council
ECOSOC Economic and Social Council
TC Trusteeship Council
IC] International Court of Justice
} Secretariat
Other organs’ > UNCTAD : UN Conference on Trade and Development.
sig ? TDB ’ Trade and Development Board
-UNDP — UN Development Program
UNICEF UN Children’s Fund
UNIDO UN Industrial Development Organization —
Regional Economic ECA : Economic Commission for Africa
Commissions ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA hte Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and. the Pacific
Specialized " * - FAO Food and Agriculture Organization
Agencies and : -. IBRD International Bank for Reconstruction and Development (World Bank)
Other autonomous :
Organizations *- -- '' ICAO International Civil Aviation Organization
Within the IDA International Development Association (IBRD Affiliate)
; System : so 8s IFAD International Fund for Agricultural Development
IFC : International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMF ; ____International Monetary Fund
IMO International Maritime Organization
ITU : International Telecommunication Union
UNESCO UN Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
- -WFC World Food Council
-WHO ‘World Health Organization
mS -- WIPO World Intellectual Property Organization
WMO World Meteorological Organization
GATT : General Agreement on Tariffs and Trade
IAEA International Atomic Energy Agency
280
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Appendix C
Selected International
Organizations
A AAPSO Afro-Asian People’s Solidarity Oreanizabion:
: ADB Asian Development Bank -
AfDB African Development Bank
AIOEC Association of Iron Ore Exporting Countries
ANRPC Association of Natural Rubber Producing Countries
ANZUS ANZUS Council; treaty signed by Australia, New Zealand, and
the United States
APC African Peanut (Groundnut) Council
ne. Arab League (League of Arab States) - -.
ASEAN Association of Southeast Asian Nations
ASPAC Asian and Pacific Council
ASSIMER International-Mercury Producers Association
B : BENELUX Belgium, Netherlands, Luxembourg Economic Union
: BLEU Belgium-Luxembourg Economic Union. , .
Cc ; CACM **~ Central American Common Market
. CARICOM Caribbean Common Market
CARIFTA Caribbean Free Trade Association
ccc Customs Cooperation Council
CDB Caribbean Development Bank
CEAO . West African Economic Community ;
CEMA Council for Mutual Economic Assistance __
CENTO Central Treaty Organization :
CIPEC Intergovernmental Council of Copper Exporting Countries
Colombo Plan
Council of Europe
DAC Development Assistance Committee (OECD)
E 7 _ ,. EAMA | African States associated with the EEC
_7* EC ; European Communities
ECOWAS. Economic Community of West African States
EFTA. European Free Trade Association \\
£ EIB European Investment Bank
ELDO European Space Vehicle Launcher. Development Organization
EMS European Monetary System
ENTENTE Political-Economic Association of Ivory Coast, Dahomey, Niger,
: Upper Volta, and Togo
ESCAP Economic and Social Commision for Asia and the Pacific
ESRO European Space Research Organization
G G-77 Group of 77
GCC Gulf Cooperation Council
I IADB Inter-American Defense Board
IATP International Association of Tungsten Producers
IBA International Bauxite Association ;
IBEC International Bank for Economic Cooperation
iCAC International Cotton Advisory Committee :
ICCAT International Commission for the Conservation of Atlantic Tunas
ICCO International Cocoa Organization
_ICEM Intergovernmental Committee for Ruropean Migration
ICES International Cooperation in Ocean Exploration
ICO International Coffee Organization
IDB Inter-American Development Bank
IDB Islamic Development Bank
IEA International Energy Agency (associated with OECD)
281
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 {
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
I IHO ; International Hydrographic Organization
International Lead and Zine Study Group
IIB International Investment Bank
INRO International Natural Rubber Organization’
INTELSAT International Telecommunications Satellite Organization
IOOC International Olive Oil Council
IPU Inter-Parliamentary Union
IRC a International Rice Council
ISO . International Sugar Organization
ITC International Tin Council
IWC International Whaling Commission
IWC International Wheat Council
LL LAIA Latin American Integration Association
"NAM 7 Nonaligned Movement ‘
NATO . North Atlantic Treaty Organization
mae) COAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States ‘ oa
OAU Organization of African Unity ; ;
OCAM Afro-Malagasy and Mauritian Common Organization
ODECA Organization of Central American States ae
OECD Organization for Economic Cooperation and Development
OIC © Organization of the Islamic Conference
OPEC Organization of Petroleum Exporting Countries
| en PAHO Pan American Health Organization
S SAARC South Asian Association for Regional Cooperation
ae SADCC on: Southern African Development Coordination Committee
SELA Latin American Economic System
; SPC South Pacific Commission
. SPEC South Pacific Bureau for Economic Cooperation
‘ ; SPF South Pacific Forum ;
pot Oka UDEAC Economic and Customs Union of Central Africa
; : UEAC Union of Central African States
UPEB Union of Banana Exporting Countries
Wwe WEU ; Western European Union
4 : WFTU World Federation of Trade Unions
WPC ., . World Peace Council
WSG International Wool Study Group
WTO World Tourism Organization
282
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Appendix D
Conversion Factors
To Convert From To Multiply By To Convert From — To Multiply By
Acres Hectares 0.4046856 Meters, cubic Tons, register 0.353147
Acres Kilometers, square 0.004046856 Miles, nautical Kilometers 1.852
Acres .. ‘Meters, square 4046.856 Miles, statute Centimeters 160934.4
Centimeters Meters 0.01 Miles, statute Meters 1609.344
Centimeters, square Meters, square 0.0001 ; Miles, statute Kilometers 1.609344
Degrees, Fahrenheit Degrees, Celsius subtract 32 and __. Miles, square Hectares 258.9998
7 multiply by 5/9 Miles, sauare Kilometers, square 2.589998
Feet Centimeters 30.48 Ounces, avoirdupois Grams 28.349523
Feet Meters 0.3048 Ounces, avoirdupois Kilograms 0.028349523
Feet Kilometers 0.0003048 Ounces, troy Pounds, troy 0.083333
Feet, cubic Liters 28.316847 Ounces, troy Grams 31.10848
Feet, cubic Meters, cubic 0.028316847 Pints, liquid Milliliters 473.176473
Feet, square Centimeters, square 929.0304 -. Pints, liquid Liters 0.473176473
Feet, square Meters, square » 0.09290304 Pounds, avoirdupois - Grams 453.59237
Gallons, US liquid Liters 3.785412 Pounds, avoirdupois Kilograms - 0.45359237
Gallons, US liquid Meters, cubic 0.003785412 Pounds, avoirdupois Quintals ‘0.00453592
Grams Ounces, troy 0.032151 Pounds, avoirdupois Tons, metric 0.000453592
Grams Pounds, troy "0.002679 Pounds, troy Ounces, troy 12-0
Hectares Kilometers, square 0.01 Pounds, troy Grams 373.241722
Hectares Meters, square — 10,000 Quarts, dry Liters 1.101221
Inches “Centimeters 2.54 Quarts, dry Dekaliters 0.110122] |
Inches Meters 0.0254 Quarts, liquid Milliliters 946.352946
Inches, cubic Milliliters 16.387064 Quarts, liquid Liters 0.946352946
Inches, cubic Liters 0.016387064 Quintals Tons, metric 01
Inches, cubic Meters, cubic . 0.000016387064 Tons, long Kilograms 1016.047
Inches, square . Centimeters, square a 6.4516 . Tons, long Tons, metric 1.016047
Inches, square Meters, square : 0,00064516 Tons, metric Quintals 10 |
Kilograms Ounces, troy $2.15075 Ton-miles, long Ton-kilometers, metric _ 1.635169
Kilograms Pounds, troy _ 2.679229 Ton-miles, short Ton-kilometers, metric 1.459972
Kilograms Tons, metric 0.001 Tons, register Meters, cubic 2.831685
Kilometers, square Hectares 100 Tons, short: Kilograms 907.185
Liters Milliliters 1000 - Tons, short Tons, metric 0.907185
Liters Meters, cubic - 0.001 Yards Centimeters 91.44
Meters Millimeters 1000 Yards - Meters 0.9144 ©
Meters Centimeters 100 Yards, cubic Liters 764.5549
Meters ___ Kilometers 0.001 Yards, cubic Meters, cubic : 0.7645549 |
Meters, cubic ~ Liters ~ Meters, square 0.836127 .
1000
Yards, square
283
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
oy teas
a
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Appendix E
Country Membership in Selected Organizations
Country International Organizations
ADB ARAB ASEAN CACM CARICOM CEMA EC G-77 Gcc IDB? IDBD AINTELSAT LAIA ‘NAM NATO OAPEC OAS
LEAGUE','caa70845635ebe35abb32d886e3f78ed79167627a8589c79f9ae3d51da28bfa7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7739b9a759ce1d455365eb5be3d4010bb006a63377579bb7b7cc2868bde1c25',1986,'MT','Malta','communications',539,'Martinique®
te) 500 Kilometers
fe)
800542 (545529) 4-86
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 as
500 Nautical Miles
Zagreb
: YUGOSLAVIA
Valletta
at.
CIA-RDP08-00534R000100170001-4
The United States Government has not recognized
the incorporation of Estonia, Latvia, and Lithuania
into the Soviet Union. Other boundary representation
} is not necessarily authoritative.
Cluj -Napoca','9649252feb8aa2f4056b26c0aa58d647bca621f3d8696d14379ef17363de19c8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a5a541fc95fc8a00789a0ce2cac20eafa838332408a0b5e02b443d14bc262bd',1986,'BG','Bulgaria','communications',540,'* Sofia
_tnEcdbnier , Y
ae
ta “.
fp ,loannina ».. Aegean
EL 8@
opgnnisos 4s ar: R4
SAT y+ Rhodes
. Crete
a od
Map V
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Middle East
a : 30 \\y 50 60
fb! : Black Sea i
i a : a '' i
s \\ Bosporus a H
2 ere istanbul i — i : :
~ aby. aN : ‘ H ; 40
| u wre dt OR Awe ° ge a Samsun : Caspian . : = = .
my \\ Dardaneijes 7 ~~--—_.."8 ihe ; _Sea Rr a
} i gs Sr aa oe '' 7 CO sn cutee kgeuegiblns SER PE :
] vs aN ” a Erzurum >
i ~ X} Aegean + ‘ . ; . 1
lo SS s 9. NS. izmir é TURKEY I ies \\ ! ( \\
! aN Led Yq Se8 98 «Kayseri | hake ; :
: } Ys 8 xX , Fs & van + .
i 90% a Denizil, Konya Malatya \\ tates :
i nN 09 i Diyarbakir bansatiag H
| ;
i‘ Oremiyeh at \\
i naeeatelye Adana, : Lake Urmna) Rasht® - Mashhad,
H é .
1 i . Zanjén* »Qazvin
j fh
! CYPRUS. wenran
Mediterranean Sea: Bakhtaran Gam
; ! Beirut " vo oe
: LEBANON Damascus Ra mak IRAN Bijand,
: ta FDe Gol .
i '' eeu Heights? SS .Estahan
t ‘\\ it rT
- A ag i rei AUSRAEY, Aenean \\ Al Hilla ArKat ssBezlol .Yazd
q Marsa ‘eq Alexandria | grace, Jerusalem, A Jost Bank, > \\
] 30... pee ~ Tene casey t x i }_— avaz
Stee Adal Suez . S t inva Kerman
} : An Nasiriyal .
t . {Cairo aon { JORDAN i ae Abadap
* 7 ! Al Bagrahi Zahedar’ *
| 3 Sain ake [ea ee er emer ; + Shiraz
Bani Suwayf,/ KUWAIT
q ke Ruwait Bandar-e
i f [ ‘ ! Iraq-Saudi awa > ‘ Boshenr:
| fj Al Minya J . Tabak ; Neutral Zone z
: she ) — ae
! “Asyat® Shay Se. Persian wig N Strout of
: AS So Hormuz
j i t bie: Gulf ve Bandar
EGYPT ~ Ad Dammam OMA Beheshti
! : admin, -
j f Ybuxor j Line U
d f ; ) : i a Gulf of Oman!
pitti, . } \\ aa i SAUDI Rivagh 4 a :
“otf Ope of | Aswan \\ jedina uscaty
SOF Cancer cyte. A Bs Yanbu" | ARABIA ae
! Lake a ee : Bodies 3
} : Nasger Mim Tesi Sa Ss
Admin t
Boundary gt
no
Seale"t:18,000.000
500 Kilometers
$00 Nautical Miles
boundary,
EOPLE’S DEM.
REP. OF YEMEN fAl Ghaydah
(SOUTH YEMEN)?
defined
Al Mukai
ja
‘2
Gulf of Aden
no defined
boundary
Salatah
''
Arabian.
Sea |
*The Golan Heights is Israeli-occupied
Syria; the West Bank and Gaza Strip
are Israeli occupied with status to be A
determined.
Boundary representation is
not necessarily authoritative.
800543 (545530)4-86
Map VI
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 :
ae
Azores
(PORTUGAL) a
Ponta
Delgada
Madeira Islands
(PORTUGAL)
*
Funchal
North
Gasablanca,-*
MOROCCO / Ghardaia,
Marrakech |
Canary Islands “Béchar
© (SPAIN),
Atlantic
Ocean','3e9d91558fac033bc3faf085d6db5cfb2c086fc7d73245d832e33983fa3a55e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

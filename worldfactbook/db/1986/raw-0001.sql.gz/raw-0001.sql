SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14164a8894cdd05b6b1e46eee1526b1e3abe10a88942d019a91a52a05091ace8',1986,'','','raw',1,'XIG-AWYSIG pue porpunyy usajouINY © Yooqey pploAy 94],
fale «= The
World
Factbook
Nineteen Hundred and Eighty-Six
LO ee ee OW 0
>
€
«
«
d
é
¢
4
«
«
«
<
g
&
<
<
4
No
MONCOLIA MONON LY
Me eth
See
SPANA
4 :
me I eee
— wee
<
Ae LAA DD ORD ABN OA OE
pew ws Wee tie eres,
6. 8 . i é : .. i = a De eee
20. boa * ea as
io
|
i
i
i
“et
ae
WwhousKOo wo)
nN re Ga
wt a wanda AOC
ee rr
POSTA AERIANA
SOT SS SU Cw ry wwe
SSE
> vores
1
=" |
Botannt arenes 64.00
A Rg ting a ow
Pw ew rw we eee
nn pete nl,
| etetinat Ril hated kh te htt = p - a ala aaatia eaiadair dt tad
ee ee ee
Py UNITED STATES OF AMER
: HOMIWASE ALA FUERZA ACREA HACIOVAL! < aaa
LPeTeEDUSU CITT.
Fe tah Madde shad Bh dod
LO I Oe We Wr ee et i
»
,
8
ee SOPOT AT NS cet
Me Pn
NEiBiee reg 86,00
BLOF ANCA ISH
tae aS
tila www we er wee
J
ROR PUT AA TUTE
RWO-S bis
aie
Gras |
el ws
me)
CR WF 86-001
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ee
Declassified and Approved For Release 2012/08/29
This publication is prepared for the use of US
Government officials, and the format, coverage,
and content are designed to meet their specific
requirements. US Government officials may ob-
tain additional copies of this document directly
or through liaison channels from the Central
Intelligence Agency.
Requesters outside the US Government may ob-
tain subscriptions to CIA publications similar to
this one by addressing inquiries to:
~ Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not inter-
ested in subscription service may purchase spe-
~~eific‘publications-either-in-paper-copy-or micro-
form from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
To expedite service call the
NTIS Order Desk (703) 487-4650
This publication may also be purchased from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
(Stock Number 041-015-00163-9)
— _Declassified and Approved For Release 2012/08/29
: CIA-RDP08-00534R000100170001-4
: CIA-RDP08-00534R000100170001-4
wel
Central
® Intelligence
Agency
The |
World
Factbook —
Nineteen Hundred and Eighty-Six
The World Factbook is produced annually
by the Directorate of Intelligence of the .
_ Central Intelligence Agency. The data are ©
provided by various components of the
Central Intelligence Agency, the Defense
Intelligence Agency, the Bueau ‘of the
Census, and the US Department of State. In
general, information available as of 1
January 1986 was used in the preparation of .
this edition, with the following exceptions:
Population figures are projected estimates
for 1 July 1986; the average annual
growth rates listed are projected estimates
for the period mid-1985 to mid-1986.
‘Military manpower estimates are as of 1
January 1986, except the numbers.of
males reaching military age, which are
projected averages for the five-year
'' period 1986-90.
Major political developments through 14
April 1986 have been included. :
Comments and queries are welcome and
may be addressed to:
Central Intelligence. Agency
Attn: Public Affairs
Washington, D.C. 20505
(703) 351- 2053
For information on how to obtain addi-
tional copies, see the inside of the front
‘cover.
Declassified and Approved For Release 2012/08/29 : CIA- RDPO8- 00534R000100170001 -4
CR WF 86-001
(Supersedes CR WF 85-001)
_ June 1986
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Contents : ea - »
; a! to Page
: Definitions, Abbreviations, and Explanatory Notes ix
A Abu Dhabi (see United Arab Emirates) . .
Afghanistan ie an 1
Ajman (see United Arab Emirates) cas
Albania 2
Algeria 3
Andorra : ; TO.te
Angola ag : ; : 6
Anguilla (formerly St. Christopher-Nevis-Anguilla) , - ae
Antigua and Barbuda. 8
Argentina ae . 9
Aruba ‘ oe i SES : ~ ag eee z i lL
Australia. ; tee cs Le! ie a8
t Austria at oo . 18
Azores (see Portugal). . a ,
i B Bahamas, The “2 i 15
Bahrain ° SS “16
: Balearic Islands (see Spain) . : Shas ;
f Bangladesh BY oe - 47
Barbados oo ee 19
Belgian Congo (see Zaire)
Belgium. sn + 20
Belize (formerly British Honduras) ~~ a gg
Benin (formerly Dahomey) V2 oe 23
* Bermuda _ Pe 24
Bhutan ; : 26
Bioko (see Equatorial Guinea) ©
Bophuthatswana (see South Africa)
| ; Bolivia 27
Botswana. ; ; 28
Brazil , ; 30
British Honduras (see Belize) . _
British Indian Ocean Territory “ a ee 31.
British Solomon Islands (see Solomon Islands)‘ ;
: British Virgin Islands ane : 32
; Brunei. a ~ 33
Bulgaria 4 -s 84
Burkina (formerly Upper Volta) 36
Burma ; ; . 87
| ; Burundi oo _ 7 38
'' C Cabinda (see Angola) .
i Cambodia (formerly Kampuchea) “| -° ~ : ee 40
i Cameroon a, = 41
iii
: Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
a Page
ie Congdad | sae oa a PS es 42
Canary Islands (see Spain) . : ; ~ 7
Cape Verde. 9) 2s 1 ee 44
Cayman Islands eS . 45
Central African Republic SO Sas 46
Ceylon (see Sri Lanka)? «21-052 fees ra ing
Chad See 48
Channel Islands (see Guernsey and Jersey). ,
Chile ng ; 49
China (Taiwan listed at end of fable): ig peice, 51
Christmas Island Mite oe m0 Bg
Colombia bh ig ops ; a 53
Comoros mee : 22108
* Congo es ‘ : ‘ 56
Cook Islands : 57
Costa Rica , ; = 58
Cuba oie a 60.
Cyprus , ae ; ; 61
Czechoslovakia ; 63
ee. De Dahomey (see Benin) ikea ;
Denmark : 64
Djibouti (formerly French Territory of the Afars and Issas) ~ 66
Dominica a. at 67
Dominican Republic : 68
Dubai (see United Arab Emirates) .
E * +» + Ecuador : BRO ha 69
Egypt ae . 71
Ellice Islands (see Tuvalu) : ;
E] Salvador ; 73
Equatorial Guinea sas, . 74
Ethiopia i a 7 76
F - Falkland Islands (Islas‘Malvinas) +» ; 77
, Faroe Islands +. 0 ee oe te ee i, 78°
Fernando Po (see Equatorial Guinea) ~~
Fiji ‘ : ae ; - 79
Finland eaten ee de 80
France gL “ae Gs 7s 82
French Guiana_- Pe . 84
French Polynesia pie 4 _ 85
French Territory of the Afars and Issas (seé Djibouti)
; Fujayrah, al (see United Arab Emirates) — ; .
G Gabon : Se ee 86
Gambia, The an ae a a: Se 88
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
= Age og Page
Gaza Strip (see West Bank and Gaza Strip, listed at end of table) :
German Democratic Republic - 89
Germany, Federal Republic of . 91
Ghana = gg
_ Gibraltar Ae 94
Gilbert Islands (see Kiribati) -
Greece 95
Greenland : 96
Grenada 97
Guadeloupe?. - .. - 99
Guatemala 100
Guernsey 102
Guinea. : 103
Guinea-Bissau (formerly Portuguese Guinéa) 104
Guyana , 105
Ho Haiti oy 107
Honduras - 108
Hong Kong i SO ilo
Hungary lu
I Iceland: tin. : 112
India 114
Indonesia ; ; 115
Iran” 117
Iraq’ Ss : 119
Ireland ge ee 120
Israel (West Bank and Gaza Strip listed at end of table) 422
Italy 124
Ivory Coast : P 125
J Jamaica 127
Japan 128
Jersey . 130
Jordan (West Bank and Gaza Strip listed at end of table) 131
K Kampuchea (see Cambodia) _
Kenya - ao ie AK 183
Kiribati (formerly Gilbert Islands) 133
Korea, North. __. 134
Korea, South 136
Kuwait ; 137
L Laos .. eS 139
, Lebanon . 140
Lesotho : 142
Liberia 143
. "Libya | | 144
} v
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
i Page
'' . Liechtenstein 146
Luxembourg 147
Macau . 148
Madagascar ; 149
_ Madeira Islands (see Portugal) .
Malagasy Republic’(seé Madagascar): ee
Malawi Mees 151.
Malaysia 152
Maldives 155
Mali 156
Malta ae 157
Man, Isle of.) 0.7 159
Martinique 160
Mauritania 161
-, Mauritius. 162
Mayotte 164
Mexico 165
Monaco 166
Mongolia 167
Montserrat 168
Morocco 169
"Mozambique : 171
'' Namibia (formerly South-West Africa) : 172
Nauru ; 174
Nepal - 175
Netherlands 176
Netherlands Antilles 178
“New Caledonia 179
- New Hebrides (see Vanuatu)
New Zealand 180
Nicaragua To 181
Niger 183
Nigeria 185
Niue . ; ; 186
Norfolk Island- °°": 187
Northern Rhodesia (seé Zambia)’ > *
Norway 188
Oman 190
Pakistan 191
Panama 193
Papua New Guinea 194
Paraguay 196
Pemba (see Tanzania)
vi
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R0001001 70001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Page
Peru Res ia fnoenie : : 197
Philippines _ . 7, . - 198
Pitcairn we ™* ; 200
Poland oe. 201
Portugal ge 202
, Portuguese Guinea (see Guinea-Bissau)
Portuguese Timor (see Indonesia)
Q Qatar x N 204
= R j Ra''s al-Khaymah (see United Arab Emirates)
i ‘Reunion _ : 205
Rhodesia (see Zimbabwe)
Rio Muni (see Equatorial Guinea)
i} Romania ye ee 206
it me, Rwanda d % 207
‘ S St. Christopher and Nevis (formerly St. Christopher-Nevis-Anguilla) 209
{ St. Helena . ; 3 210
St. Lucia oS. 21)
St. Vincent and the Grenadines area 212
_SanMarino .. . ae 213
Sao. Tome and Principe my ° 214
a . - . Saudi Arabia aes 215
- Senegal a QUT
Seychéllls = "918
Sharjah (see United Arab Emirates) .
Sierra Leone oe _ 219
i Singapore = 221
- Solomon Islands (formerly British Solomon Islands) 222
: “Somalia a 293
South Africa —_ ; = ; F 224
Southern Rhodesia (see Zimbabwe) _
I South-West Africa (see Namibia)
Soviet Union a ra 226
’ Spain : ; : 228
Spanish Sahara (see Western Sahara) : ed
Sri Lanka (formerly Ceylon). ... ; oo 230
| ‘Sudan 231
; Suriname : a:
_ | Swaziland . ere ott ee "284
. Sweden a : 235
i Switzerland - © aes 237
{ Syria : or oe ee 239
vii
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Page
T Tanganyika (see Tanzania)
Tanzania . 240
Tasmania (seé Australia)
Thailand 242
Togo bth Toe ds tenet 243
Tokelau ee . 244
Tonga _ p ~ 245
Transkei (see South Africa) ‘
Trinidad and Tobago _ = for 8 246
Tunisia : i: 248
Turkey _ 249
Turks and Caicos Islands - fore ; 251
Tuvalu (formerly Ellice Islands) 252
U- ; Uganda . 253
Umm al-Qaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 254
Ra’s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
United Kingdom ee 255
United States eee eee 257
Upper Volta (see Burkina)
* Uruguay © ; 259
Vv Vanuatu (formerly New Hebrides) 260
Vatican City sf 261
Venda (see South Africa)
Venezuela . 262°
Vietnam; - ; 263
WwW Wallis and Futuna ‘ 265
Walvis Bay (see South Africa)
Western Sahara (formerly Spanish Sahara) 265
Western Samoa 266
Y Yemen Arab Republic (North Yemen) 267
Yemen, People’s Democratic Republic of (South Yemen) 268
Yugoslavia —_ 270
Z Zaire 271
, Zambia (formerly Northern Rhodesia) 273
Zanzibar (see Tanzania)
Zimbabwe (formerly Southern Rhodesia) 274
Taiwan (China listed alphabetically) 275
‘West Bank and Gaza Strip 277 é
viii
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ices ae I
iia ME ile RO NA a hy
yy
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Page
Appendixes
A. The United Nations System 279
B. Selected UN Organizations ~ 280
C. Selected International Organizations 281
D. Conversion Table i 283
E. Country Membership in Selected Organizations
Maps SE,
I. The World (Guide to Regional Maps II-XIII)
284
II. North America
III. Central America and the Caribbean.
IV. South America. —_
V. Europe
VI. Middle East
_ VIL. Africa
VIII. Soviet Union, East and South Asia.
IX. Southeast Asia
X. Oceania”
XL. Arctic Region
XII. Antarctic Region
XIII. Standard Time Zones of the World.
ix
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
a cn nt ae nee eee a iD
eee conan
an ak Ba: ie CS a oe ek A
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Definitions, Abbreviations,
and Explanatory Notes
eT
Fiscal Year: The abbreviation FY stands for fiscal year; all years are
calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over a
particular time period, normally a year. GNP equals GDP plus.the
income accruing to domestic residents arising from investment abroad
less income earned in the domestic market accruing to foreigners
-abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual
entries throughout this factbook are c.i.f. (cost, insurance, and freight),
f.o.b. (free on board), ODA (official development assistance), arid OOF
(other official flows). :
Land Utilization: Most of the land utilization percentages are rough
estimates. Figures for “arable” land in some cases reflect the area
under cultivation rather than the total cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea limits.
Maritime claims do not necessarily represent the position of the
United States Government.
Money: All money figures are in contemporaneous US dollars unless
otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express
volume of crude oil and refined products; a barrel equals 42.00
gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not officially
recognized by the United States Government.
xi
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Ct a ee
ae ggg ee aa ae I NO a net mn age
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Afghanistan .
300 km
See regional map VIII
Land
647,497 km?; about the size of Texas; 75%
desert, waste, or urban; 22% arable (12%
cultivated, 10% pasture); 3% forest
Land boundaries: 5,510 km','87ac7f77ac0bd097cca78e9c1f9eaa7c1f0f7ec96608356d17e3abc1a8808e3b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f45b4984765163b5e9b743c33632e4c0b3e4255fd748f522b4046055e63430',1986,'','','raw',1,'Sanitized Copy Approved for Release 2011/08/22 : CIA-RDP88M00338R000100060018-5
Central Intelligence Agency
Office of the Deputy Director for Intelligence
6 June 1986
NOTE FOR: D/CPAS
Frank,
With the reorganization of OCR the
fate of the World Factbook is up in the
air. I understand Helene has talked with
| you about the possibility of CPAS taking
on the responsibility for this publication.
If OCR gives you the slots and people
involved is there a sensible place for this
project to fit into CPAS? Please give me
a call.
STAT
Jonn™£} Helgerson
Associate Deputy Director
or/ Intelligence
\\
Sanitized Copy Approved for Release 2011/08/22 : CIA-RDP88M00338R000100060018-5','4ea45da0714f0769ad311aff5a6c97919c57d826508a757f326229ed11232b0a','internet-archive','cia-readingroom-document-cia-rdp88m00338r000100060018-5','txt','a041260a17c085d3faaa4ea9008bf0ada9c018c44bd556022f5feed99e8a09e7','https://archive.org/download/cia-readingroom-document-cia-rdp88m00338r000100060018-5/cia-rdp88m00338r000100060018-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6416ac32e70ca99873c72dfd6b202d50149ae1c3966aa3a271a9f7d626206cad',1986,'','','raw',1,'Sanitized Copy Approved for Release 201 1/08/22 : CIA-RDP88M00338R0001 0006001 8-5
Central Intelligence Agency
Office of the Deputy Director for Intelligence
6 June 1986
NOTE FOR: D/CPAS
Frank ,
With the reorganization of OCR the
fate of the World Factbook is up in the
air. I understand Helene has talked with
you about the possibility of CPAS taking
on the responsibility for this publication.
If OCR gives you the slots and people
involved is there a sensible place for this
project to fit into CPAS? Please give me
a call .
<7
v STAT
jonn^bL tieigerson
AssafcjLate Deputy Director
for/ Intelligence
Sanitized Copy Approved for Release 2011/08/22 : CIA-RDP88M00338R0001 0006001 8-5','615929338396b1c220361aa7c15d951fd3b735340e904ae491d04f9c778bda33','internet-archive','CIA-RDP88M00338R000100060018-5','txt','804be297b09ade59d3da8d68000426b04f162b5bacab635021bec0b8e86847e3','https://archive.org/download/CIA-RDP88M00338R000100060018-5/CIA-RDP88M00338R000100060018-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c5763c12b9e66bc233dfabad1bbc5b796dcff095f3313e34a2966830821da5a',1986,'','','people-and-society',2,'Population: 15,425,000 (July 1986), average
annual growth rate 2.4%; these estimates _
include an adjustment for emigration to
Pakistan during recent years but do not take
into account other demographic
consequences of the Soviet intervention in
Afghanistan ,
Nationality: noun—Afghan(s); adjective— ,
Afghan
Ethnic divisions: 50% Pashtun, 25% Taiik,
9% Uzbek, 9% Hazara; minor ethnic groups
include Chahar Aimaks, Turkmen, Baluchi,
and others
Religion: 74% Sunni Muslim, 25% Shi‘a
Muslim, 1% other .
Language: 50% Pashtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily
Uzbek and Turkmen), 10% thirty minor lan-
guages (primarily Baluchi and Pashai); much
bilingualism
Life expectancy: men 39.9, women 40.7
Literacy: 12%
Labor force: 4.98 million (1980 est.); 67.8%
agriculture and animal husbandry, 10.2%
industry, 6.3% construction, 5.0%
commerce, 7.7% services and other; current
fenres prevanene because of fighting (1986)
Organized tibce government-controlled’
unions are being established','0d3210051c2f5c80b8134b9aa9ea368c739701c70bb122696ddad75900a93f4a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('985a892741de65d655d273d437abd9afe91da9c8b6045bc8a821c47f3e0de713',1986,'AL','Albania','people-and-society',7,'Population: 3,020,000 (July 1986), a average
annual growth rate 2.0%
Nationality: noun—Albanian(s), adjective—
Albanian
Ethnic divisions: 96% Albanian; remaining
4% are Greeks, Vlachs, Gypsies, Serbs, and
Bulgarians
Religion: Albania claims to be the world’s
first atheist state; prewar est. —70% Muslim,
20% Albanian Orthodox, 10% Roman Cath-
olic; observances prohibited
Language: Albanian (Tosk is offteral dialect),
Greek
Infant mortality rate: 86.8/1,000 (1971)
Life expectancy: 69
Eilerace: 75%
Labor Sie: 584, 000 gia about 22% agri-
culture, 40% industry and commerce, 38%
other (1978)','4b1fa95a9014d50ee45e24e94272d6947d9a03f16bc2c2216dac6f434bfbe918','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b16e2ce5972fb4abe21c42f37bc5d5b585ae69b583da92d7326302422798c7f',1986,'DZ','Algeria','people-and-society',13,'Population: 22;817,000 July 1980) average
annual growth rate 8. 2% a
‘
Nationality: noun—Algerian( adjective
Algerian . :
Ethnic divisions: 99% Arab- ‘Berbers, less :
than 1% Europeans. : -
Religion: 99% Sunni Muslim (state religion);
1% Christian and Jewish
ranguage: 8 Arabic (ofici) French, Berber
dialects... re ae
infant mortality rate: 9: 106/'' 1,000 (1984),
Life expectancy: 60
Literacy: 52%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Algeria (continued)
Labor force: 3.7 million (1984); 40%. industry
and commerce; 30% agriculture, 17% gov-
ernment, 10% services; at least 11% of urban
labor unemployed
Organized labor: 16-19% of labor force _
claimed; General Union of Algerian Work-
ers (UGTA) is the only labor organization
and is subordinate to the National LLibera-
tion Front','925bfdfdc8a435ea241d012127216de76095cfe475ab4b620db12d1bed74361f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8231d81465639ac5c5b2d1050063cc6a1136ed254462f5eb787a9301d7fccab6',1986,'AD','Andorra','people-and-society',17,'Population: 49,000 (J ie 1986), average an-
nual growth rate 5.1% :
Nationality: noun—Andorran(s); _
adjective—Andorran
Ethnic divisions: Catalan stock; 61% Span-
ish, 30% Andorran, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan (official); many also
speak some French and Castilian
Literacy: 100%
Labor force: largely shepherds and farmers','f65c048cf786284c84846e2472f809835328653f794113cf4f59dbde7c7f9eeb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ba7fe2dc59c34a2b926b2d6a2051936a65a11935e47c1af7cc805b0d7cd6d7',1986,'AO','Angola','people-and-society',21,'Population: 8,164,000, including Cabinda
(July 1986), average annual growth rate d
2.7%: Cabinda, 133,372 July 1986), average
annual growth rate 3.2% -
Nationality: noun—Angolan(s); adjective— .
Angolan |
Ethnic divisions: 37% Ovimbundu, 25%
Kimbundu, 13% Bakongo, 2% MES, 1%
European
Religion: 68% Roman Catholic, 20% Protes-
tant, about 10% indigenous beliefs
Language: Portuguese (official); various °
Bantu dialects
Infant mortality rate: 148/1,000 (1983) _
Life expectancy: men 40.6, women 42.9
Pay: 20%
Labor Soreb 2, 783, 000 economically qotive:
(mid-1985 est.); 85% agriculture, 15% indus-
try
Organized labor: approx. 450,695 (1980)','c29e09cae46cbd5af631a7b56f7ca3734ac17f16feb1223d40d5806ae11a6785','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bd6f71fc8c84d989af232c578a6e837620fdfdff52bde134593893f5a37e792',1986,'AI','Anguilla','people-and-society',25,'Population: 6,680 (1984)
Nationality: noun—Anguillan(s);.adjec-
tive—Anguillan Soe
Ethnic divisions: mainly of African Negro
descent :
Religion: Anglican and Methodist _
Language: English (official)
Literacy: 80%
Labor force: 2, 000 Anguillans living ov overseas
send remittances home; 26.4% unemployed
(1984)','8e2dcfaa709d6b7480dbb806652bb90b0d98d88f18e7851fddd67978a38f4aad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41186aa23838aeb65eec7d4de72fec54b5b1bb3f830f943ce3212e3bea62ec14',1986,'AG','Antigua and Barbuda','people-and-society',28,'Population: 82,000 (July 1986), average an-
nual growth rate 2.6%
Nationality: noun—Antiguan(s); adjective—
Antiguan
Ethnic divisions: almost entirely of black
African origin; some-of British, Portuguese,
Lebanese, and Syrian origin
Religion: Anglican (predominant), other
Protestant sects, some Roman Catholic
Language: English (official), local dialects
Infant mortality rate: 31.5/1,000 (1985)
Life expectancy: 70
Literacy: about 90%
Labor force: 30,000 (1983); 20% unemploy-
ment (1983); agriculture 11%, industry 7%,
and commerce and services 82% —','37fe0b36847d4578c7fe6581f7b34f15359a0c0b12a272b62399f622cdefb5be','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4e82e1c615e90341467a249cbdf34f574bb1bdbcc93e8eb1bb206be30b8153',1986,'AR','Argentina','people-and-society',32,'Population: 31,186,000 July 1986), average
annual growth rate 1.5%
Nationality: noun—Argentine(s); adjec- ‘
tive—Argentine
Ethnic divisions: approximately 85% white,
15% mestizo, Indian, or other nonwhite -
groups
Religion: 90% nominally Roman Catholic
(less than 20% practicing), 2% Protestant, 2%
Jewish, 6% other
Language: Spanish (official), English, Italian,
German, French
Infant mortality rate: 36/ 1/000 (1983)
Life expectancy: 68
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Argentina (continued) .
Literacy: 94%
Labor force: 16.8 million (1984 prelim. )s
15.9% agriculture, 24.3% manufacturing,
13.2% commerce, 11.5% transport and com-
munications, 7.7% finance and banking,
4.4% utilities, 3.6% construction, 2.7% min--
ing, 16.8% services and other; 4.6% unem-
ployment (1984)
Organized labor: 3 million; about 33% of
labor force (est.)','3fcd2e561f102aeb88bb8a5c06e9b1c979de66dce80c2702a140b624ee39df3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27b88af1ae0debd64469f9e0332d10e1ab9b48c0d756cc6a4e562424661c1cfa',1986,'AW','Aruba','people-and-society',36,'Population: 67, 014 1E86 est.)
Natiohaliey: noun—Aruban() aaa.
Aruban :
Ethnic divisions: 85% mixed African; re-
mainder Carib Indian, European, Latin, and
Oriental
Religion: 82% Roman Catholic, 8% Protes-
tant; also small Hindu, Muslim, Confucian:
and Jewish minority
Language: Dutch (official), Papiamento (a
Spanish, Portuguese, Dutch, English dia- a
lect), English (widely spoken), Spanish
Literacy: 95%
Labor force: 30% oil refining;-10% unem- -. —
ployment
Government es
Official name: Aruba
Main town: Oranjestad
Type: self-governing until complete inde- ©
pendence from the Netherlands is granted in
1996
ll
Legal system: based on Dutch civil law sys-
tem, with some English common law influ-. .
ence
Government leader: Felipe TROMP, Gov-
ernor (since January.1986); Henny, EMAN,. ..
Prime Minister (since January 1986)
Suffrage: universal over age 18
Political patties and leaders: People’ s Elec:
toral Movement (MEP), G. F. ““Betico”
Croes; Aruban Patriotic Party (PPA), Benny .
Nisbet; Aruban People’s Party (AVP), He-
nny Eman; Democratic Party of Aruba
(PDA), Dr. Leo Berlinski; National Demo-
cratic Action Party (ADN), John Booi','98bdb66ff455369400745f9be0a893eeca1eae12ae91b5935a8c486bd9445fad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3966e0de14a8908b936ddfed41a7cbbb8979efa93e6405ad6f0474e5f99ad54a',1986,'AU','Australia','people-and-society',39,'Population: 15,793,000 (July 1986), average
annual growth rate 1.0%
Nationality: noun—Australian(s); adjec-
tive—-Australian
Ethnic divisions: 99% Caucasian, 1% Asian
and Aboriginal
Religion: 26.1% Anglican, 26.0% Roman
Catholic, 24.3% other Christian
Language: English, native languages
Infant mortality rate: 10/1,000 (1983)
Life expectancy: men 71:2, women 78.2
Literacy: 98.5%
Labor force: 7.2 million (March 1985); 30.6%
industry, 6.5% agriculture; 7.8% unemploy-
ment (December 1985)
”)
Organized labor: 55% of totalemployees -
(December 1983)
Population: 7,546,000 (July 1986), average
annual growth rate 0%
Nationality: noun—Austrian(s ); adjective—
Austrian :
Ethnic divisions: 99.4% German, 0.3%
Croatian, 0.2% Slovene, 0.1% other
Religion: 88% Roman Catholic, 6% Protes-
tant, 6% none or other
Language: German
Infant mortality rate: 16/1,000 (1983)
Life expectancy: 73
Literacy: 98%
Labor force: 2.9 million (1984); 41.10% in-
dustry and crafts, 57.55% services, 1.35%-
agriculture and forestry; 4.5% unemployed
(average 1984); an estimated 200,000 Austri-
ans are employed in other European coun-
tries; foreign laborers in Austria number
138,700, about 5.4% of labor force (1984)
CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Austria (continued)
Organized labor: 1,672,820 members of
Austrian Trade Union Federation (1984)
Population: 235,000 (July 1986), average
annual growth rate 1.8%
Nationality: noun—Bahamian(s); adjec-
tive—Bahamian
Ethnic divisions: 85% black, 15% white
Religion: Baptist 29%, Anglican 23%,
Roman Catholic 22%, smaller groups of
other Protestants, Greek Orthodox, and J ews
Language: English; some Creole among
Haitian immigrants
Infant mortality rate: 20.20/1,000(1984)
Life expectancy: men 64, women 70
Literacy: 89%
Labor force: 82,000 (1982); 30% govern-
ment, 25% hotels and restaurants, 10%
15
business services, 6% aenedliues 380% unem-
ployment (1983)
Organized labor: 25% organized','9c800cf9dea289f2ec5058a5bfcebcc028f8da8603c2b6480e3f25a2812ad410','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be3889c82564bd5cd441eb67d48f7cb3dbbba1c019eb288aaebda45bd9312459',1986,'BH','Bahrain','people-and-society',46,'Population: 422,000 (July 1986), average
annual growth rate 3.5% . ;
Nationality: noun—Bahraini(s); adjective—
Bahraini
Ethnic divisions: 63% Bahraini, 13% Asian,
10% other Arab, 8% Iranian, 6% other
Religion: Muslim (70% Shi‘a, 30% Sunni)
Language: Arabic (official); English also -
widely spoken; Farsi, Urdu
Literacy: 40%
Labor force: 140,000 (1982); 42% of labor
force is Bahraini; 85% industry and com-
merce, 5% agriculture, 5% services, 3% gov-
ernment
Government ee
Official name: State of Bahrain ~
Type: traditional monarchy; independent
since 1971
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Capital: Manama
Legal system: based’on Islamic law and"
English common law; constitution went into
effect in December 1973
National eliday: 16 December
Branches: Andi aie with help of a Cabinet
led by Prime Minister; Amir dissolved the
National Assembly in August 1975 and sus- -
pended the constitutional provision for elec-
tion of the Assembly; independent judiciary
Government leader: Isa bin Sulman Al
KHALIFA, Hus seid November 1961) ,
Sateiaen none
Political parties and pressure groups: politi-
cal parties prohibited; several small, clandes-
tine leftist and Shi‘a fundamentalist groups
are active .. .
Communists: negligible
Member of: Arab League, FAO, G-77,
GATT (de facto), GCC, IBRD, ICAO,
IDB—Islamic Dévelopment Bank, ILO,
IMF, IMO, INTERPOL, ITU, NAM, -
OAPEC, OIC, UN, UNESCO, UPU, WHO_
Economy © _ ae
GDP: $4.0 billion at current prices (1982
est.), $10, 000 per capita; real growth rate 9%
(1981)
Notun resources: oil, associated and nonas-
sociated natural gas, fish
Reasiiaié: not self-sufficient in food pro-
duction; produces some fruit and vegetables;
engages in dairy and poultry farming and i in
shrimping and fishing *~
Major industiles: petroleum processing and
refining, aluminum smelting, offshore bank-
ing, lip repairing.
Bion power: 1, AOT, 800 kw capacity — -
(1985); 6.166 billion kWh produced (1985),
14, ,440 kWh per capita
Exports: $3.1 billion (f.0.b., 1984); nonoil
exports $400 million (1984). oil exports met 7
billion ees)
Imports: $3.5 billion (c.i-f., 1984):nonoil
imports $1.9 billion (1984) oil imports $1.6
billion (1984)
Major trade partners: J apan, UK; US, Saudi
Arabia -
Budget: (1985) $967 eae set expend-
iture, $556 million capital
Monetary conversion rate: 0.38 Bahrain —
dinar=US$1 (October 1985) .
Fiscal year: calendar year','889f2776b864031c01a2d033e2ae96ba8fcb359a141a21bb7dd339e8b3160e21','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe7f1363d47274a0d03c08fa77fa4a21fd57be90eb00397b25724ca62af7ed82',1986,'BD','Bangladesh','people-and-society',49,'Population: 104,205 000 que 1986), aver-
age annual growth rate 2.7%
Nationality: noun—Bangladeshi(s); adiec-
tive—Bangladesh
Ethnic divisions: 98% Bengali; 250,000
“Biharis” and fewer than one million tribals
Religion: 83% Muslim, about 16% Hindu,
less than 1% Buddhist, Christian, and other
Wasiane: Bangla (official), English widely
used
Infant mortality rate: 119.4/1,000 (1984)
Life expectancy: 53
Literacy: 29%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 ©
Bangladesh (continued)
Labor force: 35.1 million (FY86); extensive’
export of labor to Saudi Arabia, UAE, -
Oman, and Kuwait; 74% of labor force is in
agriculture, 15% services, 11% industry and
commerce (FY81/82); unemployment and
underemployment 40% (est.) -','3df60c91725e61333a3bf755b64ea45d6d81528ceede6663ba8e54927379cc05','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95859fb4f7d47881fbf87e46f9f670f57360882842bd90b68c9160e5234f5f39',1986,'BB','Barbados','people-and-society',53,'Population: 253,000 (July 1986), average_.
annual growthrate 0.5% -- . hina By
Nationality: oe
tive—Barbadian
Ethnic diesen: 80% AtHeak 16% Peer
4% European
Religion: 10% aiciicae 9% Methodist, 4%
Roman Catholic, 17% other, including . -
Moravian
Language: English
Infant- mortality rate: 26.3/1,000 (1984)
Life expectancy: 70.8
Literacy: 99%.
Labor force: 112,300 (1985 est.); 36.8% ser-
vices and government; 22.4% commerce;
21.8% manufacturing and construction;
9.3% transportation, storage, ©.
communications, and finanacial institutions;
8.1% agriculture; and 2.1% utilities -
Organized labor: 82%','6ad45dcd442218703aca42a5902f99af7151c87806e88294f2b9abfbff890e4d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1216744fc2c358d7fc729ed25823c39b52efff2614eee06a9c5c22aa346ef6b4',1986,'BE','Belgium','people-and-society',57,'Population: 9,868,000 (July 1986), average
annual growth rate 0.1%
Nationality: noun—Belgian(s); adjective—
Belgian
Ethnic divisions: 55% Fleming, 33% Wal-
loon, 12% mixed or other
Religion: 75% Roman Catholic, remainder
Protestant, none, or other
Language: 56% Flemish (Dutch), 32%
French, 1% German; 11% legally bilingual;
divided along ethnic lines
Infant mortality rate: 11.15/1,000. (1979)
Life expectancy: men 68.6, women 75.1 —
Literacy: 98%
20
Labor force: 4 million (1985); 59% services,
37% industry, 5% agriculture; 13.6% unem-
ployed (1985)
Organized labor: 70% of labor force','a10ed8c321f2c84173a4d01a91804f2ebe49892a9bc70907b71519b3e2cdcd36','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d213ada1bbefbbea34e8b006bdadfb07e84db728c401895b9660e25a75ee382',1986,'BZ','Belize','people-and-society',61,'Population: 168,000 (July 1986), average
annual growth rate 2.2%
Nationality: noun—Belizean(s); adjective—
Belizean
Ethnic divisions:51% black, 22% mestizo,
19% Amerindian, 8% other
Religion: 50% Roman “Caihelié Anglican,
Seventh-Day Adventist, Methodist, ‘Baptist,
Jehovah''s Witnessés, Mennonite
Language: English (official), Spaai Maya,
Carib ,
Halen mortality ra rate: Heb 1,000 ae:
Life expectancy: 66
iiletacy: about 90%
Labor force: 51,500 (1984); 30.0% agricul-
ture, 16.0% services, 15.4% government,”
11.2% commerce, 10.3% manufacturing;
shortage of skilled labor and all types of
technical personnel; over 14% are unem-
ployed
Organized labor: 15% of labor force','4f4a78e1e43ef063c1ef4fe698f103143821992b00356197378aada8adeec6bf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271f240905133286688245edcec8039e667d2638cd46132d1d8718744bad3779',1986,'BJ','Benin','people-and-society',65,'Population: 4,141,000 (July 1986), average
annual growth rate 3.1%
Nationality: noun—Beninese (sing., pl.);
adjective-—Beninese
Ethnic divisions: 99% African (42 ethnic
groups, most important being Fon, Adja,
Yoruba, Bariba); 5,500 Europeans
Religion: 70% indigenous beliefs, 15% Mus- -
lim, 15% Christian
Language: ictal (official); Fon and Yoruba
most common vernaculars in south; at least
six major tribal languages in north
Infant mortality rate: 45/1,000 (1984)
Life expectancy: 46.9
23
Literacy: 20%
Labor force: 1.5 million (1982); 70% of labor
force employed in agriculture; less than 2% -
of the labor force work in thé:indistrial sec-
tor, and the remainder are. employed i in
transport, ‘commerce, and public services
Organized labor; approximately 75% of
wage earners, divided among two''major and
several minor unions ©
Population: 105,448,000 (July 1986), aver-
age annual growth rate 2.6%
Nationality: noun—Nigerian(s); adjective—
Nigerian
Ethnic divisions: of the more than 250 tribal
groups, the Hausa and Fulani of the north,
the Yoruba of the southwest, and the Ibos of
the southeast comprise 65% of the popula-
tion; about 27,000 non-Africans
Religion: no exact figures on religious break-
down, but about 50% Muslim, 30% Chris-.
tian, and 20% indigenous beliefs
Language: English (official); Hausa, Yoruba,
Ibo, Fulani, and several other languages also
widely used
Infant mortality rate: 157/1,000 (1981)
Life expectancy: men 45.9, women 49.2
Literacy: 25-30%
Labor force: est. 35-40 million (1984); 56%
agriculture; 17% industry, commerce, and
services; 15% government —
Organized labor: 3.52 million wage earners —
belong to one of 42 recognized trade unions,
which are under a single national labor fed-
eration, the Nigerian Labor Congress (NLC)','104a316cfcba16f3f9608dd4bb65ad933004e7fc001f0a2837764da124bb1916','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7a3f7bb40ad5cb19e58f536118e2e18b313a3c8b7df756176e3468de95a0a91',1986,'BT','Bhutan','people-and-society',72,'Population: 1,446,000 (July 1986), average
annual growth rate 2.0%
Nationality: noun—Bhutanese (sing., pl.);
adjective—Bhutanese .
Ethnic divisions: 60% Bhote, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25%
Indian- and Nepalese-influenced Hinduism
Language: Bhotes speak various Tibetan
dialects—most widely spoken dialect is
Dzongkha (official); Nepalese speak various
Nepalese dialects
Infant mortality rate: 162/1,000 (1983)
Life expectancy: 43
Literacy: 5%
Labor force: 95% agriculture, 1% industry
and commerce (1983); massive lack of skilled
labor
Population: 6,358,000 (July 1986), average
annual growth rate 2.6%
Nationality: noun—Bolivian(s); adjective |
Bolivian
Ethnic divisions: 30% Quechua, 25%
Aymara, 25-30% mixed, 5-15% European
Religion: 95% Roman Catholic; active Prot-
estant minority, especially Methodist
Language: Spanish, Quechua, and Aymara
(all official)
Infant mortality rate: 142 /1,000 (1983)
Life expectancy: 49
Literacy: 63%
Labor force: 1.7 million (1983) 50% agricul-
ture, 26% services and utilities, 10% manu-
facturing, 4% mining, 10% other
Organized labor: 150,000-200,000, concen- -
trated in mining, industry, construction, and
transportation; mostly organized under
Bolivian Woarkers’ Central (COB) labor, <7
federation
Gaverinent “2
Official name: Republie of Bolivia’
Tipe: fepubliec. Bees
Capital: La Paz (seat of government); Sucre
(legal capital and seat of judiciary) ievnee?
Political: dibdivisions nine departments:
with limited autonomy: -
Legal system: al on Spanish law and:
Code Napoleon; constitution adopted 1967;
constitution in force.except whére contrary ©:
to dispositions dictated by governments
since 1969; legal education at University of |
San Andrés and several others; has not ac-
cepted compulsory ICJ, suedichicn
National Jioliday: Independence Day 6 Au-
gust :
Branches: executive; bicameral legislature
(National Congress—Senate aid Chamber *:
of Deputies); Congress began meeting again
in October 1982; judiciary ©
Governmeni leader: ‘Victor PAZ Estenssoro, *
President (since August 1985)’
Suffrage: universal and compulsory at age
18 if married, 21 if single .
Elections: presidential elections.on 14 July.
1985 did not produce:the-required majority .
for any of the three leading candidates; |-. .
Victor Paz Estenssoro, center-left leader of
the Nationalist Revolutionary: Movement
(MNR), placed second in the popular vote to ;
center-right Hugo Banzer, head of the Na-
tionalist Democratic Action (ADN); how-
ever, the MNR won 94 congressional seats”
compared tothe ADN’s 51; as''a result, the
Bolivian Congress on 5 August chose Paz
Estenssoro to head the government; he was
inaugurated on 6 August -
Political parties and leaders: the two parties
which garnered the most votes in. the 1985: . .
elections, the Nationalist Revolutionary
Movement (MNR)and the Nationalist Dem-
ocratic Action (ADN), continue to have a.
27
tactical alliance; MNR, Victor Paz
Estenssoro; ADN, Hugo Banzer; Movement
of the Revolutionary Left (MIR), Jaime Paz
Zamora; Nationalist Revolutionary Move-
ment of the Left (MNRI), Hernan Siles
Zuazo; Bolivian Soéialist Falange (FSB),
Mario Gutiérrez; Authentic Revolutionary
Party (PRA), Walter Guevara; Christian
Democratic Party (PDC), Benjamin Miguel;
Nationalist Revolutionary Party of the Left,
Juan Lechin Oquendo, ;
Voting strength: (1985 election) ADN
28.11%, MNR 26.66%; MIR 8.86%
Member of: FAO, G-77; IADB, IAEA, ©”
IATP, IBRD, ICAO, ICO, IDA, IDB—Inter-
American Development Bank, IFAD, IF C,.
ILO, IMF, INTELSAT, INTERPOL, Iso,
ITC, ITU, [WC—International Wheat
Council, LAIA and Andean Sub-Regional - :
Group (created in May 1969 within LAIA,
formerly LAFTA),-NAM, OAS, PAHO,
SELA, UN, UNESCO, UPU, WHO, WMO,
WTO >
Economy eG mx be,
GNP: $4 billion (1985 ms ), $400 per capita;
94% private consumption, 9% public con:
sumption, 7% gross domestic investment;
— 10.0% current account balance (1983);
real growth rate —4% (1984) -
Natural resources: tin, natural gas, petro-
leum; zinc, tungsten, antimony, silver, iron:
ore CG. ae
Agriculture: main''ctops—potatoes, corn;
rice, sugarcane, yucca, bananas, coffee; im- "
ports''significant quantities of wheat; an ille-:
gal producer of coca for the international’ - -
drug trade 22,
Major industries: mining, smelting, petro-
leum refining, food processing, textiles, and
clothing
Electric power: 490,000 kW capacity (1985);
2 billion kWh produced (1985), 323 kWh per
capita
Exports: $730 million (f.0.b., 1984 est.), tin, ,
natural gas, silver, tungsten, zinc, antimony,
lead, bismuth, gold, coffee, sugar, cotton
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Bolivia (continued)
Imports: $477 million (c.if., 1984 est.), food-
stuffs, chemicals, capital goods, pharmaceu-
ticals, transportation
Major trade partners: exports—Argentina
44%, US 24%, EC 19%, FRG 6%, UK 4%;
imports—Brazil 22%, US 16%, EC 16%, Ar-
gentina 14%, Japan 13%, FRG 4% (1984)
Budget: $257 million revenues, $1,856 mil-
lion expenditures (1984 est.)
Monetary conversion rate: 75,000
pesos= US$] (August 1985)
Fiscal year: calendar year','259ea0f27225c8cc61bb37bb523cbeddf5fda094ea5ff3c5659dc40cf8343a4e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6f5187408ce9db023873c2c20c400a7ef8e668049301c651f293bc692079846',1986,'BW','Botswana','people-and-society',76,'Population: 1,104,000 (July 1986), average
annual growth rate 3.3%
Nationality: noun—Motswana (sing.),
Botswana (pl.); adjective—Botswana
Ethnic divisions: 95% Batswana; about 4%
Kalanga, Basarwa, and Kgalagadi; about 1%
white
Religion: 50% indigenous beliefs, 50% Chris-
tian
Language: English (official), Setswana
Infant mortality rate: about 68.4/1,000
(1981)
Life expectancy: 56
Literacy: about 24% in English; about 35%
in Tswana; less than 1% secondary school
graduates
Labor force: about 400,000 total; 110,000
formal sector employees (1984); most others
are engaged in cattle raising and subsistence
agriculture; 40,000 formal sector employees
spend at least six to nine months per year as
Declassified and Approved For Release 2012/08/29 : CIA-RDPO08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
wage earners in South Africa (1980); 17%
unemployment (1983)
Organized labor: 16 trade unions organized ,
Population: 143,277,000 (July 1986), aver-
age annual growth rate 2.5% ae
Nationality: noun—Brazilian(s); adijective—
Brazilian
Ethnic divisions: Portuguese, Italian, Ger-.
man, Japanese, black, Amerindian; 55%
white, 38% mixed, 6% black, 1% other
Religion: (1980) 89% Roman Catholic (nomi-
nal) ae ath :
er
Language: Portuguese (official), English _
Infant mortality rate: 92/1,000 (1981)
Life expectancy: 62.8
Literacy: 76%
Lakes force: 50 million i in 1984; ‘40%. Ser:
vices, 35% agriculture, 25% industry
y
Organized.labor: about,6 million (1984) As
4 tee GS eet ena.
Covemiient n
Official name: Federative Republic of Brazil
Type: federal republic; democratically
elected president since March. 1985 -
Capital: Brasilia
Political subdivisions: 29, states, ‘4 territories,
1 federal district (Brasilia)
Legal system: based on Latin codes; dual
system of courts, state and federal; constitu-
tion adopted in 1967 and extensively
amended in 1969; has not accepted compul-
sory ICJ jurisdiction
National holiday: Independence Day, 7
September
Branches: strong executive with very broad
powers; bicameral legislature (National Con-
gress—Senate, Chamber of Deputies; pow-
ers of the two bodies are growing); ll-man
Supreme Court
Government ead J osé SARNEY ists
President (since April 1985) |
Suffrage: Pe et over age 18 —
Elections: Tancredo Neves indirectly
elected by an electoral college composed of
members of congress and delegates from the
state legislatures, ending 20 years of military
tule; died before assuming office; municipal
elections held November 1985; congres-
sional and gubernatorial elections scheduled
for November 1986.
Political parties and leaders: Brazilian
Democratic Movement Party (PMDB),
Ulysses Guimaraes, president; Liberal Front
Party of President Sarney’s government coa-
lition, Jorge Bornhausen, president; other
parties— Workers Party (PT), Brazilian La-
bor Party (PTB), Democratic Labor Party
(PDT), and Democratic Social Party (PDS);
Communist parties legalized in March
1985—Brazilian Communist Party (PCB)
and Communist Party of Brazil (PCdoB)
-''30
Voting strength: (November 1982 federal
and state elections) 37% then progovern-
ment PDS; 63% divided among four opposi-
tion parties (PMDB, PT, PTB, and PDT)
Communists: 6,000, less than 1,000 mili-
tants
Other political or pressure groups: left wing
of the Catholic Church and labor unions
allied to leftist Worker’s Party were critical
of military government’ s social] and eco-
nomic policies
Member of: FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAC, ICAO, ICO, IDA,
IDB—Inter-American Development Bank,
IFAD, IFC, EHO, ILO, IMF, IMO,
INTELSAT, IPU, IRC, ISO, ITU, IWC—
International Wheat Council, OAS, PAHO,
SELA, UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO ,
Population: no permanent civilian popula- *''
tion; formerly about 3,000 islanders’
Ethnic divisions: original inhabitants,
known as the Ilois, evacuated to Mauritius
- before construction of US and UK defensé
facilities','4f2db11d64ce10f8bddfbef8961ce50372e0e39bd2680ea6ee6dc4903dba0fbf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5943a94f5b204052ba39f73eff235fa513ea51cb67e1b6e80d20897875b4bed2',1986,'IO','British Indian Ocean Territory','people-and-society',82,'Population: 12,000 July 1986), average an-
nual growth rate 1.0%
Nationality: noun—Virgin Islander(s); ad- :
jective—Virgin Islander
Ethnic divisions: over 90% black, remainder
of white and Asian origin
Religion: majority Methodist; others include
Anglican, Church of God, Seventh-day
Adventist, Baptist, and Roman Catholic :
Language: English (official)
Literacy: 98.3%
Work force: 4,911 (1980)
Population: 240,000 July 1986), average
annual growth rate 3.7%
Nationality: noun—Bruneian(s), adjective—
Bruneian
Ethnic divisions: 64% Malay, 20% Chinese,
16% other
Religion: 60% Muslim (official); 8% Chris-
tian; 32% Buddhist and indigenous behets
Language: Malay (official), English, -
Chinese
Life expectancy: 73.7
Literacy: 45%
Labor force: 68,128 (includes members of
the Army); 50.4% production of oil, natural
gas, and construction; 47.6% trade, services,
33
and other; 2.0% agriculture, forestry,’and es
fishing (1984) SS
Organized labor: 2% of labor force °. Ses
Population: 8,990, 000 (July 1986), average *
annual growth rate 0.2%
Nationality: noun—Bulgarian(s); adjec-
tive—Bulgarian
Ethnic divisions: 85.3% Bulgarian, 8.5%
Turk, 2.6% Gypsy, 2.5% Macedonian, 0.38%
Armenian, 0.2% Russian, 0.6% other
Religion: regime promotes atheism; reli-
gious background of population is 85% Bul-
garian Orthodox, 13% Muslim, 0.8% Jewish,
0.7% Roman Catholic, 0.5% Protestant,
Gregorian-Armenian, and other
Language: Bulgarian; secondary languages
closely correspond to ethnic breakdown
Infant mortality rate: 20.2/1,000 (1983)
Life expectancy:''men 69, women 74
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Literacy: 95% (est.)
Labor force: 4,113,546 (1983); 34% industry,
22% agriculture, 46% other
Population: 7,094,000 (July 1986), average
annual growth rate 2.7%
Nationality: noun—Burkinabe; adjective—
Burkinan
Ethnic divisions: more than 50 tribes; prin-
cipal tribe is Mossi (about 2.5 million); other
important groups are Gurunsi, Senufo, Lobi,
Bobo, Mande, and Fulani
Religion: 65% indigenous beliefs, about 25%
Muslim, 10% Christian (mainly Catholic)
Language: French (official); tribal languages
belong to Sudanic family, spoken ey 50% of:
the population
Infant mortality rate: 182/ 1,000 (1984)
Life expectancy: 42
Literacy: 7%
Labor force: 90% agriculture; 10% industry,
commerce, services, and government; about
80,000 are wage earners; about 20% of male
labor force migrates annually to neighboring
countries for seasonal;employment
Organized labor: four principal trade union
groups represent less than 1% of population
Population: 37,651,000 July 1986), average
annual growth rate 2.0%
Nationality: noun— Burmese; adjective—
Burmese ; :
Ethnic divisions: 72% Burman, 7% Karen,
6% Shan, 6% Indian, 3% Chinese, 2%
Kachin; 2% Chin, 2% other
Religion: 85% Buddhist, 15% indigenous
beliefs; Christian, or other ;
Language: Burmese; minority ethnic groups
have their own languages
Infant mortality rate: 98.2/1,000 (1984 est.)
Life expectancy: 57
Literacy: 78%
"37
Labor force: 14.7 million (1984/85); 63.6%
agriculture, 12.0% government, 9.5% trade,
9.4% industry, 5.5% other
Organized labor: Workers’ Asiayone or
“association” (1.8 million members) and
Peasants’ Asiayone (7. 6 million members)
integrated into the country’s sole political
party','279459b007f62be9c9ce3d3924ef68249c3212697106356999da42c04283bcfd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a43a9c68eab1032065126c044c315dfeb6dd910f97b2048295db31bd31fa4de2',1986,'BI','Burundi','people-and-society',84,'Population: 4,807, 000 (July 1986), average
annual growth rate 2.8%
Nationality: noun—Burundian(s); adiec-
tive—Burundi
Ethnic divisions: Africans—85% Hutu
(Bantu), 14% Tutsi (Hamitic), 1% Twa
(Pygmy); other Africans include around
70,000 refugees, mostly Rwandans and Zair-
ians; non-Africans include about 3,000 Euro-
peans and 2,000 South Asians
Religion: about 67% Christian (62% Roman,
Catholic, 5% Protestant), 32% indigenous
beliefs, 1% Muslim
Language: Kirundi and French (official);
Swahili (along Lake Tanganyika and in the
Bujumbura area)
Infant mortality rate: 121/1,000 (1983)
Life expectancy: 42.8
Literacy: 25%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: about 1 9 million (1983); 93.0%
agriculture, 4.0% government, 1.5% indus-
try and commerce, 1.5% services
Organized labor: sole group is the Union of
Burundi Workers (UTB); by charter, mem-
bership is extended to all Burundi‘workers
(informally); figures denoting “active
membership” unobtainable','1b4f56a9dae50202aeb092c01437dd9ca9555077b91fe0945ba61964c5e10982','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fb2f19b83e29a1411a1a5d00821bfc5bae497f31012d6b2f4f4ca6916450d5d',1986,'KH','Cambodia','people-and-society',88,'Population: 6,388,000 (July 1986), average
annual growth rate 2.2%
Nationality: noun—Cambodian(s, s); adiec-
tive —Cambodian
Ethnic divisions: 90% Khmer (Cambodian),
5% Chinese, 5% other.minorities
Religion: 95% Theravada Buddhism, 5%
other,
Language: Khmer (official), French
Life expectancy: men 42, women 44.9
Literacy: 48%','9831ff47760a101b9fd1fc6f54467987206a40ca45439a58f3d4458cb38dabb0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eef4c32e8a1dc2b69f642d917fa1ac3ee6576a4bc9c364e0b7ae7d40c86ed031',1986,'CA','Canada','people-and-society',96,'Population: 318,000 (July 1986), average
annual growth rate 1.9%
Nationality: noun—Cape Verdean(s); adjec-
tive—Cape Verdean
Ethnic divisions: about 71% Creole
(mulatto), 28% African, 1% European
Religion: Catholicism fused with local
superstitions
Language: Portuguese and Crioulo, a blend
of Portuguese and West African words
Infant mortality rate: 60/1,000.(1983)
Life expectancy: 61
Literacy: 37%
44
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: bulk of population engaged in
subsistence agriculture
Population: 22,000 (July 1986), average an-
nual growth rate 2.8%
Nationality: noun—Caymanian(s); adjec-
tive—Caymanian
Ethnic divisions: 40% mixed, 20% white,
20% black, 20% expatriates of various ethnic
groups ,
Religion: United Church (Presbyterian and
Congregational), Anglican, Baptist, Roman
Catholic, Church of God, and other Protes-
tant denominations ee Ag
Language: English
Literacy: 97.5%
Labor force: 8,061; 18.7% service workers,
18.6% clerical, 12.5% construction, 6.7%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Cayman Islands (continued)
finance and investment, 5.9%''difectors and -
business managers (1979)
Organized labor: Global Seaman’s Union;
Cayman All Trade Union * ae','26ff4f4f191beca60af278e72606a23267edbbdaf5b7296ef579e944b0aaff55','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a556e3d19e4816cb9fd1c944c4f525451747a7fb7979be1fee592d2483c8b22c',1986,'CF','Central African Republic','people-and-society',98,'Highways: 160 km of main roads Population: 2,744,000 (uly 1986), average -
, annual growth-rate 3.0%
Ports: ] major. ‘(George Town), 1 minor
Nationality: rioun-—Central African(s); ad-
Airfields: 3 total; 3 usable; 2 with ~ jective—Central African ~
permanent-surface runways 1220-2439 m
- ; coe Ethnic divisions: approximately 80 ethnic
groups, the majority of which have related
ethnic and linguistic characteristics; 34%
Telecommunications: telephone system ~
links islands and to worldwide:services via
submarine coaxial cable and new satellite Baya, 28% Banda, 10% Sara, 9% Mandiia,
ground station; 2 AM and 2 FM radio sta- 9% Mboum, 7% M’Baka; 6,500 Europeans,
tions ~- - ; ue of whom 3,600 are French
Religion: 25% Protestant, 25% Roman Cath-
olic, 24% indigenous beliefs; 10%. Muslim;
animistic beliefs and practices strongly in-
fluence the Christian majority —‘
Defense Forces :
Defense is the responsbility of the United
Kingdom ~~ *) ;
Branches: police force
Language: French (official); Sango’is the
lingua franca and the national language
Infant mortality rate: 142/1, 000 (1985)
Life expectancy: 47. Le
Literacy: est. 33%
46
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: 1,320;000 (1983); 90% agricul-
ture, 4% industry and commerce, 4% ser-
vices, 4% government; approximately _
64,000 salaried workers
Organized labor: 1% of labor force
Government 4
Official name: Central African Republic
Type: republic, under military rule since
September 1981; the president shuffled the
government in September 1985 and dis-
solved the Military Committee for National
Recovery; the president now rules through
the Provisional Organization of Public .
Powers
Capital: Bangui
Political subdivisions: 14 prefectures, 47 _
subprefectures
Legal system: based on French law; consti-
tution, which was approved in F ebruary
1981 referendum, was suspended after Sep-
tember 1981 military takeover; judiciary,
Supreme Court, court of appeals, criminal
court, and numerous lower courts
National holiday: Independence Day, 13
August; National Day, 1 December
Branches: Gen. André-Dieudonné Kolingba
is Chief of State and President of the Provi-
sional Organization of Public Powers, which
replaced the Council of Ministers; no legisla-
ture; separate judiciary
Government leader: Gen. André-
Dieudonné KOLINGBA,; Chief of State and
President of the Provisional Organization of
Public Powers (since September 1985; head
of government since September 1981)
Suffrage: universal over age 21
Elections: none scheduled
Political parties and leaders: political par-
ties banned in September 1981
Communists: no Communist party; small
number of Communist sympathizers
Member of: A{DB, Conference of East and
Central African States, EAMA, ECA, FAO,
G-77, GATT, IBRD, ICAO, ICO, IDA,
IFAD, ILO, IMF, INTELSAT, INTERPOL,
ITU, NAM, OAU, OCAM, UDEAC, UEAC,
UN, UNESCO, UPU, WHO, WIPO, WMO','afdfb2cfca94d9b715867bbe5c7437a29febc7da651c4142ce63c88163be9800','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13cec6779b47007294071499ed0ecbad955d8e858dbc78ad5ff261f3ac55b03d',1986,'TD','Chad','people-and-society',101,'Population: 5,231,000 (July 1986), average
annual growth rate 3.8%
Nationality: noun—Chadian(s); adjective—
Chadian
Ethnic divisions: some 200 distinct ethnic
groups, most of whom are Muslims (Arabs,
Toubou, Fulbe, Kotoko, Hausa, Kanembou,
Baguirmi, Boulala, and Maba) in the north
and center and non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moudang,
Moussei, Massa) in the south; some 150,000
nonindigenous, of whom 1,000 are French
Religion: 52% Muslim, 43% indigenous be-
liefs, 5% Christian . ot
Language: French and Arabic (official); Sara
and Sango in south; more than 100 different
languages and dialects are spoken
Infant mortality rate: 142/1,000 (1983)
Life expectancy: men 41.5; women 43.9 -
Literacy: about 20%
Labor force: 85% agriculture (engaged in
unpaid subsistence farming, herding, and
fishing) .
Organized labor: about 20% of wage labor
force','0e2b0f19a959da2960795dfdc182c8dadf80330902b1631720fb4b06539179f8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5647a39aada2b20955b981dd6d05bf2bfb5bda09c26a4ce036a9933571474151',1986,'CL','Chile','people-and-society',105,'Population: 12,261,000 (July 1986), average
annual growth rate 1. 8%
Nationality: noun—Chilean(s); adjective—
Chilean
Ethnic divisions: 95% European and
European-Indian, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protes-
tant
Language: Spanish
Infant mortality rate: 27.2/1,000 (1981)
Life expectancy: men 63.8, women 70.4
Literacy: 90%
Labor force: 3.0 million total employment
(1982); 33% industry and commerce; 31%
49
services; 9% agriculture, forestry, and |”
fishing; 9% mining; 5% construction
Organized labor: 12% of labor force orga-
nized into labor unions (1982)
Government a
Official name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions; 12 regions plus one
metropolitan district, 41 Provincial ‘subdivi-
sions
Legal system: based on Code 1857 derived
from Spanish law and subsequent codes in-
fluenced by French and Austrian law; cur- -
rent constitution came into effect in March x
1981; the constitution provides for contin=
ued direct rule until 1989, with a phased’ ~ °
return to full civilian rule by 1997; judicial
review of legislative acts in the Supreme
Court; legal education at University of ©
Chile, Catholic University, and several
others; has not accepted compulsory ICJ ~’
jurisdiction
National holiday: Independence Day, 18
September
Branches: four-man Military Junta, which:
exercises constituent and legislative powers
and has delegated executive powers to Presi-_
dent; the Presidént has announced a plan for
transition from military to civilian rule pur-
suant to Constitution; state of siege lifted.
June 1985; National Congress (Senate, House
of Representatives) dissolved; civilian judi-
ciary remains
Government leaders: Gen. ‘Augusto
PINOCHET Ugarte, President (since Sep-
tember 1973); Adm. José Toribio MERINO
Castro (since September 1973), Air Force °
Gen. Fernando MATTHEI Aubel (since July
1978), Army Lt. Gen. Julio CANESSA
Roberts (since December 1985), Gen.
Rodolfo STANGE Oelkers (since AUEUSE
1985); Junta members
Suffrage: none
| Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Chile (continued)
Elections: prohibited by decree; all electoral
registers were destroyed in 1974
Political parties and leaders: all political
parties are officially recessed or outlawed
but have been allowed to function ona very..
limited basis since 1982; National Party
(PN), Patricio Philips; Independent Demo-
cratic Union (UDI), Sergio Fernandez; Na-
tional Unity Movement (MUN), Andrés
Allamand; Movement of National Action’
(MAN), Federico Willoughby; Radical Party
(PR), Enrique Silva Cimma; Social Demo- .
cratic Party (PSD), Luis Bossay;.Christian
Democratic Party (PDC), Gabriel Valdés;
Republican Right, Hugo Zepeda; Socialist -
Party, Ramon Silva Ulloa and J ulio Stuardo
(the PR, PSD, PDC, Republican Right, and
some elements of the Socialist Party form
the Democratic Alliance [AD] ), Movement
of Unitary. Popular Action (MAPU); Move- ,
ment of Unitary Popular Action—Workers/
Peasants (MAPU-OC), Blas Tomié and Oscar
Garreton Purcell; Christian Left (IC), Luis
Maira; Communist Party of Chile (PCCh),
Luis Corvalan Lepe (in exile); Socialist
Party—Almeyda faction (PSCh/Alm),
Clodomiro Almeyda (in exile); Socialist
Party—Altamirano faction (PSCh/ Alt),
Carlos Altamirano (in exile), Movement of
the Revolutionary Left (MIR), Andrés Pascal
Allende (in exile); the MIR, PSCh/Alm, and
PCCh form the leftist Popular Democratic
Movement (MDP)
Voting strength: (1970 presidential election)
36.6% Popular Unity coalition, 35.3% con-
servative independent, 28.1% Christian
Democrat; (1973 congressional election) 56%
Democratic Confederation (PDC and PN),
44% Popular Unity coalition
Communists: 120,000 when PCCh was legal.
in 1973; active militants now estimated at
about 20,000-50,000
Other political or pressure groups: revital-
ized university student federations at all
major universities dominated by political
groups; labor—National Workers Command
(CNT) includes trade unionists from the ©
country’s five largest labor confederations,
Roman Catholic Church | ‘
Member of: CIPEC, ECOSOC, FAO, G-77,
GATT, IADB, IAEA, IBRD, ICAO, IDA,.
IDB—Inter-American Development Bank, |
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU, LAIA, :
OAS, PAHO, SELA, UN, UNESCO, UPU,.
WHO, WIPO, WMO, WSG, wid ,','3b42f7f6383f624ad5228bb664baaade60277507c4e80d4debd24f0bb78e34ab','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0668b52d4a882a7ec6df56cf97ae34c45326e7f355bd8ff925924410076e20ed',1986,'CN','China','people-and-society',108,'Population: 1,045,537,000 (July 1986), aver--
age annual growth rate 0.8% °
Nationality: noun—Chinese (sing. , pl.); ad-
jective—Chinese
Ethnic divisions: 93.3% Han Chinese; 6.7%
Zhuang, Uygur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Buyi, Korean, and numer-
ous lesser nationalities
Religion: officially atheist: since.even before
1949 most people have been pragmatic,
eclectic, and not seriously religious; most
important elements of religion are Confu-
cianism, Taoism, Buddhism, ancestor wor-
ship; about 2-8% Muslim, 1% Christian
Limits of territorial waters (claimed): ag.) , *
Language: Standard Chinese (Putonghua) or
Mandarin (based on the Beijing dialect); also -
Yue (Cantonese), Wu (Shanghainese),
Minbei (Fuzhou), Minnan (Hokkien-
Taiwanese), Xiang, Gan, Hakka’ dialects,
and minority languages. (see ethnic divisions)
Life penboianiel: 68
Literacy: over 75% A
Labor force: est. 460 million (December ;
1983); 74.4% agriculture, 15.0% industry
and commerce, 10. 6% other
Gisitieed labor: All-China Redesign of
Trade Unions (ACF TU) follows the leader-
ship of the Chinese Communist Party;: mem-
bership about 77 million °
Population: 121,402, 000 (uly 1986), aver-
age annual growth rate 0.6%
Nationality noun—Japanese (sing., pl.)
adjective—Japanese
Ethnic divisions: 99.4% Japanese, 0.6%
other (mostly Korean)
Religion: most Japanese observe both Shinto
and Buddhist rites; about 16% belong to
other faiths, including 0.8% Christian
Language: Japanese
Infant mortality rate: 6/1,000 (1984)
Life expectancy: men 74.54, women 80.18
Literacy: 99%
Labor force: (1985) 59.3 million; 53% trade’ -
and services; 33% manufacturing, mining,
and construction; 9% agriculture, forestry,
128
and fishing; 3% government; 2.68% unem-~
ployed (1985 « ave.)
Organized inbee: about 30% of labor force
Population: 61,994,000 (July 1986), average
annual growth rate 2.5%
Nationality: noun—Vietnamese (sing. and
pl.); adjective— Vietnamese
Ethnic divisions: 85-90% predominantly
Vietnamese; 3% Chinese; ethnic minorities
include Muong, Thai, Meo, Khmer, Man,
Cham; other mountain tribes
Religion: Buddhist, Confucian, Taoist, Ro-
man Catholic, indigenous beliefs, Islamic,
Protestant
Language: Vietnamese (official), French,
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Infant mortality rate: 53/1,000 (1983)
Life expectancy: men 62, women 66
CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Vietnam (continued) .
Literacy: 78% |
Labor force: approximately 29 million, not
including military','b21bbe3bdefeb2c1132b1b03540f2d7f3686a1327838c7bdb7dfe83cba917c96','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64f26b838bc78e939dc9b88283131c8aa2818bfab2aa815e5eda96540fe9979c',1986,'CX','Christmas Island','people-and-society',112,'Population: 2,965 (as of June 1983), average
annual growth rate 0.6%
Nationality: noun—Christmas Islander(s),
adjective—Christmas Island
Ethnic divisions: 61% Chinese, 25% Malay,
11% European, 3% other; no indigenous
population - , :
Language: English
Labor force: all workers are employees of
the Phosphate Mining Company of Christ-
mas Island, Ltd. ;
Population: 29,956,000 (July 1986), average
annual growth rate 2.1% °
Nationality: noun—Colombian(s); adjec-
tive—Colombian
Ethnic divisions: 58% mestizo, 20% white,
14% mulatto, 4% black, 3% mixed black-
Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Infant mortality rate: 65/1,000 (1982)
Life expectancy: 62
Literacy: 80%
53
Labor force: 9 million (1982); 53% services,
26% agriculture, 21% industry (1981); 14%
official unemployment On)
Organized labor: 1,418,321 eee (1982)','aee3d478cc7aee222ef483dfac56c9ae1d0bd8676ccdf392f8485b1ba6d2d3d5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbba26aa3a20685229c39b11972ecd446ea2fd336d89b06f54e74ae877d5120c',1986,'KM','Comoros','people-and-society',116,'Population: 420,000 (July 1986), average
annual growth rate 2.9%
Nationality: noun—Comoran(s);
adjective—Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religion: 86% Sunni Muslim, 14% Roman
Catholic
Language: Shaafi Islam (a Swahili dialect)
Malagasy, French
9
Infant mortality rate: 92.3/1,000 (1983)
Life expectancy: 48.8
Literacy: 15%
Labor force: 140,000 (1982); 80% agricul-
ture, 3% government; significant unemploy-
ment','225d27835c29e6256e3d68cf573d754fe3ad098330b242ce0ec8f7bae7ec2045','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7219b23509553d7c34c86a5d95ac01a34580900f3edd9218b3087b5ce204688',1986,'GN','Guinea','people-and-society',120,'Population: 1,853,000 " uly 1986), average
annual growth rate 3.0%
Nationality: noun—Congolese (sing., pl.);
adjective—Congolese or Congo
Ethnic divisions: about 15 ethnic groups
divided into some 75 tribes, almost all
Bantu; most important ethnic groups are
Kongo (48%) in the south, Sangha (20%) and
M’Bochi (12%) in the north, Teke (17%) in
the center; about 8,500 Europeans, mostly
French
Religion: 48% animist, 47% Christian, 2%
Muslim
Language: French (official); many African
languages with Lingala and Kikongo most
widely used
Infant mortality rate: 200/1,000 (1983)
Life expectancy: men 68
Literacy: over 50%
Labor force: about 40% of population eco-
nomically active (1983); 75% agriculture, _
25% commerce, industry, government;
79,100 wage earners; 40,000- 60, 000 unem-
ployed
Organized labor: 20% of total labor force
(1979 est.)
Population: 1 017, 000 (July 1986), average
annual growth rate, 2.8% -_
Nationality: noun—Gabonese (sing., pl.);
adjective—Gabonese.
Ethnic divisions: about 40 Bantu tribes, in-
cluding 4 major tribal groupings (Fang,
Eshira, Bapounou, Bateke); about 100,000
expatriate Africans and Europeans, includ-
ing 35,000 rene.
Religion: 55-75% Christian, less than 1%
Muslim, remainder animist
Language: Pradch (official), Fang, Myene,
Bateke, ‘Bapoundu/Eschira, Bandjabi
Infant mortality rate: 117/1,000 (1983)
Life expectancy: 50
Literacy: 65%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 - CIA-RDP08-00534R000100170001-4
Labor force: 120,000 salaried (1983); 65.0%
agriculture, 30.0% industry and commerce,
2.5% services, 2.5% government
Organized labor: there are 38,000 members .
of the national trade union, the Gabonese . -
Trade Union Confederation (COSYGA)
Population: 774,000 (July 1986), average
annual growth rate 2.9%
Nationality: noun—Gambian(s); adjective—
Gambian
Ethnic divisions: 99% African (42%
Mandinka, 18% Fula, 16% Wolof, 10% Jola,
9% Serahuli, 3% other 1% non-Gambian
Religion: 90% Muslim, 9% Christian, 1%
indivetow beliefs
abate: English (official); Mandinka,
Wolof, Fula, other apeleen ous vernaculars
Infant mortality rate: 250/ 1, 000 ( (1984)
Life expectancy: 42
Literacy: about 15%
Labor force: 165,000 (1983 est.); 75.0% agri-
culture; 18.9% industry, commerce, and on
services; 6.1% government. ae
Organized labor: 25-80% of wage labor
force at most
Population: 16, 692, 000, including East Ber-
lin (July 1986), average annual growth rate
0%
Nationality: noun—German(s); adjective—
German . :
Ethnic divisions: 99.7% German, 0,3%
Slavic and-other
Religion: 47% Protestant, 7% Roman Catho-
lic, 46% unaffiliated or other; less than 5% of
Protestants and about 25% of Roman Catho-
lics active participants .
Language: German, Sorbian
Infant mortality rate: 10/1,000 (1984)
Life expectancy: men 68.8, women 74.7
Literacy: 99%
“89
Hnhuttenstadt .
Labor force: 8.916 million; 37.9% industry,
20.8% services, 10.1% commerce, 10.8%-ag-
riculture, 7.4% transport and communica-
tions, 6.9% construction, 3.1% handicrafts,
3.0% other (1984)
Organized labor: 87.7% of total labor force
Population: 60,734,000, including West
Berlin (July 1986), average annual growth
rate —0.4%
Nationality: noun—German(s); adjective—
German
Ethnic divisions: primarily German; Danish
minority
Religion: 45% Roman Catholic, 44% Protes-
tant, 11% other :
Language: German 7
Infant mortality rate: 11/1,000 (1983)
Life expectancy: men 67.2, women 73.4
The final borders of”
Germany have fot ; .
Literacy: 99%
Labor force: 27.612 million (1984); 41.6%
industry, 34.7% services and other, 18.2%
trade and transport, 5.4% agriculture (Feb-
ruary 1985) peda
Organized labor: 28% of total labor force;
35% of wage and salary earners (1984)
Population: 5, 734, 000 (July 1986), average
annual growth rate 2.4%
Nationality: noun—Guinean(s); adjective—*
Guinean
Ethnic divisions: Fulani, Malinke, Sousou,
15 smaller tribes ,
Religion: 75% Muslim, 24% indigenous be- .
liefs, 1% Christian
Language: French (official); each tribe has”
its own language
Infant mortality rate: 165.3/1,000 (1980)
Life expectancy: 45
Literacy: 20% in French; 48% in local lan-
guages .
Labor force: 2.4. million (1983); 82. 0% agri-
culture, 11.0% ‘industry and commerce,
5.4% services, 1.6% government
Organized labor: virtually 100% of wage’
labor force loosely affiliated, with the Na- |
tional Confederation of Guinean Workers
Population: 875, 000 (July 1986), average
annual growth rate 1.9%
Nationality: noun—Guinea- Bissauan(s );
adjective—Guinea-Bissauan
Ethnic divisions: about 99% African (30%
Balanta, 20% Fula, 14% Manjaca, 13% Man-
dinga, 7% Papel); less than 1% European and
mulatto
Religion: 65% indigenous beliefs, 30% Mus-
lim, 5% Christian
Language: Portuguese (official); Criolo and
numerous African languages
Infant mortality rate: 250/1,000 (1982)
Life expectancy: 42
Literacy: 9%
104
Labor force: 90% agriculture; 5% industry;
services, and conimerce; 5% government .
Population: 108,000 (July 1986), average
annual growth rate 2.0%
Nationality: noun—Sao Tomean(s); adjec-
tive—Sao Tomean
Ethnic divisions: mestico, angolares (descen-
dents of Angolan slaves), forros (descendents
of freed slaves), servicais (contract laborers
from Angola, Mozambique, and Cape
Verde), tongas (children of servicais born on
the islands), and Europeans (primarily Por-
tuguese)
Religion: Roman Catholic, Evangelical Prot-
estant, Seventh-Day Adventist
Language: Portuguese (official)
Infant mortality rate: 63/1,000 (1983)
214
Bye: est. 50%
Labor aie (1981) 21,096; most of ean
tion éngaged in subsistétice agriculture and
fishing; some unemployment; labor short-
ages on plantations and for skilled work','f008c11976fde852bdc8b6608b48dfc1e25f759012089ed25a6ba87411db406f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15761a3784affb58bc83919ace0ed5ebfb1f5a6ef370acafefe2d1d9c76008d3',1986,'CK','Cook Islands','people-and-society',124,'Population: 17,738 (July 1986), average an-
nual growth rate — 1.0%
Nationality: noun—Cook Islander(s); adjec-
tive—Cook Islander
Ethnic divisions: 81.3% Polynesian (full
blood),:7.7% Polynesian and European, 7.7%
Polynesian and other, 2.4% Buropean: 0.9%
other -
Religion: Christian, majority of populace
members of Cook Islands Christian Church
Lanaguage: Maal','875b721cc9f981ef6382372068892b8651abaa0869c692335eebaddf62693824','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63506631d37781d908fadfdd82b5db4abfd6ad8caf69f198c6017d8728928b9d',1986,'CR','Costa Rica','people-and-society',128,'Population: 2,714, 000 J uly 1986) average...
annual Beowth rate 2.6%
Nationality: ane Cont Ricanls ); ‘gdiew:
tive—Costa Rican ._ .. ss
Ethnic divisions: 96% white (including mes-
tizo), 3% black, 1% Indian... -- - .
Religion: 95% Roman Catholic _
Language: Spanish (official), with ebiggee
dialect of English spoken around Puerto -
ren . ;
Infant inotialitgns rate: 18. 8 0001889)
Life peneriones amen n 67. 5, women 071. 9.
Literacy: 93%
58
Caribbean | |
Labor force: 868,300 (1985 est.); 34% indus-
try and commerce, 27% agriculture, 21%
goverriment and services, 8% other; 6% un-
employment (1985 official), 10% unemploy-
ment (1985 unofficial)
Organized inbap: about 15.1% of labor force','31cc4e4d556387d97995cae1ef5ce4450ba47bb4cbcf9ea7d180cbc9ed2f80de','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('590d25bc99a37ab48a1d5dee09bac0dbe305fa6a2a603f20acb366fad2321e6f',1986,'CU','Cuba','people-and-society',132,'Population: 10,221,000 (July 1986), average
annual growth rate 1.1%
Nationality: noun—Cuban(s); adjective—
Cuban
Ethnic divisions: 51% mulatto, 37% white,
11% black, 1% Chinese
Religion: at least 85% nominally Roman
Catholic before Castro assumed power
Language: Spanish
Infant mortality rate: 15/1,000 (1985)
Life expectancy: 74
Literacy: 96%
Labor force: 3.0 million in 1982; 47% indus-
try and commerce, 28% services and govern-
ment, 25% agriculture','5eefb0b24386d43f43f078306ce82a5627766805ac6f4cc8b2641e310a98543e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b012e0bd89106ae5ea31936972f1aabb3e18f3573bfdfd84951899ee033434e6',1986,'CY','Cyprus','people-and-society',136,'Population: 673,000 (July 1986), average
annual growth rate 1.2%
Nationality: noun—Cypriot(s); adjective—
Cypriot
Ethnic divisions: 78% Greek; 18% Turkish;
4% Armenian, Maronite, and other
Religion: 78% Greek Orthodox; 18% Mus-
lim; 4% Maronite, Armenian, Apostolic, and
other
Language: Greek, Turkish, English
Infant mortality rate: 17/1,000 (1984)
Life expectancy: men 72.3, women 76.0
Literacy: about 89%
Greek Sector labor force: 240,900 (1982);
42% services, 33% industry, 22% agriculture;
3.1% unemployed
61
Government ov 2
Official name: Republic of Cyprus
Type: republic; a disaggregation of the two
ethnic communities inhabiting the island
began after the outbreak of communal strife
in 1963; this separation was further solidified
following the Turkish invasion of the island
in July 1974, which gave the Turkish Cypri-
ots de facto control over the northern 37 per-
cent of the republic; Greek Cypriots control
the only internationally recognized govern-
ment; on 15 November 1983 Turkish Cyp-
riot “President” Rauf Denktash declared
independence and the formation of a “Turk-
ish Republic of Northern Cyprus,” which
has been recognized only by Turkey; both
sides publicly call for the resolution of inter-
communal differences and creation of a new
federal system of government
Capital: Nicosia
Political subdivisions: 6 administrative dis-
tricts
Legal system: based on common law, with
civil law modifications; negotiations to cre-
ate the basis for a new or revised constitution
to govern the island and relations between
Greek and Turkish Cypriots have been held
intermittently
National holiday: Independence Day,
J October
Branches: currently the Government of
Cyprus has effective authority over only the
Greek Cypriot community; headed by Presi-
dent of the Republic and comprising Coun-
cil of Ministers, House of Representatives,
and Supreme Court; Turkish Cypriots de-
clared their own “constitution” and govern-
ing bodies within the “Turkish Federated
State of Cyprus” in 1975; “state” renamed .
“Turkish Republic of Northern Cyprus” in
1983; new “constitution” for the Turkish
sector passed by referendum in May 1985
Government leaders: Spyros KYPRIANOU,
President (since 1977); Turkish Sector—
Rauf DENKTASH, “President” (since 1975)
Suffrage: universal at age 18
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Cyprus (continued)
Elections: officially every five years (last - *
presidential election held in February. 1983):
parliamentary elections held-in December ''
1985; Turkish sector “presidential’’ elections
last held in June 1985; ° cml’ desons
held aidan 1985 , mee
Political parties and adders Greek: Cyp-’
riot—Progressive Party of the Working Peo-
ple (AKEL; Communist Party), Ezekias ©
Papaioannou; Democratic Rally (DESY),
Glafkos Clerides; Democratic Party? -
(DEKO), Spyros Kyprianow; United‘Demo- ‘
cratic Union of the Center (EDEK), Vassos
Lyssarides; Turkish sector—National Unity
Party (NUP), Dervis Eroglu; Communal,
Liberation Party (CLP), Ismail Bozkurt; Re-
publican Turkish Party (RTP), Ozker Ozeur;
New Birth Party (NBP), Aytae-Besheshler —
Voting strength: in the-1983 presidential-
election, incumbent Spyros K yprianou re-:
tained his position by winning 56% of the. .-
vote; in the 1981 parliamentary election, the
pro-Western Democratic Rally received 19°
of the 56 seats; Kyprianou ‘scentér-right ce
Democratic Party won 16 seats; ‘Commuinist
AKEL secured 15 seats; and socialist EDEK
won six seats; in 1985 “presidential” elec- _
tions in the Turkish Cypriot sector, Rauf
Denktash won with 70 percent of thé vote:.
in the 1985 “assembly” elections the conser-
vative National Unity Party won 24.0f 50 _
seats; the Communist Republican. Turkish” :
Party received 12 seats; cénter-right Com- 2
munal Liberation Party secured 10 seats:
and the rightwing New Birth Party received
4 seats : -
Communists: oe . a
Other political or pressure groups: United,
Democratic Youth Organization (EDON;
Communist controlled); Union ‘of Cyprus «-~
Farmers (EKA; Communist controlled); .
Cyprus Farmers Union (PEK; pro-West); *°
Pan-Cyprian Labor Federation (PEO; Com=
munist controlled); Corifederation of. Cyp-"
riot Workers (SEK; pro-West); Federation of
Turkish Cypriot Labor Unions (Turk- Sen);
Confederation of, Revolutionary. Labor
Unions (Dev-Is) oo.
Member of: Commonwealth, Council of | ;
Europe, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICO, IDA, IFAD, IFC, ILO, IMF, . °
IMO, INTELSAT, INTERPOL, ITU, NAM
UN, UNESCO, UPU, WFTU; WHO,
WMO, WTO; Turkish Federated State of
yp OIC fount ee
?
ee Se
GDP: $2.¥ billion (1989), es 210p per capita;
1983 est. Teal erowth rate 2. 6% : :
Turkish Sobibe GDP: $205.9 saillion’ (1989),
$1, 3.44 per canta
Natural resources: copper, ‘pirites abet
gypsum, lumber, salt, marble, clay earth ;
pigment
Agriculture: main crops—potatoes and
other vegetables, grapes, citrus fruit, wheat,
carob beans, olives
Major industries: mining (iron pyrites, gyp-
sum, asbestos), manufactures principally for
local consuthption beverages, footwear,
clothing, cement <
Electric power: ‘620-000 KW capacity ¥( 1985),
1.468 billion kWh Esc (1985), 2, 210°
kWh ner capita : :
Exports: $482. 8 Sallie (. 0. i 1984). princi-
pal items—food and beverages ‘including
citrus, raisins, potatoes, wine; also. cement «
and clothing
Turkish Sector exports; $46. 8 million (£0. b. :
1984); principal items—citrus fruits, pota- *
toes, metal pipes, pyrites
Imports: $1, 195 million é. Lf, 1984); prinei:
* pal items manufactured goods, machinery .
and transport equipment, fuels, food
Turkish Sector imports: $170 million (cif,
1984); principal items—foodstutffs, raw ma-
terials, ‘fuels; machinery a
Major trade partners: imports (1984)—
12.1% UK, 12% Japan, 10.5% Italy, 8.3% °
FRG, 5.2%-Iraq; exports (1984)—17% UK,
14.1% Lebanon, 11: 4% Libya, 7.5% pang: ;
Arabia, 3.4% USSR
Turkish Sector major trade partners: im-
ports (1984)—46% Turkey, 36% EC, 17% °°
Arab countries; exports (1984)—61 % EC,
22% Turkey, 16% Arab countries
62
Budget: (1983) revenues, $587.2 million;
expenditures, $697.3 million; deficit, $110.1
million
Turkish Sector budget: (1982) revenues,
$82.3 million; expenditures, $72.2 million;
deficit, $14.7 million
Monetary conversion rate: .63 Cyprus
pound=US$1 (October 1984)
Turkish Sector monetary conversion rate:
225.46 Turkish liras=US$1 (1983 average)
Fiscal year: calendar year
Population: 15,542,000 (July 1986), average.
annual growth rate 0.3%
Nationality: noun—Czechoslovak(s); adjec-
tive—Czechoslovak
Ethnic divisions: 64.8% Czech, 30.5% Slo-
vak, 3.8% Hungarian, 0.4% German, 0.4%
Polish, 0.3% Ukrainian, 0.1% Russian, 0.2%
other (Jewish, Gypsy)
Religion: 77% Roman Catholic, 20% Protes-
tant, 2% Orthodox, 1% other
Language: Czech and Slovak (official), Hun-
garian
Infant mortality rate: 16/1,000 (1983)
Life expectancy: 70
Literacy: 99%
Labor force: 7.51 million (1984); 38.1% in-
dustry; 12.5% agriculture; 49.4% construc-
tion, communications, and other (1982) -','3cc84917fe28642b9c4b6269e235cff37c615c1eae686d677fdbe706a239ad25','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23328b41dea0e75462c92b6beec1596f719f57116f68fdd20f0118c0b264191e',1986,'DK','Denmark','people-and-society',139,'Population: 5,097,000 (July 1986), average
annual growth rate —0.1% t
Nationality: noun—Dane(s); adiective—
Danish
Ethnic divisions: Scandinavian, Eskimo, ;
Faroese, German
Religion: 97% Fvangelical Lutheran, 2%.
other Protestant and nema Catholic, 1%
other
Language: Danish, Faroese, Greenlandic
(an Eskimo dialect), small German-speaking
minority
Infant mortality rate: 7.7/1,000 (1983)
Life expectancy: men 71.5, women 77.5
64
Eirotaey: 99%.
Pabee fee 2, 713, 000 (1984): 33.2% govern-
ment; 20.7% manufacturing; 13.2% com-
merce; 2.0% agriculture, forestry, and.
fishing; 5.9% construction; 7.8% banking and
business services; 7.5% transportation; 10.3%
unemployment rate
Organized labor: 65% of iaher force
Govelninéat :
Official name: Kingdom of. Denmark
Type: soutien monarchy
Capital:.Copenhagen -
Political subdivisions: 14 counties, 275 com-
munes (88 towns are included in communes)
Legal system: civil law system; constitution
adopted 1953; judicial review of legislative.
acts; legal education at Universities of
Copenhagen and Arhus; accepts compulsory
IC] jurisdiction, with reservations
National holiday: birthday of the Queen, 16
es
Brinihow: legislative authority rests jointly
with Crown and parliament (Folketing),
executive power.vested in Crown but exer-
cised by Cabinet responsible to parliament;
Supreme Court, 2 superior courts, 106 lower
courts
Government leaders: MARGRETHE II,
Queen (since January: 1972); Poul
SCHLUTER, Prime Minister (since Septem-
ber 1982)
Suffrage: universal over age 21
Elections: on call of prime minister but-at :‘
least every four years; last election 10 Janu-
ary 1984
Political parties and.leaders: Social Demo-
cratic, Anker Jorgensen; Liberal, Uffe. . .
Ellemann-Jensen; Conservative, Poul Schl- -
ter; Radical Liberal, Niels Helveg Petersen;
Socialist People’s; Gert Petersen; Commu-
nist, Jorgen Jensen; Left Socialist, Preben
Wilnjelm; Center Democratic, Erhard
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
- Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Jakobsen; Christian People’s, Christian
Christensen; Justice, Poul Gerhard Kristian-
sen; Trade and Industry. Party, Asger J.
Lindinger; Free Democratic Party, Mogens
Glistrup; Socialist Workers Party, no chair-
man; Communist Workers’ Party KRAE)
Benito Scocozza+ .
Voting strength: (1984 election) 31.6% So-
cial Democratic, 23.4% Conservative, 12.1%
Liberal, 11.5% Socialist People’s, 5.5% Radi-
cal Liberal, 4.6% Center Democratic, 3.6%
Progress, 2.7% Christian People’s, 2.6% Left
Socialist, 1.5% Justice, 0.7% Communist,
0.2% others :
Member of: ADB, Council of Europe, DAC,
EC, ELDO (observer), EMS, ESRO, FAO,
GATT, IAEA, IBRD; ICAC, ICAO, ICES,
ICO, IDA, IDB, Inter-American Develop-
ment Bank, IEA, IFAD, IFC, IHO, ILO,
International Lead and Zinc Study Group, °
IMF, IMO, INTELSAT, INTERPOL, IPU,:
ISO, ITC, ITU, IWC—International:Wheat
Council, NATO, Nordic Council, OECD,
UN, UNESCO, UPU; WHO, WIPO, WMO,
WSG
Reonony
GNP: $52.4 billion (1984), $10,250 per cap-
ita; 54% private consumption, 18% private
investment, 26% goverriment-consumption, _
investment; 1% net exports of goods and ser-
vices; 1% increase in stocks; 1984 growth *
rate, 3.9% :
Natural resources: oil, gas, fish
Agriculture: highly in intensive, sGecializes in
dairying and animal husbandry; main -
crops—cereals, root crops; food imports— .
oilseed, grain, animal feedstuffs
Fishing: catch 1.86 million metric tons.
(1983), exports $756. million,. ports: $317
million (1984)
Major industries: food processing, machin-
ery and equipment, textiles and clothing, .
chemical products,.electronics, construction,
furniture, and other wood products ° -
Crude steel: 0.6 million metric tons-pro-
duced.(1984); 110 kg per capita
Electric power: 9,493,000 kW capacity
(1985); 27.464 billion kWh produced (1985),
5,380 kWh per capita
Exports: $15.9 billion (f.0.b., 1984); principal
items—meat, dairy products, industrial ma-
chinery and equipment, textiles and cloth-
ing, chemical products, transport equip-
ment, fish, furs, furniture
Imports: $16.58} billion (c.i.f., 1984); princi-
pal items—industrial machinery, transport
equipment, petroleum, textile fibers and
yarns, iron and steel products, chemicals,
grain and feedstuffs, wood and paper
Major trade partners: 1984 exports—44.3%
EC, 18% FRG, 12.7% Sweden, 10.7% UK,
7.2% US, 5.38% Norway
Aid: donor—ODA and OOF economic aid
commitments Sag 83) $3.3 billion
Budget: Cy een $24.8 billion;
revenues, $18.5 billion
Monetary conversion rate: 9.03 kroner=
US$1 (December 1985)
Fiscal year: calendar year, beginning | Janu-
ary','b4aca122b7e4b615ec128ade045d6817990e0eb446084d7278c5e4070dcac8a0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('422d0a763c36f33468a88f53a97b99f942594cf546fbeac9f6fca90f33f6e68f',1986,'DJ','Djibouti','people-and-society',141,'Population: 304,000 (July 1986), average
annual growth rate 2.5%
Nationality: noun—Djiboutian(s); adjec-
tive—Dijiboutian :
Ethnic divisions: 60% Somali (Issa); 35%:
Afar, 5% French, Arab, Ethiopian, and Ital-
ian’ : ;
Religion: 94% Muslim, 6% Christian
Language: French (official); Somali and Afar
widely used
Infant mortality rate: 140/1,000 (1985)
Life éxpectancy: 50
Literacy: 17%
Labor force: a small number of semiskilled
laborers at port
Organized labor: 3.000 railway workers or-
ganized','6658966b4e1d035338e6f01d221659602b5aa30b4e39385e0c43520cdcdbb310','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98438888335460e4b3f40ef91267bca11045c896f9fe6852f981e2906d079b1a',1986,'DM','Dominica','people-and-society',146,'Population: 74, 000 (July 1986), Averiges an-
nual growth rate 0. 4%
Nationality: noun—Dominican(s ); adjec-
tive—Dominican :
Ethnic divisions: mostly black; some Carib
Indians : ; :
oe
Religion: 80% Roman Catholic; Analican,
Methodist
Language: English (official); French: Aataie
widely spoken :
Infant ocala fie. 24.1/1,000 (i981)
Life expectancy: aie 56.97,.women 59.18 :
Literacy: about 80% |
Labor force: 25,000; 40% agriculture, 32%
industry and commerce, 28% services; 15-
20% unemployment (1984)
Organized labor: 25% of the labor force -','52adfba05a4a920133cd8beece6294cc834399de4221d8c742fbefbfd9325200','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1542b6278191cc8a14d4e4b9bd20ae4a0926bfbb0ac1f9efc14bc8fff28aba',1986,'DO','Dominican Republic','people-and-society',150,'Population: 6,785,000 (July 1986), average
annual growth rate 2.5%
Nationality: ROU > PamunIcates ); adjec- -
tive—Dominican : ;
Ethnic divisions: 73% mixed, 16% white,
11% black
Religion: 95% Roman Catholic
Language: Spanish
Infant mortality rate: 63/1,000 (1983)
Life eed 60
Literacy: 68%
Labor force: 1.7 million (1984), 45% agricul-
ture, 34% industry, 16% services, 3% other
68
: Elections: last national election May 1982,
Organized labor: 150,000 (1984); 12% of |
labor force niviae |
|
{','24162770afa8deb6405002397121a7f1636f8dca615b533e36801399bfdd7fa4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ecab4b65484811415989896e1817059899be17b48ea6db844467d132ae5cc4b',1986,'EC','Ecuador','people-and-society',154,'Population: 9, 647,000 July 1986), average
annual growth rate 2.8%
Nationality: noun—Ecuadorean(s); adjec-
tive—Ecuadorean
Ethnic divisions: 55% mestizo (mixed Indian
and Spanish), 25% Indian, 10% Spanish, 10%
black
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish (official); Indian lan-
guages, especially Quechua
Infant mortality rate: 76.3/1,000 (1978)
Life expectancy: 62
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R0001001 70001-4
Ecuador (continued)
Literacy: 84%
Labor force: (1983) 2.8 million; 52% agricul-
ture, 18% manufacturing, 7% commerce, 4%
construction, 4% public administration, 16%
other services and activities
Organized labor: less than 15% of labor -
force','333fd8ab922cb8c361aee6649598416a6f8cfbc42a1d51692bdd9c013bfde128','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c87116fbca89730e8b80817f2c3f524bdac36a62577fc664ae7492dbbf426dd3',1986,'EG','Egypt','people-and-society',158,'Population: 50,525 000 (July 1986), average
annual growth rate 2. 8%:
Nationality: noun-Reyorant: adjective—
Egyptian :
Ethnic divisions: 90% Eastern Hamitic:
Stock; 10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslien
(mostly Sunni), 6% Contic Christian and |
other °
Language: Arabic (official); English and ,
French widely understood by educated
classes a
Infant Sake: 69/1,000 (1983) -_
Life expectancy: 57
Literacy: 40%
71.
Labor force: 12.5 million (official estimate):
40-45% agriculture, 36% government (local
and national), public sector enterprises, and
armed forces: 20% privately owned service
arid manufacturing enterprises; shortage of:
skilléd labor; unemployment about 7%; esti-
mated 2.5 million Egyptians work abroad,
mostly in Iraq and the Gulf Arab’states:
Organized labor: about 2.5 million','de7a76288130c85a1f5259bfdb4688f8d62b0bed7db3290dd283e720ac50d42e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82efc0aacdc98b60760ad32908537ee9b65f630ba42c2909767e99748d06efe9',1986,'LY','Libya','people-and-society',162,'Population: 5,105,000 (July 1986), average
annual growth rate 2.5%
Nationality: noun—Salvadoran(s); adiec-
tive—Salvadoran
Ethnic divisions: 89% mestizo, 10% Indian,
1% white
Religion: predominantly Roman Catholic
(probably 97-98%), with activity by Protes-
tant groups throughout the country
Language: Spanish, Nahua (among some
Indians)
Infant mortality rate: 41 /1,000 (1984)
Life expectancy: men 62.6, women 66.3
Literacy: 65%
Labor force: 1.7 million (est. 1982); 40% agri-
culture, 16% manufacturing, 16%
commerce, 13% government, 9% financial
services, 6% transportation (1984 est.); short-
age of skilled labor and large pool of
unskilled labor, but manpower training pro-
grams improving situation; significant un-
employment and underemployment
Organized labor: 8% total labor force; 10%
agricultural labor force; 7% urban labor
force (1982)
Population: 3,876,000 (July 1986), average
annual growth rate 3.2%
Nationality: noun—Libyan(s); adjective—
Libyan . :
Ethnic divisions: 97% Berber and Arab with
some black stock; some Greeks, Maltese,
Jews, Italians, Egyptians, Pakistanis, Turks,
Indians, and Tunisians ,
Religion: 97% Sunni Muslim
Language: Arabic; Italian-and English -
widely understood in major cities
Infant mortality rate: 84/1000 (1985)
Life.expectancy: men 56, women 59
Literacy: 50-60%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: 1 million, of which about
280,000 are resident foreigners; 31% indus-
try, 27% services, 24% government, 18%
agriculture','fc5bfb9e4f46c103fad5b577b5cda8f6786fa7c741a4b67abd00ce4fcc1a0199','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd8478daf642cd3b424edc14cb2c555ea3f55513f83a4fba531d4604f9d887f8',1986,'GQ','Equatorial Guinea','people-and-society',166,'Population: 359,000 (July 1986), average
annual growth rate 2.6% RioMuni—
269,546 (July 1986), average annual growth
rate 2.6%: Bioko—89,849 (July 1986), aver-.
age annual growth rate 2.6%
Nationality: noun—Equatorial Guinean(s); ;
adjective—Equatorial Guinean °
Ethnic divisions: indigenous population of
Bioko, primarily Bubi, some Fernandinos; of
Rio Muni, primarily-Fang; less than 1,000. -
Europeans, primarily Spanish, ”
Religion: natives all nominally Christian
and predominantly Roman Gatholic; some,
pagan practices retained .
Language: ‘Spanish (official), aces English,
Fang
Infant mortality rate: 142.9/1,000 (1984)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Life expectancy: men 44.4, women 47.6 |
Literacy: 55%
Labor force: most involved in subsistence
agriculture; labor shortages on plantations','67c311ef1322eb59171d843e9463cdb648f45b2a6fe489fb4785083fdafc96fc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1658bea35674eaadfdfe34e37888bd97d5f5a686d340a4fcee2abf3e4051335c',1986,'ET','Ethiopia','people-and-society',168,'Population: 43,882,000 (July 1986), average
annual growth rate 3.8%
Nationality: noun—Ethiopian(s); adjec-
tive—Ethiopian
Ethnic divisions: 40% Oromo, 32% Amhara
and Tigrean, 9% Sidamo, 6% Shankella, 6%
Somali, 4% Afar, 2% Gurage, 1% other
Religion: 40-45% Muslim, 35-40% Ethiopian
Orthodox, 15-20% animist, 5% other
Language: Amharic (official), Tigrinya,
Orominga, Arabic, English (major foreign
language taught in schools)
Infant mortality rate: 145/1,000 (1983)
Life expectancy: 38
Literacy: about 35%
Labor force: 90% agriculture and animal
husbandry; 10% government, military, and
quasi-government ,
Organized labor: All Ethiopian Trade Union
formed by the government in January 1977
to represent 273,000 registered trade union
members
Population: 2,000 (july 1986), average an-
nual growth rate 0%
Nationality: noun—Falkland Islander(s);
adjective—Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Anglican
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in
agriculture, mostly sheepherding
77','3f0d6961f2fed87071a6bbdd2c26a23c0d4aa26b036e9698b1f6e415272c53a0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c01f0e5ce3590a223d3684ce73aa7a03ee12870e8fb7aad18118cabe0a55b5d',1986,'FO','Faroe Islands','people-and-society',172,'Population: 46,000 (July 1986), average an- -
nual growth rate 0.7% -
Nationality: noun—Faroese (sing., pl.); ad-
jective—Faroese
Ethnic divisions: homogeneous white popu-
lation
Religion: Evangelical Lutheran
Language: Faroese (derived from Old
Norse), Danish
Literacy: 99%
Labor force: 17,585; largely engaged in - «
fishing, manufacturing, transportation, and
commerce |','ccf554f0078c810cdd354cd53facb3652ab9a884956e5aa32e576b26b81f65b6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8866bb152bca1e7f1d0d5a0aaeb4331f5b77131cc813b6f589154d820f6de967',1986,'FJ','Fiji','people-and-society',175,'Population: 715,000 (July 1986),-average
annual growth rate 2.0%
Nationality: noun—Fijian(s); adjective—
Fijian
Ethnic divisions: 50% Indian, 45% Fijian;
5% European, other Pacific Islanders, over-
seas Chinese, and others
Religion: Fijians are mainly Christian, Indi-
ans are Hindu with a Muslim minority
79
Language: English (official); Fijian and. -
Hindustani spoken among Indians
Infant mortality rate: 29/1,000 (1983)
Life expectancy: 72
Literacy: 80% .--
Labor force: 176,000 (1979); 40% of total
work force paid employees; remainder in-
volved in subsistence agriculture; 43.4% ag-
riculture, 15.6% industry DF
Organized labor: about 50% of labor force -
organized into about 60 unions; unions orga- -
nized along lines of work and ethnic origin --','f18f0c5bcd8e3963694406bbb8dd3d67c5a5246f95dc5d9306538850ee20c986','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('949cefb6f905956a628849b5ac0bf84c8e5adc212ef4021b10bce38860121758',1986,'FI','Finland','people-and-society',179,'Population: 4,931,000 uly 1986), average
annual growth rate 0.5% °° 7 a
Nationality: en: adjective—
Finnish
Ethnic divisions: Finn, Swede, Lapp,
Gypsy, Tatar
Religion: 97% Evangelical Lutheran, 1.2%
Greek Orthodox, 1.8% other - :
Language: 93.5% Finnish, 6.8% Swedish
(both official); small Lapp- and
Russian-speaking minorities °
Infant mortality rate: 6.2/1,000 (1983)
Life expectancy: men 70. 1, women 78.1
ak
Literacy: almost 100% ~~‘
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4 .
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 : ,
Labor force: 2.572 million; 23.3% mining
and manufacturing; 25.8% services; 19.0%
commerce; 11.4% agriculture, forestry, and
fishing; 7.1% construction: 7.0% transporta-
tion and communications; 6.2% unemployed
(1984 average)
Organized labor: 80% of labor force
Government bee ia
Official name: Republic of Finland
Type: republic
Capital: Helsinki .
Political subdivisions: 12 provinces, 377
communes, 84 towns
Legal system: civil law system based on -
Swedish law; constitution adopted 1919;
Supreme Court may request legislation in-
terpreting or modifying laws; legal educa-_
tion at Universities of Helsinki and Turku;
accepts compulsory IC] jurisdiction, with
reservations
National holiday: Independence Day, 6
December -
Branches: legislative authority rests jointly
with President and unicameral legislature
(Eduskunta); executive power.vested in Pres-.
ident and exercised through coalition Cabi-
net responsible to parliament; Supreme
Court, four superior courts, 193 lower courts
Government leaders: Dr. Mauno
KOIVISTO, President (since January 1982); -
Kalevi SORSA, Prime Minister (since Febru-
ary 1982)
Suffrage: universal, 18 years''and over; not
compulsory
Elections: parliamentary, every four years
(next in 1987); presidential, every six years
(next in 1988)
Political parties and leaders: Social Demo-
cratic Party, Kalevi Sorsa; Center Party,
Paavo Vayrynen; People’s Democratic
League (Communist front), Esko Helle; Con-,
servative Party, Ilkka Suominen; Liberal
Party, Kyésti Lallukka; Swedish Peoples
Party, Christoffer Taxell; Rural Party, Pekka
Vennamo; Finnish Communist Party, Arvo
Aalto; Finnish Christian League, Esko
Almgren; Constitutional People’s Party,
Georg Ehrnrooth; League for Citizen Power,
Kaarlo Pitsinki
Voting strength: (1983 parliamentary elec-
tion) 26% Social Democratic, 22.1% Conser-
vative, 17.6% Center-Liberal, 14.0%
People’s Democratic League, 9.7% Rural,
4.9% Swedish Peoples, 3.0% Christian:
League, 1.5% Greens, 0.4% Constitutional
People’s, 0.1% League for Citizen Power
Communists: 28,000 registered members;
an additional 45,000:persons belong to
People’s Democratic League
Member of: ADB, CEMA (special coopera- .
tion agreement), DAC, EC (free trade agree-
ment), EFTA (associate), FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO,
IDA, IDB—Inter- American Development
Bank, IFAD, IFC, IHO, ILO, International
Lead and Zinc Study.Group, IMF, IMO,
INTERPOL, IPU, ITU, IWC—Interna-
tional Wheat Council, Nordic Council,
OECD, UN, UNESCO, UPU, WHO,
WIPO, WMO, WSG
Population: 55,239,000 (July 1986), average:
annual growth rate 0.4%
Nationality: noun—Frenchman (men); ad-
jective—French
Ethnic divisions: Celtic and Latin-with Teu---”
tonic, Slavic,North African, Indochinese,
and Basque minorities
Religion: 90% Roman Catholic, 2% Protes-
tant, 1% Jewish, 1% Muslim Nore: afiican 8
workers), 6% unaffiliated
Eanauaees French (100% of population);
rapidly declining regional dialects—Proven- . -
cal, Breton, Germanic, Corsican; Catalan,
Basque, Flemish 2
Infant mortality rate: 9/1,000 (1983)
Life expectancy: 75
, 82
pMeraey: ia .
Labor foree: 2 23. 8 Sonn (1984); 61.2% ser-
vices, 21.7% industry, 7.0% agriculture;
10.1% unemployed
Cianed oe approximately 20% ot la-
bor force.','8ad2bf5eff9afe8297ebe46a24058e08bdafd5bd7f83a4ee64e63f4b9c1554d5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5599f1ca864f7f37a554770641f9a3f7b1bf2b84a03e57381f692b1982a2d341',1986,'GF','French Guiana','people-and-society',183,'Population: 88,000 (July 1986), average an-
nual growth rate 4.1%
Nationality: noun—French Guianese (sing.,
pl.); adjective—French Guiana
Ethnic divisions: 66% black or mulatto; 12%
Caucasian; 12% East Indian, Chinese,
Amerindian; 10% other
Religion: predominantly Roman Catholic i
Language: French
Literacy: 73%
Labor force: 23,265 (1980); services, govern-
ment, and commerce 60.6%; industry 21.2%;
agriculture 18.2%; 10% unemployment
(1980)
Organized labor: 7% of labor force
84','2c91363fab91019b537b335f055f3557ff0b37d6ee60570f7509525b839fe147','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('139f663bfae9422ef194bd20a0dab8526781f94315d5d9d69dfe31f32788b873',1986,'PF','French Polynesia','people-and-society',187,'Population: 181,000 (July 1986), average
annual growth rate 3.0%
Nationality: noun—French Polynesian(s);
adiective—French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chi-
nese, 6% local French, 4% metropolitan
French
Religion: mainly Christian; 55% Protestant,
32% Catholic','73af7acb9e29b0ed73652f67f1cb2d798869b9403bc2843385f92663eceae29b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d20e989420de695cf2c12613dfc8ac02466a91d2bfd28a9b02a26b7d6ca1e8a3',1986,'GH','Ghana','people-and-society',192,'Population: 13,552,000 (July 1986), average
annual growth rate 4.1%
Nationality: noun—Ghanaian(s);
adjective—Ghanaian
Ethnic divisions: 99.8% black African (ma-
jor tribes Akan, Ewe, Ga), 0.2% European
and other
Religion: 38% indigenous beliefs, 30% Mus-
‘lim, 24% Christian, 8% other
Language: English (official); African lan-
guages include 44% Akan, 16% Mole-
Dagbani, 13% Ewe, and 8% Ga-Adangbe
Infant mortality rate: 97/1,000 (1983)
Life expectancy: 49
Literacy: 30%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: 3.7 million; 54.7% agriculture
and fishing; 18.7% industry; 15.2% sales and
clerical; 7.7% services, transportation, and
communications; 3.7% professional; 400,000
unemployed
Organized labor: 467,000 or approximately
13% of labor force','bac14da95f1df5f0b0c583b6462453f74acd94a37bcab0626eeb9bc3e621e218','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c39171a9890b9f426eced7bc10a366fcf5c4a116c55245f5e8e9b329f5165b82',1986,'GI','Gibraltar','people-and-society',195,'Population: 30,000 (July 1986), average an-
nual growth rate 0.8%
Nationality: noun==Cibtaltarians adjec-
tive—Gibraltar
Ethnic divisions: mostly Italian, English,
Maltese, Portuguese, and Spanish descent
Religion: 75% Roman Catholic, 8% Church °
of England, 2.25% Jewish
Laieaibe: English and Spanish are primary
languages; Italian, Portuguese, and Russian
also spoken; English used in the schools and
for official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including. non-
Gibraltar laborers
Organized labor: over 6,000 .','b363e6b2f5d26e4d0da4237b2eff19e74abe322db15941992073bc42bbff25d9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47015075c505fc009c552ba2b95a486f28bd1722f409213c2d74eaf18f6814b4',1986,'GR','Greece','people-and-society',199,'Population: 9,954,000 0 uly 1986), average
annual growth rate 0.3%
Nationality: noun—Greek(s); adjective—
Greek :
Ethnic divisions: 97:7% Greek, 1.3% Turk-
ish; 1.0% viach Bley, plbenien: Pomach
NOTE: The eee Coveratsent states that
there are no-ethnic minorities in Greece.
Religion: 98% Greek Orhsdox, 1.38% Mus-
lim, 0. 7% other
Language: Greek (official); English and
French widely understood
ny
Infant mortality rate: 13.8/1,000 (1984)
Life expectancy: men 72, women 75
Literacy: 95%
Labor force: 3.7 million (1981 census); ap- :
proximately 39% services, 31% agriculture,
30% industry; urban unemployment is esti-
mated at 10%; substantial unreported unem-
ployment. exists i in agriculture ;
Sean dito 10-15% e total labor .
force, 20-25% of urban labor force - -
Population: 51,819,000 (July 1986), average
annual growth rate 2.3%
Nationality: foun ke adjective—
Turkish
Ethnic divisions: 85% Turkish, 12% Kurd,
3% other |
Religion: 98% Muslim (mostly Sunni), 2%
other (mostly Christian and Jewish)
Lanne: Turkish (official), Kurdish, Ara-
bic :
Infant mortality rate: 15.3/1,000 (1984)
Life expectancy: 57
Literacy: 70%
249
Labor force: 18.1 million (1984); 58.8% agri-
culture, 27.5% service, 11.9% industry and
commerce; 16.5% surplus of unskilled labor
(1984); about 1 million fuk work abroad
(1983)
Organized labor: 10-15% of labor force
Government 7
Official name: Republic of Turkey ©
Type: republican parliamentary democracy
Capital: Ankara
Political subdivisions: 67 provinces —
Legal system: derived from various conti-
nental legal systems; constitution adopted in’
November 1982; legal education at Universi-
ties of Ankara and istanbul; accepts compul-
sory ICJ jurisdiction, with réservations -.
National holiday: Republic Day, 29 October
Branches: executive—President empowered
to call new elections, promulgate laws
(elected for a seven-year term); unicameral
legislature (400-member Grand National
Assembly); independent judiciary
Government leaders: Gen. Kenan EVREN,
President (since 1982); Turgut OZAL, Frame
Minister (since 1983)
Suffrage: universal over age 2]
Elections: Pernt to the 1982 Constitu-
tion, elections to the Grand National Assem-
bly to be held every five years; most recent
election 6 November 1983
Political parties and leaders: inilitary lead-
ers banned all traditional parties from taking.
part in the parliamentary election of No-
vember 1983 and banned many prominent
party leaders from taking part in politics for
five to 10 years; three new parties allowed to
take part in the election—Motherland Party’
(ANAP), Turgut Ozal; Populist Party (PP),
Necdet Calp; Nationalist Democracy Party
(NDP), Ulk Séylemezoglu; additional par-
ties permitted to take part in local elections
in March 1984—Social Democratcy Party
(SODEP), Erdal inén; Correct Way Party
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Turkey (continued)
(CWP), Husamettin Cinderuk; SODEP and.
PF merged in 1985 to form the Social Demo-
cratic Populist Party (SHP) under Aydin .
Grkan; Democratic Left Party (DLP)
founded in 1985 under Rahsan Ecevit. . :
Voting strength: (1983 election) Grand Na-
tional Assembly—Motherland Party, 211
seats; Populist Party, 117 seats; Nationalist
Democracy Party, 71 seats; as of end of
1985, Grand National Assembly—Mother-
land Party, 207 seats; Social Democratic _
Populist Party, 82 seats; National Democ-.
racy Party, 53 seats, Democratic Left Party,
4 seats; independents, 46 seats; vacant, 8
seats : ''
Communists: strength and support negligi-
ble |
Member of: ASSIMER, Council of Europe,
EC (associate member), ECOSOC, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IDB—Islamic Development Bank, IEA,
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IPU, ITC,
ITU, NATO, OECD, OIC, Economic Coop-
eration Organization, UN, UNESCO, UPU;
WHO, WIPO, WMO, WSG, WTO','115a0d66a94d2835856de630d6d59157a9fcb89fc034f9653a940ab073b9b768','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32cf7328607b1ec841dcdee59cf8dd0a86e4140afff22aa9a885313523c6ed0b',1986,'GL','Greenland','people-and-society',202,'Population: 54,000 (July 1986), average an-
nual growth rate 1.1%
Nationality: noun—Greenlander(s), adiec-
tive—Greenlandic ,
Ethnic divisions: 86% Greenlander (Eskimos
and Greenland-born whites), 14% Danish
Religion: vanuelicaleatherai
Language: Danish, Eskimo dialects ee oe
Infant manaiure rate: ot 1 000 (1976-80)
nue a alia men 159. 7, women 67.3
iigten 99% .
Labor force: 21,378; largely engagedin
fishing, hunting, and sheep,breeding
CIA-RDP08-00534R0001001 70001 -4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Governmient
Official name: Gresilhid:
Tupe: tetas province of Kingdom
of Denmark; two representatives in Danish
parliament; separate Minister for Greenland
in the Danish Cabinet (Ministry to be phased
out during 1986-87)
Capital: Godthab (Nuuk)
Political. subdivisions: 8 counties, 18 com-
munes aa
Legal system: Danish law; transformed
from colony to province in 1953; limited |
home rule began in spring 1979
Branches: legislative authority rests jointly
with the elected 25-seat-Landsting and Dan-
ish parliament; executive power vested in’ *.
Premier and four-person council; 19 lower ..
courts et
Government leaders: MARGRETHE II, aa
Queen (since January 1972); Jonathan
MOTZFELDT, Prime Minister (since May
1979)
Suffrage: universal, but not compulsory, ee
over age 4)
Elections: held every four’ ‘years; most re- -
cent, 6 June 1984 :
Political parties: Siumut, "11 seats (moderate -
socialist, advocating more distinct Green- . - -
land identity and greater autonomy from
Denmark); Atassut Party, 1] seats (more con-
servative, favors continuing close relations .
with Denmark); Inuit Ataqatigiit, 3 seats
(Marxist-Leninist party favoring complete :
independence from Denmark rather than |
home rule) :','196639c4e5ece65734f7d5ac3be3f41691cd9a0ca675cdc82d06467342cc3622','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d03f7f0ed37777921549c116ed6ef4073c46cb0c637e250638244acca137347e',1986,'GD','Grenada','people-and-society',206,'Population: 86, 000 (July 1986), average an-
nual growth rate —0.5%
Nationality: noun—Grenadian(s ); adjec-
tive—Grenadian -_
Ethnic divisions: mainly of black African
descent
Religion: largely Roman Catholic; Anglican;
other Protestant sects
Language: English (official); some French -
patois
Infant mortality rate: 16.7/1,000 (1985)
Life expectancy: 69,
Literacy: 85%
Labor force: 36,000 (1985); 31% services,
24% agriculture, 8% construction, 5%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Grenada (continued)
manufacturing, 31% other; 35- 40% t unem-
ployment (1985)
Organized labor: 80%, of labor force','a762c7aa91c51dd070c5df1d209f8a08f5c1c765b7bc4ee40b89c030a3c7d7a4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d27a34e676dc84eaf7ca33fcf2aff294268796c5c0e960ebf85cae9144a439d4',1986,'GP','Guadeloupe','people-and-society',209,'Population: 334,000 July 1986), average
annual growth rate 0.5%
Nationality: noun—-Guadeloupian(s); adjec-
tive—Guadeloupe
Ethnic divisions: 90% black or mulatto; 5%
white; less than 5% East Indian, Lebanese,
Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, creole patois
Infant mortality rate: 18.6/1,000 (1983)
Life expectancy: 67
Literacy: over 70%
Labor force: 120,000; services, government,
and commerce 53.0%; industry 25.8%; agri-
culture 21.2%; significant unemployment
Organized labor: 11% of labor force','fd9df06b3d16fcb91f4bec35c716ae6b6a1d9ab6ffc6cd2c27e77d25fa5ba27b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4eda25eff1acb3f6edea79ad4d5c9f11e1a2f3b94cab7a775dfedf64a1408cc',1986,'GT','Guatemala','people-and-society',213,'Population: 8,600,000 (July 1986), average
‘annual growth rate 3.0%
Nationality: noun—Guatemalan(s); adiec-
tive—Guatemalan
Ethnic divisions: 56% Ladino (mestizo and
westernized Indian), 44% Indian
Religion: predominantly Roman Catholic;
also Protestant, traditional Mayan
Language: Spanish, but over 40% of the
population speaks.an Indian language asa .
primary tongue (18 Indian dialects, includ-
ing Quiche, Cakchiquel, Kekchi) .
Infant mortality rate: 66/1,000 (1982)
‘Life expectancy: 60 -
Literacy: 50%
100
Labor force (1985): 2.5 million; 57.0% agri-
culture, 14.0% manufacturing, 13.0% ser-
vices, 7.0% commerce, 4.0% construction,
3.0% transport, 0.8% utilities, 0.4% mining;
unemployment and underemployment 40%
Organized labor: 10% of labor force (1985) -: :','e6321555a1c36bd3c38ebd3412c953c420197470f222a5b6dcf5ea20a1ae337a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bfddfe528c4227f1aab904a149befb508918e7dcf7f845484c1b960c5c3b923',1986,'GG','Guernsey','people-and-society',217,'Population: 53,000 (July 1986), average. an-
nual growth rate — 0.1%
Nationality: noun—Channel Islander );
adjective—Channel Islander
Ethnic divisions: UK and Norman-French .
descent ;
Religion: Anglican, Roman Catholic, Pres-
byterian, Baptist, Congregational, Methodist
Language: English, French; Norman- .
French dialect spoken in country districts
Literacy: universal education','273d74b51922ddf3f10db8f23e9c3e479d8670ab39d077481c8ec78b58fa75c8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed9e33be8c2fa261757a1bf0e1d00daf1aafbe67f36db45aca623726b2f78854',1986,'GY','Guyana','people-and-society',221,'Population: 771,000 (July 1986), average
annual growth rate 0.8%
Nationality: noun—Guyanese (sing., pl.);
adjective—Guyanese
Ethnic divisions: 51% East Indian, 43%
black and mixed, 4% Amerindian, 2% Euro-
pean and Chinese
Religion: 57% Christian, 33% Hindu, 9%
Muslim, 1% other
Language: English, Amerindian dialects
Infant mortality rate: 41/1,000 (1985)
Life expectancy: 70
Literacy: 85%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Guyana (continued)
Labor force: 200,000 (1983); 44.5% industry
and commerce, 33.8% agriculture, 21.7%
services; 64% public sector employment; -
approximately 25% unemployed (1984)
Organized labor: 34% of labor force','2ba595102c6d2ed544dd53a726ee6c62ab4888ffc0735740bb17c87ebd34b8da','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c809988b637450c6d638444ccb3ea8da4b6868c5230db4bfb49d9e3a52feb03e',1986,'HT','Haiti','people-and-society',225,'Population: 5,870,000 (July 1986), average
annual growth rate 1.9%
Nationality: noun—Haitian(s), adjective—
Haitian
Ethnic divisions: 95% black, 5% mulatto and
European
Religion: 75-80% Roman Catholic.(of which
an overwhelming majority also practice
Voodoo), 10% Protestant, est. 10% other ; -
Language: French (official) spoken by only
10% of population; all speak Creole
Infant mortality rate: 107/1,000 (1983)
Life expectancy: 45
Literacy: 23%
Labor force: 2.3 million (1982); 66% agricul-
ture, 25% services, 9% industry; significant
unemployment; shortage of skilled labor;
unskilled labor abundant
Organized labor: less than 1% of labor force','72a3f6f3988c28db9c7923b8ab08b81885298f09eab1482805dccb7554272e9d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08c74b520c43ab41092cd067d975e1aae730e662538f5c16224787104a09c446',1986,'HK','Hong Kong','people-and-society',232,'Population: 5,465,000 (July 1986), average
annual growth rate 0.9% ,
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 90% eclectic mixture of local reli-
gions, 10% Christian
Language: Chinese (Cantonese), English
Infant mortality rate: 9.9/1,000 (1983)
Life expectancy: 75 .
Literacy: 75%
Labor force: (June 1985) 2.64 million; 37.8%
manufacturing; 22.1% commerce; 18.4%
services; 7.6% construction; 7.6% transport
and communications; 6.8% financing, insur-
ance, and real estate; 1.2% agriculture,
fishing, mining, and quarrying; 0.4% other;
unemployment (seasonally adjusted) 3.0% .
Organized labor: 15.2% of 1984 labor force','196eec815d49f12035eea5d26e6e765b07e43b1443dfc1eaaf53e0c80892d725','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4af6510813bff10365fb8b79fb8439486c9d6c392c50468c634b8d02dae8365e',1986,'HU','Hungary','people-and-society',235,'Population: 10,624,000 (July 1986), average
annual growth rate —0.2%
Nationality: noun—Hungarian(s); adjec-
tive—Hungarian
Ethnic divisions: 96.6% Hungarian, 1.6%
German, 1.1% Slovak, 0.3% Southern Slav,
0.2% Romanian, 1.2% other
Religion: 67.5% Roman Catholic, 20.0%
Calvinist, 5.0% Lutheran, 7.5% atheist and’
other
Language: 98.2% Hungarian, 1.8% other .
Infant mortality rate: 19/1,000 (1983)
Life expectancy: men 65.6, wornen 73.5
Literacy: 98%
Labor force: 4,940,000 (1984); 31% industry;
22% agriculture; 7% construction; 40% ser-
vices, trade, government, and other
lil','59cec4c12c80461e653e84dc56cb2b4fb8259637c0db9fd3f78f1483e8d1cd99','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc4200bd0a1d2bd1abc03099e21e384f124054fb8dabd6c48cd80e7b5e70951a',1986,'IS','Iceland','people-and-society',239,'Population: 244,000 (July 1986), average
annual growth rate 1.0%.
Nationality: noun—Icelander(s);
adjective—Icelandic
Ethnic divisions: homogeneous mixture of
descendants of Norwegians and Celts
Religion: 95% Evangelical eitheran 3%
other Protestant and Roman Catholic, 2% no.
athlation:
Language: Icelandic
Infant mortality rate: 6.1/1,000 (1983)
Life expectancy: men 73.9, women 79.4 .
Literacy: 99.9%
Labor force: 114,000 (1984); 18.6% com-
merce, finance, and services; 12.2%
construction; 9.0% agriculture; 8.0%. fish
- CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
processing; 6.38% transportation and commu-
nications; 5.4% fishing; 16.8% other manu-
facturing; 23.7% other (1983); 1.3% unem-
ployment (1984 average)
Organized labor: 60% Gk labor force
Ga cecient
Official name: Republic of. fedlaid:
Type: republic:
Capital: Reykiavik
Political cGhaiaes 28.¢ counties, 200 par-
ishes,.23 incorporated towns ~.
Legal system: civil law system based on
Danish law; constitution adopted 1944; legal :
education at University of Iceland; does not :''
accept compulsory:IC]J jurisdiction -
tat
National holiday: Anniversary of the Estab-
lishment of the Republic, 17 June
Branches: legislative authority rests jointly
with President and parliament (Althing);
executive power vested in President but ex- ‘.
ercised by Cabinet responsible to parlia-
ment; Supreme Court and 29 lower courts
Government leaders: Vigdis FINN-
BOGADOTTIR, President (since August
1980); Steingrimur HERMANNSSON,
Prime Minister (since May 1983)
Suffrage: universal over age 20 but not com-.
pulsory ; a:
Elections: parliamentary every four years,
last held 23 April 1983; presidential held
every four years; last held August 1984
Political parties and leaders: Independence -
(conservative), Thorsteinn Palsson; Progres-
sive, Steingrimur Hermannsson; Social
Democratic, Jon Baldvin Hannibalsson,
People’s Alliance (left socialist), Svavar
Gestsson
Voting strength: (1983 election) 38.7% Inde-
pendence, 19.5% Progressive, 17.3% |
People’s Alliance, 11.7% Social Democratic,
12.8% other Bg Rak a
Communists: est. less than 100, some of
whom participate in the People’s Alliance,
which drew 22,489 votes in-the 1983 parlia-
mentary elections .
Member of: Council of Europe, EC (free
trade agreement pending resolution of
fishing limits issue), EFTA, FAO, GATT,
IAEA; IBRD, ICAO, ICES, IDA, IFG, IHO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, ITU, [WC—International Whaling
Commission, NATO, Nordic Council,
OECD, UN, UNESCO, UPU, WHO, WMO
WSG
2','c5492a80f0c472617768a14ad07e91e79fc89c223debaeade85797b4106f4913','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af1a000e5903b555b203bc1ac5b368cb2714c9aeed32ecee92a6fdddf9fc1daa',1986,'IN','India','people-and-society',242,'Population: 783,940,000, including Sikkim
and the Indian-held part of disputed Jammu
and Kashmir (July 1986); average annual
growth rate 2.1%
Nationality: noun—Indian(s }; adjective—
Indian ; ~s
Ethnic divisions: 72% Indo-Aryan, 25% =
Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 11.0% Muslim, 2.6%
Christian, 2.0-2.5% Sikh, 0.7% Buddhist,
0.2% other
Language: Hindi, English, arid 14 other of-
ficial languages; 24 languages spoken by a
million or more persons each; numerous
other languages and dialects, for the most —
part mutually unintelligible; Hindi isthe ©
national language and primary tongue of 30
percent of the people; English enjoys
“associate” status but is the most important
language for national, political, and com-'' ’
mercial communication; : Hindustani, a pop-
ular variant of Hindi/Urdu, is spoken’.
widely throughout northern India
Infant me fates 116/1, 000 tee ee )
Life phioa ana, 54. 9.
Literacy: 36% -
Labor force:(84/85) about 284.4-million; a
67% agriculture; more than 10%
unemployed and underemployed
Organized labor: less than 5% of total labor
force
Government : P
Official name: Republic of India © © *
Tyne: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union ter-
ritories ~
Legal system: based on English common
law; constitution adopted 1950; limited judi-
cial review of legislative acts; accepts com-
pulsory ICJ jurisdiction, with reservations
National holiday: Republic Day, 26 January
Branches: bicameral parliament—Council
of States, House of the People; relatively
independent judiciary |. ,
Government leader: Rajiv GANDHL Prime
Minister (since October 1984); Zail SINGH,
President (since July 1982)
Suffrage: universal over age 21,
Elections: national and state elections ordi-
narily held every five years; may be post-
poned ii emergency and may be held more
frequently if government loses confidence
114
vote; last general election in December
1984; state elections staggered |
Political parties and leaders: Indian Na-
tional Congress, controlled national govern-
ment from independence to March 1977;
split in January 1978 and 1979; party cur- ,
rently headed by Prime Minister Rajiv
Gandhi; the Dalit Mazdoor Kisan Party
(DMKP), formed in late.1984 by Charan
Singh of the Lok Dal Party, also absorbed
the Democratic Socialist Party, a breakaway ~
faction of the Janata Party, and Sharad ~
Pawar’s Congress (S) Party; Janata Party led
by Chandra Shekhar; Bharatiya Janata
Party, L. K. Advani; Communist Party of
India (CP)), C. Rajeswara Rao; ‘Communist
Party of India/Marxist (CPI/M), E.M-S. ’
Namboodiripad; Communist Party of
India/Marxist-Leninist ‘(CPI/ML),
Satyanarayan Singh; All-India Anna
Dravida Munnetra Kazagham (AIADMK); a
regional party in Tamil Nadu, led by
M. G. Ramachandran; Akali Dal, led by
Surjit Singh Barnala, representing Sikh reli--
gious community in the Punjab; Telugu
Desam, a regional party''in Andhra Pradesh |
led by N. T. Rama Rao: National Sanjay
Front (SVM), led by Maneka Gandhi; Na-
tional Conference (NC), a regional party in
Jammu and Kashmir, split into factions led
by Farooq Abdullah and G. M. Shah
Voting strength: India Congtess, 74%;
Telugu Desam Party, 5%; CPM, 4%; Janata,
1.8%; CPI, 1.1%; DMKP, 0.5%; BJP, 0.4%;
other, 6.6%; 34 seats vacant as of January
1985
Communists: 466,000 members claimed by
CPI, 270,000 members: claimed by CPI/M;
Communist extremist groups, about 15,000 |
members :
Other eauniedl or pressure poups: ‘Varidus’
separatist groups seeking reorganization of
states; numerous “senas’ or militant/chauvi-
nistic organizations, including Shiv Sena (in
Bombay), Anand Marg, and Rashtriya
Swayamsevak Sangh
Member of: ADB, AIOEC; ANRPC, Co-
lombo Plan, Commonwealth, ESCAP, FAO, -
G-77, GATT, IAEA, IBRD; ICAC, ICAO,
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ICO, IDA, IFAD, IFC, {HO, ILO, Interna-
tional Lead and Zinc Study Group, IMF,
IMO, INTELSAT, INTERPOL, IPU, IRC,
ITC, ITU, [WC—International Wheat
Council, NAM, SAARC, UN, UNESCO,
UPU, WFTU, WHO, WIPO, WMO, WSG,
WTO','d7414d6dbcab4a07c84e18d03bb1720020866ee29089aaa5c48ce9e802f0f8ab','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72c394a6fa15d6bd48efd05fe18e320f73e3f16441efa635d8f1a714370a42b6',1986,'ID','Indonesia','people-and-society',245,'Population: 176,764,000, including Timor
Timur and Irian Jaya (West Irian; J uly ,
1986), average annual growth rate 2.1%
Nationality: noun—Indonesian(s); adjec-
tive—Indonesian
Ethnic divisions: majority of Malay stock
comprising 45.0% Javanese, 14.0% Sundan-
ese, 7.5% Madurese, 7.5% coastal Malays,
26.0% other
Religion: 88% Muslim, 6% Protestant, 3%
Roman Catholic, 2% Hindu, 1% other
Language: Indonesian (modified form of
Malay; official); English and Dutch leading
foreign languages; local dialects, the most
widely spoken of which is Javanese —
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Indonesia (continued)
Infant mortality rate: 95/1,000 (1983)
Life expectancy: 54
Literacy: 62%
Labor force: 67 million (1985 est.); 55% agri-
culture, 10% manufacturing, 4% construc-
tion, 3% transport and communications
Organized labor: 3 million members
(claimed); est. 5% of labor force
Population: 46,604,000 (July 1986), average
annual growth rate 3.1%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun—Iranian(s); adjective—
Iranian
Ethnic divisions: 63% ethnic Persian, 18%
Turkic, 13% other Iranian, 3% Kurdish, 3%
Arab and other Semitic, 1% other
Religion: 98% Shi''a Muslim; 5% Sunni Mus-
lim; 2% Zoroastrian, Jewish, Christian, and
Baha’i
117
Language: Farsi, Turki, Kurdish, Arabic,
English, French
Infant mortality rate: 100/1,000.(1983)
Life expectancy: 54
Literacy: 48%
Labor force: 12.0 million, est. (1979); 33%
agriculture, 21% manufacturing; shortage of
skilled labor; unemployment may be as high
as 35%
Population: 16,019,000 (July 1986), average
annual growth rate 3.2%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun—lIraqi(s); adjective— ,
Traqi :
Ethnic divisions: 75% Arab, 15-20% Kurd-
ish, 5-10% Turkoman, Assyrian, and other’.
Religion: 95% Muslim (55% Shi‘a, 40%
Sunni), 5% Christian or other -
Language: Arabic (official), Kurdish (official
in Kurdish regions); Assyrian, Armenian
Infant mortality rate: 76/ 1,000 (1980).
Life expectancy: 56.1
Literacy: about 50%
Labor ek 3.1 million lisa. 30% apical
ture, 27% industry, 21% government; 22%
other; severe labor shortage due to. war; ex- -
patriate labor force est. at 1,250,000 -
nes labor: 11%:of labor force','8c9b6010794fbae26ba71cfee87bc2948cce0e608d68448ca6ceefaedf89f61b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64cc40ca4c2dabdb8d734a64746fc46949cde30ab03e6f54160883049e23290a',1986,'IE','Ireland','people-and-society',249,'Population: 3,624,000 July 1086) average
annual growth rate 1.0%
Nationality: noun-—Irishman(men), Irish
(collective pl.); adjective—Irish
Ethnic divisions: Celtic, with English mi- ~
nority :
Religion: 94% Roman Catholic, 4% nel
can, 2% other .
Language: Irish (Gaelic) and English (of-
ficial); English is generally spoken
Infant mortality rate: 11/1,000 (1983). -
Life expectancy: 73
Literacy: 99%
120
Labor force: about 1;314,000 (1984); 27.5% .
manufacturing and construction;.16.4% ag- .
riculture, forestry, fishing; 20.4% services;
6.6% government; 6.2% transportation;
other 22.9%; 17.0% unemployment (October
1985)
Organized labor: 36%. of labor force a
Govarniient: ae .
Official name: Ireland, Eire (Gaelic) .
Type: tepablic :
Capital: Dublin i
Political subdivisions: 26 counties .
Legal system: based on English common
law, substantially modified by indigenous
concepts; constitution adopted 1987; judicial
review of legislative acts in Supreme Court;
has not accented compulsory ICJ suntedies
tion
National holiday: St. Panicle ''s Day, 17
March
Branches: elected President; bicameral par-
liament (Seanad, Dail) reflecting propor-
tional and vocational representation; judi-
ciaty appointed by President on advice of','7aa5861e1c98d5c7657b405d98600284db641b7d10dd15add6de66dc8c6aada1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c46199a6c552780aca24d1632aaac3cc35ce7ae16790f1ea116b427df0c91840',1986,'IL','Israel','people-and-society',253,'Population: 4, 208, 000, excluding West .
Bank, Gaza Strip, and East Jerusalem (July
1986), average annual growth rate 1.9%
Nationality: noun—Israeli(s); adjective— .
Israeli
Ethnic divisions: 83% Jewish, 17%
non-Jewish (mostly Arab)
Religion: 83% Judaism, 13.1% Islam, 2.3%
Christian, 1.6% Druze
Language: Hebrew official; Arabic used of-
ficially for Arab minority; English most
commonly used foreign language
Infant mortality rate: 14.1/1,000 (1983)
Life expectancy: 72.1
Literacy: 88% ine 70% Arabs
Labor force: est. 1,400,000 (1984); 29.5%
public services; 22.8% industry, mining, and
manufacturing; 12.8% commerce; 9.5% fi-
nance and business; 6.8% transport, storage,
and communications; 6.5% construction and
public works; 5.5% agriculture, forestry, and
fishing; 5.8% personal and other services;
1.0% electricity and water (1983); unem-
ployment about 6.7% (1985)
Organized labor: 90% ‘of labor force','ad50e767ce7085d116dad8dc9e903a9e4888cccceb9dcb7da8a3ff7e62786c90','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f3b1b6f42889637b7fee4035ef2d8aa3cb187338753774798da74685b742e76',1986,'IT','Italy','people-and-society',256,'Population: 57,226,000 (July 1986), average
annual growth rate 0.2%
Nationality: noun—Italian(s); adjective—
Italian
Ethnic divisions: primarily Italian but popu-
lation includes small clusters of German-,
French-, and Slovene-Italians in the north
and of Albanian-Italians in the south
Religion: almost 100% nominally Roman
Catholic
Language: Italian; parts of Trentino-Alto
Adige region (for example, Bolzano) are pre-
dominantly German speaking; significant
French-speaking minority in Valle d’Aosta
region; Slovene-speaking minority in the
Trieste-Gorizia area
Infant mortality rate: 11.3/1,000 (1984)
Life expectancy: 73
Literacy: 93%
Labor force: 23,083,000 (1984); 30.5% indus-
try, 10.5% agriculture, 48.6% services (1984);
10.4% unemployment (1984)
Organized labor: 40-45% (est.) of labor force
Population: 10,500,000 (July 1986), average
annual growth rate 4.0%
Nationality: noun—Ivorian(s); adjective—-
Ivorian
Ethnic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20% of
population; most important are Agni, —
Baoule, Krou, Senoufou, Mandingo; approxi-
mately 2 million foreign Africans, mostly
Burkinabe; about 70,000 to 75,000
non-Africans (30,000 French and 25,000 to |
80,000 Lebanese)
Religion: 68% indigenous, 25% Muslim, 12%
Christian
Language: French (official), over 60 native
dialects; Dioula most widely spoken
: CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Ivory Coast (continued)
Infant mortality rate: 127/1,000 (1980)
Literacy: 24%
Labor force: over 85% of population en- -
gaged in agriculture, forestry, livestock rais-__
ing; about 11% of labor force are wage earn-
ers, nearly half in agriculture and the re-
mainder in government, industry,
commerce, and professions
Organized labor: 20% of wage labor force.','93f012bf7f80b7793de3a3fb1a569b17d0dd39a985123f4d9e05a22883dca2a7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28759de2252c010c091a4cd51513c236e2c2b793fbd2d896bc173d5b4f54b8b6',1986,'JM','Jamaica','people-and-society',260,'Population: 2,288,000 (July ioe) average
annual growth rate 1.0%
Nationality: noun—Jamiaican(s);
adjective-—Jamaican. a
Ethnic divisions: 76.3% African, 15.1%
Afro-European, 3.4% East Indian and Afro-
East Indian, 3.2% white, 1.2% Chinese and
Afro-Chinese, 0.8% other
Religion: predominantly Protestant (includ-
ing Anglican and Baptist), some Roman
Catholic, some spiritualist cults
Language: English, Credle
Infant mortality rate: 16.8/1,000 (1984)
Life expectancy: 65
Literacy: 76%
Labor force: 728,700 (1984); 32% agricul-
ture, 28% industry and commerce, 27%
services, 13% government; shortage of -
technical and managerial personnel; 30% -.
unemployment
Organized labor: about 33% of labor fore
(1980)','29e467d4095c128901123838dc84e1d4af1a213332afd0287f72d10b211d344b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a124a682e2856f23a7ea1005a1a7beaa1782634f964fc834bc996434807fae2',1986,'JE','Jersey','people-and-society',265,'Population: 80,000 (July 1986), average an- ©
nual growth rate 0.9%
Nationality: noun—Channel Islander(s); -
adjective-—Channel Islander
Ethnic divisions: UK and Norman- F rench_
descent :
Religion: Anglican, Roman Catholic, Bap-
tist, Congregational New Church, Method-
ist, Presbyterian .
Taneuabe: English and Frenich (official), -
with the Norman-French dialect spoken ir in
country districts ,
Literacy: probably high','0785e1eae211c04f64afc42b072523fe83515291257fbc46fcc5d29244f8ea62','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf6bb6c250888799894147484a7eaff523a91e821588c6e125f9e72f232d491c',1986,'JO','Jordan','people-and-society',269,'Population: 2,756,000 (July 1986), average
annual growth rate 3.3%
Nationality: noun—Jordanian(s); adjec-
tive—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, *
1% Armenian
Relicioneete Sunni Msi; 5% Christian .
Leanne: Arabic (official) English midely
understood among upper and middle classes
mene mortality rate: 62/1, Oe) i?
Life expectancy: 61.7
Literacy: about 71%
Labor force: 580,000 (1983 est.); 20% agri- .
culture, 20% manufacturing and mining
Organized labor: about 10% of labor force. °','ad405efcfc72dab7973fa4a09d41a8ee83ec833ce3875c20b6abd7fef3e8573e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cb1f9fb77726aee62e0f0d06070967a6fbac60f97e6a1455e689c59a2579d59',1986,'KE','Kenya','people-and-society',273,'Population: 21,044,000 (July 1986), average
annual growth rate 4.1%
Nationality: noun—Kenyan(s), adjective—
Kenyan :
Ethnic divisions: 21% Kikuyu, 14% Luhya,
13% Luo, 11% Kalenjin, 11% Kamba, 6%
Kisii, 5% Meru, 1% Asian, European, ane:
Arab
Religion: 38% Protestant, 28% Catholic, 26%
indigenous beliefs, 6% Muslim
Language: English and Swahili (official),
numerous indigenous languages
Infant mortality rate: 59/1,000 (1985)
Life expectancy: men 58, women 58.1
Literacy: 47%
oe (182
Labor force: 7.4 million; about 1.1 million
wage earners; 50% public sector, 18% indus-
try and commerce, 17% agriculture, 18%
services j
Organized labor: about 890,000
Population: 40,000 (July 1986), average an-
nual growth rate — 1.2%
Ethnic divisions: mainly of African Negro
descent
Nationality: noun—Kittsian(s), Nevisian(s);
adjective—Kittsian, Nevisian
Religion: Anglican, other Protestant sects,
Roman Catholic
Language: English
Literacy: 80%
Labor force: 20,000 (1981)
Organized labor: 6,700
Population: 7,000 (July 1986), : average an-’
nual growth rate 1.3%
Nationality: noun—St. Helenian(s); adiec-
tive—St. Helenian_
Religion: Anglican majority; also Baptist,
Seventh Day Adventist, and Roman, Catho- .
lic oe ah B
Pan cuane: English
Infant Saaualitg rate: 22. 37/1, 000 (1982),
bieracy: probably high. a Z a ‘
Labor fee large ce oe seiglivet
overseas, particularly on Ascension
Organized labor: St. Helena General : ''
Workers’ Union, 472 members; 10% profes-
sional and technical, 9% mangement and ©
Pande 2
"122 km? St. Helena; smaller''than Washing:
clerical, 5% sales, 9% farming and fishing,
6% transport, 17% crafts, 10% service, 1%
security, and 33% other
ae ee oe op
Government: * -™ ae
Official name: St. Helena _
Type: British dependent territory
Capital: Jamestown — ,
Political subdivisions: Ascension re
Triston da Cunha are dependencies of St.
Helena. ae a
Legal system: Constitution in effect since --.
1967; Supreme Gourt- *
Branches: Executive Council, 12-member
elected: Leusiatiye Council” .
Government leader: Francis BAKER, Gov-
ernor and Commander iti Chief (sincé 1984)
Elections: gerieral élections held iri October ©
1984.
Political parties and leaders: St. Helena La-
bor Party, G. A: O. Thornton; St. Helena
Progressive. Party, leader unknown
Votiig Mena ‘both politieal parties. inac-
tive since 1976
Communists: probably none - *
Population: 128,000 July 1986), average ~
annual growth rate 1.1%
Nationality: noun—St. Lucian(s); adjec-
tive—St. Lucian
Ethnic divisions: 90. 3% African descent,
5.5% mixed, 3.2% East Indian, 0.8% Cauca-
sian
Religion: 90% Roman Catholic, 7% Protes-
tant, 3% Church of England
Language: English (official), French patois
Infant mortality tate: 27.4/1,000 (1984)
Life expectancy: men 68.3, women‘72.4
Literacy: 78%
Labor force: 43,800 (1983 est.); 43.4% agri-
_ culture, 38.9% services, 17.7% industry and
commerce; 30% unemployment (1984)
Organized labor: 20% of labor force
Population: 108,000 (July 1986), average
annual growth.rate 0.9% ;
Nationality: noun—St. Vincentian(s) or
Vincentian(s); adjectives—St. Vincentian or
Vincentian
Ethnic divisions: mainly of African Negro
descent; remainder mixed, with some white,
East Indian, Carib Indian
Religion: Anglican, Methodist, Roman Cath-
olic
Language: English, some French patois
Literacy: 82%
Labor force: 67,000 (1984 est.); about 40%
unemployed (1984)
Organized labor: 10% of labor force','56385d9054a7650c3bdccd2a9529b5e3abf2cccbb2c9d348b24a2dd9c1770880','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90adfc5a0cf9514f335da989954004a70de9dec3684e19092092352cef991ca3',1986,'KI','Kiribati','people-and-society',277,'Population: 63,000 4 uly 1986), average an-
nual growth rate 1.8%
Nationality: noun—Kiribatian(s); adjec-
tive—Kiribati
Ethnic divisions: Micronesian
Religion: Roman Catholic, Protestant
Language: English (official), Gilbertese
Literacy: 90%
Labor force: 15,921 (1973); general unem-
ployment rate 4.9%
Population: 20,543,000 (July 1986), average
annual growth rate 2. 3%
Nationality: ananeSe oleae adjective—
Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; reli-
gious activities now almost nonexistent
Language: Korean |
Infant mortality rate: 32/1,000 (1983)
Life expectancy: men 63, women 67
Literacy: 95% est. .
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
see ee
Declassified and Approved For Release 2012/08/29 CIA-RDP08-00534R000100170001-4
Labot force: 6. i million (1980); 48% agricul- ;
tural, 52% nonagricultural; shortage of
skilled and unskilled labor
Population: 43,285,000 (July 1986), average
annual growth rate 1.5%
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: homogeneous; small Chi-
nese minority (approx. 20,000)
Religion: strong Confucian tradition; vigor-
ous Christian minority (28% of the total pop-
ulation); Buddhism; pervasive folk religion
(Shamanism); Chondokyo (religion of the
heavenly way), eclectic religion with nation-
alist overtones founded in 19th century,
claims about 1.5 million adherents
Language: Korean; English widely taught in
high school
Infant mortality rate: 29/1,000 (1983)
Life expectancy: men.64, women 71
Literacy: over 90%
'' Labor force: 15.4 million (1985 est.);47%
services and other; 30% agriculture, fishing,
forestry; 21% mining''and manufacturing; ...
average unemployment 4.1% (1985 est.)
Organized labor:.about 10% of nonagri-
cultural labor force in government-. sanc-
tioned unions -','c3be7948bc581c9f3e2d9a6d4561184ec888c8390833fb4464748c703cb372f9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d56927ca2a49e8e455c3646d6e2f924aa10900c0108015d7e830c37cd81433dc',1986,'KW','Kuwait','people-and-society',281,'Population: 1,771,000 (July 1986), average
annual growth rate 3.5%
Nationality: noun—Kuwaiti(s); adjective—
Kuwaiti
Ethnic divisions: 39% Kuwaiti, 39% other
Arab, 9% South Asian, 4% Iranian, 9% other
Religion: 85% Muslim, 15% Christian,
Hindu, Parsi, and other
Language: Arabic (official); English widely ,
spoken ; ‘
Infant mortality rate: 26.1/1,000 (1985)
Life expectancy: men 69, women 74
Literacy: about 71%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Kuwait (continued)
Labor force: 566,000 (1985); 45.0% services,
20.0% construction, 12.0% trade, 8.6% man-
ufacturing, 2.6% finance and real estate,
1.9% agriculture, 1.7% power and water,
1.4% mining and quarrying; 70% of labor
force is non-Kuwaiti
Organized labor: labor unions, first autho- :
rized in 1964, formed in oil industry and
among government personnel ‘*
Population: 3,679,000 (july 1986), a average
annual growth’ rate 2.0%
Nationality: noun—Lao (sing., Lao or Lao-
tian); adjective—Lao or Laotian
Ethnic divisions: 48% Lao; 25% Phoutheung
(Kha); 14% Tribal Tai; 13%. Meo, Yao, and
other
Religion: 50% Buddhist, 50% animist and
other
Language: Lao (official), French, and Eng-
lish ;
Infant mortality rate: 159/1,000 (1983)
Life expectancy: men 42, women 45
Literacy: 85%
Labor force: about 1-1.5 million; 80-90%
agriculture
Organized labor: only labor organization is
subordinate to the Communist Party','c0f22588c60f3c2308cfdd57bdea423ad2626ced34ab89114b6517b409efa0c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11dff1295e103c13c818d00d0f743ad90dc6a60833d8f425aa4a846d86b4e7e3',1986,'LR','Liberia','people-and-society',290,'Population: 2,307,000 (July 1986), average
annual growth rate 3.3%
Nationality: noun—Liberian(s); adjective—
Liberian
Ethnic divisions: 95% indigenous African
tribes, including Kpelle, Bassa, Gio, Kru, .
Grebo, Mano, Krahn, Gola, Gbandi, Loma,
Kissi, Vai, and Bella; 5% descendants of re-
patriated slaves known as Americo-,
Liberians
Religion: 75% traditional, 15% Muslim, 10%
Christian
Language: English (official); more than 20 .
local Janguages of the Niger-Congo language
group; English used by about 20%
Infant mortality rate: 153/1,000 (1984)
Life expectancy: 54
148
Literacy: 24%
Labor force: 510,000, of which 220,000 are
in monetary economy; non-African foreign-
ers hold about 95% of the top-level manage-
ment and engineering jobs; 70.5% agricul-
ture, 10.8% services, 4.5% industry and com-
merce, 14.2% other
Organized labor: 2% of labor force','ce9384cb9db7333b784eaf4b21c7d35694a57e721bb456d2e4c0508f2ff55717','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('908c92105b12d8c81925e2672b4a2ef1b0517720ddef826f79580ef153505c34',1986,'LI','Liechtenstein','people-and-society',294,'Population: 28,000 (July 1986) average an-
nual growth rate L 8%
Nationality: seit op tee terateibene ad-
jective—Liechténstein
Ethnic divisions: 95% Alemannic, 5% italian
and other
Religion: 82.7% Roman Catholic, 7: 1% Prot-
estant, 10.2% other
Language: German (official), Alemannic
dialect tele 3
Infant mortality rate: 6.3/1,000 (1985)
Life expectancy: men 65, women 74 . "
Literacy: mee
Labor fries 12, 258; 5, 078 foadian wae
(mostly from Switzerland and Austria);
54.5% industry, trade, and building; 41:6%
services; 4.0% agriculture, fishing, forestry,
and horticulture; no unemployment','6702bb4bb13b61b2a5b4ba0deb4b6d18e386959b4b5a010f0c009639d9207044','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b2b7a769b9f57f30071f2ceef4381c6bd2a38a7f72af6c5c55de1261f14bad3',1986,'LU','Luxembourg','people-and-society',297,'Population: 367 ,000 July 1986), average
annual growth Fate 0.1%
Nationality: noun—Luxembourger() -ad-"°
jective—Luxembourg °
Ethnic divisions: Celtic fee with French .
and German biend; also guest and worker
residents from Portugal, Italy; and Euro-
péan countries
Religion: 97% Roman Catholic, 3% Protes- °
tant and Jewish
Language: Luxembourgish, German,
French; most educated Luxembourgers also
speak English ° By odie
Infant mortaitty rate: ae ai
Life expectancy: men 70, women 76. 7
Literacy: 100%.
Labor force: (1983) 160, 800; one-third of
labor force is: foreign, comprising mostly
workers from Portugal, Italy, France, Bel-.
gium, and FRG (1981); unemployment 1.5% -
147
(1985 average); 45% services, 39% industry
and commerce, 15% government, 0.7% agri-
culture
Population: 404,000 (July 1986), average
annual growth rate 2.8%
Nationality: noun—Macanese (sing. and
pl.); adjective—Macau
Ethnic divisions: 98% Chinese, 2% Portu-
guese
Religion: mainly Buddhist; 17,000 Catho-
lics, of whom about half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese
and Macanese; no data on Chinese popula-
tion','233ddc40fe71bf6488c0c7d8f2c87de5291f38b8af5483b7ecaf250ad6598238','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ff5633f347f3da87e6739fa4c07418d0a03e687d80c6e40345c6a8a8b6ced83',1986,'MZ','Mozambique','people-and-society',302,'Population: 10, 297, 000 July 1986), average
annual growth rate 2.8%
Nationality: noun—Malagasy (sing. and pl.)
adjective—Malagasy
Ethnic divisions: basic split between high-
landers of predominantly Malayo-
Indonesian origin, consisting‘of Merina
(1,643,000) and related Betsileo (760,000) on
the one hand and coastal tribes—collectively
termed the Cétiers—with mixed Negroid,
Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include |
Betsimisaraka 941,000, Tsimihety 442,000,
Antaisaka 415,000, Sakalava 875,000; there
are also 10,000-12,000 European French,
5,000 Indians of French nationality, and
5,000 Creoles
4
Religion: more than half indigenous beliefs;
about 41% Christian, 7% Muslim
Language: French and Malagasy official
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Madagascar (continued)
Infant mortality rdte: 177/1,000 (1984)
Life expectancy: 46
Literacy: 53%
Labor force: about 4.8 million (1984), of - -
which 90% are nonsalaried family workers
engaged in subsistence agriculture; of
175,000 wage and salary earners, 26% agri-
culture, 17% domestic service, 15% industry,
14% commerce, 11% construction, -9% ser-
vices, Bh transportation, 2% Hee ancols
Greate labor: 4% of labor force
Population: 14,022, 000 (july 1986), average
annual growth rate 2.8%
Nationality: noun—Mozambican(s ); adjec-
tive—Mozambican
Ethnic divisions: majority from indigenous _
tribal groups; approximately 10,000 Europe-
ans, 35,000 Euro-Africans, 15, 000 Indians
Religion: 60% indigenois beliefs, 30% Chris-
tian, 10% Muslim: :
Lengiiage: Beauedes (official); many y indig-
enous dialects
Infant mortality rate: 109/1,000(1983) ° -
Life expectancy: men 44, women 47.
Literacy: 14%
Labor force: 85% engaged in agriculture
171','59bd609d412325b7c0cf9a1ae337c95e7470aae172e6bb415c9d232476e723e0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28d28229060e1b66836ce01aff866316544cd642de08efab712ea039ed771399',1986,'MW','Malawi','people-and-society',306,'Population: 7,292,000 0 duly 1986), average ,
annual growth rate 3.3%
Nationality: noun—Malawian(s); adijec-
tive—Malawian
Ethnic divisions: Chewa, Nyania,
Tumbuko, Yao, Lomwe, Sena, Tonga,
Ngoni, Asian, European
Religion: 55% Protestant, 20% Roman Cath-
olic; 20% Muslim; traditional indigenous
beliefs are also practiced by some members
of these groups
Language: English and Chichewa (official);..
Tombuka is second African language —
Infant mortality rate: 14/1,000 (1983)
Life expectancy: 47
Literacy: 25%
Labor force: 344,052 wage earners _. -
employed in Malawi (1982); 52% agricul-
ture, 16% personal services, 9% manufactur-
ing, 7% construction, 6% commerce, 4%
151
miscellaneous services,-5% other permaz: °’
nently employed
Onbanized labor: small minority of wage
earners are unionized a
Govainnieat
Official name: Republic of Malawi ,
Type: one-party state . .
Capital: Talenewe :
Pakiieal Siuhdidistone: 3 administrative re-
gions and 24, districts
Legal system: based on-English common. -
law and customary law; constitution - ~~~"
adopted 1964; judicial review of legislative «
acts in the Supreme Court of Appeals; has
not accepted compulsory ICJ jurisdiction *":
National holiday: Republic Day, 6 July ; - °
Branches: strong presidential system with
Cabinet appointed by President; an eeieeal |
National Assembly of 87 elected and up to ...
15 nominated members; High Court with
Chief Justice and at least two justices
Government leader: Dr..Hastings Karina:
BANDA, President (since 1966).
Suffrage: universal over age 18 »
Elections: President Banda designated Pies--
ident for Life in 1970; parliamentary elec- ~
tions last held June 1983, next peheduled ie
1988 ; ;
Political parties and leaders: Malawi Con- es
gress Party (MCP), Robson Chirwa, adminis-
trative secretary j :
Communists: no Communist party
Member of: A{DB, Commonwealth, EC.
(associated member), FAO, G-77, GATT, .
IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF,
INTELSAT, INTERPOL, IPU, ISO, ITU, :
NAM, OAU, SADCC, UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO” SCP ENG ee
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Malawii (continued)','80d75c2c43c64bb4d49083c3ad4c62a715430eaff5d5d27d0a0cce02a4a29dac','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b5aff6bb6b526ca9be0082fa84dc6828ada81fd82e130517069a6e072b985d2',1986,'MV','Maldives','people-and-society',312,'Population: 184,000 (July 1986), average
annual growth rate 3.1%
Nationality: noun—Maldivian(s); adjec- «|
tive—Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab, and black
Religion: Sunni Muslim
Language: Divehi (dialect of Sinhala; script
derived from Arabic); English spoken by
most government officials
I ‘fini mortality rate: e: 88 /1,000 (1984) -
Life expectancy: 46.5
155
Literacy: see
aber ace total cag ences is approxi-
mately 66,000; fishing. industry employs 80%
of the labor force
Givemiinene ve
Official name: Republic of Maldives
Type:republic
Capital: Male
Political subdivisionis: 19 administrative
districts corresponding to atolls plus capital
city
igoal system: based on Islamic law with
admixtures of English common law prima-
rily in commercial matters; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 26 -
July; Republic Day, 11 November
Branches: popularly elected unicameral
national legislature, People’s Council (mem-
bers elected.for five-year terms); elected
President, chief executive; appointed Chief
Justice responsible for administration of Is-
lamic law
Government leader: Maumoon Abdul
GAYOOM, President (since 1978)
Suffrage: universal over age 21]
Political parties and leaders: no organized
political parties; country governed by the. -
Didi clan for the past eight centuries
Communists: s:neliible number
Member of: ADB, Civeis Plan, Common-
wealth (special member), ESCAP, FAO, °<
G-77, GATT (de facto), IBRD, ICAO, IDA,
IDB—Islamic Development Bank, IFAD, .
IFC, IMF, IMO, ITU, NAM, OIC, SAARC,
UN, UNESCO, UPU, WHO, WMO .. :','e6b78e1157d355e0086bbfc6e30ca1ee07f3ce2fa979fa1149bb7ec414f0db10','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e8506b9830408e13e493d8aecc39253711771d7c9c6505cd533763dff49e471',1986,'ML','Mali','people-and-society',315,'Population: 7,898,000 (July 1986), average
annual growth rate 2.3%
Nationality: noun—Malian(s); adjective—
Malian
Ethnic divisions: 50% Mande (Bambara,
Malinke, Sarakole), 17% Peul, 12% Voltaic,
6% Songhai, 5% Tuareg and Moor
Religion: 90% Muslim, 9% indigenous be-
liefs, 1% Christian
Language: French (official); Bambara spo-
ken by about 80% of the population
Infant mortality rate: 152/1,000 (1984)
Life expectancy: 45
Literacy: 10%
Labor force: 8.1 million (1981); 80% agricul-
ture, 19% services, 1% industry and com-
merce
Organized labor: National Union of Malian
Workers (UNTM) is umbrella organization
over 18 national unions
156
Population: 354,000 (July 1986), average
annual growth rate —0.2%.
Nationality: noun—Maltese (sing. and pl.);
adjective—Maltese : :
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, English
Religion: 98% Roman Catholic
Language: Maltese and English (official)
Infant mortality rate: 11. i 000 (1984) -
Life expectancy: 78:
Literacy: 83% _
Labor force: 121,686 (1984); 30% services
(except.government), 24% manufacturing,
21% government (except job corps), 8% con-
struction, 5% utilities and drydocks, 4% agri-
culture; 8.3% registered unemployed
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Malta (continued)
Organized labor: aporoxmately. 40% of la: |
bor force : °
Government | ee
Official name: Republic of Malta
Type: sa amentaey demiberoey indepen-
dent republic within the Commonwealth —
since December 1974
Capital: Valletta hip
Political subdivisions: 2 main populated
islands, Malta‘and Gozo, divided into 13
electoral districts (divisidns)
Legal system: based on English common
law; constitution adopted 1961, came into’
force 1964; has accepted: ‘compulsory Icy
jurisdiction, with reservations
Branches: executive, consisting of Prime
Minister and Cabinet; unicameral legisla-
ture (65-member House of Representatives);
independent judiciary — 4
National holiday: Freedom Day, 31‘March
Government leaders: Agatha BARBARA;: °
President (since February 1982): Karmenu °
MIFSUD BONNICTI, Prime Minister a
December aie
Suffrage: universal over rage 18; FegtaHon
required ae :
Elections: at the discretion of the Prime
Minister, but must be held before the.expira-
tion of a five-year electoral mandate; last ~
election December 1981
Political parties and leaders: Nationalist
Party, Edward Fenech Adami; Malta''Labor
Party, Karmenu Mifsud Bonniei_
Voting strength: (1981 election) House of
Representatives—Labor;34 seats (49% of - ».
the vote); Nationalist, 81. seats (51% of he
vote)
Communists: less than 100 (est.) .
Member of: Commonwealth, Counéil of :
Europe, FAO, G-77, GATT, IBRD, ICAO,
IFAD, ILO, IMF, IMO, INTERPOL, ITU,
IWC— International Wheat Council, NAM; -
UN, UNDP, UNESCO, UNICEF, UPU,
WHO, WO, WMO','d3b5e572c3d385da3af558ba63400e8aba0f445461184aa0488969ce5fa7e78f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('576c917b24177debe945d01e025608a31d211cf00e2bc2f24eb642fbdaaf03af',1986,'MQ','Martinique','people-and-society',319,'Population: 328,000 (July 1986), average
annual growth rate 0. Le
Nationality: ay Marttiicaais (sing. and
pl.); adjective—Martiniquais
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, 5% Caucasian,
less than 5% East Indian, Lebanese, Chinese -
Religion: 95% Roman Catholic, 5% Hindu
and pagan African . .
Language: French, Creole tetols
Infant mortality rate: 12. 6/1, 000 ( (8h
Life expectancy: 68 .
Libeacs: Buet nom
Labor force: 100,000; 31.7% service indus-
try, 29.4% construction and public works,
13.1% agriculture, 7.3% industry, 2.2% fish-
eries, 16.3% other; 14% unemployed
Organized labor:''11%.6f labor force’','2631cb739bcb430794659402dbfd50c11b59dc3abb5eb7d0c866d9069e184bfa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0677ed06732849e60bc81625936e0f4b3e733d3d5bcc0e05c62ac9054e1da440',1986,'MR','Mauritania','people-and-society',323,'Population: 1,691,000 (July 1986), average
annual growth rate 2.1%
Nationality: noun—Mauritanian(s); adjec-
tive—Mauritanian . :
Ethnic diwisions: 40% mixed Moor/ black;
80% Moor, 30% black
Religion: nearly 100% Muslim
Language: Hasaniya Arabic (national);
French (official) Toucouleur, Fula; Sarakole,
Wolof: ;
Infant mortality rate: 136/1,000 (1983)
Life expectancy: men 44, women 47
Literacy: 17% ''
Labor force: total labor force 465,000 (1981
est.); about 45,000 wage earners (1980 IMF);
161
47% agriculture, 29% services; 14% industry *
and commerce, 10% government; consider-
able unemployment.
Organized labor: 30,000 members claimed
by single union, Mauritanian Workers’
Union . ;','eb0a5f076a566fed9ff3d695efe3d1d3e7693e725a868f2e1ae7c3962de41b13','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fb864f6133bdaf06d4695ab5646edca99d4fe441d727a459f7f221f0a56ebcf',1986,'MU','Mauritius','people-and-society',326,'Population: 1,020,000 (July 1986), average ‘
annual growth rate 0.9% “ae o
Nationality: noun—=Mauritian(s); adjec-"
tive—Mauritian
Ethnic Aone 68% (as auean: 27%
Creole, 3% Sino-Mauritian, 2% - air he
Franco-Mauritian =. *
sda 51% Hinde, 30% Christian (mostly ’
Roman Catholic witha as Anglicans), Te
Muslim
eesdbe: English (official), Gila. French
Hindi, Urdu: Hakka, Hoipoon ae
bee morality rate: o28/ 1 000 (1985) «
Life expectancy: 67
Literacy: 79%
- Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: 335,000; 29% government ser-
vices, 27% agriculture and fishing, 22% man-
ufacturing, 22% other; 20% are unemployed
Organized labor: about 35% of labor force,
forming over 270 unions','5a170e5479363716142937a64e0967672f70f870958e8adaae5b7e73c050aeb5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05f97254146ca9c14832d4b9b9643b20745375836fe73f7bd2931ec30748e09e',1986,'MX','Mexico','people-and-society',330,'Population: 81,709,000 (July 1986), average
annual growth rate 2.5%
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo (Indian-
Spanish), 30% Amerindian or predominantly
Amerindian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic,
3% Protestant
Language: Spanish
Infant mortality rate: 55.9/1,000 (1980)
Life expectancy: 65.4
Literacy: 88.1%
Labor force: 24,000,000 (1985); 31.4% ser-
vices; 26% agriculture, forestry, hunting,
fishing; 13.9% commerce; 12.8% manufac-
turing; 9.5% construction; 4.8% transporta-
tion; 1.8% mining and quarrying; 0.3% elec-
tricity; 10% unemployed, 40% underem-
ployed
Organized labor: 35% of total labor force','51694aed73226a89c2a24db983bfd4bf2ac2ac5d23e03a1446fa497b0d6c9e26','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b609ea6cfd7ad61e516fc5ec32b9808424e7758289f29c93baeaaed14b6a8c94',1986,'MC','Monaco','people-and-society',334,'Population: 28,000 (July 1986), average an-
nual growth rate 1.0%
Nivionality: noun—Monacan(s) or Mone-
gasque(s); adjective—Monacan or Mone-
gasque
Ethnic divisions: 47% French, 16% Mone- _
gasque, 16% Italian, 21% other
Religion: 95% Roman Catholicism .
Language: French (official), English, Italian,
Monegarque
Literacy: 99%','a06bb496b2f2f38281cf92c3c31043acd9560ee19f7158059d2227adaa29f033','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7b6a678d76d74b95b42ee41ca2887c7d16310d8c5325d50b51907d0fe333a9e',1986,'MN','Mongolia','people-and-society',338,'Population: 1,942,000 (July 1986), average. .
annual growth rate 2.6% i
Nationality: noun—Mongolian(s); adjec-
tive— Mongolian ;
Ethnic divisions: 90% ae 4% nik
2% Cluinesss 2% Russian, 2% other
elicien: predominantly Tibetan Buddhist,
about 4% Muslim, limited religious activity ©
because of Communist regime
Language: Khalkha Mongol used by over
90% of population; minor languages include
Turkic, Russian, and Chinese
Life expectancy: 63 .
Literacy: about 80%
Labor force: primarily agricultural; ovet
half theadult population is in the labor
force, including a large percentage of
worien; shortage of skilled labor
Gibran
Official name: Mongolian People s Resablic
Pie: Coranucia state -
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 ; CIA-RDP08-00534R000100170001-4
Mongolia (continued):
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 3
autonomous municipalities (Ulaanbaatar,
Darhan, and Erdenet)
Légal system: blend of Russian, Chinese;
and Turkish systems of law; new constitu-_
tion adopted. 1960; no constitutional provi-
sion for judicial review of legislative acts;
legal education at Ulaanbaatar State Univer-
sity; has not accepted compulsory IC] juris-
diction
National holiday: People’s Revolution Day,
11 July
Branches: executive—Council of Ministers;
legislative—unicameral People’s Great
Hural; judicial—court system; Supreme
Court elected by People’s Great Hural
Government leaders: Jambyn BATMONH,
Chairman of the Presidium of the People’s
Great Hural (since December 1984);
Dumaagiyn SODNOM, Chairman of the
Council of Ministers (since December 1984)
Suffrage: universal at age 18 and over
Elections: legislative election theoretically
held every four years; last election held June
198]
Political party and-leader: Mongolian
People’s Revolutionary Party (MPRP),
Jambyn Batmonh, General Secretary (since
August 1984)
Communists: estimated MPRP member-
ship, 81,000 (1984)
Member of: CEMA, ESCAB, FAO, IAEA,
ILO, IPU, ITU, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO
Economy, _ ye
GDP: $1.20 billion (1976 est.); average an-
nual real growth, 1.6% (1970-77)
Natural resources: coal, copper, molybde- |
num, tungsten, phosphates, tin, nickel, zine,
wolfram, fluorspar, gold: ”
Agriculture: livestock raising predominates;
main crops—wheat, oats, barley
Major industries: processing-of animal
products; building materials; mining
Electric power: 645,000 kW capacity (1985);
2.2 billion kWh.produced (1985), 1,150 kWh
per capita
Exports: eetack animal products, sacl
hides, fluorspar, nonferrous metals, minerals
Imports: machinery and equipment, petro- |
leum, clothing, building: materials, sugar,
tea, chemicals
Major hails partners: nearly all trade with ~
Communist countries (approx. 80% with
USSR); total turnover about $1.0 Pullip:
(1977)
Aid: heavily dependent on USSR
M nein conversion vate: 3. 3555 inetikes
US$] (February 1984)
Fiscal year: calendar year','8b50b67d33aa13ece517233392d907183ec786d9ccdc84faed9df1f4b10758ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e88ddd6651dda38e5a3f14996995bf0c8b0afbbe19e9cee19dfb4703ef06bfe5',1986,'MS','Montserrat','people-and-society',340,'Population: 12,000 (J ally 1986), average an-
nual growth rate 0.2%
Nationality: noun--Montserratian(s); adjec-
tive—Montserratian es
Ethnic divisions: mostly black with a few.
Europeans ..
Religion: Anglican, Methodist, Roman Cath-
olic, Pentecostal, Seventh-Day ‘Adventist,
other Christian denominations
Language: English
Literacy: 77% —
Infant mortality rate: 124/1,000 (1983)
Labor force: 5,100 (1983 prelim.); 40.5%
community, social, and personal services,
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
ee
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
13.5% construction, 12.3% trade, restau-
rants, and hotels, 10.5% manufacturing,
8.8% agriculture, forestry, and fishing,
14.4% other; 7.0% unemployment (1984)
Organized labor: 3 trade unions with 1,498
members; about 30% of work force (1984)','07f3850e54c1392b88076db5f328a162b54ad6d08aa9153e8084836b88a10581','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f45c2cd8f53ff6d55c732c4a5d175774a773119db1a447e43f272b9b13a07c9',1986,'MA','Morocco','people-and-society',344,'Population: 23,667,000 (July 1986), average
annual growth rate 2.4%
Nationality: noun—Moroccan(s); adjec-
tive—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.7%
non-Moroccan, 0. 2% Jewish
Religion: 98.7% Muslim, 1.1% Christian,
0.2% Jewish
Language: Arabic (official); several Berber
dialects; French is language of business, gov-
ernment, diplomacy, and postprimary edu-
cation
Infant mortality rate: 117/1,000 (1978)
Life expectancy: 54
Literacy: 28%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Morocco (continued)
Labor force: 7.5 million (1985); 50% agricul-
ture, 26% services, 15% industry, 9% other; .
at least 20% of urban labor unemployed
Organized labor: about 5% of the labor
force, mainly in the Union of Moroccan
Workers (UMT) and the Democratic Con-
Pderaton of Labor (CDT)
Canta ;
Official name: Kingdom of Ninceces
Type: constitutional monarchy (constitution °
adopted 1972)
Capital: Rabat
Political subdivisions: 36 provinces (does not
include. Western Sahara) and 2 prefectures *
(Rabat-Salé and Casablanca, which consists
of 5 divisions)
NOTE: Morocco acquired administrative
control in 1976 over the northern two-thirds
of the former Spanish Sahara under an
agreement with Mauritania, but the legal
question of sovereignty over the area has yet
to be determined. Spain’s role as coadminis-
trator of the disputed territory ended in
February 1976. Morocco moved to occuipy
and assert administrative control over the
former Mauritanian-claimmed (southern) sec-
tor of Western Sahara in August 1979,
thereby establishing a fourth additional | -
province in the Sahara:.: - °-
Legal system: based on Islamic.law and
French and Spanish civil law system; judi-
cial review of legislative acts in Constitu-
tional Chamber of Supreme:Court; modern
legal education at branchés of Mohamed V
University in Rabat and Casablanca and
Karaouine University in Fés
National holiday: independence: Day, -I8
November
Branches: constitution provides for Prime
Minister and ministers named by and re-
sponsible to King; King has paramount exeéc-
utive powers; unicameral legislature(Cham-
ber of Representatives), of which two-thirds
of the members are directly elected and one- ’
third are indirectly elected; judiciary inde-
pendent of other branches
Government leaders: HASSAN II, King
(since March 1961); Mohamed KARIM
LAMRANI, Prime Minister (since Novem-
ber 1983)
Suffrage: universal over age 20
Elections: provincial elections held 10 June
1983; elections for National Assembly held
14 September 1984
Political parties and leaders: Morocco has
14 political parties; the major ones are
Istiqlal Party, M’7Hamed Boucetta; Socialist
Union of Popular Forces (USFP),
Abderrahim Bouabid; Popular Movement —
(MP), Mahjoubi Aherdan; National Assem-
bly of Independents (RNI) formed in Octo-
ber 1978:is progovernment grouping of pre-.
viously unaffiliated‘deputies in parliament, :
Ahmed Osman;.National Democratic Party.
(PND), a splinter group from the RNI
formed July 1981, Mohamed Arsalane
E]-Jadidi; Party for Progress and Socialism
(PPS), legalized in August 1974, is front for
Moroccan Communist Party (PCM), which
was proscribed in 1959, Ali Yata; new
promonarchy party—the Constitutional
Union (UC), Maati Bouabid
Voting strength: progovernment parties
hold absolute majority in Chamber of Rep-
resentatives; with palace-oriented Popular . -
Movement deputies, the King controls over
two-thirds of the seats
Communists: 2,000 est.
Member of: Af{DB, Arab League, EC (associ-
ate), FAO, G-77, GATT, IAEA, IBRD, .
ICAO; IDA, IDB—Islamic Development
Bank, IFAD, IFC, ILO, International Lead
and Zinc Study Group, IMF; IMO,
INTELSAT, INTERPOL, IOOC, IPU, ITU,
NAM, OIC, UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO','41efbc4b40691ec7a4e31267f85f947d585fda5bd1bb62abb50dc868127e4bc7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ca8794ccadf17d9f499b1f92f71627507fd33046bad45bafea85c95769c5db7',1986,'NA','Namibia','people-and-society',349,'Population: 1,142,000 (July 1986), average
annual growth rate 3.1%
Nationality: noun—Namibian(s); adjec-
tive—Namibian
Ethnic divisions: 85.6% black, 7.5% white, -
6.9% mixed; approximately half the Afri-
cans belong to Ovambo tribe
Religion: whites predominantly Christian,
nonwhites either Christian or indigenous .
beliefs
Language: Afrikaans principal language of
about 60% of white population, German of
33%, and English of 7% (all official); several
indigenous languages
Literacy: 100% whites, 16% nonwhites
: CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: about 500,000 (1981); 60% agri-
culture, 19% industry and commerce, 8%
services, 7% government, 6% mining; 15-
17% unemployment
Organized labor: 6 trade unions, whose
membership is almost exclusively white and
mulatto','2179f537a3acac5faf404ed534ed0bf28d29e5868ee9fd81ac63b71e46eba45a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dade6588e59cc565ac6dc8dee813fbfd51a3a5af49fb03be69e279a2f3ce10f3',1986,'NR','Nauru','people-and-society',353,'Population: 8,000 (July 1986), average an-
nual growth rate 1.3%
Nationality: noun—Nauruan(s ); adjective—
Nauruan
Ethnic divisions: 58% Nauruan, 26% other
Pacific Islander, 8% Chinese, 8% European
Religion: Christian (two-thirds Protestant,
one-third Catholic)
Language: Nauruan, a distinct Pacific Island
language (official); English widely under-
stood and spoken
Literacy: 99% ©','ce3b5ded28f6febd8badf3e7f14dabcbadcb9276d34973676f12f6931cb8adb0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('911d8c646e5250cf497c2b5fcef1ef987bb3b31bffdecf73b9e114e155ee208d',1986,'NP','Nepal','people-and-society',357,'Population: 17,422,000 (July 1986), average
annual growth rate 2.5%
Nationality: noun—Nepalese (sing. and pl.);
adjective—Nepalese
Ethnic divisions: Newars, Indians, Tibetans,
Gurungs, Magars, Tamangs, Bhotias, Rais,
Limbus, Sherpas, as well as many smaller
groups
Religion: only official Hindu kingdom in
world, although no sharp distinction
between many Hindu (about 88%) and
Buddhist groups; small groups of Muslims
and Christians
Language: Nepali (official), 20 mutually
unintelligible languages divided into numer-
ous dialects
Infant mortality rate: 143/1,000 (1983)
Life expectancy: men 47, women 45
Literacy: 20%
Labor force: 4.1 million; 93% agriculture,
5% services, 2% industry; great lack of
skilled labor
Gaverninent
Official name: Kingdom of Nepal
Type: nominally a constitutional iionsteh ;
King Birendra exercises autocratic control
over multitiered panchayat system of gov- :
ernment oH mt a
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal con-
cepts and English common law; legal educa-
tion at Nepal Law College in Kathmandu;
has not accepted compulsory IC] jurisdic-
tion
National holiday: Birthday of the. King ‘and
National Day, 28 December
Branches: Council of Ministers appointed by.
the King; Rastriya Panchayat (National As-
sembly; 112 directly elected, 28 appointed
by King)
Government leaders: BIRENDRA Bir
Bikram Shah Dev, King (since 1973);
Nagendra Prasad RIJAL, Prime Minister
(since July 1984)
Suffrage: universal over age 21
Elections: village, town, and district councils
(panchayats) elected by universal suffrage; a_
constitutional amendment in 1980 provided
for direct elections to the National Pancha-
yat, which consists of 140 members (includ-
ing 28 appointed by the King), who serve
five-year terms; Nepal’s first general election
in 22 years was held in May-1981; general
elections are scheduled for 12 May 1986
Political parties and iene all political
parties outlawed but operate more or less
openly; Nepali Congress Party (NCP),
Ganesh Man Singh, K. P. Bhattarai, G. P.
Koirala
Communists: Communist Party of Nepal _
(CPN); factions include V. B. Manandhar,
175
Man Mohan Adhikari, Bharat Raj Joshi,-Rai .-
Majhi, Tulsi Lal, Krishna Raj Burma, Sahana
Pradhan
Other political or pressure groups: numer-
ous small, left-leaning student groups in the
capital; Indian merchants in Terai and capi-
tal
Member of: ADB, Colombo Plan, ESCAP, _
FAO, G-77, IBRD, ICAO, IDA, IFAD; IFC,
ILO, IMF, IMO, INTERPOL, -IPU, IRC,
ITU, NAM, SAARC, UN, UNESCO, VEU,
WHO, WMO, WTO —','14841745c2bdc6642bb5e647e5d94e8825166b8c0dfec9fa945dfc41b127d0d2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('537a8b3f949c82fa4f9815665f3efc2dc3b81b8c8c772d062cd0565133045013',1986,'NL','Netherlands','people-and-society',360,'Population: 14,536,000 (July 1986), average
annual growth rate 0.4%
Nationality: noun—Netherlander(s); adijec-
tive—Netherlands
Ethnic divisions: 99% Dutch, 1% Indonesian
and other
Religion: 40% Roman Catholic, 31% Protes- -
tant, 24% unaffiliated
Language: Dutch
Infant mortality rate: 8.4/1,000 (1983)
Life expectancy: 16 |
Literacy: 99%
Labor force: 5.9 million (1984); 57% services,
30% manufacturing and construction, 6%
'' 176
transportation and communications, 5% ag-
riculture; 12.5% unemployed, September
1985 ;
Organized labor: 33% of labor force
Population: 236,000 (July 1986), average ~~
annual growth rate 0.3% °
Nationality: a ie sits Antill-
ean(s); adjective—Netherlands Antillean
Ethnic divisions: 85% mixed African; re- -
mainder Carib Indian, Haropest, Latin, and
Oriental ©
Religion: predominantly Roman Catholic;
Protestant, Jewish, Adventist
Language: Dutch (official); Papiamento, a
Spanish-Portuguese-Dutch-English dialect
predominates; English widely spoken; Span-
ish
Literacy: 95%
Labor force: 89,000 (1983); 65% govern-
ment, 28% industry and commerce, 1.5%
agriculture; unemployment about 16% on .
Curacao and about 10% on Aruba (1984 est.)
Organized labor: 60-70% of labor force','cf977035a7d4b98b34f43aae116989d625bff066b209564f14872ea35e2334cf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c661e46f9450950b61e9c08c468187795cb2d1353e91accb26b8a4091485b94',1986,'NC','New Caledonia','people-and-society',364,'Population: 152 000 (July 1986), average .
annual growth rate 1:2%
Nationality: noun—New Caledonian(s);
adjective—New Caledonian
Ethnic divisions: Melanesian 42.5%, Euro-
pean 37.1%, Wallisian 8.4%, Polynesian
3.8%, Indonesian 3.6%, Vietnamese 1. 6%
Religion: over 60% Roman Catholic, 30%
Protestant
Language: French; Melanesian-Polynesian “
dialects
Labor force: 50,469 (1980 est.); Javanese and
Tonkinese laborers were imported for plan-
tations and mines in pre-World-War II. .
period; immigrant labor now coming from
Wallis and Futuna, Vanuatu, and French.
Polynesia; est. 8% unemployment
179
Pee to
Pa ae pau
oindimie | ». - :','85850b0b2b6f1e1dcc6fdcc7840156e3c165e4d721c9472b9371808d188b8d8a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ff283762d278bcefba601151154e55c10a093e3f2c3efeff793212e5c7c2a95',1986,'NZ','New Zealand','people-and-society',368,'Population: 3,305,000 (July 1986), average
annual growth rate 1.0%
Nationality: noun—New Zealander(s); ad-
jective—New Zealand
Ethnic divisions: 87% European, 9% Maori,
2% Pacific Islander, 2% other
Religion: 81% Christian, 18% none or un-
specified, 1% Hindu, Confucian; and other
Language: English (official), Maori
Infant mortality rate: 12.5/1,000 (1988) -
Life expectancy: men 70.5, women 77.0
Literacy: 98%
abai force: 1,371,000 (1984); 22% manu-
facturing; 22% public service; 16% whole-
sale and retail trade; 10% agriculture,
180
hunting, and fishing; 8% transportation and
communications; 7% finance; 5.7% regis-
tered unemployed (February 1984)
Organized labor: 588,000 members; 48% of
labor force (1981)','0df0df3da85da64418c7ff686c7100ada6f1ff50eba32399a7e6f213382f1149','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1130a1868cf3d75d0f218c28f0c2ac22c83bdb670c6c5567fb97552ae73a90f5',1986,'NI','Nicaragua','people-and-society',372,'Population: 3,342,000 (July 1986), average
annual growth rate 3.3%
Nationality: noun—Nicaraguan(s); adjec-
tive—Nicaraguan
Ethnic divisions: 69% mestizo, 17% white,
9% black, 5% Indian :
Religion:95% RomahCatholic
Language: Spanish (official); English- and
Indian-speaking minorities.on Atlantic coast
Infant mortality rate: 84/1,000 (1983)
Life expectancy: men 56, women 60
Literacy: 66%
Labor force: 1,047,000 (1985); 46% service,
41% agriculture, 13% industry; 22% unem-
-ployment
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 |
Nicaragua (continued)
Organized labor: 35% of Nicaragua’s labor
force is organized; of the seven confedera-
tions, five are Sandinista or Marxist
oriented—the government-sponsored Sandi-
nista Workers’ Central (CST), 115,000 mem-
bers, including state and municipal employ-
ees; the Association of Campesino Workers
(ATC), 130,000 members; the General Con-
federation of Independent Workers (CGI-D,
approximately 15,000 members; the Work-
ers Front, about 100 members; and the Cen-
tral for Labor Action and Unity (CAUS),
about 3,000 members; the other two unions
are the Nicaraguan Workers’ Central (CTN),
25,000 members, and the Confederation of
Labor Unification (CUS), 50,000 members','aecdf6378288ed446ffb367a85123d65f589b1db67f9dae173050015f3127b07','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10c2aadabac5530a54966b83568cfa4514901d634359e0eebfb74fc0a5eba67f',1986,'NE','Niger','people-and-society',376,'Population: 6,715,000 (July 1986), average °
annual growth rate 3.4%
Nationality: noun—Nigerien(s) adjective— .
Nigerien |
Ethnic divisions: 56% Hausa; 22% Djerma; :
8.5% Fula; 8% Tuareg; 4.3% Beri Beri
(Kanouri); 1.2% Arab; Toubou, and
Gourmantche; about 4,000 French expatri-
ates 3
Religion: 80% Muslim, remainder indige- ~~. :-
nous beliefs and Christians
Lanwiade: French (official), Hausa, Dierma :
Infant mortality rate: 186/1,000 (1984)
Life expectancy: 45 . |
Literacy: 10% |
Labor force: 2.5 million (1982) siee eras
90% agriculture, 6% industry and: ..- ae
commerce, 4% government
Organized labor: negligible...
Déclaseified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Niger (continued)','fd4897d40ffb75e0f8c4f8b8fc5a0620199ce735d701b89e1a2bfedf14b7268f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4bc64d7a73e63b73fa40617c25dba24ae3534ead37be725504ebb5b3cc78776',1986,'NU','Niue','people-and-society',379,'Population: 2,672 (July 1986), average an-
nual growth rate — 4.4%
Nationality: noun—Niuean(s); adjective—
Niuean
Ethnic divisions: Polynesian, with some 200
Europeans, Samoans, and Tongans
Religion: 75% Ekalesia Nieue (Niuean
Church)—a Christian Protestant church
closely related to the London Missionary
Society, 10% Morman, 5% Roman Catholic,
Jehovah’s Witnesses, Seventh-day Adventist
Language: Polynesian tongue closely related
to Tongan and Samoan; English
Literacy: education compulsory between 5
and 14 years of age
Labor force: approx. 1,000 (1981); most
Niueans work on family plantations; paid
work exists only in government service,
small industry, and the Niue Development
Board
186','dac81cf2d51f192826838e945bc8388297d32a58e13bf65d8cf79b8b2d0d0423','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c0faa00ed70088909289d67ec76f0c29475babd9eb7f79621ddfd483ae4543d',1986,'NF','Norfolk Island','people-and-society',383,'Population: 2,473 (July 1986), average an-
nual growth rate 2.6% :
Nationality: noun—Norfolk Islander(s); ad- -
jective—Norfolk Islander
Ethnic divisions: descendants of the |
“Bounty” mutiny families; more recently,
Australian and New Zealand settlers
Religion: Church of England, Roman Cath-:
olic Church, Uniting Church in putas
and Seventh-day Adventists -
Language: ‘English (official); “Norfolk” —a
mixture of 18th Century Belen and an-
cient Tahitian
Literacy: probably high -','36efd36ce21e9a61a39345d4ac2e4b5cac9df2eee2ef3d66bfca413a28a3b458','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87ee2cde5f08d0b3a8a02c41e349b26cdc82b2f9855d3fbd206ef0d84758f649',1986,'NO','Norway','people-and-society',386,'Population: 4,165,000 (July 1986), average
annual growth rate 0.3%
Nationality: noun—Norwegian(s); adjec-
tive—Norwegian é
Ethnic divisions: Germanic (Nordic, Alpine,
Baltic) and racial-cultural minority of
20,000 Lapps
Religion: 94% Evangelical Lutheran (state
church), 4% other Protestant and Roman
Catholic, 2% other
Language: Norwegian (official); small
Lapp- and Finnish-speaking minorities
Infant mortality rate: 7.9/1,000 (1983)
188
Life expectancy: men 72.7, women 79.5
Literacy: 100%
Labor force: 2.031 million (1984); 30.9%
services; 19.6% mining and manufacturing;
16.7% commerce; 8.8% transportation; 7.6%
construction; 7.2% agriculture, forestry,
fishing; 5.7% banking and financial services
(1983); 3.9% unemployed (1984)
Organized labor: 66% of labor force (1985)','6cd1d20ec993b9dce91c8bd40a57d0d85fef1e312f9725f2c4a8b41fe2e89b99','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10e8573c7f2b6aaa9a18b3b3c41a623c83aa4b45113f17f2d5d784d1e0f79dbf',1986,'OM','Oman','people-and-society',390,'Population: 1, 271 000 (July. 1986), average .
annual growth rate3.4% , |
Nationality: nei Omni: adjective—
Omani
Ethnic divisions: almost entirely. Arab, with
small Baluchi; Zanzibari; and Indian groups
Religion: 75% Ibadhi Muslim; remainder
Sunni Muslim, Shi‘a Muslim, some Hindu
Language: Arabic (official); English, 7 : 7
Baluchi, Urdu, Indian dialects
Infant mortality rate: 121/1,000 (1983)
Life expectancy: men 51, women 54
Literacy: 20%
Labor force: 500,000; 50% are non-Omani;
est. 60% agriculture
Population: 101,855,000, exéluding
Junagadh, Manavadar, Gilgit, Baltistan, and *:
the disputed area of Jammu and Kashmir «~
(July 1986); average annual growth rate 2.6%
Nationality: noun—Pakistani(s); adjective—
Pakistani me
Ethnic divisions: Punjabi, Sindhi, Pushtan
(Pathan), Baluchi aa
Religion: 97% Muslim, 3% Christian, Hind,
and other
Language: Urdu and English (official); total
spoken languages—64% Punjabi, 12% Sif". --
ndhi, 8% Pushtu, 7% Urdu, 9% Baluchi and’ :
other; English is lingua franca
191
Infant mortality rate: 119/1,000(1983)
Life bepecianey wien 51, women 49
Literacy: 24%
Labor force: 25.24 million (1982 est.); exten-
sive export of labor; 52% agriculture, 21%
industry, 8% services, 19% other
Organized labor: negligible
Goverment
Official name: Islamic Republic of Pakistan
Type: parliamentary with arene executive, °
federal republic; military seized power 5
July 1977; President Mohammed Zia-ul-
Hag lifted martial law and restored 1973
Constitution on 30 December 1985 but re-
tained his position-as-Armiy Chief of Staff;
parliament, elected in February 1985, serves
5-year term
Capital: Islamabad
Political subdivisions: four provinces
(Baluchistan, North-West Frontier; Punjab,
Sind), 1 territory.(Federally pooner’
Tribal Areas)
Legal system: based on English common
law but gradually being transformed to cor- *
respond to Koranic injunction; accepts com-
pulsory IC] jurisdiction, with reservations;
President Zia’s government has-established
Islamic Sharia courts paralleling the secular -
courts and has introduced Koranic punish-
ments for criminal offenses; martial law
courts abolished 30 December 1985;-and all
cases, including those concerning national
security; now require due process
off
EE ae
_ National holiday: Pakistan Day, 23 March
Government leader: Gen: Mohammed ZIA-
UL-HAO, President and Army Chief of
Staff (since July 1977); confirmed as Presi-
dent through March 1990 in special referen-
dum in December 1984; Prime Minister
Mohammed Khan JUNEJO nee March
1985)
Suffrage: universal from age 18
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Pakistan (continued)
Elections: opposition agitation against rig-
ging elections in March 1977 led to military
coup; military promised to hold new na-
tional and provincial assembly elections in
October 1977 but postponed them indefi-
nitely; elections for municipal bodies were
held in 1979 and 1983; nonparty national
elections were held in February 1985; many
outlawed political parties boycotted polling
Political parties and leaders: relegalized in
December 1985 under legislation requiring
parties to register and open books for inspec-
tion; government still has wide authority
under civil code to restrict political activity; ..
law requires disqualification of any parlia-
mentary delegate who changes party affili-
ation; majority party in parliament''is Paki-
stan Muslim League (PML), Mohammed
Khan Junejo; principle opposition party is
secular socialist; Pakistan People’s Party
(PPP), Benazir Bhutto (maior leader); others
include Tehrik-i-Istiqlal, Asghar Khan; Na-
tional Democratic Party (NDP), Sherbaz
Mazari (formed in 1975 by members of out-
lawed National Awami Party—NAP—of
Abdul Wali Khan, who is de facto NDP
leader); all the aforementioned are in the
Movement for Restoration of Democracy
(MRD), formed in February 1981; Pakistan
National Party (PNP), Ghaus Bakhsh Bizenjo
(Baluch elements of the former NAP);
Jamiat-ul-Ulema-i-Islam (JUI), Fazlur Rah-
man
Communists: party membership very small:
sympathizers estimated at several thousand;
party is outlawed
Other political or pressure groups: military -
remains dominant political force; Ulema
(clergy), industrialists, and small merchants ;
also influential
NMéeibee of: ADB, Colombo Plan, ESCAP,
FAO, G-77, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IDB—Islamic Development
Bank, IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ITU,
[WC—International Wheat Council, NAM,
OIC, Economic Cooperation Organization,
SAARC, UN, UNESCO, UPU, WHO,
WFTU, WIPO, WMO, WSG, WTO
Eeanomy:
GNP: figures reflect impact ‘eal rupee devalu-
ation in 1982; $31 billion (FY85 est.); $300
per capita (F Y85); real growth 8.4% (FY85)
Natural resources: land, extensive natural
gas, limited petroleum, poor quality coal,
iron ore.
Agriculture: extensive irrigation; main
crops—wheat, rice, sugarcane, cotton; an
illegal producer of opium poppy and canna-
bis for the international drug trade
Fishing: catch 343,400 metric tons (1983)
Major industries: cotton textiles, steel, food
processing, tobacco, engineering, chemicals,
natural gas
Electric power: 5,187,000 kW capacity
(1985); 20.42 billion kWh produced (1985),
206 kWh per capita
Exports: $2.5 billion (f.0.b., FY85); primarily
rice, cotton, and textiles
Imports: $5.9 billion (f.0.b., FY85); petro-
leum (crude and products), cooking oil, and
defense equipment
Major trade partners: FY85 exports—J apan
12%, US 10%, Saudi Arabia 7%, UK 7%, Iran
2%; imports—Japan 13%, US 12%, Saudi
Arabia 11%, UK 6%, Malaysia 6%, China
3%, Iran 1%
Budget: FY85—current expenditures, $4.9
billion; development expenditures, $1.3 bil-
lion (reflects impact of rupee devaluation)
Monetary conversion rate: 15.89
rupees= US$1 (FY85 average); in January
1982, the rupee was delinked from the US
dollar and floated
Fiscal year: 1J uly-30 June
Population: 2,227,000 uly 1986), average
annual growth rate 2.1%
Nationality: noun—Panamanian(s); adijec-
tive—Panamanian
Ethnic divisions: 70% mestizo, 14% West
Indian, 10% white, 6% Indian
Religion: over 93% Roman Catholic, 6%
Protestant
Language: Spanish (official); 14% speak En-
glish as native tongue; many Fangmanlats
bilingual :
Infant mortality rate: 20.1 /1,000 (1984)
Life expectancy: at
Literacy: 90%
Labor force: est. 680,471 (1984); 45% com--
merce; finance, and services; 29% agricul-:
ture, hunting, and fishing; 10% manufactur-
ing and mining; 5% construction; 5% trans-
portation and communications; 4% Canal
Zone; 1.2% utilities; 2% other; unemployed -
estimated at 20% (January 1985); shortage of
skilled labor but an oversupply of unskilled
labor
Organized labor: approximately 15% of la-
bor force (1982)','b335aefc3b9f25886d6350d78e5989d5bfa022aebc345af5eea17c869450b601','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b54c868ad234fc232026285fbe3734c12bd8660890b1fb3016086382399cd863',1986,'PG','Papua New Guinea','people-and-society',394,'Population: 3,395,000 (July 1986), average
annual growth rate 2. 1%
Nationality: edi Pipua New Guinean(s);
adjective—Papua New Guinean
Ethnic divisions: predominantly Melanesian
and Papuan; some Negrito, Micronesian,
and Polynesian eal
Religion: over half of population nominally
Christian (490,000 Catholic, 320,000 Luth-
eran, other Protestant sects); remainder in-
digenous beliefs
Language: 715 indigénous languages; pidgin
English i in much of the country and Motu in
Papua region are lingua franca; English
spoken by 1:2% of population
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Infant mortality rate: 102/1,000(1985)-
Life expectancy: 50.
Literacy: 82%
Labor force: 1.66 million (1980); 732,806
(1980) in salaried employment; 54% agricul-
ture, 25% government, 9% industry and
commerce, 8% services _
Government 7
Official name: Papua New Guinea
Type: independent parliamentary state
within Commonwealth recognizing Eliza- .
beth II as head of state
Capital: Port Moresby
Political subdivisions: 20 provinces
Legal system: based on English common .
law
National holiday: Independence ee 16.
September ;
Branches: executive—National Executive
Council; legislature—House of Assembly .
(109 members); judiciary—court system
consists of Supreme Court of Papua New
Guinea and various inferior courts (district
courts, local courts, children’s courts,
wardens’ courts)
Government leaders: Sir Kingsford
DIBELA, Governor General (since March
1983); Paias WINGTI, Prime Minister (since
November 1985)
Suffrage: universal adult
Elections: preferential-type elections for
109-member House of Assembly every five
years, last held in June 1982
Political parties: Pangu Party, People’s.
Progress Party, United Party, Papua Besena,
National Party, Melanesian Alliance
Communists: no significant strength .
Membér of: ADB, ANRPC, CIPEC (associ-
ate), Commonwealth, ESCAP, FAO, G-77, °
GATT (de facto), IBRD, ICAO, IDA, IFAD,
IFC, [LO, IMF, IMO, INTELSAT,
INTERPOL, ITU, South Pacific Commis-
sion, SPF, UN, UNESCO, UPU, WHO,
WMO','0a472b88b4feef2848357bd72e2d8d5138f55e9edd39d63b568ed4af840e1442','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc252564943eb92369fa2f902d1d1916a5a6c552a01c385efa80e95e9f7e3835',1986,'PY','Paraguay','people-and-society',397,'Population: 4,119,000 (July 1986), average
annual growth rate 3.2%
Nationality: noun—Paraguayan(s); adjec-
tive—Paraguayan
Ethnic divisions: 95% mestizo (Spanish and
Indian), 5% white and Indian
Religion: 97% Roman Catholic; Mennonite
and other Protestant denominations
Language: Spanish (official) and Guarani
Infant mortality rate: 64/1,000 (1981)
Life expectancy: 68
Literacy: 81%
Labor force: ].1 million (1983 est.); 44% agri-
culture; 34% industry and commerce, 18%
services, 4% government; unemployment
rate 15% (1984)
Organized labor: about 5% of labor force','c45b71fd03f0884644518b99ba6a343ce0d4dd0ad685ddaf903ada70d627964f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7b9b2ac23072eb7ee7e1a0840ef49cc0b655d2fa1eaa6808c1d99f91800b624',1986,'PE','Peru','people-and-society',401,'Population: 20,207,000 (July 1986), average
annual growth rate 2.6%
Nationality: noun—Peruvian(s); adjective—
Peruvian
Ethnic divisions: 45% Indian; 37% mestizo
(white-Indian); 15% white; 3% black, Japa-
nese, Chinese, and other . :
Religion: predominantly Roman Catholic .
Language: Spanish and Quechua (official),
Aymara
Infant mortality rate: 80/1,000 (1985)
Life expectancy: 56.5
Literacy: est. 80%
197
Labor force: 4.9 million (1981); 40% govern-
ment and other services, 41% agriculture,
19% industry (1981); unemployment about
10.9% (1984); underemployment 54.2%
Organized labor: about 40% of salaried
workers (1983 est.)','2de5b67bbda135cac509b5e099a8a71fad9c4881219e5014a668fcec1655188a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33eb4c99396d995406e75bb818754472210b60e4cf420cf03ab102c8264c037f',1986,'PH','Philippines','people-and-society',405,'Population: 58,091,000 ‘C uly 1986), average
annual growth rate 2.2%
Nationality: noun—Filipino(s); adjective—
Philippine :
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 9% Protes-
tant, 5% Muslim, 3% Buddhist and other
Language: Pilipino (based on Tagalog) and
English (both official)
Infant mortality rate: 59/1,000 (1982)
Life expectancy: 64
Literacy: about 88% _
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
''
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: 20.0.61 million (1985 prelim),
47.0% agriculture, 20% industry and com-
merce, 13.5% services, 10.0% government,
9.5% other; 6.2% unemployment rate (1984
prelim.)','6bd2c8c463a43399a31ea0f1b3a9138540c72fe549ff1bf6b5cbeadbe310bdc8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bde45a7dda6533f2ddd8616e7e376a9f4e675aca94066692ab9c0dc6f2a7dd1f',1986,'PN','Pitcairn','people-and-society',408,'Population: 62 (July 1986), average annual
growth rate 5.0% :
Nationality: noun—Pitcairn Islander(s);
adiective=-eitcalm pends
Ethnic. divisions descendants of" ‘Bouaty”
mutineers | : is :
Religion: 100% Seventh Day Adventist
Language: “English (oficial also a Falutieny :
English dialect —
Literacy: Biabanly high
Labor force: no business community in the
usual sensé; sorne public: works; subsistence’
farming anid fishing
Government meet
Official name: Pitcairn, Henderson, Ducie,
and Oeno Islands
Type: British dependent territory
Capital: Adamstown—main settlement
Legal system: Island Court; provisions fora
Supreme Court
Branches: administered locally by Island |
Council consisting of four elected island of-
ficers, a secretary, and five nominated mem-
bers
Government leader: Terence D. O''LEARY,
Governor and UK High Commissioner to
New Zealand (since 1982); B. YOUNG, Is-
land Magistrate and Chairman of the Island
Council (since 1985) ..
Suffrage: 18 years old.and 3 years residency
Elections: annual; Island Magistrate elected
for a 3-year term
Communists: none .','00f98f1d8f41f7d7d853e576003980ab7c154f95ea700d90c68db86b181d6a52','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a444984ccedfd3eecc73e7342d9e57d919c84c2478a16005d7d0df536fa9822d',1986,'PL','Poland','people-and-society',412,'Population: 37,546,000 (July 1986), average
annual growth rate 0.8%
Nationality: noun—Pole(s); adjective—Pol-
ish
Ethnic divisions: 98.7% Polish, 0.6% Ukrai-
nian, 0.5% Byelorussian, less than 0.05%
Jewish, 0.2% other
Religion: 95% Roman Catholic (about 15%
practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Infant mortality rate: 19.3/1,000 (1984)
Life expectancy: 71.6
~ Literacy: 98%
Labor force: 17.54 million; 44% industry
and commerce, 30% agriculture, 11% ser-
vices, 8% government (1985)
Organized labor: new government trade
unions formed following dissolution of Soli-
darity and-all government unions in October
1982','e635f4f84b4bda43f4b5bc8a267f6a7ad81fe2c4089a7c503d3b5ccadcd788de','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89e1bf269e4cb9a1c37e735959f61b5a04b2db268524bbbc9d52b56bfc8f603c',1986,'PT','Portugal','people-and-society',416,'Population: 10,095,000 uly 1986), includ-
ing the Azores and Madeira Islands; average
annual growth rate 0. 5%
Nationality: aoune Portuese (sing. and
pl.); adjective—Portuguese
Ethnic divisions: homogeneous Mediterra-
nean stock in mainland, Azores, Madeira
Islands; citizens of black African descent
who immigrated to mainland during de-
colonization number less than 100,000
Religion: 97% Roman Catholic, 1% Protes-
tant sects, 2% other
Language: Portuguese
Infant mortality rate: 19.8/1,000 (1982)
_ 202
Life expectancy: 71
Literacy: 80%
Labor force: 4.5 million (1984); 37% services,
36% industry, 27% agriculture; unemploy-
ment, 10.6% (December 1984)
Organized labor: about 45% of Portuguese
labor is organized; the Communist-
dominated General Confederation of Portu-
guese Workers—Intersindical (CGTP-IN)
represents about half of the unionized labor
force; its main competition, the General
Workers Union (UGT), is organized by the
Socialists and Social Democrats and repre-
sents a little less than half of unionized labor','a752d8bbe60ca45fdf04a7289a22932626b88101fdb8cf1ebc4e3db3ac264aef','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('161b2af1b566087471a7e24b762d72247bba36c2f0dffec78e86be1fcb8cc1cb',1986,'QA','Qatar','people-and-society',419,'Population: 305,000 g uly 1986), average _
annual growth rate 4.2%
Nationality: noun—Qatari(s); adjective—
Qatari
Ethnic divisions: 40% Arab, 18% Pakistani,
18% Indian, 10% Iranian
Religion: 95% Muslim
Language: Arabic (official); English is com-
monly used as second language
Life expectancy: 72
Literacy: 40%
Labor force: 104,000 (1983); 85% non-Qatari
in private sector :
Population: 539,000 (July 1986), average
annual growth rate 1.0%
Nationality: noun—Reunionese (sing. and
pl.); adjective—Reunionese
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French,
African, Malagasy, Chinese, Pakistani, and
Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely
used
Literacy: over 80% among younger genera-
tion
Labor force: primarily agricultural workers;
high seasonal unemployment','b77b4df1a2d27bd3526caa206e30d7a63abc5c849e89c4deb61616c82f79dfa1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31acd564decc5c075a4279395f658ab7d41251a79b23a84262b4651f457b0f9f',1986,'RO','Romania','people-and-society',423,'Population: 22,830,000 (July 1986), average
annual growth rate 0.4%
Nationality: noun—Romanian(s); adjec- *
tive—Romanian oe
Ethnic divisions: 88.1% Romanian; 7.9%
Hungarian; 1.6% German; 2.4% Ukrainian, ,
Serb, Croat, Russian, Turk, and Gypsy
Religion: 80% Romanian Orthodox; 6% Ro-
man Catholic; 4% Calvinist, Lutheran, Jew-
ish, Baptist :
Language: Romanian, Hungarian, German
Infant mortality rate: 23.9/1,000 (1983) _
Life expectancy: men 69.3, women 71.8
Literacy: 98%
206
Laborx force: 10.5 million (1983); 37.8% in-
dustry, 29.2% agriculture, 38.0% other non-
agncultural (1983)','7d79831dcb1616c96526d8f7900b156ba84142f7bc3965a594ea2b785082c2b3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb73eb1beefda30265060a2fa84138e9d066c302af60dd4c0709668b6cf9ae6a',1986,'RW','Rwanda','people-and-society',427,'Population: 6,489,000 (July 1986), average
annual growth rate 3.8%
Nationality: noun—Rwandan(s);
adjective—Rwandan
Ethnic divisions: 85% Hutu, 14% Tutsi, 1%
Twa (Pygmoid)
Religion: 65% Catholic, 9% Protestant, 1%
Muslim, rest indigenous beliefs
Language: Kinyarwanda, French (official),
Kiswahili used in commercial centers
Infant mortality rate: 102/1,000 (1985)
Life expectancy: 48
Literacy: 837%
Labor force: 3.6 million (1985); 92% agricul-
ture, 2% industry and commerce, 7% gov-
ernment and services','a1cca109f80cb436cda7bbc5bf376da87f727806ae7aa34f0c9f5c764f8cb0dc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21d5af94189ce2b2d1e74695158d1b463bf1990370491b58bcb09584552aebf9',1986,'SM','San Marino','people-and-society',431,'Population: 23,000 (July 1986), average an-
nual growth rate 0.9%
Nationality: noun—Sanmarinese (sing. and
pl.); adjective—Sanmarinese
Religion: Roman Catholic _
Language: Italian
Infant mortality rate: 9.6/1,000 (1983)
Literacy: 97%
Labor force: approx. 4,300 _
Organized labor: Democratic Federation of
Sanmarinese Workers (affiliated with
ICFTU) has about 1,800 members;
Communist-dominated General Federation
of Labor, 1,400 members','f00812257d7199e867b8c88ff01e3b46b3e498630e2619b016343daa759a431d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ee404bb46dbca2ae41e9062271ee54ea0e9ed4541a4ba01de104c7811018f4e',1986,'SA','Saudi Arabia','people-and-society',434,'Population: 11,519,000 (July 1986), average:
annual growth rate 3.2%
Nationality: noun—Saudi(s); adjective—. »
Saudi or Saudi Arabian
Ethnic divisions: 90% Arab, 10% AfroeAsiain
Religion: 100% Muslim
Language: Arabic
Infant mortality rate: 118/1,000 (1983)
Life expectancy: 54
Literacy: 52%
Labor force: about one-third (one-half for-
eign) of population; 45% commerce, ser-
vices, government, and other; 30% agricul-
ture; 15% construction; 5% industry; 5% oil
and mining
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Saudi Arabia (continued)','271aa59b095865581c8d6d375be99268332224b543d75a0a490846d8ff62d92f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fb11a43264f5bca3035989f9e48043c8c24080dc5e2cad81c975004bf7104a6',1986,'SN','Senegal','people-and-society',437,'Population: 6,980,000 (July 1986), average
annual growth rate 3.3%
Nationality: noun—Senegalese (sing. and
pl.); adjective—Senegalese
Ethnic divisions: 36% Wolof, 17% Fulani,
17% Serer, 9% Toucouleur, 9% Diola, 9%
Mandingo, 1% European and Lebanese
Religion: 92% Muslim, 6% indigenous be-
liefs, 2% Christian (mostly Roman Catholic)
Language: French (official); Wolof, Pulaar,
Diola, Mandingo
Infant mortality: 140/1,000 (1983)
Life expectancy: 45.5
Literacy: 10%
Labor force: 2,509,000; 77% subsistence ag-
ricultural workers; 175,000-wage earners—
40% private sector, 60% government and
parapublic
Organized labor: majority of wage-labor
force represented by unions; however, dues-
paying membership very limited; major
confederation is National Confederation of
Senegalese Labor (CNTS), an affiliate of gov-
erning party
Government Gy tet
Official name: Republic of Senegal
Type: republic under multiparty demo-
cratic rule; (early in 1982, Senegal and The
Gambia formed a loose confederation
named Senegambia, which calls for the
eventual integration of their armed forces
Capital: Dakar
Political subdivisions: 8 regions, subdivided
into 28 departments, 95 arrondissements .
Legal system: based on French civil law °
system; constitution adopted 1960, revised
1963, 1970, and 1981; judicial review of leg-
islative acts in Supreme Court, which also
audits the government’s accounting office; —
legal education at University of Dakar; has
not accepted compulsory ICJ jurisdiction
National I: Independence Day, 4
April -
Branches: government dominated by the
President; unicameral legislature (120-
member National Assembly), elected for five
years; President elected for five-yéar term
by universal suffrage; judiciary headed by
Supreme Court, with members appointed
by President
Government-leaders: Abdou DIOUF, Presi-
dent (since January 1981)-
Suffrage: universal adult
Elections: presidential and legislative elec-
tions held February-1983; Socialist Party
holds 1 of 120 seats
217
Political parties and leaders: Socialist Party;
(PS), Abdou Diouf; Senegalese Democrati¢
Party (PDS), Abdoulaye Wade; 13 other
small uninfluential parties
Communists: small number of Communists
and sympathizers
Other political or pressure groups: students,
teachers, labor, Muslim Brotherhood
Member of: A{DB, APC, CEAO, EAMA,
ECA, ECOWAS, EIB (associate), FAO, -
G-77, GATT, IAEA, IBRD, ICAO, IDA, -
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ITU, NAM, OAU, OCAM,
OIC, OMVS (Organization for the Develop: :
ment of the Senegal River Valley), UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WTO','d8ead8014009745088f0961433d698805af9f8a3b5642ea020838bdc37158517','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fe998cb41ba4a63e1a43152c72bdf9f250f99d1488047d0fc8e25a3acd3c14',1986,'SC','Seychelles','people-and-society',440,'Population: 67,000 (July 1986), average an-
nual growth rate 1.2%
Nationality: noun—Seychellois (sing. and
pl.); adjective—Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religion: 90% Roman Catholic, 8% Angli-
can, 2% other
Language: English and French (official);
Creole
Infant mortality rate: 26/1,000 (1983)
Life expectancy: 66
218
Literacy: 60%
Labor force: 1984 (prelim.) formal employ-
ment (all sectors)—38.4 government, 30.7%
parastatal, 30.8% private; formal employ- —
ment (by sector)—49.0% industry and com: .
merce, 39.0% services, 11.5% agriculture...
forestry, and fishing
Organized labor: 3 major trade unions.','6f9f15932c8441c08092914c22a5e80548ed367548a59e9caa025dbf425a59d3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d613163771a82b84408e3e1a6f8aef1521cab6d9326dc48a638c772da47af757',1986,'SL','Sierra Leone','people-and-society',444,'Population: 3,987,000 tjaly 1986), average”
annual growth rate 2.6%
Nationality: noun—Sierra Leonean(s); ad- 5
jective—Sierra Leonean *
Ethnic iieonk: over 99% native African
(30% Temne; 30% Mende; 2% Creole), rest
European and Asian; 13 ibe.
Religion: 30% Muslim, 30% indigenous be-
liefs, 10% ‘Christian, 30% other or none ©
Language: English (official); regular use lim=
ited to literate minority; principal vernacu-
lars are Mende in south and Temne in north;
“Krio,” the language of the resettled exslave
population of the Freetown area, is lingua
franca
Life expectancy: 46 .
Literacy: about 15%
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Sierra Leone (continued) _
Labor force: about 1.5 million; most of pop-
ulation engages in subsistence agriculture;
only small minority, some 65,000, earn
wages
Organized labor: 85% of wage earners','626f87e674331eb18a3e21edcacea04ebee314d207f16d43bb0565a47126570d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31c20a5d54faebc354e52fb9d8d958e6180884d2d8b7ba3762f9aea5c2f76eae',1986,'SG','Singapore','people-and-society',447,'Population: 2,584,000 (July 1986), average
annual growth rate 1.1%
Nationality: noun—Singaporean(s), adjec-
tive—Singapore
Ethnic divisions: 76.4% Chinese, 14.9%
Malay, 6.4% Indian, 2.3% other
Religion: majority of Chinese are Buddhists
or atheists; Malays nearly all Muslim; minor-
ities include Christians, Hindus, Sikhs,
Taoists, Confucianists —
Language: Chinese, Malay, Tamil, and
English (official); Malay (national)
Infant mortality rate: 9.4/1,000 (1983)
Life expectancy: men 69, women 74
Literacy: 84.2%
Labor force: 1,174,827 (June 1984); 29.2%
services, 27.4% manufacturing, 22.6% trade,
10:4% transport and communication, 8.5%
construction, 0.8% agriculture and fishing;
2.7% unemployment (June 1984)
Organized labor; 18.6% of labor force','ebeefacc21ee7f906d227cee15cc9fcb094386e7480826ddd1f7c6296b9f2fd6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa16f12b8382ca087fd8eb1385b85d679451e5751b2c74adce217f3b8d71035e',1986,'SB','Solomon Islands','people-and-society',451,'Population: 283,000 July 1986), average
annual growth rate 3.5%
Nationality: noun—Solomon Islander(s);
adjective—Solomon Islander
Ethnic divisions: 93.0% Melanesian, 4.0%
Polynesian, 1.5% Micronesian, 0.8% Euro-
pean, 0.3% Chinese, 0.4% other
Religion: almost all at least nominally Chris-
tian; Roman Catholic, Anglican, and Meth-.
odist churches dominant
Language: English (official), local languages
Infant mortality rate: 46/1,000 (1980) .
222
Life expectancy: 54
Literacy: 60%
Labor force: 20,631 Seauonnically active -
(1980); 30.0% forestry and fishing 28.2% so-
cial services, 10.8% manufacturing, 9.6%
commerce, 7.7% construction, 7.1% trans-
portation and communications','7fe590c1e667190d49e4313eae1a465314a08aa2d32ab015b92f6800bfbf965a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94509fbd9b1ec75a612b68b967607473e5dda7407708abc622a47aeefdf91c51',1986,'SO','Somalia','people-and-society',455,'Population: 7,825,000 (July 1986), average
annual growth rate 3.0%
Nationality: noun—Somali(s); adiective—
Somali ce
Ethnic divisions: 85% Somali, rest mainly
Bantu; 30,000 Arabs, 3,000 Europeans, 800 ,
Asians
Religion: almost entirely Sunni Muslim
Language: Somali (official), Arabic, Italian,’
English
Infant mortality rate: 150/1,000 (1984)
Life expectancy: 43.9
Literacy: 60%
223
Labor force: about 2.2 million; very few are
skilled laborers; 70% pastoral nomad, 30%
agriculturists, government employees, trad-
ers, fishermen, handicraftsmen, other
Organized labor: General Federation of
Somali Trade Unions, a’
government-controlled organization, estab-
lished in 1977','42f0f6441368b865f9da9d66c4b4150e075406cf3b942cd1419485efc6d4ea78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4a6d7b01106625f89440ad94c5967fadfbc090b6c98e2c71b57369c25925efb',1986,'ZA','South Africa','people-and-society',459,'Population: 33,241,000 (July 1986), includ-..
ing Bophuthatswana, Ciskei, Kwazulu,
Lebowa, Transkei, and Venda; average an- -
nual growth rate 2.4%; Bophuthatswana
1,688,000 (July 1986), average annual
growth rate 3.9%; Ciskei 781,000 (July 1986),
average annual growth-rate 2.3%; Kwazulu .
4,554,000 (July 1986),average annual -
growth rate 4.6%; Lebowa 2,310,000 (July ©
1986), average annual growth rate 4.5%;
Transkei 3,063,000 (July 1986), average an-
nual growth rate 3.4%; Venda 423,000 (July
3986), average annual. growth rate 2.7%
Nationality: nidutk=“South APioant ); adjec-.
tive—South African . ie
Ethnic divisions: 69.9% African, 17.8%
white, 9.4% colored, 2.9% Indian
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Religion: most whites and coloreds and
roughly 60% of Africans are Christian; .
roughly 60% of Indians are Hindu, 20%
Muslim
Language: Afrikaans, ‘English (official): Afri-
cans have many vernacular languages, in-
cluding Zulu, Xhosa, North and South Sotho,
Tswana
Infant mortality rate: whites 14.9/1,000
(1982), coloreds 80.6/1,000 (1982), blacks
80.6/1,000 (1982), Asians 25.3/1,000 (1982),
Africans unknown
Life expectancy: whites 70, coloreds 59,
blacks 59, Asians 66, Africans 55
Literacy: almost all white population liter-
ate; government estimates 50% of Africans
literate
Labor force: 11 million economically active
(1985); 34% services, 30% agriculture, 29%
industry and commerce, 7% mining
Organized labor: about 7% of total labor
force is unionized (mostly white workers);
African unions represent less than 15% of
black labor force
Population: 279,904,000 (July 1986), aver-
age annual growth rate 0.9%
Nationality: noun—Soviet(s); adjective—
Soviet ;
Ethnic divisions: 52% Russian, 16% Ukrai-
nian, 32% among over-100 other ethnic
groups, according to 1979 census
Religion: 18% Russian Orthodox; 9% Mus-
lim; 3% Jewish, Protestant, Georgian Ortho-
dox, or Roman Catholic; bobulahion! is 70%
atheist
226
Language: Russian (official); more than 200
languages and dialects (at least 18 with more
than ] million speakers); 75% Slavic group,
8% other Indo-European, 12% Altaic, 3%
Uralian, 2% Caucasian
Infant mortality rate: 27.9/1,000 (1982)
Life epectancy: men 64, women 74
Literacy: 99%
Labor force: civilian 148 million (midyear
1984), 20% agriculture, 80% industry and
other nonagricultural fields; unemployed’
not reported; shortage of skilled labor re--
ported','f860784aace120d61f83c08798300bd11929fb241becdf43d05f2a53eea5f6b5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('742f307d7de8510b922f13fab9d0971d2795aeea3a2ae884949ffd1cb27f385a',1986,'ES','Spain','people-and-society',463,'Population: 39,075,000 (July 1986), includ-
ing the Balearic and Canary Islands and
Ceuta and Melilla (two towns on the Moroc-
can coast); average annual growth rate 0.6%
Nationality: noun—Spaniard(s); adjective—
Spanish
Ethnic divisions: composite of Mediterra-.
nean and.Nordic types
Religion: 99% Roman Catholic, 1% other
sects
Language: Castilian Spanish; second lan-
guages include 17% Catalan, 7% Galician,
and 2% Basque
Infant mortality rate: 10.3/1,000 (1982).
Life expectancy: men 73, women ‘78
Literacy: 97%
Labor force: 13.3 million (1985); 44.3% ser-
vices, 22.9% industry, 15.3% agriculture,
8.6% construction, 8.8% other; unemploy-
ment now estimated at nearly 21.9% of labor
force (June 1985)
Organized labor: \\abor unions legalized
April 1977; represent no more than a quar-
ter of the labor force (1983)','cdca3085dd3f60ab9ff519596e9eb0d474bfada443de5a577a865ec1161f89d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47782722f284740dc0ad5b798695a5ae942e8d2d54dd1c9b8602213e804eb481',1986,'LK','Sri Lanka','people-and-society',466,'Population: 16,638,000 (July 1986), average :
annual growth rate 1.8%
Nationality: noun—Sri Lankan(s); adjec-. :
tive—Sri Lankan .
Ethnic divisions: 74% Sinhalese; 18% Tamil:
7% Moor; 1% Burgher, Malay, and Veddha
Religion: 69% Buddhist, 15% Hindu, 8% °
Christian, 8% Muslim, 0.1% other ~ ;
Language: Sinhala (official); Sinhala and .
Tamil listed as national languages; Sinhala ~
spoken by about 74% of population; Tamil
spoken by about 18%; English commonly
used in government and spoken by about
10% of the population
Infant mortality rate: 37/ 1,000 (1983) .
Life expectancy: 68
Literacy: 87%
Labor Fed 6.4 million (1984 est.); 45.9%
agriculture, 138.3% mining and manufactur-
ing, 12.4% trade and transport, 26.3% ser-
vices and other; extensive underemploy-
ment; 12% unemployment (1984)
Grenbea labor: about 33% of labor force
over 50% of which employed on tea, rubber,
and coconut estates - -','02037d6ac2e40cd6aa10b70b6311d9ab8006dea458a57ea31517ff29d3682a2f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ecb25a9f44f2386efcf311f45c5c522fd82214040293fac006632f1317dfd7c',1986,'SD','Sudan','people-and-society',470,'Population: 22,932,000 (July 1986), average
annual growth rate —0.2%
Nationality: noun—-Sudanese (sing. and ph)
adjective—Sudaneése
Ethnic divisions: 52% black, 39% Arab, -6%
Beja, 2% foreigners, 1% other: -
Religion: 70% Sunni Muslim in north, 20%
indivencus beliefs, 5% Christian (mostly 1 in ‘
south ; oe
Language: Arabic (oficial), N ubian," ‘Ta’:
Bedawie, diverse dialects of Nilotic, N ilo-
Hamitic, and Sudanic languages, English;
program of Arabization in process :
Infant mortality rate: 118.9/1,000 (1985) *°
Life expectancy: 47
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Sudan (continued)
Literacy: 20%
Labor force: 6.086 million (1982); roughly
78.4% agriculture, 9.8% industry and com-
merce, 6.0% government; labor shortages for
almost all categories of employment coexist
with urban unemployment','cb3b1db9d5f4270dcd0fe3b17d3df8288977e10997250a986389f9e193102711','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be25f2f33fe3d2c5443c4eaf64c64d43c9a2eb4b7258cbd7acc9bb867250f0c2',1986,'SR','Suriname','people-and-society',474,'Population: 381,000 (July 1986), average
annual growth rate 1.7%
Nationality: noun—Surinamer(s); adiec-
tive—Surinamese
Ethnic divisions: 37.0% Hindustani (East
Indian), 31.0% Creole (black and mixed),
15.3% Javanese; 10.8% Bush Negro, 2.6%
Amerindian, 1.7% Chinese, 1.0% Europeans,
1.1% other
Religion: 27.4% Hindu, 19.6% Muslim,
22.8% Roman Catholic, 25.2% Protestant
(predominantly Moravian), about 5% indige-
nous beliefs
Language: Dutch (official); English widely
spoken; Sranan Tongo (Surinamese, some-
times called Taki-Taki) is native language of
Creoles and much of the younger population
and is lingua franca among others; also
Hindi Suriname Hindustani (a variant of
Bhoqpuri), arid Javanese
Infant mortality rate: 23/1,000 (1984)
Life expectancy: men 64.8, women 69.8
Literacy: 65%
Labor. force: 104,000 Gian, unemployment
25% (1985); about 10.6% of work force en-
gaged iri agriculture; animal husbandry, and
fishing
Organized labor: 49,000 members of labor
force organized
Population: 692,000 (July 1986), average
annual growth rate 3.0%
Nationality: noun—Swazi(s); adjective—
Swazi
Ethnic divisions: 96% African, 3% Euro-
pean, 1% mulatto
Religion: 57% Christian, 43% indigenous
beliefs
Language: English and siSwati (official),
government business conducted in English
Infant mortality rate: 156/1,000 (1982)
Life expectancy: men 46.8, women 50.0
Literacy: 65%
Labor force: 195,000; over 60,000 engaged
in subsistence agriculture; 55,000-60,000
wage earners, many only intermittently,
with 36% agriculture and forestry, 20% com-
munity and social services, 14% manufactur-
ing, 9% construction, 21% other; 12,000 em-
ployed in South Africa (1982)
984
Organized labor: about''15% of wage earners’
are unionized ° ‘','57c0cb9c7557f80083ecafa625027faf198e8360976aa4d7200481f4afbe54c8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea55f28a25ed67725b42c945f6580c84f45625e335f7585427f28c7e5838a749',1986,'CH','Switzerland','people-and-society',481,'Population: 6,466,000 (July 1986), average
annual growth rate 0.1%
Nationality: noun—Swiss (sing. & pl.); ad- .
jective—Swiss
Ethnic divisions: total population—65%
German, 18% French, 10% Italian, 1%
Romansch, 5% other; Swiss nationals—74%
German, 20% French, 4% Italian, 1%
Romansch, 1% other
Religion: 49% Catholic, 48% Protestant,
0.3% Jewish
Language: total population—65% German,
18% French, 12% Italian, 1% Romansch, 4%
other; Swiss nationals—74% German, 20%
French, 4% Italian, 1% Romansch, 1% other
Infant mortality rate: 9/1,000 (1985)
Life expectancy: men 70.3, women 76.2
Literacy: 99%
237
Labor force: 3.05 million, about 706,000
foreign workers, mostly Italian; 42% ser-
vices, 89% industry and crafts, 11% govern- -
ment, 7% agriculture and forestry, 1% other;
approximately 0.9% unemployed (1985)
Organized labor: 20% of labor force
Population: 10,931,000 (July 1986), average
annual growth rate 3.7%
Nationality: noun—Syrian(s); adjective—
Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 74% Sunni Muslim; 16% Alawite,
Druze, and other Muslim sects; 10% Chris-
tian (various sects)
Language: Arabic (official), Kurdish, Arme-
nian, Aramaic, Circassian; French and
English widely understood
Infant mortality rate: 57/1,000 (1984)
Life expectancy: men 64.9, women 67.6
Literacy: about 50%
Labor force: 2.4 million; 36% miscellaneous ;
services, 32% agriculture, 32% industry (in-
cluding construction); majority unskilled;
shortage of skilled labor
Organized labor: 5% of labor force _
Population: 22,415,000 (July 1986), average
annual growth rate 3.2%
Nationality: noun—Tanzanian(s); adjec-
tive—Tanzanian
Ethnic divisions: mainland—99% native
African consisting of well over 100 tribes; 1%
Asian, European, and Arab; Zanzibar—al-
most all Arab
Religion: mainland —33% Christian, 33%
Muslim, 33% indigenous beliefs; Zanzibar—
almost all Muslim
Language: Swahili and English (official);
English primary language of commerce,
administration, and higher education; Swa-
hili widely understood and generally used
240
for communication between ethnic groups;
first language of most people is one of the
local languages; primary education is gener-
ally in Swahili
Infant mortality rate: 103/1,000 (1984)
Life expectancy: 52
Literacy: 79%
Labor force: 208,680 in paid employment
(1983); 90% agriculture, 10% industry and
commerce
Organized labor: 15% of labor force','cb7fbb705425a28d771126fe0c2e420b0245b5e7e8d518dd8121a6a95167eb10','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ae8fa868ee03e3bbfc83953e2c6697abd010eab929e7432c1abd0d364d79a1d',1986,'TH','Thailand','people-and-society',485,'Population: 52,438,000 (July 1986), average,
annual growth rate 1.7%
Nationality: noun—Thai (sing. and pl.); ad-
jective—Thai nos
Ethnic divisions: 75% Thai, 14% Chinese, ‘
11% other
Religion: 95.5% e Buddhist 4% Muslim, 0.5%
other —
Language: Thai; English is the eee Le
language of the elite; ethnic and regional
dialects
Infant mortality rate: 51.4/1,000 (1985)
Life expectancy: men 59.5, women 65.1. ss
Literacy: 84% fs
Labor force: 26 million (1984); 13% agricul,
ture, 11% industry and commerce, 10%
services, 6% government; 1:5% unemploy-
ment rate,','fcbea649c2b24a18f69227aa24a584571258f0b21cce1d48650e5bde9d4776bd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e60266f202538352cf2cb82c2830453e113ab66ac7632b1bdb05cae17b448580',1986,'TK','Tokelau','people-and-society',489,'Population: 1, 538 July 1986), average an-
nual growth rate + 0.2% -
Nationality: noun—Tokelauan(s); adjec-
tive—Tokelauan * ;
Ethnic divisions: all Polynesian, with cul-
" tural ties to Western Samoa
Religion: 70% Congregational Christian
Church, 30% Roman Catholic—on ‘Atafu, all
Congregational Christian Church of Samoa;
on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations
Language: Tokelauan (a Polynesian lan-
guage) and English
Literacy: probably high','b41a645d5eb5ef0585c9b4ef18e8e770d8525cd896c12a7a4a04ce7957e5d867','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5903ed4b7f07da114d8fd66ead6f3cf40053a893486a1caad0b7da5a32d93dc',1986,'TO','Tonga','people-and-society',493,'Population: 104,000 (July 1986), average
annual growth rate 1.5%
Nationality: noun—Tongan(s); adjective—
Tongan
Ethnic divisions: Polynesian; about 300
Europeans .
Religion: Christian; Free Wesleyan Church
claims over, 30,000 adherents
Language: Tongan, English
Infant mortality rate: 6.4/1,000 (1983)
Life expectancy; 58
Literacy; 90-95%; compulsory education for
children ages 6-14
Labor force: 75% engaged in agriculture;
600 engaged in mining
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Tonga (continued)','10aee297a9f47124984c00a368d5f0f17339e3e5d01d4d7e640187729728b3bd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b1d3fa1dba45baf703b93ddc3c8e5f9f3925b09c0d7fe3b96e42006d2ab4ef6',1986,'TN','Tunisia','people-and-society',500,'Population: 7, 424, 000 (July 1986), average
annual growth rate 2.3%
Nationality: noun—Tunisian(s); adjective—
Tunisian
Ethnic divisions: 98% Arab, 1% European,
less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less
than 1% Jewish
Eiaeiabe Arabic (official), Arabic and
French (commerce). :
Infant mortality rate: 83/1,000 (1983)
Life expectancy: men 60, women 63
Literacy: about 62%
Labor force: 1.9 million, 832% agriculture;
15%-25% unemployed; shortage of skilled
labor
Organized labor: about 360,000 members
claimed, roughly 20% of labor force; Geni-
eral Union of Tunisian Workers (UGTT), .
quasi-independent of Destourian Socialist’
Party : ,','420ecc128e650df2ebb3378c55e4044c412fa1274457bab0dcdd0f1de1e57cee','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3ed8843bf060a67987b08d5f2ea9df44cee0da77d7e2dd1fcb591aa65387b92',1986,'TC','Turks and Caicos Islands','people-and-society',504,'Population: 7,436 (1980)
Ethnic division: majority of African descent
Religion: Anglican, Roman Catholic, Bap-
tist, Methodist, Church of God, Seventh-day
Adventist
Language: English (official)
Infant mortality rate: 24.4/1,000 (1981/82)
Literacy: about 99%
Labor force: some subsistence agriculture; .
majority engaged in fishing and tourist in-
dustries
Organized labor: St. George’s Industrial
Trade Union (Cockburn Harbor), 250 mem-
bers','cb345f4830cdfafb2c2f20c260ef821fde133a2f8042211a6d082386567620cf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74a412d4a4dcc47ada1d8520c8e969bc6604ebe2773c199cdd5c1422fdeaa9f5',1986,'TV','Tuvalu','people-and-society',508,'Population: 8,000 July 1986), average an-_
nual growth rate 1.7%
Nationality: noun—Tuvaluans(s); adjec-
tive—Tuvaluan
Ethnic divisions: 96% Polynesian
Religion: Christian, predominantly Protes-
tant
Language: Tuvaluan, English .
Infant mortality rate: 42/1,000 (1979)
Life expectancy: men 57, women 60
Literacy: less than 50%','63e0499ade9fbdcb7277d5ec096410b0c1836dcc13d451dc953d60fa61867d79','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e96dbb3355538dbda35ea9f31f4dcef799c39e724353949330c1b152018d1e3d',1986,'UG','Uganda','people-and-society',512,'Population: 15,158,000 (July 1986), average
annual growth rate 3.1%
Nationality: noun—Ugandan(s); adjective—
Ugandan
Ethnic divisions: 99% African, 1% Euro-
pean, Asian, Arab
Religion: 38% Roman Catholic, 33% Protes-
tant, 16% Muslim, rest indigenous beliefs
Language: English (official); Luganda and
Swahili widely used; other Bantu and Nilotic
languages
Infant mortality rate: 92/1,000 (1985)
Life expectancy: men 48, women 50
Literacy: 52.3%
Labor force: estimated 4.5 million; about
250,000 in paid labor; remainder in subsis-
tence activities
Organized labor: 125,000 union members
Population: 1,326,000 July HOee) average
annual growth rate 3.1% °
Nationality: Noun—Enmirian(s), adjective
Emirian .
Ethnic divisions: Emirian 19%, other Arab
23%, South Asian 50% (fluctuating), other
expatriates (includes Westerners and East
Asians) 8%; fewer than 20% of the popula-
tion are UAE citizens (1982)
Religion: Muslim 96%; Christian, Hindu,
and other 4%
Language: Arabic (official); Farsi and
English widely spoken in major cities; Hindi,
Urdu
Infant mortality rate: 44/1,000 (1983)
Life expectancy: men 68, women 73
254
Literacy: 56.3% est.
Labor force: 567,000 (1984 est.); 85% indus-
try and commerce, 5% agriculture, 5% ser-
vices, 5% government; 80% of labor force is
foreign','385c6a8777e9ad88ed61df2bdb23660cb444039b9cadb77c7e9b10b0a132fc2b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf896482706d9915c3c1339711f8320e209cd19bc591dc925671d72ef62f18ef',1986,'GB','United Kingdom','people-and-society',516,'Population: 56,458,000 (July 1986), average
annual growth rate 0.1%
Nationality: noun—Briton(s), British (collec-
tive pl.); adjective—British
Ethnic divisions: 81.5% English, 9.6% Scot-
tish, 2.4% Irish, 1.9% Welsh, 1.8% Ulster,
0.8% other; West Indian, Indian, Pakistani
2% |
Religion: 27.0 million Anglican, 5.3 million
Roman Catholic, 2.0 million Presbyterian,
760,000 Methodist, 450,000 Jewish (regis-
tered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic
(about 60,000 in Scotland)
Infant mortality rate: 10.1/1,000 (1983)
Life expectancy: 74
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
United Kingdom (continued)
Literacy: 99%
Labor force: (1985) 27.58 million;23% man-
ufacturing and construction, 49.4% services,
9.5% self-employed, 10.4% government,
1.2% agriculture; 13.1% unemployed (No-
vember 1985}
Organized labor: 40% labo fore
Population: 240,856,000 (uly 1986), aver-
age annual growth rate 0.9%
Ethnic divisions: 83.1% white; 11.6% black;
6.448% Spanish origin; 0.622%.American
Indian, Eskimo, and Aleut; 0.357% Chinese;
0.343% Filipino; 0.31% Japanese, 0.1595% ~
other Asian; 0.156% Korean; 0. nELOye Viet- :
namese (1980) :
257
Religion: total membership in religious bod-
ies 139.604 million; Protestant 76.754 mil-
lion, Roman Catholic 52.089 million, Jewish :
5.725 million, other religions 5.036 million; ’
60% of the population processes a religious <a
affiliation (1982) th
Language: predominantly English; sizable
Spanish-speaking minority sf
Infant mortality rate: 10.6/1,000 (1984) -
Life expectancy: men 71.6, women 76.3
Literacy: 99%
Labor force: 115.24 million (includes 1.708 : -
million members of the armed forces in the
US); unemployment rate 7.2% (1985); 8,291
million unemployed (October 1985)
Organized labor: approximately 17.3 mil-
lion members; 18% of. civilian labor force
(1985) : sada SY ae','340d575154d77398bfbd00a7dfcbb197820e752f3a419842ae8d7bb33cf9bf6d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('489563e9075120b15654731a2bd2719dad10d3f5bd7e4c946b2636b55b68fd12',1986,'UY','Uruguay','people-and-society',520,'Population: 2,947,000 (July,1986), average .
annual growth rate 0.4%
Nationality: noun—Uruguayan(s); adjec-
tive—-Uruguayan
Ethnic divisions: 88% white, 8% mestizo, 4%
black
Religion: 66% Roman Catholic (less than
half adult population attends church regu-
larly), 2% Protestant, 2% Jewish, 30% _
nonprofessing or other ©
Language: Spanish
Infant mortality rate: 32/1,000 (1983)
Life expectancy: men 67.1, women 73.7
Literacy: 94.3%
not necessarily authoritative.
South -
Labor force: about 1.28 million (1981); 19%
manufacturing; 19% government; 16% agri-
culture; 12% commerce; 12% utilities; con- |
struction, transport, and communications;
22% other services; unemployment more
than 15% (1984 est.)
Organized labor: Interunion Workers’ As-
sembly /National Workers’ Confederation
(PIT/CNT) Labor Federation','0a68f0fe1849d2817a67a59a9103b498a487f760936d6204263974ced687805c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22c79e12350e9fab3eca06acdf05797834553a4ad4509c25af1cf0427f60b7d7',1986,'VU','Vanuatu','people-and-society',524,'Population: 136,000 (July 1986), average
annual growth rate 3.2%
Nationality: noun—Vanuatuan(s); adjec- -
tive—Vanuatuan
Ethnic divisions: 90% indigenous Melanes-
jan; 8% French; remainder Vietnamese,
Chinese, and various Pacific Islanders
Religion: most at least nominally Christian
Language: English and French (official);
pidgin (known as Bislama or Bichelama)
Life expectancy: 55
Literacy: probably 10-20%
260
Population: 737 (July 1986), average annual
growth rate 0.1%
Ethnic divisions: primarily Italians but also
many other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various other
languages. ._
Literacy: 100%
Labor force: approx. 1,500; Vatican City
employees divided into three categories—
executives, office workers, and salaried em-
ployees','d7972988f7fb5e0b9478814d09d5e3d5a30da7898c380c4947fdc51d3c961f01','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a492b2bafac215b4c9dfdaa2adff6648f10f2bbde34caf467e1c840fafe1aa70',1986,'WF','Wallis and Futuna','people-and-society',528,'Population: 14,000 (July 1986) average an-
nual growth rate 2.5%
Nationality: noun—Wallisian(s), Futunan(s),
or Wallis and Futuna Islanders; adjective—
Wallisian, Futunan, or Wallis and Futuna
Islander
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic
Population: 92, 000 (July 1986), average an-
nual growth rate 1.8%
Nationality: noun—Saharan(s), Moroccan(s);
adjective—Saharan, Moroccan oe
Ethnic divisions: Arab and Berber
Religion: Muslim
Language: Hassaniya Arabic, Moroccan
Arabic
Literacy: among Moroccans, probably
nearly 20%; among Saharans, perhaps 5%
Labor force: 12 ,000; 50% animal husbandry
and subsistence farming, 50% other
Population: 165,000 July 1986), average
annual growth rate 0.8%
Nationality: noun— Western Samoan(s);
adjective— Western Samoa
Ethnic divisions: Samoan; about 12,000
Euronesians (persons of European and
Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of pop-
ulation associated with the London Mission-
ary Society; includes Congregational, Ro-
man Catholic, Methodist, Latter Day Saints,
Seventh-Day Adventist).
Language: Samoan (Polynesian), English
Infant mortality rate: 36/1,000 (1983)
Life expectancy: 63
Literacy: 90%
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Labor force: about 37,000 (1988): about
22,000 employed in agriculture
Population: 6,339,000 (July 1986), average
annual growth rate 2.9%
Nationality: noun-—Yenrieni(s ); adjective—
ieoem ae
Ethnic divisions: 90% Arab, 10% Afro- Ab
on
Rouen 100% Muslim (Sunil and Shi‘a)
Language: Arabic ,
Infant mortality rate: 152/1,000 (1983)
Life expectancy: mén 37.3, women 38.7
Literacy: 15% (est:)" aa
Labor force: approximately one-third expa-
triate laborers; remainder almost entirely
agriculture and herding
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
“eg
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Yemen Arab Republic
(North Yemen) (continued)','f2f8c34a92f1ed6c0269e5f1646b962d25ea4d77ca05b4dd69b632d9ef5dd9f2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('605bd96972e85a58d9f6bc880a5ded7674504d50bbdf954c3aef047caf330975',1986,'YE','Yemen','people-and-society',532,'Population: 2,275,000, excluding the island
of Perim for which no data are available
(July 1986); average annual growth rate 2.9%
Nationality: noun—Yemeni(s); adjective—
Yemeni A
Ethnic divisions: almost all Arabs; a few
Indians, Somalis, and Europeans
" Religion: Sunni Muslim, some Christian and
Hindu
Language: Arabic
Infant mortality rate: 114/1,000 (1980)
Life expectancy: men 40. 6, women 42.4
Literacy: 25% ;
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Population: 28,284 ,000 (July 1986), average
annual growth rate 0.7%
Nationality: noun—Yugoslav(s); adiective—
Yugoslav
Ethnic divisions: 36.2% Serb, 19.7% Croat,
8.9% Muslim, 7.8% Slovene, 7.7% Albanian,
5.9% Macedonian, 5.4% Yugoslav, 2.5%
Montenegrin, 1. 9% Hungarian, 4: 0% other ‘
(1981 census)
Religion: 50% Serbian Orthodox, 30% Ro-”
man Catholic, 10% Muslim, 1% Protestant,
9% other or none’
Language: Serbo-Cicatian, Slovene, Mace:
donian (all official); Albanian, Hungarian
Infant mortality rate: 30/1,000 (1982) a
Life expectancy: men 68, women 73
Literacy: 90.5%
Labor force: 10.1 million (1983); 25% agri- |
culture, 29% mining and manufacturing;
(est.) unemployment about 14% of domestic.
labor force (anuary- August''1985) ~°
Population: 31,333,000 (July 1986), average
annual growth rate 2.7%
Nationality: noun—Zairian(s); adjective—
Zairian
Ethnic divisions: over 200 African ethnic
groups, the majority are Bantu; four largest
tribes—Mongo, Luba, Kongo (all Bantu),
and the Mangbetu-Azande (Hamitic) make
up about 45% of the population
Religion: 50% Roman Catholic, 20% Protes-.
tant, 10% Kimbanguist, 10% Muslim, 10%
other syncretic sects and traditional beliefs
Language: French (official), English,
Lingala, Swahili, Kingwana, Kikongo,
Tshiluba
Infant mortality rate: 108/ 1,000 (1984)
Life expectancy: men 46, women 49
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Zaire (continued)
Literacy: 55% males, 37% females
Labor force: about 8 million, but only about
13% in wage structure
Population: 7, 054, 000 g uly AEG), average
annual growth rate 3:2%
Nationality: ‘cdi Tambane adjective—
Zambian
Ethnic distin 98, 1% phen 1. 1% Euro-
pean, 0:2% other-.
felisiere 50-75%-Christian, 1% Muslim and:
Hindu, remainder indigenous beliefs
Language: English (official); about 70 snc
enous languages.
Anfant mortality rate: 140/1, 000 (1984
Life gepectanty: 47
Literacy: 54%
Labor force: 2,455,000; 85% agriculture; 6%
mining, manufacturing, and construction;
9% transport and services
Organized labor: approximately 238,000
wage earners are unionized','25f8d41d6cd7c24e8a68f8c4f4509dcd2d08ffbe797188835c4845d609fca9a9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1179f3489cc66483877f5df1d9391517706ecdbb4d813648e34ea201b2b0346b',1986,'ZW','Zimbabwe','people-and-society',536,'Population: 8,984 000 (July 1986), average -
annual growth rate 3.5%
Nationality:. noun—Zimbabwean(s); adjec-
tive —Zimbabwean
Ethnic divisions: about 96% African (over
73% members of Shona-speaking subtribes,
19% speak Ndebele); about 3% white, 1%
mixed and Asian |
Religion: 50% syncretic (part: Christian, part
indigenous beliefs), 25% Christian, 24% i in-
digenous beliefs, a few Muslim
Language: English (official); ChiShona and
SiNdebele .. _
Infant mortality rate: 66/1,000(1985)
Life expectancy: men 53.3, women 56.8
Literacy: 45-55%
Q74
Labor force: 1,985,000 (1985); 78% agricul-
ture; 18% mining, manufacturing, construc-
tion; 4% transport and services
Organized labor: about one-third of Euro-
pean wage earners are unionized, but only a
small minority of Africans .
Population: 19,601,000, excluding the popu-
lation of Quemoy and Matsu Islands and
foreigners (July 1986), average cannual
growth rate 1.4%
Nationality: noun—Chinese (sing., pl.); ad-
jective—Chinese
Ethnic divisions: 84% Taiwanese, 14%
mainland Chinese, 2% aborigine
Religion: 93% mixture of Buddhist, Confu-
cian, and Taoist; 4.5% Christian; 2.5% other
Language: Mandarin Chinese (official); Tai-
wanese and Hakka dialects also used
Infant mortality rate: 11.01/1,000 (1983)
Life expectancy: men 69.9, women 74.9
Literacy: 94%
CIA-RDP08-00534R0001 00170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Taiwan (continued)
Labor force: 7,491,000 (1984); 41% industry
and commerce, 32% services, 20% agricul-
ture, 7% civil administration; 2.4% unem-
ployment (1984)
Organized labor; (1983) 1.3 million or about
18.4% (government controlled)
Administration
Type: one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 5 cities, 2
special municipalities (Taipei and
Kao-hsiung)
Legal system: based on civil law system;
constitution adopted 1946, though 1948
amendments set most of the constitution
aside; martial law declared in 1949 still in
effect; accepts compulsory ICJ jurisdiction,
with reservations ,
National holiday: 10 October
Branches: five independent branches (execu-
tive, legislative, judicial, plus traditional
Chinese functions of examination and con-
trol), dominated by executive branch; Presi-
dent and Vice President elected by National]
Assembly
Government leaders: CHIANG Ching-kuo,
President (since March 1978); YU Kuo-hua,
Premier (since June 1984)
Suffrage: universal over age 20
Elections: national level—Legislative Yuan
every three years; National Assembly and
Control Yuan every six years; no general
election held since 1948 election on main-
land (partial elections for Taiwan province
representatives in December 1969, 1972,
1975, 1980, 1983, 1984, and 1985); local
level—provincial assembly, county. and mu-
nicipal executives every four years, county
and municipal assemblies every four years
Political parties and leaders: Kuomintang,
or National Party, led by Chairman Chiang
Ching-kuo
Voting strength: (1983 Legislative Yuan
elections) 62 seats Kuomintang, 19 seats in-
dependents; 1981 local elections, with 63%
turnout of eligible voters, Kuomintang re-_
ceived 71% of the popular vote,
mnon-Kuomintang 29%
Other political or pressure’groups: loose
coalition of oppositionist independent poli-
ticians has emerged in the past six years plus
Young China Party, nominally controlled by
the KMT
Member of: expelled from UN General As-
sembly and Security Council on 25 October
1971 and withdrew on same date from other
charter-designated subsidiary organs; ex-
pelled from IMF /World Bank group
‘April/May 1980; member of ADB and seek-
ing to join GATT and/or MFA; attempting
to retain membership in ICAC, ISO,
ANTELSAT, INTERPOL, [WC—Interna- ~
tional Wheat Council, PCA; suspended from
IAEA in 1972 but still allows IAEA controls
over extensive atomic development
Population: total, 1,508,000 (July 1986); av-
erage annual growth rate 3.38%; West Bank
(including East Jerusalem)—967,000 (July
1986), average annual growth rate 3.1%;
Gaza Strip—541,000 July 1986), average
annual growth rate 3.7%
Nationality: West Bank—to be determined;
Gaza Strip—tobedetermined
Ethnic divisions: West Bank—88% Palestin-
ian Arab and other, 12% Jewish (includimg
expanded East Jerusalem); Gaza Strip—
99.8% Palestinian Arab and other, 0.2%
Jewish as
Religion: West Bank—80% Muslim (pre-
dominantly Sunni), 12% Jewish, 7% Chris-
tian and other; Gaza Strip—99% Muslim
(predominantly Sunni), 0.8% Christian, 0.2%
Jewish
Language: West Bank: Arabic; Israeli set-
tlers speak Hebrew; English widely under-
stood
Gaza Strip: Arabic; Israeli settlers speak He-
brew; English widely understood
Labor force: West Bank: (excluding Israeli
Jewish settlers) 29.8% small industry, com-
merce, and business; 24.2% construction;
22.4% agriculture; and 23.6% service and
other (1984)
Gaza Strip: (excluding Israeli Jewish settlers) .
32.0% small industry, commerce and busi-
ness; 24.4% construction; 25.5% service and
other; and 18.1% agriculture (1984)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
West Bank and
Gaza Strip (continued)','36072ffffefd0f5f3b689e593662e7fbd58b5667a0c8be2752774ae569258bf1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

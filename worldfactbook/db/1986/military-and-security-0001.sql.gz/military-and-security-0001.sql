SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abf815a4d3aff1051dd68b522c8aab278f9a9eae78df5ad992cae2ac1046aec8',1986,'DJ','Djibouti','military-and-security',144,'Electric power: 80,100 kW capacity (1985);
140 million kWh produced (1985), 471 kWh
per epi
Repos $88 inillion (£.0-b.,. 1984 prelim.);
hides and skins and transit of coffee; a large
66
portion consists of reexports to foreign resi"
dents of Djibouti
Imports: $200 million Gob., 1984 prelim.);
almost all domestically needed goods—
foods, machinery, transport equipment
Budget: (1983) revenues, $118 million; -.
grants, $27 million; current-expenditures,
$120 million; development-expenditures,
$32 million; extrabudgetary expenditures,
$21 million
Monetary conversion rate: 177.67 Djibouti
francs= US$] (October 1984)
Fiscal year: calendar year','78c681de061c4587033e9a743c69682f96dd38e4bb57d70f46845c24c954b874','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

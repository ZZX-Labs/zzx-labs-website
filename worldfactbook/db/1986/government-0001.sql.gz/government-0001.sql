SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ba38b1b92fecd832fdd3f8282a7deb1912a0002d3fb2e12314c522af46be47d',1986,'','','government',3,'Official name: Detiocratic Republic of Af-
ghanistan
‘Type: Communist regime backed by multi-
divisional Soviet force
Capital: Kabul
Political subdivisions: 29 provinces with
centrally appointed governors °
Legal system: not established; legal educa-
tion at Kabul University; has not accepted
compulsory ICJ jurisdiction
Branches: Revolutionary Council acts as
. legislature and final court of appeal; Presi-
dent of Council acts as chief of state; Cabi-
net and judiciary responsible to Council;
Presidium chosen by Council has full au-
thority when Council not in session; Loya
Jirga (Grand National Assembly) supposed to
convene eventually and approve permanent
constitution
Government leaders: BABRAK Karmal,
President of the Revolutionary Council and
head of the People’s Democratic Party of
Afghanistan (since December 1979); Soltan
Ali KESHTMAND, Prime Minister (since
June 1981)
Suffrage: universal from age 18
Political parties and leaders: the People’s
Democratic Party of Afghanistan (PDPA),
the sole legal political party, has two fac-
tions—the Parchami faction has been in
power since December 1979; members of _
the deposed Khalai faction continue to hold
some important posts; the Sholaye-Jaweid is
a much smaller pro-Beijing group .
Communists: the PDPA claims 120,000
members
Other political or pressure groups: the mili-
tary.and other branches of internal security
are being rebuilt by the Soviets; insurgency
continues throughout the country;
1
widespread opposition on religious grounds;
widespread anti-Soviet sentiment
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, IAEA, IBRD, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, INTELSAT, ITU, NAM,
UN; UNESCO, UPU, WFTU, WHO,
WMO, WTO, WSG; suspended from OIC in
January 1980','18143bdeb416994f9980d93ef0c62eed7dccc38dc8ad32844054442b620ed44d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b90fceea09e61c25042de9f5c42ed4e7e64454de16bcb1852407f58119ebc34',1986,'AL','Albania','government',8,'Official name: People’ s Socialist Republic, of
Type: Conia state :
Capital: Tirané
Political din doak 26 fee (districts).
Legal system: based on constitution oieed
in 1976; judicial review.of legislative acts.
only in-the Presidium.of the People’s Assem-
bly, which is not a true court; legal education
at University of Tirané; has not accepted
‘compulsory IC] jurisdiction
National halide: Tibeeian Day, 29 No-..
vember ae Ma Betas
Branches: legislature (People’s Assembly), .
Council of ‘Ministers, judiciary
Cosemanions leaders: -Ramiz ALIA, Chair-
man, Presidium of the People’s Assembly
(chief of state; since: November.1982); Adil -
CARCANI, Chairman, Council of Ministers
(premier; sirice November 1982)
Suffrage: universal and compulsory over age
18. - :
Elections: national elections held every four
years; last elections 12 November 1982;
100% of electorate,voted (with one dissent- -
ing vote) Mot ea ~
Political parties and leaders; Albanian
Workers Party only; First Secretary, Ramiz
Alia (since April 1985)
Commiunists: 122,600 party members (No-_
vember He) 4.5% of population .
Neniber on CEMA. FAO, IAEA, IPU, ITU,
UN, UNESCO, UPU, WFTU, WHO,
WMO; has not participated in CEMA since
rift with USSR in 1961]; officially withdrew
from Warsaw Pact 13 September 1968
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
a ee iene ne ee agg eR Rm I ce ec pr re
icp as 2 Se
7M Ne
at
Me er
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','efa4589fe197cb78b11e9a65691ec0d4eb3ea81cf6a3bc96d22e162883be4592','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55085f0a6cbf73346a6e0c0a823dd8ff830871360a18dab529c1d08f88755928',1986,'DZ','Algeria','government',14,'Official name: Democratic and Popular Re-
public of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 31 wilayas (depart-
ments or provinces); 160 dairat (administra:
tive districts); 691 communes
Legal system: based on French and Islamic
law, with socialist principles; new constitu-
tion adopted by referendum November
1976; judicial review of legislative acts in ad
hoc Constitutional Council coiiposed of
various public officials, including several
Supreme Court justices; Supreme Court di-
vided into four chambers; legal education at
Universities of Algiers, Oran, and Constan-
tine; has not accepted compulsory IC] juris-
diction
National holiday: Anniversary of the Revo-
lution, 1 November
Branches: executive; unicarneral legislature
(National People’s Assembly); judiciary
Government leaders: Col. Chadli BENDJE-
DID, President (since February 1979),
Abdelhamid BRAHIMI, Prime Minister
(since January 1984)
Suffrage: universal adult at age 18
Elections: presidential, 12 January 1984;
- departmental assemblies, 2 Jine 1974; local
assemblies, 30 March 1975; legislative, 5
March 1982
Political parties and leaders: National Lib-
eration Front (FLN), Secrétary General
Chadli Bendjedid
Communists: 400 (est.); Communist Party
illegal (banned 1962) ''
Member of: Af{DB, AIOEC, Arab League,
ASSIMER, FAO, G-77, GATT (de facto),
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Developmient Bank, IFAD, ILO, IMF, IMO,
INTELSAT, International Lead and Zinc
Study Group, INTERPOL, IOOC, ITU,
NAM, OAPEC, OAU, OIC, OPEC,.UN,
UNESCO, UPU, WHO, WIPO, WMO','c953b165e3b311d9998efcad89049c2c7bb74e9b53033b579cc4a769cf3d3c9f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c283d37c036b48f2c2e5996d471693784f60757571f65c1612250371ed28a04',1986,'AD','Andorra','government',18,'Official name: Principality of Andorra
Type: unique.co-principality under formal
sovereignty of President of France and
Spanish Bishop of Seo de Urgel; who are rep-
‘resented locally by officials called verguers
Capital: Andor‘a la Vella
Political subdivisions: 7 districts
Legal system: based on French and Spanish
civil codes; Plan of Reform adopted 1866:
serves as constitution; no judicial.review of
legislative acts; has not accepted compulsory
IC] jurisdiction
Branches: legislative (General Council of the
Valleys) consisting of 28 members; execu-
tive—syndic (manager) and a deputy
subsyndic chosen by General Council; judi-:-’
ciary chosen by Co-princes who appoint two
civil judges, a judge of appeals, and two
batlles (court prosecutors); final appeal to the
Supreme Court of Andorra at Perpignan, * ©
France, or to the Ecclesiastical Court of the -
Bishop of Seo de Urgel, Spain
Government leaders: head of state—Fran-
cois MITTERRAND (President of France;-
since 1981) and Juan Marti ALANIS (Bishop
of Seo dé Urgel, Spain; since 1971),
Co-Princes; Syndic—Francese
CERQUEDA Pasquet (since 1982); Sapepne: :
dic—Josep Maria MAS Pons (since 1982);
head of government—Josep’ PINTAT (Chief -
Executive; since 1986)
Suffrage: those of 21 or over who are third-
generation Andorrans can voté for General *
Council members
Elections: General Council chosen every
four years; last election December 1981
Political parties and leaders: political par-
ties not yet legally recognized; traditionally
no political parties but partisans for particu-
lar independent candidates for the General -
Council on the basis of competence, person-
ality, and orientation toward Spain or
France; various small pressure groups devel-
oped in 1972; first formal-political party, --
Andorran Democratic Association, was -
‘formed in 1976 and reorganized in 1979 as
‘Andorran Democratic Party 4
Communists: negligible
Member of: UNESCO','04b8c9586be02e1bf83af0630b4cde1dd45f8d37d7ee415fdac388f201fdd04d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49a8cd79fe72aa70926be8e9f3104008485d7a5fa19ef01b99b1362919c6bda2',1986,'AO','Angola','government',22,'Official name: People’s Republic of Angola
Type: Marxist people''s republic
Capital: Luanda
Political subdivisions: 18 provincesinclud-
ing the coastal exclave of Cabinda
Legal system: formerly based on Portuguese
civil law system and customary law;. being
modified along “socialist” model
National holiday: Independence Day, 11
November ‘
Branches: the official party is the supreme -
political institution; legislative—National
People’s Assembly
Government leader: José Eduardo dos
SANTOS, President (since September 1979)
Suffrage: to be determined
Elections: none held to date
Political parties and leaders: Popular Move-
ment for the Liberation of Angola~Labor
Party (MPLA-Labor Party), led by dos
Santos, is the only legal party; National
Union for the Total Independence of Angola
(UNITA), lost to the MPLA in immediate —
postindependence struggle, now carrying
out insurgency ,
Member of: Af{DB, FAO, G-77, GATT (de
facto), ICAO, IFAD, ILO, IMO,
INTELSAT, ITU, NAM, OAU, SADCC,
UN, UNESCO, UNICEF, UPU, WFTU,
WHO, WMO','bb4f745c2660374a953d060b11722d4eac374079ab2370932da92614339c6a3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb919376c3d8f647f398b539b5e6f38a62c5a13427ff15f3a11bf01ee1ed8cc2',1986,'AI','Anguilla','government',26,'Official name: Anguilla _
Type: British dependent territory
Capital: The Valley
Legal system: based on English common
Jaw; constitution came into effect-on 1 April
1982
Branches: 11-member House of Assembly,
seven-member Executive Council
Government leaders: Allistair BAILLE, .
Governor (since February 1984); Emile
GUMBS, Chief Minister (since March.1984) .
Suffrage: native born; resident before sepa-
ration from St. Christopher and Nevis; 15
years residence fér “belonger” status
Elections: general election, March 1984
Political parties and leaders: Anguilla
National Alliance (ANA), Emile Gumbs;
Anguillan People’s Party (APP), Ronald
Webster :
. Voting strength: ANA, 6 seats; APP, O:seats;
1 independent
Communists: none
M ember of: Commonwealth
Economy et
GDP: $6 million (1983 est.), $6,000 per cap-
ita (1988 est.) no, Ce
Agriculture: pigeon peas, corn, sweet pota-.,
toes; sheep, goats, pigs, cattle, poultry
Fishing: inshore and reef fishing
Major industries: tourism, lobster exports,
salt, fishing
Electric power: 1,500,000 kw capacity ,
(1984); 2 million kWh produced (1984), 285
kWh per capita
Exports: lobsters.
Budget: revenue, $3.7 million (1983); ex- .
penditure,, $3.9 million (1983)
M onetary conversion rate: 2. 70 East Carib.
bean dollars=$US] (December 1985)
Fiscal year: probably calendar','c0d11619087bf3302bd8b49b52aeef03cdbdf552385cca27b3d592d9804f12fc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be379f2145c784c0308b5d62c05fb5217023928b15bd61cfc74a243fcb7c118',1986,'AG','Antigua and Barbuda','government',29,'Official name: Antigua and,Barbuda |. | -
Type: independent state recognizing Eliza-
beth Il as Chief of State
Capital: St. John’s on the island of Antigua |
Political subdivisions: 6 parishes, 2 de-
pendencies (Barbuda, Redonda)
Legal system: based on English common :-
law: British Caribbean Court of Appeal,
which has exclusive original jurisdiction and .
an appellate jurisdiction, consists of Chief
Justice and five justices :
Branches: bicameral legislative, 17-member
popularly elected House of Representatives
and 17-member Senate; executive, Prime
Minister and Cabinet; judiciary, Court of
Appeals
Government leaders: Vere Cornwall BIRD, .
Sr., Prime Minister (since 1976); Lester __
BIRD, Deputy Prime Minister (since 1976);
Sir Wilfred Ebenezer JACOBS, Governor
General (since 1967)
Suffrage: universal suffrage at age 18
Elections: every five years; last general elec-
tion 17 April 1984
Political parties and leaders; Antigua Labor
Party (ALP), Vere C. Bird, Sr., Lester Bird;
United People’s Movement (UPM), George
Herbert Walter;.National Democratic Party.
(NDP), Dr. Ivor Heath
Voting strength: (1984 election) House. of. .
Representatives-—ALP, 16.seats; inde-.
pendent, 1 seat
Communists: negligible
Other political.or pressure groups: Antigua
Caribbean Liberation Movement (ACLM), a
small leftist nationalist group led by .
Leonard “Tim” Hector
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ch Ae
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Member of: CARICOM, Commonwealth,
FAO, G-77, IBRD, ICAO, ILO, IMF, ISO,
OAS, UN, UNESCO, WHO: WMO -','e95f9e7533c114dca209f4d8684d65e053020b4e8c8162c98f501386a02eb37c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be2e763e2acfbf2d34429b0840e6bc85902687f775bf7cb52c13045f23ff9ed0',1986,'AR','Argentina','government',33,'Official name: : Argentine Republic
Type: republic a
Capital: Buenos Aires
Political subdivisions: 22 provinces, | dis-
trict (Federal Capital), and 1 territory
Legal system: mixture of USand West Eu-
ropean legal systems; constitution adopted
1853 is in effect; legal education at Univer- _
sity of Buenos Aires and other public and
private universities; has not accepted com-
pulsory IC] jurisdiction
National holiday: Independence Day, 25
May
Branches: executive (President, Vice Presi-
dent, Cabinet); legislative (National Con--
gress—Senate, Chamber of Deputies); na-
tional judiciary
Government leaders: Raul ALFONSIN,
President (since December 1983); Victor
MARTINEZ, Vice President (since Decem-_.
ber 1983)
Elections: general elections held 30 October
1983; Senate elections scheduled for 1986
Political parties: operate under statute
passed in 1983 that sets out criteria for par-
ticipation in national elections; Radical
Civic Union (UCR)—moderately left of cen-
ter; Justicialist Party (JP)—Peronist
umbrella political organization; Movement
for Industrial Development (MID); Intransi-
gent Party (PI); several provincial parties
Communists: some 70,000 members in vari-
ous party organizations, including a small
nucleus of activists
Other political or pressure groups: Peronist-
dominated labor movement, General Con-
federation of Labor (Peronist-leaning associ-
ation of small businessmen), Argentine In-
dustrial Union (manufacturers’ association),
Argentine Rural Society (large landowners’
association), business organizations, students,
the Catholic Church
Member of: FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAC, ICAO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOOC, ISO, ITU, IWC—Inter-
national Whaling Commission, [WC—In-
ternational Wheat Council, LAIA, NAM,
OAS, PAHO, SELA; UN; UNESCO, UPU,
WFTU, WHO, WMO, WTO, WSG','96640aaf2446516064548788b50d5f10648099000181a69e46b073ef3e4fcc7f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('672381cca88e016c95b247347663898a4533e8b23e244c3b0cefdf52fa8ecd12',1986,'AU','Australia','government',40,'Official name: Commonwealth of Australia
Ageia ie ‘ Ob Bey or at
Type: federal parliai entary state recogniz-
ing Elizabeth II as sovereign or head of state
Capital: Canberra
Political subdivisions: 6 states and 2 territo-
ries
Legal system: based on English common
law; constitution adopted 1900; High Court
has jurisdiction over cases involving inter-
pretation of the constitution; accepts com-
pulsory IC] jurisdiction, with reservations
National holiday: Australia Day, 26 January
Branches: bicameral legislature (Federal
Parliament—Senate and House of Repre-
sentatives); Prime Minister and Cabinet re-
sponsible to House; independent judiciary
Government leaders: Sir Ninian STEPHEN,
Governor General (since July 1982); Robert
HAWKE, Prime Minister (since March
1983)
Suffrage: universal and compulsory over age
18
Elections: held at three-year intervals or
sooner if Parliament is dissolved by. Prime
Minister; last election 1 December 1984
Political parties and leaders: government—
Australian Labor Party (Robert Hawke);
opposition—Liberal Party (John Howard),
National Party (Ian Sinclair), Australian
Democratic Party (Donald L. Chipp), Nu-
clear Disarmament Party (Michael
Denborough)
Voting strength: (1984 parliamentary elec-
tion) House of Representatives—Labor
Party 82 seats, Liberal-National coalition 66
seats; Senate—Labor Party 34 seats, Liberal-
National coalition 33 seats, Australian Dem-
ocratic Party 7 seats, Nuclear Disarmament
Party 1 seat, independents 1 seat
i2
Communists: 4,000 members (est.)
Other political or pressure groups: Austra-
lian Democratic Labor Party (anti-
Communist Labor Party splinter group)
Member of: ADB, AIOEC, ANZUS, CIPEC
(associate), Colombo Plan, Commonwealth,
DAC, ELDO, ESCAP, FAO, GATT, IAEA,
IATP, IBA, IBRD, IGAC, ICAO, ICO, IDA,
IEA, IFAD, IFC, IHO, ILO; International
Lead and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IPU, IRC,
ISO, ITC, ITU, [WC—International Whal-
ing Commission, [WC—International
Wheat Council, OECD, SPF, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG
Official name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (lander): in-
cluding the capital “”
Legal system: civil law system with Roman
law origin; constitution adopted 1920, re-
promulgated 1945; judicial review of legisla- ,
tive acts by a Constitutional Court; separate
administrative and civil/penal supreme
courts; legal education at Universities of *
Vienna, Graz, Innsbruck, Salzburg, and
Linz; has not accepted compulsory ICJ j juris-
diction _
National holiday: 26 October © :
Branches: bicameral legislature (Federal ,
Assembly—Federal Council, National
Council), directly elected Président whose
functions are largely representational, inde-
pendent federal judiciary |
Government leaders: Rudolf
KIRCHSCHLAGER, President (since July
1974); Fred SINOWATZ, Chancellor (since
May 1988), leads a Socialist / Freedom Party
of Austria coalition
Suffrage: universal over age 19; compulsory
for presidential elections
Elections: presidential, every ‘six ‘ years (next
1986); parliamentary, every ‘four years (next
1987)
Political parties and leaders: Socialist Party
of Austria (SPO), Fred Sinowatz, ‘chairman; —
Austrian People’s Party (OVP); “Alois Mock,
chairman; Liberal Party (FPO), Norbert
Steger, chairman; Communist Party (KPO), °
Franz Muhri, chairman; Alternative List
Austria (ALO), no leader; ‘United Gréens |
(VGO), Josef Buchner, leader if
Voting strength: (1983 election) parliamen-
tary—SPO 47.65%, OVP 43.22%, FPO
4.98%, VGO 1.93%, ALO 1. 36%, KPO 0.66%
Communists: membership 15, 000 est.; ac-
tivists 7,000-8,000
Other political or pressure groups: Federal
Chamber of Commerce and Industry; Aus-
trian Trade Union Federation (primarily
Socialist); three composite leagues of the
Austrian People’s Party (OVP) representing
business, labor, and farmers; OVP-oriented
League of Austrian Industrialists, Roman
Catholic Church, including its chief ay or-
ganization, Catholic Action | Cte
Member of: ADB, Council of Europe, DAC,
ECE, EFTA, EMA, ESRO (observer), FAO,
GATT, IAEA, IDB—Inter-American Devel-
opment Bank, IBRD, ICAC, ICAO, IDA,
IEA, IFAD, IFC, ILO, International Lead
and Zinc Study Group, IMF, IMO, |
INTELSAT, INTERPOL, ITU, IWC—In-
ternational Wheat Council, OECD, UN,
UNESCO, UPU, WFTU, WHO, WIPO,”
WMO, WTO, WSG
Official name: The Commonwealth of The
Legal system: wide legislative and executive
responsibility under the Norfolk Island Act
of 1979; Supreme Court
National holiday: Pitcairners Arrival Day
Anniversary; 8 Juné _
Branches: 9-member elected Legislative
Assembly; chief.executive is Australian ad-
ministrator named by governor cent
Cosaanen leader: David E. BUFFETT,
Chief Munster of Norolk Island (since 1983)
Suffrage: seecrurtals veuvecentahor: all
persons born on the island are Australian
citizens
Elections: last held 18 May 1983; every -
three years |. —','0189cc8ab4290208e495f40059effa21a9a2045522b8f1a2fd205e8d15632a93','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b683202daffde78a42ce2038bfa6687cad166e520a2ee07ac4bf00f681bd049',1986,'BS','Bahamas','government',42,'Type: independent commonwealth recog-
nizing Elizabeth Il as Chief of State
Capital: N: assau on New Providence Island. |
Legal system: based on English common
law
National holiday: Independence Day, 10
July -
Branches: bicameral legislature
(Parliament—16-member appointed Senate,
43-member elected House of Assembly);
executive (Prime Minister and Cabinet);
judiciary
Government leaders: Sir Lynden Oscar
PINDLING, Prime Minister (since 1969); Sir’
Gerald C. CASH, Governor General (since
1979)
Suffrage: universal over age 18
Elections: House of Assembly ai une 2 1982);
next election constitutionally due i in five |
years
Political parties and leaders: Progressive
Liberal Party (PLP), Sir Lynden O. Pindling;
Free National Movement (FNM), Kendal
Isaacs, Cecil Wallace- Whitfield.
Vite strength: 73,309 registered voters
(July 1977); (1982 election) House of Assem- _.
bly—PLP (55%) 32 seats, FNM (45%) ll
seats, others (9%) O seats
Communists: none known
Other political or pressure groups: Van-
guard Nationalist and Socialist Party
(VNSP), a small leftist party headed by
Lionel Carey; Trade Union Congress (TUC),
headed by Leonard Archer
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
The Bahamas (continued)
Member of: CARICOM, CDB, Common-
wealth, FAO, G-77, GATT (de facto), IBRD,
ICAO, IDB—Inter-American Development
Bank, ILO, IMF, IMO, INTERPOL, ITU,
NAM, OAS, PAHO, UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO','563d67a362d60fabdec1e78d1701e828d9ef1fac1a5f682ebdfd745e6b27d43d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdf2949e4c153b3cd08d8b76dc2b49d8f0bf8086c0d619fe309957778a07d161',1986,'BD','Bangladesh','government',50,'Official name: People’s Republic of
Bangladesh , .
Type: Sublie under martial law since 24°
March 1982
Capital: Dhaka’
Political subdivisions: 4 divisions, 21 re-
gions, 64 districts, 495 thanas (rural town-
ships consisting of 4,472 unions or village
groupings) =
Legal system: martial law currently prevails
and civilian legal system suspended; tradi-
tionally based on English common law; con-
stitution adopted December 1972, amended
January 1975 to more authoritarian presi-
dential system; and changed by proclama-
tion in April 1977 to reflect Islamic charac- *
ter of nation; further change, by proclama-—
tion in December 1978, provided for the
appointment of the Prime Minister, Deputy :
Prime Minister,-and.other Cabinet-rank
ministers and defined the powers of the
President
National holiday: National Day, 26 March; :''
Victory Day, 16 December
Branches: constitution (currently suspended)
provides for uriicameral legislature (Parlia-" *
ment), strong President; independent judi- °
ciary; President has substantial control over
the judiciary
Government leaders: Lt. Gen. Hussain
Mohaminad ERSHAD, President (since De-
cember 1983) and Chief Martial Law Ad-
ministrator (since March 1982)
Suffrage: universal over age 18
Elections: some local elections held in De-: -
cember 1983; higher local elections held in
May 1985; presidential and parliamentary
elections may be held in 1986
Political parties and leaders: Bangladesh
Nationalist Party,’Begum Ziaur Rahman;
Awami League, Sheikh Hasina Wazed;
United People’s Party, Kazi-Zafar Ahmed; ‘
Democratic League, Khondakar Mushtaque
Ahmed; Muslim League, Khan A. Sabur;
Jatiya Samaitantrik Dal (National Socialist’: 7
Party), M. A. Jalil; Bangladesh Communist
Party (pro-Soviet), Mohammad Farhad; nu-
merous small parties; political activity
banned following March 1982 coup; ban ©
lifted in March 1984, reimposed in March
1985, and lifted again in January 1986 ©
Communists: 2,500 mémbers (est.) <=
Member of: ADB, Afro-Asian People’s Soli-
darity Organization, Colombo Plan, Com-
monwealth, ESCAP, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IDB—Islamic:
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IOC, IRC,
ITU, NAM, OIC, SAARC, UN, UNCTAD,
UNESCO, UPU, WHO, WFTU, WMO,
WTO','e3a284b1cf89a36ac8612f1d894747d8d442f80ce41f0264e2438c97b10c3d99','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ef6554d645738990337b8887ec64d2b1c9862b41899adf6173d51e2224b71ad',1986,'BB','Barbados','government',54,'Official name: Barbados:
Type: indepeddenpse sovereign state within
the Commonwealth recognizing Elizabeth II
as Chief of State
Capital: Bridgetown oe
Political subdivisions: u parishes and city -
of Bridgetown
Legal system: English common law;,.consti-
tution came into effect upon independence
in 1966; no judicial review of legislative acts;
has not accepted compulsory ICJ jurisdic:
tion
National holiday: Independence Day; 30
November
Branches: bicameral legislature
(Parliament—21-member appointed Senate
and 27-member elected House of Assembly); _
Cabinet headed by Prime Minister
Government leaders: H. Bernard ST.
JORN, Prime Minister (since March 1985);
Sir Hugh SPRINGER, Governor General
(since 1984)
Suffrage: universal over age 18 ,
Elections: House of Assembly members
have terms no longer than five years; last
general election held 18 June 1981
Political parties and leaders: Barbados La-
bor Party (BLP; leader not yet named
[former leader was Prime Minister Tom .-
Adams, who died in March 1985] ); Demo-
cratic Labor Party (DLP), Errol Barrow
Voting strength: (1981 election) BLP, :
52.4%; DLP, 46.8%; independent, negligi-
ble; House of Assembly seats—BLP 17, DLP
10. :
Communists: negligible
19;
Other political or pressure groups: People’s
Progressive Movement, Bobby Clarke;
People’s Pressure Movement, Eric Sealy;
Workers’ Party-of Barbados, Dr. George Bell
Member of: CARICOM, Commonwealth,
FAO, G-77, GATT, IADB, IBRD, ICAO,
IDB—Inter- American Development Bank,
IFAD, IFC, ILO; .IMF, IMO, INTELSAT,
INTERPOL, ISO, ITU, [WC—Interna-
tional Wheat Council, NAM, OAS, PAHO,
SELA, UN, UNESCO, UPU, WHO, WMO','ecfc949169c12f3fbe5c83a1808ac1811858877b8247a7320e3107ba07168094','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c60d7593358775d6dcc5666c63166db4a89272ffea8158b9c9936a62edc49fed',1986,'BE','Belgium','government',58,'Official name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: nine provinces; as of 1
October 1980, Wallonia and Flanders have
regional “subgovernments” with elected
regional councils and executive officials;
those regional authorities have limited pow-
ers over revenues and certain areas of eco-
nomic, urban, environmental, and housing
policy; Wallonia also has a separate Walloon
Cultural Council
Legal system: civil law system influenced by
English constitutional theory; constitution
adopted 1831, since amended; judicial re-
view of legislative acts; legal education at
four law schools; accepts compulsory IC]
jurisdiction, with reservations
National holiday: National Day, 21 July
Branches: executive branch consists of King
and Cabinet; Cabinet responsible to bicam-
eral parliament (Senate and Chamber of —
Representatives); independent judiciary;
coalition governments are usual
Government leaders: BAUDOUIN I, King
(since August 1950); Wilfried MARTENS,
Prime Minister (since 1979, with a nine-
month interruption in 1981)
Suffrage: universal over age 18
Elections: held at least once every four
years; last held 13 October 1985
Political parties and leaders: Flemish Social
Christian (CVP), Frank Swaelen, president;
Walloon Social Christian (PSC), Gerard
Deprez, president; Flemish Socialist (SP),
Karel van Miert, president; Walloon Social-
ist (PS), Guy Spitaels, president; Flemish
Liberal (PVV), Annemie Neyts, interim
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Oe Se Te mal
al
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
president; Walloon Liberal (PRL), Louis
Michel, president; Francophone Democratic
Front (FDF), Georges Clerfayt, president;
Volksunie (VU), Vic Anciaux, president;
Communist Party (PCB), Louis van Geyt,
president; Walloon Rally (RW), Fernand
Massart; Ecologist Party (ECOLO-
AGALEYV), loosely organized with no presi-
dent; Anti-Tax Party (UDRT-RAD), Robert
Hendrick and Thomias Delahaye, presidents:
Vlaams Blok (VB), president unknown |
Voting strength: (1985 election) 212-seat
Chamber of Representatives—-CVP 49 seats,
PS 35 seats, PVV 22 seats, SP 32 seats, PRL
24 seats, VU 16 seats, PSC''20 seats, FDF 3,
ECOLO-AGALEV 9 seats, UDRT-RAD 1
seat, VB 1
Communists: under 5,000 members (est.,
December 1985)
Other political or pressure groups: Christian
and Socialist Trade Unions; Federation of
Belgian Industries; numerous other associa-
tions representing bankers, manufacturers,
middle-class artisans, and the''legal and med-
ical professions; various organizations repre-
sent the cultural interests of Flanders and
Wallonia; various peace groups such as
Flemish Action Committee Against Nuclear
Weapons and Pax Christi: -
Member of: ADB, Benelux, BLEU, Council
of Europe; DAC, EC, ECE, ECOSOC, EIB, -
ELDO, EMS, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, iCO, IDA,
IDB—Inter-American Development Bank,
IEA, IFAD, IFC, ILO, International Lead
and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, [OOC;, IPU, ITC,
ITU, NATO, OAS (observer), OECD, UN,
UNESCO, UPU, WEU, WHO: WIPO,
WMO, WSG','2db7aeb52d3ba20ed3ca899b68d037e31690ce1c841415adecdf6db2d61de0f9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3696147926d79c151dfc32fe6396d93c608ede73934c579a549a4525244da179',1986,'BZ','Belize','government',62,'Official name: Belize
Type: parliamentary; independent state; a
member of the Commonwealth
Capital: Belmopan
Political subdivisions: 6 districts
Legal system: English law
Branches: bicameral legislature (National
Assembly—electoral redistricting in Octo- '' *
ber 1984 expanded House of Representa-
tives from 18 to 28 seats; eight-member ap-
pointed Senate; either house may choose its
speaker or president, respectively, from out-_
side its membership); Cabinet; judiciary _
Government leaders: Manuel A.
ESQUIVEL, Prime Minister (since Decem- _
ber 1984); Dr. Elmira Minita GORDON,
Governor General (since December 1981)
Suffrage: universal adult at age 18
Elections: parliamentary elections ne De-
cember 1984
Political parties and leaders: United Demo-
cratic Party (UDP), Manuel Esquivel, Curl —
Thompson, Dean Lindo; People’s United ”
Party (PUP), George Price ~
Voting strength: (December 1984) National :
Assembly—UDP 21 seats (25,785——54.1%), ©
PUP 7 seats (20,971—44.0%); before redis-
tricting, PUP held 13 seats, UDP 4 seats, and .
independents | seat
Communists: negligible
Other political or pressure groups: United
Workers Union, which is connected with
PUP
22
Member of: CARICOM, CDB, Common-
wealth, FAO, GATT, IBRD, IDA, IFAD,
IFC, ILO, IMF, G-77, ISO, ITU, UN,
UNESCO, UPU, WHO, WMO.','15f0015bca208a750aa6449203729d0653859f0a1ea158cc1689a4db50603d87','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ce56ea8e74e64f4e8d93a2ef35327a396eecabadc07d2b825d66a27f43ec4dd',1986,'BJ','Benin','government',66,'Official name: People’s Republic of Benin
Type: Soviet-modeled civilian government. ;
Capital: Porto-Novo (official), Cotonou (de
facto)
Political subdivisions: 6 provinces, 84 dis
tricts : .
Legal system: based on French civil law.and.«,
customary law; legal education generally _
obtained in France; has not accepted com-..,.. >
pulsory ICJ jurisdiction ,
National holiday: 30 November
Branches: Revolutionary National Assem-
bly, National Executive Council mee
Government leader: Brig. Gen. Mathieu “.~:. >
KEREKOU, President and inet: of State: vast
(since 1972) o ag kes
Suffrage: universal adult
Elections: National Assembly elections were
held in November 1979; Assembly then for-: «.,
mally elected Kérékou President in Febru-_
ary 1980
Political ya ee: People’ s Revlitonaivs : 7 ;
Party ‘of Benin (PRPB) is sole party
Communists: PRPB espouses Sg
Leninism . on
Member of: AEDB, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, G-77, GATT, «°°
IBRD, ICAO, ICO, IDA, IFAD, ILO, IMF,
IMO, INTERPOL, ITU, NAM, Niger River: °
Commission, OAU, OCAM, UN, UNESCO,
UPU, WFTU, WHO, WIPO; WMO, WTO.
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Benin (continued)
Official name: Federal Republic of Nigeria
Type: military government since 31 Decem-
ber 1983
Capital: Lagos —
Political subdivisions: 19 states, headed by
appointed military governors
Legal system: based on English common
law and Islamic and tribal law
National holiday: Independence Day, 1 Oc-
tober
Branches: Armed Forces Ruling Council;
National Council of Ministers and National
Council of States; judiciary headed by Su-
preme Court
Government leader: Ibrahim BABAN-
GIDA, President and Commander in Chief
of Armed Forces (since August 1985)
Suffrage: none
.Elections: last national elections under civil-
ian rule held August-September 1983
Political parties and leaders: all political
parties banned after 31 December 1983
Communists: the pro-Communist under-
ground comprises a fraction of the small
Nigerian left; leftist leaders are prominent in
the country’s central labor organization but
have little influence on government
185
Member of: A[DB, APC, Commonwealth,
ECA, ECOWAS, FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICO, IDA, IFAD, IFC, ILO,
IMO, IMF, INTELSAT, INTERPOL, IRC,
ISO, ITC, ITU, !''WC—International Wheat
Council, Lake Chad Basin Commission,
Niger River Commission, NAM, OAU;
OPEC, UN, UNESCO, UPU, WHO, WMO,
WTO','ebfffbe99045bb6b38dae8817ada88297c55b06bdac6c6ba267bd732d02df099','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d8c0b01cb8f0a7d74c097a2dc82889efb2f41d935a9329e38d5a29d9e725e39',1986,'BM','Bermuda','government',69,'Official name: Bermuda.
Type: British secant territory
Cantal: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) ap: :-.
pointed by governor, led by government °
leader; bicameral legislature with an ap- .-.
pointed Senate and a 40-member directly .
elected House of Assembly; Supreme:Court -
Government leaders: Viscount
DUNROSSIL, Governor (since 1983); John’ -
William David SWAN, Premier erence 1982)
Suffrage: universal adult over age 21
Elections: at least once every che years; last
general election October 1985
Political parties and leaders: United Ber-
muda Party (UBP), John W. D. Swan; Pro-
gressive Labor Party (PI:P); Frederick
Wade; National Liberal Party, -Gilbert
Darrell; PLP Members for phenge (infor- .
mal)
Voting strength: 1985 elections—UBP 31
House of Assembly seats; ane, 7; National
Liberal Party, 2 :
Communists: négligible
Other political or pressure groups:
Bermuda Industrial Union (BIU), headed by
Ottiwell Simmons .
Member of: INTERPOL, WHO','ca07894c12ba0272a0668e2f370ef59ed9da971cb43eab135a341e7db3e48b07','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4e5a9cabe5628c79540dc433ef3eca53e0cf4407a2b142eca62221c21e8bf32',1986,'BT','Bhutan','government',73,'Official name: Kingdom of Bhutan ;
Type: monarchy; special treaty relationship,
with India| :
Capital: Thiniphi Paro (administrative |
capital)
Political subdivisions: 4 regions (east, cen-
tral, west, south), further divided into 18 .
districts
Legal system: based on-Indian law and .
English common law; in 1907-the monarch
assumed full power—no written constitution
or bill of rights; in 1968-69 .a separate judi-
ciary-that provided for local, district, and
national courts with appellate jurisdiction
was established; has not accepted compul-
sory IC] jurisdiction
National holiday: 17 December ._
Branches: appointed ministers; 150-member
indirectly elected National Assembly con-
sisting of 110 village elders or heads of fam-
ily, 10 monastic representatives; ‘and 30 se-"
nior government administrators
Government leader: Jigme Singye
WANGCHUCK, King (since 1974),
Suffrage: each family has one-vote :
Elections: popular elections on village level
held every three years
Political parties: no legal parties _
Communists: no overt Communist presence
Other political or pressure groups: Buddhist -
clergy, Indian merchant community, ethnic
Nepalese organizations
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, IBRD, IDA, IFAD, IMF, NAM, ..
SAARC, UNESCO, UPU, UN, WHO','c2b24368ce8a9036b701f9356b7e56b191d650d77fde6ca43249127e47737436','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26b1ee249ace6be757d3c529c373d9fe658e7b6b36935cc4f1a5f3e29a03045e',1986,'BW','Botswana','government',77,'Official name: Republic of Botswana
Type: parliamentary republic; independent
member of Commonwealth
Capital: Gaborone
Political subdivisions: 10 administrative
districts pee
Legal system: based on Roman-Dutch law
and local customary law; constitution came
into effect 1966; judicial review limited to
matters of interpretation; has not accepted
compulsory ICJ jurisdiction
National holiday: Botswana Day, 30 Sep-
tember
Branches: executive—President appoints
and presides over the Cabinet, which is re-
sponsible to National Assembly; bicameral
legislature (National Assembly with 34 pop-
ularly elected members and four members
elected by the 34 representatives; House of
Chiefs with deliberative powers only); judi-
cial—local courts administer customary law,
High Court and subordinate courts have
criminal jurisdiction over all residents,
Court of Appeal has appellate jurisdiction
Government leader: Dr. Quett K. J.
MASIRE, President (since July 1980)
Suffrage: universal adult at age 21
Elections: general elections held 8 Septem-
ber 1984 ; :
Political parties and leaders: Botswana
Democratic Party (BDP), Quett Masire;
Botswana National Front (BNF), Kenneth
Koma; Botswana People’s Party (BPP);
Botswana Independence Party (BIP),
Motsamai Mpho
Voting strength: (September 1984 election)
Legislative Assembly—BDP, 28 seats; BNF,
5 seats; BPP, 1 seat j
Communists: no known Communist organi-
zation; Koma of BNF has long history of
Communist contacts
Member of: A{DB, Commonwealth, FAO,
G-77, GATT (de facto), IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, INTERPOL, ITU,
NAM, OAU, SADCC, UN, UNESCO, UPU,
WHO, WMO
Official name: British Indian Ocean Terri-
tory
Type: colony administered by United King-
dom; control disputed by Mauritius
Capital: none
Government leader: William N. WENBEN-
SMITH, Commissioner (since 1982; resident
in UK); D. H. DOBLE, administrator (since
1985; resident in UK)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','506c636a374cd881e274e8156bfafe4ca344950cf29b442acb5a8ed62a0f4307','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44b54a7878bbe4e08c0923ca250ce3739a5a041b52da8c18605c0953745d963d',1986,'IO','British Indian Ocean Territory','government',79,'(continued)
Official name: British Virgin Islands
Type: British dependent territory
32
Capital: Road Town on the island of Tortola .
Political subdivisions: 9 electoral districts
Legal system: English law; justice is admin-
istered by the Eastern Caribbean Supreme -
Court; there is a resident buisne judge on the
islands: -. i.
National holiday: Territory Day, 1 July
Branches: Executive Council (cabinet) con--:
sists of the governor as chairman, four minis-
ters of the legislature, and an ex officio mem-
ber who is the attorney general; Legislative
Council consists of the Speaker (elected from
outside the Council), nine elected members,
and an ex officio member who is the attorney
general
Government leaders: David Robert:
BARWICK, Governor (since 1982); Cyril B.
ROMNEY, Chief Minister isiice November
1983)
Suffrage: universal adult over 18
Elections: at least once every five years; last
general election held November 1983
Political parties and leaders: United Party
(UP), Conrad Maduro; Virgin Islands Party
(VIP), H. Lavity Stoutt; Independent, C. B.
Romney
Voting strength: 1983 elections—UP 4.
seats; VIP 4 seats; Independents.1 seat
Communists: probably none
Member of: Commonwealth .
Official name: Staté-of Brunei Darussalarii: --
Type: became independent on 1 January
1984; constitutional sultanate
Capital: Bandar Seri Begawan
National holiday: Natiorial Day, 23 Febru-
ary : aX :
Political subdivisions: four admunictratives: ;
districts -
Legal system: based on Islamic law; consti .
tution plomvlened by the Snliany in 1959
Branches: chief af state is sultan dased 2 fl
appointed Privy Council), who appoints Ex-
ecutive Council and Legislative Council
Government leader: Sir HASSANAL
Bolkiah, Sultan and Prime Minister (since
August 1968)
Suffrage: universal at 21; three-tiered sys-
tem of indirect elections; popular vote cast
for lowest level (district councilors)
Elections: last elections—March 1965; fur-
ther elections postponed indefinitely
Political parties and leaders: Brunei Na-
tional Democratic Party (the first legal polit-
ical party; it was established on 18 Septem-
ber 1985), Abdul Latif bin Abdul Hamid,
Chairman; Brunei National United Party
(established on 4 February 1986), Anak
Hasanuddin, chairman
Communists: probably none
Member of: ASEAN, ESCAP (associate
member), IMO, INTERPOL, OIC, UN
Official name: People’s Republic of Bulgaria
Type: Communist state -
Capital: Sofia
Political subdivisions: 27 okrugs (districts);
capital city of Sofia has equivalent status
Legal system: based on civil law. system, -
with Soviet law influence; new constitution
adopted in 1971; judicial review of legisla-
tive acts in the State Council; legal education
at University of Sofia; has accepted compul-
sory ICJ jurisdiction
National holiday: National Liberation Day,
9 September
Branches: legislative (National Assembly);
judiciary, Supreme Court
Government leaders: Todor Khristov
ZHIVKOV, Chairman, State Council (Presi-
dent and Chief of State; since July 1971);
Georgi Ivanov ATANASOV, Chairman,
Council of Ministers (Premier, since March
1986)
Suffrage: universal and compulsory over age
18
Elections: held every five years for National
Assembly; last election held on 7 June 1981;
99.96% of the electorate voted
Political parties and leaders; Bulgarian
Communist Party, Todor Zhivkov, General.
Secretary; Bulgarian National Agrarian _
Union, a puppet party,.Petur Tanchev, sec-
retary of Permanent Board
Communists: 825,811 party members (April
1981}
Mass organizations and front groups:
Fatherland Front, Dimitrov Communist
Youth Union, Central Council of Trade
Unions, National Committee for Defense of
Peace, Union of Fighters Against Fascism
and Capitalism, Committee of Bulgarian
Women, All-National Committee for
Bulgarian-Soviet Friendship
Member of: CEMA, FAO, IAEA, ICAO,
ILO, International Lead and Zinc Study
Group, IMO, TIPU, ITC, ITU, IWC—Inter-
national Wheat Council, UN, UNESCO, _
UPU, WFTU, WHO, WIPO, WMO, WTO;
Warsaw Pact, International Organization of
Journalists, International Medical Associa-
tion, International Radio and Television
Organization
Official name: Burkina Faso
Type: military; éstablished by: coup on 4
August 1983
Capital: Oitagadenadu
Political subdivisions: 30 provinces, 250
departments:
Legal system: based on French civil law
systerh and customary law
National holiday: Independence Day, 4
August
Branches: President is an army officer; mili-
tary council of unknown number; -
21-member military and civilian Cabinet;
judiciary
Government leaders: Cdr. Thomas
SANKARBA, President (since August 1983)
Suffrage: universal for adults
Elections: political process suspended; no:
talk of returning.to constitutional rule
Political parties and leaders: all political: -.-
parties banned following November 1980
coup
Communists: small Communist party front,
group; some sympathizers:
Other political or pressure groups: commit-
tees for the defense of the revolution,
watchdog/ political action groups.
established by,current regime throughout.
the country in both organizations and com-
munities
Member of: A[DB, CEAO, EAMA, ECA,
EIB (associate), Entente, FAO, GATT, G-77,
IBRD, ICAO, IDA, IDB—Islamic Develop-
ment Bank, IFAD; IFC, ILO, IMF,
INTELSAT, INTERPOL, IPU, IRC, ITU,
NAM,; Niger River Commission, OAU,
OCAM, OIC, UN, UNESCO, UPU, WCL,
WFTU, WHO, WIPO, WMO, WTO
36
Official name: Socialist Republic of the
Union of Burma
Type: republic under 1974 constitution
Capital: Rangoon
Political subdivisions: seven divisions (pre-
dominantly Burman population) and seven
states (based on ethnic minorities), subdi-
vided into townships, village-tracts (rural),
and wards (urban)
Legal system: People’s Justice system and
People’s Courts instituted under 1974 consti-
tution; legal education at Universities of
Rangoon and Mandalay; has not accepted
compulsory IC] jurisdiction
National holiday: Independence Day, 4
January
Branches: Council of State-rules through a
Council of Ministers; National Assembly
(Pyithu Hluttaw or People’s Congress) has
legislative power
Government leader: U SAN YU, President
and Chairman of Council of State (since
November 1981)
Suffrage: universal over age 18
Elections: National Assembly and local
People’s Councils elected in 1985
Political parties and leaders: government-
sponsored Burma Socialist Program Party
only legal party; U Ne Win, party chairman
Communists: est. 15,000 (primarily as an
insurgent group on the northeast frontier) ,
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 - CIA-RDP08-00534R000100170001-4
Burma (continued)
Other political or pressure groups: Kachin
Independence Army; Karen Nationalist
Union, several Shan factions (all insurgent
groups) ,
Member of: ADB, Colombo Plan, ESCAP,
FAO, G- 77, GATT, IAEA, IBRD, ICAO,
IDA, IFC, THO, ILO, IMF, IMO, _
INTERPOL, IRC, ITU, UN, UNESCO,
UPU, WHO, WMO','c41a860e9473b4749558681055366084b1a07ea412e166ed16e5dcf226527023','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5db89b2ea1b04cb883a61466162c015b9713cf9b21e704063042cdb94d1b650d',1986,'BI','Burundi','government',85,'Official name: Republic of Burundi |
Type: republic; presidential Watem:.
‘Capital: Bujumbura
Political subdivisions: 15 provinces, subdi-
vided into arrondissements and communes
according to a 1982 redistricting ;
Legal system: based on German and‘French
civil codes and customary law; has not ac-
cepted compulsory ICJ jurisdiction |
National holiday: Independence Day, 1 July
Branches: executive (President and Cabi-
net); judicial; legislature (National Assembly)
reestablished in 1982
Government leader: Col. Jean-Baptiste a
BAGAZA, President and Head of State C
(since 1976)
Suffrage: universal adult |
Elections: new constitution approved by
national referendum in November 1981;
election to National Assembly held i in Octo-
ber 1982 ©
Political parties and leaders: National Party
of Unity and Progress(UPRONA), a |
Tutsi-led party, declared sole legitimate ~
party in 1966; second national party con-
gress held in 1984; Col. Jean-Baptiste Bagaza
confirmed as party president for five-year:
term
Communists: no Communist party
Member of: AADB, EAMA, ECA, FAO,
G-77, GATT, IBRD, ICAO, ICO, IDA,
IFAD, IFC, ILO, IMF, INTERPOL, ITU,
NAM, OAU, UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO_','fd651e143d438be63156458b04dfeb5cd7c846063358be09611c33765d97d183','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c5ac8c999bf166531c37cc862004ec40777417f8a906b443333ad42cd5f273a',1986,'KH','Cambodia','government',89,'Official name: Coalition Government of _ -
Democratic Cambodia (CGDK; composed
of three resistance groups deployed along
the Thai border); People’s Republic of
Cambodia (PRK; pro-Vietnamese, in Phnom
Penh)
Type: CGDK is nationalist coalition of one
Communist and two non-Communist fac-
tions; PRK is Communist
Capital: Phnom Penh
Political subdivisions: 19 provinces
Legal system: Judicial Committee chosen by
People’s Representative Assembly in Demo-
cratic Cambodia; no information for PRK
National holiday: 17 April for both regimes
Branches: Cabinet, State Presidium, and
some form of People’s Representative As-
sembly in Democratic Cambodia; People’s
Revolutionary Council, various ministries,
and a ‘‘National Congress” held in early
1979 and a second held in September 1979
in PRK
Government leaders: CGDK—Prince_.
NORODOM SIHANOUK, President (since
July 1982); SON SANN, Prime Minister
(since July 1982); KHIEU SAMPHAN, Vice
President (since July 1982); PRK -HENG.
SAMRIN, President (since January 1979);
HUN SEN, Foreign Minister sans January
1979)
Suffrage: universal over age 18
Political parties and leaders: CGDK—an
umbrella organization for three resistance
groups including Democratic Kampuchea
under Son Sen, Khmer People’s National
Liberation Front (KPNLF) under Son Sann,
and National United Front for an Independ-
ent, Neutral, Peaceful, and Cooperative
Cambodia under Prince Norodom .
Sihanouk; PRK Cambodian Peoples Revo:
lutionary Party, the Communist party in-.
stalled by Vietnam in 1979, and Cambodian
United Front for National Construction and
Defense (KUFNCD)
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, GATT (de facto), IAEA, IBRD,
ICAO, IDA, ILO, IMF, IMO, INTERPOL,
IRC, ITU, Mekong Committee (inactive),
NAM, UN, UNE SCO, UPU, WFTU,
40
WHO, WMO, WTO for CGDK; none for
PRK','9fe7fba99cb7c6d644bf69f2f9ac24f335e01fceaf05e8e7c1cfb3513cd9f60c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae66cd2d09968606a5612d1b66720d9cd64b7b93fc23d19043f62e575bf8869a',1986,'CM','Cameroon','government',92,'Official name: Republic of Cameroon
Type: unitary republic; one-party presiden-
tial regime
Capital: Yaoundé
Political subdivisions: 10 provinces divided
into departments, arrondissements, districts
Legal system: based on French civil law
system, with common law influence; unitary «''
constitution adopted 1972; judicial review ‘‘
by Supreme Court, when a question of con-
stitutionality is referred to it by the Presi-
dent; has not accepted compulsory ICJ juris-
diction
National holiday: National Day, 20 May |
Branches: executive (President), legislative
(National Assembly), and judicial (Supreme
Court) “
Government leader: Paul BIYA, President
(since November 1982)
Suffrage: universal over age 21
Elections: parliamentary elections held May
1983; presidential-elections held January |
1984
Political parties and leaders: Cameroon
People’s Democratic Movement (known as
the Cameroon People’s National Union dur-
ing 1966-85), Paul Biya, president
Communists: no Communist party or signif-
icant number of sympathizers
Other political or pressure groups:
Cameroon People’s Union (UPC), remains
an illegal group with its factional leaders in
exile oe
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Cameroon (continued)
Member of: AEBD, EAMA, ECA, EIB (asso-
ciate), FAO, G-77, GATT, IAEA, IBRD,
ICAC, ICAO, ICO, IDA; IDB—Islamic De-
velopment Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL; IPU, ISO, :
ITU, Lake Chad Basin Commission, NAM;
Niger River Commission, OAU, OIC,
UDEAG, UN, UNESCO, UPU, WSO; WI
PO, MD, wie
Pecdoiny :
GDP: $7.3 billion (1983- 84), about $800 per
capita; average annual growth rate, 6.5%
(1984); average inflation rate, 15% (1984)
Natural resources: oil, natural gas, s, baunite,
iron ore, timber
Agriculture: commercial and food crops—
coffee, cocoa, timber, cotton,.rubber, ba-
nanas, peanuts; palm oil and palm kernels; -
root starches, livestock, millet, sorghum, and
rice
Fishing: 23, 000. metic tons (1982 i 83).
Major industries: crude oil production! ,
small aluminum plant, food processing, light
consumer goods PaCS sawmills
Electric power: 586,600 kw capacity (1985);
2.241 billion kWh produced (1985), 229 -
kWh per capita
Exports: $855.2 million (f.0.b., 1984); crude
oil, cocoa, coffee,:timber, aluminum,;cotton,
natural rubber, bananas, péanuts, tobacco;
tea, mineral products, food; alcohol, metal:
and metal products, textiles, wood products
Imports: $1.101 billion (f.0.b., 1984); con-
sumer goods, machinery, transport equip-
ment, alumina for refining, petroleum prod-
ucts, food, beverages,.electrical equipment,
chemical products
Major trade partners: ‘most tradé with
France, other EC countries, and the US
Budget: (1984 est.) revenues $1,777 million,
current expenditures $1,696 million
Monetary conversion rate: 417.4 Commu-
nauté Financiére Africaine francs=US$1-
(October 1983)
Declassified and Approved For Release 2012/08/29
Fiscal year: 1. July-30 June','0588f0ad1cbe6b22b6cd67f2ada6882c99c9b9f029761c531b5444fe1d18caee','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f043dfc44369624176f62e9a9ef1bb4182c32350a82edd8031b102e6517935c8',1986,'CA','Canada','government',94,'Offical name: Canada -
Type: federal state recognizing Elizabeth I
as sovereign >
Capital: Ottawa
Political subdivisions: 10 provinces and 2
territories
Legal system: based on English common ''
law, except in Quebec, where civil law sys:
tem based on French law prevails: constitu-
tion as of 1982 (formerly British North -
America Act of 1867 and various amend-
ments); accepts compulsory IC] jurisdiction,
with reservations
National holiday: Canada Day, lJ uly
Branches: federal executive power vested in
cabinet collectively responsible to House of
Commons and headed by Prime Minister;
federal legislative authority resides in ‘Parlia-
ment (282 seats) consisting of Queen repre-
sented by Governor General, Senate, and
House of Commons; judges appointed by
Governor General on the advice of the gov-
ernment; Supreme Court is highest tribunal
Government leaders: Brian MULRONEY, :
Prime Minister (since September 1984), -
Jeanne SAUVE, Governor General (since -
May 1984)
Suffrage: universal over age 18
Elections: legal limit of five years but in
practice usually held within four years; last
election September 1984; 75% voter turnout
Political parties and leaders: Liberal, John
Turner; Progressive Conservative, Brian
Mulroney; New Democratic, Edward _
Broadbent
Voting strength: (1984 election) Progressive
Conservative, 50%; Liberal, 28%; New
Democratic Party, 19%; parliamentary seats
as of December 1984—Progressive Conser-
vative (21 1), Liberal. {40), New Democratic .
Party (30), independent (1)
Communists: annie 2,000 oe
Member of: ADB, Colombo Plan, Common-
wealth, DAC, FAO, GATT, IAEA, IBRD,
ICAO, ICES, ICO, ICRC, IDA, 1DB—Inter-
American Development Bank, IEA, IFAD; ''
IFC, THO, ILO, International Lead and ~’
Zinc Study Group, IMF, IMO, INTELSAT,
INTERPOL, IPU, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC—
International Wheat Council; NATO, OAS
(observer), OECD, PAHO, UN, UNCTAD,
UNESCO, UPU, WHO, WIE WMO,
WSG.
Official name: Republic of Cape Verde
Type: republic
Capital: Praia
Political subdivisions: 14 administrative
districts
Legal system: based on constitution
National holiday: Independence Day, 5 July
Branches: 56-member National People’s
Assembly; the official party is the supreme
political organization
Government leaders: Aristides PEREIRA,
President (since July 1975); Pedro PIRES,
Prime Minister (since July 1975)
Suffrage: universal over age 15
Elections: National Assembly election held
December 1985, the second since inde-
pendence
Political parties and leaders: only legal
party, African Party for Independence of
Cape Verde (PAICV), led by Aristides Per-
eira, secretary general; PAICV established
in January 1981 to replace the former ruling
party in both Cape Verde and Guinea:
Bissau, the African Party for the Indepen-
dence of Guinea-Bissau and Cape Verde
(PAIGC), in protest of the November 1980
coup in Guinea-Bissau
Communists: a few Communists and some
sympathizers
Member of: FAO, G-77, GATT (de facto),
IBRD, ICAO, IDA, IFAD, ILO, IMF, IMO,
IPU, ITU, NAM, OAU, UN, UNESCO,
UPU, WHO, WMO
Official name: Cayman Islands’ ’
Type: British dependent territory
Capital: George Town, on the island o of
Grand Cayman
Political subdivisions: 6 electoral districts. -
Legal system: British ¢ cornmon law and local
statutes
National holiday: Constitution Day: 8J uly.
Branches: executive—Governor and Execu-
tive Council (3 appointed “official
members” and 4 elected “‘meinbers” chosen
by the Legislative Assembly from its elected
members); legislative—unicarheral Legisla- ~
tive Assembly (12 elected members and3 ~
appointed by Governor); judicial—Sum- -
mary Court, Grand Court, Cayman Islands
Court of Appeal, Her Majesty''s Privy Coun-
cil
Government leader:.George Peter LLOYD,
Governor (since 1982); also serves as presi-
dent of the Legislative Assembly
Suffrage: universal adult over age 18
Elections: elections held every four years
Political parties and leaders: no formal po-
litical parties
Communists: none
Member of: Com monwealth','8033f94e52f1f781c40fdfdc0705c95241fdd01215279feaf6f7d1196e77e5f5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d24d3f03a37e1eba0060c1b7540b6628a8a782566105d15793ddfc9577eca3f8',1986,'TD','Chad','government',102,'Official name: Republic of Chad
Type: republic
Capital: N''Djamena
Political subdivisions: 14 prefectures, 54
subprefectures, 27 administrative posts, 9
municipalities
Legal system: based on French civil law. .
system and Chadian customary law; consti-
tution adopted in 1962; constitution sus-
pended and National Assembly dissolved in
April 1975; Fundamental Act, a quasi-
constitution decreed in October 1982, pro-
vides juridical framework whereby decrees
are promulgated by the president; judicial
review of legislative acts in theory a power
of the Supreme Court; has not accepted
compulsory IC] jurisdiction :
National holiday: Independence Day, 11
August
Branches: presidency; Council of Ministers;
National Consultative Council, Supreme
Court and several lower courts
Government leaders: Hissein HABRE, Pres-
ident (since June 1982)
Suffrage: universal over age 18
Elections: none planned
Political parties and leaders: National
Union for Independence and Revolution
(UNIR) established June 1984 with Habré as
president; numerous dissident groups
Communists: no front organizations or un-
derground party; probably a few Commu-
nists and some sympathizers
Other political or pressure groups: the de-
velopment of a stable government continues
48
to be hampered by prolonged tribal and re-
gional antagonisms; ex-President Goukouni |
Weddeye heads a rebel government, with
Libyan backing, that occupies the northern
third of Chad ;
Member of: A{DB, CEAO, Conference of
East and Central African States, EAMA,
ECA, EC (associate), FAO, G-77, GATT,
IBRD, ICAC, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, ILO, IMF,
INTELSAT, INTERPOL, ITU, Lake Chad
Basin Commission, NAM, OAU, OCAM,
OIC, UN, UNESCO, UPU, WHO, WIPO,
WMO','eb4721ed0be2bf559b5293350210e97a87bf35e6c0afed4451de7e6cd7c87fd0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a697284e27a51abfca8b46f251ab5f69cac098d491f29c9de11bd6659a3bd3da',1986,'CN','China','government',109,'Official name: People’s Republic of China ‘
Type: Communist state; real authority lies
with Communist Party’s Politburo; the Na- -
tional People’s Congress, in theory the high- °
est organ of government, ‘ustially ratifies the °
party''s programs; the State Council actually
directs the government
Cia Beijing
Political suhmioisans: 22 provinces, “oma a
trally governed municipalities, 5 autono- _
mous regions i i
Legal system: a complex amalgam of cus-
tom and statute, largely criminal: little os- |
tensible development of uniform code of
administrative and civil law; highest judicial
organ is Supreme People’ s Court, which re-
views lower court decisions; laws and''‘legal
procedure subordinate to priorities of party
policy;-regime has attempted to write civil
and Communist codes; new legal codes in ©
effect since] January 1980; party and state
constitutions révised in September and No- ~ |
vember 1982, respectively; continuing ef-
forts are being made toi improve’ ‘civil and”
commercial law
National holiday: National Day, 1 October
51
Branches: control is exercised by Chinese”
Communist Party, through State Council,
which supervises ministries, commissions,
bureaus, etc., all technically under the
Standing Conirnitse of the National
People’s Congress
Government leaders: ZHAO Ziyang, Pre-
mier of State Council (since September
1980); LI Xiannian, President (since June
1983); PENG Zhen, Chairman of NPC
Standing Committee (since June 1983)
Suffrage: universal over age 18
Elections: elections held for People’s Con-
gress representatives at county level
Political parties and leaders: Chinese Com-
munist Party (CCP), headed by Hu Yaobang
as General Secretary of Central Committee ~
Communists: about 42 million party mem-
bers in 1984
Other political or pressure groups: such op-
position as exists consists of loose coalitions
that vary by issue rather than organized
groups
Member of: ESCAP, FAO, IAEA, IBRD,
ICAO, IDA, IFAD; IFC, THO, ILO, IMF, ”
IMO, INTELSAT, ITU, Multifiber Arrange-
ment, UN, UNESCO, UPU, WFTU, WHO,
WIPO, WMO
Official name: Japan
Type: constitutional monarchy
Capital: Tokyo’
Political subdivisions: 47 prefectures -
Legal system: civil law system with English-
American influence; constitution promul-
gated in 1946; judicial review of legislative
acts in the Supreme Court; accepts compul-
sory ICJ juried chon with reservations
National hanaiag Birthday of the Emperor,
29 April’
Branches: Emperor is merely symbol of.
state; executive power is vested in Cabinet
appointed by the Prime Minister, chosen by
the lower house of the bicameral, elective
legislature—Diet (House of Councilors, ©
House of Representatives); judiciary i is inde-
pendent
Government leaders: HIROHITO, Em-
peror (since December 1926); Yasuhiro
NAKASONE, Prime Minister (since Novem-
ber 1982)
Suiaue: universal over age 20
Elections: general elections held every four -
years or upon dissolution of lower house,
triennially for half of upper house
Political parties and leaders: Liberal Demo-
cratic Party (LDP), Y. Nakasone, president;
Japan Socialist Party (JSP), M. Ishibashi,
chairman; Democratic Socialist Party (DSP),
S. Tsukamoto, chairman; Japan Communist
Party (JCP), T. Fuwa, Presidium chairman;
Clean Government Party (CGP), Y. Takeiri,
chairman; New Liberal Club (NLC),
Y. Kono; Social Democratic Bederenen
(SDF), S. Eda
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Voting strength: (1983 election) Lower
House—45.8% LDP, 19.5% JSP, 10.1% - °
CGP, 9.3% JCP, 7.3% DSP, 2.4% NLC, 0.7%
SDF, 5% independents and minor parties;
Upper House—35.8% LDP, 24. 3% JSP,
10.5% JCP, 7.8% CGP, 5.7% DSP, 1.2%
NLC, 11.8% independents and iminor. .
parties i
Communists: approximately 470,000 regis-
tered Communist Party members
Member of: ADB, ASPAC, Colombo Plan,
DAC, ESCAP, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB— . ;
Inter-American Development Bank, IEA,
IFAD, IFC, IHO, ILO, International Lead
and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ISO,
ITC, ITU, IWC—International Whaling
Commission, IWC—International Wheat,
Council, OECD, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO, WSG
Official name: Socialist Republic of Vietnam
Type: Communist state
Capital: Hanoi
Political subdivisions: 40 provinces, under
central government control
Legal system: based on Communist legal’
theory and French civil law system
National holiday: 2 September
Branches: bicameral legislature (Council of
State, National Assembly); highly central-
ized executive nominally subordinate to Na-''
tional Assembly
Government leaders: LE DUAN, Secretary
General, Communist Party (since December
1976); TRUONG CHINH, Chairman,
Council of State (since July 1981)
Suffrage: universal over age 18
Elections: pro forma elections held for na-
tional and local assemblies; last election for
National Assembly held on 25 April 1976 .
Political parties and leaders: Vietnam Com-
munist Party (VCP), formerly known as the
Vietnam Workers Party, headed by Le
Duan
Communists: probably more than l:million
Member of: ADB, CEMA, Colombo Plan,
ESCAP, ‘FAO, G-77; IAEA, IBRD, ICAO;
IDA, IFAD, IFC, ILO: IMF, INTELSAT,
IRC, ITU, Mekong Committee, NAM, UN,
UNDP, UNESCO, UNICEF, UPU, WFTU,
WHO, WIPO, WMO, WTO’','1c4e3601bb9f2cc0a3d69a629a58d17a3e7ca279c7e106c888b34cfca6daa33c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05404e00ccdc44d5a6240497b273024d859ad5c9a5fca6e65b7b60a365548e77',1986,'CX','Christmas Island','government',113,'Official name: Territory of Christmas Island
- Type: Australian territory
Capital: settlement on Flying Fish Cove
(principal settlement)
Legal system: Australian territory since 10:
October 1958; administrator appointed by
Governor General of Australia; Supreme
Court: legislative, judicial, and administra-
tive system regulated by the Christmas Is-
land Act of 1958
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Branches: Advisory Council advises
appointed administrator
Government leader: T. F. PATERSON, Ad-
ministrator
Communists: none
Official name: Republic of Colombia
Type: republic; executive branch dominates
government structure
Capital: Bogota
Political subdivisions: 22 departments, 5
intendancies, 5 commissariats, Bogota. Spe-
cial District
Legal system: based on Spanish law; reli-
gious courts regulate marriage and divorce;
constitution decreed in 1886, with amend-
ments codified in 1946 and 1968; judicial
review of legislative acts in the Supreme
Court; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Independence Day, 20
July
Branches: President, bicameral legislature
(Parliament—Senate, House of Representa-
tives), judiciary
Government leader: Belisario BETANCUR
Cuartas, President (since August 1982); term
ends 10 August 1986
Suffrage: age 18 and over
Elections: every fourth year; presidential
election held May 1986; congressional elec-
tion held March 1986; municipal and de-
partmental elections every two years, last
held 1986
Political parties and leaders: Liberal Party,
Virgilio Barco; main dissident faction is
headed by Luis Carlos Galan; Conservative
Party—Alvaro Gémez Hurtado and Misael
Pastrana Borrero head the two principal
wings united behind current President
Belisario Betancur, who leads a small fac-
tion; Communist Party (PCC), Gilberto
Vieira White; Communist Party /Marxist-
Leninist (PCC/ML), Maoist orientation
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Colombia (continued)
Voting strength: (1982 presidential election)
Belisario Betancur 46.8%, Alfonso Lopéz ..
“Michelsen 40.7%, Luis Carlos Galan 11.1%,
Gerardo Molina 1. 2%, other 1. 2%; 49%
abstention ‘
Communists: 18,000 members est., includ- -
ing Communist Party Youth ereanizalion
(JJUCO)
Other political or pressure groups: Commu-
nist Party (PCC), Gilberto Vieira White;
PCC/ML, Chinese Line Comniunist Party;
Revolutionary Armed Forces of Colombia’s
Patriotic Union Party (FARC-UP)
Member of: FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAC, ICAO,ICO, IDA,
IDB—Inter-American Development Bank,
IFAD, IFC, IHO, ILO, IMF, IMO, -
INTELSAT, INTERPOL, IRC; ISO, ITU,
LAIA and Andean Sub-Regional Group,
NAM, OAS, PAHO, SELA, UN, UNESCO,
UPEB, UPU, WFTU, WHO, WIPO, WMO,
WSG, WTO','50c21ec29e8183a12f6d5cbd3fb4e09a1dfb05c57b8cf514bdb936a97ae03397','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c539987221ec39767c4c25e316708a8700b4fe78530312322733dd928deaa6ef',1986,'KM','Comoros','government',117,'Official name: Federal ‘Slaniite Republic oe
the Comoros
Type: three of.the four islands compose an. .
independent republic, following local
government''s unilateral declaration of inde-
pendence from France in July, 1975; the
other island, Mayotte, disallowed declara-
tion and is now a French territorial commu-
nity but is claimed by the Comoros
Capital: Moroni
Political subdivisions: the three main islands
are organized into seven regions ,
Legal system: French and Muslim law ina
new consolidated code
Branches: presidency; 38-member legisla- . .
ture (Federal Assembly)
Government leader: Ahmed ABDALLAH
ABDEREMANE, President (since October
1978) :
Suffrage: universal adult
Hachipia: Abdallah Abaveaaus won 1984
presidential election with 99% majority; -
Federal Assembly elected in March 1982
Political party: sole legal political party is
Comoran Union for Progress (UCP)
Voting strength: UCP holds 37 seats in the
Federal Assembly
Member of: Af[DB, FAO, G-77, IBRD, IDA,
IDB—Islamic Development Bank, IFAD,
ILO, IMF, ITU, NAM, OAU, OIC, UN,
UNESCO, UPU, WHO, WMO','5e84e045bbd221430a2893e4a3fed9b1049a2047e75e9b720b1823d8bb3713e0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aad026d8f32c6a6eab2df4a39dea5dad7bb2dae94a3d1faf148f6679929c433',1986,'GN','Guinea','government',121,'Official name: People’s Republic of the
Congo :
Type: people’s republic
Capital: Brazzaville
Political subdivisions: nine regions divided
into districts :
Legal system: based on French civil law
system and customary law; constitution: -
adopted 1973
National holiday: National Day, 15 August
Branches: presidential executive, Council of
State; judiciary; all policy made by Congo-
lese Labor Party Central Committee and
Politburo
Government leaders: Col. Denis SASSOU-
NGUESSO, President and party chairman. -
(since 1979); Ange Edouard POUNGUI,
Prime Minister (since July 1984)
Suffrage: universal over age 18
Elections: elections for local and regional
organs and the National Assembly were held
in July 1979—the first elections since June...
1973
Political parties and leaders: Congolese La-.
bor Party (PCT) is the only legal party; Party
Congress held in July 1984—Sassou tinani-
mously elected to another 5-year term as
president and party chairman
Communists: unknown number of Commu-
nists and sympathizers
56
Other political or pressure groups: Union of
Congolese Socialist Youth (UJSC), Congolese
Trade Union Congress (CSC), Revolutionary
Union of Congolese Women (URFC), Gen-
eral Union of Congolese Pupils and Students
(UGEEC)
Member of: A{DB, Conference of East and_-
Central African States, EAMA, ECA, EIB.
(associate), FAO, G-77, GATT, IBRD,
ICAO, ICO, IDA, IFAD, IFC, ILO, IMF, ~
IMO, INTELSAT, INTERPOL, ITU, NAM,.
OAU, UDEAC, UEAC, UN, UNESCO, °
UPU, WFTU, WHO, WIPO, WMO
Type: republic
Capital: Malabo
Political subdivisions: 6 provirices with ap-"
pointed governors
Legal system: in transition; constitution ap
proved:15 August 1982 by popular referen-
dum; in part based on Spanish civil law and
custom :
National holiday: 12 October |
Branches: constitution provides for prési-
dent with broad powers, prime minister,
unicameral legislature (Chamber of Repre-
sentatives of the People), and free judiciary
Government leader: Col. Teodoro OBIANG
NGUEMA MBASOGO, President (since
August 1979) . :
Suffrage: universal for adults .
Elections: parliamentary elections held-Oc-_
tober 1983
Political parties and leaders: political pat- °:
ties suspended; before coup of 3-August
1979, National Unity Party of Workers’
(PUNT) was the sole legal party’ _
Communists: no significant number of
Communists but some sympathizers
Member of: AfDB, Conference of East and
Central African States, ECA, FAO, G-77,
GATT (de facto), IBRD, ICAO, IDA, IFAD
ILO, IMF, IMO, INTERPOL, ITU, NAM,
OAU, UN, UNESCO, UPU, WHO :
?
Official name: Gabonese Republic .
Type:.republic; one-party presidential re-
gime since 1964 . i
Capital: Libreville
Political subdivisions: nine provinces:subdi-
vided into 36 prefectures
Legal system: based on French civil law
system and customary law; constitution
adopted 1961; judicial review of legislative
acts in Constitutional Chamber of the Su-
preme Court; legal education at Center of
Higher and Legal Studies at Libreville; com-
pulsory IC] jurisdiction not accepted
National holidays: Renovation Day, 12
March; Independence Day, 17 August; ma-
jor Islamic and Christian holidays
Branches: power centralized in President,
elected by universal suffrage for seven-year
term; unicameral legislature (93- member
National Assembly, including nine members
chosen by Omar Bongo) has limited powers; .
constitution amended in 1979 so that Assem-
bly deputies will serve five-year terms; inde-
pendent judiciary.
Government leader: El Hadj’ Omar
BONGO, President (since December 1967)
Suffrage: universal over age 18
Blections: presidential election last held De-
cember 1979, next scheduled for 1986; par-
liamentary election last held February 1980,
next scheduled for 1985; constitutional
change separates dates for presidential and
parliamentary elections _
Political parties and leaders: Gabonese -
Democratic Party (PDG) léd by President
Bongo is only legal party
Communists: no organized party; probably
some Communist sympathizers _
Member of: A{DB, African Wood Organiza-"
tion, Conference of East and Central Afri-. -
can States, BDECA (Central Af rican Devel-
opment Bank), EAMA, EIB (associate), FAO,
G-77, GATT, JAEA, IBRD, ICAO, ICCO, *
ICO, IDA, IDB—Islamic Development.
Bank, IFAD, IFC, ILO, IMF; IMO, |
INTELSAT, INTERPOL, IPU, ITU, NAM, .
OAU, OIC, OPEC, UDEAC, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WTO
Economy J
GDP: $3.4 billion (1983), $3,690 per eapitas
0.7% annual growth rate (1981)
Natural resources: -oil, manganese, uranium,
gold, wood, iron ore
Agriculture: commercial—cocoa, coffee,
wood, palm oil, rice; main food crops—pine-
apples, bananas, manioc, peanuts, root
crops; imports food |
Fishing: catch 52,638 metric tons (1982)
Major industries: petroleum production,
sawmills, petroleum refinery, food and bev-
erage processing; mining of increasing im-
portance; major minerals—manganese, ura-
nium, iron (not produced)
Electric power: 280,000 kW capacity (1985);
736 million kWh produced (1985), 744 kWh
per capita
Exports: $2.0 billion (f.0.b., 1983); crude
petroleum, wood and wood products, miner-
als (manganese, uranium concentrates, gold)
Imports: $0.9 billion (cif, 1983); mining,
roadbuilding machinery, electrical equip-
ment, transport vehicles, foodstuffs, textiles
Major trade’ partners: France, US, FRG,
Curacao.
Budeet: (1982) revenues, $1.4 billion; cur-
rent expenditures, $0.5 billion; capital ex-
penditures, $0.6 billion ‘
87
Monetary conversion rate: 475 Commu-
nauté Financiére Africaine (CFA)
francs=US$1 (1985)
Fiscal year: calendar year
Official name: Republic of The Combia
Type: tepublic pe arene since. re
1965; The Gambia and Senegal in early 1982:
formed a loose confederation of
Senegambia, which calls for the integration
of their armed forces and, eventually, their.
monetary union © : SEE
Guia Banjul
Political subdivisions: Banjul and five divi-
sions
Legal system: based on a composite of
English common law, Koranic law, and cus-
tomary law; constitution came into force
upon independence in 1965, new. republican’
constitution adopted in April 1970; accepts —
compulsory ICJ iurisdiction, with reserva- :.
tions
National holiday: Independence Day, 18
February
Branches: Cabinet of 13 members; unicam--
eral legislative branch (43-member parlia- °
ment), in which four seats are reserved for
tribal chiefs, four are government
appointed, 35 are filled by election for five:
year terms, a Speaker is elected by the
House, and the Attorney General is an ap-
pointed member; independent judiciary
Government leader: Sir Dawda Kairaba
J AWARA, President (since Hebrusty. 1970)
idl ae
Palivieal parties oa ade People’ sPro- -
gressive Party (PPP), secretary general, ''
Dawda K. Jawara; National Convention
Party (NCP), Sheriff Dibba
Suffrage: universal adult over 21
Elections: general election held May 1982 : .
88
wey he, ee
Voting strength:,PPP 27 Seats, NCP 4 seats,
others4 seats _
Communists: no Communist party
Member of: A{BD, APC, Commonwealth,
ECA, ECOWAS, FAO, G-77, GATT, IBRD,.:
ICAO, IDA, IDB—Inter-American Devel-
opment Bank, IFAD, IFC, IMF, IMO, IRC,
ITU, NAM, OAU, OIC, UN, UNESCO, -
UPU, WFTU, WHO, WMO, WTO
beohomy
GDP: $125 million (1984), Rae $170 per .
capita; real growth rate — 7.8% (FY84)
Natural resources: fish
Agriculture: main crops—groundnuts, mil-
let, sorghum, rice, maize, palm kernels, cot-
ton:
Fishing: catch 9, 600 metric tons e985)
Major industeies: baa processing, tour-
ism, brewing, soft drinks, agricultural ma-
chinery assembly, small woodworking and —
metalworking, clothing :
Electric power: 29,600 kW capacity (1985);
64 million kWh produce? O02) 85 kWh .
per capita
Exports: $59 million (f.0.b., FY85 est.) pea-
nuts and peanut products, fish, palm kernels
Imports: $73 million (f.0.b., FY85 est.); tex-
tiles, foodstuffs, tobacco, machinery, petro-
leum products, chemicals
Major trade partners: exports—mainly EC,
Africa; imports—EC, Africa
Aid: economic commitments—Western
(non-US) countries, ODA and OOF
(1970-83), $237 million; US (FY70-84), $49
million
Budget: (1982-83 est.) revenues $44.2 mil-
lion, current expenditures $34.90 million,
development expenditures $19.7 million
Monetary conterston rate: | dalasi=
US$0.28 (October 1985)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
218Fiscal year: 1 July-30 June.
Official name: German Deniocraue Renae:
lic
Type: Communist state
Capital: East Berlin (not officially recog-
nized by US, UK, and France, which i
together with the USSR have special rights
and responsibilities in Berlin)
Political subdivisions: (excluding East Ber-
lin) 14 districts (Bezirke), 218 counties
(Bree). 7, 600 communities iGereinden) ons
Legal system: 2: civil law system modified ie
Communist legal theory; new constitution
adopted 1974; court system parallels admin-
istrative divisions; no judicial review of legis-,
lative acts; legal-education at Universities of
Berlin, Leipzig, Halle; and Jena; has not ac-...
cepted compulsory ICJ jurisdiction; more
stringent penal code adopted in 1968 and . «
amended in 1974 and 1979
National holiday: Foundation of German . .
Democratic Republic, 7 October
Branches: unicameral legislature (People’s .. -
Chamber—Volkskammer, elected directly);
executive (Council of State, Council of Min-
isters); judiciary (Supreme Court); entire -
structure dominated by Socialist Unity -
(Communist) Party
Government.leaders: Erich HONECKER, :.
Chairman, Council of State (Héad of State; ~
since October 1976); Willi STOPH, Chair-
man, Council of.Ministers (Premier; since. ..
October 1976)’ -
Suffrage: all citizens age.18 and over
Elections: national every five years; pre-._
pared by an electoral commission of the Na-
tional Front; ballot supposed to be secret and
voters permitted to strike names off ballot;
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
German Democratic
Republic (continued)
more candidates than offices available; par-
liamentary election held 14 June 1981, and
local elections held 6 May 1984; next parlia- .
mentary election scheduled for 8 June 1986
Political parties and leaders: Socialist Unity
(Communist) Party of Germany (SED), ''
headed by General Secretary Erich .
Honecker, dominates the regime; four token
parties (Christian Democratic Union, :
National Democratic Party, Liberal Deme .
cratic Party, and Democratic Peasants’
Party) and an amalgam of special interest .
organizations participate with the SED in
National Front
Voting eta 1981 parliamentary elec-
tions and 1984 local elections; over 99%
voted the regime slate
Communists: 2.195 million party members
(1986)
Other special interest groups: Free German
Youth, Free German Trade Union Federa-
tion, Democratic Women’s League, Cultural
League of the German Democratic Republic
(all Communist dominated)
Member of: CEMA, IAEA, ICES, ILO,
IMO, IPU, ITU, UN, UNESCO, UPU, War-
saw Pact, WFTU, WHO, WIPO, WMO,
WTO
Official name: Federal Republic of Ger- _
many
Type: federal republic
Capital: Bonn
Political subdivisions: 10 Laender (states);
Western sectors of Berlin are ultimately con-
trolled by US, UK, and France; Eastern sec-
tor by USSR; the four countries share special
rights, and responsibilities i in Berlin
Legal system: civil law system with indige-
nous concepts; constitution adopted 1949;
judicial review of legislative acts in the Su-
preme Federal Constitutional Court; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral parliament—
Bundesrat (Federal Council, upper house),
Bundestag (National Assembly, lower
house); President (titular head of state),
Chancellor (executive head of government);
independent judiciary _
Government leaders: Richard von
WEIZSACKER, President (since July 1984);
Dr. Helmut KOHL, Chancellor (since Octo-
ber 1982)
Suffrage: universal over age 18
Rigctions: national lection generally held
every four years; last held on 6 March 1983;
next scheduled for January 1987
Political parties and leaders: Christian
Democratic Union (CDU), Helmut Kohl,
Gerhard Stoltenberg, Ernst Albrecht, Alfred
Dregger, Lothar Spaeth; Christian Social _
Union (CSU), Franz-Josef Strauss, Gerold
Tandler, Heiner Geissler, Walter Wollman,
Kurt Biedenkopf, Friedrich Zimmermann,
91
Theo Waigel; Free Democratic Party (FDP),
Martin Bangemann, Hans-Dietrich
Genscher, Wolfgang Mischnick, Helmut
Haussmani; Social Democratic Party (SPD),
Willy Brandt, Hans-Jochen Vogel, Johannes
Rau, Hans Apel, Horst Ehmke, Hans
Koschnik; National Democratic Party
(NPD), Martin Mussgnug; Communist Party
(DKP), Herbert Mies; Green Party (Greens),
Rainer Trampert; Otto Schily, Lukas
Beckmann, Joschka Fischer
‘Voting strength: (1983 election) 48.8%
CDU/CSU (CDU 38.2%, CSU 10.6%), 38.2%
SPD, 6.9% FDP, 5.6% Greens, .5% other
Communists: about 40,000 members and
supporters
Other political or pressure groups: expellee,
refugee, and veterans groups
Member of: ADB, Council of Europe, DAC,
EC, EIB, ELDO, EMS, ESRO, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO,
IDA, IDB—Inter-American Development
Bank, IFAD, IEA, IFC, IHO, ILO, Interna-
tional Lead and Zinc Study Group, IMF,
IMO, INTELSAT, INTERPOL, IPU, ITC,
ITU, NATO, OAS (observer), OECD, UN,
UNESCO, UPU, WEU, WHO, WIPO,
‘WMO, WSG, WTO
Official name: Republic of Guinea . ; a ;
Type: republic
Capital: Conakry’
Political subdivisions: 33 provinces, divided.
into 86 prefectures,
Legal system: based on French civil law
system, customary law, and decree; 1958
constitution. suspended after military coup
on3 April 1984; legal ‘codes currently being
revised; has not accepted compulsory IC] ,
jurisdiction
National holiday: Independence Day, 2 Oc-
tober; Anniversary of Committee for Na-
tional Redressment, 3 April
Branches: coup on 8 April 1984 established
the 25-member (currently 20 members) Mil-..
itary Committee for National Redressrnént
to determine government policy;,the highest. .
ranking CMRN member became President,
with other CMRN assuming most Cabinet’
portfolios; precoup unicameral legislature .
has been abolished
Government leaders: Gen. Lanena Be
CONTE, Head of Government (since Abril ,
1984)
Suffrage: universal c over age 18
Elections: none scheduled but CMRN i
promised to create a true and viable democ-
racy
Political parties and leaders: following 30
April 1984 coup all political activity banned
and only party, Demociatic Party of Guinea’
(PDG), dissolved
Communists: no Communist party,
although there are some sympathizers
108
Member of: ADB, ECA, ECOWAS, FAO,
G-77,.IBA, IBRD, ICAO, ICO, IDA, IDB—
Islamic Development Bank, IFAD, ILO,
IMF, IMO, INTELSAT, INTERPOL, ITU,
Mano River Union, Niger River Commis-
sion, NAM, OAU, OATUU, OIC, UN,
UNESCO, UPU, WHO, WMO
Official name: Republic es cy
re
Type: republic; highly neiivalibadlc one- party
regime sirice pepiember 1974
Capital: Bissau
Political subdivisions: 9 regions, 3 circum-
scriptions (predominantly indigenous popu-.
lation) ns
Legal system: new constitution approved -
May 1984 oe:
National holiday: Independence Day, : 24
September 3%:
ok
Branches: president and cabinet;
150-member National Popular Assembly,
overseen by 15-member Council of State...
Government leaders: Brig. Gen. Jodo
Bernardo VIEIRA, President, Council of
State (since November 1980); Paulo ;
CORREIA, First Vice President, Council:of
State (since May 1984); Ilafai CAMARA,
Second Vice President, Council of State. .
(since May wea
Suffrage: universal over age 15
Elections: east: elections held March :
1984; legislature elected Vieira to serve a .
five-year term as President:in May 1984
Political gaviles and leaders: Mri Party
for the Independence of Guinea-Bissau. and
Cape Verde (PAIGC), led by President
Vieira, only legal party; Guinea-Bissau .
decided to retain the binational party title:-.
despite its formal break with Cape Verde
Communists: a few Communists, some sym-
pathizers
Member of: ADB, CEAO, FAO, G-77,,
GATT (de facto), IBRD, ICAO, ICO, IDA;
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, IMO, ISCON, ITU, NAM,
OAU, OIC, UN, UNESCO, UPU, WFTU,
WHO, WMO
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Official name: Democratic Republic of Sao
Tome arid Principe ©
Type: fepae =
Capital: Sao Tome;
Political’ subdtnsions: seven counties
Legal system: based on Portuguese law sys-
tem and customary law; constitution -
adopted December 1975; has not accepted
compulsory Icy lenecon
National holidays: Marve’ s Day, 4 Febru-
ary; Independence Day, 12 July; Armed
Forces Day, first week in | September (varies);
Farmer’s oD ay, a September
Branches: President heads the government
assisted by a cabinet of ministers; unicam-
eral legislature (elected National Fopulat
Assembly) * :
Goverriment leader: Dr. Manuel Pinto DA
COSTA, President (since 1975)
suffrage: aise for age 18 and over
Elections: da Costa reelected by Popular
Assembly May’1980:and September 1985;
Assembly elections:in September 1985
Political patties and leaders: Movement for
the Liberation of Sao Tome and Principe
(MLSTP), Mantel Dine da Costa :
Communists: no Communist party, proba-
bly a few sympathizers:
Member of: AfDB, FAO, G-77, GATT (de
facto), IBRD, ICAO, IDA, IFAD, IFC, ILO,
IMF, ITU, NAM, OAU, UN, UNEBCO:
UPU,; ‘WHO, WMO i. ;
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','0f80e804f518710c71c067c2b451691166896f936ff55feadd582c4c39c3b945','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6236300e4297d49a26b5ee0765addff29d98ec5c67ddfbf35a8b2fb7e1e1459f',1986,'CK','Cook Islands','government',125,'Official name: Cook leads:
Type: self-governing in “free association”
with New Zealand; Cook Islands Govern-
ment fully responsible for internal affairs
and has the right at any time to move to full
independence by unilateral action; New
Zealand retains responsibility for external
affairs, in consultation with the Cook Islands
57
Capital: Avarua, located on Rarotonga “~
Branches: New Zealand Governor General
appoints Representative to Cook Islands,
who represents the Queen and the New
Zealand Government; Representative ap-
points the Prime Minister; popularly elected
24-member Parliament; 15-member House
of Arikis (chiefs), appointed by Representa-
tive, isan advisory body only
Government leader: Sir Thomas DAVIS,
Prime Minister (since July 1978)
Suffrage: universal adult
Elections: every five years, latest in Novem-
ber 1983
Political parties and leaders: Democratic
Party, Sir Thomas Davis; Cook Islands -
Party, Geoffrey Henry
Voting strength: (1983) Parliament—Dem- ‘
ocratic Party, 18 seats; Cook Islands Party,
1] seats :
Member of: ADB, IDA, IFC, IMF, SPF,
SPEC, ESCAP (associate member)','7d8ce5eb3e50a43df0dc9e638afd6c4dea122535c3e2f2a3d07a9b9fa4376710','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc79ee68af56582aa113377ca0b661f89f65bd6df99a22471c0522929b744d4b',1986,'CR','Costa Rica','government',129,'Official name: Republic of Costa Rica
Type: democratic republic
Capital: San José
Political subdivisions: 7 provinces divided
into 80 cantons and districts
\\ % :
Legal system: based on Spanish civil law
system; constitution adopted in 1949; judi-
cial review of legislative acts in the Supreme
Court; legal education at University of Costa
Rica; has not accepted compulsory ICJ juris- -
diction
National holiday: Independence Day, 15
September
Branches: executive—President (head of
government and chief of state), elected for a
single four-year term; two vice presidents;
legislative—57-delegate unicameral Legisla-
tive Assembly elected at four-year intervals,
judiciary—Supreme Court of Justice (17
magistrates elected by Legislative Assembly
at eight-year intervals)
Government leader: Oscar Arias
SANCHEZ, President-elect (to be inaugu-
rated May 1986)
Suffrage: universal and compulsory age 18
and over ° i
Elections: every four vee last held in Feb- -
ruary 1986
Political parties and leaders: National Lib-
eration Party (PLN),.Luis Alberto Monge,
Daniel Oduber, José “Pepe” Figueres, Oscar
Arias Sanchez; the new United Social Chris-
tian Party (PUSC) comprises the four Unity
Coalition (UNIDAD) parties—Republican
Calderonista Party (PRC), Rafael Angel
Calderon Fournier; Democratic Renovation
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 ; CIA-RDP08-00534R000100170001-4
Party (PRD), leader unknown; Christian .
Democratic Party (PDC), Rafael Grillo
Rivera; Popular Union Party (PUP); Chris-
tian Tallenbach Iglesias; the Popular Alli-
ance (PA) is a coalition comprising two
parties—Marxist Popular Vanguard Party
(PVP), Humberto Vargas Carbonell, and .. +:
Leftist Broad Democratic Front (FAD),
Rodrigo Gutiérrez; the United People (PU) is :
a leftist coalition comprising four parties—*
New Republic Movement (MNR), Sergio
Erick Ardén; Socialist Party (PS), Alvaro
Montero Mejia; People’s Party of Costa Rica
(PPC), Manuel Mora Valverde; and Radical:
Democratic Party (PRD), Juan José
Echeverria Brealey ae
Voting strength: (1986 election) PLN, 29
seats; UNIDAD, 25 seats: PVP, I seat; PPC,
1 seat; other, 1 seat
Communists: 7,500 members and sympa- *
thizers :
Other political or pressure groups: Costa
Rican Confederation of Democratic Work- °
ers (CCTD,; Liberation Party affiliate), Con- »
federated Union of Workers (CUT; Commu-
nist Party affiliate), Authentic Confederation
of Democratic Workers (CATD; Communist
Party affiliate), Chamber of Coffee Growers,
National Association for Economic Develop-
ment (ANFE), Free Costa Rica Movement °
(MCRL; rightwing militants), National Asso- :
ciation of Educators (ANDE)
Member of: CACM, Central American
Democratic Community, FAO, G-77,
IADB, IAEA, IBRD, ICAO, ICO, IDA,
IDB—Inter-American Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, ITU, IWC—Interna-
tional Wheat Council, OAS, ODECA,
PAHO, SELA, UN, UNESCO, URES, ue
WHO, WMO, WTO. : ©. |','8ff4421fb7bd2dca64a284f335b3ce19c06d0549b16a91855688c3c9b083fd70','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fcfa3a46b8f09a8af4350da05c956c60f4e8cd40a7ea9506bef04ff400f019c',1986,'CU','Cuba','government',133,'Official name: Republic of Cuba .
Type: Communist state
Capital: Havana
Political subdivisions: 14 provinces sand 169
municipalities.
Legal system: based on Spanish and Ameri-
can law, with large elements of Communist
legal theory; Fundamental Law of 1959 re-
placed constitution of 1940: a new constitu-
tion was approved at the Cuban Communist
Party’s First Party Congress in December -
1975 and by a popular referendum, which ~
took place on 15 February 1976; portions of
the new constitution were put into effect on
24 February 1976, by means ofa Constitu-
tional Transition Law, and the entire consti-
tution became effective on 2 December .__
1976; legal education at the Universities of
Havana, Oriente, and Las Villas; does not: :
accept compulsory ICJ jurisdiction
National holiday: Anniversary of the Revo-
lution, 1 January
Branches: executive; legislature (National
Assembly of the People’s Power), controlled ;
judiciary
Government leader: Fidel CASTRO Ruz,
President (since January 1959) rs
Suffrage: universal but not compulsory over
age 16
Elections: National People’s Assembly (indi-
rect election) every five years; last election
held November 1981
Political parties and leaders: Cuban Com-
munist Party (PCC), First Secretary Fidel
Castro Ruz, Second Secretary Radl Castro |
Ruz
Communists: approx. 400,000 ee mem-
bers
Member of: CEMA, ECLA, FAO, G:77,
GATT, JADB (nonparticipant), IAEA,
ICAO, IFAD, ICO, IHO, ILO, IMO, IRC,
ISO, ITU, IWC—International Wheat
60
Council, NAM, OAS (nonparticipant);
PAHO, Permanent Court of Arbitration,
Postal Union of the Americas and Spain,
SELA, UN, UNESCO, UNIDO, UPU,
WFTU, WHO, WIPO; WMO, WSG, WTO','3f2d67826fc143430a4de49c590bc87bea51cbe8ab5547442c9703647815eacf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c267ad4df3188645f92fc5825d47f85bbb52f952dae9185526473d4fa3c2e4e8',1986,'CY','Cyprus','government',137,'Official name: Czechoslovak Socialist Re-
public (CSSR)
dupe Coanunel state :
Capital: Prague. ep | ROSES ESS ak
Political subdivisions: 2 catcusiblys cepacia.
and nominally autonomous republics (Czech
Socialist Republic and Slovak Socialist.Re- .
public);,7 regions (kraj) in Czech lands, 3: : ..
regions in Slovakia; republic capitals of.
Prague and prausiava have fezional status
Legal system: vil ie system based on
Austro-Hungarian codes, modified by Com-
munhist legal theory; revised constitution -”
adopted 1960; and amended in 1968 and
1970; no judicial review of legislative aéts; -”
legal education at Charles University School
of Law; has not accepted compulsory IC]
jurisdiction
he aes
National holiday: Liberation Day, 9 May ,;
Bieaene eeeeuve Ereient (elected by.
Federal Assembly), Cabinet (appointed by |
President); legislative (Federal Assembly;
elected directly—Chamber of Nations,
Chamber of the People), Czech and Slovak -
National Councils (also elected directly) leg-
islate on limited area of regional matters;
judiciary; Supreme Court (elected by.Fed- .-
eral Assembly); entire governmental struc-. -.
ture dominated by Communist Party:
Government leaders: Gustav HUSAK, ee:
dent (since 1975); Lubomir STROUGAL, ''
Premier: (since 1970)
Suffrage: aulveuaioies age18. -
Elections: governmental bodies and presi-
dent every five years; last election June 1981
Dominant political party and leader: . Com-
munist Party of Czechoslovakia (KSC),. Gus-
tav Husak, General Secretary (since 1969);
Communist Party of Slovakia (KSS)] has sta- .
tus of provincial KSC‘ ‘organization””
Voting strength: (1981 election) 99.96% ae
Communist- sponsored single slate -
Communists: 1.6 million party members
hag 1984) ..
Other political groups: puppet parties— -
Czechoslovak Socialist Party, Czechoslovak
People’s Party, Slovak Freedom Party, Slo-
vak Revival Party
Member of: CEMA, FAO, GATT, IAEA,
ICAO, ICO; ILO, International Lead and
Zinc Study Group, IMO; IPU, ISO, ITC,
ITU, UN, UNESCO, UPU, Warsaw Pact,
WFTU, bias WIPO, WMO, WSG, WTO
Beano’
GNP: $127.9. billion ir in 1984 (in 1984 dollars),
$8,280 per capita; 1984 real growth rate
23%
Natural? resources: coal, coke, timber, lig-
nite; uranium, magnesite :
‘Apriealeute. diversified agriculture; main
crops—wheat, rye, oats, corn, barley, pota-
toes, sugar beets, hogs, cattle, horses; net
food importer—meat, wheat, vegetable oils,
fresh fruits and vegetables
Major industries: iron and steel, machinery
and equipment, cement, sheet glass, motor
vehicles, armaments, chemicals, ceramics,
wood, paper products
Shortages: ores, crude oil
Crude steel: 14.8 million metric tons pro-
duced (1984), 960 kg per capita
Electric power: 20,830,000 kW capacity
(1985); 79.5 billion kWh produced (1985),
5,128 kWh per capita |
Exports: $17. 398 billion i o.b. heey 54.8%
machinery and equipment; 16. 2% manufac-
tured consumer goods; 14.2% fuels, miner-
als, and metals; 6.7% agricultural and for-
estry products, 8.1% other products (1984
prelim. ) ;
Imports: $17. 585 billion (f.0.b., 1984); 41.1%
fuels, minerals, and.metals; 33.2% machin-
ery and equipment; 12.1% agricultural and
forestry products; 5.7% manufactured con-
sumer goods; 7.9% other products (1984)
Major trade partners: USSR, GDR, Poland,
Hungary, FRG, Yugoslavia, Austria, Bul-
garia, Romania; $32,484 million (1982); 71%
with Communist countries, 29% with non-
Communist countries (1984)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Czechoslovakia (continued)
Monetary conversion rate: 6.65 koronas=
US$1 (1983 average)
Fiscal year: calendar year
NOTE: foreign trade figures were converted
at the rate of 6.9 koronas= er (January
1982)','72cce0d91dd947af6c810b7c5621a02989d6f4f6bef18f004fed6f7dbf151133','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b0ca78fa0f0fbab4d6e18257ea208c1b733222ac5a88f79250aa8331ba59b81',1986,'DJ','Djibouti','government',142,'Official name: Republic of Djibouti
National holiday: 27 June
Type: republic
Capital: Diibouti
Political subdivisions: 5 cercles (districts)
Legal system: based on French civil law __
system, traditional practices, and Islamic .
law; partial constitution ratified January ©
1981 by National Assembly
Branches: legislative—65-member parlia- .
ment (National Assembly), executive, judi-
ciary
Government leader: Hassan GOULED ©
Aptidon, President (since June 1977)
Suffrage: universal adult ss ;
Elections: parliament elected May 1982 7.
Political party and leader: Péoples Progress
Assembly (RPP), Hassan Gouled Aptidon; :
sole legal party
Communists: possibly a few sympathizers
Member of: A{DB, Arab League, FAO,
G-77, IBRD, ICAO, IDA, IDB—Islamic ~.
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTERPOL, ITU, NAM, OAJU, OIC,
UN, UPU, WFTU, WHO, WMO','c744918e3333bff7581e38ad23fdf362b08db99a60546ab6ded8075b1ccefe36','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3acb49b2aeb93920c30a5cf31369fb9ca65a18872dd4255b077482d0a28a576',1986,'DM','Dominica','government',147,'Official name: Commonwealth of Dominica
ine independent state within Common-
wealth
Capital: Roseau
Political subdivisions: 21 districts .
Legal system: based on English common
law; three local magistrate courts and the
British Caribbean Court of Appeals
Branches: legislative, 51-member bicameral
House of Assembly (1 ex-officio member, 9
appointed members, and 21 members popu-
larly elected members; executive, Cabinet
headed by Prime Minister; judicial,
magistrate’s courts and regional court of
appeals
Government leader: (Mary) Eugenia
CHARLES, Prime Minister (since July
1980); Sir Clarence SEIGNORET, President
(since December 1983)
Suffrage: universal adult suffrage at age 18
Elections: every five years; last held 2 July
1985
Political parties and leaders: Labor Party of
Dominica (LPD, a leftist front group),
Michael Douglas; Dominica Freedom Party
(DFP), (Mary) Eugenia Charles ~
Voting strength: (1985 election) House of
Assembly seats—DFP 15, LPD 5, inde-
pendent 1
Cunnnas negligible
Other political or pressure groups: Domin-
ica Liberation Movement (DLM), a small __
leftist group
Member of: CARICOM, Commonwealth,
FAO, GATT (de facto), G-77, IBRD, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
OAS, UN, UNESCO, UPU, WHO, WMO
67','31a579839b5094f171d75e92882e647497baae7cac62d4c3fdcf063be79c3346','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d23c7870e6eaea44b2f0f069c0feebf42d3e126b7439d3e8a6ec3eceb5e7e35c',1986,'DO','Dominican Republic','government',151,'Official name: Dominican Republic
Type: republic
Capital: Santo Domingo -
Political subdivisions: 26 provinces and the
National District
Legal system: based on French civil codes;
1966 constitution
National holiday: Independence Day, 27
February
Branches: President popularly elected for a
four-year term; bicameral legislature (Na-
tional Congress—27-seat Senate and 120-
seat Chamber of Deputies elected for four-
year terms); Supreme Court
Government leader: Salvador JORGE
Blanco, President (since May 1982)
Suffrage: universal and compulsory, over
age 18 or married, except members of the
armed forces and police, who cannot vote
next election May 1986
Political parties and leaders: Dominican
Revolutionary Party (PRD), Jacobo Majluta
and José Francisco Pefia Gomez; Reformist
Social Christian Party (PRSC), Joaquin
Balaguer (formed in 1984 by merger of Re-
formist Party and Revolutionary Social
Christian Party); Dominican Liberation
Party (PLD), Juan Bosch; Democratic
Quisqueyan Party (POD), Elias Wessiny . —
Wessin; Antireelection Movement of Demo-
cratic Integration (MIDA), Francisco
Augusto Lora; National Civic Union (UCN),
Guillermo Delmonte Urraca; Dominican
Communist Party (PCD), Narciso Isa Conde,
Anti-Imperialist Patriotic Union (UPA), Ivan
Rodriguez;.in 1983 several leftist parties,
including the Communists, joined to form
the Dominican Leftist Front (FID); how-
ever, they still retain individual party struc-
tures ;
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Voting strength: (1982 election) 74% voter
turnout; 46.76% PRD, 39.14% PR; 9.69%.
PLD; 4.41% minor parties
Communists: an estimated 8,000 to 10,000
members in several legal and illegal factions;
effectiveness limited by ideological differ-
ences and organizational inadequacies
Member of: FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, ICAO, ICO, IDA; IDB—
Inter-American Development Bank, IFAD,
IFC, THO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOOG, IRC, ISO, ITU, OAS,
PAHO, SELA, UN, UNESCO, UPU,
WFTU, WHO, WMO, WTO','020d4220febcb2dfdec679d585bb6d489e2f09161d4cc2c4c88ce076e4830d67','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b70322fb31c19da850478ea061f3a61c58202cee87c23921c254bff2b5899d6e',1986,'EC','Ecuador','government',155,'Official name: Republic of Ecuador. .
National holiday: Independence Day, 10
August
Type: republic “i
Capital: Quito
Political subdivisions: 20 provinces includ-—
ing Galapagos Islands
Legal system: based on civil law system;
progressive new constitution passed in Janu-
ary 1978 referendum; came into effect fol- ,
lowing the installation of a new civilian gov-
ernment in August 1979; legal education at
four state and two private universities; has
not accepted compulsory ICJ jurisdiction
Branches: executive; unicameral legislature
(Chamber of Representatives); independent
judiciary
Government leader: Leon FEBRES-
CORDERO Ribadeneyra, President (since _
August 1984)
Suffrage: universal over age 18; compulsory
for literates :
Elections: parliamentary and presidential —
elections held January 1984; second-stage.
presidential election held May 1984; govern-
ment and legislature took office in August
1984; an amendment to the constitution in
August 1983 changed the term of office for
the president from 5 to 4 years; the.59 depu-
ties elected by the provinces serve for 2
years; the 12 at-large deputies serve for 4
years; next presidential election scheduled
for 1988 il
Political parties and leaders: Social Chris- ..
tian Party (PSC, the party of President Leon
Febres-Cordero), center-right; Popular De-
mocracy (DP), Osvaldo Hurtado; Christian
Democratic, Julio César Trujillo; Demo-
cratic Left (ID), Xavier Ledesma; Social
Democratic, Rodrigo Borja; Radical Alfarist
Front (FRA), Cecilia Calderon de Castro,
populist; Dernocratic Party (PD), Francisco
Huerta, center-left; Radical Liberal Party,
Eudoro Loor Rivadeneira, center-right;
Conservative Party, José Teran, center-
right; Concentration of Popular Forces
(CFP), Averroes Bucaram, populist; People,
Change, and Democracy (PCD), Aquiles
Rigail Santistevan, center-left; Democratic
‘Popular Movement (MPD), Jaime Hurtado,
Communist; Revolutionary Nationalist
Party (PNR), Carlos Julio Arosemena,
center-right; Broad Leftist Front (FADD),
René Maugé, pro- Moscow, Communist
Voting strength: results of May 1984 presi-
dential runoff election—Leon Febres-
Cordero of the Social Christian Party, who -
headed the coalition National Reconstruc-
tion Front, 52.2%; Rodrigo Borja of the
Democratic Left, 47.8%
Communists: Communist Party of Ecuador
(PCE, pro-Moscow, René Maugé—secretary
general), 6,000 members; Communist Party
of Ecuador /Marxist Leninist (PCMLE, in- .
dependent), 6,000 members; Revolutionary
Socialist Party of Ecuador (PSRE, pro- _
Cuba), 100 members plus an estimated 5, 000 :
sympathizers
Member of: Andean Pact, ECOSOC, FAO,”
G-77, IADB, IAEA, IBRD, ICAO, ICO,
IDA, IDB—Inter-American Development —
Bank, IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IRC, ITU, LAIA,
NAM, OAS, OPEC, PAHO, SELA, UN, |
UNESCO, UPEB, UPU, WFTU, WHO,»
WMO, WTO','95caa646e18091ad822c4a74d74528ebdea8397d81d77ad9d25fbc271374b1a9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a90aa748e332973296c1726b1d38ab54dde8dc8a7235ee33314a5da33fa42e74',1986,'EG','Egypt','government',159,'Official name: Arab Republic of Egypt
Type: republic
Capital: Cairo
Political subdivisions: 26 governorates
Legal system: based on English common -—
law, Islamic law, and Napoleonic codes; pér-
manent constitution written in 1971; judicial
review of limited nature in Supreme Court, *
also in Council of State, which oversees va-
lidity of administrative decisions; legal edu-.
cation at Cairo University; accepts compul-
sory IC] jurisdiction, with reservations
National holiday: National Day, 23 July
Branches: executive power vested in Presi- ©
dent, who appoints Cabinet; People’s Assem-
bly is principal legislative body, with Shura
Council having consultative role; inde-
pendent judiciary administered by Minister
of Justice ;
Government leaders: Mohammed Hosni
MUBARAK, President (since 1981); ‘Ali
Lotfy Mahmoud LOTFY, Prime Minister
(since September 1985)
Suffrage: universal over age 18
Elections: regular elections to People’s A3-
sembly every five years (most recent May
1984); two-thirds of Shura Council is elected
for six-year term (first elections were in Sép-
tember 1980) with remaining members ap-
pointed by President; presidential election
every six years; last held October 1981
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Egypt (continued).
Political parties and leaders: formation of
political parties must be approved by gov-
ernment; National Democratic Party, led by
Mubarak, is the dominant party; legal oppo-
sition parties are Socialist Liberal Party,
Kamal Murad; Socialist Labor Party,
Ibrahim Shukri; National Progressive
Unionist Grouping, Khalid Muhyi-al-Din;
Umma Party, Ahmad al-Sabahi; and New
Wafd Party, Fu’ad Siraj al-Din
Communists: approximately 500 party
members
Other political or pressure groups: Islamic
groups are illegal, but the largest one, the
Muslim Brotherhood, is tolerated by the gov-
ernment; trade unions and professional asso-
ciations are officially sanctioned
Member of: AAPSO, AfDB, FAO, G-77,
GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOOC, IPU, IRC, ITU, IWC—
International Wheat Council, NAM, OAU,
OIC, UN, UNESCO, UPU, WHO, WIPO,
WMO, WPC, WSG, WTO; Egypt
suspended from Arab League and OAPEC
in April 1979','5c7c37e76a5eef41dd03b21c07543ae382876b5c7b59c43937dbbbe7270713d3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85621319c4f87bdb1f265db8ed760300c90bf09411c6c86b6fdd3650e7878aa3',1986,'LY','Libya','government',163,'Official name: Republic of El Salvador
Type: republic
Capital: San Salvador
Political Subdivisions: 14 departments
Legal system: based on Spanish law, with
traces of common law; new constitution en-
acted in December 1983; judicial review of
legislative acts in the Supreme Court; legal
education at University of El Salvador; ac-
cepts compulsory IC] jurisdiction, with res-
ervations |
National holiday: Independence Day, 15
September
Branches: Legislative Assembly (60 seats),
Executive, Supreme Court
Government leaders: José Napoleén
DUARTE, President (since June 1984);
Rodolfo CASTILLO Claramount, Vice
President (since June 1984); Abraham
RODRIGUEZ, First Presidential Designate
(since September 1984); René FORTIN,
Magajfia, Second Presidential Designate
(since September 1984)
Suffrage: universal over age 18
Elections: Legislative Assembly (formerly
Constituent Assembly), 28 March 1982; pres-
idential election, 25 March 1984; presiden-
tial runoff election, 6 May 1984 (next sched-
uled for 1989); Legislative Assembly elec-
tion, 31 March 1985
73
Political parties and leaders: Christian
Democratic Party (PDC), José Antonio
Morales Erlich; National Conciliation Party
(PCN), Hugo Carrillo; Democratic Action |
(AD), Ricardo Gonzélez Camacho; Salva-_-
doran Popular Party (PPS), Francisco
Quifiénez; National Republican. Alliance
(ARENA), Alfredo Cristiani; Salvadoran
Authentic Institutional Party (PAISA),
Roberto Escobar Garcia; Social Democratic
Party (PSD), Mario René Roldan; Patria
Libre, Hugo Barrera
Voting strength: Legislative Assembly—
PDC, 33 seats; ARENA, 18 seats; PAISA, 1
seat; PCN, 12 seats; Independent, 1 seat
Other political or pressure groups: leftist.
revolutionary movement-——Unified Revolu-
tionary Directorate (DRU) and Farabundo
Marti National Liberation Front (FMLN),
leadership bodies of the insurgency; Popular
Liberation Forces (FPL), Armed Forces of
National Resistance (FARN), People’s Revo-
lutionary Army (ERP), Salvadoran Commu-
nist Party/Armed Forces of Liberation
(PCES/FAL), and Central American
Workers’ Revolutionary Party (PRTC)/
Popular Liberation Revolutionary Armed
Forces (FARLP); militant front organiza- ''
tions—Revolutionary Coordinator of Masses
(CRM; alliance of front groups), Popular
Revolutionary Bloc (BPR), Unified Popular
Action Front (FAPU), Popular Leagues of 28
February (LP-28), National Democratic
Union (UDN), and Popular Liberation:
Movement (MLP); Revolutionary Demo-
cratic Front (FDR), coalition of CRM and:
Democratic Front (FD), controlled by DRU;
FD consists of moderate leftist groups—.
Independent Movement of Professionals and
Technicians of E] Salvador (MIPTES), Na-
tional Revolutionary Movement (MNR), and.
Popular Social Christian Movement (MPSC),
extreme rightist vigilante organizations or
death squads—Secret Anti-Communist
Army (ESA); Maximiliano Hernandez Bri- .
gade; Organization for Liberation From
Communism (OLC)
Labor organizations: Federation of Con-.
struction and Transport Workers Unions
(FESINCONSTRANS), independent; Salva-
doran Communal Union (UCS), peasant as-
sociation; Unitary Federation of Salvadoran
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
El Salvador (continued)
Unions (FUSS), leftist; National Federation
of Salvadoran Workers (FENASTRAS), left-.
ist; Democratic Workers Central (CTD),
moderate; General Confederation of Work-
ers (CGT), moderate; Popular Democratic
Unity (UPD), moderate labor coalition
which includes FESINCONSTRANS, and
other democratic labor organizations
Business organizations: National Associa-
tion of Private Enterprise (ANEP), conserva-
tive; Productive Alliance (AP), conservative;
National Federation of Salvadoran Small
Businessmen (FENAPES), conservative
Member of: CACM, FAO, G-77, IADB,
IAEA, IBRD, ICAC, ICAO, ICO, IDA, .
IDB-—Inter-American Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ITU, IWC—International
Wheat Council, OAS, ODECA, PAHO,
SELA, UN, UNESCO, UPU, WFTU, WHO,
WIPO, WMO, WTO
Official name: Socialist People’s Libyan
Arab Jamahiriya
Type: republic; major overhaul of the consti-
tution and government structure in March -
1977 established a. system of popular con-
gresses, which theoretically controls the
General People’s Committee, or cabinet .
Capital: Tripoli -
Political subdivisions: 46 municipalities
closely controlled by central government -*!
Legal system: based on Italian civil law sys-
tem and Islamic law; separate religious
courts; no constitutional provision for judi-
cial review of legislative acts; legal education.
at Law School at University of Libya at
Banghazi; has not accepted compulsory ICJ
jurisdiction
National oui: Independence Day, 1
September
Branches: officially, paramount political
power and authority rests with the General
People’s Congress, which theoretically func-:
tions as a parliament with a cabinet called
the General People’s Committee.
Government leaders: Col. Mu‘ammar Abu - «
Minyar al-OADHAFI (no official title; runs -
country and is treated as chief of state); Mi-
ftah al-Ista ‘UMAR, Secretary of the General ..
People’s Congress (chief of state in theory
but riot treated as such)-
Suffrage: mandatory universal adult
Elections: representatives to the General
People’s Congress are drawn from popularly
elected municipal committees
Political parties: none
Communists: no organized party, negligible
membership
Other political or pressure groups: various
Arab nationalist movements and the Arab
Socialist Resurrection (Ba th) party with al-
most negligible memberships may.be func-
tioning clandestinely
- Member of: AEDB, Arab League, FAO,..--
G-77, IAEA, IBRD; ICAO: IDA, IDB—Is-
lamic Development Bank; IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL,
IOOC, ITU, NAM, OAPEC, OAU, OIC,
OPEC, UN, UNESCO, UPU; WHO, WIRO;
WMO, WSG','014952f5a5f8e48294b4adfc9f617b42eb460a73121fc3d80ac1549193756dff','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acb7cc7488c83fdf30b08a7625fc69f71cd5310cde72ac9df5bb3d79e8462071',1986,'ET','Ethiopia','government',169,'Official name: Socialist Ethiopia
Type: under military rule since September
1974; monarchy abolished in March 1975,
but republic not yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also
referred to as regional administrations)
Legal system: complex structure with civil,
Islamic, common, and customary law influ-
ences; constitution suspended September
1974; military leaders have promised a new
constitution by September 1986; legal edu-
cation at Addis Ababa University; has not
accepted compulsory ICJ jurisdiction
National holiday: Popular Revolution Com-
memoration Day, 12 September
Branches: executive power exercised by the
Provisional Military Administrative Council
(PMAC), dominated by its chairman and
small circle of associates; predominantly
civilian Cabinet holds office at sufferance of
military; legislature dissolved September
1974; judiciary at higher levels based on
Western pattern, at lower levels on tradi-
tional pattern, without jury system in either
Government leader: Lt. Col. MENGISTU
Haile-Mariam, Chairman of the Provisional
Military Administrative Council (since Feb-
ruary 1977)
Suffrage: none
Elections: none (January 1985)
76
Political parties and leaders: Ethiopian ~
Workers Party (WPE) founded in Septem-
ber 1984; headed by Mengistu Haile-
Mariam
Communists: government is officially
Marxist-Leninist
Other political or pressure groups: impor-
tant dissident groups include Eritrean Liber-
ation Front (ELF), Eritrean People’s Libera-
tion Front (EPLF), and Eritrean Liberation
Front/Popular Liberation Forces in Eritrea;
Tigrean People’s Liberation Front (TPLF) in
Tigray and Welo Provinces; Western Somali
Liberation Front (WSLF) in the Ogaden
region
Member of: A{DB, ECA, FAO, G-77, IAEA,
IBRD, ICO, ICAO, IDA, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, IPU,
ITU, NAM, OAU, UN, UNESCO, UPU,
WFETU, WHO, WMO, WTO
Official name: Colony of the Falkland Is-:
lands
Type: British dependent territory
Capital: Stanley
Political subdivisions: Falkland, South °°
Georgia, and South Sandwich Islands (the
latter two are administered from Stanley)
Legal system: English common law
Branches: under the 1985 Constitution an
Executive Council was established; it con-
sists of three elected members from the 8- _
member popularly elected Legislative
Counil
Government leaders: Gordon W. JEWKES,
Governor (since 1985); Air Vice Marchall R.-
J. KEMBALL, Commander of the British
Armed Forces (since 1985)
Suffrage: universal adult at age 18','f6112e5ca7d996a4da2dffa712918e27705b1899ad6b14b85cb9e0d15742e7cb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('429ca23f43aab6d5a8ad20142e56d3fa468da5b17e59a157dad5a60aaa4f021a',1986,'FO','Faroe Islands','government',173,'Official name: Faroe Islands
78
Type: self-governing province within the
Kingdom of Denmark; 2 representativesin
Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 com-
munes, | town
Legal system: based on Danish law; Home
Rule Act enacted 1948
Branches: ieaicthave authority rests ‘eine
with Crown, acting through appointed High
Commissioner,.and 32-member provincial
parliament (Lagting) in matters of strictly
Faroese concern; executive power vested in.
Crown, acting through High Commissioner,
but exercised by-provincial cabinet responsi-
ble to provincial parliament
Government leaders: MARGRETHE II,
Queen (since January 1972); Atli DAM,
Lagmand, Prime Minister (since December
1984); Niels BENTSEN,, Danish Governor
(since 1981)
Suffrage: universal, but not compulsory,
over age 2] ; ‘
Elections: held every four years; most re-
cent, 8 November 1984
Political parties and leaders: four-party ~ .—
ruling coalition—Social Democratic, Atli
Dam; Republican, Erlendur Patursson;. - .
Home Rule, Tobjern Poulsen; Peoples, ©
Jogvan Sundstein
Voting sthenith Gainey, 1985) eae party
coalition—17 of 32 seats .-
Communists: jocienificant number
Member a Nordic Council
Eeansaly
GDP: $369.3 million (1980), about $8,800
per papa
Natural resources: fish
Agriculture: sheep and cattle grazing
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Fishing: catch-329;900 metric tons (1983);
exports, $162.3 million (1980): -‘ -
Major ea: ening
Electric power: 67,000 kW capacity (1985);
215 million kWh prodtced (086), 4, ele
kWh per capita
Exports: $178.7: million (f. o.b.; aes moa
fish and fish products
Imports:$222:1 million (c.i-f.,:1980); ma- .-
chinery and trarispért-equipment, petio-''
leum ane ag saree ereducts ‘food products :
Major ae ‘eine exports a1, 3% Den-''
mark, 13.4% UK, 12. 4% FRG; i, 7% DS :
(1980) ‘ : 7
Budget: (FY81) expenditures, $08. 8 million,
revenues, oe. 8 fenlen
Monetary senobsions rate: 10.80 Danish
kroner=US$1 (November 1984 avetagé)
Fiscal year: calendar year','3a5adee47ac262d43d71aac052d01635480ab8a22fa2bdcabf5e0f682498ba85','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2c14b646ee44b259c1c17cdca25c2c318d9b7bc769c7c5944b27d9d374ed93a',1986,'FJ','Fiji','government',176,'Official name: Fiji
Type: independent parliamentary state
within Commonwealth; Elizabeth II recog- - :
nized as chief of state
Capital: Suva, located on the scat coast of
the ita of Viti Levu -
Politleal Adsense: 4 divisions
Legal system: based on British system
National holiday: Fiji Day, 10 October
Branches: executive—Prime Minister and
Cabinet; legislative—52-member House of
Representatives; 22-member appointed Sen-
ate; judicial—Supreme Court, Court of Ap-
peal, Magistrate’s Courts
Government leader: Ratu Sir Kamisese
MARA, Prime Minister (since 1966 [as Chief
Minister during preindependence days] )
Suffrage: universal adult
Elections: every five years unless House dis-
solves earlier; last held July 1982
Political parties: Alliance, primarily Fijian,
headed by Ratu Mara; National Federation,
primarily Indian, headed by Siddig Koya;
Western United Front, Fijian, Ratu Osea
Gauidi; Fiji Labor Party (founded in mid-
1985), headed by Dr. Timoci Bavadra
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Fiji (continued)
Voting strength: (July 1982) House of Rep-
resentatives—(Alliance Party 28 seats; Na-
tional Federation Party / Western United
Front coalition 24 seats
Communists some
Member ae ADB, eauiia Pak. Common-
wealth, EC (associate), ESCAP, FAO, G-77,
GATT (de facto), IBRD, ICAO, IDA, IFAD,
IFC, {LO, IMF, IMO, INTELSAT,
INTERPOL, ISO, ITU, SPF, UN, UNESCO,
UPU, WFTU, WHO, WIPO, WMO','c6a299fdd9ff6111ca907b5e283f430def28e2d2d7958ab68bdf9223bb65f419','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('238c09cac7ff907c0d28fbfabb78f8626473e11734fb633921c8e18350458634',1986,'FI','Finland','government',181,'Official name: French Republic
Type: republic, with President having wide .
powers cE
Capital: Paris
Political subdivisions: 22 regions with 96
metropolitan departments: ° :
Legal system: civil law system with indige-
nous concepts; new constitution adopted
1958, amended concerning election of Presi-
dent in 1962; judicial review of administra-
tive but not legislative acts; legal education
at over 25 schools of law
National holiday: National Day, 14 July.
Branches: presidentially appointed Prime.
Minister heads Council of Ministers, which
is formally responsible to National Assem-
bly; bicameral legislaturé—National Assem-
bly (currently 491 members but will expand
to 577 as.of 16 March 1986), Senate (304 .
members)—restricted to a delaying action;
judiciary independent in principle
Government leader: Francois
MITTERRAND, President (since May
1981); Jacques CHIRAC, Prime Minister
(since March 1986)
Suffrage: aniyereil overage 18; not compul-
sory j : :
Elections: National Assembly—every five
years, last election March 1986; proportional
representation, with minimum 5 percent of
the vote; Senate—indirect collegiate system
for nine years, renewable by one-third every
three years, last election September 1983;
President, direct, universal suffrage every
seven years, two ballots, last election May
1981
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Political parties and leaders: majority coali: |
tion—Rally for the Republic (RPR, formerly
UDR), Jacques Chirac; Union for French
Democracy (UDF, federation of PR, CDS,.
and RAD), Jean Lecanuet; Republicans (PR),
Francois Léotard; Center for Social Demo-
crats (CDS), Pierre Méhaignerie; Radical -
(RAD), André Rossinot; left opposition—"
Socialist Party (PS), Lionel Jospin; Left Radi-
cal Movement (MRG), F rancois Doubin;
Communist Party (PCF), Georges Marchais~
Voting strength: (1986 election) UDF/ -
RPR/CNIP, 44.9%: PS/MRG 31.6%; Com-
munist, 9.8%; National Front, 9.7%; diverse _
left, 1.0%; extreme left, 1.5%; extreme right,
0.2%; other 1.2%
Communists: 700,000 claimed but probably --
closer to 150,000; Communist voters, 2.7
million in 1986 elections ° -
Other political or pressure groups: .%
Communist-controlled labor union “+ «
(Confédération Générale du Travail) nearly
2.4 million members (claimed); Socialist-
leaning labor union (Confédération
Francaise Démocratique du Travail—
CFDT)} about 800,000 members est.; inde-
pendent labor union (Force Ouvriére) about: ~!
1,000,000 members est.; independent white °
collar union (Confédération Générale des
Cadres) 340,000 members (claimed); Na-
tional Council of French Employers (Conseil -
National du Patronat BtangaleUNEE or
Patronat)
Member of: ADB, Council of Europe, DAC,
EC, EIB, ELDO, EMA, EMS, ESCAP,
ESRO, FAO, GATT, IAEA, IATP, IBRD,
ICAC, ICAO, ICES, ICO, IDA, IDB—Inter-
American Development Bank, IFAD; IFC;-. -
THO, ILO, International Lead and Zinc |
Study Group, IMF, IMO, INTELSAT; * > *-
INTERPOL, IOOC, IPU, IRC, ISO; ITC,
ITU, [WC—International Whaling Com-
mission, NATO (signatory), OAS (observer),
OECD, South Pacific Commission, UN,’
UNESCO, UPU, WEU, WFTU, WHO,
WIPO, WMO, Wee WTO','a1aca7b7960e392623fb8d21149649f2f68e67cf931c4b842d4920e191ce3105','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e0ceefdd1cf0a5896bebe63e43f0643037de01c2c44cf0e9928a246d07afbf0',1986,'GF','French Guiana','government',184,'Official name: Department of French
Guiana
Type: overseas department and region of
France; represented by one deputy in
French National Assembly and one senator
in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19
communes each with a locally elected mu-
nicipal council
Legal system: French legal system; highest
court is Court of Appeals based in Mart-
inique with jurisdiction over Martinique,
Guadeloupe, and French Guiana
Branches: executive: Prefect appointed by
Paris; legislative—popularly elected 16-
member General Council and a Regional
Council composed of members of the local
General Council and of the locally elected
deputy and senator to the French parlia-
ment; judicial, under jurisdiction of French
judicial system
Government leader: Bernard COURTOIS,
Prefect of the Republic (since 1984)
Suffrage: universal over age 18
Elections: General Council elections nor-
mally are held every five years; last election
February 1983
Political parties and leaders: Guianese So-
cialist Party (PSG), Raymond Tarcy (sena-
tor), Léopold Helder; Union of the Guianese
People (UPG), weak leftist party allied with
and reported to have been absorbed by the
PSG; Rally for the Republic (RPR), Héctor
Rivierez
Communists: Communist party member-
ship negligible
Member of: WFTU','3bc218ddf98969c2a369aca86cd1f25cc55b3a696e92bb9f22231d759235d414','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609482889ae4759106e5ecc6e67f41966e0dbc21f54c8f90704c80ef673e2e69',1986,'PF','French Polynesia','government',188,'Official name: Territory of French
Polynesia.”
Type: overseas territory of France
Capital: Papeete
Political subdivisions: 48 communes
Legal system: based on F rench; lower and
higher courts
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
French Polynesia (continued)
Branches: 30-member Territorial Assembly,
popularly elected; 5-member Council of ''
Government, elected by Assembly; popular
election of two deputies to National Assem-
bly and one senator to Senate in Paris "
Government leader: Alain OHREL, High
‘Commissioner and President of the Council
of Government (since 1983), appointed by.
French Government; Gaston FLOSSE, Vice
President of the Council of Government
(since May 1982; highest elected official i in
the territory) ©
Suffrage: universal adult
Elections: every five years; last held in May
1982
Political parties and leaders; Tahoeraa
Huiraatira (Gaullist), Gaston Flosse; Ai’a Api
(New Country Party), Emile Vernaudon;
Here Ai’a, Jean Juventin; Ja Mana (Socialist), .
Jacques Crollet; Te E’a Api (Socialist),
Jacques VII
Voting strength: (1982 election) Tahoeraa
Huiraatira, 13 seats; Ai’a Api, 3 seats; Here
Ai’a, 6 seats; Ia Mana, 3 seats; Independents,
4 seats; Te E’a Api, 1 seat.','f5d1e000ea6d0f641026de9320eb0890e375a1c77362dde57aee1277d9fab5ea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e3ea5bcb8100a96607fe26facb3284a287a1dda321a772d468e147b63998dfe',1986,'GH','Ghana','government',193,'Official name: Republic of Ghana
Type: republic; 31 December 1981 coup
ended two-year-old civilian government and
suspended constitution and political activity
Capital: Accra
Political subdivisions: 8 administrative re-
gions and separate Greater Accra Area; re-
gions subdivided into 58 districts and 267
local administrative districts
Legal system: based on English common
law and customary law; legal education at
University of Ghana (Legon); has not ac-
cepted compulsory ICJ jurisdiction
National holiday: Independence Day, 6
March
Branches: executive authority vested in
seven-member Provisional National Defense
Council (PNDC); on 21 January 1982 PNDC
appointed secretaries to head most minis-
tries
Government leader: Fit. Lt. (Ret.) Jerry
John RAWLINGS, Chairman of PNDC
(since December 1981)
Suffrage: none
Elections: elections held in June 1979 for
parliament and president; presidential
runoff election held in July; none scheduled
since 1981 coup:
Political parties and leaders: political par-
ties outlawed after 31 December 1981 coup
Communists: a small number of Commu-
nists and sympathizers
Member of: A[DB, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IAEA, IBA,
_ IBRD, ICAO, ICO, IDA, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, IRC,
ISO, ITU, NAM, OAU, UN, UNESCO,
UPU, World Confederation of Labor,
WHO, WIPO, WMO, WTO
Economy ea. of
GNP: $10.5 billion (1982 est.); real growth
rate —7.2% (1982 est.)
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish
Agriculture: main crop—cocoa; others in-
clude root crops, corn, sorghum, millet,
coffee, peanuts; not self-sufficient but can
become so
Fishing: catch 241,000 metric tons (1982)
Major industries: mining, lumbering, light
manufacturing, fishing, aluminum
Electric power: 1,200,000 kW eapadity
(1985); 2.628 billion kWh produced (1985),
200 kWh per capita :
Exports: $856.9 million (f.0.b., 1982); cocoa
(about 60%), wood, gold, diamonds, manga-
nese, bauxite, aluminum (aluminum regu-
larly excluded from balance-of-payments
data)
Imports: $668.7 million (f.0.b., 1982); tex-
tiles and other manufactured goods, food,
fuels, transport equipment.
Major trade partners: UK, EC, US
Budget: revenues, $1.8 billion; expenditures
and net lending, $3.5 billion (1981/82)
Monetary conversion rate: 50 cedis=US$1
(December 1984)
Fiscal year: calendar year','65adc9347de86f48d2fb47bc6c5f3a3fd16e83f02b332e9f31c3b9d3913c593e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a7e01b0d5df82d03b0a3cf5a727c992df2a45c8c7c85dd21fa15547670afceb',1986,'GI','Gibraltar','government',196,'Official name: Gibraltar.
Type: British dependent territory
Capital: none
Legal system: English law; constitutional —
talks in July 1968; new system effected in
1969 after electoral inquiry
Branches: parliamentary system comprising
the Gibraltar House of the Assembly (15 °°
elected members and 3 ex officio members),
the Couricil of Ministers headed by the
Chief Minister, and the Gibraltar Council;
the Governor i is appointed by the on
Goverinient leaders: Air:‘Chief Marshal Sir
Peter. TERRY, Governor and Commander
in Chief (since 1985); Sir Joshua A. HASSAN,
Chief Minister (1964-69 and since 1972)
Suffrage: all adult Gibraltarians, plus other
UK subjects resident six months or more
Elections: every four years; last held j in J an-,
uary 1984 i
Political parties and léaders: Gibraltar La:
bor Party / Association for the Advancement
of Civil Rights (GCL/AACR), Sir Joshua
Hassan; Democratic Party of British Gibr- .
altar (DPBG), Peter Isola; Socialist Labor
Party, Joe Bossano
Voting sibentihe (January 1984) Noise of
the Assembly—GCL/AACR, 8 seats; Social-
ist Labor, 7 seats -
Communists: negligible
Other political or pressure groups: House-.
wives Association, Chamber of Commerce,
Gibraltar Representatives Organization','7ab07fff40fbbac13f728c5f976924412f6848076eddfa2cba2c954a0683dbf8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc2fab9b555e9af5d2848ada099d96b814b4376db1173751cee8fd7fbc37c2e2',1986,'GR','Greece','government',200,'Official name: Hellenic Republic
Type: presidential parliamentary govern-
ment; monarchy rejected by referendum 8
December 1974
Capital: Athens
Political subdivisions: 51 departments
(nomoi) constitute basic administrative units
for country; each nomos headed by officials _
appointed by central.government and policy
and programs tend to be formulated by cen-
tral ministries; degree of flexibility each ..
nomos may have in altering or avoiding pro-
grams imposed by Athens depends upon ©
tradition and influence that prominent local
leaders and citizens may-exercise vis-a-vis
key figures in central government; the de- —
partments of Macedonia and Thrace exer- *
cise some degree of autonomy from Athens
since they-are governed through the Minis-
try of Northern Greece
Legal system: new constitution enacted in. .
June 1975 :
National holiday: Independence Day, 25
March “ae .
Branches: executive consisting of a Presi-
dent, elected by the Vouli (Parliament), a
Prime Minister, and a-Cabinet; unicameral .
legislature consisting of the 300-member ’
Vouli; and an independent judiciary
Government leaders: Dr. Andreas
PAPANDREOU, Prime Minister (since
1981); Christos SARTZETAKIS, President 7
(since 1285) =
Suffrage: universal age 18 and over
95
Elections: every four years; <Papandicot! $
Panhellenic Socialist Movement defeated
the incumbent New. Democracy govern-
ment of George Rallis in elections held on 18
October 1981; PASOK was. ‘reelected i in June
1985
Political parties and hace: Bahbistlenié
Socialist Movement (PASOK), Andreas
Papandreou; New Democracy (ND),
Constantine Mitsotakis; Democratic Re-
newal (DR), Constantine Stefanopoulos;
Communist Party- Exterior (KKE-Ext),
Kharilaos Florakis; Communist
Party-Interior (KKE-Int), Leonidas Kyrkos
Voting strength: Parliament-——Panhellenic
Socialist Movement, 157 seats; New Democ-.
racy, 11] seats; Democratic Renewal, 10
seats; Communists (Exterior), 10 seats, Com-
munists (Interior), 1 seat; independents, 11
seats , :
Communists:-an estimated 60,000 members
and sympathizers
Member of: EC, EIB (associate), EMA, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFAD,
IFC, IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOOC, ITU, [WC—Interna-
tional Wheat Council, NATO, OECD, UN,
UNESCO; UPU, WHO, WIPO, WMO,
WSG, WTO ,
Economy ; ao :
GNP: $33.5 billion ise $3, 380° per capita;
real growth rate 2.89% ( 1984).
Natural resources: bauxite, lignite, magne-
site,.oil. - k
Aprouliare: main tone Swhieat olives,
tobacco, cotton, raisins, fruit; nearly self- ”
sufficient; food shortages—livestock prod-
ucts . “oo
Major industries: food and tobacco process-
ing, textiles, chemicals, metal products
Crude steel: 1.8 million metric tons pro-
duced (1984 est.), 132 kg per capita
Electric power: 10,553,000 kW capacity
(1985); 26.572 billion kWh produced (1985),
2,680 kWh per capita > |
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Greece (continued)
Exports: $4.40 billion (£.0.b., 1984); principal
items—tobacco, minerals, fruits, textiles
Imports: $9.8 billion (c.i.f., 1984); principal
items—machinery and automotive equip-
ment, petroleum and petroleum products,
manufactured consumer goods, chemicals
meat and live animals
Major r ivade partners: (1983 est.) imports—
16.7% FRG, 9.7% Italy, 7.6% Japan, 6.9%
France, 6.8% Saudi Arabia; exports—19.6% ''
FRG, 13.5% Italy, 8. ne France, e 3% US,
6.3% UK
Aid: economic commitments—US, includ-
ing Ex-Im, $525 million (1970-81); other
Western bilateral (ODA and OOF), $1.1
billion (1970-83); Communist countries
(1970-84), $360 million; military—US, $2.6
billion (FY70-84); Communist countries
MBTOSS $110 million.
Bulger (1984) central government revenues
$9.1 billion, expenditures $12.5 billion, $8. 4
billion deficit
Monetary conversion rate: 154.04 Greek
drachmas=US$1 (October 1985)
Fiscal year: calendar year
Communications : i
Railroads: 2,479 km total; 1,565 iin 1. 435-
meter standard gauge, of which 36 km elec-
trified. and 100 km double track, 889 km _
1.000-meter gauge; 22 km 0.750-meter nar-
row gauge; all governinent owned |
Highways: 38,938 km total; 16,090 km
paved, 13,676 km crushed stone and gravel,
5,632 km improved earth, 3, 540 km: ‘unim- -
proved earth
Inland waterways: system consists of three
coastal canals and three unconnected rivers,
which provide navigable length of just under
80 km
Pipelines: crude oil, 26 km; refined prod-
ucts, 547 km
Ports: 2 major, 12 secondary, 37 minor
Civil air: 89 major transport aircraft
Declassified and Approved For Release 2012/08/29 :
Airfields: 81 total, 78 usable; 57 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 21 with runways 2,440- °
8,659 m, 21 with runways 1,220-2,439 m_
Telecommunications: adequate; modern
networks reach all areason mainland: :- :
islands; 3.31 million telephones (33.5 per 100
popl.); 28 AM, 37 FM, and 292 TV stations; 6
submarine cables; 1 satellite station with 2.
Atlantic Ocean antennas and 1 Indian
Ocean antenna
Defense Forces. ee
Branches: Hellenic Army, Hellenic Navy,
Hellenic Air Force
Military manpower: males 15-49, 2,357,000;.
1,906,000 fit for military service; about ..
77,000 reach military age (21) annually .
Military budget: for fiscal-year ending 31°
December 1984, $2.7 billion; 18.8% of cen-
tral government budget
96
Greenland ''
Arctic Ocean
Tourism and foreign worker remittances:
$825 million (1985)
Declassified and Approved For Release 2012/08/29 . CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Budget: (1985 prelim.) total revenues, $8.04
billion; operating budget, $2.5 billion; capi-
tal budget, $1.2 billion
Monetary conversion rate: 0.80 Tunisian’
dinar (TD)=US$1 (30 October 1985)
Fiscal year: calendar year','506924a9170d2a74398d27dd3432dc40aa1184877369e2ae3ab41241d241770d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8483dc80818e09c62f99ab2e6a6a28f6b8304f1cb103e25efa68b3b6435917e1',1986,'GL','Greenland','government',201,'Sea
Baffin Bay
eigormiit
Qegertarsuac
Davis Strait
“Ammassalik
STAUUK Denmark Strait
. Qaqortog
See regional map I.
Land
2,175,600 km?; inaueie ‘that edinnicds US;
84% permanent ice and snow, less than 1% ...
arable (of which only a fraction is
cultivated), 16% other
Water
Limits of territorial waters (claimed): 3 nm
fishing zone (200 nm)
Coastline: approx. 44,087 km (includes mi-
nor islands) :','34b638ca4daded6cb7c9127d43f5b5a5d0b98a2fd1efdec9bcf8529619def4c0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c067a8207a4940de03d3b027b6e8aa702d4c487ffc21c58dae15523248cd9eb0',1986,'GD','Grenada','government',207,'Official name: Grenada’
Type: independent : state; recognizes Eliza-_
beth H as Chief of State ©
Capital: St. George’s
Political subdivisions: 6 parishes
Legal system: based on English common
law
National holiday: Independence Day,7 ~
February
Branches: bicameral legislature (15-member
elected House of Representatives and 13-
member appointed Senate): executive is
Cabinet led by thé Prime Minister; judiciary
consists of Grenada Supreme Court, com-
posed of the High Court of Justice and''two- |
tier Court of Appeals
Government leaders: Sir Paul SCOON,
Governor General (since 1978); Herbert
BLAIZE, Prime Minister (since December
1984)
Suffrage: universal adult
Elections: last general election''held 3 De-''
cember 1984 ;
Political parties and leaders: the New Na-
tional Party (NNP) is the ruling party and is |
a three-party centrist coalition composed of
the Grenada National Party (GNP), the Na-
tional Democratic Party (NDP), and the
Grenada Democratic Movement (GDM);
former Prime Minister Sir Eric Gairy re-
vived his Grenada United Labor Party
(GULP) in 1984; Grenada Democratic Labor
Party (GDLP) formed by Marcel Peters, the
only opposition member of parliament, who
was elected as a GULP candidate but
changed parties after he assumed his seat in
the House of Representatives; the Maurice
Bishop Patriotic Movement (MBPM) was
formed in May 1984 and is composed of
pro-Cuban Socialists; the New Jewel Move-
ment (NJ M) consists of supporters of Bern-
ard Coard and other hardliners accused of
Killing Bishop i in 1983
Voting strength: (1984 election) NNP 59%,
GULP 36%, MBPM 5%; patliamentary”
seats—NNP, 14; GDLP, 1
Communists: the New J ewel Movement,
which is currently trying to revitalize, and
the less hardline Maurice Bishop Patriotic
Movement
Other political or pressure group: Grenada
Democratic Labor Party (GDLP) is the of-
ficial opposition
Member of: CARICOM, FAO, G-77, GATT
(de facto), IBRD, ICAO, IDA, IFAD, IFC,
ILO, IMF, ITU, NAM, OAS, PAHO, SELA,
UN, UNESCO, UPU, WHO
Economy on ; : ae
GDP: $86.8 million (1984 ést.), $940 per cap-
ita; real growth rate 0.6% (1984 est.); average
inflation rate 5% (1984 est.)
Agriculture: main crops—cocoa, nutmeg,
mace, and bananas
Electric power: 11,000 kW capacity (1985);
23 million kWh produced (1985),''261. kWh ©
per capita
Exports: $18.9 million (£.0.b., 1983); « cocoa.
beans, nutmég, bananas, mace
1
Imports: $55.6 million (ci if., 1983); food,
machinery and transport equipment, oil,
building materials
Major trade partners: exports——35% UK,
9% FRG, 6% Netherlands, 6% US, (1984
est.); imports—_17% US; 17% ‘Trinidad and
Tobago, 20% UK (1983)
Budget:(1984 est.) revenues, $32 million; :
expenditures, $61 million :
Monetary conversion rate: 2.70 East Carib-’
bean dollars=US$1 (December 1985)
Fiscal year: calendar year
98','0d7b19c9d5d0987f8541d887515be7c3ca111d6baf1215a8c5dfcf4ed2f1af50','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7cb71e16450753bb237b17d0dadbb06ba0ddd899a6224de60fa73caf3451c18',1986,'GP','Guadeloupe','government',210,'Official name: Department of Guadeloupe _
Type: overseas department and region of
France; ‘represented by three deputies in the
French National Assembly and two senators
in the Senate; last Assembly election, 21 June
1981
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34
communes, each with a locally elected mu- .
nicipal council ,
Legal system: French legal system, highest
court is a court of appeal based in Marti-
nique with jurisdiction over Guadeloupe,
French Guiana, and Martinique
Branches: executive, Prefect appointed by
Paris; legislative, popularly elected General
Council of 36 members and a Regional
Council composed of members of the ‘local
General Council and the locally elected dep-
uties and senators to the French parliament;
judicial, under jurisdiction of French judi-
cial system
Government leader: Robert MIGUET, Pre-
fect of the Republic (since 1985)
Suffrage: universal over age 18
Elections: General Council elections are
normally held every five years; last General
Council election took place in June 1981,
regional assembly elections held in February
1983"
Political parties and leaders: Rally for the
Republic (RPR), Gabriel Lisette; Communist
Party of Guadeloupe (PCG), Henri Bangou; —
Socialist Party (MSG), leader unknown; Pro-
gressive Party of Guadeloupe (PPG), Henri
Rodes; Independent Republicans; Federa-_ .
tion of the Left; Union for French Democ-
racy (UDF); Union for a New Maiority
(UNM) -
Voting strength: (198] election) French Na-
tional Assembly—MSG, 1 seat; PCG, 1 seat; .
UDF, 1 seat
99
Communists: 3,000 est.
Other political or pressure groups: Popular
Union for the Liberation of Guadeloupe
(UPLG), Caribbean Revolutionary Alliance
(ARC), Popular Movement for Independent
Guadeloupe (MPGD), Union for the Libera-
tion of Guadeloupe (UPLG), General Union”
of Guadeloupe Workers (UGTG), General.
Federation of Guadeloupe Workers.
(CGT-G)
Member of: WFTU |','5cf532b2ccb95fa175fd6ca1e1498e4525e76b411820aa98e1459e6b2e8fd82a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7285fe23c9b898c82be2e147f9306ea8a0e9b694dd320bcbbaa0eff74f29f5ba',1986,'GT','Guatemala','government',214,'Official name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions; 22 departments
Legal system: civil law system; constitution
came into effect 1966 but suspended follow- .
ing March 1982 coup; Constituent Assembly
elected in July 1984 completed drafting new
constitution and other electoral laws in June -
1985; elections held 2 November and 8 De-
cember 1985; the new President, Marco
Vinicio Cerezo Arévalo, inaugurated 14 Jan-
uary 1986; judicial review of legislative acts;
legal education at University of San Carlos
of Guatemala; has not accepted compulsory
IC] jurisdiction :
National holiday: dependence Day, 15
September
Branches: traditionally dominant executive;
new 100-member congress installed 14 Janu-
ary 1986; power vested in Office of Presi-
dent; seven-member (minimum) Supreme
Court
Government leader: Marco Vinicio
CEREZO Arévalo, President (since January
1986)
. Suffrage: universal over age 18, compulsory
for literates, optional for illiterates
Elections: last congressional election held 3
November 1985; presidential runoff election
held 8 December 1985
Political parties and leaders: Christian
Democratic Party (DCG), Marco Vinicio
Cerezo Arévalo; National Centrist Union
(UCN), Jorge Carpio Nicolle; National Lib-
eration Movement (MLN), Mario Sandoval
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Alarcon; Institutional Democratic Party
(PID) in coalition with MLN; People’s Dem-
ocratic Force (FDP) in coalition with MLN;
Democratic Party of National Cooperation
(PDCN), Jorge Serrano Elias; Revolutionary
Party (PR) in coalition with PDCN; Social
Democratic Party (PSD), Mario Solarzano
Martinez; National Renewal Party (PNR),
Alejandro Maldonado Aguirre; National
Authentic Center (CAN), Mario David
Garcia; Anti-Communist Democratic Front
(DUA) in coalition with PUA; emerging
Movement for Harmony (MEC) in coalition
with PUA; 14 political groups participated
in national election for a civilian president,
congress, and mayoralties; in runoff elections
between Vinicio Cerezo (DCG) and Jorge
Carpio (UCN), Cerezo won by a 2 to 1 mar-
gin
Voting strength: (November 1985) DCG
648,681 (38.65%), UCN 339,522 (20:23%),
PDCN/PR 231,397 (13.78%), MLN/PID
210,806 (12.56%), CAN 105,478 (6.28%),
PSD 57,362 (3.41%), PNR 52,941 (3.15%), °
PUA/FUN/MEC 82,118(1.91%); (Déceim-
ber 1985) DCB 5] seats, UCN 22 seats, MLN
12 seats, PDCN/PR. 11] seats, PSD 2 seats,
PNR 1 seat, CAN 1 seat
Communists: Guatemalan Labor Party
(PGT); main radical] left guerrilla groups—
Guerrilla Army of the Poor (EGP), Revolu-
tionary Organization of the People in Arms
(ORPA), Rebel Armed Forces (FAR), and
PGT Dissidents
Other political or pressure groups: Feder-
ated Chambers of Commerce and Industry
(CACIF), Mutual Support Group (GAM)
Member of: CACM, FAO, G-77, IADB,
IAEA, IBRD, ICAC, ICAO, ICO, IDA,
IDB—Inter-American Development Bank,
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IRC, ISO, ITU,
IWC— International Wheat Council, OAS,
ODECA, PAHO, SELA, UN, UNESCO,
UPEB, UPU, WFTU, WHO, WMO','13f4ad5f213e5f25e011093aca34f959b1c45986af17b79283c5ac3c10d3c75c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a02f15036673dbe80506ac31b8b8b396819aaa24cf5927092563ef6dcb47b3e',1986,'GG','Guernsey','government',218,'Official name: Bailiwick of Guernsey
Type: independent British crown depend- ,
ency
Capital: St. Peter Port
Political subdivisions: 10 douzaines or r par-
ishes
Legal system: Enelish law and local statute;
justice i is administered by’ the Royal Court ~
Branches: the Lieutenant Governor and
Commander in Chief is the personal repre-
sentative of the Crown and is entitled to sit
and speak in the States of Deliberation (par-
liament); parliament is composed of the *
Bailiff (President ex officio), 12 Conseillers, 2
nonvoting Law Officers of the Crown, 33
popularly elected People’s Deputies, 10
Douzaine Representatives, 2 representatives
of the States of Alderney; States of Election —
(electoral college) elects Jurats and Con-
seillers—it is composed of the Bailiff, 12 Jur-
ats, 12 Conseillers, 2 Law Officers, 33
People’s Deputies, 34 Douzainée Representa-
tives, and 4 Alderney representatives (for
election of Conseillers nly); Alderney has its
own popularly elected President and States’
(12 members) and its own Court; Sark has
mixture of feudal and popular government
Government leader: Lt. Gen. Sir Alexander
BOSWELL, Lieutenant Governor and
Commander i in Chief (since 1985); Sir
Charles Frossard, Bailiff and President of
the States (since 1982)
Suffrage: universal adult over 18
Communists: none —','79532235bd0d715bd69dea3759416615bca5dee455a0142d06dc77d32d48fecf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d3e5b9aa9fbe437aa43d22dbf3d745c115e65466f0bcae059bf096d7260aa45',1986,'GY','Guyana','government',222,'Official name: Cooperative Republic of
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 6 government dis-
tricts
Legal system: based on English common
law with certain admixtures of Roman-
Dutch law; has not accepted compulsory ICJ
jurisdiction ~
National holiday: Republic Day, 23 Febru-.
ary
Branches: Executive President, who ap-
points and heads a cabinet; unicameral legis-
lature (53-member National Assembly)
elected by proportional representation every
five years
Government leader: Hugh Desmond
HOYTE, President (since August 1985);
Hamilton GREEN, Prime Minister (since
August 1985)
Suffrage: universal adult over age 18
Elections: last held in December 1985 -
Political parties and leaders: People’s Na-
tional Congress (PNC), Hugh Desmond
- Hoyte; People’s Progressive Party (PPP),
Cheddi Jagan; Working People’s Alliance
(WPA), Rupert Roopnarine, Clive Thomas,
Walter Omawale, Eusi:K wayana, Moses
Bhagwan, Kenneth Persand; United Force
(UF), Feilden Singh; Vanguard for Libera-
tion and Democracy (VLD; also known as
Liberator Party), Ganraj Kumar, Dr. J. K.
Makepeace Richmond; Democratic Labor
Movement (DLM), Dr. Paul Tennassee
Voting strength: (1985 election, unofficial
returns) 78% PNC (42 seats), 16% PPP (8
seats), 4% UF (2 seats), 2% WPA (1 seat)
Communists: est. 100 hardcore within PPP;
top echelons of PPP and PYO (Progressive
Youth Organization, militant wing of the
PPP) include many Communists, but rank
and file is conservative and non-Communist;
small but unknown number of orthodox
Marxist-Leninists within PNC, some of |
whom are PPP turncoats
Other political or pressure groups: Trades
Union Congress (TUC); Working People’s
Vanguard Party (WPVP); Guyana Council
of Indian Organizations (GCIO); Civil Liber-
ties Action Committée (CLAC); the latter
two organizations are small and active but
not well organized —
Member of: CARICOM, CDB, FAO, G-77,
GATT, JADB, IBA, IBRD, ICAO, IDA,
IDB—Inter-American Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
IRC, ISO, ITU, NAM, OAS (observer),
PAHO, SELA, UN, UNESCO, UPU,
WFTU, WHO, WMO','9d090d02a5eff764cf2d1f78d171f63e52128b6109633a3dc96c7a18e9a36ee6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fee009c0dce3d5e02cb754fca81d38f4a0110891647254b192f02f9f2c82080',1986,'HT','Haiti','government',226,'Official name: Republic of Haiti
Type: republic .
Capital: Port-au-Prince
Political subdivisions: five departments (de-
spite constitutional provision for nine) —
Legal system: based on Roman civil law
system; constitution adopted 1964 and ;
amended 1971 and 1983; legal education at
State University in Port-au-Prince and pri-
vate law colleges in Cap-Haitien, Les Cayes,
Gonaives, and Jérémie; accepts compulsory _
IC] jurisdiction
National holiday: Independence Day, 1 Jan-
uary
Branches: interim government following the
end of 29 years of Duvalier family rule; uni-
cameral legislature (59-member National
Assembly) suspended following coup; judi-
ciary appointed by President before coup
Government leader: Lt. Gen. Henri
NAMPHY, President, National Council of
Government (CNG; since February 1986),
two other CNG members, and 12-member
cabinet
Suffrage: universal over age 18
Elections: constitution as amended in 1983
named Jean-Claude Duvalier President for
Life and granted him authority to name his
successor; most recent legislative election
held February 1984; talk of new elections in
18 to 24 months, following coup and
_Duvalier’s self-imposed exile
Political parties and leaders: Haitian Chris-
tian Democratic Party (PDCN), Sylvio
Claude; Haitian Social Christian Party
(PSCH), Grégoire Eugéne; Haitian Demo-
cratic Action (ADH), Alexandre LeCouge;
107
National Rallying Democratic Party
(PADRANA), Constant Pognon
Voting strength: (1984 legislative elections)
Assembly comprised of regime loyalists be-
fore coup
Communists: United Party of Haitian Com-_
munists (PUCH), René Théodore (party in °
exile in the Dominican Republic); Haitian
Workers Party (PTH; pro-Chinese Marxist),
Sergio Gilles
Other political or pressure groups: none
Member of: FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IRC, ITU, OAS, PAHO,
SELA, UN, UNESCO, UPU, WHO, WMO,
WTO :','67a33ed91db1080a610c797d4c45361251deb87e134d691477cf8a03f49c37d7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60a7677bc6b293afc999fb6734fb14c4886ddd76bf0d1379f81a8516d78e8dc9',1986,'HN','Honduras','government',229,'Official name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: rooted in Roman and Spanish
civil law; some influence of English common
law; new constitution became effective in
January 1982; the nine Supreme Court jus-
tices are appointed by Congress; legal educa-
tion at University of Honduras in
Tegucigalpa; accepts ICJ jurisdiction, with
reservations
National holiday: Independence Day, 15
September
Branches: constitution provides for elected
President, unicameral legislature
(184-member National Congress), and na-
tional judicial branch
Government leader: Jost ALCONA Hoyo,
President (since January 1986)
Suffrage: universal and compulsory over age _
18
Elections: national election for president
and legislature held every four years; last
election held November 1985; legislature’
chosen by proportional representation; 282
county councils
Political parties and leaders: Liberal Party
(PLH)—party president, Romualdo Bueso
Penalba; faction leaders, Roberto Suazo
Cordova (Rodista faction), José Azcona Hoyo
(Azconista subfaction), Jorge Bueso Arias
(ALIPO faction), Jorge Arturo Reina
(M-Lider faction); National Party (PNH)—
party president, Rafael Leonardo Calleias;
faction leaders, Juan Pablo Urrutia (MUC
faction); Ricardo Zaiiga Augustinus
(Officialista faction), Mario Rivera Lopez
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
(Riverista subfaction), and Rafael Leonardo
Callejas (MONARCA faction); National In-’
novation and Unity Party (PINU)—Miguel
Andonie Fernandez; Christian Democratic
Party (PDCH)—Efrain Diaz Arivillaga
Voting strength: (1985 election) 1.6 million
out of 1.8 million eligible voters cast ballots;
PLH 51%, PNH 45%, PINU 1.5%, PDCH
1.9%, legislative seats—PLH 67, PNH 63,
PINU 2, PDCH 2
Communists: up to 1,500; Honduran leftist
groups—Communist Party of Honduras
(PCH), Communist Party of
Honduras/Marxist-Leninist (PCH/ML),
Morazanist Front for the Liberation of Hon-
duras (FMLH), People’s Revolutionary
Union/Popular Liberation Movement
(URP/MPL), Popular Revolutionary Forces-
Lorenzo Zelaya (FPR/LZ), Socialist Party of
Honduras Central American Workers Revo-
lutionary Party (PASO/PRTC)
Other political or pressure groups: National
Association of Honduran Campesinos -
(ANACH), Honduran Council of Private
Enterprise (COHEP), Confederation of
Honduran Workers (CTH), National Union
of Campesinos (UNC), General Workers
Confederation (CGT), United Federation of
Honduran Workers (FUTH)
Member of: CACM, FAO, G-77, IADB,
IBRD, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ISO, ITU, OAS, PAHO, SELA,
UN, UNESCO, UPEB, UPU, WFTU,
WHO, WMO','507f7d4dbe15bf0f2874953daaf50e3c6b26930da7e587875015f0cd9d814094','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a8e7583866d45c5c44d3a1fa7f2ad8ac3846ae7fa15e6dbdf9ae29f1d86d973',1986,'HK','Hong Kong','government',233,'Official name: Hong Kong
Type: British dependent territory; sched-
uled to revert to China in 1997
Capital: Victoria
Political subdivisions: Hong Kong,
Kowloon, and New Territories
Legal system: English common law
Branches: Governor assisted by advisory
Executive Council, legislates with advice
and consent of Legislative Council; Execu-
tive Council composed of governor, four
ex-officio senior officials, and 1] nominated
members; Legislative Council composed of
governor, three ex-officio members, 10 of-
ficial members, 22 appointed unofficial
members and 24 unofficial members elected
indirectly by functional constituencies and
by an electoral college; Urban Council, con-
sisting of 15 elected members and 15 ap-
pointed by Governor, responsible for health,
recreation, and resettlement in urban areas;
Regional! Council (established 1 April 1986),
comprising 12 directly elected members, 9
indirectly elected, 12 appointed, and 3 ex
officio, has similar responsibilities in
nonurban areas; independent judiciary
Government leader: Sir Edward YOUDE,
Governor and Commander in Chief (since
May 1982); Chief Secretary Sir David
AKERS-JONES (since 1985)
Suffrage: limited to 450,000 to 550,000 pro-
fessional or skilled persons
Elections: on three-year cycle for Urban and
Regional Councils; last held March 1986;
indirect elections for Legislative Council
held for first time in September 1985 and
planned for three-year intervals
Political parties: no significant parties
110
Communists: an estimated 4,000 cadres
affiliated with Communist Party of China
Other political or pressure groups: Federa-
tion of Trade Unions (Communist
controlled), Hong Kong and Kowloon Trade
Union Council (Nationalist Chinese domi-
nated), Hong Kong General Chamber of
Commerce, Chinese General Chamber of
Commerce (Communist controlled), Federa-
tion of Hong Kong Industries, Chinese
Manufacturers’ Association of Hong Kong,
Hong Kong Professional Teachers’ Union
Member of: ADB, ESCAP (associate mem-
ber), IMO, INTERPOL, Multifiber Arrange-
ment, WMO 7
Economy .. 7
GDP: (1985 est.) $33.3 billion, $6,064 per
capita; real growth, 4.0%
Agriculture: agriculture occupies a minor
position in the economy; main products rice,
vegetables, dairy products; less than 20%
self-sufficient; shortages—rice, wheat, water
Major industries: textiles and clothing, tour-
ism, electronics, plastics, toys, watches, and
clocks
Shortages: industrial raw materials
Electric power: 6,142,000 kw capacity
(1985); 17.830 billion kWh produced (1985),
3,290 kWh per capita © sO
Exports: $28.4 billion (f.0.b., 1984), includ-
ing $10.7 billion reexports; principal prod-
ucts—clothing, plastic articles, textiles, elec-
trical goods, wigs, footwear, light metal
manufactures
Imports: $28.6 billion (c.i-f., 1984)
Major trade partners: (1984) exports—32%
US, 18% China, 8% Japan, 5% UK, 5% FRG,
imports—25% China, 24% Japan, 11% US
Budget: (1984 /85) $4.7 billion
Monetary conversion rate: 7.76 Hong Kong
dollars=US$1 (July 1985) ’
Fiscal year: | April-31 March
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 |
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','182f4e3e778fb0dc72a47260bd31ce2c6e837b633841154e05f3e99512c7116f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acbcc85fe88cfc3c8d712481408442e2e992ea9546a232c1f8a1232396146d2c',1986,'HU','Hungary','government',236,'Official name: Hungarian People s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19-megyes (counties),
5 autonomous cities in county status —
Legal system: based on Communist legal
theory, with both civil law system (civil code
of 1960) and common law elements; consti-
tution adopted 1949 amended 1972; Su-
preme Court renders decisions of principle
that sometimes have the effect of declaring
legislative acts unconstitutional: legal educa-
tion at Lorand Eétvés University Faculty of
Law in Budapest and two other schools of
law; has not accepted compulsory ICJ juris- ”
diction
National holiday: Liberation Day: 4 April 5
'' Branches: executive—Presidential Council
(elected by parliament); unicameral legisla-
turé—National Assembly (elected by direct
suffrage); judicial—Supreme Court (elected
by parliament)
Government leaders: Pal LOSONCZI, Pres-
ident, Presidential Council (since April
1967); Gyérgy LAZAR, Premier, Council of |
Ministers (since May 1975) |
Suffrage: universal over age 18
Elections: every five years (last election June
1985); national and local elections are held
separately
Political parties and leaders: Hungarian
Socialist (Communist) Workers’ Party
(MSZMP), sole party: Janios Kadar, General
Secretary (since November 1956; his title
was changed from First Secretary to General
Secretary in March 1985)
Voting strength: (1985 election) 7,700,000
(94%) turnout for multiple-candidate elec-
tion, with only some leading figures running
without opposition ,
Communists: about 870, 992 party members
January 1985)
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Hungary (continued)
Member of: CEMA, Danube Commission,
FAO,.GATT, IAEA, IBRD, ICAC, ICAO,
ILO, International Lead and Zinc Study
Group, IMF, IMO, IPU, ISO, ITC, ITU, UN,
UNESCO, UPU, Warsaw Pact, WFTU,
WHO, WIPO, WMO','2125f6f9c5fc03898c7b15c123817032de5fb3dd7253739695ae553b84ba520e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f7a1953976531aff31b93a1a62901b31688b2ab3d25b4679de6dde7ab5a6925',1986,'ID','Indonesia','government',246,'Official name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 28 first-level adminis-
trative subdivisions or provinces, which are
further subdivided into 282 second-level
areas
Legal system: based on Roman-Dutch law,
substantially modified by indigenous con-
cepts and by new criminal procedures code;
constitution of 1945 is legal basis of govern-
ment; legal education at University of Indo-
nesia, Jakarta; has not accepted compulsory
IC] jurisdiction
National holiday: Independence Day, 17
August
Branches: executive headed by President
who is chief of state and head of Cabinet;
Cabinet selected by President; unicameral
legislature (DPR or House of Representa-
tives) of 460 members (96 appointed, 364
elected); second body (MPR or People’s
Consultative Assembly) of 920 members
includes the legislature and 460 other mem-
bers (chosen by several. processes, but not
directly elected); MPR elects President and
Vice President and theoretically determines
national policy; judicial, Supreme Court is
highest court
Government leader: Gen. (Ret.)
SOEHARTO, President (since March 1968)
Suffrage: universal over age 18 and married
persons regardless of age
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Political parties and leaders: Golkar (quasi-
official “party” based on functional groups),
Lt. Gen. Sudharmono; Indonesia Democ-
racy Party (federation of former Nationalist
and Christian Parties), leader unknown;
United Development Party (federation of
former Islamic parties), John Naro
Voting strength: (1982 election) Golkar
64.1%, Unity Development 28%, Indonesia
Democracy 7.9%
Communists: Communist Party (PKT) was
officially banned in March 1966; current
strength est. at 1,000-3,000, with Jess than
10% engaged in organized activity;
pre-October 1965 hardcore membership has
been estimated at 1.5 million
Member of: ADB, ANRPC, ASEAN, Associ-
ation of Tin Producing Countries, CIPEC,
ESCAP, FAO, G-77, GATT, IAEA, IBA,
IBRD, ICAO, ICO, IDA, IDB—Islamic De-
velopment Bank, IFAD, IFC, THO, ILO,
IMF, IMO, INTELSAT, INTERPOL, IPU,
IRC, ISO; ITC, ITU, NAM, OIC, OPEC,
UN, UNESCO, UPU, WFTU, WHO,
WIPO, WMO, WTO
Official name: Islamic Republic of Iran
Type: theocratic republic
Capital: Tehran
Political subdivisions: 24 provinces, subdi-
vided into districts, subdistricts, counties,
and villages
Legal system: the new constitution codifies
Islamic principles of government
National holiday: Shi‘a Islam religious holi-
days observed nationwide
Branches: Ayatollah ol-Ozma Ruhollah
Khomeini, the leader of the revolution, pro-
vides general guidance for the government, ''
which is divided into executive, unicameral
legislature (Islamic Consultative Assembly), .
and judicial branches
Government leaders: Ayatollah ol-Ozma
Ruhollah KHOMEINI, “Guardian
Jurisprudent” (since February 1979); Ali
KHAMENE! (cleric), President (since Octo-
ber 1981); Mir Hosein MUSA VI- KHAME-
NEI, Prime Minister (since October 1981);
Ali Akbar HASHEMI RAFSANJANI
(cleric), Speaker of Islamic Consultative As-
sembly (since July 19806); Ayatollah Hosein
Ali MONTAZERI, Designated Successor to
Ayatollah Ruhollah Khomeini (22 Novem-
ber 1985) ,
Suffrage: universal over age 15
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Tran (continued)
Elections: elections to select a president held
in August 1985; those to select an Assembly
of Experts to name Khomeini’s successor
held in December 1982; parliamentary eleéc-
tions held in 1984; next presidential election
to be held during the summer of 1989; next
parliamentary elections to be held in 1988
Political parties and leaders: Islamic Re-
public Party ([RP), Ali Khamenei’
Voting strength: reliable figures not avail-
able; supporters of the Islamic Republic
dominate the parliament
Communists: 1,000 to 2,000 est. hardcore;
15,000 to 20,000 est. sympathizers; crack-
down in 1983 crippled the party: trials-of
captured leaders began in laté 1983 and re-
main incomplete
Other political or pressure groups: People’s
Strugglers (Muiahedin), People’s Fedayeen,
and Kurdish Democratic Party are armed
political groups that have been harshly but
not completely repressed by the govern-
ment; other ethnic minorities, local leaders,
and Islamic Committees enforce their:politi- .
cal views through armed militia -
Member of: Colombo Plan, ESCAP, FAO, -
G-77, IAEA, IBRD, ICAC, ICAO, IDA,
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ITU, °
NAM, OIC, OPEC, Economic Cooperation
Organization, UN, UNESCO, UPU, WFTU,
WHO, WMO, WSG, WTO; continued par- -
ticipation in:some of these organizations
doubtful-under the new Islamic constitution
Economy — a
GNP: $80.4 billion (1984) ae ae
Natural resources: petroleum, natural gas, ''
coal, chromium, copper, iron; lead, manga-
nese, zinc, barite, sulfur, coal, emeralds, tur-
quoise :
Agriculture: wheat, barley, rice, sugar beets, .
cotton, dates, raisins, tea, tobacco, sheep,
goats; an illegal producer of opium poppy :» ''
for the international drugtrade: - -
Major industries: crude oil production (2.4
million b/d in 1985) and refining, textiles,.
cement and other building materials, food
processing (particularly sugar refining and -
vegetable oil production), metal fabucatine
(steel and copper)
Electric power: 11,907,600 kW capacity. .
(1985); 41.724 billion kWh Bey (195),
923 kWh per capita —
Exports: $16.2 billion (est., ioe 98% petro-
leum; also carpets, fruits, nuts
Imports: $16.5 billion (est., 1984); machin ..
ery, military supplies, foodstuffs, pharma-
ceuticals, technical services -
Major trade partners: exports—Japan, Tur-~
key, Syria, Italy, Netherlands, Spain,
France, FRG; imports—FRG, Japan, Tur-
key, UK,-Italy
Budget: (FY85) proposed expenditures of .
$42 billion; projected deficit of $4 billion—. -
actual defer likely to Pe higher
Monetary conversion rate: 98 rials=USS1
(official rate) ae
Fiscal year: 21 March-20 March
Communications ae
Railroads: 4,601 km total; 4,509 see l. 435-:
meter gauge, 92 km 1.676-meter gauge’
Highways: 85,000 km total; 36,000km
gravel and-crushed stone, 15,000 kmim- -
proved earth, 19,000 km bituminous and
bituminous-treated surfaces, 15,000 km un- ’
improved earth
I ‘nland waterways: 904 km, excluding the
Caspian Sea, 104 km on the Shatt al Arab
(closed since September 1980 because of -
Iran-Iraq conflict); 3 inland coastal ports on ?
Caspian Sea
Pinslines: crude oil, 5,900 km; refined prod-
ucts, 3,900 km; natural-gas, sontien sh
Ports: 5 major tataden reload Bandar-e
‘Abbas, Bandar-e.Khomeyni; Bandar -
Beheshti, and Bandar-e Bshehr), 12 minor
(Khorramshahr closed)
118
Civil air59 major eae aircraft
Airfields: 165 at. 139-usable; 77 with
permanent-surface runways; 14 with run-
ways over 3,659 m, 16 with runways
2,440-3,659 m,:67 with runways 1,220-
2,439 m
Defense Forces
Branchés: Islamic Ground Forces, Navy, Air
Force, and Revolutionary Guard (includes
Basij militia), Gendarmerie
Military’ manpower: males 15-49,
10,789,000; 6,629,000 fit for military service;
about 462,000 reach military age (21) annu-.
ally
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
i
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Persian
Gulf —
See regional map VIE
Land
434,924 km?; larger then California; 68%
desert, waste, or urban; 18% cultivated; 10%
seasonal and other grazing; 4% forest and
wood
Land boundaries: 3,668 km (including areas
belonging to Iraq and now occupied by Iran
during continuing border war)
, Water
Limits of territorial waters (claimed): 12
nm
Coastline: 58 km
Ofiea! name: Republic of Iraq
Type: republic National Front paverhureil ;
consisting of Ba‘th Party (BPI), weak nation-''
alist parties, and proadministration Kurds
Capital: Baghdad
Political subdivisions: 18 provinces under —
centrally appointed officials’
Legal system: based on Islamic law in spe-
cial religious courts, civil law system else-
where; provisional constitution adopted in
1968; judicial review was suspended; legal
education at University of Baghdad; has not
accepted compulsory IC] jurisdiction -
National holidays: anniversaries of the 1958
and 1968 revolutions are celebrated 14 July
and 17 July; various religious holidays
Branches: Ba‘th Party of Iraq-has been in +
power since 1968 coup; unicameral legisla-
ture (National Assembly)
Government leaders: Saddam HUSAYN,
President (since July 1979); Izzat IBRAHIM,
Deptity Chairman of the Revolutionary.
Command Council (since July 1979)
Suffrage: universal adult
Elections: National Assembly elections held
October 1984; Legislative Council for the
Autonomous Region held September 1980
Communists: est. 2,000 hardcore members
Political or pressure groups: political parties
and activity severely restricted; possibly
some opposition to regime from disaffected
members of the regime, army officers, and
religious and ethnic dissidents
119
Member of: Arab League, FAO, G-77,
IAEA, IBRD,-ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO, IMF, -
IMO, INTELSAT, INTERPOL, ITU, NAM;
OAPEC, OIC, OPEC, UN, UNESCO, UPU;
WFTU, WHO, WIPO, WMO, WSG, WTO .','d7be3d6ca457c5c23bdbc94168366e3a298f518108f1daea5c81d72c0cf6ce3b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bf6e1620f8d17448003809ff843aab99f663d5f61c3bb2052446a4ef130dff2',1986,'IE','Ireland','government',250,'Government leaders: Dr. Patrick J.
HILLERY, President (since 1976); Dr. Gar- -
ret FITZGERALD, Prime Minister (since
1982): Richard SPRING, Deputy Prime
Minister (sirice 1982)
Suffrage: universal over age 18
Elections: Dail (lower house) elected every
five years—last. election November 1982;
President elected for seven- year term—last
election October 1983
Political parties and deadeee Fianna Fail,
Charles Haughey; Labor Party, Richard
Spring; Fine Gael, Garret F itzGerald; Com-
munist Party of Ireland, Michael O''Riordan,
Workers’ Party, Tomas MacGiolla; Sinn
Fein, Gerry Adams; Progressive Democrats,
Desmond O''Malley
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Voting strength: (1982 election) Dail—
Fianna Fail, 75 seats; Fine Gael,.70 seats;
Labor Party, 16 seats; independents, 3 seats;
Workers’ Party, 2 seats ti
Communists: under 500
Member of: Council of Europe, EC,“EMS,::
ESRO (observer), FAO, GATT, IAEA,
IBRD, ICAO, ICES, IDA, IEA, IFAD, IFC, -
ILO, IMF, IMO, INTELSAT, INTERPOL,’
IPU, ISO, ITC, ITU, IWC—International
Wheat Council, OECD, UN, UNESCO,
UPU, WHO, WIPO, WMO, WSG','b930d32ce85d502cb451a696c34a4fac0c0965961bef10279490dc5866a587e5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ad049d0e3e1b5c7264c1b0158f41d3c47b5055f100fbb85032b1d0d4f03bc82',1986,'IL','Israel','government',254,'Official name: State of eel:
Type: republic
Capital: Jerusalem; not recognized by US, ,
which maintains the Embassy i in Tel Aviv
Political subdivisions: six administrative
districts
Legal system: mixture of English common
law, British Mandatory regulations, and, in
personal, area, Jewish, Christian, and Muslim
legal systems; commercial matters regulated
substantially by codes adopted since 1948;
no formal constitution; some of the functions
of a constitution are filled by the Declaration
of Establishment (1948), the basic laws of the
122
Knesset (legislature)—relating to the Knes-
set, Israeli lands, the president, the govern- *
ment—and the Israel citizenship law; no
judicial review of legislative acts; — edu-
cation at Hebrew. University of Jerusalem; in
December 1985 Israel informed the UN Sec-
retariat that it would no longer accept com-
pulsory ICJ jurisdiction
sCiiaeal holidays: ee declared ides a :
pendence on 14 May 1948; because the Jew-
ish calendar is lunar, however, the holiday .
varies from year to year; all major J ewish —
religious holidays are also observed as na-
tional holidays
Branches: president has largely ceremonial —
functions, except for the authority to decide
which political leader should try to forma.
ruling coalition following an election or the
fall of a previous government; executive
power vested in Cabinet; unicameral parlia-.
ment (Knesset) of 120 members elected un-_
der a system of proportional representation;
legislation provides fundamental laws in
absence of a written constitution; two dis-
tinct court systems (secular and religious)
Government leaders: ; Chaim HERZOG,
President (since May 1983), Shimon PERES,
Prime Minister (since September 1984); in
October 1986 Vice Prime Minister and For-
eign Minister. Yitzhak SHAMIR and Peres
are to trade.government positions ,
Suffrage: universal over age 18 -
Elections: held every four years unless re- _
quired by dissolution of Knesset; last election
held in July. 1984; next scheduled for No-
vember 1988
Political parties and leaders: Israel
currently hasa. national | unity government
comprising 8 parties that hold 97 of the '' :
Knesset’s 120 seats; members of the unity
government—Labor Alignment, Prime
Minister Shimon Peres; Likud Bloc, Yitzhak
Shamir; Shinui Party, Minister of Communi-
cations Amnon Rubenstein; National Reli-
gious Party, Minister of Religious Affairs
Yosef Burg; SHAS, Minister, of Interior rs
Yitzhak Peretz; ‘Agudat Israel, Meriachem | ''
Porush; Morasha, Chaim Druckman; ge
Ometz, Yigael Hurwitz; opposition parties—
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
2
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Tehiya-Tzomet, Yuval Ne’eman; MAPAM,
Eliezer Granot, Citizens’ Rights Movement, |
Shulamit Aloni; RAKAH (Communist
party), Meir Wilner; Progressive List for
Peace, Muhammad Mi‘ari; TAMI, Aharon
Abuhatzeira; Kakh, Meir Kahane
Voting strength: Labor Alignment, 40 seats;
Likud, 41 seats; MAPAM, 6 seats; Tehiya-
Tzomet, 5 seats; Citizens’ Rights Movement,
4 seats; RAKAH, 4 seats; SHAS, 4 seats; Na-
tional Religious Party, 4 seats; Shinui Party, |
3 seats; Morasha, 2 seats; Agudat Yisrael, 2
seats; Progressive. List for Peace, 2 seats;
Ometz, | seat; Kakh, 1 seat; TAMI, 1] seat
Communists: RAKAH (predominantly Arab
but with Jews in its leadership) has some
1,500 members
Other political or pressure groups: Black
Panthers, a loosely organized youth group
seeking more benefits for oriental Jews;
Gush Emunim, Jewish rightwing nationalists
pushing for freedom for Jews to settle any-
where on the West Bank; Peace Now critical
of government’s West Bank/Gaza Strip and
Lebanon policies.
Member of: FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IDB—Inter-American ©
Development Bank, IFAD, IFC, ILO, IMF,
IMO, IOOC, INTELSAT, INTERPOL,
IPU, ITU, [WC—International Wheat
Council, OAS (observer), UN, UNESCO,
UPU, WHO, WIPO, WMO, WSG, WTO
Economy a
GNP: $25.9 billion (1985, in 1985 prices),
$6,270 per capita; 1985 growth of real GNP
2.0%
Natural resources: copper, phosphates, bro-
mide, potash, clay, sand, sulfur, bitumen,
manganese . ;
Agriculture: main products—citrus and
other fruits, vegetables, cotton, beef and
dairy products, poultry products
Major industries: food processing, diamond
cutting and polishing, textiles and clothing;
chemicals, metal products, trarisport equip-
ment, electrical equipment, miscellaneous
machinery, potash mining, high-technology
electronics
Electric power: 4,750,000 kW capacity.
(1985); 15.504 billion kWh produced ( 1985), -
8,755 kWh per capita
Exports: $6.2 billion (f.0.b., 1984), major
items—polished diamonds, citrus and other .
fruits, textiles and-clothing, processed foods, ©
fertilizer and chemical products, electronics;
tourism is important foreign exchange
earner
Imports: $8.9 billion (f.0.b., 1984), major
items—military equipment, rough
diamonds, oil, chemicals, machinery, iron _.
and steel, cereals, textiles, vehicles, ships,
and aircraft —
Major trade partners: exports—US, UK,
FRG, France, Belgium, Luxembourg, Italy;
imports—US, FRG, UK, Switzerland, Italy,
Belgium, Luxembourg -
Budget: public revenue $11.5 billion, ex- .
penditure $15.5 billion (FY82/83) —
Monetary conversion rate: the Israeli pound
was allowed to float on 31 October 1977; the
shekel became the unit of account on 1 Oc-
tober 1980 (1 shekel=10 Israeli pounds);
293.2 shekels=US$1 (average conversion _
rate for 1984); 1,500 shekels=US$] (official
exchange rate year end 1985); new shekel
introduced in September 1985 (1,000 old
shekels=1 new shekel)
Fiscal year: 1 April-31 March','7542294479c0a72d28c6c454044d2f766c0774993cc5741cf6dd25d0198e13fe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('362b9938e7c65564652e699759619e9c1d63147a71cd7e20b3c48ef0264f9f0e',1986,'IT','Italy','government',257,'Official name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides
for establishment of 20 regions; five with
special statutes (Sicilia, Sardegna, Trentino-
Alto Adige, Friuli-Venezia Giulia, and Valle
d’ Aosta) have been functioning for some
time, and the remaining 15 regions with reg-
ular statutes were instituted on 1 April 1972;
95 provinces, 8,08] communes
Legal system: based on civil law system,
with ecclesiastical law influence; constitu-
tion came into effect 1 January 1948; judicial
. review under certain conditions in Constitu-
tional Court; has not accepted compulsory
IC] jurisdiction
National holiday: Anniversary of the Re-
public, 2 June
Branches: executive—President empowered
to dissolve Parliament and call national elec-
tion; he is also Commander of the Armed
Forces and presides over the Supreme De-
fense Council; otherwise, authority to gov-
ern invested in Council of Ministers; bicam-
eral legislature—popularly elected Parlia-
ment (315-member Senate, 630-member
Chamber of Deputies); independent judicial
establishment
Government leaders: Francesco COSSIGA,
President (since July 1985); Bettino CRAXI,
Premier (since August 1983)
Suffrage: universal over age 18 (except in
senatorial elections, where minimum age is
25)
124
Elections: national election for Parliament
held every five years (most recent, June
1983); provincial and municipal elections
held every five years with some out of phase;
regional elections every five years (held June
1980)
Political parties and leaders: Christian
Democratic Party (DC), Ciriaco DeMita :
(political secretary); Communist Party (PCI),
Alessandro Natta (secretary general); Social-
ist Party (PSI), Bettino Craxi (party secre-
tary); Social Democratic Party (PSD),
Franco Nicolazzi (party secretary); Liberal
Party (PLI), Alfredo Biondi (secretary gen-
eral); Italian Social Movement (MSI), Giorgio
Almirante (national secretary); Republican -
Party (PRI), Giovanni Spadolini (political
secretary) ,
Voting strength: (1983 election) 32.5% DC,
80.5% PCI, 11.3% PSI, 6.6% MSI, 5.2% PRI,
4.0% PSDI, 3.0% PLI :
Communists: 1,673,751 members (1983)
Other political or pressure groups: the Vati-
can; three major trade union confederations
(CGIL—Communist dominated, CISL—
Christian Democratic, and UIL—Social
Democratic, Socialist, and Republican); Ital-
ian manufacturers association (Confindus-
tria); organized farm groups
Member of: ADB, ASSIMER, CCC, Council
of Europe, DAC, EC, ECOWAS, EIB,
ELDO, EMS, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IEA, IFC, THO, ILO, International Lead
and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IPU, IRC,
ITC, ITU, NATO, OAS (observer), OECD,
UN, UNESCO, UPU, WEU, WHO, WIPO,
WMO, WSG
Official name: Republic of the Ivory Coast
Type: republic; one-party presidential re-
gime established 1960
Capital: Abidjan (capital city changed to :
Yamoussoukro in March 1983 but not Tecog- ;
nized by US)
Political subdivisions: 34 prefectures subdi-
vided into-161 subprefectures
Legal system: based on French civil law
system and customary law; constitution
adopted 1960; judicial review in the Consti- _
tutional Chamber of the Supreme Court;
legal education at Abidjan School of Law; —
has not accepted compulsory ICJ jurisdic-
tion :
National holiday: 7 December
Branches: President has sweeping powers,
unicameral legislature (175-member Na- -
tional Assembly), separate judiciary
Government leader: Félix HOUPHOUET-
BOIGNY, President.(since 1960)
Suffrage: universal over age 21.
Elections: legislative and municipal elec-
tions were held in October 1985;
Houphouét-Boigny reelected in October
1985 to his fifth consecutive five-year term;
next round of national elections scheduled -_
for October 1990
Political parties and leaders: Democratic
Party of the Ivory Coast (PDCI), only party;
Houphouét-Boigny firmly controls party .
Communists: no Communist party; possibly
some sympathizers
Member of: A[DB, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), Entente, FAO,
G-77, GATT, IAEA, IBRD, ICAO, ICO,
IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU, Niger
River Commission, NAM, OAU, OCAM,
UN, UNESCO, UPU, WHO, WIPO, WMO,
WTO','8aa8082d69bda2e12f60757d266bc6419681825aa602a78bf4f6cf780af11f56','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06db42188f0a8fd61ef728e55ad707f07640d230704f253ff2cc4c99794e277d',1986,'JM','Jamaica','government',261,'Official name: Jamaica
Type: independent state within Common-''
wealth, recognizing Elizabeth II as head of
state
Capital: Kingston Re
Political subdivisions: 12 parishes and the
Kingston-St. Andrew corporate area’ -
Legal system: based on English common
law; has not accepted compulsory 10%) juris~ i
diction
National holiday: Independence Day; first
Monday in August
Branches: cabinet cal By Prime Minis-
ter; bicameral legislature—21-member Sen-
ate (13 nominated by the Prime Minister,
eight by opposition leader, if''any; currently
no official opposition because of People’s
National Party boycott of December 1983°- °
election; eight non-Jamaica Labor Party -
members appointed to current Senate by -
Prime Minister Seaga), 60-member elected
House of Representatives; judiciary follows’
British tradition under a Chief Justice --
Government leaders: Edward Philip George
SEAGA, Prime Minister (since Novembet
1980); Sir Florizel A. GLASSPOLE, Gover-
nor General (since 1973) . .
Suffrage: universal adult at age 18 * + *
Elections: at discretion of Governor General
upon advice of Prime Minister but within ~~
five years; last held 15 Decne 1983
Political parties oe leaders: Jamaica no
Party (JLP), Edward Seaga; People’s Na- *""
tional Party (PNP), Michael: Maniley; *’
Workers’ Party of Jamaica (WP), Trevor
Munroe
ody
127
Voting strength: in the 1983 general elec-
tions 54 seats were uncontested; in 6 con-
tested seats the JLP won overwhelmingly
against several small fringe parties; the PNP
and WP] boycotted:the election; in 1980
general elections approx. 58.8% JLP (51 seats
in Househ 41.2% ENE _ ee)
Communists: wane Party of Jamaica
(Marxist-Leninist) :
Other political or pressure groups: New
World Group (Caribbean regionalists, na-
tionalists, and leftist intellectual fraternity);
Rastafarians (Negro religious/racia] cultists,
pan-Africanists); New Creation Interna-
tional Peacemakers. Tabernacle (leftist
group); Workers Liberation League (a Marx-
ist coalition of students / labor)
ens of. CARICOM, Commonwealth,
FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, ICAO, ICO, IDB—Inter-American
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTERPOL, ISO, ITU, NAM, OAS,
PAHO, SELA, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO, WTO -','8c0ded463c5baddb50d45db424cfcc394b7a4366a9510192a059d037b569165a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a68a2679409f0e08e57a82a0dc80b06ec8091fa39ee00fc665ed9bf94c609c5c',1986,'JE','Jersey','government',266,'Official name: Bailiwick of Jersey
Type: British crown dependency :
Capital: St. Helier
Political subdivisions: 12 parishes
Legal system: English law and local statute;
justice is administered by the Royal-Court .
National holiday: pesidey of the Queen; 16
June
Branches: the Lieutenant Governor and .
Commander in Chief is the personal repre- -
sentative of the Crown and is entitled to sit |
and speak in the Assembly of the States (leg-
islature) but not vote; the Assembly is pre-
sided over by the Bailiff who has a right of
dissent and a casting vote; it consists of 12
senators (elected for six years), 12 constables
(triennial), and 29 deputies (triennial); the
Crown is ultimately responsible for the
island’s ““good’’ government
Government leaders: Adm. Sir William
PILLAR, Lieutenant Governor and Com-
mander in Chief (since 1985); Peter CRILL,
Bailiff, President of the Assembly of the
States and the Royal Court (since 1975)
Suffrage: universal adult
Communists: probably none','e24307a3ac8ee21d20bba859afe4a86517353a80381bc6e6cad7b7412c0b49e1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a61538a518450efab56d1fa28750ce5b4b865dfa3ed42debef39c5f6628ae467',1986,'JO','Jordan','government',270,'Official name: Hashemite Kingdom of Jor-.
dan
Type: constitutional monarchy.
Capital: Amman
Political subdivisions: eight governorates
under centrally appointed officials
Legal system: based on Islamic law and..
French.codes; constitution adopted 1952;
judicial review of legislative acts in a spe- *
cially provided High Tribunal; has not ac-
cepted compulsory ICJ jurisdiction ..
National holiday: Independence Day, 25
May . .
Branches: King holds balance of power; —
Prime Minister exercises executive authority
in name of King; Cabinet appointed by. King
and responsible to parliament; bicameral
parliament with House of Representatives,
dissolved: by King in February 1976, and --.
reconvened in January 1984, following na-. .
tional elections; Senate last appointed by -
King in January 1984; secular court system
based on differing legal systems of the,
former Transjordan and Palestine; law
Westerriin concept and structure; Sharia ~
(religious) courts for Muslims, and religious ,
community council courts for non-Muslim
communities; desert police carry out quasi-
judicial functions in desert areas | _
131
Govérnment leader: HUSSEIN I, King
(since August 1952)
Suffrage: universal adult at age 20
Political parties and leaders: political party
activity illegal since 1957 -
Communists: party actively repressed,
membership estimated at less than 500
Member of: Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IPU, ITU,
NAM, OIC, UN, UNESCO, -UPU, WFTU,
WHO, WIPO, WMO, WTO','64856d823c3fc76736c408519e7946540ecc533ed6e301a9baaa19efb617fd45','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4833bc34a15dc19c79b3c0fd0ffaf04abe43d1c3b2671f75012076887f6423e1',1986,'KE','Kenya','government',274,'Official name: Republic of Kenya
Type: republic within Commonwealth
Capital: Nairobi
Political subdivisions: 7 provinces plus
Nairobi.area
Legal system: based on English common
law, tribal law, and Islamic law; constitution
enacted 1963; judicial review in Supreme
Court; legal education at Kenya School of
Law in Nairobi; accepts compulsory IC]
jurisdiction, with reservations; constitutional
amendment in 1982 made Kenya a de jure :
one-party state
National holiday: Jamhuri Day, 12 Decem-
ber
Branches: President and Cabinet responsible
to unicameral legislature (National Assem-
bly) of 170 seats, 158 directly elected by con-
stituencies and 12 appointed by the Presi-
dent; High Court, with Chief Justice and at
least 11 justices, has unlimited original juris-
diction to hear and determine any civil or
criminal proceeding; provision for system of
courts of appeal:
Government leader: Daniel T. arap MOI,
President (since 1978)
Suffrage: universal over age 21
’ Elections: Assembly at least every five years;
present National Assembly and President
elected September 1983
Political party and leader: Kenya African
National Union (KANU), Kenya’s sole legal
political party, Daniel arap Moi, president
Voting strength: KANU holds all seats in the -
National Assembly
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Communists: may bea few. Communists
and sympathizers
Other political or pressure groups: labor
unions
Member of: AEDB, Commonwealth, FAO,
G-77, GATT, IAEA, IBRD, ICAO, ICO,
IDA, IFAD, IFC, ILO, IMF, IMO.,,. -
INTELSAT, INTERPOL, IRC, ISO, ITU,
{WC—International Wheat Council, NAM,
OAU, UN, UNDP, UNESCO, UPU, WHO, -
WIPO, WMO, WTO
Official name: Federation of St. Christopher
and Nevis
Type: independent state within Common- -
wealth, recognizing B Elizabeth II as Chief of
State
Capital: Wciene. St. Christopher;. Charl
estown, Nevis
Political Subilioidone. 11 districts .
Legal system: based on English common
law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and
Windward Islands
Branches: legislative, 11-member popularly
elected House of Assembly; executive, Cabi-
net headed by Prime Minister; separate
Nevis Island Legislature and Nevis Island
Assembly headed by Premier .
Government leaders: Dr. Kennedy
Alphonse SIMMONDS, Prime Minister
(since.1980); Sir Clement ARRINDELL, |
Governor General (since 1981)
Suffrage: universal adult suffrage
Elections: at least every five years; last elec-
tion held June 1984
Political parties and leaders: St. Christopher
and Nevis Labor Party (SKNLP), Lee _
Moore; People’s Action Movement (PAM),
Kennedy Simmonds; Nevis Reformation
Party (NRP), Simeon Daniel
Voting strength: (June 1984 election) House
of Assembly—PAM, 6 seats; SKNLP, 2 seats;
NRP, 3 seats
Communists: none known
Member of: CARICOM, Commonwealth,
FAO, IBRD, IMF, ISO, OAS, UN
Official name: St: Lucia
Type: independent state within Common- _
wealth, recognizing Elizabeth TI as Chief of .
State . .
Capital: Castries
Political subdivisions: 16 parishes’...
Legal system: based on English common
law; constitution of 1960; highest judicial
body is Court of Appeal of: Tepward and -
Windward Islands.
Branches: bicameral legislative (Senate,
House of Assembly); executive, Cabinet:
headed by Prime Minister
Government leaders: John G. M. COM-.
PTON, Prime Minister (since February
1975); Sir Allen LEWIS, Governor General -
(since December 1982) . ee
Suffrage: universal adult over age 18
Elections: every five years; last election held’
May 1982
Political parties and leaders: United
Workers’ Party (UWP), John Compton;''St. © -
Lucia Labor Party (SLP), Julian Hunte; Pro-
gressive Labor Party (PLP), George Odlum |
Voting strength: (1982 election) House of
Assembly—UWP, 14 seats; SLP, 2 seats; .
PLP, 1 seat
Communists: negligible
Member of: CARICOM, FAO, G-77, GATT
(de facto), IBRD, ICAO, IDA, IFAD, IFC,
ILO, IMF, IMO, NAM, OAS, PAHO, UN, |
UNESCO, UPU, WFTU, WHO, WMO
Official name: St. Vincent and the Grena-
dines
Type: independent state within Common-
wealth, recognizing Elizabeth II as Chief of
State
Capital: Kingstown
Legal system: based on English common
law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and
Windward Islands
Branches: bicameral legislature (13-member
elected House of Representatives and
6-member appointed Senate), judiciary (Su-
preme Court)
Government leaders: James “Son” MITCH-
ELL, Prime Minister (since 1984); Sir Joseph
EUSTACE, Governor General (since Febru-
ary 1985)
Suffrage: universal adult at age 18
Elections: évery five years; last‘held 18 July
1984
Political parties and leaders: New Demo-
cratic Party (NDP), James “Son” Mitchell;
St. Vincent Labor Party (SVLP), Hudson
Tannis; United People’s Movement (UPM),
Renwick Rose and Oscar Allen; Movement
for National Unity (MNU), Ralph Gonsalves
Voting strength: (1984 election) House of
Assembly—NDP, 9 seats; SVLP, 4 seats
Member of: CARICOM, FAO, G-77, GATT
(de facto), IBRD, ICAO, IDA, IFAD, IMF,
IMO, OAS, UN, UNESCO, UPU, WFTU,
WHO','b95d1fbcb926c35de56504c929a5c8f0817b3a9a4496a7ca0f7e4f88ae1b0dff','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('434182025315804aa21cb1d99727158cd81ca8ae885e9fd753ed5bc275937b29',1986,'KI','Kiribati','government',278,'Official name: Republic of Kiribati
Type: republic
Capital: Tarawa
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Kiribati (continued)
Branches: unicameral legislature
(35-member House of Assembly); nationally .
elected President .
Government leader: leremia T. TABAL,
President (since July 1979).
Political parties and leaders: Gilbertese Na-
tional Party, Christian Democratic Party
Member of: ADB, Commonwealth, ESCAP
(associate member), GATT (de facto), ICAO,
SPF
Official name: Democratic People’ s Repub-
lic of Korea
we
ty
Type: Communist state; one-man rule we,
Capital: P’yongyang
Political subdivisions: nine provinces, four
special cities (Pyongyang, Kaeséneg; ..
Namp’o, and Ch’ongjin)
Legal system: based on German civil law
system with Japanese influences and Com-
munist legal theory; constitution adopted *
1948 and revised 1972; no judicial review of
‘legislative acts; has not accepted compulsory
ICJ jurisdiction
National holiday: 9 September
Branches: Supreme People’s Assembly theo-.
retically supervises legislative and judicial
functions; State Administration Council
(cabinet) oversees ministerial operations = *
Government leaders: KIM Il-song, President
(since December 1972); KANG Song-san,
Premier (since January 1984) .
Suffrage: universal at age 17
Elections: election to SPA every four years,
but this constitutional provision not neces: _
sarily followed—last election February 1982
Political party and leaders: Korean
Workers’ Party (KWP); Kim I]-song, General
Secretary, and his son, Kim Chong- il, Secre-
tary
Communists: KWP claims membership of
about 2 million, or about 11% of population
Member of: FAO, G-77, IAEA, ICAO, IPU,
ITU, NAM, UNCTAD, UNESCO, UPU,
WFTU, WHO, WIPO, WMO; official ob-
server statusatUN ~"" a
Official name: Republic sf Korea
Type: republic; power deitntlieed ina
strong executive
Capital: Seoul
Political subdivisions: nine provinces, four
special cities; governors/mayors centrally
appointed ~
Legal system: combines elements of conti-._
nental European civil law systems, Anglo-
American law, and Chinese classical
thought; constitution approved 1980; has not
accepted compulsory IC] jurisdiction
National holiday: Independence Day, 15
August _
Branches: unicameral legislature (National
Assembly), judiciary :
Government leaders: CHUN Doo Hwan,
President (since August 1980); LHO Shin
Yong, Prime Minister (since February 1985)
Suffrage: universal over age 20
Elections: under new constitution of Octo-
ber 1980, President elected every seven
years indirectly by a 5,000-man electoral
college; last election February 1981; four-
year National Assembly, elected in Febru-
ary 1985, consists of 276 representatives, 184
directly elected and 92 appointed on propor-
tional basis by major parties
Political parties and leaders: major party is
government’s Democratic Justice Party
(DJP), Chun Doo Hwan, president, and Roh
136
Tae Woo, chairman; opposition parties are ».
New Korea Democratic Party (NKDP), Lee
Min-woo; Korean National Party (KNP), Lee
Man-sup; several smaller parties
Communists: Communist activity banned.
by government
yh . £3
Other political or pressure groups: Council .
for the Promotion of Democracy; Korean
National Council of Churches; large, poten-
tially volatile student population concen-
trated in Seoul; Federation of Korean Trade.
Unions; Korean Veterans’ Association; Fed-
eration of Korean Industries; Koréan Trad-
ers Association :
Member of: ABD, AfDB, Asian-African Le-
gal Consultative Committee, Asian Parlia-
mentary Union, APACL—Asian People’s .
Anti-Communist League, ASPAC, Colombo
Plan, ESCAP, FAO, G-77, GATT, Geneva
Conventions of 1949 for the protection of
war victims, IAEA, IBRD, ICAC, ICAO,
IDA, IFAD, IFC, THO, IMF, IMO,
INTELSAT, INTERPOL, {PU, IRC, ITU, .
IWC— International Whaling Commission,
IWC—International Wheat Council, UN-
CTAD, UNDP, UNESCO, UNICEF, UN-
IDO, UN Special Fund, UPU, WACL—
World Anti-Communist League, WHO,
WIPO, WMO, WTO; official observer status
at UN','eae47223f81abf5963f92dd7af90263770ef11ab846ceec7b23e139d4aed3f3d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6cb1b8803618392982c40e863fb0cc5b7b907ea898149e201d2910b7b911a98',1986,'KW','Kuwait','government',282,'Official name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Political subdivisions: 4 governorates (Ku-
wait City, Hawalli, Ahmadi, Johra), 25-vot-
ing constituencies
Legal system: civil law system with Islamic
law significant in personal matters; constitu-
tion took effect in 1963; popularly elected
50-man National Assembly (the 15 cabinet
members can also vote) reinstated in March
1981 after being suspended in 1976; judicial:
review of legislative acts not yet determined;
has not accepted compulsory IJ june:
tion :
National holiday: National Day, 25 Febru-
ary
Branches: Council of Ministers; -
legislature—National Assembly
Government leader: Jabir al-Ahmad al-Jabir
Al SABAH, ‘Amir (since December 1977)
Suffrage: adult males who resided in Kuwait
before 1920 and their male descendents (eli-
gible voters, 8. 3% of citizenry)
Elections: National Assembly elected in
February 1985
Political parties and leaders: political par- -.
ties prohibited, some small clandestine
groups are active
Communists: insignificant
Other political or pressure groups: large
(350,000) Palestinian community
Member of: Arab League, FAO, G-77,
. GATT, GCC, IAEA, IBRD, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, IMO, INTELSAT, -
INTERPOL, IPU, ITU, NAM, OAPEC,
OIC, OPEC, UN, UNESCO, UPU, WFTU,
WHO, WMO, WTO
Official name: Lao People’s Democratic
Republic
Type: Communist state
Capital: Vientiane .
Political subdivisions: 16 provinces subdi-
vided into districts, cantons, and villages
Legal system: based on civil law system; has
not accepted compulsory ICJ jurisdiction
National holiday: 2 December
Branches: President; 37-member Supreme
People’s Council; Cabinet; Cabinet is totally
Communist but Council contains a few
nominal neutralists and non-Communists;’
National Congress of People’s Representa- .
tives established the current government
structure in December 1975
Government leaders: SQUPHANOU-
VONG, President (since December 1975);
KAYSONE PHOMVIHAN, Chairman
(since December 1975)
Suffrage: universal over age 18
Elections: elections for National Assembly,
originally scheduled for 1 April 1976, have
not yet been held
Political parties and leaders: Lao People’s
Revolutionary Party (Communist), Kaysone
Phomvihan, party chairman; includes Lao
Patriotic Front and Alliance Committee of
Patriotic Neutralist Forces; other parties
moribund
Other political or pressure groups: non-
Communist political groups moribund; most
leaders have fled the country
M ember of: ADB, Colombo Plan, ESCAP,
FAO, G-77, IBRD, ICAO, IDA, IFAD, ILO,
IMF, INTERPOL, IPU, IRC, ITU, Mekong —
Committee, NAM, UN, UNCTAD,
UNESCO, UPU, WFTU, WHO, WMO,
WTO
139','1160ccdacec9d2716eb5972075a46ec95a9629a34f26ae3c4fc1077f9e8ce574','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1edd0a1294eb2e0fb1ddab7d47ff8d3daf4a94caccacf92ccdbe071d30798a29',1986,'LS','Lesotho','government',287,'Official name: Kingdom of Lesotho
Type: constitutional monarchy under King
Moshoeshoe II; independent member of
Commonwealth
Capital: Maseru
Political subdivisions: 10 administrative
districts
Legal system: based on English common
law and Roman-Dutch law; constitution
came into effect 1966; judicial review of leg-
islative acts in High Court and Court of Ap-
peal; legal education at National University
of Lesotho; has not accepted compulsory ICJ
jurisdiction
National holiday: 4 October
Branches: executive and legislative author-
ity nominally vested in King; real power
rests with 6-man Military Council, estab-
lished after military coup January 1986, 20- -
member Council of Ministers responsible for
administrative duties; judicial—63 Lesotho
courts administer customary law for Afri-
cans, High Court and subordinate courts
have criminal jurisdiction over all residents,
Court of Appeal at Maseru has appellate
jurisdiction
Government leaders: MOSHOESHOE II,
King (since 1966); Maj. Gen. Justinus Mets-
ing LEKHANYA, chairman of Military
Council and Minister of Defense and Inter-
nal Security (since January 1986); other
members of council—Col. E. T.
RAMAEM4A, Col. A. K. MOSOEUNYANE, -
Col. M. K. TSOTETSI, Lt. Thabe LETSIE,
Lt. Col. Joshua Sekhobe LETSIE (since Jan-
uary 1986)
Suffrage: universal for adults
Elections: elections scheduled for Septem-
ber 1985 were boycotted by all opposition
parties because of procedural irregularities;
ruling BNP won all 60 parliamentary seats
by default ,
142
Political parties and leaders: Basotho Na-
tional Party (BNP), Leabua Jonathan; Basu-
toland Congress Party (BCP), Ntsu Mokh-
ehle; Basotho Democratic Alliance (CDA),
C. D. Molapo; National Independent Party
(NIP), A. C. Manyeli; Marematlou Breedom
Party (MFP), B. Khaketla
Voting strength: National Assembly i inoper-
ative as of 20 January 1986
Communists: diplomatic rélations with So-
viet Union, Romania, North Korea, and Yu-
goslavia established in 1983; Soviet Union,
China, and North Korea maintain diplo-
matic presence in Maseru
Member of: ADB, Geis aaltle FAO,
G-77, GATT (de facto), IBRD, ICAO, IDA,
_IFAD, IFC, ILO, IMF, INTERPOL, ITU,
NAM, OAU, SADCC, UN, UNESCO UPU,
WHO, WMO :','6ef63305e7417a19d236d3fc017c683e3de4944fa6425da89cd2025399d98b15','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b5e61b0f28f1b1734f9ed87b87a0eab962e6248f7d4253b37418615e03ee9e8',1986,'LR','Liberia','government',291,'Official name: Republic of Liberia
Type: republic under Hiflitary rule from
April 1980 until January 1986, when it re-
turned to civilian rule
Capital: Monrovia
Political subdivisions: country divided into
13 counties
Legal system: new constitution approved by
nationwide referendum in July 1984 and
implemented in January 1986); judicial.
powers invested in People’s Supreme Court
and lower courts
National holiday: National Redemption. |
Day, 12 April; Independence Day, 26 July
Branches: executive powers held by Presi-
dent, assisted by appointed Cabinet; legisla-
tive powers held by bicameral legislature; —
independent judiciary.
Government leader: Gen. Samuel Kanyon
DOE, President and Commander in Chief
of the Armed Forces (since April-1980) .
Suffrage: universal at-age.18
Elections: presidential and legislative elec-
tions held October 1985; Doe was
proclaimed winner of presidential election
and took office in January 1986
Political parties and leaders: 4 parties par-
ticipated in elections in October 1985; Na-
tional Democratic Party of Liberia, headed
by Samuel Doe; Liberian Action Party; .
Liberian Unity Party; and Unity Party
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Liberia (continued)
Communists: no Communist Party and only
a few sympathizers
Member of: AEDB, ECA, ECOWAS, FAO,
G-77, IAEA, IBRD, ICAO, ICO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
IPU, IRC, ITU, Mano River Union, NAM,
OAU, UN, UNESCO, UPU, WHO, WMO','8aa1662ca3ef698cca74bb471bffc2ba36ac8d7105ddc98a9cdb1870cf4cf5b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bb20a4704bd0be0eb7d5c7fa91e599f3b05055be4614d1efa7f177e94f1d97f',1986,'LI','Liechtenstein','government',295,'Official name: Principality of Libchitelstaii
Tipe: héreditary coristitutional monarchy
Capital: Vaduz
Political subdivisions: 11 communes -
Legal system: principality has its own civil
and penal codés; lowest court is county court
(Landgericht), presided over by one judge,
which decides. minor civil cases and sum-
mary criminal offenses; criminal court ''
(Kriminalgericht), with a bench of five
judges, is for major crimes; another. court of
mixed jurisdiction isthe court of assizes
(three judges) for misdemeanors; Superior 7
Court (Obergericht).and-Supreme Court* -
(Oberster Gerichtshof) are courts of appeal |
for civil and criminal cases (five judges each);
an administrative court of appeal from gov:
ernment actions-and the State Court deter=* .
mine the constitutionality of laws; accepts
compulsory ICJ jurisdiction, with reserva- .
tions
Branches: unicameral legislature (Diet) with
15 deputies elected to four-year terms,
hereditary Prince, independent judiciary
Government leaders: FRANZ JOSEF U,
Prince (since 1938); Hans BRUNHART,
Head of Government (Prime Minister; since
May 1978); the Prince transferred most of «:... .
his executive powers to his son, Prince
HANS ADAM, in eAuaUet rae
apa aces ale?
Elections: every ou years; last clecticn
1986. ‘
Political parties and leaders: Fatherland
Union (VU), Dr. Otto Hasler; Progressive. -’-
Citizens’ Party-(FBP), Dr. Herbert Batliner; =
Christian Social Party, Fritz Kaiser»
Voting strength: (1986) VU 50:2% (8 seats),.
FBP about 41.9% (7 seats)
Communists: none
Member of: Council of Europe, EFTA,.
IAEA, INTELSAT,, INTERPOL, TEU
UNCTAD, UNIDO; UNICEF; UPU,-
WIPO;-considering UN membership; hae ;
consultative status in the EG; under several
146
post-World War I treaties Switzerland han-
dles Liechtenstein’s customs-and represents’. °
the principality abroad on a diplomatic and
consular Jevel whenever requested to do so: ”
by the Liechtenstein Government - ~.-
Economy 2 ae .
NOTE:«Liechtenstein has a prospérous econ: *
omy based primarily on-small-scale light:
industry and some farming; metal industry .
is by far the most prominent sector; high- ~. :°
frequency installations, boilers for central
heating, hardware, small machinery, canned -
goods, furniture and upholstery, chemical: : ..
and pharmaceutical goods, vacuum installa-
tions, optical and measuring instruments, oil 2
tanks, artificial teeth, ceramics, and textiles
are the principal manufactures, intended.
almost entirely for export; industry accounts
for 54% of.total employment; service''sector ~
42% and agriculture and forestry 4%;live- .
stock raising and dairying are the main’
sources of income in the small farm sector;
the sale of postage stamps to foreign collec-
tors, estimated ‘at $10 million-annually, pro-
vides for 10% of state expenditures; compa-
nies incorporated in Liechténstein solely for-
tax purposes provide a further 30% of the
state budget; low business taxes (the maxi-
mum tax rate is 20%) and easy incorporation
rules have induced between 20,000 and
30,000 holding companies, so-called letter
box companies, to establish nominal offices
in the principality; economy is tied closely to
that of Switzerland in.a customs union; no
national accounts data are available
GNP: approximately $15,000 per capita
(1984)
Natural resources: hydroelectric power
Agriculture: livestock, vegetables, corn,
wheat, potatoes, grapes
Major industries: electronics, metal manu-
facturing, textiles, ceramics, pharmaceuti-
cals, food products
Electric power: 23,000 kW capacity (1985);
150 million kWh produced (1985), 5,857
kWh per capita
Exports: (1984) $440 million; 89% EC, 32%
EFTA (24% Switzerland), 29% other
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Budget: (1983) revenues, $108 million; ex-
penditures, $86 million
M onetary conversion rate: 2.17 Swiss.
francs=US$1 (October 1985)','8f86c441c0f2d1cbe8c42673cc5eb21a6bb3fe1490ddb4a96bc1aac96c853c3e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b235c8641f8e8ecab3a6e69958da6c57accd53170fe5f3798b89dd3ce9d6159',1986,'LU','Luxembourg','government',298,'Official name: Grand Duchy of Luxem- .
bourg —
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for
administrative purposes has 3 districts (Lux-
embourg, Diekirch, Grevenmacher) and 12
cantons... ...
Legal system: based on civil law system;
constitution adopted 1868; accepts compul-
sory ICJ jurisdiction
National holiday: 23 June
Branches: parliamentary democracy; seven -
ministers compose Council of Government
headed by President, which constitutes the
executive; it is responsible to the unicameral
legislature (Chamber of Deputies), the
Council of State, appointed for indefinite
term, exercises some powers of an upper
house; judicial power exercised by indepen-
dent courts; coalition governments are usual
Government leaders: JEAN, Grand Duke
(since 1964); Jacques SANTER, Prime Min-
ister (since June 1984)
Suffrage: universal and compulsory over age
18
Elections: every five years for entire Cham-
ber of Deputies; latest elections June 1984 -
Political parties and leaders: Christian So--
cial Party, Jacques Santer, parliamentary
president, and Jean Spautz, party president;
Socialist Workers Party, Ben Fayot, party
president; Social Democrat, Henry Crava-
tte, party president; Liberal, Colette Flesch;
Communist, Dominique Urbany; Indepen-
dent Socialists, Jean Gremling, party presi-
dent; Green Alternative, Jean Huss; Enrélés
de Force -
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4 |
Luxembourg (continued)
Voting strength: (1984) Chamber of
Deputies—Christian Social Paarty, 25; So-
cialist Workers Party, 21; Liberals, 14; Com-
munists, 2; Green Alternative, 2
Communists: 500 party members (1981)
Other political or pressure groups: group of
steel industries representing iron and steel
industry, Centrale Paysanne representing
agricultural producers; Christian and Social-
ist labor unions; Federation of Industrialists;
Artisans and Shopkeepers Federation
Member of: Benelux, BLEU, Council of
Europe, EC, EIB, EMS, FAO, GATT, IAEA,
IBRD, ICAO, IDA, IEA, IFAD, IFC, ILO,
IMF, INTELSAT, INTERPOL, IOOC, IPU,
ITU, NATO, OECD, UN, UNESCO, UPU,
WEU, WHO, WIPO, WMO
Official name: Macau
Type: Chinese territory under Portuguese
administration
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Capital: Lisbon (Portugal)
Political subdivisions: municipality of
Macau and two islands (Taipa and Coloane)
Legal system: Portuguese civil law system
Branches: 18-member Legislative Assembly,
with Governor and 5 appointed, 6 nomi-
nated, and 6 elected representatives
Government leader: vacant since resigna-
tion of former Governor, Rear Adm. Vasco
Fernando Lecte da Almeida e COSTA, on 7
January 1986
Suffrage: Portuguese, Chinese, and foreign
residents over 18
Elections: conducted every four years
Political parties and leaders: Association to
Defend the Interests of Macau; Macau Dem-
ocratic Center; Group to Study the Develop-
ment of Macau; Macau Independent Group
Other political or pressure groups: wealthy
Macanese and Chinese representing local
interests, wealthy pro-Communist
merchants representing China’s interests; in
January 1967 Macau Government acceded
to Chinese demands that gave Chinese veto
power over administration of the enclave
Member of: Multifiber Agreement .','54f9d1c64b39533c3aa42179c79d0c717cc17f75df10f44a3f71a24cc37a7e8c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e079537888bf4dcf8bfb8d9b4d05d69688d7febba71bad2374c965ccdc4524e5',1986,'MZ','Mozambique','government',303,'Official name: Deiioeratie Republic of -
Madagascar. -
Type: eal authority in hands of the Presi-
dent, although Supreme Revolutionary
Council is theoretically ultimate executive .
authority
Capital: Antananarivo
Political subdivisions: 6 provinces ’
Legal systeny: based on French civillaw -
system and traditional Malagasy law; consti-
tution of 1959 modified in October.1972 by.
law establishing provisional government
institutions; new constitution accepted by
referendum in December, 1975; legal educa-
tion at National School of Law, University of
Madagascar; has not accepted compulsory
ICJ jurisdiction . .
National holiday: Independence Day, 26
June
Branches: exbautive 4 19- member
Supreme Revolutionary Council (made up
of military and political leaders); assisted by
cabinet called Council of Ministers; unicam-
eral legislative—Popular National Assem-’ ''
bly; Military Committee for Development;
regular courts are patterned aftér French ~
system, and a High Council of Institutions -
reviews all legislation to determine its consti-
tutional validity
Cobeninient leader: Adm. Didier’:
RATSIRAKA, President (since June eet
Lt..Col. Desire RAKOTOARIJAONA,
Prime Minister (since 1977)
Suffrage: universal over age 18°”
Elections: referendum held in December
1975 gave overwhelming approval to gov-
ernment and new constitution; elections for
Popular National Assembly held in June
1977 and in August 1983; only one political
group allowed to take part in the election,
The National Front for the Defense of the
Revolution, which presented a single list of
candidates; a presidential election in No-
vember 1982 returned President Ratsiraka
with an 80% majority; the challenger, Monja
Jaona, réceived 20% and was later arrested
after leading demonstrations to protest elec-
tion fraud :
Political parties and leaders: seven parties
are now allowed limited political activity
under the national front and are represented
on the Supreme Revolutionary Council: Ad-
vance Guard of the Malagasy Revolution
(AREMA), Didier Ratsiraka; Congress Party
for Malagasy Independence (AKFM), Pastor
Richard Andriamanjato; Movement for Na-
tional Unity (VONJY), Dr. Marojama
Razanabahiny; Malagasy Christian
Demcratic Union (UDECMA), Norbert
Andriamorasata; Militants for the Establish-
ment of a Proletarian Regime (MFM),
Manandafy Rakotonirina; National Move-
ment for the Independence of Madagascar
(MONIMA), Monja Jaona; Socialist Organi-
zation MONIMA (VS MONIMA), Remanin-
dry Jaona
Voting strength: 4.8 million registered vot-
ers (1982); in 1977 local elections, President
Ratsiraka’s AREMA captured approxi-
mately 89.5% of the 73,000 available posi-
tions on 11,400 local executive committees;
AKFM won about 7.3% of the seats,
MONIMA 1.7%, and VONJY 1.4%; ©
UDECMA won only about 45 seats; in the
1988 legislative élection AREMA.won 117.
out of the 137 seats in the Popular National *
Assembly
Communists: Communist party of virtually
no importance; small and vocal group of .
Communists has gained strong position in .
leadership of AKFM, the rank and file of
which is non-Communist ~
Member of: AEDB, re FAO, G-77,
GATT, IAEA, IBRD, ICAO, ICO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
150
INTERPOL, IRC, ISO, ITU, NAM, OAU,
OCAM, UN, UNESCO, UPU, WFTU,
WHO, WMO, WTO
Official name: People s Republic of Mozam:
bique , :
Type: people’s republic
Capital: Maputo .
Political subdivisions: 10 provinces subdi-
vided into 112 districts; administrators are
appointed by central government
Legal system: based on Portuguese civil law
system and customary law
National holiday: Independence Day, 25
June
Branch: unicameral legislature (People’s
Assembly; last’ convened in December 1985)
Government leader: Samora Moisés
MACHEL, President (since June ewe
Sudiaee: universal adult
Elections: general elections announced for
1986
Political parties and leaders: the Mozam-
bique Liberation Front (FRELIMO), led by
Samora Machel, is only legal party
Communists: FRELIMO is a Marxist orga-
nization and maintains close ties to the So-_.
viet Union and its allies but has recently
taken steps to improve-relations with the’
West and neighboring South Africa
Member of: Af{DB, FAO, G-77, GATT (de
facto), IBRD, ICAO,-IFAD, ILO, IMF,
IMO, ITU, NAM, OAU, SADCC; UN,
UNESCO, UPU, WHO, WMO','ea6bb8b044d38e25c4a04cbc13b24faabc2e0593aa4d1c69875d764efa5ac599','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f8d3c28086a4336d470aa54de81477449f8608eee360dc984d90db33fea81e8',1986,'MY','Malaysia','government',309,'Organized labor: 620,000 (1985), about 10% ~
of total labor force; unemployment‘about -.
6.2% of total labor force (1985), but higher in
urban areas
Government : ny
Official name: Malaysia
Type: Federation of Malaysia formed 9 July .
1963 Malaysia: constitutional monarchy _. -
nominally headed by Paramount Ruler
(King); a bicameral Parliament consisting of
a 58-member Senate anda1l54-member
House of Representatives
Peninsular Malaysian states: hereditary
rulers in all but Penang and Melaka where
Governors appointed by Malaysian Govern- -
ment; powers of state governments limited
by federal constitution
Sabah: self-governing state within Malaysia ’
in which it holds 16 seats in House of Repre-
sentatives; foreign affairs, defense, internal
security, and other powers delegated to fed-
eral government
Sarawak: self-governing state within Malay-
sia in which it holds 24 seats in House of
Representatives; foreign affairs, defense,
and internal security, and other powers are
delegated to federal government
Capital: Peninsular Malaysia: Kuala Lum-
pur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 14 states (including
Sabah and Sarawak)
Legal system: based on English common
law; constitution came into force 1963; judi-
cial review of legislative acts in the Supreme
Court at request of Supreme Head of the
Federation; has not accepted compulsory
IC] jurisdiction
National holiday: 31 August, Independence
Day
Branches: nine state rulers alternate as Para-
mount Ruler for five-year terms; locus of
executive power vested in Prime Minister .
153
and Cabinet, who are responsible to bicam-: ”
eral Parliament (Senate, House of Represen-.
tatives); following communal rioting in May--
1969, government imposed state of emer-
gency and suspended constitutional rights of
all parliamentary bodies; parliamentary. -
democracy resumed in February 1971
Peninsular Malaysia: executive branches of
11 states vary in detail but are similar in de- - .
sign; a Chief Minister, appointed by heredi- -
tary ruler or Governor, heads an executive
council (cabinet), which is responsible to an
elected, unicameral legislature -
Sarawak and Sabah: executive branch
headed by Governor appointed by central
government, largely ceremonial role; execu- |
tive power exercised by Chief Minister who_
heads parliamentary cabinet responsible to
unicameral legislature; judiciary part of Ma-
laysian judicial system. . : .
Government leader: Dr. MAHATHIR bin
Mohamad, Prime Minister (since July 1981) .
Suffrage: universal over age 21
Elections: minimum of every five years; last
elections April 1982
Political parties and leaders: Peninsular | .
Malaysia: National Front, a confederation
of 11 political parties dominated by United.-.
Malay National Organization (UMNO),
Mahathir. bin Mohamad; major opposition -.-
parties are Democratic Action Party (DAP)...
Chen Man Hin; and Pan Maléyan islamic
Party (PAS), Yusof Rawa. -
Sabah: Berjaya Party, Datuk Haji Mohamad
Noor Haji.Mansodr; Bersatu Sabaj (PBS), «+ ~
Joseph Pairin Kitingan; United Sabah Na-
tional Organization (USN ont Tun Datuk
Mustapha
Sarawak: coalition Sarawak National Front -
composed of the Party Pesaka Bumipatra .
Bersatu (PBB), Datuk Abdul Taib; the
United People’s Party (SUPP), Wong Soon ~
Kai; and the Sarawak National Party .
(SNAP); Datuk James Wong; opposition is .
Parti Bansa Dayak Sarawak (PBDS),} Leo
Moggie :
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Malaysia (continued)
Voting strength: Peninstilar Malaysia:
(1982 election) lower house of parliament; -
National Front, 132 seats; DAP, 9 seats; PAS,
5 seats; independents, 8 seats :
Sabah: (April 1985 election) State Assem-
bly—Berjaya Party, 6 seats; USNO, 16 seats;
PBS, 26 seats
Sarawak: (1979 election) State Assembly
National Front controlled about 30 of 46
seats
Communists: Peninsular Malaysia: approx-
imately 2,000 armed insurgents on Thailand
side of Thai/Malaysia border; approxi-.
mately 200 full-time inside Peninsular Ma-
laysia
Sarawak: less than 100, North Kalimantan’
Communist Party: - <<
Sabah: insignificant
Member of: ADB, ANRPC, ASEAN, Associ-
ation of Tin Producing Countries, Colombo
Plan, Commonwealth, ESCAP, FAO, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IPU, IRC,
ITC, ITU, NAM, OIC, UN, UNESCO, UPU,
WHO, WMO, WTO','014f64f09ba31ab78b8d7ddbc538facd84be108b434a353c35130883219d3cc5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc0c921f570b7999f0ac29a6c69f2141ef92c67d7589b82b4a2da203cf88ef26',1986,'ML','Mali','government',316,'Official name: Republic of Mali
Type: republic; single-party constitutional
Capital: Bamako
Political subdivisions: 8 administrative re-
gions
Legal system: based on French civil law .
system and customary law; constitution
adopted 1974, came into full effect in 1979;
judicial review of legislative acts in Constitu-
tional Section of Court of State; has not ac- -
cepted compulsory ICJ jurisdiction.
National holiday: Independence Day, 22
September
Branches: until 1979 executive authority
exercised by Military Committee of Na-
tional Liberation (MCNL) composed of 1]
army officers; now Cabinet composed of
civilians and army officers; unicameral legis-
lature (National Council); judiciary
Government leader: Gen. Moussa
TRAORE, President (led Mali as President
of MCNL during 1968-79; President since
1979)
Suffrage: universal over age 21
Political parties and leaders: Democratic
Union of Malian People (UDPM) is the sole
political party; under civilian leadership
Elections: constitutional elections took place
June 1979
Communists: a few Communists and some
sympathizers (no legal Communist party)
Member of: A[DB, APC, CEAO, ECA,
ECOWAS, FAO, G-77, GATT-(de facto),
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO, IMF,
INTELSAT, INTERPOL, IRC, ITU, Niger
River Commission, NAM, OAU, OIC,
OMVS (Organization for the Development
of the Senegal River Valley), UN, UNESCO,
UPU, WHO, WMO, WTO
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Official name: Isle of Man
Type: self-governing British dependent ter-
ritory
Capital: Douglas
Political subdivisions: 6 sheadings and 7
constituencies
Legal system: English law and local statute
June
Branches: the Tynwald (parliament) consists
of the Lieutenant Governor, appointed by. .
and representative of the Crown; the Legis-
lative Council (upper house), which includes
members indirectly elected by the House of
Keys and certain ex officio members; and the
elected 24-member House of Keys (lower
house); an Executive Council carries out ad-’
ministrative actions; the Crown has ultimate
responsibility for the island’s “good” govern-
ment
Government leader: Maj. Gen. Laurence --..
NEW, Lieutenant Governor (since 1985) -
who is appointed by the Lord of Mann,
Queen Elizabeth II, Head of State; J. C.
NIVISON, President of the Legislative ..
Council (since 1985)
Suffrage: universal at age 21
Elections: every five years, next general
election slated for November 1986 :
Political parties and leaders: thereisno
party system and members sit as indepen-.-
dents; affiliations—Manx Labor Party, Alan
Clague, chairman; Manx National Party, °
Audrey Ainsworth, chairman; Mec Vannin
(Sons of Man), Lewis Crellin, chairman
Communists: probably none-
159
National holiday: Birthday of the Queen, 16','4495f2ea6420af725a6ee01521cd6e550b1d7b4b3491f24c723aa5a00d29f6a2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb7b4651c77e14ab891c8799dc57f8da3e539990982a9de60519e66711bbb7e8',1986,'MQ','Martinique','government',320,'Official name: Department of Martinique
Type: overseas department and region of
France; represented by three deputies in the
French National Assembly and two senators
in the Senate
Capital: Fort-de-France
Political subdivisions: 3 arrondissements; 34
communes, each witha iceally elected mu-
nicipal council
Legal system: French legal system; highest
court is a court of appeal based in Marti-
nique with jurisdiction over Guadeloupe,
French Guiana, and Marbntaue: :
Branches: Sune. Prefect appointed by. °°
Paris; legislative, popularly elected council
of 36 members and a Regional Council in-
cluding all members of the local general
council and the locally elected deputies and
senators to the French parliament; judicial,
under jurisdiction of French judicial system
Government leader: Jean CHEVANCE,
Prefect of the Republic (since 1981}
Suffrage: universal overagel18 =
Elections: General Council election nor-
mally held every five years; last General
Council election took place in June 1981;
regional assembly elections held February
1983 :
Political parties and leaders: Rally for the .
Republic (RPR), Edmond Valcin; Progres-
sive Party of Martinique (PPM), Aimé Cé-
saire; Communist Party of Martinique ~
(PCM), Armand Nicolas; Democratic Union ©
of Martinique (UDM), Léon-Laurent Valére
Voting strength: RPR, 1 seat in French.Na-
tional Assembly; UDF, ] seat; oe
Party, | seat .
Communists: 1,000 estimated
160
Other political or pressure groups: Proletar--
ian Action Group (GAP), Socialist Revolu-
tion Group (GRS), Martinique.
Independence Movement (MIM), Calibers
Revolutionary Alliance (ARC), Central .. | -
Union for Martinique Workers (CSTM)
Member of WFTU |
Besnaay a .
GDP: $1.38 billion (1980), $4, 540 per capita
Natural resources: scenery, ealtvable land
Agriculture: bananas, pineapples, vegeta-.: :
bles, flowers, limited sugarcane for rum
Major industries: construction, rum, ce-
ment, oil refining, light industry, tourism
Electric power: 66,000 kW capacity (1985);
319 million kWh produced (1985), 976 kWh
per capita
Exports: $123 million (1981); refined petro-
leum products, bananas, rum, pineapples
Imports: $708 million (1981); petroleum
products, foodstuffs, construction materials,
vehicles, clothing and other consumer goods
Major trade partners: exports—56% France
(1978); imports—62% France, 28% EC and
franc zone, 4.5% US, 5.5% other (1977)
Aid: economic—bilateral ODA and OOF
commitments (1970-81) from Western (non-
US) countries, $3.1 billion; no military aid
Budget: (1981) expenditures, $215 million
Monetary conversion rate: 7.71 French
francs=US$1 (December 1985)
Fiscal year: calendar year','fa7f9ac60ba3df3121947bd56886faac2ceffe2b6f744031a2280f08b408235c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73d32c1b55373e856aa6927c8b75f362b50550ca8caf387ed00fb2dc8aee74bf',1986,'MR','Mauritania','government',324,'NOTE: Mauritania acquired administrative
control of the southern third of Western (for-
merly Spanish) Sahara under a 1975 agree-
ment with Morocco and Spain. Following an
August 1979 peace agreement with Polisario
insurgents fighting for control of Western
Sahara, Mauritania withdrew from the terri-
tory and renounced all territorial claims.
Official name: Islamic Republic of Maurit-_:
ania :
Type: republic; military first seized power in
bloodless coup 10 July 1978; a palace coup
that took place on 12 December 1984
brought the President to power
Capital: Nouakchott
Political subdivisions: 12 regions and a capi-
tal district nt
Legal system: based on Islamic law; military.
constitution April 1979
National holiday: Independence Day, 2 28°
November
Branches: executive;-Military Committee
for National Salvation rules by decree; Na-. .
tional Assembly.and judiciary suspended
pending restoration of civilian rule
Government leader: Col. Maaouiya Ould
Sid Ahmed TAYA, President and Prime
Minister (since December 1984)
Suffrage: universal for adults
Elections: in abeyance; last presidential
election August 1976 |
- Political parties and leaders: suspended: . -
Communists: no Communist Party, but
there is a scattering of Maoist sympathizers -
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Mauritania (continued)
Meinber of: A{DB,:AIOEC; Arab League, :
CEAO, CIPEC (associate), EAMA, EIB (as-
sociate), FAO, G-77, GATT, IBRD, ICAO,
IDA, IDB—Islamic Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, ITU, NAM, OAU, OIC, ~—
OMVS (Organization for the Development
of the Senegal River Valley), UN, UNESCO,
UPU, ba WIPO, WMO
EeoAdinys ee
GNP: about $730 inillion 982 est. ) $460 +a
per capita
Natural resources: iron ore, gypsum, fish
Agriculture: most Mauritanians are nomads
or subsistence farmers; main products—
livestock, cereals, vegetables, dates; cash
crops—gum arabic
Fishing: catch, 353,800 0 metric tons (1983)
Major industries: mining of iron ore and
gypsum, fish processing
Electric power: 131,000 kW capacity (1985);
114 million kWh produced ies 68 kWh
per parte
Exports: $275 million (f.0.b., 1984); iron ore,
processed fish, and small amounts of gum .
arabic’and gypsum; also unrecorded but
numerically significant cattle exports to
Senegal —
Imports: $215 million (f.0.b., 1984); food-
stuffs and other consumer goods, petroleum:
products, capital goods - .
Major trade''partners: France and other EC
members, Senegal, and US
Buidget: $225 million budgeted in 1984:
$184 million revenues (planned 1984)
Monetary conversion rate: 61.4
ougtiiyas= US$] (80 July 1984)
Fiscal year: calendar year','e0fd8a4d34ad105b96890e354b8bf367b5ed09b97586ab268c55e3ebdd2cca73','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74d710dea9b938ca538fa7c2aca5111b5ea311a90ce72384ea7d9ed520c843b5',1986,'MU','Mauritius','government',327,'Official name: Mauritius
Type: independent state, recognizing Eliza-
beth II as Chief of State
Capital: Port Louis
Political subdivisions: 5 organized munici- .
palities and various island dependencies
Legal system: based on French civil law
system with elements of English common.
law in.certain areas; constitution adopted 6
March 1968
National holiday: Independence Day, 12
March
Branches: executive power exercised by
Prime Minister and 19-member Council of
Ministers; unicameral legislature (Legisla-
tive Assembly) with 62 members elected by
direct suffrage, 8 specially elected under
“best loser” system
Government leader: Aneerood JUG-
NAUTH, Prime Minister (since June 1982)
Suffrage: universal over age 18
Elections: legislative August 1983 .
Political parties and leaders: the govern-
ment is currently controlled by a coalition
composed of the Militant Socialist Move-
ment (MSM), A. Jugnauth, and the Maurit-
ian Social Democratic Party (PMSD), G.
Duval and the Mauritian Workers’ Assem-
bly (RTM), Beergoonath Ghurburrun; the
Mauritian Labor Party (MLP) faction, led by
party head S. Boolell,. voted to leave the coa-
lition in February 1984; the main opposition
parties are the Mauritian Militant Move- .
ment (MMM), P. Bérenger, and the Rodr-
igues People’s Organization (OPR)
Voting strength: MSM, 30 of 70 seats in the,
Assembly; MMM, 21; MLP, 11; PMSD, 4;
OPR, 2; and independents, 2. ~
Communists: may be 2,000 sympathizers; :
several Communist organizations; Mauritius
Lenin Youth Organization, Mauritius | a,
Women’s Committee, Mauritius Commu- ,
nist Party, Mauritius People’s Progressive
Party, Mauritius Young Communist League,
Mauritius Liberation Front, Chinese Middle
School Friendly Association, Mauritius/ _
USSR Friendship Society
Other political or pressure groups: various.
labor unions
4
G-77, GATT, IAEA, IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
ISO, ITU, [WC—International Wheat
Council, NAM, OAU, OCAM, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WTO
Official name: Mayotte
Type: French overseas territority, :
7
Capital: Dzaoudzi
Legal system: represented in French Parlia-
ment by one deputy in the National Assem-
bly and one member in the Senate; superior
court of. appeal -
Branches: elected 17-member general cotin-
cil; appointed commissioner
Government leader: Christian PELLERIN;
Commissioner of the Republic (sirice-1983);-
Younoussa BAMANA, President of the Gen-
eral Council (since 1976)
Political parties and leaders: Mahoran Pop-
ular Movement (MPM), Zna M’Oere; Party
for the Mahoran Democratic Rally (PRDM),
Darouéche Maoulida; Mahoran Rally for the -
Republic (RMPR), Abdoul Anizizi
Communists: probably none','57c3829646611d53d972f2808f9b28e4232512acc826eeb9253bfb7e1cab8aa5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c088094e409963f47fe31829a44bf7e5da8916b772f41227c3cc0338f0df73a6',1986,'MX','Mexico','government',331,'Official name: United Mexican States
Type: federal republic operating in fact un-
der a centralized government
Capital: Mexico
Political subdivisions: 31 states and the Fed-
eral District
Legal system: mixture of US constitutional
theory and civil law system; constitution
established in 1917; judicial review of legis-
lative acts; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Independence Day, 16
September .
Branches: dominant executive, bicameral
legislature (National Congress—Senate,
Federal Chamber of Deputies), Supreme
Court
Government leader: Miguel DE LA
MADRID Hurtado, President (since Decem-
ber 1982) .
Suffrage: universal over age 18; compulsory
but unenforced
Elections: next presidential election to be
held in 1988 ©
Political parties and leaders: (recognized
parties) Institutional Revolutionary Party
(PRI), Adolfo Lugo Verduzco; National Ac-
tion Party (PAN), Pablo Emilio Madero;
Popular Socialist Party (PPS), Jorge
Cruickshank Garcia; Unified Socialist Party
of Mexico (PSUM), Pablo Gémez Alvarez;
Mexican Democratic Party (PDM), Ignacio
Gonzalez Gollaz; Socialist Workers Party
_ (PST), Pedro Etiene; Revolutionary Workers
165
Party (PRT), Ricardo Pascoe Pierce; Mexi-
can Workers Party (PMT), Heberto Castillo
Martinez; Authentic Party of the Revolution
(PARM), Carlos Enrique Cantu Rosas
Voting strength: (1985 congressional elec-
tion) 66% PRI, 15% PAN, 3% PSUM, 3%
PDM, 2% PST, 2% PPS, 2% PARM, 2%
PMT, 1% PRT, 4% other parties or annulled
Other political or pressure groups: Roman
Catholic Church, Confederation of Mexican
Workers (CTM), Confederation of Industrial
Chambers (CONCAMIN), Confederation of
National Chambers of Commerce (CON-
CANACO), National Peasant Confederation
(CNC), National Confederation of Popular
Organizations (CNOP), Revolutionary Con-
federation of Workers and Peasants (CROC)
Member of: FAO, G-77, IADB, IAEA,
IBRD, ICAG, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, ILO, International Lead and Zinc —
Study Group, IMF, IMO, INTELSAT,
INTERPOL, IRC, ISO, ITU, [WC—Inter-
national Whaling Commission, LAIA, OAS,
PAHO, SELA, UN, UNESCO, UPU, WHO,
WIPO, WMO, WSG, WTO
Fiscal year: calendar year
Communications ae
Railroads: 20,680 km total; 19,950 km 1.435-
meter standard gauge; 730 km 0.914-meter .
narrow gauge —
Highways: 210,000 km total; 65,000 km
paved, 30,000 km semipaved or cobblestone,
60,000 km rural roads (improved earth) or.
roads under construction, 55,000 km unim-
proved earth roads
Inland waterways: 2,900 km navigable tiv-
ers and coastal canals
Pipelines: crude oil, 5,134 km; refined prod-
ucts,.6,875 km; natural gas; 9,490 km
Ports: 11 major, 20 minor
Civil air: 174 major transport ge
Airfields: 1,928 on 1,74] usable; 182 with
permanent-surface runways; 3 with run-
ways over 3,659-m, 28 with runways |
2,440-3,659 m, 276 with runways
J,220-2,439 m
Telecommunications: highly developed.
telecom system with extensive radio-relay
links; connection into Central. American
microwave net; 2 Atlantic Ocean satellite
ground antennas; 6.41 million telephones
(8.9 per 100 popl.); 650 AM, 120 TV, and
about 180 low-power TV relay stations; 120
domestic satellite terminals
Defense Forces Bi ee
Branches: Army, Air Force, ere Marine
Corps
Military manpower: males 15-49,
19,372,000; 15,361,000 fit for military ser-
vice; 905,000 reach military age (18) annu-
ally -
Military budget: for-year ending 31 Decem-
ber 1985, $1.16 billion (proj.); expenditures,
including support of parastatals, 3.4% of
central government budget
166','e9c58174d0858151388d3f0807830d5ca04f9db78e2bb50e0319aac6f72536db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('177d2de1ed5bc18d740282605b12e5bd525780ab0f53067886524dac0ce0f44d',1986,'MC','Monaco','government',333,'Mediterranean
- Sea
See regional map V
Land
1.9 km?; about one-tenth the size of Wash-
ington, D.C. ;
Land boundaries: 3.7 km
Water .
Limits of territorial waters (claimed): 12
nm ‘
Coastline: 4.1 km:
Official name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Political subdivisions: 1 commune com-
posed of 4 communal sectors
Legal system: based on French law; new
constitution adopted 1962; has not accepted
compulsory JCJ jurisdiction
National holiday: 19 November
Branches: legislative branch is composed of
the Prince and National Council of 18 mem-
bers; executive consists of the Prince as
Chief of State, the Minister of State as Head
of Government (senior French civil servant
appointed by Prince), and the Council of
Government as Cabinet; judicial authority is
delegated by the Prince to the Supreme Tri-
bunal
Government leader: Prince RAINIER III,
Chief of State (since November 1949)
Suffrage: universal adult
Elections: National Council every five years;
national election held. January 1983; munici-
pal election held February 1983
Political parties and leaders: National and -
Democratic Union (UND), Democratic
Union Movement (MUD), Monaco Action,
Monegasque Socialist Party (PSM)
Voting strength: (1978) National Council—
UND 18 seats’ :
Member of: IAEA, ICAO, IHO,
INTELSAT, INTERPOL, IPU, ITU, UN ~
(permanent observer), UNESCO, UPU,
WHO, WIPO','f42e1cd930d7dab1e468517afe2af6cfb572b6352a87833afd17299c3f34b741','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a078640c16cfd8555a01174eec637e4107cc453644902787035ca0d9b3b5127',1986,'MS','Montserrat','government',341,'Official name: Montserrat
Type: British dependent territory
Capital: Plymouth
Political subdivisions: 7 districts -
Legal system: English common law
Branches: Executive Council presided over
by governor, consisting of two ex-officio
members (attorney general and financial -.
officer) and four unofficial members (chief.
minister and three other ministers); Legisla-
tive Council presided over by speaker cho-
sen from outside the Council, seven elected
two official, and two nominated members -
?
Government leader: A.C. WATSON, Gov-..
ernor (since 1984); Dr. J. A. OSBORNE,
Chief Minister (since 1978)
Suffrage: universal over age 18
Elections: at least once every five years; last
election held February 1983
Political parties and leaders: People’s Liber-
ation Movement (PLM), John Osborne; Pro-
gressive Democratic Party (PDP), P. Austin
Bramble; United National Front (UNF), Dr.''
George Irish; National Development Party
(NDP), Bertram Osborne
Voting strength: July 1984 elections—PLM,
4 seats; PDP, 3 seats
Communists: probably none','76969fc039b8c5e0b7f105cdff3e49a984e47c956b6957ab11a0238172dfd5c9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5a15ea4261d6654e2ef863ef54ad9dca193968723dec71bc33c578ae204af62',1986,'NA','Namibia','government',350,'Official name: Namibia
Type: former German colony of South-West
Africa mandated to South Africa by League
of Nations in 1920; UN formally ended
South Africa’s mandate on 27 October 1966,
but South Africa has retained administrative
control
Capital: Windhoek
Political subdivisions: 10 tribal homelands,
mostly in northern sector, and zone open to
white settlement with administrative subdi-
visions similar to a province of South Africa
Legal system: based on Roman-Dutch law
and customary law
Branches: since September 1977 Adminis-
_ trator General, appointed by South African
Government, has exercised coordinative
functions over zone of white settlement and
tribal homelands, where traditional chiefs
and representative bodies exercise limited
autonomy; veto power over legislation pro-
posed by National Assembly; interim gov-
ernment established June 1985 with
8-member Cabinet, 16-member Constitu-
tional Council and 62-member National
Assembly
Government leader: Louis A. PIENAAR,
Administrator General (since July 1985)
Suffrage: universal white adult suffrage at
territorial level; lower level elections open to
blacks
Elections: last election of Namibian Na-
tional Assembly, December 1978
Political parties and leaders: approximately
45 political parties; member parties of the
interim Multi-Party Conference govern-
e
ment—Multisocial Democratic Turnhalle -.
Alliance (DTA), Dirk Mudge; South-West
African National Union (SWANU), Moses. .
‘Katjiuongua; South-West African People’s -
Organization Democrats (SWAPO-D), An-
dreas Shipanga; South-West African Na-
tional Party (SWANP), Kosie Pretorius; Col-
ored Labor Party, David Bezuidenhout;
Rehoboth Free Democratic Party (RFDP), .
Hans Diergaardt; other parties—United
Democratic Party, formed in September
1985 after merger of 2 Caprivi parties,
Mishake Muyongo; Federal Party, largely
white, English-speaking, liberal; Christian
Democratic Action Party, a primarily
Ovambo party formed in early 1982 asa
result of a split in the DTA, Peter Kalangula
Voting strength: (1978 election) Namibian
National Assembly—DTA, 22 seats;
SWANP, 8 seats; SWANU, 8 seats;
SWAPO-D, 8 seats; CP, 8 seats; RFDP, 8
seats; Assembly appointed in June 1985
Communists: no Communist Party;
SWAPO guerrilla force is supported by So-
viet Union, Cuba, and other Communist
states as well as OAU
Other political or pressure groups: South-
West African People’s Organization
(SWAPO), led by Sam Nujoma, maintains a
foreign-based guerrilla movement; is pre-
dominantly Ovambo but has some influence
among other tribes; is the only Namibian
group recognized by the UN General Assem-
bly and the Organization of African Unity
Member of: FAO, ILO, UNESCO, WFTU,
WHO','8a76f78f04a154f5c566ec20de006a1065e5aae1b8a941e8a2895bff9fc75081','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdf758e6ba281dc4aa3a00ce13a8dcdb42b217636b662bbfe333d8efa1304d39',1986,'NR','Nauru','government',354,'Official name: Republic of Nauru
{ee 8
Type: republic
Capital: no capital city per se; government
offices in Yaren District -
Political subdivisions: 14 districts
National holidays: Independence Day, 31 °
January; Constitution Day, 17 May; Angram
Day, 26 October
Branches: President elected from and by
Parliament for an unfixed term; popularly
elected 18-member unicameral legislature
(Parliament); four-member Cabinet to assist
the President appointed by him from Parlia-
ment members :
Government leader: Hammer
DEROBURT, President (since May 1978)
Suffrage: universal adult
Elections: last held in December 1988”
Political parties and liad: governing fac-
tion, President DeRoburt; opposition Nauru
Party, Lagumot Harris
M. eather of: Commonwealth (special mem-
ber), ESCAP, ICAO, INTERPOL, ITU, - ;
South Pacific Commission, SPF, UPU','c1c95fe4bab2d03b66cb0ad19d7c0ff3076ea4cd89f499b276a226c2e4b2f546','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('978d7fd9f383015ce8a3864270e8db62c807562562e1775d649eef51b8bbdd80',1986,'NL','Netherlands','government',361,'Official name: Kingdom mS dg Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government re-
sides at The Hague
Political subdivisions: 11 provinces and 4
special municipalities. governed by centrally
appointed commissioners of Queen
Legal system: civil law system incorporating
French penal theory; constitution of 1815.
frequently amended, reissued 1947; judicial .
review in the Supreme Court of legislation
of lower order rather than Acts of Parlia-
ment; legal education at six law schools; ac-
cepts compulsory IC] jurisdiction; with res-
ervations
National holiday: Queen’s Day, 30 April
Branches: executive (Queen and Cabinet of
Ministers), which is responsible to bicameral
parliament (States General) consisting of a
First Chamber (75 indirectly elected mem-. -
bers) and a Second Chamber (150 directly
elected members); independent judiciary;
coalition governments are usual
Government leaders: BEATRIX Wilhelm--
ina Armgard, Queen (since April 1980);
Ruud LUBBERS, Prime Minister (since No-
vember 1982) -
Suffrage: universal over age 18
Elections: must be held at least every four
years for lower house (next scheduled for 21
May 1986); following. an amendment to the
constitution that took effect.in 1983, elec-
tions are held for the upper house every four
years (most recent August 1983)
Political parties and leaders: Christian
Democratic Appeal (CDA), Chairman Pieter
Bukman; Labor (PvdA), Max van den Berg;
Liberal (VVD), Jan Kamminga; Democrats
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
66 (D’66), Jacob Kohnstamm; Communist
(CPN), Henk Hoekstra; Pacifist Socialist
(PSP), Bram van der Lek; Political Reformed
(SGP), Hette G. Abma; Reforrned Political
Union (GPV), Jan van der Jagt; Radical -
Party (PPR), Herman Verbeek; Democratic
Socialist 70 (DS’70), Z. Hartog; Rightist Peo- »
ples Party (RVP), Hendrik Koekoek; Re-.
formed Political Federation (RPF), P
Lamegeler; Center Party (CP), H. Janmatt;
Evangelical People’s Party (EVP), J. Renes
Voting strength: (1982 election) 30.8%
PvdA (47 seats), 29.3% CDA (45 seats), 23%
VVD (36 seats),-4.8% D’66(6 seats), 2.3% PSP
(3 seats), 1.9% SGP (3 seats), 1.8% CPN.(3
seats), 1.7% PPR (2 seats), 1.3% RDF (2 seats),
0.8% GPF (1 seat), 0.8% CP (1 seat); 0.7%
EVP (1 seat); two members of the CDA were
expelled from the-party in 1984 and are new
serving as indebetideats ar
Contianiis CPN claim about 2 27, 000 tee
members
Other political or pressure groups: large
- multinational firms; Federation of Nether-
lands Trade Union Movement (comprising
Socialist and Catholic trade unions) and a
Protestant-trade union; Federation of Catho-
lic and Protestant Employers Associations;
the nondenominational Federation of Neth-
erlands Enter prises; and IKV—Interchurch :
Peace Ceuna
M nies of. ADB, Benelux; Council of Eu-
rope, DAC, EC, ECE, EIB, ELDO, EMS,
ESCAP, ESRO, FAO, GATT, IAEA, IBRD,
ICAC, ICAO; ICES, ICO, IDA, IDB—Inter-
American Development Bank, IEA, IFAD,
IFC, THO, ILO, IMF, IMO, INRO, .
INTELSAT, International Lead and Zinc
Study Group, INTERPOL, IPU, IRC, ITC,
ITU, IWC—International Wheat Council
(with respect to interests of the Netherlands:
Antilles and Suriname), NATO, OAS (ob-
server), OECD, UN, UNESCO, UPU, WEU,
io WIPO, WMO, WSG. . ;
Resesaiy : a
GNP: $123.8 billion ‘ona $8, 500 per cap-
ita; 59.3% consumption, 18.4% investment,
16.8% government, 0.5%. inventories, 5.0%
net foreign demand, 1.7% ial GNP Browih :
(1984)
Natural resources: natural gas, oil
Agriculture: animal hihadey predomi-
nates; main crops—horticultural crops,
grains, potatoes, sugar beets; food
shortages—erains, fats, oils
Fishing: catch 328,000 metric tons (1983);
exports of fish and fish products, $416.1 mil-
lion (1982); imports,-$150.2 million (1982)
Major industries: food processing, metal.
and engineering products, electrical and |
electronic machinery and equipment,
chemicals, petroleum products, natural gas
Shortages: crude petroleum, raw. cotton,
base metals and ores, pulp, pulpwood, lum-
ber, feedgrains, oilseeds
Crude steel: 8.0 million metric ton capacity
(1984); 5.7 million metric tons produced, 394
kg per capita (1984)
Electric power: 19,546,000 kW capacity
(1985); 63.632 billion kWh produced (1985),
4,398 kWh per capita ''
Exports: $65.8 billion (f.o.b., 1984); food-
stuffs, machinery, chemicals, petroleum
products, natural gas, textiles
Imports: $62.8 billion (c.i.f., 1984); machin--
ery,.transportation equipment, crude petro-
leum, foodstuffs, chemicals, raw cotton, base
metals and ores, ule
Major trade partners: (1984) exports—
71.9% EC (29.8% FRG, 13.8% Belgium-
Luxembourg, 10.5%. France, 9.4% UK), 5.0%
US, 1.9% Communist; imports—53.3% EC
(21.8% FRG, 11.4% Belgium-Luxembourg,
8.7% UK), 8.8% US, 5.3% Communist
Aid: donor—ODA and OOF economic aid
commitments (1970- 83), $11.0 billion
Budget: (1985 est.) revenues, $47.4 billion;
expenditures, $56.4 billion; deficit, $9.0 bil-
lion’
Monetary Gonversion rate: 2.9820
guilders=US$1 (October 1985)
Fiscal year:calendar year .
MTT
Official name: Netherlands Antilles
Type: autonomous territory within King-
dom of the Netherlands, enjoying complete
domestic autonomy
Capital: winced on Curacao
Political subdivisions: three island territo-
ries—Bonaire, Curacao, and the Windward
Islands—St. Eustatius, southern part of St. .
Martin (northern part is French), Saba;
‘Aruba; formerly part of the Antilles federa-
tion, assumed separate status (under Prime
Minister Jan Hendrik Albert Eman) within
the Kingdom of the Netherends on] went
ary 1986
Legal salen based on Dutch civil law sys-
tem, with some English common law influ-
ence; constitution adopted 1954
Branches: federal-executive power rests
nominally with Governor (appointed by the
Crown); actual power exercised by eight- .
member Council of Ministers or cabinet pre-
sided over by Minister-President; legislative
power rests with 22-member Legislative
Council; independent court system under
control of Chief Justice of Supreme Court of
Justice (administrative functions under Min-
ister of Justice); each:island territory has is-
land council headed by Lieutenant Gover-
nor -
Government leaders: Domenico Felip
MARTINA, Prime Minister (since January
1986); Dr. Rene ROMER, Governor (since
1983)
Suffrage: universal age 18 and over
Elections: federal elections mandatorily
held every four years, last regular held 22
November 1985; island:council elections
every four | years, last held 25 apr 1983
Political parties uel aioe aoieal par-
ties are indigenous to each island:
Curacao: Movement for a New Antilles
(MAN), Domenico Felip Martina;
178 °
Democratic Party (DP), Augustin Diaz; -;
People’s National Party (PNP), Maria
Liberia-Peters; Frente Obrero de Liberacion
(FOL), Wilson “Papa” Godett; Social Demo-.
cratic Party (PSD), Efraim Cintie .
Bonaire: Union Party of Bonaire (UPB),
Charles E.R. Ellis; Democratic Party of
Bonaire, Jopie Abraham; New Democratic
Action (ADEN)
Windward Islands: Windward Islands .
Democratic Party (DPWI), Leo Chance and.
Claude Wathey; United Federation of Antil-
lean Workers (UFA); Windward Islands
People’s Movement (WIPM); and ones
Voting sional: in June 1984 nee govern:
ment of Prime Minister Don Martina lost its
majority in the Legislative Council; an in-
terim coalition government was appointed
by the Governor; the coalition controls 15 of
22 seats in the Council and consists of mem-
bers of the PNP, DP, MEP, DPWI, and UPB
parties
Communists: small leftist groups
Member of: EC (associate), INTERPOL;
associated with UN through the Nether- .
lands; UPU, WMO','6d6302cef40509d2878ba4ebd40935e8d41ca185eb1cfc5d7894146b58da643b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c09676894e642af111da215e74481a7f8b8fd80b066dd582057479706936c92c',1986,'NC','New Caledonia','government',365,'Official name: Territory of New Caledonia
and Dependencies
Type: French overseas territory; represented
in French parliament by two deputies and
one senator
Capi tal: Nouméa
Political subdivisions: 4 islands or island
group dependencies—lIle des Pins, Ie:
Loyauté, He Huon, Island of New Caledonia
Legal surety French law
Branches: aac by High Cortnte:
sioner, responsible to French Ministry for
Overseas France and Council of Govern-. -
ment; 46-seat Territorial Assembly
Government leader: Fernand WIBAUX,.
French High Commissioner and President
of the Council of Government (since 1985);-
Kanak Provisional Government—
Jean-Marie TJIBAOU, President (since De-
cember 1984)
Suffrage: universal
Elections: Assembly elections every five
years, last in November 1984; referendum
on New Caledonian independence sched-
uled for 1987
Political parties: white-dominated Rassem-
blement pour la Calédonie dans.la Républ: -
ique (RPCR)—Gonservative; Melanesian - -.
proindependence Kanak Socialist National.
Liberation Front (FLNKS); Melanesian
moderate Kanak Socialist Liberation (LKS) © -
Voting strength: (1984 election) Territorial
Assembly—RPCR, 34 seats; LKS, 6 seats;
splinter groups, 2 seats; FLNKS beveoted
the election
Communists: number unknown, Palita ex-
treme left party; some politically active
Communists deported during 1950s; small
number of North Vietnamese - a
Member of: ETB (associate); WFTU, WMO
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
New Caledonia (continued)','1de93220b274d2acc99f2a6a1b9710cce92ddf6d88352d048b242cc3123e7e5f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a56cadd00c87d361f207cbd430f73852acc5629248fccd9ad1d203ae8b5a5b2',1986,'NZ','New Zealand','government',369,'Official name: New Zealand
Type: independent state within Common-
wealth, recognizing Elizabeth II as head of
state
Capital: Wellington
Political subdivisions: 241 territorial units
(128 boroughs, 90 counties, 10 town and dis-
trict councils); 579 special-purpose bodies
Legal system: based on English law, with
special land legislation and land courts for
Maoris; constitution consists of various docu-
ments, including certain acts of the UK and
New Zealand Parliaments; legal.education
at Victoria, Auckland, Canterbury, and
Otago Universities; accepts compulsory ICJ
- jurisdiction, with reservations
National holiday: Waitangi Day, 6 Febru-
ary
Branches: unicameral legislature
(92-member House of Representatives, com-
monly called Parliament); Cabinet responsi-
ble to Parliament: three-level court system
(magistrates and courts, Supreme Court, and
Court of Appéal)
Government leader: David LANGE, Prime
Minister (since July 1984)
Suffrage: universal age 18 and over
Elections: held at three-year intervals or
sooner if Parliament is dissolved by Prime
Minister; last election July 1984
Political parties and leaders: New Zealand
Labor Party (NZLP; government), David
Lange; National Party (NP; opposition), Jim
McLay; Social Credit Political League (So- 3
cred), Bruce Beetham; New Zealand Party,
Bob Jones; Socialist Unity Party (SUP; pro-
Soviet), G. H. “Bill” Andersen
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Voting strength: (1981 election)
Parliament—National Party, 47 seats; Labor
Party, 43 seats; Social Credit, 2 seats
Communists: CPNZ about 800, SUP about
100
Member of: ADB, ANZUS, ASPAC, Co-
lombo Plan, Commonwealth of Nations,
DAC, ESCAP, FAO, GATT, IAFA, IBRD,
ICAO, ICO, IDA, IEA, IFAD, IFC, IHO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, ISO, ITU, OECD, SPF, UN, UNESCO,
UPU, WHO, WMO, WSG','e402d20d6180ad5179662ce85e002af11ce004cf83bc7a7f24440a4fe61ed0eb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('151fbd1702b3adab773185e3fad6cbc0e75167ad0880dcac8a32d0e8ab8c5c43',1986,'NI','Nicaragua','government',373,'Official name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: one national district
and 16 departments; in 1982 the Sandinistas
established six regions and three special
zones, which both the government and the ~
Sandinista National Liberation Front:
(FSLN) increasingly use for administrative
purposes - _ :
Legal system: the Sandinista-appointed
Government of National Reconstruction
revoked the constitution of 1974.and issued a-
Fundamental Statute and a Program of the ©
Government of National Reconstruction to
guide its actions until a new constitution is.
drafted by the National Assembly, which
was elected in November 1984
National holiday: Independence Day, 15
September; Anniversary of the Revolution,
19 July
Beatties executive and administrative re-
sponsibility formally reside in the President, .
Vice President, and Cabinet; in reality, the
nine-member National Directorate of the
Sandinista National Liberation Front
(FSLN) shares power with and dominates.
the executive; National Assembly was ..
elected in November 1984 and inaugurated
in January 1985 with a mandate to draft a
new constitution; the country’s highest -
judicial authority is the Sandinista-
appointed Supreme Court, composed of
seven members
Government leaders: Cdte. (José) Daniel
ORTEGA Saavedra, President (since 10 Jan-
uary 1985); Sergio RAMIREZ Mercado, Vice
President (since 10 January a
Elections: Aone deena: were held on 4.
November 1984 for president and vice presi-
dent (elected for a six-year term), and:a 96-
member National Assembly
Political parties and leaders: the Sandinista
National Liberation Front (FSLN) is the rul- -
ing party and dominates political life; the
FSLN has 61 seats in the National Assembly;
only the Liberal Party, because of its ties to
the Somoza family, has been specifically
banned; the government prohibited most
political activities by opposition parties un-
der the state of emergency in March 1982
and expanded the emergency decree in Oc-
tober 1985; the main opposition parties boy- -
cotted the elections on the grounds that the
regime had not provided them with suffi-
cient political guarantees; the democratic
opposition parties include the Social Demo-
cratic Party (PSD), Luis Rivas Leiva; the
Social Christian Party (PSC), Erick Ramirez; _
the Democratic Conservative Party of Nica-
ragua (PCDN), Mario Rappaccioli; the Con-
stitutionalist Liberal Party (PLC), Alfredo
Reyes Duque Estrada; the Independent Lib-
eral Party (PLI), Virgilio Godoy; the Popular
Social Christian Party (PPSC), Mauricio
Diaz; and the Democratic Conservative
Party (PCD), Eduardo Molina; the PSD,
PSC, PCDN and PLC, as well as opposition
business and union organizations form the
Democratic Coordinating Board—Eduardo
Rivas Gasteazoro, president; the PPSC and
PLI were allied with the FSLN in the Patri-
otic Front of the Revolution (FPR) until
early 1984 but fielded their own candidates
in the elections; a pro-FSLN faction domi-
nates the PCD; the PCD has 14 seats in the
National Assembly, the PLI 9, and the PPSC
6; two additional relatively obscure parties,
the Central American Unionist Party
(PUCA) and the Revolutionary Party of the
Workers (PRT), were founded in late 1984
182
Communists: the Nicaraguan Socialist Party
(PSN), Luis Sanchez Sancho, founded in
1944, has served as Nicaragua’s Moscow-line
Communist party; the Communist Party of
Nicaragua (PCdeN), Eli Altamirano Pérez, is
an ultraleft- breakaway faction from the
PSN; and the Popular Action Movement—
Marxist-Leninist (MAP-ML), Isidro Téllez;
only the PSN was a member of the FPR alli-
ance with the FSLN, but all three have sup- -
ported the revolution; the PCdeN and
MAP-ML have criticized the Sandinistas for
moving too slowly toward consolidation of a
Marxist-Leninist regime; each of the three
Communist parties has two seats in the Na-
tional Assembly
Other political or pressure groups: the Supe-
rior Council of Private Enterprise (COSEP) -
is an umbrella.group comprising 11 different
chambers of associations, including such
groups as the Chamber of Commerce, the .-
Chamber of Industry, and the Nicaraguan -
Development Institute (INDE)
Member of: CACM, CEMA (observer),
FAO, G-77, GATT, IADB, .IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, ILO; IMF, IMO; INTELSAT,
INTERPOL, IPU; IRC, ISO, ITU, NAM,
OAS, ODECA, PAHO, SELA, UN, _
UNESCO, UPEB, UPU, WFTU, WHO,
WMO, WTO','68ad277b9dafad9982ebd41e0554a195c4476102a85a1750227660d52db5f93f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac667db64677024bb2ab359c09c7d95b8c920c19f948a2e1c66449ea86094b1',1986,'NE','Niger','government',377,'Official name: Republic of Niger
Type: republic; military regime in power.
since April 1974
Capital: Niamey.
Political subdivisions: 7 departments, 32
arrondissements
Legal system: based on French civil law
system and customary law; constitution
adopted 1960, suspended 1974; committee ~
appointed January 1984 to “reflect” ona
new national charter; has not accepted com-
pulsory [CJ jurisdiction
National holidays: Independence Day, 3
August; Republic Day, 18 December
Branches: executive authority exercised by
President Seyni Kountché in the name of the
Supreme Military Council (SMC), which is
composed of army officers; office of prime
minister created January 1983; since No-
vember 1983, civilians have held all cabinet
portfolios except Defense and Interior,
which are held by President Kountché
Government leader: Brig. Gen. Seyni
KOUNTCHE, President of Supreme Mili-
tary Council, Chief of State (since 1974);
Hamid ALGABID, Prime Minister (since
November 1983).
Suffrage: universal adult
Elections: popular elections currently al-
lowed only for choosing representatives for
village Development Councils, which advise
on local economic development
Political parties and leaders: political par-
ties banned
Communists: no Communist party; some
sympathizers in outlawed Sawaba party
Member of: ADB, APC, CEAO, EAMA,
ECA, ECOWAS, Entente, FAO, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFAD, IFC,
ILO, IMF, INTELSAT; INTERPOL, IPU,
ITU, Lake Chad Basin Commission, Niger
Declassified and Approved For Release 2012/08/29
River Commission, NAM, OAU, OCAM,
OIC, UN, UNESCO, UPU, WHO, wee
WMO
Economy , . ne
GDP: $1.2 billion (1985 est:), $240 per capita
(1985); annual real growth rate —3.1% (1985
est.)
Natural resources: uranium, coal, iron, tin,
phosphates
Agriculture: commercial—cowpeas, groun-
dnuts, cotton; main food crops—millet,
sorghum, rice : :
Major industries: cement plant, brick fac-
tory, rice mill, small cotton gins, oil presses,
slaughterhouse, and a few other small light
industries; uranium production began in
1971
Electric power: 101,700 kW capacity (1985);
133 million kWh produced (1985), 20 kWh
per capita
Exports: $319.1 million (1985 est.);.uranium,
livestock, cowpeas, onions, hides, skins; ex-
ports understated because much regional
trade not recorded
Imports: $351.9 million (1982 est.); petro-
leum products, primary materials, machin-
ery, vehicles and parts, electronic equip-
ment, pharmaceuticals, chemical products,
cereals, foodstuffs :
Major trade partners: France (about half),
other EC countries, Nigeria, UDEAC coun-
tries; US (3.8%, 1981); preferential tariff to
Ee and franc zone countries
Budget: hore est.) revenue $173 million,
(1986 est.) $364.6 million expenditures
M onetary conversion rate: 475 Commun-
auté Financiére Africaine (CFA) francs=
US$1 (1985)
Fiscal year: 1 October-30 September.','f4e613ef26954f5594e46fc8594b2b835734688349a6c88fb09fc1cb16660fc1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11fcd6bc890471032e4cdafc7cea48f7c966ea9a324e9a707915887a80323ed6',1986,'NU','Niue','government',380,'Official name:nO Niue.
Type: (since 1974) self-governing territory
“in free association with New Zealand”;
Niueans retain New Zealand citizenship
Capital: Alofi
Political subdivisions: 14 village councils
Legal system: English common law -
Branches: Executive consists of a Cabinet of
four members—the Premier (elected by. the
Assembly) and three ministers (chosen by the
Premier from among Assembly members);
Legislative Assembly consists of 20 members
(14 village representatives and 6 elected ona
common roll); if requested by, the Assembly,
New Zealand will also legislate for the island
Government.leaders: Sir Robert R. REX;
Premier (since early 1950s); John
SPRINGFORD, New Zealand Representa-
tive (since 1974), .
Suffrage: universal adult . ,
Elections: every three years; last election .
held March 1984...
Member of: ESCAP Ogee member), |
SPF','1774426a3486112a1d0ecf595c4648ecbdb3e4697e7e21a13a9fabaa0dc02b0c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9af86e1c457ba1155ee6d0cf05b146d4fad1ba86a1a0546ffab8091d6af147eb',1986,'NF','Norfolk Island','government',384,'Official name: Territory of Norfolk Island
Type: Australian territory
187
Capital: Kingston (administrative center),
Burnt Pine (commercial center)
Political subdivisions: external territory,of -','3119983fe851234fedd9f756a08323e3953bace7f90d95132e17fc8897d59a7c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33d5cb9b014e026f11b61e8a2279611790eaa7faa4ae0aa40ca1e4bf29b782b4',1986,'NO','Norway','government',387,'Official name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 19 counties, 407 com-
munes, 47 towns :
Legal system: mixture of customnary-law,
civil law system, and common law tradi-
tions; constitution adopted in 1814 and mod-
ified in 1884; Supreme Court renders advi-
sory opinions to legislature when asked; legal
education at University of Oslo; accepts
compulsory ICJ jurisdiction, with reserva-
tions :
National holiday: Constitution Day, 17 May
Branches: legislative authority rests jointly
with Crown and parliament (Storting—
Lagting, upper house; Odelsting, lower
house); executive power vested in Crown but
exercised by Cabinet responsible to parlia-
ment; Supreme Court, 5 superior courts, 104
lower courts
Government leaders: OLAV V, King (since
1957); Kare WILLOCH, Prime Minister
(since September 1981)
Suffrage: universal at age 18 but not compul-
sory
Elections: held every four years (next in
1989)
Political parties and leaders: Labor, Gro
Harlem Brundtland; Conservative, Rolf
Presthus (in April 1986); Center, Johan J.
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Jakobsen; Christian People’s, Kjell Magne
Bondevik; Liberal, Odd Einar Dorum; So-
cialist Left, Theo Koritzinsky; Norwegian
Communist, Hans I. Kleven; Progressive,
Carl I. Hagen
Voting strength: (1985 election) Labor,
40.8%; Conservative, 30.4%; Christian
People’s, 8.3%; Center, 6.6%; Socialist Left
(Socialist Electoral Alliance); 5.5%; Progres-
sive, 3.7%; Liberal, 3.1%; Red Electoral Alli-
ance, 0.6%; Liberal People’s Party (antitax),
0.5%; Norwegian Communist, 0.2%; other
0.4%
Communists: 15,500 est.; 5,500 Norwegian
Communist Party (NKP); 10,000 Workers
Communist Party Marxist-Leninist (AKP-
ML, pro-Chinese)
Member of: ADB, Council of Europe, DAC, .
EC (Free Trade Agreement), EFTA, ESRO
(observer), FAO, GATT, IAEA, IBRD,
ICAC, ICAO, ICES, ICO, IDA, IEA (associ-
ate member), IFAD, IFC, IHO, ILO, IMF,
IMO, INTELSAT, INTERPOL, Interna-
tional Lead and Zinc Study Group, IPU,
ITU, IWC—International Whaling. Com-
mission, [WC—International Wheat Coun-
cil, NATO, Nordic Council, OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG','b8a5133695f0cccca835c7e124d722502ca18462e271bc93ca4344d9625d4ea1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5777e6d008b91e9ec4bd9afe1768f40f4383de0f93c960cece1dd3ae15779c6',1986,'OM','Oman','government',391,'- Official name: Sultanate of Oman
Type: absolute monarchy; independent,
with strong residual UK influence
Capital: Muscat
Political subdivisions: | province (Dhofar), 2
governorates (Musandam and Muscat), and
numerous districts (wilayats)
Legal system: based on English common
law and Islamic law; no constitution; ulti-
mate appeal to the Sultan; has not accepted
compulsory ICJ jurisdiction
Branches: executive—Sultan, who appoints
45-member State Consultative Assembly to
advise him; legislative—none; judicial—
traditional Islamic judges and a nascent civil
court system
National holiday: National Day, 18-19 No-.
vember
Government leader: QABOOS bin Said,
Sultan (since July 1970)
Political parties: none
Other political or pressure groups: outlawed
Popular Front for the Liberation of Oman
(PFLO), based in South Yemen
Member of: Arab League, FAO, G-77, GCC,
IBRD, ICAO, IDA, IDB—Islamic Develop-
ment Bank, IFAD, IFC, IMF, IMO, m
INTELSAT, INTERPOL, ITU, NAM, OIC,
UN, UNESCO, UPU, WFTU, WHO, WMO.
Official name: Republic of Panama
Type: centralized republic
Capital: Panama
Political subdivisions: 9 provinces,.] inten- -
dancy
Legal system: based on civil law system;
constitution adopted in 1972, but major re-
forms adopted in April 1983; judicial review
of legislative acts in the Supreme Court; le-
gal education at University of Panama; ac-
cepts compulsory ICJ jurisdiction, with res-
ervations
National holiday: Independence Day, 3 No-
vember
Branches: under April 1983 reforms, a Presi-
dent, two Vice Presidents, and a 67-member
Legislative Assembly are elected by popular
vote for 5-year terms; nine Supreme Court :
Justices and nine alternates serve 10-year
terms; two justices and their alternates are
replaced every other December by presi-
dential nomination and legislative confirma-
tion ;
Government leaders: Eric Arturo
DELVALLE Henriquez, President (since
September 1985); Roderick ESQUIVEL,
First Vice President (since October 1985),
Second Vice President, unfilled.
Suffrage 18: universal aul Shinpuilsony: over
age 18
Elections: seven electoral slates made up of *
14 registered political parties were on the
193
May 1984 ballot with the president and -
other winners decided by simple pluralities;
mayoral and municipal elections were held
in June 1984 ;
Political parties and leaders: (registered for
1984 presidential‘and legislative elections)
National Democratic Union(UNADE; gov-:
ernment coalition)—Democratic Revolu-
tionary Party (PRD; official government
party), Romulo Escobar Bethancourt, Carlos.
Ozores Typaldos; Republican Party (PR),
Eric Arturo Devalle Henriquez; Liberal
Party (PL), Roderick Lorenzo Esquivel; La- °
bor Party (PALA), Ramén Sieiro Mungas «:-’
and Carlos Eleta Almaran; Panamenista
Party (PP), Luis Suarez; Popular Broad.
Front Party (FRAMPO), Alvaro Arosemena;-
Democratic Opposition Alliance (ADO, op-
position)—Christian Democratic Party
(PDC), Ricardo Arias Calderén; Authentic -
Panamenista Party (PPA), Arriulfo Arias
Madrid; Nationalist Republican Liberal
Movement (MOLIRENA), Alfredo Ramirez,
Sr.; other opposition parties—Popular Na- -
tionalist Party (PNP), Olimpo A. Saez
Maruci; Popular Action Party (PAPO);
Carlos Ivan Zuniga; People’s Party (PdP,
Soviet-oriented Communist), Rubén Dario
Sousa Batista; Socialist Workers Party (PST),
José Cambra; Revolutionary Workers Farty
(PRT), leader unknown :
Voting ial in the May 1984 elections :
the government coalition received 300,748
-votes, narrowly defeating the opposition © =
alliance, which received 299,035 votes;
UNADE won 45 seats in-the 67-member
Legislative Assembly, and ADO won the
remaining 22 Seats : : .
Communists: People’s Party (PdP), progov-
ernment mainline Communist party, did not
obtain the 3 percent of the total vote in 1984
elections to retain its legal status :
Other political or pressure groups: National
Council of Organized Workers (CONATO),
National Council of Private Enterprise
(CONEP); Panamanian Association of Busi: -
ness Executives (APEDE)
Member of: FAO, G-77, IADB, IAEA,
IBRD, ICAO, ICO, IDA, IFAD, IDB—
Inter-American Development Bank, IFC,
‘Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Panama (continued)
ILO, IMF, IMO, INTELSAT, INTERPOL;
IRC, ITU, IWC—International Whaling
Commission, IWC—International Wheat
Council, NAM, OAS, PAHO, SELA, UN,
UNESCO, UPEB, UPU, WFTU, WHO,
we. whe: ;
Beenie
GNP: $4.4 billion (1984), $2.1 159 per capita; ©
real growth (1984), — 1.0%
Natural resources: copper, mahogany for:
ests, shrimp
Agriculture: miain crops—bananas, rice,
sugarcane, coffee, corn; self-sufficient in ba-
sic foods; an illegal producer of cannabis for
the international drug trade
Fishing: catch 143,000 metric tons (1983);
exports $53.2 million (1984)
Major industries: food processing, bever-
ages, petroleum products, construction ma- -
terials; clothing, paper products
Electric power: 1,200,000 kW capacity
(1985);-3.1 billion kWh produced er
1,420 kWh per capita.
Exports: $419 million (f.0.b., 1984); petro-
leum products, bananas, shrimp, sugar
Imports: $1.34 billion (f.0.b., 1984); petro-
leum products, manufactured goods, ma-
chinery and transportation equipment,
chemicals, foodstuffs
Major trade partners: exports—59.1% US,
17% Central America and Caribbean, 16%
EC, 8% other; imports—30% US, 19% Cen-
tral America and Caribbean, 10% Mexico;
8% Japan, 8% Venezuela, 6% EC, 15% ‘other
(1984)
Aid: economic—US, including Ex-Im com-
mitments (FY70-84), $394 million; Western —
(non-US) countries, ODA and OOF
(1970-83), $468 million; Communist coun-
tries (1970-84), $5 million; military —US
(FY70-84), $37 million
Budget: (1984) revenues, $886 million; ex- -
penditures, $1.175 billion
Monetary conversion rate: 1 balboa= US$]
(January seigeies
Fiscal year: calendar year','471845d4474ae86feb9133a02ebf48527f453e31aeeaec8ea06054f711a2e7d6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d786269f8355e523b9620da177a35132183f44678b00c0b062f483cca5cd7081',1986,'PY','Paraguay','government',398,'Official name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncién
Political subdivisions: 19 departments and
the national capital
Legal system: based on Argentine codes,
Roman law, and French codes; constitution
promulgated 1967; judicial review of legisla-
tive acts in Supreme Court; legal education
at National University of Asuncion and
Catholic University of Our Lady of the As-
sumption; does not accept compulsory ICJ
jurisdiction
National holiday: Independence Day, 14
May
Branches: President heads executive: bicam-
eral legislature (Senate, Chamber of Depu-
ties); judiciary headed by Supreme Court
Government leader: Gen. (Ret.) Alfredo
STROESSNER, President (since May 1954)
Suffrage: universal; compulsory between
ages of 18 and 60
Elections: President and Congress elected
together every five years (last election Feb-
ruary 1983)
Political parties and leaders: Colorado
Party, Juan Ramon Chaves; Authentic Radi-
cal Liberal Party (PLRA), Miguel Angel
Martinez Yaryes; Christian Christian Demo-
cratic Party (PDC), Alfredo Rojas Len;
Febrerista Revolutionary Party (PRF),
Fernando Vera; Liberal] Party (PL), Joaquin
Burgos; Popular Golorado Movement
(MOPOCO), Waldino Lovera; Radical Lib-
eral Party (PLR), Emilio Forestieri
Voting strength: (February 1983 general
election) 90% Colorado Party, 5.6% Radical
Liberal Party, 3.2% Liberal Party;
Febrerista Party boycotted elections
Communists: Oscar Creydt faction and
Miguel Angel Soler faction (both illegal); est.
196
3,000 to 4,000 party members and sympa-
thizers in Paraguay, very few are hard core;
party in exile is small and deeply divided
Other political or pressure groups: Popular
Colorado Movement (MoPoCo) led by
Epifanio Méndez, in exile; National Accord
includes MoPoCo and Febrerista, Radical
Liberal, and Christian Democratic Parties
Member of: FAO, G-77, IADB, IAEA,
IBRD, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, ILO, IMF, INTELSAT, INTERPOL,
IPU, IRC, ITU, LATA, OAS, SELA, UN,
UNESCO, UPU, WHO, WMO, WSG','fc3c570226f6259b6c4cc843abfd1a998528f93f8235dabc191ed7c9ba77366e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6dc8b930d1f1bd0c93c7fc6864b9a6de4487d3eb59c8d6bb784471e1949583f',1986,'PE','Peru','government',402,'Official name: Republic of Peru
Type: republic
Capital: Lima
Political subdivisions: 24 departments with
limited autonomy plus constitutional Prov-
ince of Callao
Legal system: based on civil law system;
1979 constitution reestablished civilian gov-
ernment witha popularly elected president
and bicameral legislature; legal education at
the National Universities in Lima, Trujillo, —
Arequipa, and Cuzco; has not accepted com-
pulsory ICJ jurisdiction :
National holiday: Independence Day, 28
July
Branches: executive, judicial, bicameral
legislature (Senate, Chamber of Deputies)
Government leader: Alan GARCIA Pérez,
President (since July 1985); Luis ALVA Cas-
tro; Prime Minister (since July 1985)
Suffrage: universal over age 18
Elections: elections for president and con-
gress held every five years; election for presi-
dent and congress held 14 April 1985; new
government inaugurated 28 July 1985
Political parties and leaders: American Pop-
ular Revolutionary Alliance (APRA), Alan
Garcia; United Left (IU), Alfonso Barrantes;
Popular Christian Party (PPC), Luis Bedoya
Reyes; Popular Action Party (AP), Fernando
Belatinde Terry
Voting strength: (1985 presidential election)
48% APRA, 23% IU, 14% PPC, 5% AP
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Peru (continued)
Communists: Communist Party of Peru
(PCP), pro-Soviet, 2,000; pro-Chinese (2 fac-.
tions) 1,200
Member of: Andean Pact, AIOEC, ;
ASSIMER, CIPEC, FAO, G-77, GATT, -
IADB, IAEA, IATP, IBRD, ICAO, ICO,
IDA, IDB—Inter-American Development
Bank, IFAD, IFC, ILO, INTERPOL, IMF,
IMO, INTELSAT, International Lead and
Zinc Study Group, ISO, ITU, ''WC—Inter-
national Wheat Council, LAIA, NAM, OAS,
PAHO, SELA, UN, UNESCO, UPU,
WFTU, WHO, WMO, WSG, WTO','8f7d11e916056cc8f6d209a2b1e86625ab93e8450a4602c6b5f4addb9d6d47ab','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40ae3f05d0c72162a8cf1bf12a61cfd5489020b4729ac6d739c2f04555118c87',1986,'PH','Philippines','government',406,'Official name: Republic of the Philippines
Type: republic
Capital: Manila (de facto), Quezn City (des-
ignated) .
Political subdivisions: 74 provinces and 6]
chartered cities
Legal system: based on Spanish, Islamic,
and Anglo-American law; parliamentary
constitution passed 1978; constitution
amended in 1981 to provide for French- °
style mixed presidential-parliamentary sys-
tem; judicial review of legislative acts in the
Supreme Court; legal education at Univer- _
sity of the Philippines, Ateneo de Manila
University, and 71 other law schools; accepts
compulsory IC]J jurisdiction, with reserva-
tions
National holiday: Independence Day, 12
June
Branches: constitution provides for unicam-
eral legislature (Batasang Pambansa) and a
strong executive branch under President and
Prime Minister; judicial branch headed by
Supreme Court with descending authority in
a three-tiered system of local, regional trial,
and intermediate appellate courts ©
Government leader: Corazon AQUINO,
President (since February 1986); Salvador
LAUREL, Vice President, Prime Minister,
and Foreign Minister (since February 1986)
Suffrage: universal and compulsory
Elections: presidential election held on 7
February 1986; Ferdinand Marcos initially
declared winner; following civil unrest and
military rebellion, he left office and Aquino
assumed presidency; provincial and legisla-
tive elections may be scheduled for late 1986
Political parties: national parties are New
Society Movement (KBL); United National-
ist Democratic Organization (UNIDO); and
the Liberals, Nacionalistas, and PDP-Laban;
prominent regional parties include the Mi- ;
ndanao Alliance and the Pusyon Visevas ‘
Communtsix the Chiaraanist Party at the :
Philippines (CPP) controls about 16,000 full-
time insurgents; not recognized as légal ... -
party; a second Communist party, the-pro---
Soviet Philippine Communist Party ERE
has quasi-legal status shot 30
Member of ADB, ASEAN, .ASPAC, Co-
lombo Plan, ESCAP, FAO, G-77, GATT, _
IAEA, IBRD, ICAO, IDA, IFAD, IFC, IHO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, IRC, ISO, ITU, UN, UNESCO, UPU, ©
WFTU, WHO, WIPO, WMO, WTO |
Economy : ae
GNP: $33.590 billion (1985 scistehee ); $590 ;
per capita; —3.8% real growth, 1985 prelim:
Natural resources: timber, petroleum,. . :
nickel, iron, cobalt,''silver, gold... . <°
Agriculture: main crops—rice, corn, coco-
nut, sugarcane, bananas,-abaca, tobacco
Fishing: catch 1.8 million metric tons (1982)
Major industries: textiles, pharmaceuticals,
chemicals, wood products, food processing, _
electronics assembly
Electric power: 6,290,000 kW capacity |
(1985); 22 billion kWh produced (1985), Bet
kWh per capita
Exports: $4.636 billion (f.0.b., 1985 prelim:);
coconut products, sugar, logs and lumber, «. °
copper concentrates, bananas; garments; -
nickel, electrical components, gold
Imports: $5.085 billion (f.0.b., 1985 prelim);
petroleum, industrial equipment, wheat
Major trade partners: (1983) exports—36%.
US, 20% Japan; imports—23% US, 17% Ja- ;
pan
Budget: (1984) revenues, $3.1 billion; expen-
ditures, $2.8 billion, deficit, $0:3 billion ©
Monetary conversion rate: (floating) 18.8
pesos= =e (December 18?)
Fiscal year: éalendae year ~
199
Communications j
Railroads: 378 km ecaeibie (1982); 34% gov-''
ernment owned
Highways: 152,800 km total (1980); 27,800
km paved; 73,000 km gravel, crushed stone,
or stabilized soil surface; 52,000 km unim-
proved earth .” :
Inland waterways: 3,219 km; limited. to. -
shallow-draft (less than 1.5 m) vessels
Pipelines: refined products, 357 km
Ports: 10 major, numerous minor
Civil air: approximately 53 major transport
aircraft
Airfields: 331 total, 284 usable; 70 with °
permanent-surface runways; 10 with run-
ways 2,440-3,659 m, 48 with runways
1,220-2,439 m
Telecommunications: good international
radio and submarine cable services; domes-
tic and interisland service adequate; 707,000
telephones (1.28 per 100 popl.); 267 AM sta-
tions, including 6 US; 55 FM stations; 33 TV
stations, including 4 US; submarine cables
extended to Hong Kong, Guam, Singapore,
Taiwan, and Japan; tropospheric-scatter link
to Taiwan; 2 international ground satellite
stations; 11 domestic satellite stations
Defense Forces
Branches: Army, Navy, Air Force, Constab-
ulary—Integrated National Police
Military manpower: males 15-49, .
14,553,000; 10,315,000 fit for military ser-
vice; about 610,000 reach military age (20)
annually...
Supply: limited small arms and small arms |
ammunition, small patrol craft production;
licensed assembly of transport aircraft; most
other. materiel obtained from US; naval ships
and equipment from Australia, Japan, Si-
ngapore, US, and F RG: aircraft and helicop-
ters from FRG, US, Italy, Australia, and the
Netherlands .
Military biddeok for fiscal year mae 81
December 1986, $569 million; about 15.7%
of central government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Pitcairn Islands
100km
Oeno
i fenderson .
Ducie,
e+ ADAMSTOWN','f8e412a60cec721e542a98567ad322c26af2e36f100182226c8a23b566da1b26','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4ffb40dbcae3440bdb4fec8b69499727cdfc58f2bc994e9524748960434d196',1986,'PN','Pitcairn','government',407,'South Pacific Ocean
See regional map X
Land
47 km; about one third the size of Washineg-
ton, D. C.; Pitcairn (5 km?), plus four unin-
habited islands (Oeno—5 km?, Ducie—5
km?, Henderson—31 km?, Sandy 1 km?);
volcanic, fertile land
Water
Limits of territorial waters (claimed ):3nm
(200 nm fishing zone)
Coastline: Pitcairn 10 km; Oeno 5.5 km;
Ducie 8 km; Henderson 26 km; Sandy 1.5
km','8808b2cdb4496a02b2d4f43b00a033c7203bb4aa4f1cb907cc02989e83921368','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71b9b45c9a601c45cdb8d7c684706bea1a9bb85e191b824a9f8dfa59debd25c8',1986,'PL','Poland','government',413,'Official name: Polish People’s Republic
Type: Communist state
Capital: Warsaw
Political subdivisions: 49 provinces
Legal system: mixture of Continental
(Napoleonic) civil law and Communist legal
theory; constitution adopted 1952; court
system parallels administrative divisions
with Supreme Court, composed of 104 jus-
tices, at apex; no judicial review of legisla-
tive acts; legal education at seven law
schools; has not accepted compulsory ICJ
jurisdiction
National holiday: National Liberation Day,
22July | ee
Branches: unicameral legislature (Seim),
executive, judicial system dominated by
parallel Communist party apparatus
Government leaders: Zbigniew MESSNER,
Chairman of Council of Ministers (Premier;
since November 1985); Army Gen. Wojciech
JARUZELSKI, Chairman of Council of
State (President; since November 1985)
Suffrage: universal and compulsory over age
18 :
Elections: parliamentary and local govern-
ment every four years; last election held Oc-
tober 1985
Political party and leader: Polish United
(Communist) Workers’ Party (PZPR), Woici-
ech Jaruzelski, First Secretary (since October
1981)
201
Voting strength: (March 1985 election)
78.86% voted for Communist-approved can-
didates
Communists: 2.2 million (1984)
Other political or pressure groups: United
Peasant Party (ZSL), Democratic Party (SD);
powerful Roman Catholic Church, Patriotic
Movement of National Rebirth (PRON)
Member of: CEMA, FAO, GATT, IAEA,
ICAO, ICES, IHO, ILO, Indochina Truce
Commission, IMO, International Lead and
Zinc Study Group, IPU, ISO, ITC, ITU, Ko-
rea Truce Commission, UN, UNESCO,
UPU, WFTU, WHO, Warsaw Pact, WIPO,
WMO, WTO','58873cc1d7d0d4216962c42e17bb93831d4f20c498633bcd0564e41ee00aff88','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66f32b677a5d43a44324c9fb263d7e30ce65c3bb9381c60fcfedef703746672d',1986,'PT','Portugal','government',417,'Official name: Portuguese Republic
Type: republic, first government under new
constitution formed July 1976
Capital: Lisbon
Political subdivisions:.18 districts in main-
land Portugal; Portugal’s two autonomous
regions, the Azores and Madeira Islands,
have 4 districts (3 of them in the Azores);
Macau, Portugal’s remaining overseas terri-
tory, was granted broad executive and legis-
lative autonomy in February 1976; Portugal
has not officially recognized the unilateral
annexation of Portuguese Timor by Indone-
sia
Legal system: civil law system; constitution
adopted April 1976 and revised October
1982; the Constitutional Tribunal reviews
the constitutionality of legislation; legal edu-
cation at Universities of Lisbon and Coim-
bra; accepts compulsory IC] jurisdiction,
with reservations
National holiday: 25 April
Branches: executive with President and
Prime Minister; unicameral legislature (pop-
ularly elected 250-seat Assembly of the Re-
public); independent judiciary *
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 -
Government leaders: Mario SOARES, Presi-
dent (since March 1986); Anibal Cavaco
SILVA, Prime Minister (since November
1985)
Suffrage: universal over age 18
Elections: national elections for Assembly of
the Republic normally to be held every four
years; Assembly elections held October
1985; national election for President to be
held every five years (scheduled for 29 Janu-
ary 1986), second constitutional president
elected in December 1980; local elections to
be held every three years, last elections in
December 1985
Political parties and leaders: Social Demo-
cratic Party (PSD), Anibal Cavaco Silva;.Por-
tuguese Socialist Party (PS), Mario Soares;
Party of Democratic Renewal (PRD), Her-
minio Martinho; Portuguese Communist
Party (PCP), Alvaro Cunhal; Social Demo-
cratic Center (CDS), Adriano Moreira
Voting strength: (1985 parliamentary elec-
tion) Social Democrats, 29.87%; Socialists,
20.77%; Democratic Renewal, 17.92%;
Communists (in a front coalition called the
United Peoples Alliance—APU), 15.49%;
Center Democrats, 9.96% (1985 local elec-
tions) PSD, 34.02%; PS, 27.89%; APU,
19.44%; CDS, 9.7%; PRD, 4.74% (unofficial
results) ; ‘
Communists: Portuguese Communist Party
claims membership of 200,753 (December
1983)
Member of: Council of Europe, EC, EFTA,
FAO, GATT, IAEFA, IATP, IBRD, ICAC,
ICAO, ICES, ICO, IDB—Inter- ArieriGane
Development Bank, IEA, IFAD, IFC, IHO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IOOC, IRC, ISO, ITU, IWC—International
Wheat Council, NATO, OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG
Economy i
GNP: $19.2 billion (1984); 15% government
consumption, 71% private consumption,
23% fixed capital formation; —0.7% change
in stocks; —8% net exports; real growth rate
— 1.7% (1984)
Natural resources: fish, forests (cork), tung-
sten, iron, uranium ores
Agriculture: generally underdeveloped;
main crops—grains, potatoes, olives, grapes
for wine; deficit foods—sugar, grain, meat,
fish, oilseed
Fishing: catch 243,423 metric tons (1984)
Major industries: textiles and footwear;
wood pulp, paper, and cork; metalworking;
oil refining; chemicals; fish canning; wine
Crude steel: 690, 675 tons produced (1988),
69 kg per capita
Electric power: 5,124,000 kW capacity
(1985); 16.829 billion kWh produced (1985),
1,675 kWh per capita
Exports: $5.2 billion-(£.0.b., 1984); principal
items—cotton textiles, cork and cork prod-
ucts, canned fish, wine, timber and timber
products, resin, machinery, and appliances
Imports: $7.8 billion (c.i.f., 1984); principal
items—petroleum, cotton, industrial ma-
chinery, iron and steel, chemicals
Major trade partners: 58% EC, 9% US, 2%
Communist countries, 18% other developed
countries, 11% less developed countries _.
Aid: economic authorizations—US, includ-
ing Ex-Im, $1.5 billion (FY70-84); other .
Western countries (ODA and OOF), $749 |
million (1970-82); military authorizations—
US, $475 million (FY70-84)
Budget: (1984) expenditures, $7.0 billion;
revenues, $4.5 billion; deficit, $2.5 billion
Monetary conversion ‘rate: 163.3]
escudos=US$1 (October 1985)
Fiscal year: calendar year','7db45d3bd74b97186fd1536957d073be2694d303839c1f6c30265b952b33221c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4d56a094439d5591637447ccd49c18356bb8a9210bdc6d8c772cfb2e28f8d82',1986,'QA','Qatar','government',420,'Official name: State of Qatar
Type: traditional monarchy; independence
declared in 1971
Capital: Doha
Legal system: discretionary system of law
controlled by the ruler, although civil codes
are being implemented; Islamic law is signif-
icant in personal matters; a constitution was
promulgated in 1)
National holiday: jadansndeids Day, 3
September
Beaiehen Sievitive—-Ainit and Council of
Ministers; legislature—State Advisory Coun-
cil
Government leader: Khalifa bin Hamad Al
THANI, Amir and Prime Minister (since
February 1972) ,
Suffrage: no specific provisions for suffrage
laid down é
Elections: constitution calls for elections for
part of State Advisory Council, a consulta-
tive body, but no elections have been held
Political parties and leaders: none
Other political or pressure groups: a few
small clandestine organizations are active
Member of: Arab League, FAO, G-77, |
GATT (de facto), GCC, IBRD, ICAO,
IDB—Islamic Development Bank, IFAD,
ILO, IMF, IMO, INTELSAT, INTERPOL,
ITU, NAM, OAPEC, OIC, OPEC, UN,,.
UNESCO, UPU, WHO, WIPO, WMO
Official name: Department of Reunion
Type: overseas Heparithent of Fines: repre-
sented in French Parliament by three depu-
ties and two senators :
Capital: Saint-Denis
Legal system: French law °
Branches: Reunion is administered by a Pre-
fect appointed by the French Minister of
Interior, assisted by a Secretary General and
an elected 36-man General Council; in 1974
France created an elected 45-member Re-
gional Assembly to coordinate economic and
social development policies; in 1981 both the
General Council and the Regional Assembly
received greater authority for fiscal policy.
Government leader: Michel BLANGY,
Commissioner of the Republic (since Febru-
ary 1984)
Suffrage: universal adult
Elections: last municipal and General Coun-
cil elections in 1983; parliamentary election
June 1981; Regional Assembly election Feb-
ruary 1983
Political parties and leaders: Reunion Com-
munist Party (RCP), Paul Verges; Popular -
Movement for the Liberation of Reunion,
Georges Sinamale; other political candidates
affiliated with metropolitan French parties,
which do not maintain permanent organiza-
tions on Reunion
Voting strength: (parliamentary election
1981) Union for French Democracy — Rally
for the Republic coalition elected two depu-
ties; the Socialists elected one; in the 1983
Regional Assembly election, leftist parties
received 45.7% of the vote _
Communists: Communist Party small but
has support among sugarcane cutters and the
minuscule Popular Movement for the Liber-
ation of Reunion (MPLR) and in Le Port
District
Member of: WFTU
205"','f936eb9b8b9c8afbd66a09da45a78dcecf94a19f77aec4fbe06a16af97d98502','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c189b7be20f34ec61a3673240e61770c36bca14937dad3cdade6d07789adb61',1986,'RO','Romania','government',424,'Official name: Socialist Republic of Roma-
nia ;
Type: Communist state
Capital: Bucharest © ~~”
Political subdivisions: 40 counties; city of
Bucharest has administrative status equal to
a county :
Legal system: mixture of civil law''system
and: Communist legal theory that increas-
ingly reflects Romanian traditions; constitu-
tion adopted 1965; legal education at Uni-
versity of Bucharest and {wo ''cther law:*
schools; has not accepted compulsory ICJ
jurisdiétion ae
Mwioadl holiday: feces Day, 23
August
Branches: Présidency; Council of Ministers; ~
Grand National Assembly, under which is
Office of Prosecutor General and Supreme
Court; Council of State
Government leaders: Nicolae
CEAUSESCU, President of the Socialist Re-
public (head of state; since 1967); Constantin
DASCALESCU, Prime Minister (since May
1982)
Suffrage: universal and compulsory over age
18 po
Elections: élections held every five''years for ~
Grand National Assembly deputies and local
people’s councils; last election held March
1985 :
Political parties and leaders: Communist
Party of Romania only functioning party,
Nicolae Ceausescu, Secretary General (since
March 10)
Voting siensie (iss eléction) overall par-
ticipation reached 99.99%; of those regis-
tered to vote (15,733,060), 97.73% voted for
party candidates
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
ee ee ee:
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Communists: 3,400,000 (November 1984)
Member of: CEMA, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IFAD, ILO, IMF,
IMO, INTERPOL, IPU, ITC, ITU, UN,
UNESCO, UPU, Warsaw Pact, WFTU, .
WHO, WIPO, WMO, WTO','9d64ff846e49db0ad96d4f80456b86f57ab76f3f06f3d0c0cdd536245136b46a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cf84342ee9b66ec386efacce25a0f6d603c032a107c87070e09a160eeb868a8',1986,'RW','Rwanda','government',428,'Official name: Republic of Rwanda
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Rwanda (continued)
Type: republic; presidential system in which
military leaders hold key offices; new consti-
tution adopted 17 December 1978
Capital: Kigali
Political subdivisions: 10 prefectures, subdi-
vided into 143 communes
Legal system: based on German and Belgian
civil law systems and customary law; judicial
review of legislative acts in the Supreme
Court; has not accepted compulsory ICJ
jurisdiction
National holiday: National Day, lJuly ©
Branches: executive (President, 16-member
Cabinet); unicameral legislative (National
Development Council); judiciary (4 senior
courts, magistrates)
Government leader: Maj. Gen. Juvénal
HABYARIMANA, President and Head of
State (since 1973)
Suffrage: universal adult
Elections: national elections, including con-
stitutional referendum and presidential
plebiscite, held December 1978; National
‘ Development Council elected and President
reélected in December 1983
Political parties and leaders: National Revo-
lutionary Movement for Development
(MRND), General Habyarimana (officially a
“development movement, ” not a party)
Communists: no Communist party
Member of: A[DB, EAMA, FAO, G:77,
GATT, IBRD, ICAO, ICO, IDA, IFAD,
IFC, ILO; IMF, INTERPOL, IPU, ITU,
NAM, OAU, OCAM, UN, UNESCO, UPU,
WHO, WMO, WTO’','79104e55d47ab4e413b4863bd53fa51c7b52f1d1041314b9154aed1fac7c2766','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d88edcb6f75eed05f1519baa7b3fe5f91125f5ff842df36255635cfb2b4591d',1986,'SM','San Marino','government',432,'Official name: Republic of San Marino
Type: republic (dates from 4th century
A.D.); in 1862 the Kingdom of Italy con-
cluded a treaty guaranteeing the indepen-
dence of San Marino; although legally
sovereign, San Marino is vulnerable to pres-
sure from the Italian Government
Capital: San Marino
Political subdivisions: San Marino is divided
into 9 “castles” Acquaviva, Borgo Maggi-
ore, Chiesanuova, Domagnano; Faetano,
Fiorentino, Monte Giardino, San Marino,
Serravalle
Legal system: based on civil law system with
Italian law influences; electoral law of 1926
serves some of the functions of a constitu-
tion; has not accepted compulsory ICJ juris-
diction
National holiday: Anniversary of the Liber-
ation of the Republie, 5 Febriiary
Branches: the Grand and General: Council is
the legislative body élected by popular vote;
its 60 members ''serve five-year terms; Coun-
cil in turn elects two''Captains-Regent who
exercise executive power for term of six
months, the Congress 6f State whose mem-
bers head government administrative de-
partments, and the Council of Twelve, the
supreme judicial body: actual exécutive
power is wielded by the Sécretary of State
for Foreign Affairs and the Secretary of
State for Internal Affairs’
Government leaders: Giordario Bruno RE-
FFI (Socialist); Secretary of State for Foreign
and Political Affairs and for Information
(since July 1978); Alvaro SELVA (Commu-
nist), Secretary of State for Internal Affairs
and Justice (since July 1978); Dr. Emilio DE-
LLA BALDA (Unitary Socialist), Secretary
of State for Budget, Finance, and Planning
(since July 1978)
Suffrage: universal (since 1960) .
Elections: elections tothe Grand and Gen-
eral Council required at least every five
years; last election was held 29 May 1983
Political parties and leaders: Christian
Democratic Party (DCS), Clara Boscaglia;
Social Democratic Party (PSDS), Alvaro
213
Casali; Socialist Party (PSS), Remy Giacom-
ini; Communist Party (PCS), Gilberto
Ghiotti; Unitary Socialist Party (PSU), Em-
ilio Della Balda; Committee for the Defense
of the Republic (CDR), leader unknown
Voting strength: (1983 election) 42.1% DCS,
24.4% PCS, 14.8% PSS, 13.9% PSU, 2.9%
PSDS .
Communists: approx. 300 members (num-
ber of sympathizers cannot be determined);
the PCS, in conjunction with the PSS, PSU,
and PSDS, has led the government since.
1978
Other political parties or pressure groups:
political parties influenced by policies of . -
their counterparts in Italy; the two Socialist -
parties are not united
Member of: ICJ, International Institute for -
Unification of Private Law, International .
Relief Union, ITU, IRC, UNESCO, UPU,
WFTU, WHO, WTO; observer status''in
NAM _','28af67c9f8c07027f75e40888867212c2ff64e24dbc9589224f89d517899545b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4603dbfa57e52af47812661ce8f10294c4a8dcd9a2c893cb1a77a7588592c95a',1986,'SA','Saudi Arabia','government',435,'Official name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh
Political subdivisions: 14 provinces .
Legal system: based on Islamic law, several
secular codes have been introduced; com-
mercial disputes handled by special commit-
tees; has not accepted compulsory IC] juris-
diction
National holiday: 23 September
Branches: King rules in consultation with .
royal family and Council of Ministers
Government leader: FAHD bin ‘Abd al-
‘Aziz Al Sa‘ud, King and Prime Minister
(since 1982)
Communists: negligible
Member of: Arab League, FAO, G-77, GCC,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, International Maritime
Satellite Organization, INTERPOL, ITU,
IWC— International Wheat Council, NAM,
OAPEC, OIC, OPEC, UN, UNESCO, UPU,
WHO, WMO','91a5eb1558aafc8dbc48745901cff32a10d4715834445470cf9cdd9f09576942','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f37ef2440d0a2b30637c2dc0cc1dcb7399945fcbb19b6ccd8cc4c2e7fd12b57',1986,'SC','Seychelles','government',441,'Official name: Republic of Seychelles...
Type: republic; member of the Common- -
wealth : ; .
Capital: Victoria, Mahé Island. a
Legal system: based on English’ common a
law, French civil law, and customary law, =
National holidays: 5 and 29 June
Branches: President, Council of Ministers,
People’s Assembly | 7
Government leader: France Albert RENE, .
President (since June 1979)
Suffrage: universal adult
Elections: general election held June 1979. ,
gave 98% approval to René as only presiden-
tial candidate on yes/no ballot; reelected i in
June 1984 with 92% of vote
Political parities ‘and ieiden: René, who -
heads the Seychelles People’s Progressive” “
Front, came to power by a military coup in
June 1977; until then he had been Prime ~
Minister in an uneasy coalition with then ||
President James Mancham, who headed the.
Seychelles Democratic Party; René barined |
the Seychelles Democratic Party in March. ;
1978 and announced anew ‘constitution in
March 1979 that turned the country into a
one-party state. ‘
Communists: negligible, although some _
Cabinet sip eta ea line :
Other political or ‘pressure groups: trade |
unions, ‘church
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Member of: AfDB, FAO, G-77, GATT (de
facto), IBRD, ICAO, IFAD, IFC, ILO, IMF,
IMO, INTERPOL, NAM, OAU, UN, “et
UNESCO, UPU, WHO, WMO','cb51ae166894a3859a3e5534ec56c27829ecbb0517301563c33ec423f3782104','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92da7842a5827cb8fb33be99194ac679af7df1f1d004aa4be099a24598557def',1986,'SL','Sierra Leone','government',445,'Official name: Republic of Sierra Leone
Type: fepublic under presidential regime
since April av = :
Capital: Freetown —
Political subdivisions: 3 provinces and the
Western Area; divided into 12 districts with’
146 chiefdoms, where paramount chief and
council of elders constitute basic unit of gov-
ernment; plus Western Area, which-com-
prises Freetown and other coastal areas of
the former colony --
Legal system: based on English law and cus-
tomary laws indigenous to local tribes; con-
stitution adopted 1978; highest court of ap-
peal is the Sierra Leone Court of Appeals;
has not accepted compulsory IC] jurisdic-
tion
National holiday: Republic Day, 19 April
Branches: executive authority exercised by
President; unicameral parliament consists of
104 authorized seats, 85 of which are filled
by elected representatives of constituencies
and 12 by Paramount Chiefs elected by fel-
low Paramount Chiefs in each district; Presi-
dent authorized to appoint up to seven
members; independent judiciary .
Government leader: Gen. Joseph MOMOH,
President (since 28 November 1985); Francis
MINAH, First Vice President (since Novem-
ber 1985); A. B. KARMARA, Second Vice
President (since November 1985)
Suffrage: universal over age 21
Elections: the Constitution of Sierra Leone _
Act, 1971, has been replaced''by the Consti-
tution of Sierra Leone, 1978, which provides
for one-party rule
Political parties and leaders: All People’s
Congress (APC), headed by Momoh
Communists: no party, although there are a
few Communists and a slightly larger num-
ber of sympathizers
Member of: AEDB, AIOEC, Common-
wealth, ECA, ECOWAS, FAO, G-77,
GATT, IAFA, IBA, IBRD, ICAO, ICO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, IMO, INTERPOL, IPU,
IRC, ITU, Mano River Union, NAM, OAU;
OIC, UN, UNESCO, UPU, WHO, WMO,
WTO
cannon
GDP: (current factor cost) $1 billion
(1983/84 est.); real growth rate 0.5%
(1983/84)
Natural resources: diamonds, rutile, baux-
ite, iron ore, gold, chromite
Agriculture: main crops—palm kernels,
coffee, cocoa, rice, yams, millet, ginger, cas-
sava; much of cultivated land devoted to
subsistence farming; food crops insufficient
for domestic consumption
Fishing: catch''53,000 metric tons (1983)
Major industries: mining—diamonds, iron
ore, bauxite, rutile; manufacturing bever-
ages, textiles, cigarettes, construction goods;
1 oil refinery
Electric power: 65,000 kW capacity (1985);
113 million kWh produced GES?) 29kWh
per capita
Exports: $104 million (f-0.b., 1983/84); dia-
monds, iron ore, palm kernels, cocoa, coffee
Imports: $126 million (f.0.b., 1983/84); ma-
chinery and transportation equipment,-
manufactured goods, foodstuffs, petroleum
products
Major trade partners: UK, EC, US, Japan,
Communist countries
Budget: (1983/84) revenues, $109 million,
current expenditures, $146 million; develop-
ment expenditures, $68 million
220
Monetary conversion rate: (official) 2.5
leones=US$1 (October 1983)
Fiscal year: 1 July-30 June','7e0068ba95474c41a8b5444879c934382f70c931e8749af07b1828dbb158bd70','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63db663f0636f3840f684fc08d12be321b1ceeaa758a20f519b5251b4415100c',1986,'SG','Singapore','government',448,'Official name: Republic of Singapore.
Type: republic within Commonwealth. -
Capital: Singapore
Legal system: based on English common.
law; constitution based on preindependence
State of Singapore constitution; legal educa- .
tion at University of Singapore; has not ac-.
cepted compulsory IC] jurisdiction
National holiday: 9 August
Branches: ceremonial President; executive
power exercised by Prime Minister and Cab-
inet responsible to unicameral legislature
(Parliament)
Government leaders: WEE Kim Wee, Presi-
dent (since September 1985); LEE Kuan
Yew, Prime Minister (since June 1959)
Suffrage; universal and compulsory over age
20 o.
Elections: normally held every five years;
last held-1984
Political parties and leaders: government—
People’s Action Party (PAP), Lee Kuan Yew;
opposition —Barisan Sosialis (BS), Dr. Lee
Siew Choh; Workers’ Party (WP), J.B.
Jeyaretnam; United People’s Front (UPF),
Harbans Singh; Singapore Democratic Party
(SDP), Chiam See Tong; Communist Party
illegal
Voting strength: (1984-election) PAP won
77 of 79 seats in Parliament and received
63% of the vote; WP and SDP won one seat
each
Communists: 200-500; Barisan Sosialis infil-
trated by Communists
Member of: ADB, ANRPC, ASEAN, Co-
lombo Plan, Commonwealth, ESCAP, G-77,
221
GATT, IAEA, IBRD, ICAO, IFC, IHO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, ISO, ITU, NAM, UN, UNESCO, UPU,
WHO, WMO, WTO','ea5d5434d17e445c500745363afcfb5c42fb002384cada4e6f0baacdadea2178','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('837aacd7b7831e8a9e0485079570852db85b1cfb5de548e97465fb0c6b606f71',1986,'SB','Solomon Islands','government',452,'Official name: Solomon Islands
Type: independent parliamentary state
within Commonwealth
Capital: Honiara on the island of
Guadalcanal
Political subdivisions: 4 administrative dis-
tricts
Legal. system: a High Court plus Magistrates
Courts; also a system of native courts
throughout the islands |
Branches: executive authority i in Governor
General; unicameral legislature (38-member
National Parliament)
Government leaders: Sir Baddeley . _
DEVESI, Governor General (since July.
1978); Sir Peter KENILOREA,.Prime Minis-
ter (since November 1984)
Suffrage: universal adult at age 21
Bieciintan: every four years; last held Octo-.
ber 1984
Political parties and leaders: United Party,’
Sir Peter Kenilorea; People’s Alliance Party,
Solomon Mamaloni, National Democratic
Party, Bartholemew Ulufa’alu
Member of: ADB, Commonwealth, ESCAP,
G-77, GATT (de facto), IBRD, IDA, IFAD,
IFC, ILO, IMF, SPF, UN, UPU, WHO |','a38a0804a553d1c5254a044ae3b326e183ba3cd81aca67b58a2bcc5cb0f94710','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da7a7e3fbc3814a1309f00caf5c5669cd9a912cfd80e71bf0228a9a0347f421f',1986,'SO','Somalia','government',456,'Official name: Somali Democratic Republic
Type: republic « *
Capital: Mogadishu
Political subdivisions: 18 regions, 60 dis-
tricts
National holiday: 21 October
Branches: President dominates political sys-
tem; Cabinet carries out day-to-day govern-
ment functions; unicanieral legislature (Na-
tional People’s Assembly) exists but has little
power
Government leader: Maj. Gen. Mohamed
SIAD Barre, President and Commander in
Chief of the Army (since October 1969)
Political party and leader: the Somali Revo-
lutionary Socialist Party (SRSP), created on 1
July 1976, is the sole legal party; Maj. Gen.
Mohamed Siad Barre is general secretary of
the SRSP
Elections: parliamentary. elections held 31
December 1984
Communists: probably some Communist
sympathizers in the government hierarchy
Member of: Af{DB, Arab League, EAMA,
FAO, G-77, IBRD, ICAO, IDA, IDB—Is-
lamic Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, ITU,
NAM, OAU, OIC, UN, UNESCO, UPU,
WFTU, WHO, WMO','3695d861d2a27e3834b4fec480ec4b694e381e8826c3aef873a54ef8b3a9e198','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c55618cc9a868074482df1e2bed693ee138dcb6b1eb3ebf3e29b3e8c0ecfc71e',1986,'ZA','South Africa','government',460,'Official name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative,
Cape Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each
headed by centrally appointed administra-
tor; provincial councils, elected by white
electorate, retain limited powers; numerous
districts; 10 homelands’ administered in
areas set aside for black Africans
Legal system: based on Roman-Dutch law
and English common law; constitution en-
acted 1961, changing the Union of South
Africa into a republic; accepts compulsory
IC) jurisdiction, with reservations
National holiday: Republic Day, 31 May
Branches: state president is chief of state,
head of government, and chairman of cabi-
net; tricameral legislature—House of As-
sembly (whites), House of Representatives _
(coloreds), and House of Delegates (Indians)
élected directly by respective racial elector-
ates; judiciary maintains substantial inde-
pendence of government influence
Government leaders: Pieter Willem .
BOTHA, State. President (since September
1984)
Suffrage: general suffrage limited to whites
over 18 (17 in Natal Province) and to
coloreds and Indians over 18
Elections: must be held at least every five
years; last white election April 1981; last
colored and Indian elections August 1984;
because of the introduction of a new consti- ”
tution in 1984, the next white elections prob-
ably will be delayed until 1989 to coincide
with nonwhite elections
White political parties and leaders: Na-
tional.Party-P: W. Botha; Progressive Fed-
eral Party, Colin Eglin; New Republic Party,
Bill Sutton; Conservative Party, Dr. Andries ©
P. Treurnicht; Herstigte National Party,
Jaap Marais
Colored political parties and leaders: Labor
Party, Allan Hendrickse (majority party);
People’s Congress Party, Peter Marais
Indian political parties and leaders: Na-
tional People’s Party, Amichand Rajbansi
(majority party); Solidarity, J. N. Reddy
Voting strength: white parliamentary
seats—National Party, 127; Progressive Fed-
eral Party, 27; Conservative Party, 18; New
Republic, 5; Herstigte National Party, 1
Communists: small Communist Party illegal
since 1950; party in exile maintains head-
quarters in London; Joe Slovo
Other political groups: (insurgent groups in
exile) African National Congress (ANC),
Oliver Tambo; Pan-Africanist Congress
(PAC), Johnson Mlambo ,
225
Member of: GATT, IAEA, IBRD, ICAO, .
IDA, IFC, IHO, International Leadand
Zinc Study Group, IMF, INTELSAT, ISO,
ITU, I[WC—International Whaling Com-
mission, IWC—International Wheat Coun-
cil, UN, UPU, WFTU, WHO, WIPO,
WMO, WSG (membership rights in IAEA,
ICAO, ITU, WHO, WIPO, and WMO sus-
pended. or restricted)
Official name: Union of Soviet Socialist Re-
publics
Type: Communist state
Capital: Moscow —
Political subdivisions: 15 union republics,
consisting of 20 autonomous republics, 6 -
krays, 123 oblasts, 8-autonomous oblasts, and
10 autonomous okrugs :
Legal system: civil law system as modified.
by Communist legal theory; revised consti- -
tution adopted 1977; no judicial-review of
legislative acts; legal education at 18 univer-
sities and 4 law institutes; has not accepted
compulsory IC] jurisdiction ,
National holiday: October Revolution Day,:
7 November © : x8
Branches: executive—USSR Council of
Ministers, legislative-——USSR Supreme ''So- .
viet, judicial—Supreme Court of USSR...
Government leaders: Mikhail Sergeyevich
GORBACHEV, General Secretary of the
Central Committee of the Communist Party
(since 1.1 March 1985); Nikolay Ivanovich
RYZHKOV, Chairman.of the USSR Council:
of Ministers (since 28 September 1985);
Andrey Andreyevich GROMYKO, Presi-
dent of the Soviet Union (since 2 July 1985)
Suffrage: universal over age 18; direct, equal
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Elections: to Supreme Soviet every five .... .
years; 1,500 seats in 1984; 71.5% held By oh
party members _
Political party: ‘Gonienunist Party of the So-
viet Union (CPSU) only party permitted
Voting strength:(1984 election) 184,006,350
persons over. 18; allegedly.99.95% voted
Communists: over 18 million party mem- . :
bers ,
Other.political or pressure groups: -
Komsomol, trade unions, and other organi-
zations that facilitate Communist control :
Member of: CEMA, ESCAP, Geneva Disar-
mament Conference, IAEA, IBEC,.ICAC, ..:
ICAO, ICCAT; ICCO, ICES, ILO, IMO,
International Lead and Zinc Study Group,
INRO, IPU, ISO, ITC, ITU, IWC—Interna-
tional Whaling Commission, }WC—Inter-.
national Wheat Council, UN, UNESCO,
UPU, Warsaw Pact, WFTU, WHO, WIPO,
WMO, WTO
ecaweny
GNP: $1,957.6 billion (1984, in 1984 g geo-:
metric mean prices), $7,120 per capita; in,
1984 percentage shares were—53% con-
sumption, 30% investment, 17% government
and other, including defense (based on-1970
GNP in rubles at adjusted factor cost); aver- .
age annual growth rate of real GNP -
(1971-84), 3.0%, average annual.growth rate
(1976-84), 2.6%, (1984) 2.5%
Natural resources: fossil. fuels, hydroelectric
power, timber, manganese, lead, zinc,
nickel, mercury, potash, phosphates
Agriculture: principal food crops—grain
(especially wheat), potatoes; main industrial
crops—sugar beets, cotton, sunflowers, and
flax; degree of self-sufficiency depends on
fluctuations in crop yields, particularly: -.-
grain; large grain importer over past decade .
Fishing: catch 10.6 million metric tons: -
(1984); exports 452,755 metric tons (1983), ©
imports 371,237, metric tons (1984); exports -.
exclude canned fish; canned crab, and caviar
Major industries: diversified, highly devel-
oped capital goods industries; consumer
goods industries comparatively less devel-
oped -
Shortages: fertilizer, pesticides, feed, natu-
ral rubber, bauxite and alumina, tantalum,
tin, tungsten, fluorspar, molybdenum, and
finished steel products —
Crude steel: 174 million metric ton capacity
as of 1 January 1985; 154.2 million metric
tons produced in 1984, 560 kg per capita
Electric power: 316,000,000 kW capacity
(1985); 1,540 billion kWh produced (1985),
5,549 kWh per capita
Exports: $91.492 billion (f.0.b., 1984); petro-
leum and petroleum products, natural gas,
metals, wood, agricultural products, and a
wide variety of manufactured goods (pri-
marily capital goods and arms)
Imports: $80,352 billion (f.0.b., 1984), grain
and other agricultural products, machinery
and equipment, steel products (including
large diameter pipe), consumer manufac-
tures
Major trade partners: $171.8 billion (1984
total turnover); trade 58% with Communist
countries, 29% with industrialized West, and
13% with less developed countries
Aid: economic—total extaded to
non-Communist less developed countries
(1954-84), $30 billion
M onetary conversion rate: official, 0.743
ruble=US$1 ee average)
Coinininiteations:
Railroads: 144,100 km total; 142,967 km
1.524-meter broad gauge; 1,833 km mostly
0.750-meter narrow gauge; 113,315.km
broad-gauge single track; 47,900 km electri-.
fied; does not include industrial lines (1984)
Highways: 1,516,700 km total; 439,000 km
asphalt; concrete, stone block; 354,000km -
asphalt treated, gravel, crushed stone; __--
723,700 km earth (1984)
227
Inland waterways: 136,700 km navigable,.
exclusive of Caspian Sea (1984)
Freight carried: rail—3,909 million metric
tons, 3.64 trillion metric ton/km (1984);
highways—25.9 billion metric tons, 477 bil-
lion metric ton/km (1984); waterway—619 |
million metric tons, 265 billion metric
ton/km, excluding Caspian Sea (1984)
Pipelines: 78,300 km erude oil and refined
products; 165,000 km natural gas (1984)
Ports: 53 major (most important—Lenin- .
grad, Riga, Tallinn, Kaliningrad, Liepaja, |
Ventspils, Murmansk, Arkhangel’sk, Odessa,
Novorossiysk, Il’ichevsk, Nikolayev,
Sevastopol’, Vladivostok, Nakhodka); over. .
180 selected minor; 58 major inland ports
(some of the more important—Astrakhan’,;
Baku, Gor’kiy, Kazan, Khabarovsk, Sat
Krasnoyarsk, Kuybyshev, Moscow, Rostov,....
Volgograd, Kiev (1984)
Defense Forces
Branches: Ground Forces, Navy, AirDe- .
fense Forces, Air Forces, Strategic Rocket
Forces . ;
Military taipower: males 15-49, att,
68,559,000; 55,173,000.fit for military ser-__.
vice; 2,096,000 reach military age (17) annu-
ally ;
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4','99ac292bb11bbb2c96e0ef6140c160894fddf90294820cee607715632b343e72','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10056d8f517d015fb7aa14d8e42e0c67965f6bafcdb97f1a44a3cac6c262021a',1986,'ES','Spain','government',462,'300 km
Bay of Biscay
Balearic
Sea
© Balearic
* Islands
es
Mediterranean
North. : Sea
Atlantic”
Ocean’ _ Strait of
Gibraltar Canary tslands, Ceuta,
and Melilla are not shown,
See regional map V and VII
Land
504,782 km2; including Canary (7,511 km?)
“and Balearic (5,025 km?) Islands; the size of
Arizona and Utah combined; 41% arable
and crop, 27% meadow and pasture, 22% —
forest, 10% urban or other
Land boundaries: 1,899 km ©:
’ Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 4,964 km (includes Balearic Is-
lands, 677 km, and Canary Islands, 1,15
km) 5
Official name: Spanish State
Type: parliamentary monarchy defined by
new constitution of December 1978, that
completed transition from authoritarian
regime of the late Generalissimo Franco and
confirmed Juan Carlos I as monarch, but
without the exceptional powers inherited
from Franco on being proclaimed King 22
November 1975
Capital: Madrid
Political subdivisions: metropolitan Spain,
including the Canaries and Balearics, di-
vided into 50 provinces, which form 17 au-
tonomous regions assuming numerous pow-
ers previously exercised by the central gov-
ernment; also five places of sovereignty
'' (presidios) on the Mediterranean coast of
Morocco; transferred administration of
Spanish Sahara to Morocco and Mauritania
on 26 February 1976
Legal system: civil law system, with regional
applications; new constitution provides for
rule of law, established jury system as well.as
independent constitutional court to rule on
unconstitutionality of laws and to serve as
court of last resort.in protecting liberties and
rights granted in constitution; does‘not:ac--
cept compulsory ICJ jurisdiction .
National holiday: 24 June
Branches: executive, with King’s acts subject
to countersignature, Prime Minister
(Presidente) and. his ministers responsible to
lower house; bicameral legislature—Cortes_.
228.
Generales, consisting of more powerful Con-
gress of Deputies (850 members) and Senate
(208 members), with possible addition of one
to six members from each new autonomous
region: judiciary, independent
Government leaders: JUAN CARLOS I,
King (since November 1975); Felipe
GONZALEZ Marquez, Prime Minister
(Presidente; since December 1982)
Suffrage: universal at age 18
Elections: parliamentary election 28 Octo-
ber 1982 for four-year term; local elections
for municipal and provincal councils April
1983; regional elections staggered
Political parties and leaders: principal na-
tional parties, from right to left—Popular -
Alliance (AP); Manuel Fraga Iribarne; Popu-
lar Democratic Party (PDP), Oscar Alzaga;
Liberal Union (UL), José Antonio Segurado,
‘Social Democratic Center (CDS), Adolfo. .
Suarez; Spanish Socialist Workers Party
(PSOE), Felipe Gonzalez Marquez; Spanish
Communist Party (PCE), Gerardo Iglesias;
chief regional parties—-Convergence and
Unity (CiU), Jordi Pujol, in Catalonia; Re-
publican Left of Catalonia (ERC), Herribert
Barrera; Basque Nationalist Party (PN), ©
Xabier Arzallus; Basque radical coalitions
Popular Unity (HB) and Basque Left (EE)
Juan Haria Bandres; Andalusian Party (PA),
‘Luis Urufiuela; Democratic Reform Party
(PRD), Antonio Garrigues Walker
Voting strength: (1982 parliamentary elec-
tion in lower house) PSOE 46%, and 202
seats (26''seats over a majority); AP, PDP, and
UL in coalition 25.4%, 106 seats; UCD
7.31%, 12 seats; PCE 3.9%, 4 séats; CiU
3.7%, 12 seats; CDS 2.9%, 2 seats; PNV 1.9%,
8 seats; HB 1%, 2 seats; EE .47%, 1 seat; ERC
.47%, 1 seat; PA .33% 0 seats
‘Communists: PCE membership has...
declined from a possible high of 160,000 in
1977 to.roughly.60,000 today; the party lost
64% of its voters and 20 deputies in the 1982
election; remaining strength is in labor,
where it dominates the Workers Commis-
sions trade union (one of the country’s two
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
major-labor centrals); which claims a mem-
bership of about 1 million; experienced a
modest recovery in 1983 municipal election,
receiving 8% of the vote .
Other political or pressure groups: on thé
extreme left, the Basque Fatherland and
Liberty (ETA) and the First of October Anti-
fascist Resistarice Group (GRAPO) use ter-
rorism to oppose the government; free labor
unions (authorized in April 1977)include the
Communist-dominated Workers Commis- —
sions (CCOO); the Socialist General Union of
Workers (UGT), and the smaller indepen-
dent Workers Syndical Union (USO); the
Catholic Church; business and landowning
interests; Opus Dei; university students
Member of: Andean-Pact (observer),
ASSIMER, Council of Europe, EC, ESRO,
FAO, GATT, IAEA, IBRD, ICAC, ICAO,
ICES, ICO, IDA, IDB—Inter- American
Development Bank, IEA, IFAD, IFC, IHO,
ILO, IMF, IMO, INTELSAT, Intertiational
Lead and Zinc Study Group, INTERPOL,
IOOC, IPU, ITC, ITU, IWC—International
Wheat Council, NATO, OAS (observer),
OECD, UN, UNESCO, UPU, WHO,
Ee WMO, WSG, WTO
Tesecoty
GNP: $160.4 billion (1984); 68% pavate con-
sumption, 12% government consumption,
18% gross fixed capital investment; 3%
change in stocks; 3% net exports; real growth
rate 2.2% (1984)
Natural resources: coal, lignite, iron ore,
uranium, mercury, pyrites, fluorspar, gyp-
sum, zinc, lead, tungsten, copper, kaolin,
hydroelectric power
Agriculture: main crops—-grains, vegeta-
bles, fruits; virtually self-sufficient in good
crop years
Fishing: catch, 1,123,100 metric toris (1984)
Major industries: textiles and apparel (in-
cluding footwear), food and beverages, met-
als and metal manufactures, chemicals, ship-
building, automobiles
Crude steel: 18.5:million metric tons pro-
duced.(1984), 348 kg per capita
Electric power: 38,490,000.kW capacity
(1985); 122.644 billion kWh produced
(1985), 3,160 kWh per capita
Exports: $23.6 billion (f.0.b., 1984); principal
items—iron and steel products, machinery,
automobiles, fruits and vegetables, textiles,
footwear
Imports: $28.8 billion (c.i-f., 1984); principal
items—fuels (40%), machinery, chemicals,
iron and steel, vegetables, automobiles.
Major trade partners: (1984) 49% EC, 24%
less developed countries, 12% other devel-
oped countries, 10% US, 4% Communist .
countries
Aid: economic commitments—US authori-
zations, $1.9 billion, including Ex-Im (FY70-
84); other Western bilateral (ODA and
OOF), $545.0 million (1970-79). military.
authorizations—US (FY70-84), $2.0 billion
Budget:{1984 central government) reve-
nues, $59 billion; expenditures, $70 billion;
deficit, $11 billion
Monetary conversion rate: 161.65 pesetas=
US $1 (October 1985). -
Fiscal year: calendar year','06911be422ff4a90b0754e354131688b9b1663e6833278c3d0234368f1c69bf2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b666b144d66ab7b8d843cce508bef69220bd7202847dddf0a1159f41d5e3041',1986,'LK','Sri Lanka','government',467,'Official name: Democratic Socialist Repub- -
lic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 24 ad-
ministrative districts
Legal''system: a highly complex mixture of .
English common law, Roman-Dutch, Mus-
lim, and customary law; new constitution 7
September 1978 reinstituted a strong, inde-
pendent judiciary; legal education at Sri
Lanka Law College and University of
Colombo; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 22
May —
Branches: the 1978 constitution established
a strong presidential form of government
under J. R. Jayewardene, who had been
Prime Minister since his party’s election vic-
tory in July 1977; Jayewardene was elected
to.a second term in October 1982 and will
serve until 1989 regardless of whether Par-
liament is dissolved; the current Parliament
was extended until August 1989 by a na-
tional referendum held in December 1982
Government ibaitex: Junius Richard
JAYEWARDENE, President (since 1978)
Suffrage: universal over age-18
Elections: national elections ordinarily held
every six years; must be held more
frequently if government loses confidence
vote; the constitution was amended in Au-
gust 1982 to permit the President to call an
early presidential election
"280
Political parties and leaders: Sri Lanka
Freedom Party (SLFP), Sirimavo Ratwatte
Dias Bandaranaike; Sri Lanka Mahajana
Party, Vijaya Kumaratunga; Lanka Sama
Samaja Party (LSSP; Trotskyite), C. R. de
Silva; Nava Sama Samaja Party (NSSP), V
Nanayakkara; Tamil United Liberation
Front, A. Amirthalingam; United National
Party (UNP), J. R. Jayewardene; Communist
Party /Moscow, K. P. Silva; Communist
Party /Peking, N. Shanmugathasan;
Mahajana Eksath Peramuna (People’s
United Front), M. B. Ratnayaka; Janatha
Vimukthi Peramuna (JVP; People’s Libera-
tion Front), Rohana Wijeweera; All-Ceylon
Tamil Congress, Kumar Ponnambalam
Voting strength: (October 1982 presidential
election) UNP 52.91%, SLFP 39.07%, JVP
4.18%, All Ceylon Tamil Congress 2.67%,
LSSP .9%, NSSP .27%
Communists: approximately 107,000 voted
’ for the Communist Party in the July 1977
general election; Communist Party /Moscow
approximately 5,000 members (1975), Com-
munist Party/Peking 1,000 members (1970
est.)
Other political or pressure groups: Tamil
separatist groups, Buddhist clergy, Sinhalese
Buddhist lay groups; far-left violent revolu-.
tionary groups; labor unions
Member of: ADB, ANRPC, Colombo Plan,
’ Commonwealth, ESCAP, FAO, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, IRC, ITU, NAM,
SAARC, UN, UNESCO, UPU, WFTU,
WHO, WIPO, WMO, WTO','035f0e99b5529f54d3985609a6587069d5153fa71a5009ab50f5995757c9fbff','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('292404ed6ff2dcbad8de65ef348a0d56659a85ec2379025a07de012c2fa80e67',1986,'SD','Sudan','government',471,'Official name: Republic of the Sudan
Type: republic under an interian military
regime since coup on 6 April 1985
Capital: Khartoum
Political subdivisions: 9 regions
Legal system: based on English common
law and Islamic law; in September 1983
President Nimeiri declared the penal code
would conform to Islamic law; some sepa-
rate religious courts; interim constitution
promulgated August 1985; legal education at
University of Khartoum and extension of
Cairo University at Khartoum; accepts com-
pulsory ICJ jurisdiction, with reservations
National holiday: 1 January, Independence
Day _
Branches: Transitional Military Council and
Provisional Civilian Cabinet; regional mili-
_ tary governors
Government leader: Gen. Abdel Rahman
SUWAR EL DAHAB, Chairman, Transi-
tional Military Council (since April 1985);
Dr. El Gizouli DAFALLA, Prime Minister
(since April 1985)
Suffrage: universal adult.
Elections: elections scheduled in April 1986
to select representation to a Constituent As-
sembly that will draft a new constitution in
one year and thereafter turn itself into a par-
liament to serve for three years
Political parties and leaders: following coup
in April 1985, more than 30 different politi-
cal parties declared; most significant include
the Umma Party (Ansar Muslim Sect), the
Democratic Unionist Party (Khatmiyyah
Muslim Sect), the rightist Islamic fundamen-
talist National Islamic Front (Muslim Broth-
ethood), the Sudanese Communist Party,
and the B’ath Party; major southern parties
include the Sudan African Congress and the
Southern Sudanese Political Association —
Member of: AfDB, APC, Arab League, .
FAO, G-77, IAEA, IBRD, ICAC, ICAO,
IDA, IDB—Islamic Development Bank,
IFAD, IFC, ILO, IMF; IMO, INTELSAT,
INTERPOL, ITU, NAM, OAU, OIC, UN,
UNESCO, UPU, WETU, WHO, WIPO,-
WMO, WTO','9a8ccd4981777d9f391b80db498e4c06bf75ddb25082336740a7461ecc2c1df7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a90f00e52a5201709493cc185c2cedd3f7215b595be2cad15d5844413f69c89',1986,'SR','Suriname','government',475,'Official name: Republic of Suriname
Type: military-civilian rule
Capital: Paramaribo
Political subdivisions: 9 districts, each
headed by District Commissioner responsi
ble to Minister of Internal Affairs and Local
Administration; 100 “People’s Committees”
installed at local level
Legal system: Suspended constitution; judi-
cial system functions in ordinary civil and
critninal. cases
National holiday: Independence Day, 25
November
Branches: civilian government controlled by
the military :
Government leaders: Lt. Col. Desire
BOUTERSE, Head of Government, Army
Commander and strongman (since February
1980); Lachmipersad Frederick RAMDAT-
MISIER, Acting President (figurehead; since
February 1982); Willem Alfred UDEN-
HOUT, Prime Minister (since February
1984)
Suffrage: suspended —
Elections: rione-planned —
Political parties and leaders: 25 February
National Unity Movement (Novemiber 1983)
233 -
established by Bouterse; regular party activ-
ity limited; given greater freedom of assem-
bly in 1985; leftists (all small groups)—Revo-
lutionary People’s Party (RVP), Michael
Naarendorp; Progressive Workers and
Farmers (PALU), Iwan Krolis
Member of: ECLA, FAO, GATT, G-77,
IBA, IBRD, ICAO, IDB—Inter-American
Development Bank, IFAD, ILO, IMF, IMO,
INTERPOL, ITU, NAM, OAS, PAHO,
SELA, UN; UNESCO, UPU, WHO, WIEO:
WMO
Official name: Kingdom of Swaziland
Type: monarchy; independent member of
Commonwealth since September 1968 *
Capital: Mbabane (administrative);
Lobamba (legislative capital)
Political subdivisions: 4 administrative dis-
tricts :
Legal system: based on South African
Roman-Dutch law in statutory courts, Swazi
traditional law and custom in traditional
courts; legal education at University of
Botswana and Swaziland; has not accepted «
compulsory ICJ jurisdiction
National holiday: Somhlolo Undependentee)
Day, 6 September
Branches: constitution was repealed and
Parliament dissolved by King Sobhuza II
(deceased August 1982)''in April 1973; new
bicameral Parliament (Senate, House ‘of As- -
sembly) formally opened in January 1979;
80-member electoral collegé chose 40:mem*
bers-of lower house and 10 members of up-:
per house; additional 10 members for each ©
house chosen by King; exécutive authority *
vested in the King or Quéen (with the advice
of the Supreme Council of State); whose as-
sent is required before parliamentary acts -
become law; King’s authority exercised
through Prime Minister and Cabinet who -
must be members of Parliament; judiciary is
part of Ministry of Justice but otherwise in-
dependent of executive and legislative
branches; cases from subordinate courts can
be appealed to the High Court and the
Court of Appeal
Government leaders: Head ‘of ‘State, Ntombi
THWALA, Queen Regent (since September
1983); Prince Bhekimpi DLAMINI, Prime: *
Minister (since March 1983) °°
Suffrage: universal for adults. .
Communists: no Communist party
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Member of: A{DB, FAO;-G-77, GATT (de
facto), IBRD, ICAO, IDA, IFAD, IFC, ILO,
IMF, INTERPOL, ISO, ITU, NAM, OAU,
SADCC, UN, UNESCO, UPU, WHO','9d8d4152c02bbdacb80d855fc4662acc248cb12a80816c3133d77160aa1d557c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c3ff06f2e7284481dcfb711e2f1c5b7729a97d5992d07c6521b8233e2e0c7b6',1986,'SE','Sweden','government',478,'Official name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 counties, 284 mu-
nicipalities (townships)
Legal system: civil law system influenced by
customary law; a new constitution was
adopted in 1975 replacing the Acts of 1809,
1866, and 1949; legal education at Universi-
ties of Lund, Stockholm, and Uppsala; ac-
cepts compulsory ICJ jurisdiction, with res-
ervations :
National holiday: no national holiday; ~
King’s birthday, 30 April, celebrated as such
by Swedish embassies
Branches: legislative authority rests with.
unicameral parliament (Riksdag); executive
power vested in Cabinet, responsible to par--
liament; Supreme Court, 6 superior courts,
108 lower courts ,
Government leaders: CARL XVI Gustaf,
King (since September 1973); Ingvar
CARLSSON, Prime Minister (since March
1986)
Suffrage: universal but not compulsory over
age 18; after three years of legal residence
immigrants may vote in county and munici-
pal but not national elections
Elections: every three years; next scheduled
for September 1988 _
Political parties and leaders: Moderate Coa-
lition (conservative), Ulf Adelsohn; Center,
Karen Séder; Liberal People’s Party, Bengt
Westerberg; Social Democratic, Ingvar
Carlsson; Left Party-Communist (VPK),
Lars Werner; Swedish Communist Party
(SKP), Roland Pettersson; Communist
Workers’ Party, Rolf Hagel
Voting strength: (1985 election) 45.0% So-
cial Democratic, 21.3% Moderate Coalition,
12.5% Center (includes votes for Christian
Democratic Alliance), 14.3% Liberal, 5.4%
Communist, 1.5% other
Communists: VPK and SKP; VPK, the ma-
jor Communist party, is reported to have
roughly 17,800 members; in the 1985 elec-
tion, the VPK attracted 293,548 votes; in
addition, there are 4 other active Commu-
nist parties, including the SKP, for which
membership figures are not available; in the
1985 elections, these parties obtained an
additional 16,000 votes
Member of: ADB, Council of Europe, DAC,
EC (Free Trade Agreement), EFTA, ESRO,
FAO, GATT, IAEA, IBRD, ICAC, ICAO,
ICES, ICO, IDA, [DB—Inter-American
Development Bank, IEA, IFAD, IFC, THO,
ILO, IMF, IMO, INTERPOL, INTELSAT,
Internationa] Lead and Zinc Study Group,
IPU, ISO, ITU, IWC—International Whal-
ing Commission, IWC— International
Wheat Council, Nordic Council, OECD,
UN, UNESCO, UPU, WHO, WIPO, WMO,
WSG ,','67b2229e935e7850ded73993277106de883f27a6650a57f2d707a9fa6b6fdbd4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f3207e215dbfc4681655fcdec00fa840cc48921436051cdee224a0f4f4504df',1986,'CH','Switzerland','government',482,'Official name: Swiss Confederation
Type: federal fepublie
Capital: Bern
Political subdivisions: 23 cantons (3 divided
into half cantons)
Legal system: civil law system influenced by
customary law; constitution adopted 1874, -
amended since; judicial review of legislative
acts, except with respect to federal decrees
of general obligatory character; legal educa-
tion at Universities of Bern, Geneva, and
Lausanne and four other university schools
of law; accepts compulsory IC] jurisdiction,
with reservations
National holiday: National Day, 1 August
Branches: bicainera] parliament (National,
Council, Council of States) has legislative
authority; federal council (Bundesrat) has
executive authority; justice left chiefly to
cantons
Government leader: Alfons EGLI, President
(1986; presidency rotates annually)
Suffrage: universal over age 20
Elections: held every four years; next elec-
tions scheduled for 1987
Political parties and leaders: Social Demo-
cratic Party (SPS), Helmuth Hubacher,
chairman; Radical Democratic Party (FDP),
Bruno Hunziker, president; Christian Dem-
ocratic People’s Party (CVP), Flavio Cotti,
president; Swiss People’s Party (SVP), Adolf
Ogi, president; Workers’ Party (PdA),
Armand Magnin, secretary general; Nation-
al Action Party (NA), Rodolf Keller, presi-
dent; Independents’ Party (LdU), Walter
Biel, president; Republican Movement
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Switzerland (continued)
(Rep); Liberal Party (LPS); Gilbert Coutau,
president; Evangelical People’s Party (EVP),
Paul Gysel, president; Progressive Organiza-
tions of Switzerland (POCH); Green Party |
(GP); Autonomous Socialist Party (PSA),
Werner Carobbio, secretary; Progressive
Swiss Organization (POS), Georg Degen,
secretary ©
Voting strength: (1983 election) 23.4% FDP,
22.8% SPS, 20.5% CVP, 11.1% SVP, 3. 5%
es 2. 9% GP, 16.1% others °
Communists: about 5,000 sntnibers
Member of: ADB, Council of Europe, DAC,
EFTA, ELDO (observer), ESRO, FAO, ~
GATT, IAEA, ICAC, ICAO, ICO, IDB—
Inter-American Development Bank, IEA,
IFAD, ILO, IMO, INTELSAT,
INTERPOL, IPU, ITU, IWC—Interna-
tional Wheat Council, OECD, UNESCO, -
UPU, World Confederation of Labor,
WFTU, WHO, WIPO, WMO, WSG, WTO;
permanent observer status at the UN ~~
Official name: Syrian, Arab Republic.
Type: republic; under leftwing military re
gime since ‘March 1963
Capital: Damascus
Political subdivisions: 13 provinces ana city,
of Damascus administered as separate unit
Legal system: based on Islamic law and civil
law system; special religious courts; constitu-
tion promulgated in 1973; legal education at
Damascus University and University of
Aleppo; has not accepted compulsory IC] _
jurisdiction
National nena: Independence Day,.17 .
April
Branches: executive powers vested in Presi-
dent and Council of Ministers; power rests in
unicameral legislative (People’s Council);
seat of power is the Ba‘th Party Regional
(Syrian) Command
Government leader: Lt. Gen. Hafiz
al-ASSAD, President (since February 1971)
Suffrage: universal at age 18 .
Elections: People’ s Council election held -
November 1983; presidential. election held |
February 1985
Political parties and leaders: ruling party is
the Arab Socialist Resurrectionist (Ba''‘th)
Party; the Progressive National Front is
dominated by Ba’ thists but includes inde-
pendents and members of the Syrian Arab
Socialist Party (ASP), Arab Socialist Union
(ASU), Socialist Unionist Movement, and .
Syrian Communist Party (SCP)
239
Communists: mostly sympathizers, num-
bering about 5,000
Other political c or pressure groups: non-
Bath parties have little effective political
influence; Communist Party ineffective; :
greatest threat to Assad regime lies infac- _ .
tionalism in the military; conservative reli-
gious leaders; Muslim Brotherhood ,
Member of: Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO, IMF,
IMO; INTELSAT, INTERPOL, IOOC,
IPU, ITU, !WC—International Wheat
Council, NAM, OAPEC, OIC, UN,
UNESCO, UPU, WFTU, WHO, WMO,
WSG, WTO .
Official name: United Republic of Tanzania
Type: republic; single party constitutionally
supreme on the mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 25 regions—20 on
mainland, 5 on Zanzibar
Legal system: based on English common
law; permanent constitution adopted 1977,
replaced interim constitution adopted 1965; -
Zanzibar has its own constitution but re-
mains subject to provisions of the union con-
stitution; judicial review of legislative acts
limited to matters of interpretation; legal
education at University of Dar es Salaam;
has not accepted compulsory IC] jurisdic-
tion oni
National holiday: Union Day, 26 April; In-
dependence Day, 9 December
Branches: President Ali Hassan Mwinyi has
full executive authority on the mainland;
National Assembly dominated by the
Chama Cha Mapinduzi (Revolutionary
Party); National Assembly consists of 233
members, 72 from Zanzibar, of whom 10 are
directly elected, 65 appointed from the
mainland, and 96 directly elected from the
mainland (these numbers are slated to be
changed when amendments to the Constitu-
tion are approved)
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Government leaders: Ali Hassan MWINYL,
President (since November 1985); Joseph
Sinde WARIOBA, Prime Minister (since
November 1985)
Suffrage: universal adult over age 18
Political party and leader: Chama Cha
Mapinduzi (Revolutionary Party), only polit-
ical party, dominated by Nyerere; has con-
siderable power over domestic policies and
the enforcement of them
Voting strength: (October 1980 national
elections) close to 7 million registered voters;
Nyerere received 93% of about 6 million
votes cast; general elections scheduled for
late 1985
Communists: a few Communist sympathiz-
ers, especially on Zanzibar
Member of: ALDB, Commonwealth, FAO,
G-77, GATT, IAEA, IBRD, ICAG, ICAO,
ICO, IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, ITU, NAM,
OAU, SADCC, UN, UNESCO, UPU, WHO,
WMO, WTO','b8fa70cac1d76d3d12ae16be0bc8144cb767573ba590f6d915df65cc4a72d67b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('879ca9b1dbde5ca984747f8930cc947e342a95872dd595baff5a1d5ae7727261',1986,'TH','Thailand','government',486,'Official name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 72 centrally
controlled provinces. -
Legal system: based on civil law system,
with influences of. common law; legal educa-
tion at’ Thammasat University; has not ac- ,
cepted compulsory ICJ jurisdiction
National holiday: King’s Birthday, 5De- .
cember ..: .. .
Branches: King is head of state with nominal
powers; bicameral legislature (National As-
sembly—Senate appointed by King, elected -
House of Representatives); judiciary rela-
tively independent except in important po-
litical subversive cases,
Government leaders: BHUMIBOL
ADULYADE]J, King (since June 1946); Gen. -
(Ret.) PREM TINSULANONDA, Prime
Minister (since March 1980)
Suffrage: universal at age 20.
Elections: last held April 1988 .
Political parties: Social Action Party, Thai
Nation.Party, Thai People’s Party, Thai Citi-
zen Party,. Democrat Party, F reedom and .
Justice Party, Nation and People Party, New
Force Party, National Democracy Party;
other small parties represented in parlia-
ment 3 ;
Communists: strength of illegal Communist:
Party is probably: less than 1,000; Commu-
nist insurgents throughout Thailand total an
estimated 1,000.
Member of: ADB, ANRPC, ASEAN,
ASPAC, Association of Tin Producing Coun-
tries, Colombo Plan, GATT, ESCAP, FAO,
G-77, [AEA, IBRD, ICAO, IDA, IFAD, IFC,
THO, ILO, IMF, IMO, INTELSAT,
'' 242
INTERPOL, IPU, IRC, ITC, ITU, UN,
UNESCO, UPU, WHO, WMO, WTO
Official name: Republic of Togo
Type: republic; one-party presidential re-
gime with a centralized national administra-
tion
Capital: Lomé
Political subdivisions: 21 prelcetites
Legal : soon French-based court system
with a court of appeals
National holiday: Independence Day, 27
April
praneies strong executive President; uni-
cameral legislature (National Assembly); .
separate judiciary, including State Security
Court, established in 1970; a new constitu-
tion was endorsed by referendum in 1979
that provided for an elective presidential _
system and a 67-member National Assembly
Government leader: Gen. Gnassingbé —
EYADEMA, President (since 1967)
Suffrage: universal adult
Elections: to be held every seven years; last
held in December 1979; General Eyadéma,
the sole candidate, was elected by almost
100% of votes cast
Political party: single party formed by Presi-
dent Eyadéma in September 1969, Rally of
the Togolese People (RPT); structure and
staffing of party closely controlled by gov-
ernment
Communists: no Communist Party; possibly
some sympathizers
Member of: ADB, CEAO (observer),
EAMA, ECA, ECOWAS, ENTENTE, FAO,
G-77, GATT, IBRD, ICAO, ICO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
ITU, NAM, OAU, OCAM, UN, UNESCO,
UPU, WHO, WIPO, WMO, WTO ©
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Togo (continued)','18445ba3bd37cedf5def8ab8c788d24685ac352bf842841b4eb8a4bae40f3340','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d2a958c5656f4b1f34f09e2fdfc444df1f85d8eb6ccaf5b36f416b6ea2cf0e4',1986,'TK','Tokelau','government',490,'Official name: Tokelau
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 .
Type: New Zealand Associated Territory;
Tokelauans are British subjects and New
Zealand citizens; administered under the.
Tokelau Islands Act of 1948 as amended in
1970
Capital: no capital—each atoll has its own
administrative center
Branches: the Minister of Foreign Affairs of
New Zealand is empowered to appoint an
Administrator to the region; the powers of
the Administrator are delegated to the Offi-
cial Secretary at the Office of Tokelau Af-
fairs, Apia, Western Somoa ;
Political subdivisions: each village has a
Council of Elders (Taupulega) made up of
heads of family groups together with the
commissioner (faipule) and the mayor
(pulenuku); the commissioner administers .
the law and presides over the court -
Legal system: British and local statutes
National holiday: 6 February (Waitangi
Day)
Government leaders: H. H. FRANCIS, Ad-
ministrator (since February 1985); A. H.
MACEY, Official Secretary, Office of
Tokelau Affairs (since February 1985)
Suffrage: universal adult
Elections: elections for a commissioner and
a mayor from each atoll held at three-year
intervals
Communists: probably none','ccdb07702b9548122317a1c17e9fbe3fa6be15146c880ae16a8f06988aeac9be','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4351969bead1fa9b06aff443606462bb1d48cb7ac667000c790c790b6af5790e',1986,'TO','Tonga','government',494,'Official name: Kingdom of Tonga ;
Type: castitauanal monarchy withinthe
Commonwealth,
Capital: Nuku''alofa, on Tongatapu Island.
Political subdivisions: three main island .
groups (Tongatapi, Ha’ apai, Vava ‘u) ;
Legal system: based o on Enelsh law
Branches: Hace ais Cabinet and
Privy Council; unicameral legislature—Leg-
islative Assembly composed of seven nobles
elected by their peers, seven elected repre-
sentatives of the people, eight Ministers of
the Crown; the King appoints one of the’
seven nobles to be the speaker; judiciary—
Supreme Court, Magistrate’ s Court, Land
Court
Government leaders: Taufa’ahau TUPOU
IV, King (since December 1965); Prince
Fatafehi TU IPELEHAKE), Premier (since
December 1965)
Suffrage: all literate, tax-paying males and
all literate females over 21
Elections: supposed to be held every three
years; last held in April 1978 -
Communists: none known
Member of: ADB, Commonwealth, FAO,
ESCAP,.GATT (de facto), IFAD, ITU, South
Pacific Bureau for Economic Cooperation,
SPF, UNESCO, UPU, WHO','18ee44f360ed3886f9f9cf196855d663c3041f570f2074d7b294fe12c029ffde','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('065b9e6f630288041a0c2ce0dea91aceeb0026a0cbd95c358cb2676290312d81',1986,'TT','Trinidad and Tobago','government',497,'Official name: Republic of Trinidad and
Tobago
Type: parliamentary democracy
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards,
Tobago is 30th)
Legal system: based on English common
law; constitution came into effect 1976; judi-
cial review of legislative acts in the Supreme
Court; has not accepted compulsory IC] |
jurisdiction
National holiday: Independence Day, 81
August
Branches: bicameral legislature (36-member’
elected House of Representatives and 31-
member appointed Senate); executive is:
Cabinet led by the Prime Minister; judiciary
is headed by the Chief Justice and includes a
Court of Appeal, eet Court, and lower,
courts ; ;
Government leaders: George Michael
CHAMBERS, Prime Minister (since 1981);
Ellis Emmanuel Innocent CLARKE, Presi-
dent (since 1976)
Suffrage: universal over age 18
Elections: elections to be held at intervals of
not more than five years; last election held 9.
November 1981
Political parties and leaders: People’s Na: ‘
tional Movement (PNM), George Chambers; ’
United Labor Front (ULF), Basdeo Panday;
Organization for National Reconstruction :
(ONR), Karl Hudson-Phillips; Democratic
Action Congress (DAC), Arthur Napoleon
Raymond Robinson; Tapia House Move-
ment, Michael Harris
Voting strength: (1981 election) 55% at reg-
istered voters cast ballots; House of Repre-
sentatives—PNM, 26 seats; ULF, 8; DAC,
the 2 Tobago seats
Communists: People’s Popular Movement “
(PPM), Michael Als; February 18 Movement
(F/18), James Millette; Workers’ Revolution:
ary Committee (WRC), John Poon’ ;
Other political pressure groups: National ©
Joint Action Committee (NJAC), radical
antigovernment black-identity organization:
Trinidad and Tobago Peace Council, leftist’ ,
organization affiliated with the World Peace
Council; Trinidad and Tobago Chamber of |
Industry and Commerce; Trinidad and To: ::
bago Labor Congress, moderate labor feder-
ation; Council of Progressive Trade Unions,
radical labor federation ‘
Member of: CARICOM, Commonwealth,
FAO, G-77, GATT, IADB, IBRD, Interna-
tional Coffee Agreement, ICAO, ICO, IDA,
IDB—Inter-American Development Bank,”
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ISO, ITU, [''WC—Interna-
tional Wheat Council, NAM, OAS, PAHO,’
SELA, UN, UNESCO, UPU, WFTU, WHO,
WMO, WTO','dab184d304f7421479dedaad41deb4ce6724abbeb722c53cfc67f20ce1245b5e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a05839f5020b95a59dbbd87a9f715d59f684cad8deb9da25080f5dd9752082ed',1986,'TN','Tunisia','government',501,'Official name: Republic of. Tunisia.
Type: republic
Capital: Tunis
Political subdivisions: 18 governorates
(provinces)
Legal system: based on French civil law
system and Islamic law; constitution pat-.
terned on Turkish and US constitutions
adopted 1959; some’judicial review. of legis- :
lative acts in the Supreme Court in joint ses-
sion; legal education at Institute of Higher
Studies and Superior School of Law of the
University of Tanis
National holiday: Independence Day, L
June
Branches: executive dominant; unicameral -
legislative (National Assembly) largely advi-_
sory; judicial, patterned on French and Ko- |
ranic systems
Government leaders: Habib BOURGUIBA,
President (Prime Minister in 1956; President
since 1957; President for Life since Novem-
ber 1974); Mohamed MZALL Prime Minis- -
ter (since April 1980)
Suffrage: universal over age 21 -
Electionss: national election held every five
years; last election held 1 November 1981
Political parties and leaders: Destourian
Socialist Party is official ruling party; two
small parties—Movement of Social Demo- .
crats and Movement of Popular Unity—
legalized in 1983; Communist Party legal- ,
ized in 1981
248
Voting strength: (1981 election) over 95%
Destourian Socialist Party; 3.2% Social Dem-
ocrats, under 1% Movement of Popular
Unity: under | 1% Communist Party
Conmnintsie: a sinall ee of dein
Communists, mostly students
Member of: AfDB, Arab League, AIOEC,
FAO, G-77, GATT (de facto), IAEA, IBRD, °:
ICAO, IDA, IDB—Islamic Development __.
Bank, IFAD, IFC, ILO, International Lead +
and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IOOC,ITU, _.
{WC—International Wheat Council, NAM,
OAPEC; OAU, OIC, Regional Cooperation.
for Developrnent, UN, UNESCO, UPU,. -
WHO, WIPO, WMO, WTO
Economy ee
GNP: $9.3 billion (1985 est.), $1,280 per cap-
ita (1985); 57% private consumption, 16%
government consumption, 29% gross fixed -
capital formation; average annual real:
growth (1980-83), 4%
Natural resources: oil, Enosetates iron, ore,
lead, zinc
Agriculture: main crops—cereals (barley
and wheat), olives, grapes, citrus fruits, and
vegetables
Major sectors: agriculture; industry—min-
ing (phosphate), energy (petroleum, natural
gas), manufacturing (food processing and
textiles), services (transport, telecommunica-
tions, tourism, government)
Electric power: 1,070,300 kW capacity
(1985); 3.75 billion kWh produced (1985),
510kWh per capita
Exports: $1.8 billion (f.0.b., 1985); 40%
crude petroleum, 21% textiles, 21% phos- ~.":
phates and chemicals, 18% other
Imports: $2.9 billion (F.0.b., 1985)
Major trade partners: France, Italy, FRG,','ed919b592c6b28b0b1c2454b17cf1d76795779e6add1ec4edaf27e29995c3b45','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1015560132583a83d0c6c13a0b188965d22ab7651e336e84247b3e1d9b2271cf',1986,'TC','Turks and Caicos Islands','government',505,'Official name: Turks and Caicos Islands
Type: British dependent territory; constitu-
tion introduced in 1976
coinition mawe a eae
ves
Capital Grand Turk (Cookin Town)
Political abuniibne Sdiiist
Legal system: probably based o on een
National holiday Cul Day, 31°
May ies es
Branches: executive, bicameral legislature
(Executive Council, 14-member Legislative
Council); judicial (Supreme Court) ~. <°!
Government leader: Nathaniel FRAN CIS,
Chief Minister (since March 1985); Chris-**
topher J: TURNER, Governor (since 1982)''-
Suirage: univetal adult at age 18- 4
Bieétione: last 1984 for ll Lesislatve Coun-
cil seats ge, Oe .
Political parties and leaders: Péople’s Demn-
ocfatic Movement (PMD), Oswald cela
pings; Progressive National Party(PNP), °
Nathaniel Francis
Voting strength: PDM, 8 seats; PNP; 8 seats:
Communist: none known *','419cf662efe3e23d6d6ddee646143c20300a61b0519147dca9e296e2d1e67874','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0632599bc64fe9df14f778fd68a0cc956cadb3c30e2a7b630436969e67f82de0',1986,'TV','Tuvalu','government',509,'Official name: Tuvalu
Type: independent state with special
“membership” in the Commonwealth, rec-
ognizing Elizabeth II as head of state
Capital: Funafuti
Political subdivisions: 8 island councils on
the permanently inhabited islands
Branches: executive—Prime Minister and
Cabinet; unicameral legislature—
12-member House of Parliament judicial—
High Court, 8 island courts with limited jur-
isdication
Government leaders: Dr. Tomasi PUAPUA,
Prime Minister (since September 1981); Sir
Fiatau Penitala TEO, Governor General
(since October 1978) ~
Elections: last general election September
1985, next scheduled for September 1989
Political parties: none
Member of: ESCAP (associate member),
GATT (de facto), SPF, SPC, UPU','bd7825277cba27a23438d5382c7b3eebf9fd5d0647fe1d0fdcb09d0922dc580e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8a175035a3211540bdb4f0666a1d8fcbdce84e35fee08d91c4e1d7d35b814d2',1986,'UG','Uganda','government',513,'Official name: Republic of Uganda
Type: republic
Capital: Kampala
Political subdivisions: 10 provinces and 34
districts
Legal system: government plans to restore
system based on English common law and
customary law to reinstitute a normal judi-
cial system; legal education at Makerere
University, Kampala; accepts compulsory
ICJ jurisdiction, with reservations
National holiday: Independence Day, 9 Oc-
tober
Branches: present government, which as-
sumed power in January 1986, consists of a
National Resistance Council headed by the
President; the constitution has been
suspended and the unicameral legislature
(National Assembly) has been dissolved
Government leader: Yoweri Kaguta
MUSEVENI, Head of State and Chairman
of the National Resistance Council (since
January 1986) ‘
Suffrage: universal adult
Elections: none scheduled
Political parties: Uganda Patriotic Move-
ment (UPM), Ugandan People’s Congress
(UPC), Democratic Party (DP), Conserva-
tion Party (CP) tes
Voting strength: (December 1980 election)
National Assembly UPC, 74; DP, 51; other; 1
Other political parties or pressure groups:
Uganda National Liberation Army (UNLA),
Uganda Freedom Movement (UFM), Fed-
eral Democratic Movement of Uganda
(FEDEMU), Uganda National Rescue Front
(UNRF)
Communists: possibly a few sympathizers
Member of: ADB, Commonwealth, FAO,
G-77, GATT, IAEA, IBRD, ICAC, ICAQ,:
253
ICO, IDA, [DB—Islamic Development
Bank, IFAD, IFC, ILO, IMF, INTELSAT,
INTERPOL, ISO, ITU, NAM, OAU, OIC,
UN, UNESCO, UPU, WHO, WIPO, WMO,
WTO
Official name: United Arab Emirates (com-
posed of former Trucial States)
Member states: ‘Abu Dhabi, “Ajman,
Dubayy, Al Fujayrah, Ra’s al Khaymah, Ash
Sharigah, Umm al Qaywayn
Type: federation; constitution signed De-
cember 1971, which delegated specified
powers to the UAE central government and
reserved other powers to member
shaykhdoms |
Capital: Abu Dhabi
Legal system: secular codes are being intro-
duced by the UAE Government and in sev- |
eral member shaykhdoms; Islamic law re-
mains influential
National holiday: 2 December
Branches: executive—Supreme Council of.
Rulers (seven members), from which a Presi-
dent and Vice President are elected; Prime
Minister and Council of Ministers; unicam-
eral legislature—Federal National Council;
judicial—Union Supreme Court
Government leaders: Shaykh Zayid bin Sul-
tan Al NUHAYYAN of Abu Dhabi, Presi-
dent (since ] December’ 1971); Shaykh Rashid
ibn Sa‘id Al MAKTUM of Dubavy, Vice
President (since 1971) and Prime Minister
(since April 1979) ..
Suffrage: none
Elections: none
Political or pressure groups: none; a few
smal] clandestine groups ‘are active
Member of: Arab Léague, FAO, G-77,
GATT (de facto), GCC, IAEA, IBRD, ICAO,
IDA, IDB—Islamic Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
Declassified and Approved For Release 2012/08/29 - CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 - CIA-RDP08-00534R000100170001-4
INTERPOL, ITU, NAM, OAPEC, OIC,
OPEC, UN, UNESCO, UPU, WHO, WIPO,
WTO','b674a5148772b736ceb0ce7b77c648663cc2afe74b6736985a71b5b1ada7dd41','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a859bd96ae7332039f7c16d75e9488766ff44e0cc28e1f9ddd5da025ed38a677',1986,'GB','United Kingdom','government',517,'Official name: United Kingdom of Great
Britain and Northern Ireland
Type: constitutional monarchy’
Capital: London
Political subdivisions: 54 counties in Eng-
land and Wales, 12 regions in Scotland and
islands area, 26 districts in Northern Ireland
Legal system: common law tradition with
early Roman and modern continental influ-
ences; no judicial review of Acts of Parlia-
"ment; accepts compulsory ICJ jurisdiction,
with reservations ,
National holiday: Birthday of the Queen, 16
June
Branches: legislative authority resides in
Parliament (House of Lords, House of Com-
mons); executive authority lies with collec-
tively responsible Cabinet led by Prime
Minister; House of Lords is supreme judicial
authority and highest court of appeal
Government leader: ELIZABETH IL,
Queen (since 1952); Margaret THATCHER,
Prime Minister (since 1979)
Suffrage: universal over age. 18
Elections: at.discretion of Prime Minister
but must be held before expiration of a five-
year electoral mandate; last election held 9
June 1983.
Political parties and leaders: Conservative,
Margaret Thatcher; Labor, Neil Kinnock;
Social Democratic, David Owen; Commu-
hist, Gordon McLennan; Scottish National,
Donald Stewart; Plaid Cymru, Dafydd
Wigley; Official Unionist, James Molyneaux;
Democratic Unionist, Ian Paisley; Social
Democratic and Labor, John Hume; Provi-
sional Sinn Fein, Gerry Adams; Alliance,
John Cushnahan; Liberal, David Steel
Voting strength: (1983 election) House of
Commons—Conservative, 394 seats (42.4%);
Labor, 210 seats (27.6%); Social Democratic-
Liberal Alliance, 23 seats (18 Liberal, 7 SDP)
(25.4%); Scottish National Party, 2 seats;
Plaid Cymru (Welsh Nationalist), 2 seats;
Ulster (Official) Unionist (Northern Ireland),
10 seats; Ulster Democratic Unionist (North-
ern Ireland), 3 seats, Ulster Popular Unionist
(Northern Ireland), 2 seats; Social Demo-
cratic and Labor (Northern Ireland), ] seat;
Sinn Fein (Northern Ireland), 1 seat
Communists: 15,961
Other political or pressure groups: Trades
Union Congress, Confederation of British
Industry, Nationa] Farmers’ Union, Cam-
paign for Nuclear Disarmament:
Member of: ADB, CENTO, C Colombo Plan,
Council of Europe, DAC, EC, ELDO,,.
ESCAP, ESRO, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, ICES, ICO, IDA, IDB—Inter-
American Development Bank, IEA, IFAD,
IFC, IHO, ILO, International Lead and |...
Zinc Study Group, IMF, IMO, INTELSAT,
INTERPOL, IOOC, IPU, IRC, ISO, ITC, .
ITU, IWC—International Whaling Com--
mission, IWC—International: Wheat Coun- ..
cil, NATO, OECD, UN, UPU, WEU, WHO,
WIPO, WMO, WSG
Official name: United States of America
Type: federal republic; strong democratic
tradition :
Capital: Washington, D. C.
Political subdivisions: 50 states and the Dis-
trict of Columbia; dependencies includé
Commonwealth of Puerto Rico, Guam, Vir-
gin Islands, American Samoa, Wake and .
Midway Islands, Johnston Atoll, and King-
man Reef; under UN trusteeship Caroline,
Marshall, and Northern Mariana Islands
Legal system: based on English common
law; dual system of courts, state and federal;
constitution adopted 1789; judicial review of
legislative acts; accepts compulsory IC] juris- -
diction, with reservations ;
National holiday: Independence Day, 4 July
Branches: executive (President), bicameral
legislature (House of Representatives and
Senate), and judicial (Supreme Court); °
branches, in principle, independent and
maintain Dalene of power
Declassified and Approved For Release 2012/08/29 - CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
United States (continued)
Government leaders: Ronald REAGAN,
President (since January 1981); George
BUSH, Vice President (since January 1981) ¢
Suffrage: all citizens over age 18; not com-
pulsory
Elections: presidential, every four years
(next November 1988); all members of the
House of Representatives, every two years;
one-third of members of the Senate, every |
two years
Political parties and leaders: Republican
Party, Frank J. Fahrenkopf, Jr., national
chairman, Democratic Party, Paul G. Kirk, | :
Jr., national committee chairman; several
others groups or parties of minor political
significance
Voting strength: 40% voter participation
(1982, congressional election); 53.3% voter
participation (1984 presidential election);
Republican Party (Ronald Reagan), 59% of
the popular vote (525 electoral votes); Demo-
cratic Party (Walter Mondale), 41 % (18 elec-
toral votes)
Communists: Communist Party (claimed
15,000- 20, 000 members), Gus Hall, general
secretary; Socialist Workers Party (claimed |
1,800 members); Jack Barnes, national secre-
tary (1983)
Member of: ADB, ANZUS, Bank of Interna-
tional Settlements, CCC, CENTO, Colombo
Plan, DAC, FAO, ESCAP. GATT, Group of
Ten, IADB, IAEA, IBRD, ICAC, ICAO,
ICEM, ICES, ICO; IDA, IDB—Inter-
American Development Bank, IEA, IFAD,
IFC, IHO, ILO, International Lead and
Zinc Study Group, IMF, IMO, INTELSAT,
INTERPOL, IPU, IRC, ITC, ITU; Two
International Whaling Commission, Iwc—
International Wheat Council, NATO, OAS,
OECD, PAHO, SPC, UN, UPU, WHO, |
WIPO, WMO, WSG, WTO.
Econoniy
GNP: $3,662.8 billion (1984 est.); $2,186.5
billion (65%) personal consumption, $501.0
billion (14. 9%) private investment, $701.8
billion (20.9%) government, — $25. 9 billion _
(—.07%) net exports; $11,338 per capita;,
annual growth rate 6.8% (1984)
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, baux- |
ite, gold, iron, mercury, nickel, potash, sil-
ver, tungsten, zinc
Agriculture: food grains. feed crops, oilbear-
ing crops, cattle, dairy products
Fishing: catch 4,143 thousand metric tons
(1983); 13.0 lb per capita consumption
(1981); imports $4.173 billion (1981); exports
$1.156 billion, (1981); est. value, $2.388 bil-
lion (1981)
Crude steel: 83.9 million metric tons pro-
duced (1984)
Natural gas: 18.5 trillion cubic feet pro-
duced (1984) :
Electric power: (public utilities only)
705,961,000 kW capacity (1985); 2,679.857
billion (net) kWh produced (1985), 11 220.
kWh per capita pan ,
Exports: $17,034.2 million (f.0.b., 1985);
machinery, chemicals, transport equipment,
agricultural products
Imports: $31,349.1 million (c.i.f., 1985);
crude and partly refined petroleum, ma-
chinery, transport equipment (mainly new
automobiles) a
Major trade partners: exports—$4,030 mil- ;
lion Canada, $1,925.7 million Japan,
$1,015.7 million Mexico, $842.8 million UK,
$651.4 million FRG (1985); imports— °_
$6,153.8 million Canada, $6,451.8 million
Japan, $1,479. 4 million Mexico, $1,300.1
million UK, $1,807.5 million FRG (1985)
Aid: obligations and loan authorizations, ;
including Ex-Im (F Y82), economic $11.2
billion, military (FY82) $4.2 billion _
Budget: (1985) receipts, $763.768 billion;
outlays, $930. 635 billion; deficit, $123. 3 bil-
lion
F iscal year: 1 October-30 September
Communications ey
Railroads: 270, 312 km
258.
Highways: 6,365,590 km, including 88,641
_ km expressways
Inland waterways: est. 41,009 km of naviga-
ble inland channels, -exclusive of the Cicat
Lakes -
Freight carried: rail—1,637.0 million metric
tons, 1,345.6 billion metric ton/km (1984);
highways—987.53 billion metric ton/km
(1984); inland water freight (excluding Great
Lakes traffic)—582.81 million metric tons,
358.29 billion metric ton/km (1984); air—
11,495 million metric ton/km (1984)
Pipelines: petroleum, 883.3 billion metric
ton/km, 1,049.6 million metric tons carried
(1984)
Ports: 44 handling 10.9 million metric tons
or more per year
Civil air: 2,960 commercial multiengine
transport aircraft, including 2,724 jet, 185
turboprop, 51 piston (1984)
Airfields: 15,422 in operation (1981)
Telecommunications: 182,558,000 tele-
phones (791 telephones per 1,000 popl.);
4,892 AM, 3,915 FM,.1,285 noncommercial
FM stations (10,092 total); 796 commercial, ..
300 noncommercial (public broadcasting),
6,200 commercial cable TV broadcast sta-
tions (7,296 total); 495 million radio and 150
million-TV receivers (1982)
Defense Forces
Branches: Department of the Army, De-
partment of the Navy (including Marine
Corps), US Coast Guard, Department of the
Air Force
Military manpower; 2,135,900 total;
780,800, army; 594,500, air force; 564,800,
navy; 196,600, marines (1984)
Military budget: $266.151 billion (1984
prop.); 29.1% of central government budget
(planned, 1985)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 . .','23493fa1e4987969e1a9b8b87a2af0e1e89af46bdbfc9e040085178f29b0fc36','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f30e520c8fa66c050f67171f58173ca91c126e722fdce1026d32b83a0008bad',1986,'UY','Uruguay','government',519,'128km "|
Boundary representation is
f Atlantic —
Flo Xe Ocean
de la
Plata
See regional map IV -
Land
176,215 km?; the size of Washington (state);
84% agricultural (73% pasture, 11% crop);
16% forest, urban, waste, and other
Land boundaries: 1,352 km
Water
Limits of territorial waters (claimed): 200
nm
Coastline: 660 km |
Official name: Oriental Republic of Uru-
guay —
Type: republic
Capital: Montevideo
Political subdivisions: 19 departments with
limited autonomy
Legal system: based on Spanish civil law
system; most recent constitution
implemented 1967; legal education at Uni-
versity of the Republic in Montevideo; ac-
cepts compulsory ICJ jurisdiction °
National holiday: Independence Day, 25
August
Branches: executive, headed by President;
bicameral National Congress (Senate and
House of Deputies); national judiciary -
headed by Court of J ustice ;
Government leaders: JulioM. SANGUE .
NETTI, President (since March 1985);
Enrique E. TARIGO, Vice President (since
March 1985) — oo
Suffrage: universal over age 18
Elections: last November 1984; elections
held every five years
Political parties and leaders: National
(Blanco) Party, Wilson Ferreira; Broad.
Front Coalition, Liber Seregni; Colorado -
: Party, Julio Sanguinetti, Enrique Tarigo,
Jorge Pacheco Areco; Communist Party (le- ,
galized in March 1985), Rodney Arismendi;
Civic Union, Humberto Ciganda; Radical ~ _
Christian Union, leader unknown
259
Voting strength: (1984 elections) 41% Colo-
rado, 34.9% Blanco, 21.7% Broad Front,
2.4% Civic Union, 0.5% Radical Christian
Union
Communists: 15,000-18,000 -
Other political or pressure groups: National -
Liberation Movement (MLN)}—Tupamaros,
leftist revolutionary terrorist group, granted
amnesty in 1985 : oO
Member of: FAO, G-77, GATT, IADB, |.
IAEA, IBRD, ICAO, [DB—Inter-American
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IRC, ITU,
LAIA, OAS, PAHO, SELA, UN, UNESCO, ‘
UPU, WHO, WIPO, WMO, WsG :','c5ba88624e45dbcd8b2cbb64ab0c5a813f0b6b4ebbcb700ab699898271477fe5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc672b08e1dc1f1c659fd885df60a5a17ee5d97bb1c278b80f4fa9af253d2d8e',1986,'VU','Vanuatu','government',525,'Official name: Republic of Vanuatu
Type: republic, formerly Anglo-French con-
dominium of New Hebrides, independent
30 July 1980 =.
Capital: Port-Vila
Political subdivisions: four administrative
districts
Legal system: unified system being created
from former dual French and British sys-
tems ;
Branch: unicameral legislature (89-member
Parliament), elected November 1983
Government leader: Father Walter Hadye
LINI, Prime Minister (since 1980)
Political parties and leaders: National Party
(Vanuaaku Pati), Walter Lini, chairman
Member of: ADB, Commonwealth, ESCAP,
FAO, G-77, IBRD, ICAO, IDA, IFC, IMF,
ITU, NAM, SPF, UN, WHO, WMO
Official name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes
St. Peter’s, the Vatican Palace and Museum,
and neighboring buildings covering more
than 100 acres; 13 buildings in Rome and
261
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Castel Gandolfo, the Pope’s summer resi-
dence, although outside the boundaries, en-
joy extraterritorial rights
Legal system: Canon laws of 1929 serve
some of the functions of a constitution
National holiday: 30 June
Branches: the Pope possesses full executive,
legislative, and judicial powers; he delegates
these powers to the President of the Pontif-
ical Commission, who is subject to pontifical
appointment and recall; the administrative
structure of the Roman Catholic Church is
known as the Roman Curia; its most impor-
tant temporal components include the Sec-
retariat of State and Council for Public Af-
fairs (which handles Vatican diplomacy) and
the Prefecture of Economie Affairs; the Col-
lege of Cardinals act as chief papal advisers
Government leader: JOHN PAUL I, Su-
preme Pontiff (Karol WOJTYLA, elected
Pope 16 October 1978)
Suffrage: limited to cardinals less than 80
years old
Elections: Supreme Pontiff elected for life
by College of Cardinals
Communists: none known
Other political or pressure groups: none
(exclusive of influence exercised by other
church officers in universal Roman Catholic
Church) ,
Member: IAEA, INTELSAT, ITU, IWC—
International Wheat Council, UPU, WIPO,
WTO; permanent observer status at FAO,
OAS, UN, and UNESCO
Official name: Republic of Venezuela
Type: republic ,
Capital: Caracas
Political subdivisions: 20 states, 1 federal
district, 2 federal territories, and 72 island
dependencies in the Caribbean
Legal system: based on Napoleonic code;
constitution promulgated 1961; judicial re-
view of legislative acts in Cassation Court
only; dual court system, state and federal;
legal education at Central University of
Venézuela; has not accepted compulsory ICJ
jurisdiction |
National holiday: Independence Day, 5 July
Branches: executive (President), bicameral
legislature (National Congress—Senate,
Chamber of Deputies), judiciary
Government leader: Jaimé LUSINCHI,
President (since: February 1984)
Suffrage: universal and compulsory over age
18, though rarely enforced
Elections: every five years by secret ballot;
last held December. 1983; next national elec-
tion for President and bicameral legislature
scheduled for December 1988
Political parties and leaders: Social Chris-
tian Party (COPET), Godofredo Gonzalez;
Democratic Action (AD), Gonzalo Barrios;
Movement Toward Socialism (MAS),
Pompeyo Marquez (president), Freddy
Mufioz (secretary general)
Voting strength: (1983 election) 56.8% AD,
34.5% COPEI, 4.17% MAS, 4.53% others
Communists: 10,000 members (est.)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Other political or pressure groups:
FEDECAMARAS, a conservative business
eon ji ‘trot
Member of: Andean Pact, AIOEC, FAO,
G-77, IADB, IAEA, IBRD, ICAO, ICO,
IDB—Inter-American Development Bank,
IFAD, IFC, IHO, ILO, IMF, IMO,’
INTELSAT, INTERPOL, IPU, IRC, ITU,
IWC— International Wheat Council; , LAIA, ;
OAS, OPEC, PAHO, SELA, WFTU, UN,
UNESCO, UPU, WHO, WMO, WTO__.','7f4336e50424c146ededebd8ca1f156ff67922e9855e5bc432204a56fcfd4654','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b982fe8b893f734461dccf6b9f5d05c6b96c09ed53384c6fcf34d2dcfa598cef',1986,'WF','Wallis and Futuna','government',529,'Official name: Territory of the Wallis and
Futuna Islands
Type: overseas territory of France ©
Capital: Mata-Utu
Political subdivisions: three districts
Branches: territorial assembly of 20 mem-
bers; popular election of one deputy to Na-
tional Assembly in Paris and one senator
Government leaders: Mirhel KUHN-
MUNCH, Superior Administrator and Presi-
dent of Territorial Assembly (since at least
1984)
Suffrage: universal adult -
Elections: every five years
Official name: Western Sahara _
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Western Sahara (continued)
Type: legal status of territory and question
of sovereignty unresolved—territory parti-
tioned between Morocco and Mauritania in
April 1976, with Morocco acquiring the
northern two-thirds, including the rich phos-
phate reserves at Bu Craa; Mauritania, un-
der pressure from the Polisario guerrillas,
abandoned all claims to its portion in August
1979; Morocco moved to occupy .that sector
shortly thereafter and hassince asserted ad-
ministrative control there; the Polisario’s
government in exile seated as an OAU mem-
ber in 1984, while guerrilla activities contin-
ued in 1985
Government leader: Muhamad
ABDELAZIZ, President, Sahara Democratic
Arab Republic (since October 1982), and
secretary general, Polisario (since August
1976)
Official name: Independent State of. West-
ern Samoa :
Type: constitutional monarchy under native
chief; special treaty relationship with New
Zealand .
Capital: Apia
Legal system: based on English common
law and local customs; constitution came
into effect upon independence in 1962; judi-
cial review of legislative acts with respect to
fundamental rights of the citizen; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day; 1 Jan- _
uary
Branches: Head of State and Executive | .
Council; unicameral legislature (47-member
Legislative Assembly); Supreme Court,
Court of Appeal, Land and Titles Court,:
village courts
Government leaders: MALIETOA
Tanumafili I], Head of State (sirice 1962);
Va’ai KOLONE, Prime Minister one De-
cember 1985)
Suffrage: 45 members of Legislative Assem-
bly are elected by holders of matai (heads of
family) titles (about 12,000 persons); two
members are elected by universal adult suf- |
frage of persons lacking traditional family
ties
Elections: held triennially; last held in Feb-
ruary 1982 ;
Political parties and leaders: no clearly dee
fined political party structure
Communi Sieben
Member of: ADB, Commonwealth, ESCAP,
FAO, G-77, IBRD, IDA, IFAD, IFC, IMF,
South Pacific Commission, SPF, UN,
UNESCO, WHO .
Official name: Yemen Arab Republic
Type: republic; military regime assumed
power in June 1974
Capital: Sanaa
Political subdivisions: 11 provinces
Legal system: based on Turkish law, Islamic
law, and local customary law; first constitu-
tion promulgated December 1970, sus-
pended June 1974; has not accepted compul-
sory ICJ jurisdiction
National holiday: Proclamation of the Re-
public, 26 September
Branches: President, Prime Minister, Cabi-
net; People’s Constituent Assembly
Government leaders: Col. ‘Ali “Abdallah
SALIH, President (since 1978); ‘Abd al-‘Aziz
‘ABD AL-GHANI, Prime Minister (since
1983)
Communists: small number
Political parties or pressure groups: no legal
political parties; in 1983 President Salih
started the General People’s Congress,
which is designed to function as the
country’s sole political party; conservative
tribal groups, Muslim Brotherhood, and left-
ist factions—pro-Iraqi Ba’ thists, Nasirists,
National Democratic Front (NDF)
supported by South Yemen—exert political
influence
Member of: Arab League, FAO, G-77,
IBRD, ICAO, IDA, IDB—Islamic Develop-
ment Bank, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, ITU, NAM, OIC,
UN, UNESCO, UPU, WFTU, WHO,
WIPO, WMO','9603290c4b443d344f886ded97e2b0ca9aa4eb45ce11de0db148d218e5bffad8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8f276b91d7bb7dd998dfb06d19f5acc8751b8aebf7b12ca3f55e35fab4a48ba',1986,'YE','Yemen','government',533,'Official name: People’s Democratic Repub-
lic of Yemen
Type: republic; power centered in ruling
Yemeni Socialist Party (YSP)
Capital: Aden
Political subdivisions: six governorates
Legal system: based on Islamic law (for per-
sonal matters) and English common law (for
commercial matters); highest judicial organ,
Federal High Court, interprets constitution
and determines disputes between states _
National holiday: 14 October
Branches: unicameral legislature (People’s
Assembly); Supreme Cabinet
Government leaders: Haydar Abu Baler
al-‘ATTAS, Chairman, Presidium, Supreme —
People’s Council (since February 1986); ‘Ali
Salim al-BID, secretary general, Yemeni
Socialist Party (since February 1986); Yasin
Sa‘id NU‘MAN, Chairman, Council of Min-
isters (since February 1986)
Suffrage: all citizeris age 18 and over
Elections: elections for legislative body, Su-
preme People’s Council, called for in the
constitution; none have been held
Political parties and leaders: Yemeni Social-
ist Party (YSP), the only legal party, is coali-
tion of National Front, Ba‘th, and Commu-
nist Parties
Communists: unknown number
Member of: Arab League, FAO, G-77,
GATT (de facto), IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFAD, ILO,
IMF, IMO, ITU, NAM, OIC, UN, ©
UNESCO, UPU, WFTU, WHO, WMO,
WTO
Official name: Socialist Federal Republic of
Yugoslavia
Type: Communist state, federal republic in in
form”
Capital: Belgrade
Political subdivisions: six republics witht two
autonomous provinces (within the Republic
of Serbia)
Legal system: mixture of civil law system
and Communist legal theory; constitution
_ adopted 1974; legal education at several law
schools; has not accepted compulsory ICJ
jurisdiction
National holiday: Proclamation of the So-
cialist Federal Republic of Yugoslavia, 29
November
Branches: bicameral legislature (Federal
Assembly—Federal Chamber, Chamber of
Republics and Provinces); executive includes
cabinet (Federal Executive Council) and the
federal administration; judiciary; the State
Presidency is a collective, rotating policy-
making body composed of a representative
from each republic and province, Radovan
Vlajkovic presides as President of the Re-
public until May 1986, when he will be re-
placed by the representative from Kosovo
Province, Sinan Hasani
Government leader: Milka PLANING, Pres-
ident of the Federal Executive Council
(since 1982); nonrenewable four-year term
expires May 1986
Suffrage: universal over age 18
Elections: Federal Assembly elected every
four years by a complicated, indirect system
of voting
270
Political parties and leaders: League of
Communists of Yugoslavia (LCY) only; lead-
ers are 23 membérs of party Presidium se-
lected proportionally from republics, prov-
inces, and Yugoslav People’s Army, with the
president rotating on an annual basis and the
secretary rotating every two years; current
president is Vidoje Zarkovic, a Montenegrin
(until June 1986); Party Congress scheduled
for June 1986, to elect new, Central Commit-
tee
Communists: 2,167,860 party members
(December 1985)
Other political or pressure groups: Socialist
Alliance of Working People of Yugoslavia
(SAWPY), the major mass front organiza-
tion; Confederation of Trade Unions of Yu-
goslavia (CTUY), League of Socialist Youth
of Yugoslavia, Federation of Veterans’ Asso-
ciations of Yugoslavia (SUBNOR)
Member of: ASSIMER, CEMA (observer but.
participates in certain commissions), FAO,
G-77, GATT, IAEA, IBA, IBRD, ICAC,
ICAO, IDA, IDB—Inter-American Devel- °
opment Bank, IFAD, IFC, 1HO, ILO, IMF,
IMO, INTELSAT, International Lead and
Zinc Study Group, INTERPOL, IPU, ITC,
ITU, NAM, OECD (participant i in some ac-
tivities), UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO
Official name: Republic of Zaire
Type: republic; constitution establishes
strong presidential system
Capital: Kinshasa
Political subdivisions: eight regions and fed-
eral district of Kinshasa
Legal system: based on Belgian civil law
system and tribal law; new constitution pro-
mulgated February 1978; legal éducation at
National University of Zaire; has not ac-
cepted compulsory IC] jurisdiction
National holiday: Independence Day, 30
June; Anniversary of the Regime, 24 No-
vember
Branches: President elected originally in
1970 for seven-year term; Marshal Mobutu
reelected July 1984; limits on reelection re-
moved by new constitution; unicameral leg-
islature (810-member National Legislative
Council elected for five-year term); the offi-
cial party is the supreme political institution
Government leader: Marshal MOBUTU.-
Sese Seko, President (since 1965); KENGO
Wa Dondo, First State Commissioner (prime
minister; since November 1982)
Suffrage: universal and compulsory over age
18
Elections: elections for rural collectivities’
urban zone councils, and the Legislative
Council of the Popular Movement of the
Revolution were held June-September 1982;
presidential referendum/election held July
1984; presidential election/referendum
scheduled for 1991
Political parties and leaders: Popular Move-
ment of the Revolution (MER), only legal
ay ,
Voting strength: Mobutu polled 99.6% of
vote in the 1984 election ,
Communists: no Communist party |
Member of: A{DB, APC, CIPEC, EAMA,
EIB (associate), FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICO, IDA, IFAD, IFC, THO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, ITC, ITU, NAM, OAU, OCAM, UD-
EAC, UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO
Official name: Republic of Zambia
Type: one-party state
Capital: Lusaka
Political subdivisions: nine provinces
Legal system: based on English common
law and.customary law; new constitution
_adopted September 1973; judicial review of ,
legislative acts in an ad hoc constitutional
council; legal education at University of
Zambia in Lusaka; has not accepted compul-
sory yIC} jurisdiction
National holiday: Independence Day, 24
October ...
Branches: modified presidential system;
unicameral legislature (National Assembly);.
judiciary
Government leaders: Dr. Kenneth David
KAUNDA, President (since October 1964), .
Kebby MUSOKOTWANE, Prime Minister
(April 1985)
Suffrage: universal adult at age 18
Elections: general election held 27 October
1983; next general election scheduled for
1988
Political parties and leaders: United Na-
tional Independence Party (UNIP), Kenneth
Kaunda; former opposition party banned in
December 1972 when onerparty state pro-
claimed :
Voting strength: (1983 election) 63.5% of
eligible voters participated; Kaunda, who
was the only candidate for president, re-
ceived 2.98% “yes” vote; National Assembly
seats were contested by members of UNIP
Communists: no Communist party, but so-
cialist sympathizers in upper levels of gov- -
ernment and UNIP
273 -
Member of: AfDB, Commonwealth, FAO,
G-77, GATT (de facto), IAEA, IBRD, ICAO,
IDA, IFA, IFAD, IFC, ILO, IMF,
INTELSAT, International Lead and Zinc _
Study Group, INTERPOL, IPU, ITU, NAM,
OAU, SADCC, UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO .
Economy o
GDP: $2.6 billion (1984), $410 per capita;
real growth rate, — 1.3% (1984)
Natural resources: copper, cobalt, zinc,
lead, coal, emeralds, gold, silver, uranium,
hydroelectric power, fertile land
Agriculture: main crops—corn, tobacco,
cotton; net importer of most major agricul-
tural products a
Major industries: copper mining and re- .
finery, transport, construction, foodstuffs,
baverazes chemicals, textiles, and fertilizer
Electric power: 1,924 700 kw saaee. ;
(1985); 12.645 billion kWh produced (1985),
1,850 kWh per capita -
Exports: $916 million (f.0.b., 1984); copper,
zinc, cobalt, lead, tobacco
Imports: $612 million (c.i.f., 1984); machin-
ery, transport equipment, foodstuffs, fuels,
manufactures
Major trade partners: EC, Japan, South Af-
rica, US, Iraq.
Budget: (central government, 1984) reve-
nues, $900 million (est.); expenditures, $840
million (est.)
Monetary conversion rate: 5:7 Zambian -
kwachas=US$1 (December 1985)
Fiscal year: calendar year
Commiunieations ;
Railroads: 1,204 km, all 1. 067- meter gauge;
13 km double track
Highways: 36,370 kn total; 6, 500 ie paved
7,000 km crushed stone, gravel, or stabilized
soil; 22,870 km improved and unimproved
earth
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 CIA-RDP08-00534R000100170001-4
Zambia (continued)
Inland waterways: 2,250 km, including
Zambezi River, Luapula River, Lake ~
Tanganyika; “Mpulungu is small port on
Lake Tanga
Pipelivigs: 1,724 km crude oil
Civil air: 9 major transport aircraft
Airfields: 129 total, 114 usable; 12 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 4 with runways
2,440-3,659 m, 19 with runways 1,220-
2,439 m
Telecommunication: facilities are among
the best in Sub-Saharan Africa;
high-capacity radio relay connects most _
larger towns and cities; 71,700 telephones <
(1.2 per 100 popl.); 9 AM, 2 FM, 10 TV sta-
tions; 1 Indian Ocean satellite station -
Defense Forces
Branches: Army, Air Force, paramilitary
Police Mobile Force, Police Paramilitary ,
Military manpower: males 15-49, 1,472,000;
768,000 fit for military service','c0f07ce8c7882d938c8046c66d9432eef2a35c988a69dcfa9d2ac8a4c0324ec2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12d7b8b27a922d00f43ba1544db3ee0bc278a641dc7dbc3b916479a8f3d2177b',1986,'ZW','Zimbabwe','government',535,'-200km__-.
Boundary represeniation is
not necessarily authoriative.
See regional map VII
a ED
Land’
391, 090 km?; nearly as large as California;
40% arable (of which 6% cultivated), 60%
extensive grazing; of this total 48% worked —
communally by Africans, 39% owned by ~
Europeans (farmed by modern methods), 7%
national land, 6% other
Land boundaries: 3.017 km
Officials name: Beoublig of Zimbabwe
Type: independent; a British-style parlia-
mentary democracy
Capital : Harare
Political subdivisions: eight provinces
Legal system: Roman-Dutch °
Branches: legislative authority resides in a
Parliament consisting of a 100-member
House of Assembly (with 20 seats reserved —
for whites) and a 40-member Senate (10
elected by white members of the’ House, 14
elected by the other members ‘of the House;
10 chiefs, 5 from Mashonaland and 5 from |
Matabeleland, elected. by members of the
Council of Chiefs; 6 appointed by the Presi-
dent, on the advice of the Prime Minister);
executive authority lies with a Cabinet led
by the Prime Minister; the High Court is the
superior judicial authority -
Government leaders: Rev. Canaan Sodindo
BANANA, President (since April 1980);
Robert Gabriel MUGABE, Prime Minister
(since April 1980)
Suffrage: universal over age 18; for at least
seven years after independence (1980),
white, mixed, and Asians vote on a separate
roll for 20 seats in the House of Assembly
Elections: last held July 1985
Political parties and leaders: Zimbabwe
African National Union (ZANU), Robert
Mugabe: Zimbabwe African People’ s Union
(ZAPU), Joshua Nkomo; Conservative Alli-
ance of Zimbabwe (CAZ), Ian Smith; Inde- —
pendent Zimbabwe Group (IZG), Bill Irving;
Zimbabwe African National Union - Sithole
(ZANU- -$), Ndabaningi Sithole; others failed
to win any seats in Parliament
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 :
Voting strength: (July 1985 elections) ZANU
(also known as ZANU-PF), 64 seats; ZAPU,
15 seats; CAZ, 15 seats; IZG, 4 seats;
ZANUSS, 1 seat; independents,1
Communists: negligible
Member of: AfDB, Commonwealth, FAO,
- G-77, GATT, IBRD, ICAO, IDA, IFAD,
IFC, ILO, IMF, INTERPOL, ITO, NAM,
OAU, SADCC, UN, UNESCO, UPU,.
WFTU, WHO, WMO
The West Bank and the Gaza Strip are cur-
rently governed by Israeli military authori-
ties and their civil administrations. It is US
policy that the final status of these areas will
be determined by negotiations among the
concerned:parties.:Thesé negotiations will
determine how this area is to be governed.','9967f25fb18406614607b95ec40eaef674916bbd3ed6bb8b1e96c730206348ad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

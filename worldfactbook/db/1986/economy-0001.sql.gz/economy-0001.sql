SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab3787dd2367c1d5d9bf6aae36f00b4fbbebaaeb6318a368378f32509ea4cf29',1986,'','','economy',4,'GNP: $3.0 billion (1985), $160 per capita
(1984); real growth rate 2.5% (1975-79); cur-
rent growth rate figures not available (1986)
Natural resources: natural gas, oil, coal, cop-
per, talc, barites, sulphur, lead, zinc, iron,
salt, precious and semiprecious stones
Agriculture: subsistence farming and animal
husbandry; main crops—wheat, fruits, nuts,
karakul pelts, wool, mutton; an illegal pro-
ducer of opium poppy and cannabis for the
international drug trade
Major industries: small-scale production of
textiles, soap, furniture, shoes, fertilizer, and
cement for domestic use; handwoven car-
pets for export
Electric power: 472,000 kW capacity (1984);
1.375 billion kWh produced (1985), 93 kWh
per capita
Exports: $778 million (£.0.b., 1985); mostly
fruits and nuts, natural gas, and carpets
Imports: $902 million (c.i.f., 1985); mostly
food supplies and petroleum products
Major trade partners: exports—mostly -
USSR and other Eastern bloc countries; im-
ports—mostly USSR and other Eastern bloc
countries
Budget: current expenditure Af22.7 billion,
capital expenditure Af10.9 billion for FY82
(est.)
Monetary conversion rate: 50.6
afghanis=US$1 (official, January 1985)
Fiscal year: 21 March-20 March
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Afghanistan (continued)','79d6fdb70a1144db0d5a0f81928f1c2ce80e501568ff248e9620c0f432b40c15','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af29e95b1d5343c71a1785c3de695f3e59663beb9fa7c373042619fb4f12bf18',1986,'AL','Albania','economy',9,'GNP: $2.6-2.8 billion (1985); approximately
$900 per-capita (1984).
Natural resources: oil, gas, coal, chromium
Agriculture: main crops—corn, wheat, pota-
toes,.tobacco, sugar beets, cotton
Major industries: agricultural products and
processing, textiles and clothing, lumber,
and extractive industries (chrome and oil)
Shortages: spare parts, machinery and
equipment, some food products and con-
sumer goods
Electric power: 1,540,000 kW capacity
(1985); 4.7 billion kWh produced (1985),
1,584 kWh per capita
Exports: $290 million (1983 est.); asphalt,
bitumen, petroleum products, metals and
metallic ores, electricity, oil, vegetables,
fruits, and tobacco .
Imports: $280 million (1983); machinery,
machine tools, iron and steel ‘products, tex-
tiles, chemicals, pharmaceuticals
Major trade partners:.exports—Y ugoslavia,
Czechoslovakia, Romania; Italy, Poland,
Austria; imports—Yugoslavia, Czechoslova-
kia, FRG, Romania, Poland, Italy, Greece,','52aa5105cb8b4a3dc5f450ad92f12e5373f2092f013526cff105eaef883fafdb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22f3a960522c0c7eb9dfb2588f00c90e6d0e5746e0ef3f7d991c3d0d6f0b63f4',1986,'FR','France','economy',10,'Budget: (1984 prov.) revenue $1.29 billion,
expenditure $1.28 billion; state investment
$709.7 billion (1984 planned)
Monetary conversion rate: 7.1328
leks=US$1 (February 1984)
Fiscal year: same as calendar year; economic
'' data reported for calendar year','42e370b154d1cecdfdc058bab5de54d42241d2dc921cadc8c56f9497dc5e5b02','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d75b4138ef2e8ef192d34323a5dad2f23952b943e928abea017a32cd05f8cff',1986,'DZ','Algeria','economy',15,'GDP: $51.9 billion (1984 est.), $2,430 per
capita; 5.0% real growth in 1985
Natural resources: crude oil, natural gas,
iron ore, phosphates, uranium, lead, zinc,
mercury
Agriculture: main crops—wheat, barley, ©
oats, grapes, olives, citrus fruits, dates, vege-
tables, sheep, cattle, industrial crops
Major industries: petroleum, light fdas
tries, natural gas, mining, petrocliemical,
électrical, automotive plants (under con-
struction), and food processing
Crudé steel: 842,000.metric tons produced
(1982)
Electric power: 3,142,300 kW capacity _
(1985); 11. 148 billion kWh produced (1985),
506 kWh per capita
Exports: $12.6 billion (f.0.b., 1984); petro-
leum and gas account for 98.0% of exports;.
US 39. 0%, France 93. 0% (1984)
‘Imports: $10.0 billion (f.0.b., 1984); major
items—capital goods 35.0%, semifinished
goods 25.0%, foodstuffs 18.0%; France
25.7%, US 6.0%
“Major trade partners: US, FRG, France,
Ttaly, Belgium, Netherlands, Canada
Budget: $20 billion revenue, $20 billion ex-
penditure (1984)
Monetary conversion rate: 5.1 Algerian
dinars=US$1 (August 1984)
Fiscal year: calendar. year','42dd6654eb3ebe59b84e91453d0f90c3104c447d6eed85b54ae7da8a9811a691','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5f797f4c2705430a0f2337baee2bc6df1b57c485ce393e65af88817a966c6ae',1986,'AD','Andorra','economy',19,'Natural resources: hydrorlectsie1 power,
-minéral water
Agriculture: sheep raising; small quantities
of tobacco, rye, wheat, barley, oats, and
some vegetables (less-than 4% of land is ara-
ble)
Major industries: tourism (particularly ski-. -
ing), sheep, timber, tobacco, and smuggling
Electric power: 35,000 kW capacity (1985);
141 million- kWh produced (1985), 3,000
kWh per capita; power is:‘mainly exported to
Spain and France
Major trade partners: Spain, France
Monetary conversion rate: 9:375 French
francs=US$1 (October 1984); 169.96 Span-
ish pesetas=US$1 (October 1984)','a4732f53383b1ea32fee9370a667d1e888a0d35f8b766b0924553a450b26c3b5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9eb6614593c7239c35f4d3ef4b38c727bd103546cca5c713490c3f9cfee446b',1986,'AO','Angola','economy',23,'GDP: $4.0 billion ( 1985 est.), $500 per cap-
ita, 0% real growth (1985) ;
Natural resources: petroleum, diamonds,
iron, phosphates, copper, feldspar, gold,
bauxite, uranium ;
Agriculture: cash crops—coffee, sisal, corn,
cotton, sugar, manioe, and tobacco; food
crops—cassava, corn, vegetables, plantains,
bananas, and other local foodstuffs; drought
and disruptions caused by civil war require
food imports ~ ae
Fishing: earch 112, eon metric tons (1982)
Major serasstiee mining Gil, dautnay: ;
fish processing, brewing, tobacco, sugar
processing, textiles, cement, food processing
plants, building construction. .
Electric power: (including Cabinda) 630,000
kW capacity (1985); 1.655 billion kWh pro-
duced (1985), 208 kWh per capita ‘
Exports: est: $2.0 billion (f.0.b:, 1985); oil,
coffee, diamonds, sisal, fish and fish prod-
ucts, iron ore, timber, and cotton
Imports: est. $1.7-billion (f.0.b., 1985); capi-
tal equipment (machinery and electrical
equipment), wines, bulk iron and ironwork,
steel and metals, vehicles and spare parts,
textiles and‘clothing, medicines, food; sub-
stantial military deliveries
Major trade partners: Cuba, USSR, Portu-
gal, and US
Budget: (1981) est. revenues $2.0 billion; est.
total expenditures $3.5 billion
Monetary conversion rate: 30.214
kwanza=US$1 (December 1985)
Fiscal year: calendar year','a9c40672622cc07cab3b4006c5ba2d6555fe986cc7e476d938117ea87d101ea1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1453ce89b92103ec632904d2118a4f7c4233e617de3676aa1a7624bd4efe12f7',1986,'AG','Antigua and Barbuda','economy',30,'GDP: $158 million (1984), $1, 990 per capita
Natural resources: negligible ~
fe ne cotton (main crop), sugar, live-
stock °
Major industries: tourism 15.2%, construc-
tion 7.7%, manufacturing 0.5%
Electric power: 27,000 kW capacity (1985);
60.5 million kWh produced (1985), 756 kWh
per capita
Exports: $41 million (1984 prelim.); cloth-
ing, rum, lobsters.
Imports: $146.9 million (c.i. ts 1984 prelim )
fuel, food, machinery
Major fade partners: exports—47% Trin-
idad and Tobago, 8% Barbados, 1% US
(1983); imports—49% US, 138% UK, 4% Ja-:
maica, 2% Trinidad and Tobago (1983)
Aid: ecoriomic—bilateral commitments,
ODA and OOF (1970-80) from Western
(non-US) countries, $20 million; no mpltary
aid ae
Budget: (current) revenues, $40 million
(1984); expenditures, $44 million (1984)
Monetary conversion rate: 2.70 Fast Carib-
bean (EC) dollars=US$1 (February 1984)
Fiscal year: 1 April-30 March','9396c999892411137f9ed0ce515144f34707f38b40af51e362f252b6d61577d0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18c4dfcff2e9fe730c8a762df2fd705136cf81de407962aac29f600adb06312',1986,'AR','Argentina','economy',34,'GDP: $74.4 billion (1984), $2,470 per capita;
80% consumption, 15% investment; 5% net
exports; 2.0% real GDP growth rate (1984)
Natural resources: pampas, lead, zinc, tin,
copper, iron, manganese, oil, uranium
Agriculture: main products—cereals, oil-
seed, livestock products; major world ex-
porter of temperate zone foodstuffs
Fishing: catch 290,000 metric tons (1984);
exports $139.7 million (1984)
Major industries: food processing (espe-
cially meat packing), motor vehicles, con-
sumer durables, textiles, chemicals, printing,
and metallurgy
_ Steel: 2.6 million metric tons produced
(1984)
Electric power: 15,210,000 kW capacity
(1985); 40.5 billion kWh produced (1985),
1,319 kWh per capita
Exports: $8.1 billion (f.0.b., 1984) wheat,
corn, oilseed, hides, wool :
10
Imports: $4.1 billion (f.0.b., 1984); chemical
products, machinery, metallurgical prod-
ucts, fuel and lubricants
Major trade partners: (1984) exports—15%
USSR, 11% Netherlands, 11% US, 6% Brazil,
5% Italy, 4% FRG, 3% Japan; imports—20%
US, 19% Brazil, 12% FRG, 9% Bolivia, 8%
Japan, 5% France
Budget: (1984) general government reve-
nues $16.9 billion; expenditures $21.7 billion
at official exchange rate
Monetary conversion rate: 0.8
australes= US$1 (December 1985); Argen-
tina introduced a new currency, the austral,
in June 1985; new currency to be exchanged
for the peso argentino at 1,000 pesos to the
austral
Fiscal year: calendar year','47fa60be0d04596d515bffa4264640cab4e4983502b0951ed6b4a9a31f2ef9d6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('508caeef5d005ea5279f23a36b221d377cbf0490e7b6e1a7bace25c7135cec84',1986,'AW','Aruba','economy',37,'Agriculture: little production .
Major industries: petrochemicals, oil re-
fining, petroleum transshipment facilities,
tourism, light manufacturing.
Communications: ; att
Ports: 2 (Oranjestad, Sint Nicolaas)
Airfield: government- -owned aitport east of |
Oranjestad. . 2
Telecommunications: facilities, which in-
clude extensive interisland radio-relay links,
are generally adequate, 49, 600 telephones
Defense
Defense is the responsibility of the Nether-
lands until 1996 e
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4 |','cc98fe37b37ae47a9aec82aa671454764f8b824c29651a93a9a1b743332f6444','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8e2de4fefb38384fe15960defad8d893bf552365a72ea7297f61a9b2969d800',1986,'AU','Australia','economy',38,'" Timor Sea
,Darwi
Indian
Coral Sea
Ocean a
reat
Australian
Bight bourne
Tasman
Sea
1000 km
Indian Ocean
See regional map X
Land
7,686,848 km?; almost as large as the conti-.
nental US; 58% pasture; 6% arable; 2% for-
est; 34% other
Water
Limits of territorial waters (claimed): 3 nm
(fishing 200 nm)
Coastline: about 25,760 km
GDP: $173.6 billion (1984), $11,172 per cap-
ita; 60% private consumption, 22% invest-
ment, 17.1% government expenditure; 2.8%
real average annual growth (1978-84)
Natural resources: bauxite, coal, iron ore,
copper, tin, silver, uranium, nickel, tung-
sten, mineral sands, lead, zinc, diamonds,
natural gas, oil
Agriculture: large areas devoted to grazing;
60% of area used for crops is planted in
wheat; major products—wool, lamb, beef,
wheat, fruits, sugarcane; self-sufficient in
food
Major industries: mining, industrial and
transportation equipment, food processing,
chemicals -
Crude steel: 5.6 million metric tons pro-
duced (1983) _
Electric power: 30,000,000 kW capacity
(1985); 110 billion kWh produced (1985),
7,040 kWh per capita —
Exports: $24.0 billion (f.0.b., 1984); principal
products—coal, wool, iron ore, lamb, other
meat, dairy products
Imports: $26.0 billion (f.0.b., 1984); princi-
pal products—manufactured raw materials,
capital equipment, consumer goods
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Pe Oe Cy |. A CO: ee
|
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Major trade partners: (1983-84) exports—
26% Japan, 11% US, 6% New Zealand, 4%
North Korea, 4% Singapore, 3% USSR; im- .
ports—22% US, 22% Japan, 7% UK, 6%
FRG, 4% New Zealand
Aid: donor—ODA and OOF economic aid
commitments (1970-83), $6.3 billion
Budget: (F Y85-86 proj.) expenditures, $48
billion; receipts, $51. 5 billion; deficit, $3. 5°
billion -
_ Monetarsy conversion rate: 1.44 Australian.
dollar=US$1 (6 February 1986)
Fiscal year: 1 July-30June *
GNP: $64.21 billion (1984), $8, 500 per cap-
ita; 57% private consumption, 22% invest- °
ment, 19% public consumption; 1984 real
GNP growth rate, 2.2%
Natural resources: iron ore, petroleum, tim-
ber, magnesite, aluminum, coal, lignite, ce-
ment, copper
Agriculture: livestock, forest products, cere-
als, potatoes, sugar beets; 84% self-sufficient ©
Major industries: foods, iron and steel, ma-
chinery, textiles, chemicals, electrical, paper
and pulp’
Crude steel: 5.3 million metric tons | pro- Lo
duced (1984)
Electric power: 14,711,000 kW capacity
(1985); 45.11 billion kWh produced (1985),
5,983 kWh per capita
Exports: $15.72 billion (f.0.b., 1984); iron’
and steel products, machinery and
14
equipment, lumber, textiles, Daper products,
chemicals ”
Imports: $19.59 billion (¢.i.f., 1984); machin-
ery and equipment, chemicals, textiles''and
clothing, petroleum, foodstuffs, vehicles,
office machines, pharmaceuticals
Major trade partners: (1984) imports—
39.9% FRG, 8.6% Italy, 6.6% East Europe
(excluding USSR), 5/0% USSR, 4.4% Switzer: °
land, 3.5% US, exports—29.6% FRG, 9.4%
Italy, 7.6% East Europe (excluding USSR),
6.9% Switzerland, 6.4% OPEC, 4.1% US
Aid: donor—ODA and OOF economic aid
commitments (1970-83), $1.3 billion
Budget: expenditures, $23.2 billion; reve-
nues, $18.5 billion; deficit, $4.7 billion (1985)
Monetary conversion rate: 20.01
schillings=US$1 (1984 average); 22.28
schillings=US$]1 (first half 1985)
Fiscal year: calendar year
Agriculture: Kentia palm seed, eeieale: veg-
etables, fruit.
Major industries: tourism ($10 million)
Electric power: 7,000 kW capacity (1985); 8
million kWh produced (1985), 3,300 kWh
per capita - é AST a
Exports: $2.9 billion (1982-83); seed of the
Norfolk-Island pine; Kentia palm seeds,
small quantities of avocados
Imports: $15.1 million (1982-83)
-8 at e he eos 2 A
Major trade partners: .imports—Australia .
and Pacific Islands, New Zealand, Asia, Eu-
rope; exports—Australia and Pacific Islands,
New Zealand, Asia, and Europe
Budget: revenue, $2:7 million; expenditure,
$3.3 million (1983); main source of income is
sale of postage stamps and customs duties;
expenses—administrative $1.2 million, edu-
cation $0.5 million, health $0.5 million, wel-
fare $0.2 million, maintenance $0.4 million
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Norfolk Island (continued)
Monetary conversion rate: 1.44 Australian
dollars=US$1 (5 February 1986)
Fiscal year: 1 July-30 June','2a3176ca5a376549a4654fd0bf6a0d682e49fbebccec71ddcb3bb3e8c7bbbdf7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3ee16952fa0da3677e0c27d3f0461df0e7f3c24156ee672f7c4ae49fb780349',1986,'BS','Bahamas','economy',43,'GNP: $1.8 billion (1984), $7,950 per capita;
real growth rate 2% (1984)
Natural resources: salt, aragonite, timber
Agriculture: food importer; main crops fish,
fruits, vegetables _
Major industries: banking, tourism, cement,
oi refining and transshipment, lumber, salt
production, rum, aragonite, pharmaceuti-
cals, spiral weld, and steel pipe
Electric power: 348,000 kW capacity (1985);
880 million kWh produced (1985), 3,793
kWh per capita
Exports: $2.3 billion (f.0.b., 1984); pharma-
ceuticals, cement, rum, crayfish
Imports: $3.0 billion (c.i.f., 1984); foodstuffs,
manufactured goods, mineral fuels
Major trade partners: exports—US 90%,
UK 10%; imports—Iran 30%, Nigeria 20%,
US 10%, EC 10%, Gabon 10% (1981)
Aid: economic—US economic
commitments, including Ex-Im (1970-80),
from US, $42 million; ODA and OOF eco-
nomic commitments (1970-83), $140 mil-
lion;.no military aid
Budget: (1984 prelim.) revenues, $347 mil-
lion; expenditures, $363 million
Monetary conversion rate: 1 Bahamian
dollar=US$1 (September 1985) .
Fiscal year: calendar year','563d8d8521ea6a72f97aa3a9dcd6e5b2082fab89df476b5bc2c96b28feb47be5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21aea98bf4eb94e5c0bfa55932aa0ac617fa3c1ec69e7d376a3e02673bc2e816',1986,'BD','Bangladesh','economy',51,'GNP: $11.6 billion eves current ae
$130 per capita; 3.8% real growth (FY85)
Natural resources: natural gas, uranium
Agriculture: large-scale subsistence farming,
heavily dependent on monsoon rainfall,
main crops are jute, tea, and rice; grain, cot-
ton, and oilseed shortages:
Fishing: production 751, 000 metric tons
(1984) :
Major industries: jute manufactures, food
Brocessing, and cotton textiles
Electric power: ae 118,000 kW capacity
(1985); 4.21 billion kWh produced eee
kWh: per capita yk
Exports: $811 million (f. oO. b. FY84)) raw and
manufactured jute, leather, tea
oper $2. Sbillion ie if:, FY84); food- -
grains, fuels, raw cotton, fertilizer, manufac-
tured products
18
Major trade partners: exports—Middle East
29%, US''13%, Italy 8.6%, Japan 7.5%; im-
ports—Middle East 17%, Western Europe
12%, Japan 11%, US 11% (FY84)
Budget: (FY86) current expenditures, $1.2
billion; capital expénditures, $1.4 billion
Monetary conversion rate: 82.15
takas=US$1 (October 1985)
Fiscal year: 1 July-30 June','872e222ead7b361cdc74036c8b07336e22b2bfc5f824a8d1fbc0784363d309c3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af6ebf37f91a538bffc494fa331daa81d9cf990054fd5ee2f261ba930c61a47e',1986,'BB','Barbados','economy',55,'GDP: $1,151.7 million (1984), $4,560 per
capita; real GDP growth rate 0% (1984)
Natural resources: negligible
Agriculture: main products—sugarcane,
subsistence foods
Major industries: tourism, sugar milling,
light-manufacturing, component assembly
for Expert:
Electric power: 145,000 kW capacity (1985);
360 million kWh produced (1985), 1,429
kWh per capita
Exports: $390 million (f.0.b., 1984); sugar
and sugarcane byproducts, electrical parts,
clothing
Imports: $656.2 million (f.0.b., 1984); food-
stuffs, consumer durables, machinery, fuels
Major trade partners: exports—42% US,
22% CARICOM, 7% UK; imports—48% US,
12% CARICOM, 8% UK, 6% Canada (1984
prelim.) .
Aid: economic—US economic
commitments, including Ex-Im (FY70-84),
$14 million; ODA and OOF commitments
from other Western countries (1970-83),
$107 million; no military aid
Budget: (FY84 prelim.) revenues, $288 mil-
lion; expenditures, $323 million
Monetary conversion rate: 2.0113 Barbados
dollars=US$1 (September 1985)
Fiscal year: 1 April-31 March
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Barbados (continued)','9447b2ff947832fa232655069a8c560a6a5cbaa0d27ba6893b74811e7c402998','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7db09f150773ef654d882340af94c6550bb7768c437ca44f754ff1a86bf36235',1986,'BE','Belgium','economy',59,'GNP: $76.3 billion (1984), $7,870 per capita;
66% consumption, 16% investment, 18%
government consumiption, 0.0% net foreign
balance (1983); 2.2% real growth rate in
1984
Natural resources: coal
Agriculture: livestock production predomi-
nates, main crops—grains, sugar beets, flax,
potatoes, other vegetables, fruits
Fishing: catch 40,580 metric tons (1983);
exports a 991 million, imports $25,787
million. «
Major industries: engineering and metal
products, processed food and beverages,
chemicals, basic metals, textiles, lass, petro-
leum ;
Crude steel: 17.9 million metric tons capac
ity (Decemiber 1981); 11.3 million metric
tons produced, 1,147 kgper capita (1984)
Electric power: 15,911,000kW capacity
(1985); 55.885 billion kWh produced (1985),
5,669 kWh per-capita
Exports: (Belgium-Luxembourg Economic
Union) $51.4 billion (£.0.b., 1984); iron and
steel products.ears), petroleum: products,
chemicals
Imports: (Belgium-Luxembourg Economic
Union) $54.7 billion (c.i-f. 1984); fuels, food:
stuffs, chemicals
Major trade,partners: ;
(Belgium-Luxembourg. Economic. Union,
1984) exports—69.1% EC (19.5% FRG,
14.3% Netherlands, 14.0% France, 9.8%
UK), 6.1% US, 2.6%.Communist; imports—
67.3% EC (20:0% FRG, .19.0% Netherlands,
14.8% France, 8.8% UK),.6.1%. ae 4.4%
Communist
Aid: donor—@DA and OOF economic aid
commitments (1970-83), $3.6 billion
Budget: (1984) revenues; $23.1 billion; ex-
penditures, $28.5 billion: deficit, $5.4 billion
Monetary conversion rate: 51:6’ Belgian
francs=US$1 (December 1985)
Fiscal year: calendar year','a00ebe0e4ced807cde22eba8a13d7aab403b562e9b822a17123c2cb2fdc6a888','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3aaa0a1b1f5881087c79a94a8e557c2d107d9b118024ddd61a36e330063af53',1986,'BZ','Belize','economy',63,'GDP: $198 million (1985), $1,200 per capita
(1985); real growth : rate 1.5% (1983)
Natural resources: arable land, timber, fish
Agriculti:re: main products—sugarcane,
citrus fruits, corn, molasses, rice, beans, ba- ”
nanas, livestock products, honey; net.im-
porter of food; an illegal producer of canna-
bis for the international ane trade
Fishing: catch 1;349 metric tons (1980)
Major industries: sugar refining, garments,
timber and forést products, furniture, rum,
soap, beverages, cigarettes -
Electric powe?: 23,000 kW capacity (1985);
56 million kWh produced (1985), 840 kWh
per cape
Exports: $98 million m0 o.b., 1984 est.); sugar,
garments, seafood, molasses, citrus fruits,
wood and wood prone
Imports: $126 million (c.i.f., 1984 est.); ma-
chinery and transportation equipment, food,
manufactured goods, fuels, chemicals, phar-
maceuticals °
Major trade partnérs: exports—US 36%,
UK 22%, Trinidad and Tobago 11%, Canada
10%; imports—US 55%, UK 17%, Nether- ~
lands Antilles 8%; Mexico 7% (1983)
Aid: US economic commitments, including -
Ex-Im (FY70-84), $3.0''million; ODA and
OOF commitments from Western (non-US)
countries (1970-83), $160 million
Budget: revenues, $49 million; expendi-
tures, $90 million (budget for 1984/85)
Monetary conversion rate: 2 Belize
dollars=US$1 (December 1985)
Fiscal year: 1 April-31 March
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Pe rtem ont ee or Cpe Re ee Tee sate igs
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','efaea7f6cdf47f6e09d0ee582b8fa60bee2d689d55102fdcb6ce465d01cc0f46','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2952aebf1dbe4b6fe2014eb760fc0e65c41a4a51df1aded21987d3eb50b5db93',1986,'BJ','Benin','economy',67,'GNP: $974.2 million (1984 eat. ) $270 per
capita (1983); 1.6% growth during 1984
Natural resources: small offshore oil depos-
its; no other known minerals in commercial
quantity
Agriculture: major cash crop is oil palms;
peanuts, cotton, coffee, sheanuts, and to-
bacco also produced commercially; main
food crops—corn, cassava, yams, rice, sor-
ghum, millet; livestock, fish
Fishing: catch 21,000 metric tons (1983)
Major industries: palm oil and palm kernel
oil processing, textiles, beverages
Electric power: 21,000 kW capacity (1985);
27 million kWh produced (1985), 7 kWh per
capita
Exports: $172.5 million (f.0.b., 1984 est.);
palm products, cotton, other agricultural
products
Imports: $225.4 million (f.0.b. 1984 est.);
thread, cloth, clothing and other consumer
goods, construction materials, iron, steel,
fuels, foodstuffs, machinery, and transport
equipment
Major trade partners: France, EC, frane
zone; preferential tariffs to EC and france
zone countries
Budget: (1985 est.) revenues $119 million;
expenditures, $119 million
Monetary conversion rate: 475 Commu-
nauté Financiére Africaine (CFA)
francs=US$1 (1985)
Fiscal year: calendar year
GDP: $68 billion (1984), $630 per capita;
— 0.6% growth rate (1984 est. )s 40% inflation
rate (August 1985)
Natural resotirces: petroleum, tin, colum- -
bite, iron ore, coal, limestone, lead, zinc -
Agriculture: main crops—peanuts, cotton;
cocoa, rubber, yams, cassava, sorghum, palm
kernels, millet, corn, rice; livestock; an ille-
gal producer of cannabis for the interna-
tional drug trade
Fishing: catch 512,000 metric tons (1982);
imports nonprocessed and processed fish.
Major industries: mining—crude oil, natu-
ral gas, coal, tin, columbite; processing in-
dustries—oil palm, peanut, cotton, rubber,
petroleum, wood, hides, skins; manufactur- -
ing industries—textiles, cement, building .
materials, food products, footwear, chemi-
cal, printing, ceramics
Electric power: 3,732,900 kW capacity
(1985); 8.175 billion kWh produced (1985),
80 kWh per capita
Exports: $11.2 billion (f.0.b., 1984); oil (98%),
cocoa, palm products, rubber, timber, tin
Imports: $9.5 billion (f.0.b. , 1984); machin-
ery and transport equipment, manufactured
goods, chemicals, wheat
Major trade partners UK, EC, US
Budget: (1985) revenues, $12.3 billion; cur-
rent expenditures, $6.0 billion; capital ex- .
penditure $6.4 billion
Monetary conversion rate: .98 naira=US$1
(December 1985)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Nigeria (continued)
Fiscal year: calendar year».','3c6d8b71c8b7e29f0bd842d2b6c7b764113e594137824f9aa4de6aa55b1b44e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fe427f938612ce9e027aa5c6e237973b5a39ee762968e8b398f2d350c7f5f3f',1986,'BM','Bermuda','economy',70,'GDP: $1,003 million (1983-84), $18,040 per.
capita (1983-84); real growth rate 1.1%
(1983-84); average inflation rate 3.8%
(1984-85)
Natural resources: limestone (used pri-
marily for building) - :
Agriculture: main products—bananas, vege-
tables, Easter lilies, iy products, citrus
fruits
Major industries: tourism (83%), finance,
structural concrete products, paints, per-
fumes, furniture
Electric power: 110,000 kW capacity (1985);
850 million kWh produced (1985), 6,034
kWh per capita
Exports: $40.5 million (1984); semitropical
produce, light manufactures’
Imports: $411.094 million G64) fuel food-
stuffs, machinery
Major ide partners: 57% US, 9% Carib-
bean countries, 8% UK, 6% Canada, 20%
other; tourists, 90% US
Aid: economic—bilateral commitments,
including Ex-Im (FY70-81), from US $34
million; from Western (non-US) countries,
ODA and OOF (1970-82), $252 million; no
military aid
Budget: revenues, $159 million; expendi-
tures, $143 million (FY82/83)
Monetary conversion rate: 1 Bermuda
dollar=US$1 (September 1985)
Fiscal year: 1 April-31 March','b61f74252c75f5df6b98403ec6058e76bc21cb4b1ad37a379979e7873de83ca3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c13f0972113534380e32dbb33d400df39dadb500e092d0a7812ac58ada3c1098',1986,'BT','Bhutan','economy',74,'GDP: $300 million (FY84/85), $250 per cap-
ita; 6.7% real GDP growth in FY84/ 85
Natural resources: timber, hydroelectric
power . ; We ;
Agriculture: rice, corn; barley, wheat, Pota-
toes, fruit, ‘spices: fe ot
Major industries: cement, chemical prod-
ucts, mining, distilling, food processing,
handicrafts
Electric power: 15,720 kW capacity (1985);
9 million kWh produced (1985), 6 kWh per
capita :
Exports: $15.1 million (FY84/85); agricul-
tural and forestry products, coal
Imports: total imports $69.4 million
(FY84/85); imports from India $61.0 million
(FY84/85); textiles, cereals, vehicles, fuels,
machinery
Major trade partner: India
Budget: total receipts, $59.168 million; ex-
penditures, $66.861 million (FY85/86 est.)
Monetary conversion rate: both ngultrums
and Indian rupees are legal tender; 12.882
ngultrums= 12.882 Indian rupees= US$1
(October 1985)
Fiscal year: | April-31 March','95b433c09561b6a93eb29c05eeb9d80b0cf1978dc80a210da41ab5928ceae370','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('313ecb995de173f1a594dab22d45bd7874098e2add8feb0a47f0611221a4b811',1986,'BW','Botswana','economy',78,'GDP: $905 million (1984); average annual
real growth, 9.7% during 1976-84, 2% in
FY83/84
Natural resources: diamonds, copper,
nickel, salt, soda ash, potash, coal
Agriculture: principal crops are corn, sor-
ghum, millet, cowpeas; livestock raised and
exported; heavy dependence on imported
food
Major industries: livestock processing; min-
ing of diamonds, copper, nickel, coal, salt,
soda ash, potash; tourism
Electric power: 105,000 kW capacity (1985);
505 million kWh produced (1985), 472 kWh
per capita
Exports: $670 million (f.0.b. 1984);
diamonds, cattle, animal products, copper,
nickel
Imports: $690 million (c.i.f., 1984); food-
stuffs, vehicles, textiles, petroleum products
Major trade partners: Switzerland, US, UK,
other EC members of Southern African Cus-
toms Union
Budget: (FY84/85 est.) revenues $433 mil-
lion, expenditures $351 million
Monetary conversion rate: 1.88 pula=US$1
‘(24 January 1985)
Fiscal year: 1 April-31 March
GNP: $321.4 billion, $1,610 per capita (1984
est.); 83% consumption, 16% gross invest-
ment, 2% net foreign balance (1984 est.); real
growth rate 8.3% (1985)
Natural resources: iron ore, manganese,
bauxite, nickel, uranium, tin, gemstones,
hydroelectric power
Agriculture: main rod gee eolkee: rice,
corn, sugarcane, cocoa, soybeans, cotton,
manioc, oranges; nearly self-sufficient ex-
cept for wheat; an illegal producer of coca
and cannabis for the international drug
trade
Fishing: catch 828,900 metric tons (1982);
exports, $162 million (f.0.b., 1982); imports,
$80 million (f.0.b., 1982)
Major industries: textiles and other con-
sumer goods, chemicals, cement, lumber,
iron ore, steel, motor vehicles, other metal-
working industries, capital goods, tin
Crude steel: 20.0 million metric tons capac-
ity; 18.4 million metric tons produced (1984)
Electric power: 42,000,000 kW capacity
(1985); 167 billion kWh produced (1985),
1,195 kWh per capita
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Exports: $25.1 billion (f.0.b., 1985);
soybeans, coffee, transport equipment, iron -
ore, steel products, chemicals, machinery.
orange juice, shoes, sugar
Imports: $12.7 billion (f.0.b., 1985); petro-"
leum, machinery, chemicals, fertilizers,
wheat, copper
Major trade partners: exports—29% US,
23% EC; 11% Latin America, 6% Japan, 31%
other (1984); imports—36% oil exportors,
17% US, 16% Latin America, 12% EC, 4%
Japan, 15% other (1984)
Budget: (1984) public sector; revenue 64,235
billion cruzeiros; current expenditure, ©
59,997 billion curezeros; capital expendi-
ture, 18,111 billion cruzeiros
Monetary conversion rate: 8,900 |
cruzeiros=US$1 (November 1985), with an
inflation rate of 230% per year at the end of
1985; new currency introduced in March
1986; 13.8 cruzados=US$1 (March 1986)
Fiscal year: calendar year','0e1c7a95b74e567991e0a0960e4664a22e8c0f2ae78f0cfe5d092c4d0aa6ba78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b3cb4cfd5a12b3985aec7131dad647d97d7feeae443f3efe9214beed64b409a',1986,'IO','British Indian Ocean Territory','economy',80,'Electric power: provided by US military
GDP: $77.1 million (1983)
Agriculture: limited—livestock (including
poultry), fish, fruit, and vegetables
Fishing: 298 metric tons fish, 25 metric tons
crustaceans (1975)
Major industries: tourism (over 45%), con-
struction, rum, concrete block
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Electric power: 5,000 kW capacity (1985);
22 million kWh produced (1985), 1,833 8 kWh
per capita:(1985)
sae: $2.0 million (1981); fresh fish,
gravel, sand, fruits; and vegetables. -
Imports: $49.8 million (1981); building ma- -
terials, automobiles, foodstuffs, machinery
Major trade panniers intl with neighbor
ing US Virgin Islands | :
Baden (1984 est. es aid 79 million:
expenditures, $19.0 million |
M onetary conversion rate: US currency
used; 1 pound sterling=US$1.443 (October
1985)
Fiscal year: \\''‘April-31 March °
GDP: $1.7 billion (1984), $7,300 per capita
(1984)
Natural resources: oil, natural gas
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Brunei (continued)
Agtivisltuéé:n main crops—ride, pepper; must
import most food
Major industry: erie petroleum, liquefied
natural ; gas, construction
Electric power: 153,000 kW capacity (1985);
470 million kWh produced (1985), 2, 026
kWh per capita
Exports: $3.26 billion (1983); 98-99% crude
oil, liquefied natural gas, and petroleum
products
Imports: $701 million (1983); includes ma-
chinery and transport equipment, manufac-
tured goods, food, beverages, tobacco, and
other; most consumer goods imported
Major trade partners: exports—(crude pe-
troleum and liquefied natural gas) Japan
68.4%; imports—Japan 30%, US 24%, UK
15%, Singapore 9%
Budget: (1984) revenues $3,497 million, ex-
penditures $1,970 million; surplus $1,528
million; 11% defense
Monetary conversion rate: 2.119 Brunei
dollars= =US$ 1 (December 1985)
Fiscal year: calendar year
GNP: $56.4 billion, 1984 (1984 dollars),
$6,295 per capita; 1984 real growth rate,
3.1%
Natural resources: bauxite, copper, lead,
zinc, coal, lignite, lumber
Agriculture: mainly self-sufficient; main
crops—grain, tobacco, fruits, vegetables,
sheep, hogs, poultry, cheese, sunflower seeds
Fishing: catch 151,000 metric tons (1983)
Major industries: food processing, machine
and metal building, electronics, chemicals
Shortages: some raw materials; scattered
energy and food shortages in 1985
Crude steel: 2.9 million metric tons pro-
duced (1984), 324 kg per capita
Electric power: 10,200,000 kW capacity
(1985); 45.8 billion kWh produced (1985),
5,100 kWh per capita
Exports: $12.2 billion (f.0.b., 1984); 48% ma-
chinery and equipment; 18% agricultural
products; 11% fuels, mineral raw materials,
and metals; 10% manufactured consumer
goods; 13% other
Imports: $12.0 billion (f.0.b., 1984); 47%
fuels and minerals, 34% machinery and
equipment, 5% chemicals, 4% manufac-_ .
tured consumer goods, 10% other (1982)
35
_Major trade partners: 57% Soviet Union,
18.5% other Communist countries, 24.5%
non-Communist countries
M onetary conversion rate: 1.016 leva=
US$1 Peptember a
Fiscal year: renee year
GDP: $66 million (1984), $160 per capita
(1984); real growth; — 1.3% (1983)
Natural resources: manganese, limestone,
marble, gold, antimony, copper, nickel,
bauxite, lead, phosphates
Agriculture: cash crops—peanuts, shea nuts,
sesame, cotton; food:crops—sorghiim, mil-
let, con, rice; livestock; food deficiency
Fishing: catch 7,000 metric toris (1983 est.)
Major industries: agricultural. processing
plants, brewery, bottling, and brick plants; a
few other light industries
Electric power: 55,000 kW capacity (1985);
134 million kWh produced (1985), 19 kWh
per capita
Exports: $110 million (f.0.b., 1983); livestock
(on the hoof), peanuts, shea nut products,
cotton, sesame
Imports: $230 million (f.0.b., 1983); textiles, .
food, and other consumer goods, transport
equipment, machinery, fuels
Major trade partners: Ivory Coast and
Ghana; overseas trade mainly with France
and other EC countries; preferential tariff to
EC and franc zone countries
Aid: economic commitments—Western
(non-US) countries, ODA and OOF
(1970-83), $1.6 billion; US authorized in-
cluding Ex-Im (FY70-84) $196 million;
Communist countries (1970-84), $62 million;
OPEC ODA commitments Wele 83), $100
million
Budget: (1983) revenue $220 million, cur-
rent expenditures $148 million, develop-
ment expenditures $161 million
Monetary conversion rate: about 475 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (1985)
Fiscal year: calendar year °
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
GDP: $6.5 billion (FY84/85, in current.
prices), $180 per capita; real growth rate
4.5% (FY84/85)
Natural resources: oil, copper, asbestos,
some marble, limestone; possibly chromium,
gypsum
Agriculture: accounts for 64% of total em- ;
ployment and about 29% of GDP; main
crops—paddy, pulses, sugarcane, beans,
peanuts; almost 100% self-sufficient; most
rice grown in deltaic land; an illegal pro-
ducer of opium poppy and cannabis for the
international drug trade
Fishing: catch 585,800 metric tons (1983)
Major industries: agricultural processing;
textiles and footwear; wood and wood prod-
ucts; petroleum refining; mining of copper,
tin, tungsten, iron
Electric power: 818,000 kW capacity (1985);
1.78 billion kWh produced (1985), 48 kWh
per capita
Exports: $349.3 million (f.0.b., FY84/85);
teak, rice, pulses, beans, base metals, ores
Imports: $672.8 million (f.0.b., FY84/85),
machinery and transportation equipment,
building materials, oil industry equipment
M ajor trade partners: exports—Singapore,
Western Europe, China, UK, Japan; im-
ports—Japan, Western Europe, Singapore,
UK
Budget: (FY84/85) $826.5 million est. reve-
nue, $954 million est. expenditure
M onetary, conversion rate: 8.5586
kyats=US$1 (FY84/85)
Fiscal year: 1 April-31 March ;','be6599688951f7420a967474b83d9112ddf2933f888ee8818fbb80e95a44649c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6e135f1cdbd82ab651d5f9374218610366c753cd47f2367ff82612bc959526e',1986,'BI','Burundi','economy',86,'‘GDP: $963 million (1984 est. Jy $250 per cap-
ita; 3% real growth rate (1983) ae
Natural resources: nickel, uranium, rare
earth oxide, peat, cobalt; copper; platinum
(not yet exploited)
Agriculture: maior cash crops—coffee, cot-
ton, tea; main food crops—manioc, yams,
peas, corn, sorghum, bananas, haricot beans
Major industries: light consumer goods such
as blankets, shoes, soap; assembly of imports:
public works construction; food processing
Electric power: 20,000 kW capacity (1985);
26 million kWh prodiiced (1985), 5 kWH per
capita ; 7 é
Exports: $83.5 million (1984); coffee (87%),
tea, cotton, hides and skins
Imports: $158 million (1984); textiles, food-’
stuffs, transport equipment, petroleum
products ;
M ay trade partners: US, EC countries .
Budget: (1983) revenue $121.4 million, ex>
penditure $146.4 million. ;
Monetary conbersion rate: 120 Burundi
francs= US$ 1 (October 1984)
Fiscal year: calendar year','f4bbfbfa561ca7d6b36af0380fe6ab834d793e261d6e05b288fd02294807cb6e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d893f7fa67a65479c1ba2bc580d51ce497d5e0ca8d74f398cfb66ec4622df4c',1986,'KH','Cambodia','economy',90,'Natural resources: daiek gemstones, some .
iron ore, manganese, phosphates, hydroelec-
tric power (potential)
Agriculture: mainly subsistence except for
rubber plantations; main crops—rice, rub- |
ber, corn; food shortages—rice, meat, vege
tables, dairy products, sugar, flour
Major industries: rice milling, fishing, wood —
and wood products
Shortages: fossil fuels
Electric power: 123,500 kW capacity ( 1985);
141 million kWh produced (1985), 28 kWh;
per capita
Exports: probably less than $10 million
(1983 est.); natural rubber, rice, pepper,
wood
Imports: probably less than $30 million
(1983), international food aid; Soviet bloc
economic development aid (post-1979)
Trade partners: Vietnam and USSR
Aid: economic commitments—US (F Y70-
84), $714 million; other Western (1970-83),
$254 million; military (FY70-82)—US, $1.2
billion; Communist data not available
Monetary conversion rate: 4 riels=US$1
(1984)
Fiscal year: calendar year','10d21eca373963f386d82c3e623b5baddc2660d32d6ff4ec1d5f6946a9f7ce78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7d96b0ba6addb4cebe4e4cec028a9cda7a8442fda7c43db52778e918e1512ae',1986,'CA','Canada','economy',95,'GNP: $384.1 billion (1984), $12, 940 per cap-
ita (1984), 61.4% consumption, 19.7% invest-
ment, 17.2% government, 0.8%. net foreign:
trade; 0.4% change in inventories; real
growth rate 4.7% (1984-85) _
Natural resources: nickel, zinc, copper,
gold, lead, molybdenum, potash silver, fish,
forests, wildlife
Agriculture: main products—livestock,
grains (principally wheat), dairy.products, -
feedgrains, oilseeds, tobacco; food short:
ages—fresh fruits and vegetables
Fishing: catch 1.34 million metric tons .
(1983) . : :
Major industries: processed and unproc-
essed minerals, food products, wood and
paper products, transportation equipment,
chemicals, fish products, petroleum and nat-
ural gas
Shortages: rubber, rolled steel, fruits, preci-
sion instruments
Crude steel: 14.7 million metric tons pro-
duced (1984)
Electric power: 95,600,000 kw capacity
(1985); 437.885 billion kWh produced
(1985), 17,240 kWh per capita
48
Exports: $86.244 billion (f.0.b., 1984); prin-
cipal items—transportation equipment,
wood and wood products including paper,
ferrous and nonferrous ores, crude petro-
leum, wheat; Canada is a major food ex-
porter i
Imports: $70.346 billion (f.0.b., 1984); prin-
cipal items—transportation equipment, ma-
chinery, crude petroleum, communication
equipment, textiles, steel, fabricated metals,
office machines, fruits and vegetables :
Major trade partners: imports—71.5% US,
5.9% Japan, 2.4% UK; exports—75.6% US,
5.1% Japan, 2.2% UK, 1.9% USSR (1984)
Aid; economic—(received US, $1.8 billion
Ex-Irh Bank, FY70- -81); ODA and OOF eco-
nomic aid commitments (1970-83), $15.8
billion a ;
Budget: total revenues $58.78 billion; cur-
rent expenditures $80.50 billion; budget def-
icit $22.8 billion (1984)
"Monetary conversion, Fate: 1.402 C$= US$1
(2 January 1986) -
Fiscal year: 1 April-3i March °
GNP: $106 million (1982 prov.); $350 per
capita GNP (1982); 0% growth rate (1978)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Natural resources: salt, basalt rock, pozzo-
lana, limestone, kaolin
Agriculture: main crops—corn, beans, man-
ioc, sweet potatoes; barely self-sufficient in
food
Fishing: catch 13,205 metric tons (1983);
largely undeveloped but provides major
source of export earnings
Major industries: salt mining
Electric power: 14,174 kW capacity (1985);
16 million kWh produced (1985); 50 kWh
per capita
Exports: $1.6 million (f.0.b., 1983); fish, ba-
nanas, salt, flour
Imports: $68.1 million (c.i.f., 1983); petro-
leum products, corn, rice, machinery, tex-
tiles
Major trade partners: Portugal, UK, Japan,
African neighbors
Budget: $20.4 million public revenue, $26.7
million current expenditures (1984)
Monetary conversion rate: 89.27
escudos= US$] (November 1984)
Fiscal year: calendar year
GNP: $8,333 per capita (1983 est.)
Agriculture: minor production of vegetables
and livestock, turtle farming ~','fa79cf208c3f028c6a88813fff4f3dea69783df38c4447b0dcb15434e17108f6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59ee4d004610919615fc7a84b705d1e0750d3c03a4585f034a3bc9a58d5d51d0',1986,'CF','Central African Republic','economy',97,'Major industries: tourism, banking, insur- a
ance and finance; real estate and construc- ole . 400 km
tion Ce :
Electric power: 29,000 kW: capacity (1985); -
90''niillion kWh produced (1985), 4,110. kWh -
per capita
Exports: $2.4 million (1983); turtle products —
Imports: $140.4 million (1983) angassou
Major trade partners: exports—mostly US;
imports—US, Trinidad and Tobago, UK,
Netherlands Antilles to ;
See regional map VI) |
Budget: current revenue $41.6 million; cur-
rent expenditure $31 million (1983)
ae Land
622,984 km; slightly smaller than Texas;
80-85% meadow, fallow, vacant arable land,
urban, or waste; 10-15% cultivated; 5%
dense forest
Monetary conversion rate: | Cayman
dollar= USS1. 20(1985 est. )
Fiscal year: V April: 31 Marchi
Communications Land boundaries: 4,981 km
Railroads: none - ; ;
GDP: $764 million (1984), $280 per capita,
~ 8.7% real growth (1984)
Natural resources: diamonds, uranium, tim-
ber
Agriculture: commercial—cotton, coffee,
peanuts, sesame, wood; main food crops
manioc, corn, peanuts, rice, potatoes ,
Major industries: sawmills, brewery, dia-
mond mining and splitting
Electric power: 46,000 kW capacity ( 1985); .
80 million kWh preduced (1985), 29 kWh _
per capita
Exports: $114.6 million (f.0.b., 1984); cotton, .
coffee, diamonds, timber
Imports: $139.6 million (£.0.b., 1984 est.);
textiles, petroleum products, machinery, .
electrical equipment, motor vehicles, chem-
icals, pharmaceuticals
Major trade partners: exports—F rance,
Belgium, Japan, US; imports—France and
other EC countries, Japan, Algeria, Yugosla-.
via ;
Budget: (1984) revenues $93.3 million; cur-.
rent expenditures $90.8 million; official for-
eign debt $223 million (1984) .
Monetary conversion rate: 475 Commu- *
nauté Financiére Africaine (CFA)
francs=US$1 (1985)
Fiscal year: calendar year','4bca93da2a57dc309e71eb7d1d74a08b696e2120f7f0be872b884057f438a4c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f1e737d705a132a9820403fdc16ff093fdf6f77877f488e535af44d6d2bcb68',1986,'TD','Chad','economy',103,'During the last decade droughts and plagues
of locusts have caused widespread food .
shortages, and years of civil war have devas-
tated the economy
GDP: $360 million (1984 est.), $88 per capita
(1984 est.); real annual growth rate — 2.8%
(1960-82 est.)
Natural resources: petroleum (unexploited
but exploration beginning), uranium, na-
tron, kaolin
Agriculture: commercial—cotton, gum ara-
bic, livestock, peanuts, fish; food crops—
millet, sorghum, rice, sweet potatoes, yams, .
cassava, dates; imports food
Fishing: catch 110,000 metric tons (1983
est.)
Major industries: agricultural and livestock
processing plants (cotton textile mills,
slaughterhouses, brewery), natron -
Electric power: 25, 000 kW capacity (1985);
32 million kWh produces 98>). 6 kWh per :
capita
Exports: $113.15 million (f.0.b., 1984); cot-
ton (80%), meat, fish, animal] products
Imports: $114.38 million (f.0.b., 1984); ce-
ment, petroleum, flour, sugar, tea, machin-
ery, textiles, motor vehicles
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Major trade partners: France and Central
African Customs and: Beonomlc Union
countries ;
Budget: (1978 est.) total revenue $34.1 mil-
lion, total expenditures $36.6 million
M onetary conversion rate: 475 Commu-
nauté Financiére Africaine (CFA)
francs= ee (1985)
Fiscal year: calendar year','812800334bc09ef984b2fddccac0c5cb0a265b787aece094a41ff7a54d5737d9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44122ebf94cb2fd9728ff0b8146010c4e7f3d42b199c2cf364d01eecc84d8898',1986,'CL','Chile','economy',106,'GDP: $19.2 billion (1984), $1,590 per capita
71% private consumption, 15% government
consumption; 14% gross investment. (1984);
real growth rate 6.3% (1984) °
Natural resources: copper, timber, iron ore,
nitrates, precious metals, molybdenum
Agriculture: main crops—wheat, potatoes, ., |
corn, sugar beets, onions, beans, fruits; net. .
agricultural importer
Fishing: catch 4 million metric tons (1983); _
exports $275. 5 million (1984)
Major industries; copper, other minerals,
foodstuffs, fish processing, iron and steel,
pulp, paper, and forestry products __
Crude steel: 765,000 metric tons capacity
(1980); 700,000 metric tons produced (1980);
683,000 metric tons produced (1984) -
Electric power: 3,300,000 kW capacity |
(1985); 13 billion kWh produced (1985),
1,094 kWh per capita
Exports: $3.7 billion (f.0.b., 1984); copper,
molybdenum, iron ore, paper products, steel
products, fishmeal, fruits, wood products
Imports: $3.4 billion (f .o.b., 1984); petro-
leum, sugar, wheat, capil goods, vehicles .
Major trade partners: rpors 26% US, ;
11% Japan, 10% FRG, 6.2% Brazil, 5.4% UK
(1984); imports—21. 5% US, 9% Japan, 8.5%
Brazil, 7.2% Venezuela, 6.2% FRG (1983)
Budget: revenues, $6.5 billion; expenditures,
$7.2 billion (1984)
Monetary conversion rate: 178 pesos=US$1
(November 1985)
Fiscal year: calendar year
50
Communication’
Railroads: 8,478 km total; 4, 257 km 1.676-
meter gauge, 135 km 1.435-meter standard
gauge, 4,221 km 1.000-meter gauge; electri-
fication, 1,578 km, 1.676-meter gauge, 76
km 1. 000- meter gauge
Highisaye: 78,025 ia total; 9,365 km paved,
37,700 km gravel, 32,000 km improved and
unimproved earth
I nland ‘waterways: 725 km’
Pipelines: crude oil, 755°’km; refined prod-
ucts, 785 km; natural gas, 320 km
Ports: 10 major, 13 minor
Civil air: 22 maior transport aircraft
Aiehelde: 375 total, 339 usable; 50 with |
permanent-surface runways; 13 ‘with run-
ways 2,440-3,659 m, 53 with runways
1,220-2,439 m
Telecommunications: modern telephone
system based on extensive radio-relay facili-
ties; 629,000 telephones (5.4 per 100 popl.); 2
Atlantic Ocean satellite antennas; 3 domes-
tic satellite stations; 153 AM, 126 TV stations
Defense Forces
Branches: Army of the Nation, National
Navy, Air Force of the Nation, Carabineros
of Chile
Military manpower: males 15-49, 3,249,000;
2,445,000 fit for military service; about,
123,000 reach military age (19) annually
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 ; CIA-RDP08-00534R000100170001-4','bd6a450d0ae939d2d8d89489535bedc5944c14ba85efbd225f096bf2e51edc15','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a66f053cf2df248327729e41d7cefdf79076691ae8ea95cb5efcff529084a20',1986,'CN','China','economy',107,'(Taiwan listed
at end of table)
RAGS:
1200 km
Boundary representation is
not necessarily authoritative. |
Taiwan
Hainan @ cio
- 00.” South China -: -
See regional map VIII S Sea
Land ae
9.6 million km; slightly larger than US;
74.3% desert, waste, or urban (32% of this °-
area consists largely of denuded wasteland,
plains, rolling hills, and basins from which’
about 3% could be reclaimed); 11.0% ‘culti: ;
vated (sown area extended by multicrop-
ping); 12.7% forest and a eosland: 2.0% in- : .
land water
Land boundaries: 24,000 km
Water
nm
Coastline: 14,500 km
GNP: $3483 billion 98s est.), $330 per cap- °
ita
Natural resources: coal, iron, petroleum,
mercury, tin, tungsten, antimony, manga-
nese, molybdenum, vanadium, magnetite,
aluminum, lead, zinc, uranium, hydroelec-
tric power (world’s largest potential) |
Agriculture: main crops—rice, wheat, other
grains, oilseed, cotton; agriculture mainly
subsistence; grain imports 9.8 million metric
tons in 1984; grain exports (mostly corn) 3.4
million metric tons (1984)
Major industries: iron, steel, coal, machine -
building, armaments, textiles, petroleum
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
China (continued)
Shortages: complex machinery and equip-
ment, highly skilled scientists and techni-
cians, energy, and transport
Crude steel: 43.4 million metric tons pro-
duced, 42 kg per capita (1984)
Electric power: 86,220,000 kW capacity
(1985); 406 billion kWh produced (1985),
389 kWh per capita
Exports: $27.4 billion (f.0.b., 1984); manu-
factured goods, agricultural products, oil,
minerals
Imports: $25.1 billion (f.0.b., 1984); grain,
chemical fertilizer, steel, industrial raw ma-
terials, machinery, equipment
Major trade partners: Japan, Hong Kong,
US, FRG, Jordan, Canada, Brazil, Singapore
(1984)
Monetary conversion rate: 3.06 renminbi
yuan=US$]1 (October 1985)
Fiscal year: calendar year
Sea ne
: Philippine
4
o Sea
? Okinawa
See regional map VIII
Land
372,318 km?; slightly smaller fas Califor-
nia; 69% forest; 16% arable and cultivated,
12% urban and waste, 3% grass
Water
Limits of territorial waters (claimed): 12
nm except 3 nm in five ‘ ‘international
straits” (200 nm fishing zone)
Coastline: 13,685 km .
GNP: $1,233 billion Agnes at 237.52.
yen=US$1); $10,200 per.capita (1984); 59%
personal consumption, 28%-investment, 10%
government current expenditure, negligible
stocks, and 2% foreign balance; real growth
rate 5.7% (1984); average annual growth rate
4.3% (1980- 84) . :
Natural resources: negligible mineral re--
sources, fish |. -
Agriculture: land intensively cultivated;
rice, sugar, vegetables, fruits; 72%
self-sufficient in food (1980); food
shortages—meat, wheat, feed grains, edible
oils and fats
Fishing: catch 11.2 million metric tons ,
(1983)
Major industries: metallurgical and engi-
neering industries, electrical and electronic
industries, textiles, chemicals.
Shortages: fossil fuels, most industrial r raw
materials °
Crude steel: 105.6 million m metric tons pro- -.
duced a
Electric power: (including Ryukyus) |
175,000,000 kW capacity (1985); 650 billion
‘kWh produced (1985), 5,385 kWh per capita
Exports: $170.1 billion (f.0.b., 1984); 97%
manufactures (including 25% machinery,
18% motor vehicles, 9% iron and steel)
Imports: $136.5 billion (c.i.f., 1984); 47%
fossil fuels, 22.4% manufactures, 12% food-
stuffs, 8% machinery -
Major trade partners: exports—29% US,
23% Southeast Asia, 16% Western Europe,
12% Middle East, 6% Communist countries,
imports—27% Middle East, 22% Southeast.
- Asia, 19% US, 8% Western Europe, 6% Com-
munist countries
Aid: donor—ODA and OOF economic com-
manent a(C) 83), $35.6 billion
Budget: ‘revenues, $216 billion; expendi-
tures, $270 billion; deficit, $54 billion (pro-
posed general account for fiscal year ending
March 1987)
Monetary conversion rate: 198.5 yen=US$1
(2 January 1986)
Fiscal year: 1 April-81 March
inn Se@
Guilt of °
. Thailand
See regional map IX
Land
329,707 km?; the size of New Mexico; 50% °
forest; 14% Ae nee 36% urban, inland’
water, and other
Land boundaries: 4,562 km.
Water
Limits of territorial waters (claimed): 12°
nm (200 nm exclusive economic zone)
Coastline:''3,444 km (excluding islands) _<
GNP: $18.1 billion, $300 per capita (1984) at
official exchange rates of 12.1 dong=US$1
Natural resources: phosphates, coal, manga-
nese, bauxite, apatite, chromate, possible
offshore oil deposits, forests
Agriculture: main crops—rice, rubber,
fruits and vegetables; some corn, manioc,
sugarcane; major food imports—wheat,
corn, dairy products... ~
Fishing: catch 539,000 metric tons (1984)
Major industries: food processing, textiles;
machinebuilding, mining, cement, chemical
fertilizer, glass, tires
Shortages: foodgrains, petroleum, capital
goods and machinery, fertilizer
Electric power: 1,800,000 kW capacity
(1985); 5 billion kWh produced (1985), 88
kWh per capita ,
Exports: $768 million (1984); agricultural
and handicraft products, coal, minerals, ores
Imports: $1,823 million (1984); petroleum,
steel products, railroad equipment, chemi-
cals, medicines, raw cotton, fertilizer, grain
Major trade partners: exports—USSR, East -
European countries, Japan, other Asian mar-
kets; imports—USSR; East Europe, Japan
Aid: accurate data on aid since April 1975
unification unavailable; estimated afinual _
economic aid on annual basis is—USSR,
$600 million or more; East European coun-
tries, $150 million; non-Communist coun-
tries, $50 million; international institutions,
$50 million; value of military aid deliveries
since 1975 not available
Monetary conversion rate: 12.1 dong=US$1
(June 1985)
Fiscal year: calendar year','8a5d5c569c21d8d5863c569c25d132bdd570c7aeb7da138247a173caaa5edf5e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b37914c5741474ca67736d9253ec7a034e55233233aff7d0880577bb65f0ffe',1986,'CX','Christmas Island','economy',114,'National resources: phosphates
Major industries: phosphate extraction
(near depletion)
Electric power: 11,000 kW capacity (1985);
38 million kWh produced (1985), 12,900
kWh per capita
Exports: about 1.2 million metric tons of
phosphate exported to Australia, New
Zealand, and other Asian | nations
Major trade partners: Australia, New
Zealand
Monetarsy conversion rate: 1.44 Australian
dollar=US$1 (6 February 1986)
Fiscal year: 1 July-30 June
GNP: $29 billion (1985 est).; $1,430 per cap-
ita (1984); 73% private consumption, 19% -
gross investment, 12% public consumption
(1983); growth rate 2% (1985) ;
Natural resources: petroleum, natural gas,
coal, iron ore, nickel, gold, copper, emeralds’
Agriculture: main crops—coffee, rice, corn,
sugarcane, plantains, bananas, cotton, to-
bacco; an illegal producer of coca and can-
nabis for the international drug trade
Fishing: catch 57,537 metric tons 1983:
Major industries: textiles, food processing,
clothing and footwear, beverages, chemicals,
metal products, cement; mining—gold, coal,
emeralds, iron, nickel
Crude steel: 300, 000 maekne tons produced
(1984);. 10 ms per capita a
Electric power: 7,160,000 kW capacity
(1985); 25.5 billion kWh produced (1985),
864 kWh per capita
Exports: $3.5 billion (f.0.b., 1984); coffee,
coal, fuel oil, cotton, tobacco, sugar, textiles,
cattle and hides, bananas, fresh cut flowers
Imports: $4.5 billion (c.i.f., 1984); transpor- "
tation equipment, machinery, industrial
metals and raw materials, chemicals and
pharmaceuticals, fuels, fertilizers, paper and
paper products, foodstuffs, beverages
Major trade partners: exports—34% US,
15% FRG, 6% Venezuela, 4% Netherlands,
4% Japan, 3% Italy; imports—35% US, 10%
Japan, 8% FRG, 7% Venezuela, 4% Brazil, ~
4% Netherland Antilles, 3% France, 3% ©
Ecuador (1984)
Budget: (1985 est.) revenues, $4.1 billion;
expenditures, $4.8 billion
Monetary conversion rate: 164. 58 pesos=
US$1 Deen 1985)
Fiscal year: calendar year','a5b196cd1ea576aa805eb05abc5ada6b145c7543799ba3452d824c1112bd80b9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccdc9382cee96d10c002ab4713ccedcad4d608a6ac516da472962c076a7ea4ca',1986,'KM','Comoros','economy',118,'GNP: $92 million (1984 prov. ), about $250
per capita
Agriculture: food érops—rice, manioc,
maize, fruits, vegetables, coconuts, cinna-
mon, yams; export crops—essential oils for
perfumes (mainly ylang-ylang), vanilla,
copra, cloves
Major industry: perfume distillation
Electric power: 5,500 kW capacity (1985); 9
million kWh produced (1985), 22 kWh per’
capita
55
Exports: $16 million (f.0.b., 1984 prov.); per- ~
fume oils, vanilla, copra, cloves. hte
Imports: $27 million (f.0.b., 1984 prov.); rice :
and other foodstuffs, cement, fuels, chemi- te
cals, textiles ,
Major trade partriers: exports—France,
FRG, US; imports—France, Kenya,
Reunion
Budget: (1984) domestic revenue, $11 mil-. ..
lion; external grants, $29 million; current : ._..
expenditures, $14 million; capital expendi- ds
tures, $7 million; extrabudgetary expendi-_
tures,: $44 million.
Monetary conversion rate: 475 Commu-
nauté Financiére Africaine (CFA)
francs=US$1 (1985)','05a713c164a68e8f298630e4628deedcd6890ddc082ff146277b6884a4950126','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22568f4e80554d301983c7546c9fc7e7ffaa8403af47611bc47241de8f459730',1986,'GN','Guinea','economy',122,'GDP: about. $1. 8 billion (1984), $1, 1401 per. :
capita; real growth.rate 2.5% per year
(1984); 80% of economy is.private sector,
predominantly French owned and operated
Natural resources: petroleum, wood, potash,
lead, zinc, uranium, phosphates, natural gas
Agriculture: cash crops—sugarcane, wood,
coffee, cocoa, palm kernels; peanuts,
tobacco; food crops—root crops, rice, corn,
bananas, manioc, fish :
Fishing: catch 31,926 metric tons (1982)...
Major industries: crude oil, cement, saw-
mills, brewery, cigarettes, sugar mill; soap
Electric power: 175, 000 kW capacity (1985);
306 million kWh.produced eee 170kWh
per capita :
Exports: $1.3 billion (ob, 1984) oil es
lumber, tobacco, veneer, plywood, coffee,
cocoa
Imports: $618 million (f.0.b., 1984); machin-
ery, transport equipment, manufactured
consumer goods, iron and steel, foodstuffs, _
chemical products, sugar ©
Major trade partners: France, other EC
countries, US
Budget: (1984) revenues, $721 million; cur-
rent expenditures, $508 million; develop-
ment expenditures, $241 million
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
M onetary conversion rate: 475 Commu-
riauté Financiére Africaine (CFA)
francs=US$1 (1985)
Fiscal year: calendar year
GNP: $75 million (1983); $420 per capita;
economy destroyed during regime of foamer
President Masie Nguema :
Natural resources: timber, petroleum min-
erals, agriculture ; :
Agriculture: major cash crops—Rio Muni,
timber, coffee; Bioko, cocoa; main food
products—rice, yams, cassava, bananas, oil
palm nuts, manioc, livestock
Major industries: fishing, sawmilling
Electric power: (including Rio Muni and -
Fernando Po) 10,000 kW capacity (1985); 17.
million kWh produced ae 50kWh per
an :
Exports: $16.9 Nailea (1982 est.); cocoa,
coffee, weed
Imports: $41.5 million ee est. % foodstuffs,
chemicals and chemical products, textiles
Major trade partner: Spain
Budget: (1976) receipts, $2.8 million
Monetary conversion rate: ekuele replaced
by Communauté Financiére Africaine
(CFA) franc in 1985; 475 CFA francs=US$1
(1985) :
Fiscal year: calendar year-
GNP: $163.7 billion (1984), $9, 800 per cap-
ita; 1984 growth rate 8. 0%
Natural resources: lignite coal, potash, ura-__
nium, copper, natural gas
Agriculture: food deficit area; main crops—
potatoes, rye, wheat, barley, cats es
Fishing: catch 299,463 netric tons 1984)
Major industries: inetal fabrication, chemi-
cals, light industry, brown coal, shipbuilding
Shortages: grain, vegetables, vegetable oil,
beef, coking coal, coke, crude oil, rolled steel
products, nonferrous metals _
Crude steel: 7.6 million metric tons pro-
duced (1984), approx. 455 ke per capita
(1984) | .
Electric power: (including East Berlin) |
23,240,000 kW capacity (1985); 114.7 billion |
kWh produced (1985), 6,870 kWh per capita
Exports: $25.18 billion, est. (f.0.b.; 1984) ~
Imports: $22.97 billion, est. (f.0,b., 1984)
Major trade partners: 65.7% Socialist coun-
tries, 29.6% developed West, 4.7% less devel-
oped countries
Monetary conversion rate: 2.45
ostmarks=US$1 (January 1986)
Fiscal year: same as calendar year
GNP: $616.1 billion (1984), $10,670 per cap-
ita (1982); 56.3% private consumption,
20.2% investment, 20% public consumption,
0.6% inventory change, 2.9% net foreign
balance; real growth rate''2.7%
Natural resources: iron, coal, potash
Agriculture: main crops—grains, potatoes,
sugar beets; 75% self-sufficient
Fishing: catch 293,170 metric tons, $112.1
million (1984); exports $192 million, anor
$589 million (1984)
Major industries: among world’s largest
producers of iron, stéel, coal, cement, chemi-
cals, machinery, ships, vehicles, machine
tools
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Germany, Federal
Republic of (continued)
Shortages: fats and oils, pulses, tropical
products, sugar, cotton, wool, rubber, petro-
leum, iron ore, bauxite, nonferrous metals,
sulfur
___ Crude steel: 60 million metric tons capacity
- (est.); 39.4 million metric tons produced
(1984), 645 kg per capita
Electric power: (including West Berlin)
96,228,000 kW capacity (1985); 401.94 bil-
lion kWh produced (1985), 6,595 kWh per
capita
Exports: $171 billion (f.0.b., 1984), manufac-
- tures 85.2% (including machines and mia-
chine tools, chemicals, motor vehicles, iron
and steel products), agricultural products
5.5%, fuels 3.2%, raw materials 2.8%, other
3.2%
Imports: $153 billion (c.i.f., 1984); manufac-
tures 55.9%, fuels 20.4%, agricultural prod-
ucts 12.2%, raw materials 8.7%, other 2.8%
Major trade partners: (1984) EC 47.8%
(France 11.6%, Netherlands 10.3%, UK 8%,
Italy 7.8%, Belgium-Luxembourg 6.8%),
other Europe 16.7%, less developed coun-
tries 14.5%, US 8.4%, Communist 6.5%,
OPEC 5.7% ;
Aid: donor—ODA and OOF economic aid
commitments (1970-83), $41.1 billion
Budget: (1984) federal government expendi-
tures, $89 billion; revenues, $57 billion; def-
icit, $10 billion
Monetary conversion rate: 2.64 marks=
US$1 (October 1985)
Fiscal year: calendar year
GDP: $1.546 billion (1984), $300 per capita;
real growth rate 1.3% (1984 est:)
Natural resources: bauxite, iron ore, dia-
monds, gold, uranium, hydroelectric power,
fish
Agriculture: cash crops—coffee, bananas,
palm products, peanuts, citrus fruits, pine-
apples; staple food crops—cassava, rice, mil-
let, corn, sweet potatoes; livestock raised in *
some areas , ;
Major industries: bauxite mining, alumina,
diamond mining, light manufacturing and
processing industries
Electric power: 100,600 kW capacity (1985);
220 million kWh produced (1985), 38 kWh
per capita .
Exports: $537 million (f.0.b., 1984 est.);
bauxite, alumina, diamonds, coffee, pine-
apples, bananas, palm kernels
Imports: $403 million (f.0.b., 1984 est.); pe-
troleum products, metals, machinery and |
transport equipment, foodstuffs, textiles
Major trade partners: imports—France,
USSR, US; exports—US, USSR, France,
Spain ‘
Budget: (1983) public revenues, $444 mil-
lion; current expenditures, $330. million;
development expenditures, $104 million
Monetary conversion rate: 25. 1 sylis=US$1
(December 1984)
Fiscal year: calendar year
GDP; $154 riifilion (FY83), $180 per capita,
real growth rate —5.1% (1983)
Natural resources: potential petroleum;
bauxite, phosphates
Agriculture: main crops—rice, palm prod-
ucts, root crops, coconuts, peanuts, wood
Fishing: catch 6,000 metric ton (1983) |
Major industries: agricultural processing,
beer, soft drinks
Electric power: 22,200 kW capacity (1985);
38 million kWh produced (1985), 44 AW Ti
per capita
Exports: $8. 6 million (1983); principally
peanuts; also palm kernels, shrimp, fish,
lumber ei
Imports: $57.1 million (1983); foodstuffs,
manufactured goods, fuels, transport equip-
ment
Major trade partners: mostly Portugal,
Spain, and other European countries
Budget: (1983 est.) revenues, $12.2 million;
current expenditures, $27.4.million; invest-
ment expenditures, $27.9 million ‘
Monetary conversion rate: 83.528 Guinea
Bissauan pesos=US$1 (November. 1984) -
Fiscal year: calendar year
GDP: $30 million (1981 est. ‘per capita in-
come $260 (1983 est.); average annual
growth rate — 10% (1981 est.); average infla-
tion rate 10% (1981). .. Be :
Natural resources: agricultural products,
fish
Agriculture: cash crops—cocoa; copra, coco-
nuts, coffee, palm oil, bananas’
Fishing: catch 4,050 metric tons ( 1)
Major industries: light construction, shirts,
soap, beer, fisheries, shrimp processing
Electric power: 4,300 kW capacity ty (1985); 7
million kWh produced (1985), 67 kWh per.
capita
Exports: $8.8 million «. o.b., 1981 est.);
mainly cocoa a0), copra (7%), coffee, palm
oil
Imports: $20. O million (f. 0. b., 1981 est.); .
food products, machinery and electrical
equipment, fuels _
Major trade partners: main partner Nether-.
lands, followed by Portugal, US, and FRG .
Aid; economic. commitments— Western
(non-US) countries,,ODA and OOF
(1970-81), $583 million; US (FY77-84), $93.7
million; Communist countries (1970- 84), $23
million
Budget: (1981 est.) central government bud-
get $22.0 million; (1979 est.) revenues, $15.7
million; current expenditures, $10.4 million;
capital expenditures, $9.1 million.
Monetary conversion rate: 46. 2051
dobras= pe Demir page
F ‘edt year: s eleidak year','b4dd8701c23c9bfdc30a06e857d05b41696426f0c3890eec90759c6e637e5373','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c34e63546673c0625de63b6d79d40b0070aca2117129de2fd92242798ae6b5a0',1986,'CK','Cook Islands','economy',126,'GDP: $15.4 million (1977), $860 per capita ©
(1978) ar
Agriculture: export crops include copra,
citrus fruits, pineapples, tomatoes, and ba-
nanas, with subsistence crops of yams and
taro
Major industry: fruit processing, tourism
Electric power: 4,750 kW capacity rigae
15 million kWh Bence (1985), 840 kWh
per capita . ;
Exports: $3.0 million (1977); copra, fresh.
and canned fruit
Imports: $16.8 million (1977), foodstfts
textiles, fuels :
Major trade partners: (1970) exports—98%
New Zealand; imports—76% New Zealand,
7% Japan
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Cook Islands (continued) -
Aid: Australia (1980-83), $2.0 million; Aus-.
tralia and New Zealand ee $6.5 million
Government hiteek $121 saillion gr.
Monetary conversion rate: 1:88 New
Zealand$=US$1 (5 February 1986)','992415c13c7c3bdc20ecf8da83732c0e9ae46a20c255b895676dd168eb5c64f9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6267b8be8af1264fecd151b6f453849c054c71a8796e71a0153fa8eb254bfcad',1986,'CR','Costa Rica','economy',130,'GDP: $3.4 billion (1984 est.);-$1;280 per cap-
ita; 62% private consumption, 16% public -
consumption, 23% gross domestic invest-
ment, —1% net foreign balance; 6% real -
growth rate 0964): i
Natural resources: iaieelotte power
Agriculture: main products—coffée, ba- °°’
nanas, sugarcane, rice, corn, cocoa, livestock
products; an illegal producer of cannabis for
the international ae trade AG
F ishing: atch 10,902 metric tons 0982)
Major aduithes: ‘feed processing, textiles c
and clothing, construction materials; fertil-~.
izer. : ,
Electric power: 820,000 kW capacity (1985);
2.8 billion kWh produced poet 1 055 kWh
per capita
Exports: $956 ‘million (£. ob., 1984); eoffee,.
bananas, beef, Sugar, cocoa.
Imports: $1,101 million (c.i-f., 1984); manu- «4:
factured''products, machinery, transporta-
tion equipment, chemicals, fuels, foodstuffs,
fertilizer adh ther’ A a
Major trade partners: exports—47% US,
18% CACM, 9% FRG; imports—40%. US,
12% Japan, 11% CACM, 4% FRG (1983)
Aid: economic bilateral commitments—US--
authorized (FY70-84), including Ex-Im,
$603 million, other Western countries ODA
and OOF (1970-83), $333 million, Commu-
nist countries (1971-84); $27 million; mili-
tary commitments US ee 84), — mile
lion
Budget: consolidated public sector (1983)
$1,009 milliori total revenues; total expendi- “
tures including debt amortization, $1, 058
million
Monetary conversion rate: 54. a
colones=US$1 (December 1985)
Fiscal year: calendar year
Gatainunieations® aaa
Railroads: 800 km total, all 1. 067- meter ae
gauge; 243 km electrified °
Hise: 15, 400 ia total; 7,030 ia ped.
7,010 km gravel, 1,360 km unuavioved
earth
Inland waterways: ‘about 730 km; seasonally
navigable ° :
59
Pipelines: fies oa 95 km
Ports: 1 major (Limén), 4 eacaes
(Caldera, Golfito, Moin, Puntarenas)
'' Civil air: gmEior tiarisport ancl.
Airfields: 221 fotal, 212 able: 28 with
permanent- -surface runways; 1 withrun-: .- ~
ways 2,440-3,659 m; 9 with runways
1,220-2,439 m
ielcosldanaiones very. oe Geaeens :
telephone service; 292,000 telephones (11.8 -
per 100 popl.); connection into Central
American microwave net; 62''AM stations, .
17 TV stations; 1 Atlantic Ocean satellite
station
Defense Forces: : bs
Branches: Civil Guard, Rural Assistance
Guard :
Military manpower: males.15-49, 727,000.
494,000 fit for military service; about 33,000
reach military age’ nee
Supply: Paes on imports from US -
Military budget: for fiscal year ending 31
December 1985, $17.0 million for Ministry
of Public Security, including the Civil
Guard; about 3.0% of total central govern-
ment budget; $19.5 million for Ministry of
Government and Police; 3.4% of total cen-
tral government budget
Declassified and Approved For Release 2012/08/29 - CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','f7e5eb1be31786d518ffa5f3a6897a55a6bfcb1da9647ac6e00b763234fae9d3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dd88922dd114224597e304089be4264ec9dcf199928533a363f75410811e9e5',1986,'CU','Cuba','economy',131,'300 km
Straits
of Florida
HAVAN North Atlantic
Ocean
Isla de la
Juventud
ago
Caribbean Sea de Cuba
See regional map IIE
Land
114,471 km?; nearly as large as Pennsylva-
nia; 35% cultivated; 30% meadow and pas-
ture; 20% waste, urban, or other; 15% forest
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 3,735 km
GNP: $14.9 billig i in 1974 dois (1982 ©
est.); $1,530 per capita in 1974 dollars (1982 -
est.); real growth rate 1.4% (1982 est.) .
Natural resources: cobalt, nickel, iron, cop-
pér, manganese, salt, forests
Agriculture: main crops—sugar, tobacco,
rice, potatoes, tubers, citrus fruits, coffee
Fishing: catch 198,400 metric tons (1984);
exports $102 million (1984 est.) -
Major industries: sugar milling, petroleum
refining, food and tobacco processing, tex-
tiles, chemicals, paper and wood Braducts
metals, cement
Shortages: spare parts for transportation and
industrial machinery, consumer goods
Crude steel: 338,200 metric tons prodticed
(1984); 34 kg per capita
Electric power: 3,461,000 kW capacity
(1985); 12.915 billion kWh produced (1985),
1,278 kWh per capita :
Exports: $6.2 billion (f.0.b., 1984); sugar,
nickel, shellfish, tobacco, coffee, citrus
Imports: $8.1 billion (c.i-f., 1984); capital
goods, industrial raw materials, food, petro-
leum
Major trade partners: exports—72% USSR,
17%-other Communist countries; imports—
66% USSR, 18% other Sonmnunist countries
ned)
Aid: from US (FY46-61), $41.5 million (loans
$37.5 million, grants $4.0 million); economic
aid from USSR (1961-84), $10.6 billion in
economic credit and $27.0 billion in subsi- .
dies; military assistance from the USSR
(1959-78), $1.6 billion
Budget: $12.1 billion (1984).
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
M onetary conversion rate: 0.9346
peso=US$1 (80 March 1985) °
Fiscal year: calendar year','d5845d89032d1580f7f453baa00083103fab2f4667d5c6da06f0f0d87b63cdc9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2c9bef902b9ad262c7b8cfeeef4a8c3c971ad08a1d6c243639e700f02626a1e',1986,'DJ','Djibouti','economy',143,'GDP: $369 million (1983); per capita income
$1,168 (1983)
Natural resources: none
Agriculture: livestock; limited commercial.
crops, including fruit and vegetables
Major industries: transit trade, port, rail-
way, services; live cattle and sheep exports to
Saudi Arabia; secondary services to French |','7595e0d5a0ca42a6fe59305b9ba682abca1f0b92c77d753da0cb21b920b68ece','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f660e6a48207e9ff660195d240662ff7ee7c8299d12952864b52df06cdb5ec94',1986,'DM','Dominica','economy',148,'GNP: $85.4 million (prelim.), $1,034 per
capita; 1984 real growth rate 4.3% (1984)
Natural resources: timber ~
Agriculture: ananas citrus, coconuts, co-
coa, essential oils
Major industries: agricultural processing,
tourism, soap and other coconut-based prod-
ucts, cigars
Electric power: 7,000 kW capacity ( 1985);
16 million kWh pipeuces Ee 216 kWh
per capita
Exports: $25.6 million (f.0.b., 1984 prelim.);
bananas, coconuts, lime j juice and oil, cocoa’, |
reexports :
Imports: $55.8 million (c.i.f., 1984 prelim.); ”
machinery and equipment, foodstuffs, man-
ufactured articles, cement’
Major trade partners: (1984) exports—46%.
UK, 16% Jamaica, 15% Trinidad and To-
bago, 2% US, 0.3% other EC; imports—27%
US, 138% UK, 8% Trinidad and Tobago, 6%
other EC
Aid: economic—bilateral ODA and OOF ™
(1970-80), from Western (non-US) countries,
$22.6 million; no military aid
Budget: revenues, $33.4 million; expendi-
tures, $38.5 million KEYS!) ”
M jibtiny conversion rate: 2.70 East Carib-
bean days US$1 Peony aed
Fiscal sh year: lJ ay 30 0 une','bcb1c128a1230c655506483baaacebb3cb9e27b8f7b2b6165a26ada8999ba903','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bc9a2f37324fc2eb1c4eb46483a8be090eef1e09cfff8b401d8131ebea81a48',1986,'DO','Dominican Republic','economy',152,'GNP: $11.0 billion (1984 prelim.), $1,090
per capita; real GDP growth 1.0% (1984)
Natural resources: nickel, bauxite, gold,
silver
Agriculture: main crops—sugarcane, coffee,
cocoa, tobacco, rice, corn.
Major industries: tourism, sugar processing,
nickel mining, gold mining, textiles, cement
Electric power: 1,439,000 kW capacity
(1985); 3.286 billion kWh produced (1985),
497 kWh per capita
Exports: $866 million (f.0.b., 1984); sugar,
nickel, coffee, tobacco, cocoa, gold, silver
Imports: $1.4 billion (f.0-b., 1984); food-
stuffs, petroleum, industrial raw materials,
capital equipment
Major trade partners: exports—77% US,
including Puerto Rico (1984 prelim.); im-
ports—45% US, ancliding Puerto Rico
(1980)
Aid: economic—US economic
commitments, including Ex-Im (FY70- 84),
from US, $598 million; ODA and OOF from
other Western countries (1970-83), $289 mil-
lion; military authorized from US (1970- 84),
$40 million
Budget: revenues, $1.2 billion; expenditures,
$1.3 million (1984)
M onetary conversion rate: 8 pesos=US$1
(September 1985)
Fiscal year: calendar year','1c72a39173422ad376bc0dbb0bc9164a632663bc8fdd63a333dbec90579a9598','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b0671f63b1d88eabd53faba41c96213851578eb6d92fb8a89203965909b1c52',1986,'EC','Ecuador','economy',156,'GNP: $9.9 billion (1984), $1, 165 per capita:
60% private consumption, 21% gross invest-
ment, 12% public consumption, 7% foreign
(1984); average annual growth rate 2.7%
(1978-84)
Natural resources: petroleum, fish, timber
70
Agriculture: main crops—bananas, coffee,
cocoa, sugarcane, corn, potatoes, rice; an
illegal producer of coca for the international
drug trade
Fishing: catch 307,300 metric tons (1983);
exports $219.3 million (1984), imports negli-
gible
Major industries: food processing, textiles,
chemicals, fishing, petroleum
Electric power: 1,700,000 kW capacity
(1985); 3.575 billion kWh produced (1985),
380 kWh per capita
Exports: $2.6 billion (f.0.b., 1984); petro-
leum, fish products, coffee, bananas, cocoa
Imports: $1.6 billion (f.0.b., 1984); agricul-
tural and industrial machinery, industrial
raw materials, building supplies, chemical
products, transportation and communica-
tion equipment
Major trade partners: exports (1984)—64%
US, 13% Latin America and Caribbean, 3%
EC, 1% Japan; imports (1984)—36% US,
22% Latin America and Caribbean, 21% EC,
7% Japan (1984) ,
Aid: economic—Western (non-US) ODA
and OOF commitments (1970-83), $589 mil-
lion; US economic (FY70-84), $279; Com-
munist countries (1970-84), $51 million; mil-
itary—US (FY70-84) $64 million
Budget: (1984) revenues, $1,088 million;
expenditures, $1,140 million
M onetary conversion rate: 110 sucres=
US$1 (31 January 1986)
Fiscal year: calendar year','4d376a968b2f4f8ffbd6c2552d1c3a5cd2b9ebfac463bb766b09fec5cfb7121d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a86ddd2a82fdb3fc5eb5f0e37923d641ce271c89b4cc6f6ac5f122d24b7c6cf8',1986,'EG','Egypt','economy',160,'GNP: $39.7 billion (1984; based on flexible
bank exchange rate of 1.23 Egyptian
pounds=US$1), $466 per capita; 5% real _
growth (1984) °
Natural resources: petroleum, natural gas,
iron ore, phosphates, manganese, limestone,
gypsum, talc, asbestos, lead, zinc
Agriculture: main cash crop—cotton; other
crops—rice, onions, béanis, citrus fruit,
wheat, corn, barley; not self-sufficient in
food
Major industries: textiles, food processing,
chemicals, petroleum, construction, cement
Electric power: 6,836,000 kW capacity
(1984); 35.931 billion kWh produced (1984),
730 kWh per capita
Exports: $3.7 billion (f.0.b., 1985 est.);crude -
petroleum, raw cotton, cotton yarn and fab-
ric we :
Imports: $10.1 billion (c.i.f., 1985 est.); food-
stuffs, machinery and equipment, fertilizers,
woods
Major trade partners: US, EC countries
Monetary conversion rate: official rate 0.70.
Egyptian pound=US$]; flexible “bank” rate
- 2.35 Egyptian pounds=US$1; parallel or
“own” exchange market rate 1.80 Egyptian
pounds=US$1 (December 1985)
Fiscal year: July through June','37d38dbd253d4356676e8c31bd817cc1108b0b11faacee97d7b78b9b3ff0c1b8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b667e4797d3d930347aa4e468c9bd572731363ba66eba2f739aa4058665c205c',1986,'LY','Libya','economy',164,'GDP: $4.36 billion (1985 est.), $880 per cap-
ita
Natural resources: hydroelectric and geo-
thermal power
Agriculture: main crops—coffee, cotton,,
corn, sugar, beans, rice, sorghum, wheat
Fishing: catch 10,500 metric tons (1984 pre-
lim.)
Major industries: food processing, textiles,
clothing, petroleum products
Electric power: 700,000 kW capacity (1985),
1.5 billion kWh produced (1985), 300 kWh
per capita
Exports: $760.8 million (f.0.b., 1984); coffee,
cotton, sugar, shrimp
Imports: $892 million (c.i.f., 1983); machin-
ery, intermediate goods, petroleum, con-
struction materials, fertilizers, foodstuffs
Major trade partners: exports—33% US,
15% FRG, 12% Guatemala; imports—39%
US, 18% Guatemala, 9% Mexico
Aid: economic—authorized from US, in-
cluding Ex-Im (FY70-84), $907 million;
ODA and OOF commitments by other, .
Western countries (1970-83),.$138 million;
military—from US (FY70-84), $412 million
Budget: (1983) government revenues, $502. ;
million; expenditures, $582 million
M: onetary conversion rate:-2.5 colones=
US$1 (February. 1984) . .
Fiscal year: calendar year
GDP: roughly.$26 billion (1985.est), $7, 180
per capita
Natural résources: petroleum, natural gas,
gypsum
Agriculture: main crops—wheat, barley,
olives, dates, citrus fruits, peanuts; 65% of
food is imported
Major industries: petroleum, food process-
ing, textiles, handicrafts
Electric power: 4,070,100 kW capacity
(1985); 12.478 billion kWh produced (1985),
8,325 kWh per capita
ee sit: 0 billion (f.0. es 1985); petro-
leum
Imports: $7.0 billion (f.0.b., 1985); manufac-
tures, food
Major trade partners: imports—Italy, FRG;
_ exports—Italy, FRG, Spain, France, Japan,
UK
Budget: (1985 est.) revenues, $10 billion;
expenditures, $9.9 billion, including devel-
opment expenditure of $5.7 billion
Monetary conversion rate: .2961 Libyan
dinar=US$1 (February 1984)
Fiscal year: calendar year','ded4196c74595446affdcb888a203214827b4be3c5e6bb0ee4137154677c15f0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2b72cae6721173cd67c4702aa8df5b97a09eb01d2740146b4220b321b3c4f35',1986,'ET','Ethiopia','economy',170,'GDP: $5.0 billion (1983/84 est.), $120 per
capita; real growth rate 3.7% (1983/84)
Natural resources: potash, salt, gold, copper,
platinum ;
Agriculture: main crop—coffee; also cereals,
pulses, oilseeds, meat, hides and skins
Major industries: cement, sugar refining,
cotton textiles, food processing, oil refinery
Electric power: 324,000 kW capacity (1985);
709 million kWh produced (1985), 16 kWh
per capita
Exports: $403 million (f.0.b., 1983/84 est.);
61% coffee, 10% hides and skins
Imports: $906 million (c.i.f., 1983/84)
Major trade partners: exports—US, FRG,
Djibouti, Japan, Saudi Arabia, France, Italy;
imports—USSR, Italy, FRG, Japan, UK, US
Budget: revenues and cash grants, $1.1 bil-
lion; current expenditures, $1.0 billion; de-
velopment expenditures, $467 million
(1983/84)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
\\
External debt: $1.0 billion, 1981/82; debt
service payment, $1.3 billion outstanding
(1983/84); 11.0% of exports of goods and
nonfactor services (1982/83)
Monetary conversion ‘ate: 2.07 Ethiopian
birr=US$1 (31 October 1983)
Fiscal year: 8 July-7 July
Agriculture: predominantly sheep farming ~
Major industry: wool processing
Electric power: 1,250 kW capacity (1985);
2.2 million kWh produced (1985), 1,100
kWh per capita
Exports: to UK, $5.2 million (1982); wool,
hides and skins, and other
Imports: from UK, $8.2 million (1982); food,
clothing, fuels, and machinery
Major trade partners: exports—nearly allto
the UK, some to the Netherlands and to Ja-
pan; imports—Curag¢ao, Japan, and UK
Aid: economic commitments—(1970-79)
Western (non-US) countries, ODA and OOF, ©
$24 million
Budget: revenues, $5 million (1982); ex-
penditures, $4.8 million (1982) °
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Falkland Islands (continued)
Monetary conversion rate: .833 Falkland,
Island pound=.833 pound sterling=US$1 .. ;
(December 1984)','fb713388c6a85db10ac28fd69429676279cfc80f78d19674d4bfa9c513fe724f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('264731a67d9d6b1d2129fae35fae2bdd52518142344d41f73fd49bdc3bf2a0c0',1986,'FJ','Fiji','economy',177,'GDP: $1.32 billion (1984), $1,850 per capita;
annual growth rate, —3.6% (1984)
Natural resources: timber, fish, gold, copper
Agriculture: main crops—sugar, copra, gin-
ger, rice; major deficiency, grains
Major industries: sugar refining, tourism,
gold, lumber, small industries
Electric power: 213,000 kW capacity (1985);
220 million kWh produced (1985), 314 kWh
per capita
Exports: $236 million (f.0.b., 1984); 70%
sugar; also copra
Imports: $472 million (c.i.f., 1984); 24%
manufactured goods, 20.0% machinery,
16.3% foodstuffs, 16% fuels
Major trade:partners: Australia, New
Zealand, Japan, UK, Singapore, US
Aid: economic commitments—Western
(non-US) countries (1980-82), $438 million
Budget: (1984 est.) revenues; $304 million;
expenditures, $376 million —
Monetary conversion rate: .9022 Fiji }
dollar=US$1 (80 November 1985)
Fiscal year: calendar year','fb6704b6e0520d804005683468608c915dbf5a5cae88123dc67a33067b107ac9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056a2fd0fa6002f77900c40c8a7cbe798241deb4673bd1b3bf02994bfa173228',1986,'FI','Finland','economy',180,'GNP: $50.1 billion (1984), $10,270 per cap-
ita; 54.7% private consumption, 24% gross
fixed capital formation; 19.9% government
consumption; 1.4% net exports of goods and
services; 1984 growth rate 3.0% (1980 prices)
Natural resources: forests, copper, zinc,
iron, farmland
Agriculture: animal husbandry, especially
dairying, predominates; forestry important
secondary occupation for rural population;
main crops—cereals, sugar beets, potatoes;
85% self- sufficient; shortages—food and fod-
der grains
Fishing: catch 157,100 metric tons (1983)
Major industries: include metal manufac-
turing and shipbuilding, forestry and wood
processing (pulp, paper), copper refining,
foodstuffs, textiles and clothing ©
81
Shortages: fossil fuels; idateeael raw. materi-
als, except wood and iron ore
Crude steel: 2.6 million metric tons pro-..
duced (1984), 533 kg per capita
Electric power: 12,109,000 kW capacity
(1985); 44.475 billion kWh produces wae
9,060 kWh per capita
Exports: $13.5 billion (f.0.b., re timber,
paper and pulp, ships, ndehinery, clang: -
and footwear :
Imports: $12.4 billion (c.i.f.,.1984); food-
stuffs, petroleum and petroleum products;
chemicals, transport equipment, iron and
steel, machinery, textile yarn and fabrics
Major trade partners: (1984) 36.5% EC
(11.6% FRG; 9.9% UK), 21% USSR, 12.3%
Sweden, 6.6% US
Aid: donor—ODA and OOF economic aid
commitments (1970-83), $793 million
Budget: (1984) expenditures, $14.4 billion,
revenues, $12.8 billion
Monetary conversion rate: 5.42 Finnmarks
(Fim)=US$1 (80 December 1985)
Fiscal year: calendar year
GDP: $490 billion on $8, 890 per capita: *
64% private consumption, 19% investment
(including government) 17% government
consumption; 1984 real growth rate; 176%; ~~
average annual growth rate (1975-84), 2.1%
Natural resources: “coal; iron ore, e, bauxite,
fish, forests oe
Agriculture: ‘Western: Europe’ s forernost
producer; main products—beef, dairy prod-
ucts, cereals, sugar beets, potatoes,. wine ws aties
grapes; self- sufficient for most tem/perate
zone, foodstuffs; agricultural shortages—fats
and oils, tropical produce .
Fishing: catch 784,000 metric tons (1983):
exports (includes shellfish, etc.) $297 million,
imports-$967 million (1984)
Major industries: steel, machinery and
equipment, textiles and clothing, chemicals;:. -:
automobiles, food processing, mictallurgy: 4 Bs
aircraft, electronics :
Shenades: srudé oil, natural gas, textile
fibers, most nonferrous ores, coking coal, fats _
and oils
Crude steel:19 million metric tons .
produced (1984), 347: kg per capita °
Electric power: 87,246,000 kW capacity
(1985); 332.016 billion kWh produced
(1985), 6,026 kWh per capita.
Exports: $93.2 billion (f.0.b., 1984); principal ie
items—machinery-and transportation.
equipment, chemicals, foodstuffs, agricul- -
tural products, iron and steel products: tex-
tiles and clothing
Imports: $108.6 billion (c.i.., 1984); princi- -*
pal items—crude petroleum; machinery-and’ -
equipment, agricultural products, chémi- .
cals, iron and steel products .
Major trade partners: (1984) imports—
50.4% EC, 14.6% petroleum exporting:coun: **
tries, 10.3% other West European countries,
7.7% US, 2.6% Japan, 2.5% USSR, 2.5% other’.
Communist countries; exports—48, 9% EC,
13.5% petroleum exporting countries, 11.3%:
other West European countriés, 8. 1% ‘US,:
2.1% USSR, 2% other Communist countries,
1.1% Jagan: ; a
83
Aid: donor—ODA and OOF economic aid
commitments (1970-83), $33.2 billion
Budget: (proposed for 1986) expenditures,
1,080 billion frances; revenues, 889 billion
francs; deficit, 141 billion franes
Monetary conversion rate: 7.67 French
francs=US$1 (17 December 1985)
Fiscal-year: calendar year','92e21f5586b24a692b4b48819ef7f6ed5200a9ba0562d427747ebf7fbee09c7c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('903718be1444ec71285d7522c9385571d08d68f0fb9b04947ae01a323aaefba6',1986,'GF','French Guiana','economy',185,'GNP: $120 million (1976), $1,940 per capita
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Natural resources: bauxite, timber, gold
(widely scattered), cinnabar, clay, low-grade
iron ore
Agriculture: limited vegetables for local
consumption; rice, corn, manioc, cocoa, ba-
nanas, sugar
Fishing: catch 1,430 metric tons (1988 est.)
Major industries: construction, shrimp
processing, forestry products, rum, gold
mining
Electric power: 31,000 kW capacity (1985);
138 million kWh produced (1985), 1,625
kWh per capita
Exports: $35.4 million (1981); shrimp, tim-
ber, rum, rosewood essence
Imports: $245.9 million (1981); food (grains,
processed meat), other consumer goods, pro-
ducer goods, and petroleum
Major trade partners: exports—54% US,
17% Japan, 15% France, 5% Martinique;
imports—53% France, 15% Trinidad and
Tobago, 10% US (1981)
Aid: economic—bilateral commitments,
ODA and OOF (FY70-79), from Western _
(non-US) countries, $700 million, no military
aid a
Budget: $101 million (1982)
Monetary conversion rate: 8.66 French
francs=US$1 (September 1985)’
Fiscal year: calendar year','658fcd1ba5a34787e679b450bcc62edee8cc110418702583a2c91b30c9b791c1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e5c97d7871608418fb6a3e872f42a692d8c4a75c94d6bd1fe9355e142fee38b',1986,'PF','French Polynesia','economy',189,'GDP: A$931.3 million (1980), US$6, 400 per
capita (1980)
Agriculture: main crop—coconuts
Major industries: maintenance of French
nuclear test base, tourism
Electric power: 72,000 kW capacity (1985); ss
265 million kWh produced (1885), 1,515,
kWh per capita
Exports: $21 million (1977); principal prod-..
ucts—coconut products (79%), mother-of-
pearl (14%), vanilla (1971)
Imports: $419 million (1977); principal
items—fuels, foodstuffs, equipment
Major trade partners: imports—59%
France, 14% US; exports—86% France
Aid: France $91 million (1978)
Budget: $180 million in 1979; ODA and
OOF commitments from Western (non-US _
countries)
M onetary conversion rate: 127. 05 Colonial
Francs Pacifique (CFP)= $US] (February
1984)','4d82e3259197668c7439c1701af45380de5d35ba19c58f0ca159094a902cb629','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97343b39f73a7d86244beb6f41711a5dc93bd482615912e10315c429626fd93a',1986,'GI','Gibraltar','economy',197,'Economic activity in Gibraltar centers on’ _
commerce and large British naval and air “~~
bases; nearly all trade in the well-developed
port is transit trade and port serves alsoas —
important supply depot for fuel,: water, and:
ships’ wares; recently built dockyards and“: ''
machine shops provide maintenance and |
repair services to 3,500-4,000 vessels that
call at Gibraltar each year; UK military es-
tablishments and the civil government em-’ .
ploy nearly half the insured labor force, and
a recently announced decision to close the -
Royal Navy dockyard will significantly add
to unemployment; local industry is confined
to manufacture of tobacco, roasted coffee,
ice, mineral waters, candy, beer, and canned
94
fish; some factories for manufacture of cloth-
ing are being developed; a small segment of
the local population makes its livelihood by
fishing; in recent years tourism has increased
in importance
Electric power: 60, 000 kW capacity (1985);
210 million kWh produced (1985), 7,000
kWh per capita
Exports: $47.8 million (1983); principally
reexports of tobacco, petroleum, and wine
Imports: $136.8 million (1983); principally
manufactured goods, fuels, and foodstuffs;
65% from UK
M. ajor trade partners: UK, Morocco, Portu-
gal, Netherlands
Budget: (FY82) revenues, $89 million; ex-
penditure, $84.2 million
Monetary conversion rate: .833 Gibraltar
pound=.833 pound sterling=US$1 (Decem-
ber 1984)','b2f23ee174eda38079b682752fe7e94b6f08cf870b115c097251c67245f047a6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('334e78bdad05a162acaab44fbc99f4f37a627b7fc719672eeb2c74bcbf83c233',1986,'GL','Greenland','economy',203,'GNP: included in abt of Denmark
Natural resources: zinc, iia iron ore, coal,
molybdenum, cryolite, uranium, fish
Agriculture: arable areas''largely in hay;
sheep grazing; garden produce
Fishing: catch.105,830 tons (1982); « Eepbi
$108.6 million eae Bis
Major iduiies mining, fishing, sealing |
Electric power: 84,000 kW capacity (1985);
168 million kWh: pee (1985) 3,170
kWh per capita
Exports: $168. 4 maillion (f. o.b., 1980); fish
and fish products, metallic ores and concen-
trates :
Imports: $259.4 million (c.i.f., 1980); petro- -
leum and petroleum products, machinery -
and transport equipment, food. products
Major.trade partners: (1980) Denmark
49.4%, Finland 9. 5%, FRG 8.1%, US6. ue
UK 2. 9%
Monetary conversion rate: 8.915 Danish
Kroner=US$1 (December 1985 average)
Fiscal year: calendar year','1ae79aa9b6242a1ee63a794f33e8ecbd0b47da4048d1a03d2df3dc2d007b0fbc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20dedd2a29bd4cd4d794c7509c467b8d96631c4ab0fadbf36a9e03defaaa4325',1986,'GP','Guadeloupe','economy',211,'GDP: $1.18 billion (1980), $3,760 per capita;
real growth rate 15.7% (1979-80 average)
Natural resources: scenery, cultivable land
Agriculture: sugarcane, bananas, pine-
apples, vegetables | _
roe
Major industries: ‘construction, cement,
rum, light industry, tourism
Electric power: 80,000 kW capacity (1985);
273 million kWh produced (1985), 820 kWh
per capita ,
Exports: $89.2 million (1981); bananas,
sugar,rum. .
Imports: $560 million (1981); vehicles, food-
stuffs, clothing and other consumer goods,
construction materials, petroleum products
Major trade partners: exports—88% franc
zone; imports—73% franc zone, 3% Italy
(1981)
Aid: economic—bilateral ODA and OOF
commitments (1970- 79) from Western (non-
US) countries, $2. 4 billion, no military aid
Budget: $198 million (1981) :
Monetary conversion vate; 8.66 French
francs= US$1 (September, 1985) °
Fiscal year: calendar year','a3f0961b423dc3c4ce488d65fa5901f4e58bcbe27df39eebc6f86dc31a639994','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e93ad28f30d69b36e9560bafc8af3e3f4052a7fcb0d47d5091446baf8a1a2ee',1986,'GT','Guatemala','economy',215,'GDP: $9.2 billion (1985), $1,150 per capita; |
26% commerce, 25% agriculture, 9% finan-
cial services, 7% transportation and commu-
nication, 6% government, 27% other;
average annual real growth rate (1975-80),
5.7%; real growth rate 1985, — 1.0%
Natural resources: oil, nickel, rare woods,
fish, chicle
Agriculture: main products—coffee, cotton,
corn, beans, sugarcane, bananas, livestock
Fishing: catch 4,300 metric tons (1982)
Major industries: food processing, textiles
and clothing, furniture, chemicals, nonme-
tallic minerals, metals
Electric power: 815,000 kW capacity (1985);
2.1 billion kWh produced (1985), 250 kWh
per capita
Exports: $1.1 billion (f.0.b., 1983); coffee,
cotton, sugar, bananas, meat
Imports: $1.3 billion (c:i.f., 1984); manufac-
tured products, machinery, transportation
equipment, chemicals, fuels :
Major trade partners: exports (1985)—35%
US, 17% El Salvador, 6% Honduras, 5%
Costa Rica; imports (1983)—33% US, 10% El
Salvador, 8% Netherland Antilles, 7% Mex-
ico, 7% Venezuela
Aid: economic commitments—US, includ-
ing Ex-Im (FY70-84), $325 million; from
other Western (non-US) countries, ODA and
OOF (1970-83), $6.5 billion; military—assist-
ance from US (FY70-80), $22 million
Central government budget: (1986 est.) ex-
penditures, $1.710 billion; revenues, $975
million
Monetary conversion rate: 1 quetzal=US$1
(official; December 1985); 3.30''quetzals=
US$1 (unofficial; December 1985)
Fiscal year: calendar year','2e15fbe8dec0925424a9bf4ff41716753298b3e6cb15a2bf7f8a2233a680dd94','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2da425957c68d74655145f12b6c69559a78eb993ce75331ca5d2b0e627828bf',1986,'GG','Guernsey','economy',219,'Agriculture: ptincipal crops—tomatoes and
flowers (mostly grown under glass); sweet
peppers, eggplant, plants, other vegetables
and fruit; Guernsey cattle -
Major industries: tourism, banking
Electric power: 160, 000 kW capacity ( gas
508 million kWh produced (1985), 9,585
kWh per capita
Exports: tomatoes, flowers anid ferns, sweet
peppers, eggplant, other vegetables, plants
Imports: coal, gasoline and oil
102
Major trade partners: UK (regarded as in-
ternal trade)
Budget: (1983) total revenues for Guernsey
and Alderney, 63,836 million pounds; total
expenditures for Guernsey and Alderney,
65, us auillicn pene
Monetary conversion rate: 0.833 Sound
sterling=US$1 (December 1984)
F iscal year: | January-31 December','af9d514d95f225cf55f932bdd9f4e7d5a680cbcdd7dbfaeb4224ea691faecd7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4824725085f2c642deb5edf4dd81e29a347f1fece184446d1ed66427bb1014d6',1986,'GY','Guyana','economy',223,'GNP: $399 million (1984), $510 per capita;
real growth 4.0% (1984)
Natural resources: bauxite, gold, diamonds,
hardwood timber, shrimp, fish
Agriculture: main crops—sugarcane, rice,
other food crops; food shortages—wheat
flour, cooking oil, processed meat, dairy
products
Major industries: bauxite mining, sugar and
rice milling, timber fishing (shrimp), textiles,
gold mining i
Electric power: 200,000 kW capacity (1985);
485 million kWh produced (1985), 630 kWh
per capita
Exports: $212 million (f.0.b., 1984 prelim.);
bauxite, sugar, rice, shrimp, molasses, tim-
ber, rum :
Imports: $222 million (c.i-f., 1984 prelim.);
manufactures, machinery, food, petroleum
106
Major trade partners: exports—29% UK,
17% US, 17% CARICOM, 6% Canada; im-
ports—33% CARICOM, 21% US, 11% UK,
8% Canada vie
Budget: est. revenues, $167 million; expend-
iture $366 million (1984): -
MoneneE conversion rate: G$4.15=US$1
(September 1985)
Fiscal year: calendar year','8f81cb93e493b9e972e47f84bac90476fe85b78a67851869d84e6b103a346ee4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b78ef41d87eebba3aca861a487d044b2b391449f305ca56a356f3876dd238f4',1986,'HT','Haiti','economy',227,'GNP: $1.8 billion (FY84), ‘$240 per capita;
real growth rate 1984, 2.0%
Natural resources: bauxite
Agriculture: main crops—coffee, sugarcane,
rice, corn, sorghum’
Major industries: sugar refining, textiles,
flour milling, cement manufacturing, baux-
ite mining, touristn, heh assembly indus-
tries
Electric power: 193,000 kW capacity (1985);
325 million kWh produced (1985), 56 kWh °
per capita
Exports: $167.6 million (f.0.b., 1983); man- _
gos, coffee, light industrial products, essen-
tial oils, sisal, sugar i.
Imports: ‘yo84 million (f.0.b., 1982); con-
sumer durables, foodstuffs, industrial equip-
ment, petroleum: products, construction ma-
terials ae
Major trade partners: exports—59% US;
imports—45% US (1978) ‘
Aid: economic—US commitments, includ-
ing Ex-Im (FY70-84), $363 million, ODA
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Haiti (continued)
and OOF from other Western countries
(1970-83), $362 million; military US (FY70-
84), $5 million
Budget: (1984) revenues, $283 million; ex-
penditures, $357 million
Monetary conversion rate: 5.00
gourdes=US$1 (September 1985)
Fiscal year: 1 October-30 September','1686ec9994243564be64ec8a799906d4206b3af61e0733adebf02b3cbcb02ba1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17dc53166b977ef766aa5b6bfd69e76437cda645090f21b45e329797d8264b90',1986,'HN','Honduras','economy',230,'GDP: $3.2 billion (1984), $750 per capita;
real growth rate average — 3.1% (1980-83):
real growth rate 2.8% (1984)
Natural resources: forests, gold, silver, cop-
per, lead, zinc, iron, antimony, coal, fish
Agriculture: main crops—bananas, coffee,
corn, beans, sugarcane, rice, tobacco
Fishing: catch 8,400 metric tons (1983)
Major industries: agricultural processing,
textiles, clothing, wood products
Electric power: 580,000 kW capacity (1985);
1.4 billion kWh produced (1985), 320 kWh
per capita aah a
Exports: $675 million (£.0.b.,-1983); bananas,
coffee, lumber, meat; petroleum products
Imports: $705 million (f.0.b., 1983); manu-
factured products, machinery, transporta-
tion equipment, chemicals, petroleum
Major trade partners: exports—54% US, 8%
CACM, 6% Japan, 5% FRG (1983);
imports—47% US, 11% CACM, 6% Japan,
5% Trinidad and Tobago (1983)
Aid: economic commitments—US, includ-
ing Ex-Im (FY70-84), $980 million loans;
other Western (non-US) countries, ODA and
ODF (1970-83), $333 million; OPEC ODA
commitments (1974-83), $15 million; mili-
tary—assistance from US (FY79-84), $190
million
Budget: (1983) revenues, $389 million; nes
penditures, $605 million
Monetary conversion rate: 2
lempiras=US$1 (1 January 1985)
F iscal year: calendar year','bd5e07279cb7ce599449e1ae8b9d673dba8aa96cad472c3a27ce4372b891d142','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4067193efd1285554c80467534ca1f68e406579f655a7807d69e4a810428b89',1986,'HU','Hungary','economy',237,'GNP: $77 billion in 1984 (at 1984 US dol-
lars), $7,200 per capita; 1984 growth rate,
1.3%
Natural resources: bauxite, brown coal, nat-
ural gas
Agriculture: normally self-sufficient; main
crops—corn, wheat, potatoes, sugar beets,
wine grapes
Major industries: mining, metallurgy, engi-
neering industries, processed foods, textiles,
chemicals (especially pharmaceuticals)
Shortages: metallic ores (except bauxite),
copper, high grade coal, forest products,
crude oil
Crude steel: 3.8 million metric tons pro-
duced (1984), 355 kg per capita
Electric power: 6,530,000 kW capacity
(1985); 29.315 billion kWh produced (1985),
2,754 kWh per capita:
Exports: $16.3 billion (f.0.b., 1984); 38%
fuels, raw materials, and semifinished prod-
ucts; 25% machinery and equipment; 23%
agricultural and forestry products; 14%
manufactured consumer goods
Imports: $15.6 billion (c.i-£., 1984); 67%
fuels, raw materials, and semifinished prod-
ucts; 16% machinery and equipment; 10%
manufactured consumer goods; 7% agricul-
tural and forestry products
Major trade partners: 30% USSR, 9% FRG
(1984)
Monetary conversion rate: 48.244
forints=US$1 (October 1985)
Fiscal year: calendar year
Declassified and Approved For Release 2012/08/29','63c68e91b6c172e7fe7d073e25fe74e91ec3302460bb4448238242002ded9d0f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6abb8590016af5ca376c024762973fa7563de08c141409ad52cdf085b0b0fce',1986,'IS','Iceland','economy',240,'GNP: $2.17 billion (1984), $9,040 per capita;
59% private consumption, 22% private i in-
vestment; 17% government (1981); —0.6% |
net export of goods and services (1981);
change in stockbuilding 1. 0% erento rate.
—5.5% (1988)
Natural resources: s: fish, hydroelectric and
geothermal power, diatomite .
Agriculture: cattle, sheep, dairying, hay,
potatoes, turnips
Fishing: catch, 1,519,000 (1984) metric tons;
marine product exports, $500 million (1984)
Major industries: fish processing, aluminum
smelting, diatomite production, hydroelec-
tricity - :
Shortages: grains, sugar, vegetables and
vegetable fibers, fuel, wood, minerals
Electric power: 913, 000 kW capacity (1985);
4.332 billion kWh produced (1985), 17,975
kWh per capita
Exports: $743.3 million (f.0.b., 1984); fish
and fish products, animal products, alumi-
num, diatomite
Imports: $843.8 million (c.i.f., 1984); ma-
chinery and transportation equipment, pe-
troleum, foodstuffs, textiles °
Ma jor trade partners: (1984) EC 41.8%
(FRG 11.8%, UK 10.7%, Denmark 6.2%,
. Netherlands 5.7%); US 16.9%, CEMA 10.3%,
Japan 4.2%
113
Aid: economic authorizations, including.
Ex-Im from US, $19.1 million ORD
Budget: (1984) expenditures $577.2 million;
revenues: $530. 5 million
Monetary conversion rate: 41.47 kronur=
US$1 (October 1985 average) -
Fiscal year: calendar year','8c7f75473549b37d53d32547ca118962a3fa0cc384041b97c52d70eeb030d6a0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fcc1c73e5382acd3055ba67060d4f88632f3032d43d8d96390ea21b853429f4',1986,'IN','India','economy',243,'GNP: $198 billion (FY84/ 85 at current
prices), $240 per capita; real growth 8%
(FY83/84 est. ).
Natural resources: coal, iron ore, manga-
_ nese, mica, bauxite, chromite
Agriculture: main ae other cere-
als, pulses, oilseed, cotton, jute, sugarcane,
tobacco, tea, coffee; an illegal producer of
opium poppy and cannabis for the interna-
tional drug trade ©
Fishing: catch 2.85 million metric tons. Me
(1984); exports $337 million (1982) , |
Major industries: textiles, food processing,
steel, machinery, transportation equipment,
cement, Jute manufactures
Crude steel: 10.0 million metric tons of i in- :
gots (1983)
Electric power: 43,400,000 kW capacity _
(1985); 154 billion kWh produced ( pa
202 kWh per capita
Exports: $8.8 billion (f.0.b., FY84/ 85); engi-
neering goods, textiles and clothing, tea
Imports: $13.8 billion (c.i.f., FY84/85); ma-
chinery and transport equipment, petro-.
leum, edible oils, fertilizers
Major trade partners: US, UK, USSR, Japan
Budget: (FY84/85) central government rev-
enue and capital receipts, $40 billion; dis-
bursements, $58 billion
Monetary conversion rate: 12.028
rupees=US$1 (October 1985)
Fiscal year: 1 April-31 March
Communications a
Railroads: 61,950 km total (1985); 31,750 km
1.676-meter broad gauge, 25,550 km 1.000-
meter gauge, 4,650 km narrow gauge (0.762-
meter and 0.610-meter); 12,617 km double ‘
track; 6,078 km, electrified ;
Highways: 1,633,400 km eat ir
515,300 km mainly secondary and about °—
11 18,000 km gravel, crushed stone, or earth
Inland wniennaus: 16,000 km; 2 575 km
navigable by river steamers
Pipelines: crude oil, 3,497 ia refined prod-
ucts, 1,828 km; natural gas, 260 km
Ports: 9 major, 79 minor
Civil air: 93 major transport aircraft
Airfields: 345 total, 299 usable; 192 with
permanent-surface runways; 2 with run--
ways over 3,659 m, 54 with runways 2, 440-
3,659 m, 96 with runways 1,220-2,439 m
Telecommunications: fair domestic tele- | -
phone service where available, good internal
microwave links; telegraph facilities wide-
spread; AM broadcast adequate; interna-
tional radio communications adequate; 2.6 -
million telephones (0.4 per 100 popl.); about
174 AM stations at 80 locations, 17 TV sta-
tions; domestic satellite system for commu- ;
nications and TV; submarine cable extends
to Sri Lanka ,
Defense Forces
Branches: Army, Navy, Air Forve: Coast
Guard, Paramilitary Forces.
Military manpower: males 15-49, _ ;
204,005,000; 124,477,000 fit for military
service; about 9,107, 000, reach military age
(17) annually
Military budget: for fiscal year ending 3I
March 1986; est. budget $7.1 billion; 17. 3%
of central government budget
5.','6d3b82af428526bc6db397d32b37e4c5eac7a8f5d87f2d9078061341b1cb76f8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec6f5259d758fd40595678144e9d21bada7e6e9122c1c7baa39c007cb96f18d9',1986,'ID','Indonesia','economy',244,'a eh eee)
1200 km _
Strait of
Malacca N or th
we ee ,
Rate eee
a PFimor New
5 ’ Guinea
Indian Ocean
See regional map IX
Land
2,027,087 km?; about the size of Alaska and
California parabined: consists of an archipel-
ago of more than 13,000 islands, of which
about 1,000 are inhabited; 64% forest; 24%
inland water, waste, urban, and other; 12%
small holding and estate (8.6% cultivated)
Land boundaries: 2,736 km
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 54,716 km
GNP: $90.3 billion (1985 est.), about $540
per capita; real average annual growth, 5.9%
(1980-84); real annual growth rate 3.5%
(1985 est.)
Natural resources: oil, tin, natural gas,
nickel, timber, bauxite, copper
Agriculture: subsistence food production,
and smallholder and plantation production
for export; main crops—rice, cassava, rub-
ber, copra, other tropical products; an illegal
producer of cannabis for the international
drug trade
Fishing: catch 2.2 million metric tons (1984),
shtimp exports $194 million (1984), imports
$4 million (1984)
Major industries: petroleum, textiles, min-
ing, cement, chemical fertilizer production,
timber
Electric power: (including Timor Timur and
Irian Jaya) 10,200,000 kW capacity (1985);
%
116
98.5 billion kWh produced (1985), 164 kWh
per capita
Exports: $22.2 billion (1984), petroleum and
liquefied natural gas ($15.0 billion), timber |
($1.2 billion), rubber ($0.9 billion), coffee
($0.6 billion), tin ($0.3 billion), palm oil ($0.8 |
billion), tea ($0.2 billion), copper ($0.1 bil-
lion)
Imports: $15.3 billion (1984); rice ($1.02 bil-
lion); wheat flour, wheat grains, and other
cereals and cereal products ($0.3 billion),
textiles ($0.3 billion), chemicals ($1.5 billion),
iron and steel products ($0.7 billion), ma-
chinery ($1.3 billion), transport equipment
($0.7 billion)
Major trade partners: (1984) exports—47%
Japan, 21% US, 9% Singapore; imports—
23% Japan, 18% US, 12% Singapore, 11%
Saudi Arabia, 4% FRG
Budget: (1984/85) expenditures, $17.4 bil-
lion; receipts, $14.5 billion
Monetary conversion rate: 1,125
rupiahs=US$1 (81 December 1985)
Fiscal year: 1 apne) March
GNP: $27 billion (1984 est. )
Natural resources: oil, natural gas, phos-
phates, sulfur eed
Agriculture: dates, wheat, barley, rice, live-- :
stock _
Major industry: crude petroleum.1.4 mil- *
lion b/d (1985 est.); petroleum revenues,
$11.4 billion (1985 est.)
Electric power: 6,874,800 kW capacity
(1985); 21.078 billion kWh produced catia .
1,859 kWh per capita °
aan $11.7 billion (£.0.b., 1985 est.); from
nonoil receipts, $300 million est.
Imports: $11.5 billion (£.0.b:, 1985 est.); 14% -
from Communist countries (1980)
Major trade partners: exports—France, -
Italy, Brazil, Japan, Turkey, UK, USSR;
other Communist countries; imports—FRG,:°
Japan, France, Italy, US, UK, USSR, other
Communist countries (1985)
Budget: public revenues, $13.6 billion; cur-
rent expenditures, $17.5 billion; develop- .
ment expenditures, $22.8 billion (1981 est.) :
Monetary conversion rate: .3109 Iraqi
dinar=US$1 (October 1985) .
Fiscal year: calendar year','e35e299178c31c96d63cc6b5906e4da8bf5a590fe4f6a1eb33d7d25bcadb74b2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41229a772a2770b59de5512c72c3673e2189657801ec6c4af7dcb7a86d5e5be6',1986,'IE','Ireland','economy',251,'GNP: $16.0 billion (1984), $4, 440 per capita;
64.5% consumption, 23.3% investment,
21.0% government, 2.4% inventories;-
—~ 11.0% net foreign demand: 2.4% real .
GNP (1984) ’
Natural resources: zinc, lead, natural gas,
barite, copper, gypsum, limestone, dolomite,
peat, silver
Agriculture: 70% of agricultural area used
for permanent hay and pasture; main prod-
ucts—livestock and dairy products, turnips, .-"''
barley, potatoes, sugar beets, wheat; 85%: :
self-sufficient; food shortages—grains, fruits, -
vegetables
Fishing: catch 197,000 metric tons (1983); .
exports of fish and fish products $97 million
(1982), imports of fish and fish peeducte $36.
million (1982)
Major eas food prodiicts, brewing, -
textiles and clothing, chemicals and pharma-
ceuticals, machinery and transportation. -
equipment
Crude steel: 200,000. metric ions produced;
(1984); 330,000 metric.ton capacity ( Ee.
Electric power: 4,087,000 kW nacute
(1985); 11.938 billion kWh produged ee)
8,325 Eh per capita >
Exports: $9. 64 billion (1982) foodstutts Gas. P
marily dairy products), computers, live ani- -
mals, machinery, chemicals,:clothing . ~
Imports: $9.58 billion (c.i-f., 1984); machin-
ery, petroleum and petroleum products, -
chemicals, semifinished goods, cereals
Major trade partners: exports—68.7% EC
(34.4% UK, 10.2% FRG, 8.4% France), 9.8%
US, 1.0% Communist (1984); imports—
64.6% EC (43% UK, 7.4% FRG, 4.8%
France), 16.5% US, 1:8% Communist (1984);
Budget: (1985 est.) expenditures, $7.98 bil-
lion; revenues, $6.69 billion; deficit, $1.29
billion
Monetary conversion rate: 0.8541 -Irish
pound=US$1 (October 1985)
Fiscal year: calendar year','13ef41d4ccf351ba27e9303bdb89e5922fd5152cca7bb7f33db91a8cb9492ea4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8d3552ff521bcc52349b584481b084ccabe631de6ab2cca744f34d633d28657',1986,'IT','Italy','economy',258,'GDP: $348.4 billion (1984), $6,096 per cap-
ita; 63.5% private consumption, 18.0% gross
fixed investment, 20.0% government, ,
—2.1% net foreign balance, 0.7% change in
stocks; 1984 growth rate — 2.6% (1980 con-
stant prices) ;
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
cain te Ni a ia teen ete aie
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Natural resources: mercury, potash, marble,
sulfur, dwindling natural gas reserves, fish
Agriculture: important producer of fruits
and vegetables; main crops—cereals, pota-
toes, olives; 95% self-sufficient; food short-
ages—fats, meat, fish, and eggs
Fishing: catch 478,350 metric tons (1983);
exports $94 million (1984), imports $709
million (1984)
Major industries: machinery and transpor-
tation equipment, iron and steel, chemicals,
food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 24 million metric tons
produced (1984), 420 kg per capita
Electric power: 51,868,000 kW capacity
(1985); 183.377 billion kWh produced
(1985), 3,209 kWh per capita
Exports: $73.4 billion (f.0.b., 1984); principal
items—textiles, chemicals, footwear
Imports: $84.3 billion (c.i.f., 1984); principal
items—petroleum machinery and transport
equipment, foodstuffs, ferrous and nonfer-
rous metals, wool, cotton
Major trade partners: (1981) 44% EC (16%
FRG, 13% France, 6% UK, 4% Switzerland),
18% OPEC (3% Libya), 8% US, 4% USSR,
38% Eastern Europe
Aid: donor—ODA and OOF economic aid
commitments (1970-83), $8.9 billion
Monetary conversion rate: 1,785.4
lire=US$1 (October 1985)
Fiscal year: calendar year
GDP: $6.1 billion (1984), $780 per capita
(1983); real average annual growth rate,
4.0% (1985 est.)
Natural resources: petroleum, diamonds,
manganese
Agriculture: commercial—coffee, cocoa,
wood, bananas, pineapples, palm oil; food
crops—corn, millet, yams, rice; other com-
modities—cotton, rubber, tobacco, fish .
Fishing: “catch 92,469 metric tons (1982);
exports $44.7 million na imports $71.9
million (1979)
Major industries: food and lumber process-
ing, oil refinery, automobile assembly plant,
textiles, soap, flour mill, matches, three small
shipyards, fertilizer plant, and battery fac- _
tory.
Electric power: 987,600 kW capacity (1985);
2.162 billion kWh produced (1985), 214
kWh per capita
Exports: $3.5 billion (1985 est.); cocoa (30%),
coffee (20%), tropical woods (11%), cotton,
bananas, pineapples, palm oil, cotton
Imports: $1.6 billion (1985 est.); manufac-
tured goods and semifinished products
(50%), consumer goods (40%), raw materials
and fuels (10%)
Aid: economic commitments— Western
(non-US) ODA and OOF (1970-83), $3.0
billion; US authorizations, including Ex-Im
(FY70-81), $340 million
Major trade partners: (1984) exports— :
France, Nigeria, FRG, Netherlands, US
126
Budget: (1984 est:), revenues, $1.4 billion;
current expenditures, $1.4 billion
Monetary conversion rate: 475 Commu-
nauté Financiére Africaine (CFA)
francs= US$] (1985)
Fiscal yea?: calendar year','f5ef3d99ceb9c9de601a143e326104793c4934a730a18370f24ec795892b0e73','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f8556bbbb29b0ffc359a6cff3588e3c99b976186fb2cb6d1043d6eb1d6ddc32',1986,'JM','Jamaica','economy',262,'GNP: $2.0 billion (1984), $390 per capita;
real: ‘growth rate’ 1984, 1.0% est.
Natural resources: bauxite, gypsum, lime-
stone
Agriculture: main crops—sugarcane, citrus
fruits, bananas, pimento; coconuts, coffee,
cocoa, tobacco; an illegal producer of canna-
bis for the international drug trade
Major industries: tourism, bauxite mining,
textiles, food processing, light manufactures
Electric power: 1,080,000 kW capacity
(1985); 1.8 billion kWh produced (1985), 790
kWh per capita
Exports: $706 million (f.0.b., 1984); alumina,
bauxite, sugar, bananas, citrus fruits and
fruit products; rum, cocoa *
Imports: $1.1 billion (c.i.f., 1984); fuels, ma-
chinery,''transportation and electrical equip-
ment, food, fertilizer -
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Jamaica (continued)
Major trade partners: exports—US 48%,
Canada 14%, UK 138%, Norway 3%,
imports—US 46%, Netherlands Antilles
13%, Venezuela 8%, UK 5% (1984)
Budget: revenues, $1.0 billion; expenditures,
$1.6 billion (1982)
Monetary conversion rate: 5.50 Jamaican
dollars=US$1 (December 1985)
Fiscal year: 1 April-31 March
Communications x
Railroads: 370 km, all 1.435-meter standard
gauge, single track
Highways: 18,200 km total; 12,600 km
paved, 3,200 km gravel, 2,400 km improved
eamh
pinsiince refined products, 10km
Ports: 2 major (Kingston, Montego Bay), 10
minor
Civil air: 6 major transport aircraft
Airfields: 42 total, 39 usable; 15 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 5 with runways
],220-2,439 m
Telecommunications: fully automatic do-
mestic telephone network with 127,000 tele-
phones (6.0 per 100 popl.); 2 Atlantic Ocean
INTELSAT stations; 9 AM, 13-FM, 8 TV
stations; 3 coaxial submarine cables
Defense Forces
Branches: Jamaica Defense Force (includes
Coast Guard and Air Wing)
Military manpower: males 15-49, 546,000;
403,000 fit for military service; no conscrip-
tion; 32,000 reach minimum volunteer age
(18) annually
Military budget: for fiscal year ending 31
March 1985, $22.6 million; about 2.8% of
central government budget','e9a69a3d15cd3d1ea9b1847da31f11d84c06b63cb05b7722e5d4be52fc061978','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd49b16d08e68d7678fd8e521f37c7475204d0d85ea55199ee14b93a6072c3d5',1986,'JP','Japan','economy',263,'500 km
Occupied by
Soviet Union since
1945, claimed by
Kitakyashi,¢ North
: Pacific
East Ocean','2c7716df1896350512ed58c5a9dc04754acc96d8931485e03f58c91ff67a124f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b71207e19a2461ece3b7ef621da12039f7c4b15186d43c40b695937894803af2',1986,'JE','Jersey','economy',267,'Agriculture: principal crops—potatoes, cau-
liflowers, tomatoes; dairy and cattle farming
Major industries: tourism, banking and
finance
Electric power: 50,000 kW standby capacity
(1985); ove supplied by France
Exports: 19. 8 million ‘soaids sterling (1983):
light industry, electrical manufacturing,
oe
I oth machinery and transport equip-
ment, manufactured goods, food, mineral
fuels, ehemicals
Major Hate partners: UK
Budget: (1983) revenue 143,680 million —
pounds; expenditure 1''15;902'' million pounds
130
Monetary conversion rate: 1 Jersey pound; ’
which is at par with the pound sterling; ] |.
pound sterling=US$1.42 (November 1985)
Fiscal year: 31 April-1May * -','e29abf6a9855e0a410a3fc5582bd0ece47923e998b6d686f17978ffbf48b4ce9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('864ec193ab84e53f0b686bb6f2a10574e995066f6c9f71716f386f44db63124d',1986,'JO','Jordan','economy',271,'GNP: $4.9 billion (1984), $1,900 per capita;
real growth rate (1984), 2.0%
Natural resources: phosphates, potash, shale
oil
Agriculture: main crops—vegetables, fruits, .
olive oil, wheat; not self-sufficient in many
foodstuffs ;
Major industries: phosphate mining, petro-
leum refining, cement production, light ’.
manufacturing
Electric power: 691,400 kW capacity (1985);
2.422 billion kWh produced (1985), 910 — ,
kWh per capita
Exports: $756 million (f.0.b., 1984); fruits
and vegetables, phosphates, fertilizers; Com- -
munist share 13% of total (1984) .
Imports: $2,789 million (c.i.f., 1984); crude.
oil, petroleum, textiles, capital goods, motor
vehicles, foodstuffs; Communist share. ad of
total (1984) ..
Aid: economic commitments—US, includ-
ing Ex-Im (1970-84), $1.3 billion; Western .
(non-US) countries, ODA and OOF
(1970-83), $816 million; Communist coun-
tries (1970-84), $70 million; military—US
(FY70-84), $1.2 billion; Communist coun-
tries (1970-84), $590-million; OPEG ODA
commitments (1974-83), $5.5 billion
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Jordan (continued)
Budget: (1984) total revenue, $1,836 million;
current expenditures, $1,267 million; capital
expenditures, $675 million
Monetary conversion rate: .384 Jordanian
dinar=US$1 (1984 average)
Fiscal year: calendar year','e0a8f7ae8420d42a7f43cb6ef439f325702601c0cd91bb5b8ecbac5b1aae3d4e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03eabde534b33a0e3e0d8a597034535e752ab08ac59863772517f068249c0649',1986,'KE','Kenya','economy',275,'GDP: $4.5 billion (1985), $280 per capita;
real growth rate; 3.5% (1985 est.)
Natural resources: gold, limestone, dioto-
mite, salt barytes, magnesite, feldspar, sap-
phires, fluorspar, garnets, wildlife, land
Agriculture: main cash crops—coffee, tea,
sisal, pyrethrum, cotton, livestock; food
crops—corn, wheat, sugarcane, rice, cas-
sava; largely self-sufficient in food
Major industries: small-scale consumer
goods (plastic, furniture, batteries, textiles,
soap, cigarettes, flour), agricultural process-
ing, oil refining, cement, tourism
Electric power: 550,000 kW capacity (1985);
1.686 billion kWh produced (1985), 83 kWh
per capita
Exports: $1,034 million (f.0.b., 1984); reex-
porting of petroleum products, coffee, tea,
sisal, livestock products, pyrethrum, soda
ash, wattle-bark tanning extract
Imports: $1,549 million (c.i.f., 1984); ma-
chinery, transport equipment, crude oil,
paper and paper products, iron-and steel
products, and textiles
Major trade partners: EC, Japan, Middle
East, US, Zambia, Uganda
Budget: (1982 percent of GDP) revenues
and grants 24%; total expenditure and net
lending — 28%; debt service. ee 380%
(est.)
External public debt: $2.9 billion (1982 est.);
debt service payment 23% of exports
Monetary conversion rate: 16.75 Kenya
shillings=US $1 (80 September 1985)
Fiscal year: 1 July-30 June
External debt: $225 rmillion (1983), ‘external
debt ratio 4.5% (1983)
Budget: (1983 est.) revenues, $161.5 saline
current expenditures, $164.3 million; devel-
opment expenditures, $30.6 million
Monetary conversion rate: 100.96 Roan
francs=US$1 (August 1984)
Fiscal year: calendar year -
GNP: $61.9 million (1983), $820 per capita;
4.1% real growth in 1984
Agriculture: main crops—sugar on St. Chris-
topher, cotton on Nevis
Major industries: sugar processing, tourism,
cotton, salt, copra
209
Electric power: 12,000 kW capacity (1985);
32 million kWh produced (1985), 780 kWh |
per capita
Exports: $30.6 million (1983); sugar
Imports: $47.3 million (1983); foodstuffs,
manulactires: fuel
Major trade partners: exports—50% US,
35% UK; imports—21% UK, 17% Japan,
11% US (1973)
Aid: economic—bilateral commitments, |
including Ex-Im, from Western (non-US)
countries (1970-81), $15 million; no military
aid
Badge (1982) revenues, ae million; expen-
ditures, $26 million ;
Monetary conversion rate: 2.70 East Carib-
bean dollars=US$1 (December 1985)
Natural resources: Ascension—sea: turtle’
and sooty, tern breeding ground; no minerals
Agriculture: maize, potatoes, vegetables;
timber production being developed; |
crawfishing on Tristan da Cunha
Fishing: 458, metric,ton catch (1982) =
Maj jor iadesiies crafts (furniture,
lacework, fancy mcodwerk)”
Electric power: 1, 700 kw enoHeey (1985), 8
million. kWh pomiers ee ‘428 ehh per
capita
Exports: fish (frozen skipiack, tuna, salt:
dried skipjack), handicrafts _
210
[niperis toed: drink, tobacco, fuel oils, ani-
mal feed, building materials, motor vehicles
and parts, machinery and parts (1981/82)
Major trade partners: imports—59% UK,
29% South Africa :
Aid: development aid from UK—8 million
pounds sterling (1982 est.)
Builgets revenue, 5,656,518 eens stenting:
expenditure, 5,681,933 pounds sterling
(1981/ Bay
Mgnelany conversion rate: UK currency; 1
pound sterling= US$1.235 -
Fiscal year: 1 April-31 March
Communications a
Railroads:none. °° . er)
Highways: 87 km bitumen sealed roads, 20 +.
km earth roads on St. Helena; 80 km sealed
on Ascension; 2.7 km sealed on n Tristan da
Cunha :
Ports: J amestown on St. Helena, George-
town on Ascension, and St. James Bay’
Airfields: none on St. Helena; airstrip
(Miracle Miles) near Georgetown on Ascen- ..
sion; ] permanent-surface runway
2,440-3,659 on Tristan da Cunha
Telecommunications: 1,500 radio receivers;
no television service; wireless service to
Cape Town and Ascension; telephones 310 -
(1982); coaxial cable relay point between
South Africa, Portugal, and UK at Ascension
Defense Forces
Defense is the responsibility of the United
Kingdom; United Kingdom Royal Air Force
and United States NASA bases on Ascension
Military manpower: St. Helena Constabu-
lary :
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
St. Lucia
10km
Caribbean
Sea
Caribbean
Sea
See regional map III : . Z ‘
ES TES
Land
619 km?; about one-fifth the size of Rhode
Island; 50% arable, 23% wasteland and built ..
on, 19% forest, 5% unused but potentially
productive, 3% pasture -. .
Water
Limits of territorial waters (claimed): 3n nm
(fishing 12 nm)
Coastline: 158 km
GDP: $148.1 million (1984), $1,105 per cap-
ita; 5.0% real GDP growth ee)
Natural resources: forests, Reaches minerals
(pumice), mineral springs
Agriculture: main Prien aaieren ah: eh
nuts, sugar, cocoa, spices
211
Major industries: garments, electronic com-
ponents, beverages, corrugated boxes, tour-
ism, lime processing, tropical agriculture
Shortages: food, machinery, capital goods
Electric power: 20,000 kW capacity (1985);
75 million kWh produced (1985), 615 kWh
per capita
Exports: $49.7 million (f.0.b., 1983);
bananas, cocoa
Imports: $106.8 million (c.i.f., 1983); food-
stuffs, machinery and equipment, fertilizers,
petroleum products
Major trade partners: exports—58% UK,
16% US, 24% CARICOM; imports—-37%
US, 18% UK, 17% CARICOM, 9% Trinidad
and Tobago (1984 est.)
Aid: economic—bilateral commitments, -
ODA and OOF, Western (non-US) countries
(1970-81), $34 million; no military aid
Budget: (FY84) revenues, $61 million; ex-_
penditures, $64 million
Monetary conversion rate: 2.70 East Carib-
bean dollars=US$1 (December 1985)
GNP: $88.9 million (1983), $781 per capita;
3% real growth in 1984
Agriculture: bananas, arrowroot
Major industries: food processing
212
Electric power: 16,000 kW capacity (1985);
32 million kWh produced (1985), 314 kWh
per capita
Exports: $42.0 million (f.0.b., 1983 prelim.)
bananas, arrowroot, copra
Imports: $71.4 million (c.if., 1983 prelim.);
foodstuffs, machinery and equipment,
chemicals and fertilizers, minerals and fuels
Major trade partners: exports—32% UK,
57% CARICOM, 34% Trinidad and Tobago
(1983); imports 11% UK, 33% US, 32%
CARICOM, 24% Trinidad and Tobago, 6%
Canada (1983 est.)
Aid: economic—bilateral economic commit-
ments, ODA and OOF, from Western (non-
US) countries (1970-81), $25 million; no mili-
tary aid ‘ : :
Budget: (1984) revenues, $32 million; expen-
ditures, $32 million
Monetary conversion rate: 2.70 East Carib-
bean dollars=US$1 (December 1985)','b8b2d78309580e2306ebcbcbadfe8e10709c11949c33f2234cb5c8fc517d6743','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f504f16444f325dee7302cfb9ec140567e0b6d444dae30e587c8129fcff6faf',1986,'KI','Kiribati','economy',279,'GDP: $25 million (1984 est.), $417 per eapit
Agriculture: limited; copra, sieiiencs
crops of vegetables, supplemented by do-..
mestic fishing
Industry: formerly phosphate production;
supply exhausted by mid-1981; tuna fishing -
licenses to USSR fishing fleet within
Kiribati’s 200 nm fishing zone, excluding
]2-nm territorial zone
Electric power: 2,750 kW capacity (1985); 8
million kWh produced (1985), 129 kWh per |
capita
Exports: phosphate, formerly 80% of ex-
ports, exhausted in 1981; copra accounted
for 80% (A$1.45 million) in 1982
Imports: $15 million (1979); foodstuffs, fuel,
transportation equipment
Aid: Western (non-US) commitments ODA
and OOF (1970-83), $192 million; Australia —
(1970-83), $25.7 million committed
Budget: $15.2 million (1979)
Monetary conversion rate: 1.0392
Australian$=US$1 (23 February 1983)
GNP: $23 billion (1984 i in 1984 dollar)
$1, 170 per capita ee 8 :
Natural résources: coal, lead, tungsten, zine,
graphite, magnesite, ‘iron, copper, gold, «:
phosphates, salt, uorspat, hydroeeatic
power os
Agriculture: ‘main: crops-—corn, rice, vegeta-
bles; food shiortages—meat, cooking’ oils; *
production of foodstuffs adequate for do-
mestic needs
Major industries: machine building, electric
power, chemicals, mining, metallurgy, tex-
tiles, food processing
Shortages: advanced machinery and equip-
ment, coking coal, coal, petroleum, electric
power, transport
Crude steel: 4.0 million metric tons pro-
duced (1984), 204 kg per capita
Electric power: 5,910,000 kW capacity
(1985); 40 billion kWh produced (1985),
1,992 kWh per capita
Coal: 52 million tons (1984) .
Exports: $1.59 billion (1984); minerals, met-
allurgical products, agricultural products, 3
manufactures _s
Imports: $1.36 billion (1984), petroleum,
machinery and equipment, coking coal,
grain
Major trade partners: total trade turnover
$2.95 billion (1983); 55% with Communist.
countries, 45% with non-Communist coun-:
tries -
Aid: economic and military aid from the
Soviet Union and China
Monetary conversion rate: 2 wons=US$1
(December 1984)
Fiscal year: calendar year
135
GNP: $90.1 billion (1984, in 1984 prices),
$2,000 per capita; real growth 7.5% (1984);
real growth 4.7% (1980-84 average)
Natural resources: coal (limited), tungsten, -
graphite
Agriculture: 9.0 million people (22% of the
population) live in farm households, but ag-
riculture, forestry, and fishing constitute
15% of GNP; main crops—rice, barley, veg-
etables, and legumes
Fishing: catch 2,909,811 metric tons ( 1984)
Major industries: textiles and clothing,.food °
processing, chemicals, steel, electronics, ship
building .
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Shortages: heavily dependent on imports of
iron ore, crude oil, base metals, lumber, and
certain food grains
Crude steel: 13.0 million metric tons pro-
duced (1984) ES
Electric power: 15,560,000 kW capacity
(1985); 56.49 billion kWh produced (1985),
1,325 kWh per capita ,
Exports: $29.2 billion (f.0.b., 1984); textiles
and clothing, electrical machinery, foot-
wear, steel, ships, fish
Imports: $30.6 billion (c.i.f., 1984); machin-
ery, oil, steel, transport equipment, textiles,
organic chemicals, grains
Major trade partners: exports—36% US, -
16% Japan; imports—25% Japan, 22% US
(1984) :
Aid: economic—US, including Ex-Im
(1970-83), $3.9 billion committed; Japan
(1965-75), $1.8 billion extended; military—
US (1970-84) $3.8 billion committed
Budget: planned expenditures, $15.4 billion
(1986)
Monetary conversion rate: 892 won=US$1 _
(2 January 1986)
Fiscal year: calendar year','ab65492f9bcc973867a6d7680249661a3f5d1fbd9c0dbc88ce4954c3189d9915','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fd83c3f4294b4db6bbaf8cc10b97df8faf28eaaf00c1af708ffe434ffad1498',1986,'KW','Kuwait','economy',283,'GDP: $21.8 billion (1984), $13, 620 r per cap- |
ita GNP (1984); 5% annual growth rate
(1984)
Natural resources: petroletm, fish, shrimp ~
Agriculture: virtually none; dependent on... *
imports for food; approx. 75% of-potable
water must be distilled or imported
Major industries: crude petroleum produc-
tion average for 1984, 1.1 million b/d; petro-
leum refining (capacity approximately 0.5
million b/d); other major industries include
petrochemicals, retail trade, and manufac- .
turing; water desalinization capacity 618
million liters per day (1983 prelim.)
Electric power: 5,335,300 kW capacity
(1985); 18.694 billion kWh produced (1985),
10,930 kWh per capita
Exports: $11.3 billion (f.0.b., 1985), of which
petroleum accounted for about 85%
Imports: $7.4 billion (f.0.b., 1984); major
suppliers—Japan, US; FRG, UK -
Major trading partners: exports—Japan,
US, FBG, Italy; imports—Japan, FRG, UK,
US é
Budget: (1984/85 actual) revenues, $10.6
billion; expenditures, $12.9 billion
Monetary conversion rate: .29 Kuwaiti
dinar=US$1 (October 1985)
Fiscal year: 1 July-30 June
GNP: $765 million, $220 per capita a 1984
est.)
Natural resources: tin, timber, gypsum, hy-
droelectric power
Agriculture: main crops—rice (overwhelm-
ingly dominant), corn, vegetables, tobacco,
coffee, cotton; formerly self-sufficient; food
shortages (due in part to distribution defi-
ciencies) include rice; an illegal producer of
opium poppy and cannabis for the interna-''
tional drug trade
Major industries: tin mining, timber, green
coffee, electric power
Shortages: capital equipment, petroleum, ©
transportation system, trained personnel
Electric power: 175,100 kW capacity (1985),
905 million kWh produced (1985), 250 kWh
per capita
Exports: $36 million (f.0.b., 1984 est.); elec-
tric power, forest products, tin concentrates;
coffee, undeclared exports of opium and
tobacco ,
Imports: $98 million (c.if., 1984 est.); rice’
and other foodstuffs, petroleum products,
machinery, transportation equipment
Major trade partners: imports—Thailand,
USSR, Japan, France, China, Vietnam; ex-
ports—Thailand, Malaysia
Aid: economic commitments—Western
(non-US) countries ODA.and OOF
(1970-83), $386 million; US (FY70-79), $276
million; military—US assistance $1.1 billion
(1970-75)...
Budget: (1979 est.) receipts, $100 million; —
expenditures, $191 million; deficit, $91 mil-
lion : :
Monetary conversion. rate: official—10
kips=US$1; commercial—35 kips=US$1,
inward remittances—108 kips=US$1 (De-
cember 1985) —
Fiscal year: 1 July-30 June
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Laos (continued)','47af9504d01af5c72df275e0a31312cdd9417d6eac5381dd4eea01837fc24feb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8676f7ba8157a05330172dc59007461789d85fdf1263426dacdcd594819c9c7',1986,'LB','Lebanon','economy',285,'GDP: $5.3 billion (1983 est.)
Natural resources: limestone, irori
Agriculture: fruits, wheat, corn, barley, po-
tatoes, tobacco, olives, onions; not
self-sufficient in food; an illegal producer of -
opium poppy and cannabis for the interna-
tional drug trade
Major industries: service industries, food
processing, textiles, cement, oil refining,
chemicals, some metal fabricating
141:
Electric power: 1,047,300 kW capacity
(1985); 13.761 billion kWh produced (1985),
5,254 kWh per capita
Exports: $595 million (£.0.b., 1984)
Imports: $2.7 billion (£:0.b., 1984)
Budget: (1985 est.) public revenues, $500
million; public expenditures, $1.5 billion
Monetary conversion rate: 18 Lebanese
pounds=US$1 (November 1985)
Fiscal year: calendar year','a09f2011b0247d2aabd37abdf0be64322a00e2fe42e6610beb1571f67869613f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8903b29ec685f965037c5ed03c7dffa826e7395409728bfa0bb19ca542467475',1986,'LS','Lesotho','economy',288,'GDP: $300 million rr)
Natural resources: some diamonds and
other minerals, water, asnicultural and graz-
ing land. ;
Agriculture: exceedingly primitive; mostly
subsistence farming.and livestock;-principal
crops.are corn, wheat, pulses, sorehurh, bar-
ley :
Major inauntne: none
Electric power: 1,660 kW Baaaty Abs
million kWh produce! (1985), 0.7 kWh per
capita . .
Exports: labor to South Africa pene re-
mittances $94 million est. in 1983); $29 mil-
lion (f.0.b., 1984), wool, mohair, wheat, cat-
tle, peas, beans, corn, hides, skins, tourism,
diamonds
Imports: $476 million (f.0.b., 1984); mainly
corn, building materials, clothing, vehicles,
machinery, medicines, petroleum, oil, and
lubricants
Major trade partner: South Africa; member
of Southern African Customs Union
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Budget: (FY84/85) revenues, $160. million;
current expenditures, $130 million; develop-
ment (capital) expenditures, $50 million
Monetary-conversion rate: the Lesotho |
maloti exchanges at par with the-South Afri--
can rand; 2.3 maloti=US$1 (29 January -
1986)
Fiscal year: 1 April-81 March','6ff3c90a554ac1ee45fecbbe2678fc782dd32413b5d4e35deea2ceb520162ef9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1539d230a2a549aeec0cb068c535723c6f09bf73be9947d2ee3962598b05c30',1986,'LR','Liberia','economy',292,'GDP: $1.14 billion (1984), $490 per capita;
2% real annual growth rate (1984)
Natural resources: iron ore, rubber, timber,
diamonds, gold
Agriculture: rubber, rice, oil palm, cassava,
coffee, cocoa; imports of rice, wheat, and
live cattle and beef are necessary for basic
diet
Fishing: catch 13,553 metric tons (1982)
Major industries: rubber processing, food
processing, construction materials, furni-
ture, palm oi! processing, mining (iron ore,
diamonds)
Electric power: 374,200 kW capacity (1985),
491 million kWh produced (1985), 219 kWh
per capita
Exports: $482 million (f.0.b., 1984); iron ore,
rubber, diamonds, lumber and logs, coffee,
cocoa
Imports: $366 million (c.i.f., 1984); machin-
ery, transportation equipment, petroleum
products, manufactured goods, foodstuffs
Major trade partners: US, FRG, Nether-
lands, Italy, Belgium
Aid: economic commitments— Western
(non-US), ODA and OOF (1970-83), $560
million; US authorizations (including Ex-Im)
(FY70-84), $443 million; Communist
(1970-84), $73.0 million; military commit-
ments US (FY70-84), $57 million
Budget: (FY84-85) revenues, $192 million;
current expenditures, $238 million; develop-
ment and nonbudgetary expenditures, $151
million
a
Monetary conversion rate: uses the US dol-
lar and the Liberian dollar, which trades
officially at par
Fiscal year: 1 July-30 June','86da6c21418d9d09903dffce4430d3518426ff3aed043972b183bc072f68d7e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3d42f8acd0d338dfa0fbd25479ecf64b0479e7852ad2f30f20c745cd7ced292',1986,'LU','Luxembourg','economy',299,'GNP: $4.2 billion, $11.350 per capita (1983);
53.2% private consumption, 22.4% invest-
ment, 14.6% government consumption,
—0.7% stockbuilding, 10.4% net foreign
balance; 1.6% real GDP growth (1983)
Natural resources: iron ore
Agriculture: mixed farming, dairy products,
and wine
!
Major industries: banking, iron and steel,
food processing, chemicals, metal products
and engineering, tires, and banking,
Crude steel: 3:98 million metric tons pro-
duced (1984), 10.8 metric tons per capita; 6.4
metric ton capacity (1982)
Electric power: 1,497,000 kW capacity
(1985); 956 million kWh produced (1985),
2,605 kWh per capita
Exports, imports, ma jor trade partners:
Luxembourg has a customs union with Bel-
gium under which foreign -trade is recorded
jointly for the two countries; Luxembourg’s
principal exports are iron and steel products,
principal imports are minerals, metals, food-
stuffs, and machinery; most of its foreign
trade is with FRG, Belgium, France, and
other EC countries (for totals, see Belgium)
Budget: (1984 est.) revenues, $1.18 billion;
expenditures, $1.17 billion; surplus, $0.13
million
Monetary conversion rate: 51.6 Luxem-
bourg francs=US$1 (Decembes 1985); under
the BLEU agreement, the Luxembourg
franc is equal in value to the Belgian franc,
which circulates freely in Luxembourg
Fiscal year: calendar year
GNP: $640 million (1980 est.)
Agriculture: main crops—rice, vegetables;
food shortages—rice, vegetables, meat; de-
pends mostly on imports for food require-
ments
Major industries: textiles, toys, plastic prod-
ucts, furniture
Electric power: 123,000 kW capacity (1985);
335 million kWh produced (1985), 852 kWh
per capita
Exports: $755.9 million (f.0.b., 1983); textiles
and clothing
Imports: $722.4 million (c.i.f.,1988); food-
stuffs
Major trade partners: exports—27% US,
22% Hong Kong, 12% FRG, 10% France; -
imports—39% Hong Kong, 28% China
(1983)
Budget: (1982) expenditures, $140.4 million
Monetary conversion rate: 8 patacas=US$1
(June 1985)
Fiscal year: calendar year','846cbc613629bb698c63a6720980c959c1c9e9eceeeb668042ae60e7fedd8b3d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cead7d0e75a9ca4b4ed63c02ba92b68020ead5458d6d5f7ef2391c05ab68f4d',1986,'MZ','Mozambique','economy',304,'GDP: $2.4 billion (1984), baat $250 per .
capita; real growth rate 2.1% (1984)
Natural resources: graphite, chrome, coal,
bauxite, ilmenite, tar sands, semiprecious
stones :
Agriculture: cash crops—coffee, vanilla,
cloves; sugar; tobacco, sisal, raffia; pepper:
cocoa; food crops—rice, cassava, cereals,
potatoes, corn, beans, bananas, coconuts,
and peanuts; animal husbandry widespread;
imports some rice, milk, and cereal
Fishing: catch 54,500 (1983); marketed out-
put—22,150 metric tons fish (1984 prov.);
6,695 metric tons shellfish (1984 prov.)
Major industries: agricultural processing
(meat canneries, soap factories, brewery,
tanneries, sugar refining), light consumer
goods industries (textiles, glassware), cement
plant, auto assembly plant, paper mill, oil
refinery
Electric power: 114,000 kW capacity (1985);
402 million kWh produced (1985), 40 RWh
per capita
Exports: $350 million (f.0.b., 1985 est.);
coffee, vanilla, sugar, cloves; agricultural
and livestock:products account for about
85% of export earnings
Imports: $353. million (f.0.b., 1985 est.); raw
materials, intermediate goods, foodstuffs _
Major trade partners: France, other EC,
US, Saudi Arabia; trade with Communist
countries remains. a minute part of total
trade
Budget: 1984 overall government operations
(1984)—total revenues, $420 million; cur-
rent expenditures, $300 million; capital ex-
penditures, $150 million; other expendi-
tures, $90 million
iowa debe (1984) $2.2 billion disbursed;
debt service payment 33% of exports after
rescheduling —
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Monetary conversion rate: 621.12 Malagasy
francs=US$I (October 1984) 7 to
Fiscal year: calendar year a
GNP: $2 billion (1985 eh i about $150 per
capita; average annual growth rate —1% |
(1971-84 est.) ,
Natural resources:.coal, iron ore, natural
gas, copper, heavy.minerals, bauxite, possi-
bly petroleum
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Mozambique (continued)
Agriculture: cash crops—raw cotton,
cashew nuts, sugar, tea, copra, sisal, rice;
other crops—corn, wheat, peanuts, potatoes,
beans, sorghum, cassava; imports corn and
wheat
Fishing: 18,500 metric tons (1984)
Major industries: food processing (chiefly
sugar, tea, wheat, flour, cashew kernels);
chemicals (vegetable oil,-oilcakes, soap,
paints); petroleum products; beverages; tex-
tiles; nonmetallic mineral products (cement,
glass, asbestos, cement products); tobacco
Electric power: 228,700 kW capacity (1985);
2.998 billion kWh produced (1985), 217
kWh per capita
Exports: $95 million (1984); cashews,
shrimp, sugar, tea, cotton
Imports: $539 million (1984); refined petro-
Jeum products, machinery, transportation
goods, spare parts, consumer goods
Major trade partners: exports—US, West-
erm Europe; imports—Western and Eastern
Europe
Budget: (1982) current expenditures, $500
million; revenues, $600 million
Monetary conversion rate: 43 meticais=
US$1 (January 1985)
Fiscal year: calendar year','72459b777e7afcf8b97d0122d558b7b9a25c6acca741fd52ff6e49ec547f82f1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b3d42c63f0d722f2c4394b8efd3210cfffc85c2663a22921406c272885bbe3',1986,'MW','Malawi','economy',307,'GDP: $1.34 billion Aose $210 per capita;
real growth rate 3.0% (1982)
Natural resources: limestone, uranium po-
tential
Agriculture: cash crops—tobacco, tea, sugar,
peanuts, cotton, tung oil, maize; subsistence -
crops—corn, sorghum, millet, pulses, root
crops, fruit, vegetables, rice; self-sufficient in
food production
Electric power: 174,000 kW capacity (1985);
458 million kWh produced (1985), 65 kWh
per capita
. Major industries: agricultural processing
(tea, tobacco, sugar); sawmilling, cement,
consumer goods
epee $259.9 million(c.i.f., 1984);
tobacco, tea, sugar, peanuts, cotton, corn
Imports: $308 billion (c.i.f., 1984); manufac-
tured goods, machinery and transport
equipment, building and construction mate-
rials, fuel, fertilizer
Major trade partners: exports—UK, FRG,
US, Netherlands, South Africa; imports—
Sout Africa, UK, Japan, US, FRG
Aid: economic Sranibnente Avesera
(non-US) countries, ODA and OOF
(1970-83), $1.2 billion; US authorized (FY70-
84), $55 million —
Budget: 1983 revenues $211.9 million, ex-
penditures $231.9 million
Monetary conversion rate: 1.67.Malawi
kwacha=US$1 (June 1984)
Fiscal year: 1 April-31 March','88ebfbe422d12f71f4d9a9dabea118f019aadf61ea93f4134d0c5cae7316d32c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('583b9d40a9560ed78292686945978448d598de84052630c3b38e0bb5ff6196ee',1986,'MY','Malaysia','economy',310,'GNP: $28.4 billion (1984), $1, 870 per capita;
annual growth 5.0% (1984)
Natural resources: tin, Detroleum, timber, ©
copper, iron ss
Agriculture: Peninsular Malaysia: natural
rubber, oil palm, rice; 10-15% of rice,re-
quirements imported
Sabah: mainly subsistence; main crops—
rubber, timber, coconut, rice; food deficit—
rice
Sarawak: main crops——rubber, timber, pep-
per; food deficit—rice
Fishing: catch 741,000 metric tons (1983) .
Major industries: Peninsular Malaysia:
rubber and oil palm processing and .
manufacturing, light manufacturing indus-
try, electronics, tin mining and smelting,
logging and processing timber
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum
production and refining, logging
Electric power: Peninsular Malaysia:
2,732,000 kW capacity (1985); 10.382 billion
kWh produced (1985), 808 kWh per capita
Sabah: 430,000 kW capacity (1985); 1,252
million kWh produced (1985), 1,010 kWh
-per capita
Sarawak: 350,000 kW capacity (1985); 1,019
million kWh produced (1985), 685 kWh per.
capita
Exports: $16.6 billion (£.0.b., 1984); natural
rubber, palm oil, tin, timber, petroleum,
light manufactures
Imports: $14.1 billion (c.i-f., 1984)
Major trade partners: exports—22%
Singapore, 20% Japan, 15% EC, 18% US;
imports—25% Japan, 16% US, 14% EC, 14%
Singapore (1983)
Budget: 1985 operating expenditures, $9.1
billion; development expenditures, $2.8 bil-
lion; deficit, $2.7 billion
Monetary conversion rate: 2.371
ringgits= US$1 (September 1984)
Fiscal year: calendar year','3fc8228ea9cf3aa54f35e11444ea3b25486db49a92b924fd76b015b91d6817c5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f63c83a06a108769a20445f2dfd27d10cfbe229f7dddc397636f4c87352550f',1986,'MV','Maldives','economy',313,'GDP: $74 million (1982), $462 per capita; :
real Soy rate ee 1983), 10%
Natural resources: fish
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Maldives (continued) .
Agriculture: crops—coconut, limited pro-
duction of millet, corn, pumpkins, sweet
potatoes; shortages—rice, sugar, flour.
Fishing: catch 38,500 metric tons (1983)
Major industries: fishing, tourism, some
coconut processing, garment industry, wo-
ven mats, shipping, coir (rope)
Electric power: 4,690 kW capacity (1985); 9
million kWh produced (1985), 51 kWh per
capita -
Exports: US$ 17.3 million (1982)
Imports: US$46.0 million (1982)
Major trade partners: Japan, Sri Lanka,
Thailand ©
Budget: (1983 est.) revenues, $22.7 million; ©
expenditures, $41.65 million (at official rate
of 5.50 rufiyas=US$1
Monetary conversion rate: 5.50 Maldivian
rufiyas=US$1, official rate; 7.05 Maldivian
rufiyas=US$1, market rate (August 1983)
Fiscal year: calendar year','02aa6a226733a392b322d1a0dcb86ddd04c9629ff1fb3bee54ad993f3fab74c5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bfc7a87d630051db9a711f09a2c96b367d12ade71523c1716fe1c0b7fc92cfe',1986,'ML','Mali','economy',317,'GDP: $1.0 billion (1989), $140 per capita; .
annual real growth rate 4.4% (1982)
Natural resources: gold, phosphates, kaolin,
salt, limestone; bauxite, iron ore, manganese,
lithium, and uranium deposits are known or
suspected but not exploited
Agriculture: main crops—millet, sorghum,
rice, corn, peanuts; cash crops—peanuts,
cotton, livestock
Fishing: catch 33,000 tons (1983 est.)
Major industries: small loca] consumer
goods and processing
Electric power: 92,000 kW capacity (1985);
161 million kWh produced (1985), 20 kWh
per capita
Exports: $145.8 million (f.0.b., 1982); live-
stock, peanuts, dried fish, cotton, skins
Imports: $232.6 million (f.0.b., 1982); tex-
tiles, vehicles, petroleum products, machin-
ery, sugar, cereals
Major trade partners: mostly franc zone
and Western Europe; also with USSR, China
Budget: (1982) revenues, $154 million; ex-
penditures and net lending, $169 million
Monetary conversion rate: 475 Commun-
auté Financiére Africaine (CFA) francs=
US$1 (1985)
Fiscal year: calendar year
GDP: $1.0 billion (1984), $3,010 per capita
(1984); 68.9% private consumption, 27.4%
gross investment; 17.4% government con-
sumption, ~ 15.2% net foreign sector; » -
change in stocks 1.0%; in 1984 real GDP
growth was 1.2%
Natural resources: limestone, salt
Agriculture: overall, 20% self-sufficient; gen-
erally adequate supplies of vegetables, poul-
try, milk, and pork products; seasonal or
periodic shortages in grain, animal fodder,
fruits, other basic foodstuffs; main prod-~ :
ucts—potatoes, cauliflower, grapes, wheat,
barley, tomatoes, citrus, cut flowers, green
peppers, hogs, poultry, eggs
Major industries: tourism, ship repair yard,
clothing, building industry, food manufac-
turing, textiles
Shortages: most consumer and industrial
needs (fuels and raw materials) must be im-
ported
Electric power: 157,000 kW capacity (1985); °
766 million kWh produced (1985), 2,158
kWh per capita
Exports: $398.7 million (f.0.b., 1984); cloth-
ing, textiles, ships, printed matter
Imports: $717.8 million (c.i.f., 1984)
Major trade partners: 74% EC (24% Italy,
22% FRG, 17% UK); 6% US
Budget: (1984) projects $486 million in ex-
penditures, $475 million in revenues
Monetary conversion rate: 0.43 Maltese
lira=US$1 (October 1985)
Fiscal year: | January-31 December
158
Airfields: | usable with permanent-surface |
GNP: 195 million pounds (1983 7 4); feat
services 21%, manufacturing 13.7%, tourism
10.8%, construction 10.4% (1984)
Natural resources: lead, iron
Agriculture: cereals and vegetables; cattle,
sheep, pigs, poultry
Fishing: 8,300 metric tons witha value of
170,934 pounds sterling (1983)
M ajor industries: the Isle. of Man is an im-
portant offshore financial center; financial
services, light manufacturing, tourism
Electric power; 61,000 kW capacity (1985);
185 million kWh produced (1985), 3,025
kWh per capita
Exports: tweeds, herring, processed shellfish. .
meat
Imports: timber, fertilizers, fish
Major trade partners: UK
Budget:(FY 1984/85 est.) revenues, 108,214
million pounds; expenditures, 94,949 million
pounds .
M onetary conversion rate: ] Isle of Man
pound (at par with the pound
sterling)=US$1.42 (November 1985) »
Fiscal year:.1 foul! March
Chiiminnestions. .
Railroads: 36 km electric tiiek, 24 km steam.
track
Highways; 640 km motorable roads
Ports: 3 minor (Douglas, Ramsey, Peel)
Airfields: airport at Ronaldsway
Telecommunications: radio station; 24,435
telephones
Defense Forces
Defense is the responsibility of the United
Kingdom |
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','7ee526143fcb1cbf9092564fc9c46d2aaaa7a4766e39add129f489d93f32b73d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d52658cb3a15595ca5749d3486537c230e031d110ef8a04bc126ad94f54dbade',1986,'MQ','Martinique','economy',318,'10km
_ Caribbean
~ Sea
Caribbean
: Sea
See regional map HI
: :
Land .
1,100 km?; slightly sinaller than Rhode Is-
land; 31% crop, 29% forest, 24% waste or
built on, 16% pasture
Water
Limits of territorial waters (claimed): 12
nm (200 nm exclusive economic zone)
Coastline: 290 km','ff655d86a458d91f7e399dffcdba0e00a0b9aaa27923cc916d8f739681ca078f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f7f1e9949dbfa0eef977aad3d0fb6b63d956ffead1f977b9129f7efadc4a2f4',1986,'MU','Mauritius','economy',328,'GDP: $1.0 billion (1984/85 prov.), $1,000 .
per capita; real growth rate, 4.2% (1984/85
prov.) .
Agriculture: sugar crop is a:major economic
asset; over 90% of cultivated land area is-
planted in sugar; also sugar derivatives, tea, .
tobacco; most food imported
Shortage: land
Major industries: mainly food manufactur-
ing (largely sugar milling); textiles and wear-
ing apparel; chemical and chemical prod-
ucts; and metal products, transport equip-
ment, and nonelectrical machinery
Electric power: 237,000 kW capacity (1985);
416 million kWh produced (1985), 411 kWh
per capita
Exports: $387.8 million (merchandise, fob,
1984/85 prov.); sugar (48%); Export Process-
ing Zone exports
Imports: $406 million (f.0.b., 1984/85);
food, petroleum products, manufactured
goods
163
Member of: AfDB, Commonwealth; FAO, .
Major trade partners; all EC countries and
US have preferential treatment, UK buys
almost all of Mauritius''s sugar export at sub-
sidized prices; ‘small amount of sugar ex-
ported to Canada, US, and Italy; nonoil i im-
ports from UK and EC primarily, also from
South Africa, Australia, US, and Japan, some
minor trade with China
Budget: central government—(1984/85
prov.) revenues, $217 million; external _
grants, $10 million; current expenditures,
$247 million; capital expenditures, $40 mil-
lion
Monetary conversion rate: 14.557 Maurit-
ian rupees=US$1.(31 October 1985)
Fiscal year: 1 J uly-30 June :
Aid: from France, 84 million frances (1983)
Agriculture: vanilla, ylang-ylang, coffee,
copra
Fishing: annual catch, about 2,000 tons
Major industries: newly created lobster and
shrimp industry
Exports: 5 million franes (1982);
ylang-ylang, vanilla
Imports: 116 million franes (1982); building
materials, transport equipment, rice, cloth-
ing, flour
Major trade partners: imports—France
57%, Kenya 16%, South Africa 11%, Paki-
stan 8%; exports—France 79%, Reunion
19%, Comoros 10%
Budget: 144.3 million francs (1982)
Monetary conversion rate: 8.40 French
francs=US$1 (January 1984)
Fiscal year: calendat year:
164','f8a7733749ab4d946001b140e820d2d7bbe6ec88c48fc585a565ec9737cdb3b5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c180aa1f1c3ffc19163682af270e16c04f1aaeef015d145de918032ce23d0df3',1986,'MX','Mexico','economy',332,'GDP: $176.0 billion (1984), $2,200 per cap-
ita; 60% private consumption, 10% private
investment, 10% public consumption, 7%
public investment (1983); net foreign bal-
ance 14%; real growth rate 1984, 3.7%
Natural resources: petroleum, silver, cop-
per, gold, lead, zinc, natural gas, timber
Agriculture: main crops—corn, cotton,
wheat, coffee, sugarcane, sorghum, oilseed,
pulses, and vegetables; an illegal producer of
opium poppy and cannabis for the interna-
tional drug trade
Fishing: catch 1,200,000 metric tons (1984);
exports-valued at $481 million, imports at
$21.9 million (1982) ,
_ Major industries: processing of food, bever-
ages, and tobacco; chemicals, basic metals
and metal products, petroleum products,
mining, textiles and clothing, and transport
equipment
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Mexico (continued)
Crude:steel: 10 million metric tons capacity
(1984); 7.5 million metric tons produced
(1984)
Electric power: 21,492,000 kW capacity
(1985); 83.7 billion kWh produced (1985),
1,051 kWh per-capita
Exports: $23.727 billion (f.0.b., 1984); cot-
ton, coffee, nonferrous minerals (including
lead and zinc), shrimp, petroleum, sulfur,
salt, cattle and meat, fresh fruit, tomatoes,
machinery and equipment
Imports: $11.870 billion (f.0.b., 1984); ma-
chinery, equipment, industrial vehicles, and
intermediate goods
Major trade partners: exports—53% US, -
10% EC, 6% Japan (1984); Epon 00
US, 16% EC, 5% Japan
Aid: economic commitments, US, including
Ex-Im (FY70-84), $2.9 billion; (ODA and
OOF) Western (non-US) countries (1970-83),
$3.7 billion; Communist countries (1970-84),
$97 million; military commitments, US
(FY70-84), $7.8 million
Budget: (at controlled rate of exchange)
1984 public sector, budgeted revenues,
$54.5 billion; Euderied vende $63. 7
billion
Monetary conversion rate: dual exchange
rates—controlled rate 364 .pesos=US$1;
“free” rate 454=US$] (both rates as of
1 January 1986, set daily by the Mexican','72eccbcb68cfe57d863dd66c4e7286a9543751e78607e8c82a386c7e64df42fa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1c07eed6a7e982be7192052c1397a637630aedb0d611c572ba6c8cdf388dde5',1986,'MC','Monaco','economy',335,'GNP: 55% tourism; 25. -80% industry (small
and primarily tourist oriented); 10-15% reg-
istration fees and sales of postage stamps;
about 4% traceable to the Monte Carlo ca-
sino
Major industries: chemicals, food process-
ing, precision-instruments, glass making,
printing
Electric power: 8,000 kW standby capacity:
(1985); power supplied ne France
Trade: full custonis integration with France,
which collects and rebates Monacan tradé’ - :
duties; also participates in EC market system
through customs union with France. #*"" -
Monetary conversion rate: 8.40 French ‘i
francs=US$1 (4 January 1984)','ffa5d3d5d26aedad95ad88f81d979d8268502ba8d69b13296768fc1ca0f29f3b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b52e8336bd0a43b2c36f1ed6e30b4330fa2c8edeeefeb392f2a4cdc874c67234',1986,'MS','Montserrat','economy',342,'GDP: $82.4 million (1983); $2,760 per capita
(1983); real GDP growth rate 2% (1984); 15%
tourism
Agriculture: main crops—cotton, limes, po-''
tatoes, tomatoes, hot peppers; livestock—
cattle, pigs, sheep, goats, poultry
Fishing: catch 150 metric tons (1983)
Major industries: tourism; light manufac-
turing—plastic bags, textiles, electronic ap-
pliances
Electric power: 8,900 kw capacity (1985);
12 million kWh produced (1985), 1,000 per.
capita ’
Reports: $1.6 million (1983); plastic bags,
electronic parts, textiles; hot peppers, live -
plants; cattle
Imports: $20 million (1988); machinery and
transport equipment, foodstuffs, manufac-
turéd goods, fuels, lubricants, and related
materials
Major trade partners: UK
Budget: (1984 est.) revenue $10.6 million;
expenditure $10.7 million
M onetary conversion rate: $2.70 East
Caribbean=US$]1 (1985)
Fiscal year: 1 April-31 March','fd7d71b7d63ba1b366532d8cdf7f69a417bf4877d0bf9e0d7381f5b5a006cbe1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e8fe866d5798ebf0333f82d81426ca32e77bded0df202533300c55f7bbfc3fb',1986,'MA','Morocco','economy',345,'GDP: $11.9 billion (1984 est.), about $500 --
per capita; average annual real growth 6-7%
during 1973-77, 3-4% during 1978-80, 2.0% ..
in 1984 (est.), 2.5% in 1985 (est.)
Natural resources: phosphates, iron, manga-
nese, lead, zinc, fish _
170
Agriculture: cereal farming and livestock
raising predominate; main products—
wheat, barley, citrus fruit, wine, vegetables,
olives; some fishing; an illegal producer of
cannabis for the international drug trade
Fishing: catch 440,000 metric tons (1983);
exports $165 million (1983)
Major industries: mining and mineral pro-
cessing, food processing, textiles, construc-
tion and tourism
Electric power: 1,930,100 kW capacity
(1985); 6.763 billion kWh produced (1985),
290 kWh per capita
Exports: $2.2 billion (f.0.b., 1984); 24% phos-
phates, 76% other
Imports: $3.6 billion (f.0.b., 1984); 25% pe-
troleum products, 75% other
Major trade partners: France, FRG, Italy,','65a974ab7833756ea1df055af008fb16dfdc448e512b00d9aa2baf899af75182','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6988d6946a53ab0508ffde42f0f15f1ab00fc2a05c516840f6a709e9077069f',1986,'SA','Saudi Arabia','economy',346,'Budget: (1984 est.) revenues, $4.5 billion;
current expenditures, $3.6 billion; develop-
ment expenditures, $2.0 billion
Monetary conversion rate: 10.06
dirhams=US$]1 (average 1985)
Fiscal year: calendar year
GDP: $108 billion (FY84e est.), $10,335 per
capita; annual growth in nonoil GDP in con-
stant 1969/70 prices approx. 7% (1981-84)
Natural resources: oil, natural gas, iron ore,
gold, copper
Agriculture: dates, grains, livestock; not self-
sufficient in food except wheat
Major industries: crude oil production 3.6
million b/d (1985); oil revenue payments to
Saudi Arabian Government, $28 billion
(FY85); petroleum refining, basic
petrochemicals, cement production and
small steel-rolling mill; several other light
industries, including factories producing
detergents, plastic products, furniture
Electric power: 18,997,500 kW eapacity
(1985); 49.925 billion kWh produced ae)
4,476 kWh per capita
Exports: $40 billion (f.0.b., 1984); 98% petro-
leum and petroleum products
Imports: $35 billion (c.i-f., 1984); manufac-
tured goods, transportation equipment, con-
struction materials, and processed food
products
Major trade partners: exports—Japan; US,
France; imports—US, Japan, FRG
Budget: FY85 proposed appropriations, $55
billion; current expenditures, $21.5 billion
(est.); capital expenditures, $33.5 billion (est.)
Monetary conversion rate: 3.65 Saudi
riyals=US$1 (December 1985)
Fiscal year: follows Islamic calendar months
Rajab through Jumada II; the Saudi fiscal
year covers 2] March 1985-10 March 1986','cbc51f1a6c806594d847c8c4688b18d80c8970f79d3ea3ec7112cdfad064bd8d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('715c54e3ad9f476013e3c5a45bd6feb52b58b3ebb23b8ca84c0c4c4ea37641b4',1986,'NA','Namibia','economy',351,'Natural resources: diamonds, copper, ura-
nium, lead, tin, zinc, salt, vanadium
Agriculture: livestock raising (cattle and
sheep) predominates; subsistence crops (mil-
let, sorghum, corn, and some wheat) are
raised, but most food must be imported
Fishing: est. catch 341,000 metric tons
(1983); processed mostly in South African
exclave of Walvis Bay
173
Major industries: (nearly all for export)
meatpacking, fish processing, dairy prod-
ucts, copper, lead, zinc, diamond, and ura-
nium mining
Electric power: 400,000 kW capacity (1985);
700 million kWh produced (1985), 631 kWh
per capita
Monetary conversion rate: 2.3SA
rands=US$1 (January 1986)
Fiscal year: 1 April-3] March','20b1986f2f80ca7cb21585afbdbb72d1106fd687c4b7ed239dbc3863bbdbbaec','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dd95778c8cf98d5fd96c320ad61ff2205759bb2bc974572f256f67ad73ca11f',1986,'NR','Nauru','economy',355,'GNP: over $160 million (1984), $20,000 per
capita
Natural resources: phosphates
Agriculture: negligible; almost completely |
dependent on imports for food and water °
Major industries: mining of phosphates,
about 2 million tons per year
Electric power: 13,250 kW capacity (1985);
48 million kWh produced (1985), 6,000 aie
per capita
Exports: $93. zaallton (£.0.b., 1984)
Imports: $11 saillen (cif, 1979), food, fuel,
water
M ajor trade partners: exports—75% Austra-
lia and New Zealand; imports—Australia, :
UK, New Zealand, Japan
Monetary conversion rate: 1.0778 Austra-
lian dollars=US$1 (February 1984)
ATA
Fiscal year: | July-30 June ©','f045f57da2ef9c8f0a8d8e8ec0dfef999124a0b2116aeefb13a909bad97abc74','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4523da430f3668e02cd295f0253764854e0e6ca841c1e8d31e6bd5d6770a2749',1986,'NP','Nepal','economy',358,'GDP: $2.4 billion (FY84 / 85 Girvan prices),
$142 per capita; 9% real growth in FY84/85
(est.)
Natural resources: seauiatts, water, timber,
hydroelectric potential, scenic beauty
Agriculture: over 90% of population en-
gaged in agriculture; main crops—rice,
corn, wheat, sugarcane, oilseeds; an illegal . |
producer of cannabis for the international ~
drug trade
Major industries: small rice, jute, sugar, and
oilseed mills; match, cigarette, and brick
factories
Electric power: 160,000 kW capacity (1985);
395 million kWh produced (1985), 23 kWh
per oe
Pe $157 million F Y84 / 85 est. ); rice
and other food products, jute, timber, manu-
factured goods
Imports: $450 million (FY84/85); ); manufac-
tured consumer goods, fuel, construction.
materials, fertilizers, food products
Major trade partner: India
Budget: (FY84/85 revised est.) domestic
revenues, $290 million; expenditures, $485
million :
Monetary conversion rate: 20.40 N epalese
rupees=US$1 (November 1985)
Fiscal year: 15 July-14 July
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Nepal (continued)','d8f1dee724392de0050ce4e07fdc05bd03fae278535d78d256f54bdc304bcae9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7df5e6dbe360e54602e89e652b79f2cde59a700dd209aa08d969baafc4967e33',1986,'NL','Netherlands','economy',362,'GNP: $1.35 billion (1983), $9,140 per capita;
real growth rate, 1.0% (1984)
Natural resources: phosphates (Curacao
only), salt (Bonaire only)
Agriculture: corn, pulses
Major industries: petroleum refining on
Curacao (refinery currently closed but may
start up again); petroleum transshipment -
facilities on Curacao, Aruba, and Bonaire;
tourism on Curacao, Aruba, -and St. Martin;
light manufacturing on Curacao and Aruba
Electric power: 433,000 kW capacity (1985);
1.312 billion kWh meee ve 5, 560 ©
kWh per capita
Exports: $4.4 billion (f.0.b., 1983); 98% pe-
troleum products, phosphate
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Imports: $4.5 billion (c.i.f., 1983); 64% crude
petroleum, food, manufactures .
Major trade partners: exports—46% US, 2%
Canada, 1% Netherlands; imports—35% —
Venezuela, 11% US, 4% Netherlands (1977)
Aid: bilateral ODA and OOF commitments
(1970-79), economic—Western (non-US)
countries $353 million
Budget: (1984) central government reve-
nues, $616 million; central government ex-''
penditures, $656 million
Monetary conversion rate: 1.8 Netherlands ‘
Antillean florins (NAF)= US$1 (September
1985)
Fiscal year: calendar year','afe2ef4ef7f56a7f30ec1fafb64fc4ca6d9a09f40a17eb88cd86d91b1a326093','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('215cc1e4d6ae3c2640ad648af175bb89ef516f1e56732415b1194231eec15281',1986,'NC','New Caledonia','economy',366,'GNP: $637 million (1979), $4,000 per capita;
1.0% growth (1977)
Natural resources: nickel, chrome, iron,.co-
balt, manganese, silver, gold, lead, copper
Agriculture: large areas devoted to cattle
grazing; major products—coffee, maize,
wheat, vegetables; 60% self-sufficient in beef
Industry: mining of nickel
Electric power: 400,000 kW capacity (1985);
2.1 billion kWh produced (1985), 14,000
kWh per capita
Exports: $257.4 million (£.0.b., 1980); 95%
nickel metal (95%), nickel ore
Imports: $318.2 million (c.i.f., 1980); fuels
and minerals, machines and electrical
equipment
Major trade partners: (1980) exports—
54.9% France; imports—32.5% France
Budget: (1981) revenues, $187.1 million;
expenditures, $168.3 million
Monetary conversion rate: 127.05 francs
CFP=US$1 (December 1982)','0e02994953e55cd5c02957d8ffa0d579694d62b5661b38f2804c8880d183eee3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5195e765113d3df4d974aecc1e08da5a797af6e89cb5744d41696f71a94f8c51',1986,'NZ','New Zealand','economy',370,'GDP: $21.7 billion (year ending March
1985), $5,060 per capita; real average annual
growth Sigel 1.1%
Natural resources: natural gas, iron sand,
coal, timber
Agriculture: fodder and silage crops, 10% of
land in use is planted in field crops; main
products—wool, meat, dairy products; food
surplus country
Fishing: catch 138,000 metric tons (1983);
exports—130,000 metric tons valued at $300
million (1984)
Major industries: food processing, wood and
paper products, textile production, machin-
ery, transport equipment ‘
Electric power: 7,473,000 kW capacity
(1985); 26.307 billion kWh produced (1985),
8,040 kWh per capita
Exports: $5.5 billion (f.0.b., year ending
June 1985); principal products—beef, wool,
dairy
Imports: $6.0 billion (c.i.f., year ending June
1985); principal products—petroleum, cars,
trucks, machinery and electrical equipment,
iron and steel, petroleum products
Major trade partners: (trade year 1982/83)
exports—15% Japan, 16% Australia, 15%
US, 9% UK; imports—20% Japan, 19% Aus-
tralia, 17% US, 9% UK, 5% FRG
Aid: ODA and OOF economic aid commit-
ments (1970-83), $406 million
Budget: (1984/85) expenditures, $7.3 bil-
lion; receipts, $6.0 billion; deficit, $1.3 bil-
lion
Monetary conversion rate: NZ$1.88=US$1
(5 February.1986)
Fiscal year: 1 April-31 March','e4de121e8ecd225afcb2960c0539982332ac7e603782b1cf13ea76f000ee1c90','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d173f9f218bde87cffe6438a9920a4999b419f15ab836761c3709b62922d3753',1986,'NI','Nicaragua','economy',374,'GDP: $2.9 billion (1985), $960 per capita;
real GDP growth rate 1985, —7.1% (Note:
conversion from national currency made at
50 cordobas=US$1; a highly overvalued:
official exchange rate)‘: :
Natural resources: gold, silver, copper, tung-
sten, arable land, timber, livestock, fish
Agriculture: main crops—cotton, coffee,
sugarcane, rice, corn, beans,.cattle’
Major industries: food processing, chemi-
cals, meta] products, textiles and clothing,
petroleum, beverages
Electric power: 400,000 kW-capacity (1985);
1.14 billion kWh produced (1282) 350 kWh
per capita
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Exports: $320 million (f.0.b., 1985); cotton,
coffee, chemical products meat, sugar, sea- -
food
nen $850 million (f.0.b.; 1985); food .-
and nonfood agricultural products, chemi-
cals and pharmaceuticals, transportation
equipment, machinery, construction materi-
als, clothing, petroleum -
Major trade partners: exports—4] % EG,
13% US, 8% CACM; 24% Japan, 1% CEMA,
7% other; imports—10% Mexico, 14% US,
9% CACM, 21% EC, 82% EMS 14% other -
(1984) -.
Aid: economic commitments—US, includ-
ing Ex-Im(FY70-82), $290 million; Western
(non-US) countries; ODA and OOF: -
(1970-83), $540. million; Communist coun-
tries (1970-84), $760 million; military—US
commitments (FY70-79), $20 million, Com-
munist countries tet: 84) = million - -
Budget: 1984 eae aig $1. L billion; rev-
enues, $0.7 billion; converted at 50
cordobas=US$1, at highest official erchanee:
ate ane 3 a)
Monetary conversion rate: multiple
exchange policy; official rates:vary from
10-50 cordobas=US$1 (January 1986); free
market 1,200 cordobas=US$1 (January
1986)
Fiscal year: calendar year','cbd22ca3e7f5f350d6b559fd6078e24cb049233111dc4a51f72147b518e96367','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f4a141ad2ed70966b6e86dafefc2750cce2087917ebb1acac84c68e40126f03',1986,'NU','Niue','economy',381,'GNP: $3 million (1984), x per capita GDP
$1,080 (1984)
Agriculture:.coconuts, passion fruit, honey, .
limes; subsistence crops—taro, yams, cassava
(tapioca), sweet potatoes; pigs, poultry, beef
cattle
Fishing: 930,000 metric tons (1982) _
Major industries: small tourist industry
Electric power: network completed in 1977,
with all villages linked to service
Exports: $301,224 (£.0.b. 1983); canned co-
conut cream, copra, honey, passion fruit
products, pawpaw, root crops, limes, foot-
balls, handicrafts
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R0001 00170001-4
Imports: $1,504,180 (c.i.f. 1983); food and
live animals, manufactured goods, machin:
ery, fuels, lubricants, chemicals, drugs
Major trade partnérs: éxports—New Ze- -
aland, Fiji, Cook Islands, Australia;
imports-—-New Zealand, Fiji, Japan, West:
ern Samoa, Australia, US
Budget: revenues (including New Zealand
subsidy of $2.3 million) $3.2 million; expen-
ditures, $3:8 million (FY83/84 est.)
Monetary conversion rate: usés New Ze-
aland currency; NZS1. 83= ve (5 February
Hee).
Feed year: 1 Apri: 31 Moreh','9fccbbf582097664a52a7254c7fd5561329f7a599b4862bae6d13aff2b094b81','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d1de3934000185a41302067e9ff3ec00361f1909512bc70e61d283bd06fe9e9',1986,'NO','Norway','economy',388,'GNP: $53.15 billion in 1984, $12,838 per
capita; 48.0% private consumption; 19.4%
government consumption; 26.4% gross fixed
investment; —0.7% change in stockbuilding;
net exports of goods and services 10.0%;
1984 growth rate 3.8%, in 1980 prices
Natural resources: oil, copper, gas, pyrites,
nickel, iron, zinc, lead, fish, timber, hydro-
electric power
Agriculture: animal husbandry predomi-
nates; main crops—feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food
shortages—food grains, sugar
Fishing: catch 2.48 million metric tons
(1984); exports $766 million (1984)
Major industries: oil and gas; food process-
ing, shipbuilding, wood pulp, paper prod-
ucts, metals, chemicals
Shortages: most raw materials except tim-
ber, petroleum, iron, copper, and ilmenite
ore; dairy products and fish
_ Crude petroleum: 35.0 million metric tons
produced (1984), exports $6.3 billion (1984)
Crude steel: 915,000 metric tons produced
(1984), 228 kg per capita
Electric power: 23,035,000 kW capacity
(1985); 119.082 billion kWh produced
(1985), 28,626 kWh per capita
Exports: $18.9 billion (f.0.b., 1984); principal
items—oil, natural gas, metals, chemicals,
machinery, fish and fish products, pulp and
paper, ships
Imports: $13.9 million (c.i.f., 1984); princi-
pal items—machinery, fuels and lubricants,
transport equipment, chemicals, foodstuffs,
clothing, ships :
Major trade partners: 59.4% EC (25.3% UK,
16.2% FRG, 12.9% Sweden), 6.7% US (1984)
Aid: donor—ODA and OOF economic com-
mitments (1970-83), $2.1 billion
Budget: revenues, $29.0 billion; expendi-
tures, $25.7 billion
Monetary conversion rate: 7.69 kroner=
US$1 (23 December 1985)
Fiscal year: calendar year','9ae3ea64ed2249dde9f60607ee45c03d718afd684f4f0cefaeeffaf8fa797a4a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64c7105683f2ef18335504f6f26b4416ffbf43cf942ad3ba1662960680b0509c',1986,'OM','Oman','economy',392,'GNP: $7.7 billion (1984), $6, 300 per capita
(est.)
Natural resources: oil, copper, asbestos,
some marble, limestone, chromium, gypsum
Agriculture: based on subsistence farming
(fruits, dates, cereals, cattle, camels), fishing
Ma jor industries: crude petroleum produc-
tion in 1984, 415,000 b/d
190
Electric power: 950,900 kW capacity (1985);
2.082 billion kWh produced (1985), 1,695
kWh per capita
ee $4.5 billion (f.0.b., 1984), mostly
petroleum; nonoil consist mostly of
re-exports, processed copper, and some agri-
cultural goods
Imports: $2.7 billion (c.i-f., 1984), machin-
ery, transportation equipment, manufac-
tured goods, food, livestock, lubricants
Major trade partners: exports—52% Japan,
80% Europe, 8% US (1983); imports—21.3%
Japan, 16.6% UK, 17.8% UAE, 7.6% US
(1984)
Budget: (1984) revenues, $5.1 billion; expen-
ditures, $6.1 billion
Monetary conversion rate: .38454 rial=US$1
(October 1985)
Fiscal year: calendar year','049d95d4ec2ba7893d8429235d1dc8204aef464c10f78b01c05f6a655ee0620f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3293ed95091e53cdd47cd375f280a6dd3f0734549988f4149fff7b35090d815',1986,'PG','Papua New Guinea','economy',395,'GNP: $2.2 billion (1984), $660 per capita; .
real growth (1984) 2.2% est.; 8.5% inflation’,
rate (1985 est.)
Natural resources: gold, copper, silver, gas
Agriculture: main crops—coffee, cocoa,
coconuts, timber, tea
Major industries: sawmilling and timber
processing, copper mining (Bougainville),
fish canning
Electric power: 750,000 kW capacity (1985):
1.7 billion kWh produced Ga 511 kWh
per capita
Exports: $840 million (fob, 1983); gold
($206 million), copper ($149 million), coffee
($123 million), palm oil ($84 million), logs
($78 million), cocoa ($74 million), copra ($54 -
million), coconut oil ($48 million), tea ($17-
million)
Imports: $906 million (f.0.b., 1983); machin-
ery and equipment ($259 million), fuels and
lubricants ($186 million), food and live ani-
mals ($50 million), chemicals ($71 million),
other manufactured ($67 million)
Major trade partners: Australia, UK, Japan
Aid: economic—Australia, commitments -
(1970-83) $4.0 billion; US, including Ex-Im
(FY70-84), $219 million; other Western
countries, ODA and OOF bilateral commit-
ments (1980-84), $6.0 billion
Budget: (1984) total revenue $518 Milliohe=
tax revenue $441 million, non-tax $77 mil-
lion; total expenditures-——$698 million, capi-
tal $165 million:
Monetary conversion rate: .9009 kina= |
US$1 (February 1984)
195
Fiscal year: calendar year','d9b9e76055243b20fdf94dcbcbf8d9d091b5b1f0976361ca5661cee5f35d7fa2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c7cea854c6dcf881755f60cf8e1146bac63c9bf58284849e4724c6846083524',1986,'PY','Paraguay','economy',399,'GDP: $4.8 billion (1985), $1, 020 per capita,
depending on exchange rate (1984); 7% pub-
lic consumption; 66% private consumption
(1983), 28% gross domestic investment; real
growth rate 1985, 4.5%
Natural resources: iron, manganese, lime-
stone, hydroelectric power, forests
Agriculture: main crops—oilseeds,
soybeans, cotton, wheat, manioc, sweet pota-
toes, tobacco, corn, rice, sugarcane; self-
sufficient in most foods:
Major industries: meat packing, oilseed
crushing, milling, brewing, textiles, light
consumer goods, cement, construction
Electric power: 1,675,000 kW capacity
(1985); 1.118 billion kWh produced (1985),
280 kWh per capita
Exports: $361.8 million (f.0.b., 1984); cotton,
oilseeds, meat products, tobacco, timber,
coffee, essential oils, tung oil
Imports: $649.1 million (f.0.b., 1984); fuels
and lubricants, machinery and motors, mo-
tor vehicles, beverages and tobacco, food-
stuffs
Major trade partners: exports—21% Brazil,
14% Netherlands, 12% Argentina, 12% FRG,
9% US, 7% Switzerland, 2% Japan;
imports--28% Brazil, 19% Argentina, 7%
FRG, 6% US, 5% Japan, 5% UK (1983)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Ny
\\
peers and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
\\
y
1
Aid: economic bilateral commitments, US
(FY70-84) $154 million, other Western
countries, ODA and OOF (1970-83), $596
million; military commitments (FY70-84),
US $18 million
Budget: (1983 est.) revenues, $494 million;
expenditures, $741 million
Monetary conversion rate: 240
guaranies=US$1 (January 1986)
Fiscal year: calendar year','6b4835c9c6b292cc48a774373c7d3578e2ca22425aaa86ac9e17e861ca5274b5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8e4a392f2a6a16ca82aa5d57b98a94c076413ce419d97b927de67a65baeab96',1986,'PE','Peru','economy',403,'GNP: $17 billion (1984), $980 per éapita:
(1984); 72% private consumption, 15% pub-
lic consumption, 13% gross investment; 1%
net foreign balance (1983); real growth rate
(1985), 2.5% ;
Natural resources: minerals, metals, petro-
leum, forests, fish
Agriculture: main crops—wheat, potatoes,
beans, rice, barley, coffee, cotton, sugarcane;
imports—wheat, meat, lard and oils, rice,
corn; an illegal producer of coca for the in-
ternational drug trade ,
Fishing: catch 1.450 million metric tons.
(1983); exports—oil, other products, $137
million (1984); meal, $208 million me
Major industnies. mining of metals, petro-..
leum, fishing, textiles and clothing, food pro-
cessing, cement, auto assembly, steel, ship- .
building, metal fabrication
Electric power: 3,720,000 kW capacity
(1985); 13.1 billion kWh produced (1985),
671 kWh per capita
Exports: $3.3 billion (f.0.b., 1984); fishmeal,
cotton, sugar, coffee, copper, iron ore, gold,
refined silver, lead, zinc, crude petroleum
and byproducts e
Imports: $2.6 billion (f.0.b., 1984); food-
stuffs, machinery, transport equipment, iron
and steel semimanufactures, chemicals, . -
pharmaceuticals
Major trade partners: exports—38% US,. |
20% EC, 11% Japan, 9% Latin America, 4% :
UK.(1984); imports—29% US, 22% EC, 17%
Latin America, 1% Japan, 5% FRG (1984)
Budget: 1984— revenues, $2.7 billion; ex-
penditures, $3.6.billion
Monetary conversion rate: 13,9438 soles=
US$1 (November 1985); new currency, the
inti,has been in circulation since January
1986: 1 inti=1,000 soles (January 1986)
Fiscal year: calendar year','904de53b6359d0a515b8669c598fd886a78277a48d6dc3d52a8381dbc615e8dc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b14f8b1e35cbb11b68f684fa8dcf024a082748e4441ab01baa3df505aa131505',1986,'PN','Pitcairn','economy',409,'GNP: expenditure $NZ91 1,000 (1981/82);
bartering important part of life
Natural resources: re-afforestation of miro
trees (used for handicrafts)
Agriculture: local use—citrus, sugarcane,
watermelons, bananas, yams, taro, beans,
pumpkin, coconuts, wild goats, poultry
Fishing: plentiful
Major industries: postage stamp sales
Electric power: 25 kW capacity (1985); .05 .
million kWh produced (1985), 1,850 kWh
per pea
Exports: fruits, vegetables, curios
Imports: fuel oil, machinery, building mate-.
rials, flour, sugar, other foodstuffs .
Budget: revenue $NZ812,639, expenditure
$NZ1,119,882 (1983/84 est.)
200
Monetary conversion rate: NZ$1.88=US$1
(5 February 1986)
Fiscal year: | April-31 March','33007e0d778ee31748dad8f42b5edfae0bc00dd923e4cdfc7f3fcde7388b612b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('626e41612ccd89086755676c2a77f2021c28f6e3733d9e9a2c508324bf67fe81',1986,'PL','Poland','economy',414,'GNP: $228.5 billion in 1984 (1984 dollars),
$6,190 per capita; 1984 growth rate 3.4%
Natural resources: coal, sulfur, copper, nat- —
ural gas, silver
Agriculture: self-sufficient for minimum
requirements; main crops—grain, sugar
beets, oilseed, potatoes, exporter of livestock
products and sugar; importer of grains
Fishing: catch 672,000 metric tons (1983)
Major industries: machinebuilding, iron
and steel, extractive industries, chemicals, -
shipbuilding, food processing '' :
Crude steel: 16.5 million metric tons pro-
duced (1984), about 445 kg. per capita
Electric power: 30,020,000 kW capacity
(1985); 148.5 billion kWh produced (1985),
3,854 kWh per capita
Exports: $17.448 billion (f.0.b., 1984); 47.8%
machinery and-equipment; 29.2% fuels,
minerals, and metals; 11.8% manufactured ©
consumer goods, 8.5% agricultural and for-
estry products; 2.7% other (1984)
Imports: $16.197-billion (f.0.b., 1984); 27.2%
machinery and equipment; 41.0% fuels,
minerals, and metals; 14.0% agricultural and
forestry products; 10.0% manufactured con-
sumer goods, 7.8% other (1984)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Poland (continued)
Major trade partners: $32.726 billion:
(1984); 66% with Communist countries, 24%
- with West, 10% sees less developed coun-
PES
Monetary conversion rate: 148 zlotys=US$1
(December 1985)
Fiscal year: calendar year','acb015655adf760debad0aa58dcbb440c7f2f87e5b2f4c2fee0b209d092a04a3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69a549f3d7ad504d0548b85dac35551e23405d6202449e77f711a5d309907933',1986,'QA','Qatar','economy',421,'GNP: $7.6 billion (1983); $27, 000 per capita
(1983)
Natural resources: petroleum, natural gas,
fish , ,
Agriculture: farming and grazing on small
scale; commercial fishing increasing in im-
portance; most food imported; rice and dates
staple diet
Major industries: oi) production and re-
fining; crude oil production averaged
399,000 b/d (1984); oil revenues accrued
$3.1 billion (est.) in FY85, representing 95%
of government r revenue
204
Electric power: capacity 1,304,200 kW
(1985); 4.569 billion kWh produced (1985),
15,650 kWh per capita
Exports: $4.5 billion (f.0.b., 1984), of which
petroleum accounted for $4.2 billion
Imports: $1.0 billion (c.i-f., 1984)
Budget: (FY85) revenues, $2.7 billion; ex-
penditures, $4.3 billion
Monetary conversion rate: 3.64 Qatar
riyals=US$1 (October 1985)
Fiscal year: 1 April-31 March
Agriculture: cash crops—almost entirely
sugarcane, small amounts of vanilla and per-
fume plants; food crops—tropical fruit and
vegetables, manioc, bananas, corn, market
garden produce, some tea, tobacco, and
coffee; food crop inadequate, most food
needs imported
Major industries: 12 sugar processing mills,
rum distilling plants, cigarette factory, 2 tea
plants, fruit juice plant, canning factory, a
slaughterhouse, and several small shops pro-
ducing handicraft items
Electric power: 180,000 kW capacity (1985);
551 million kWh produced (1985), 1,026
kWh per capita
Exports: $128 million (f.0.b., 1980); 90%
sugar, 5% rum and molasses, 4% perfume
essences, 1% vanilla and tea
Imports: $871 million (c.i.f., 1980); manu-
factured goods, food, beverages, tobacco,
machinery and transportation equipment,
raw materials, and petroleum products
Major trade partners: France and Mauritius
Aid: economic commitments— Western
(non-US) countries, ODA and OOF
(1970-81), $4.0 billion
Monetary conversion rate: 7.974 French
francs=US$]1 (31 October 1983)
Fiscal year: probably calendar year','8fca398b88f0646bd88c5f7b0d7e48bbef1de7166a80e829c42156a7350c21ec','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ee42fb4f7fb1cfb81d8edde5f29a7ee5718e6e529b9654df14958d9065ed4fb',1986,'RO','Romania','economy',425,'GNP: $117.6 billion in 1984 (1984 dollars),
$5,200 per capita; 1984 real growth rate,
4.3%
Natural resources: oil, timber, natural gas,
coal
Agriculture: net exporter; main crops—
corn, wheat, oilseed;.livestock—cattle, hogs,
sheep; consumer and food supplies weak
Fishing: catch 244,000 metric tons (1982)
Major industries: mining, forestry, con-
struction materials, metal production and
processing, chemicals, machine-building,
food processing
Shortages: energy, iron ore, coking coal,
metallurgical coke, cotton fibers, natural
rubber
Crude steel: 14.4 inillion metric tons pro-
duced ven 635 i per capita
Electric power: 18, 768, 000 kW capacity
(1985); 76.318 billion kWh produced (1985),
8,351 kWh per capita
Exports: $12.6 billion (f.0.b., 1984); 32.0%
machinery and equipment; 28.0% fuels,
minerals, and metals; 16.0% manufactured
consumer goods; 12.0% agricultural materi-
als and forestry products; 12.0% other (1984)
Imports: $10.3 billion (f.0.b. 1984); 24.7%
machinery and equipment; 52.6% fuels,
minerals, and metals; 10.8% agricultural and
forestry products; 4.2% manufactured con-
sumer goods;.7.7% other (1984)
Major trade partners: $23.0 billion in 1984;
48% non-Communist countries, 52%.Com-
munist countries (1984):
Monetary conversion rate:.17.1- lei=US81 ;
(September 1985)
Fiscal year: calendar year','54b76cfcce724a146bc48e8b585332fd4ec1539e8c2a24b324bde7f186ab0cef','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1165de83b07b1f0d0446313ff430731fce0a609849e133820a022ba05443dd88',1986,'RW','Rwanda','economy',429,'GDP: $1.6 billion (1984), $257 per capita;
real growth rate (1984 est.), 5.5%
Natural resources: gold, cassiterite,
wolframite
Agriculture: cash crops—mainly coffee, tea, .
some pyrethrum; main food crops—
bananas, cassava; stock raising; self-
sufficiency declining; country imports
foodstuffs
Major industries: mining of cassiterite (tin
ore) and wolframite (tungsten ore), tin fac-
tory, cement factory, agricultural process- |
ing, and production of beer; soft drinks,
soap, furniture, shoes, plastic goods, textiles,
cigarettes
Electric power: 42,000 kW capacity (1985);
110 million kWh produced (1985), 17 kWh
per capita
Exports: $147.9 million (f.0.b., 1984 est.);
mainly coffee, tea, cassiterite, wolframite,
pyrethrum
Imports: $204.9 million (c.i.f., 1984 est.);
textiles, foodstuffs, machines, equipment,
capital goods, steel, petroleum products, °
cement and construction ‘material
Major trade partners: US, Belgium, FRG,','aaf5200bf9f170cc6cfa57ceb664d27ff0588a6ce2fa75cf05ee4657e3061922','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b552ca21a093d538e7720a7678a927fc15c39e7ddc08946e3e103907a071f95',1986,'SM','San Marino','economy',433,'Principal economic activities of San Marino:
are farming, livestock raising, light manu-
facturing, and tourism; the largest.share of. :
government revenue is derived from the sale
of postage stamps throughout the world and
from payments by the Italian Government
in exchange for Italy’s monopoly in retailing
tobacco, gasoline, and a few other goods; -
main problem is finding additional funds to
finance badly needed water and electric
power systems expansions
Natural resources: building stones
Agriculture: principal crops are wheat (av-
erage annual output about,4,400 metric ton-
s/year) and grapes (average annual output
about 700 metric tons/year); other grains,
fruits, vegetables, and animal feedstuffs are
also grown; livestock population numbers
roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock prod-
ucts
Electric power: power supplied by Italy
(1985)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
San Marino (continued)
Manufacturing: consists mainly of cotton
textile production at Serravalle, brick and
tile production at Dogana, cement produc-
tion at Acquaviva, Dogana, and Fiorentino,
and pottery production at Borgo Maggiore;
some tanned hides, paper, candy, baked.
goods, Moscato wine, and gold and silver
souvenirs are also produced :
Foreign transactions: dominated by tour-
ism; in summer months 20,000 to 30,000
foreigners visit San Marino every day; sev-
eral hotels and restaurants have been built in
recent years to accommodate them; remit-
tances from Sanmarinese abroad also repre-
serit an important net foreign inflow; com-
modity trade consists primarily of exchang-
ing building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceram-
ics for a wide variety of consumer manufac-
Tunes:
Monetary conversion rate: 1704.0 Italian
lire=US$1 January 1984)','6930c3967a7429683e3ef9239fa2d78c92513d3c13be7161a2421b29175da339','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75da0474d5ccba98e0c1572a8286e0af54ed8200bdb866ba96c0504448e8321e',1986,'SN','Senegal','economy',438,'GDP: $2.3 billion (1984), $360 (1984) per
capita; real growth — 4.2% in 1983 .
Natural resources: fish, phosphates
Agriculture: main crops—peanuts (primary
cash crop); millet, sorghum, manioc, maize, :
rice, livestock; deliatpredueten of food’: *
Fishing: eateh 230,000 metric-tons (. 1984)
exports $120 million (1964) ie
Major industries: fishing, agricultural pro-
cessing plants, light manufacturing, mining -
Electric power: 187,000 kW capacity (1985); :
737 million kWh produced (1985), 109 ee
per capita
Exports: $525 million (f.0.b., 1984); peanuts
and peanut products, phosphate rock, fish,
petroleum products (reexport)
Imports: $805 million (f.0.b., 1984);''food, * *
consumer goods, machinery, transport
equipment, petroleum :
Major.trade em France, ccother EC, *
and franc zone - ee ee:
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Senegal (continued)
Budget: (1984/85) public revenues, $467 -
million; current expenditures, $489 million;
capital expenditures, $75 million
Monetary conversion rate: about 475 Com-
munauté Financiére Africaine (CFA)
francs=US§$1 (1985)
Fiscal year: 1 July-30 June','5674258e99f12ee44d3ffa96ad8616496f0ecfd6470bdfa249961cf067447bd1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14c2166e7dffa1e1ec62837af08ab0b2d15eb282cd4ce856808f196b56106595',1986,'SC','Seychelles','economy',442,'GDP: $150 million (1988 prelim.); $2,320 °
per capita (1984 est.); real growth rate
— 1.8% (1984 prelim.)
Natural resources: fish, copra, spices
Agriculture: islands depénd largely on‘coco-
nut production and export of copra; cinna-
mon, vanilla, and patchouli (used for per-
fumes) are other cash crops; food crops—
small quantities of sweet potatoes, cassava,
sugarcane, and bananas; islaids ‘not self-
sufficient in foodstuffs and the bulk of the
supply must be imported; fish i is an impor-
tant food source
Major nance is largest industry:
processing of coconut and vanilla, fishing,
small-scale manufacture of consumer goods,
coir rope factory, tea factory —
Electric power: 20,000 kW capacity (1985);
58 million kWh produced (1985), 878 kWh
per capita
Exports: $4.4 million (f.0.b., 1984 prelim. ds.
fish, copra, cinnamon bark” :
Imports: $72.7 million (f.0.b.; neces
manufactured goods, food, tobacco, bever-
ages; machinery and transport equipment,
and petroleum products
Major trade partners: exports—Pakistan,
France, Reunion, UK, Mauritius; imports—
Bahrain, UK, South Africa, Singapore, ,
Japan, France :
Aid: economic commitments— Western
(non-US) countries, ODA andOOF |
(1978-83), $216 million; US (FY78- 84), $11
million; Communist countries (1970-84), $32
million
Budget: (1984) revenues, $61 million; grants,
$4 million; current expenditures, $64 mil-
lion; capital expenditures, $11 million; net
lending, $3.5 million
M onetary conversion rate: 6. 80 Seychelles
rupees=US$1 (31 October 1985) -
Fiscal year: calendar year','0b62b2bf6cb96b3aa8b45b57e8c6d28059ab7bfdb94ec0ece32afc2878fd46eb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0b605e8f969a21d69bcd0379d4232a187ea8e73755f750828023bda08f020f6',1986,'SG','Singapore','economy',449,'GDP: $17.6 billion (1984 est.), $7,000 per
capita; 8.7% average annual real growth
(1973-83), — 1.7% (1985)
Agriculture: occupies.a position of minor
importance in the economy, self-sufficient in
pork (but pig farming outlawed as of 1985),
poultry, and eggs; must import much of its
other food requirements; major crops—rub-
ber, copra, fruit and vegetables
Fishing: catch 22,763 metric tons (1984),
imports—97,976 metric tons (1984), exports
55,666 metric. tons (1984).
Major industries: petroleum refining, elec-
tronics, oil drilling equipment, rubber. pro-
cessing and rubber products, processed food:
and beverages, ship repair, entrepot trade,
financial services, biotechnology
Electric power: 3,388,000 kW capacity
(1985); 9.865 billion kWh produced Coase
3,860 kWh per cacu
Exports: $24, J billion (f.0.b., 1984); manu-
factured goods, petroleum, rubber, electron-
ics ;
Imports: $28.7 billion (c.i.f., 1984); major
retained imports—capital equipment, man-
ufactured goods, petroleum
Major trade partners: exports—US, Malay-
sia, Japan, Hong Kong, Thailand, Australia,
FRG; imports—Japan, US, Malaysia, Saudi
Arabia 7 . ,
Aid: economic commitments—Western |
(non-US) countries (1970-83), $562 million;
US, including Ex-Im (FY70-80), $575 mil-
lion; military —US (FY70-84), $2 million
Budget: (1984) revenues, $5.4 billion; expen-
ditures, $3.9. billion; lending minus repay-
ment, $0.5 billion; surplus, $1. O billion
Monetary conversion rate: 2.13 Singapore
dollars=US$1 (5 February 1986)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Singapore (continued).
Fiscal year: | April-31 Mar¢h :','8ea91c74df14f958226928f02484ed9b881454b1f31062afa636a74754bf45ba','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffc32fcedde4d2f5be41b6d673d6ff4f4af13251c5de9e6f534d8c9f9babee36',1986,'SB','Solomon Islands','economy',453,'GDP: $131 million (1982), $520 per capita
Natural resources: forests, agricultural land,
marine shell, some minerals, water
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Agriculture: largely dominated by coconut
production with subsistence crops of yams,
taro, bananas; self-sufficient in rice
Electric power: 15,000 kW capacity (1985);
30 million kWh produced (1985), 110 kWh
per capita
Exports: $93.7 million (2884); copra, timber,
fish
Imports: $79.2 million (c.if:; 1984)"
Major trade partners: exports—Japan 37%,
UK 11%, Australia 3%; imports—Australia
31%, Singapore 16%, Japan 15%, UK 9%
(1981)
Aid: economic commitments from Western
(non-US) countries, ODA (1979), $13.3 mil-
lion
Budget: (1979) million révenues, $22. 45 mil-
lion; expenditires, $37. 8 million °
Monetary conversion rate: 1.44 Australian
dollars=US$1 (6 February 1986)','d9d6b405df7c46aa3e8c72cd358537d1ad4f528e926aedfab1735fed12107011','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96391a56745cd6b9e6946f8ffbe632d5fb954f81849213f324688f76fbba81e4',1986,'SO','Somalia','economy',457,'GDP: $1.875 million (1982 est.), $380 per
capita
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Somalia (continued)
Natural resources: uranium, iron, tin, SYD-
sum, , bauxite”
ee mainly a pastoral-country, rais-
ing livestock; crops—bananas, sugarcane,
cotton, cereals
Major industries: a few small industries,
including sugar refining, tuna, beef canning,
textiles, iron rod plant, and petroleum re-
fining :
Electric power:63,600 kW capacity (1985);
83 million kWh produced (1985), 10 kWh
per capita
Exports: $107 million (f.0.b., 1985 est.); live-
stock, hides, skins, bananas
Imports: $561 million (c.i.f., 1985 est.); tex-
tiles, cereals, transport equipment, machin-
ery, construction materials and equipment,
petroleum products; also military materiel
in 1977
Major trade partners: exports—Saudi
Arabia 65.8%, Italy 14.1% (1983); imports—
Italy 28.1%, Saudi Arabia 15.5%, US 12%
(1983)
External debt: $1.5 billion (1985 est.); exter-
nal debt service 48% of exports of goods and
services
Budget: (1988 est. in percent of GDP) reve-
nues and grants, 13.9%; current expendi-
tures, 7.2%; investment expenditures, 10%
Monetary conversion rate: official rate—
40.6 Somali shillings=US$1; legal free mar-
ket—100 Somali shillings=US$1 (October
1985)
Fiscal year: calendar year','ee0c8f3a07f74aa19ee26563f8c2e361a99465be97ebd6f2483569f979a7c885','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59bfffffa23706155a74c6c05d4a9bd0f8c8845fa63cc034665973668fd433a2',1986,'ZA','South Africa','economy',461,'GDP: $73 billion (1984), about $2,500 per
capita; 4.5% real growth in 1984
Natural resources: gold, chromium, anti- -
mony, coal, iron, manganese, nickel, phos-
phates, tin, uranium, gem diamonds, plati-_
num, copper, vanadium
Agriculture: main crops—corn, wool,
wheat, sugarcane, tobacco, citrus fruits;
dairy products; self-sufficient in foodstuffs
Fishing: catch 599,897 metric tons (1983)
Major industries: mining, automobile as-
sembly, metalworking, machinery, textile,
iron and steel, chemical, fertilizer
Electric power: 26,150,000 kW capacity
(1985); 137.444 billion kWh produced ..
(1985), 4,233 kWh per capita
Exports: $19.6 billion (f.0.b., 1984, including
gold); gold, coal, diamonds, corn, uranium,’
other mineral and agricultural products; net
gold output $8. billion (1984)
Imports: $14.9 billion (f.0.b., 1984); machin-
ery, motor vehicle parts, petroleum prod-
ucts, textiles, chemicals
Major trade partners: US, FRG, Japan, UK;
member of Southern African Customs
Union
Budget: (FY1984/85) revenues, $16.4 bil-
lion; current expenditures, $18.8 billion
Monetary conversion rate: 2.3 South Afri- ..
can rand=US$] (29 January 1986}
Fiscal year: 1 April-31 March
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
South Africa (continued)','240fa8bf45f8718af707096caa9ac2a2b387c1f3f16a515960c2d46a4d42e3de','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f377dee88cb317861b86c209f60f29cf0062763d0beb9b1d0f270b4d3b3e8691',1986,'LK','Sri Lanka','economy',468,'GDP: $6.0 billion (1984), $380 per capita;
real growth rate 5% (1984) .
Natural resources: limestone,.graphite, min-
eral sands, gems, phosphates
Agriculture: agriculture accounts for about
25% of GDP; main crops—trice, rubber, tea,
coconuts
Fishing: catch 170,000 metric tons (1984
est.)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Major industries: processing of rubber, tea,
coconuts, and other agricultural commodi-
ties; consumer goods manufacture; garment
industry”
Electric power: 972,000 kW capacity (1985);
2.352 billion kWh produced (1985), 145
kWh per capita
Eons: $1.5 billion (f.0.b., 1984); tea, rub-
ber, petroleum products, textiles, coconuts
Imports: $1.9 billion (c.i.f., 1984); petro-
leum, machinery, transport equipment,
sugar, textiles and textile materials
Major trade partners: (1984) exports—US,
Iraq, UK, UAR, FRG, Singapore, Japan; im-
ports—Japan, Saudi Arabia, US, India, Singa-
pore, FRG, UK, Iran
Budget: (1984) revenues, $1.3 billion; expen-
ditures, $1.8 billion
Monetary conversion rate: 27.4
rupees=US$1 (October 1985)
Fiscal year: 1 January-31 December
Commiunications
Railroads: 1,868 km total (1985); all 1.868-
meter broad gauge; 102 km double track; 1 no
electrification; government owned
Highways: 66,176 km total (1985); 24,300
km paved (mostly bituminous treated);
28,916 km crushed stone or gravel, 12,960
km improved earth or unimproved earth; in
addition, several thousand km of tracks,
mostly unmotorable
Inland waterways: 430 km; navigable by
shallow- draft craft
Pipelines: crude, 14 km; refined products,
55 km
Ports: 3 major, 9 minor
Civil air: 8 major transport (including 1
leased) ©
Airfields: 14 total;-12 usable; 11 with ‘
permanent-surface runways; 1 with run- =~
ways 2,440-3,659-m, 7 with runways
1,220-2,439 m- :
Peconsiuiteaens: good international
service; 75,000 (est.) telephones (0.5 per 100°
popl.); 16 AM; 2 FM stations;1-TV station; *
submarine cables extend to Iridia; 1: ground
satellite station
Defense Forces
Branches: Army, Air Force, Navy; Police
Force, Special Police Task Force, National
Auxiliary Force -
Military manpower: males 15-49, 4,416,000,
3,468,000 fit for military service; 193,000
reach military age (18)anriually -
Military budget: for fiscal year ending 31
December 1986, $256 million, 9% of central
government estimated budget °
231','e120958cfd722b40f0318741175917351e60882a6159348d378c03610328016b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b281954ed2665fb2e44ed96726047ca5800705648f795a43982e9bd84f9b4b8',1986,'SD','Sudan','economy',469,'BG wuindary
ep
__ See regional map VII
Land
2,505,813 km?; over one-fourth the size: Be
the''US; 37% arable (3% cultivated): 33%
desert, waste, or urban; 15% grazing; 15%.
forest
Land boundaries: 7,805 km - ~
Water
Limits of territorial waters (claimed):
12nm
Coastline: 853km-- °° - soar th
GDP: $7.3! billion at current prices (FY84),
$350 per capita at current prices (FY83)
Natural resources: modest reserves of oil,
iron ore, copper, chrome, and other indus- -
trial minerals
Agriculture: main crops—sorghum, millet,
wheat, sesame, peanuts, beans, barley; not
self-sufficient in food production; main cash
crops—cotton, gum arabic, peanuts, sesame
Major industries: cotton ginning, textiles,
brewery, cement, edible oils, soap, dshlling.
shoes, pharmaceuticals
Electric power: 542, 700 kW capacity (1985): ;
1.188 billion kWh produced (gee) 54 kWh
per capita
Exports: $409 million (f.0.b., 1984); cotton
(31%), gum arabic, peanuts, sesame; $40 mil-
lion eaDoUts to Communist countries (FY82)
Imports: $465. 7 million (c.f, 1984); tex- _
tiles, petroleutn products, foodstuffs, trans-
port equipment, manufactured goods :
Major trade partners: UK, FRG, Italy, US,
Saudi Arabia, France, Egypt, J apan
Budget: (FY84)-public revenue $551 million,
total expenditures $829 million, including
development expenditure of $208 million .
Monetary conversion rate: 2.45 Sudanese
pounds= US$1 (December 1985) official;
3.70 Sudanese_pounds=US$1 free ea
Dene 1969) :
232
Fiscal year: 1 July-30 June','3a8e0c3ced486c679160e034b35d05bd2083c35530059ad48b90b26eb6721c74','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9143774a487fb2b4c210ecdfb5687bd0544123f4a49a6e1a9442d08974a32be2',1986,'SR','Suriname','economy',476,'GDP: $1.1 billion (1984); $2,980 per capita
(1984); real growth rate — 1.0% (1984)
Natural resources: forests, hydroelectric
power potential, fish, shrimp, bauxite, iron
ore, and other minerals -
Agriculture: main crops—rice, bananas,
palm oil, timber
Major industries: bauxite mining, alumina
and aluminum production, lumbering, food
processing
Electric power: 420,000 kW capacity (1985),
1.61 billion kWh produced (1985), 4,290
kWh per capita ;
Exports: $356 million (f.0.b., 1984); alumina,
bauxite, aluminum, rice, wood and wood
products
Imports: $346 million (c.i.f., 1984); capital —
equipment, petroleum, iron and steel, cot-
ton, flour, meat, dairy products
Major trade partners: exports—26% Neth-
erlands, 17% US, 18% FRG; imports—30%
US, 21% Trinidad and Tobago, 9% Nether-
lands (1983)
Aid: economic—bilateral commitments,
including Ex-Im—US (F Y70-83), $2.5 mil--
lion, Western (non-US) countries, ODA and
OOF (1970-83), $1.4 billion; no military aid
Budget: revenues, $261 million; expendi-
tures, $421 million (1984 est.)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Suriname (continued)
M onetary conversion rate: 1.79 Suriname
guilders=US$1 (September 1985)
Fiscal year: calendar year
GNP: approximately $478 million (1984),
about $900 per capita; real growth 11%
(1984)
Natural resources: asbestos, coal, clay, tin,
diamonds, hydroelelectric power, forests
Agriculture: main crops—maize, cotton,
rice, sugar, and citrus fruits
Major industry: mining, pulping
Electric power: 60,000 kw capacity (1988);
84 million kWh produced (1985), 125 kWh
per capita
Exports: $360 million (f.0.b., 1984); sugar, ~
asbestos, wood and forest products, citrus,
and canned fruit
Imports: $498 million (f.0.b., 1984); motor
vehicles, chemicals, petroleum products,
and foodstuffs
Major trade partners: South Africa, UK, US;
member of South African Customs Union
Aid: economic commitments—- Western
(non-US) countries, ODA and OOF
(1970-83), $340 million; US (FY70-84), $80
million
Budget: 1984/85 (est.)—revenues, $204 mil-
lion; current expenditures, $149 million
Monetary conversion rate: theSwazi
lilangeni exchanges at par with the South .
African rand; 2.3 emalangeni=US$1 (29
January 1986)
Fiscal year: 1 April-31 March','74d50d64ed98cd6a8654c27dba1021dfc27b6cf3346b0388efd419b52991bf58','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7953655a195d700143ccd1fadbf07c78205fc331c7939dffd78aa3182e195650',1986,'SE','Sweden','economy',479,'GDP: $96.0 billion, $11,510 per capita
(1984); 51.9% private consumption, 28.8%
government consumption, 12.9% private
investment; 6.0% public investment; — 1.0%
change in stock building; 1.4% net exports of
goods and services; 1984 growth rate, 3.3%
Natural resources: zinc, iron, lead, copper,
silver, gold, forests, hydroelectric power
Agriculture: anima] husbandry predomi-
nates, with milk and dairy products account-
ing for 37% of farm income; main crops—
grains, sugar beets, potatoes; 100%
self-sufficient in grains and potatoes, 85%
self-sufficient in sugar beets
236
Fishing: catch 285,000 metric tons (1984),
exports $77 million, imports $196.0 million
Major industries: iron and steel, precision
equipment (bearings, radio and telephone
parts, armaments), wood pulp and paper
products, processed foods, motor vehicles
Shortages: coal, petroleum, textile fibers,
potash, salt, oils and fats, tropical products
Crude steel: 4.7 million metric tons pro-
duced (1984), 564 kg per capita
Electric power: 38,956,000 kW capacity
(1985); 129.6 billion kWh produced (1985),
15,543 kWh per capita
Exports: $29.0 billion (f.0.b., 1984); machin-
ery, motor vehicles, paper products, pulp
and wood, iron and steel products, chemi-
cals, petroleum and petroleum products
Imports: $26.38 billion (c.i-f., 1984); machin-
ery, petroleum and petroleum products,
chemicals, motor vehicles, foodstuffs, iron
and steel, clothing
Major trade partners: EC 50.2%, other de-
veloped 34.9%, non-OPEC less developed
countries 5.5%, OPEC 4.5%, CEMA 4.9%
(1984)
Aid: donor—ODA and OOF economic aid
commitments (1970-83), $5.4 billion
Budget: (1984/85) revenues $31.0 billion,
expenditures $38.7 billion, deficit $7.7 bil-
lion
Monetary conversion rate: 7.8
kronor=US$1 (November 1985 average)
Fiscal year: 1 July-30 June','fb3e3879eab7880d7707b264ee16eecc44db6689f3447b42005a1fbff3c5b12f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8721acf98c984a92c7e482701f6c48db001b801e8d5458685b496f018c8cedb0',1986,'CH','Switzerland','economy',483,'GNP: $96.1 billion (1984), $14,300 per cap-
ita; 58% consumption, ‘22% investment, i.
0.13% government, — 1% ret foreign bal-
ance; real growth rate 2.5% (1984)
Natural resources: hydroelectric power (po-
tential), timber, salt "
Agriculture: dairy farming predominates; °
less than 50% self-sufficient; food
shortages—fish, refined sugar, fats and oils ° ;
(other than butter), grains, eaes, fruits, vege-
tables, meat
Major industries: machinery, chemicals,
watches, textiles, precision instruments
Shortages: practically all important raw
materials except hydrdelectric energy
Electric power: 17,690,000 kW capacity
(1985); 56.765 billion kWh produced (1985),
8, 790 kWh per cape eae,
ieneme $25.8 billion (f.0.b., 1984); principal
items—machinery and equipment, chemi-
cals, precision instruments, metal products,
textiles, foodstuffs
Imports: $28.5 billion (f.0.b., 1984); princi-
pal items—machinery and transportation
equipment, metals and metal products,
foodstuffs, chemicals, textile fibers and yarns
Major trade partners: 59% EC, 21% other
developed, 17% less developed countries, 3%
Communist
Aid: donor--ODA and OOF economic aid
committed (1970-83), $1.4 billion
Budget: receipts, $8.50 billion; expendi- -
tures, $8.75 billion; deficit, $0.25 billion
(1984)
Monetary conversion rate: 2.17
francs=US$1 (October 1985)
Fiscal year: calendar year
CDP: $20.7 billion (1984), $2,000 per capita;
real GDP growth rate 2% (1984)
Natural resources: crude oil, phosphates, —
chrome and manganese ores, asphalt, iron. _
ore, rock salt, marble, gypsum
Agriculture: main crops—cotton, wheat,
barley, tobacco; sheep and goat raising; self-
sufficient. in most foods in years of good -
weather
Major industries: textiles, food processing,
beverages, tobacco; petroleam—170, 000
b/d production (1984), 229,000 b/d refining
capacity
Electric power: ay 256, 700 kw capacity | ''
(1985); 6.919 billion kWh produced (1985), _
656 kWh per capita
Exports: $1.9 billion (f.0.b., 1984); petro-
leum, textiles and textile products, tobacco,
fruits and vegetables, cotton
Imports: $4. 1 billion (£.0. ‘i , 1984); petro- o
leum, machinery and metal products, tex-
tiles, fuels, foodstuffs
Major trade partners: exports—Romania, ; ,
Italy, France, USSR; imports—Iran, FRG,
Italy, Libya
eat so tees & toa
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Syria (continued)
Budget: 1985—revenues $6.8 billion (ex-
cluding aid payments); expenditures $10.9
billion
Monetary conversion rate: 3.925 Syrian
pounds=US$]1 (official rate, February 1984);
two other officially sanctioned rates—the
“parallel” and “tourist” rates—are deter-
mined by the government guided by supply
and demand
Fiscal year: calendar year
GDP; $4.2 billion (1984), $210 per capita;
real growth rate, 0.6% (1984 prelim.)
Natural resources: hydroelectric power po- .
tential, large unexploited iron and coal,
gemstone and gold mines, natural gas, nickel
Agriculture: main crops—cotton, coffee,
sisal on mainland; cloves and coconuts on
Zanzibar
Major industries: primarily agricultural
processing (sugar, beer, cigarettes, sisal
twine), diamond mine, oil refinery, shoes,
cement, textiles, wood products
Electric power: 872,800 kW capacity (1985);
816 million kWh produced (1985), 37 kWh
per capita
Exports: $396 million (f:0.b., 1984); coffee,
cotton, sisal, cashew nuts, meat, cloves, to-
bacco, tea, coconut products
Imports: $831 million (c.if., 1984); manv- .
factured goods, machinery aiid transport
equipment, cotton piece goods, crude oil,
foodstuffs
Major trade partners: exports—FRG, UK;-
US; imports, ERG, UK, US, Iran
External debt: $2.8 billion (1983); debt ser-
vice ratio 68.1% (1984—not including IMF)
Budget: (1984 / 85) revenues, $891.8 million;
current expenditures, $1.017 billion; devel-
opment expenditures, $359.5 million
Aid: economic aid. commitments from West-
em (non- US) countries (1970-79), ODA and
OOF, $100 million; US, including Ex- Im
(FY70-80), $200 million
M. onetary conversion rate: 17.Tanzanian
shillings=US$1 (14 June 1984)
Fiscal year:.1 July-30 June','1fb1f0d49e0643d5956342097e9f563bdd88573a8f5077faff31953df2d5e9d3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db4b73864b2e084e048e2afe33c451717a763fd873f31e1f3da043c1205d33f3',1986,'TH','Thailand','economy',487,'GNP: $52.4 billion (1984), $1,030 per capita:
5.4% real growth in 1984
Natural resources: tin, rubber, natural gas,
tungsten, timber, fisheries products
Agriculture: main crops—trice, sugar, corn, .
rubber, manioc; an illegal producer of
opium poppy and cannabis for the interna-
tional drug trade
Fishing: catch 2.2 million metric tons (1984);
major fishery export, shrimp, 19,428 metric
tons, about $117 million (1984)
Major industries: agricultural processing, ..
textiles, wood and wood products, cement,
tin and tungsten ore mining; world’s second .
largest tungsten producer and third largest
tin producer
Shortages: fuel sources, including coal and,
petroleum; scrap iron; and fertilizer
Electric power: 5,826,000 kW capacity
(1985); 20.7 billion kWh produced (1985),
393 kWh per capita
Exports: $7.4 billion (f.0.b., 1984); rice,
sugar, corn, rubber, tin, tapioca, textiles and
garments, integrated circuits, canned sea- __
food, fruit 7 ,
Imports: $10.37 billion (c.i.f., 1984); machin-
ery and transport equipment, fuels and
lubricants, base metals, chemicals, and fer-
tilizer
Major trade partners: exports—US, Japan,
Singapore, the Netherlands, Hong Kong,
Malaysia; imports—Japan, US, FRG, UK,
Singapore, Saudi Arabia; about 1% or less .
trade with Communist countries
Budget: (FY84) estimate of expenditures,
$7.6 billion; revenues $6.2 billion; deficit
$1.4 billion
M onetary conversion ra te: 27 baht= US$ fh
(January 1986)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDPO8-00534R000100170001-4
Fiscal year: 1 October-30 September
GNP: $950 million (1982 est.), about $340
per capita; 3.2% real growth in 1982
Natural resources: phosphates, limestone,
marble
Agriculture: main cash crops—coffee, co-
coa, cotton; major food crops—yams, cas-
sava, corn, beans, rice, millet, sorghum, fish
Fishing:catch 14,556 metric tons (1983)
Major industries: phosphate mining, agri-
cultural processing, cement, handicrafts,
textiles, beverages
Electric power: 47,900 kW capacity (1985);
83 million kWh produced (1985), 27 kWh
per capita
Exports: $202 million (f.0.b., 1982); phos-
phates, cocoa, coffee, palm kernels
Imports: $390 million (f.0.b., 1982); con-
sumer goods, fuels, machinery, tobacco,
foodstuffs
Major trade partners: mostly Frarice and
other EC countries
Budget: (1982 proj.), revenues, $243.1 mil-
lion; current expenditures, $219 million;
development expenditures, $89 million
Monetary conversion rate: 475 Commun-_
auté Financiére Africaine (CFA) francs=
US$1 (1985)
Fiscal year: calendar yeat
Communications ale
Railroads: 570 km 1. 000-meter gaiige, single
track
Hanae 7,562 km total; 1,505 km paved,
1,257 km improved earth, remainder unim-
proved earth
Inland waterways: section of Mono River
and about 50 km of coastal Jagoons and tidal
creeks
Ports: 1 major (Lomé), 1 minor
Civil air: no major transport aircraft
Airfields: 11 total, 11 usable; 2 with
permanent-surface runways 2,440-8,659 m —
Telecommunications: fair system based on
network of open-wire lines supplémented by
radio-relay routes; 12,000 telephones(0.4 ~
per 100 popl.); 2 AM, no FM, 3 TV stations; 1
Atlantic Ocean satellite station arid 1.
SYMPHONIE station
Defense Forces:
Branches: Army, Navy, Air Force, paramili-
tary Gendarmerie
Military manpower: males 15-49, 681,000; ,
354,000.fit for military service; no conscrip-
tion : ,
244','3e84f9658227fd7bc7eb0db2b98c8f1da028e910e73a8fb47ae2dd34e4e7751f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0de6b9beb677340838d154d8adc22c6217c78521e81bfc081dfeb3af74f1f421',1986,'TK','Tokelau','economy',488,'50 km
e Atafu
South Pacific Ocean
: j wWukunonu
Fakaofo™''
Seeregional mapX
Land
about 10.1 km?; about one-fifteenth the size
of Washington, D. C.; consists of three atolls
(Atafu—2 km?, Nukunonu—5. 5 km?, and
Fakaofo—2.6 kim? )
Water
Limits of territorial waters (claimed): 12
nin (200 nm exclusive econorie zone)
Coastline: Fakaofo, about 36 km;
’- Nukunonu, about 45 km; Atafu, about
20 km
Natural resources: negligible
Agriculture: coconuts, copra; basic subsis-
tence crops—pulaka, breadfruit, pawpaw,
bananas; pigs, poultry
Fishing: ocean and lagoon fish and shellfish
for local consumption
Major industries: copra production, wood
work, plaited craft goods, stamps, coins
Electric power: 200 kW capacity (1985); .3
million kWh produced (1985), 187 kWh per
capita
Exports: $23,648 (1982/3); copra, handi-
crafts | = ot
Imports: foodstuffs, building materials, fuel
Major trade partner: New Zealand
Budget: (1983/4) expenditures, $1,358,105;
revenue, $208,419; New Zealand subsidy,
$1,149,686
Monetary conversion rate: New Zealand
currency and the Tokelau souvenir coin are
legal tender-—NZ$1.88=US$1 (5 February
1986); Western Samoan currency is also used
Fiscal year: 1 April-31 March','fd21630e551e9f3f7deb7ca0ad302930bf80448ce1858a0820c0a5dc293d6642','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23bbd15cc40b21acb853677a2a83b03561a41c527a960d8fdf84b5070c141d7a',1986,'TO','Tonga','economy',495,'GNP: $65 million (1984), $580 per capita
Natural resources: fish
Agriculture: largely dominated by coconut *
and banana production, with subsistence
crops of taro, yams, sweet’ potatoes; bread-
fruit ,
Major industry: tourism |
Electric power: 5,000 kW capacity (1985); 8
million kWh produced (1985), 75 kWh per
capita - :
Exports: $7 million (1979); 65% copra, 8%
bananas, 7% coconut products
Imports: $29 million (1979); food, machin-: :
ery, petroleum
Major trade partners: exports—36% Austra-
lia, 34% New Zealand, 14% US; imports 38%
New Zealand, 31% Australia, 6% Japan, 5%
Fiji (1979)
Aid: economic commitments—§27 million
(1983); Western (non-US) countries, ODA
and OOF (1970-81), $77 million
Budget: (1981-82) revenues, 14,744,237
pa’anga; expenditures, 14,735,833 pa’anga
(est.)
Monetary conversion rate: 1.0778
pa’anga=US$1 (February 1984)
Fiscal year: 1 July-30 June','135526f03a98501bd1970de4f9336410ddf6bcf15eaeff3f1aa2218e0db06d38','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a6f84caa7cfbbb6cd1f8eb315f3cd145e2c2ddec11b1b9efdbcdb4a5dfc6591',1986,'TT','Trinidad and Tobago','economy',498,'GNP: $8.6 billion (1984), $7;370 per capita; .
real growth rate (1984), —7.4% oe
Natural resources: oil, gas, petroleum, as-
phalt
Agriculture: main crops—sugar, cocoa,
coffee, rice, citrus, bananas; largely depen-
dent upon imports of food |
Fishing: catch 4,461 metric tons (1983)
Major industries: petroleum, chemicals,
tourism, food Processing, cement
Electric’p power: 1 Star 000 kWe ‘capacity -
(1985); 2.7 billion kWh produced (1985),
2,275 kWh per capita
Exports: $2.2 billion (f.0.b., 1984); petro- oe
leum and petroleum products, ammonia,
fertilizer, chemicals, sugar, cocoa, coffee,
citrus; includes exports of oil under process-
ing agreement
247
Imports: $1.9 billion (cif, , 1984); crude} pe-. a
troleum (83%), machines: fabricated met-
als, transportation equipment, manufac-
tured goods, food, chemicals; includes i im-"
ports under processing agreement 7
Major trade partners: (1984 prelim.) éx: © -*
ports—US 56%, CARICOM 10%, UK 8%;
imports —US 37%, UE 10%, CARICOM ie:
Aid: Seonbinie-ilaieeal, ceminitients Us,
including Ex-Im (F-Y70-84); $355 million; .
(1970-83) other Western countries, Ope and
OOF, $233 million may
Budget: (1984 prehin ) consolidated central: :
government revenues, $2.7 billion; expendi...
tures, $3.4 billion (current, $2.5 billion; capi-.
tal, $889 million). Es tit
Monetary conversion rate: 3.60 Trinidad |
and Tobago dollars=US$1 (December 1985).,
F iscal year: alendar year','6b41bb584a8779a2b7b0fc01f2501392c7a6b25b4bb06203c4c380dae3c70f73','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f93926a26f85b195e7989cac123da0fd63e70abb022ee2f31c1e03d62d219f01',1986,'GR','Greece','economy',502,'GNP: $50.0 billion (1984), $990 per capita; .
5.9% real growth 1983, 4.6% average annual
real growth 1974-84
Natural resources: antimony, coal, chro- .
mium, mercury, copper, borate, oil
Agriculture: main products—cotton, to-
bacco, cereals, sugar beets, fruits, nuts, and
livestock products; self-sufficient in food in
average years; an illegal producer of opium
poppy for the international drug trade
Major industries: textiles, food processing,
mining (coal, chromite, copper, boron min-
erals), steel, petroleum
Crude steel: 3.0 million tons s produced
(1984)
Electric power: 8,685,500 kW capacity
(1985); 34.238 billion kWh produced pee)
667 kWh per capita
Exports: $7,134 million (f.0.b., 1984); cotton,
tobacco, fruits, nuts, metals, livestock prod-
ucts, textiles, clothing, cement, leather, glass,-
. ceramics :
Imports: $10,757 million (c.i-f.,.984); crude
oil, machinery, transport equipment;.metals,
pharmaceuticals, dyes, plastics, rubber, min-
eral fuels, fertilizers, chemicals:
Major trade parties (1984) estes
17.9% ERG, 13.1% Iraa,.10.5% Iran, 7:0% :
Italy, 5.3% Saudi Arabia; imports—14.3%
Iran, 10.9% FRG, 9.9% US, 8. 7% Iraq, 6.1%.
Libya’
Bids: (FY84) revenues, $7.55 billion; ex-
penditures,:$10. 1 billion;.deficit, $2.5 billion
Monetary conversion rate: 551.55 Turkish.
rae! Wcteber ee)
F eal year: flea: year
Communications., oe uauete
Railroads: 8,198 kon] 1. 435. meee eo adials
gauge; 204 km double, track; 109.km ee
fied
Highways: 49,615 km total; 26,915 km bitu-
minous; 16,500 km gravel or crushed stone;
4,000 km improved earth; 2,200 km un-.,
improved earth
Inland waterways: approx. 1,200 km.
Pipelines: 1,288 km crude oil; 2,145 tan re-
fined products’. aoe
Ports: 4 major, 8 secondary,.16 minor, = , .
Cid air: 80.major transport aa ye
Airfields: 120 eral 104 usable; 62; with, #
permanent-surface runways;.3 with run-.
ways over 3,660 m, 27 with runways
2,440-3,659 m, 26 with runways 1;220-. .
2,489m - a
Telecommunications:fair domestic.and - -
international systems; trunk radio-relay net-
work; 2.66 million telephones (5.5 per 100
popl.); 16 AM, 27 EM, 252 TV stations; 2.
satellite ground station antennas, 1 aie:
rine telephone cable
250
Defense Forces
Branches: Land Forces, Navy, Air Force,
Gendarmerie
Military manpower: males 15-49,
12,685,000; 7,507,000 fit for military service;
about 533,000 reach military age (20) annu-
ally ,
Military budget: for fiscal year ending 31
December 1984, $2.3 billion; 17% of central
government budget
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4','c40040799ed06097f1256d50655ee62c6460b7c005604ca3177ed1b22fd89a12','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25496150427e476654769349fa1000b908d1c01806dcb079c3ac31fb2c013300',1986,'TC','Turks and Caicos Islands','economy',503,'> 5Okm +”
North Atlantic
Ocean
Cockburn,{ -GRAND TURK*
_ Harbour @* (Cockburng
kg mt Town} ane
err
as. es ae
Turks
Islands
North Atlantic ;
Ocean
See regional map III
a SS TES TV
Land
430 km?; about two-thirds the size of New
York City; more than 30 islands, including 8
inhabited; largest island is Grand Caicos
’ Water
Limits of territorial waters (claimed): 3 nm
(200 nm fishing zone)
GDP: $15 million, per capita GDP: $2: 020"
uehO)
Notuiral resources: spiny lobster:‘corich 2
Agriculture: corn, beans
Fishing: catch 1,050 metric tons (1983) | ~
Major industries: fishing, tourism; formerly
produced salt Py wl baad Of ho
Expotti: 42.5 million (iosdy ctadvtish, aried
and fresh conch, conch shells“: -” pao
Imports: $20.9 million (1982); foodstuffs,
drink, fobaces: serine
Major trade’ Seabee: US (abstr, conch,
tourism) and UK: en ee ee em
251.
Budget: revenues, $5.9 million; expendi- ©
tures, $7.2 million (1981/82)
Monetary conversion rate: uses the US dol-
lar
Fiscal yedt? probably calendar','e5d2e419a411d5e49666aafbda41325a882a552de7ed83454c790892a5a9de68','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a35ebfb938bf592257ec79543be5a6be6338eaf019c76bd04b5d9daee5143d6c',1986,'TV','Tuvalu','economy',510,'GNP: $4 million (1984), $450 per capita
Agriculture: limited; coconut palms, copra
Major industry: copra
Electric power: 2,600 kW capacity (1985); 3
million kWh produced (1985), 375 kWh per
capita ‘
Exports: copra—$26,789 (1981)
Imports: $2.8 million (1981); food and min-
eral fuels ,
252
Major trade partners: UK, Australia
Aid: economic commitments—$4.2 million
(1983); Western (non-US) countries, ODA
(1970-79), $22 million
Budget: (1983 est.) revenues, $2:59 million;
expenditures, $3.6 million
Monetary conversion rate: 1.44 Australian
dollars=US$1 (6 February 1986)','bc2243ec292530a24cec12a0881344368f6ceed562edef63644d85f543d57f07','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd4bcbb9e1fd31a740dc03bc4da2c9b17ff6f437bef50f7eda667e9344a06acb',1986,'UG','Uganda','economy',514,'GDP: $5.9 billion in 1983 (est.), approxi-
mately $220 per capita; real growth rate
5.0% (1983/84 est.)
Natural resources: copper, cobalt, limestone
Agriculture: main cash crop—coffee
(180,600 metric tons produced in 1983/84,
est.); other cash crops—cotton, tobacco, tea,
sugar, fish, livestock
Major industries: agricultural processing
(textiles, sugar, coffee, plywood, beer), ce-
ment, copper smelting, corrugated iron
sheet, shoes, fertilizer
Electric power: 200,000 kW capacity (1985);
438 million kWh produced (1985), 29 kWh
per capita
Exports: $380 million (f.0.b., 1983/84 est.);
coffee (98%), cotton, tea
Imports: $509 million (c.i.f., 1983/84 est.);
petroleum products, machinery, cotton
piece goods, metals, transport equipment,
food
Major trade partners: exports—31% US,
12% UK, 10% France; imports—32% Kenya,
11% UK, 11% FRG (1983)
Budget: current receipts 7.7% of GDP
(FY83/84); expenditures, 6.4% of GDP; cap-
ital expenditures, 1.1% of GDP
Monetary conversion rate: 1,400 Uganda
shillings=US$1 (December 1985)
Fiscal year: 1 July-30 June
GDP: $28.2 billion (1984 est. t) $24,000 per ~
capita
Natural resources: oil and natural gas; oil
production in 1984, 1.1 million b/d
Agriculture: food imported; some dates,
alfalfa, vegetables, fruit, tobacco raised
Electric power: 6,015,000 kW capacity
(1985); 15.807 billion kWh produced (1985),
12,300 kWh per capita
Exports: $14.1 billion (f.0.b., 1984); $12.8
billion in crude oil, $1.8 billion consisting
mostly of gas, reexports, dried fish, dates
Imports: $6.9 billion (f.0.b., 1984); food, con-
sumer and capital goods
Major trade partners: Japan, EC, US
Budget: (1984) current expenditures, $3.7 |
billion; development, $0.2 billion; revenue, —
$3.9 billion
Monetary conversion rate: 3.671 UAE
dirhams=US$1 (October 1985)
Fiscal year: calendar year.','facf232c09fbe3dd6ae6c7d55f662450f49e499a13d61adf42c08984ab667153','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88f0bc0fcadf1f99bc1196d4413488ccf2894848d4227094ac1560646884bcf8',1986,'GB','United Kingdom','economy',518,'GNP: $426.3 billion (1984), $7, 640 per cap-
ita; 60.3% consumption, 17.1% investment,
21.6% government; 0.0% stockbuilding, —
1.0% net foreign balance, real growth 2.0%
(1984)
Natural resources: coal, oil, gas (North Sea),
tin, limestone, iron, salt, clay, chalk, gyD-
sum, lead, silica.
Agriculture: mixed farming predominates;. :
main products—wheat, barley, potatoes,
sugar beets, livestock, dairy products; 62.1%
self-sufficient (1983); dependent on imports
for more than half of consumption of refined
sugar, butter, oils and fats, bacon and ham
256
Fishing: catch 846,535 metric tons (1983);
imports 707;000 metric tons (1983), exports
879,000 metric tons ( Tes)
Major industries: netic and transport .
equipment, metals, food processing, paper
and paper products, textiles, chemicals, - -
clothing
Crude steel: 15. 2 million acti tons pro-
duced (1984); 267 kg per capita-(1984); 23.6
million tons capacity (1984)
Electric power: 95,533,000 kW capacity
(1985); 292:661 billion kWh produced
(1985), 5,186 kWh per capita
Exports: $94.2 billion (f.0.b., 1984); manu-
factured goods, machinery, fuels, chemicals, ,
semifinished goods, transport equipment
Imports: $105.2 billion (c.i-f., 1984); manu- .
factured goods, machinery, semifinished
goods; foodstuffs, consumer goods
Major trade partners: exports—44.8% EC
(10.6%. FRG; 10% France, 8.7% Nether-
lands), 14.4% US,-2.3% Communist (1984); °
imports—44.7% EC (14.1% FRG, 7.8% ° -
Netherlands, 7.5% France), 11.9% US, 2.6%
Communist (1984)
Aid: donor—ODA and OOF economic aid. -
commitments (1970-82) $14.4 billion
Budget: national and local government reve-
nues (FY85 est.), $208.6 billion; expendi-
tures, $22).2 billion; deficit $12.6 billion
Monetary conversion rate: 0. 701 pound
sterling=US$1 Decrmber 1985)
Fiscal year: 1 Apal: 31 March
Conniianieaiions
Railroads: Great Britain—17,249 km total;
British Railways (BR) operates 16,964 km
1.435-meter standard gauge (3,749 km elec-.
trified, 12,591 km double or multiple track),
and 19 km 0.597-meter gauge; several addi- _
tional small standard-gauge and narrow-
gauge lines are privately owned and oper-
ated; Northern Ireland Railways (NIR)
operates 332 km 1.600-meter gauge, 190 km
double track
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Highways: United Kingdom, 362,982 km
total; Great Britain, 339,483 km paved (in-
cluding 2,573 km limited-access divided -
highway); Northern Ireland, 23,499 km
(22,907 paved; 592 km gravel):
Inland waterways: 3,219 km publicly
owned; 605 km major commercial routes
Pipelines: 933 km crude oil, almost all insig- ~
nificant; 2,993 km refined pies 12,800
km natural gas i
Ports: 9 major, 15 secondary; 190 minor
Civil air: 618 major transport aircraft
Airfields: 548 total, 345 usable; 246 with
permanent-surface runways; 1 with run-
ways over 8,659 m, 37 with runways ”
2,440-3,659 m, 137 with runways
1,220-2,439 m : ;
Pcdet vinndenlioas modern: efficient .
domestic and international system; 29.5 mil-
lion telephones (52.5 per 100 popl.); excel-.
lent countrywide broadcast systems with - -''
210 AM, 436 FM, 2,736 TV stations; 35 coax-
ial submarine cables; 4 earth''satellite stations
with a total of 9 antennas
Defense Forces
Branches: Royal Army, Royal Navy, Royal - .
Air Force, Royal Marines ~~
Military manpower: males 15-49, .
14,039,000; 11,906,000 fit for mmalitery: ser-
vice; no-conscription. -
Military budget: for fiscal year ending 31
March 1985, $24.1 billion; about 19:7% of
central government budget
United States —
3000 km :
+, Hawaiian
* Islands
See regional map IT
This “Factsheet” on the US is provided
solely as a service to those wishing to make
rough comparisons of foreign country data
with a US “yardstick.”” Information is from
US open sourees and publications and in
no sense represents estimates by the US
Intelligence Community.
Land
9,372,614 km? (contiguous US plus Alaska
and Hawaii); 32% forest; 27% grazing and
pasture; 19% cultivated; 22% waste, urban,
and other
Water
_ Limits of territorial waters s(Glabned ):3nm
(200 nm exclusive economic zone); includes -
Puerto Rico, US Virgin Islands, American
Samoa, Guam, Johnston Atoll,. Wake Island,
Jarvis Island; Kingman Reef, Howland and
Baker Islands, Northern Marianas
Coastline: 19,924 km','dd117af8286bd4db00a305bf879c7abe590f3074542a47b3b33065946d717830','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e73df938bd996cf5165fc0a8c07bb60625d1f24c4a5fa40227bd61a43675f49',1986,'UY','Uruguay','economy',521,'GDP: $5.2 billion (1984), $1,800 per capita;
89% consumption, 13% gross investment,
—2.0% foreign; real growth rate 1984,
—1. 8%
Natural resources: soil, hydroelectric p power
(potential), minor minerals
Agriculture: large areas devoted to extensive
livestock grazing; main crops—wheat, rice, ’
corn, sorghum; self- sufficient i in most basic.
foodstuffs ©
Major industries: meat processing, wool and
hides, textiles, footwear, leather apparel, ©
tires, cement, fishing, petroleum refining
Electric power: 1,350,000 kW ‘capacity
(1985); 5.2 billion kWh produced (1985),
1,771 kWh per capita,
Exports: $925 million (f.0.b., 1984); wool,
hides, meat, textiles, leather products, fish,
rice, furs
Imports: $732 million (f. ob., 1984); fuels
and lubricants (37%), metals, machinery,
transportation equipment, industrial chemi-
cals |
Major trade partners: exports—22% LAIA;
21% EC, 8% US, imports—39% LAIA (13%
Brazil, 11% Argentina), 15% EC, 7% US
(1981)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Uruguay (continued)
Aid: economic commitments—US autho-
rized, including Ex-Im (FY70-84), $78 mil-
lion; other Western countries, ODA and
OOF (1970-83) $151 million; Communist
countries (1970-84), $65 million; military—
US authorized (FY70-84) $39 million
Budget: (1983 est.) revenues, $709 million;
expenditures, $901 million
Monetary conversion rate: 119.6 new
pesos=US$1 (November 1985)
Fiscal year: calendar year','58b3e89d5423d390b95fc9f0a7c35509235ac000595ee99bab924c9a76910976','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1035792bd6651a03a7a8bda7c04c7f8f670cbc8bffcc0294644bda83cb83684',1986,'VU','Vanuatu','economy',526,'GDP: $77 million ages average annual
growth rate 5.0% (1985 est.) .
Natural resources: manganese, hardwood
forests, cattle
Agriculture: export crops of copra, cocoa,
coffee, some livestock and fish production;
subsistence crops of copra, taro, yams
Fishing: catch, 2,470 metric tons (1983)
Major industries: fish-freezing, canneries,
tourism
"Electric power: 10,000 kW capacity (1985);
20 million kWh produced (1985), 150 kWh
per capita
Exports: $44 million (1984); 24% copra, 59%
frozen fish, meat
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Imports: $66 million (1984); 18% food
Aid: Australia (1980-83), $14.4 million
Monetary conversion rate: 102.084
vatu=US$1;, 1.44 Australian dollars=US$1
(6 February 1986)
The Vatican City, seat of the Holy See, is
supported financially by contributions
(known as Peter’s pence) from Roman Cath-
olics throughout the world; some income
derived from sale of Vatican postage stamps
and tourist mementos, fees for admission to
Vatican museums, and sale of publications;
industrial activity consists solely of printing
and production of a small amount of mosaics
and staff uniforms; the banking and financial
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Vatican City (continued)
activities of the Vatican are worldwide; the
Institute for Religious Works (IOR) carries
out fiscal operations and invests and trans-
fers funds of Roman Catholic religious com-
munities throughout the world; the Adminis-
tration of the Patrimony of the Holy See
manages the Holy See’s capital assets; the
Vatican announced an operating deficit of
$25 million for 1981
Electric power: 3,000 kW (standby) capacity
(1985); power supplied by Italy
Monetary conversion rate: the Vatican is-
sues its own coinage, which is interchange-’ _
able with the Italian lira; 1,785.4 lira=US$ 1
(February 1984)
GDP: $47 billion (1985), $2,680 per capita ©
(1985); 60.4% private consumption, 12.5%
public consumption, 14.8% gross invest-
ment, 12.3% foreign (1984); real growth rate
0.4% (1985) as
Natural resources: petroleum, natural gas,
iron ore, gold, bauxite, other minerals, hhy-
droelectric power
Agriculture: main crops—cereals, fruits,
sugar, coffee, rice; an illegal producér of
coca and cannabis for the international drug
trade
Fishing: catch 226,870 metric tons (1983); j
exports $12.4 million (1982), imports $30. 0
million (1982) :
Major industries: petroleum, iron-ore min-
ing, construction, food processing, textiles,
steel, aluminum, motor vehicles
Crude steel: 2.8 million metric tons pro- *
duced (1985), 154 kg per capita
Electric power: 13,000,000 kW capacity
(1985); 37 billion kWh produced (1965),
2,135 kWh per capita * ;
Exports: $15.8 billion (f.0.b., 1984 prelim. );
petroleum (94%) ~
Imports: $7.3 billion (f.0.b., 1984) .
Major trade partners: imports—46% US,
5.2% Japan, 5.2% FRG, 4.8% Italy; exports—
40.9% US, 10.3% Italy, 7% FRG (1984)
Budget: revised 1984—revenues, $17.4 bil
lion; expenditures, $16.9 billion
Declassified and Approved For Release 2012/08/29 :
Monetary conversion rate: (official) 7.
bolivares= US$1 (1 January 1986) ~
Fiscal year: calendar year
Communications ; ks :
Railroads: 439 km ‘total: 260 ‘ita 1. 485-meter
standard gauge all single track, government
owned; 179 km 1.435-meter gauge,”
privately owned .
Highways: 77,185 km total; 22,780km
paved, 24,720 km gravel, 14,450 km earth
roads, and 15,835 km unimproved earth
Inland waterways: 1, 100 km; Rio Orinoco _
and Lago de Maracaibo accept oceangoing
vessels
Pipelines: 6,370 km crude oil; 480 km re-, .
fined products; 2,480 km natural gas
Ports: 6 major, 17 minor
Civil air: 58 major transport aircraft
Airfields: 278 total, 254 usable; 107 with —
permanent-surface runways; 7 with run- |
ways 2,440-3,659 m, 87 with runways
1,220-2,439 m
Telecommunications: modern expanding _
telecom system; 1.44 million telephones (9.5''
per 100 popl.); 180 AM; 58 TV stations; 3
submarine coaxial-cables; 1 Atlantic Ocean:
satellite station with 2 antennas, and 3 do-
mestic satellite stations © eee
Defense Forces
Branches: Ground Forces, Naval Forces, Ait
Forces, Armed Forces of Cooperation (Na-
tional Guard), Marines, Coast Guard ©
Military manpower: males 15-49, 4,323,000;
3,283,000 fit for military service; 193, 000°
reach military age (18) annually - S$
263 |
Vietnam
400km__
Gulf of
Tonkin = 3, -.,
Boundary representation 1s
nol necessarily authoritative af
Cam Ranh
South','0fabadda04827f5bfb5bd8a03b1f87c6c553cf1a1a6bf98bae8a03c49598511d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73554a642005e64768e2bf5cd8e16386ee0f2ece867c74380f7d85877c22a40d',1986,'WF','Wallis and Futuna','economy',530,'Agrictilture: dominated by coconut produc-
tion, with subsisterice crops of yams, taro,
bananas:
Electric power: 1,000 kW capacity (1985); 1
million kWh produced (1985), 83 kWh per.
eapita-
Exports: negligible ; -
Imports: $3.4 million (1977); largely food-
stuffs and some equipment associated with
development ‘programs |
Aid: (1978) France, European Development
Fund, $2.6 million
M onetary conversion rate: 127.05 Colonial
Francs Pacifique (CFP)=US$1 (December
1982) :
Natural resources: phosphates ironore .
Agriculture: practically none; some barley is
grown in nondrought years; fruit and vege-
tables in the few oases; food imports are es-
sential; camels, sheep, and goats are kept by
the nomadic natives; cash economy exists
largely for the garrison forces
Major industries: phosphate, fishing, and
handicrafts
Shortages: water
Electric power: 60,000 kW capacity (1985);
78 million kWh produced (1985), 857 kWh
per capita
Exports: in 1982, up to $5 million in phos-
phates, all other exports valued valued at
under $3 million ‘* .
Imports: up to $30 million (1982); fuel for
fishing feet, foodstufts
Major trade partners: Morocco claims ad-
ministrative control over Western Sahara
and controls all trade with the country;
Western Sahara trade figures are included in
overall Moroccan accounts
Aid: previously received small amounts
from Spain; Morocco is now the major
source of support
Monetary conversion rate: uses Moroccan
dirham; 8.9 dirham=US$1 (1984)
GNP: $50 million (1984), $770 per capita
Natural resources: hardwood forests, fish
Agriculture: cocoa, a, barianas; copra; staple
foods include coconuts, Bananas: taro, yams,
Major industries: timber, tourism, Hight i in-
dustry °°" * a
Electric power: 62,000 kW capacity lige
79 million kWh produced (pe): 485 2
per capita :
Exports: $19.5 million (1984): copra. 43.8%;
cocoa. 32.3%, timber 2.0%, mineral fuel; ba- --
nanas . on
Imports:.$57 million (1984); food 30%, man-
ufactured goods 25%, machinery
Major trade. partners: exports—31 % FRG,
26% New Zealand, 12% US, 2% Australia;
imports—30% US, 28% New Zealand, 10%,
Australia, 6% UK (1981)
Aid: economic commitments—US (F Y70-
84), $12 million; Western (non-US) coun-
tries, ODA and OOF (1970-83), $176 million
Budget: (1982 est.) revenues, $36.9 million;
expenditures, $37.6 million; development
expenditure, $34.9 million
Monetary conversion rate: 1.533 WS tala=
US$1 (February 1984)
GNP: $3.6 billion (1983), $580 per capita
Natural resources: petroleum, rock salt,
small deposits of coal and copper, oil
Agriculture: sorghum and millet, gat (a mild
narcotic), cotton, coffee, fruits and vegeta-
bles
Major industries: cotton textiles and leather
goods produced on a small scale; handicraft
and some fishing; small aluminum products
factory
Electric power: 254,900 kW capacity (1985),
446 million kWh prodiiced’ (1985), 73 kWh -
per capita ~
Exports: $9 million (f0.b., 1984); gat, cotton,
coffee, hides, vegetables -
Imports: $1.4 billion (f.0.b., 1984); textiles
and other manufactured consumer goods,
petroleum products, sugar, grain, flour,
other foodstuffs, and cement (one of the
worst export/import ratios in the world)
Major trade partners: China, South Yemen,
USSR, Japan, UK, Australia, Saudi Arabia
Budget: (1984) total receipts, $830 million;
- current expenditures, $1.1 billion; develop-
ment expenditures, $480 million
Monetary conversion rate: 6.5 rials=US$1
(October 1985).
Fiscal year: | July-30J une','d690f6b74f8bb1df748019b9bfb8d0ff65800f32c9f6e3709069d0eee5ba0d41','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('255689eab1c9452ae4d2c037a56a09479871076fc8b9827ebd33e630052fc1a9',1986,'YE','Yemen','economy',534,'GNP: $792 million (1978 est.), $430 per cap-
ita (1980) _
Natural resources: fish
Agriculture: cotton is main cash crop; cere-
als, dates, qat (a mild narcotic), coffee, and .
livestock are raised, and''there is a growing
fishing industry; large amount of food must 7
be imported (particularly for Aden); cotton, ‘
hides, skins, dried‘and salted fish are
exported
Major industries: petroleum refinery at Lit-
tle Aden operates on imported crude
Electric power: 235,200 kW capacity (1985);
446 million kWh produced (1985), 200 kWh’
per capita
Exports: $800 million (1982)
Imports: $670 million (f.0.b., 1980)
Major trade partners: North Yemen, East
Africa, but some cement and sugar imported -
from Communist countries; crude oil im-
ported from Persian Gulf, exports mainly to
UK and Japan
Budget: (1983) total receipts $452 million,
current expenditures $455 million, develop-
ment expenditures $402 million
Monetary conversion rate: 0.3425
dinar=US$1 (October 1985)
Fiscal year: calendar year
GNP: $128.8 billion (1984 est., at 1988
prices), $5,600 per capita; ‘réal growth rate
—1.7% (1984)
Natural resources: coal, copper, bauxite,
timber, iron, antimony, chromium, lead,
zinc, asbestos, mercury
Agriculture: diversified agriculture with
many small private holdings and large agri-
cultural combines; main crops—corn,
wheat, tobacco, sugar beets, and sunflowers;
occasionally a net exporter of, foodstuffs and
live animals; imports tropical products, cot-
ton, wool, and vegetable meal feeds
Fishing: catch 73,505 metric tons (1984)
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Declassified and Approved For Release 2012/08/29 : CIA-RDP08-00534R000100170001-4
Major industries: metallurgy, machinery ,
and equipment; oil refining, chemicals, tex-
tiles, wood processing, food processing
Shortages: electricity, fuels
Crude steel: 4.2 million metric tons pro-
duced (1984), 184 kg per capita
Electric power: 19,575,000 kW capacity
(1985); 77.516 billion kWh produced (1985),
3,350 kWh per capita _
Exports: $10.3 billion (f.0.b., 1984); 52% raw
materials and semimanufactures, 31% con-
sumer goods, 17% equipment
Imports: $12.0 billion (c.i.f., 1984); 82% raw
materials and semimanufactures, 13%
equipment, 5% consumer goods
Major trade partners: 61% non-Communist
countries; 39% Communist countries, of
which 21% USSR (1984)
Monetary éonversion rate: 296.4
dinars=US$1 (November 1985)
Fiscal year: calendar year (all data refer to
calendar year or to middle or end of calen-
dar year as indicated) | :
GDP: $4.5 billion (1983), $200 per capita;.
2.0% real growth (1985 est.)
Natural resources: cobalt, copper,
cadmium, petroleum, industrial and gem
diamonds, gold, silver, zinc, manganese, tin,
germanium, uranium, radium, bauxite, iron,
coal, hydroelectric power (potential)
Agriculture: main cash crops—coffee, palm
oil, rubber, quinine; main food crops—man-
ioc, bananas, root crops, corn; some prov-
inces self-sufficient
Fishing: catch 102,000 metric tons (1983)
Major industries: mining, mineral process-
ing, consumer products (including textiles,
footwear, and cigarettes), processed foods
and beverages, cement
Electric power: 2, 412,200 kW capacity
(1985); 5.282 billion kWh produced (1985),
175 kWh per capita
Exports: $1.846 billion (f.0.b., 1984); $1.824
billion (1985 est.) copper (45%), cobalt, dia-
monds, petroleum, coffee
Imports: $1.102 billion (f.0.b., 1984 est.);
$1.113 billion (1985 est.) consumer goods,
foodstuffs, mining and other machinery,
transport equipment, fuels .
Major trade partners: Belgium, i France,
and West Germany.
Budget: (1985 est.) revenues, $780 million;
total expenditures, $739 million
272
Monetary conversion rate: 55 zaires=US$1
(December 1985)
Fiscal year: calendar year','a1fa997c293ac40d2f48ced9731716ffa309909a05853c2945dd48e28791c549','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a26b651d64a18cb2918daab06e1df3ced606e954d8faa0c4d7f315ce303c3f6',1986,'ZW','Zimbabwe','economy',537,'GDP: $6.6 billion (1982), $870 per capita;
real growth 12% (1980 and 1981), 2% (1982)
Natural resources: coal; chromé, asbestos,”
gold, nickel, copper, iron ore, vanadium, |
lithium
Agriculture: main crops—tobacco, corn, tea,
sugar, cotton; livestock
Major industries: mining, steel, fete.
chemicals, vehicles _
Electric power: 1,608,500 kw capacity, io
(1985); 4.691 billion kWh produced (1985),
541 kWh per capita:
Exports: $1.17 billion (f.0.b., 1984), includ-
ing net gold sales and reexports; tobacco,
asbestos, cotton, copper, tin, chrome, gold,
nickel, meat, clothing, sugar, iron ore, silver _
Imports: $989 million (E. o.b. 1984); machin-
ery, petroleum products, wheat, transport
equipment
Major trade partner: South Africa
Aid: economic commitments—Western .
(non-US) countries, ODA and OOF
(1970-83), $1.0 billion; US, including Ex-Im .
(1980-84), $271 million; Communist coun- |
tries (1970-84), $100 million
Budget: (FY83/84 est.) revenues, $1.82 bil-
lion; expenditures, $2.223 billion; deficit,
$400 million
Monetary conversion rate: 1.67
Zimbabwean dollars=US$1 (November
1985)
Declassified and Approved For Release 2012/08/29 :
Fiscal year: 1 July-30 June
Communications 3
Railroads: 3,394 km_1.067-meter gauge; 42
km double track; 835 km electrified
Highays: 85, 237 7 kn total 12,243 km
paved, 28,090 km-crushed stone, gravel, sta-
bilized soil: 23,097 km improved earths,
2] 807 i unimproved e Cee
Inland twatérways: Lake Kariba i isa poten-
tial line of communication
Pipelines:8 hintreflngd products
Civil air: 12 major transport aircraft eee
Airfields: 497 total, 444 usable; 22 with
permanent-surface runways; 2 with, run- bon
ways over 3,659 m, 3 with Tunways 7 a
2,440-3,659 m, 36 with ri runways 1 220-
2 Sa m
Pea? | RE ie
Telecommunications: system was one of the
best in Africa but now suffers from poor
maintenance; consists of radio- relay links,
open-wire lines, and radio communication
n
stations; principal center Harare, secondary .
center Bulawayo; 246,800 telephones (3. 8
per 100 popl.); 8 AM, 15 FM, 8 TV stations; T
Atlantic Ocean satellite. station
Defense Forces
Branches: Zimbabwe National Ae ‘Air’
Force of Zimbabwe, Police Support Unit,
People’ s Militia , 7
Military } manpower: males 15- 49, ] 927, 000; ;
1,184,000 fit for military service’
M ilitary budget: for fiscal y: year ending 30°
June 1985, $307.4 million; 10. A%, of. central
government budget
275
CIA-RDP08-00534R000100170001-4
Taiwan
(China listed in
alphabetic order)
100 km
Taiwan Strait
Pescadores
Philippine
Sea
Quemoy and Matsu
islands are not shown
a
See regional map VIII :
Land
32,260 km? (Taiwan and Pescadores); the
size of Maryland and Delaware combined;
55% forest, 24% cultivated, 6% pasture, 15%
other (urban, industrial, waste, or water)
Water
Limits of territorial waters (claimed): 3 nm
(200 nm exclusive economic zone)
Coastline: 1,240 km Taiwan, 327 km
Pescadores
GNP: $56.6 billion (1984 est), $2,980 per
capita; 4.6% real growth (1985) :
Natural resources: small deposits of coal,
natural gas, limestone, marble, and asbestos
Agriculture: most arable land intensely
farmed—60% cultivated land under irriga-
tion; main crops—rice, sweet potatoes, sug- ,
arcane, bananas, pineapples, citrus fruits;
food shortages—wheat, corn, soybeans .
Fishing: catch 930,582 metric tons (1983)
Major industries: textiles, clothing, chemi-
cals, electronics, food processing, plywood,
sugar milling, cement, shipbuilding --
Electric power: 16,067,000 kW capacity _
(1985); 58 billion kWh produced (1985),
2,738 kWh per capita
Exports: $80.4 billion (f.0.b.; 1984 est.);
20.5% textiles, 18.8% electrical machinery,
9% general machinery and equipment, 9% -
telecommunications equipment, 7.4% basic
metals and metal products, 5.4% foodstuffs,
2.5% plywood and wood products
276
Imports: $21.6 billion (c.i.£., 1984 est.); 25%
machinery and equipment, 17.7% crude oil,
11.9%-chemical and chemical products,
6.7% basic metals, 6.3% foodstuffs
Major trade partners: exports—49% US,
10% Japan; imports—29% Japan, 23% US,
8.6% Saudi Arabia (1983)
Aid: economic commitments—US authori-
zations, including Ex-Im (FY 46-82), $4.6 ~
billion; Western (non-US) countries, ODA
and OOF (1970-83), $402 million;
military —US (F Y46-81), $4.4 billion autho-
rized
Budget: central government expenditure,
$42.5 billion (FY83)
Monetary conversion rate: NT (New Tai-
wan) 40.39 dollars=US$1 (September 1985)
Fiscal year: 1 July-30 June
GNP: West Banke $1. 1 billion (1983): Gaza
Strip—$550 million (1983)
Agriculture: olives, citrus, and other fruits,
vegetables, beef, and dairy products
Major industries: the Israelis have estab-
lished some small-scale modern industries in
the settlements and industrial centers (3 in
West Bank and 1 in Gaza Strip); generally
small family businesses that produce ce-
ment, textiles, soap,.olive wood carvings,
and mother-of-pearl souvenirs
Electric power: the Israel Electric Corpora-
tion, Ltd., exported 285 million kWh during
1985 (exported is understood to mean power
providéd to-occupied territories)
West Bank: bulk of installed capacity con-
tained in two diesel power plants—
Jerusalem-Shoufat plant.(22,000 kW),
- which is owned and operated by the East
Jerusalem Electric Co., and Nablus plant
(19,600 kW), which is owned and operated
by the Nablus municipality; total estimated
capacity for all West Bank power plants is
45,000 kW (1985); 59 million kWh produced
(1985), 63 kWhrper capita’ ”
Gaza Sirip: no known installed capacity;
power probably obtained from Israel
Exports: West Bank—$184. 5.million (1984);
Gaza Strip—$1 14.9 million (1984)
Imports: West Bank—$406.8 maillion (1984);
Gaza Strip—$279.4 million (1984)
Major trade partners: West Bank—Jordan
and Israel; Gaza Strip—Egypt and Israel
Declassified and Approved For Release 2012/08/29 : CIA-RDP0O8-00534R000100170001-4
Budget: within the occupied territories,
each municipality has its own budget; the
following data represent the sum of the reve-
nues and expenditures of the municipalities
in each area for fiscal year beginning 1 April
1984
West Bank: revenues, $26.7 million; expen-
ditures, $27.1 million
_ Gaza Strip: revenues, $14.2 million; expen-
* ditures, $18.2 million mt
Monetary conversion rate: West Bank: units
of currency used are Israeli shekel
_ (293.2=US$1, 1984 average), Jordanian di-
nar (0.384= US$1, 1984 average), and US
dollar
Gaza Strip: units of currency used are Israeli
shekel (293.2=US$1, 1984 average), Egyp-
tian pound (1.43=US$1, February 1984 av-
erage), and US dollar','63c795a0d8ac483a882fc8e3dcd0770c2f5f4b64f5933d816e412de84b1425da','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100170001-4','txt','0b5a13664c02742a9f5dbabbfe5e0dea9d4fe4b1675d00b1e1be77799a3c660a','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100170001-4/cia-rdp08-00534r000100170001-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

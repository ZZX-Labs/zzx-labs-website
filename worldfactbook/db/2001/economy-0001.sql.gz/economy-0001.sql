SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47633446de6f671d5a396b1a2558003c4dc92958fe3dffc594bdce037a1cab80',2001,'EH','Western Sahara','economy',12,'Economy • overview
GDP
GDP ■ real growth rate
GDP ■ per capita
GDP ■ composition by sector
agriculture
industry
services
Population below poverty line
Household income or consumption by
percentage share
lowest 10%
highest 10%
Inflation rate (consumer prices)
Labor force
Labor force - by occupation
Unemployment rate
Budget
revenues
expenditures
Industries
Industrial production growth rate
Electricity • production
Electricity - production by source
fossil fuel
hydro
nuclear
other
Electricity - consumption
Electricity - exports
Electricity - Imports
Agriculture - products
Exports
Exports ■ commodities
Exports - partners
Imports
Imports - commodities
Imports - partners
Debt ■ external
Economic aid - donor
Economic aid - recipient
Currency
Currency code
Exchange rates
Fiscal year
Economy - overview: Afghanistan is an extremely
poor, landlocked country, highly dependent on
farming and livestock raising (sheep and goats).
Economic considerations have played second fiddle
to political and military upheavals during two decades
of war, including the nearly 10-year Soviet military
occupation (which ended 15 February 1989). During
that conflict one-third of the population fled the
country, with Pakistan and Iran sheltering a combined
peak of more than 6 million refugees. In early 2000, 2
million Afghan refugees remained in Pakistan and
about 1 .4 million in Iran. Gross domestic product has
fallen substantially over the past 20 years because of
the loss of labor and capital and the disruption of trade
and transport; severe drought added to the nation''s
difficulties in 1998-2000. The majority of the
population continues to suffer from insufficient food,
clothing, housing, and medical care. Inflation remains
a serious problem throughout the country.
International aid can deal with only a fraction of the
humanitarian problem, let alone promote economic
development. In 1999-2000, internal civil strife
continued, hampering both domestic economic
policies and international aid efforts. Numerical data
are likely to be either unavailable or unreliable.
Afghanistan was by far the largest producer of opium
poppies in 2000, and narcotics trafficking is a major
source of revenue.
GDP: purchasing power parity- $21 billion
(2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $800
(2000 est.)
GDP - composition by sector:
agriculture: 53%
industry: 28.5%
serv/ces.'' 18.5% (1990)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 1 0 million (2000 est.)
Labor force - by occupation: agriculture 70%,
industry 15%, services 15% (1990 est.)
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: small-scale production of textiles, soap,
furniture, shoes, fertilizer, and cement; handwoven
carpets; natural gas, oil, coal, copper
Electricity - production: 420 million kWh (1999)
Electricity - production by source:
foss/7 fue/.'' 35.71%
hydro: 6A29%
nuclear: 0%
ofoer0%(1999)
Electricity - consumption: 480.6 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 90 million kWh (1999)
Agriculture - products: opium poppies, wheat,
fruits, nuts; wool, mutton, karakul pelts
Exports: $80 million (does not include opium)
(1996 est.)
Exports - commodities: opium, fruits and nuts,
handwoven carpets, wool, cotton, hides and pelts,
precious and semi-precious gems
Exports - partners: FSU, Pakistan, Iran, Germany,
India, UK, Belgium, Luxembourg, Czech Republic
Imports: $150 million (1996 est.)
Imports - commodities: capital goods, food and
petroleum products; most consumer goods
Imports - partners: FSU, Pakistan, Iran, Japan,
Singapore, India, South Korea, Germany
Debt - external: $5.5 billion (1996 est.)
Economic aid - recipient: US provided about $70
million in humanitarian assistance in 1997; US
continues to contribute to multilateral assistance
through the UN programs of food aid, immunization,
land mine removal, and a wide range of aid to
refugees and displaced persons
Currency: afghani (AFA)
Currency code: AFA
Exchange rates: afghanis per US dollar - 4,700
(January 2000), 4,750 (February 1999), 17,000
(December 1996), 7,000 (January 1995), 1,900
(January 1994), 1,019 (March 1993), 850 (1991);
note - these rates reflect the free market exchange
rates rather than the official exchange rate, which was
fixed at 50.600 afghanis to the dollar until 1996, when
it rose to 2,262.65 per dollar, and finally became fixed
again at 3,000.00 per dollar in April 1996
Fiscal year: 21 March - 20 March
Economy - overview: Western Sahara, a territory
poor in natural resources and lacking sufficient
rainfall, depends on pastoral nomadism, fishing, and
phosphate mining as the principal sources of income
for the population. Most of the food for the urban
population must be imported. All trade and other
economic activities are controlled by the Moroccan
Government. Incomes and standards of living are
substantially below the Moroccan level.
GDP: purchasing power parity ■ $NA
GDP - real growth rate: NA%
GDP “ per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: 40%-45% (1 996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o: NA%
Inflation rate (consumer prices): NA%
Labor force: 12,000
Labor force - by occupation: animal husbandry
and subsistence farming 50%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: phosphate mining, handicrafts
Industrial production growth rate: NA%
Electricity - production: 90 million kWh (1999)
Electricity ■ production by source:
fossil fuel: ^00%
hydro: 0%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 83.7 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: fruits and vegetables
(grown in the few oases); camels, sheep, goats (kept
by nomads)
Exports: $NA
Exports - commodities: phosphates 62%
Exports - partners: Morocco claims and
administers Western Sahara, so trade partners are
included in overall Moroccan accounts
Imports: $NA
Imports - commodities: fuel for fishing fleet,
foodstuffs
Imports - partners: Morocco claims and administers
Western Sahara, so trade partners are included in
overall Moroccan accounts
552
WestGrn Sahara (continued)
Debt «■ external: $NA
Economic aid - recipient: $NA
Currency: Moroccan dirham (MAD)
Currency code: MAD
Exchange rates: Moroccan dirhams per US dollar -
10.590 (January 2001), 10.626 (2000), 9.804 (1999),
9.604 (1998), 9.527 (1997), 8.716 (1996)
Fiscal year: calendar year
Economy - overview: Growth in global output
(gross world product, GWP) rose to 4.8% in 2000 from
3.5% in 1999, despite continued low growth in Japan,
severe financial difficulties in other East Asian
countries, and widespread dislocations in several
transition economies. The US economy continued its
remarkable sustained prosperity, growing at 5% in
2000, although growth slowed in fourth quarter 2000;
the US accounted for 23% of GWP. The EU
economies grew at 3.3% and produced 20% of GWP.
China, the second largest economy in the world,
continued its strong growth and accounted for 1 0% of
GWP. Japan grew at only 1 .3% in 2000; its share in
GWP is 7%. As usual, the 15 successor nations of the
USSR and the other old Warsaw Pact nations
experienced widely different rates of growth. The
developing nations also varied in their growth results,
with many countries facing population increases that
eat up gains in output. Externally, the nation-state, as
a bedrock economic-political institution, is steadily
losing control over international flows of people,
goods, funds, and technology. Internally, the central
government often finds its control over resources
slipping as separatist regional movements - typically
based on ethnicity - gain momentum, e.g.. In many of
the successor states of the former Soviet Union, in the
former Yugoslavia, in India, and in Canada. In
Western Europe, governments face the difficult
political problem of channeling resources away from
welfare programs in order to increase investment and
strengthen incentives to seek employment. The
addition of 80 million people each year to an already
overcrowded globe is exacerbating the problems of
pollution, desertification, underemployment,
epidemics, and famine. Because of their own internal
problems and priorities, the industrialized countries
devote insufficient resources to deal effectively with
the poorer areas of the world, which, at least from the
economic point of view, are becoming further
marginalized. Continued financial difficulties in East
Asia, Russia, and many African nations, as well as the
slowdown in US economic growth, cast a shadow over
short-term global economic prospects; GWP probably
will grow at 3-4% in 2001 . The introduction of the euro
as the common currency of much of Western Europe
in January 1999, while paving the way for an
integrated economic powerhouse, poses serious
economic risks because of varying levels of income
and cultural and political differences among the
participating nations. (For specific economic
developments in each country of the world in 2000,
see the individual country entries.)
GDP: GWP (gross world product) - purchasing
power parity - $43.6 trillion (2000 est.)
GDP - real growth rate: 4.8% (2000 est.)
GDP - per capita: purchasing power parity - $7,200
(2000 est.)
GDP ■ composition by sector:
agriculture: 4%
industry: 32%
services: 64% (1 999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): all countries
25%; developed countries 1% to 3% typically;
developing countries 5% to 60% typically (2000 est.)
note: national inflation rates vary widely in individual
cases, from stable prices in Japan to hyperinflation in
a number of Third World countries
Labor force: NA
Labor force - by occupation: agricultue NA%,
industry NA%, services NA%
Unemployment rate: 30% combined
unemployment and underemployment in many
non-industrialized countries; developed countries
typically 4%-12% unemployment (2000 est.)
Industries: dominated by the onrush of technology,
especially in computers, robotics,
telecommunications, and medicines and medical
equipment; most of these advances take place in
OECD nations; only a small portion of non-OECD
countries have succeeded in rapidly adjusting to
these technological forces; the accelerated
development of new industrial (and agricultural)
technology is complicating already grim
environmental problems
Industrial production growth rate: 6% (2000 est.)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Exports: $6 trillion (f.o.b., 2000 est.)
Exports - commodities: the whole range of
industrial and agricultural goods and services
Exports - partners: in value, about 75% of exports
from the developed countries
Imports: $6 trillion (f.o.b., 2000 est.)
Imports - commodities: the whole range of
industrial and agricultural goods and services
Imports - partners: in value, about 75% of imports
by the developed countries
Debt - external: $2 trillion for less developed
countries (2000 est.)
Economic aid - recipient: traditional worldwide
foreign aid $50 billion (1997 est.)','2209031a122ad405ee8b1e45ed9efb1eb71f989943f26a150b9c79c56dd8e74f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86d2bc83e822411d7b5bd05d428a58b632a67a62476cd84dfff11c8291dc4c92',2001,'AL','Albania','economy',21,'Economy - overview: Poor by European standards,
Albania is making the difficult transition to a more
open-market economy. The economy rebounded in
1 993-95 after a severe depression accompanying the
end of the previous centrally planned system in 1990
and 1991 . However, a weakening of government
resolve to maintain stabilization policies in the election
year of 1996 contributed to renewal of inflationary
pressures, spurred by the budget deficit which
exceeded 12% of GDP. The collapse of financial
pyramid schemes in early 1997 - which had attracted
deposits from a substantial portion of Albania''s
population - triggered severe social unrest which led
to more than 1 ,500 deaths, widespread destruction of
property, and a 7% drop in GDP. The government has
taken measures to curb violent crime and to revive
economic activity and trade. The economy is
bolstered by remittances from some 20% of the labor
force that works abroad, mostly in Greece and Italy.
These remittances supplement GDP and help offset
the large foreign trade deficit. Most agricultural land
was privatized in 1992, substantially improving
peasant incomes. In 1998, Albania recovered the 7%
drop in GDP of 1 997 and pushed ahead by 8% in 1 999
and by 7.5% in 2000. International aid helped defray
the high costs of receiving and returning refugees
from the Kosovo conflict. Privatization scored some
successes in 2000, but other reforms lagged.
GDP: purchasing power parity - $10.5 billion
(2000 est.)
GDP - real growth rate: 7.5% (2000 est.)
GDP - per capita: purchasing power parity - $3,000
(2000 est.)
GDP - composition by sector:
agriculture: 55%
industry: 24%
se/v/ces;2r/o(2000)
Population below poverty line; 19.6% (1996 est.)
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1% (2000 est.)
Labor force: 1 .692 million (including 352,000
emigrant workers and 261 ,000 domestically
unemployed) (1994 est.)
Labor force - by occupation: agriculture 50%,
industry and services 50%
Unemployment rate: 1 6% (2000 est.) officially; may
be as high as 25%
Budget:
revenues; $393 million
expenditures: %515 million, including capital
expenditures of $NA (1997 est.)
Industries: food processing, textiles and clothing;
lumber, oil, cement, chemicals, mining, basic metals,
hydropower
Industrial production growth rate: 9% (2000 est.)
Electricity - production: 5.332 billion kWh (1999)
Electricity - production by source:
fossil fuel: 3.31%
hydro: 93.19%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 5.379 billion kWh (1999)
Electricity - exports: 1 00 million kWh (1 999)
Electricity - imports: 600 million kWh (2000)
4
Albania (continued)
Agriculture - products: wheat, corn, potatoes,
vegetables, fruits, sugar beets, grapes; meat, dairy
products
Exports: $310 million (f.o.b., 2000 est.)
Exports - commodities: textiles and footwear;
asphalt, metals and metallic ores, crude oil;
vegetables, fruits, tobacco
Exports - partners: Italy 67%, Greece 15%,
Germany 5%, Austria 2%, The Former Yugoslav
Republic of Macedonia 2% (2000)
Imports: $1 billion (f.o.b., 2000 est.)
Imports ■ commodities: machinery and equipment,
foodstuffs, textiles, chemicals
Imports - partners: Italy 37%, Greece 28%, Turkey
6%, Germany 6%, Bulgaria 3% (2000)
Debt -external: $1 billion (2000)
Economic aid - recipient: $NA; aid for energy from
China, Germany, Norway (2000)
Currency: lek(ALL)
Currency code: ALL
Exchange rates: leke per US dollar - 146.08
(December 2000), 143.71 (2000) 137.69 (1999),
150.63 (1998), 148.93 (1997), 104.50 (1996); note -
leke is the plural of lek
Fiscal year: calendar year
Population below poverty line: 23% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.0%
highest 10%o:20.0%(m0)
Inflation rate (consumer prices): 2% (2000 est.)
Labor force: 9.1 million (2000 est.)
Labor force - by occupation: government 29%,
agriculture 25%, construction and public works 15%,
industry 11%, other 20% (1996 est.)
Unemployment rate: 30% (1999 est.)
Budget;
revenues; $15.8 billion
expenditures: $16 billion, including capital
expenditures of $5.3 billion (2001 est.)
Industries: petroleum, natural gas, light industries,
mining, electrical, petrochemical, food processing
Industrial production growth rate: 7% (1999 est.)
Electricity - production; 23.21 5 billion kWh (1 999)
Electricity - production by source:
foss/7 /ue/; 99.14%
hydro: 0.86%
nuclear: 0%
ofoer;0%(1999)
Electricity ■ consumption: 21.613 billion kWh
(1999)
Electricity - exports: 307 million kWh (1999)
Electricity - Imports: 330 million kWh (1999)
Agriculture - products: wheat, barley, oats, grapes,
olives, citrus, fruits; sheep, cattle
Exports: $19.6 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum, natural gas,
and petroleum products 97%
Exports - partners: Italy 22%, US 15%, France
12%, Spain 11%, Brazil 8%, Netherlands 5% (1999)
Imports: $9.2 billion (f.o.b., 2000 est.)
Imports - commodities: capital goods, food and
beverages, consumer goods
Imports - partners; France 30%, Italy 9%, Germany
7%, Spain 6%, US 5%, Turkey 5% (1999)
Debt - external: $25 billion (2000 est.)
Economic aid ■ recipient: $100 million (1999 est.)
Currency: Algerian dinar (DZD)
Currency code: DZD
Exchange rates: Algerian dinars per US dollar -
74,81 3 (January 2001 ), 75.260 (2000), 66.574 (1 999),
58.739 (1998), 57.707 (1997), 54.749 (1996)
Fiscal year: calendar year','0165197902cfb90f8ebcefaba08d1f11f6c6656f91df9351d59bc5a680674d08','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cc9f0be2aa202e600927ca0c4a6e1fa76cececa89bd28ce59199ae9c5da33bf',2001,'AS','American Samoa','economy',31,'Economy - overview: This is a traditional
Polynesian economy in which more than 90% of the
land is communally owned. Economic activity is
strongly linked to the US, with which American Samoa
conducts the great bulk of its foreign trade. Tuna
fishing and tuna processing plants are the backbone
of the private sector, with canned tuna the primary
export. Transfers from the US Government add
substantially to American Samoa''s economic
well-being. Attempts by the government to develop a
larger and broader economy are restrained by
Samoa''s remote location, its limited transportation,
and its devastating hurricanes. Tourism, a developing
sector, has been held back by the recurring financial
difficulties in East Asia.
GDP: purchasing power parity - $500 million
(2000 est.)
GDP ■ real growth rate: NA%
GDP - per capita: purchasing power parity - $8,000
(2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); NA%
Labor force: 14,000(1996)
Labor force - by occupation; government 33%,
tuna canneries 34%, other 33% (1990)
Unemployment rate: 1 6% (1 993)
Budget:
revenues; $121 million (37% in local revenue and
63% in US grants)
expenditures: $127 million, including capital
expenditures of $NA (FY96/97)
Industries: tuna canneries (largely dependent on
foreign fishing vessels), handicrafts
Industrial production growth rate: NA%
Electricity - production: 130 million kWh (1999)
Electricity - production by source:
foss/7 fuel; 100%
hydro: 0%
nuclear: 0%
other: 0% {1999)
Electricity - consumption: 120.9 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, coconuts,
vegetables, taro, breadfruit, yams, copra, pineapples,
papayas; dairy products, livestock
Exports: $500 million (1998)
Exports - commodities: canned tuna 93%
Exports - partners: US 99.6%
Imports: $471 million (1996)
Imports - commodities: materials for canneries
56%, food 8%, petroleum products 7%, machinery
and parts 6%
Imports - partners: US 62%, Japan 9%, NZ 7%,
Australia 11%, Fiji 4%, other 7%
Debt - external: $NA
Economic aid - recipient: important financial
support from the US, more than $40 million in 1994
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September','89bf7ac4a8faed2c4995acf346cf35ac14c5f9bdb71dea552e8b470a8d19d179','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d31ca5e32dd8b2ba58d861339dc7d340f55df88337fa8b1d668bba6e6e988b52',2001,'AD','Andorra','economy',38,'Economy - overview: Tourism, the mainstay of
Andorra''s tiny, well-to-do economy, accounts for
roughly 80% of GDP. An estimated 9 million tourists
visit annually, attracted by Andorra''s duty-free status
and by its summer and winter resorts. Andorra''s
comparative advantage has recently eroded as the
economies of neighboring France and Spain have
been opened up, providing broader availability of
goods and lower tariffs. The banking sector, with its
"tax haven" status, also contributes substantially to
the economy. Agricultural production is limited by a
scarcity of arable land, and most food has to be
imported. The principal livestock activity is sheep
raising. Manufacturing output consists mainly of
cigarettes, cigars, and furniture. Andorra is a member
of the EU Customs Union and is treated as an EU
member for trade in manufactured goods (no tariffs)
and as a non-EU member for agricultural products.
GDP: purchasing power parity - $1 .2 billion
(1996 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$18,000 (1996 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .62% (1 998)
Labor force: 30,787 salaried employees (1998)
Labor force - by occupation: agriculture 1%,
industry 21%, services 78% (1998)
Unemployment rate: 0%
Budget:
revenues: $385 million
expenditures: $342 million, including capital
expenditures of $NA (1997)
Industries: tourism (particularly skiing), cattle
raising, timber, tobacco, banking
Industrial production growth rate: NA%
Electricity - production by source:
fossil fuel:
hydro: m%
nuclear: NA%
other: NA%
Electricity ■ consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
note: most electricity supplied by Spain and France;
Andorra generates a small amount of hydropower
Agriculture - products: small quantities of tobacco,
rye, wheat, barley, oats, vegetables; sheep
Exports: $58 million (f.o.b., 1998)
Exports - commodities: tobacco products, furniture
Exports - partners: France 34%, Spain 58% (1998)
Imports: $1,077 billion (c.i.f., 1998)
Imports - commodities: consumer goods, food,
electricity
Imports - partners: Spain 48%, France 35%, US
2.3% (1998)
Debt -external: $NA
Economic aid - recipient: none
Currency: French franc (FRF); Spanish peseta
(ESP); euro (EUR)
Currency code: FRF; ESP; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1 .0854 (2000), 0.9386 (1999); French
francs per US dollar - 5.8995 (1998), 5.8367 (1997),
5.1 155 (1996); Spanish pesetas per US dollar -
149.40 (1998), 146.41 (1997), 126.66 (1996)
Fiscal year: calendar year','7bfef38b63c12b8fbe752b2eaea7f9b8e976159947e04947fb35bf5baf182185','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('622e79e48d865daaabbb7d8ab64b68a33e9cc2f7b0d65b2f865f3b085192312a',2001,'AO','Angola','economy',44,'Economy - overview: Angola is an economy in
disarray because of a quarter century of nearly
continuous warfare. Despite its abundant natural
resources, output per capita is among the world''s
lowest. Subsistence agriculture provides the main
livelihood for 85% of the population. Oil production
and the supporting activities are vital to the economy,
contributing about 45% to GDP and 90% of exports.
Violence continues, millions of land mines remain,
and many farmers are reluctant to return to their fields.
As a result, much of the country''s food must still be
imported. To fully take advantage of its rich
resources - gold, diamonds, extensive forests,
Atlantic fisheries, and large oil deposits - Angola will
need to end its conflict and continue reforming
government policies. Despite the increase in the pace
of civil warfare in late 1998, the economy grew by an
estimated 5% in 2000. The government introduced
new currency denominations in 1999, including 1 and
5 kwanza notes. Internal strife discourages
investment outside of the petroleum sector, which is
producing roughly 800,000 barrels of oil per day.
Angola has entered into a Staff Monitored Program
(SMP) with the IMF. Continued growth depends on
sharp cuts in inflation, further economic reform, and a
lessening of fighting.
GDP: purchasing power parity - $10.1 billion
(2000 est.)
GDP - real growth rate; 4.9% (2000 est.)
GDP - per capita; purchasing power parity - $1 ,000
(2000 est.)
GDP - composition by sector:
agriculture: 7%
industry: 60%
services: 33% (1999 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share;
lowest 10%: NA%
highest 10%>: NA%
Inflation rate (consumer prices): 325% (2000 est.)
Labor force: 5 million (1997 est.)
Labor force - by occupation: agriculture 85%,
industry and services 15% (1997 est.)
Unemployment rate: extensive unemployment and
underemployment affecting more than half the
population (2000 est.)
Budget:
revenues: $928 million
expenditures: $2.5 billion, including capital
expenditures of $963 million (1992 est.)
Industries: petroleum; diamonds, iron ore,
phosphates, feldspar, bauxite, uranium, and gold;
cement; basic metal products; fish processing; food
processing; brewing; tobacco products; sugar; textiles
13
Angola (continued)
Industrial production growth rate; NA%
Electricity - production: 1 .475 billion kWh (1999)
Electricity - production by source:
fossil fuel: 32.2%
hydro: 67.8%
nuclear: 0%
other: Q%{^999)
Electricity - consumption: 1 .372 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: bananas, sugarcane,
coffee, sisal, corn, cotton, manioc (tapioca), tobacco,
vegetables, plantains; livestock; forest products; fish
Exports: $7.8 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil 90%, diamonds,
refined petroleum products, gas, coffee, sisal, fish and
fish products, timber, cotton
Exports - partners: US 54%, South Korea 14%,
Benelux 11%, China 7%, Taiwan 6% (1999)
Imports: $2.5 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and electrical
equipment, vehicles and spare parts; medicines, food,
textiles, military goods
Imports - partners: South Korea 16%, Portugal
15%, US 13%, South Africa 10%, France 8% (1999)
Debt - external: $10.8 billion (2000 est.)
Economic aid - recipient: $493.1 million (1995)
Currency: kwanza (AOA)
Currency code: AOA
Exchange rates: kwanza per US dollar - 1 7,91 0,800
(January 2001), 10,041 ,000 (2000), 2,790,706 (1999),
392,824 (1998), 229,040 (1997), 128,029 (1996);
note - in December 1999 the kwanza was revalued
with six zeroes dropped off the old value
Fiscal year: calendar year','eaae15c4bab47d85b7d58da92e9386485e08f49f4699df9ed30e4c43d7fd2601','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f5f3f5bb96410c78eb930e995696015d6ad9979085d9996193f892332157758',2001,'AI','Anguilla','economy',53,'Economy - overview: Anguilla has few natural
resources, and the economy depends heavily on
luxury tourism, offshore banking, lobster fishing, and
remittances from emigrants. The economy, and
especially the tourism sector, suffered a setback in
late 1995 due to the effects of Hurricane Luis in
September but recovered in 1996. Increased activity
in the tourism industry, which has spurred the growth
of the construction sector, has contributed to
economic growth. Anguillan officials have put
substantial effort into developing the offshore financial
sector. A comprehensive package of financial
services legislation was enacted in late 1994. In the
medium term, prospects for the economy will depend
on the tourism sector and, therefore, on continuing
income growth in the industrialized nations as well as
favorable weather conditions.
GDP: purchasing power parity - $96 million
(1999 est.)
GDP ■ real growth rate: 7% (1999 est.)
GDP ■ per capita: purchasing power parity - $8,200
(1999 est.)
GDP " composition by sector:
agriculture: 4%
industry: 18%
services: 78% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: m%
Inflation rate (consumer prices); 2.5% (1998 est.)
Labor force: 4,400(1992)
Labor force - by occupation: commerce 36%,
services 29%, construction 18%, transportation and
utilities 10%, manufacturing 3%, agriculture/fishing/
forestry/mining 4%
Unemployment rate: 7% (1 992 est.)
Budget:
revenues: $20.4 million
expenditures: $23.3 million, including capital
expenditures of $3.8 million (1997 est.)
Industries; tourism, boat building, offshore financial
services
Industrial production growth rate: 3.1%
(1997 est.)
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity -consumption: NAkWh
Agriculture ■ products: small quantities of tobacco,
vegetables; cattle raising
Exports: $4.5 million (1998)
Exports - commodities: lobster, fish, livestock, salt
Exports - partners; NA
Imports: $57.6 million (1998)
Imports - commodities: NA
Imports - partners: NA
Debt - external: $8.8 million (1998)
Economic aid - recipient: $3.5 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Fiscal year: 1 April - 31 March
15
Anguilla (continued)','88a6148d88fb442c57935cb398ceeb8865e548374e69b60c83ce3ef2b9145f38','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('895212a437339f3e43dafed8b1c1d7c6bd3c9d6bac10c9ac2764fb100fe5587c',2001,'AQ','Antarctica','economy',60,'Economy ■ overview: Fishing off the coast and
tourism, both based abroad, account for the limited
economic activity. Antarctic fisheries in 1998-99
(1 July-30 June) reported landing 1 19,898 metric
tons. Unregulated fishing landed five to six times more
than the regulated fishery, and allegedly illegal fishing
in antarctic waters in 1998 resulted in the seizure (by
France and Australia) of at least eight fishing ships.
Companies interested in commercial fishing activities
in Antarctica have put forward proposals. The
Convention on the Conservation of Antarctic Marine
Living Resources determines the recommended catch
limits for marine species. A total of 13,193 tourists
visited in the 1999-2000 summer, up from the 10,013
who visited the previous year. Nearly all of them were
passengers on 24 commercial (nongovernmental)
ships and several yachts that made 143 trips during
the summer. Most tourist trips lasted approximately
two weeks.
17
Antarctica (continued)
Economy - overview: Argentina benefits from rich
natural resources, a highly literate population, an
export-oriented agricultural sector, and a diversified
industrial base. However, when President Carlos
MENEM took office in 1989, the country had piled up
huge external debts, inflation had reached 200% per
month, and output was plummeting. To combat the
economic crisis, the government embarked on a path
of trade liberalization, deregulation, and privatization,
in 1991, it implemented radical monetary reforms
which pegged the peso to the US dollar and limited the
growth in the monetary base by law to the growth in
reserves. Inflation fell sharply In subsequent years. In
1 995, the Mexican peso crisis produced capital flight,
the loss of banking system deposits, and a severe, but
short-lived, recession; a series of reforms to bolster
the domestic banking system followed. Real GDP
growth recovered strongly, reaching 8% in 1997. In
22
Argentina (continued)
1998, international financial turmoil caused by
Russia''s problems and increasing investor anxiety
over Brazil produced the highest domestic interest
rates in more than three years, halving the growth rate
of the economy. Conditions worsened in 1999 with
GDP falling by 3%. President Fernando DE LA RUA,
who took office in December 1999, sponsored tax
increases and spending cuts to reduce the deficit,
which had ballooned to 2.5% of GDP in 1999. Growth
in 2000 was a disappointing 0.8%, as both domestic
and foreign investors remained skeptical of the
government''s ability to pay debts and maintain its
fixed exchange rate with the US dollar. One bright
spot at the start of 2001 was the IMF''s offer of $13.7
billion in support.
GDP: purchasing power parity - $476 billion
(2000 est.)
GDP - real growth rate: 0.8% (2000 est.)
GDP ■ per capita: purchasing power parity -
$12,900 (2000 est.)
GDP ■ composition by sector:
agriculture: 6%
industry: 32%
services: 62% (2000 est.)
Population below poverty line; 37% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Infiation rate (consumer prices): -0.9% (2000 est.)
Labor force: 1 5 million (1 999)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 1 5% (December 2000)
Budget:
revenues: $44 billion
expenditures: $48 billion, including capital
expenditures of $NA billion (2000 est.)
Industries: food processing, motor vehicles,
consumer durables, textiles, chemicals and
petrochemicals, printing, metallurgy, steel
Industrial production growth rate: 1% (2000 est.)
Electricity - production: 77.087 billion kWh (1999)
Electricity - production by source:
fossil fuel: 60.3%
hydro: 30.7%
nuclear: 8.75%
other; 0.25% (1999)
Electricity “ consumption: 77.111 billion kWh
(1999)
Electricity - exports: 1 .08 billion kWh (1 999)
Electricity - imports: 6.5 billion kWh (1999)
Agriculture - products: sunflower seeds, lemons,
soybeans, grapes, corn, tobacco, peanuts, tea,
wheat; livestock
Exports: $26.5 billion (f.o.b., 2000 est.)
Exports - commodities: edible oils, fuels and
energy, cereals, feed, motor vehicles
Exports - partners; Brazil 24%, EU 21%, US 11%
(1999 est.)
Imports: $25.2 billion (f.o.b., 2000 est.)
Imports ■ commodities: machinery and equipment,
motor vehicles, chemicals, metal manufactures,
plastics
Imports - partners: EU 28%, US 22%, Brazil 21%
(1999 est.)
Debt - external: $154 billion (2000 est.)
Economic aid - recipient: IMF offer of $1 3.7 billion
(January 2001)
Currency: Argentine peso (ARS)
Currency code: ARS
Exchange rates; Argentine pesos per US dollar -
1 .000 (fixed rate pegged to the US dollar)
Fiscal year: calendar year
Economy - overview: Under the old Soviet central
planning system, Armenia had developed a modern
industrial sector, supplying machine tools, textiles,
and other manufactured goods to sister republics in
exchange for raw materials and energy. Since the
implosion of the USSR in December 1991 , Armenia
has switched to small-scale agriculture away from the
large agroindustrial complexes of the Soviet era. The
agricultural sector has long-term needs for more
investment and updated technology. The privatization
of industry has been at a slower pace, but has been
given renewed emphasis by the current
administration. Armenia is a food importer, and its
mineral deposits (gold, bauxite) are small. The
ongoing conflict with Azerbaijan over the ethnic
Armenian-dominated region of Nagorno-Karabakh
and the breakup of the centrally directed economic
system of the former Soviet Union contributed to a
severe economic decline in the early 1990s. By 1994,
however, the Armenian Government had launched an
ambitious IMF-sponsored economic program that has
resulted in positive growth rates in 1995-2000.
Armenia also managed to slash inflation and to
privatize most small- and medium-sized enterprises.
The chronic energy shortages Armenia suffered in
recent years have been largely offset by the energy
supplied by one of its nuclear power plants at
Metsamor. Armenia''s severe trade imbalance,
importing three times its exports, has been offset
somewhat by international aid, domestic restructuring
of the economy, and foreign direct investment.
GDP: purchasing power parity - $10 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $3,000
(2000 est.)
GDP ■ composition by sector:
agriculture: 40%
industry: 25%
services: 35% (1999 est.)
Population below poverty line: 45% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest fO%;NA%
Inflation rate (consumer prices): 1% (1999 est.)
Labor force; 1 .5 million (1 999)
Labor force - by occupation; agriculture 55%,
services 25%, industry 20% (1999 est.)
Unemployment rate: 20% (1998 est.)
note: official rate is 9.3% for 1 998
Budget:
revenues; $360 million
expenditures: $536 million, including capital
expenditures of $NA (1 999 est.)
Industries: metal-cutting machine tools,
forging-pressing machines, electric motors, tires,
knitted wear, hosiery, shoes, silk fabric, chemicals,
trucks, instruments, microelectronics, gem cutting,
jewelry manufacturing, software development, brandy
Industrial production growth rate: 5% (2000 est.)
Electricity - production: 6.668 billion kWh (1999)
Electricity - production by source:
fossil fuel: 45.53%
hydro: 23.25%
nuclear: 31. W/o
other; 0% (1999)
Electricity - consumption: 6.201 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: fruit (especially grapes),
vegetables; livestock
Exports: $284 million (f.o.b., 2000 est.)
Exports - commodities: diamonds, scrap metal,
machinery and equipment, brandy, copper ore
Exports - partners: Belgium 36%. Iran 15%, Russia
14%, US 7%, Turkmenistan, Georgia (1999)
Imports: $913 million (f.o.b., 2000 est.)
Imports ■ commodities: natural gas, petroleum,
tobacco products, foodstuffs, diamonds
Imports - partners: Russia 17%, US 11%, Belgium
11%, Iran 10%, UK, Turkey (1999)
Debt - external: $836 million (January 2001)
Economic aid - recipient: $245.5 million (1995)
Currency: dram (AMD)
Currency code: AMD
Exchange rates; drams per US dollar - 554.29
(1 February 2001), 539.53 (2000), 535.06 (1999),
504.92 (1998), 490.85 (1997), 414.04 (1996)
Fiscal year: calendar year
Economy ■ overview: Tourism is the mainstay of
the Aruban economy, although offshore banking and
oil refining and storage are also important. The rapid
growth of the tourism sector over the last decade has
resulted in a substantial expansion of other activities.
Construction has boomed, with hotel capacity five
times the 1985 level. In addition, the reopening of the
country''s oil refinery in 1993, a major source of
employment and foreign exchange earnings, has
further spurred growth. Aruba''s small labor force and
less than 1% unemployment rate have led to a large
number of unfilled job vacancies, despite sharp rises
in wage rates in recent years.
GDP: purchasing power parity - $2 billion (2000 est.)
GDP - real growth rate: 3.5% (2000 est.)
GDP - per capita: purchasing power parity -
$28,000 (2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 4.2% (2000 est.)
Labor force: 41,501 (1997 est.)
Labor force ■ by occupation: most employment is
in wholesale and retail trade and repair, followed by
hotels and restaurants; oil refining
Unemployment rate: 0.6% (1999 est.)
Budget:
revenues: SNA
expenditures: $541 million, including capital
expenditures of SNA (2000 est.)
Industries: tourism, transshipment facilities, oil
refining
Industrial production growth rate: NA%
Electricity - production: 450 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 418.5 million kWh
(1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: aloes; livestock; fish
Exports: $2.2 billion (including oil reexports)
(2000 est.)
Exports - commodities: live animals and animal
products, art and collectibles, machinery and
electrical equipment, transport equipment
Exports - partners: US 42%, Colombia 20%,
Netherlands 12% (1999)
Imports: $2.5 billion (2000 est.)
Imports - commodities: machinery and electrical
equipment, crude oil for refining and reexport,
chemicals: foodstuffs
Imports - partners: US 63%, Netherlands 1 1%,
Netherlands Antilles 3%, Japan (1999)
Debt - external: $285 million (1996)
Economic aid - recipient: $26 million (1 995); note -
the Netherlands provided a $127 million aid package
to Aruba and Suriname in 1996
Currency: Aruban guilder/florin (AWG)
Currency code: AWG
Exchange rates: Aruban guilders/florins per US
dollar - 1.7900 (fixed rate since 1986)
Fiscal year: calendar year
Economy - overview: no economic activity','dcf9c553501a232b4c077e752362fa2b2b48509b8abf048e8cbad9109af31951','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dbe1448ce0298ccb72d825ebb8c211477eb2589f88864bfce0c4a776e429a77',2001,'AG','Antigua and Barbuda','economy',68,'Economy - overview: Tourism continues to be the
dominant activity in the economy accounting directly
or indirectly for more than half of GDP. The budding
offshore financial sector has been seriously hurt by
financial sanctions imposed by the US and UK as a
result of the loosening of its money-laundering
controls. The government has made efforts to comply
with international demands in order to get the
sanctions lifted. Antigua and Barbuda was listed as a
tax haven by the OECD in 2000. The dual island
nation''s agricultural production is mainly directed to
the domestic market; the sector is constrained by the
limited water supply and labor shortages that reflect
the pul! of higher wages in tourism and construction.
Manufacturing comprises enclave-type assembly for
export with major products being bedding,
handicrafts, and electronic components. Prospects for
economic growth in the medium term will continue to
depend on income growth in the industrialized world,
especially in the US, which accounts for about
one-third of all tourist arrivals.
GDP: purchasing power parity - $533 million
(1999 est.)
GDP - real growth rate; 4.6% (1999 est.)
GDP - per capita: purchasing power parity - $8,200
(1999 est.)
GDP - composition by sector:
agriculture: 4%
industry: 12.5%
services: 83.5% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .6% (1999 est.)
19
Antigua and Barbuda (continued)
Labor force: 30,000
Labor force - by occupation: commerce and
services 82%, agriculture 11%, industry 7% (1983)
Unemployment rate: 7%(1999est.)
Budget:
revenues; $122.6 million
expenditures: A]. 2 million, including capital
expenditures of $17.3 million (1997 est.)
Industries: tourism, construction, light
manufacturing (clothing, alcohol, household
appliances)
Industrial production growth rate: 6% (1997 est.)
Electricity - production: 95 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
ofoer; 0% (1999)
Electricity - consumption: 88.4 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cotton, fruits, vegetables,
bananas, coconuts, cucumbers, mangoes,
sugarcane; livestock
Exports: $38 million (1998)
Exports - commodities: petroleum products 48%,
manufactures 23%, machinery and transport
equipment 17%, food and live animals 4%, other 8%
Exports - partners: OECS 26%, Barbados 15%,
Guyana 4%, Trinidad and Tobago 2%, US 0.3%
Imports: $330 million (1998)
Imports - commodities: food and live animals,
machinery and transport equipment, manufactures,
chemicals, oil
Imports “ partners: US 27%, UK 16%, Canada 4%,
OECS 3%
Debt - external: $357 million (1998)
Economic aid - recipient: $2.3 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Fiscal year: 1 April - 31 March','9db993b43f2abccc30d2330b2c41be68427e357a5a2efbaa040db13fb54ce6c6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c95c55b4292cad8e3b6e315494e5fd62e18e6c1317a098477d59aac79906a02',2001,'GP','Guadeloupe','economy',76,'Economy - overview: Economic activity is limited to
the exploitation of natural resources, including
petroleum, natural gas, fish, and seals.','a7193d22d5850bc7a607495bb9f8f46f620f33c2a396068fd64b5074b02b2afe','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c85030bca17ee240c71c4768be0ca6ada15475409e37da477f0dd094a21c1475',2001,'AU','Australia','economy',83,'Economy - overview: The Atlantic Ocean provides
some of the world''s most heavily trafficked sea routes,
between and within the Eastern and Western
Hemispheres. Other economic activity includes the
exploitation of natural resources, e.g., fishing, the
dredging of aragonite sands (The Bahamas), and
production of crude oil and natural gas (Caribbean
Sea, Gulf of Mexico, and North Sea).
Economy - overview: Australia has a prosperous
Western-style capitalist economy, with a per capita
GDP at the level of the four dominant West European
economies. Rich in natural resources, Australia is a
major exporter of agricultural products, minerals,
metals, and fossil fuels. Commodities account for 57%
of the value of total exports, so that a downturn in
world commodity prices can have a big impact on the
economy. The government is pushing for increased
exports of manufactured goods, but competition in
international markets continues to be severe. While
Australia has suffered from the low growth and high
unemployment characterizing the OECD countries in
the early 1990s and during the recent financial
problems in East Asia, the economy has expanded at
a solid 4% annual growth pace in the last five years.
Canberra''s emphasis on reforms is a key factor behind
the economy''s resilience to the regional crisis and its
stronger than expected growth rate. Growth in 2001
will depend on key international commodity prices, the
extent of recovery in nearby Asian economies, and the
strength of US and European markets.
GDP: purchasing power parity - $445.8 billion
(2000 est.)
GDP - real growth rate: 4.7% (2000 est.)
GDP - per capita: purchasing power parity -
$23,200 (2000 est.)
GDP - composition by sector:
agriculture: 3%
industry: 26%
services: 71 % (1 999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2%
highest 25.4% (1994)
Inflation rate (consumer prices): 1 .4% (2000 est.)
Labor force: 9.5 million (December 1999)
Labor force - by occupation: services 73%,
industry 22%, agriculture 5% (1997 est.)
Unemployment rate: 6.4% (2000)
Budget:
revenues: $94 billion
expenditures: $^03 billion, including capital
expenditures of $NA (1999 est.)
Industries: mining, industrial and transportation
equipment, food processing, chemicals, steel
Industrial production growth rate: 1.5%
(1999 est.)
Electricity - production: 1 91 .727 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 89.93%
hydro: 8.36%
nuclear: 0%
ote; 1.71% (1999)
Electricity - consumption: 178.306 billion kWh
(1999)
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: wheat, barley, sugarcane,
fruits; cattle, sheep, poultry
Exports: $69 billion (f.o.b., 2000 est.)
Exports - commodities: coal, gold, meat, wool,
alumina, iron ore, wheat, machinery and transport
equipment
Exports ■ partners: Japan 19%, EU 14%, ASEAN
12%, US 9%, South Korea, NZ, Taiwan, Hong Kong,
China (1999)
Imports: $77 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment, computers and office machines,
telecommunication equipment and parts; crude oil
and petroleum products
Imports - partners: EU 24%, US 22%, Japan 14%,
ASEAN 13% (1999)
Debt - external: $220.6 billion (2000)
Economic aid ■ donor: ODA, $1 .43 billion
(FY97/98)
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates: Australian dollars per US dollar -
1 .7995 (January 2001 ), 1 .71 73 (2000), 1 .5497 (1999),
1.5888 (1998), 1.3439 (1997), 1.2773 (1996)
Fiscal year: 1 July - 30 June
Economy ■ overview: Austria with its
well-developed market economy and high standard of
living is closely tied to other EU economies, especially
Germany''s. Membership in the EU has drawn an
influx of foreign investors attracted by Austria''s access
to the single European market and proximity to EU
aspirant economies. In 2000, Austria moved to further
cut government spending and raise taxes to meet
EMU deficit targets after facing unexpected difficulties
in reducing the public deficit. To meet increased
competition from both EU and Central European
countries, Austria will need to emphasize
knowledge-based sectors of the economy and
continue to deregulate the service sector. Growth is
expected to remain at about 3% In 2001 .
GDP: purchasing power parity - $203 billion
(2000 est.)
GDP - real growth rate: 3.1% (2000 est.)
GDP - per capita: purchasing power parity -
$25,000 (2000 est.)
GDP - composition by sector:
agriculture: 2.2%
industry: 30.4%
services: 67.4% (1999 est.)
Population below poverty line: NA%
inflation rate (consumer prices); 2% (2000 est.)
Labor force: 3.7 million (1999)
Labor force - by occupation; services 68%,
industry and crafts 29%, agriculture and forestry 3%
(1999 est.)
Unemployment rate: 5,4% (2000 est.)
Budget:
revenues: $56.3 billion
expenditures: $50.5 billion, including capital
expenditures of $NA (2000 est.)
Industries: construction, machinery, vehicles and
parts, food, chemicals, lumber and wood processing,
paper and paperboard, communications equipment,
tourism
Industrial production growth rate: 4.2% (2000)
Electricity - production: 59.283 billion kWh (1999)
Electricity - production by source:
fossil fuel: 29.53%
hydro: 57.55%
nuclear: 0%
other; 2.82% (1999)
Electricity - consumption: 53.231 billion kWh
(1999)
Electricity - exports: 1 3.507 billion kWh (1 999)
Electricity - imports: 1 1 .605 billion kWh (1 999)
Agriculture ■ products: grains, potatoes, sugar
beets, wine, fruit; dairy products, cattle, pigs, poultry;
lumber
Exports: $63.2 billion (2000 est.)
Exports - commodities: machinery and equipment,
paper and paperboard, metal goods, chemicals, iron
and steel; textiles, foodstuffs
Exports - partners: EU 64.2% (Germany 35.7%,
Italy 8.7%, France 4.5%), Switzerland 5.9%, US 4.5%,
Hungary 3.9% (1999)
Imports: $65.6 billion (2000 est.)
Imports - commodities: machinery and equipment,
chemicals, metal goods, oil and oil products;
foodstuffs
Imports - partners: EU 70.3% (Germany 42.5%,
Italy 7.9%, France 5.3%), US 5.4%, Switzerland 3.0%,
Hungary 2.8% (1999)
Debt - external; $1 6 billion (1 999)
Economic aid - donor: ODA, $472 million (1999)
Currency: Austrian schilling (ATS); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Austria at a fixed rate of
13.7603 Austrian shillings per euro and will replace
the local currency for all transactions in 2002
Currency code: ATS; EUR
Exchange rates; euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999);
Austrian schillings per US dollar - 1 1.86 (January
1999), 12.91 (1999), 12.379 (1998), 12.204 (1997),
10.587 (1996)
Fiscal year: calendar year
Economy - overview: Although 115 species of fish
have been identified in the territorial waters of
Clipperton Island, the only economic activity is tuna
fishing.
Economy - overview: This unique, noncommercial
economy is supported financially by contributions
(known as Peter''s Pence) from Roman Catholics
throughout the world, the sale of postage stamps and
tourist mementos, fees for admission to museums,
and the sale of publications. The incomes and living
standards of lay workers are comparable to, or
somewhat better than, those of counterparts who
work in the city of Rome.
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Labor force: NA
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%; note - dignitaries,
priests, nuns, guards, and 3,000 lay workers live
outside the Vatican
Budget:
revenues: $209.6 million
expenditures: $^98 5 million, including capital
expenditures of SNA (1997)
Industries: printing and production of a small
amount of mosaics and staff uniforms; worldwide
banking and financial activities
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - imports: NA kWh; note - electricity
supplied by Italy
Economic aid - recipient: none
Currency: Italian lira (ITL); euro (EUR)
Currency code: ITL; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001 ), 1 .0854 (2000), 0.9386 (1 999);
Vatican lire per US dollar - 2,099 (2000), 1817.2
(1999), 1,736.2 (1998), 1,703.1 (1997), 1,542.9
(1996); note - the Vatican lira is at par with the Italian
lira; the Vatican will start using euros in 2002 in
conjunction with Italy at a fixed rate of 1 ,936. 1 7 lire per
euro
Fiscal year: calendar year
Economy ■ overview: no economic activity
imports: $4.1 million (c.i.f., 1989)
Imports - commodities: food, live animals,
manufactured goods, machinery, fuels, lubricants,
chemicals, drugs
Imports - partners: NZ 59%, Fiji 20%, Japan 13%,
Samoa, Australia, US
Debt -external: $NA
Economic aid - recipient: $8.3 million (1995)
Currency: New Zealand dollar (NZD)
Currency code: NZD
Exchange rates: New Zealand dollars per US
dollar - 2.2502 (January 2001 ), 2.1 863 (2000), 1 .8886
(1999), 1.8629 (1998), 1.5082 (1997), 1.4543 (1996)
Fiscal year: 1 April - 31 March
Economy - overview; Tourism, the primary
economic activity, has steadily increased over the
years and has brought a level of prosperity unusual
among Inhabitants of the Pacific islands. The
agricultural sector has become self-sufficient in the
production of beef, poultry, and eggs.
GDP: purchasing power parity ■ $NA
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%:HA%
Inflation rate (consumer prices): NA%
Labor force; 1,395 (1991 est.)
Labor force - by occupation; tourism NA%,
subsistence agriculture NA%
Unemployment rate: NA%
Budget:
revenues: $4.6 million
expenditures: $4.3 million, including capital
expenditures of $NA (FY92/93)
Industries: tourism
378
Norfolk Island (continued)
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: Hk%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Agriculture - products: Norfolk Island pine seed,
Kentia palm seed, cereals, vegetables, fruit; cattle,
poultry
Exports: $1.5 million (f.o.b., FY91/92)
Exports “ commodities: postage stamps, seeds of
the Norfolk Island pine and Kentia palm, small
quantities of avocados
Exports - partners: Australia, other Pacific island
countries, NZ, Asia, Europe
Imports: $17.9 million (c.i.f., FY91/92)
Imports - commodities: NA
Imports - partners: Australia, other Pacific island
countries, NZ, Asia, Europe
Debt -external: $NA
Economic aid - recipient: $NA
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates: Australian dollars per US dollar -
1 .7995 (January 2001 ), 1 .7173 (2000), 1 .5497 (1 999),
1.5888 (1998), 1.3439 (1997), 1.2773 (1996)
Fiscal year: 1 July - 30 June','2b8aa4f0a6100463d89fce5eddcf9937ab6e2290d0305be1d3a6be6647332dea','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f5e738c607b776c101b55ec07c23c480cc6a59164efb4033c3667926bd9d42b',2001,'AZ','Azerbaijan','economy',95,'Economy - overview: Azerbaijan''s most prominent
products are oil, cotton, and natural gas. Azerbaijan''s
oil production declined through 1997 but has
registered an increase every year since. Negotiation
of 19 production-sharing arrangements (PSAs) with
foreign firms, which have thus far committed $60
billion to oil field development, should generate the
funds needed to spur future industrial development.
Oil production under the first of these PSAs, with the
Azerbaijan International Operating Company, began
in November 1997. Azerbaijan shares all the
formidable problems of the former Soviet republics in
making the transition from a command to a market
economy, but its considerable energy resources
brighten its long-term prospects. Baku has only
recently begun making progress on economic reform,
and old economic ties and structures are slowly being
replaced. An obstacle to economic progress, including
stepped up foreign investment, is the continuing
conflict with Armenia over the Nagorno-Karabakh
region. Trade with Russia and the other former Soviet
republics is declining in importance while trade is
building up with Turkey, Iran, UAE, and the nations of
Europe. Long-term prospects will depend on world oil
prices, the location of new pipelines in the region, and
Azerbaijan''s ability to manage its oil wealth.
35
Azerbaijan (continued)
GDP: purchasing power parity - $23.5 billion
(2000 est.)
GDP - real growth rate: 1 1 .4% (2000 est.)
GDP - per capita: purchasing power parity - $3,000
(2000 est.)
GDP - composition by sector:
agriculture: 22%
industry: 33%
services: 45% (1 999 est.)
Population below poverty line: 60% (2000 est.)
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .8% (2000 est.)
Labor force: 2.9 million (1997)
Labor force - by occupation: agriculture and
forestry 32%, industry 15%, services 53% (1997)
Unemployment rate: 20% (1999 est.)
Budget:
revenues: $777 million
expenditures: $995 million, including capital
expenditures of $NA (1999 est.)
Industries: petroleum and natural gas, petroleum
products, oilfield equipment; steel, Iron ore, cement;
chemicals and petrochemicals; textiles
Industrial production growth rate: 6.9%
(2000 est.)
Electricity - production: 16.378 billion kWh (1999)
Electricity - production by source:
fossil fuel: 86.46%
hydro: 13.54%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 15.432 billion kWh
(1999)
Electricity - exports: 600 million kWh (1999)
Electricity - imports: 800 million kWh (1999)
Agriculture - products: cotton, grain, rice, grapes,
fruit, vegetables, tea, tobacco; cattle, pigs, sheep,
goats
Exports: $1 .9 billion (f.o.b., 2000 est.)
Exports - commodities: oil and gas 75%,
machinery, cotton, foodstuffs
Exports - partners: Italy, Turkey, Russia, Georgia,
Iran
Imports: $1.4 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
foodstuffs, metals, chemicals
Imports - partners: Russia, Turkey, Ukraine, UAE,
Iran
Debt - external: $1 billion (2000)
Economic aid - recipient: ODA, $113 million (1996)
Currency: Azerbaijani manat (AZM)
Currency code: AZM
Exchange rates: Azerbaijani manats per US dollar -
4,579 (1 February 2001 ), 4,342 (October 1 999), 4,373
(1999), 3,869 (1998), 3,985.38 (1997), 4,301.26
(1996)
Fiscal year: calendar year','f44941ff9a914b4e05e93e80bcba202e915ff10cf9e65a01a7d69d7305af944b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bab26fe8e669a8ebf43ff6690e46212386dca43700e009aa946e922369b44008',2001,'BS','Bahamas','economy',100,'Economy - overview: The Bahamas is a stable,
developing nation with an economy heavily
dependent on tourism and offshore banking. Tourism
alone accounts for more than 60% of GDP and directly
or indirectly employs 40% of the archipelago''s labor
force. Moderate growth in tourism receipts and a
boom in construction of new hotels, resorts, and
residences led to an Increase of the country''s GDP by
an estimated 3% In 1998, 6% in 1999, and 4.5% in
2000. Manufacturing and agriculture together
contribute only 10% of GDP and show little growth,
despite government incentives aimed at those
sectors. Overall growth prospects in the short run will
depend heavily on the fortunes of the tourism sector
and continued sturdy growth in the US, which
accounts for the majority of tourist visitors.
GDP: purchasing power parity - $4.5 billion
(2000 est.)
GDP - real growth rate: 4.5% (2000 est.)
GDP - per capita: purchasing power parity -
$15,000 (2000 est.)
GDP “ composition by sector:
agriculture: 3%
industry: 7%
services: 90% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 1 .9% (2000 est.)
Labor force: 156,000 (1999)
Labor force - by occupation: tourism 40%, other
services 50%, Industry 5%, agriculture 5% (1 995 est.)
Unemployment rate: 9% (1998 est.)
Budget:
revenues: $766 million
expenditures: $845 million, including capital
expenditures of $97 million (FY97/98)
Industries: tourism, banking, cement, oil refining
and transshipment, salt, rum, aragonite,
pharmaceuticals, spiral-welded steel pipe
Industrial production growth rate: NA%
Electricity - production: 1.465 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% {1999)
Electricity - consumption: 1 .362 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: citrus, vegetables; poultry
Exports: $376.8 million (2000 est.)
Exports ■ commodities: pharmaceuticals, cement,
rum, crawfish, refined petroleum products
Exports - partners: US 22.3%, Switzerland 15.6%,
UK 15%, Denmark 7.4% (1998)
Imports: $1.73 billion (2000 est.)
Imports " commodities: foodstuffs, manufactured
goods, crude oil, vehicles, electronics
Imports - partners: US 27.3%, Italy 26.5%, Japan
10%, Denmark 4.2% (1998)
Debt - external: $385.8 million (2000 est.)
Economic aid - recipient: $9.8 million (1995)
Currency: Bahamian dollar (BSD)
Currency code: BSD
Exchange rates: Bahamian dollars per US dollar -
1 .000 (fixed rate pegged to the dollar)
Fiscal year: 1 July - 30 June','6a3236c73ac6b530a555e4ffc2bd965ed18da1b256d68ed5efdacec96588db1a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49aca65a1be10b9730d4e2f4ba266241c4ffcbb106d0853953d32b8b3aad4772',2001,'BH','Bahrain','economy',108,'Economy - overview: In Bahrain, petroleum
production and refining account for about 60% of
export receipts, 60% of government revenues, and
30% of GDP. With its highly developed
communication and transport facilities, Bahrain is
home to numerous multinational firms with business in
the Gulf. Bahrain is dependent on Saudi Arabia for oil
revenue granted as aid. A large share of exports
consists of petroleum products made from imported
crude. Construction proceeds on several major
Industrial projects. Unemployment, especially among
the young, and the depletion of both oil and
underground water resources are major long-term
economic problems.
GDP: purchasing power parity -$10.1 billion
(2000 est.)
GDP ■ real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity -
$15,900 (2000 est.)
GDP - composition by sector:
agriculture: 1%
industry: 40%
sen/ices: 53% (1996 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2% (2000 est.)
Labor force: 295,000 (1998 est.)
note: 44% of the population in the 15-64 age group is
non-national (July 1998 est.)
Labor force ■ by occupation: industry, commerce,
and service 79%, government 20%, agriculture 1%
(1997 est.)
Unemployment rate: 15% (1998 est.)
Budget:
revenues; $1.8 billion
expenditures: $2.2 billion, including capital
expenditures of $NA (2001 est.)
Industries: petroleum processing and refining,
aluminum smelting, offshore banking, ship repairing;
tourism
Industrial production growth rate: 2% (2000 est.)
Electricity - production: 6.185 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 5.752 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1 999)
Agriculture - products: fruit, vegetables; poultry,
dairy products; shrimp, fish
Exports: $5.8 billion (f.o.b., 2000)
Exports - commodities: petroleum and petroleum
products 61%, aluminum 7%
Exports - partners: India 14%, Saudi Arabia 5%,
US 5%, UAE 5%, Japan 4%, South Korea 4% (1999)
Imports: $4.2 billion (f.o.b., 2000)
Imports - commodities: nonoi! 59%, crude oil 41%
Imports - partners: France 20%, US 14%, UK 8%,
Saudi Arabia 7%, Japan 5% (1999)
Debt -external: $2.7 billion (2000)
Economic aid - recipient: $48.4 million (1995)
Currency: Bahraini dinar (BHD)
Currency code: BHD
Exchange rates: Bahraini dinars per US dollar -
0.3760 (fixed rate pegged to the US dollar)
Fiscal year: calendar year
Economy - overview: no economic activity','5e554eae19ecfe29d012ca021752f70a574f31f115ef7dc30a819de0c9608c67','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab5a82d1b443c7cd143cd66efa792ac833d32cdaa45f6199391566ecaa5bda53',2001,'BD','Bangladesh','economy',117,'Economy - overview: Despite sustained domestic
and international efforts to improve economic and
demographic prospects, Bangladesh remains one of
the world''s poorest, most densely populated, and
least developed nations. Although more than half of
GDP is generated through the service sector, nearly
two-thirds of Bangladeshis are employed in the
agriculture sector, with rice as the single most
important product. Major impediments to growth
include frequent cyclones and floods, inefficient
state-owned enterprises, inadequate port facilities, a
rapidly growing labor force that cannot be absorbed by
agriculture, delays in exploiting energy resources
(natural gas), insufficient power supplies, and slow
implementation of economic reforms. Reform is
stalled in many instances by political infighting and
corruption at all levels of government. Even so. Prime
Minister Sheikh HASINA''s Awami League
government has made some headway improving the
climate for foreign investors and liberalizing the capital
markets. Progress on other economic reforms has
been halting because of opposition from the
bureaucracy, public sector unions, and other vested
interest groups.
GDP: purchasing power parity - $203 billion
(2000 est.)
GDP - real growth rate: 5.3% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,570
(2000 est.)
GDP ■ composition by sector:
agriculture: 30%
industry: ^Q%
services: 52% (2000 est.)
Population below poverty line: 35.6%
(FY95/96 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.9%
highest 10%: 28.6% (1995-96 est.)
Inflation rate (consumer prices): 5.8% (2000 est.)
Laborforce: 64.1 million (1998)
note: extensive export of labor to Saudi Arabia,
Kuwait, DAE, Oman, Qatar, and Malaysia; workers''
remittances estimated at $1 .71 billion in 1998-99
Labor force ■ by occupation: agriculture 63%,
services 26%, industry 11% (FY95/96)
Unemployment rate: 35.2% (1996)
Budget:
revenues: $4.9 billion
expenditures: billion, including capital
expenditures of $NA (FY99/00 est.)
Industries: cotton textiles, jute, garments, tea
processing, paper newsprint, cement, chemical
fertilizer, light engineering, sugar
Industrial production growth rate: 6.1%
(2000 est.)
Electricity - production: 12.06 billion kWh (1999)
Electricity - production by source:
fossil fuel: 93.7%
hydro: 6.3%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 1 1 .21 6 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: rice, jute, tea, wheat,
sugarcane, potatoes, tobacco, pulses, oilseeds,
spices, fruit; beef, milk, poultry
Exports: $5.9 billion (2000)
Exports - commodities: garments, jute and jute
goods, leather, frozen fish and seafood
Exports - partners: US 31 .2%, Germany 9.95%, UK
8.06%, France 5.82%, Italy 4.42% (1999)
Imports: $8.1 billion (2000)
Imports - commodities: machinery and equipment,
chemicals, iron and steel, textiles, raw cotton, food,
crude oil and petroleum products, cement
Imports - partners: India 12.2%, Singapore 7.8%,
Japan 6.7%, China 6.4%, US 5.3% (1999)
Debt ■ external: $17 billion (2000)
Economic aid - recipient: $1 .575 billion (2000 est.)
Currency: taka (BDT)
Currency code: BDT
Exchange rates: taka per US dollar - 54.000
(January 2001 ), 52.1 42 (2000), 49.085 (1 999), 46.906
(1998), 43.892 (1997), 41.794 (1996)
Fiscal year: 1 July - 30 June','e2c7b5df9ed34a4ef1377dc20eda9061b45b7622b98a6d7c226331578c6dde32','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aa526aa10621844c67bbba159e2a111a06409882de414936630cb9a6467e6df',2001,'BB','Barbados','economy',125,'Economy - overview: Historically, the Barbadian
economy had been dependent on sugarcane
cultivation and related activities, but production in
recent years has diversified into manufacturing and
tourism. The start of the Port Charles Marina project in
Speightstown helped the tourism industry continue to
expand in 1996-2000. Offshore finance and
information services are important foreign exchange
earners, and there is also a light manufacturing sector.
The government continues its efforts to reduce
unemployment, encourage direct foreign investment,
and privatize remaining state-owned enterprises.
Growth should remain steady in 2001 , with new tourist
facilities a plus factor.
GDP: purchasing power parity - $4 billion (2000 est.)
GDP - real growth rate: 2.8% (2000 est.)
GDP - per capita: purchasing power parity -
$14,500 (2000 est.)
GDP - composition by sector:
agriculture: 4%
industry: ]0%
services: 80% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2% (2000 est.)
Labor force: 1 36,000 (1 998 est.)
Labor force - by occupation: services 75%,
industry 15%, agriculture 10% (1996 est.)
Unemployment rate: 11% (1999 est.)
Budget:
revenues: $725.5 million
expenditures: $750.6 million, including capital
expenditures of $126.3 million (FY97/98 est.)
Industries: tourism, sugar, light manufacturing,
component assembly for export
Industrial production growth rate: 0.8% (1996)
Electricity - production: 718 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(im)
Electricity ■ consumption: 667.7 million kWh
(1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: sugarcane, vegetables,
cotton
Exports; $260 million (2000 est.)
Exports - commodities: sugar and molasses, rum,
other foods and beverages, chemicals, electrical
components, clothing
Exports ■ partners: UK 14.8%, US 11.6%, Trinidad
and Tobago 7.6%, Venezuela 6.1%, Jamaica 5.8%
(1998)
Imports: $800.3 million (2000 est.)
Imports - commodities: consumer goods,
machinery, foodstuffs, construction materials,
chemicals, fuel, electrical components
Imports ■ partners: US 30.7%, Trinidad and Tobago
10.2%, Japan 8.3%, UK 7.7%, Canada 2.2% (1998)
Debt - external: $425 million (2000 est.)
Economic aid - recipient: $9.1 million (1995)
Currency: Barbadian dollar (BBD)
Currency code: BBD
Exchange rates: Barbadian dollars per US dollar -
2.0000 (fixed rate pegged to the US dollar)
Fiscal year: 1 April - 31 March','5d9cddd1d6857a4a12f9dc2514f671b7cc9b21a7adae83aca1187a6d4a5a6b05','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c86e01af285d753771c622551502010c95083082383034d7c74b613b8ffef169',2001,'LC','Saint Lucia','economy',133,'Economy - overview: no economic activity
Economy - overview: The recent changes in the EU
import preference regime and the increased
competition from Latin American bananas have made
economic diversification increasingly important in
Saint Lucia. Improvement in the construction sector
and growth of the tourism industry helped expand GDP
in 1998-99. The agriculture sector registered its fifth
year of decline in 1997 primarily because of a severe
decline in banana production. The manufacturing
sector is the most diverse in the Eastern Caribbean,
and the government is beginning to develop
regulations for the small offshore financial sector.
GDP: purchasing power parity - $700 million
(2000 est.)
GDP - real growth rate: 0.5% (2000 est.)
GDP - per capita: purchasing power parity - $4,500
(2000 est.)
GDP ■ composition by sector:
agriculture: 10.7%
industry: 32.3%
sen/ices: 57% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 2.5% (2000 est.)
Labor force; 43,800
Labor force - by occupation: agriculture 43.4%,
services 38.9%, industry and commerce 17.7%
(1983 est.)
Unemployment rate: 15% (1996 est.)
Budget:
revenues: $141.2 million
expencf/fures; $146.7 million, including capita!
expenditures of $25.1 million (FY97/98 est.)
Industries: clothing, assembly of electronic
components, beverages, corrugated cardboard
boxes, tourism, lime processing, coconut processing
Industrial production growth rate: -8.9%
(1997 est.)
Electricity - production: 1 1 0 million kWh (1 999)
Electricity - production by source:
fossil fuel: ^00%
hydro: 0%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 102.3 million kWh
(1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, coconuts,
vegetables, citrus, root crops, cocoa
Exports: $68.3 million (2000 est.)
Exports - commodities: bananas 41%, clothing,
cocoa, vegetables, fruits, coconut oil
Exports - partners: UK 50%, US 24%, Caricom
countries 16% (1995)
Imports: $319.4 million (2000 est.)
Imports - commodities: food 23%, manufactured
goods 21%, machinery and transportation equipment
19%, chemicals, fuels
Imports - partners; US 36%, Caricom countries
22%, UK 11%, Japan 5%, Canada 4% (1995)
Debt ■ external: $131.6 million (1998)
Economic aid - recipient: $51.8 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Fiscal year: 1 April - 31 March','60f865f6e5695ade59a73da95f076e627bfc64f18e03e2b0b09aea2471fefaa3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ef7dea2b1328994cb4f8b47f25cede3b20148952b6b6043e893a6380e8e49c',2001,'FR','France','economy',142,'Economy - overview: Belarus has seen little
structural reform since 1995, when President
LUKASHENKO launched the country on the path of
"market socialism." In keeping with this policy,
LUKASHENKO reimposed administrative controls
over prices and currency exchange rates and
expanded the state''s right to intervene in the
management of private enterprise. In addition to the
burdens imposed by extremely high inflation,
businesses have been subject to pressure on the part
of central and local governments, e.g., arbitrary
changes in regulations, numerous rigorous
inspections, and retroactive application of new
business regulations prohibiting practices that had
been legal. Further economic problems are two
consecutive bad harvests, 1998-99, and persistent
trade deficits. Close relations with Russia, possibly
leading to reunion, color the pattern of economic
developments. For the time being, Belarus remains
self-isolated from the West and its open-market
economies.
GDP: purchasing power parity - $78.8 billion
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity - $7,500
(2000 est.)
GDP - composition by sector:
agriculture: ^3%
industry: 46%
sen/ices: 41 % (1 999 est.)
Population below poverty line: 22% (1995 est.)
Household income or consumption by percentage
share:
lowest 10%: 4.9%
highest 10%: 19.4% (1993)
Inflation rate (consumer prices): 200% (2000 est.)
Labor force: 4.8 million (2000)
Labor force - by occupation: industry and
construction NA%, agriculture and forestry NA%,
services NA%
Unemployment rate: 2.1% officially registered
unemployed (December 2000); large number of
underemployed workers
Budget:
revenues: $4 billion
expenditures: $4.1 billion, including capital
expenditures of $180 million (1997 est.)
Industries: metal-cutting machine tools, tractors,
trucks, earth movers, motorcycles, television sets,
chemical fibers, fertilizer, textiles, radios, refrigerators
Industrial production growth rate: 5% (2000 est.)
Electricity - production: 24.91 1 billion kWh (1999)
Electricity - production by source:
fossil fuel: 99.9%
hydro: 0.1%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 27.647 billion kWh
(1999)
Electricity - exports: 2.62 billion kWh (1999)
Electricity - imports: 7.1 billion kWh (1999)
Agriculture - products: grain, potatoes,
vegetables, sugar beets, flax; beef, milk
Exports: $7.4 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment,
chemicals, metals, textiles, foodstuffs
Exports - partners: Russia 66%, Ukraine, Poland,
Germany, Lithuania (1998)
Imports: $8.3 billion (f.o.b., 2000)
Imports ■ commodities: mineral products,
machinery and equipment, metals, chemicals,
foodstuffs
Imports ■ partners: Russia 54%, Ukraine, Germany,
Poland, Lithuania (1998)
Debt - external: $1 billion (2000 est.)
Economic aid - recipient: $194.3 million (1995)
Currency: Belarusian ruble (BYB/BYR)
Currency code: BYB/BYR
Exchange rates: Belarusian rubles per US dollar -
1 ,1 80 (yearend 2000), 730,000 (1 5 December 1 999),
139,000 (25 January 1999), 46,080 (second quarter
1998), 25,964 (1997), 15,500 (yearend 1996); note -
on 1 January 2000, the national currency was
redenominated at one new ruble to 2,000 old rubles
Fiscal year: calendar year
Economy - overview: This modern private
enterprise economy has capitalized on its central
geographic location, highly developed transport
network, and diversified industrial and commercial
base. Industry is concentrated mainly in the populous
Flemish area in the north, although the government is
encouraging investment in the southern region of
Wallonia. With few natural resources, Belgium must
import substantial quantities of raw materials and
export a large volume of manufactures, making its
economy unusually dependent on the state of world
markets. About three-quarters of its trade is with other
EU countries. Belgium''s public debt is expected to fall
below 1 00% of GDP in 2002, and the government has
succeeded in balancing is budget. Belgium became a
charter member of the European Monetary Union
(EMU) in January 1 999. Economic growth in 2000 was
broad based, putting the government in a good
position to pursue its energy market liberalization
policies and planned tax cuts.
GDP: purchasing power parity - $259.2 billion
(2000 est.)
GDP - real growth rate: 4.1% (2000 est.)
GDP - per capita: purchasing power parity -
$25,300 (2000 est.)
GDP ■ composition by sector:
agriculture: 1 .4%
industry: 26%
services: 72.6% (2000 est.)
Population below poverty line: 4%
Household income or consumption by percentage
share:
lowest 10%: 3.7%
highest 20.2% (1992)
Inflation rate (consumer prices): 2.2% (2000 est.)
Labor force: 4.34 million (1999)
Labor force - by occupation: services 73%,
industry 25%, agriculture 2% (1999 est.)
Unemployment rate: 8.4% (2000 est.)
Budget:
revenues: $114.8 billion
expenaf/fures:$1 17 billion, including capital
expenditures of $7.6 billion (1999)
Industries: engineering and metal products, motor
vehicle assembly, processed food and beverages,
chemicals, basic metals, textiles, glass, petroleum,
coal
Industrial production growth rate: 5.5%
(2000 est.)
Electricity - production: 79.829 billion kWh (1999)
Electricity - production by source:
foss/7 fue/: 40.01%
hydro: 0.42%
nuclear: 58.33%
other: 1 .24% (1 999)
Electricity - consumption: 75.089 billion kWh
(1999)
Electricity - exports: 8.207 billion kWh (1999)
Electricity ■ imports: 9.055 billion kWh (1999)
Agriculture - products: sugar beets, fresh
vegetables, fruits, grain, tobacco; beef, veal, pork,
milk
Exports: $181.4 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment,
chemicals, diamonds, metals and metal products
Exports - partners: EU 76% (Germany 18%,
France 18%, Netherlands 12%, UK 10%) (1999)
Imports: $166 billion (c.i.f., 2000)
Imports - commodities; machinery and equipment,
chemicals, metals and metal products
Imports - partners: EU 71% (Germany 18%,
Netherlands 17%, France 14%, UK 9%) (1999)
Debt - external: $28.3 billion (1999 est.)
Economic aid - donor: ODA, $764 million (1997)
Currency: Belgian franc (BEF); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Belgium at a fixed rate of
40.3399 Belgian francs per euro and will replace the
local currency for all transactions in 2002
Currency code: BEF; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1 .0854 (2000), 0.9386 (1999);
Belgian francs per US dollar - 34.77 (January 1999),
36.229 (1998), 35.774 (1997), 30.962 (1996)
Fiscal year: calendar year
50
Belgium (continued)
Economy - overview: Grown throughout the
islands, coconuts are the sole cash crop. Copra and
fresh coconuts are the major export earners. Small
local gardens and fishing contribute to the food
supply, but additional food and most other necessities
must be imported from Australia.
GDP: purchasing power parity - $NA
GDP ■ real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): NA%
Labor force: NA
Labor force - by occupation: the Cocos Islands
Cooperative Society Ltd. employs construction
workers, stevedores, and lighterage workers; tourism
employs others
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
industries: copra products and tourism
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity -consumption: NAkWh
Agriculture - products: vegetables, bananas,
pawpaws, coconuts
Exports: $NA
Exports - commodities: copra
Exports ■ partners: Australia
Imports: $NA
Imports - commodities: foodstuffs
Imports - partners: Australia
109
Cocos (Keeling) Islands (continued)
Debt -external: $NA
Economic aid - recipient: $NA
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates: Australian dollars per US dollar -
1 7995 (January 2001 ), 1 71 73 (2000), 1 .5497 (1999),
1.5888 (1998), 1.3439 (1997), 1.2773 (1996)
Fiscal year: 1 July - 30 June
Economy - overview: Cote d''Ivoire is among the
world''s largest producers and exporters of coffee,
cocoa beans, and palm oil. Consequently, the
economy is highly sensitive to fluctuations in
international prices for these products and to weather
conditions. Despite government attempts to diversify
the economy, it is still largely dependent on agriculture
and related activities, which engage roughly 68% of
the population. After several years of lagging
performance, the Ivorian economy began a comeback
in 1994, due to the 50% devaluation of the CFA franc
and improved prices for cocoa and coffee, growth in
nontraditional primary exports such as pineapples and
rubber, limited trade and banking liberalization,
offshore oil and gas discoveries, and generous
external financing and debt rescheduling by
multilateral lenders and France. Moreover,
government adherence to donor-mandated reforms
led to a jump in growth to 5% annually in 1996-99.
Growth was negative in 2000 because of the difficulty
of meeting the conditions of international donors,
continued low prices of key exports, and post-coup
instability. In 2001-02, a moderate rebound in the
cocoa market could boost growth back above 3%;
however, political instability could impede growth
again.
GDP: purchasing power parity - $26.2 billion
(2000 est.)
GDP - real growth rate: -0.3% (2000 est.)
GDP “ per capita: purchasing power parity - $1 ,600
(2000 est.)
GDP - composition by sector:
agriculture: 32%
industry: 18%
services: 50% (1 998)
Population below poverty line: NA%
Househoid income or consumption by percentage
share:
lowest 10%: 3.1%
highest 70%; 28.8% (1995)
Infiation rate (consumer prices): 2.5% (2000 est.)
Labor force: 68% agricultural (2000 est.)
Unemployment rate: 13% in urban areas
(1998 est.)
Budget:
revenues: $1.5 billion
expenditures: $2.1 billion, including capital
expenditures of $420 million (2000 est.)
Industries: foodstuffs, beverages; wood products,
oil refining, truck and bus assembly, textiles, fertilizer,
building materials, electricity
Industrial production growth rate: 15%
(1998 est.)
Electricity - production: 4.06 billion kWh (1999)
Electricity - production by source:
fossil fuel: 75.37%
hydro: 24.63%
nuclear: 0%
of^er; 0% (1999)
Electricity - consumption: 3.1 83 billion kWh (1999)
Electricity ■ exports: 593 million kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coffee, cocoa beans,
bananas, palm kernels, corn, rice, manioc (tapioca),
sweet potatoes, sugar, cotton, rubber; timber
Exports: $3.8 billion (f.o.b., 2000 est.)
Exports - commodities: cocoa 33%, coffee, tropical
woods, petroleum, cotton, bananas, pineapples, palm
oil, cotton, fish (1999)
Exports " partners: France 15%, US 8%,
Netherlands 7%, Germany 6%, Italy 6% (1999)
Imports: $2.5 billion (f.o.b., 2000 est.)
Imports - commodities: food, consumer goods;
capital goods, fuel, transport equipment
Imports - partners: France 26%, Nigeria 10%,
China 7%, Italy 5%, Germany 4% (1 999)
Debt - external: $13.9 billion (2000 est.)
Economic aid - recipient: ODA, $1 billion
(1996 est.)
Currency: Communaute Financiere Africaine franc
(XOF); note - responsible authority is the Central
Bank of the West African States
Currency code: XOF
Exchange rates: Communaute Financiere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 511.55 (1996); note - from 1 January 1999,
the XOF Is pegged to the euro at a rate of 655.957
XOF per euro
Fiscal year: calendar year
Economy - overview: The economy was formerly
based on agriculture, mainly sheep farming, but today
fishing contributes the bulk of economic activity. In
1 987 the government began selling fishing licenses to
foreign trawlers operating within the Falklands
exclusive fishing zone. These license fees total more
than $40 million per year, which goes to support the
Island''s health, education, and welfare system. Squid
accounts for 75% of the fish taken. Dairy farming
supports domestic consumption; crops furnish winter
fodder. Exports feature shipments of high-grade wool
to the UK and the sale of postage stamps and coins.
To encourage tourism, the Falkland Islands
Development Corporation has built three lodges for
visitors attracted by the abundant wildlife and trout
fishing. The islands are now self-financing except for
defense. The British Geological Survey announced a
200-mile oil exploration zone around the islands in
1993, and early seismic surveys suggest substantial
reserves capable of producing 500,000 barrels per
day: to date no exploitable site has been identified. An
agreement between Argentina and the UK in 1995
seeks to defuse licensing and sovereignty conflicts
that would dampen foreign interest in exploiting
potential oil reserves.
GDP: purchasing power parity - $52 million
(FY95/96 est.)
GDP - real growth rate: 1% (FY95/96 est.)
GDP - per capita: purchasing power parity -
$19,000 (FY95/96 est.)
GDP ■ composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%:HA%
highest 10%: NA%
Inflation rate (consumer prices): 3.6% (1998)
Labor force: 1,100 (est.)
Labor force - by occupation: agriculture 95%
(mostly sheepherding and fishing)
Unemployment rate: full employment; labor
shortage
Budget:
revenues: $66.2 million
expenditures: million, including capital
expenditures of $23.2 million (FY98/99 est.)
Industries: wool and fish processing; sale of stamps
and coins
Industrial production growth rate: NA%
Electricity - production: 12 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other 0% (1999)
Electricity - consumption: 1 1 .2 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: fodder and vegetable
crops; sheep, dairy products
Exports: $7.6 million (1995)
Exports - commodities: wool, hides, meat
Exports - partners: UK, Japan, Chile, NZ
Imports: $24.7 million (1995)
Imports - commodities: fuel, food and drink,
building materials, clothing
Imports - partners: UK, Japan, Chile, NZ
Debt -external: $NA
Economic aid - recipient: $1.7 million (1995)
Currency: Falkland pound (FKP)
Currency code: FKP
165
Falkland Islands (Islas Malvinas)
(continued)
Exchange rates: Falkland pounds per US dollar -
0.6764 (January 2001 ), 0.6596 (2000), 0.61 80 (1999),
0.6037 (1998), 0.6106 (1997), 0.6403 (1996); note -
the Falkland pound is at par with the British pound
Fiscal year: 1 April > 31 March
Economy - overview: The economy is tied closely
to that of France through subsidies and imports.
Besides the French space center at Kourou, fishing
and forestry are the most important economic
activities. The large reserves of tropical hardwoods,
not fully exploited, support an expanding sawmill
industry which provides sawn logs for export.
Cultivation of crops is limited to the coastal area,
where the population is largely concentrated; rice and
manioc are the major crops. French Guiana is heavily
dependent on imports of food and energy.
Unemployment is a serious problem, particularly
among younger workers.
GDP: purchasing power parity -$1 billion (1998 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $6,000
(1998 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 2.5% (1992)
Labor force: 58,800(1997)
Labor force ■ by occupation: services,
government, and commerce 60.6%, industry 21 .2%,
agriculture 18.2% (1980)
Unemployment rate: 21.4% (1998)
Budget:
revenues; $225 million
expenditures: $390 million, including capital
expenditures of $1 05 million (1 996)
Industries: construction, shrimp processing, forestry
products, rum, gold mining
Industrial production growth rate: NA%
Electricity ■ production: 440 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
off/er; 0% (1999)
Electricity - consumption: 409.2 million kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rice, manioc (tapioca),
sugar, cocoa, vegetables, bananas; cattle, pigs,
poultry
Exports: $155 million (f.o.b., 1997)
Exports ■ commodities: shrimp, timber, gold, rum,
rosewood essence, clothing
Exports - partners: France 62%, Switzerland 7%,
US 2% (1997)
Imports: $625 million (c.i.f., 1997)
Imports - commodities: food (grains, processed
meat), machinery and transport equipment, fuels and
chemicals
Imports - partners: France 52%, US 14%, Trinidad
and Tobago 6% (1997)
Debt - external: $1 .2 billion (1 988)
Economic aid ■ recipient: $NA
Currency: French franc (FRF); euro (EUR)
Currency code: FRF; EUR
Exchange rates: Euros per US dollar - 1 .0659
(January 2001), 1 .0854 (2000), 0.9386 (1999); French
francs per US dollar - 5.8995 (1998), 5.8367 (1997),
5.1155(1996)
Fiscal year: calendar year
Economy ■ overview: Economic activity is limited to
servicing meteorological and geophysical research
stations and French and other fishing fleets. The fish
catches landed on lies Kerguelen by foreign ships are
exported to France and Reunion.
Economy - overview: Gabon enjoys a per capita
income four times that of most nations of sub-Saharan
Africa. This has supported a sharp decline in extreme
poverty; yet because of high income inequality a large
proportion of the population remains poor. Gabon
depended on timber and manganese until oil was
discovered offshore in the early 1970s. The oil sector
now accounts for 50% of GDP. Gabon continues to
face fluctuating prices for its oil, timber, manganese,
and uranium exports. Despite the abundance of
natural wealth, the economy is hobbled by poor fiscal
management. In 1 992, the fiscal deficit widened to
2.4% of GDP, and Gabon failed to settle arrears on its
bilateral debt, leading to a cancellation of
rescheduling agreements with official and private
creditors. Devaluation of its Francophone currency by
50% on 12 January 1994 sparked a one-time
inflationary surge, to 35%; the rate dropped to 6% in
1996. The IMF provided a one-year standby
arrangement in 1994-95, a three-year Enhanced
Financing Facility (EFF) at near commercial rates
beginning in late 1995, and stand-by credit of $1 19
million in October 2000. Those agreements mandate
progress in privatization and fiscal discipline. France
provided additional financial support in January 1997
after Gabon had met IMF targets for mid-1996. In
1997, an IMF mission to Gabon criticized the
government for overspending on off-budget items,
overborrowing from the central bank, and slipping on
its schedule for privatization and administrative
reform. The rebound of oil prices in 1 999-2000 helped
growth, but drops in production hampered Gabon
from fully realizing potential gains. An expected
decline in oil output may lead to contraction in GDP in
2001-02.
GDP: purchasing power parity - $7.7 billion
(2000 est.)
GDP - real growth rate: 1 .2% (2000 est.)
GDP - per capita: purchasing power parity - $6,300
(2000 est.)
GDP - composition by sector:
agriculture: 10%
industry: 60%
services: 30% (1999 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .5% (2000 est.)
Labor force: 600,000
Labor force - by occupation: agriculture 60%,
services and government 25%, industry and
commerce 1 5%
Unemployment rate: 21% (1997 est.)
Budget:
revenues; $1.5 billion
expenditures: $1.3 billion, including capital
expenditures of $302 million (1996 est.)
Industries: food and beverage; textile; lumbering
and plywood; cement; petroleum extraction and
refining; manganese, uranium, and gold mining;
chemicals; ship repair
Industrial production growth rate: 2.3% (1995)
Electricity - production: 1.02 billion kWh (1999)
Electricity - production by source:
fossil fuel: 29.9%
hydro: 70.1%
nuclear: 0%
other: 0% (1999)
Electricity ■ consumption: 948.6 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cocoa, coffee, sugar, palm
oil, rubber; cattle; okoume (a tropical softwood); fish
Exports: $3.4 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil 75%, timber,
manganese, uranium (1998)
Exports ■ partners: US 47%, France 19%, China
8%, Japan 1.3% (1999)
Imports: $1 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
foodstuffs, chemicals, petroleum products,
construction materials
Imports ■ partners: France 64%, US 4%, UK 2%,
Netherlands 2%, (1999)
Debt - external: $3.9 billion (2000 est.)
Economic aid - recipient: $331 million (1995)
Currency: Communaute Financiere Africaine franc
(XAF); note - responsible authority is the Bank of the
Central African States
Currency code: XAF
Exchange rates: Communaute Financiere Africaine
francs (XAF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 511.55 (1996); note -from 1 January 1999,
the XAF is pegged to the euro at a rate of 655.957
XAF per euro
Fiscal year: calendar year
Economy - overview: The Gambia has no important
mineral or other natural resources and has a limited
agricultural base. About 75% of the population
depends on crops and livestock for its livelihood.
Small-scale manufacturing activity features the
processing of peanuts, fish, and hides. Reexport trade
normally constitutes a major segment of economic
activity, but a 1999 government-imposed preshipment
inspection plan, instability of the Gambian dalasi, and
the stable political situation in Senegal have drawn
some of the reexport trade away from Banjul. The
government''s 1998 seizure of the private peanut firm
Alimenta eliminated the largest purchaser of Gambian
groundnuts; the following two marketing seasons
have seen significantly lower prices and sales. A
decline in tourism from 1999 to 2000 has also held
back growth. Unemployment and underemployment
rates are extremely high. Shortrun economic progress
remains highly dependent on sustained bilateral and
multilateral aid, on responsible government economic
management as forwarded by IMF technical help and
advice, and on expected growth in the construction
sector.
GDP: purchasing power parity - $1 .5 billion
(2000 est.)
GDP - real growth rate: 4.9% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,1 00
(2000 est.)
GDP - composition by sector:
agriculture: 2^%
industry: 12%
sen/ices: 67% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3.4% (2000 est.)
Labor force: 400,000
Labor force - by occupation: agriculture 75%,
industry, commerce, and services 19%, government
6%
Unemployment rate: NA%
Budget:
revenues: $90.5 million
expenditures: $S0.9 million, including capital
expenditures of $4.1 million (2001 est.)
Industries: processing peanuts, fish, and hides;
tourism; beverages; agricultural machinery assembly,
woodworking, metalworking; clothing
Industrial production growth rate: NA%
Electricity - production: 75 million kWh (1999)
Electricity - production by source:
fossil fuel: ^00%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 69.8 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: peanuts, millet, sorghum,
rice, corn, sesame, cassava (tapioca), palm kernels;
cattle, sheep, goats; forest and fishery resources not
fully exploited
Exports: $125.8 million (f.o.b., 1999)
Ex','14e26b933f3660bcb9cf7eff3fb8d9c681753ea8b56bd4d69657564f9342ad92','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c850384967e4d35924512e2495d4ac2853ff0d87255256030564596b44c5e53b',2001,'FR','France','economy',143,'ports - commodities: peanuts and peanut
products, fish, cotton lint, palm kernels
Exports - partners: Benelux 59%, Japan 20%, UK
7%, Spain 2% (1999)
Imports: $202.5 million (f.o.b., 1999)
Imports - commodities: foodstuffs, manufactures,
fuel, machinery and transport equipment
184
Gambia, The (continued)
Imports - partners: China (including Hong Kong)
49%, UK 15%, Netherlands 11.6%, Brazil 10%.
Senegal 10% (1997)
Debt - external: $440 million (2001 est.)
Economic aid - recipient: $45.4 million (1995)
Currency: dalasi (GMD)
Currency code: GMD
Exchange rates: dalasi per US dollar - 15.000
(January 2001 ), 1 2.729 (3d quarter 1 999), 1 1 .395
(1999), 10.643 (1998), 10.200 (1997), 9.789 (1996)
Fiscal year: calendar year
Economy - overview: Economic output in the Gaza
Strip “ which comes under the responsibility of the
Palestinian Authority since the Cairo Agreement of
May 1994 - declined perhaps one-third between 1992
and 1996. The downturn was largely the result of
Israeli closure policies - the imposition of generalized
border closures in response to security incidents in
Israel - which disrupted previously established labor
and commodity market relationships between Israel
and the WBGS (West Bank and Gaza Strip). The most
serious negative social effect of this downturn was the
emergence of high unemployment; unemployment in
the WBGS during the 1 980s was generally under 5%;
by 1995 it had risen to over 20%. Since 1997 Israel''s
use of comprehensive closures has decreased and, in
1998, Israel implemented new policies to reduce the
impact of closures and other security procedures on
the movement of Palestinian goods and labor. These
changes fueled an almost three-year long economic
recovery in the West Bank and Gaza Strip; real GDP
grew by 5% in 1998 and 6% in 1999. Recovery was
upended in the last quarter of 2000 with the outbreak
of Palestinian violence, which triggered tight Israeli
closures of Palestinian self-rule areas and a severe
disruption of trade and labor movements.
GDP: purchasing power parity -$1.11 billion
(2000 est.)
GDP " real growth rate: -7.5% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,000
(2000 est.)
GDP - composition by sector:
agriculture: 9%
industry: 28%
services: 63% (1999 est., includes West Bank)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest /0%.-NA%
Inflation rate (consumer prices): 3% (includes
West Bank) (2000 est.)
Labor force: NA
Labor force - by occupation: services 66%,
industry 21%, agriculture 13% (1996)
Unemployment rate: 40% (includes West Bank)
(yearend 2000)
Budget:
revenues: $1 .6 billion
expenditures: $1 .73 billion, including capital
expenditures of $NA
note: includes West Bank (1999 est.)
Industries: generally small family businesses that
produce textiles, soap, olive-wood carvings, and
mother-of-pearl souvenirs; the Israelis have
established some small-scale modern industries in an
industrial center
Industrial production growth rate: NA%
Electricity - production: NA kWh; note - electricity
supplied by Israel
Electricity ■ consumption: NA kWh
Electricity - exports: 0 kWh (1 999)
Electricity - imports: NA kWh; note - electricity
supplied by Israel
Agriculture - products: olives, citrus, vegetables;
beef, dairy products
Exports: $682 million (f.o.b., 1998 est.) (includes
West Bank)
Exports - commodities: citrus, flowers
Exports - partners: Israel, Egypt, West Bank
Imports: $2.5 billion (c.i.f., 1998 est.) (includes West
Bank)
Imports - commodities: food, consumer goods,
construction materials
Imports - partners: Israel, Egypt, West Bank
Debt - external: $108 million (1997 est.) (includes
West Bank)
Economic aid - recipient: $121 million disbursed
(2000) (includes West Bank)
Currency: new Israeli shekel (ILS)
Currency code: ILS
Exchange rates: new Israeli shekels per US dollar -
4.0810 (December 2000), 4.0773 (2000), 4.1397
(1999), 3.8001 (1998), 3.4494 (1997), 3.1917 (1996)
Fiscal year: calendar year
Economy - overview: Georgia''s economy has
traditionally revolved around Black Sea tourism;
cultivation of citrus fruits, tea, and grapes; mining of
manganese and copper; and output of a small
Industrial sector producing wine, metals, machinery,
chemicals, and textiles. The country imports the bulk
of its energy needs, including natural gas and oil
products. Its only sizable internal energy resource is
hydropower. Despite the severe damage the
economy has suffered due to civil strife, Georgia, with
the help of the IMF and World Bank, has made
substantial economic gains since 1995, increasing
GDP growth and slashing inflation. The Georgian
economy continues to experience large budget
deficits due to a failure to collect tax revenues.
Georgia also still suffers from energy shortages; it
privatized the distribution network in 1998, and
deliveries are steadily improving. The country is
pinning its hopes for long-term recovery on the
development of an international transportation
corridor through the key Black Sea ports of P’ot''i and
Bat’umi. The growing trade deficit, continuing
problems with tax evasion and corruption, and political
uncertainties cloud the short-term economic picture.
GDP: purchasing power parity - $22.8 billion
(2000 est.)
GDP - real growth rate: 1 .9% (2000 est.)
GDP - per capita: purchasing power parity - $4,600
(2000 est.)
GDP - composition by sector:
agriculture: 32%
industry: 23%
services: 45% (1999 est.)
Population below poverty line: 60% (1999 est.)
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%>:HA%
Inflation rate (consumer prices): 4.1% (2000 est.)
Labor force: 3.08 million (1997)
Labor force - by occupation: industry 20%,
agriculture 40%, services 40% (1999 est.)
Unemployment rate: 14.9% (1999 est.)
Budget:
revenues: $437 million
expenditures: $626 million, including capital
expenditures of $60 million (1999)
Industries: steel, aircraft, machine tools, electric
locomotives, trucks, tractors, textiles, shoes,
chemicals, wood products, wine
Industrial production growth rate: -0.3%
(1998 est.)
Electricity - production: 7.975 billion kWh (1999)
Electricity - production by source;
fossil fuel: 20.38%
hydro: 79.62%
nuclear: 0%
other: 0%{^999)
Electricity ■ consumption: 7.1 1 7 billion kWh (1 999)
Electricity ■ exports; 850 million kWh (1999)
Electricity - imports: 550 million kWh (1 999)
Agriculture - products: citrus, grapes, tea,
vegetables, potatoes; livestock
Exports: $372 million (2000 est.)
Exports - commodities: citrus fruits, tea, wine,
other agricultural products; diverse types of
machinery and metals; chemicals; fuel reexports;
textiles
Exports - partners: Russia 19%, Turkey 16%,
Azerbaijan 8%, Armenia 6% (1999)
Imports; $898 million (2000 est.)
Imports - commodities: fuel, grain and other foods,
machinery and parts, transport equipment
Imports - partners: EU 22%, Russia 19%, Turkey
12%, US 12% (1999)
Debt - external: $1.9 billion (2000)
Economic aid ■ recipient: $212.7 million (1995)
Currency: lari (GEL)
Currency code: GEL
Exchange rates: lari per US dollar - 1 .9798
(December 2000), 1.9762 (2000), 2.0245 (1999),
1.3898 (1998), 1.2975 (1997), 1.2628 (1996)
Fiscal year: calendar year
Economy - overview: The economy depends on
agriculture, tourism, light industry, and services. It
also depends on France for large subsidies and
imports. Tourism is a key industry, with most tourists
from the US; an increasingly large number of cruise
ships visit the islands. The traditional sugarcane crop
is slowly being replaced by other crops, such as
bananas (which now supply about 50% of export
earnings), eggplant, and flowers. Other vegetables
and root crops are cultivated for local consumption,
although Guadeloupe is still dependent on imported
food, mainly from France. Light industry features
sugar and rum production. Most manufactured goods
and fuel are imported. Unemployment is especially
high among the young. Hurricanes periodically
devastate the economy.
GDP: purchasing power parity - $3.7 billion
(1997 est.)
GDP- real growth rate: NA%
GDP - per capita: purchasing power parity - $9,000
(1997 est.)
GDP - composition by sector:
agriculture: 15%
industry: 17%
services: 58% (1997 est.)
Popuiation beiow poverty line: NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Infiation rate (consumer prices): NA
Labor force: 125,900 (1997)
Labor force -by occupation: NA
Unemployment rate: 27.8% (1998)
Budget:
revenues: $225 miilion
expenditures: $390 million, including capital
expenditures of $105 million (1996)
Industries: construction, cement, rum, sugar,
tourism
Industrial production growth rate: NA%
Electricity - production: 1 .3 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 1 .209 billion kWh (1 999)
Electricity - exports: 0 kWh (1 999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: bananas, sugarcane,
tropical fruits and vegetables; cattle, pigs, goats
Exports: $140 million (f.o.b., 1997)
Exports - commodities: bananas, sugar, rum
Exports - partners: France 60%, Martinique 18%,
US 4% (1997)
Imports: $1.7 billion (c.i.f., 1997)
Imports - commodities: foodstuffs, fuels, vehicles,
clothing and other consumer goods, construction
materials
Imports - partners: France 63%, Germany 4%, US
3%, Japan 2%, Netherlands Antilles 2% (1997)
Debt - external: $NA
Economic aid - recipient: $NA; note - substantial
annual French subsidies
Currency: French franc (FRF); euro (EUR)
Currency code: FRF; EUR
Exchange rates: Euros per US dollar - 1 .0659
(January 2001 ), 1 .0854 (2000), 0.9386 (1 999); French
francs per US dollar - 5.8995 (1998), 5.8367 (1997),
5.1155 (1996)
Fiscal year: calendar year
Economy - overview: The economy is based on
sugarcane, bananas, tourism, and light industry.
Agriculture accounts for about 6% of GDP and the
small industrial sector for 1 1 %. Sugar production has
declined, with most of the sugarcane now used for the
production of rum. Banana exports are increasing,
going mostly to France. The bulk of meat, vegetable,
and grain requirements must be imported,
contributing to a chronic trade deficit that requires
large annual transfers of aid from France. Tourism has
become more important than agricultural exports as a
source of foreign exchange. The majority of the work
force is employed in the service sector and in
administration.
GDP: purchasing power parity - $4.39 billion
(1997 est.)
GDP “ real growth rate: NA%
GDP - per capita: purchasing power parity -
$11,000 (1997 est.)
GDP - composition by sector:
agriculture: 6%
industry: ^^%
services: B3% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o:m%
Inflation rate (consumer prices): 3.9% (1990)
Labor force: 170,000(1997)
Labor force - by occupation: agriculture 1 0%,
industry 17%, services 73% (1997)
Unemployment rate: 27.2% (1998)
Budget:
revenues: $900 million
expenditures: $2.5 billion, including capital
expenditures of $140 million (1996)
Industries: construction, rum, cement, oil refining,
sugar, tourism
Industrial production growth rate: NA%
Electricity - production: 1.1 billion kWh (1999)
Electricity - production by source:
foss//fue/; 100%
hydro: 0%
nuclear: 0%
other: 0%{^m)
Electricity ■ consumption: 1.023 billion kWh (1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1 999)
Agriculture - products: pineapples, avocados,
bananas, flowers, vegetables, sugarcane
Exports: $250 million (f.o.b., 1997)
Exports - commodities: refined petroleum
products, bananas, rum, pineapples
Exports - partners: France 45%, Guadeloupe 28%
(1997)
Imports: $2 billion (c.i.f., 1997)
Imports - commodities: petroleum products, crude
oil, foodstuffs, construction materials, vehicles,
clothing and other consumer goods
Imports - partners: France 62%, Venezuela 6%,
Germany 4%, Italy 4%, US 3% (1997)
Debt - external: $1 80 million (1 994)
Economic aid - recipient: $NA: note - substantial
annual aid from France
Currency: French franc (FRF); euro (EUR)
Currency code: FRF; EUR
Exchange rates: euros per US dollar ■ 1 .0659
(January 2001 ), 1 .0854 (2000), 0.9386 (1 999); French
francs per US dollar - 5.8995 (1998), 5.8367 (1997),
5.1155(1996)
Fiscal year: calendar year
Economy ■ overview; Economic activity traditionally
has been based on agriculture and breeding of
livestock. Mongolia also has extensive mineral
deposits: copper, coal, molybdenum, tin, tungsten,
and gold account for a large part of industrial
production. Soviet assistance, at its height one-third of
GDP, disappeared almost overnight in 1 990-91 , at the
time of the dismantlement of the USSR. Mongolia was
driven into deep recession, which was prolonged by
the Mongolian People''s Revolutionary Party''s (MPRP)
reluctance to undertake serious economic reform. The
Democratic Coalition (DC) government has embraced
free-market economics, easing price controls,
liberalizing domestic and international trade, and
attempting to restructure the banking system and the
energy sector. Major domestic privatization programs
were undertaken, as well as the fostering of foreign
investment through international tender of the oil
distribution company, a leading cashmere company,
and banks. Reform was held back by the
ex-communist MPRP opposition and by the political
instability brought about through four successive
governments under the DC. Economic growth picked
up in 1997-99 after stalling in 1996 due to a series of
natural disasters and declines in world prices of
copper and cashmere. In August and September
1999, the economy suffered from a temporary
Russian ban on exports of oil and oil products, and
Mongolia remains vulnerable in this sector. Mongolia
joined the World Trade Organization (WTrO) in 1997.
The international donor community pledged over $300
million per year at the last Consultative Group
Meeting, held in Ulaanbaatar in June 1999. The
MPRP government, elected in July 2000, is anxious to
improve the investment climate; it must also deal with
a heavy burden of external debt.
GDP: purchasing power parity - $4.7 billion
(2000 est.)
GDP - real growth rate: -1% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,780
(2000 est.)
GDP - composition by sector:
agriculture: 36%
industry: 22%
services: 42% (2000 est.)
Population below poverty line: 40% (2000 est.)
Household Income or consumption by percentage
share:
lowest 10%: 2.9%
highest 24.5% (1995)
Inflation rate (consumer prices): 7.6% (1999)
Labor force: 1 .3 million (1 999)
Labor force - by occupation: primarily herding/
agricultural
Unemployment rate: NA%
Budget:
revenues: $262 million
expenditures: $32S million, including capital
expenditures of $NA (2000 est.)
Industries: construction materials, mining
(particularly coal and copper); food and beverages,
processing of animal products
Industrial production growth rate: 2.4%
(2000 est.)
Electricity - production: 2.671 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 2.767 billion kWh (1 999)
Electricity - exports: 80 million kWh (1999)
Electricity ■ imports: 363 million kWh (1999)
Agriculture - products: wheat, barley, potatoes,
forage crops; sheep, goats, cattle, camels, horses
Exports: $454.3 million (f.o.b., 1999)
Exports - commodities: copper, livestock, animal
products, cashmere, wool, hides, fluorspar, other
nonferrous metals
Exports - partners: China 60%, US 20%, Russia
9%, Japan 2% (2000 est.)
Imports: $510.7 million (c.i.f., 1999)
Imports - commodities: machinery and equipment,
fuels, food products, industrial consumer goods,
chemicals, building materials, sugar, tea
Imports - partners: Russia 33%, China 21%, Japan
12%, South Korea 10%, US 4% (1999)
Debt - external: $760 million (2000 est.)
Economic aid - recipient: $200 million (1998 est.)
Currency: togrog/tugrik (MNT)
Currency code: MNT
344
Mongolia (continued)
Exchange rates: togrogs/tugriks per US dollar -
1,097.00 (December 2000), 1,076.67 (2000),
1,072.37 (1999), 840.83 (1998), 789.99 (1997),
548.40(1996)
Fiscal year: calendar year
Economy - overview: The economy has
traditionally been based on agriculture. Sugarcane
has been the primary crop for more than a century,
and in some years it accounts for 85% of exports. The
government has been pushing the development of a
tourist industry to relieve high unemployment, which
amounts to more than 40% of the labor force. The gap
in Reunion between the well-off and the poor is
extraordinary and accounts for the persistent social
tensions. The white and Indian communities are
substantially better off than other segments of the
population, often approaching European standards,
whereas minority groups suffer the poverty and
unemployment typical of the poorer nations of the
African continent. The outbreak of severe rioting in
February 1991 illustrates the seriousness of
socioeconomic tensions. The economic well-being of
Reunion depends heavily on continued financial
assistance from France.
GDP: purchasing power parity - $3.4 billion
(1998 est.)
GDP - real growth rate: 3.8% (1998 est.)
GDP > per capita: purchasing power parity - $4,800
(1998 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 261,000 (1995)
Labor force - by occupation: agriculture 8%,
industry 19%, services 73% (1990)
Unemployment rate: 42.8% (1998)
Budget:
revenues: NA
expenditures: NA
Industries: sugar, rum, cigarettes, handicraft items,
flower oil extraction
Industrial production growth rate: NA%
Electricity - production: 1.1 billion kWh (1999)
Electricity - production by source:
fossil fuel: 54.55%
hydro: 45.45%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 1 .023 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: sugarcane, vanilla,
tobacco, tropical fruits, vegetables, corn
Exports: $214 million (f.o.b., 1997)
Exports - commodities: sugar 63%, rum and
molasses 4%, perfume essences 2%, lobster 3%,
(1993)
Exports - partners: France 74%, Japan 6%,
Comoros 4% (1994)
Imports: $2.5 billion (c.i.f., 1997)
Imports - commodities: manufactured goods, food,
beverages, tobacco, machinery and transportation
equipment, raw materials, and petroleum products
Imports ■ partners: France 64%, Bahrain 3%,
Germany 3%, Italy 3% (1994)
Debt -external: $NA
Economic aid - recipient: $NA; note - substantial
annual subsidies from France
Currency; French franc (FRF); euro (EUR)
Currency code: FRF; EUR
Exchange rates: euros per US dollar - 1.06594
(January 2001), 1 .08540 (2000), 0.9386 (1999);
French francs per US dollar - 5.8995 (1 998), 5.8367
(1997), 5.1155 (1996)
Fiscal year: calendar year
Economy - overview: The UK, a leading trading
power and financial center, deploys an essentially
capitalistic economy, one of the quartet of trillion dollar
economies of Western Europe. Over the past two
decades the government has greatly reduced public
ownership and contained the growth of social welfare
programs. Agriculture is intensive, highly mechanized,
and efficient by European standards, producing about
60% of food needs with only 1 % of the labor force. The
UK has large coal, natural gas, and oil reserves;
primary energy production accounts for 10% of GDP,
one of the highest shares of any industrial nation.
Services, particularly banking, insurance, and
business services, account by far for the largest
proportion of GDP while industry continues to decline
in importance. The economy has grown steadily, at
just above or below 3%, for the last several years. The
BLAIR government has put off the question of
participation in the euro system until after the next
election, in June of 2001 ; Chancellor of the Exchequer
BROWN has identified some key economic tests to
determine whether the UK should join the common
currency system, but it will largely be a political
decision. A serious short-term problem is
foot-and-mouth disease, which by early 2001 had
broken out in nearly 600 farms and slaughterhouses
and had resulted in the killing of 400,000 animals.
GDP: purchasing power parity - $1 .36 trillion
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity -
$22,800 (2000 est.)
GDP - composition by sector:
agriculture: 1 .7%
industry: 24.9%
serv/ces; 73.4% (1999)
Population below poverty line: 17%
Household income or consumption by percentage
share:
lowest 10%: 2.6%
highest m; 27.3% (1991)
Inflation rate (consumer prices): 2.4% (2000 est.)
Labor force: 29.2 million (1999)
Labor force - by occupation: agriculture 1%,
industry 19%, services 80% (1996 est.)
Unemployment rate: 5.5% (2000 est.)
Budget;
revenues: $555.2 billion
expenditures: $510.8 billion, including capital
expenditures of $37.7 billion (FYOO)
Industries: machine tools, electric power equipment,
automation equipment, railroad equipment,
shipbuilding, aircraft, motor vehicles and parts,
electronics and communications equipment, metals,
chemicals, coal, petroleum, paper and paper
products, food processing, textiles, clothing, and other
consumer goods
Industrial production growth rate: 2% (2000)
Electricity - production: 342.771 billion kWh (1999)
Electricity - production by source:
fossil fuel: 69.38%
hydro: 1 .55%
nuclear: 26.68%
other; 2.39% (1999)
Electricity - consumption: 333.012 billion kWh
(1999)
Electricity - exports; 265 million kWh (1999)
Electricity - Imports: 14.5 billion kWh (1999)
Agriculture - products: cereals, oilseed, potatoes,
vegetables; cattle, sheep, poultry; fish
Exports: $282 billion (f.o.b., 2000)
Exports - commodities; manufactured goods,
fuels, chemicals; food, beverages, tobacco
Exports - partners: EU 58% (Germany 12%,
France 10%, Netherlands 8%), US 15% (1999)
Imports: $324 billion (f.o.b., 2000)
Imports - commodities: manufactured goods,
machinery, fuels; foodstuffs
Imports - partners; EU 53% (Germany 1 4%, France
9%, Netherlands 7%), US 13%, Japan 5% (1999)
Debt -external: $NA
Economic aid - donor: ODA, $3.4 billion (1997)
Currency: British pound (GBP)
Currency code: GBP
Exchange rates: British pounds per US dollar -
0.6764 (January 2001 ), 0.6596 (2000), 0.61 80 (1 999),
0.6037 (1998), 0.6106 (1997), 0.6403 (1996)
Fiscal year: 1 April - 31 March
Economy - overview: Economic output in the West
Bank is governed by the Paris Economic Protocol of
April 1994 between Israel and the Palestinian
Authority. Real per capita GDP for the West Bank and
Gaza Strip (WBGS) declined by 36.1% between 1992
and 1996 owing to the combined effect of falling
aggregate incomes and rapid population growth. The
downturn in economic activity was largely the result of
Israeli closure policies - the imposition of border
closures in response to security incidents in Israel -
which disrupted established labor and commodity
market relationships between Israel and the WBGS.
The most serious social effect of this downturn was
550
West Bank (continued)
rising unemployment; unemployment in the WBGS
during the 1980s was generally under 5%; by 1995 it
had risen to over 20%. Since 1997 Israel''s use of
comprehensive closures has decreased and, in 1998,
Israel implemented new policies to reduce the impact
of closures and other security procedures on the
movement of Palestinian goods and labor. These
changes fueled an almost three-year long economic
recovery in the West Bank and Gaza Strip; real GDP
grew by 5% in 1998 and 6% in 1999. Recovery was
upended in the last quarter of 2000 with the outbreak
of Palestinian violence, which triggered tight Israeli
closures of Palestinian self-rule areas and a severe
disruption of trade and labor movements.
GDP: purchasing power parity- $3.1 billion
(2000 est.)
GDP - real growth rate: -7.5% (2000 est.)
GDP - per capita: purc','e0c0eb3ae9da60be5e90bd56e0a61faeb0ee07f826b8f0b97cf49a5546358107','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16f1e310336f90f25da42802f0de2814c5434c9690365fe1e48e8d48504b91bc',2001,'FR','France','economy',144,'hasing power parity - $1 ,500
(2000 est.)
GDP - composition by sector:
agriculture: 9%
industry: 28%
services: 63%
note: includes Gaza Strip (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%:NA%
Inflation rate (consumer prices): 3% (includes
Gaza Strip) (2000 est.)
Labor force: NA
Labor force - by occupation: services 66%,
industry 21%, agriculture 13% (1996)
Unemployment rate: 40% (includes Gaza Strip)
(yearend 2000)
Budget:
revenues: $1 .6 billion
expenditures: $1 .73 billion, including capital
expenditures of $NA
note: includes Gaza Strip (1999 est.)
Industries: generally small family businesses that
produce cement, textiles, soap, olive-wood carvings,
and mother-of-pearl souvenirs; the Israelis have
established some small-scale, modern industries in
the settlements and industrial centers
Industrial production growth rate: NA%
Electricity - production: NA kWh; note - most
electricity imported from Israel; East Jerusalem
Electric Company buys and distributes electricity to
Palestinians in East Jerusalem and its concession in
the West Bank; the Israel Electric Company directly
supplies electricity to most Jewish residents and
military facilities; at the same time, some Palestinian
municipalities, such as Nablus and Janin, generate
their own electricity from small power plants
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - imports: NA kWh
Agriculture - products: olives, citrus, vegetables;
beef, dairy products
Exports: $682 million (includes Gaza Strip) (f.o.b.,
1998 est.)
Exports - commodities: olives, fruit, vegetables,
limestone
Exports - partners: Israel, Jordan, Gaza Strip
Imports: $2.5 billion (includes Gaza Strip) (c.i.f.,
1 998 est.)
Imports - commodities: food, consumer goods,
construction materials
Imports - partners: Israel, Jordan, Gaza Strip
Debt - external: $108 million (includes Gaza Strip)
(1997 est.)
Economic aid - recipient: $121 million disbursed
(includes Gaza Strip) (2000)
Currency: new Israeli shekel (ILS); Jordanian dinar
(JOD)
Currency code: ILS; JOD
Exchange rates: new Israeli shekels per US dollar -
4.0810 (December 2000), 4.0773 (2000), 4.1397
(1999), 3.8001 (1998), 3.4494 (1997), 3.1917 (1996);
Jordanian dinars per US dollar - fixed rate of 0.7090
(from 1996)
Fiscal year: calendar year (since 1 January 1992)','1742a0ecad93ec3d403f97dc767051c9acb59745f44898e78b7943688379a3b9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e94930b8f1ea080b0c9157ad758cc82f4af1586fe44f2dbddb5909e2a9a3cfc8',2001,'BZ','Belize','economy',153,'Economy - overview: The small, essentially private
enterprise economy is based primarily on agriculture,
agro-based industry, and merchandising, with tourism
and construction assuming greater importance.
Sugar, the chief crop, accounts for nearly half of
exports, while the banana industry is the country''s
largest employer. The government''s tough austerity
program in 1997 resulted in an economic slowdown
that continued in 1998. The trade deficit has been
growing, mostly as a result of low export prices for
sugar and bananas. The tourist and construction
sectors strengthened in early 1999, supporting growth
of 6% in 1999 and 4% In 2000. Aided by international
donors, the government''s key short-term objective
remains the reduction of poverty.
GDP: purchasing power parity - $790 million
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity - $3,200
(2000 est.)
GDP - composition by sector;
agriculture: 18%
industry: 24%
services: 58% (2000 est.)
Population below poverty line: 33% (1999 est.)
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 2% (2000 est.)
52
Belize (continued)
Labor force: 71,000
note: shortage of skilled labor and all types of
technical personnel (1997 est.)
Labor force ■ by occupation: agriculture 38%,
industry 32%, services 30% (1994)
Unemployment rate: 12.8% (1999)
Budget:
revenues.’ $157 million
expenditures: $279 million, including capital
expenditures of $NA (1999 est.)
Industries: garment production, food processing,
tourism, construction
Industrial production growth rate: 4.6% (1999)
Electricity ■ production: 185 million kWh (1999)
Electricity - production by source;
fossil fuel: 56.7^%
hydro: 4324%
nuclear: 0%
other: 0%0m)
Electricity - consumption: 172.1 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, coca, citrus,
sugarcane; lumber; fish, cultured shrimp
Exports: $235.7 million (f.o.b., 2000 est.)
Exports - commodities: sugar, bananas, citrus,
clothing, fish products, molasses, wood
Exports ■ partners; US 42%, UK 33%, EU 12%,
Caricom 4.8%, Canada 2%, Mexico 1% (1999)
Imports: $413 million (c.i.f., 2000 est.)
Imports - commodities; machinery and
transportation equipment, manufactured goods; food,
beverages, tobacco; fuels, chemicals,
pharmaceuticals
Imports - partners: US 58%, Mexico 12%, UK 5%
EU 5%, Central America 5%, Caricom 4% (1998)
Debt - external: $338 million (1998)
Economic aid - recipient: $NA
Currency: Belizean dollar (BZD)
Currency code; BZD
Exchange rates: Belizean dollars per US dollar -
2.0000 (fixed rate pegged to the US dollar)
Fiscal year: 1 April - 31 March
Economy - overview: The economy of Benin
remains underdeveloped and dependent on
subsistence agriculture, cotton production, and
regional trade. Growth in real output averaged a
sound 5% in 1996-99, but a rapid population rise
offset much of this growth. Inflation has subsided over
the past several years. Commercial and transport
activities, which make up a large part of GDP, are
vulnerable to developments in Nigeria, particularly
fuel shortages. The Paris Club and bilateral creditors
have eased the external debt situation in recent years.
While high fuel prices constrained growth in 2000,
increased cotton production - enabled by a major
restructuring program - and an expansion of the
Cotonou port, may lead to increased growth in 2001 .
GDP: purchasing power parity - $6.6 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,030
(2000 est.)
GDP - composition by sector:
agriculture: 37.9%
industry: ^3.5%
semces; 48.6% (1999)
Population below poverty line: 37.2% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: NA%
Inflation rate (consumer prices): 3% (2000 est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $299 million
expenditures: $445 million, including capital
expenditures of $14 million (1995 est.)
Industries: textiles, cigarettes; beverages, food;
construction materials, petroleum
Industrial production growth rate: 6.9%
(2000 est.)
Electricity - production: 226 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 24.78%
hydro: 75.22%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 51 0.2 million kWh (1 999)
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 300 million kWh (1999)
Agriculture - products: corn, sorghum, cassava
(tapioca), yams, beans, rice, cotton, palm oil, peanuts;
poultry, livestock
Exports: $396 million (f.o.b., 1999)
Exports - commodities: cotton, crude oil, palm
products, cocoa
Exports ■ partners: Brazil 14%, Libya 5%,
Indonesia 4%, Italy 4% (1999)
Imports: $566 million (c.i.f., 1999)
Imports ■ commodities: foodstuffs, tobacco,
petroleum products, capital goods
Imports - partners: France 38%, China 16%, UK
9%, Cote d''Ivoire 5% (1999)
Debt ■ external: $1 .6 billion (1998 est.)
Economic aid - recipient: $274.6 million (1997)
Currency: Communaute Financiere Africaine franc
(XOF); note - responsible authority is the Central
Bank of the West African States
Currency code: XOF
Exchange rates: Communaute Financiere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
71 1 .98 (2000), 61 5.70 (1 999), 589.95 (1 998), 583.67
(1997), 511.55 (1996); note - from 1 January 1999,
the XOF is pegged to the euro at a rate of 655.957
XOF per euro
Fiscal year: calendar year','37c89c20f6ccf9a7661807eb961e8dd481671ec12db27414debe67fd8c23f729','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91e331f48e2ff9b08801395af0e68c72c88d15c47b07b98bfc0f5d25c39d5911',2001,'BM','Bermuda','economy',162,'Economy - overview: Bermuda enjoys one of the
highest per capita incomes in the world, having
successfully exploited its location by providing
financial services for international firms and luxury
tourist facilities for 360,000 visitors annually. The
tourist industry, which accounts for an estimated 28%
of GDP, attracts 84% of its business from North
s America. The industrial sector is small, and agriculture
is severely limited by a lack of suitable land. About
80% of food needs are imported. International
business contributes over 60% of Bermuda''s
economic output; a failed independence vote in late
1995 can be partially attributed to Bermudian fears of
scaring away foreign firms. Government economic
priorities are the further strengthening of the tourist
and international financial sectors.
GDP: purchasing power parity - $2.1 billion
(2000 est.)
GDP - real growth rate: 1 .5% (2000 est.)
GDP - per capita: purchasing power parity -
$33,000 (2000 est.)
GDP - composition by sector:
agriculture: 1%
industry: W/o
services: 89% (1995 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o:m%
Inflation rate (consumer prices): 2.7% (2000 est.)
Labor force: 35,296(1997)
Labor force ■ by occupation: clerical 23%,
services 22%, laborers 17%, professional and
technical 17%, administrative and managerial 12%,
sales 7%, agriculture and fishing 2% (1996)
Unemployment rate: NEGL%(1995)
Budget:
revenues.'' $504.6 million
expenditures: $537 million, including capital
expenditures of $75 million (FY97/98)
Industries: tourism, finance, insurance, structural
concrete products, paints, perfumes,
pharmaceuticals, ship repairing
Industrial production growth rate: NA%
Electricity - production; 550 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 51 1 .5 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, vegetables,
citrus, flowers; dairy products
Exports: $56 million (2000 est.)
Exports - commodities: reexports of
pharmaceuticals
Exports - partners; UK 29.5%, US 9.8% (1997)
Imports: $739 million (2000 est.)
Imports « commodities: machinery and transport
equipment, construction materials, chemicals, food
and live animals
Imports - partners: US 34%, UK 9%, Mexico 8%
(1997)
Debt -external: $NA
Economic aid - recipient: $27.9 million (1995)
Currency: Bermudian dollar (BMD)
Currency code: BMD
Exchange rates: Bermudian dollar per US dollar -
1 .0000 (fixed rate pegged to the US dollar)
Fiscal year: 1 April - 31 March
Economy - overview: The economy, one of the
world''s smallest and least developed, is based on
agriculture and forestry, which provide the main
livelihood for more than 90% of the population.
Agriculture consists largely of subsistence farming
and animal husbandry. Rugged mountains dominate
the terrain and make the building of roads and other
infrastructure difficult and expensive. The economy is
closely aligned with India''s through strong trade and
monetary links. The industrial sector is technologically
backward, with most production of the cottage
industry type. Most development projects, such as
road construction, rely on Indian migrant labor.
Bhutan''s hydropower potential and its attraction for
tourists are key resources. The Bhutanese
Government has made some progress in expanding
the nation''s productive base and improving social
welfare. Model education, social, and environment
programs in Bhutan are underway with support from
multilateral development organizations. Each
economic program takes into account the
government''s desire to protect the country''s
environment and cultural traditions. Detailed controls
and uncertain policies in areas like industrial licensing,
trade, labor, and finance continue to hamper foreign
investment.
GDP: purchasing power parity - $2,3 billion
(2000 est.)
GDP ■ real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity - $1,100
(2000 est.)
GDP - composition by sector:
agriculture: 38%
industry: 37%
services: 25% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 7% (2000 est.)
Labor force: NA
note: massive lack of skilled labor
Labor force - by occupation: agriculture 93%,
services 5%, industry and commerce 2%
Unemployment rate: NA%
Budget;
revenues.- $146 million
expenditures: $152 million, including capital
expenditures of $NA (FY95/96 est.)
note: the government of India finances nearly
three-fifths of Bhutan''s budget expenditures
Industries: cement, wood products, processed
fruits, alcoholic beverages, calcium carbide
Industrial production growth rate: 9.3%
(1996 est.)
Electricity - production: 1.856 billion kWh (1999)
Electricity - production by source:
fossil fuel: 0.05%
hyc/ro; 99.95%
nuclear: 0%
ofher; 0% (1999)
Electricity ■ consumption: 191.1 million kWh
(1999)
Electricity - exports; 1 .55 billion kWh (1999)
Electricity - imports: 15 million kWh (1999)
Agriculture - products: rice, corn, root crops, citrus,
foodgrains; dairy products, eggs
Exports: $154 million (f.o.b., 2000 est.)
Exports - commodities: cardamom, gypsum,
timber, handicrafts, cement, fruit, electricity (to India),
precious stones, spices
Exports - partners; India 94%, Bangladesh
Imports: $269 million (c.i.f., 2000 est.)
Imports ■ commodities: fuel and lubricants, grain,
machinery and parts, vehicles, fabrics, rice
Imports ■ partners: India 77%, Japan, UK,
Germany, US
Debt - external: $120 million (1998)
Economic aid - recipient: $73.8 million (1995)
Currency: ngultrum (BTN); Indian rupee (INR)
Currency code: BTN; INR
Exchange rates: ngultrum per US dollar ■ 46.540
(January 2001 ), 44.942 (2000), 43.055 (1 999), 41 .259
(1998), 36.313 (1997), 35.433 (1996); note - the
Bhutanese ngultrum is at par with the Indian rupee
which is also legal tender
Fiscal year: 1 July - 30 June
Economy - overview: Bolivia, long one of the
poorest and least developed Latin American
countries, has made considerable progress toward
the development of a market-oriented economy.
Successes under President SANCHEZ DE LOZADA
(1993-97) included the signing of a free trade
agreement with Mexico and joining the Southern
Cone Common Market (Mercosur), as well as the
privatization of the state airline, telephone company,
railroad, electric power company, and oil company.
His successor, Hugo BANZER Suarez has tried to
further improve the country''s investment climate with
an anticorruption campaign. Growth slowed in 1999,
in part due to tight government budget policies, which
limited needed appropriations for anti-poverty
programs, and the fallout from the Asian financial
crisis. In 2000, major civil disturbances in April, and
again in September and October, held down overall
growth to 2.5%.
GDP: purchasing power parity - $20.9 billion
(2000 est.)
GDP - real growth rate: 2.5% (2000 est.)
GDP - per capita; purchasing power parity - $2,600
(2000 est.)
GDP - composition by sector:
agriculture: 16%
industry: 3^%
services: 53% (1999 est.)
Population below poverty line: 70% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.3%
highest 10%: 31.7% (mO)
Inflation rate (consumer prices): 4.4% (2000 est.)
Labor force: 2.5 million
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 1 1 .4% (1 997)
note; widespread underemployment
Budget:
revenues; $2.7 billion
expenditures: $2.7 billion, including capital
expenditures of $NA (1998)
Industries; mining, smelting, petroleum, food and
beverages, tobacco, handicrafts, clothing
Industrial production growth rate: 4% (1995 est.)
Electricity ■ production: 3.625 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 56.61%
/7yGfro;41.6%
nuclear: 0%
oteer; 1.79% (1999)
Electricity ■ consumption: 3.377 billion kWh (1999)
Electricity ■ exports: 4 million kWh (1999)
Electricity ■ imports: 10 million kWh (1999)
Agriculture - products; soybeans, coffee, coca,
cotton, corn, sugarcane, rice, potatoes; timber
Exports: $1 .26 billion (f.o.b., 2000 est.)
Exports - commodities: soybeans, natural gas,
zinc, gold, wood
Exports - partners: UK 16%, US 12%, Peru 11%,
Argentina 10%, Colombia 7% (1998)
Imports: $1.86 billion (f.o.b., 2000 est.)
Imports - commodities: capital goods, raw
materials and semi-manufactures, chemicals,
petroleum, food
Imports - partners; US 32%, Japan 24%, Brazil
12%, Argentina 12%, Chile 7%, Peru 4%, Germany
3%, other 6% (1998)
Debt - external: $6.6 billion (2000)
Economic aid - recipient: $588 million (1997)
Currency: boliviano (BOB)
Currency code: BOB
Exchange rates: bolivianos per US dollar - 6.4071
(January 2001 ), 6.1 835 (2000), 5.81 24 (1 999), 5.51 01
(1998), 5.2543 (1997), 5.0746 (1996)
Fiscal year: calendar year
Economy - overview: Bosnia and Herzegovina
ranked next to The Former Yugoslav Republic of
Macedonia as the poorest republic in the old Yugoslav
federation. Although agriculture is almost all in private
hands, farms are small and inefficient, and the
republic traditionally is a net importer of food. Industry
has been greatly overstaffed, one reflection of the
socialist economic structure of Yugoslavia. TITO had
pushed the development of military industries in the
republic with the result that Bosnia hosted a large
share of Yugoslavia''s defense plants. The bitter
interethnic warfare in Bosnia caused production to
plummet by 80% from 1 990 to 1 995, unemployment to
soar, and human misery to multiply. With an uneasy
peace in place, output recovered in 1996-98 at high
percentage rates from a low base; but output growth
slowed appreciably in 1999 and 2000, and GDP
remains far below the 1990 level. Economic data are
of limited use because, although both entities issue
figures, national-level statistics are not available.
Moreover, official data do not capture the large share
of activity that occurs on the black market. The
marka - the national currency introduced in 1 998 - has
gained wide acceptance, and the Central Bank of
Bosnia and Herzegovina has dramatically increased
its reserve holdings. Implementation of privatization,
however, has been slower than anticipated. Banking
reform accelerated In early 2001 as all the
communist-era payments bureaus were shut down.
The country receives substantial amounts of
reconstruction assistance and humanitarian aid from
the international community but will have to prepare
for an era of declining assistance.
GDP: purchasing power parity - $6.5 billion
(2000 est.)
GDP - real growth rate: 8% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,700
(2000 est.)
GDP - composition by sector:
agriculture: 19%
industry: 23%
services: 58% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 8% (2000 est.)
Labor force: 1 .026 million
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 35%-40% (1999 est.)
Budget:
revenues; $1.9 billion
expenditures: $22 billion, including capital
expenditures of $NA (1 999 est.)
Industries: steel, coal, iron ore, lead, zinc,
manganese, bauxite, vehicle assembly, textiles,
tobacco products, wooden furniture, tank and aircraft
assembly, domestic appliances, oil refining
Industrial production growth rate: 10%
(2000 est.)
Electricity - production: 2.585 billion kWh (1999)
Electricity - production by source:
fossil fuel: 38.68%
hydro: 61 22%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 2.684 billion kWh (1 999)
Electricity - exports; 150 million kWh (1999)
Electricity ■ imports: 430 million kWh (1999)
Agriculture - products: wheat, corn, fruits,
vegetables: livestock
Exports: $950 million (f.o.b., 2000 est.)
Exports - commodities; NA
Exports “ partners: Croatia, Switzerland, Italy,','34758e8a986396fc6e08b98f5100f0de1f735e1fa172c18ade68c250796d3914','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1fbc63205b0f8463089404f53864409fdf3b23ab49bff9cbbc93fda5ac18983',2001,'DE','Germany','economy',167,'Imports: $2.45 billion (f.o.b., 2000 est.)
Imports - commodities: NA
Imports - partners; Croatia, Slovenia, Germany,
Economy - overview: Germany possesses the
world''s third most technologically powerful economy
after the US and Japan, but structural market
rigidities - including the substantial non-wage costs of
hiring new workers - have made unemployment a
long-term, not just a cyclical, problem. Germany’s
aging population, combined with high unemployment,
has pushed social security outlays to a level
exceeding contributions from workers. The
modernization and integration of the eastern German
economy remains a costly long-term problem, with
annual transfers from western Germany amounting to
roughly $70 billion. Growth picked up to 3% in 2000,
largely due to recovering global demand; newly
passed business and income tax cuts are expected to
keep growth strong in 2001 . Corporate restructuring
and growing capital markets are transforming the
German economy to meet the challenges of European
economic integration and globalization in general.
GDP: purchasing power parity - $1 .936 trillion
(2000 est.)
GDP ■ real growth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity -
$23,400 (2000 est.)
GDP - composition by sector:
agriculture: 1 .2%
industry: 30.4%
semces;68.4% (1999)
Population below poverty line: NA%
Inflation rate (consumer prices): 2% (2000 est.)
Labor force: 40.5 million (1 999 est.)
Labor force - by occupation: industry 33.4%,
agriculture 2.8%, services 63.8% (1999)
Unemployment rate: 9.9% (2000 est.)
Budget:
revenues: $996 billion
expenditures: $1,036 trillion, including capital
expenditures of $NA (1999 est.)
Industries: among the world''s largest and most
technologically advanced producers of iron, steel,
coal, cement, chemicals, machinery, vehicles,
machine tools, electronics, food and beverages;
shipbuilding; textiles
Industrial production growth rate: 4.7% (2000)
Electricity ■ production: 531 .377 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 63.29%
hydro: 3.59%
nuclear: 30.3%
ofher; 2.82% (1999)
Electricity - consumption: 495.181 billion kWh
(1999)
Electricity - exports: 39.5 billion kWh (1999)
Electricity - imports: 40.5 billion kWh (1999)
Agriculture - products: potatoes, wheat, barley,
sugar beets, fruit, cabbages; cattle, pigs, poultry
Exports: $578 billion (f.o.b., 2000 est.)
Exports - commodities: machinery, vehicles,
chemicals, metals and manufactures, foodstuffs,
textiles
Exports - partners: EU 55.3% (France 1 1 .3%, UK
8.3%, Italy 7.3%, Netherlands 6.3%, Belgium/
Luxembourg 5.1%), US 10.1%, Japan 2.0% (1999)
Imports: $505 billion (f.o.b., 2000 est.)
Imports - commodities: machinery, vehicles,
chemicals, foodstuffs, textiles, metals
Imports - partners: EU 52.2% (France 10.5%,
Netherlands 7.6%, Italy 7.4%, UK 6.9%, Belgium/
Luxembourg 5.6%), US 8.1%, Japan 4.9% (1999)
Debt - external: $NA
Economic aid - donor: ODA, $5.6 billion (1998)
Currency: deutsche mark (DEM); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Germany at a fixed rate of
1 .95583 deutsche marks per euro and will replace the
local currency for all transactions in 2002
Currency code: DEM; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1 .0854 (2000), 0.9386 (1999);
deutsche marks per US dollar - 1.69 (January 1999),
1.7597 (1998), 1.7341 (1997), 1.5048 (1996)
Fiscal year: calendar year
Economy - overview: The stable, high-income
economy features solid growth, low inflation, and low
unemployment. The industrial sector, initially
dominated by steel, has become increasingly
diversified to include chemicals, rubber, and other
products. Growth in the financial sector has more than
compensated for the decline in steel. Services,
especially banking, account for a substantial
proportion of the economy. Agriculture is based on
small family-owned farms. The economy depends on
foreign and trans-border workers for 30% of its labor
force. Luxembourg has a custom union with Belgium
and the Netherlands, and, as a member of the EU,
enjoys the advantages of the open European market.
It joined with 1 0 other EU members to launch the euro
on 1 January 1999.
GDP: purchasing power parity - $15.9 billion
(2000 est.)
GDP ■ real growth rate: 5.7% (2000 est.)
GDP - per capita: purchasing power parity -
$36,400 (2000 est.)
GDP - composition by sector:
agriculture: 1%
industry: 30%
services: 69% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest f0%;NA%
Inflation rate (consumer prices): 7.8% (2000 est.)
Labor force: 248,000 (of whom 70,200 are foreign
cross-border workers primarily from France, Belgium,
and Germany) (2000)
Labor force - by occupation: services 83.2%,
industry 14.3%, agriculture 2.5% (1998 est.)
Unemployment rate: 2.7% (2000 est.)
Budget:
revenues; $5.6 billion
expenditures: $5.6 billion, including capital
expenditures of $NA (2000 est.)
Industries: banking, iron and steel, food processing,
chemicals, metal products, engineering, tires, glass,
aluminum
Industrial production growth rate: 7.8%
(2000 est.)
Electricity - production: 648 million kWh (1999)
Electricity - production by source:
fossil fuel: 36.88%
hydro: 53.09%
nuclear: 0%
of/?er; 10.03% (1999)
Electricity - consumption: 6.149 billion kWh (1999)
Electricity - exports: 655 million kWh (1999)
Electricity - imports: 6.201 billion kWh (1999)
Agriculture - products: barley, oats, potatoes,
wheat, fruits, wine grapes; livestock products
Exports: $7.6 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment,
steel products, chemicals, rubber products, glass
302
Luxembourg (continued)
Exports - partners: EU 75% (Germany 25%,
France 21%, Belgium 13%, UK 8%, Italy 6%,
Netherlands 5%), US 4% (1999)
Imports: $10 billion (c.i.f., 2000)
Imports ■ commodities: minerals, metals,
foodstuffs, quality consumer goods
Imports - partners: EU 81% (Belgium 35%,
Germany 26%, France 12%, Netherlands 4%), US 9%
(1999)
Debt -external: $NA
Economic aid - donor: ODA, $160 million (1999)
Currency: Luxembourg franc (LUF); euro (EUR)
note; on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Luxembourg at a fixed rate of
40.3399 Luxembourg francs per euro and will replace
the local currency for all transactions in 2002
Currency code: LUF; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999);
Luxembourg francs per US dollar - 34.77 (January
1999), 36.299 (1998), 35.774 (1997), 30.962 (1996);
note “ the Luxembourg franc is at par with the Belgian
franc, which circulates freely in Luxembourg
Fiscal year: calendar year
Economy - overview: The economy is based
largely on tourism (including gambling) and textile and
fireworks manufacturing. Efforts to diversify have
spawned other small industries - toys, artificial
flowers, and electronics. The tourist sector has
accounted for roughly 25% of GDP, and the clothing
industry has provided about three-fourths of export
earnings: the gambling industry probably represents
over 40% of GDP. More than 8 million tourists visited
Macau in 2000. Macau depends on China for most of
its food, fresh water, and energy imports. Japan and
Hong Kong are the main suppliers of raw materials
and capital goods. Output dropped 5% in 1998 and
3% in 1999, with a small 2% gain in 2000. Macau
reverted to Chinese administration on 20 December
1999. Gang violence, a dark spot in the economy,
probably will be reduced in 2000-01 to the advantage
of the tourism sector.
GDP: purchasing power parity - $7.82 billion
(2000 est.)
GDP - real growth rate: 2% (2000 est.)
GDP - per capita: purchasing power parity -
$17,500 (2000 est.)
GDP - composition by sector:
agriculture: 1%
industry: 25%
services: 74% (2000 est.)
Population below poverty line: NA%
304
Macau (continued)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); -1 .8% (2000 est.)
Labor force: 283,450(1999)
Labor force - by occupation: restaurants and
hotels 26%, manufacturing 22%, other services 52%
(2000 est.)
Unemployment rate; 6.6% (2000)
Budget:
revenues.'' $1.26 billion
expenditures: $122 billion, including capital
expenditures of $175 million (1999 est.)
Industries: clothing, textiles, toys, electronics,
footwear, tourism, gambling
Industrial production growth rate: NA%
Electricity - production: 1 .355 billion kWh (1 999)
Electricity - production by source:
foss/7 fue/.'' 100%
hydro: 0%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 1 .422 billion kWh (1 999)
Electricity - exports: 3 million kWh (1999)
Electricity - imports: 1 65 million kWh (1 999)
Agriculture - products: rice, vegetables
Exports: $2.6 billion (f.o.b., 2000 est.)
Exports - commodities: textiles, clothing, toys,
electronics, cement, footwear, machinery
Exports - partners: US 47%, EU 30%, China 9.2%,
Hong Kong 6.7% (1999)
Imports: $2.4 billion (c.i.f., 2000 est.)
Imports - commodities: raw materials, foodstuffs,
capital goods, fuels, consumer goods
Imports - partners: China 36%, Hong Kong 18%,
EU 13%, Taiwan 10%, Japan 7% (1999)
Debt - external: $1 .7 billion (1 997)
Economic aid - recipient: $NA
Currency: pataca (MOP)
Currency code: MOP
Exchange rates: patacas per US dollar - 8.033
(January 2001), 8.025 (2000), 7.990 (1999), 7.978
(1 998), 7.974 (1 997), 7.966 (1 996); note - linked to the
Hong Kong dollar at the rate of 1 .03 patacas per Hong
Kong dollar
Fiscal year: calendar year
Economy - overview: At independence in
November 1991, Macedonia was the least developed
of the Yugoslav republics, producing a mere 5% of the
total federal output of goods and services. The
collapse of Yugoslavia ended transfer payments from
the center and eliminated advantages from inclusion
in a de facto free trade area. An absence of
infrastructure, UN sanctions on its largest market
Yugoslavia, and a Greek economic embargo hindered
economic growth until 1996. GDP has subsequently
increased each year, rising by 5% in 2000. Successful
privatization in 2000 boosted the country''s reserves to
over $700 million. Also, the leadership demonstrated
a continuing commitment to economic reform, free
trade, and regional integration. Inflation jumped to
11% in 2000, largely due to higher oil prices.
GDP: purchasing power parity - $9 billion (2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP ■ per capita: purchasing power parity - $4,400
(2000 est.)
GDP - composition by sector:
agricuiture: ^2%
industry: 25%
services: 63% (2000)
Population below poverty line: 25% (2000 est.)
Household income or consumption by percentage
share:
iowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 11% (2000 est.)
Labor force: 1 million (1999 est.)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 32% (2000)
Budget:
revenues; $1.06 billion
expenditures: $1 billion, including capital
expenditures of $107 million (1996 est.)
Industries: coal, metallic chromium, lead, zinc,
ferronickel, textiles, wood products, tobacco
Industrial production growth rate: 3% (2000)
Electricity - production: 6.395 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 82.25%
hydro: 17.75%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 5.992 billion kWh (1 999)
Electricity - exports: 30 million kWh (1999)
Electricity - imports: 75 million kWh (1999)
Agriculture ■ products: rice, tobacco, wheat, corn,
millet, cotton, sesame, mulberry leaves, citrus,
vegetables; beef, pork, poultry, mutton
Exports: $1 .4 billion (f.o.b., 2000 est.)
Exports - commodities: food, beverages, tobacco;
miscellaneous manufactures, iron and steel
Exports - partners: Germany 22%, Yugoslavia
22%, US 12%, Greece 7%, Italy 6% (2000)
Imports: $2 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
chemicals, fuels; food products
Imports - partners: Germany 13%, Ukraine 13%,
Russia 10%, Yugoslavia 8%, Greece 8% (2000)
Debt -external: $1 .4 billion (2000)
Economic aid - recipient: $1 00 million from the EU
(2000)
Currency: Macedonian denar (MKD)
Currency code: MKD
Exchange rates: Macedonian denars per US dollar -
64.757 (January 2001), 65.904 (2000), 56.902 (1999),
54.462 (1998), 50.004 (1997), 39.981 (1996)
Fiscal year: calendar year
Economy - overview: The Netherlands is a
prosperous and open economy depending heavily on
foreign trade. The economy is noted for stable
industrial relations, moderate inflation, a sizable
current account surplus, and an important role as a
European transportation hub. Industrial activity is
predominantly in food processing, chemicals,
petroleum refining, and electrical machinery. A highly
mechanized agricultural sector employs no more than
4% of the labor force but provides large surpluses for
the food-processing industry and for exports. The
Dutch rank third worldwide in value of agricultural
exports, behind the US and France. The Dutch
economy has expanded by 3% or more in each of the
last four years and real GDP growth is likely to be about
3.6% in 2001 . The government in 2001 will implement
its most comprehensive tax reform since World War II,
designed to reduce high income tax levels and redirect
the fiscal burden onto consumption. The Dutch were
among the first 1 1 EU countries establishing the euro
currency zone on 1 January 1999.
GDP: purchasing power parity - $388.4 billion
(2000 est.)
GDP ■ real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity -
$24,400 (2000 est.)
GDP • composition by sector:
agriculture: 3.3%
industry: 26.3%
services: 70 A% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.8%
highest 10%>:2bA%{m4)
Inflation rate (consumer prices): 2.6% (2000 est.)
Labor force: 7.2 million (2000)
Labor force - by occupation: services 73%,
industry 23%, agriculture 4% (1998 est.)
Unemployment rate: 2.6% (2000 est.)
Budget:
revenues.* $134 billion
expenditures: $134 billion, including capital
expenditures of $NA (2001 est.)
Industries: agroindustries, metal and engineering
products, electrical machinery and equipment,
chemicals, petroleum, construction, microelectronics,
fishing
Industrial production growth rate: 3.2% (2000)
Electricity - production: 85.294 billion kWh (1999)
Electricity - production by source:
fossil fuel: 90.25%
hydro: 0.M%
nuclear: 4.27%
ote 5.37% (1999)
Electricity ■ consumption: 97.76 billion kWh (1 999)
Electricity ■ exports: 3.97 billion kWh (1999)
Electricity - imports: 22.407 billion kWh (1999)
Agriculture - products; grains, potatoes, sugar
beets, fruits, vegetables; livestock
Exports: $210.3 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment,
chemicals, fuels; foodstuffs
Exports - partners: EU 78% (Germany 26%,
Belgium-Luxembourg 12%, France 12%, UK 11%,
Italy 6%), Central and Eastern Europe, US (2000)
Imports: $201.2 billion (c.I.f., 2000 est.)
Imports - commodities: machinery and transport
equipment, chemicals, fuels; foodstuffs, clothing
Imports - partners: EU 56% (Germany 18%,
Belgium-Luxembourg 10%, UK 5%, France 6%), US
9%, Central and Eastern Europe (2000)
Debt - external: $0
Economic aid - donor: ODA, $3.5 billion (2000 est.)
Currency: Netherlands guilder (NLG); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that Is now being used by
financial institutions in the Netherlands at a fixed rate
of 2.20371 Netherlands guilders per euro and will
replace the local currency for all transactions in 2002
Currency code: NLG; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999);
Netherlands guilders per US dollar - 1 .9837 (1998),
1.9513 (1997), 1.6859 (1996)
Fiscal year: calendar year','1c2cddf77a375e25e33a465cd8050fd1444df43765edd606aee39bea427db8b0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d7149f0175a91de730f3ef5e63a3bced9a2aa2c7a57a9087ea90448124d7cb0',2001,'IT','Italy','economy',168,'Debt - external: $3.4 billion (2000 est.)
Economic aid - recipient: $1 billion (1999 est.)
Currency: marka (BAM)
Currency code: BAM
Exchange rates: marka per US dollar - 2.10 (2000),
1.83(1999), 1.76 (1998)
Fiscal year: calendar year
Economy - overview: The tourist sector contributes
over 50% of GDP. In 1 999 more than 3 million tourists
visited San Marino. The key industries are banking,
wearing apparel, electronics, and ceramics. Main
agricultural products are wine and cheeses. The per
capita level of output and standard of living are
comparable to those of the most prosperous regions
of Italy, which supplies much of its food.
GDP: purchasing power parity - $860 million
(2000 est.)
GDP - real growth rate: 8% (2000 est.)
GDP - per capita: purchasing power parity -
$32,000 (2000 est.)
GDP “ composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o: NA%
Inflation rate (consumer prices): 2.2% (2000)
Labor force: 18,500 (1999)
Labor force ■ by occupation: services 60%,
industry 38%, agriculture 2% (1998 est.)
Unemployment rate: 3% (1999)
Budget;
revenues: $400 million
expenditures: $400 million, including capital
expenditures of $NA (2000 est.)
Industries: tourism, banking, textiles, electronics,
ceramics, cement, wine ^
Industrial production growth rate: 6% (1997 est.)
Electricity -production: NAkWh
Electricity - production by source;
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity ■ consumption: NA kWh
Electricity - exports: 0 kWh
note: electric power supplied by Italy (1999)
Electricity ■ imports: NA kWh
note: electricity supplied by Italy
Agriculture ■ products: wheat, grapes, corn, olives;
cattle, pigs, horses, beef, cheese, hides
Exports: trade data are included with the statistics
for Italy
Exports - commodities: building stone, lime, wood,
chestnuts, wheat, wine, baked goods, hides, ceramics
Imports: trade data are included with the statistics
for Italy
Imports - commodities: wide variety of consumer
manufactures, food
Debt -external: $NA
Economic aid - recipient: $NA
Currency: Italian lira (ITL); euro (EUR)
Currency code: ITL; EUR
Exchange rates: euros per US dollar - 1.06594
(January 2001), 1.08540 (2000), 0.93863 (1999);
Italian lire per US dollar - 1 ,736.2 (1 998), 1 ,703.1
(1997), 1,542.9(1996)
Fiscal year: calendar year
Economy ■ overview; Switzerland, a prosperous
and stable modern market economy with a per capita
GDP 20% above that of the big western European
economies, experienced solid growth of 3% in 2000,
but growth is expected to fall back to about 2% in
2001. The Swiss in recent years have brought their
economic practices largely into conformity with the
EU''s to enhance their international competitiveness.
Although the Swiss are not pursuing full EU
membership in the near term, in 1999 Bern and
Brussels signed agreements to further liberalize trade
ties, and the agreements should come into force in
2001. Switzerland is still considered a safe haven for
investors, because it has maintained a degree of bank
secrecy and has kept up the franc''s long-term external
value.
GDP: purchasing power parity - $207 billion
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity -
$28,600 (2000 est.)
GDP • composition by sector:
agriculture: 2.8%
industry: 3^^%
sen/ices: Q6A% (1995)
Population beiow poverty iine: NA%
Househoid income or consumption by percentage
share;
lowest 10%:2.Q%
highest 25.2% (1992)
Inflation rate (consumer prices); 1 .5% (2000 est.)
Labor force: 3.9 million (964,000 foreign workers,
mostly Italian) (1998 est.)
Labor force - by occupation: services 69.1%,
Industry 26.3%, agriculture 4.6% (1998 est.)
Unemployment rate: 1 .9% (2000 est.)
Budget:
revenues: $32.66 billion
expenditures: billion, including capital
expenditures of $2.3 billion (1 998 est.)
Industries: machinery, chemicals, watches, textiles,
precision instruments
Industrial production growth rate; 8.6%
(2000 est.)
Electricity - production: 66.768 billion kWh (1999)
Electricity - production by source:
fossil fuel: 3.44%
hydro; 59.1 6%
nuclear: 35.43%
ofher; 1.97% (1999)
Electricity - consumption: 51 .862 billion kWh (1 999)
Electricity - exports: 31 .955 billion kWh (1999)
Electricity ■ imports: 21.723 billion kWh (1999)
Agriculture ■ products: grains, fruits, vegetables;
meat, eggs
Exports: $91 .3 billion (f.o.b., 2000)
Exports - commodities: machinery, chemicals,
metals, watches, agricultural products
Exports ■ partners: EU 65.8% (Germany 22.6%,
France 9.2%, Italy 8.0%, UK 5.5%, Austria 3.2%), US
12.4%, Japan 4.0% (1999)
Imports: $91.6 billion (f.o.b., 2000)
Imports - commodities: machinery, chemicals,
vehicles, metals; agricultural products, textiles
Imports - partners: EU 77.7% (Germany 31 .0%,
France 12,0%, Italy 9.7%, Netherlands 5.1%, UK
5.7%), US 7.1%, Japan 2.9% (1999)
Debt -external: $NA
Economic aid - donor: ODA, $1.1 billion (1995)
Currency: Swiss franc (CHF)
Currency code: CHF
Exchange rates: Swiss francs per US dollar -
1 .6303 (January 2001 ), 1 .6888 (2000), 1 .5022 (1 999),
1 .4498 (1 998), 1 .451 3 (1 997), 1 .2360 (1 996)
Fiscal year: calendar year
487
Switzerland (continued)
Economy - overview: Syria''s predominantly statist
economy is on a shaky footing because of
Damascus''s failure to implement extensive economic
reform. The dominant agricultural sector remains
underdeveloped, with roughly 80% of agricultural land
still dependent on rain-fed sources. Although Syria
has sufficient water supplies in the aggregate at
normal levels of precipitation, the great distance
between major water supplies and population centers
poses serious distribution problems. The water
problem is exacerbated by rapid population growth,
industrial expansion, and increased water pollution.
Private investment is critical to the modernization of
the agricultural, energy, and export sectors. Oil
production is leveling off, and the efforts of the nonoil
sector to penetrate international markets have fallen
short. Syria''s inadequate infrastructure, outmoded
technological base, and weak educational system
make it vulnerable to future shocks and hamper
competition with neighbors such as Jordan and Israel.
The government recognizes the need to open the
economy to additional domestic and foreign
investment.
GDP: purchasing power parity - $50.9 billion
(2000 est.)
GDP - real growth rate: 3.5% (2000 est.)
GDP “ per capita: purchasing power parity - $3,100
(2000 est.)
GDP ■ composition by sector:
agriculture: 29%
industry: 22%
services: 49% (1997)
Population below poverty line: 15%“25%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .5% (2000 est.)
Labor force: 4.7 million (1998 est.)
Labor force - by occupation: agriculture 40%,
industry 20%, services 40% (1 996 est.)
Unemployment rate: 20% (2000 est.)
Budget:
revenues.'' $2.25 billion
expenditures: $5.4 billion, including capita!
expenditures of $NA (2000 est.)
Industries: petroleum, textiles, food processing,
beverages, tobacco, phosphate rock mining
Industrial production growth rate: NA%
Electricity - production: 17.94 billion kWh (1999)
Electricity - production by source:
/OSS// fue/.'' 57.64%
hydro.'' 42.36%
nuclear: 0%
other.'' 0% (1999)
Electricity - consumption: 16.684 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity ■ imports: 0 kWh (1999)
Agriculture - products: wheat, barley, cotton,
lentils, chickpeas, olives, sugar beets; beef, mutton,
eggs, poultry, milk
Exports: $4.8 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum 65%, textiles
1 0%, manufactured goods 1 0%, fruits and vegetables
7%, raw cotton 5%, live sheep 2%, phosphates 1%
(1998 est.)
Exports - partners: Germany 21%, Italy 12%,
France 10%, Saudi Arabia 9%, Turkey 8% (1999 est.)
Imports: $3.5 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment
23%, foodstuffs/animals 20%, metal and metal
products 15%, textiles 10%, chemicals 10%
(1998 est.)
Imports ■ partners: France 1 1 %, Italy 8%, Germany
7%, Turkey 5%, China 4% (1999 est.)
Debt - external: $22 billion (2000 est.)
Economic aid - recipient: $199 million (1997 est.)
Currency: Syrian pound (SYP)
Currency code: SYP
Exchange rates: Syrian pounds per US dollar - 46
(2000), 46 (1998), 41.9 (January 1997)
Fiscal year: calendar year','e43172a63e1e1f1817297f12b2ebce4f76e2a035af018e804413b9b7c2a66e3a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0774a605f38dcb8d0f158330ab9dae6cb6e2a4efcc3ed4eb95d02d3bd7c7c9c',2001,'BW','Botswana','economy',177,'Economy - overview: Botswana has maintained
one of the world''s highest growth rates since
independence in 1966. Through fiscal discipline and
sound management, Botswana has transformed itself
from one of the poorest countries in the world to a
middle-income country with a per capita GDP of
$6,600 in 2000. Diamond mining has fueled much of
Botswana''s economic expansion and currently
accounts for more than one-third of GDP and for
three-fourths of export earnings. Tourism,
subsistence farming, and cattle raising are other key
sectors. The government must deal with high rates of
unemployment and poverty. Unemployment officially
is 1 9%, but unofficial estimates place it closer to 40%.
HIV/AIDS infection rates are the highest in the world
and threaten Botswana''s impressive economic gains.
GDP: purchasing power parity - $1 0.4 billion
(2000 est.)
GDP - real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity - $6,600
(2000 est.)
GDP - composition by sector:
agriculture: 4%
industry: 40% (including 36% mining)
services: 50% (1998 est.)
Population below poverty line: 47% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 8.6% (2000 est.)
Labor force: 235,000 formal sector employees
(1995)
Labor force - by occupation: 1 00,000 public
sector; 135,000 private sector, including 14,300 who
are employed in various mines in South Africa; most
others engaged in cattle raising and subsistence
agriculture (1995 est.)
Unemployment rate: 40% (2000 est.)
Budget;
revenues: $1 .6 billion
expenditures: $1.8 billion, including capital
expenditures of $560 million (FY96)
Industries: diamonds, copper, nickel, coal, salt,
soda ash, potash; livestock processing
Industrial production growth rate: 6.2%
(2000 est.)
Electricity - production: 610 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 1 .51 7 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity ■ imports; 950 million kWh (1999)
Agriculture - products: sorghum, corn, millet,
pulses, groundnuts (peanuts), beans, cowpeas,
sunflower seed; livestock
Exports: $2.6 billion (f.o.b., 2000 est.)
Exports - commodities: diamonds 72%, vehicles,
copper, nickel, meat (1998)
Exports - partners: EU 77%, Southern African
Customs Union (SACU) 18%, Zimbabwe 3% (1998)
Imports: $2.2 billion (f.o.b., 2000 est.)
Imports - commodities: foodstuffs, machinery and
transport equipment, textiles, petroleum products
Imports - partners: Southern African Customs Union
(SACU) 76%, Europe 10%, South Korea 5% (1998)
Debt - external: $455 million (2000)
Economic aid - recipient: $73 million (1995)
Currency: pula(BWP)
Currency code: BWP
Exchange rates: pulas per US dollar - 5.4585
(January 2001 ), 5.1018 (2000), 4.6244 (1 999), 4.2259
(1998), 3.6508 (1997), 3.3242 (1996)
Fiscal year: 1 April - 31 March','629a60fec880597cb9f99ffcf714796c6a6fbceb1d5131d15f7732df1367c89c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('146a4aa6e52fb92cd8cb4b6432afd7b9f1666b8b68239520247f6a600ecc9bb0',2001,'BR','Brazil','economy',191,'Economy - overview: Possessing large and
well-developed agricultural, mining, manufacturing,
and service sectors, Brazil''s economy outweighs that
of all other South American countries and is
expanding its presence in world markets. In the late
eighties and early nineties, high inflation hindered
economic activity and investment. "The Real Plan",
instituted in the spring of 1994, sought to break
inflationary expectations by pegging the real to the US
dollar. Inflation was brought down to single digit
annual figures, but not fast enough to avoid
substantial real exchange rate appreciation during the
transition phase of the "Real Plan". This appreciation
meant that Brazilian goods were now more expensive
relative to goods from other countries, which
contributed to large current account deficits. However,
no shortage of foreign currency ensued because of
the financial community''s renewed interest in Brazilian
markets as inflation rates stabilized and the debt crisis
of the eighties faded from memory. The maintenance
of large current account deficits via capital account
surpluses became problematic as investors became
more risk averse to emerging market exposure as a
consequence of the Asian financial crisis in 1997 and
the Russian bond default in August 1998. After
crafting a fiscal adjustment program and pledging
progress on structural reform, Brazil received a $41 .5
billion IMF-led international support program in
November 1998. In January 1999, the Brazilian
Central Bank announced that the real would no longer
be pegged to the US dollar. This devaluation helped
moderate the downturn in economic growth in 1999
that investors had expressed concerns about over the
summer of 1998. Brazil''s debt to GDP ratio for 1999
beat the IMF target and helped reassure investors that
Brazil will maintain tight fiscal and monetary policy
even with a floating currency. The economy continued
to recover in 2000, with inflation remaining in the
single digits and expected growth for 2001 of 4.5%.
Foreign direct investment set a record of more than
$30 billion in 2000.
GDP: purchasing power parity - $1 .13 trillion
(2000 est.)
GDP " real growth rate: 4.2% (2000 est.)
GDP - per capita: purchasing power parity - $6,500
(2000 est.)
GDP - composition by sector:
agriculture: 9%
industry: 29%
services: 62% (1999 est.)
Population below poverty line: 17.4% (1990 est.)
Household income or consumption by percentage
share:
lowest t0%:\\%
highest /0%; 47.6% (1996)
Inflation rate (consumer prices): 6% (2000)
Labor force: 79 million (1999 est.)
Labor force - by occupation: services 53.2%,
agriculture 23.1%, industry 23.7%
Unemployment rate: 7.1% (2000 est.)
Budget:
revenues; $151 billion
expenditures: P 49 billion, including capital
expenditures of $36 billion (1998)
Industries: textiles, shoes, chemicals, cement,
lumber, iron ore, tin, steel, aircraft, motor vehicles and
parts, other machinery and equipment
Industrial production growth rate: 6.9%
(2000 est.)
Electricity - production: 337.44 billion kWh (1999)
Electricity - production by source:
fossil fuel: 5.28%
hydro; 90.66%
nuc/ear;1.12%
other; 2.94% (1999)
Electricity - consumption: 353.674 billion kWh
69
Brazil (continued)
(1999)
Electricity ■ exports: 5 million kWh (1999)
Electricity - imports: 39.86 billion kWh
note; supplied by Paraguay (1999)
Agriculture - products: coffee, soybeans, wheat,
rice, corn, sugarcane, cocoa, citrus; beef
Exports: $55.1 billion (f.o.b., 2000)
Exports - commodities: manufactures, iron ore,
soybeans, footwear, coffee
Exports - partners: US 23%, Argentina 11%,
Germany 5%, Netherlands 5%, Japan 5% (1999)
Imports: $55.8 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment,
chemical products, oil, electricity
Imports - partners: US 24%, Argentina 12%,
Germany 10%, Japan 5%, Italy 5% (1999)
Debt - external: $232 billion (2000)
Economic aid - recipient: NA
Currency: real(BRL)
Currency code: BRL
Exchange rates: reals per US dollar - 1 .954
(January 2001), 1.830 (2000), 1.815 (1999), 1.161
(1998), 1.078 (1997), 1.005 (1996)
note; from October 1994 through 14 January 1999,
the official rate was determined by a managed float;
since 15 January 1999, the official rate floats
independently with respect to the US dollar
Fiscal year: calendar year','9b855aca32c569c51575faee3ba2d0ff599ada2d6c64d5eddae24c5a2c039768','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ce8099136c0b31e3f3ca62531ed84512b1d1da0709ab9536ce1919ffbd2e438',2001,'ID','Indonesia','economy',198,'Economy - overview: All economic activity is
concentrated on the largest island of Diego Garcia,
where joint UK-US defense facilities are located.
Construction projects and various services needed to
support the miiitary instailations are done by miiitary
and contract employees from the UK, Mauritius, the
Philippines, and the US. There are no industrial or
agricultural activities on the islands. When the Hois
return, they plan to reestablish sugarcane production
and fishing.
Electricity - production: NA kWh; note - electricity
supplied by the US military
Electricity - consumption: NA kWh
Economy - overview: The economy, one of the
most stable and prosperous in the Caribbean, is highly
dependent on tourism, which generates an estimated
45% of the national income. An estimated 350,000
tourists, mainly from the US, visited the islands in
1997. In the mid-1980s, the government began
offering offshore registration to companies wishing to
incorporate in the islands, and incorporation fees now
generate substantial revenues. An estimated 250,000
companies were on the offshore registry by yearend
1 997. The adoption of a comprehensive insurance law
in late 1 994, which provides a blanket of confidentiality
with regulated statutory gateways for investigation of
criminal offenses, is expected to make the British
Virgin Islands even more attractive to international
business. Livestock raising is the most important
agricultural activity; poor soils limit the islands’ ability
to meet domestic food requirements. Because of
traditionally close links with the US Virgin Islands, the
British Virgin Islands has used the dollar as its
currency since 1959.
GDP: purchasing power parity - $31 1 million
(2000 est.)
GDP - real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity -
$16,000 (2000 est.)
GDP - composition by sector:
agriculture: 1 .8%
industry: 6.2%
services: 92% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: m%
Inflation rate (consumer prices): 2% (2000)
Labor force: 4,911 (1980)
Labor force ■ by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 3% (1995)
Budget:
revenues.'' $121 .5 million
expenditures: $115.5 million, including capital
expenditures of $NA (1997)
Industries: tourism, light industry, construction, rum,
concrete block, offshore financial center
Industrial production growth rate: 4% (1985)
Electricity - production: 42 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity -consumption: 39.1 million kWh (1999)
Electricity - exports: 0 kWh (1 999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: fruits, vegetables; livestock,
poultry; fish
Exports: $6.2 million (2000 est.)
Exports - commodities: rum, fresh fish, fruits,
animals; gravel, sand
Exports - partners: Virgin Islands (US), Puerto
Rico, US
Imports: $220 million (2000 est.)
Imports - commodities: building materials,
automobiles, foodstuffs, machinery
72
British Virgin isiands (continued)
Imports - partners: Virgin Islands (US), Puerto
Rico, US
Debt -external: $36.1 million (1997)
Economic aid - recipient: $2.6 million (1995)
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 April - 31 March
Economy - overview: This small, wealthy economy
is a mixture of foreign and domestic entrepreneurship,
government regulation and welfare measures, and
village tradition. Exports of crude oil and natural gas
account for over half of GDP. Per capita GDP is far
above most other Third World countries, and
substantial income from overseas investment
supplements income from domestic production. The
government provides for all medical services and
subsidizes rice and housing. Brunei''s leaders are
concerned that steadily increased integration in the
world economy will undermine internal social
cohesion although it became a more prominent player
by serving as chairman for the 2000 APEC (Asian
Pacific Economic Cooperation) forum. Plans for the
future include upgrading the labor force, reducing
unemployment, strengthening the banking and tourist
sectors, and, in general, a further widening of the
economic base beyond oil and gas.
GDP: purchasing power parity - $5.9 billion
(2000 est.)
GDP " real growth rate: 3% (2000 est.)
GDP ■ per capita: purchasing power parity -
$17,600 (2000 est.)
GDP - composition by sector:
agriculture: 5%
industry: 46%
services: 49% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: m%
Inflation rate (consumer prices): 1% (1999 est.)
Labor force: 144,000 (1995 est.); note ■ includes
foreign workers and military personnel
note: temporary residents make up 41 % of labor force
(1991)
Labor force - by occupation: government 48%,
production of oil, natural gas, services, and
construction 42%, agriculture, forestry, and fishing
10% (1999 est.)
Unemployment rate: 4.9% (1995 est.)
Budget:
revenues: $2.5 billion
expenditures: $2.6 billion, including capital
expenditures of $1.35 billion (1997 est.)
Industries: petroleum, petroleum refining, liquefied
natural gas, construction
Industrial production growth rate: 4% (1997 est.)
Electricity - production: 2.445 biliion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 2.274 billion kWh (1 999)
Electricity - exports: 0 kWh (1 999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: rice, vegetables, fruits,
chickens, water buffalo
Exports: $2.55 billion (f.o.b., 1999 est.)
Exports “ commodities: crude oil, natural gas,
refined products
Exports - partners: Japan 42%, US 17%, South
Korea 14%, Thailand 3% (1999)
Imports: $1.3 biliion (c.i.f., 1999 est.)
Imports - commodities: machinery and transport
equipment, manufactured goods, food, chemicals
Imports - partners: Singapore 34%, UK 15%,
Malaysia 15%, US 5% (1999)
Debt - external: $0
Economic aid - recipient: $4.3 million (1995)
Currency: Bruneian dollar (BND)
Currency code: BND
Exchange rates: Bruneian dollars per US dollar -
1 .7365 (January 2001 ), 1 .7240 (2000), 1 .6950 (1 999),
1.6736 (1998), 1.4848 (1997), 1.4100 (1996); note -
the Bruneian dollar is at par with the Singapore dollar
Fiscal year: calendar year
74
Brunei (continued)
Military expenditures - doilar figure: $343 million
(FY98)
Military expenditures - percent of GDP: 5.1%
(FY98)
Transnationai Issues
Disputes - international: possibly involved in a
complex dispute over the Spratly Islands with China,
Malaysia, Philippines, Taiwan, and Vietnam; in 1984,
Brunei established an exclusive fishing zone that
encompasses Louisa Reef in the southern Spratly
islands, but has not publicly claimed the island
Illicit drugs: drug trafficking and illegally importing
controlled substances are serious offenses in Brunei
and carry a mandatory death penalty
Economy - overview: Economic activity consists
primarily of subsistence farming and fishing. The
islands have few mineral deposits worth exploiting,
except for high-grade phosphate. The potential for a
tourist industry exists, but the remoteness of the
location and a lack of adequate facilities hinder
development. In 1 996, the country experienced a 20%
reduction in revenues from the Compact of Free
Association - the agreement between the US and
Micronesia in which Micronesia receives $1 .3 billion in
financial and technical assistance over a 15-year
period until 2001 - as a result of the second step-down
under the agreement. Since these revenues
accounted for 57% of consolidated government
revenues, reduced Compact funding resulted in a
severe depression. While Micronesia''s economy
appears to have bottomed out in 1999, the country''s
medium-term economic outlook remains fragile due to
likely further reductions in external grants made under
the US Compact funding. Geographical isolation and
a poorly developed infrastructure remain major
impediments to long-term growth.
GDP: purchasing power parity - $263 million
(1999 est.)
note: GDP is supplemented by grant aid, averaging
perhaps $100 million annually
GDP - real growth rate: 0.3% (1999 est.)
GDP - per capita: purchasing power parity - $2,000
(1999 est)
GDP - composition by sector:
agriculture: ^9%
industry: 4%
services: 77% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%:
highest 10%: NA%
Infiation rate (consumer prices): 2.6% (FY98/99)
Labor force: NA
Labor force ■ by occupation: two-thirds are
government employees
Unemployment rate: 1 6% (1 999 est.)
Budget;
revenues; $161 million ($69 million less grants)
expencf/fures; $160 million, including capital
expenditures of $NA (1998 est.)
Industries: tourism, constructiori, fish processing,
craft items from shell, wood, and pearls
Industrial production growth rate: NA%
Eiectricity - production; NA kWh
Eiectricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Eiectricity - consumption: NA kWh
Agriculture - products: black pepper, tropical fruits
and vegetables, coconuts, cassava (tapioca), sweet
potatoes; pigs, chickens
Exports: $73 million (f.o.b., 1996 est.)
Exports - commodities: fish, garments, bananas,
black pepper
Exports - partners: Japan, US, Guam
Imports; $168 million (c.i.f., 1996 est.)
Imports - commodities: food, manufactured goods,
machinery and equipment, beverages
Imports - partners: US, Japan, Australia
Debt - external: $1 1 1 million (1997 est.)
Economic aid - recipient: under terms of the
Compact of Free Association, the US will provide $1 .3
billion in grant aid during the period 1986-2001
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September
Economy - overview: The economy is based on
providing support services for the national wildlife
refuge activities located on the islands. All food and
manufactured goods must be imported.
Economy - overview: Moldova enjoys a favorable
climate and good farmland but has no major mineral
deposits. As a result, the economy depends heavily
on agriculture, featuring fruits, vegetables, wine, and
tobacco. Moldova must import all of its supplies of oil,
coal, and natural gas, largely from Russia. Energy
shortages contributed to sharp production declines
after the breakup of the Soviet Union in 1 991 . As part
of an ambitious reform effort, Moldova introduced a
convertible currency, freed all prices, stopped issuing
preferential credits to state enterprises, backed
steady land privatization, removed export controls,
and freed interest rates. Yet these efforts could not
offset the impact of political and economic difficulties,
both internal and regional. In 1998, the economic
troubles of Russia, by far Moldova''s leading trade
partner, were a major cause of the 8.6% drop in GDP.
In 1999, GDP fell again, by 4.4%, the fifth drop in the
past seven years; exports were down, and energy
supplies continued to be erratic. GDP declined slightly
in 2000, with a serious drought hurting agriculture.
Growth should turn positive in 2001 .
GDP: purchasing power parity -$11.3 billion
(2000 est.)
GDP - real growth rate: -1 .5% (2000 est.)
GDP - per capita: purchasing power parity - $2,500
(2000 est.)
GDP " composition by sector:
agriculture: 31%
industry: 35%
services: 34% (1998)
Population below poverty line: 75% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.7%
highest 10%: 25.8% (1992)
Inflation rate (consumer prices): 32% (2000 est.)
Labor force: 1 .7 million (1 998)
Labor force - by occupation: agriculture 40%,
industry 14%, other 46%o (1998)
Unemployment rate: 1 .9% (includes only officially
registered unemployed; large numbers of
underemployed workers) (November 2000)
Budget:
revenues: $536 million
expenditures: $594 million, including capital
expenditures of $NA (1 998 est.)
Industries: food processing, agricultural machinery,
foundry equipment, refrigerators and freezers,
washing machines, hosiery, sugar, vegetable oil,
shoes, textiles
Industrial production growth rate: 3% (2000 est.)
Electricity - production: 4.155 billion kWh (1999)
Electricity - production by source:
fossil fuel: 93.62%
hydro: 6.38%
nuclear: 0%
other: 0%(1999)
Electricity - consumption: 5.78 billion kWh (1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 1 .91 6 billion kWh (1 999)
Agriculture - products: vegetables, fruits, wine,
grain, sugar beets, sunflower seed, tobacco; beef,
milk
Exports: $500 million (f.o.b., 2000)
Exports - commodities: foodstuffs 57%, wine,
tobacco; textiles and footwear, machinery (1999)
Exports - partners: Russia 41%, Romania 9%,
Germany 8%, Ukraine 7%, Italy, Belarus (1999)
Imports: $761 million (f.o.b., 2000)
Imports - commodities: mineral products and fuel
38%, machinery and equipment, chemicals, textiles
(1999)
Imports ■ partners: Russia 21%, Romania 16%,
Ukraine 14%, Germany 12%, Italy 6%, Belarus (1999)
Debt - external: $900 million (2000)
Economic aid - recipient: $100.8 million (1995);
note - $547 million from the IMF and World Bank
(1992-99)
Currency: Moldovan leu (MDL)
Currency code: MDL
Exchange rates: lei per US dollar - 12.3728
(January 2001), 12.4342 (2000), 10.5158 (1999),
5.3707 (1998), 4.6236 (1997), 4.6045 (1996); note -
lei is the plural form of leu
Fiscal year: calendar year
Economy - overview: Singapore is blessed with a
highly developed and successful free-market
economy, a remarkably open and corruption-free
business environment, stable prices, and the fifth
highest per capita GDP In the world. Exports,
particularly In electronics and chemicals, and services
are the main drivers of the economy. Mainly because
of robust exports, especially electronic goods, the
economy grew10.1%in 2000. Forecasters, however,
are projecting only 4%-6% growth in 2001 largely
because of weaker global demand, especially In the
US. The government promotes high levels of savings
and investment through a mandatory savings scheme
and spends heavily In education and technology. It
also owns government-linked companies (GLCs) -
particularly In manufacturing - that operate as
commercial entities. As Singapore looks to a future
increasingly marked by globalization, the country is
positioning Itself as the region''s financial and
high-tech hub.
GDP: purchasing power parity - $109.8 billion
(2000 est.)
GDP - real growth rate: 1 0.1 % (2000 est.)
GDP - per capita: purchasing power parity -
$26,500 (2000 est.)
GDP - composition by sector:
agriculture: NEGL%
industry: 30%
services: 70%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .4% (2000)
Labor force: 2.1 million (2000)
Labor force - by occupation: financial, business,
and other services 35%, manufacturing 21%,
construction 13%, transportation and
communication 9%
Unemployment rate: 3% (2000 est.)
Budget:
revenues; $18.1 billion
expencf/ft/res; $17.1 billion, including capital
expenditures of $9.5 billion (FY99/00 est.)
Industries: electronics, chemicals, financial
services, oil drilling equipment, petroleum refining,
rubber processing and rubber products, processed
food and beverages, ship repair, entrepot trade,
biotechnology
Industrial production growth rate: 14%
(2000 est.)
Electricity - production: 27.381 billion kWh (1999)
Electricity - production by source:
/bss/7fue/;100%
hydro: 0%
nuclear: 0%
other: 0%(m9)
Electricity - consumption: 25.464 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rubber, copra, fruit, orchids,
vegetables; poultry, eggs, fish, ornamental fish
Exports: $137 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment
(including electronics), chemicals, mineral fuels
Exports - partners: US 19%, Malaysia 17%, Hong
Kong 8%, Japan 7%, Taiwan 5%, Thailand 4%, UK
4%, Netherlands 3.8%, China 3%, South Korea 3%,
Germany 3% (1999)
Imports: $127 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment,
mineral fuels, chemicals, foodstuffs
Imports - partners: US 17%, Japan 17%, Malaysia
16%, Thailand 5%, China 5%, Taiwan 4%, Germany
3%, Saudi Arabia 3% (1999)
Debt - external: $9.7 billion (2000)
Economic aid - recipient: $NA
Currency: Singapore dollar (SGD)
Currency code: SGD
Exchange rates: Singapore dollars per US dollar -
1 .7365 (January 2001 ), 1 .7240 (2000), 1 .6950 (1 999),
1.6736 (1998), 1.4848 (1997), 1.4100 (1996)
Fiscal year: 1 April - 31 March','c4c6dd170aa8ceb865bd1fcc979d993caab9e56812c24a4271dafc6bf4e611fc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a4ddcc0c8d79383656daf68b61a0e241b738a929526054f720e2d4439e78acb',2001,'BG','Bulgaria','economy',209,'Economy - overview: Bulgaria, a former communist
country struggling to enter the European market
economy, suffered a major economic downturn in
1996 and 1997, with triple digit inflation and GDP
contraction of 10.6% and 6.9%. The current
government - which took office in May 1997 after
pre-term parliamentary elections - stabilized the
economy and promoted growth by implementing a
currency board, practicing sound financial policies,
invigorating privatization, and pursuing structural
reforms. Additionally, strong assistance from
international financial institutions - most notably the
IMF which approved a three-year Extended Fund
Facility worth approximately $900 million in
September 1998 - played a critical role in turning the
economy around. After several years of tumult,
Bulgaria''s economy has stabilized. Its
better-than-expected economic performance in 1999 -
despite the impact of the Kosovo conflict, the 1998
Russian financial crisis, and structural reforms - and
strong growth in 2000 portends solid growth over the
next few years; this assumes continued fiscal
restraint, additional structural reforms, aid from
abroad, and prosperous times in the EU economy.
GDP: purchasing power parity - $48 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $6,200
(2000 est.)
GDP - composition by sector:
agriculture’A5%
industry: 29%
services: 56% (2000 est.)
Population below poverty line: 35% (2000 est.)
Household Income or consumption by percentage
share:
lowest 10%: 3.4%
highest 22.5% (1995)
Inflation rate (consumer prices): 10.4%
(2000 est.)
Labor force: 3.83 million (2000 est.)
Labor force ■ by occupation: agriculture 26%,
industry 31%, services 43% (1998 est.)
Unemployment rate: 17.7% (2000 est.)
Budget:
revenues; $4.85 billion
expenditures: $4.92 billion, Including capital
expenditures of $NA (2000 est.)
Industries: electricity, gas and water; food,
beverages and tobacco; machinery and equipment,
base metals, chemical products, coke, refined
petroleum, nuclear fuel
Industrial production growth rate: 10.8%
(2000 est.)
Electricity - production: 36.217 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 51 .52%
hydro; 8.35%
nuclear: 40A2%
ofher; 0.01% (1999)
Electricity ■ consumption: 33.182 billion kWh
(1999)
Electricity - exports: 2.2 billion kWh (1999)
Electricity - Imports: 1 .7 billion kWh (1999)
Agriculture - products: vegetables, fruits, tobacco,
livestock, wine, wheat, barley, sunflowers, sugar
beets
Exports: $4.8 billion (f.o.b., 2000 est.)
Exports - commodities: clothing, footwear, iron and
steel, machinery and equipment, fuels
Exports - partners: Italy 14%, Turkey 10%,
Germany 9%, Greece 8%, Yugoslavia 8%, Belgium
6%, France 5%, US 4% (2000)
Imports: $5.9 billion (f.o.b., 2000 est.)
Imports - commodities: fuels, minerals, and raw
materials; machinery and equipment; metals and
ores; chemicals and plastics; food, textiles
Imports ■ partners: Russia 24%, Germany 14%,
Italy 8%, Greece 5%, France 5%, Romania 4%,
Turkey 3%, US 3% (2000)
Debt - external: $10.4 billion (2000 est.)
Economic aid - recipient: $1 billion (1999 est.)
Currency: lev(BGL)
Currency code: BGL
Exchange rates: leva per US dollar - 2.0848
(January 2001), 2.1233 (2000), 1.8364 (1999),
1,760.36 (1998), 1,681.88 (1997), 177.89 (1996)
note: on 5 July 1 999, the lev was redenominated; the
post-5 July 1 999 lev is equal to 1 ,000 of the pre-5 July
1999 lev
Fiscal year: calendar year','7b1490e3eb109c73544c1eb9a3ecf82ffccc16e9a8f52f14b63c1376838521bc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf3279aed42a2daa213cb72ea914cf4aac0859492b41ddcfff843e6128fa0660',2001,'ET','Ethiopia','economy',215,'Economy - overview: One of the poorest countries
in the world, landlocked Burkina Faso has a high
population density, few natural resources, and a
fragile soil. About 90% of the population is engaged in
(mainly subsistence) agriculture which is highly
vulnerable to variations in rainfall. Industry remains
dominated by unprofitable government-controlled
corporations. Following the African franc currency
devaluation in January 1 994 the government updated
its development program in conjunction with
International agencies, and exports and economic
growth have increased. Maintenance of its
macroeconomic progress in 2001-02 depends on
continued low inflation, reduction in the trade deficit,
and reforms designed to encourage private
investment.
GDP: purchasing power parity - $12 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,000
(2000 est.)
GDP - composition by sector:
agriculture: 26%
industry: 27%
sen/ices: A7% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 22%
highest 39.5% (1994)
Inflation rate (consumer prices): 1 .5% (2000 est.)
Labor force: 5 million (1999)
note: a large part of the male labor force migrates
annually to neighboring countries for seasonal
employment
Labor force - by occupation: agriculture 90%
(2000 est.)
Unemployment rate: NA%
Budget:
revenues: $277 million
expenditures: $492 million, including capital
expenditures of $233 million (1995 est.)
Industries: cotton lint, beverages, agricultural
processing, soap, cigarettes, textiles, gold
Industrial production growth rate: 4.2% (1995)
Electricity - production: 285 million kWh (1999)
Electricity - production by source:
fossil fuel: 71 .93%
hydro: 26.07%
nuclear: 0%
other: 0%(i999)
Electricity - consumption: 265.1 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: peanuts, shea nuts,
sesame, cotton, sorghum, millet, corn, rice; livestock
Exports: $220 million (f.o.b., 2000 est.)
Exports - commodities: cotton, animal products,
gold
79
Burkina Faso (continued)
Exports - partners: Italy 13%, France 10%,
Indonesia 8%, Thailand 7% (1999)
Imports: $610 million (f.o.b., 2000 est.)
Imports - commodities: machinery, food products,
petroleum
Imports - partners: Cote d''Ivoire 30%, France 28%,
Spain 3%, Benelux 3% (1999)
Debt - external: $1 .3 billion (1 997)
Economic aid - recipient: $484.1 miilion (1995)
Currency: Communaute Financiere Africaine franc
(XOF); note - responsible authority is the Central
Bank of the West African States
Currency code: XOF
Exchange rates: Communaute Financiere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1 997), 51 1 .55 (1 996): note - from 1 January 1 999,
the XOF is pegged to the euro at a rate of 655.957
XOF per euro
Fiscal year: calendar year
Economy - overview: Burma has a mixed economy
with private activity dominant in agriculture, light
industry, and transport, and with substantial
state-controlled activity, mainly in energy, heavy
industry, and the rice trade. Government policy in the
1990s has aimed at revitalizing the economy after
three decades of tight central planning. Private activity
markedly increased in the early to mid-1 990s, but
began to decline in the past several years due to
frustrations with the unfriendly business environment
and political pressure from western nations. Published
estimates of Burma''s foreign trade are greatly
understated because of the volume of black-market,
illicit, and border trade. A major ongoing problem is
the failure to achieve monetary and fiscal stability.
Burma remains a poor Asian country and living
standards for the majority have not improved over the
past decade. Short-term growth will continue to be
restrained because of poor government planning and
minima! foreign investment.
GDP: purchasing power parity - $63.7 billion
(2000 est.)
GDP - real growth rate: 4.9% (2000 est.)
GDP ■ per capita: purchasing power parity - $1 ,500
(2000 est.)
GDP - composition by sector:
agriculture: 42%
industry: 17%
services: A^% (2000 est.)
Population below poverty line: 23% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%:2.Q%
highest m; 32.4% (1998)
Inflation rate (consumer prices): 18% (1999)
Labor force: 19.7 million (FY98/99 est.)
Labor force - by occupation: agriculture 65%,
industry 10%, services 25% (1999 est.)
Unemployment rate: 7.1% (official FY97/98 est.)
Budget:
revenues: $7.9 billion
expenditures: $^2.2 billion, including capital
expenditures of $5.7 billion (FY96/97)
Industries: agricultural processing: textiles and
footwear; wood and wood products; copper, tin,
tungsten, iron; construction materials;
pharmaceuticals; fertilizer
Industrial production growth rate: NA%
Electricity - production: 4.813 billion kWh (1999)
Electricity - production by source:
fossil fuel: 68.56%
/?yofro; 31.44%
nuclear: 0%
other: 0%{^m)
Electricity ■ consumption: 4.476 billion kWh (1 999)
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: paddy rice, corn, oilseed,
sugarcane, pulses; hardwood
Exports: $1.3 billion (f.o.b., 1999)
Exports - commodities: apparel 36%, foodstuffs
22%, wood products 21%, precious stones 5% (1999)
Exports - partners: India 1 3%, Singapore 1 1 %,
China 11%, US 8% (1999 est.)
note: official trade statistics do not include trade in
illicit goods - such as narcotics, teak, and gems - or
the largely unrecorded border trade with China and
Economy - overview: Ethiopia''s economy is based
on agriculture, which accounts for half of GDP, 90% of
exports, and 80% of total employment. The
agricultural sector suffers from frequent periods of
drought and poor cultivation practices, and as many
as 4.6 million people need food assistance annually.
Coffee is critical to the Ethiopian economy, and
Ethiopia earned $267 million in 1999 by exporting
105,000 metric tons. According to current estimates,
coffee contributes 10% of Ethiopia''s GDP. More than
15 million people (25% of the population) derive their
livelihood from the coffee sector. Other exports
include live animals, hides, gold, and qat. In
December 1 999, Ethiopia signed a $1 .4 billion joint
venture deal to develop a huge natural gas field in the
Somali Regional State. The war with Eritrea forced the
government to spend scarce resources on the military
and to scale back ambitious development plans.
Foreign investment has declined significantly.
162
Ethiopia (continued)
Government taxes imposed in late 1 999 to raise
money for the war depressed an already weak
economy. The war forced the government to improve
roads and other parts of the previously neglected
infrastructure, but only certain regions of the nation
benefited. Recovery from the war is mostly contingent
on natural factors. A drought has continued into the
end of 2000 and food relief is expected to be needed
through mid-2001 at least. Ethiopia may receive
Highly Indebted Poor Countries (HIPC) debt relief by
the end of the year.
GDP: purchasing power parity - $39.2 billion
(2000 est.)
GDP - real growth rate: 2% (2000 est.)
GDP - per capita: purchasing power parity - $600
(2000 est.)
GDP - composition by sector:
agriculture: 45%
industry: 12%
services: 43% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3%
highest 33.7% (1995)
Inflation rate (consumer prices): 5% (2000 est.)
Labor force; NA
Labor force - by occupation; agriculture and
animal husbandry 80%, government and services
12%, industry and construction 8% (1985)
Unemployment rate: NA%
Budget;
revenues: $1 billion
expenditures: AS billion, including capital
expenditures of $415 million (FY96/97)
Industries: food processing, beverages, textiles,
chemicals, metals processing, cement
Industrial production growth rate: NA%
Electricity - production: 1 .625 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 3.08%
hydro.'' 96.92%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 1 .51 1 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1 999)
Agriculture - products: cereals, pulses, coffee,
oilseed, sugarcane, potatoes, qat; hides, cattle,
sheep, goats
Exports: $460 million (f.o.b., 1999)
Exports - commodities: coffee, gold, leather
products, oilseeds, qat
Exports - partners: Germany 16%, Japan 13%,
Djibouti 10%, Saudi Arabia 7% (1999 est.)
Imports: $1.25 billion (f.o.b., 1999)
Imports - commodities: food and live animals,
petroleum and petroleum products, chemicals,
machinery, motor vehicles
Imports ■ partners: Saudi Arabia 28%, Italy 10%,
Russia 7%, US 6% (1999 est.)
Debt ■ external: $10 billion (1999 est.)
Economic aid - recipient: $367 million (FY95/96)
Currency: birr(ETB)
Currency code: ETB
Exchange rates: birr per US dollar (end of period) -
8.3140 (December 2000), 8.3140 (2000), 8.1340
(1999), 7.5030 (1998), 6.8640 (1997), 6.4260 (1996)
note: since May 1993, the birr market rate has been
determined in an interbank market supported by
weekly wholesale auction
Fiscal year: 8 July - 7 July
Economy - overview: no economic activity
Falkland Islands ^
(Islas Malvinas) ■
(overseas territory of the UK;
also claimed by Argentina)
Background: A French possession since 1897, the
island is heavily wooded; it is the site of a small
military garrison that staffs a weather station.
Economy - overview: One of the 20 poorest
countries in the world, Guinea-Bissau depends mainly
on farming and fishing. Cashew crops have increased
remarkably in recent years, and the country now ranks
sixth in cashew production. Guinea-Bissau exports
fish and seafood along with small amounts of peanuts,
palm kernels, and timber. Rice is the major crop and
staple food. However, intermittent fighting between
Senegalese-backed government troops and a military
junta destroyed much of the country''s infrastructure
and caused widespread damage to the economy in
1 998; the civil war led to a 28% drop in GDP that year,
with partial recovery in 1999-2000. Before the war,
trade reform and price liberalization were the most
successful part of the country''s structural adjustment
214
Guinea-Bissau (continued)
program under IMF sponsorship. The tightening of
monetary policy and the development of the private
sector had also begun to reinvigorate the economy.
Because of high costs, the development of petroleum,
phosphate, and other mineral resources Is not a
near-term prospect. However, unexploited offshore oil
reserves could provide much-needed revenue in the
long run.
GDP: purchasing power parity -$1.1 billion
(2000 est.)
GDP ■ real growth rate: 7.6% (2000 est.)
GDP - per capita: purchasing power parity - $850
(2000 est.)
GDP - composition by sector:
agriculture: 54%
industry: 15%
serv/ces,'' 31% (1997 est.)
Population below poverty line: 50% (1991 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.5%
highest /(?%.• 42.4% (1991)
Inflation rate (consumer prices): 3% (2000 est.)
Labor force: 480,000
Labor force - by occupation: agriculture 78%
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: SNA, including capital expenditures of
SNA
Industries: agricultural products processing, beer,
soft drinks
Industrial production growth rate: 2.6%
(1997 est.)
Electricity - production: 55 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1999)
Electricity ■ consumption: 51 .2 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: rice, corn, beans, cassava
(tapioca), cashew nuts, peanuts, palm kernels, cotton;
timber; fish
Exports: $80 million (f.o.b., 2000 est.)
Exports - commodities: cashew nuts 70%, shrimp,
peanuts, palm kernels, sawn lumber (1996)
Exports - partners: India 59%, Singapore 12%, Italy
10% (1998)
Imports: $55.2 million (f.o.b., 2000 est.)
Imports ■ commodities: foodstuffs, machinery and
transport equipment, petroleum products (1996)
Imports - partners: Portugal 26%, France 8%,
Senegal 8%, Netherlands 7% (1998)
Debt - external: $964 million (1998 est.)
Economic aid - recipient: $115.4 million (1995)
Currency: Communaute Financiere Africaine franc
(XOF); note - responsible authority is the Central
Bank of the West African States; previously the
Guinea-Bissau peso (GWP) was used
Currency code: XOF; GWP
Exchange rates: Communaute Financiere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997); Guinea-Bissauan pesos per US dollar -
26,373(1996)
note: as of 1 May 1997, Guinea-Bissau adopted the
CFA franc as the national currency; since 1 January
1 999, the CFA franc is pegged to the euro at a rate of
655.957 CFA francs per euro
Fiscal year: calendar year
Economy - overview: This small poor island
economy has become increasingly dependent on
cocoa since independence 25 years ago. However,
cocoa production has substantially declined because
of drought and mismanagement. The resulting
shortage of cocoa for export has created a persistent
balance-of-payments problem. Sao Tome has to
import all fuels, most manufactured goods, consumer
goods, and a significant amount of food. Over the
years, it has been unable to service its external debt
and has had to depend on concessional aid and debt
rescheduling. Sao Tome benefited from $200 million
in debt relief in December 2000 under the Highly
Indebted Poor Countries (HIPC) program.
Considerable potential exists for development of a
tourist industry, and the government has taken steps
to expand facilities in recent years. The government
also has attempted to reduce price controls and
subsidies, but economic growth has remained
sluggish. Sao Tome is also optimistic that significant
petroleum discoveries are forthcoming in its territorial
waters in the oil-rich waters of the Gulf of Guinea.
Corruption scandals continue to weaken the
economy. At the same time, progress in the economic
reform program has attracted international financial
institutions'' support, and GDP growth will likely rise to
at least 4% in 2001-02.
GDP: purchasing power parity - $178 million
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,100
(2000 est.)
GDP - composition by sector:
agriculture: 23%
industry: ^9%
services: 58% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o: NA%
Inflation rate (consumer prices): 5% (2000 est.)
Labor force: NA
Labor force - by occupation: population mainly
engaged in subsistence agriculture and fishing
note: shortages of skilled workers
Unemployment rate: NA%
Budget:
revenues: $58 million
expenditures: $114 million, including capital
expenditures of $54 million (1993 est.)
Industries: light construction, textiles, soap, beer;
fish processing; timber
Industrial production growth rate: NA%
Electricity - production: 17 million kWh (1999)
Electricity - production by source:
/oss/7fue/;41.18%
hydro: 58.82%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 1 5.8 million kWh (1 999)
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cocoa, coconuts, palm
kernels, copra, cinnamon, pepper, coffee, bananas,
papayas, beans; poultry; fish
Exports: $3.2 million (f.o.b., 2000 est.)
Exports ■ commodities: cocoa 90%, copra, coffee,
palm oil
Exports - partners: Netherlands 18%, Germany
9%, Portugal 9% (1998)
Imports: $40 million (f.o.b., 2000 est.)
Imports - commodities: machinery and electrical
equipment, food products, petroleum products
Imports - partners: Portugal 42%, US 20%, South
Africa 6% (1998)
Debt - external: $268 million (2000)
Economic aid - recipient: $200 million in December
2000 under the HIPC program
Currency: dobra (STD)
Currency code: STD
Exchange rates: dobras per US dollar - 2390.04
(December 2000), 7,119.0 (1999), 6,883.2 (1998),
4,552.5 (1997), 2,203.2(1996)
Fiscal year: calendar year
Economy - overview: This is an oil-based economy
with strong government controls over major economic
activities. Saudi Arabia has the largest reserves of
petroleum in the world (26% of the proved reserves),
ranks as the largest exporter of petroleum, and plays
a leading role in OPEC. The petroleum sector
-accounts for roughly 75% of budget revenues, 40% of
GDP, and 90% of export earnings. About 35% of GDP
comes from the private sector. Roughly 5 million
foreign workers play an important role in the Saudi
economy, for example, in the oil and service sectors.
Saudi Arabia was a key player in the successful efforts
of OPEC and other oil producing countries to raise the
price of oil in 1999-2000 to its highest level since the
Gulf war by reducing production. Riyadh expects to
have a moderate budget deficit in 2001 , in part
because of increased spending for education and
other social programs. The government in 1999
announced plans to begin privatizing the electricity
companies, which follows the ongoing privatization of
the telecommunications company. The government is
expected to continue calling for private sector growth
to lessen the kingdom''s dependence on oil and
increase employment opportunities for the swelling
Saudi population. Shortages of water and rapid
population growth will constrain government efforts to
increase self-sufficiency in agricultural products.
GDP: purchasing power parity - $232 billion
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity -
$10,500 (2000 est.)
GDP - composition by sector:
agriculture: 6%
industry: 47%
services: 47% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o:m%
Inflation rate (consumer prices): 0.5% (2000)
Labor force: 7 million
note: 35% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Labor force ■ by occupation: agriculture 12%,
industry 25%, services 63% (1999 est.)
Unemployment rate: NA%
Budget:
revenues; $66 billion
expenditures: $00 billion, including capital
expenditures of $NA (2000 est.)
Industries: crude oil production, petroleum refining,
basic petrochemicals, cement, construction, fertilizer,
plastics
Industrial production grovirth rate: 1% (1997 est.)
Electricity - production: 120 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1 999)
Electricity - consumption: 111.6 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1 999)
Agriculture - products: wheat, barley, tomatoes,
melons, dates, citrus; mutton, chickens, eggs, milk
Exports: $81.2 billion (f.o.b., 2000)
Exports - commodities: petroleum and petroleum
products 90%
Exports - partners: Japan 18%, US 18%, France
4%, South Korea, Singapore, India (1999)
Imports: $30.1 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment,
foodstuffs, chemicals, motor vehicles, textiles
Imports - partners: US 25%, Japan 10%, Germany
7%, Italy 5%, France, UK (1999)
Debt “ external: $26.3 billion (2000 est.)
Economic aid ■ donor: pledged $100 million in
1993 to fund reconstruction of Lebanon; since 1993,
Saudi Arabia has committed $208 million for
assistance to the Palestinians
Currency: Saudi riyal (SAR)
Currency code: SAR
Exchange rates: Saudi riyals per US dollar - 3.7450
(fixed rate since June 1986)
Fiscal year: calendar year
Economy - overview: In January 1994, Senegal
undertook a bold and ambitious economic reform
program with the support of the international donor
community. This reform began with a 50%
devaluation of Senegal''s currency, the CFA franc,
which is linked at a fixed rate to the French franc.
Government price controls and subsidies have been
steadily dismantled. After seeing its economy contract
by 2.1% in 1993, Senegal made an important
turnaround, thanks to the reform program, with real
growth in GDP averaging 5% annually in 1995-99.
Annual inflation has been pushed down to 2%, and the
fiscal deficit has been cut to less than 1.5% of GDP.
Investment rose steadily from 13.8% of GDP in 1993
to 16.5% in 1997. As a member of the West African
Economic and Monetary Union (UEMOA), Senegal is
working toward greater regional integration with a
unified external tariff. Senegal also realized full
Internet connectivity in 1996, creating a miniboom in
information technology-based services. Private
activity now accounts for 82% of GDP. On the
negative side, Senegal faces deep-seated urban
problems of chronic unemployment, juvenile
delinquency, and drug addiction. Real GDP growth is
expected to rise above 6%, while inflation is likely to
hold at 2% in 2001-02.
GDP: purchasing power parity - $16 billion
(2000 est.)
GDP - real growth rate: 5.7% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,600
(2000 est.)
GDP - composition by sector:
agriculture: 19%
industry: 20%
services: 61 % (1 997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 1 .4%
highest 42.8% (1991)
Inflation rate (consumer prices): 1 .5% (2000 est.)
Labor force: NA
Labor force - by occupation: agriculture 60%
Unemployment rate: NA%; urban youth 40%
Budget:
revenues: $885 million
expenditures: $QSS million, including capital
expenditures of $125 million (1996 est.)
Industries: agricultural and fish processing,
phosphate mining, fertilizer production, petroleum
refining, construction materials
Industrial production growth rate: 7% (1998 est.)
Electricity - production: 1 .27 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 1.181 billion kWh (1999)
446
Sonogal (continued)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: peanuts, millet, corn,
sorghum, rice, cotton, tomatoes, green vegetables;
cattle, poultry, pigs; fish
Exports: $959 million (f.o.b., 2000)
Exports - commodities: fish, ground nuts
(peanuts), petroleum products, phosphates, cotton
Exports - partners: France 17%, India 17%, Italy
12%, Spain 6%, Mali 6%, Cote d’Ivoire 4% (1999)
Imports: $1.3 billion (f.o.b., 2000)
Imports - commodities: foods and beverages,
consumer goods, capital goods, petroleum products
Imports - partners: France 30%, Nigeria 7%, Italy
6%, Thailand 5%, Germany 4%, US 4% (1999)
Debt - external: $4.1 billion (1998 est.)
Economic aid - recipient: $647.5 million (1995)
Currency: Communaute Financiere Africaine franc
(XOF); note - responsible authority is the Central
Bank of the West African States
Currency code: XOF
Exchange rates: Communaute Financiere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 511.55 (1966); note - from 1 January 1999,
the XOF is pegged to the euro at a rate of 655.957
XOF per euro
Fiscal year: calendar year','de76585d3ea63869eb7b206309b5ff9efcb8bab7d690719612435c742266243e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad5506304dbeb1df5d0207976f7fac46e571fc01052210959a2b4aed744b3f29',2001,'TH','Thailand','economy',224,'Imports: $2.5 billion (f.o.b., 1999)
Imports - commodities: machinery, transport
equipment, construction materials, food products
Imports - partners: Singapore 28%, Thailand 12%,
China 10%, Japan 10%, South Korea 9% (1999 est.)
Debt ■ external: $6 billion (FY99/00 est.)
Economic aid - recipient: $99 million (FY98/99)
Currency: kyat(MMK)
Currency code: MMK
Exchange rates: kyats per US dollar - official rate -
6.5972 (January 2001), 6.5167 (2000), 6.2858 (1999),
6.3432 (1998), 6.2418 (1997), 5.9176 (1996); kyats
per US dollar - black market exchange rate - 435
(yearend 2000)
Fiscal year: 1 April - 31 March
Economy - overview: Burundi is a landlocked,
resource-poor country with an underdeveloped
manufacturing sector. The economy is predominantly
agricultural with roughly 90% of the population
dependent on subsistence agriculture. Its economic
health depends on the coffee crop, which accounts for
80% of foreign exchange earnings. The ability to pay
for imports therefore rests largely on the vagaries of
the climate and the international coffee market. Since
October 1993 the nation has suffered from massive
ethnic-based violence which has resulted in the death
of perhaps 250,000 persons and the displacement of
about 800,000 others. Only one in four children go to
school, and one in nine adults has HIV/AIDS. Foods,
medicines, and electricity remain in short supply.
GDP: purchasing power parity ■ $4.4 billion
(2000 est.)
GDP - real growth rate: 1 .8% (2000 est.)
GDP - per capita: purchasing power parity - $720
(2000 est.)
GDP - composition by sector:
agriculture: 50%
industry: ^8%
services: 32% (1 999 est.)
Popuiation below poverty iine: 36.2% (1990 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.4%
highest 26.6% (1992)
Inflation rate (consumer prices): 22% (2000 est.)
Labor force: 1.9 million
Labor force - by occupation: NA
Unemployment rate: NA%
Budget:
revenues; $125 million
expenditures: million, including capital
expenditures of $NA (2000 est.)
Industries: light consumer goods such as blankets,
shoes, soap; assembly of imported components;
public works construction; food processing
Industrial production growth rate: 6.3%
(1999 est.)
Electricity - production: 141 million kWh (1999)
Electricity - production by source:
fossil fuel: 0.71%
hydro: 99.29%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 160.1 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 29 million kWh
note: supplied by the Democratic Republic of the
Congo (1999)
Agriculture ■ products: coffee, cotton, tea, corn,
sorghum, sweet potatoes, bananas, manioc (tapioca);
beef, milk, hides
Exports: $32 million (f.o.b., 2000)
Exports - commodities: coffee, tea, sugar, cotton,
hides
84
Burundi (continued)
Exports - partners: Germany 17%, Belgium 14%,
US 8%, France 6%, Switzerland 4% (1999)
Imports: $110 million (f.o.b., 2000)
Imports ■ commodities: capital goods, petroleum
products, foodstuffs
Imports - partners: Belgium 20%, Zambia 11%,
Kenya 8%, South Africa 5%, France 4% (1999)
Debt - external: $1 .12 billion (1999 est.)
Economic aid - recipient: $1,344 billion (1999 est.)
Currency: Burundi franc (BIF)
Currency code: BIF
Exchange rates: Burundi francs per US dollar -
782.36 (January 2001), 720.67 (2000), 563.56 (1999),
477.77 (1998), 352.35 (1997), 302.75 (1996)
Fiscal year: calendar year
Economy ■ overview: After enjoying the world''s
highest growth rate from 1985 to 1995 - averaging
almost 9% annually - increased speculative pressure
on Thailand''s currency in 1997 led to a crisis that
uncovered financial sector weaknesses and forced
the government to float the baht. Long pegged at 25 to
the dollar, the baht reached its lowest point of 56 to the
dollar in January 1 998 and the economy contracted by
10.2% that same year. Thailand entered a recovery
stage in 1999, expanding 4.2% and grew about the
same amount in 2000, largely due to strong exports -
which increased about 20% in 2000. An ailing financial
sector and the slow pace of corporate debt
restructuring, combined with a softening of global
demand, is likely to slow growth in 2001 .
GDP: purchasing power parity - $413 billion
(2000 est.)
GDP - real growth rate: 4.2% (2000 est.)
GDP - per capita: purchasing power parity - $6,700
(2000 est.)
GDP - composition by sector:
agriculture: 13%
industry: 40%
services: 47% (1999)
Population below poverty line: 12.5% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.5%
highest 10%: 37.1% (1992)
Inflation rate (consumer prices): 2.1% (2000 est.)
Labor force: 32.6 million (1 997 est.)
497
Thailand (continued)
Labor force - by occupation; agriculture 54%,
industry 15%, services 31% (1996 est.)
Unemployment rate: 3.7% (2000 est.)
Budget:
revenues; $19 billion
expenditures: $21 billion, including capital
expenditures of $NA (2000 est.)
Industries: tourism; textiles and garments,
agricultural processing, beverages, tobacco, cement,
light manufacturing, such as jewelry; electric
appliances and components, computers and parts,
integrated circuits, furniture, plastics; world''s
second-largest tungsten producer and third-largest tin
producer
Industrial production growth rate: 3% (2000 est.)
Electricity ■ production: 89.431 billion kWh (1999)
Electricity ■ production by source:
foss/7 fue/; 91.17%
hydro: 3^0
nuclear: 0%
ofoer; 5.02% (1999)
Electricity - consumption: 83.991 billion kWh
(1999)
Electricity - exports: 200 million kWh (1999)
Electricity - imports: 1.02 billion kWh (1999)
Agriculture - products: rice, cassava (tapioca),
rubber, corn, sugarcane, coconuts, soybeans
Exports: $68.2 billion (f.o.b., 2000 est.)
Exports - commodities: computers and parts,
textiles, integrated circuits, rice
Exports - partners: US 22%, Japan 14%,
Singapore 9%, Hong Kong 5%, Netherlands 4%,
Malaysia 4%, UK 4% (1999)
Imports: $61 .8 billion (f.o.b., 2000 est.)
Imports - commodities: capita! goods, intermediate
goods and raw materials, consumer goods, fuels
Imports ■ partners: Japan 26%, US 14%, Singapore
6%, China 5%, Malaysia 5%, Taiwan 5% (1999)
Debt - external: $90 billion (2000 est.)
Economic aid - recipient: $131 .5 million
(1998 est.)
Currency: baht(THB)
Currency code: THB
Exchange rates: baht per US dollar - 43.078
(January 2001 ), 40.1 12 (2000), 37.814 (1 999), 41 .359
(1998), 31.364 (1997), 25.343 (1996)
Fiscal year: 1 October - 30 September
Economy - overview: This small sub-Saharan
economy is heavily dependent on both commercial
and subsistence agriculture, which provides
employment for 65% of the labor force. Some basic
foodstuffs must still be imported. Together, cocoa,
coffee, and cotton generate some 40% of export
earnings, with cotton being the most significant cash
crop despite falling prices on the world market. In the
industrial sector, phosphate mining is by far the most
important activity. Togo is the world''s fourth largest
producer, and geological advantages keep production
costs low. The recently privatized mining operation,
Office Togolais des Phosphates (OTP), is slowly
recovering from a steep fall in prices in the early
1990''s, but continues to face the challenge of tough
foreign competition, exacerbated by weakening
demand. Togo serves as a regional commercial and
trade center. It continues to expand its duty-free
export-processing zone (EPZ), launched in 1989,
which has attracted enterprises from France, Italy,
Scandinavia, the US, India, and China and created
jobs for Togolese nationals. The government''s
decade-long effort, supported by the World Bank and
the IMF, to implement economic reform measures,
encourage foreign investment, and bring revenues in
line with expenditures has stalled. Progress depends
on following through on privatization, increased
openness in government financial operations,
progress towards legislative elections, and possible
downsizing of the military, on which the regime has
depended to stay in place. Lack of foreign aid,
deterioration of the financial sector, energy shortages,
and depressed commodity prices continue to
constrain economic growth; however, Togo did realize
a 3% gain in GDP in 1 999. The takeover of the national
power company by a Franco-Canadian consortium in
2000 should ease the energy crisis and if successful
legislative elections pave the way for increased aid,
growth should rise to 5% a year in 2001-02.
GDP: purchasing power parity - $7.3 billion
(2000 est.)
GDP - real growth rate: 3.4% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,500
(2000 est.)
GDP - composition by sector:
agriculture: A2%
industry: 2\\%
services: 37% {^997)
Popuiation below poverty iine: 32% (1989 est.)
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: m%
Inflation rate (consumer prices): 2.5% (2000 est.)
Labor force: 1 .74 million (1 996)
Labor force - by occupation: agriculture 65%,
industry 5%, services 30% (1998 est.)
Unempioyment rate: NA%
Budget:
revenues: $232 million
expenditures: $252 million, including capital
expenditures of $NA (1997 est.)
Industries: phosphate mining, agricultural
processing, cement; handicrafts, textiles, beverages
Industrial production growth rate: NA%
Electricity - production: 92 million kWh (1999)
Electricity - production by source:
fossil fuel: 97.83%
hydro: 2A7%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 51 1 .6 million kWh
(1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 426 million kWh
note: electricity supplied by Ghana (1999)
Agriculture - products: coffee, cocoa, cotton,
yams, cassava (tapioca), corn, beans, rice, millet,
sorghum; livestock; fish
Exports: $336 million (f.o.b., 2000)
Exports - commodities: cotton, phosphates,
coffee, cocoa
Exports - partners: Nigeria, Brazil, Canada,
Philippines (1999)
Imports: $452 million (f.o.b., 2000)
Imports - commodities: machinery and equipment,
foodstuffs, petroleum products
Imports - partners: Ghana, China, France, Cote
d''Ivoire (1999)
Debt -external: $1.5 billion (1999)
Economic aid - recipient: $201 .1 million (1 995)
Currency: Communaute Financiere Africaine franc
(XOF); note - responsible authority is the Central
Bank of the West African States
Currency code: XOF
Exchange rates: Communaute Financiere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 511.55 (1996); note - from 1 January 1999,
the XOF is pegged to the euro at a rate of 655.957
XOF per euro
Fiscal year: calendar year
Economy - overview: Tokelau''s small size (three
villages), isolation, and lack of resources greatly
restrain economic development and confine
agriculture to the subsistence level. The people must
rely on aid from New Zealand to maintain public
services, annual aid being substantially greater than
GDP. The principal sources of revenue come from
sales of copra, postage stamps, souvenir coins, and
handicrafts. Money is also remitted to families from
relatives in New Zealand.
GDP: purchasing power parity - $1 .5 million
(1993 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $1 ,000
(1993 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $430,830
expenditures: $2.8 million, including capital
expenditures of $37,300 (1987 est.)
Industries: small-scale enterprises for copra
production, woodworking, plaited craft goods; stamps,
coins; fishing
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Agriculture - products: coconuts, copra, breadfruit,
papayas, bananas; pigs, poultry, goats
Exports: $98,000 (f.o.b., 1983)
Exports - commodities: stamps, copra, handicrafts
Exports - partners: NZ
Imports: $323,400 (c.i.f., 1983)
Imports - commodities: foodstuffs, building
materials, fuel
Imports “ partners: NZ
Debt -external: $0
Economic aid ■ recipient: $3.8 million (1995)
Currency: New Zealand dollar (NZD)
Currency code: NZD
Exchange rates: New Zealand dollars per US
dollar - 2.2502 (January 2001), 2.1863 (2000), 1.8886
(1999), 1.8632 (1998), 1.5083 (1997), 1.4543 (1996)
Fiscal year: 1 April - 31 March','3f5517f342f01a2a570ecdad758f5a86e78b1bb92806a7bec7be8f9429e56696','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ceca425059055596b35d6331cd14018954d7ec2d673500ac76be589e71207b47',2001,'KH','Cambodia','economy',237,'Economy - overview: Cambodia''s economy slowed
dramatically in 1997-98 due to the regional economic
crisis, civil violence, and political infighting. Foreign
investment and tourism fell off. In 1999, the first full
year of peace in 30 years, progress was made on
economic reforms and growth resumed at 4%. GDP
growth for 2000 had been projected to reach 5.5%, but
the worst flooding in 70 years severely damaged
agricultural crops, and high oil prices hurt industrial
production, and growth for the year is estimated at
only 4%. Tourism is Cambodia''s fastest growing
industry, with arrivals up 34% in 2000. The long-term
development of the economy after decades of war
remains a daunting challenge. The population lacks
education and productive skills, particularly in the
poverty-ridden countryside, which suffers from an
almost total lack of basic infrastructure. Fear of
renewed political instability and corruption within the
government discourage foreign investment and delay
foreign aid. On the brighter side, the government is
addressing these issues with assistance from bilateral
and multilateral donors.
GDP: purchasing power parity -$16.1 billion
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,300
(2000 est.)
GDP - composition by sector:
agriculture: 43%
industry: 20%
services: 37% (1998 est.)
Population below poverty line: 36% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.9%
highest 10%o: 33.8% {mi)
Inflation rate (consumer prices): 1 .6% (2000 est.)
Labor force: 6 million (1998 est.)
Labor force - by occupation: agriculture 80%
(1999 est.)
Unemployment rate: 2.8% (1999 est.)
Budget;
revenues; $363 million
expenditures: $532 million, including capital
expenditures of $225 million (2000 est.)
Industries: garments, tourism, rice milling, fishing,
wood and wood products, rubber, cement, gem
mining, textiles
Industrial production growth rate: NA%
Electricity - production: 147 million kWh (1999)
Electricity - production by source;
fossil fuel: 59.18%
hydro: 40.82%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 136.7 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity “ Imports: 0 kWh (1999)
Agriculture - products: rice, rubber, corn,
vegetables
Exports: $942 million (f.o.b., 2000 est.)
Exports ■ commodities: timber, garments, rubber,
rice, fish
Exports ■ partners: Vietnam 18%, Thailand 15%,
US 10%, Singapore 8%, China 5% (1997)
Imports: $1.3 billion (f.o.b., 2000 est.)
Imports - commodities: cigarettes, gold,
construction materials, petroleum products,
machinery, motor vehicles
Imports - partners: Thailand 16%, Vietnam 9%,
Japan 7%, Hong Kong 5%, China 5% (1997)
Debt - external: $829 million (1999 est.)
Economic aid ■ recipient: $548 million pledged in
grants and concessional loans for 2001 by
international donors
Currency: he! (KHR)
Currency code: KHR
Exchange rates; riels per US dollar - 3,909.0
(January 2001), 3,840.8 (2000), 3,807.8 (1999),
3,744.4 (1998), 2,946.3 (1997), 2,624.1 (1996)
Fiscal year: calendar year','20db792a27d8ef9eb340d8ef06d6ce7b39b674dc7dd388b65405b0ea06281eea','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a64d6176fc6a49dfee53d1d392f15ab670316f167a05aeb8ed430d8f5ef90c66',2001,'CM','Cameroon','economy',245,'Economy - overview: Because of its oil resources
and favorable agricultural conditions, Cameroon has
one of the best-endowed primary commodity
economies in sub-Saharan Africa. Still, it faces many
of the serious problems facing other underdeveloped
countries, such as a top-heavy civil service and a
generally unfavorable climate for business enterprise.
Since 1 990, the government has embarked on various
IMF and World Bank programs designed to spur
business investment, increase efficiency in
agriculture, improve trade, and recapitalize the
nation''s banks. In June 2000, the government
completed an IMF-sponsored, three-year structural
adjustment program; however, the IMF is pressing for
more reforms, including increased budget
transparency and privatization. Higher oil prices in
2000 helped to offset the country''s lower cocoa export
revenues. A rebound in the cocoa market should
increase growth to over 5% in 2001 .
GDP: purchasing power parity - $26 billion
(2000 est.)
GDP - real growth rate: 4.4% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,700
(2000 est.)
GDP - composition by sector:
agriculture: 43.4%
industry: 20A%
services: 36.5% (1999 est.)
Population below poverty iine: 48% (2000 est.)
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 2% (2000 est.)
Labor force: NA
Labor force - by occupation: agriculture 70%,
industry and commerce 13%, other 17%
Unemployment rate: 30% (1998 est.)
Budget:
revenues; $2.1 billion
expenditures: $2A billion, including capital
expenditures of $NA (FYOO/01 est.)
Industries: petroleum production and refining, food
processing, light consumer goods, textiles, lumber
Industrial production growth rate: 4.2%
(1999 est.)
Electricity ■ production: 3.47 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 2.59%
/?yc/ro; 97.41%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 3.227 billion kWh (1 999)
Electricity ■ exports: 0 kWh (1999)
Electricity ■ imports: 0 kWh (1 999)
Agriculture - products: coffee, cocoa, cotton,
rubber, bananas, oilseed, grains, root starches;
livestock; timber
Exports: $2.1 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil and petroleum
products, lumber, cocoa beans, aluminum, coffee,
cotton
Exports - partners: Italy 24%, France 18%,
Netherlands 10% (2000 est.)
Imports: $1 .6 billion (f.o.b., 2000 est.)
Imports - commodities: machines and electrical
equipment, transport equipment, fuel, food
Imports - partners: France 29%, Germany 7%, US
6%, Japan 6% (2000 est.)
Debt - external: $10.9 billion (2000 est.)
Economic aid - recipient: on 23 January 2001 , the
Paris Club agreed to reduce Cameroon''s debt of $1 .3
billion by $900 million; total debt relief now amounts to
$1.26 billion
Currency: Communaute Financiere Africaine franc
(XAF); note - responsible authority is the Bank of the
Central African States
Currency code: XAF
Exchange rates: Communaute Financiere Africaine
francs (XAF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 51 1 .55 (1996); note - from 1 January 1999,
the XAF is pegged to the euro at a rate of 655.957
XAF per euro
Fiscal year: 1 July - 30 June','bd6a7f95c6a572d00f68091ab8cc74d92f8d1930302ef5cc98c2f43412dea5de','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2dc3ecb4d0c3b2ca631bc43bb306dba650ed605e4dc8b4a4bac56c75ae42e5d',2001,'CA','Canada','economy',254,'Economy - overview: As an affluent, high-tech
industrial society, Canada today closely resembles
the US in its market-oriented economic system,
pattern of production, and high living standards. Since
World War II, the impressive growth of the
manufacturing, mining, and service sectors has
transformed the nation from a largely rural economy
into one primarily industrial and urban. Real rates of
growth have averaged nearly 3.0% since 1993.
Unemployment is falling and government budget
surpluses are being partially devoted to reducing the
large public sector debt. The 1989 US-Canada Free
Trade Agreement (FTA) and 1994 North American
Free Trade Agreement (NAFTA) (which included
Mexico) have touched off a dramatic increase in trade
and economic integration with the US. With its great
natural resources, skilled labor force, and modern
capita! plant Canada enjoys solid economic
prospects. Two shadows loom, the first being the
continuing constitutional impasse between English-
and French-speaking areas, which has been raising
the possibility of a split in the federation. Another
91
Canada (continued)
long-term concern is the flow south to the US of
professional persons lured by higher pay, lower taxes,
and the immense high-tech infrastructure.
GDP: purchasing power parity - $7747 billion
(2000 est.)
GDP - real growth rate: 4.3% (2000 est.)
GDP - per capita: purchasing power parity -
$24,800 (2000 est.)
GDP ■ composition by sector:
agriculture: 3%
industry: 3^%
sen/ices: 66% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.8%
highest 10%: 28.8% (^994)
Inflation rate (consumer prices): 2.6% (2000)
Labor force: 16.1 million (2000)
Labor force - by occupation: services 74%,
manufacturing 15%, construction 5%, agriculture 3%,
other 3% (2000)
Unemployment rate: 6.8% (2000 est.)
Budget:
revenues.* $126.1 billion
expenditures: $125.3 billion, including capital
expenditures of $14.8 billion (2000)
Industries: processed and unprocessed minerals,
food products, wood and paper products,
transportation equipment, chemicals, fish products,
petroleum and natural gas
Industrial production growth rate: 4.5%
(2000 est.)
Electricity - production: 567. 193 billion kWh (1999)
Electricity - production by source:
fossil fuel: 26.38%
hydro: 60%
nuc/ear.* 12.31%
ofher; 1.31% (1999)
Electricity - consumption: 497.532 billion kWh
(1999)
Electricity - exports: 42.91 1 billion kWh (1999)
Electricity - imports: 12.953 billion kWh (1999)
Agriculture - products: wheat, barley, oilseed,
tobacco, fruits, vegetables; dairy products; forest
products; fish
Exports; $272.3 billion (f.o.b., 2000 est.)
Exports - commodities: motor vehicles and parts,
newsprint, wood pulp, timber, crude petroleum,
machinery, natural gas, aluminum,
telecommunications equipment, electricity
Exports - partners: US 86%, Japan 3%, UK,
Germany, South Korea, Netherlands, China (1999)
Imports: $238.2 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
crude oil, chemicals, motor vehicles and parts,
durable consumer goods, electricity
Imports - partners: US 76%, Japan 3%, UK,
Germany, France, Mexico, Taiwan, South Korea
(1999)
Debt - external: $1 .9 billion (2000)
Economic aid - donor: ODA, $1 .3 billion (1 999)
Currency: Canadian dollar (CAD)
Currency code: CAD
Exchange rates: Canadian dollars per US dollar -
1 .5032 (January 2001 ), 1 .4851 (2000), 1 .4857 (1 999),
1.4835 (1998), 1.3846 (1997), 1.3635 (1996)
Fiscal year: 1 April - 31 March','b7fc33e7772bae004354145a3395c24b5554d7200487d54f3c28ea9e7576b137','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdb4707e4b9c71d627a006d2a6769e2653fda8fa5b1763b1ad28ef66f765c4e6',2001,'PT','Portugal','economy',260,'Economy - overview: Cape Verde''s low per capita
GDP reflects a poor natural resource base, including
serious water shortages exacerbated by cycles of
long-term drought. The economy is service-oriented,
with commerce, transport, and public services
accounting for almost 70% of GDP. Although nearly
70% of the population lives in rural areas, the share of
agriculture in GDP in 1998 was only 13%, of which
fishing accounts for 1 .5%. About 90% of food must be
imported. The fishing potential, mostly lobster and
tuna, is not fully exploited. Cape Verde annually runs a
high trade deficit, financed by foreign aid and
remittances from emigrants; remittances constitute a
supplement to GDP of more than 20%. Economic
reforms, launched by the new democratic government
in 1 991 , are aimed at developing the private sector and
attracting foreign investment to diversify the economy.
Prospects for 2001 depend heavily on the maintenance
of aid flows, remittances, and the momentum of the
government''s development program.
GDP; purchasing power parity - $670 million
(2000 est.)
GDP - real growth rate: 6% (2000 est.)
GDP ■ per capita: purchasing power parity - $1 ,700
(2000 est.)
GDP - composition by sector:
agriculture: 13%
industry: 19%
services: 63% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4% (2000)
Labor force: NA
Unemployment rate: 24% (1999 est.)
Budget;
revenues; $188 million
expenditures: $228 million, including capital
expenditures of $116 million (1996)
Industries: food and beverages, fish processing,
shoes and garments, salt mining, ship repair
Industrial production growth rate: NA%
Electricity - production: 40 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 37.2 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products; bananas, corn, beans,
sweet potatoes, sugarcane, coffee, peanuts; fish
Exports: $40 million (f.o.b., 2000 est.)
Exports - commodities: fuel, shoes, garments, fish,
bananas, hides
Exports ■ partners: Portugal, UK, Germany, Spain,
France, Malaysia
Imports: $250 million (f.o.b., 2000 est.)
Imports ■ commodities: foodstuffs, industrial
products, transport equipment, fuels
Imports - partners: Portugal, Netherlands, France,
UK, Spain, US
Debt - external; $260 million (2000)
Economic aid - recipient: $111.3 million (1 995)
Currency: Cape Verdean escudo (CVE)
Currency code: CVE
Exchange rates; Cape Verdean escudos per US
dollar - 123.080 (December 2000), 115.877 (2000),
1 02.700 (1999), 98. 1 58 (1 998), 93. 1 77 (1 997), 82.591
(1996)
Fiscal year: calendar year
Economy - overview: Portugal is an upcoming
capitalist economy with a per capita GDP two-thirds that
of the four big West European economies. The country
qualified for the European Monetary Union (EMU) in
1998 and joined with 10 other European countries in
launching the euro on 1 January 1999. The year 2000
was marked by moderation in growth, inflation, and
unemployment. The country continues to run a sizable
trade deficit. The government is working to reform the
tax system, to modernize capital plant, and to increase
the country''s competitiveness in the increasingly
integrated world markets. Growth is expected to fall off
slightly in 2001 . Improvement in the education sector is
critical to the long-run catch-up process.
GDP: purchasing power parity - $159 billion
(2000 est.)
GDP - real growth rate: 2.7% (2000 est.)
GDP - per capita: purchasing power parity -
$15,800 (2000 est.)
GDP - composition by sector:
agriculture: 4%
industry: 36%
services: 60% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%:3A%
highest m.* 28.4% (1995 est.)
Inflation rate (consumer prices): 2.8% (2000 est.)
Labor force: 5 million (1 999)
Labor force - by occupation: services 60%,
industry 30%, agriculture 10% (1999 est.)
Unemployment rate: 4.3% (2000 est.)
Budget:
revenues: $48.6 billion
expenditures: $50.7 billion, including capital
expenditures of $7.7 billion (2000 est.)
Industries: textiles and footwear; wood pulp, paper,
and cork; metalworking; oil refining; chemicals; fish
canning; wine; tourism
Industrial production growth rate: 2.9%
(1999 est.)
Electricity - production: 41 .696 billion kWh (1999)
Electricity - production by source:
fossil fuel: 79.97%
hydro: 17.25%
nuclear: 0%
other; 2.78% (1999)
Electricity - consumption: 37.915 billion kWh
(1999)
Electricity - exports: 4.49 billion kWh (1999)
Electricity - imports: 3.628 billion kWh (1999)
Agriculture - products: grain, potatoes, olives,
grapes; sheep, cattle, goats, poultry, beef, dairy
products
Exports: $26.1 billion (f.o.b., 2000 est.)
Exports - commodities: clothing and footwear,
machinery, chemicals, cork and paper products, hides
Exports - partners: EU 83% (Germany 20%, Spain
18%, France 14%, UK 12%, Netherlands 5%, Benelux
5%, Italy), US 5% (1999)
Imports: $41 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment, chemicals, petroleum, textiles, agricultural
products
Imports - partners: EU 78% (Spain 25%, Germany
1 5%, France 1 1 %, Italy 8%, UK 7%, Netherlands 5%),
US 3%, Japan 3% (1998)
Debt - external: $13.1 billion (1997 est.)
Economic aid - donor: ODA, $271 million (1995)
Currency: Portuguese escudo (PTE); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Portugal at a fixed rate of
200.482 Portuguese escudos per euro and will
replace the local currency for all transactions in 2002
Currency code: PTE; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999);
Portuguese escudos per US dollar - 180.10 (1998),
175.31 (1997), 154.24(1996)
Fiscal year: calendar year','926fcc84d94768fa68e969e42c420034bd8f54f909010bb6b537d83fea7b2a1e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82798b34024a9428b0b4117d60ecd1638152871a76f7a464eed18dae7f347718',2001,'HN','Honduras','economy',271,'Economy - overview: With no direct taxation, the
islands are a thriving offshore financial center. More
than 40,000 companies were registered in the
Cayman Islands as of 1997, including almost 600
banks and trust companies; banking assets exceed
$500 billion. A stock exchange was opened in 1997.
Tourism is also a mainstay, accounting for about 70%
of GDP and 75% of foreign currency earnings. The
tourist industry is aimed at the luxury market and
caters mainly to visitors from North America. Total
95
Cayman Islands (continued)
tourist arrivals exceeded 1.2 million visitors in 1997.
About 90% of the islands'' food and consumer goods
must be imported. The Caymanians enjoy one of the
highest outputs per capita and one of the highest
standards of living in the world.
GDP: purchasing power parity - $930 million
(1997 est.)
GDP - real growth rate: 4.9% (1 999 est.)
GDP - per capita: purchasing power parity -
$24,500 (1997 est.)
GDP - composition by sector:
agriculture: 1 .4%
industry: 3.2%
services: 95.4% (1994 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3% (1998)
Labor force: 19,820(1995)
Labor force ■ by occupation: agriculture 1 .4%,
industry 12.6%, services 86% (1995)
Unemployment rate: 4.1% (1997)
Budget:
revenues: $265.2 million
expenditures: 9 million, including capital
expenditures of $NA (1997)
Industries: tourism, banking, insurance and finance,
construction, construction materials, furniture
Industrial production growth rate: NA%
Electricity - production: 330 million kWh (1999)
Electricity - production by source:
fossil fuel: ^00%
hydro: 0%
nuclear: 0%
other 0% (1999)
Electricity - consumption: 306.9 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: vegetables, fruit; livestock,
turtle farming
Exports: $1.5 million (1998)
Exports - commodities: turtle products,
manufactured consumer goods
Exports - partners: mostly US
Imports: $507.6 million (1998)
Imports - commodities: foodstuffs, manufactured
goods
Imports - partners: US, Trinidad and Tobago, UK,
Netherlands Antilles, Japan
Debt “ external: $70 million (1 996)
Economic aid - recipient: $NA
Currency: Caymanian dollar (KYD)
Currency code: KYD
Exchange rates: Caymanian dollars per US dollar -
0.83 (3 November 1995), 0.85 (22 November 1 993)
Fiscal year: 1 April - 31 March
Economy - overview: Subsistence agriculture,
together with forestry, remains the backbone of the
economy of the Central African Republic (CAR), with
more than 70% of the population living in outlying
areas. The agricultural sector generates half of GDP.
Timber has accounted for about 16% of export
earnings and the diamond industry for nearly 54%.
Important constraints to economic development
include the CAR''s landlocked position, a poor
transportation system, a largely unskilled workforce,
and a legacy of misdirected macroeconomic policies.
The 50% devaluation of the currencies of 14
Francophone African nations on 1 2 January 1 994 had
mixed effects on the CAR''s economy. Diamond,
97
Central African Republic (continued)
timber, coffee, and cotton exports increased, leading
an estimated rise of GDP of 7% in 1 994 and nearly 5%
In 1995. Military rebellions and social unrest in 1996
were accompanied by widespread destruction of
property and a drop in GDP of 2%. The IMF approved
an Extended Structure Adjustment Facility in 1998
and the World Bank extended further credits in 1999
and approved a $10 million loan in early 2001. The
government has set targets of 3.5% GDP growth in
2001 and 2002. As of January 2001 , many civil
servants were owed as much as 30 months pay,
leading them to go on strike and further damaging the
GDP: purchasing power parity - $6.1 billion
(2000 est.)
GDP " real growth rate: 3.5% (2000 est.)
GDP ■ per capita: purchasing power parity - $1 ,700
(2000 est.)
GDP ■ composition by sector:
agriculture: 53%
industry: 20%
semces;27%(1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: 07%
highest 47.7% (1993)
Inflation rate (consumer prices): 3% (2000 est.)
Labor force: NA
Unemployment rate; 6% (1993)
Budget:
revenues: $638 million
expenditures: $1,9 billion, including capital
expenditures of $888 million (1994 est.)
Industries: diamond mining, sawmills, breweries,
textiles, footwear, assembly of bicycles and
motorcycles
Industrial production growth rate: NA%
Electricity ■ production: 102 million kWh (1999)
Electricity - production by source:
fossil fuel: 20.59%
hydro: 79.41%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 94.9 million kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cotton, coffee, tobacco,
manioc (tapioca), yams, millet, corn, bananas; timber
Exports: $166 million (f.o.b., 2000)
Exports - commodities: diamonds, timber, cotton,
coffee, tobacco
Exports - partners: Benelux 64%, Cote d''Ivoire,
Spain, China, Egypt, France (1999)
Imports: $154 million (f.o.b., 2000)
Imports - commodities: food, textiles, petroleum
products, machinery, electrical equipment, motor
vehicles, chemicals, pharmaceuticals, consumer
goods, industrial products
Imports - partners: France 35%, Cameroon 13%,
Benelux, Cote d''Ivoire, Germany, Japan (1999)
Debt - external: $790 million (1999 est.)
Economic aid - recipient: $172.2 million (1995);
note - traditional budget subsidies from France
Currency: Communaute Financiere Africaine franc
(XAF); note - responsible authority is the Bank of the
Central African States
Currency code: XAF
Exchange rates: Communaute Financiere Africaine
francs (XAF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 511.55 (1996); note - from 1 January 1999,
the XAF is pegged to the euro at a rate of 655.957
XAF per euro
Fiscal year: calendar year
Economy - overview: Honduras, one of the poorest
countries in the Western Hemisphere, is banking on
expanded trade privileges under the Enhanced
Caribbean Basin Initiative and on debt relief under the
Heavily Indebted Poor Countries (HIPC) initiative.
While reconstruction from 1 998’s Hurricane Mitch is at
an advanced stage, and the country has met most of
its macroeconomic targets, it failed to meet the IMF''s
goals to liberalize its energy and telecommunications
sectors. Economic growth has rebounded nicely since
the hurricane and should continue in 2001 .
GDP: purchasing power parity - $17 billion
(2000 est.)
GDP - real growth rate; 5% (2000 est.)
GDP - per capita: purchasing power parity - $2,700
(2000 est.)
GDP - composition by sector:
agriculture: )6.2%
industry: 31 .9%
services: 51 .9% (1999 est.)
Population below poverty line: 53% (1993 est.)
Household income or consumption by percentage
share:
lowest 10%:} 2%
highest f0%; 42.1% (1996)
Inflation rate (consumer prices); 11% (2000 est.)
Labor force: 2.3 million (1 997 est.)
Labor force - by occupation: agriculture 29%,
industry 21%, services 50% (1998 est.)
Unemployment rate: 28% (2000 est.)
Budget:
revenues: $607 million
expenditures: $41 1 .9 million, including capital
expenditures of $106 million (1999 est.)
Industries: sugar, coffee, textiles, clothing, wood
products
Industrial production growth rate: 4% (1999 est.)
Electricity - production: 3.319 billion kWh (1999)
Electricity ■ production by source:
foss/7 fue/; 44.71%
hydro: 55.29%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 3.232 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 145 million kWh (1999)
Agriculture ■ products: bananas, coffee, citrus;
beef; timber; shrimp
Exports: $2 billion (f.o.b., 2000 est.)
Exports - commodities: coffee, bananas, shrimp,
lobster, meat; zinc, lumber
Exports - partners: US 35.4%, Germany 7.5%, Ei
Salvador 6.4%, Guatemala 5.8%, Nicaragua 4.8%
(1999)
Imports: $2.8 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment, industrial raw materials, chemical
products, fuels, foodstuffs
imports ■ partners: US 47.1%, Guatemala 7.4%, El
Salvador 5.9%, Mexico 4.8%, Japan 4.7% (1999)
Debt - external; $5.4 billion (2000)
Economic aid - recipient: $557.8 million (1999)
Currency: lempira (HNL)
Currency code: HNL
Exchange rates: lempiras per US dollar - 15.1407
(December 2000), 15.1407 (2000), 14.5039 (1999),
13.8076 (1998), 13.0942 (1997), 12.8694 (1996)
Fiscal year: calendar year','9d3c6ee47bc466ecefe9c373486b4d08434b76dbe04c223d02bdf420fc8c1cd4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24805942bf935185b6ff7adc58b3d0c5bf86d33e589544f9f79ae7127e2eb366',2001,'TD','Chad','economy',281,'Economy - overview: Landlocked Chad''s economic
development suffers from its geographic remoteness,
drought, lack of infrastructure, and political turmoil.
About 85% of the population depends on agriculture,
including the herding of livestock. Of Africa''s
Francophone countries, Chad benefited least from the
50% devaluation of their currencies in January 1994.
Financial aid from the World Bank, the African
Development Fund, and other sources is directed
largely at the improvement of agriculture, especially
livestock production. The World Bank''s decision to
back the Doba oil field development and the
Chad-Cameroon pipeline will add Chad to the group of
already booming West African oil exporters. However,
the rank and file may not benefit much from the oil
development projects.
GDP: purchasing power parity- $8.1 billion
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,000
(2000 est.)
GDP - composition by sector:
agriculture: 40%
industry: 14%
serv/ces; 46% (1998)
Population below poverty line: 64% (1995 est.)
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: NA%
Inflation rate (consumer prices): 3% (2000 est.)
Labor force: NA
Labor force - by occupation: agriculture 85%
(subsistence farming, herding, and fishing)
Unemployment rate: NA%
Budget:
revenues.* $198 million
expenditures: %2^0 million, including capital
expenditures of $146 million (1998 est.)
Industries: cotton textiles, meatpacking, beer
brewing, natron (sodium carbonate), soap, cigarettes,
construction materials
Industrial production growth rate: 5% (1995)
Electricity - production: 90 million kWh (1999)
Electricity - production by source:
foss/Zfue/.’ 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 83.7 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity ■ imports: 0 kWh (1999)
Agriculture - products: cotton, sorghum, millet,
peanuts, rice, potatoes, manioc (tapioca); cattle,
sheep, goats, camels
Exports: $172 million (f.o.b., 2000 est.)
Exports - commodities: cotton, cattle, textiles
Exports - partners: Portugal 38%, Germany 12%,
Thailand, Costa Rica, South Africa, France (1999)
Imports: $223 million (f.o.b., 2000 est.)
Imports - commodities: machinery and
transportation equipment, industrial goods, petroleum
products, foodstuffs, textiles
Imports - partners: France 40%, Cameroon 13%,
Nigeria 12%, India 5% (1999)
Debt -external: $1 billion (1999 est.)
Economic aid - recipient: $238.3 million (1995);
note - $125 million committed by Taiwan (August
1997); $30 million committed by African Development
Bank
Currency: Communaute Financiere Africaine franc
(XAF); note - responsible authority is the Bank of the
Central African States
Currency code: XAF
Exchange rates: Communaute Financiere Africaine
francs (XAF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 51 1 .55 (1996); note - from 1 January 1999,
the XAF is pegged to the euro at a rate of 655.957
XAF per euro
Fiscal year; calendar year
Economy - overview: Chile has a market-oriented
economy characterized by a high level of foreign
trade. During the early 1990s, Chile''s reputation as a
role model for economic reform was strengthened
when the democratic government of Patricio
AYLWIN - which took over from the military in 1990 -
deepened the economic reform initiated by the military
government. Growth in real GDP averaged 8% during
1991-97, but fell to half that level in 1998 because of
tight monetary policies implemented to keep the
current account deficit in check and lower export
earnings - the latter a product of the global financial
crisis. A severe drought exacerbated the recession in
1999, reducing crop yields and causing hydroelectric
shortfalls and electricity rationing, and Chile
experienced negative economic growth for the first
time in more than 15 years. Despite the effects of the
recession, Chile maintained its reputation for strong
financial institutions and sound policy that have given
it the strongest sovereign bond rating in South
America. By the end of 1999, exports and economic
activity had begun to recover, and growth rebounded
to 5.5% in 2000. Unemployment remains stubbornly
high, however, putting pressure on President LAGOS
to improve living standards. Meanwhile, Chile has
launched free trade negotiations with the US.
GDP: purchasing power parity -$153.1 billion
(2000 est.)
GDP - real growth rate: 5.5% (2000 est.)
GDP - per capita: purchasing power parity -
$10,100 (2000 est.)
GDP - composition by sector:
agriculture: 8%
102
Chile (continued)
industry: 38%
services: 54% (2000)
Population below poverty line: 22% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: 1 .2%
highest f0%;41.3%(1998)
Inflation rate (consumer prices): 4.5% (2000 est.)
Labor force: 5.8 million (1 999 est.)
Labor force - by occupation: agriculture 14%,
industry 27%, services 59% (1997 est.)
Unemployment rate: 9% (December 2000)
Budget:
revenues.'' $16 billion
expenditures: $17 billion, including capital
expenditures of $NA (2000 est.)
Industries: copper, other minerals, foodstuffs, fish
processing, iron and steel, wood and wood products,
transport equipment, cement, textiles
Industrial production growth rate: 6% (2000 est.)
Electricity - production: 38.092 billion kWh (1999)
Electricity - production by source:
fossil fuel: 61%
hydro: 35%
nuclear: 0%
other: 4% (1999)
Electricity - consumption: 35.426 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity ■ imports: 0 kWh (1999)
Agriculture - products: wheat, corn, grapes, beans,
sugar beets, potatoes, fruit; beef, poultry, wool; fish;
timber
Exports: $18 billion (f.o.b., 2000)
Exports - commodities; copper, fish, fruits, paper
and pulp, chemicals
Exports - partners: EU 27%, US 16%, Japan 14%,
Brazil 6%, Argentina 5% (1998)
Imports: $17 billion (f.o.b., 2000)
Imports - commodities: consumer goods,
chemicals, motor vehicles, fuels, electrical machinery,
heavy industrial machinery, food
Imports - partners: US 24%, EU 23%, Argentina
11%, Brazil 6%, Japan 6%, Mexico 5% (1998)
Debt ■ external: $39 billion (2000)
Economic aid - recipient: ODA, $40 million
(2001 est.)
Currency: Chilean peso (CLP)
Currency code: CLP
Exchange rates; Chilean pesos per US dollar -
571.12 (January2001), 535.47 (2000), 508.78 (1999),
460.29 (1998), 419.30 (1997), 412.27 (1996)
Fiscal year: calendar year','4d2e05ffae675104f5ad47e9841ca19881491a131b93b74a6d7724ecffbed9fa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed653945bcbba01e0b7a488a8ac9160161da9afc4aed0e5b8d871209d44b1756',2001,'CN','China','economy',291,'Economy - overview: In late 1978 the Chinese
leadership began moving the economy from a
sluggish Soviet-style centrally planned economy to a
more market-oriented system. Whereas the system
operates within a political framework of strict
Communist control, the economic influence of
non-state managers and enterprises has been
steadily increasing. The authorities have switched to a
system of household responsibility in agriculture in
place of the old collectivization, increased the
authority of local officials and plant managers in
industry, permitted a wide variety of small-scale
enterprise in services and light manufacturing, and
opened the economy to increased foreign trade and
investment. The result has been a quadrupling of GDP
since 1978. In 2000, with its 1 .26 billion people but a
GDP of just $3,600 per capita, China stood as the
second largest economy in the world after the US
(measured on a purchasing power parity basis).
Agricultural output doubled in the 1980s, and industry
also posted major gains, especially in coastal areas
near Hong Kong and opposite Taiwan, where foreign
investment helped spur output of both domestic and
export goods. On the darker side, the leadership has
often experienced in its hybrid system the worst
results of socialism (bureaucracy and lassitude) and
of capitalism (windfall gains and stepped-up inflation).
Beijing thus has periodically backtracked, retightening
central controls at intervals. The government has
struggled to (a) collect revenues due from provinces,
businesses, and individuals; (b) reduce corruption and
other economic crimes; and (c) keep afloat the large
state-owned enterprises many of which had been
shielded from competition by subsides and had been
losing the ability to pay full wages and pensions. From
80 to 120 million surplus rural workers are adrift
between the villages and the cities, many subsisting
through part-time low-paying jobs. Popular resistance,
changes in central policy, and loss of authority by rural
cadres have weakened China''s population control
program, which is essential to maintaining growth in
living standards. Another long-term threat to
continued rapid economic growth is the deterioration
in the environment, notably air pollution, soil erosion,
and the steady fall of the water table especially in the
north. China continues to lose arable land because of
erosion and economic development. Weakness in the
global economy in 2001 could hamper growth in
exports. Beijing will intensify efforts to stimulate
growth through spending on infrastructure-such as
water control and power grids-and poverty relief and
through rural tax reform aimed at eliminating arbitrary
local levies on farmers.
GDP: purchasing power parity - $4.5 trillion
(2000 est.)
GDP - real growth rate: 8% (2000 est.)
GDP ■ per capita: purchasing power parity - $3,600
(2000 est.)
GDP - composition by sector:
agriculture: 15%
industry: 50%
services: 35% (2000 est.)
Population below poverty line: 10% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%:2A%
highest m; 30.4% (1998)
Inflation rate (consumer prices): 0.4% (2000 est.)
Labor force: 700 million (1998 est.)
Labor force - by occupation: agriculture 50%,
industry 24%, services 26% (1998)
105
China (continued)
Unemployment rate: urban unemployment roughly
10%; substantial unemployment and
underemployment in rural areas (2000 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: iron and steel, coal, machine building,
armaments, textiles and apparel, petroleum, cement,
chemical fertilizers, footwear, toys, food processing,
automobiles, consumer electronics,
telecommunications
Industrial production growth rate: 10%
(2000 est.)
Electricity - production: 1.173 trillion kWh (1999)
Electricity - production by source:
fossil fuel: 79.Q2%
hydro.- 18.98%
nuclear: ^ 2%
other; 0.01% (1999)
Eiectricity - consumption: 1 .084 trillion kWh (1 999)
Electricity - exports: 7.2 billion kWh (1999)
Electricity - imports: 90 million kWh (1999)
Agriculture ■ products: rice, wheat, potatoes,
sorghum, peanuts, tea, millet, barley, cotton, oilseed;
pork; fish
Exports: $232 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment;
textiles and clothing, footwear, toys and sporting
goods; mineral fuels
Exports - partners: US 21%, Hong Kong 18%,
Japan 17%, South Korea, Germany, Netherlands, UK,
Singapore, Taiwan (2000)
Imports: $197 billion (f.o.b., 2000)
Imports " commodities: machinery and equipment,
mineral fuels, plastics, iron and steel, chemicals
Imports - partners: Japan 18%, Taiwan 11%, US
10%, South Korea 10%, Germany, Hong Kong,
Russia, Malaysia (2000)
Debt - external: $162 billion (2000 est.)
Economic aid - recipient: $NA
Currency: yuan(CNY)
Currency code: CNY
Exchange rates: yuan per US dollar - 8.2776
(January 2001 ), 8.2785 (2000), 8.2783 (1 999), 8.2790
(1998), 8.2898 (1997), 8.3142 (1996)
note: beginning 1 January 1994, the People''s Bank of
China quotes the midpoint rate against the US dollar
based on the previous day''s prevailing rate in the
Interbank foreign exchange market
Fiscal year: calendar year','fad94bec21d9293f50a498f4de8a4b7fea6ac1d3aa44eb0ef71c8c4b1b3a649c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09043ad7a2835b2c00bb28c71a51af05751bacf4c35a5e529a5e701fb1a36d9e',2001,'CX','Christmas Island','economy',299,'Economy - overview: Phosphate mining had been
the only significant economic activity, but in December
1987 the Australian Government closed the mine. In
1991, the mine was reopened by union workers. With
the support of the government, Australian-based
Casinos Austria International Ltd. built a $34 million
casino on Christmas Island, which opened in 1 993. As
of yearend 1999, gaming facilities at the casino were
temporarily closed but were expected to reopen in
early 2000. Another economic prospect is the possible
location of a space-launching site on the island.
GDP: purchasing power parity - $NA
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force; NA
Labor force - by occupation: tourism 400 people,
mining 100 people (1995)
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: tourism, phosphate extraction (near
depletion)
Industrial production growth rate; NA%
Electricity -production: NAkWh
107
Christmas Island (continued)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Agricuiture - products: NA
Exports: $NA
Exports - commodities: phosphate
Exports - partners: Australia, NZ
Imports: $NA
Imports ■ commodities: consumer goods
Imports - partners: principally Australia
Debt -external: $NA
Economic aid - recipient: $NA
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates; Australian dollars per US dollar -
1 .7995 (January 2001 ). 1 .71 73 (2000), 1 .5497 (1 999),
1.5888 (1998), 1.3439 (1997), 1.2773 (1996)
Fiscal year: 1 July - 30 June','d5ad23baaa3daaa6c0a5656f8ea7cce822e80b5b7982741e25ded5769d6962fa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08903ce7c582b22b74f06b54821a517d92c526314e10ebf8b69c121822bad02b',2001,'CO','Colombia','economy',306,'Economy - overview: Colombia is poised for muted
growth in the next several years, marking continued
recovery from the severe 1999 recession when GDP
fell by about 4%. President PASTRANA''S
well-respected economic team is working to keep the
economy on track, maintaining low interest rates, for
example. In accordance with its IMF loan agreement,
the administration also is taking steps to improve the
public sector''s fiscal health. However, many
challenges to improved prosperity remain.
Unemployment was stuck at a record 20% in 2000,
contributing to the extreme inequality in income
distribution. Two of Colombia''s leading exports, oil
and coffee, face an uncertain future; new exploration
is needed to offset declining oil production, while
coffee harvests and prices are depressed. The lack of
public security is a key concern for investors, making
progress In the government''s peace negotiations with
insurgent groups an Important driver of economic
performance. Colombia is looking for continued
support from the international community to boost
economic and peace prospects.
GDP: purchasing power parity - $250 billion
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP ■ per capita: purchasing power parity - $6,200
(2000 est.)
Ill
Colombia (continued)
GDP - composition by sector:
agriculture: 19%
industry: 26%
sen/ices: 55% (1999 est.)
Population below poverty line: 55% (1999)
Household income or consumption by percentage
share:
lowest 10%: 1%
highest 10%: 44% (1999)
Inflation rate (consumer prices): 9% (2000)
Labor force: 1 8,3 million (1999 est.)
Labor force - by occupation: services 46%,
agriculture 30%, Industry 24% (1990)
Unemployment rate: 20% (2000 est.)
Budget:
revenues: $22 billion
expenditures: $24 billion, including capital
expenditures of $NA (2000 est.)
Industries: textiles, food processing, oil, clothing
and footwear, beverages, chemicals, cement; gold,
coal, emeralds
Industrial production growth rate: 11%
(2000 est.)
Electricity - production: 43.574 billion kWh (1999)
Electricity - production by source:
fossil fuel: 22.27%
hydro: 76.19%
nuclear: 0%
other; 1.54% (1999)
Electricity - consumption: 40.532 billion kWh
(1999)
Electricity - exports: 27 million kWh (1999)
Electricity - imports: 35 million kWh (1999)
Agriculture - products: coffee, cut flowers,
bananas, rice, tobacco, corn, sugarcane, cocoa
beans, oilseed, vegetables; forest products; shrimp
Exports: $14.5 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum, coffee, coal,
apparel, bananas, cut flowers
Exports - partners: US 50%, EU 14%, Andean
Community of Nations 16%, Japan 2% (2000 est.)
Imports: $12.4 billion (f.o.b., 2000 est.)
Imports ■ commodities: industrial equipment,
transportation equipment, consumer goods,
chemicals, paper products, fuels, electricity
Imports - partners: US 35%, EU 16%, Andean
Community of Nations 15%, Japan 5% (2000 est.)
Debt - external: $34 billion (2000 est.)
Economic aid - recipient: $40.7 million (1995)
Currency: Colombian peso (COP)
Currency code: COP
Exchange rates: Colombian pesos per US dollar -
2,241.43 (January 2001), 2087.90 (2000), 1,756.23
(1999), 1,426.04 (1998), 1,140.96(1997), 1,036.69
(1996)
Fiscal year: calendar year','1a68c5f3ef4dcccfd7e2579a26894c3d603cca6751cc9bc2a2f64698660038a4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('735e72440c81a7ef7b63e4a7ce927199c4742a34f1354a6a75709a749b51f1e7',2001,'MZ','Mozambique','economy',314,'Economy - overview; One of the world''s poorest
countries, Comoros is made up of three islands that
have inadequate transportation links, a young and
rapidly increasing population, and few natural
resources. The low educational level of the labor force
contributes to a subsistence level of economic activity,
high unemployment, and a heavy dependence on
foreign grants and technical assistance. Agriculture,
Including fishing, hunting, and forestry, is the leading
sector of the economy. It contributes 40% to GDP,
employs 80% of the labor force, and provides most of
the exports. The country is not self-sufficient in food
production; rice, the main staple, accounts for the bulk
of imports. The government is struggling to upgrade
education and technical training, to privatize
commercial and industrial enterprises, to improve
health services, to diversify exports, to promote
tourism, and to reduce the high population growth
rate. Continued foreign support is essential if the goal
of 4% annual GDP growth is to be met. Remittances
from 150,000 Comorans abroad help supplement
GDP.
GDP: purchasing power parity - $419 million
(2000 est.)
GDP - real growth rate: 0.5% (2000 est.)
GDP - per capita; purchasing power parity - $720
(2000 est.)
GDP ■ composition by sector:
agriculture: 40%
industry: 4%
sen/ices: 56% (2000 est.)
Population beiow poverty iine: NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Infiation rate (consumer prices): 3.5% (1999)
Labor force: 1 44,500 (1 996 est.)
Labor force - by occupation: agriculture 80%
Unemployment rate: 20% (1996 est.)
Budget:
revenues: $48 million
expenditures: $53 million, including capital
expenditures of $NA (1997)
Industries: tourism, perfume distiliation, textiles,
furniture, jewelry, construction materials, soft drinks
Industrial production growth rate: -2% (1999 est.)
Electricity - production: 17 million kWh (1999)
Electricity - production by source:
fossil fuel: 88.24%
hydro: M. 76%
nuclear: 0%
oto;0%(1999)
Electricity - consumption: 15.8 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: vanilla, cloves, perfume
essences, copra, coconuts, bananas, cassava
(tapioca)
Exports: $7.9 million (f.o.b., 1999 est.)
Exports - commodities: vanilla, ylang-ylang,
cloves, perfume oil, copra
Exports - partners: France 50%, Germany 25%
(1998)
Imports: $55.1 million (f.o.b., 1999 est.)
Imports - commodities: rice and other foodstuffs,
consumer goods; petroleum products, cement,
transport equipment
Imports - partners: France 38%, Pakistan 13%,
South Africa 8%, Kenya 8% (1998)
Debt - external: $197 million (1997 est.)
Economic aid - recipient: $28.1 million (1997)
Currency: Comoran franc (KMF)
Currency code: KMF
Exchange rates: Comoran francs per US dollar -
524.41 (January 2001 ), 533.98 (2000), 461 .77 (1 999),
442.46 (1998), 437.75 (1997), 383.66 (1996)
note: prior to January 1999, the official rate was
pegged to the French franc at 75 Comoran francs per
French franc; since 1 January 1999, the Comoran
franc is pegged to the euro at a rate of 491 .9677
Comoran francs per euro
Fiscal year: calendar year
Economy ■ overview: Up to 12,000 tons of guano
are mined per year.
Economy - overview: Before the peace accord of
October 1992, Mozambique''s economy was
devastated by a protracted civil war and socialist
mismanagement. In 1994, it ranked as one of the
poorest countries in the world. Since then,
Mozambique has undertaken a series of economic
reforms. Almost all aspects of the economy have been
liberalized to some extent. More than 900 state
enterprises have been privatized. A value-added tax,
introduced in 1999, launched the government''s
comprehensive tax reform program. Pending are
much needed commercial code reform and greater
private sector involvement in the transportation,
telecommunications, and energy sectors. Since 1996,
inflation has been low and foreign exchange rates
relatively stable. Albeit from a small base,
Mozambique''s economy grew at an annual 10% rate
in 1997-99, one of the highest growth rates in the
world. Growth slowed and inflation rose in 2000 due to
devastating flooding in the early part of the year. Both
indicators should recover in 2001. The country
depends on foreign assistance to balance the budget
and to pay for a trade imbalance in which imports
greatly outnumber exports. The trade situation should
improve in the medium term, however, as trade and
transportation links to South Africa and the rest of the
region have been improved and sizeable foreign
investments are beginning to materialize. Among
these investments are metal production (aluminum,
steel), natural gas, power generation, agriculture,
fishing, timber, and transportation services.
Mozambique has received a formal cancellation of a
large portion of its external debt through an IMF
initiative and is scheduled to receive additional relief.
GDP: purchasing power parity - $19.1 billion
(2000 est.)
GDP - real growth rate: 3.8% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,000
(2000 est.)
GDP - composition by sector:
agriculture: 44%
industry: 19%
services: 37% (1 999 est.)
Population below poverty line: 70% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.5%
highest 10%; 31 .7% (1996-97)
Inflation rate (consumer prices): 1 1 .4%
(2000 est.)
Labor force: 7.4 million (1997 est.)
Labor force - by occupation: agriculture 81%,
industry 6%, services 13% (1997 est.)
Unemployment rate: 21% (1997 est.)
Budget:
revenues; $466.9 million
expenditures: $1 .004 billion, including capital
expenditures of $502.5 million (2000 est.)
Industries: food, beverages, chemicals (fertilizer,
soap, paints), petroleum products, textiles, cement,
glass, asbestos, tobacco
Industrial production growth rate: 7.2% (1999)
Electricity ■ production: 2.3 billion kWh (1999)
Electricity - production by source:
fossil fuel: 13.0A%
hydro: 85.%%
nuclear: 0%
ote0%(1999)
Electricity ■ consumption: 307 million kWh (1999)
Electricity ■ exports: 1 .9 billion kWh (1 999)
Electricity - imports: 68 million kWh (1999)
Agriculture - products: cotton, cashew nuts,
sugarcane, tea, cassava (tapioca), corn, rice,
coconuts, sisal, tropical fruits; beef, poultry
Exports: $390 million (f.o.b., 2000 est.)
Exports ■ commodities: prawns 40%, cashews,
cotton, sugar, citrus, timber; bulk electricity (2000)
Exports - partners: EU 27%, South Africa 26%,
Zimbabwe 15%, India 12%, US 5%, Japan 4%
(1999 est.)
Imports: $1 .4 billion (c.i.f., 2000 est.)
Imports - commodities: machinery and equipment,
mineral products, chemicals, metals, foodstuffs,
textiles (2000)
Imports - partners: South Africa 44%, EU 16%, US
6.5%, Japan 6.5%, Pakistan 3%, India 3% (1999 est.)
Debt ■ external: $1 .4 billion (2000 est.)
Economic aid - recipient: $1 .04 billion (1 998)
Currency: metical (MZM)
Currency code: MZM
Exchange rates: meticais per US dollar - 1 7,331 .0
(January 2001), 5,199.8 (2000), 12,775.1 (1999),
1 1 ,874.6 (1 998), 1 1 .543.6 (1 997), 1 1 ,293.8 (1 996)
Fiscal year: calendar year
Economy - overview: Taiwan has a dynamic
capitalist economy with gradually decreasing
guidance of investment and foreign trade by
government authorities. In keeping with this trend,
some large government-owned banks and industrial
firms are being privatized. Real growth in GDP has
averaged about 8% during the past three decades.
Exports have grown even faster and have provided
the primary impetus for industrialization. Inflation and
unemployment are low; the trade surplus is
substantial: and foreign reserves are the world''s fourth
largest. Agriculture contributes 3% to GDP, down from
35% in 1 952. T raditional labor-intensive industries are
steadily being moved offshore and replaced with more
capital- and technology-intensive industries. Taiwan
has become a major investor in China, Thailand,
Indonesia, the Philippines, Malaysia, and Vietnam.
The tightening of labor markets has led to an influx of
foreign workers, both legal and illegal. Because of its
conservative financial approach and its
entrepreneurial strengths, Taiwan suffered little
compared with many of its neighbors from the Asian
financial crisis in 1998-99. Growth in 2001 will depend
largely on conditions in Taiwan''s export markets and
may be about 5%.
566
Taiwan (continued)
GDP: purchasing power parity - $386 billion
(2000 est.)
GDP - real growth rate: 6.3% (2000 est.)
GDP - per capita: purchasing power parity -
$17,400 (2000 est.)
GDP - composition by sector:
agriculture: 3%
industry: 33%
services: 64% (1999 est.)
Population below poverty line: 1% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: MA%
Inflation rate (consumer prices): 1.3% (2000 est.)
Labor force: 9.8 million (2000 est.)
Labor force - by occupation: services 55%,
industry 37%, agriculture 8% (1999 est.)
Unemployment rate: 3% (2000 est.)
Budget:
revenues: $42.74 billion
expenditures: $48.8 billion, including capital
expenditures of $NA (2001 est.)
Industries: electronics, petroleum refining,
chemicals, textiles, iron and steel, machinery, cement,
food processing
Industrial production growth rate: 8% (2000 est.)
Electricity - production: 139.676 billion kWh (1999)
Electricity - production by source:
fossil fuel: 67.26%
hydro: 8.32%
nuclear: 26.42%
other: 0%{m9)
Electricity ■ consumption: 129.899 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rice, corn, vegetables, fruit,
tea; pigs, poultry, beef, milk; fish
Exports: $148.38 billion (f.o.b., 2000)
Exports - commodities: machinery and electrical
equipment 51%, metals, textiles, plastics,
chemicals
Exports - partners: US 23.5%, Hong Kong 21 .1%,
Europe 16%, ASEAN 12.2%, Japan 11.2% (2000)
Imports: $140.01 billion (c.i.f., 2000)
Imports “ commodities: machinery and electrical
equipment 51%, minerals, precision instruments
Imports - partners: Japan 27.5%, US 17.9%,
Europe 13.6% (2000)
Debt -external: $40 billion (2000)
Currency: new Taiwan dollar (TWD)
Currency code: TWD
Exchange rates: new Taiwan dollars per US dollar -
33.082 (yearend 2000), 31.395 (yearend 1999),
32.216 (1998), 32.052 (1997), 27.5 (1996)
Fiscal year: 1 July - 30 June (up to FY98/99): 1 July
1999 ‘ 31 December 2000 for FYOO; calendar year
(after FYOO)','eaebda0988928c8361111e279eef2a7b36c65f2172177bde35ef7c79eba93de2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c7b7fdb1ae3013b9733e97fe7a4e64abae6834607b28eec773b7e808030b93c',2001,'CG','Congo','economy',320,'Economy ■ overview: The economy of the
Democratic Republic of the Congo - a nation endowed
with vast potential wealth - has declined drastically
since the mid-1980s. The new government instituted
a tight fiscal policy that initially curbed inflation and
currency depreciation, but these small gains were
quickly reversed when the foreign-backed rebellion in
the eastern part of the country began in August 1998.
The war has dramatically reduced national output and
government revenue and has increased external debt.
Foreign businesses have curtailed operations due to
uncertainty about the outcome of the conflict and
because of increased government harassment and
restrictions. The war has intensified the impact of such
basic problems as an uncertain legal framework,
corruption, raging inflation, and lack of openness in
government economic policy and financial operations.
A number of IMF and World Bank missions have met
with the government to help it develop a coherent
economic plan but associated reforms are on hold.
GDP: purchasing power parity - $31 billion
(2000 est.)
GDP - real growth rate: -15% (2000 est.)
GDP - per capita: purchasing power parity - $600
(2000 est.)
GDP - composition by sector:
agriculture: 58%
industry: 17%
services: 25% (1997 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 540% (2000 est.)
Labor force: 14.51 million (1993 est.)
Labor force - by occupation: agriculture 65%,
industry 16%, services 19% (1991 est.)
Unemployment rate: NA%
Budget:
revenues: $269 million
expenditures: $244 million, including capital
expenditures of $24 million (1996 est.)
Industries: mining (diamonds, copper, zinc), mineral
processing, consumer products (including textiles,
footwear, cigarettes, processed foods and
beverages), cement
Industrial production growth rate: NA%
Electricity - production: 5.268 billion kWh (1999)
Electricity - production by source:
fossil fuel: 2.05%
hydro: 97.95%
nuclear: 0%
other: 0% {1999)
Electricity - consumption: 4.55 billion kWh (1999)
Electricity - exports: 404 million kWh (1999)
Electricity - imports: 55 million kWh (1999)
Agriculture - products: coffee, sugar, palm oil,
rubber, tea, quinine, cassava (tapioca), palm oil,
bananas, root crops, corn, fruits; wood products
Exports: $960 million (f.o.b., 2000 est.)
Exports - commodities: diamonds, copper, coffee,
cobalt, crude oil
Exports « partners: Benelux 62%, US 18%, South
Africa, Finland, Italy (1999)
Imports: $660 million (c.i.f., 2000 est.)
Imports - commodities: foodstuffs, mining and
other machinery, transport equipment, fuels
Imports - partners: South Africa 28%, Benelux
14%, Nigeria 9%, Kenya 7%, China (1999)
Debt - external: $1 3 billion (1 998 est.)
Economic aid - recipient: $195.3 million (1995)
Currency: Congolese franc (CDF)
Currency code: CDF
Exchange rates: Congolese francs per US dollar -
50 (January 2001), 4.5 (January 2000), 4.02 (1999),
1.61 (1998), 1.31 (1997), 0.50(1996)
note: on 30 June 1998 the Congolese franc was
introduced, replacing the new zaire
Fiscal year: calendar year
116
Congo, Democratic Republic of the (continued)
Military expenditures - dollar figure: $250 million
{FY97)
Military expenditures - percent of GDP: 4.6%
(FY97)
Economy - overview: The economy is a mixture of
village agriculture and handicrafts, an industrial sector
based largely on oil, support services, and a
government characterized by budget problems and
overstaffing. Oil has supplanted forestry as the
mainstay of the economy, providing a major share of
government revenues and exports. In the early 1 980s,
rapidly rising oil revenues enabled the governments
finance large-scale development projects with GDP
growth averaging 5% annually, one of the highest
rates in Africa. Moreover, the government has
mortgaged a substantial portion of its oil earnings,
contributing to the government''s shortage of
revenues. The 12 January 1994 devaluation of Franc
Zone currencies by 50% resulted in inflation of 61 % in
1994, but inflation has subsided since. Economic
reform efforts continued with the support of
international organizations, notably the World Bank
and the IMF. The reform program came to a halt in
June 1997 when civil war erupted. Denis
SASSOU-NGUESSO, who returned to power when
the war ended in October 1997, publicly expressed
interest in moving forward on economic reforms and
privatization and in renewing cooperation with
international financial institutions. However, economic
progress was badly hurt by slumping oil prices and the
resumption of armed conflict in December 1998,
which worsened the Republic of the Congo''s budget
deficit. Even with the IMF''s renewed confidence and
high world oil prices, Congo is unlikely to realize
growth of more than 5% in 2001 -02. With the return to
fragile peace, the IMF approved a $14 million credit in
November 2000 to aid post-conflict reconstruction.
GDP: purchasing power parity - $3.1 billion
(2000 est.)
GDP - real growth rate: 3.8% (2000 est.)
GDP - per capita: purchasing power parity - $1 , 1 00
(2000 est.)
GDP - composition by sector:
agriculture: W/o
industry: 48%
services: 42% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3.5% (2000 est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues; $870 million
expenditures: $970 million, including capital
expenditures of $NA (1997 est.)
Industries: petroleum extraction, cement kilning,
lumbering, brewing, sugar milling, palm oil, soap,
flour, cigarette making
Industrial production growth rate: NA%
Electricity - production: 302 million kWh (1999)
Electricity - production by source:
fossil fuel: 0.66%
hydro: 99.34%
nuclear: 0%
ofber; 0% (1999)
Electricity - consumption: 406.9 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 126 million kWh (1999)
Agriculture - products: cassava (tapioca), sugar,
rice, corn, peanuts, vegetables, coffee, cocoa; forest
products
Exports: $2.6 billion (f.o.b., 2000)
Exports - commodities: petroleum 50%, lumber,
plywood, sugar, cocoa, coffee, diamonds
Exports - partners: US 23%, Benelux 14%,
Germany, Italy, Taiwan, China (1998)
Imports: $870 million (f.o.b., 2000)
Imports - commodities: petroleum products, capital
equipment, construction materials, foodstuffs
Imports - partners: France 23%, US 9%, Belgium
8%, UK 7%, Italy (1997 est.)
Debt - external: $5 billion (1999 est.)
Economic aid ■ recipient: $159.1 million (1995)
Currency: Communaute Financiere Africaine franc
(XAF); note - responsible authority is the Bank of the
Central African States
Currency code: XAF
Exchange rates: Communaute Financiere Africaine
francs (XAF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1 997), 51 1 .55 (1 996): note - from 1 January 1 999,
the XAF is pegged to the euro at a rate of 655.957
XAF per euro
Fiscal year: calendar year','dbe670541cd9152149e5c53acf4a60ba8515d89cd9a1adeb55237ab696126119','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ada8f124f057de48a4533c87754b68d6af7e546118a92f4ba44600b78b6875fc',2001,'CK','Cook Islands','economy',333,'Economy - overview: Like many other South Pacific
island nations, the Cook Islands'' economic
development is hindered by the isolation of the
country from foreign markets, the limited size of
domestic markets, lack of natural resources, periodic
devastation from natural disasters, and inadequate
infrastructure. Agriculture provides the economic base
120
Cook Islands (continued)
with major exports made up of copra and citrus fruit.
Manufacturing activities are limited to fruit processing,
clothing, and handicrafts. Trade deficits are made up
for by remittances from emigrants and by foreign aid,
overwhelmingly from New Zealand. In the 1980s and
1990s, the country lived beyond its means,
maintaining a bloated public service and accumulating
a large foreign debt. Subsequent reforms, including
the sale of state assets, the strengthening of
economic management, the encouragement of
tourism, and a debt restructuring agreement, have
rekindled investment and growth.
GDP: purchasing power parity - $100 million
(1999 est.)
GDP - real growth rate: 2.9% (1999 est.)
GDP - per capita: purchasing power parity - $5,000
(1999 est.)
GDP - composition by sector:
agriculture: 18%
industry: 9%
serv/ces.-73%(1995)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .6% (1999 est.)
Labor force: 6,601 (1993)
Labor force - by occupation: agriculture 29%,
industry 15%, services 56% (1995) note - shortage of
skilled labor
Unemployment rate: NA%
Budget:
revenues: $25 million
expenditures: $23 million, including capital
expenditures of $NA (FY 99/00)
Industries; fruit processing, tourism, fishing
Industrial production growth rate: NA%
Electricity -production: 21 million kWh (1999)
Electricity - production by source:
foss//fue/.''100%
hydro: 0%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 19.5 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: copra, citrus, pineapples,
tomatoes, beans, pawpaws, bananas, yams, taro,
coffee; pigs, poultry
Exports: $3 million (f.o.b., 1999 est.)
Exports - commodities: copra, papayas, fresh and
canned citrus fruit, coffee; fish; pearls and pearl shells;
clothing
Exports - partners: Japan 42%, New Zealand 25%,
US 9%, Australia 9% (1999)
Imports: $85 million (c.i.f., 1994)
Imports ■ commodities: foodstuffs, textiles, fuels,
timber, capital goods
Imports - partners: NZ 70%, Australia 8% (1999)
Debt - external: $141 million (1996 est.)
Economic aid - recipient: $13.1 million (1995);
note ■ New Zealand continues to furnish the greater
part
Currency: New Zealand dollar (NZD)
Currency code: NZD
Exchange rates: New Zealand dollars per US
dollar - 2.2502 (January 2001 ), 2.1 863 (2000), 1 .8886
(1999), 1.8632 (1998), 1.5083 (1997), 1.4543 (1996)
Fiscal year: 1 April • 31 March
Economy - overview: no economic activity
Economy ■ overview: no economic activity
Economy - overview: The economy is based
largely on international financial services, agriculture,
and tourism. Potatoes, cauliflower, tomatoes, and
especially flowers are important export crops, shipped
mostly to the UK. The Jersey breed of dairy cattle is
known worldwide and represents an important export
Income earner. Milk products go to the UK and other
EU countries. In 1 996 the finance sector accounted for
about 60% of the island''s output. Tourism, another
mainstay of the economy, accounts for 24% of GDP.
In recent years, the government has encouraged light
industry to locate in Jersey, with the result that an
electronics industry has developed alongside the
traditional manufacturing of knitwear. All raw material
and energy requirements are imported, as well as a
large share of Jersey''s food needs. Light taxes and
death duties make the island a popular tax haven.
GDP: purchasing power parity - $2.2 billion
(1999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$24,800 (1999 est.)
GDP - composition by sector:
agriculture: 5%
industry: 2%
services: 93% (^9%)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 4.7% (1998)
Labor force: 57,050(1996)
Unemployment rate: 0.7% (1998 est.)
Budget:
revenues; $601 million
expenditures: $583 million, including capital
expenditures of $98 million (2000 est.)
Industries: tourism, banking and finance, dairy
Industrial production growth rate: NA%
Electricity - imports: NA kWh
note: electricity supplied by France
Agriculture - products: potatoes, cauliflower,
tomatoes; beef, dairy products
Exports: $NA
Exports - commodities: light industrial and
electrical goods, foodstuffs, textiles
Exports ■ partners: UK
Imports: $NA
Imports ■ commodities: machinery and transport
equipment, manufactured goods, foodstuffs, mineral
fuels, chemicals
Imports ■ partners: UK
Debt -external: none
Economic aid ■ recipient: none
Currency: British pound (GBP); note - there is also a
Jersey pound
Currency code: GBP
Exchange rates: Jersey pounds per US dollar -
0.6764 (January 2001 ), 0.6596 (2000), 0.61 80 (1 999),
0.6037 (1998), 0.6106 (1997), 0.6403 (1996); the
Jersey pound is at par with the British pound
Fiscal year: 1 April - 31 March
Economy - overview: Economic activity is limited to
providing services to US military personnel and
contractors located on the island. All food and
manufactured goods must be imported.
Electricity - production: approximately 1 ,000,000
kWh weekly; note - there are six 25,000 kWh
generators supplied by the base operating support
contractor (1999)
Electricity - consumption: NA kWh','670577adb800a197d730001de8a8e7175c805dbe962e8f51fe8d23e6d7df338b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b85d78e47c07f20e7d3b1af9c8728316526f749be6bbd09fbe6b8291d842b68',2001,'CR','Costa Rica','economy',341,'Economy - overview: Costa Rica''s basically stable
economy depends on tourism, agriculture, and
electronics exports. Poverty has been substantially
reduced over the past 15 years, and a strong social
safety net has been put into place. Foreign investors
remain attracted by the country''s political stability and
high education levels, and tourism continues to bring
in foreign exchange. However, traditional export
sectors have not kept pace. Low coffee prices and an
overabundance of bananas have hurt the agricultural
sector. The government continues to grapple with its
large deficit and massive internal debt and with the
need to modernize the state-owned electricity and
telecommunications sector.
GDP: purchasing power parity - $25 billion
(2000 est.)
GDP - real grovirth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity - $6,700
(2000 est.)
GDP - composition by sector:
agriculture: ^2.5%
industry: 30.7%
se/v/ces;56.8% (1999)
Population below poverty line: 20.6% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%; 1.3%
highest f0%; 34.7% (1996)
Inflation rate (consumer prices): 11% (2000 est.)
Labor force: 1 .9 million (1 999)
Labor force - by occupation: agriculture 20%,
industry 22%, services 58% (1999 est.)
Unemployment rate: 5.2% (2000 est.)
Budget:
revenues; $1.95 billion
expencf/fures; $2.4 billion, including capital
expenditures of $NA (2000 est.)
Industries; microprocessors, food processing,
textiles and clothing, construction materials, fertilizer,
plastic products
Industrial production growth rate; 4.3% (2000)
Electricity - production: 5.805 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 2.41%
hydro: 83.32%
nuclear: 0%
ofoer; 14.27% (1999)
Electricity - consumption: 5.303 billion kWh (1999)
Electricity ■ exports: 1 65 million kWh (1 999)
Electricity - imports: 69 million kWh (1999)
Agriculture - products: coffee, pineapples,
bananas, sugar, corn, rice, beans, potatoes; beef;
timber
Exports: $6.1 billion (f.o.b., 2000 est.)
Exports - commodities: coffee, bananas, sugar;
pineapples; textiles, electronic components, medical
equipment
Exports - partners: US 54.1%, EU 21 .3%, Central
America 8.6% (1 999)
Imports: $5.9 billion (f.o.b., 2000 est.)
123
Costa Rica (continued)
Imports - commodities: raw materials, consumer
goods, capital equipment, petroleum
Imports - partners: US 56.4%, EU 9%, Mexico
5.4%, Japan 4.7%, (1999)
Debt ■ external: $4.2 billion (2000 est.)
Currency: Costa Rican colon (CRC)
Currency code: CRC
Exchange rates: Costa Rican colones per US
dollar - 318.95 (2001), 308.19 (2000), 285.68 (1999),
257.23 (1998), 232.60 (1997), 207.69 (1996)
Fiscal year: calendar year','d23cb5d9d699a1cd2f3eef7ccca43f73c41af4166692ff41c77546665419432e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('509ab180d381ae0707b5307d61bf10d7c98f21eb00048f47400bf355ed8a8bd1',2001,'SI','Slovenia','economy',355,'Economy - overview: Before the dissolution of
Yugoslavia, the Republic of Croatia, after Slovenia,
was the most prosperous and industrialized area, with
a per capita output perhaps one-third above the
Yugoslav average. Croatia faces considerable
economic problems stemming from: the legacy of
longtime communist mismanagement of the
economy; damage during the internecine fighting to
bridges, factories, power lines, buildings, and houses;
the large refugee and displaced population, both
Croatian and Bosnian; and the disruption of economic
ties. Stepped-up Western aid and investment,
especially in the tourist and oil industries, would help
bolster the economy. The economy emerged from its
mild recession in 2000 with tourism the main factor.
Massive unemployment remains a key negative
element. The government''s failure to press the
economic reforms needed to spur growth is largely the
result of coalition politics and public resistance,
particularly from the trade unions, to measures that
would cut jobs, wages, or social benefits.
GDP: purchasing power parity - $24.9 billion
(2000 est.)
GDP - real growth rate: 3.2% (2000 est.)
GDP - per capita: purchasing power parity - $5,800
(2000 est.)
GDP - composition by sector:
agriculture: 10%
industry: 19%
services: 71 % (1 999 est.)
Population below poverty line: 4% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 6% (2000 est.)
Labor force: 1 .68 million (October 2000)
Labor force ■ by occupation: agriculture NA%,
industry NA%, services NA%
128
Croatia (continued)
Unemployment rate: 22% (October 2000)
Budget:
revenues: $6 billion
expenditures: $47 billion, Including capital
expenditures of $NA (1999 est.)
Industries: chemicals and plastics, machine tools,
fabricated metal, electronics, pig iron and rolled steel
products, aluminum, paper, wood products,
construction materials, textiles, shipbuilding,
petroleum and petroleum refining, food and
beverages; tourism
Industrial production growth rate: 1.7% (2000)
Electricity - production: 10.96 billion kWh (1999)
Electricity - production by source:
fossil fuel: 40.89%
hydro: 59%
nuclear: 0%
other; 0.11% (1999)
Electricity - consumption: 1 3.643 billion kWh
(1999)
Electricity - exports: 1 billion kWh (1999)
Electricity - imports: 4.45 billion kWh (1999)
Agriculture - products: wheat, corn, sugar beets,
sunflower seed, alfalfa, clover, olives, citrus, grapes,
soy beans, potatoes; livestock, dairy products
Exports: $4.3 billion (f.o.b., 1999)
Exports - commodities: transport equipment,
textiles, chemicals, foodstuffs, fuels
Exports - partners: Italy 18%, Germany 15.7%,
Bosnia and Herzegovina 12.8%, Slovenia 10.6%,
Austria 6.2% (1999)
Imports: $7.8 billion (c.i.f., 1999)
Imports ■ commodities: machinery, transport and
electrical equipment, chemicals, fuels and lubricants,
foodstuffs
Imports - partners: Germany 18.5%, Italy 15.9%,
Russia 8.6%, Slovenia 7.9%, Austria 7.1% (1999)
Debt - external: $9.9 billion (December 1999)
Economic aid - recipient: $NA
Currency: kuna(HRK)
Currency code: HRK
Exchange rates: kuna per US dollar - 8.089
(January 2001), 8.277 (2000), 7.112 (1999), 6.362
(1998), 6.101 (1997), 5.434 (1996)
Fiscal year: calendar year','a320c06d2f1de38b6980378460f5e52287375058aa7039386140d973514e5864','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69c24c95a78ef33e38a4f87750037bdacb06a8431c32d13b2fe296108ff9b905',2001,'CU','Cuba','economy',364,'Economy - overview: The government, the primary
player in the economy, has undertaken limited
reforms in recent years to stem excess liquidity,
increase enterprise efficiency, and alleviate serious
shortages of food, consumer goods, and services, but
prioritizing of political control makes extensive reforms
unlikely. Living standards for the average Cuban,
without access to dollars, remain at a depressed level
compared with 1990. The liberalized farmers'' markets
Introduced in 1994, sell above-quota production at
market prices, expand legal consumption alternatives,
and reduce black market prices. Income taxes and
increased regulations introduced since 1996 have
sharply reduced the number of legally self-employed
from a high of 208,000 in January 1996. Havana
announced in 1995 that GDP declined by 35% during
1989-93 as a result of lost Soviet aid and domestic
inefficiencies. The slide in GDP came to a halt in 1 994
when Cuba reported growth in GDP of 0.7%. Cuba
reported that GDP increased by 2.5% in 1995 and
7.8% in 1996, before slowing down in 1997 and 1998
to 2.5% and 1 .2% respectively. Growth recovered with
a 6.2% increase in GDP in 1999 and a 5.6% increase
in 2000. Much of Cuba''s recovery can be attributed to
tourism revenues and foreign investment. Growth in
2001 should continue at the same level as the
government balances the need for economic
loosening against its concern for firm political control.
GDP: purchasing power parity - $1 9.2 billion
(2000 est.)
GDP - real growth rate: 5.6% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,700
(2000 est.)
GDP - composition by sector:
agriculture: 7%
industry: 37%
services: 53% {^998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%>: NA%
Inflation rate (consumer prices): 0.3% (1999 est.)
Labor force: 4.3 million (2000 est.)
note: state sector 75%, non-state sector 25% (1 998)
Labor force - by occupation: agriculture 25%,
industry 24%, services 51% (1998)
Unemployment rate: 5.5% (2000 est.)
Budget:
revenues; $13.5 billion
expencf/fures; $14.3 billion, including capital
expenditures of $NA (2000 est.)
Industries: sugar, petroleum, tobacco, chemicals,
construction, services, nickel, steel, cement,
agricultural machinery
Industrial production growth rate: 5% (2000 est.)
Electricity ■ production: 14.358 billion kWh (1999)
Electricity ■ production by source:
fossil fuel: 94.2%
hydro: 0.7%
nuclear: 0%
oto; 5.1% (1999)
Electricity - consumption: 13.353 billion kWh
(1999)
Electricity - exports: 0 kWh (1 999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: sugar, tobacco, citrus,
coffee, rice, potatoes, beans; livestock
Exports: $1.8 billion (f.o.b., 2000 est.)
Exports - commodities: sugar, nickel, tobacco, fish,
medical products, citrus, coffee
Exports - partners: Russia 23%, Netherlands 23%,
Canada 13% (1999)
Imports: $3.4 billion (f.o.b., 2000 est.)
Imports - commodities: petroleum, food,
machinery, chemicals, semifinished goods, transport
equipment, consumer goods
Imports - partners: Spain 18%, Venezuela 13%,
Canada 8% (1999)
Debt - external: $11.1 billion (convertible currency,
1999); another $15 billion -$20 billion owed to Russia
(2000)
Economic aid - recipient: $68.2 million (1997 est.)
Currency: Cuban peso (CUP)
Currency code: CUP
Exchange rates: Cuban pesos per US dollar -
1.0000 (nonconvertible, official rate, for international
transactions, pegged to the US dollar); convertible
peso sold for domestic use at a rate of 1 .00 US dollar
per 22 pesos by the Government of Cuba (January
2001)
Fiscal year: calendar year
131
Cuba (continued)
Economy ■ overview; About 80% of the population
lives in abject poverty. Nearly 70% of all Haitians
depend on the agriculture sector, which consists
mainly of small-scale subsistence farming and
employs about two-thirds of the economically active
work force. The country has experienced little job
creation since the former President PREVAL took
office in February 1996, although the informal
economy is growing. Following legislative elections in
May 2000, fraught with irregularities, international
donors - including the US and EU - suspended almost
all aid to Haiti. This destabilized the Haitian currency,
the gourde, and, combined with a 40% fuel price hike
in September, caused widespread price increases.
Prices appear to have leveled off in January 2001 .
GDP: purchasing power parity - $12.7 billion
(2000 est.)
GDP - real growth rate: 1 .2% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,800
(2000 est.)
GDP - composition by sector:
agriculture: 32%
industry: 20%
services: 48% (1999 est.)
Population below poverty line: 80% (1998 est.)
Household Income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 19% (2000 est.)
Labor force; 3.6 million (1995)
note: shortage of skilled labor, unskilled labor
abundant (1998)
Labor force - by occupation: agriculture 66%,
services 25%, industry 9%
Unemployment rate: widespread unemployment
and underemployment; more than two-thirds of the
labor force do not have formal jobs (1 999)
Budget:
revenues; $31 7 million
expenditures: $362 million, including capital
expenditures of $84 million (FY99/00 est.)
219
Haiti (continued)
Industries: sugar refining, flour milling, textiles,
cement, tourism, light assembly industries based on
imported parts
Industrial production growth rate: 0.6%
(1997 est.)
Electricity - production: 672 million kWh (1999)
Electricity > production by source:
fossil fuel: 52.83%
hydro; 47.17%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 625 million kWh (1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coffee, mangoes,
sugarcane, rice, corn, sorghum; wood
Exports: $186 million (f.o.b., 1999)
Exports - commodities: manufactures, coffee, oils,
mangoes
Exports - partners: US 89%, EU 8% (1999)
Imports: $1.2 billion (c.i.f., 1999)
Imports - commodities: food, machinery and
transport equipment, fuels, raw materials
Imports - partners: US 60%, EU 13% (1999)
Debt - external: $1 billion (1998 est.)
Economic aid - recipient: $730.6 million (1995)
Currency: gourde (HTG)
Currency code: HTG
Exchange rates: gourdes per US dollar - 23.761
(January 2001 ), 22.524 (2000), 1 7.965 (1 999), 1 6.505
(1998), 17.311 (1997), 15.093(1996)
Fiscal year: 1 October - 30 September','06fea8958953a5690f11849b1b86a63fdf1c680a477b8ae7627133d0ada6bb97','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00fd25dd96a8fa1b7f2b7bc460c4e16a892571414b3da1391e8dc2e06d279d7e',2001,'CY','Cyprus','economy',373,'Economy - overview: Economic affairs are affected
by the division of the country. The Greek Cypriot
economy is prosperous but highly susceptible to
external shocks. Erratic growth rates in the 1990s
reflect the economy''s vulnerability to swings in tourist
arrivals, caused by political instability on the island
and fluctuations in economic conditions in Western
Europe. Economic policy is focused on meeting the
criteria for admission to the EU. As in the Turkish
sector, water shortage is a growing problem, and
several desalination plants are planned. The Turkish
Cypriot economy has about one-fifth the population
and one-third the per capita GDP of the south.
Because it is recognized only by Turkey, it has had
much difficulty arranging foreign financing, and
foreign firms have hesitated to Invest there. It remains
heavily dependent on agriculture and government
service, which together employ about half of the work
force. Moreover, the small, vulnerable economy has
suffered because the Turkish lira is legal tender. To
compensate for the economy''s weakness, Turkey
provides direct and Indirect aid to tourism, education,
industry, etc.
GDP; Greek Cypriot area: purchasing power parity -
$9.7 billion (2000 est.); Turkish Cypriot area:
purchasing power parity - $830 million (1999 est.)
GDP - real growth rate: Greek Cypriot area: 4.2%
(2000 est.); Turkish Cypriot area: 4.9% (1999 est.)
GDP - per capita: Greek Cypriot area: purchasing
power parity - $16,000 (2000 est.); Turkish Cypriot
area: purchasing power parity - $5,300 (1999 est.)
GDP - composition by sector: Greek Cypriot area:
agriculture 6.3%, industry 22.4%, services 71.3%
(1998); Turkish Cypriot area: agriculture 11.8%,
industry 20.5%, services 67.7% (1998)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): Greek Cypriot
area: 4.2% (2000 est.); Turkish Cypriot area: 58%
(1999 est.)
Labor force: Greek Cypriot area: 291 ,000; Turkish
Cypriot area: 86,300 (2000)
134
Cyprus (continued)
Labor force ■ by occupation: Greek Cypriot area:
services 73%, industry 22%, agriculture 5% (2000);
Turkish Cypriot area: services 56.4%, industry 22.8%,
agriculture 20.8% (1998)
Unempioyment rate: Greek Cypriot area: 3.6%
(2000 est.); Turkish Cypriot area: 6% (1998 est.)
Budget:
revenues: Greek Cypriot area - $2.9 billion
(2000 est.); Turkish Cypriot area - $294 million
(2000 est.)
expenditures: Greek Cypriot area - $3.2 billion,
including capital expenditures of $324 million
(2000 est.); Turkish Cypriot $495 million, including
capital expenditures of $60 million (2000 est.)
Industries: food, beverages, textiles, chemicals,
metal products, tourism, wood products
Industrial production growth rate: Greek Cypriot
area: 2.2% (1999); Turkish Cypriotarea: -0.3% (1999)
Electricity -production: 2.951 billion kWh (1999);
Turkish Cypriot area: NA kWh
Electricity ■ production by source:
fossil fuel: ^00%
hydro: 0%
nuclear: 0%
of/?ef;0%(1999)
Electricity - consumption: 2.744 billion kWh
(1999); Turkish Cypriotarea: NA kWh
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: potatoes, citrus,
vegetables, barley, grapes, olives, vegetables
Exports: Greek Cypriot area: $1 billion (f.o.b.,
1999 est.); Turkish Cypriot area: $51.1 million (f.o.b.,
1999)
Exports - commodities: Greek Cypriot area: citrus,
potatoes, grapes, wine, cement, clothing and shoes;
Turkish Cypriot area: citrus, potatoes, textiles
Exports - partners: Greek Cypriot area: UK 17.3%,
Greece 9.7%, Russia 7.0%, Lebanon 5.2% (1999);
Turkish Cypriot area: Turkey 51%, UK 31%, other EU
16.5% (1999)
Imports: Greek Cypriot area: $3.6 billion (f.o.b.,
1999 est.); Turkish Cypriot area: $402 million (f.o.b.,
1999)
Imports - commodities: Greek Cypriot area:
consumer goods, petroleum and lubricants, food and
feed grains, machinery; Turkish Cypriot area: food,
minerals, chemicals, machinery
Imports - partners: Greek Cypriot area: UK 1 1 .2%,
US 10.6%, Italy 8.8%, Greece 8.2%, Germany 6.7%
(1999); Turkish Cypriot area: Turkey 58.6%, UK
12.5%, other EU 13% (1999)
Debt - external: Greek Cypriot area: $NA; Turkish
Cypriot area: $NA
Economic aid - recipient: Greek Cypriot area - $17
million (1998); Turkish Cypriot area - $700 million from
Turkey in grants and loans (1990-97) that are usually
forgiven
Currency: Greek Cypriot area: Cypriot pound (CYP);
Turkish Cypriot area: Turkish lira (TRL)
Currency code: CYP; TRL
Exchange rates: Cypriot pounds per US dollar -
0.6146 (January 2001 ). 0.6208 (2000), 0.5423 (1 999),
0.5170 (1998), 0.5135 (1997), 0.4663 (1996); Turkish
liras per US dollar - 677,621 (December 2000),
625,219 (2000), 418,783 (1999), 260,724 (1998),
151,865 (1997), 81,405 (1996)
Fiscal year: calendar year
Economy - overview: Basically one of the most
stable and prosperous of the post-Communist states,
the Czech Republic has been recovering from
recession since mid-1999. The economy grew about
2.5% in 2000 and should achieve somewhat higher
growth in 2001. Growth is led by exports to the EU,
especially Germany, and foreign investment, while
domestic demand is reviving. Uncomfortably high
fiscal and current account deficits could be future
problems. Unemployment is down to 8.7% as job
creation continues in the rebounding economy;
inflation is up to 3.8% but still moderate. The EU put
the Czech Republic just behind Poland and Hungary
in preparations for accession, which will give further
impetus and direction to structural reform. Moves to
complete banking, telecommunications and energy
privatization will add to foreign investment, while
intensified restructuring among large enterprises and
banks and Improvements in the financial sector
should strengthen output growth.
GDP: purchasing power parity - $132.4 billion
(2000 est.)
GDP ■ real growth rate: 2.5% (2000 est.)
GDP - per capita: purchasing power parity -
$12,900 (2000 est.)
GDP - composition by sector:
agriculture: 3.7%
industry: 4^.S%
sen//ces; 54.5% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 4.3%
highest m; 22.4% (1996)
Inflation rate (consumer prices): 3.8% (2000 est.)
Labor force: 5.203 million (1999 est.)
Labor force - by occupation: agriculture 5%,
industry 40%, services 55% (2000 est.)
Unemployment rate: 8.7% (2000 est.)
Budget:
revenues: $16.7 billion
expenditures: $18 billion, including capital
expenditures of $NA (2001 est.)
Industries: metallurgy, machinery and equipment,
motor vehicles, glass, armaments
Industrial production growth rate: 7.6% (2000)
Electricity - production: 67.642 billion kWh (2000)
Electricity - production by source:
fossil fuel: 77.8%
hydro: 3.43%
nuclear: 18.77%
other: 0% {2000)
Electricity - consumption: 52.898 billion kWh
(2000)
Electricity ■ exports: 18.744 billion kWh (2000)
Electricity - imports: 8.735 billion kWh (2000)
Agriculture - products: wheat, potatoes, sugar
beets, hops, fruit; pigs, poultry
Exports: $28.3 billion (f.o.b., 2000)
Exports - commodities: machinery and transport
equipment 44%, other manufactured goods 40%,
chemicals 7%, raw materials and fuel 7% (1999)
Exports - partners: Germany 43%, Slovakia 8.4%,
Austria 6.6%, Poland 5.6%, France 4% (1999)
Imports: $31 .4 billion (f.o.b., 2000)
Imports - commodities: machinery and transport
equipment 42%, other manufactured goods 33%,
chemicals 12%, raw materials and fuels 10% (1999)
Imports ■ partners: Germany 37.5%, Slovakia
6.7%, Austria 6.2%, Italy 5.9%, France 5.4% (1999)
Debt - external: $21 .3 billion (2000)
Economic aid - recipient: $NA
Currency: Czech koruna (CZK)
Currency code: CZK
Exchange rates: koruny per US dollar - 37.425
(January 2001), 38.598 (2000), 34.569 (1999), 32.281
(1998), 31.698 (1997), 27.145 (1996)
Fiscal year: calendar year
Economy - overview: This thoroughly modern
market economy features high-tech agriculture,
up-to-date small-scale and corporate industry,
extensive government welfare measures, comfortable
living standards, and high dependence on foreign
trade. Denmark is a net exporter of food and energy
and has a comfortable balance of payments surplus.
The center-left coalition government has reduced the
formerly high unemployment rate and attained a
budget surplus as well as followed the previous
government''s policies of maintaining low inflation and
a stable currency. The coalition has lowered marginal
income tax rates and raised environmental taxes thus
maintaining overall tax revenues. Problems of
bottlenecks, and longer term demographic changes
reducing the labor force, are being addressed through
labor market reforms. The government has been
successful in meeting, and even exceeding, the
economic convergence criteria for participating in the
third phase (a common European currency) of the
European Monetary Union (EMU), but Denmark, in a
September 2000 referendum, reconfirmed its decision
not to join the 1 1 other EU members in the euro. Even
so, the Danish currency remains pegged to the euro.
GDP: purchasing power parity - $136.2 billion
(2000 est.)
GDP - real growth rate: 2.8% (2000 est.)
GDP - per capita: purchasing power parity -
$25,500 (2000 est.)
GDP - composition by sector:
agriculture: 3%
industry: 25%
services: 72% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2%
highest 10%: 2A% (2000 est.)
Inflation rate (consumer prices): 2.9% (2000 est.)
Labor force: 2.856 million (2000 est.)
Labor force ■ by occupation: services 79%,
industry 17%, agriculture 4% (2000 est.)
Unemployment rate: 5.3% (2000)
139
Denmark (continued)
Budget:
revenues: $52.9 billion
expenditures: $51 .3 billion, including capital
expenditures of $500 million (2001 est.)
Industries: food processing, machinery and
equipment, textiles and clothing, chemical products,
electronics, construction, furniture, and other wood
products, shipbuilding, windmills
Industrial production growth rate: 3% (2000 est.)
Electricity - production: 37.885 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 88.4%
hydro: 0.07%
nuclear: 0%
of/?er 11.53% (1999)
Electricity ■ consumption: 32.916 billion kWh
(1999)
Electricity - exports: 7.28 billion kWh (1999)
Electricity - imports: 4.963 billion kWh (1999)
Agriculture - products: grain, potatoes, rape, sugar
beets; pork and beef, dairy products; fish
Exports: $50.8 billion (f.o.b., 2000)
Exports - commodities: machinery and
instruments, meat and meat products, dairy products,
fish, chemicals, furniture, ships, windmills
Exports - partners: EU 66.5% (Germany 20.1%,
Sweden 11.7%, UK 9.6%, France 5.3%, Netherlands
4.7%), Norway 5.8%, US 5.4% (1999)
Imports: $43.6 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment,
raw materials and semimanufactures for industry,
chemicals, grain and foodstuffs, consumer goods
Imports - partners: EU 72.1% (Germany 21.6%,
Sweden 12.4%, UK 8.0%, Netherlands 8.0%, France
5.8%), Norway 4.2%, US 4.5% (1999)
Debt ■ external: $21.7 billion (2000)
Economic aid - donor: ODA, $1 .63 billion (1 999)
Currency: Danish krone (DKK)
Currency code: DKK
Exchange rates: Danish kroner per US dollar -
7.951 (January 2001), 8.083 (2000), 6.976 (1999),
6.701 (1998), 6.604 (1997), 5.799 (1996); note ■ the
Danes rejected the Euro in a 28 September 2000
referendum
Fiscal year: calendar year','825bea3c8655f304e8d7b1ea22ba181ccef6fe148660783e12028e65606611bf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ef7f0f5f6ce44e303a69b5e3e6d71ff6f8cdb2124be74029310c68b3954cde3',2001,'DJ','Djibouti','economy',382,'Economy - overview: The economy is based on
service activities connected with the country''s
strategic location and status as a free trade zone in
northeast Africa. Two-thirds of the inhabitants live in
the capital city, the remainder being mostly nomadic
herders. Scanty rainfall limits crop production to fruits
and vegetables, and most food must be imported.
Djibouti provides services as both a transit port for the
region and an international transshipment and
refueling center. It has few natural resources and little
industry. The nation is, therefore, heavily dependent
on foreign assistance to help support its balance of
payments and to finance development projects. An
unemployment rate of 40% to 50% continues to be a
major problem. Inflation is not a concern, however,
because of the fixed tie of the franc to the US dollar.
Per capita consumption dropped an estimated 35%
over the last seven years because of recession, civil
war, and a high population growth rate (including
immigrants and refugees). Faced with a multitude of
economic difficulties, the government has fallen in
arrears on long-term external debt and has been
struggling to meet the stipulations of foreign aid
donors. The year 2001 will see only small growth as
port activity should decrease now that Ethiopia has
more trade route options.
GDP: purchasing power parity - $574 million
(2000 est.)
GDP - real growth rate: 2% (2000 est.)
GDP ■ per capita: purchasing power parity - $1 ,300
(2000 est.)
GDP - composition by sector:
agriculture: 3%
industry: 22%
services: 75% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o: NA%
Inflation rate (consumer prices): 2% (2000 est.)
Labor force: 282,000
Labor force - by occupation: agriculture 75%,
industry 11%, services 14% (1991 est.)
Unemployment rate: 50% (2000 est.)
Budget:
revenues; $133 million
expenditures: $187 million, including capital
expenditures of $NA (1999 est.)
Industries: limited to a few small-scale enterprises,
such as dairy products and mineral-water bottling
Industrial production growth rate: 3% (1996 est.)
Electricity - production: 180 million kWh (1999)
Electricity > production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(im)
Electricity - consumption: 167.4 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: fruits, vegetables; goats,
sheep, camels
Exports: $260 million (f.o.b., 1999 est.)
Exports - commodities: reexports, hides and skins,
coffee (in transit)
Exports - partners: Somalia 53%, Yemen 23%,
Ethiopia 5%, (1998)
Imports: $440 million (f.o.b., 1999 est.)
Imports - commodities: foods, beverages,
transport equipment, chemicals, petroleum products
Imports " partners: France 13%, Ethiopia 12%, Italy
9%, Saudi Arabia 6%, UK 6% (1998)
Debt - external: $356 million (1 999 est.)
Economic aid - recipient: $106.3 million (1995)
Currency: Djiboutian franc (DJF)
Currency code: DJF
Exchange rates: Djiboutian francs per US dollar -
177.721 (fixed rate since 1973)
Fiscal year: calendar year
Economy - overview: The economy depends on
agriculture and is highly vulnerable to climatic
conditions, notably tropical storms. Agriculture,
primarily bananas, accounts for 21% of GDP and
employs 40% of the labor force. Development of the
tourist industry remains difficult because of the rugged
coastline, lack of beaches, and the lack of an
International airport. Hurricane Luis devastated the
country''s banana crop in September 1995; tropical
storms had wiped out one-quarter of the crop in 1994
as well. The subsequent recovery has been fueled by
increases in construction, soap production, and tourist
arrivals. The government is attempting to develop an
offshore financial industry in order to diversify the
Island''s production base.
GDP: purchasing power parity - $290 million
(2000 est.)
GDP - real growth rate: 0.5% (2000 est.)
GDP - per capita: purchasing power parity - $4,000
(2000 est.)
GDP - composition by sector:
agriculture: 2]%
industry: 16%
services: 63% (1999 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.5% (2000 est.)
Labor force: 25,000
Labor force - by occupation: agriculture 40%,
industry and commerce 32%, services 28%
Unemployment rate: 20% (1999 est.)
Budget:
revenues: $72 million
expenditures: $79.9 million, including capital
expenditures of $1 1 .5 million (FY97/98)
Industries: soap, coconut oil, tourism, copra,
furniture, cement blocks, shoes
Industrial production growth rate: -10%
(1997 est.)
Electricity - production: 62 million kWh (1999)
Electricity - production by source:
fossil fuel: 48.39%
hycfro; 51 .61%
nuclear: 0%
other: 0%{m9)
Electricity - consumption: 57.7 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, citrus, mangoes,
root crops, coconuts, cocoa; forest and fishery
potential not exploited
Exports: $60.7 million (2000 est.)
Exports - commodities: bananas, soap, bay oil,
vegetables, grapefruit, oranges
Exports ■ partners: Caricom countries 47%, UK
36%, US 7% (1996 est.)
Imports: $126 million (2000 est.)
Imports ■ commodities: manufactured goods,
machinery and equipment, food, chemicals
Imports - partners: US 41%, Caricom countries
25%, UK 13%, Netherlands, Canada (1996 est.)
Debt - external: $108.9 million (1999)
Economic aid - recipient: $24.4 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Fiscal year: 1 July - 30 June','582b4a91167f88d03b394cf9759de0a8c8cecb10a42e612d6b90472eda10c778','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e77216b1b6178b4ac517e3b1280f72fdd3cf300fc428f32108f4e4c3a33f8de',2001,'DO','Dominican Republic','economy',390,'Economy - overview: The Dominican economy
experienced dramatic growth over the last decade,
even though the economy was hit hard by Hurricane
Georges in 1998. Although the country has long been
viewed primarily as an exporter of sugar, coffee, and
tobacco, in recent years the service sector has
overtaken agriculture as the economy''s largest
employer, due to growth in tourism and free trade
zones. The country suffers from marked income
inequality; the poorest half of the population receives
less than one-fifth of GNP, while the richest ten
percent enjoy 40% of national income. In December
2000, the new MEJIA administration passed broad
new tax legislation which it hopes will provide enough
revenue to offset rising oil prices and to service foreign
debt.
GDP: purchasing power parity - $48.3 billion
(2000 est.)
GDP - real growth rate: 8% (2000 est.)
GDP - per capita: purchasing power parity - $5,700
(2000 est.)
GDP - composition by sector:
agricuiture:^^.3%
industry: 32.2%
services: 53.5% (1999 est.)
Population below poverty line: 25% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 1.6%
highest 10%: 39.6% {1969)
Inflation rate (consumer prices): 7.9% (2000 est.)
Labor force: 2.3 million - 2.6 million
Labor force - by occupation: services and
government 58.7%, industry 24.3%, agriculture 17%
(1998 est.)
Unemployment rate: 1 3.8% (1 999 est.)
Budget:
revenues: $2.3 billion
expenditures: $2.9 billion, including capital
expenditures of $867 million (1999 est.)
Industries: tourism, sugar processing, ferronickel
and gold mining, textiles, cement, tobacco
Industrial production growth rate: 8% (2000 est.)
Electricity - production: 7.29 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 87.19%
hydro: 12.4%
nuclear: 0%
ofoer; 0.41% (1999)
Electricity - consumption: 6.78 billion kWh (1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: sugarcane, coffee, cotton,
cocoa, tobacco, rice, beans, potatoes, corn, bananas;
cattle, pigs, dairy products, beef, eggs
Exports: $5.8 billion (f.o.b., 2000)
Exports - commodities: ferronickel, sugar, gold,
silver, coffee, cocoa, tobacco, meats
Exports - partners: US 66.1%, Netherlands 7.8%,
Canada 7.6%, Russia 7.4%, UK 4.5% (1999 est.)
Imports: $9.6 billion (f.o.b., 2000 est.)
Imports - commodities: foodstuffs, petroleum,
cotton and fabrics, chemicals and pharmaceuticals
Imports ■ partners: US 25.7%, Venezuela 9.2%,
Mexico 4%, Japan 3%, Panama 2.6% (1999 est.)
Debt ■ external: $4.7 billion (2000 est.)
Economic aid - recipient: $239.6 million (1995)
Currency: Dominican peso (DOP)
Currency code: DOP
Exchange rates: Dominican pesos per US dollar -
1 6.888 (January 2001 ), 1 6.41 5 (2000), 1 6.033 (1 999),
15.267 (1998), 14.265 (1997), 13.775 (1996)
Fiscal year: calendar year
Economy - overview: Puerto Rico has one of the
most dynamic economies in the Caribbean region. A
diverse industrial sector has surpassed agriculture as
the primary locus of economic activity and income.
Encouraged by duty-free access to the US and by tax
incentives, US firms have invested heavily In Puerto
Rico since the 1950s. US minimum wage laws apply.
Sugar production has lost out to dairy production and
other livestock products as the main source of income
in the agricultural sector. Tourism has traditionally
been an Important source of income, with estimated
arrivals of nearly 5 million tourists in 1999. Prospects
for 2001 are clouded by a probable slowing down in
both the construction and tourist sectors and by
increasing inflation, particularly in energy and food
prices; estimated growth will be 2%.
GDP: purchasing power parity - $39 billion
(2000 est.)
GDP - real growth rate: 2.8% (2000 est.)
GDP - per capita: purchasing power parity -
$10,000 (2000 est.)
GDP - composition by sector:
agriculture: 1%
industry: 45%
services: 54% (1 999 est.)
Population below poverty line: NA%
Househoid Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
inflation rate (consumer prices): 5.7% (2000 est.)
Labor force: 1 .3 million (2000)
Labor force - by occupation: agriculture 3%,
industry 20%, services 77% (2000 est.)
Unemployment rate: 9.5% (2000)
Budget:
revenues: $6.7 billion
expenditures: $9.6 billion, including capital
expenditures of $NA (FY99/00)
Industries: pharmaceuticals, electronics, apparel,
food products; tourism
Industrial production growth rate: NA%
Electricity - production: 1 6.76 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 98.45%
/?yafro.-1.55%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 1 5.587 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: sugarcane, coffee,
pineapples, plantains, bananas; livestock products,
chickens
Exports: $38.5 billion (f.o.b., 2000)
Exports - commodities: pharmaceuticals,
electronics, apparel, canned tuna, rum, beverage
concentrates, medical equipment
413
Puerto Rico (continued)
Exports “ partners: US 88% (2000)
Imports: $27 billion (c.i.f., 2000)
Imports - commodities: chemicals, machinery and
equipment, clothing, food, fish, petroleum products
Imports - partners: US 60% (2000)
Debt -external: $NA
Economic aid - recipient: $NA
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 July - 30 June','c93d57f3ce2379ce9550e2306a236288000f3820baaef42be61d356f1469c0f9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9ffca4c904661dc1cf9ebda23b422cf4c2e0cbf4edd0f15aa88367b1de0dd91',2001,'PE','Peru','economy',399,'Economy - overview: Ecuador has substantial oil
resources and rich agricultural areas. Because the
country exports primary products such as oil,
bananas, and shrimp, fluctuations in world market
prices can have a substantial domestic impact.
Ecuador joined the World T rade Organization in 1 996,
but has failed to comply with many of its accession
commitments. In recent years, growth has been
uneven due to ill-conceived fiscal stabilization
measures. The aftermath of El Nino and depressed oil
market of 1997-98 drove Ecuador''s economy into a
free-fall in 1999. The beginning of 1999 saw the
banking sector collapse, which helped precipitate an
unprecedented default on external loans later that
year. Continued economic instability drove a 70%
depreciation of the currency throughout 1999, which
eventually forced a desperate government to
"dollarize" the currency regime in 2000. The move
stabilized the currency, but did not stave off the ouster
of the government. The new president, Gustavo
NOBOA has yet to complete negotiations for a long
sought IMF accord. He will find it difficult to push
through the reforms necessary to make "dollarization"
work in the long run.
GDP: purchasing power parity - $37.2 billion
(2000 est.)
GDP - real growth rate: 0.8% (2000 est.)
GDP - per capita: purchasing power parity - $2,900
(2000 est.)
GDP " composition by sector:
agriculture: 14%
industry: 36%
services: 50% (1999 est.)
Population below poverty line: 50% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.2%
highest /0%; 33.8% (1995)
inflation rate (consumer prices): 96% (2000 est.)
Labor force: 4.2 million
Labor force - by occupation: agriculture 30%,
industry 25%, services 45% (1999 est.)
Unemployment rate: 13%; note - widespread
underemployment (2000 est.)
Budget:
revenues: planned $5.1 billion (not including revenue
from potential privatizations)
expenditures: billion, including capital
expenditures of $NA (1999)
Industries: petroleum, food processing, textiles,
metal work, paper products, wood products,
chemicals, plastics, fishing, lumber
148
Ecuador (continued)
Industrial production growth rate: 2.4%
(1997 est.)
Electricity - production: 10.065 billion kWh (1999)
Electricity - production by source:
foss/7 fue/.* 29.51%
hydro: 70 A9%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 9.386 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 25 million kWh (1999)
Agriculture - products: bananas, coffee, cocoa,
rice, potatoes, manioc (tapioca), plantains,
sugarcane; cattle, sheep, pigs, beef, pork, dairy
products; balsa wood; fish, shrimp
Exports: $5.6 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum, bananas,
shrimp, coffee, cocoa, cut flowers, fish
Exports - partners: US 37%, Colombia 5%, Italy
5%, Chile 5%, Peru 4% (1999)
Imports: $3.4 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
raw materials, fuels; consumer goods
Imports - partners: US 30%, Colombia 13%,
Venezuela 6%, Japan 5%, Venezuela 6%, Mexico 3%
(1998)
Debt - external: $1 5 billion (1 999)
Economic aid - recipient: $695.7 million (1995)
Currency: US dollar (USD)
Currency code: USD
Exchange rates: sucres per US dollar ■ 25,000
(January 2001), 24,988.4 (2000), 11,786.8 (1999),
5,446.6 (1998), 3,988.3 (1997), 3,189.5 (1996)
note: on 7 January 2000, the government passed a
decree "dollarizing” the economy; on 13 March 2000,
the National Congress approved a new exchange
system whereby the US dollar is adopted as the main
legal tender in Ecuador for all purposes; on 20 March
2000, the Central Bank of Ecuador started to
exchange sucres for US dollars at a fixed rate of
25,000 sucres per US dollar; since 30 April 2000, all
transactions are denominated in US dollars
Fiscal year: calendar year
Economy - overview: The Peruvian economy has
become increasingly market-oriented, with major
privatizations completed since 1990 in the mining,
electricity, and telecommunications industries.
Thanks to strong foreign investment and the
cooperation between the FUJIMORI government and
the IMF and World Bank, growth was strong in
1994-97 and inflation was brought under control. In
1998, El Nino''s impact on agriculture, the financial
crisis in Asia, and instability in Brazilian markets
undercut growth. And 1999 was another lean year for
Peru, with the aftermath of El Nino and the Asian
financial crisis working its way through the economy.
Political instability resulting from the presidential
election and FUJIMORI''S subsequent departure from
office limited economic growth in 2000.
GDP: purchasing power parity - $1 23 billion
(2000 est.)
GDP - real growth rate: 3.6% (2000 est.)
GDP - per capita: purchasing power parity - $4,550
(2000 est.)
GDP - composition by sector:
agriculture: 15%
industry: 42%
services: 45% (1999)
Population below poverty line: 49% (1994 est.)
401
Peru (continued)
Household income or consumption by percentage
share:
lowest 10%:
highest 10%: 34.3% (im)
Inflation rate (consumer prices): 3.7% (2000 est.)
Labor force: 7.6 million (1 996 est.)
Labor force - by occupation: agriculture, mining
and quarrying, manufacturing, construction, transport,
services
Unemployment rate: 7.7%; extensive
underemployment (1997)
Budget:
revenues: $8.5 billion
expenditures: $9.3 billion, including capital
expenditures of $2 billion (1996 est.)
Industries: mining of metals, petroleum, fishing,
textiles, clothing, food processing, cement, auto
assembly, steel, shipbuilding, metal fabrication
Industrial production growth rate: 8.5%
(2000 est.)
Electricity - production: 18.886 billion kWh (1999)
Electricity - production by source:
fossil fuel: 23.04%
hydro: 76.43%
nuclear: 0%
ote 0.53% (1999)
Electricity ■ consumption: 17.565 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 1 million kWh (1999)
Agriculture ■ products: coffee, cotton, sugarcane,
rice, wheat, potatoes, plantains, coca; poultry, beef,
dairy products, wool; fish
Exports: $7 billion (f.o.b., 2000 est.)
Exports ■ commodities: fish and fish products,
copper, zinc, gold, crude petroleum and byproducts,
lead, coffee, sugar, cotton
Exports - partners: US 29%, EU 25%, Andean
Community 6%, Japan 4%, Mercosur 3% (1999)
imports: $7.4 billion (f.o.b., 2000 est.)
Imports ■ commodities: machinery, transport
equipment, foodstuffs, petroleum. Iron and steel,
chemicals, pharmaceuticals
Imports - partners: US 32%, EU 21%, Andean
Community 6%, Mercosur 8%, Japan 5% (1999)
Debt - external: $31 billion (2000 est.)
Economic aid ■ recipient: $895.1 million (1995)
Currency: nuevo sol (PEN)
Currency code: PEN
Exchange rates: nuevo sol per US dollar - 3.5230
(January 2001), 3.4900 (2000), 3.383 (1999), 2.930
(1998), 2.664 (1997), 2.453(1996)
Fiscal year: calendar year','035e41296207eb8f64a39b2270fd47856cc63553a549d4b881483a5505ba5f36','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f039bbce91d7fbb84a7be3adf99630685995e79766744d13f2c310799e7f6df0',2001,'EG','Egypt','economy',408,'Economy - overview: A series of IMF
arrangements - along with massive external debt
relief resulting from Egypt''s participation in the Gulf
war coalition - helped Egypt improve its
macroeconomic performance during the 1990s.
Sound fiscal and monetary policies through the
mid-1990s helped to tame inflation, slash budget
deficits, and build up foreign reserves, while structural
reforms such as privatization and new business
legislation prompted increased foreign investment. By
mid-1998, however, the pace of structural reform
slackened, and lower combined hard currency
earnings resulted in pressure on the Egyptian pound
and sporadic US dollar shortages. External payments
were not in crisis, but Cairo''s attempts to curb demand
for foreign exchange convinced some investors and
currency traders that government financial operations
lacked transparency and coordination. Monetary
pressures have since eased, however, with the
1 999-2000 higher oil prices, a rebound in tourism, and
a series of mini-devaluations of the pound. The
development of a gas export market is a major plus
factor in future growth.
GDP: purchasing power parity - $247 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $3,600
(2000 est.)
GDP - composition by sector:
agriculture: 17%
industry: 32%
serv/ces; 51% (1999)
Population below poverty line: 22.9% (FY95/
96 est.)
Household income or consumption by percentage
share:
lowest 10%: 4.4%
/?/g/7esf )0%;25%(1995)
Inflation rate (consumer prices): 3% (2000)
Labor force: 19.9 million (2000 est.)
Labor force - by occupation; agriculture 29%,
services 49%, industry 22% (FY99)
Unemployment rate: 1 1 .5% (2000 est.)
Budget:
revenues; $22.6 billion
expenditures: $26.2 billion, including capital
expenditures of $NA (FY99)
Industries: textiles, food processing, tourism,
chemicals, hydrocarbons, construction, cement,
metals
industrial production growth rate: 2.1%
(2000 est.)
Electricity ■ production: 64.685 billion kWh (1999)
Electricity - production by source:
fossil fuel: 70.59%
hydro: 23.41%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 60.157 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cotton, rice, corn, wheat,
beans, fruits, vegetables; cattle, water buffalo, sheep,
goats
Exports; $7.3 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil and petroleum
products, cotton, textiles, metal products, chemicals
Exports - partners; EU 35%, Middle East 17%,
Afro-Asian countries 14%, US 12% (1999)
Imports: $17 billion (f.o.b., 2000 est.)
Imports - commodities; machinery and equipment,
foodstuffs, chemicals, wood products, fuels
Imports - partners: EU 36%, US 14%, Afro-Asian
countries 14%, Middle East 6% (1999)
Debt - external: $31 billion (2000 est.)
Economic aid ■ recipient: ODA, $2.25 billion (1 999)
Currency: Egyptian pound (EGP)
Currency code: EGP
Exchange rates: Egyptian pounds per US dollar -
market rate - 3.8400 (January 2001), 3.6900 (2000),
3.4050 (1999), 3.3880 (1998), 3.3880 (1997), 3.3880
(1996)
Fiscal year: 1 July - 30 June','713b1b020b63893b8880cab40617f0896fb04c5e10d947979a36eb2424bfa48b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c334e2bc787fcbd6debf5e4914b6aef26fc70461e9fb7325d9818495c988245',2001,'SV','El Salvador','economy',417,'Economy - overview: El Salvador is a struggling
Central American economy which has been suffering
from a weak tax collection system, factory closings,
the aftermaths of Hurricane Mitch of 1998 and the
devastating earthquakes of early 2001 , and weak
world coffee prices. On the bright side, in recent years
inflation has fallen to single digit levels, and total
exports have grown substantially. The trade deficit
has been offset by remittances (an estimated $1.6
billion in 2000) from Salvadorans living abroad and by
external aid. As of 1 January 2001 , the US dollar was
made legal tender alongside the colon.
GDP: purchasing power parity - $24 billion
(2000 est.)
GDP “ real growth rate: 2.5% (2000 est.)
GDP - per capita: purchasing power parity - $4,000
(2000 est.)
GDP - composition by sector:
agriculture: 12%
industry: 28%
services: 60% (1999 est.)
Population below poverty line: 48% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 1.2%
highest 10%: 38.3% (im)
153
El Salvador (continued)
Inflation rate (consumer prices): 2.5% (2000 est.)
Labor force: 2.35 million (1999)
Labor force - by occupation: agriculture 30%,
industry 15%, services 55% (1999 est.)
Unemployment rate: 10% (2000 est.)
Budget:
revenues; $1.8 billion
expenditures: $22 billion, including capital
expenditures of $NA (1 999 est.)
Industries: food processing, beverages, petroleum,
chemicals, fertilizer, textiles, furniture, light metals
Industrial production growth rate: 5% (2000 est.)
Electricity - production: 3.641 billion kWh (1999)
Electricity - production by source:
fossil fuel: 45,65%
hydro; 41.01%
nuclear: 0%
other: 13.34% (1999)
Electricity - consumption: 3.638 billion kWh (1999)
Electricity - exports: 208 million kWh (1999)
Electricity - imports: 460 million kWh (1999)
Agriculture - products: coffee, sugar, corn, rice,
beans, oilseed, cotton, sorghum; shrimp; beef, dairy
products
Exports: $2.8 billion (f.o.b., 2000)
Exports - commodities: offshore assembly exports,
coffee, sugar, shrimp, textiles, chemicals, electricity
Exports - partners: US 63%, Guatemala 11%,
Honduras 7%, Costa Rica 4% (1999)
Imports: $4.6 billion (f.o.b., 2000)
Imports - commodities: raw materials, consumer
goods, capital goods, fuels, foodstuffs, petroleum,
electricity
Imports - partners: US 52%, Guatemala 9%,
Mexico 6%, Costa Rica 3% (1999)
Debt - external: $4.1 billion (2000 est.)
Economic aid ■ recipient: total $252 million; $57
million from US (1999 est.)
Currency: Salvadoran colon (SVC); US dollar (USD)
Currency code: SVC; USD
Exchange rates: Salvadoran colones per US dollar -
8.755 (fixed rate since 1993)
Fiscal year: calendar year','f0cca1944a9f3d2097bb3a8d552cd3074b186a3f61906cda5bf63ba19f337d95','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f484fb41b7bfc63fd6263cf4b4280cc4c9724b5f37f89f79681bdd6d6496930e',2001,'GN','Guinea','economy',426,'Economy - overview: The discovery and
exploitation of large oil reserves have contributed to
dramatic economic growth in recent years. Forestry,
farming, and fishing are also major components of
GDP. Subsistence farming predominates. Although
pre-independence Equatorial Guinea counted on
cocoa production for hard currency earnings, the
deterioration of the rural economy under successive
brutal regimes has diminished potential for
agriculture-led growth. A number of aid programs
sponsored by the World Bank and the IMF have been
cut off since 1993 because of the government''s gross
corruption and mismanagement. Businesses, for the
most part, are owned by government officials and their
family members. Undeveloped natural resources
include titanium, iron ore, manganese, uranium, and
alluvial gold. The country responded favorably to the
devaluation of the CFA franc in January 1 994. Boosts
in production and high world oil prices stimulated
growth in 2000, with oil accounting for 90% of greatly
increased exports.
GDP: purchasing power parity - $960 million
(2000 est.)
GDP - real growth rate: 12% (2000 est.)
GDP - per capita: purchasing power parity - $2,000
(2000 est.)
155
Equatorial Guinea (continued)
GDP - composition by sector:
agriculture: 20%
industry: 60%
services: 20% (1999 est.)
Popuiation below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 6% (1999 est.)
Labor force: NA
Unemployment rate: 30% (1998 est.)
Budget:
revenues: $47 million
expenditures: $43 million, including capital
expenditures of $7 million (1996 est.)
Industries: petroleum, fishing, sawmilling, natural
gas
Industrial production growth rate: 7.4%
(1994 est.)
Electricity -production: 21 million kWh (1999)
Electricity - production by source:
foss/7 fue/.'' 85.71%
hydro: 14.29%
nuclear: 0%
ofoer; 0% (1999)
Electricity - consumption: 19.5 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coffee, cocoa, rice, yams,
cassava (tapioca), bananas, palm oil nuts; livestock;
timber
Exports: $860 million (f.o.b., 2000 est.)
Exports - commodities: petroleum, timber, cocoa
Exports - partners: US 62%, Spain 1 7%, China 9%,
France 3%, Japan 3%, (1997)
Imports: $300 million (f.o.b., 1999)
Imports - commodities: manufactured goods and
equipment
Imports - partners: US 35%, France 15%, Spain
10%, Cameroon 10%, UK 6% (1997)
Debt ■ external: $290 million (1999 est.)
Economic aid - recipient: $33.8 million (1995)
Currency: Communaute Financiere Africaine franc
(XAF): note - responsible authority is the Bank of the
Central African States
Currency code: XAF
Exchange rates: Communaute Financiere Africaine
francs (XAF) per US dollar - 699.21 (January 2001 ),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1997), 511.55 (1996): note - from 1 January 1999,
the XAF is pegged to the euro at a rate of 655.957
XAF per euro
Fiscal year: 1 April - 31 March
Economy - overview: With independence from
Ethiopia on 24 May 1993, Eritrea faced the economic
problems of a small, desperately poor country. The
economy is largely based on subsistence agriculture,
with 80% of the population involved in farming and
herding. The small industrial sector consists mainly of
light industries with outmoded technologies. Domestic
output (GDP) is substantially augmented by worker
remittances from abroad. Government revenues
come from custom duties and taxes on income and
sales. Road construction is a top domestic priority. In
the long term, Eritrea may benefit from the
development of offshore oil, offshore fishing, and
tourism. Eritrea''s economic future depends on its
ability to master fundamental social and economic
problems, e.g., by reducing illiteracy, promoting job
creation, expanding technical training, attracting
foreign investment, and streamlining the bureaucracy.
Eritrea''s agriculture over the last two years was
severely weakened by war and drought, and many
farmlands must wait to be demined. Another major
difficulty is the ports, which prior to the war were
Ethiopia''s preferred outlets but since have seen trade
dry up.
GDP: purchasing power parity - $2.9 billion
(2000 est.)
GDP - real growth rate: -1% (2000 est.)
GDP - per capita: purchasing power parity - $710
(2000 est.)
GDP ■ composition by sector:
agriculture: 18%
industry: 27%
services: 57% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 14% (2000 est.)
Labor force: NA
Labor force ■ by occupation: agriculture 80%,
industry and services 20%
Unemployment rate: NA%
Budget:
revenues: $283.9 million
expenditures: $851. 8 million, including capital
expenditures of $NA (1 997 est.)
Industries: food processing, beverages, clothing
and textiles
Industrial production growth rate: NA%
Electricity - production: 165 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity ■ consumption: 153.5 million kWh
(1999)
Electricity - exports: 0 kWh NA kWh (1999)
Electricity - imports: 0 kWh NA kWh (1999)
Agriculture - products: sorghum, lentils,
vegetables, corn, cotton, tobacco, coffee, sisal;
livestock, goats; fish
Exports: $26 million (f.o.b., 1999)
Exports - commodities: livestock, sorghum,
textiles, food, small manufactures
Exports - partners: Sudan 27.2%, Ethiopia 26.5%,
Japan 13.2%, UAE 7.3%, Italy 5.3% (1998)
Imports: $560 million (c.i.f., 1999)
Imports - commodities: machinery, petroleum
products, food, manufactured goods
imports - partners: Italy 17.4%, UAE 16.2%,
Germany 5.7%, UK 4.5%, Korea 4.4% (1998)
Debt ■ external: $281 million (2000 est.)
Economic aid - recipient: $77 million (1999)
Currency: nakfa (ERN)
Currency code: ERN
Exchange rates: nakfa per US dollar = 9.5 (January
2000), 7.6 (January 1999), 7.2 (March 1998 est.)
Fiscal year: calendar year
Economy - overview: Guinea possesses major
mineral, hydropower, and agricultural resources, yet
remains a poor underdeveloped nation. The country
possesses over 30% of the world''s bauxite reserves
and is the second largest bauxite producer. The
mining sector accounted for about 75% of exports in
1999. Long-run improvements in government fiscal
arrangements, literacy, and the legal framework are
needed if the country is to move out of poverty. The
government made encouraging progress in budget
management in 1997-99, and reform progress was
praised in the World Bank/IMF October 2000
assessment. However, escalating fighting along the
Sierra Leonean and Liberian borders will cause major
economic disruptions. In addition to direct defense
costs, the violence has led to a sharp decline in
investor confidence. Foreign mining companies have
reduced expatriate staff, while panic buying has
created food shortages and inflation in local markets.
Real GDP growth is expected to fall to 2% in 2001 .
GDP: purchasing power parity - $10 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,300
(2000 est.)
GDP - composition by sector:
agriculture: 22.3%
industry: 35.3%
services: 42.4% (1998 est.)
Population below poverty line: 40% (1994 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.0%
highest 10%: 32% (1994)
Inflation rate (consumer prices): 6% (2000 est.)
Labor force: 3 million (1999)
Labor force - by occupation: agriculture 80%,
industry and services 20% (2000 est.)
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $4M. 7 million, including capital
expenditures of $NA million (2000 est.)
Industries: bauxite, gold, diamonds; alumina
refining; light manufacturing and agricultural
processing industries
Industrial production growth rate: 3.2% (1994)
Electricity - production: 750 million kWh (1999)
Electricity - production by source:
foss//te/; 46.67%
hydro: 53.33%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 697.5 million kWh
(1999)
Electricity ■ exports: 0 kWh (1 999)
Electricity ■ imports: 0 kWh (1 999)
Agriculture - products: rice, coffee, pineapples,
palm kernels, cassava (tapioca), bananas, sweet
potatoes; cattle, sheep, goats; timber
Exports: $820 million (f.o.b., 2000 est.)
Exports - commodities: bauxite, alumina, gold,
diamonds, coffee, fish, agricultural products
Exports - partners: US, Benelux, Ukraine, Ireland
(1999)
Imports: $634 million (f.o.b., 2000 est.)
Imports - commodities: petroleum products,
metals, machinery, transport equipment, textiles,
grain and other foodstuffs
Imports - partners: France, Belgium, US, Cote
d''Ivoire (1999)
Debt - external: $3.6 billion (1999 est.)
212
Guinea (continued)
Economy - overview: Papua New Guinea is richly
endowed with natural resources, but exploitation has
been hampered by the rugged terrain and the high
cost of developing infrastructure. Agriculture provides
a subsistence livelihood for 85% of the population.
Mineral deposits, including oil, copper, and gold,
account for 72% of export earnings. The 3.4%
average annual growth rate of GDP during 1 979-1998
conceals considerable year-to-year variation resulting
from external economic shocks, natural disasters, and
economic management problems. There has been
little growth in the last half of the 1 990s, with real GDP
in 1999 barely 3% higher than in 1994, not enough to
compensate for population growth. A new
administration under the leadership of Prime Minister
Mekere MORAUTA in July 1999 has promised to
restore integrity to state institutions, to stabilize the
kina, to restore stability to the national budget, to
privatize public enterprises where appropriate, and to
ensure ongoing peace on Bougainville. The
government has had considerable success in
attracting international support, specifically gaining
the support of the IMF and the World Bank in securing
development assistance loans. Significant challenges
remain for MORAUTA, however, including gaining
further investor confidence, specifically for the
proposed Papua New Guinea-Australia oil pipeline,
continuing efforts to privatize government assets, and
in maintaining the support from members of
Parliament who after 15 July 2001 can dismiss him
with a vote of no-confidence.
GDP: purchasing power parity - $12.2 billion
(2000 est.)
GDP - real growth rate: 2.9% (2000 est.)
GDP - per capita: purchasing power parity - $2,500
(2000 est.)
GDP - composition by sector:
agriculture: 30%
industry: 35%
services: 35% (1999 est.)
Popuiation beiow poverty line: 37%
Househoid income or consumption by percentage
share:
lowest 10%: 7%
highest 10%: 40.5% {me)
Inflation rate (consumer prices): 17% (2000 est.)
Labor force: 1.941 million
Labor force - by occupation: agriculture 85%,
industry NA%, services NA%
Unemployment rate: NA%
Budget:
revenues: $1 .6 billion
expenditures: $1 .9 billion, including capital
expenditures of $NA (1998 est.)
Industries: copra crushing, palm oil processing,
plywood production, wood chip production; mining of
gold, silver, and copper; crude oil production;
construction, tourism
Industrial production growth rate: NA%
Electricity - production: 1 .82 billion kWh (1999)
Electricity - production by source:
fossil fuel: 54.95%
hydro; 45.05%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 1 .693 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coffee, cocoa, coconuts,
palm kernels, tea, rubber, sweet potatoes, fruit,
vegetables; poultry, pork
Exports: $2.1 billion (f.o.b., 2000 est.)
Exports - commodities: oil, gold, copper ore, logs,
palm oil, coffee, cocoa, crayfish, prawns
Exports - partners: Australia 30%, Japan 12%,
Germany 7%, South Korea 4%, Philippines 3%, UK
3% (1999)
Imports: $1 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment, manufactured goods, food, fuels,
chemicals
Imports - partners: Australia 53%, Singapore 13%,
Japan 6%, US 4%, New Zealand 4%, Malaysia 4%
(1999)
Debt - external: $2.9 billion (2000 est.)
Economic aid - recipient: $400 million (1999 est.)
Currency: kina(PGK)
Currency code: PGK
Exchange rates: kina per US dollar ■ 2.81 (October
2000), 2.696 (2000), 2.539 (1999), 2.058 (1998),
1.434(1997), 1.318(1996)
Fiscal year: calendar year','1e194a6ba840375612197dfa081399da290cd26e608a3ef64fd1bf265b115000','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d65d8bc6b5dd5e0f993693779ab40b8016ad7e8d328685f575c0dd54e6fb45a8',2001,'EE','Estonia','economy',438,'Economy - overview: In 2000, Estonia rebounded
from the Russian financial crisis by scaling back Its
budget and reorienting trade away from Russian
markets into EU member states. After GDP shrank
1.1% in 1999, the economy made a strong recovery in
2000, with growth estimated at 6.4% - the highest in
Central and Eastern Europe. Estonia joined the World
Trade Organization in November 1999 - the second
Baltic state to join - and continues its EU accession
talks. For 2001, Estonians predict GDP to grow
around 6%, inflation of between 4.2%-5.3%, and a
balanced budget. Substantial gains were made in
completing privatization of Estonia''s few remaining
large, state-owned companies in 2000, and this
momentum is expected to continue in 2001 . Estonia
hopes to join the EU during the next round of
enlargement tentatively set for 2004.
GDP: purchasing power parity - $14.7 billion
(2000 est.)
GDP - real growth rate: 6.4% (2000 est.)
GDP - per capita: purchasing power parity -
$10,000 (2000 est.)
GDP - composition by sector:
agriculture: 3.6%
industry: 30.7%
serv/ces; 65.7% (1999)
Population below poverty line: 8.9% (1995 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.2%
highest 70%; 28.5% (1996)
Inflation rate (consumer prices): 4.1% (1999 est.)
Labor force: 785,500 (1999 est.)
Labor force - by occupation: industry 20%,
agriculture 11%, services 69% (1999 est.)
Unemployment rate; 1 1 .7% (1 999 est.)
Budget;
revenues: $1 .37 billion
expenditures: $1.37 billion, including capital
expenditures of $NA (1997 est.)
Industries: oil shale, shipbuilding, phosphates,
electric motors, excavators, cement, furniture,
clothing, textiles, paper, shoes, apparel
Industrial production growth rate; 5% (2000 est.)
Electricity - production: 7.782 billion kWh (1999)
Electricity - production by source;
fossil fuel: 99.72%
hydro: 0.09%
nuclear: 0%
other: 0.19% (1993)
Electricity - consumption: 6.807 billion kWh (1 999)
Electricity - exports: 530 million kWh (1999)
Electricity - imports: 100 million kWh (1999)
Agriculture ■ products: potatoes, fruits, vegetables;
livestock and dairy products; fish
Exports: $3.1 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment
24%, wood products 20%, textiles 17%, food products
9%, metals, chemical products (1999)
Exports - partners: Finland 19.4%, Sweden 18.8%,
Russia 9.2%, Latvia 8.7%, Germany 7.5%, US 2.5%
(1999)
Imports: $4 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment
31%, chemical products 13%, foodstuffs 11%, metal
products 8%, textiles 8% (1999)
Imports - partners: Finland 22.8%, Russia 13.5%,
Sweden 9.3%, Germany 9.3%, Japan 4.7% (1999)
Debt - external: $1 .6 billion (2000 est.)
Economic aid ■ recipient: $137.3 million (1995)
Currency: Estonian kroon (EEK)
Currency code: EEK
Exchange rates: krooni per US dollar - 16.663
(January 2001), 16.969 (2000), 14.678(1999), 14.075
(1998), 13.882 (1997), 12.034 (1996); note - krooni
are tied to the German deutsche mark at a fixed rate
of8to1
Fiscal year: calendar year','e722054b4a943331ac41c7c66b70ae534678e8e434eb831557d88b7877a9119e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d7bc88924074cc6f75a5f0ab2550f010fd297897ae30a1eb52538079064290f',2001,'FO','Faroe Islands','economy',446,'Economy - overview: The Faroese economy has
had a strong performance since 1994, mostly as a
result of increasing fish landings and high and stable
export prices. Unemployment is falling and there are
signs of labor shortages in several sectors. The
positive economic development has helped the
Faroese Home Rule Government produce increasing
budget surpluses which in turn help to reduce the
large public debt, most of it owed to Denmark.
However, the total dependence on fishing makes the
Faroese economy extremely vulnerable, and the
present fishing efforts appear in excess of what is
required to ensure a sustainable level of fishing in the
long term. Oil finds close to the Faroese area give
hope for deposits in the immediate Faroese area,
which may eventually lay the basis for a more
diversified economy and thus less dependence on
Denmark and Danish economic assistance. Aided by
a substantial annual subsidy (15% of GDP) from
Denmark, the Faroese have a standard of living not far
below the Danes and other Scandinavians.
GDP: purchasing power parity - $91 0 million
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity -
$20,000 (2000 est.)
GDP ■ composition by sector:
agriculture: 27%
industry: 11%
sen/ices: 62% (1 999)
Population below poverty line: NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Infiation rate (consumer prices); 5.1% (1999)
Labor force: 24,250 (October 2000)
Labor force - by occupation: fishing, fish
processing, and manufacturing, construction and
private services, public services
Unemployment rate: 1% (October 2000)
Budget:
revenues; $488 million
expenditures: $484 million, including capital
expenditures of $21 million (1999)
Industries: fishing, fish processing, shipbuilding,
construction, handicrafts
Industrial production growth rate: 8% (1999 est.)
Electricity - production: 170 million kWh (1999)
Electricity - production by source:
fossil fuel: 58.82%
hydro; 41.18%
nuclear: 0%
other: 0% (1999)
Electricity - consumption; 158.1 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: milk, potatoes, vegetables;
sheep; salmon, other fish
Exports: $471 million (f.o.b., 1999)
Exports - commodities: fish and fish products 94%,
stamps, ships (1999)
Exports ■ partners: Denmark 32%, UK 21%, France
9%, Germany 7%, Iceland 5%, US 5% (1996)
Imports: $469 million (c.i.f., 1999)
Imports - commodities: machinery and transport
equipment 29%, consumer goods 36%, raw materials
and semi-manufactures 32%, fuels, fish and salt
(1999)
Imports - partners: Denmark 28%, Norway 26%,
Germany 7%, UK 6% Sweden 5%, Iceland 4%, US
(1999)
Debt - external: $64 million (1999)
Economic aid - recipient: $135 million (annual
subsidy from Denmark) (1999)
Currency: Danish krone (DKK)
Currency code: DKK
Exchange rates: Danish kroner per US dollar -
7.951 (January 2001), 8.093 (2000), 6.976 (1999),
6.701 (1998), 6.604 (1997), 5.799 (1966)
Fiscal year; calendar year','41b695e316a7da6c1a972449733ab205c5d3e729f1c93ba6c967a8715327c7f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ba3448cde474a7a0c52540d80b70e7862e62889f54633d043e0608edff9605d',2001,'JE','Jersey','economy',458,'Economy - overview; Fiji, endowed with forest,
mineral, and fish resources, is one of the most
developed of the Pacific island economies, though still
with a large subsistence sector. Sugar exports and a
growing tourist industry are the major sources of
foreign exchange. Sugar processing makes up
one-third of industrial activity. Roughly 300,000
tourists visit each year, including thousands of
Americans following the start of regularly scheduled
non-stop air service from Los Angeles. Fiji''s growth
slowed in 1997 because the sugar industry suffered
from low world prices and rent disputes between
farmers and landowners. Drought in 1998 further
damaged the sugar industry, but its recovery in 1999
contributed to robust GDP growth. Long-term
problems include low investment and uncertain
property rights. The political turmoil in Fiji has had a
severe impact with the economy shrinking by 8% in
1 999 and over 7,000 people losing their jobs. The
interim government''s 2001 budget is an attempt to
attract foreign investment and restart economic
activity. The government''s ability to manage the
budget and fulfill predictions of 4% growth for 2001 will
depend on a return to stability, a regaining of investor
confidence, and the absence of international
sanctions (which could cripple Fiji''s sugar and textile
Industry).
GDP: purchasing power parity - $5.9 billion
(1999 est.)
GDP - real growth rate: -8% (1999 est.)
GDP - per capita: purchasing power parity - $7,300
(1999 est.)
GDP - composition by sector:
agriculture: 16%
industry: 30%
services: 54% (1999 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 0% (1999 est.)
Labor force: 235,000
169
Fiji (continued)
Labor force - by occupation: subsistence
agriculture 67%, wage earners 18%, salary earners
15% (1987)
Unemployment rate: 6%(1997est.)
Budget:
revenues: $610 million
expenditures: $501 million, including capital
expenditures of $NA (1999 est.)
Industries: tourism, sugar, clothing, copra, gold,
silver, lumber, small cottage industries
Industrial production growth rate: 2.9% (1995)
Electricity - production: 510 million kWh (1999)
Eiectricity - production by source:
fossil fuel: 17.65%
hydro: 82.35%
nuclear: 0%
other: 0%(im)
Eiectricity - consumption: 474.3 million kWh
(1999)
Eiectricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: sugarcane, coconuts,
cassava (tapioca), rice, sweet potatoes, bananas;
cattle, pigs, horses, goats; fish
Exports: $537 million (f.o.b., 1999)
Exports ■ commodities: sugar, garments, gold,
timber, fish
Exports - partners: Australia 33.1%, US 14.8%, UK
13.8%, other Pacific island countries 8.8%, NZ 4.5%,
Japan 4.5% (1999)
Imports: $653 million (f.o.b., 1999)
Imports - commodities: manufactured goods,
machinery and transport equipment, petroleum
products, food, chemicals
Imports - partners: Australia 41.9%, US 14%, NZ
13.3%, Japan 4.8%, Taiwan 1.9% (1999)
Debt - external: $193 million (1998)
Economic aid - recipient: $40.3 million (1995)
Currency: Fijian dollar (FJD)
Currency code: FJD
Exchange rates: Fijian dollars per US dollar -
2.1814(January 2001), 2.1286(2000), 1.9696(1999),
1.9868 (1998), 1.4437 (1997), 1.4033 (1996)
Fiscal year: calendar year
Economy - overview: Finland has a highly
industrialized, largely free-market economy, with per
capita output roughly that of the UK, France,
Germany, and Italy. Its key economic sector is
manufacturing - principally the wood, metals,
engineering, telecommunications, and electronics
industries. Trade is important, with exports equaling
more than one-third of GDP. Except for timber and
several minerals, Finland depends on imports of raw
materials, energy, and some components for
manufactured goods. Because of the climate,
agricultural development is limited to maintaining
self-sufficiency in basic products. Forestry, an
important export earner, provides a secondary
occupation for the rural population. Rapidly increasing
integration with Western Europe - Finland was one of
the 1 1 countries joining the euro monetary system
(EMU) on 1 January 1999 - will dominate the
economic picture over the next several years. Growth
in 2001 will be bolstered by strong private
consumption, yet may be 1 or 2 points lower than in
2000, largely because of a weakening in export
demand.
GDP: purchasing power parity - $1 18.3 billion
(2000 est.)
GDP - real growth rate: 5.6% (2000 est.)
GDP - per capita: purchasing power parity -
$22,900 (2000 est.)
GDP ■ composition by sector:
agriculture: 3.5%
industry: 29%
services: 67.5% (1 999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 4.2%
highest f0%;21.6% (1991)
Inflation rate (consumer prices): 3.4% (2000 est.)
Labor force: 2.6 million (2000 est.)
Labor force ■ by occupation: public services 32%,
industry 22%, commerce 14%, finance, insurance, and
business services 10%, agriculture and forestry 8%,
transport and communications 8%, construction 6%
Unemployment rate: 9.8% (2000 est.)
Budget:
revenues; $36.1 billion
expenditures: $31 billion, including capital
expenditures of $NA (2000 est.)
Industries: metal products, shipbuilding, pulp and
paper, copper refining, foodstuffs, chemicals, textiles,
clothing
Industrial production growth rate: 7.5% (2000)
Electricity - production: 75.792 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 41 .88%
hydro: 16.77%
nuclear: 28.82%
ofoer; 12.53% (1999)
Electricity - consumption: 81 .61 1 billion kWh (1 999)
Electricity - exports: 232 million kWh (1999)
Electricity - Imports: 1 1 .356 billion kWh (1999)
Agriculture - products: cereals, sugar beets,
potatoes; dairy cattle; fish
Exports: $44.4 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment,
chemicals, metals; timber, paper, pulp
Exports ■ partners: EU 58% (Germany 13%,
Sweden 10%, UK 9%, France 5%, Netherlands 4%),
US 8%, Russia, Japan (1999)
Imports: $32.7 billion (f.o.b., 2000)
Imports ■ commodities: foodstuffs, petroleum and
petroleum products, chemicals, transport equipment,
iron and steel, machinery, textile yarn and fabrics, grains
Imports - partners: EU 60% (Germany 15%,
Sweden 1 1 %, UK 7%), US 8%, Russia 7%, Japan 6%
(1999)
Debt - external: $30 billion (December 1993)
Economic aid - donor: ODA, $379 million (1997)
Currency: markka (FIM); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Finland at a fixed rate of
5.94573 markkaa per euro and will replace the local
currency for all transactions in 2002
Currency code: FIM; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999);
markkaa per US dollar - 5.3441 (1 998), 5.1914
(1997), 4.5936 (1996)
Fiscal year: calendar year
Economy - overview: Kuwait is a small, relatively
open economy with proved crude oil reserves of
about 94 billion barrels - 10% of world reserves.
Petroleum accounts for nearly half of GDP, 90% of
export revenues, and 75% of government income.
Kuwait''s climate limits agricultural development.
Consequently, with the exception of fish, it depends
almost wholly on food imports. About 75% of potable
water must be distilled or imported. Higher oil prices
put the FY99/00 budget into a $2 billion surplus. The
FYOO/01 budget covers only nine months because of
a change in the fiscal year. The budget for FY01/02,
which begins 1 April, contains higher expenditures
for salaries, construction, and other general
categories. Kuwait continues its discussions with
foreign oil companies to develop fields in the northern
part of the country.
GDP: purchasing power parity - $29.3 billion
(2000 est.)
GDP - real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity -
$15,000 (2000 est.)
GDP - composition by sector:
agriculture: 0%
industry: 55%
semces;45%(1996)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3% (2000)
Labor force: 1 .3 million (1 998 est.)
note: 68% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 1 .8% (official 1996 est.)
Budget:
revenues: $1 1 .5 billion
expenditures: $17.2 billion, including capital
expenditures of $NA (FY01/02)
Industries: petroleum, petrochemicals, desalination,
food processing, construction materials
Industrial production growth rate: 1% (1997 est.)
Electricity - production: 31 .567 billion kWh (1999)
Electricity > production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 29.357 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: practically no crops; fish
Exports: $23.2 billion (f.o.b., 2000 est.)
Exports - commodities: oil and refined products,
fertilizers
Exports - partners: Japan 23%, US 12%,
Singapore 8%, Netherlands 7% (1999)
Imports: $7.6 billion (f.o.b., 2000 est.)
Imports - commodities: food, construction
materials, vehicles and parts, clothing
Imports - partners: US 15%, Japan 10%, UK 7%,
Germany 7% (1999)
Debt - external: $6.9 billion (2000 est.)
Economic aid - recipient: $27.6 million (1995)
Currency: Kuwaiti dinar (KWD)
Currency code: KWD
Exchange rates: Kuwaiti dinars per US dollar -
0.3057 (January 2001), 0.3067 (2000), 0.3044 (1999),
0.3047 (1998), 0.3033 (1997), 0.2994 (1996)
Fiscal year: 1 April - 31 March
Economy - overview: New Caledonia has more
than 20% of the world''s known nickel resources. In
recent years, the economy has suffered because of
depressed international demand for nickel, the
principal source of export earnings. Only a negligible
amount of the land is suitable for cultivation, and food
accounts for about 20% of imports. In addition to
nickel, the substantial financial support from France
and tourism are keys to the health of the economy.
The situation in 1998 was clouded by the spillover of
financial problems in East Asia and by lower prices for
nickel. Nickel prices jumped in 1999-2000, and large
additions were made to capacity. French Government
interests in the New Caledonian nickel industry are
being transferred to local ownership.
GDP: purchasing power parity - $3 billion (1 998 est.)
GDP - real growth rate: 3.5% (1 998 est.)
GDP ■ per capita: purchasing power parity -
$15,000 (1998 est.)
GDP - composition by sector:
agriculture: 4%
industry: 30%
services: 66% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .5% (1 998 est.)
Labor force: 79,395 (including 15,018 unemployed,
1996)
Labor force - by occupation: agriculture 7%,
industry 23%, services 70% (1999 est.)
Unemployment rate: 19% (1996)
Budget:
revenues; $861 .3 million
expenditures: p35. 3 million, including capital
expenditures of $52 million (1996 est.)
Industries: nickel mining and smelting
Industrial production growth rate: -0.6% (1996)
Electricity - production: 1 .52 billion kWh (1999)
365
N6W CaiGdonia (continued)
Electricity - production by source:
fossil fuel: 78.95%
hydro: 2^.05%
nuclear: 0%
other: 0%(^999)
Electricity - consumption: 1 .41 4 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: vegetables; beef, deer,
other livestock products
Exports: $411 million (f.o.b., 1999)
Exports - commodities: ferronickels, nickel ore, fish
Exports - partners: Japan 27%, France 17%,
Taiwan 12%, South Korea 9% (1999)
Imports: $843 million (f.o.b., 1999)
Imports ■ commodities: transport equipment,
machinery and electrical equipment, fuels, minerals,
wine, sugar, rice
Imports - partners: France 49%, Australia 14%,
Singapore 6%, New Zealand 5%, US 5% (1999)
Debt ■ external: $79 million (1998 est.)
Economic aid - recipient: $880 million annual
subsidy from France
Currency: Comptoirs Francais du Pacifique franc
(XPF)
Currency code: XPF
Exchange rates: Comptoirs Francais du Pacifique
francs (XPF) per US dollar - 127.11 (January 2001),
1 29.44 (2000), 1 1 1 .93 (1 999), 1 07.25 (1 998), 1 06. 1 1
(1997), 93.00 (1996); note - linked at the rate of
119.25 XPF to the euro
Fiscal year: calendar year
Economy - overview: Although Slovenia enjoys
one of the highest GDPs per capita among the
transition economies of Central Europe, it needs to
speed up the privatization process and the
dismantling of restrictions on foreign investment.
About 45% of the economy remains in state hands,
and the level of foreign direct investment inflows as a
percent of GDP is the lowest in the region. Analysts
are predicting between 4.0% and 4.2% growth for
2001 . Export growth is expected to slow in 2001 and
2002 as EU markets soften. Inflation rose from 6.1%
to 8.9% in 2000 and remains a matter of concern.
GDP: purchasing power parity - $22.9 billion
(2000 est.)
GDP - real growth rate: 4.5% (2000 est.)
GDP - per capita: purchasing power parity -
$12,000 (2000 est.)
GDP - composition by sector:
agriculture: 4%
industry: 35%
services: 61% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3.2%
highest 20.7% (1995)
Inflation rate (consumer prices): 8.9% (2000 est.)
Labor force: 857,400
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate; 7.1% (1997 est.)
Budget:
revenues: billion
expenditures: $3.32 billion, including capital
expenditures of $NA (1997 est.)
Industries: ferrous metallurgy and rolling mill
products, aluminum reduction and rolled products,
lead and zinc smelting, electronics (including military
electronics), trucks, electric power equipment, wood
products, textiles, chemicals, machine tools
Industrial production growth rate: 6.2% (2000)
Electricity - production: 12.451 billion kWh (1999)
Electricity - production by source:
foss/''/fue/; 34.44%
hydro: 29.53%
nuclear: 35.98%
other; 0% (1999)
Electricity - consumption: 1 0.024 billion kWh
(1999)
Electricity - exports: 2.2 billion kWh (1999)
Electricity ■ imports: 645 million kWh (1999)
Agriculture - products: potatoes, hops, wheat,
sugar beets, corn, grapes; cattle, sheep, poultry
Exports: $8.9 billion (f.o.b., 2000)
Exports - commodities: manufactured goods,
machinery and transport equipment, chemicals, food
Exports - partners: Germany 31%, Italy 14%,
Croatia 8%, Austria 7%, France 6% (1999)
Imports: $9.9 billion (f.o.b., 2000)
458
Slovenia (continued)
Imports - commodities: machinery and transport
equipment, manufactured goods, chemicals, fuels
and lubricants, food
Imports - partners: Germany 21%, Italy 17%,
France 11%, Austria 8%, Croatia 4%, Hungary,
Russia (1999)
Debt - external: $6.2 billion (2000)
Economic aid - recipient: ODA, $5 million (1 993)
Currency: tolar (SIT)
Currency code: SIT
Exchange rates: tolars per US dollar - 225.93
(January 2001 ), 222.66 (2000), 1 81 .77 (1 999), 1 66.1 3
(1998), 159.69 (1997), 135.36 (1996)
Fiscal year: calendar year
Economy - overview: In this small landlocked
economy, subsistence agriculture occupies more than
60% of the population. Manufacturing features a
number of agroprocessing factories. Mining has
declined in importance in recent years: diamond
mines have shut down because of the depletion of
easily accessible reserves; high-grade iron ore
deposits were depleted by 1 978; and health concerns
have cut world demand for asbestos. Exports of soft
drink concentrate, sugar, and wood pulp are the main
earners of hard currency. Surrounded by South Africa,
except for a short border with Mozambique,
Swaziland is heavily dependent on South Africa from
which it receives four-fifths of its imports and to which
it sends two-thirds of its exports. Remittances from the
Southern African Customs Union and Swazi workers
in South African mines substantially supplement
domestically earned income. The government is trying
to improve the atmosphere for foreign investment.
Overgrazing, soil depletion, drought, and sometimes
floods persist as problems for the future. Prospects for
2001 are strengthened by government millennium
projects for a new convention center, additional
hotels, an amusement park, a new airport, and
stepped-up roadbuilding and factory construction
plans.
GDP: purchasing power parity - $4.4 billion
(2000 est.)
GDP - real growth rate: 2.4% (2000 est.)
GDP - per capita: purchasing power parity - $4,000
(2000 est.)
GDP - composition by sector:
agriculture: 10%
industry: 40%
services: 44% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 6.4% (2000 est.)
Labor force: NA
Labor force - by occupation: private sector 70%,
public sector 30%
Unemployment rate: 22% (1995 est.)
Budget;
revenues: $400 million
expenditures: $450 million, including capital
expenditures of $1 15 million (FY96/97)
Industries: mining (coal and asbestos), wood pulp,
sugar, soft drink concentrates
Industrial production growth rate: 3.7%
(FY95/96)
Electricity - production: 375 million kWh (1999)
Electricity ■ production by source:
fossil fuel: 53.33%
hydro: 46.67%
nuclear: 0%
other: 0%(im)
Electricity - consumption; 198 million kWh (1999)
Electricity - exports: 852 million kWh (1999)
Electricity - imports: 701 million kWh
note: supplied by South Africa (1 999)
Agriculture ■ products: sugarcane, cotton, corn,
tobacco, rice, citrus, pineapples, sorghum, peanuts;
cattle, goats, sheep
Exports: $881 million (f.o.b., 2000)
Exports - commodities: soft drink concentrates,
sugar, wood pulp, cotton yarn, refrigerators, citrus and
canned fruit
Exports - partners: South Africa 65%, EU 12%,
Mozambique 11%, US 5% (1998)
Imports: $928 million (f.o.b., 2000)
Imports - commodities: motor vehicles, machinery,
transport equipment, foodstuffs, petroleum products,
chemicals
Imports - partners: South Africa 84%, EU 5%,
Japan 2%, Singapore 2% (1998)
Debt -external: $281 million (2000 est.)
Economic aid - recipient: $55 million (1995)
Currency: lilangeni (SZL)
Currency code: SZL
Exchange rates: emalangeni per US dollar - 7.7803
(January 2001), 6.9056 (2000), 6.1087 (1999), 5.4807
(1998), 4.6032 (1997), 4.2706 (1996); note - the
Swazi lilangeni is at par with the South African rand;
emalangeni is the plural form of lilangeni
Fiscal year: 1 April ■ 31 March
Economy - overview: Aided by peace and
neutrality for the whole twentieth century, Sweden
has achieved an enviable standard of living under a
mixed system of high-tech capitalism and extensive
welfare benefits. It has a modern distribution system,
excellent internal and external communications, and
a skilled labor force. Timber, hydropower, and iron
ore constitute the resource base of an economy
heavily oriented toward foreign trade. Privately owned
firms account for about 90% of industrial output, of
which the engineering sector accounts for 50% of
output and exports. Agriculture accounts for only 2%
of GDP and 2% of the jobs. In recent years, however,
this extraordinarily favorable picture has been
somewhat clouded by budgetary difficulties, high
unemployment, and a gradual loss of
competitiveness in international markets. Sweden
has harmonized its economic policies with those of
the EU, which it joined at the start of 1995. GDP
growth is forecast for 4% in 2001 .
GDP: purchasing power parity - $197 billion
(2000 est.)
GDP - real growth rate: 4.3% (2000 est.)
GDP - per capita: purchasing power parity -
$22,200 (2000 est.)
GDP - composition by sector:
agriculture: 2.2%
industry: 27.9%
serv/ces; 69.9% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3.7%
highest 10%: 20.1% (1992)
Inflation rate (consumer prices): 1 .2% (2000 est.)
Labor force: 4,4 million (2000 est.)
Labor force - by occupation: agriculture 2%,
industry 24%, services 74% (2000 est.)
Unemployment rate: 6% (2000 est.)
Budget:
revenues; $133 billion
expenditures: $125.2 billion, including capital
expenditures of $NA (2000 est.)
484
Sweden (continued)
Industries; iron and steel, precision equipment
(bearings, radio and telephone parts, armaments),
wood pulp and paper products, processed foods,
motor vehicles
Industrial production growth rate: 7% (2000 est.)
Electricity - production: 146.633 billion kWh (1999)
Electricity - production by source:
fossi! fuel: 5.53%
hydro: 47 2A%
nuclear: 45.42%
oto; 1.81% (1999)
Electricity ■ consumption: 1 28.81 9 billion kWh
(1999)
Electricity - exports: 1 5.9 billion kWh (1 999)
Electricity - imports: 8.35 billion kWh (1999)
Agriculture - products: grains, sugar beets,
potatoes; meat, milk
Exports: $95.5 billion (f.o.b., 2000)
Exports - commodities: machinery 35%, motor
vehicles, paper products, pulp and wood, iron and
steel products, chemicals
Exports - partners: EU 55% (Germany 11%, UK
10%, Denmark 6%, Finland 5%, France 5%), US 9%,
Norway 8% (1999)
Imports; $80 billion (f.o.b., 2000)
Imports - commodities: machinery, petroleum and
petroleum products, chemicals, motor vehicles, iron
and steel; foodstuffs, clothing
Imports ■ partners: EU 67% (Germany 18%, UK
10%, Denmark 7%, France 6%), Norway 8%, US 6%
(1999)
Debt - external: $66.5 billion (1994)
Economic aid ■ donor: ODA, $1.7 billion (1997)
Currency: Swedish krona (SEK)
Currency code: SEK
Exchange rates: Swedish kronor per US dollar -
9.4669 (January 2001), 9.1622 (2000), 8.2624 (1 999),
7.9499 (1998), 7.6349 (1997), 6.7060 (1996)
Fiscal year; calendar year','0012aaa7f2ea09a636154c4e07ab81cefe0904ba67936a26c563e62bab9c5f19','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b90a228260d000bbbaae639084e0eae7c733fabb4f37609e489522fe67671f3e',2001,'WF','Wallis and Futuna','economy',465,'Economy - overview: France is in the midst of
transition, from an economy that featured extensive
government ownership and intervention to one that
relies more on market mechanisms. The government
remains dominant in some sectors, particularly power,
public transport, and defense industries, but it has
been relaxing its control since the mid-1980s. The
Socialist-led government has sold off part of its
holdings in France Telecom, Air France, Thales,
Thomson Multimedia, and the European Aerospace
and Defense Company (EADS). The
telecommunications sector is gradually being opened
to competition. France''s leaders remain committed to
a capitalism in which they maintain social equity by
means of laws, tax policies, and social spending that
reduce income disparity and the impact of free
markets on public health and welfare. The
government has done little to cut generous
unemployment and retirement benefits which impose
a heavy tax burden and discourage hiring. It has also
shied from measures that would dramatically increase
the use of stock options and retirement investment
plans; such measures would boost the stock market
and fast-growing IT firms as well as ease the burden
on the pension system, but would disproportionately
benefit the rich. In addition’ to the tax burden, the
reduction of the work week to 35-hours has drawn
criticism for lowering the competitiveness of French
companies.
GDP: purchasing power parity - $1 .448 trillion
(2000 est.)
GDP - real growth rate: 3.1% (2000 est.)
GDP - per capita: purchasing power parity -
$24,400 (2000 est.)
GDP - composition by sector:
agriculture: 3.3%
industry: 26A%
services: 70.6% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.8%
highest 10%>:25.^%{m5)
Inflation rate (consumer prices): 1 .7% (2000 est.)
Labor force: 25 million (2000)
Labor force - by occupation: services 71%,
industry 25%, agriculture 4% (1997)
Unemployment rate: 9.7% (2000 est.)
Budget:
revenues; $210 billion
expenditures: $240 billion, including capital
expenditures of $NA (2000 est.)
Industries: machinery, chemicals, automobiles,
metallurgy, aircraft, electronics; textiles, food
processing; tourism
Industrial production growth rate: 3.5%
(2000 est.)
Electricity - production: 497.26 billion kWh (1999)
Electricity - production by source:
fossil fuel: 9.69%
hydro: 14.30%
174
France (continued)
nuclear: 75.43%
ote; 0.49% (1999)
Electricity - consumption: 398.752 billion kWh
(1999)
Electricity - exports: 68.7 billion kWh (1999)
Electricity - imports: 5 billion kWh (1999)
Agriculture - products: wheat, cereals, sugar
beets, potatoes, wine grapes; beef, dairy products;
fish
Exports: $325 billion (f.o.b., 2000 est.)
Exports - commodities: machinery and
transportation equipment, aircraft, plastics, chemicals,
pharmaceutical products, iron and steel, beverages
Exports - partners: EU 63% (Germany 16%, UK
10%, Spain 9%, Italy 9%, Belgium-Luxembourg 8%),
US 8% (1999)
Imports: $320 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
vehicles, crude oil, aircraft, plastics, chemicals
Imports - partners: EU 62% (Germany 16%,
Belgium-Luxembourg 11%, Italy 9%, UK 8%), US 7%
(2000 est.)
Debt - external: $1 06 billion (1 998)
Economic aid - donor: ODA, $6.3 billion (1997)
Currency: French franc (FRF); euro (EUR)
note; on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in France at a fixed rate of
6.55957 French francs per euro and will replace the
local currency for all transactions in 2002
Currency code: FRF; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001 ), 1 .0854 (2000), 0.9386 (1 999); French
francs per US dollar - 5.65 (January 1999), 5.8995
(1998), 5.8367 (1997), 5.1155 (1996)
Fiscal year: calendar year','4c2cb5a098091078f628a29477b9920bbb70004c89ae8dcc3a2eb8caf27597f6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69bf748784686182867d8445e9843f2ae222cb6e9ff46bbc1f5c593c47492d90',2001,'KI','Kiribati','economy',480,'Economy - overview: Since 1962, when France
stationed military personnel in the region, French
Polynesia has changed from a subsistence economy
to one in which a high proportion of the work force is
either employed by the military or supports the tourist
industry. Tourism accounts for about one-fourth of
GDP and is a primary source of hard currency
earnings. The small manufacturing sector primarily
processes agricultural products. The territory
benefited from a five-year (1994-98) development
agreement with France aimed principally at creating
new jobs.
GDP: purchasing power parity - $2.6 billion
(1997 est.)
GDP ■ real growth rate: 2.5% (1997 est.)
GDP - per capita: purchasing power parity -
$10,800(1997 est.)
GDP - composition by sector:
agriculture: 4%
industry: 18%
semces;78%(1997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .5% (1994)
Labor force: 70,000(1996)
Labor force - by occupation; agriculture 13%,
industry 19%, services 68% (1997)
Unemployment rate: 15% (1992 est.)
Budget:
revenues: billion
expenditures: $900 million, including capital
expenditures of $185 million (1996)
Industries: tourism, pearls, agricultural processing,
handicrafts
Industrial production growth rate: NA%
Electricity - production: 430 million kWh (1999)
Electricity - production by source:
fossil fuel: 51. mo
hydro.'' 48.84%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 399.9 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports; 0 kWh (1999)
Agriculture ■ products: coconuts, vanilla,
vegetables, fruits; poultry, beef, dairy products
Exports: $205 million (f.o.b., 1999)
Exports - commodities; cultured pearls 50%,
coconut products, mother-of-pearl, vanilla, shark meat
(1997)
Exports - partners: Japan 62%, US 21% (1999)
Imports: $749 million (f.o.b., 1999)
Imports - commodities: fuels, foodstuffs,
equipment
Imports - partners: France 53%, US 13%, Australia
10% (1999)
Debt - external: $NA
Economic aid - recipient: $367 million (1997)
Currency: Comptoirs Francais du Pacifique franc
(XPF)
Currency code: XPF
Exchange rates: Comptoirs Francais du Pacifique
francs (XPF) per US dollar - 1 27.1 1 (January 2001 ),
1 29.44 (2000), 1 1 1 .93 (1 999), 1 07.25 (1 998), 1 06.1 1
(1997), 93.00 (1996); note - pegged at the rate of
119.25 XPF to the euro
Fiscal year: calendar year
Economy - overview: A remote country of 33
scattered coral atolls, Kiribati has few national
resources. Commercially viable phosphate deposits
were exhausted at the time of independence from the
UK in 1 979. Copra and fish now represent the bulk of
production and exports. The economy has fluctuated
widely in recent years. Economic development is
constrained by a shortage of skilled workers, weak
infrastructure, and remoteness from international
markets. Tourism provides more than one-fifth of
GDP. The financial sector is at an early stage of
development as is the expansion of private sector
initiatives. Foreign financial aid, largely from the UK
and Japan, is a critical supplement to GDP, equal to
25%-50% of GDP in recent years. Remittances from
workers abroad account for more than $5 million each
year. Performance in 2000 fell short of the 2.5%
growth in 1999, which benefited from increased copra
production and exceptionally large revenues from
fishing licenses.
GDP: purchasing power parity - $76 million
(2000 est.), supplemented by a nearly equal amount
from external sources
GDP - real growth rate: 1% (2000 est.)
GDP - per capita: purchasing power parity - $850
(2000 est.)
GDP - composition by sector:
agriculture: 14%
industry: 7%
services: 79% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2% (1999 est.)
Labor force: 7,870 economically active, not
including subsistence farmers (1985 est.)
Unemployment rate: 2%; underemployment 70%
(1992 est.)
Budget:
revenues; $33.3 million
expenditures: million, including capital
expenditures of $NA million (1996 est.)
Industries: fishing, handicrafts
Industrial production growth rate: 0.7%
(1992 est.)
Electricity - production: 7 million kWh (1999)
Electricity - production by source:
fossil fuel: W0%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 6.5 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture ■ products: copra, taro, breadfruit,
sweet potatoes, vegetables; fish
Exports: $6 million (f.o.b., 1998)
Exports - commodities: copra 62%, coconuts,
seaweed, fish
Exports - partners: Bangladesh, Australia, US,
Hong Kong (1999)
Imports: $44 million (c.i.f., 1999)
Imports - commodities: foodstuffs, machinery and
equipment, miscellaneous manufactured goods, fuel
Imports - partners: Australia, Fiji, Japan, NZ, China
(1999)
Debt - external: $10 million (1999 est.)
Economic aid - recipient: $15.5 million (1995),
largely from UK and Japan
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates: Australian dollars per US dollar -
1 .7995 (January 2001 ), 1 .71 73 (2000), 1 .5497 (1 999),
1.5888 (1998), 1.3439 (1997), 1.2773 (1996)
Fiscal year: NA
Economy - overview: North Korea, one of the
world''s most centrally planned and isolated
economies, faces desperate economic conditions.
Industrial capital stock is nearly beyond repair as a
result of years of underinvestment and spare parts
shortages. The nation faces its seventh year of food
shortages because of weather-related problems,
including major drought in 2000, and chronic
shortages of fertilizer and fuel. Massive international
food aid deliveries have allowed the regime to escape
the major consequence of spreading economic
failure, such as mass starvation, but the population
remains vulnerable to prolonged malnutrition and
deteriorating living conditions. Large-scale military
spending eats up resources needed for expanding
investment and consumption goods. In 2000, the
regime placed emphasis on expanding foreign trade
links, embracing modern technology, and attracting
foreign investment, but in no way at the expense of
relinquishing central control over key national assets
or undergoing market-oriented reforms.
GDP: purchasing power parity - $22 billion
(2000 est.)
GDP - real growth rate: -3% (2000 est.)
GDP ■ per capita: purchasing power parity - $1 ,000
(2000 est.)
GDP - composition by sector:
agriculture: 30%
industry: 42%
services: 28% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 9.6 million
Labor force - by occupation: agricultural 36%,
nonagricultural 64%
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: including capital expenditures of
SNA
Industries; military products; machine building,
electric power, chemicals; mining (coal, iron ore,
magnesite, graphite, copper, zinc, lead, and precious
metals), metallurgy; textiles, food processing: tourism
Industrial production growth rate: NA%
Electricity - production: 28.6 billion kWh (1999)
Electricity - production by source:
foss/7 fue/.- 34.62%
hydro: 65.38%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 26.598 billion kWh
(1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports; 0 kWh (1999)
Agriculture - products: rice, corn, potatoes,
soybeans, pulses; cattle, pigs, pork, eggs
Exports: $520 million (f.o.b., 1999 est.)
Exports - commodities; minerals, metallurgical
products, manufactures (including armaments);
agricultural and fishery products
Exports - partners: Japan 28%, South Korea 21%,
China 5%, Germany 4%, Russia 1% (1995)
Imports; $960 million (c.i.f., 1999 est.)
Imports - commodities: petroleum, coking coal,
machinery and equipment; consumer goods, grain
Imports - partners; China 33%, Japan 17%, Russia
5%, South Korea 4%, Germany 3% (1995)
274
Korea, North (continued)
Debt - external: $12 billion (1996 est.)
Economic aid - recipient; $NA: note - an estimated
$200 million to $300 million in humanitarian aid from
US, South Korea, Japan, and EU in 1997 plus much
additional aid from the UN and non-governmental
organizations; substantial continuing humanitarian
aid, 1998-2000
Currency: North Korean won (KPW)
Currency code: KPW
Exchange rates: official: North Korean won per US
dollar - 2.15 (May 1994), 2.13 (May 1992), 2.14
(September 1991), 2.1 (January 1990), 2.3
(December 1989); market: North Korean won per US
dollar -200
Fiscal year: calendar year
Economy - overview: As one of the Four Dragons
of East Asia, South Korea has achieved an incredible
record of growth. Three decades ago GDP per capita
was comparable with levels in the poorer countries of
Africa and Asia. Today its GDP per capita is seven
times India''s, 1 6 times North Korea''s, and comparable
to the lesser economies of the European Union. This
success through the late 1980s was achieved by a
system of close government/business ties, including
directed credit, import restrictions, sponsorship of
specific industries, and a strong labor effort. The
government promoted the import of raw materials and
technology at the expense of consumer goods and
encouraged savings and investment over
consumption. The Asian financial crisis of 1997-99
exposed certain longstanding weaknesses in South
Korea''s development model, including high debt/
equity ratios, massive foreign borrowing, and an
undisciplined financial sector. By 1999 GDP growth
had recovered, reversing the substantial decline of
1998. Seoul has pressed the country''s largest
business groups to restructure and to strengthen their
financial base. Growth in 2001 likely will be a more
sustainable rate of 5%.
GDP: purchasing power parity - $764.6 billion
(2000 est.)
GDP - real growth rate: 9% (2000 est.)
GDP - per capita: purchasing power parity -
$16,100 (2000 est.)
GDP - composition by sector:
agriculture: 5.6%
industry: 41 A%
services: 53% (1999 est.)
Popuiation below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: 2.9%
highest 24.3% (1993)
Inflation rate (consumer prices): 2.3% (2000)
Labor force: 22 million (2000)
Labor force - by occupation: services 68%,
industry 20%, agriculture 12% (1999)
Unemployment rate: 4.1% (2000 est.)
Budget:
revenues; $81.8 billion
expenditures: $94.9 billion, including capital
expenditures of $6.1 billion (1999)
Industries: electronics, automobile production,
chemicals, shipbuilding, steel, textiles, clothing,
footwear, food processing
Industrial production growth rate: 17% (2000)
Electricity - production: 250.287 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 59.22%
hydro: 1 .64%
nuc/ear; 39.12%
ofher; 0.02% (1999)
Electricity - consumption: 232.767 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity ■ imports: 0 kWh (1999)
Agriculture - products: rice, root crops, barley,
vegetables, fruit; cattle, pigs, chickens, milk, eggs; fish
Exports: $172.6 billion (f.o.b., 2000)
Exports - commodities: electronic products,
machinery and equipment, motor vehicles, steel,
ships; textiles, clothing, footwear; fish
Exports - partners: US 20.5%, Japan 11%, China
9.5%, Hong Kong 6.3%, Taiwan 4.4% (1999)
Imports: $160.5 billion (f.o.b., 2000)
Imports - commodities: machinery, electronics and
electronic equipment, oil, steel, transport equipment,
textiles, organic chemicals, grains
Imports ■ partners: US 20.8%, Japan 20.2%, China
7.4%, Saudi Arabia 4.7%, Australia 3.9% (1999)
Debt - external: $137 billion (November 2000)
Economic aid - recipient: $NA
Currency: South Korean won (KRW)
Currency code; KRW
Exchange rates: South Korean won per US dollar -
1 ,271 .89 (January 2001 ), 1 ,1 30.96 (2000), 1 ,1 88.82
(1999), 1,401.44 (1998), 951.29 (1997), 804.45
(1996)
Fiscal year: calendar year','84688dfe79464928f928a6cb472c03d6951db3e4232c6b3a43e275101d267a79','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13ea32c0e057d5f5d8a1677e35aeaaa9004c67b8f976cdd2d115b2a56627f2dd',2001,'GH','Ghana','economy',496,'Economy - overview: Well endowed with natural
resources, Ghana has twice the per capita output of
the poorer countries in West Africa. Even so, Ghana
remains heavily dependent on international financial
and technical assistance. Gold, timber, and cocoa
production are major sources of foreign exchange.
The domestic economy continues to revolve around
subsistence agriculture, which accounts for 36% of
GDP and employs 60% of the workforce, mainly small
landholders. In 1 995-97, Ghana made mixed progress
under a three-year structural adjustment program in
cooperation with the IMF. On the minus side, public
sector wage increases and regional peacekeeping
commitments have led to continued inflationary deficit
financing, depreciation of the cedi, and rising public
discontent with Ghana''s austerity measures. Political
uncertainty and a depressed cocoa market led to
disappointing growth in 2000. A rebound in the cocoa
market should push growth over 4% in 2001-02.
GDP: purchasing power parity - $37.4 billion
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,900
(2000 est.)
GDP - composition by sector:
agriculture: 36%
industry: 25%
services: 39% (2000 est.)
Population below poverty line: 31.4% (1992 est.)
Household income or consumption by percentage
share;
lowest 10%: 3.6%
/?/gf?esf/0%; 26.1% (1997)
Inflation rate (consumer prices): 22.8%
(2000 est.)
Labor force: 9 million (2000 est.)
Labor force - by occupation: agriculture 60%,
industry 15%, services 25% (1999 est.)
Unemployment rate: 20% (1997 est.)
Budget:
revenues; $1.39 billion
expenditures: $1 .47 billion, including capita!
expenditures of $370 million (1996 est.)
Industries: mining, lumbering, light manufacturing,
aluminum smelting, food processing
Industrial production growth rate; 4.2%
(1996 est.)
Electricity ■ production: 5.466 billion kWh (1999)
Electricity - production by source:
fossil fuel: 26.82%
/?yQf/''o;73.18%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 5.573 billion kWh (1999)
Electricity - exports: 400 million kWh (1999)
Electricity - imports: 890 million kWh (1999)
Agriculture - products: cocoa, rice, coffee, cassava
(tapioca), peanuts, corn, shea nuts, bananas; timber
Exports: $1 .6 billion (f.o.b., 2000)
Exports - commodities: gold, cocoa, timber, tuna,
bauxite, aluminum, manganese ore, diamonds
Exports " partners: Togo, UK, Italy, Netherlands,
Germany, US, France (1998)
imports: $2.2 billion (f.o.b., 2000)
imports ■ commodities: capital equipment,
petroleum, foodstuffs
Imports - partners: UK, Nigeria, US, Germany,
Italy, Spain (1998)
193
Ghana (continued)
Debt “ external: $7 billion (1999 est.)
Economic aid - recipient: $477.3 million (1995)
Currency: cedi (GHC)
Currency code: GHC
Exchange rates: cedis per US dollar - 6,895.77
(January 2001), 5,321.68 (2000), 2,647.32 (1999),
2,314.15 (1998), 2,050.17 (1997), 1,637.23 (1996)
Fiscal year: calendar year','1005ceaf37e2e0e0cc6e00e0946743f6ce27ac6a4de34ff200bdb0694cd03576','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18f4359b21e9dfbd94b1521c84d522d1d712ed90bb16aa68ca7838b03f70b07b',2001,'GI','Gibraltar','economy',504,'Economy - overview: Gibraltar benefits from an
extensive shipping trade, offshore banking, and its
position as an international conference center. The
British military presence has been sharply reduced
and now contributes about 1 1 % to the local economy.
The financial sector accounts for 20% of GDP; tourism
(almost 6 million visitors in 1998), shipping services
fees, and duties on consumer goods also generate
revenue. In recent years, Gibraltar has seen major
structural change from a public to a private sector
economy, but changes in government spending still
have a major impact on the level of employment.
GDP: purchasing power parity - $500 million
(1997 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$17,500 (1997 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1.5% (1998)
Labor force: 14,800 (including non-Gibraltar
laborers)
Labor force - by occupation: services 60%,
industry 40%, agriculture NEGL%
Unemployment rate: 13.5% (1996)
Budget:
revenues: $307 million
expenditures: $284 million, including capital
expenditures of $NA (FYOO/01 est.)
Industries: tourism, banking and finance,
ship-building and repairing; support to large UK naval
and air bases; tobacco, mineral water, beer, canned
fish
Industrial production growth rate: NA%
Electricity - production: 95 million kWh (1999)
Electricity - production by source:
foss/7 /ue/: 100%
hydro: 0%
nuclear: 0%
other: 0%(m9)
Electricity - consumption: 88.4 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: none
Exports: $81.1 million (f.o.b., 1997)
Exports ■ commodities: (principally reexports)
petroleum 51%, manufactured goods 41%, other 8%
Exports - partners: UK, Morocco, Portugal,
Netherlands, Spain, US, Germany
Imports: $492 million (c.i.f., 1997)
Imports - commodities: fuels, manufactured
goods, and foodstuffs
Imports - partners: UK, Spain, Japan, Netherlands
Debt ■ external: $NA
Economic aid - recipient: $NA
Currency: Gibraltar pound (GIP)
Currency code: GIP
Exchange rates: Gibraltar pounds per US dollar ■
0.6764 (January 2001), 0.6596 (2000), 0.6180 (1999),
0.6037 (1998), 0.6106 (1997), 0.6403 (1996); note -
the Gibraltar pound is at par with the British pound
Fiscal year: 1 July - 30 June
195
Gibraltar (continued)
Economy ■ overview: no economic activity
Economy - overview; Morocco faces the problems
typical of developing countries - restraining
government spending, reducing constraints on private
activity and foreign trade, and achieving sustainable
economic growth. Following structural adjustment
programs supported by the IMF, World Bank, and the
Paris Club, the dirham is now fully convertible for
current account transactions, and reforms of the
financial sector have been implemented. Drought
conditions depressed activity in the key agricultural
sector and contributed to a stagnant economy in 1 999
and 2000. During that time, however, Morocco
reported large foreign exchange inflows from the sale
of a mobile telephone license and partial privatization
of the state-owned telecommunications company.
Favorable rainfalls have led Morocco to predict a
growth of 1% for 2001 . Formidable long-term
challenges include: servicing the external debt;
preparing the economy for freer trade with the EU; and
improving education and attracting foreign investment
to boost living standards and job prospects for
Morocco''s youthful population.
GDP: purchasing power parity - $105 billion
(2000 est.)
GDP - real growth rate: 0.8% (2000 est.)
GDP - per capita: purchasing power parity - $3,500
(2000 est.)
GDP - composition by sector:
agriculture: 15%
industry: 33%
services: 52% (1999 est.)
Population below poverty line: 19% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.6%
highest 10%: 20.9% (1998-99)
inflation rate (consumer prices): 2% (2000 est.)
Labor force: 1 1 million (1 997 est.)
348
Morocco (continued)
Labor force - by occupation: agriculture 50%,
services 35%, industry 15% (1999 est.)
Unemployment rate: 23% (1999 est.)
Budget:
revenues: $9.6 billion
expenditures: $8.6 billion, including capital
expenditures of $2.1 billion (2001 est.)
Industries: phosphate rock mining and processing,
food processing, leather goods, textiles, construction,
tourism
Industrial production growth rate: 0.5%
(1999 est.)
Electricity - production: 1 3.695 billion kWh (1 999)
Electricity - production by source:
fossil fuel: S9A9%
hydro: ^0mo
nuclear: 0%
o//?er; 0% (1999)
Electricity - consumption: 13.441 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 705 million kWh (1999)
Agriculture - products: barley, wheat, citrus, wine,
vegetables, olives; livestock
Exports: $7.6 billion (f.o.b., 2000 est.)
Exports - commodities: phosphates and fertilizers,
food and beverages, minerals
Exports - partners: France 35%, Spain 9%, UK 8%,
Germany 7%, US 5% (1999)
Imports; $12.2 billion (f.o.b., 1999 est.)
Imports - commodities: semiprocessed goods,
machinery and equipment, food and beverages,
consumer goods, fuel
Imports - partners: France 32%, Spain 12%, Italy
7%, Germany 6%, UK 6% (1999)
Debt - external: $18.4 billion (2000 est.)
Economic aid ■ recipient: $565.6 million (1995)
Currency: Moroccan dirham (MAD)
Currency code: MAD
Exchange rates; Moroccan dirhams per US dollar -
10.590 (January 2001), 10.626 (2000), 9.804 (1999),
9.604 (1998), 9.527 (1997), 8.716 (1996)
Fiscal year: calendar year','3d266707ede6feeee8cd4da62a4bd4b6a555beda944240f3d88a0731d6a2188d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a7737dae99b7161c30987a06fbea235bf21349366349e176c9f9e36c7964c66',2001,'GR','Greece','economy',513,'Economy - overview: Greece has a mixed capitalist
economy with the public sector accounting for about
half of GDP. Tourism is a key industry, providing a
large portion of GDP and foreign exchange earnings.
Greece is a major beneficiary of EU aid, equal to
about 4% of GDP. The economy has improved
steadily over the last few years, as the government
has tightened policy in the run-up to Greece''s entry
into the EU''s Economic and Monetary Union (EMU)
on 1 January 2001. In particular, Greece has cut its
budget deficit to below 1% of GDP and tightened
monetary policy, with the result that inflation fell from
20% in 1990 to 3.1% in 2000. Major challenges
remaining include the reduction of unemployment and
further restructuring of the economy, including the
privatization of some leading state enterprises.
Growth, 3.8% in 2000, may fall off to 3%-3.5% in
2001.
GDP: purchasing power parity -$181.9 billion
(2000 est.)
GDP -real growth rate: 3.8% (2000 est.)
GDP - per capita: purchasing power parity -
$17,200 (2000 est.)
GDP - composition by sector:
agriculture: 8.3%
industry: 27.3%
services: 64 A% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3%
highest 10%: 25.3% (1 993 est.)
Inflation rate (consumer prices): 3.1% (2000 est.)
Labor force: 4.32 million (1999 est.)
Labor force - by occupation; industry 21%,
agriculture 20%, services 59% (2000 est.)
Unemployment rate: 1 1 .3% (2000 est.)
Budget:
revenues: $45 billion
expenditures: $47.6 billion, including capital
expenditures of $NA (1998 est.)
Industries: tourism; food and tobacco processing,
textiles; chemicals, metal products; mining, petroleum
Industrial production growth rate: 7% (2000 est.)
Electricity - production: 46.432 billion kWh (1999)
Electricity ■ production by source:
fossil fuel: 89.6%
hydro: 972%
nuclear: 0%
ofber: 0.68% (1999)
Electricity - consumption: 43.343 billion kWh
(1999)
Electricity - exports: 1 .65 billion kWh (1 999)
Electricity - imports: 1 .81 1 billion kWh (1 999)
Agriculture - products: wheat, corn, barley, sugar
beets, olives, tomatoes, wine, tobacco, potatoes;
beef, dairy products
Exports: $15.8 billion (f.o.b., 2000)
Exports - commodities: manufactured goods, food
and beverages, petroleum products
Exports • partners: EU 49% (Germany 15%, Italy
13%, UK 6%), US 6% (1999)
Imports: $33.9 billion (c.i.f., 2000)
Imports ■ commodities: manufactured goods,
foodstuffs, fuels, chemicals
Imports - partners: EU 66% (Italy 15%, Germany
15%, France 9%, UK 6%) (1999)
Debt ■ external: $57 billion (2000 est.)
Economic aid - recipient: $5.4 billion from EU
(1997 est.)
Currency: drachma (GRD); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Greece (which entered the
European Monetary Union on 1 January 2001) at a
fixed rate of 340.750 drachmae per euro and will
replace the local currency for all transactions in 2002
Currency code: GRD; EUR
Exchange rates: drachmae per US dollar - 380.21
(December 2000), 365.40 (2000), 305.65 (1999),
295.53 (1998), 273.06 (1997), 240.71 (1996)
Fiscal year: calendar year','7617ed814da90c5c6b10b055c8dc77e406ad639c830f9f879ec1b7536eb72def','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('680f3539b545de211fb6806d301529cbabbd1624030be723812dd9dadfc28c26',2001,'GL','Greenland','economy',521,'Economy - overview: The economy remains
critically dependent on exports of fish and substantial
support from the Danish Government, which supplies
about half of government revenues. The public sector,
including publicly owned enterprises and the
municipalities, plays the dominant role in the
economy. Despite several interesting hydrocarbon
and minerals exploration activities, it will take several
years before production can materialize. Tourism is
the only sector offering any near-term potential and
even this is limited due to a short season and high
costs.
GDP: purchasing power parity - $1 .1 billion
(2000 est.)
GDP -real growth rate: NA%
GDP - per capita: purchasing power parity -
$20,000 (2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .6% (1 999 est.)
Labor force: 24,500 (1999 est.)
Unemployment rate: 7% (1999 est.)
Budget:
revenues: $646 million
expenditures: $629 million, including capital
expenditures of $85 million (1999)
Industries: fish processing (mainly shrimp and
Greenland halibut), handicrafts, furs, small shipyards
Industrial production growth rate: NA%
Electricity - production: 250 million kWh (1999)
Electricity - production by source:
fossil fuel: 41%
hydro: 59%
nuclear: 0%
other: 0%
note: Greenland is shifting its electricity production
from fossil fuel to hydroelectric power production
(1999)
Electricity - consumption: 232.5 million kWh
(1999)
Electricity ■ exports: 0 kWh (1999)
Electricity ■ imports: 0 kWh (1999)
Agriculture - products: forage crops, garden and
greenhouse vegetables; sheep, reindeer; fish
Exports: $276 million (f.o.b., 1999)
Exports - commodities: fish and fish products 94%
Exports ■ partners: EU (mainly Denmark) 85%,
Japan 8%, US 2% (1999)
Imports: $400 million (c.i.f., 1999)
Imports • commodities: machinery and transport
equipment, manufactured goods, food, petroleum
products
Imports - partners: EU (mostly Denmark), Norway,
US, Canada
Debt ■ external: $25 million (1999)
Economic aid - recipient: $380 million subsidy from
Denmark (1999)
Currency: Danish krone (DKK)
Currency code: DKK
Exchange rates: Danish kroner per US dollar -
7.951 (January 2001), 8.083 (2000), 6.976 (1999),
6.701 (1998), 6.604 (1997), 5.799 (1996)
Fiscal year: calendar year
200
Greenland (continued)','4db42c043db79dd336e99d79768c688eab4ef7ef6d36a0f8dc448157372d13e3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e046d3a6378e7c53bd849afaf28f7376f5223df6d28ff06a98e4e12f05f73790',2001,'GD','Grenada','economy',528,'Economy - overview: In this island economy
progress in fiscal reforms and prudent
macroeconomic management have kept annual
growth steady since 1998. The increase in economic
activity has been led by construction and trade.
Tourist facilities are being expanded; tourism is the
leading foreign exchange earner. Major short-term
concerns are the rising fiscal deficit and the
deterioration in the external account balance.
Grenada shares a common central bank and a
common currency with seven other members of the
Organization of Eastern Caribbean States (OECS).
GDP: purchasing power parity - $394 million
(2000 est.)
GDP - real growth rate: 7% (2000 est.)
GDP - per capita: purchasing power parity - $4,400
(2000 est.)
GDP - composition by sector:
agriculture: 9.7%
industry: ^5%
services: 75.3% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.5% (2000 est.)
Labor force: 42,300(1996)
Labor force ■ by occupation: services 62%,
agriculture 24%, industry 14% (1999 est.)
Unemployment rate: 15% (1997)
Budget:
revenues; $85.8 million
expend/fures; $102.1 million, including capital
expenditures of $28 million (1997)
Industries: food and beverages, textiles, light
assembly operations, tourism, construction
Industrial production growth rate: 0.7%
(1997 est.)
Electricity - production: 120 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
other: 0% (1 999)
Electricity - consumption: 1 1 1 .6 million kWh
(1999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, cocoa, nutmeg,
mace, citrus, avocados, root crops, sugarcane, corn,
vegetables
Exports: $62.3 million (2000 est.)
Exports - commodities: bananas, cocoa, nutmeg,
fruit and vegetables, clothing, mace
Exports - partners: Caricom 32.3%, UK 20%, US
13%, Netherlands 8.8% (1991)
Imports: $217.5 million (2000 est.)
Imports - commodities: food, manufactured goods,
machinery, chemicals, fuel (1989)
Imports - partners: US 31 .2%, Caricom 23.6%, UK
13.8%, Japan 7.1% (1991)
Debt - external: $1 82.8 million (1 998)
Economic aid - recipient: $8.3 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Fiscal year: calendar year
Economy - overview; Agriculture, dominated by
banana production, is the most important sector of this
lower-middle-income economy. The services sector,
based mostly on a growing tourist industry, is also
important. The government has been relatively
unsuccessful at introducing new industries, and a high
unemployment rate persists. The continuing
dependence on a single crop represents the biggest
obstacle to the islands'' development; tropical storms
wiped out substantial portions of crops in both 1994
and 1995. The tourism sector has considerable
potential for development over the next decade.
Recent growth has been stimulated by strong activity
in the construction sector and an improvement In
tourism. There is a small manufacturing sector and a
small offshore financial sector whose particularly
restrictive secrecy laws have caused some
international concern.
GDP; purchasing power parity - $322 million
(2000 est.)
GDP - real growth rate: 2% (2000 est.)
GDP ■ per capita: purchasing power parity - $2,800
(2000 est.)
GDP - composition by sector:
agriculture: 10.6%
industry: 17.5%
services: 71 .9% (1 996 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: m%
highest 10%: m%
Inflation rate (consumer prices); 2% (1999 est.)
Labor force: 67,000 (1984 est.)
Labor force - by occupation: agriculture 26%,
industry 17%, services 57% (1980 est.)
Unemployment rate: 22% (1997 est.)
Budget;
revenues: $85.7 million
expenditures: $98.6 million, including capital
expenditures of $25.7 million (1997 est.)
Industries: food processing, cement, furniture,
clothing, starch
Industrial production growth rate: -0.9%
(1997 est.)
Electricity - production: 82 million kWh (1999)
Electricity - production by source:
foss/7 fi/e/; 73.1 7%
hydro; 26.83%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 76.3 million kWh (1 999)
Electricity - exports; 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, coconuts, sweet
potatoes, spices; small numbers of cattle, sheep, pigs,
goats; fish
Exports: $53.7 million (2000 est.)
Exports - commodities: bananas 39%, eddoes and
dasheen (taro), arrowroot starch, tennis racquets
Exports - partners: Caricom countries 49%, UK
16%, US 10% (1995)
Imports: $185.6 million (2000 est.)
Imports “ commodities: foodstuffs, machinery and
equipment, chemicals and fertilizers, minerals and
fuels
Imports - partners: US 36%, Caricom countries
28%, UK 13% (1995)
Debt - external: $99.3 million (1998)
Economic aid - recipient: $47.5 million (1995);
note - EU $34.5 million (1998)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar ■ 2.7000 (fixed rate since 1976)
Fiscal year: calendar year','5b0286284d7c0f27a45f2a784111937ba5fd026e4ab204752665fab2dd0cf3a3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('068c27ac57158d14b566a2fb6291e8760650c1c126c1b1ffaab653aa958f7001',2001,'GU','Guam','economy',539,'Economy - overview: The economy depends on US
military spending, tourism, and the export of fish and
handicrafts. Total US grants, wage payments, and
procurement outlays amounted to $1 billion in 1998.
Over the past 20 years, the tourist industry has grown
rapidly, creating a construction boom for new hotels
and the expansion of older ones. More than 1 million
tourists visit Guam each year. The industry has
recently suffered setbacks because of the continuing
Japanese slowdown; the Japanese normally make up
almost 90% of the tourists. Most food and industrial
goods are imported. Guam faces the problem of
building up the civilian economic sector to offset the
impact of military downsizing.
GDP: purchasing power parity - $3.2 billion
(2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$21,000 (2000 est.)
GDP - composition by sector:
agriculture: NA%
/nofusf/y;15%(1993)
services: NA%
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 0% (1999 est.)
Labor force: 60,000 (2000 est.)
Labor force - by occupation: federal and territorial
government 26%, private 74% (trade 24%, other
services 40%, industry 10%) (2000 est.)
Unemployment rate: 15% (2000 est.)
Budget:
revenues: $605.3 million
expenditures: $6542 million, including capital
expenditures of $NA (2000)
Industries: US military, tourism, construction,
transshipment services, concrete products, printing
and publishing, food processing, textiles
Industrial production growth rate: NA%
Electricity ■ production: 800 million kWh (1999)
Electricity - production by source:
foss/7 /ue/.'' 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 744 million kWh (1999)
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: fruits, copra, vegetables;
eggs, pork, poultry, beef
Exports: $75.7 million (f.o.b., 1999)
Exports ■ commodities: mostly transshipments of
refined petroleum products; construction materials,
fish, food and beverage products
Exports - partners: US 25%
Imports: $203 million (f.o.b., 1999 est.)
Imports - commodities: petroleum and petroleum
products, food, manufactured goods
Imports - partners: US 23%, Japan 19%
Debt - external: $NA
Economic aid - recipient: Guam receives large
transfer payments from the US Federal Treasury
($143 million in 1997) into which Guamanians pay no
income or excise taxes; under the provisions of a
special law of Congress, the Guam Treasury, rather
than the US Treasury, receives federal income taxes
paid by military and civilian Federal employees
stationed in Guam
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September','9b8d3fee60d7ef2b1c2fba1c46414c18c68ee100bdfc28eb76f669f71b65a763','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('029db96f2d03905944730d69e0c0d447bbd2586c3304367f16eab670f8e28b38',2001,'GT','Guatemala','economy',546,'Economy - overview: The agricultural sector
accounts for about one-fourth of GDP, two-thirds of
exports, and half of the labor force. Coffee, sugar, and
bananas are the main products. Former President
ARZU (1 996-2000) worked to implement a program of
economic liberalization and political modernization.
The 1996 signing of the peace accords, which ended
36 years of civil war, removed a major obstacle to
foreign investment. In 1998, Hurricane Mitch caused
relatively little damage to Guatemala compared to its
neighbors. Ongoing challenges include increasing
government revenues, negotiating further assistance
from international donors, and increasing the
efficiency and openness of both government and
private financial operations. Despite low international
prices for Guatemala''s main commodities, the
economy grew by 3% in 2000 and is forecast to grow
by 4% in 2001. Guatemala, along with Honduras and
El Salvador, recently concluded a free trade
agreement with Mexico and has moved to protect
international property rights. However, the PORTILLO
administration has undertaken a review of
privatizations under the previous administration,
thereby creating some uncertainty among investors.
GDP: purchasing power parity - $46.2 billion
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity - $3,700
(2000 est.)
GDP “ composition by sector:
agriculture: 23%
industry: 20%
services: 57% (2000 est.)
Population below poverty line: 60% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.6%
highest f0%; 46.6% (1989)
Inflation rate (consumer prices): 6% (2000 est.)
Labor force; 4.2 million (1999 est.)
208
Guatemala (continued)
Labor force - by occupation: agriculture 50%,
industry 15%, services 35% (1999 est)
Unemployment rate: 7.5% (1999 est.}
Budget:
revenues: $2.2 billion
expenditures: billion, including capital
expenditures of $NA (2001 est.)
Industries: sugar, textiles and clothing, furniture,
chemicals, petroleum, metals, rubber, tourism
Industrial production growth rate: 4.1% (1999)
Electricity ■ production: 3.785 billion kWh (1999)
Electricity - production by source:
foss/7 fue/.'' 38.31%
hydro.- 61 .69%
nuclear: 0%
ofoer; 0% (1999)
Electricity - consumption: 3.295 billion kWh (1 999)
Electricity - exports: 435 million kWh (1999)
Electricity - Imports: 210 million kWh (1999)
Agriculture - products: sugarcane, corn, bananas,
coffee, beans, cardamom; cattle, sheep, pigs,
chickens
Exports: $2.9 billion (f.o.b., 2000)
Exports - commodities: coffee, sugar, bananas,
fruits and vegetables, cardamom, meat, apparel,
petroleum, electricity
Exports - partners: US 51 .4%, El Salvador 8.7%,
Honduras 5%, Costa Rica 3.4%, Germany 2.7%
(1998)
Imports: $4.4 billion (f.o.b., 2000)
Imports - commodities: fuels, machinery and
transport equipment, construction materials, grain,
fertilizers, electricity
Imports - partners: US 42.8%, Mexico 9.9%, Japan
4.8%, El Salvador 4.3%, Venezuela 3.8% (1998)
Debt - external: $4.7 billion (2000 est.)
Economic aid - recipient: $212 million (1995)
Currency: quetzal (GTQ), US dollar (USD), others
allowed
Currency code: GTQ; USD
Exchange rates: quetzales per US dollar - 7.8020
(January 2001 ), 7.7632 (2000), 7.3856 (1 999), 6.3947
(1998), 6.0653 (1997), 6.0495 (1996), 5.8103 (1995)
Fiscal year: calendar year','8034f6da4aadd033faedbf8fa86c5c08c0bc311aa11309c41eab759b6cf17f6b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67c3bfdab856b2b7b9f6e120a12ba444c9bac69034241c4e943e137410fbfc6c',2001,'GG','Guernsey','economy',554,'Economy - overview: Financial services - banking,
fund management, insurance, etc. - account for about
55% of total income in this tiny Channel Island
economy. Tourism, manufacturing, and horticulture,
mainly tomatoes and cut flowers, have been declining.
Light tax and death duties make Guernsey a popular
tax haven. The evolving economic integration of the
EU nations is changing the rules of the game under
which Guernsey operates.
GDP: purchasing power parity - $1 .3 billion
(1999 est.)
GDP - real growth rate: 5.7% (1 999 est.)
GDP - per capita: purchasing power parity -
$20,000 (1999 est.)
GDP - composition by sector:
agriculture: 3%
industry: 10%
services: 87% (2000)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%:
highest /0%.’NA%
Inflation rate (consumer prices): 3.99%
(2000 est.)
Labor force: 31 ,322 (2000)
Unemployment rate: 0.5% (1999 est.)
Budget:
revenues.’ $381.3 million
expenditures: $368.8 million, including capital
expenditures of $NA (2000 est.)
Industries: tourism, banking
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
foss/7 fue/;NA%
hydro: m%
nuclear: NA%
other: NA%
Electricity ■ consumption: NA kWh
Electricity ■ exports: NA kWh
Electricity ■ imports: NA kWh
Agriculture - products: tomatoes, greenhouse
flowers, sweet peppers, eggplant, fruit; Guernsey
cattle
Exports: $NA
Exports - commodities: tomatoes, flowers and
ferns, sweet peppers, eggplant, other vegetables
Exports - partners: UK (regarded as internal trade)
Imports: $NA
Imports - commodities: coal, gasoline, oil,
machinery and equipment
Imports - partners: UK (regarded as internal trade)
Debt -external: $NA
Economic aid - recipient: $NA
Currency: British pound (GBP); note - there is also a
Guernsey pound
Currency code: GBP
Exchange rates: Guernsey pounds per US dollar -
0.6764 (January 2001 ), 0.6596 0.61 80 (1 999), 0.6037
(1998), 0.6106 (1997), 0.6403 (1996); note - the
Guernsey pound is at par with the British pound
Fiscal year: calendar year','24d6598777b976e778db4417b188488b1bf5ab693d5276d75c8d1518d5921e29','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0524f94a899a848f105e2596472c889caece7c64844b2016d943d781b93a8bc2',2001,'GY','Guyana','economy',564,'Economy - overview: Severe drought and political
turmoil contributed to Guyana''s negative growth
of -1 .8% for 1 998 following six straight years of growth
of 5% or better. Growth came back to a positive 1 .8%
In 1999 and 3% in 2000. Underlying growth factors
have included expansion in the key agricultural and
mining sectors, a more favorable atmosphere for
business initiative, a more realistic exchange rate, a
moderate inflation rate, and continued support by
international organizations. President JAGDEO, the
former finance minister, is taking steps to reform the
economy, including drafting an investment code and
restructuring the inefficient and unresponsive public
sector. Problems include a shortage of skilled labor
and a deficient infrastructure. The government must
persist in efforts to manage its sizable external debt
and attract new investment.
GDP: purchasing power parity - $3.4 billion
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP - per capita: purchasing power parity - $4,800
(2000 est.)
GDP - composition by sector:
agriculture: 34.7%
industry: 32.5%
services: 32.S% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 5.9% (2000 est.)
Labor force: 245,492(1992)
Labor force ■ by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 12% (1992 est.)
Budget:
revenues; $220.1 million
expenditures: $286.4 million, including capital
expenditures of $86.6 million (1998)
Industries: bauxite, sugar, rice milling, timber,
fishing (shrimp), textiles, gold mining
Industrial production growth rate: 7.1%
(1997 est.)
Electricity - production: 455 million kWh (1999)
Electricity - production by source:
fossil fuel: 98.9%
hydro:
nuclear: 0%
of/ier;0%(1999)
Electricity - consumption: 423.2 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: sugar, rice, wheat,
vegetable oils; beef, pork, poultry, dairy products;
forest and fishery potential not exploited
Exports: $570 million (f.o.b., 2000 est.)
Exports - commodities: sugar, gold, bauxite/
alumina, rice, shrimp, molasses, rum, timber
Exports - partners: US 22%, Canada 22%, UK
18%, Netherlands Antilles 11%, Jamaica (1999)
Imports: $660 million (c.i.f., 2000 est.)
Imports - commodities: manufactures, machinery,
petroleum, food
Imports - partners: US 29%, Trinidad and Tobago
18%, Netherlands Antilles 16%, UK 7%, Japan (1999)
Debt - external: $1.1 billion (2000)
Economic aid - recipient: $84 million (1995),
Heavily Indebted Poor Country Initiative (HIPC) $253
million (1997)
Currency: Guyanese dollar (GYD)
Currency code: GYD
Exchange rates: Guyanese dollars per US dollar -
184.1 (November 2000), 182.2 (2000), 178.0 (1999),
150.5 (1998), 142.4 (1997), 140.4 (1996)
Fiscal year: calendar year
Economy - overview: The economy is dominated
by the bauxite industry, which accounts for more than
15% of GDP and 70% of export earnings. After
assuming power in the fall of 1996, the
WIJDENBOSCH government ended the structural
adjustment program of the previous government,
claiming it was unfair to the poorer elements of
society. Tax revenues fell as old taxes lapsed and the
government failed to implement new tax alternatives.
By the end of 1 997, the allocation of new Dutch
development funds was frozen as Surinamese
Government relations with the Netherlands
deteriorated. Economic growth slowed in 1998, with
decline in the mining, construction, and utility sectors.
Rampant government expenditures, poor tax
collection, a bloated civil service, and reduced foreign
aid in 1999 contributed to the fiscal deficit, estimated
at 11% of GDP. The government sought to cover this
deficit through monetary expansion, which led to a
dramatic increase in inflation and exchange rate
depreciation. Suriname''s economic prospects for the
medium term will depend on renewed commitment to
responsible monetary and fiscal policies and to the
introduction of structural reforms to liberalize markets
and promote competition. The new government of
Ronald VENETIAAN has begun an austerity program,
raised taxes, and attempted to control spending, the
exchange rate has responded by stabilizing. The
Dutch Government has restarted the aid flow, which
will allow Suriname to access international
development financing.
GDP: purchasing power parity - $1 .48 billion
(1999 est.)
GDP - real growth rate: -1% (1 999 est.)
GDP - per capita: purchasing power parity - $3,400
(1999 est.)
GDP “ composition by sector:
agriculture: 13%
industry: 22%
services: 65% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 78% (2000 est.)
Labor force: 100,000
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 20% (1997)
Budget:
revenues; $393 million
expenditures: $403 million, including capital
expenditures of $34 million (1997 est.)
Industries: bauxite and gold mining, alumina
production, lumbering, food processing, fishing
Industrial production growth rate: 6.5%
(1994 est.)
Electricity - production: 1 .937 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 25.92%
hydro: 74.08%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 1 .801 billion kWh (1 999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: paddy rice, bananas, palm
kernels, coconuts, plantains, peanuts; beef, chickens;
forest products; shrimp
Exports: $443 million (f.o.b., 1999)
Exports " commodities: alumina, crude oil, lumber,
shrimp and fish, rice, bananas
Exports - partners: US 23%, Norway 19%,
Netherlands 11%, France, Japan, UK (1999)
Imports: $525 million (f.o.b., 1999)
Imports - commodities: capital equipment,
petroleum, foodstuffs, cotton, consumer goods
Imports - partners: US 35%, Netherlands 15%,
Trinidad and Tobago 12%, Japan, UK, Brazil (1999)
Debt - external: $512 million (2000 est.)
Economic aid - recipient: Netherlands provided
$37 million for project and program assistance,
European Development Fund $4 million, Belgium $2
million (1998)
Currency: Surinamese guilder (SRG)
Currency code: SRG
Exchange rates: Surinamese guilders per US
dollar - 2,178.50 (December 2000), 987.50
(December 1999), 401.00 (December 1998), 401.00
(December 1 997), 401 .26 (December 1 996)
note: beginning in July 1 994, the central bank
midpoint exchange rate was unified and became
market determined; during 1998, the exchange rate
splintered into four distinct rates; in January 1999 the
government floated the guilder, but subsequently
fixed it when the black-market rate plunged; the
government currently allows trading within a band of
SRG 500 around the official rate
Fiscal year: calendar year
478
Suriname (continued)
Economy - overview: Coal mining is the major
economic activity on Svalbard. The treaty of
9 February 1920 gives the 41 signatories equal rights
to exploit mineral deposits, subject to Norwegian
regulation. Although US, UK, Dutch, and Swedish
coal companies have mined in the past, the only
companies still mining are Norwegian and Russian.
The settlements on Svalbard are essentially company
towns. The Norwegian state-owned coal company
employs nearly 60% of the Norwegian population on
the island, runs many of the local services, and
provides most of the local infrastructure. There is also
some trapping of seal, polar bear, fox, and walrus.
GDP: purchasing power parity - $NA
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: NA
Budget:
revenues; $11.5 million
expenof/fures; $11.5 million, including capital
expenditures of $NA (1998 est.)
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity -consumption: NAkWh
Exports: $NA
Imports: $NA
Economic aid - recipient: $8.2 million from Norway
(1998)
Currency: Norwegian krone (NOK)
Currency code: NOK
Exchange rates: Norwegian kroner per US dollar -
8.7784 (January 2001 ), 8.801 8 (2000), 7.7992 (1 999),
7.5451 (1998), 7.0734 (1997), 6.4498 (1996)','327bf9cd41114fd834de7d3e18e73f8b1b5c3fc1cc449bded8fe33a3c4712514','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9538e62e2c691bf0646456d6abc1ecf80ea3a44f1ac82bc9d9d20d4971d9db0f',2001,'HK','Hong Kong','economy',575,'Economy - overview: Hong Kong has a bustling
free market economy highly dependent on
international trade. Natural resources are limited, and
food and raw materials must be imported. Indeed,
imports and exports, including reexports, each exceed
GDP in dollar value. Even before Hong Kong reverted
to Chinese administration on 1 July 1997 it had
extensive trade and investment ties with China. Per
capita GDP compares with the level in the four big
countries of Western Europe. GDP growth averaged a
strong 5% in 1989-97. The widespread Asian
economic difficulties in 1998 hit this trade-dependent
economy quite hard, with GDP down 5%. The
economy is undergoing a rapid recovery, with growth
of 10% in 2000 to be followed by projected growth of
5% in 2001.
GDP: purchasing power parity - $1 81 billion
(2000 est.)
GDP ■ real growth rate: 10% (2000 est.)
GDP - per capita: purchasing power parity -
$25,400 (2000 est.)
GDP - composition by sector:
agriculture: 0.1%
industry: 14.3%
sen''/ces; 85.6% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 3.7% (2000 est.)
Labor force: 3.39 million (2000 est.)
Labor force - by occupation: wholesale and retail
trade, restaurants, and hotels 31 .5%, community and
social services 24%, financing, insurance, and real
estate 14.5%, transport and communications 1 1.6%,
manufacturing 7.7%, construction 2.6% (October
1999)
Unemployment rate: 4.5% (2000 est.)
Budget:
revenues: $20.8 billion
expenditures: $24.5 billion, including capital
expenditures of $NA (FY99/00)
Industries: textiles, clothing, tourism, electronics,
plastics, toys, watches, clocks
Industrial production growth rate: 2.1% (2000)
Electricity - production: 27.726 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1 999)
Electricity - consumption: 32.202 billion kWh
(1999)
Electricity - exports: 633 million kWh (1999)
Electricity - imports: 7.05 billion kWh (1999)
Agriculture - products: fresh vegetables; poultry
Exports: $204 billion (including reexports; f.o.b.,
2000 est.)
Exports - commodities: clothing, textiles, footwear,
electrical appliances, watches and clocks, toys
Exports - partners: China 33%, US 24%, Japan
5%, UK 4%, Germany, Singapore (1999)
Imports: $215 billion (f.o.b., 2000)
Imports - commodities: foodstuffs, transport
equipment, raw materials, semimanufactures,
petroleum; a large share is reexported
Imports - partners: China 44%, Japan 1 2%, US 7%,
Taiwan 7%, South Korea, Singapore (1999)
Debt -external: $48.1 billion (1999)
Currency: Hong Kong dollar (HKD)
Currency code: HKD
Exchange rates: Hong Kong dollars per US dollar -
7.7990 (January 2001 ), 7.791 2 (2000), 7.7575 (1 999),
7.7453 (1998), 7.7421 (1997), 7.7343 (1996); note -
Hong Kong became a special administrative region of
China on 1 July 1997; before then, the Hong Kong
dollar was linked to the US dollar at the rate of about
7.8 Hong Kong dollars per US dollar
Fiscal year: 1 April - 31 March','cf1f31fb160712eed402a40cc7445db6ff44967e09c7dba7a435c5209374100a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('014f51dd9b4935a318f152d7689f7a51aef9c646175c7d1407b9267ad30f48c9',2001,'AT','Austria','economy',585,'Economy - overview: Iceland''s Scandinavian-type
economy is basically capitalistic, yet with an extensive
welfare system, low unemployment, and remarkably
even distribution of income. In the absence of other
natural resources (except for abundant hydrothermal
and geothermal power), the economy depends
heavily on the fishing industry, which provides 70% of
export earnings and employs 12% of the work force.
The economy remains sensitive to declining fish
stocks as well as to drops in world prices for its main
exports: fish and fish products, aluminum, and
ferrosilicon. The center-right government plans to
continue its policies of reducing the budget and
current account deficits, limiting foreign borrowing,
containing inflation, revising agricultural and fishing
policies, diversifying the economy, and privatizing
state-owned industries. The government remains
opposed to EU membership, primarily because of
Icelanders'' concern about losing control over their
fishing resources. Iceland''s economy has been
diversifying into manufacturing and service industries
in the last decade, and new developments in software
production, biotechnology, and financial services are
taking place. The tourism sector is also expanding,
with the recent trends in ecotourism and whale
watching. Growth has been remarkably steady over
the past five years at 4%-5%.
GDP: purchasing power parity - $6.85 billion
(2000 est.)
GDP ■ real growth rate: 4.3% (2000 est.)
GDP ■ per capita: purchasing power parity -
$24,800 (2000 est.)
GDP - composition by sector:
agriculture: 15% (includes fishing 13%)
industry: 2]%
sen/ices: 64% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Infiation rate (consumer prices): 3.5% (2000 est.)
Labor force: 159,000(2000)
Labor force - by occupation: agriculture 5.1%,
fishing and fish processing 1 1 .8%, manufacturing
12.9%, construction 10.7%, other services 59.5%
(1999)
Unemployment rate: 2.7% (January 2001)
Budget:
revenues: $3.5 billion
expenditures: $3.3 billion, including capital
expenditures of $467 million (1999)
Industries: fish processing; aluminum smelting,
ferrosilicon production, geothermal power; tourism
Industrial production growth rate: 1 .5%
(2000 est.)
Electricity ■ production: 7.069 billion kWh (1999)
Electricity - production by source:
fossil fuel: 0.07%
hydro: 84.64%
nuclear: 0%
other; 15.29% (1999)
Electricity - consumption: 6.574 billion kWh (1 999)
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: potatoes, turnips; cattle,
sheep; fish
Exports: $2 billion (f.o.b., 2000)
Exports - commodities: fish and fish products 70%,
animal products, aluminum, diatomite, ferrosilicon
Exports - partners: EU 64% (UK 20%, Germany
13%, France 5%, Denmark 5%), US 15%, Japan 5%
(1999)
Imports: $2.2 billion (f.o.b., 2000)
Imports ■ commodities; machinery and equipment,
petroleum products; foodstuffs, textiles
Imports - partners: EU 56% (Germany 12%, UK
9%, Denmark 8%, Sweden 6%), US 11%, Norway
10% (1999)
Debt ■ external: $2.6 billion (1999)
Economic aid - donor: $NA
Currency: Icelandic krona (ISK)
Currency code: ISK
Exchange rates: Icelandic kronur per US dollar -
84.81 0 (January 2001 ), 78.676 (2000), 72.335 (1 999),
70.958 (1998), 70.904 (1997), 66.500 (1996)
Fiscal year: calendar year
Economy - overview: India''s economy
encompasses traditional village farming, modern
agriculture, handicrafts, a wide range of modern
industries, and a multitude of support services. More
than a third of the population is too poor to be able to
afford an adequate diet. India''s international
payments position remained strong In 2000 with
adequate foreign exchange reserves, moderately
depreciating nominal exchange rates, and booming
exports of software services. Growth in manufacturing
output slowed, and electricity shortages continue in
many regions.
GDP: purchasing power parity - $2.2 trillion
(2000 est.)
GDP - real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity - $2,200
(2000 est.)
GDP - composition by sector:
agriculture: 25%
industry: 24%
sen//ces;51%(2000)
Population below poverty line: 35% (1994 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.5%
highest 10%: 33.5% (mi)
Inflation rate (consumer prices): 5.4% (2000 est.)
Labor force: NA
Labor force - by occupation: agriculture 67%,
services 18%, industry 15% (1995 est.)
Unemployment rate: NA%
Budget:
revenues: $44.3 billion
expenditures: $73.5 billion, including capital
expenditures of $NA (FYOO/01 est.)
Industries: textiles, chemicals, food processing,
steel, transportation equipment, cement, mining,
petroleum, machinery, software
Industrial production growth rate: 7.5%
(2000 est.)
Electricity - production: 454.561 billion kWh (1999)
Electricity - production by source:
foss///ue/.'' 79.41%
hydro: 17.77%
nuclear: 2.52%
of/)er; 0.3% (1999)
Electricity - consumption: 424.032 billion kWh
(1999)
Electricity - exports: 200 million kWh (1999)
Electricity - imports: 1.49 billion kWh (1999)
Agriculture - products: rice, wheat, oilseed, cotton,
jute, tea, sugarcane, potatoes; cattle, water buffalo,
sheep, goats, poultry; fish
Exports: $43.1 billion (f.o.b., 2000)
Exports - commodities: textile goods, gems and
jewelry, engineering goods, chemicals, leather
manufactures
Exports - partners: US 22%, UK 6%, Germany 5%,
Japan 5%, Hong Kong 5%, UAE 4% (1999)
Imports: $60.8 billion (f.o.b., 2000)
Imports - commodities: crude oil, machinery,
gems, fertilizer, chemicals
Imports - partners: US 9%, Benelux 8%, UK 6%,
Saudi Arabia 6%, Japan 6%, Germany 5% (1999)
Debt - external: $99.6 billion (2000)
Economic aid - recipient: $2.9 billion (FY98/99)
Currency: Indian rupee (INR)
Currency code: INR
Exchange rates: Indian rupees per US dollar -
46.540 (January 2001), 44.942 (2000), 43.055 (1999),
41.259 (1998), 36.313 (1997), 35.433 (1996)
Fiscal year: 1 April - 31 March
Economy - overview: The Indian Ocean provides
major sea routes connecting the Middle East, Africa,
and East Asia with Europe and the Americas. It carries
a particularly heavy traffic of petroleum and petroleum
products from the oilfields of the Persian Gulf and
Indonesia. Its fish are of great and growing importance
to the bordering countries for domestic consumption
and export. Fishing fleets from Russia, Japan, South
Korea, and Taiwan also exploit the Indian Ocean,
mainly for shrimp and tuna. Large reserves of
hydrocarbons are being tapped in the offshore areas
of Saudi Arabia, Iran, India, and western Australia. An
estimated 40% of the world''s offshore oil production
comes from the Indian Ocean. Beach sands rich in
heavy minerals and offshore placer deposits are
actively exploited by bordering countries, particularly
India, South Africa, Indonesia, Sri Lanka, and
Thailand.
Economy - overview: Indonesia, a vast polyglot
nation, faces severe economic problems, stemming
from secessionist movements and the low level of
security in the regions, the lack of reliable legal
recourse in contract disputes, corruption, weaknesses
in the banking system, and strained relations with the
IMF. Investor confidence will remain low and few new
jobs will be created under these circumstances.
Growth of 4.8% in 2000 is not sustainable, being
attributable to favorable short-term factors, including
high world oil prices, a surge in nonoil exports, and
increased domestic demand for consumer durables.
GDP: purchasing power parity - $654 billion
(2000 est.)
GDP - real growth rate: 4.8% (2000 est.)
GDP - per capita: purchasing power parity - $2,900
(2000 est.)
GDP - composition by sector:
agriculture: 2]%
industry: 35%
services: 44% (1999 est.)
Population below poverty line: 20% (1998)
Household income or consumption by percentage
share:
lowest 10%: 3.6%
highest 30.3% (1996)
Inflation rate (consumer prices): 9% (2000 est.)
Labor force: 99 million (1999)
Labor force - by occupation: agriculture 45%,
industry 16%, services 39% (1999 est.)
Unemployment rate: 1 5%-20% (1 998 est.)
Budget:
revenues: $26 billion
expenditures: $30 billion, including capital
expenditures of $NA (2000 est.)
Industries: petroleum and natural gas; textiles,
apparel, and footwear; mining, cement, chemical
fertilizers, plywood; rubber; food; tourism
Industrial production growth rate: 7.5%
(2000 est.)
Electricity - production: 78.674 billion kWh (1999)
Electricity - production by source:
fossil fuel: 80.36%
hydro: 14.63%
nuclear: 0%
ote 5.01% (1999)
Electricity - consumption: 73.167 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: rice, cassava (tapioca),
peanuts, rubber, cocoa, coffee, palm oil, copra;
poultry, beef, pork, eggs
Exports: $64.7 billion (f.o.b., 2000 est.)
Exports - commodities: oil and gas, plywood,
textiles, rubber
Exports - partners: Japan 21%, US 14%,
Singapore 10%, South Korea 7%, Netherlands 3%,
Australia 3%, Hong Kong, China, Taiwan (1999 est.)
Imports: $40.4 billion (c.i.f., 2000 est.)
Imports - commodities: machinery and equipment;
chemicals, fuels, foodstuffs
Imports - partners: Japan 1 2%, US 1 2%, Singapore
10%, Germany 6%, Australia 6%, South Korea 6%,
Taiwan, China (1999 est.)
Debt ■ external: $144 billion (2000 est.)
Economic aid ■ recipient: $43 billion from IMF
program and other official external financing
(1997-2000)
238
Indonesia (continued)
Currency: Indonesian rupiah (IDR)
Currency code: IDR
Exchange rates: Indonesian rupiahs per US dollar -
10,000 (January 2001), 8,421.8 (2000), 7,855.2
(1999), 10,013.6 (1998), 2,909.4 (1997), 2,342.3
(1996)
Fiscal year: calendar year; note - previously was
1 April - 31 March, but starting with 2001 , has been
changed to calendar year
Economy - overview; Iran''s economy is a mixture of
central planning, state ownership of oil and other large
enterprises, village agriculture, and small-scale
private trading and service ventures. President
KHATAMI has continued to follow the market reform
plans of former President RAFSANJANI and has
indicated that he will pursue diversification of Iran''s
oil-reliant economy although he has made little
progress toward that goal. The strong oil market in
1996 helped ease financial pressures on Iran and
allowed for Tehran''s timely debt service payments.
Iran''s financial situation tightened in 1997 and
deteriorated further in 1998 because of lower oil
prices. The subsequent zoom in oil prices in
1999-2000 afforded Iran fiscal breathing room but
does not solve Iran''s structural economic problems,
including the encouragement of foreign investment.
GDP: purchasing power parity - $413 billion
(2000 est.)
GDP ■ real growth rate: 3% (2000 est.)
GDP “ per capita: purchasing power parity - $6,300
(2000 est.)
GDP - composition by sector:
agriculture: 24%
industry: 2Q%
services: 48% (2000 est.)
Popuiation below poverty line: 53% (1996 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 16% (2000 est.)
Labor force: 17.3 million
note: shortage of skilled labor (1 998)
Labor force - by occupation: agriculture 33%,
industry 25%, services 42% (1999 est.)
Unemployment rate: 14% (1999 est.)
Budget:
revenues: $27 billion
expenditures: $27 billion, including capital
expenditures of $NA (1999)
Industries: petroleum, petrochemicals, textiles,
cement and other construction materials, food
processing (particularly sugar refining and vegetable
oil production), metal fabricating, armaments
Industrial production growth rate: 4.4% (nonoil)
(1999)
Electricity - production: 1 03.054 billion kWh (1 999)
Electricity - production by source;
fossil fuel: 93 W/o
hydro: 6.34%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 95.84 billion kWh (1 999)
Electricity - exports; 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: wheat, rice, other grains,
sugar beets, fruits, nuts, cotton; dairy products, wool;
caviar
Exports: $25 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum 85%, carpets,
fruits and nuts, iron and steel, chemicals
Exports ■ partners: Japan, Italy, UAE, South Korea,
France, China
Imports: $15 billion (f.o.b., 2000 est.)
Imports - commodities: industrial raw materials
and intermediate goods, capital goods, foodstuffs and
other consumer goods, technical services, military
supplies
Imports - partners: Germany, South Korea, Italy,
UAE, France, Japan
Debt - external: $7.5 billion (2000 est.)
Economic aid - recipient; $1 1 6.5 million (1 995)
Currency: Iranian rial (IRR)
Currency code: IRR
Exchange rates: Iranian rials per US dollar -
1,754.71 (January 2001), 1,764.43 (2000), 1,725.93
(1999), 1,751.86 (1998), 1,752.92 (1997), 1,750.76
(1996)
note: Iran has three officially recognized exchange
rates; the averages for 1 999 are as follows: the official
floating rate of 1,750 rials per US dollar, the "export"
rate of 3,000 rials per US dollar, and the variable
Tehran Stock Exchange rate, which averages 7,863
rials per US dollar; the market rate averages 8,615
rials per US dollar
Fiscal year: 21 March - 20 March
Economy - overview; Iraq''s economy is dominated
by the oil sector, which has traditionally provided
about 95% of foreign exchange earnings. In the
1980s, financial problems caused by massive
expenditures in the eight-year war with Iran and
damage to oil export facilities by Iran led the
government to implement austerity measures, borrow
heavily, and later reschedule foreign debt payments;
Iraq suffered economic losses of at least $100 billion
from the war. After the end of hostilities in 1988, oil
exports gradually Increased with the construction of
new pipelines and restoration of damaged facilities.
Iraq''s seizure of Kuwait in August 1990, subsequent
international economic sanctions, and damage from
military action by an international coalition beginning
in January 1 991 drastically reduced economic activity.
Although government policies supporting large
military and internal security forces and allocating
resources to key supporters of the regime have hurt
the economy, Implementation of the UN''s oil-for-food
program in December 1996 has helped improve
conditions for the average Iraqi citizen. For the first
six, six-month phases of the program, Iraq was
allowed to export limited amounts of oil in exchange
for food, medicine, and some infrastructure spare
parts. In December 1999. the UN Security Council
authorized Iraq to export under the program as much
oil as required to meet humanitarian needs. Oil
exports are now more than three-quarters their prewar
level. Per capita food imports have increased
significantly, while medical supplies and health care
services are steadily improving. Per capita output and
living standards are still well below the prewar level,
but any estimates have a wide range of error.
GDP: purchasing power parity - $57 billion
(2000 est.)
GDP - real growth rate: 15% (2000 est.)
GDP - per capita: purchasing power parity - $2,500
(2000 est.)
GDP - composition by sector:
agriculture: 6%
industry: 13%
semces; 81 % (1 993 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 100% (2000 est.)
Labor force: 4.4 million (1989)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: NA%
Budget:
revenues.'' $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: petroleum, chemicals, textiles,
construction materials, food processing
243
Iraq (continued)
Industrial production growth rate: NA%
Electricity - production: 29.42 billion kWh (1999)
Electricity - production by source:
fossil fuel: 97.96%
hydro: 2.04%
nuclear: 0%
other: 0%{^m)
Electricity ■ consumption: 27.361 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: wheat, barley, rice,
vegetables, dates, cotton; cattle, sheep
Exports: $21.8 billion (2000 est.)
Exports - commodities: crude oil
Exports - partners: Russia, France, Switzerland,
China (2000)
Imports: $13.8 billion (2000 est.)
Imports - commodities: food, medicine,
manufactures
Imports - partners: Egypt, Russia, France, Vietnam
(2000)
Debt - external: $139 billion (2000 est.)
Economic aid - recipient: $327.5 million (1995)
Currency: Iraqi dinar (IQD)
Currency code: IQD
Exchange rates: Iraqi dinars per US dollar - 0.31 09
(fixed official rate since 1 982); black market rate - Iraqi
dinars per US dollar - 1 ,91 0 (December 1 999), 1 ,81 5
(December 1998), 1,530 (December 1997), 910
(December 1996), 3,000 (December 1995); note -
subject to wide fluctuations
Fiscal year: calendar year','d41b90c94e649148518e06da8f2ce07a479e8fdeb30b6a766a6d55d74b577288','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ede53946dcef3a11b14e0f403f2963af18e2b540b078297e968d09162db8fdc',2001,'IE','Ireland','economy',595,'Economy ■ overview: Ireland is a small, modern,
trade-dependent economy with growth averaging a
robust 9% in 1995-2000. Agriculture, once the most
important sector, is now dwarfed by industry, which
accounts for 38% of GDP and about 80% of exports
and employs 28% of the labor force. Although exports
remain the primary engine for Ireland''s robust growth,
the economy is also benefiting from a rise in consumer
spending and recovery in both construction and
business investment. Over the past decade, the Irish
government has implemented a series of national
economic programs designed to curb inflation, reduce
government spending, increase labor force skills, and
promote foreign investment. Ireland joined in
launching the euro currency system in January 1999
along with 10 other EU nations. The Irish economy is
in danger of overheating, with the tight labor market
driving up wage demands and inflation.
GDP: purchasing power parity - $81 .9 billion
(2000 est.)
GDP ■ real growth rate: 9.9% (2000 est.)
GDP ■ per capita: purchasing power parity -
$21,600 (2000 est.)
GDP - composition by sector:
agriculture: 4%
industry: 38%
services: 58% (1 999)
Population below poverty line: 10% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%: 2%
highest /0%; 27.3% (1997)
Inflation rate (consumer prices): 5.6% (2000)
Labor force: 1 .82 million (2000 est.)
Labor force - by occupation: services 64%,
industry 28%, agriculture 8% (2000 est.)
Unemployment rate: 4.1% (2000)
Budget:
revenues: $25.7 billion
expenditures: 2 billion, including capital
expenditures of $2 billion (2000)
Industries: food products, brewing, textiles, clothing;
chemicals, pharmaceuticals, machinery,
transportation equipment, glass and crystal; software
Industrial production growth rate: 14%
(2000 est.)
Electricity - production: 19.542 billion kWh (1999)
Electricity ■ production by source:
foss/7 fue/; 94.42%
hydro: 423%
nuclear: 0%
ofoer 1.35% (1999)
Electricity - consumption: 18.414 billion kWh
(1999)
Electricity ■ exports: 50 million kWh (1999)
Electricity ■ imports: 290 million kWh (1999)
Agriculture - products: turnips, barley, potatoes,
sugar beets, wheat; beef, dairy products
Exports: $73.5 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment,
computers, chemicals, pharmaceuticals; live animals,
animal products
Exports - partners: EU 59% (UK 19%, Germany
9%, France 7%), US 20% (2000)
Imports: $45.7 billion (f.o.b., 2000 est.)
Imports - commodities: data processing
equipment, other machinery and equipment,
chemicals; petroleum and petroleum products,
textiles, clothing
Imports - partners: EU 54% (UK 29%, Germany
6%, France 5%), US 18%, Japan 5%, Singapore 4%
(2000)
Debt - external: $11 billion (1998)
Economic aid - donor: ODA, $245 million (2000)
Currency: Irish pound (lEP); euro (EUR)
note: on 1 January 1 999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Ireland at a fixed rate of
0.787564 Irish pounds per euro and will replace the
local currency for all transactions in 2002
Currency code: lEP; EUR
Exchange rates: Irish pounds per US dollar - 1 .0658
(January 2001 ), 1 .0823 (2000), 0.9374 (1 999), 0.701 4
(1998), 0.6588 (1997), 0.6248 (1996)
Fiscal year: calendar year','5d830e8a1a48d93b4f0a7ac380f69aef7df89f3697c6934d47fd2015e10d8c2c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fef4f79e3178418531195b0007ca70b3b06d55beb276f75884298e926c62ffcb',2001,'IL','Israel','economy',603,'Economy - overview: Israel has a technologically
advanced market economy with substantial
government participation. It depends on imports of
crude oil, grains, raw materials, and military
equipment. Despite limited natural resources, Israel
has intensively developed its agricultural and
248
IsraGi (continued)
industrial sectors over the past 20 years. Israel is
largely self-sufficient in food production except for
grains. Cuts diamonds, high-technology equipment,
and agricultural products (fruits and vegetables) are
the leading exports. Israel usually posts sizable
current account deficits, which are covered by large
transfer payments from abroad and by foreign loans.
Roughly half of the government’s external debt is
owed to the US, which is its major source of economic
and military aid. The influx of Jewish immigrants from
the former USSR topped 750,000 during the period
1989-99, bringing the population of Israel from the
former Soviet Union to 1 million, one-sixth of the total
population, and adding scientific and professional
expertise of substantial value for the economy''s
future. The influx, coupled with the opening of new
markets at the end of the Cold War, energized Israel''s
economy, which grew rapidly in the early 1990s. But
growth began moderating in 1996 when the
government imposed tighter fiscal and monetary
policies and the immigration bonus petered out.
Growth was a strong 5.9% in 2000. But the outbreak
of Palestinian unrest in late September and the
collapse of the BARAK Government - coupled with a
cooling off in the high-technology and tourist sectors -
undercut the boom and foreshadows a slowdown to
2%-3%in2001.
GDP: purchasing power parity - $1 1 0.2 billion
(2000 est.)
GDP - real growth rate: 5.9% (2000 est.)
GDP - per capita: purchasing power parity -
$18,900 (2000 est.)
GDP - composition by sector:
agriculture: 4%
industry: 37%
services: 59% est.)
Popuiation beiow poverty iine: NA%
Household Income or consumption by percentage
share:
lowest 10%: 2.8%
highest 26.9% (1992)
Inflation rate (consumer prices): 0.1% (2000 est.)
Labor force: 2.4 million (2000 est.)
Labor force - by occupation: public services
31 .2%, manufacturing 20.2%, finance and business
13.1%, commerce 12.8%, construction 7.5%,
personal and other services 6.4%, transport, storage,
and communications 6.2%, agriculture, forestry, and
fishing 2.6% (1996)
Unemployment rate: 9% (2000 est.)
Budget:
revenues: $40 billion
expenditures: $42 A billion, including capital
expenditures of $NA (2000 est.)
Industries: high-technology projects (including
aviation, communications, computer-aided design
and manufactures, medical electronics), wood and
paper products, potash and phosphates, food,
beverages, and tobacco, caustic soda, cement,
diamond cutting
Industrial production growth rate: 7% (2000)
Electricity - production: 35.437 billion kWh (1999)
Electricity ■ production by source:
fossil fuel: 99.89%
hydro: 0M%
nuclear: 0%
of/)er.- 0% (1999)
Electricity ■ consumption: 31.899 billion kWh
(1999)
Electricity ■ exports: 1.061 billion kWh (1999)
Electricity - imports: 4 million kWh (1999)
Agriculture - products: citrus, vegetables, cotton;
beef, poultry, dairy products
Exports: $31.5 billion (f.o.b., 2000)
Exports - commodities: machinery and equipment,
software, cut diamonds, agricultural products,
chemicals, textiles and apparel
Exports ■ partners: US 36%, UK 6%, Benelux 5%,
Hong Kong 4%, Netherlands 4% (1999)
Imports: $35.1 billion (f.o.b., 2000)
Imports - commodities: raw materials, military
equipment, investment goods, rough diamonds, fuels,
consumer goods
Imports - partners: US 20%, Benelux 11%,
Germany 8%, UK 8%, Switzerland 6%, Italy 5%
(1999)
Debt - external: $38 billion (2000 est.)
Economic aid ■ recipient: $1.1 billion from the US
(1999)
Currency: new Israeli shekel (ILS)
Currency code: ILS
Exchange rates: new Israeli shekels per US dollar -
4.0810 (December 2000), 4.0773 (2000), 4.1397
(1999), 3.8001 (1998), 3.4494 (1997), 3.1917 (1996)
Fiscal year: calendar year','15df3cdff7e3fa6599c530b15d46736923baab7b4476e3725d65708a55f77d34','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('015006b77780dc0c7a692286e34fab17dcd9c33010255cfc8321a52a0f68e0a7',2001,'TN','Tunisia','economy',611,'Economy - overview: Italy has a diversified
industrial economy with roughly the same total and
per capita output as France and the UK. This
capitalistic economy remains divided into a developed
industrial north, dominated by private companies, and
a less developed agricultural south, with more than
20% unemployment. Most raw materials needed by
industry and more than 75% of energy requirements
are imported. Since 1992, Italy has adopted budgets
compliant with the requirements of the European
Monetary Union (EMU); wage moderation
agreements by representatives of government, labor,
and employers have helped to bring Italy''s Inflation
into conformity with EMU requirements. Italy''s
economic performance, however, has lagged behind
that of its EU partners and it must work to stimulate
employment, promote labor flexibility, reform its
expensive pension system, and tackle the informal
GDP; purchasing power parity - $1 .273 trillion
(2000 est.)
GDP - real growth rate: 2.7% (2000 est.)
GDP - per capita: purchasing power parity -
$22,100 (2000 est.)
GDP - composition by sector:
agriculture: 2.5%
industry: 30 A%
services: 67.1% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3.5%
highest /0%; 21 .8% (1995)
Inflation rate (consumer prices): 2.5% (2000)
Labor force: 23.4 million (2000)
Labor force - by occupation: services 61 .9%,
industry 32.6%, agriculture 5.5% (1999)
Unemployment rate: 10.4% (2000 est.)
Budget;
revenues: $488 billion
expenditures: $501 billion, including capital
expenditures of $NA (2000 est.)
Industries: tourism, machinery, iron and steel,
chemicals, food processing, textiles, motor vehicles,
clothing, footwear, ceramics
Industrial production growth rate: 1.9% (2000)
Electricity - production: 247.679 billion kWh (1999)
Electricity - production by source:
fossil fuel: 79.09%
hydro: 18.08%
nuclear: 0%
other; 2.83% (1999)
251
Italy (continued)
Electricity - consumption: 272.35 billion kWh
(1999)
Electricity - exports: 530 million kWh (1999)
Electricity - imports: 42.539 billion kWh (1999)
Agriculture - products: fruits, vegetables, grapes,
potatoes, sugar beets, soybeans, grain, olives; beef,
dairy products; fish
Exports: $241.1 billion (f.o.b., 2000)
Exports ■ commodities: engineering products,
textiles and clothing, production machinery, motor
vehicles, transport equipment, chemicals; food,
beverages and tobacco; minerals and nonferrous
metals
Exports ■ partners: EU 56.8% (Germany 16.4%,
France 12.9%, Netherlands 7.1%, Spain 6.3%,
Netherlands 2.9%), US 9.5% (1999)
Imports: $231.4 billion (f.o.b., 2000)
Imports - commodities: engineering products,
chemicals, transport equipment, energy products,
minerals and nonferrous metals, textiles and clothing;
food, beverages and tobacco
Imports “ partners: EU 61% (Germany 19.3%,
France 12.6%, Netherlands 6.3%, Spain 4.4%), US
5.0% (1999)
Debt ■ external: $NA
Economic aid ■ donor: ODA, $1.3 billion (1997)
Currency: Italian lira (!TL); euro (EUR)
note.'' on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Italy at a fixed rate of 1 ,936.27
Italian lire per euro and will replace the local currency
for all transactions in 2002
Currency code: ITL; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999); Italian
lire per US dollar - 1 ,688.7 (January 1 999), 1 ,736.2
(1998), 1,703.1 (1997), 1,542.9(1996)
Fiscal year: calendar year
Economy ■ overview: Tunisia has a diverse
economy, with important agricultural, mining, energy,
tourism, and manufacturing sectors. Governmental
control of economic affairs while still heavy has
gradually lessened over the past decade with
508
Tunisia (continued)
increasing privatization, simplification of the tax
structure, and a prudent approach to debt. Rea!
growth averaged 5.5% in the past four years, and
inflation is slowing. Growth in tourism and increased
trade have been key elements in this steady growth.
Tunisia''s association agreement with the European
Union entered into force on 1 March 1998, the first
such accord between the EU and Mediterranean
countries to be activated. Under the agreement
T unisia will gradually remove barriers to trade with the
EU over the next decade. Broader privatization,
further liberalization of the investment code to
increase foreign investment, and improvements in
government efficiency are among the challenges for
the future.
GDP; purchasing power parity - $62.8 billion
(2000 est.)
GDP - real growth rate; 5% (2000 est.)
GDP - per capita; purchasing power parity - $6,500
(2000 est.)
GDP - composition by sector;
agriculture: 14%
industry: 32%
services: 54% (1999 est.)
Population below poverty line: 6% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.3%
highest 70%; 30.7% (1990)
Inflation rate (consumer prices): 3% (2000 est.)
Labor force: 2.65 million (2000 est.)
note: shortage of skilled labor
Labor force - by occupation: services 55%,
industry 23%, agriculture 22% (1995 est.)
Unemployment rate: 15.6% (2000 est.)
Budget:
revenues: $7.5 billion
expenditures: $3.^ billion, including capital
expenditures to $1.6 billion (2000 est.)
Industries: petroleum, mining (particularly
phosphate and iron ore), tourism, textiles, footwear,
food, beverages
Industrial production growth rate: 4.1%
(2000 est.)
Electricity - production; 9.173 billion kWh (1999)
Electricity - production by source:
fossil fuel: 99.2%
hydro: 0.8%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 8.677 billion kWh (1 999)
Electricity - exports: 19 million kWh (1999)
Electricity - imports: 165 million kWh (1999)
Agriculture - products: olives, olive oil, grain, dairy
products, tomatoes, citrus fruit, beef, sugar beets,
dates, almonds
Exports: $6.1 billion (f.o.b., 2000 est.)
Exports ■ commodities: textiles, mechanical
goods, phosphates and chemicals, agricultural
products, hydrocarbons
Exports - partners: Germany 28%, France 22%,
Italy 17%, Belgium 5%, Libya 4% (1999)
Imports: $8.4 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
hydrocarbons, chemicals, food
Imports - partners: France 23%, Germany 23%,
Italy 15%, Belgium 3% (1999)
Debt - external: $13 billion (2000 est.)
Economic aid - recipient: $933.2 million (1995);
note - ODA, $90 million (1998 est.)
Currency: Tunisian dinar (TND)
Currency code: TND
Exchange rates: Tunisian dinars per US dollar -
1 .3753 (January 2001), 1 .4667 (November 2000),
1.1862 (1999), 1.1387 (1998), 1.1059 (1997), 0.9734
(1996)
Fiscal year: calendar year
Economy - overview: T urkey''s dynamic economy is
a complex mix of modern industry and commerce
along with traditional agriculture that still accounts for
nearly 40% of employment. It has a strong and rapidly
growing private sector, yet the state still plays a major
role in basic industry, banking, transport, and
communication. The most important industry - and
largest exporter - is textiles and clothing, which is
almost entirely in private hands. In recent years the
economic situation has been marked by erratic
economic growth and serious imbalances. Real GNP
growth has exceeded 6% in most years, but this
strong expansion was interrupted by sharp declines in
output in 1994 and 1999. Meanwhiie the public sector
fiscal deficit has regularly exceeded 10% of GDP -
due in large part to the huge burden of interest
payments, which now account for more than 40% of
central government spending - while inflation has
remained in the high double digit range. Perhaps
because of these problems, foreign direct investment
in Turkey remains low - less than $1 billion annually.
Prospects for the future are improving, however,
because the ECEVIT government since June 1999
has been implementing an IMF-backed reform
program, including a tighter budget, social security
reform, banking reorganization, and accelerated
privatization. As a result, the fiscal situation is greatly
Improved and inflation has dropped below 40% - the
lowest rate since 1 987. The country experienced a
financial crisis in late 2000, including sharp drops in
the stock market and foreign exchange reserves, but
is recovering rapidly, thanks to additional IMF support
and the government''s commitment to a specific
timetable of economic reforms.
GDP: purchasing power parity - $444 billion
(2000 est.)
GDP ■ real growth rate: 6% (2000 est.)
GDP ■ per capita: purchasing power parity - $6,800
(2000 est.)
GDP - composition by sector:
agriculture: 15%
industry: 29%
services: 56% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.3%
highest 10%: 32.3% (1994)
Inflation rate (consumer prices): 39% (2000 est.)
Labor force: 23 million (2000 est.)
note: about 1 .2 million Turks work abroad (1999)
Labor force - by occupation: agriculture 38%,
services 38%, industry 24% (2000)
Unemployment rate: 5.6% (plus underemployment
of 5.6%) (2000 est.)
Budget:
revenues: $54.5 billion
expenditures: $75.2 billion, including capital
expenditures of $3.3 billion (2000)
Industries: textiles, food processing, autos, mining
(coal, chromite, copper, boron), steel, petroleum,
construction, lumber, paper
Industrial production growth rate: 6.2%
(2000 est.)
Electricity - production: 125.3 billion kWh
(2000 est.)
Electricity ■ production by source:
fossil fuel: 71%
hydro: 29%
nuclear: 0%
other: 0% (2000 est.)
Electricity - consumption: 1 1 9.5 billion kWh
(2000 est.)
Electricity - exports: 350 million kWh (2000 est.)
Electricity - Imports: 3.35 billion kWh (2000 est.)
Agriculture - products: tobacco, cotton, grain,
olives, sugar beets, pulse, citrus; livestock
Exports: $26.9 billion (f.o.b., 2000 est.)
511
Turkey (continued)
Exports ■ commodities: apparel 25.6%, foodstuffs
15.4%, textiles 12.3%, metal manufactures 8.6%,
transport equipment 8.1% (1998)
Exports - partners: Germany 1 8.7%, US 1 1 .4%, UK
7.4%, italy 6.3%, France 6.0% (2000 est.)
Imports: $55.7 billion (c.i.f., 2000 est.)
Imports - commodities: machinery 28.3%,
chemicals 15.2%, semi-finished goods 14.5%, fuels
11%, transport equipment 9.5% (1999)
Imports - partners: Germany 13.1%, Italy 7.9%, US
7.2%, Russia 7.0%, France 6.6%, UK 5.0%
(2000 est.)
Debt - external: $109 billion (2000 est.)
Economic aid - recipient: ODA, $1 95 million (1 993)
Currency: Turkish lira (TRL)
Currency code: TRL
Exchange rates: Turkish liras per US dollar -
677,621 (December 2000), 625,219 (2000), 418,783
(1999), 260,724 (1998), 151,865 (1997), 81,405
(1996)
Fiscal year: calendar year
Economy ■ overview: Turkmenistan is largely
desert country with intensive agriculture in irrigated
oases and huge gas (fifth largest reserves in the
world) and oil resources. One-half of its irrigated land
is planted in cotton, making it the world''s tenth largest
producer. Until the end of 1993, Turkmenistan had
experienced less economic disruption than other
former Soviet states because its economy received a
boost from higher prices for oil and gas and a sharp
increase in hard currency earnings. In 1994, Russia''s
refusal to export Turkmen gas to hard currency
markets and mounting debts of its major customers in
the former USSR for gas deliveries contributed to a
sharp fall in industrial production and caused the
budget to shift from a surplus to a slight deficit. With an
authoritarian ex-communist regime in power and a
tribally based social structure, Turkmenistan has
taken a cautious approach to economic reform,
hoping to use gas and cotton sales to sustain its
inefficient economy. Privatization goals remain
limited. In 1998-2000, Turkmenistan suffered from the
continued lack of adequate export routes for natural
gas and from obligations on extensive short-term
external debt. At the same time, however, total exports
rose sharply because of higher international oil and
gas prices. Prospects in the near future are
discouraging because of widespread internal poverty
and the burden of foreign debt. IMF assistance would
seem to be necessary, yet the government is not as
yet ready to accept IMF requirements. Turkmenistan''s
1999 deal to ship 20 billion cubic meters (bcm) of
natural gas through Russia''s Gazprom pipeline helped
alleviate the 2000 fiscal shortfall. Inadequate fiscal
restraint and the tenuous nature of Turkmenistan''s
2001 gas deals, combined with a lack of economic
reform, will limit progress in the near term.
GDP: purchasing power parity - $19.6 billion
(2000 est.)
GDP - real growth rate: 16% (2000 est.)
GDP - per capita: purchasing power parity - $4,300
(2000 est.)
GDP ■ composition by sector:
agriculture: 25%
industry: A3%
services: 32% (1999 est.)
Population below poverty line: 58% (1 999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.0%
highest m; 31 .7% (1998)
Inflation rate (consumer prices): 14% (2000 est.)
Labor force: 2.34 million (1996)
Labor force - by occupation: agriculture 44%,
industry 19%, services 37% (1996)
Unemployment rate: NA%
Budget:
revenues: $588.6 million
expenditures: $658.2 million, including capital
expenditures of $NA (1 999 est.)
Industries: natural gas, oil, petroleum products,
textiles, food processing
Industrial production growth rate: 18%
(2000 est.)
Electricity - production: 8.371 billion kWh (1999)
Electricity - production by source:
fossil fuel: 99.94%
hydro: 0.06%
nuclear: 0%
of/ier; 0% (1999)
Electricity - consumption: 4.785 billion kWh (1999)
Electricity - exports: 4.1 billion kWh (1999)
Electricity - imports: 1.1 billion kWh (1999)
Agriculture - products: cotton, grain; livestock
Exports: $2.4 billion (f.o.b., 2000 est.)
Exports - commodities: gas 33%, oil 30%, cotton
fiber 18%, textiles 8% (1999)
Exports ■ partners: Ukraine, Iran, Turkey, Russia,
Kazakhstan, Tajikistan, Azerbaijan
Imports: $1.65 billion (c.i.f., 2000 est.)
Imports - commodities: machinery and equipment
60%, foodstuffs 15% (1999)
Imports - partners: Ukraine, Turkey, Russia,
Germany, US, Kazakhstan, Uzbekistan
Debt - external: $2.5 billion (2000 est.)
Economic aid - recipient: $27.2 million (1995)
Currency: Turkmen manat (TMM)
Currency code: TMM
Exchange rates: Turkmen manats per US dollar -
5,200 (January 2001), 5,200 (January 2000), 5,350
(January 1999), 4,070 (January 1997), 2,400
(January 1996)
Fiscal year: calendar year
Economy - overview: The Turks and Caicos
economy is based on tourism, fishing, and offshore
financial services. Most capital goods and food for
domestic consumption are imported. The US was the
leading source of tourists in 1 996, accounting for more
than half of the 87,000 visitors: tourist arrivals had
risen to 93,000 by 1 998. Major sources of government
revenue include fees from offshore financial activities
and customs receipts.
GDP: purchasing power parity - $128 million
(1999 est.)
GDP - real growth rate: 8.7% (1999 est.)
GDP ■ per capita: purchasing power parity - $7,300
(1999 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 4% (1 995)
Labor force: 4,848 (1990 est.)
Labor force - by occupation: about 33% in
government and 20% in agriculture and fishing;
significant numbers in tourism, financial, and other
services (1997 est.)
Unemployment rate: 10% (1997 est.)
Budget:
revenues: $47 million
expenditures: $33.6 million, including capital
expenditures of $NA (1997-1998 est.)
Industries: tourism, offshore financial services
Industrial production growth rate: NA%
Electricity - production: 5 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(m9)
Electricity - consumption: 4.6 million kWh (1999)
Electricity - exports: 0 kWh (1 999)
Electricity ■ imports: 0 kWh (1999)
Agriculture - products: corn, beans, cassava
(tapioca), citrus fruits; fish
Exports: $4.7 million (1993)
Exports - commodities: lobster, dried and fresh
conch, conch shells
Exports ■ partners: US, UK
Imports: $46.6 million (1993)
Imports ■ commodities: food and beverages,
tobacco, clothing, manufactures, construction
materials
Imports - partners: US, UK
Debt -external: $NA
Economic aid - recipient: $4.1 million (1997)
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: calendar year','571740b32e7f2e6b1f75df67d4a902e461f0c86e293e616420f486c546858a95','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f74a50d3b169eedb01eb9750cf57f06a2d9cd8995f165081ebd77254b7941456',2001,'JM','Jamaica','economy',620,'Economy - overview: Key sectors in this island
economy are bauxite (alumina and bauxite account
for more than half of exports) and tourism. Since
assuming office in 1992, Prime Minister PATTERSON
has eliminated most price controls, streamlined tax
schedules, and privatized government enterprises.
Continued tight monetary and fiscal policies have
helped slow inflation - although inflationary pressures
are mounting - and stabilize the exchange rate, but
have resulted in the slowdown of economic growth
(moving from 1.5% in 1992 to 0.5% in 1995). In 1996,
GDP showed negative growth (-1 .4%) and remained
negative through 1999. Serious problems include:
high interest rates; increased foreign competition; the
weak financial condition of business in general
resulting in receiverships or closures and downsizings
of companies; the shift in investment portfolios to
non-productive, short-term high yield instruments; a
pressured, sometimes sliding, exchange rate; a
widening merchandise trade deficit; and a growing
internal debt for government bailouts to various ailing
sectors of the economy, particularly the financial
sector. Depressed economic conditions in 1999-2000
led to increased civil unrest, including a mounting
crime rate. Jamaica''s medium-term prospects will
depend upon encouraging investment in the
productive sectors, maintaining a competitive
exchange rate, stabilizing the labor environment,
selling off reacquired firms, and implementing proper
fiscal and monetary policies.
GDP: purchasing power parity - $9.7 billion
(2000 est.)
GDP - real growth rate: 0.2% (2000 est.)
GDP - per capita: purchasing power parity - $3,700
(2000 est.)
GDP - composition by sector:
agriculture: 7.4%
industry: 35.2%
services: 57.4% (1999 est.)
Population below poverty line: 34.2% (1992 est.)
Household Income or consumption by percentage
share:
lowest 10%: 2.9%
b/g/7esM0%; 28.9% (1996)
Inflation rate (consumer prices): 8.8% (2000 est.)
Labor force: 1 . 1 3 million (1 998)
Labor force - by occupation: services 60%,
agriculture 21%, industry 19% (1998)
Unemployment rate: 16% (2000 est.)
Budget:
revenues: $2.23 billion
expenditures: $2.50 billion, including capital
expenditures of $232.5 million (FY99/00 est.)
Industries: tourism, bauxite, textiles, food
processing, light manufactures, rum, cement, metal,
paper, chemical products
Industrial production growth rate: -2% (2000 est.)
Electricity ■ production: 6.53 billion kWh (1999)
Electricity ■ production by source:
fossil fuel: 92.28%
hydro: 1.30%
nuclear: 0%
other 6.36% (1999)
Electricity - consumption: 6.073 billion kWh (1 999)
Electricity ■ exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: sugarcane, bananas,
coffee, citrus, potatoes, vegetables; poultry, goats,
milk
Exports: $1.7 billion (f.o.b., 2000 est.)
Exports ‘ commodities: alumina, bauxite; sugar,
bananas, rum
Exports - partners: US 35.7%, EU (excluding UK)
15.8%, UK 13%, Canada 10.5% (1999)
Imports: $3 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment, construction materials, fuel, food,
chemicals, fertilizers
Imports - partners: US 47.8%, Caricom countries
12.4%, Latin America 7.2%, EU (excluding UK) 4.7%
(1999)
Debt - external: $4.7 billion (2000 est.)
Economic aid - recipient: $102.7 million (1995)
Currency: Jamaican dollar (JMD)
Currency code: JMD
Exchange rates: Jamaican dollars per US dollar -
45.557 (January 2001), 42.701 (2000), 39.044 (1999),
36.550 (1998), 35.404 (1997), 37.120 (1996)
Fiscal year: 1 April - 31 March
Location: Northern Europe, island between the
Greenland Sea and the Norwegian Sea, northeast of','78f69f8b05192a342703a25bc973af801bffd8acb963679daa93b27ceb75531c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f67a34b92b642620d8648382ad978c137efb59288d437b1f8fe27f19372dfbf',2001,'IS','Iceland','economy',625,'Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area:
total: 373 sq km
land: 373 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims:
contiguous zone: 1 0 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 4
Climate: arctic maritime with frequent storms and
persistent fog
Terrain: volcanic island, partly covered by glaciers
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Haakon Vll Toppen/Beerenberg 2,277 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
Economy - overview: Jan Mayen is a volcanic
island with no exploitable natural resources.
Economic activity is limited to providing services for
employees of Norway''s radio and meteorological
stations located on the island.','150ba9a57e64aa5530fc6d4eb622d8751f3be7c5da6a090d81453c50f9b8b380','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f06ae1a947111bb79eaa77f5b01da25eebfdfdd86c3c01e84d4cbd4897184adc',2001,'NO','Norway','economy',632,'Economy - overview: Government-industry
cooperation, a strong work ethic, mastery of high
technology, and a comparatively small defense
allocation (1% of GDP) have helped Japan advance
with extraordinary rapidity to the rank of second most
technologically powerful economy in the world after
the US and third largest economy in the world after the
US and China. One notable characteristic of the
economy is the working together of manufacturers,
suppliers, and distributors in closely-knit groups called
keiretsu. A second basic feature has been the
guarantee of lifetime employment for a substantial
portion of the urban labor force. Both features are now
eroding. Industry, the most important sector of the
economy, is heavily dependent on imported raw
materials and fuels. The much smaller agricultural
sector is highly subsidized and protected, with crop
yields among the highest in the world. Usually
self-sufficient in rice, Japan must import about 50% of
its requirements of other grain and fodder crops.
Japan maintains one of the world''s largest fishing
fleets and accounts for nearly 1 5% of the global catch.
For three decades overall real economic growth had
been spectacular: a 10% average in the 1960s, a 5%
average in the 1 970s, and a 4% average in the 1 980s.
G rowth slowed markedly in the 1 990s largely because
of the aftereffects of overinvestment during the late
1980s and contractionary domestic policies intended
to wring speculative excesses from the stock and real
estate markets. Government efforts to revive
economic growth have met little success and were
further hampered in late 2000 by the slowing of the US
and Asian economies. The crowding of habitable land
area and the aging of the population are two major
long-run problems. Robotics constitutes a key
long-term economic strength, with Japan possessing
41 0,000 of the world''s 720,000 "working robots".
GDP: purchasing power parity - $3.15 trillion
(2000 est.)
GDP - real growth rate: 1 .3% (2000 est.)
GDP - per capita: purchasing power parity -
$24,900 (2000 est.)
GDP - composition by sector:
agriculture: 2%
Industry: 35%
semces;63%(1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 4.8%
highest /0%; 21. 7% (1993)
Inflation rate (consumer prices): -0.7% (2000 est.)
Labor force: 67.7 million (December 2000)
Labor force ■ by occupation: services 65%,
industry 30%, agriculture 5%
Unemployment rate: 4.7% (2000)
Budget:
revenues; $441 billion
expenditures: $718 billion, including capital
expenditures (public works only) of about $84 billion
(FY01/02 est.)
Industries: among world''s largest and
technologically advanced producers of motor
vehicles, electronic equipment, machine tools, steel
and nonferrous metals, ships, chemicals; textiles,
processed foods
Industrial production growth rate: 5.3%
(2000 est.)
Electricity - production: 1.018 trillion kWh (1999)
Electricity ■ production by source:
fossil fuel: 88.91%
hydro: 8.85%
nuclear: 80.81%
of/?er; 2.43% (1999)
Electricity - consumption: 947.038 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rice, sugar beets,
vegetables, fruit; pork, poultry, dairy products, eggs; .
fish
Exports: $450 billion (f.o.b., 2000)
Exports - commodities: motor vehicles,
semiconductors, office machinery, chemicals
Exports “ partners: US 30%, Taiwan 7%, South
Korea 6.4%, China 6.2%, Hong Kong 5.6%
(2000 est.)
Imports: $355 billion (c.i.f., 2000)
Imports - commodities: fuels, foodstuffs,
chemicals, textiles, office machinery
Imports - partners: US 19%, China 14.5%, South
Korea 5.4%, Taiwan 4.8%, Indonesia 4.3%, Australia
3.9% (2000 est.)
257
Japan (continued)
Debt - external: $NA
Economic aid - donor: ODA, $9.1 billion (1999)
Currency: yen(JPY)
Currency code: JPY
Exchange rates: yen per US dollar - 117.10
(January 2001 ), 1 07.77 (2000), 1 1 3.91 (1 999), 1 30.91
(1998), 120.99 (1997), 108.78 (1996)
Fiscal year: 1 April - 31 March
Economy - overview: The Norwegian economy is a
prosperous bastion of welfare capitalism, featuring a
combination of free market activity and government
intervention. The government controls key areas,
such as the vital petroleum sector (through
large-scale state enterprises). The country is richly
endowed with natural resources - petroleum,
hydropower, fish, forests, and minerals - and is highly
dependent on its oil production and international oil
prices; in 1999, oil and gas accounted for 35% of
exports. Only Saudi Arabia exports more oil than
Norway. Oslo opted to stay out of the EU during a
referendum in November 1994. Growth picked up in
2000 to 2.7%, compared to the meager 0.8% of 1 999,
but may fall back in 2001 . The government moved
ahead with privatization in 2000, even proposing the
sale of up to one-third of the 100% state-owned oil
company Statoil. Despite their high per capita income
and generous welfare benefits, Norwegians worry
about that time in the next two decades when the oil
and gas begin to run out. Accordingly, Norway has
been saving its oil-boosted budget surpluses in a
Government Petroleum Fund, which is invested
abroad and now is valued at more than $43 billion.
GDP: purchasing power parity - $124.1 billion
(1999 est.)
GDP - real growth rate: 2.7% (2000 est.)
GDP - per capita: purchasing power parity -
$27,700 (2000 est.)
GDP - composition by sector:
agriculture: 2%
industry: 25%
semces;73%(1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest )0%.*4.1%
highest /0%.'' 21.8% (1995)
Inflation rate (consumer prices): 2.9% (2000 est.)
Labor force: 2.4 million (2000 est.)
Labor force - by occupation: services 74%,
industry 22%, agriculture, forestry, and fishing 4%
(1995)
Unemployment rate: 3% (2000 est.)
Budget:
revenues; $71 .7 billion
expend/fures; $57.6 billion, Including capital
expenditures of $NA (2000 est.)
Industries: petroleum and gas, food processing,
shipbuilding, pulp and paper products, metals,
chemicals, timber, mining, textiles, fishing
Industrial production growth rate: 3% (2000 est.)
Electricity - production: 1 21 .084 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 0.63%
hydro; 99.11%
nuclear: 0%
other; 0.26% (1999)
Electricity - consumption: 1 1 0.795 billion kWh
(1999)
Electricity - exports: 8.28 billion kWh (1999)
Electricity - imports: 6.467 billion kWh (1999)
Agriculture - products: barley, other grains,
potatoes; beef, milk; fish
Exports: $59.2 billion (f.o.b., 2000 est.)
Exports - commodities; petroleum and petroleum
products, machinery and equipment, metals,
chemicals, ships, fish
Exports - partners: EU 73% (UK 17%, Germany
11%, Netherlands 10%, Sweden 9%), US 5% (1999)
Imports: $35.2 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
chemicals, metals, foodstuffs
Imports - partners: EU 66% (Sweden 15%,
Germany 12%, UK 9%, Denmark 7%), US 10%,
Japan (1999)
Debt ■ external: $0 (Norway is a net external
creditor)
Economic aid - donor: ODA, $1 .4 billion (1 998)
Currency: Norwegian krone (NOK)
Currency code: NOK
Exchange rates; Norwegian kroner per US dollar -
8.7784 (January 2001 ), 8.801 8 (2000), 7.7992 (1 999),
7.5451 (1998), 7.0734 (1997), 6.4498 (1996)
Fiscal year: calendar year
Economy ■ overview: Oman''s economic
performance improved significantly in 2000 due
largely to the upturn in oil prices. The government is
moving ahead with privatization of its utilities, the
development of a body of commercial law to facilitate
foreign investment, and increased budgetary outlays.
Oman continues to liberalize its markets and joined
the World Trade Organization (WTrO) in November
2000.
GDP: purchasing power parity - $19.6 billion
(2000 est.)
GDP - real growth rate: 4.6% (2000 est.)
GDP ■ per capita: purchasing power parity - $7,700
(2000 est.)
GDP - composition by sector:
agriculture: 3%
industry: 40%
semces; 57% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): -0.8% (2000 est.)
Labor force: 850,000 (1 997 est.)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: NA%
Budget:
revenues; $4.7 billion
expenditures: $5.9 billion, including capital
expenditures of $490 million (1999)
Industries: crude oil production and refining, natural
gas production, construction, cement, copper
Industrial production growth rate: 4% (2000 est.)
Electricity - production: 8.63 billion kWh (1999)
Electricity - production by source:
foss/7 fee/; 100%
hydro: 0%
nuclear: 0%
ofoer; 0% (1999)
Electricity - consumption: 8.026 billion kWh (1 999)
Electricity « exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: dates, limes, bananas,
alfalfa, vegetables; camels, cattle; fish
Exports: $11.1 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum, reexports, fish,
metals, textiles
Exports - partners: Japan 27%, China 12%,
Thailand 18%, UAE 12%, South Korea 12%, US
(1999)
Imports: $4.5 billion (f.o.b., 2000 est.)
Imports ■ commodities: machinery and transport
equipment, manufactured goods, food, livestock,
lubricants
Imports - partners: UAE 26% (largely reexports),
Japan 16%, UK 9%, Italy 7%, Germany 6%, US
(1999)
Debt - external: $4.5 billion (2000 est.)
Economic aid - recipient: $76.4 million (1 995)
Currency: Omani rial (OMR)
Currency code: OMR
Exchange rates: Omani rials per US dollar - 0.3845
(fixed rate since 1986)
Fiscal year: calendar year
Economy - overview: The Pacific Ocean is a major
contributor to the world economy and particularly to
those nations its waters directly touch. It provides
low-cost sea transportation between East and West,
extensive fishing grounds, offshore oil and gas fields,
minerals, and sand and gravel for the construction
industry. In 1 996, over 60% of the world''s fish catch
came from the Pacific Ocean. Exploitation of offshore
oil and gas reserves is playing an ever-increasing role
in the energy supplies of Australia, NZ, China, US,
and Peru. The high cost of recovering offshore oil and
gas, combined with the wide swings in world prices for
oil since 1985, has slowed but not stopped new
drillings.
Economy - overview: Pakistan is a poor, heavily
populated country, suffering from internal political
disputes, lack of foreign investment, and a costly
confrontation with neighboring India, Pakistan''s
economic outlook continues to be marred by its weak
foreign exchange position, which relies on
international creditors for hard currency inflows. The
MUSHARRAF government will face an estimated $21
billion in foreign debt coming due In 2000-03, despite
having rescheduled nearly $2 billion in debt with Paris
Club members. Foreign loans and grants provide
approximately 25% of government revenue, but debt
service obligations total nearly 50% of government
expenditure. Although Pakistan successfully
negotiated a $600 million IMF Stand-By Arrangement,
future loan installments will be jeopardized if Pakistan
misses critical IMF benchmarks on revenue collection
and the fiscal deficit. MUSHARRAF has complied
largely with IMF recommendations to raise petroleum
prices, widen the tax net, privatize public sector
assets, and improve the balance of trade. However,
Pakistan''s economic prospects remain uncertain; too
little has changed despite the new administration''s
intentions. Foreign exchange reserves hover at
roughly $1 billion, GDP growth hinges on crop
performance, the import bill has been hammered by
high oil prices, and both foreign and domestic
investors remain wary of committing to projects in
Pakistan.
GDP: purchasing power parity - $282 billion
(2000 est.)
GDP - real growth rate: 4.8% (2000 est.)
GDP - per capita: purchasing power parity - $2,000
(2000 est.)
GDP - composition by sector:
agriculture: 25.4%
industry: 24.9%
services: 49.7% (1999 est.)
Population below poverty line: 40% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%:AA%
highest 27.7% (1996)
Inflation rate (consumer prices): 5.2% (2000 est.)
Labor force: 40 million
note: extensive export of labor, mostly to the Middle
East, and use of child labor (2000 est.)
Labor force - by occupation: agriculture 44%,
industry 17%, services 39% (1999 est.)
Unemployment rate: 6% (FY99/00 est.)
Budget:
revenues: $8.9 billion
expenditures: $1 1 .6 billion, including capital
expenditures of $NA (FYOO/01 est.)
Industries: textiles, food processing, beverages,
construction materials, clothing, paper products,
shrimp
Industrial production growth rate: 3.8%
(1999 est.)
Eiectricity - production: 62.078 billion kWh (1999)
388
Pakistan (continued)
Electricity - production by source:
fossil fuel: 63.38%
hydro: 3^.5^%
nuclear: 0A]%
other: 0%(m9)
Electricity ■ consumption: 57.732 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: cotton, wheat, rice,
sugarcane, fruits, vegetables; milk, beef, mutton, eggs
Exports: $8.6 billion (f.o.b., FY99/00)
Exports - commodities: textiies (garments, cotton
cloth, and yarn), rice, other agricultural products
Exports - partners: US 24%, Hong Kong 7%, UK
7%, Germany 6%, UAE 6% (FY99/00)
Imports: $9.6 billion (f.o.b., FY99/00)
Imports ■ commodities: machinery, petroleum,
petroleum products, chemicals, transportation
equipment, edible oils, grains, pulses, flour
Imports - partners: Saudi Arabia 8%, UAE 8%, US
6%, Japan 6%, Malaysia 4% (FY99/00)
Debt - external: $38 billion (2000 est.)
Economic aid - recipient: $2 billion (FY99/00)
Currency: Pakistani rupee (PKR)
Currency code: PKR
Exchange rates: Pakistani rupees per US dollar -
59.152 (January 2001), 52.814 (2000), 49.1 18 (1999),
44.943 (1998), 40.918 (1997), 35.909 (1996)
Fiscal year: 1 July - 30 June
Economy - overview: The economy consists
primarily of subsistence agriculture and fishing. The
government is the major employer of the work force,
relying heavily on financial assistance from the US.
The population enjoys a per capita income of twice
that of the Philippines and much of Micronesia.
Long-run prospects for the tourist sector have been
greatly bolstered by the expansion of air travel in the
Pacific and the rising prosperity of leading East Asian
countries.
GDP: purchasing power parity - $129 million
(1998 est.)
note: GDP numbers reflect US spending
GDP - real growth rate: -1 .4% (1 998 est.)
GDP - per capita: purchasing power parity - $7,100
(1998 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
390
Palau (continued)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 8,300(1999)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 2,3% (2000 est.)
Budget:
revenues: $57.7 million
expenditures: $80.8 million, including capital
expenditures of $17.1 million (FY98/99 est.)
Industries: tourism, craft items (from shell, wood,
pearls), construction, garment making
Industrial production growth rate: NA%
Agriculture - products: coconuts, copra, cassava
(tapioca), sweet potatoes
Exports: $14.3 million (f.o.b., 1996)
Exports - commodities: trochus (type of shellfish),
tuna, copra, handicrafts
Exports - partners: US, Japan
Imports: $126 million (f.o.b., FY99/00)
Imports “ commodities: machinery and equipment,
fuels, metals; foodstuffs
Imports - partners: US
Debt -external: $0(FY99/00)
Economic aid - recipient: $155.8 million (1995);
note - the Compact of Free Association with the US,
entered into after the end of the UN trusteeship on
1 October 1994, will provide Palau with up to $700
million in US aid over 1 5 years in return for furnishing
military facilities
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September','08696fcbc543ff047cf1b4d6b6cc1f4441f16022177add15b0f0e854e4f00511','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85e15dd4886e2046cbf38cc6587b7e8e302934c25adebfd11a8f13a21b2091b9',2001,'JO','Jordan','economy',640,'Economy - overview: Jordan is a small Arab
country with inadequate supplies of water and other
natural resources such as oil. The Persian Gulf crisis,
which began in August 1990, aggravated Jordan''s
already serious economic problems, forcing the
government to stop most debt payments and suspend
rescheduling negotiations. Aid from Gulf Arab states,
worker remittances, and trade revenues contracted.
Refugees flooded the country, producing serious
balance-of-payments problems, stunting GDP growth,
and straining government resources. The economy
rebounded in 1992, largely due to the influx of capital
repatriated by workers returning from the Gulf. After
averaging 9% in 1992-95, GDP growth averaged only
1 .5% during 1 996-99. In an attempt to spur growth,
King ABDALLAH has undertaken limited economic
reform, including partial privatization of some
state-owned enterprises and Jordan''s entry in
January 2000 into the World Trade Organization
(WTrO). Debt, poverty, and unemployment are
fundamental ongoing economic problems.
GDP: purchasing power parity - $17.3 billion
(2000 est.)
GDP - real growth rate: 2% (2000 est.)
GDP - per capita: purchasing power parity - $3,500
(2000 est.)
GDP - composition by sector:
agriculture: 3%
industry: 25%
se/v/ces;72%(1998 est.)
Population below poverty line: 30% (1998 est.)
Household Income or consumption by percentage
share:
lowest 10%: 2.4%
highest m; 34.7% (1991)
Inflation rate (consumer prices): 0.7% (2000 est.)
Labor force; 1.15 million
note: in addition, at least 300,000 workers are
employed abroad (1997 est.)
Labor force - by occupation: industry 1 1 .4%,
commerce, restaurants, and hotels 10.5%,
construction 10%, transport and communications
8.7%, agriculture 7.4%, other services 52% (1992)
Unemployment rate: 1 5% official rate; actual rate is
25%-30%(1999 est.)
Budget:
revenues: $2.8 billion
expenditures: $3.1 billion, including capital
expenditures of $NA (2000 est.)
Industries; phosphate mining, petroleum refining,
cement, potash, light manufacturing, tourism
Industrial production growth rate: 3.8%
(2000 est.)
Electricity - production: 6.657 billion kWh (1999)
Electricity - production by source:
fossil fuel: 99.79%
hycfro; 0.21%
nuclear: 0%
other: 0%(m0)
Electricity - consumption: 6.594 billion kWh (1 999)
Electricity ■ exports: 4 million kWh (1999)
Electricity ■ imports: 407 million kWh (1999)
Agriculture - products; wheat, barley, citrus,
tomatoes, melons, olives; sheep, goats, poultry
Exports: $2 billion (f.o.b., 2000 est.)
Exports - commodities: phosphates, fertilizers,
potash, agricultural products, manufactures
Exports - partners: India, Iraq, Saudi Arabia, EU,
Indonesia, UAE, Lebanon, Kuwait, Syria, Ethiopia
Imports; $4 billion (f.o.b., 2000 est.)
Imports - commodities: crude oil, machinery,
transport equipment, food, live animals, manufactured
goods
Imports ■ partners: Iraq, Germany, US, Japan, UK,
Italy, Turkey, Malaysia, Syria, China
Debt - external: $8 billion (2000 est.)
Economic aid ■ recipient: ODA, $850 million
(1996 est.)
Currency: Jordanian dinar (JOD)
Currency code: JOD
Exchange rates: Jordanian dinars per US dollar -
0.7090 (1996-present)
note: since May 1 989, the Jordanian dinar has been
pegged to a group of currencies
Fiscal year: calendar year','da22ce2915f2ed0756d3491084134cd77328ababbd12bbd8c85ee53d5c483e5f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ec86690c60942a1abd559a90ee109328bb91e7ace580d5a7b86ccbf4b7b5ca',2001,'KZ','Kazakhstan','economy',649,'Economy - overview: Kazakhstan, the second
largest of the former Soviet republics in territory,
possesses enormous fossil fuel reserves as well as
plentiful supplies of other minerals and metals. It also
is a large agricultural - livestock and grain - producer.
Kazakhstan''s industrial sector rests on the extraction
and processing of these natural resources and also on
a growing machine-building sector specializing in
construction equipment, tractors, agricultural
machinery, and some defense items. The breakup of
the USSR in December 1991 and the collapse of
demand for Kazakhstan''s traditional heavy industry
products resulted in a short-term contraction of the
economy, with the steepest annual decline occurring
in 1994. In 1995-97, the pace of the government
program of economic reform and privatization
quickened, resulting in a substantial shifting of assets
into the private sector. The Caspian Pipeline
Consortium agreement to build a new pipeline from
western Kazakhstan''s Tengiz oil field to the Black Sea
increases prospects for substantially larger oil exports
in several years. Kazakhstan''s economy again turned
downward in 1998 with a 2% decline in GDP due to
slumping oil prices and the August financial crisis in
Russia. The recovery of international oil prices in
1999, combined with a well-timed tenge devaluation
and a bumper grain harvest, pulled the economy out
of recession in 2000. Astana has embarked upon an
industrial policy designed to diversify the economy
away from overdependence on the oil sector by
developing light industry.
GDP: purchasing power parity - $85.6 billion
(2000 est.)
GDP - real growth rate: 10.5% (2000 est.)
GDP - per capita: purchasing power parity - $5,000
(2000 est.)
GDP - composition by sector:
agriculture: 10%
industry: 30%
services: 60% (1999 est.)
Population below poverty line: 35% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.7%
highest 10%: 26.3% (^9%)
Inflation rate (consumer prices): 13.4%
(2000 est.)
Labor force: 8.8 million (1997)
Labor force - by occupation: industry 27%,
agriculture 23%, services 50% (1996)
Unemployment rate: 13.7% (1998 est.)
Budget:
revenues.'' $3.1 billion
expenof/fures; $3.6 billion, including capital
expenditures of $NA (1 999 est.)
266
Kazakhstan (continued)
Industries: oil, coal, iron ore, manganese, chromite,
lead, zinc, copper, titanium, bauxite, gold, silver,
phosphates, sulfur, iron and steel, nonferrous metal,
tractors and other agricultural machinery, electric
motors, construction materials
Industrial production growth rate: 14.9%
(2000 est.)
Electricity ■ production: 44.36 billion kWh (1999)
Electricity - production by source:
fossil fuel: 87.12%
hydro: 12.65%
nuclear: 0.23%
other: 0%(1999)
Electricity - consumption: 44.132 billion kWh
(1999)
Electricity - exports: 200 million kWh (1999)
Electricity - Imports: 3.077 billion kWh (1999)
Agriculture - products: grain (mostly spring wheat),
cotton; wool, livestock
Exports: $8.8 billion (f.o.b., 2000 est.)
Exports - commodities: oil 40%, ferrous and
nonferrous metals, machinery, chemicals, grain, wool,
meat, coal
Exports ■ partners: EU 23%, Russia 20%, China
8% (1999)
Imports: $6.9 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and parts,
industrial materials, oil and gas, vehicles
Imports - partners: Russia 37%, US, Uzbekistan,
Turkey, UK, Germany, Ukraine, South Korea (1999)
Debt - external: $12.5 billion (2000 est.)
Economic aid - recipient: $409.6 million (1995)
Currency: tenge (KZT)
Currency code: KZT
Exchange rates; tenge per US dollar - 145.09
(January 2001), 142.13(2000), 119.52 (1999), 78.30
(1998), 75.44 (1997), 67.30 (1996)
Fiscal year: calendar year','49052215d6b0b7ec46792e2b915057254b92afa449cb3bd2fed1c8bb6edc0dff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dceb408ba014d89497a03dff35014778104e08a65c1e800352e25bbe04fa14a0',2001,'KE','Kenya','economy',658,'Economy - overview: Kenya is well placed to serve
as an engine of growth in East Africa, but its economy
has been stagnating because of poor management
and uneven commitment to reform. In 1993, the
government of Kenya implemented a program of
economic liberalization and reform that included the
removal of import licensing, price controls, and foreign
exchange controls. With the support of the World
Bank, IMF, and other donors, the reforms led to a brief
turnaround in economic performance following a
period of negative growth in the early 1990s. Kenya''s
real GDP grew 5% in 1995 and 4% in 1996, and
inflation remained under control. Growth slowed after
1997, averaging only 1.5% in 1997-2000. In 1997,
political violence damaged the tourist industry, and
Kenya''s Enhanced Structural Adjustment Program
lapsed due to the government''s failure to maintain
reform or address public sector corruption. Severe
drought in 1999 and 2000 caused water and energy
rationing and reduced agricultural sector productivity.
A new economic team was put in place in 1999 to
revitalize the reform effort, strengthen the civil service,
and curb corruption. The IMF and World Bank
renewed their support to Kenya in mid-2000, but a
number of setbacks to the economic reform program
in late 2000 have renewed donor and private sector
concern about the government''s commitment to
sound governance. Long-term barriers to
development include electricity shortages, inefficient
government dominance of key sectors, endemic
corruption, and high population growth.
GDP: purchasing power parity - $45.6 billion
(2000 est.)
GDP - real growth rate: 0.4% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,500
(2000 est.)
GDP - composition by sector:
agriculture: 25%
industry: ^3%
services: 62% (1 999 est.)
Population below poverty line: 42% (1992 est.)
Household income or consumption by percentage
share:
lowest 10%:].S%
highest ^0%; 34.9% (1994)
Inflation rate (consumer prices): 7% (2000 est.)
Labor force: 9.2 million (1998 est.)
Labor force ■ by occupation; agriculture 75%-80%
Unemployment rate: 50% (1998 est.)
Budget:
revenues: $2.91 billion
expenditures: $2.97 billion, including capital
expenditures of $NA (2000 est.)
Industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, cigarettes, flour),
agricultural products processing; oil refining, cement;
tourism
Industrial production growth rate: 0.5%
(2000 est.)
Electricity - production: 4.225 billion kWh (1999)
Electricity - production by source:
fossil fuel: 3^%
hydro: 67%
nuclear: 0%
of/ier; 2% (1999 est.)
Electricity - consumption: 4.075 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 146 million kWh (1999)
Agriculture - products: coffee, tea, corn, wheat,
sugarcane, fruit, vegetables; dairy products, beef,
pork, poultry, eggs
Exports: $1.7 billion (f.o.b., 2000 est.)
Exports - commodities: tea, coffee, horticultural
products, petroleum products, fish, cement
Exports - partners: Uganda 18%, UK 15%,
Tanzania 12%, Pakistan 8% (1999)
Imports: $3 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and
transportation equipment, petroleum products, iron
and steel
Imports - partners: UK 12%, UAE 8%, Japan 8%,
US 7% (1999)
Debt • external: $6.2 billion (2000)
Economic aid - recipient; $457 million (1997)
Currency: Kenyan shilling (KES)
Currency code: KES
Exchange rates: Kenyan shillings per US dollar -
78.733 (December 2000), 76.176 (2000), 70.326
(1999), 60.367 (1998), 58.732 (1997), 57.115 (1996)
Fiscal year: 1 July - 30 June
269
Kenya (continued)','563fb2d4c05c66fb7427017ba62939b01a78b65268616f838e1d3564bc56a690','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d07ff5653c559651fc9541ec431b69a4588a8f3b8b3b7ea69df9b045d4d6f61d',2001,'WS','Samoa','economy',666,'Economy - overview: no economic activity
Economy - overview: no economic activity
Economy - overview: The economy of Samoa has
traditionally been dependent on development aid,
family remittances from overseas, and agricultural
exports. The country is vulnerable to devastating
storms. Agriculture employs two-thirds of the labor
force, and furnishes 90% of exports, featuring coconut
cream, coconut oil, and copra. The manufacturing
sector mainly processes agricultural products.
Tourism is an expanding sector, accounting for 1 5% of
GDP; about 85,000 tourists visited the islands in 2000.
The Samoan Government has called for deregulation
of the financial sector, encouragement of investment,
and continued fiscal discipline. Observers point to the
flexibility of the labor market as a basic strength for
future economic advances. Foreign reserves are in a
relatively healthy state, the external debt Is stable, and
inflation is low.
GDP: purchasing power parity - $571 million
(2000 est.)
GDP - real growth rate: 6.8% (2000 est.)
GDP - per capita: purchasing power parity - $3,200
(2000 est.)
GDP “ composition by sector:
agriculture: 15%
industry: 24%
services: 61% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%>:m%
Inflation rate (consumer prices): 0.8% (2000 est.)
Labor force: 90,000 (2000 est.)
Labor force - by occupation: agriculture 65%,
services 30%, industry 5% (1995 est.)
Unemployment rate: NA%; note - substantial
underemployment
Budget:
revenues: $74.8 million
expenditures: $81 .4 million, including capital
expenditures of $NA (1 999 est.)
Industries: food processing, building materials, auto
parts
Industrial production growth rate: 10%
(2000 est.)
Electricity - production: 100 million kWh (1999)
Electricity - production by source:
fossil fuel: 60%
hydro: 40%
nuclear: 0%
other: 0%(m9)
Electricity - consumption: 93 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coconuts, bananas, taro,
yams
Exports: $17 million (f.o.b., 2000)
Exports - commodities: coconut oil and cream,
copra, fish, beer
Exports - partners: American Samoa 59%, US
18%, Germany 9%, New Zealand 8% (2000 est.)
Imports: $90 million (f.o.b., 2000)
Imports - commodities: machinery and equipment,
industrial supplies, foodstuffs
Imports - partners: New Zealand 37%, Australia
24%, Fiji 14%, US 14% (2000 est.)
Debt - external: $1 80 million (1 998 est.)
Economic aid ■ recipient: $42.9 million (1995)
Currency: tala(WST)
Currency code: WST
Exchange rates: tala per US dollar - 3.3400
(January 2001), 3.2712 (2000), 3.0120 (1999), 2.9429
(1998), 2.5562 (1997), 2.4618 (1996)
Fiscal year: calendar year','82285db21f3919ef5972d37090ec12ed6b158b6321eeed6b26b1d6f3ee1bbd9e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56310e93d0db32577e9562a19260f11ba0e1f5a50515deec8a7980e327a0aaea',2001,'KG','Kyrgyzstan','economy',674,'Economy - overview: Kyrgyzstan is a small, poor,
mountainous country with a predominantly agricultural
economy. Cotton, wool, and meat are the main
agricultural products and exports. Industrial exports
Include gold, mercury, uranium, and electricity.
Kyrgyzstan has been one of the most progressive
countries of the former Soviet Union in carrying out
market reforms. Following a successful stabilization
program, which lowered inflation from 88% in 1994 to
15% for 1997, attention is turning toward stimulating
growth. Much of the government''s stock in enterprises
has been sold. Drops in production had been severe
since the breakup of the Soviet Union in December
1991, but by mid-1995 production began to recover
and exports began to increase. Pensioners,
unemployed workers, and government workers with
salary arrears continue to suffer. Foreign assistance
played a substantial role in the country''s economic
turnaround in 1996-97. Growth was held down to
2.1% in 1998 largely because of the spillover from
Russia''s economic difficulties, but moved ahead to
3.6% in 1999 and an estimated 5.7% in 2000. The
government has adopted a series of measures to
combat such persistent problems as excessive
external debt, inflation, and inadequate revenue
collection.
GDP: purchasing power parity - $1 2.6 billion
(2000 est.)
GDP - real growth rate: 5.7% (2000 est.)
GDP - per capita: purchasing power parity - $2,700
(2000 est.)
GDP - composition by sector:
agriculture: 39%
industry: 22%
services: 39% (1999 est.)
Population below poverty line: 51% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.7%
highest /0%; 31 .7% (1997)
Inflation rate (consumer prices): 18.7%
(2000 est.)
Labor force: 1.7 million
Labor force - by occupation: agriculture 55%,
industry 15%, services 30% (1999 est.)
Unemployment rate: 6% (1998 est.)
Budget:
revenues: $207.4 million
expenditures: $23Q.7 million, including capital
expenditures of $NA (1 999 est.)
Industries; small machinery, textiles, food
processing, cement, shoes, sawn logs, refrigerators,
furniture, electric motors, gold, rare earth metals
Industrial production growth rate: 7% (2000 est.)
Electricity ■ production: 12.981 billion kWh (1999)
Electricity ■ production by source:
fossil fuel: 6.67%
hydro: 93.33%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 10.236 billion kWh
(1999)
Electricity - exports: 2.02 billion kWh (1999)
Electricity - imports: 184 million kWh (1999)
Agriculture - products: tobacco, cotton, potatoes,
vegetables, grapes, fruits and berries; sheep, goats,
cattle, wool
Exports: $482 million (f.o.b., 2000 est.)
Exports - commodities: cotton, wool, meat,
tobacco; gold, mercury, uranium, hydropower;
machinery; shoes
Exports ■ partners: Germany 33%, Russia 16%,
Kazakhstan 10%, Uzbekistan 10%, China 6% (1999)
Imports: $579 million (f.o.b., 2000 est.)
Imports - commodities: oil and gas, machinery and
equipment, foodstuffs
Imports - partners: Russia 18%, Kazakhstan 12%,
US 9%, Germany 8%, Uzbekistan 8%, China (1999)
Debt - external: $1 .4 billion (2000 est.)
Economic aid - recipient: $329.4 million (1995)
Currency: Kyrgyzstani som (KGS)
Currency code: KGS
Exchange rates: soms per US dollar - 48.701
(January 2001), 47.704 (2000), 39.008 (1999), 20.838
(1998), 17.362 (1997), 12.810 (1996)
Fiscal year: calendar year
281
Kyrgyzstan (continued)
Economy - overview: The government of Laos -
one of the few remaining official communist states -
began decentralizing control and encouraging private
enterprise in 1986. The results, starting from an
extremely low base, were striking - growth averaged
7% during 1988-97. Reform efforts subsequently
slowed, and GDP growth dropped an average of 3
percentage points. Because Laos depends heavily on
its trade with Thailand, it was damaged by the
regional financial crisis beginning In 1997.
Government mismanagement deepened the crisis,
and from June 1997 to June 1999 the Lao kip lost
87% of its value. Laos'' foreign exchange problems
peaked in September 1999 when the kip fell from
3,500 kip to the dollar to 9,000 kip to the dollar in a
matter of weeks. Now that the currency has stabilized,
however, the government seems content to let the
current situation persist, despite limited government
revenue and foreign exchange reserves. A
landlocked country with a primitive Infrastructure,
Laos has no railroads, a rudimentary road system,
and limited external and Internal telecommunications.
Electricity is available in only a few urban areas.
Subsistence agriculture accounts for half of GDP and
provides 80% of total employment. For the
foreseeable future the economy will continue to
depend on aid from the IMF and other international
283
Laos (continued)
sources; Japan Is currently the largest bilateral aid
donor; aid from the former USSR/Eastern Europe has
been cut sharply.
GDP: purchasing power parity - $9 billion (2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,700
(2000 est.)
GDP ■ composition by sector:
agriculture: 5^%
industry: 22%
services: 27% (1999 est.)
Population below poverty line: 46.1% (1993 est.)
Household Income or consumption by percentage
share:
lowest 10%; 4.2%
highest 10%: 2M% (m2)
Inflation rate (consumer prices): 33% (2000 est.)
Labor force: 1 million - 1.5 million
Labor force - by occupation: agriculture 80%
(1997 est.)
Unemployment rate: 5.7% (1 997 est.)
Budget:
revenues: $21 1 million
expenditures: $462 million, including capital
expenditures of $NA (FY98/99 est.)
Industries: tin and gypsum mining, timber, electric
power, agricultural processing, construction,
garments, tourism
Industrial production growth rate: 7.5%
(1999 est.)
Electricity - production: 792 million kWh (1999)
Electricity - production by source:
fossil fuel: 2.76%
hydro: 97. 22%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 1 73.6 million kWh
(1999)
Electricity - exports: 705 million kWh (1999)
Electricity - imports: 142 million kWh (1999)
Agriculture - products: sweet potatoes,
vegetables, corn, coffee, sugarcane, tobacco, cotton;
tea, peanuts, rice; water buffalo, pigs, cattle, poultry
Exports: $323 million (f.o.b., 2000 est.)
Exports - commodities: wood products, garments,
electricity, coffee, tin
Exports - partners: Vietnam, Thailand, Germany,
France, Belgium
Imports: $540 million (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
vehicles, fuel
Imports - partners: Thailand, Japan, Vietnam,
China, Singapore, Hong Kong
Debt - external: $2.46 billion (1998 est.)
Economic aid - recipient: $345 million (1999 est.)
Currency: kip(LAK)
Currency code: LAK
Exchange rates: kips per US dollar - 7,578.00
(December 2000), 7,102.03 (1999), 3,298.33 (1998),
1,259.98 (1997), 921.02 (1996)
Fiscal year: 1 October - 30 September','21bcf4512f04b093edbb4615c96bd2bfbd5f58944203f5ff50c820a4dfafc8e8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('182d7621136e961f47192df8b770266d34beafe9fbaa679d7eb83ef159bafd63',2001,'LV','Latvia','economy',683,'Economy - overview: In 2000, Latvia''s transitional
economy recovered from the 1998 Russian financial
crisis, largely due to the SKELE government''s budget
stringency and a gradual reorientation of exports
toward EU countries, lessening Latvia''s trade
dependency on Russia. Latvia officially joined the
World Trade Organization in February 1999 - the first
Baltic state to join - and was invited at the Helsinki EU
Summit in December 1 999 to begin accession talks In
early 2000. Unemployment fell to 7.8% In 2000, down
from 9.6% in 1999, and 9.2% In 1998. Privatization of
large state-owned utilities and the shipping industry
faced more delays in 2000, and political instability will
continue to delay completion of the privatization
process over the next year. Latvia projects 6% GDP
growth, 2.5%-3.0% inflation, and a 1.7% fiscal deficit
In 2001 . Preparing for EU membership over the next
few years remains a top foreign policy goal.
GDP: purchasing power parity - $17.3 billion
(2000 est.)
GDP - real growth rate: 5.5% (2000 est.)
GDP - per capita: purchasing power parity - $7,200
(2000 est.)
GDP - composition by sector:
agriculture: 5%
industry: 33%
services: 52% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2M
highest 25.9% (1998)
Inflation rate (consumer prices): 2.7% (2000)
Labor force: 1 .4 million (2000 est.)
Labor force - by occupation: agriculture 10%,
industry 25%, services 65% (2000 est.)
Unemployment rate: 7.8% (2000 est.)
Budget:
revenues; $1.33 billion
expenditures: $1 .27 billion, Including capital
expenditures of $NA (1 998 est.)
Industries: buses, vans, street and railroad cars,
synthetic fibers, agricultural machinery, fertilizers,
washing machines, radios, electronics,
pharmaceuticals, processed foods, textiles; note -
dependent on imports for energy, raw materials, and
intermediate products
Industrial production growth rate: 6.3%
(2000 est.)
Electricity - production: 3.996 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 31 .78%
hydro: 68.22%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 4.31 6 billion kWh (1 999)
Electricity - exports: 400 million kWh (1999)
Electricity - Imports: 1 billion kWh (1999)
Agriculture - products: grain, sugar beets,
potatoes, vegetables; beef, milk, eggs; fish
Exports: $2.1 billion (f.o.b., 2000)
Exports - commodities: wood and wood products,
machinery and equipment, metals, textiles, foodstuffs
Exports - partners: Germany 16%, UK 1 1%,
Sweden 11%, Russia 7% (1999)
Imports: $3.2 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment,
chemicals, fuels
Imports - partners: Russia 15%, Germany 10%,
Finland 9%, Sweden 7% (1999)
Debt - external: $800 million (2000 est.)
Economic aid - recipient: $96.2 million (1995)
Currency: Latvian lat (LVL)
Currency code: LVL
Exchange rates: lati per US dollar - 0.614 (January
2001), 0.607 (2000), 0.585 (1999), 0.590 (1998),
0.581 (1997), 0.551 (1996)
Fiscal year: calendar year','4c69412f165659abc36cb306ac8173131365372e7772e2eb1ac6f1e920c6cfcc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebd60cc5221d1078a48e26ed9572edc0247892d1f2e65bc1489e337a77a3489a',2001,'LB','Lebanon','economy',692,'Economy - overview: The 1975-91 civil war
seriously damaged Lebanon''s economic
infrastructure, cut national output by half, and all but
ended Lebanon''s position as a Middle Eastern
entrepot and banking hub. Peace enabled the central
government to restore control in Beirut, begin
collecting taxes, and regain access to key port and
government facilities. Economic recovery was helped
by a financially sound banking system and resilient
small- and medium-scale manufacturers. Family
remittances, banking services, manufactured and
farm exports, and international aid provided the main
sources of foreign exchange. Lebanon''s economy has
made impressive gains since the launch in 1993 of
"Horizon 2000," the government''s $20 billion
reconstruction program. Real GDP grew 8% in 1994,
7% in 1 995, 4% per year in 1 996 and 1 997 but slowed
to 2% in 1998, -1% in 1999, and 1% in 2000. Annual
inflation fell during the course of the 1990s from more
than 100% to 0%, and foreign exchange reserves
jumped from $1 .4 billion to more than $6 billion.
Burgeoning capital inflows have generated foreign
payments surpluses, and the Lebanese pound has
remained very stable for the past two years. Lebanon
has rebuilt much of its war-torn physical and financial
infrastructure. Solidere, a $2-billion firm, has
managed the reconstruction of Beirut''s central
business district; the. stock market reopened in
January 1996; and international banks and insurance
companies are returning. The government
nonetheless faces serious challenges in the economic
arena. It has funded reconstruction by tapping foreign
exchange reserves and by borrowing heavily - mostly
from domestic banks. The newly re-installed HARIRI
government''s announced policies fail to address the
ever-increasing budgetary deficits and national debt
burden. The gap between rich and poor has widened
in the 1990s, resulting in grassroots dissatisfaction
over the skewed distribution of the reconstruction''s
benefits.
GDP: purchasing power parity - $1 8.2 billion
(2000 est.)
GDP ■ real growth rate: 1% (2000 est.)
GDP - per capita: purchasing power parity - $5,000
(2000 est.)
GDP - composition by sector:
agriculture: 12%
industry: 27%
services: 61% (1999 est.)
Population below poverty line: 28% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 0% (2000 est.)
Labor force: 1 .3 million (1 999 est.)
note: in addition, there are as many as 1 million
foreign workers (1997 est.)
Labor force - by occupation: services NA%,
industry NA%, agriculture NA%
288
Lebanon (continued)
Unemployment rate: 18% (1 997 est.)
Budget:
revenues: billion
expenditures: $5.55 billion, including capital
expenditures of $NA (2000 est.)
Industries: banking: food processing; jewelry;
cement: textiles; mineral and chemical products;
wood and furniture products; oil refining; metal
fabricating
Industrial production growth rate: NA%
Electricity - production: 7.748 billion kWh (1999)
Electricity - production by source:
fossil fuel: 91 .29%
/?ycfro; 8.71%
nuclear: 0%
other: 0%(m9)
Electricity - consumption: 7.86 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 654 million kWh (1999)
Agriculture - products: citrus, grapes, tomatoes,
apples, vegetables, potatoes, olives, tobacco; sheep,
goats
Exports: $700 million (f.o.b., 2000 est.)
Exports ■ commodities: foodstuffs and tobacco,
textiles, chemicals, precious stones, metal and metal
products, electrical equipment and products, jewelry,
paper and paper products
Exports ■ partners: UAE 9%, Saudi Arabia 8%,
Syria 6%, US 6%, Kuwait 6%, France 5%, Belgium
5%, Jordan 4% (1999)
imports: $6.2 billion (f.o.b., 2000 est.)
imports - commodities: foodstuffs, machinery and
transport equipment, consumer goods, chemicals,
textiles, metals, fuels, agricultural foods
imports ■ partners: Italy 13%, France 11%,
Germany 8%, US 7%, Switzerland 6%, Japan, UK,
Syria (1999)
Debt - external: $9.6 billion (2000 est.)
Economic aid - recipient: $3.5 billion (pledges
1997-2001)
Currency: Lebanese pound (LBP)
Currency code: LBP
Exchange rates: Lebanese pounds per US dollar -
1,507.5 (January 2001), 1,507.5 (2000), 1,507.8
(1999), 1,516.1 (1998), 1,539.5 (1997), 1,571.4
(1996)
Fiscai year: calendar year','8546af93321a71e75e0eae7f26d5165150c70b252437f48d61084254cb3ba03f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a1ef00d3957a8029021fc8774c647d26a6027041f5d1dde110c1e27b02e3a72',2001,'ZA','South Africa','economy',699,'Economy - overview: Small, landlocked, and
mountainous, Lesotho''s primary natural resource is
water. Its economy is based on subsistence
agriculture, livestock, and remittances from miners
employed in South Africa. The number of such
mineworkers has declined steadily over the past
several years. A small manufacturing base depends
largely on farm products that support the milling,
canning, leather, and jute industries. Agricultural
products are exported primarily to South Africa.
Proceeds from membership in a common customs
union with South Africa form the majority of
government revenue. Although drought has
decreased agricultural activity over the past few
years, completion of a major hydropower facility in
January 1998 now permits the sale of water to South
Africa, generating royalties for Lesotho. The pace of
substantial privatization has increased in recent
years. In December 1999, the government embarked
on a nine-month IMF staff-monitored program aimed
at structural adjustment and stabilization of
macroeconomic fundamentals. The government is in
the process of applying for a three-year successor
program with the IMF under its Poverty Reduction and
Growth Facility.
GDP: purchasing power parity - $5.1 billion
(2000 est.)
GDP - real growth rate: 2.5% (2000 est.)
GDP - per capita: purchasing power parity - $2,400
(2000 est.)
GDP - composition by sector:
agriculture: 18%
industry: 38%
se/y/ces;44%(1999)
Population below poverty line: 49.2% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.9%
highest 10%: 43 A%(m6^Q7)
Inflation rate (consumer prices): 6% (2000 est.)
Labor force: 700,000 economically active
Labor force - by occupation: 86% of resident
population engaged in subsistence agriculture;
roughly 35% of the active male wage earners work in
Unemployment rate: 45% (2000 est.)
Budget:
revenues; $76 million
expenditures: $80 million, including capital
expenditures of $15 million (FY99/00 est.)
Industries: food, beverages, textiles, handicrafts;
construction; tourism
Industrial production growth rate: 15.5%
(1999 est.)
Electricity - production: 0 kWh; note - electricity
supplied by South Africa (1999)
Electricity - production by source:
fossil fuel: 0%
hydro: 0%
nuclear: 0%
ofber; 0% (1999)
Electricity - consumption: 55 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 55 million kWh
note: electricity supplied by South Africa (1999)
Agriculture ■ products: corn, wheat, pulses,
sorghum, barley; livestock
Exports: $175 million (f.o.b., 2000 est.)
Exports - commodities: manufactures 75%
(clothing, footwear, road vehicles), wool and mohair,
food and live animals (1998)
Exports ■ partners: South African Customs Union
65%, North America 34% (1998)
Imports: $700 million (f.o.b., 2000 est.)
Imports - commodities: food; building materials,
vehicles, machinery, medicines, petroleum products
(1995)
Imports - partners: South African Customs Union
90%, Asia 7% (1998)
Debt - external: $720 million (2000 est.)
Economic aid - recipient: $123.7 million (1 995)
Currency: loti (LSL); South African rand (ZAR)
Currency code: LSL; ZAR
Exchange rates: maloti per US dollar - 7.78307
(January 2001), 6.93983 (2000), 6.10948 (1999),
5.52828 (1998), 4.60796 (1997), 4,29935 (1996);
note - the Lesotho loti is at par with the South African
rand which is also legal tender; maloti is the plural
form of loti
Fiscal year: 1 April - 31 March
Economy - overview: South Africa is a
middle-income, developing country with an abundant
supply of resources, well-developed financial, legal,
communications, energy, and transport sectors, a
stock exchange that ranks among the 10 largest in the
world, and a modern infrastructure supporting an
efficient distribution of goods to major urban centers
throughout the region. However, growth has not been
strong enough to cut into the 30% unemployment, and
daunting economic problems remain from the
apartheid era, especially the problems of poverty and
lack of economic empowerment among the
disadvantaged groups. Other problems are crime,
corruption, and HIV/AIDS. At the start of 2000,
President MBEKI vowed to promote economic growth
and foreign investment, and to reduce poverty by
relaxing restrictive labor laws, stepping up the pace of
privatization, and cutting unneeded governmental
spending.
GDP: purchasing power parity - $369 billion
(2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP ■ per capita: purchasing power parity - $8,500
(2000 est.)
GDP - composition by sector:
agriculture: 5%
industry: 30%
services: 65% (1999 est.)
Population below poverty line: 50% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 1.1%
highest 10%: 45.9% (1994)
Inflation rate (consumer prices): 5.3% (2000 est.)
Labor force: 17 million economically active (2000)
Labor force - by occupation: agriculture 30%,
industry 25%, services 45% (1999 est.)
Unemployment rate: 30% (2000 est.)
Budget:
revenues: $31.1 billion
expenditures: $34.4 billion, including capital
expenditures of $NA billion (FY01/02)
Industries: mining (world''s largest producer of
platinum, gold, chromium), automobile assembly,
metalworking, machinery, textile, iron and steel,
chemicals, fertilizer, foodstuffs
Industrial production growth rate: 2.4%
(2000 est.)
Electricity- production: 186.903 billion kWh (1999)
Electricity - production by source:
fossil fuel: 92.74%
hydro: 0.39%
nuclear: 6.87%
other: 0%(1999)
Electricity - consumption: 172.393 billion kWh
(1999)
Electricity - exports: 3.884 billion kWh (1999)
Electricity - imports: 2.457 billion kWh (1999)
Agriculture - products: corn, wheat, sugarcane,
fruits, vegetables; beef, poultry, mutton, wool, dairy
products
Exports: $30.8 billion (f.o.b., 2000 est.)
Exports - commodities: gold, diamonds, other
metals and minerals, machinery and equipment
Exports - partners: UK, Italy, Japan, US, Germany
Imports: $27.6 billion (f.o.b., 2000 est.)
Imports - commodities: machinery, foodstuffs and
equipment, chemicals, petroleum products, scientific
instruments
Imports ■ partners: Germany, US, UK, Japan
Debt - external: $25.6 billion (2000 est.)
Economic aid - recipient: $676.3 million
Currency: rand(ZAR)
Currency code: ZAR
Exchange rates: rand per US dollar - 7.60 (March
2001), 6.93983 (2000), 6.10948 (1999), 5.52828
(1998), 4.60796 (1997), 4.29935 (1996)
Fiscal year: 1 April - 31 March
465
South Africa (continued)
Economy ■ overview: Some fishing takes place in
adjacent waters. There is a potential source of income
from harvesting fin fish and krill. The islands receive
income from postage stamps produced in the UK.
Budget:
revenues: $291 ,777
expenditures: $451 ,000, including capital
expenditures of $NA (1988 est.)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Economy - overview: Fisheries in 1998-99 (1 July
to 30 June) landed 1 1 9,898 metric tons, of which 85%
was krill and 14% Patagonian toothfish. International
agreements were adopted in late 1999 to reduce
illegal, unreported, and unregulated fishing, which in
the 1998-99 season landed five to six times more
Patagonian toothfish than the regulated fishery. In the
1999- 2000 antarctic summer 13,193 tourists, most of
them seaborne, visited the Southern Ocean and
Antarctica, compared to 10,013 the previous year.
Nearly 16,000 tourists are expected during the
2000- 01 season.','7cfafc6978175a6c467a46193a34a0a02d2da5b46e0135915e239ebf26c424f9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('351f25abacee3805e9bd9c5be3e6861a4905038f3d62a6f8827dff36f5a728f8',2001,'LR','Liberia','economy',708,'Economy - overview: A civil war in 1989-96
destroyed much of Liberia''s economy, especially the
infrastructure in and around Monrovia. Many
businessmen fled the country, taking capital and
expertise with them. Some returned during 1997.
Many will not return. Richly endowed with water,
mineral resources, forests, and a climate favorable to
agriculture, Liberia had been a producer and exporter
of basic products, while local manufacturing, mainly
foreign owned, had been small in scope. The
democratically elected government, installed in
August 1997, inherited massive international debts
and currently relies on revenues from its maritime
registry to provide the bulk of its foreign exchange
earnings. The restoration of the infrastructure and the
raising of incomes in this ravaged economy depend
on the implementation of sound macro- and
micro-economic policies of the new government,
including the encouragement of foreign investment.
Recent growth has been from a low base, and
continued growth will require major policy successes.
GDP: purchasing power parity - $3.35 billion
(2000 est.)
GDP “ real growth rate: 15% (2000 est.)
GDP - per capita: purchasing power parity - $1,100
(2000 est.)
GDP - composition by sector:
agriculture: 60%
industry: 10%
services: 30% (2000 est.)
Population below poverty line: 80%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o: NA%
Inflation rate (consumer prices): 5% (2000 est.)
Labor force - by occupation: agriculture 70%,
industry 8%, services 22% (1999 est.)
Unemployment rate: 70%
Budget;
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: rubber processing, palm oil processing,
diamonds
Industrial production growth rate: NA
Electricity ■ production: 432 million kWh (1999)
Electricity - production by source:
foss//tee/;100%
hydro: 0%
nuclear: 0%
0^0% (1999)
Electricity ■ consumption: 401 .8 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rubber, coffee, cocoa, rice,
cassava (tapioca), palm oil, sugarcane, bananas;
sheep, goats; timber
Exports: $55 million (f.o.b,, 2000 est.)
Exports - commodities: diamonds, iron ore, rubber,
timber, coffee, cocoa
Exports - partners; Belgium 53%, Switzerland 9%,
US 6%, France 4% (1999)
Imports; $170 million (f.o.b., 2000 est.)
Imports ■ commodities: fuels, chemicals,
machinery, transportation equipment, manufactured
goods; rice and other foodstuffs
Imports - partners; South Korea 30%, Italy 24%,
Japan 15%, Germany 9% (1999)
Debt - external: $3 billion (1999 est.)
Economic aid - recipient: $200 million pledged
(1998)
Currency: Liberian dollar (LRD)
Currency code: LRD
293
Liberia (continued)
Exchange rates: Liberian dollars per US dollar -
39.8100 (December 2000), 41.0483 (2000), 41.9025
(1999), 41.5075 (1998), 1.0000 (officially fixed rate
1940-97): market exchange rate: Liberian dollars per
US dollar - 40 (December 1998), 50 (October 1995)
note: until December 1997, rates were based on a
fixed relationship with the US dollar; beginning in
January 1998, rates are market determined
Fiscal year: calendar year','9e25f2572f573af4c50ce47fdeb61b0283f7741f988e5451998961b78366c58a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7479f468585008132106ee69a0a2175c5269dbb92d4a7e20a116b007710d2f53',2001,'LY','Libya','economy',716,'Economy - overview: The socialist-oriented
economy depends primarily upon revenues from the
oil sector, which contributes practically all export
earnings and about one-quarter of GDP. These oil
revenues and a small population give Libya one of the
highest per capita GDPs in Africa, but little of this
income flows down to the lower orders of society. In
this statist society, import restrictions and inefficient
resource allocations have led to periodic shortages of
basic goods and foodstuffs. The nonoil manufacturing
and construction sectors, which account for about
20% of GDP, have expanded from processing mostly
agricultural products to include the production of
petrochemicals, iron, steel, and aluminum. Climatic
conditions and poor soils severely limit agricultural
output, and Libya imports about 75% of its food
requirements. Higher oil prices in 1999 and 2000 led
to an increase in export revenues, which improved
macroeconomic balances and helped to stimulate the
economy. Following the suspension of UN sanctions
in 1999, Libya has been trying to increase its
attractiveness to foreign investors, and several foreign
companies have visited in search of contracts.
GDP: purchasing power parity - $45.4 billion
(2000 est.)
GDP - real growth rate: 6.5% (2000 est.)
GDP - per capita: purchasing power parity - $8,900
(2000 est.)
GDP - composition by sector:
agriculture: 7%
industry: 47%
services: 46% (1997 est.)
Population below poverty line: NA%
295
Libya (continued)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 18.5%
(2000 est.)
Labor force: 1 .5 million (2000 est.)
Labor force - by occupation: services and
government 54%, industry 29%, agriculture 17%
(1997 est.)
Unemployment rate: 30% (2000 est.)
Budget:
revenues: $6.85 billion
expenditures: $4 A billion, including capital
expenditures of $IMA (2000 est.)
Industries: petroleum, food processing, textiles,
handicrafts, cement
Industrial production growth rate: NA%
Electricity - production: 1 8.9 billion kWh (1 999)
Electricity - production by source:
fossil fuel: )00%
hydro: 0%
nuclear: 0%
other: 0%{^999)
Electricity - consumption: 17.577 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: wheat, barley, olives, dates,
citrus, vegetables, peanuts, soybeans; cattle
Exports: $13.9 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil, refined
petroleum products
Exports - partners: Italy 33%, Germany 24%, Spain
10%, France 5%, Turkey 4%, Tunisia 4% (1999)
Imports: $7.6 billion (f.o.b., 2000 est.)
Imports - commodities: machinery, transport
equipment, food, manufactured goods
Imports - partners: Italy 24%, Germany 12%,
Tunisia 9%, UK 7%, France 6%, South Korea 5%
(1999)
Debt -external: $4.1 billion (2000 est.)
Economic aid - recipient: $8.4 million (1995)
Currency: Libyan dinar (LYD)
Currency code: LYD
Exchange rates: Libyan dinars per US dollar -
0.5101 (January 2001), 0.5081 (2000), 0.461 6 (1999),
0.3785 (1998), 0.3891 (1997), 0.3651 (1996)
note: Libya currently has two rates for foreign trade;
one for government operations and foreign
companies and one for Libyan individuals (0.45 dinars
per US dollar in December 1998)
Fiscal year: calendar year','0484bd1ea3a569958ee8db843e3da24798c2ba8ec7900b370e064e2d65709c1d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98edeb94ebcc6e6ea9574e1336159d88cc50705661dda2c7f115c4085d438c98',2001,'LI','Liechtenstein','economy',725,'Economy - overview: Despite its small size and
limited natural resources, Liechtenstein has
developed into a prosperous, highly industrialized,
free-enterprise economy with a vital financial service
sector and living standards on a par with the urban
areas of its large European neighbors. Low business
taxes - the maximum tax rate is 18% - and easy
incorporation rules have induced 73,700 holding or
so-called letter box companies to establish nominal
offices in Liechtenstein, providing 30% of state
revenues. The country participates in a customs union
with Switzerland and uses the Swiss franc as its
national currency. It imports more than 90% of its
energy requirements. Liechtenstein has been a
member of the European Economic Area (an
organization serving as a bridge between European
Free Trade Association (EFTA) and EU) since May
1995. The government is working to harmonize its
economic policies with those of an integrated Europe.
GDP: purchasing power parity - $730 million
(1998 est.)
GDP ■ real growth rate: NA%
GDP - per capita: purchasing power parity -
$23,000 (1998 est.)
GDP - composition by sector:
agriculture: NA%
Industry: NA%
sen/lces: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 0.5% (1997 est.)
Labor force: 22,891 of which 1 3,847 are foreigners;
8,231 commute from Austria and Switzerland to work
each day
Labor force - by occupation: industry, trade, and
building 45%, services 53%, agriculture, fishing,
forestry, and horticulture 2% (1997 est.)
Unemployment rate: 1.8% (February 1999)
Budget:
revenues: $424.2 million
expenditures: million, including capital
expenditures of $NA (1998 est.)
Industries: electronics, metal manufacturing,
textiles, ceramics, pharmaceuticals, food products,
precision instruments, tourism
Industrial production growth rate: NA%
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports; NA kWh
Agriculture ■ products: wheat, barley, corn,
potatoes: livestock, dairy products
Exports: $2.47 billion (1996)
Exports - commodities: small specialty machinery,
dental products, stamps, hardware, pottery
Exports ■ partners: EU and EFTA countries 60.57%
(Switzerland 15.7%) (1995)
Imports: $917.3 million (1996)
Imports - commodities: machinery, metal goods,
textiles, foodstuffs, motor vehicles
Imports - partners: EU countries, Switzerland
(1996)
Debt -external: $0(1996)
Economic aid - recipient: none
Currency: Swiss franc (CHF)
Currency code: CHF
Exchange rates: Swiss francs per US dollar -
1 .6303 (January 2001), 1 .6888 (2000), 1 .5022 (1999),
1.4498 (1998), 1.4513 (1997), 1.2360 (1996)
Fiscal year: calendar year','e408df5faf8a691c644396d4720744976beaa1adca22ef519c93142c29aac99b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8b8866a6607633b893c8cb3f9ee21a0dc5e44f43c303e930dd9a34e10ad4df6',2001,'CH','Switzerland','economy',730,'Economy - overview: Lithuania, the Baltic state that
has conducted the most trade with Russia, has been
slowly rebounding from the 1998 Russian financial
crisis. High unemployment and weak consumption
have held back recovery. GDP growth for 2000 -
estimated at 2.9% - fell behind that of Estonia and
Latvia, and unemployment is estimated at 10.8%, the
country''s highest since regaining independence in
1990. For 2001, Lithuanians forecast 3.2% growth,
1 .8% inflation, and a fiscal deficit of 3.3%. In early
2001, the Lithuanian Government announced that it
will repeg its currency, the litas, to the euro (the litas is
currently pegged to the dollar) some time in 2002.
Lithuania must ratify 25 agreements along with other
legal documents and obligations by 1 May 2001
before gaining World Trade Organization
membership. Lithuania was invited to the Helsinki
summit in December 1999 and began EU accession
talks in early 2000. Privatization of the large,
state-owned utilities, particularly in the energy sector,
remains a key challenge for 2001 .
GDP: purchasing power parity - $26.4 billion
(2000 est.)
GDP - real growth rate: 2.9% (2000 est.)
GDP - per capita: purchasing power parity - $7,300
(2000 est.)
GDP - composition by sector:
agriculture: 10%
industry: 33%
sen/ices: 57% (1 999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: 3.1%
highest 10%: 25.6% (1996)
Inflation rate (consumer prices): 1% (2000 est.)
Labor force: 2 million (2000 est.)
Labor force ■ by occupation; industry 30%,
agriculture 20%, services 50% (1997 est.)
Unemployment rate: 10.8% (2000)
Budget;
revenues: $1 .5 billion
expenditures: $1.7 billion, including capital
expenditures of $NA (1997 est.)
Industries; metal-cutting machine tools, electric
motors, television sets, refrigerators and freezers,
petroleum refining, shipbuilding (small ships),
furniture making, textiles, food processing, fertilizers,
agricultural machinery, optical equipment, electronic
components, computers, amber
Industrial production grovrth rate; 2.3%
(2000 est.)
Electricity - production; 13.567 billion kWh (1999)
Electricity - production by source;
fossil fuel: 23.89%
hydro: 3.43%
nuclear: 72.68%
other: 0% (1999)
Electricity ■ consumption; 9.817 billion kWh (1999)
Electricity - exports; 3.2 billion kWh (1999)
Electricity - Imports; 400 million kWh (1999)
Agriculture - products; grain, potatoes, sugar
beets, flax, vegetables; beef, milk, eggs; fish
Exports: $3.7 billion (f.o.b., 2000)
Exports ■ commodities; machinery and equipment
22%, mineral products 15%, chemicals 12%, textiles
and clothing, foodstuffs (1999)
Exports - partners; Germany 15.8%, Latvia 12.6%,
Russia 6.9%, Belarus 5.8%, Denmark (1999)
Imports; $4.9 billion (f.o.b., 2000)
Imports ■ commodities; machinery and equipment
18%, mineral products 16%, chemicals 10%, textiles
and clothing 10%, transport equipment 7% (1999)
Imports - partners; Russia 20.4%, Germany 1 6.5%,
Denmark 3.8%, Belarus 2.2%, Latvia 2% (1999)
Debt - external; $2.5 billion (2000 est.)
Economic aid - recipient: $228.5 million (1995)
Currency: litas (LTL)
Currency code: LTL
Exchange rates: litai per US dollar - 4.000 (fixed
rate since 1 May 1994); note - litai is the plural of litas
Fiscal year: calendar year','9c22f1fbcc0b1e8d6c6107019e76c5054380fe03448828c91ff6f99eda8914fd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b6447fe69520e35a7dd32eee8c575b2b9891bd3f12925baaf4e56c6eeeeeec7',2001,'MG','Madagascar','economy',739,'Economy - overview: Madagascar faces problems
of chronic malnutrition, underfunded health and
education facilities, a roughly 3% annual population
growth rate, and severe loss of forest cover,
accompanied by erosion. Agriculture, including fishing
and forestry, is the mainstay of the economy,
accounting for 30% of GDP and contributing more
than 70% to export earnings. Industry features textile
manufacturing and the processing of agricultural
products. Growth in output in 1992-97 averaged less
than the growth rate of the population. Growth has
been held back by antigovernment strikes and
demonstrations, a decline in world coffee prices, and
the erratic commitment of the government to
economic reform. The extent of government reforms,
outside financial aid, and foreign investment will be
key determinants of future growth. For 2001 , growth
should again be about 5%.
GDP: purchasing power parity - $1 2.3 billion
(2000 est.)
GDP - real growth rate: 4.8% (2000 est.)
GDP - per capita: purchasing power parity - $800
(2000 est.)
GDP - composition by sector:
agriculture: 30%
industry: 14%
services: 56% (1999 est.)
Population below poverty line: 70% (1994 est.)
Household income or consumption by percentage
share:
lowest 10%::, 9%
highest 36.7% (1993)
Inflation rate (consumer prices): 1 0% (1 999 est.)
Labor force: 7 million (1999)
Unemployment rate: NA%
Budget:
revenues; $553 million
expenof/Yures; $735 million, including capital
expenditures of $NA (1998 est.)
Industries: meat processing, soap, breweries,
tanneries, sugar, textiles, glassware, cement,
automobile assembly plant, paper, petroleum, tourism
Industrial production growth rate: 3% (2000 est.)
Electricity - production: 810 million kWh (1999)
Electricity - production by source:
fossil fuel: 37.04%
hydro: 62,%%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 753.3 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coffee, vanilla, sugarcane,
cloves, cocoa, rice, cassava (tapioca), beans,
bananas, peanuts; livestock products
Exports: $538 million (f.o.b., 1998)
Exports - commodities: coffee, vanilla, shellfish,
sugar; cotton cloth, chromite, petroleum products
Exports - partners: France 41%, US 19%, Germany
13%, UK 8%, Japan 6% (1999)
Imports: $693 million (f.o.b., 1998)
Imports - commodities: intermediate
manufactures, capital goods, petroleum, consumer
goods, food
Imports - partners: France 34%, Hong Kong 6%,
China 6%, Japan 5%, Singapore 4% (1999)
Debt - external: $4.4 billion (1 999)
Economic aid - recipient: $838 million (1997)
Currency: Malagasy franc (MGF)
Currency code: MGF
Exchange rates: Malagasy francs per US dollar -
6,656.3 (November 2000), 6,283.8 (1999), 5,441.4
(1998), 5,090.9 (1997), 4,061.3 (1996)
Fiscal year: calendar year','705bbf1df5b60035d829edf24e19af1380d2315611d0f8478bf68448244dc552','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a9c36a3124e971015cf1b08e23a5088a960dfda0dd49817ccc5b36d5ffbaaba',2001,'MW','Malawi','economy',747,'Economy - overview: Landlocked Malawi ranks
among the world''s least developed countries. The
economy is predominately agricultural, with about
90% of the population living in rural areas. Agriculture
accounts for 37% of GDP and 85% of export
revenues. The economy depends on substantial
inflows of economic assistance from the IMF, the
World Bank, and individual donor nations. In late
2000, Malawi was approved for relief under the
Heavily Indebted Poor Countries (HIPC) program.
The government faces strong challenges, e.g., to fully
develop a market economy, to improve educational
facilities, to face up to environmental problems, and to
deal with the rapidly growing problem of HIV/AIDS.
GDP: purchasing power parity - $9.4 billion (2000 est.)
GDP - real growth rate: 3% (2000 est.)
GDP - per capita; purchasing power parity - $900
(2000 est.)
GDP - composition by sector:
agriculture: 37%
industry: 29%
services: 34% (1998 est.)
Population below poverty line; 54%
(FY90/91 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%,: NA%
Inflation rate (consumer prices): 29.5% (2000)
Labor force: 3.5 million
Labor force ■ by occupation: agriculture 86%
(1997 est.)
Unemployment rate: NA%
Budget;
revenues; $490 million
expencf/fures; $523 million, including capital
expenditures of $NA (FY99/00 est.)
Industries: tobacco, tea, sugar, sawmill products,
cement, consumer goods
Industrial production growth rate: NA%
Electricity - production: 1 .025 billion kWh (1 999)
Electricity - production by source:
foss/7 fue/; 2.44%
hydro; 97.56%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 950 million kWh (1999)
Electricity - exports: 3 million kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: tobacco, sugarcane,
cotton, tea, corn, potatoes, cassava (tapioca),
sorghum, pulses; cattle, goats
Exports; $416 million (f.o.b., 2000)
Exports - commodities: tobacco, tea, sugar,
cotton, coffee, peanuts, wood products
Exports - partners: South Africa 16%, Germany
16%, US 15%, Netherlands 7%, Japan (1999)
Imports: $435 million (f.o.b., 2000)
Imports - commodities: food, petroleum products,
semimanufactures, consumer goods, transportation
equipment
Imports - partners: South Africa 43%, Zimbabwe
14%, UK 5%, Germany 5%, Zambia, Japan, US
(1999)
Debt - external: $2.9 billion (2000 est.)
Economic aid ■ recipient: $427 million (1999)
Currency: Malawian kwacha (MWK)
Currency code: MWK
Exchange rates: Malawian kwachas per US dollar -
80.0946 (December 2000), 59.5438 (2000), 44.0881
(1999), 31.0727 (1998), 16.4442 (1997), 15.3085
(1996)
Fiscal year: 1 July - 30 June
311
Malawi (continued)','78c37e601b77f65d2c260515628ba6ee85a061e09436dca6af1c6b0c7f5e03c4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b522ad3e77c4185f3fbbd0d67ac64068fd5cb496e3db4d1f20f415cf91df7f0',2001,'PH','Philippines','economy',748,'Kudat/S''
South China
Sea
y\\Kepulauan
•O Natuna
■^(INDONESIA)
,lpoh
Lumut!^
Strait
of \\ KUALA iKuantan
■^Malacca\\ tUMPUR ]
^ Kelarfg ,
N,PortDick^._.,_ Kepu/auan
^teka V
\\ Baharu
Economy - overview: GDP grew at 8.6% in 2000,
mainly on the strength of double-digit export growth
and continued government fiscal stimulus. As an oil
exporter, Malaysia also benefited from higher
petroleum prices. Higher export revenues allowed the
country to register a current account surplus, but
foreign exchange reserves have been declining - from
a peak of $34.5 billion in April 2000 to $29.7 billion by
December - as foreign investors pulled money out of
the country. Despite this development, Kuala Lumpur
is unlikely to abandon its currency peg soon. An
economic slowdown in key Western markets,
especially the United States, and lower world demand
for electronics products will slow GDP growth to
3%-6% in 2001 , according to private forecasters. Over
the longer term, Malaysia''s failure to make substantial
progress on key reforms of the corporate and financial
sectors clouds prospects for sustained growth and the
return of critical foreign investment.
GDP: purchasing power parity - $223.7 billion
(2000 est.)
GDP - real growth rate: 8.6% (2000 est.)
GDP - per capita: purchasing power parity -
$10,300 (2000 est.)
GDP - composition by sector:
agriculture: 14%
industry: 44%
services: 42% (2000)
Population below poverty line: 6.8% (1997 est.)
Household Income or consumption by percentage
share:
lowest 10%: 1 .4%
highest 10%: 20.4% (1997 est.)
Inflation rate (consumer prices): 1.7% (2000)
Labor force: 9.6 million (2000 est.)
Labor force - by occupation: local trade and
tourism 28%, manufacturing 27%, agriculture,
forestry, and fisheries 16%, services 10%,
government 10%, construction 9% (2000 est.)
Unemployment rate: 2.8% (2000 est.)
Budget:
revenues.'' $16.4 billion
expenditures: $17.8 billion, including capital
expenditures of $43 billion (2000 est.)
Industries: Peninsular Malaysia - rubber and oil
palm processing and manufacturing, light
manufacturing industry, electronics, tin mining and
smelting, logging and processing timber; Sabah -
logging, petroleum production; Sarawak - agriculture
processing, petroleum production and refining,
logging
Industrial production growth rate: 12.1%
(2000 est.)
Electricity - production: 59.044 billion kWh (1999)
Electricity - production by source:
foss/7 fue/.'' 91 .61%
hydro: S.39%
nuclear: 0%
ofoer; 0% (1999)
Electricity ■ consumption: 54.872 billion kWh
(1999)
Electricity ■ exports: 50 million kWh (1999)
Electricity - imports: 11 million kWh (1999)
Agriculture ■ products: Peninsular Malaysia -
rubber, palm oil, cocoa, rice; Sabah - subsistence
crops, rubber, timber, coconuts, rice; Sarawak -
rubber, pepper; timber
Exports: $97.9 billion (2000 est.)
Exports ■ commodities: electronic equipment,
petroleum and liquefied natural gas, chemicals, palm
oil, wood and wood products, rubber, textiles
Exports ■ partners: US 21%, Singapore 18%,
Japan 13%, Hong Kong 5%, Netherlands 4%, Taiwan
4%, Thailand 3% (2000 est.)
Imports: $82.6 billion (2000 est.)
Imports - commodities: machinery and transport
equipment, chemicals, food, fuel and lubricants
Imports - partners: Japan 21 %, US 1 7%, Singapore
14%, Taiwan 6%, South Korea 5%, Thailand 4%,
China 4% (2000 est.)
Debt - external: $41 .8 billion (2000 est.)
Currency: ringgit (MYR)
Currency code: MYR
Exchange rates: ringgits per US dollar - 3.8000
(January 2001 ), 3.8000 (2000), 3.8000 (1 999), 3.9244
(1998), 2.81 33 (1997), 2.5159 (1996)
Fiscal year: calendar year
Economy - overview: China announced plans in
1 997 to open the islands for tourism.
Economy - overview: In 1998 the Philippine
economy - a mixture of agriculture, light industry, and
supporting services - deteriorated as a result of
spillover from the Asian financial crisis and poor
weather conditions. G rowth fell to about -0.5% in 1 998
from 5% in 1997, but recovered to about 3% in 1999
and 3.6% in 2000. The government has promised to
continue its economic reforms to help the Philippines
match the pace of development in the newly
industrialized countries of East Asia. The strategy
includes improving infrastructure, overhauling the tax
system to bolster government revenues, moving
toward further deregulation and privatization of the
economy, and increasing trade integration with the
region.
GDP: purchasing power parity - $31 0 billion
(2000 est.)
GDP - real growth rate: 3.6% (2000 est.)
GDP - per capita: purchasing power parity - $3,800
(2000 est.)
GDP ■ composition by sector:
agriculture: 20%
industry: 32%
services: 48% (1997 est.)
Population below poverty line: 41% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%:^.5%
highest y0%; 39.3% (1998)
Inflation rate (consumer prices): 5% (2000 est.)
Labor force: 48.1 million (2000 est.)
Labor force - by occupation: agriculture 39.8%,
government and social services 19.4%, services
17.7%, manufacturing 9.8%, construction 5.8%, other
7.5% (1998 est.)
Unemployment rate: 10% (2000)
Budget:
revenues; $14.5 billion
expenditures: $^2.0 billion, including capital
expenditures of $NA (1998 est.)
Industries: textiles, pharmaceuticals, chemicals,
wood products, food processing, electronics
assembly, petroleum refining, fishing
Industrial production growth rate: 4% (2000 est.)
Electricity - production: 40.745 billion kWh (1999)
Electricity - production by source:
fossil fuel: 0^. 03%
hydro: 18.68%
nuclear: 0%
other; 20.29% (1999)
404
Philippines (continued)
Electricity ■ consumption: 37.893 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rice, coconuts, corn,
sugarcane, bananas, pineapples, mangoes; pork,
eggs, beef; fish
Exports: $38 billion (f.o.b., 2000 est.)
Exports - commodities: electronic equipment,
machinery and transport equipment, garments,
coconut products
Exports - partners: US 34%, Japan 14%,
Netherlands 8%, Singapore 6%, UK 6%, Hong Kong
4% (1998)
Imports: $35 billion (f.o.b., 2000 est.)
Imports - commodities: raw materials and
intermediate goods, capital goods, consumer goods,
fuels
Imports - partners: US 22%, Japan 20%, South
Korea 8%, Singapore 6%, Taiwan 5%, Hong Kong 4%
(1998 est.)
Debt - external: $52 billion (1999)
Economic aid - recipient: ODA, $1.1 billion (1998)
Currency: Philippine peso (PHP)
Currency code: PHP
Exchange rates: Philippine pesos per US dollar -
50.969 (January 2001), 44.192 (2000), 39.089 (1999),
40.893 (1998), 29.471 (1997), 26.216 (1996)
Fiscal year: calendar year
Economy - overview: Economic activity is limited to
commercial fishing. The proximity to nearby oil- and
gas-producing sedimentary basins suggests the
potential for oil and gas deposits, but the region is
largely unexplored, and there are no reliable
estimates of potential reserves; commercial
exploitation has yet to be developed.','870b4393500127e221589ae99bb141dd7fc673a34160fc1897822ba363ea98ef','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec5768bb0279f672867c56b9bde1e3c3c758e40864bc392a6942558cb87c1c92',2001,'MV','Maldives','economy',762,'Economy - overview: Tourism, Maldives largest
industry, accounts for 20% of GDP and more than
60% of the Maldives'' foreign exchange receipts. Over
90% of government tax revenue comes from import
duties and tourism-related taxes. Almost 400,000
tourists visited the islands in 1 998. Fishing is a second
leading sector. The Maldivian Government began an
economic reform program in 1989 initially by lifting
import quotas and opening some exports to the
private sector. Subsequently, it has liberalized
regulations to allow more foreign Investment.
Agriculture and manufacturing continue to play a
minor role in the economy, constrained by the limited
availability of cultivable land and the shortage of
domestic labor. Most staple foods must be imported.
Industry, which consists mainly of garment
production, boat building, and handicrafts, accounts
for about 18% of GDP. Maldivian authorities worry
about the impact of erosion and possible global
warming on their low-lying country; 80% of the area is
one meter or less above sea level.
GDP: purchasing power parity - $594 million
(2000 est.)
GDP - real growth rate; 7.6% (2000 est.)
GDP - per capita: purchasing power parity - $2,000
(2000 est.)
GDP - composition by sector:
agriculture: 20%
industry: ^S%
sen/ices: 62% (2000 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
/owesf 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3% (2000 est.)
Labor force: 67,000 (1995)
Labor force - by occupation: agriculture 22%,
industry 18%, services 60% (1995)
Unemployment rate: NEGL%
Budget;
revenues: $166 million (excluding foreign grants)
expenditures: $^92 million, including capital
expenditures of $80 million (1999 est.)
Industries: fish processing, tourism, shipping, boat
building, coconut processing, garments, woven mats,
rope, handicrafts, coral and sand mining
Industrial production growth rate: 4.4%
(1996 est.)
Electricity - production: 101 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other 0% (1999)
Electricity - consumption: 93.9 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture ■ products: coconuts, corn, sweet
potatoes; fish
Exports: $88 million (f.o.b., 2000 est.)
Exports - commodities: fish, clothing
Exports - partners: US, UK, Sri Lanka, Japan
Imports: $372 million (f.o.b., 2000 est.)
Imports - commodities: consumer goods,
intermediate and capital goods, petroleum products
Imports - partners: Singapore, India, Sri Lanka,
Japan, Canada
Debt “ external: $237 million (2000 est.)
Economic aid ■ recipient: $NA
Currency: rufiyaa (MVR)
Currency code: MVR
Exchange rates: rufiyaa per US dollar - 1 1 .770
(fixed rate since 1995)
Fiscal year: calendar year','4fd3f47fb9f4456eb57cf71183c135fd5b8de7157e685cc94834dbeec982e235','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f497f18d4e867111a4148559d0add8042fef4ef01b3652d202a768e714aaabbc',2001,'ML','Mali','economy',770,'Economy ■ overview: Mali is among the poorest
countries in the world, with 65% of its land area desert
or semidesert. Economic activity is largely confined to
the riverine area irrigated by the Niger. About 10% of
the population is nomadic and some 80% of the labor
force is engaged in farming and fishing. Industrial
activity is concentrated on processing farm
commodities. Mali is heavily dependent on foreign aid
and vulnerable to fluctuations in world prices for
cotton, its main export. In 1997, the government
continued its successful implementation of an
IMF-recommended structural adjustment program
that is helping the economy grow, diversify, and attract
foreign investment. Mali''s adherence to economic
reform and the 50% devaluation of the African franc in
January 1994 have pushed up economic growth to a
sturdy 5% average in 1996-2000. Growth should
remain around 5% in 2001-02, and inflation should
stay less than 2%.
GDP: purchasing power parity - $9.1 billion
(2000 est.)
GDP - real growth rate: 4.8% (2000 est.)
GDP - per capita: purchasing power parity - $850
(2000 est.)
GDP - composition by sector:
agriculture: 46%
industry: 2^%
services: 33% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%:^.Q%
highest 40.4% (1994)
Inflation rate (consumer prices): 0.8% (2000 est.)
Labor force: NA
Labor force - by occupation: agriculture and
fishing 80% (1998 est.)
Unemployment rate: NA%
Budget:
revenues; $730 million
expenditures: $770 million, including capital
expenditures of $320 million (1997 est.)
Industries: minor local consumer goods production
and food processing; construction; phosphate and
gold mining
Industrial production growth rate: NA
Electricity - production: 445 million kWh (1999)
Electricity - production by source:
fossil fuel: 44.94%
hydro: 55.06%
nuclear: 0%
other: 0%(^999)
Electricity - consumption: 413.9 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cotton, millet, rice, corn,
vegetables, peanuts; cattle, sheep, goats
Exports: $480 million (f.o.b., 2000 est.)
Exports - commodities: cotton 50%, gold, livestock
(1999 est.)
Exports - partners: Italy 18%, Thailand 15%,
Germany 7%, Portugal 4% (1999)
Imports: $575 million (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
construction materials, petroleum, foodstuffs, textiles
Imports - partners: Cote d''Ivoire 1 9%, France 1 9%,
Senegal 4%, Benelux 3% (1999)
Debt - external: $3 billion (1999)
Economic aid - recipient: $596.4 million (1995)
Currency: Communaute Financiere Africaine franc
(XOF); note - responsible authority is the Central
Bank of the West African States
Currency code: XOF
318
Mali (continued)
Exchange rates: Communaute FInanciere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1 997), 51 1 .55 (1 996); note - from 1 January 1 999,
the XOF is pegged to the euro at a rate of 655.957
XOF per euro
Fiscal year: calendar year','fb0db2016d97a8de4521326d60163ec412fa68866feaae078768ec38c9d4d187','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f0ad524c1fc897475118bda0913d64db2cc30b78c306c92701c06003afc91db',2001,'MT','Malta','economy',778,'Economy - overview: Major resources are
limestone, a favorable geographic location, and a
productive labor force. Malta produces only about
20% of its food needs, has limited freshwater supplies,
and has no domestic energy sources. The economy is
dependent on foreign trade, manufacturing (especially
electronics and textiles), and tourism. Malta is
privatizing state-controlled firms and liberalizing
markets in order to prepare for membership in the
European Union. However, the island is divided
politically over the question of joining the EU. The
sizable budget deficit remains a key concern.
GDP: purchasing power parity - $5.6 billion
(2000 est.)
GDP - real growth rate: 3.4% (2000 est.)
GDP - per capita: purchasing power parity -
$14,300 (2000 est.)
GDP - composition by sector:
agriculture: 2.8%
industry: 25.5%
services: 7]. 7% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: m%
Inflation rate (consumer prices): 2.5% (2000 est.)
Labor force: 145,901 (1999)
320
Malta (continued)
Labor force - by occupation: industry 24%,
services 71%, agriculture 5% (1999 est.)
Unemployment rate: 4.5% (3rd Quarter 2000)
Budget:
revenues; $1.6 billion
expenditures: $1 .73 billion, including capital
expenditures of $265.4 million (1999)
Industries: tourism; electronics, ship building and
repair, construction; food and beverages, textiles,
footwear, clothing, tobacco
Industrial production growth rate: NA%
Electricity - production: 1.65 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
ofoer; 0% (1999)
Electricity - consumption: 1 .534 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: potatoes, cauliflower,
grapes, wheat, barley, tomatoes, citrus, cut flowers,
green peppers; pork, milk, poultry, eggs
Exports: $2 billion (f.o.b., 1999)
Exports - commodities: machinery and transport
equipment, manufactures
Exports - partners: US 21 .4%, France 15.2%,
Germany 12.6%, UK 9.3%, Italy 4.9% (1999)
Imports: $2,6 billion (f.o.b., 1999)
Imports - commodities: machinery and transport
equipment, manufactured and semi-manufactured
goods; food, drink, and tobacco
Imports - partners: France 19.1%, Italy 16.7%, UK
10.9%, Germany 10.0%, US 8.5% (1999)
Debt - external: $1 30 million (1 997)
Economic aid - recipient: $NA
Currency: Maltese lira (MIL)
Currency code: MIL
Exchange rates: Maltese liri per US dollar - 0.4370
(January 2001), 0.4376 (2000), 0.3994 (1999), 0.3885
(1998), 0.3857 (1997), 0.3604 (1996)
Fiscal year: 1 April - 31 March
Economy - overview: Offshore banking,
manufacturing, and tourism are key sectors of the
economy. The government''s policy of offering
incentives to high-technology companies and financial
institutions to locate on the island has paid off in
expanding employment opportunities in high-income
industries. As a result, agriculture and fishing, once
the mainstays of the economy, have declined in their
shares of GDP. Banking and other services now
contribute 42% to GDP. Trade is mostly with the UK.
The Isle of Man enjoys free access to EU markets.
GDP: purchasing power parity - $1 .4 billion
(1999 est.)
GDP - real growth rate: 13.5% (1999 est.)
GDP - per capita: purchasing power parity -
$18,800(1999 est.)
GDP - composition by sector:
agriculture: 1%
industry: 9%
services: 90% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%:NA%
Inflation rate (consumer prices); 2.5% (2000 est.)
Labor force: 36,61 0 (1 998)
Labor force - by occupation: agriculture, forestry
and fishing 3%, manufacturing 11%, construction
10%, transport and communication 8%, wholesale
and retail distribution 11%, professional and scientific
services 18%, public administration 6%, banking and
finance 18%, tourism 2%, entertainment and catering
3%, miscellaneous services 10%
Unemployment rate: 0.6% (August 2000)
Budget:
revenues: $485 million
expenditures: $463 million, including capital
expenditures of $NA (FYOO/01 est.)
Industries: financial services, light manufacturing,
tourism
Industrial production growth rate: 3.2%
(FY96/97)
Agriculture - products: cereals, vegetables; cattle,
sheep, pigs, poultry
Exports: $NA
Exports - commodities: tweeds, herring,
processed shellfish, beef, lamb
Exports ■ partners: UK
Imports: $NA
Imports - commodities: timber, fertilizers, fish
Imports - partners: UK
Debt -external: $NA
Economic aid ■ recipient: $NA
Currency: British pound (GBP); note - there is also a
Manx pound
Currency code: GBP
Exchange rates: Manx pounds per US dollar -
0.6764 (January 2001 ), 0.6596 (2000), 0.61 80 (1 999),
0.6037 (1998), 0.6106 (1997), 0.6403 (1996); the
Manx pound is at par with the British pound
Fiscal year: 1 April - 31 March','17fbbd426e2090159948bf4f531bf6b47288cc3bd335960f5165f7b938ce964f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('397eb3c405bde1e271ae8951a6d5618068ef5f8ffb61f5cc3865b1722f3e0fb8',2001,'MH','Marshall Islands','economy',786,'Economy - overview: US Government assistance is
the mainstay of this tiny island economy. Agricultural
production is concentrated on small farms, and the
most important commercial crops are coconuts,
tomatoes, melons, and breadfruit. Small-scale
industry is limited to handicrafts, fish processing, and
copra. The tourist industry, now a small source of
foreign exchange employing less than 10% of the
labor force, remains the best hope for future added
income. The islands have few natural resources, and
imports far exceed exports. Under the terms of the
Compact of Free Association, the US provides
roughly $65 million in annual aid. Negotiations were
underway in 1999 for an extended agreement.
Government downsizing, drought, a drop in
construction, and the decline in tourism and foreign
investment due to the Asian financial difficulties
caused GDP to fall in 1996-98.
GDP: purchasing power parity - $105 million
(1998 est.), supplemented by approximately $65
million annual US aid
GDP - real growth rate: -5% (1998 est.)
GDP - per capita: purchasing power parity - $1 ,670
(1998 est.)
GDP - composition by sector:
agriculture: 15%
industry: ^3%
services: 72% (1 995)
Popuiation below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 5% (1997)
Labor force: NA
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%o
Unemployment rate: 16% (1991 est.)
Budget:
revenues; $80.1 million
expend/Yures; $77.4 million, including capital
expenditures of $19.5 million (FY95/96 est.)
Industries; copra, fish, tourism, craft items from
shell, wood, and pearls, offshore banking (embryonic)
Industrial production growth rate: NA%)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Agriculture ■ products: coconuts, tomatoes,
melons, cacao, taro, breadfruit, fruits; pigs, chickens
Exports: $28 million (f.o.b., 1997 est.)
Exports - commodities: fish, coconut oil, trochus
shells
Exports - partners: US, Japan, Australia
Imports: $58 million (f.o.b., 1997 est.)
Imports - commodities: foodstuffs, machinery and
equipment, fuels, beverages and tobacco
Imports - partners: US, Japan, Australia, NZ,
Guam, Singapore
Debt - external: $125 million (FY96/97 est.)
Economic aid - recipient: approximately $65
million annually from the US
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September','92e8dc2b7b23e2bd7e5319020ea7a6303d527dcddd2a2d207b84083bbd49714b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e4257bcd36844c2bf925b4920ef950423ed96c25439ca205c3c2d1a99ee5cd9',2001,'MR','Mauritania','economy',798,'Economy - overview: A majority of the population
still depends on agriculture and livestock for a
livelihood, even though most of the nomads and many
subsistence farmers were forced into the cities by
recurrent droughts in the 1970s and 1980s.
Mauritania has extensive deposits of iron ore, which
account for half of total exports. The decline in world
demand for this ore, however, has led to cutbacks in
production. The nation''s coastal waters are among the
richest fishing areas in the world, but overexploitation
by foreigners threatens this key source of revenue.
The country''s first deepwater port opened near
Nouakchott in 1986. In the past, drought and
economic mismanagement have resulted in a buildup
of foreign debt. In March 1999, the government signed
an agreement with a joint World Bank-IMF mission on
a $54 million enhanced structural adjustment facility
(ESAF). Mauritania withdrew its membership in the
Economic Community of West African States
(ECOWAS) in 2000. Privatization and debt relief are in
full swing, and the rate of economic growth appears to
be accelerating, especially in the construction,
telecommunication, and information sectors.
Diamonds and petroleum are beginning to be
explored and exploited.
GDP: purchasing power parity - $5.4 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $2,000
(2000 est.)
GDP - composition by sector:
agriculture: 25%
industry: 9^%
services: 44% (1997)
Population beiow poverty line: 50% (1996 est.)
Househoid income or consumption by percentage
share:
lowest 10%: 2.3%
highest 29.9% (1995)
Infiation rate (consumer prices): 4.5% (2000 est.)
Labor force: 750,000(1999)
Labor force - by occupation: agriculture 47%,
services 39%, industry 14%
Unemployment rate: 23% (1995 est.)
Budget:
revenues: $329 million
expenditures: $235 million, including capital
expenditures of $75 million (1996 est.)
Industries: fish processing, mining of iron ore and
gypsum
Industrial production growth rate: 2.2% (1999)
Electricity - production: 151 million kWh (1999)
Electricity - production by source:
fossil fuel: 32.73%
hydro: 17.22%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 140.4 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
328
Mauritania (continued)
Electricity - imports: 0 kWh (1999)
Agriculture - products: dates, millet, sorghum, rice,
corn, dates; cattle, sheep
Exports: $333 million (f.o.b., 1999)
Exports - commodities: iron ore, fish and fish
products, gold
Exports - partners: Japan 18%, France 17%, Italy
16%, Spain 11% (1998)
Imports: $305 million (f.o.b., 1999)
Imports - commodities: machinery and equipment,
petroleum products, capital goods, foodstuffs,
consumer goods
Imports - partners: France 27%, Benelux 9%,
Germany 7%, Spain 7% (1998)
Debt -external: $2.1 billion (1999)
Economic aid - recipient: $300 million (1998)
Currency: ouguiya (MRO)
Currency code: MRO
Exchange rates: ouguiyas per US dollar - 250.870
(December 2000), 238.923 (2000), 209.514 (1999),
188.476 (1998), 151.853 (1997), 137.222 (1996)
Fiscal year: calendar year','0e78db61debbf580a1481e2c976ed2a6c077fcd48ff6a727b931fa84b6c1e4e1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b37b4b881c09e71fc3571cb0f55cb3e61a665709d27a75aba95ac7cf256f9a91',2001,'MU','Mauritius','economy',807,'Economy - overview: Since independence in 1 968,
Mauritius has developed from a low-income,
agriculturally based economy to a middle-income
diversified economy with growing industrial, financial,
and tourist sectors. For most of the period, annual
growth has been in the order of 5% to 6%. This
remarkable achievement has been reflected in
increased life expectancy, lowered infant mortality,
and a much-improved infrastructure. Sugarcane is
grown on about 90% of the cultivated land area and
accounts for 25% of export earnings. The
government''s development strategy centers on
foreign investment. Mauritius has attracted more than
9,000 offshore entities, many aimed at commerce in
India and South Africa, and investment in the banking
sector alone has reached over $1 billion. Economic
performance since 1991 has continued strong with
solid growth and low unemployment.
GDP: purchasing power parity - $12.3 billion
(2000 est.)
GDP - real growth rate: 7.5% (2000 est.)
GDP - per capita: purchasing power parity -
$10,400 (2000 est.)
GDP - composition by sector:
agriculture: 10%
industry: 29%
services: 31% (1996)
330
Mauritius (continued)
Population below poverty line: 10.6% (1992 est.)
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: NA%
Inflation rate (consumer prices): 5.3% (2000 est.)
Labor force: 51 4,000 (1 995)
Labor force - by occupation: construction and
industry 36%, services 24%, agriculture and fishing
14%, trade, restaurants, hotels 16%, transportation
and communication 7%, finance 3% (1995)
Unemployment rate: 6.4% (1999 est.)
Budget:
revenues; $1.1 billion
expenditures: $1 .2 billion, including capital
expenditures of $NA (1999 est.)
Industries: food processing (largely sugar milling),
textiles, clothing: chemicals, metal products, transport
equipment, nonelectrical machinery: tourism
Industrial production growth rate: 8% (2000 est.)
Electricity - production: 1 .26 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 91 .27%
hydro: 873%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 1 .172 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: sugarcane, tea, corn,
potatoes, bananas, pulses: cattle, goats: fish
Exports: $1.6 billion (f.o.b., 1999)
Exports - commodities: clothing and textiles,
sugar, cut flowers, molasses
Exports - partners: UK 32%, France 1 9%, US 1 5%,
Germany 6%, Italy 4% (1999 est.)
Imports: $2.3 billion (f.o.b., 1999)
Imports - commodities: manufactured goods,
capital equipment, foodstuffs, petroleum products,
chemicals (1996)
Imports - partners: France 14%, South Africa 1 1%,
India 8%, UK 5% (1999 est.)
Debt - external: $1 .9 billion (1 998 est.)
Economic aid - recipient: $42 million (1997)
Currency: Mauritian rupee (MUR)
Currency code: MUR
Exchange rates: Mauritian rupees per US dollar -
27.900 (January 2001), 26.250 (2000), 25.186 (1999),
22.993 (1 998), 21 .057 (1 997), 1 7.948 (1 996)
Fiscal year: 1 July - 30 June','36f907ee6403e52766decdea628e721643574f28f30f2dbe242718405fffe185','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc183873458476f6dc89af89f0b862018c06da877084157cdd47922be7cdbc4e',2001,'YT','Mayotte','economy',816,'Economy - overview: Economic activity is based
primarily on the agricultural sector, including fishing
and livestock raising. Mayotte is not self-sufficient and
must import a large portion of its food requirements,
mainly from France. The economy and future
development of the island are heavily dependent on
French financial assistance, an important supplement
to GDP. Mayotte''s remote location is an obstacle to
the development of tourism.
GDP: purchasing power parity - $85 million
(1998 est.)
GDP - real growth rate: NA%
GDP ■ per capita: purchasing power parity - $600
(1998 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
sen/ices: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%>: NA%
Inflation rate (consumer prices): NA%
Labor force: NA
Unemployment rate: 45% (1997)
Budget:
revenues: $NA
expenditures: $73 million. Including capital
expenditures of $NA (1991 est.)
Industries: newly created lobster and shrimp
industry, construction
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity -consumption: NAkWh
Agriculture - products: vanilla, ylang-ylang
(perfume essence), coffee, copra
Exports: $3.44 million (f.o.b., 1997)
Exports ■ commodities: ylang-ylang (perfume
essence), vanilla, copra, coconuts, coffee, cinnamon
Exports ■ partners: France 80%, Comoros 15%,
Reunion
Imports: $141.3 million (f.o.b., 1997)
Imports - commodities; food, machinery and
equipment, transportation equipment, metals,
chemicals
Imports - partners: France 66%, Africa 14%,
Southeast Asia 11% (1997)
Debt - external: $NA
Economic aid - recipient: $107.7 million (1995);
note - extensive French financial assistance
Currency: French franc (FRF); euro (EUR)
Currency code: FRF; EUR
Exchange rates: euros per US dollar - 1.0659
(January 2001), 1 .0854 (2000), 0.9386 (1999); French
francs per US dollar - 5.8995 (1998), 5.8367 (1997),
5.1155 (1996)
Fiscal year: calendar year','445c9db12a5b0f1bf38007307bde7bb8c8d6e4f3a4759fac86475e5513fa8c5e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab5b9d33863d6a2c9386880cdcc2dbb97c77f107054ae80168964628d3bb77ef',2001,'US','United States','economy',826,'Economy - overview: Mexico has a free market
economy with a mixture of modern and outmoded
industry and agriculture, increasingly dominated by
the private sector. The number of state-owned
enterprises in Mexico has fallen from more than 1 ,000
in 1 982 to fewer than 200 in 2000. The ZEDILLO
administration privatized and expanded competition in
seaports, railroads, telecommunications, electricity,
natural gas distribution, and airports. A strong export
sector helped to cushion the economy’s decline in
1995 and led the recovery in 1996-2000. Private
consumption became the leading driver of growth in
2000, accompanied by increased employment and
higher real wages. Mexico still needs to overcome
many structural problems as it strives to modernize its
economy and raise living standards. Income
distribution is very unequal, with the top 20% of
income earners accounting for 55% of income. Trade
with the US and Canada has tripled since NAFTA was
implemented in 1994. Mexico completed free trade
agreements with the EU, Israel, El Salvador,
Honduras, and Guatemala in 2000, and is pursuing
additional trade agreements with countries in Latin
America and Asia to lessen its dependence on the US.
GDP: purchasing power parity - $915 billion
(2000 est.)
GDP - real growth rate: 7.1% (2000 est.)
GDP - per capita: purchasing power parity - $9,100
(2000 est.)
GDP - confiposition by sector:
agriculture: 5%
industry: 27%
services: 68% (2000)
Population below poverty line: 27% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: 1 .8%
highest 10%: (me)
Inflation rate (consumer prices): 9% (2000 est.)
Labor force: 39.8 million (2000)
Labor force - by occupation: agriculture 20%,
industry 24%, services 56% (1 998)
Unemployment rate: urban - 2.2% (2000); plus
considerable underemployment
Budget:
revenues; $125 billion
expenditures: $130 billion, including capital
expenditures of $NA (2000 est.)
Industries: food and beverages, tobacco,
chemicals, iron and steel, petroleum, mining, textiles,
clothing, motor vehicles, consumer durables, tourism
Industrial production growth rate: 7.5%
(2000 est.)
Electricity - production: 1 82.492 billion kWh (1 999)
Electricity - production by source:
foss/7 fue/; 74.1 2%
hydro: 17.75%
nuc/ear; 5.21%
other: 2.92% (1999)
Electricity - consumption: 170.754 billion kWh
(1999)
Electricity - exports: 1 1 million kWh (1999)
Electricity - imports: 1 .047 billion kWh (1999)
Agriculture - products: corn, wheat, soybeans,
rice, beans, cotton, coffee, fruit, tomatoes; beef,
poultry, dairy products; wood products
Exports: $168 billion (f.o.b., 2000), includes in-bond
industries (assembly plant operations)
Exports ■ commodities: manufactured goods, oil
and oil products, silver, fruits, vegetables, coffee,
cotton
Exports ■ partners: US 88.6%, Canada 2%, Spain
0.9%, Germany 0.9%, Japan 0.6%, UK 0.6%,
Netherlands Antilles 0.5%, Switzerland 0.3%
Venezuela 0.3%, Chile 0.3% (2000 est.)
Imports: $176 billion (f.o.b., 2000), includes in-bond
industries (assembly plant operations)
Imports - commodities: metal-working machines,
steel mill products, agricultural machinery, electrical
equipment, car parts for assembly, repair parts for
motor vehicles, aircraft, and aircraft parts
Imports - partners: US 73.6%, Japan 3.7%,
Germany 3.3%, Canada 2.3%, South Korea 2%,
China 1.6%, Taiwan 1.2%, Italy 1%, Brazil 1%
(2000 est.)
Debt - external: $162 billion (2000)
Economic aid - recipient: $1,166 billion (1995)
Currency: Mexican peso (MXN)
Currency code: MXN
Exchange rates: Mexican pesos per US dollar -
9.7701 (January 2001), 9.4556 (2000), 9.5604 (1999),
9.1360 (1998), 7.9185 (1997), 7.5994 (1996)
Fiscal year: calendar year
Economy - overview: The US has the largest and
most technologically powerful economy in the world,
with a per capita GDP of $36,200. In this
market-oriented economy, private individuals and
business firms make most of the decisions, and
government buys needed goods and services
predominantly in the private marketplace. US
business firms enjoy considerably greater flexibility
than their counterparts in Western Europe and Japan
in decisions to expand capital plant, lay off surplus
workers, and develop new products. At the same time,
they face higher barriers to entry in their rivals'' home
markets than the barriers to entry of foreign firms in
US markets. US firms are at or near the forefront in
technological advances, especially in computers and
in medical, aerospace, and military equipment,
although their advantage has narrowed since the end
of World War II. The onrush of technology largely
explains the gradual development of a "two-tier labor
market" in which those at the bottom lack the
education and the professional/technical skills of
those at the top and, more and more, fail to get
comparable pay raises, health insurance coverage,
and other benefits. Since 1975, practically all the
gains in household income have gone to the top 20%
of households. The years 1994-2000 witnessed solid
increases in real output, low inflation rates, and a drop
in unemployment to below 5%. Long-term problems
include inadequate investment in economic
infrastructure, rapidly rising medical costs of an aging
population, sizable trade deficits, and stagnation of
family income in the lower economic groups. Growth
weakened in the fourth quarter of 2000; growth for the
year 2001 almost certainly will be substantially lower
than the strong 5% of 2000. The outlook for 2001 is
further clouded by the continued economic problems
of Japan, Russia, Indonesia, Brazil, and many other
countries.
GDP: purchasing power parity - $9,963 trillion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity -
$36,200 (2000 est.)
GDP ■ composition by sector:
agriculture: 2%
industry: ^S%
services: 80% (1 999)
Population below poverty line: 12.7% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%:^.8%
highest 30.5% (1997)
Inflation rate (consumer prices): 3.4% (2000)
Labor force: 140.9 million (includes unemployed)
(2000)
Labor force - by occupation: managerial and
professional 30.2%, technical, sales and
administrative support 29.2%, services 13.5%,
manufacturing, mining, transportation, and crafts
24.6%, farming, forestry, and fishing 2.5% (2000)
note: figures exclude the unemployed
Unemployment rate: 4% (2000)
Budget:
revenues: $1 .828 trillion
expenditures: $t703 trillion, including capital
expenditures of $NA (1999)
Industries: leading industrial power in the world,
highly diversified and technologically advanced;
petroleum, steel, motor vehicles, aerospace,
telecommunications, chemicals, electronics, food
processing, consumer goods, lumber, mining
Industrial production growth rate: 5.6%
(2000 est.)
Electricity - production: 3.678 trillion kWh (1999)
Electricity - production by source:
fossil fuel: 69.64%
hydro: S.3]%
nuclear: 19.8%
ote 2.25% (1999)
Electricity - consumption: 3.45 trillion kWh (1999)
Electricity ■ exports: 1 4 billion kWh (1 999)
Electricity ■ imports: 43 billion kWh (1999)
Agriculture ■ products: wheat, other grains, corn,
fruits, vegetables, cotton; beef, pork, poultry, dairy
products; forest products; fish
Exports: $776 billion (f.o.b., 2000 est.)
Exports - commodities: capital goods,
automobiles, industrial supplies and raw materials,
consumer goods, agricultural products
Exports ■ partners: Canada 23%, Mexico 14%,
Japan 8%, UK 5%, Germany 4%, France,
Netherlands (2000)
Imports: $1 .223 trillion (f.o.b., 2000 est.)
Imports - commodities: crude oil and refined
petroleum products, machinery, automobiles,
consumer goods, industrial raw materials, food and
beverages
Imports - partners: Canada 19%, Japan 11%,
Mexico 1 1%o, China 8%, Germany 5%, UK, Taiwan
(2000)
Debt ■ external: $862 billion (1995 est.)
Economic aid - donor: ODA, $6.9 billion (1997)
Currency: US dollar (USD)
Currency code: USD
Exchange rates: British pounds per US dollar -
0.6764 (January 2001 ), 0.6596 (2000), 0.6180 (1999),
0.6037 (1998), 0.6106 (1997), 0.6403 (1996);
Canadian dollars per US dollar - 1.5032 (January
2001), 1.4851 (2000), 1.4857 (1999), 1.4835 (1998),
1.3846 (1997), 1.3635 (1996); French francs per US
dollar - 5.65 (January 1999), 5.8995 (1998), 5.8367
(1997), 5.1 155 (1996), 4.9915 (1995), 5.5520 (1994);
Italian lire per US dollar - 1,668.7 (January 1999),
1,763.2(1998), 1,703.1 (1997), 1,542.9 (1996),
1 ,628.9 (1 995), 1 ,61 2.4 (1 994); Japanese yen per US
dollar - 1 17.1 0 (January 2001 ), 1 07.77 (2000), 1 13.91
(1999), 130.91 (1998), 120.99 (1997), 108.78 (1996);
German deutsche marks per US dollar - 1 .69
(January 1 999), 1 .9692 (1 998), 1 .7341 (1 997), 1 .5048
(1996), 1.4331 (1995), 1.6228 (1994); euros per US
dollar - 1.06594 (January 2001), 1.08540 (2000),
0.93863 (1999)
note: financial institutions in France, Italy, and
Germany and eight other European countries started
using the euro on 1 January 1999 with the euro
replacing the local currency in consenting countries
for all transactions in 2002
Fiscal year: 1 October - 30 September','19bbf26e999d30f2c25e195996fae956ceed6436b4286a77f146b69f3cedc5b3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9341ec94ca3900330c3caad5c32e5bb0b9e4b0036849aa44ab8964a64e8283fc',2001,'MC','Monaco','economy',834,'Economy - overview: Monaco, situated on the
French Mediterranean coast, is a popular resort,
attracting tourists to its casino and pleasant climate.
The Principality has successfully sought to diversify
into services and small, high-value-added,
nonpolluting industries. The state has no income tax
and low business taxes and thrives as a tax haven
both for individuals who have established residence
and for foreign companies that have set up
businesses and offices. The state retains monopolies
in a number of sectors, including tobacco, the
telephone network, and the postal service. Living
standards are high, roughly comparable to those in
prosperous French metropolitan areas. Monaco does
not publish national income figures; the estimates
below are extremely rough.
GDP: purchasing power parity - $870 million
(1999 est.)
GDP - real growth rate: NA%
GDP ■ per capita: purchasing power parity ■
$27,000 (1999 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 30,540 (January 1994)
Unemployment rate: 3.1% (1998)
Budget:
revenues; $518 million
expend/fures; $531 million, including capital
expenditures of $NA (1995)
Industries: tourism, construction, small-scale
industrial and consumer products
Industrial production growth rate: NA%
Electricity -consumption: NAkWh
Electricity - imports: NA kWh
note: electricity supplied by France (1999)
Agriculture - products: none
Exports: $NA; full customs integration with France,
which collects and rebates Monegasque trade duties;
also participates in EU market system through
customs union with France
Imports: $NA; full customs integration with France,
which collects and rebates Monegasque trade duties;
also participates in EU market system through
customs union with France
Debt -external: $NA
Economic aid - recipient: $NA
Currency: French franc (FRF); euro (EUR)
Currency code: FRF; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999); French
francs per US dollar - 5.8995 (1998), 5.8367 (1997),
5.1155 (1996)
Fiscal year: calendar year','7a61f7c840d9bca4c8d7e1e23b5b744cd33c79edd3f84c4cb6e659100fada073','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('167ff8d1152c37644186d939a0c62e63cc8a650148594a30f0c4573b276f3174',2001,'MS','Montserrat','economy',841,'Economy - overview: Severe volcanic activity,
which began in July 1995, has put a damper on this
small, open economy. A catastrophic eruption in June
1 997 closed the airports and seaports, causing further
economic and social dislocation. Two-thirds of the
12,000 inhabitants fled the island. Some began to
return in 1 998, but lack of housing limited the number.
The agriculture sector continued to be affected by the
lack of suitable land for farming and the destruction of
crops. Prospects for the economy depend largely on
developments in relation to the volcano and on public
sector construction activity. The UK committed to a
three year $125 million aid program in 1999 to help
reconstruct the economy.
GDP: purchasing power parity - $31 million
(1999 est.)
GDP - real growth rate: -1.5% (1999 est.)
GDP - per capita: purchasing power parity - $5,000
(1999 est.)
GDP - composition by sector:
agriculture: 5.4%
industry: 13.5%
services: 81% (1996 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: m%
highest 10%o:m%
Inflation rate (consumer prices): 5% (1998)
Labor force: 4,521 (1992); note - recently lowered
by flight of people from volcanic activity
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 20% (1996 est.)
Budget:
revenues; $31 .4 million
expenditures: $31. 5 million, including capital
expenditures of $8.4 million (1997 est.)
Industries: tourism, rum, textiles, electronic
appliances
Industrial production growth rate: NA%
Electricity - production: 10 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
of/ier; 0% (1999)
Electricity - consumption: 9.3 million kWh (1999)
Electricity ■ exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: cabbages, carrots,
cucumbers, tomatoes, onions, peppers; livestock
products
Exports: $1.5 million (1998)
Exports - commodities: electronic components,
plastic bags, apparel, hot peppers, live plants, cattle
Exports - partners: US, Antigua and Barbuda
(1993)
Imports: $26 million (1998)
346
Montserrat (continued)
Imports ■ commodities: machinery and
transportation equipment, foodstuffs, manufactured
goods, fuels, lubricants, and related materials
Imports - partners: US, UK, Trinidad and Tobago,
Japan, Canada (1993)
Debt - external: $8.9 million (1997)
Economic aid - recipient: $9.8 million (1995);
note - about $100 million (1996-98) in reconstruction
aid from the UK; Country Policy Plan (1999) is a
three-year program for spending $122.8 million in
British budgetary assistance
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Fiscal year: 1 April - 31 March','fb469fdff2d2f1801308f72ae979ad49e953af300523cb83f14e1bfcae013c04','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0595997802577c0439b11627ff5f356b26d6ae5a199e80bea8082a033289c1ae',2001,'NA','Namibia','economy',851,'Economy - overview: The economy is heavily
dependent on the extraction and processing of
minerals for export. Mining accounts for 20% of GDP.
Namibia is the fourth-largest exporter of nonfuel
minerals in Africa and the world''s fifth-largest
producer of uranium. Rich alluvial diamond deposits
make Namibia a primary source for gem-quality
diamonds. Namibia also produces large quantities of
lead, zinc, tin, silver, and tungsten. Half of the
population depends on agriculture (largely
subsistence agriculture) for its livelihood. Namibia
must import some of its food. Although per capita GDP
is four times the per capita GDP of Africa''s poorer
countries, the majority of Namibia''s people live in
pronounced poverty because of large-scale
unemployment, the great inequality of income
distribution, and the large amount of wealth going to
foreigners. The Namibian economy has close links to
South Africa. GDP growth in 2000 was led by gains in
the diamond and fish sectors. Agreement has been
reached on the privatization of several more
enterprises in coming years, which should stimulate
long-run foreign investment. Growth in 2001 could be
5.5% provided the world economy remains stable.
GDP: purchasing power parity - $7.6 billion
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity - $4,300
(2000 est.)
GDP - composition by sector:
agriculture: 12%
industry: 25%
se/v/ces:63%(1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%>: NA%
Inflation rate (consumer prices): 9.1% (2000)
Labor force: 500,000
Labor force - by occupation: agriculture 47%,
industry 20%, services 33% (1999 est.)
Unemployment rate: 30% to 40%, including
underemployment (1997 est.)
Budget:
revenues: $883 million
expenditures: $950 million, including capital
expenditures of $NA (1998)
Industries: meatpacking, fish processing, dairy
products; mining (diamond, lead, zinc, tin, silver,
tungsten, uranium, copper)
Industrial production growth rate: NA
Electricity - production: 1 .198 billion kWh (1999)
Electricity - production by source:
fossil fuel: 2%
hydro: 98%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 1 .948 billion kWh (1 999)
Electricity - exports: 56 million kWh (1999)
Electricity - imports: 890 million kWh
note: supplied by South Africa (1999)
Agriculture - products: millet, sorghum, peanuts;
livestock; fish
Exports: $1 .4 billion (f.o.b., 2000 est.)
Exports - commodities: diamonds, copper, gold,
zinc, lead, uranium; cattle, processed fish, karakul
skins
Exports - partners: UK 43%, South Africa 26%,
Spain 14%, France 8%, Japan (1998 est.)
Imports: $1 .6 billion (f.o.b., 2000 est.)
Imports - commodities: foodstuffs; petroleum
products and fuel, machinery and equipment,
chemicals
353
Namibia (continued)
Imports - partners: South Africa 81%, US 4%,
Germany 2% (1997 est.)
Debt - external: $217 million (2000 est.)
Economic aid - recipient: $127 million (1998)
Currency: Namibian dollar (NAD); South African
rand (ZAR)
Currency code: NAD; ZAR
Exchange rates: Namibian dollars per US dollar -
7.78307 (January 2001), 6.93983 (2000), 6.10948
(1999), 5.52828 (1998), 4.60796 (1997), 4.29935
(1996)
Fiscal year: 1 April - 31 March','514af0146fd1f85c9605a7e3eac6845a59ccd2dc3eeee61f00e95322ffd3b270','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdfff6d661b08fddfd17dc1b99d53424ebfe7b7d7d8f000c5cb3141a50d1203b',2001,'NR','Nauru','economy',859,'Economy - overview: Revenues of this tiny island
have come from exports of phosphates, but reserves
are expected to be exhausted within five to ten years.
Phosphate production has declined since 1989, as
demand has fallen in traditional markets and as the
marginal cost of extracting the remaining phosphate
increases, making it less internationally competitive.
While phosphates have given Nauruans one of the
highest per capita Incomes in the Third World, few
other resources exist with most necessities being
imported, including fresh water from Australia. The
rehabilitation of mined land and the replacement of
income from phosphates are serious long-term
problems. In anticipation of the exhaustion of Nauru''s
phosphate deposits, substantial amounts of
phosphate income have been invested in trust funds
to help cushion the transition and provide for Nauru''s
economic future. The government has been
borrowing heavily from the trusts to finance fiscal
deficits. To cut costs the government has called for a
freezing of wages, a reduction of over-staffed public
service departments, privatization of numerous
government agencies, and closure of some overseas
consulates. In recent years Nauru has encouraged
the registration of offshore banks and corporations.
Tens of billions of dollars have been channeled
through their accounts. Few comprehensive statistics
on the Nauru economy exist, with estimates of
Nauru''s per capita GDP varying widely.
GDP: purchasing power parity - $59 million (2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity ■ $5,000
(2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Infiation rate (consumer prices): -3.6% (1993)
Labor force - by occupation: employed in mining
phosphates, public administration, education, and
Economy - overview: no economic activity','069adc398d562a2bc031ee93d3c966d873ba806e7ea7db9ae715729254d7639b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f989ae0dea76c452ef6c1c2553b62173c46931a4fb1b3517b8528d81428a746',2001,'NP','Nepal','economy',867,'Economy - overview: Nepal is among the poorest
and least developed countries in the world with nearly
half of its population living below the poverty line.
Agriculture is the mainstay of the economy, providing
a livelihood for over 80% of the population and
accounting for 41% of GDP. Industrial activity mainly
involves the processing of agricultural produce
including jute, sugarcane, tobacco, and grain.
Production of textiles and carpets has expanded
recently and accounted for about 80% of foreign
exchange earnings in the past three years.
Agricultural production is growing by about 5% on
average as compared with annual population growth
of 2.3%. Since May 1991 , the government has been
moving forward with economic reforms, particularly
those that encourage trade and foreign investment,
e.g., by reducing business licenses and registration
requirements In order to simplify investment
procedures. The government has also been cutting
expenditures by reducing subsidies, privatizing state
industries, and laying off civil servants. More recently,
however, political instability - five different
governments over the past few years - has hampered
Kathmandu''s ability to forge consensus to implement
key economic reforms. Nepal has considerable scope
for accelerating economic growth by exploiting its
potential in hydropower and tourism, areas of recent
foreign investment interest. Prospects for foreign
trade or investment in other sectors will remain poor,
however, because of the small size of the economy,
its technological backwardness, its remoteness, its
landlocked geographic location, and its susceptibility
358
Nepal (continued)
to natural disaster. The international community''s role
of funding more than 60% of Nepal''s development
budget and more than 28% of total budgetary
expenditures will likely continue as a major ingredient
of growth.
GDP: purchasing power parity - $33.7 billion
(2000 est.)
GDP ■ real growth rate: 3.7% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,360
(2000 est.)
GDP - composition by sector:
agriculture: 4V/o
industry: 22%
services: 37% (2000 est.)
Population beiow poverty line: 42%
(FY95/96 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.2%
highest 29.8% (1995-96)
Infiation rate (consumer prices): 3.3%
(FY99/00 est.)
Labor force: 1 0 million (1996 est.)
note: severe lack of skilled labor
Labor force - by occupation: agriculture 81%,
services 16%, industry 3%
Unemployment rate: NA%; substantial
underemployment (1999)
Budget;
revenues; $536 million
expenditures: $S^S million, Including capital
expenditures of $NA (FY96/97 est.)
Industries: tourism, carpet, textile; small rice, jute,
sugar, and oilseed mills; cigarette; cement and brick
production
Industrial production growth rate: NA%
Eiectricity - production: 1.255 billion kWh (1999)
Electricity - production by source:
fossil fuel: 9.56%
hydro: 90.44%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 1 .309 billion kWh (1 999)
Electricity - exports: 68 million kWh (1999)
Electricity ■ Imports: 210 million kWh (1999)
Agriculture ■ products: rice, corn, wheat,
sugarcane, root crops; milk, water buffalo meat
Exports: $485 million (f.o.b., 1998), but does not
include unrecorded border trade with India
Exports - commodities: carpets, clothing, leather
goods, jute goods, grain
Exports - partners: India 33%, US 26%, Germany
25% (FY97/98)
Imports: $1.2 billion (f.o.b., 1998)
Imports - commodities: gold, machinery and
equipment, petroleum products, fertilizer
Imports - partners: India 31%, China/Hong Kong
16%, Singapore 14% (FY97/98)
Debt - external: $2.4 billion (1997)
Economic aid - recipient: $41 1 million (FY97/98)
Currency: Nepalese rupee (NPR)
Currency code: NPR
Exchange rates: Nepalese rupees per US dollar -
74.129 (January 2001), 71 .104 (2000), 68.239 (1 999),
65.976 (1998), 58.010 (1997), 56.692 (1996)
Fiscal year: 1 6 July - 1 5 July','ec48a7e818c41ea010cb99eb437374dae162a4a4dcd308a78b13013b81e4cff0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61848d879876da2ce85924dc8e9bb690990c1f3c8a28d8fe1266fcaeaf808384',2001,'NL','Netherlands','economy',876,'Economy - overview: Tourism, petroleum refining,
and offshore finance are the mainstays of this small
economy, which is closely tied to the outside world.
Although GDP has declined slightly in each of the past
five years, the islands enjoy a high per capita income
and a well-developed infrastructure as compared with
other countries in the region. Almost all consumer and
capital goods are imported, with Venezuela, the US,
and Mexico being the major suppliers. Poor soils and
inadequate water supplies hamper the development
of agriculture.
GDP: purchasing power parity - $2.4 billion
(2000 est.)
GDP - real growth rate: -3.5% (2000 est.)
GDP - per capita: purchasing power parity -
$11,400 (2000 est.)
GDP - composition by sector:
agriculture: 1%
industry: 15%
services: 84% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 6.4% (2000 est.)
Labor force: 89,000
Labor force - by occupation: agriculture 1%,
industry 13%, services 86% (1994 est.)
Unemployment rate: 14.9% (1998 est.)
Budget;
revenues; $71 0.8 million
expenditures: $741 .6 million, including capital
expenditures of $NA (1997 est.)
Industries; tourism (Curacao, Sint Maarten, and
Bonaire), petroleum refining (Curacao), petroleum
transshipment facilities (Curacao and Bonaire), light
manufacturing (Curacao)
Industrial production growth rate: NA%
Electricity -production: 1.11 billion kWh (1999)
Electricity - production by source:
foss/7 foe/; 100%
hydro: 0%
nuclear: 0%
ofoer; 0% (1999)
Electricity - consumption: 1 .032 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: aloes, sorghum, peanuts,
vegetables, tropical fruit
Exports: $276 million (f.o.b., 2000)
Exports - commodities: petroleum products
Exports - partners: US 17.5%, Guatemala 8%,
Costa Rica 6.5%, The Bahamas 4.6%, Jamaica 4.1%,
Chile 3.4% (1998)
Imports: $1.5 billion (f.o.b., 2000)
Imports - commodities: crude petroleum, food,
manufactures
Imports - partners: Venezuela 35.3%, US 21%,
Mexico 9.8%, Italy 5.4%, Netherlands 4.8%, Brazil
3.1% (1998)
Debt - external: $1.35 billion (1996)
Economic aid - recipient: IMF provided $61 million
in 2000, and the Netherlands continued its support
with $40 million
Currency: Netherlands Antillean guilder (ANG)
Currency code: ANG
Exchange rates: Netherlands Antillean guilders per
US dollar - 1.790 (fixed rate since 1989)
Fiscal year: calendar year
363
Netherlands Antilles (continued)','f158238c1d8546449371c06b4e9e323a3432245a74457a26f411b36b70fa3390','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d106ca7b49e0858e34cd04aef16abcb61df159c0f0ecaeb9e348ff7f0288804f',2001,'NZ','New Zealand','economy',885,'Economy - overview: Since 1984 the government
has accomplished major economic restructuring,
moving an agrarian economy dependent on
concessionary British market access toward a more
industrialized, free market economy that can compete
globally. This dynamic growth has boosted real
Incomes, broadened and deepened the technological
capabilities of the industrial sector, and contained
inflationary pressures. Inflation remains among the
lowest in the industrial world. Per capita GDP has
been moving up toward the levels of the big West
European economies. New Zealand''s heavy
dependence on trade leaves its growth prospects
vulnerable to economic performance in Asia, Europe,
and the US. With the FYOO/01 budget pushing up
pension and other public outlays, the government''s
ability to meet fiscal targets will depend on sustained
economic growth.
GDP: purchasing power parity - $67.6 billion
(2000 est.)
GDP - real growth rate: 3.6% (2000 est.)
GDP - per capita; purchasing power parity -
$17,700 (2000 est.)
GDP - composition by sector:
agriculture: 8%
industry: 23%
semces;69%(1999)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: 0.3%
highest /0%; 29.8% (1991 est.)
Inflation rate (consumer prices): 2.4% (2000 est.)
Labor force: 1 .88 million (2000)
Labor force - by occupation: services 65%,
industry 25%, agriculture 10% (1995)
Unemployment rate: 6.3% (2000 est.)
Budget:
revenues; $19.2 billion
expenditures: $^92 billion, including capital
expenditures of $NA (1999 est.)
Industries: food processing, wood and paper
products, textiles, machinery, transportation
equipment, banking and insurance, tourism, mining
Industrial production growth rate; 6.2% (2000)
Electricity - production: 37.952 billion kWh (1999)
Electricity - production by source:
fossil fuel: 30.49%
^ydro; 61.42%
nuclear: 0%
other; 8.09% (1999)
Electricity - consumption: 35.295 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: wheat, barley, potatoes,
pulses, fruits, vegetables; wool, beef, dairy products;
fish
Exports: $14.6 billion (f.o.b., 2000 est.)
Exports ■ commodities: dairy products, meat, fish,
wool, forestry products, manufactures
Exports - partners: Australia 22%, US 14%, Japan
13%, UK 7% (1999)
Imports: $14.3 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
vehicles and aircraft, petroleum, consumer goods,
plastics
Imports - partners: Australia 24%, US 17%, Japan
12%, UK 4% (1999)
Debt - external: $30.8 billion (2000 est.)
Economic aid ■ donor: ODA, $123 million (1995)
Currency: New Zealand dollar (NZD)
Currency code: NZD
Exchange rates: New Zealand dollars per US
dollar ■ 2.2502 (January 2001 ), 2.1 863 (2000), 1 .8886
(1999), 1.8632 (1998), 1.5083 (1997), 1.4543 (1996)
Fiscal year: 1 July - 30 June
Economy - overview: Tonga has a small, open
economy with a narrow export base in agricultural
goods, which contributes 30% to GDP. Squash,
coconuts, bananas, and vanilla beans are the main
crops, and agricultural exports make up two-thirds of
total exports. The country must import a high
proportion of its food, mainly from New Zealand. The
industrial sector accounts for only 10% of GDP.
Tourism is the primary source of hard currency
earnings. The country remains dependent on sizable
external aid and remittances from Tongan
communities overseas to offset its trade deficit. The
government is emphasizing the development of the
private sector, especially the encouragement of
investment, and is committing increased funds for
health and education. Tonga has a reasonable basic
infrastructure and well-developed social services.
GDP: purchasing power parity - $225 million
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP ■ per capita: purchasing power parity - $2,200
(2000 est.)
GDP ■ composition by sector:
agriculture: 30%
industry: ^0%
services: 60% (^997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 7% (2000 est.)
Labor force: 34,000 (FY96/97)
Labor force - by occupation: agriculture 65%
(1997 est.)
Unemployment rate: 13.3% (FY96/97)
Budget:
revenues: $49 million
expenditures: $120 million, including capital
expenditures of $75 million (FY96/97 est.)
Industries: tourism, fishing
Industrial production growth rate: 8.6%
(FY98/99)
Electricity - production: 35 million kWh (1999)
Electricity - production by source:
fossil fuel: 1 00%
hydro: 0%
nuclear: 0%
oto.''0%(1999)
Electricity - consumption: 32.6 million kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: squash, coconuts, copra,
bananas, vanilla beans, cocoa, coffee, ginger, black
pepper; fish
Exports: $8 million (f.o.b., 1998)
Exports - commodities: squash, fish, vanilla beans
Exports - partners: Japan 53%, US 18%, NZ 6%,
Australia 6% (1997 est.)
Imports: $69 million (f.o.b., 1998)
Imports - commodities: foodstuffs, machinery and
transport equipment, fuels, chemicals
Imports - partners: NZ 30%, Australia 19%, US
11%, UK 11%, Japan 3% (1997 est.)
Debt - external: $62 million (1998)
Economic aid - recipient: $38.8 million (1995)
Currency: pa''anga (TOP)
Currency code: TOP
Exchange rates: pa''anga per US dollar - 1 .9885
(January 2001), 1.7585 (2000), 1.5991 (1999), 1.4920
(1998), 1.2635(1997), 1.2323 (1996)
Rsca! year: 1 July - 30 June
Economy - overview: Trinidad and Tobago has
earned a reputation as an excellent investment site for
International businesses. Successful economic
reforms were implemented in 1995, and foreign
investment and trade are flourishing. Persistently high
unemployment remains one of the chief challenges of
the government. The petrochemical sector has
spurred growth in other related sectors, reinforcing the
government''s commitment to economic
diversification. Tourism is growing, especially in the
pleasure boat sector. New investment and
construction also will continue to drive the economy.
GDP: purchasing power parity - $1 1 .2 billion
(2000 est.)
GDP • real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $9,500
(2000 est.)
GDP - composition by sector:
agriculture: 2%
industry: 44%
services: 54% (1998 est.)
Population below poverty line: 21% (1992 est.)
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3.2% (2000 est.)
Labor force: 558,700(1998)
Labor force ■ by occupation: construction and
utilities 12.4%, manufacturing, mining, and quarrying
14%, agriculture 9.5%, services 64.1% (1997 est.)
Unemployment rate: 12.8% (2000)
Budget:
revenues; $1.54 billion
expenditures: $1 .6 billion, including capital
expenditures of $1 17.3 million (1998)
Industries: petroleum, chemicals, tourism, food
processing, cement, beverage, cotton textiles
Industrial production growth rate: 3.8% (2000)
Electricity - production: 4.9 billion kWh (1999)
Electricity - production by source:
fossil fuel: 99.59%
hydro: 0%
nuclear: 0%
other; 0.41% (1999)
Electricity - consumption: 4.557 billion kWh (1 999)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cocoa, sugarcane, rice,
citrus, coffee, vegetables; poultry
Exports: $3.2 billion (f.o.b., 2000)
Exports " commodities: petroleum and petroleum
products, chemicals, steel products, fertilizer, sugar,
cocoa, coffee, citrus, flowers
Exports - partners: US 39.3%, Caricom countries
26.1%, Latin America 9.5%, EU 5.7% (1999)
Imports: $3 billion (f.o.b., 2000 est.)
Imports - commodities: machinery, transportation
equipment, manufactured goods, food, live animals
Imports •• partners: US 39.8%, Venezuela 1 1 .9%,
EU11%, Caricom 4.8% (1999)
Debt - external: $2.8 billion (2000 est.)
Economic aid ■ recipient: $121.4 million (1995)
Currency: Trinidad and Tobago dollar (TTD)
Currency code: TTD
Exchange rates: TrinidadandTobagodollarsperUS
dollar - 6.2688 (January 2001), 6.2998 (2000), 6.2989
(1999), 6.2983 (1998), 6.2517 (1997), 6.0051 (1996)
Fiscal year: 1 October - 30 September
Economy - overview: no economic activity
Economy - overview: The economy is limited to
traditional subsistence agriculture, with about 80% of
the labor force earning its livelihood from agriculture
(coconuts and vegetables), livestock (mostly pigs),
and fishing. About 4% of the population is employed in
government. Revenues come from French
Government subsidies, licensing of fishing rights to
Japan and South Korea, import taxes, and
remittances from expatriate workers in New
Caledonia.
GDP: purchasing power parity - $30 million
(1997 est.)
GDP ■ real growth rate: NA%
GDP • per capita: purchasing power parity - $2,000
(1997 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
sen/ices: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%>: NA%
Inflation rate (consumer prices): NA%
Labor force: NA
Labor force - by occupation: agriculture, livestock,
and fishing 80%, government 4% (est.)
Unemployment rate: NA%
Budget:
revenues: $20 million
expenditures: million, including capital
expenditures of $NA (1998 est.)
Industries: copra, handicrafts, fishing, lumber
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity -consumption: NAkWh
Agriculture - products: breadfruit, yams, taro,
bananas; pigs, goats
Exports: $250,000 (f.o.b., 1999)
Exports - commodities: copra, chemicals,
construction materials
Exports - partners: Italy 40%, Croatia 15%, US
14%, Denmark 13%
Imports: $300 million (f.o.b., 1999)
Imports ■ commodities: chemicals, machinery,
passenger ships, consumer goods
imports - partners: France 97%, Australia 2%, New
Zealand 1%
Debt - external: $NA
Economic aid - recipient: assistance from France
Currency: Comptoirs Francais du Pacifique franc
(XPF)
Currency code: XPF
Exchange rates: Comptoirs Francais du Pacifique
francs (XPF) per US dollar - 1 127.1 1 (January 2001),
129.43 (2000), 111.93(1999), 107.25(1998), 106.11
(1997), 93.00 (1996); note ■ linked at the rate of
119.25 XPF to the euro
Fiscal year: calendar year','f12c2e81a913898029d9aa33740760d389189f0afb804b4ea6bcf5c0b51cf2a1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d631b09377a74e4be7424e7cbe51312593679104d715c776e18d2c01d818c5e',2001,'NI','Nicaragua','economy',889,'Economy - overview: Nicaragua, one of the
hemisphere''s poorest countries, faces low per capita
income, flagging socio-economic indicators, and huge
external debt. While the country has made progress
toward macro-economic stabilization over the past
few years, a banking crisis and scandal has shaken
the economy. Managua will continue to be dependent
on international aid and debt relief under the Heavily
Indebted Poor Countries (HIPC) initiative. Donors
have made aid conditional on improving governability,
the openness of government financial operation,
poverty alleviation, and human rights. Nicaragua met
the conditions for additional debt service relief in
December 2000. Growth should remain moderate to
high in 2001.
GDP: purchasing power parity -$13.1 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $2,700
(2000 est.)
GDP - composition by sector:
agriculture: 31.6%
industry: 22.8%
semces; 45.6% (1999)
Population below poverty line: 50% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 1.6%
highest 39.8% (1993)
Inflation rate (consumer prices): 1 1 % (2000 est.)
Labor force: 1.7 million (1999)
Labor force - by occupation: services 43%,
agriculture 42%, industry 15% (1999 est.)
Unemployment rate: 20% plus considerable
underemployment (1999 est.)
370
Nicaragua (continued)
Budget:
revenues: $734 million
expenditures: $836 million, including capital
expenditures of $NA (1999 est.)
Industries: food processing, chemicals, machinery
and metal products, textiles, clothing, petroleum
refining and distribution, beverages, footwear, wood
Industrial production growth rate: 4.4%
(2000 est.)
Electricity - production: 2.349 billion kWh (1999)
Electricity - production by source:
fossil fuel: 67.26%
hydro; 17.71%
nuclear: 0%
ofher; 15.03% (1999)
Electricity - consumption: 2.265 billion kWh (1 999)
Electricity - exports: 20 million kWh (1999)
Electricity ■ imports: 100 million kWh (1999)
Agriculture - products: coffee, bananas,
sugarcane, cotton, rice, corn, tobacco, sesame, soya,
beans; beef, veal, pork, poultry, dairy products
Exports: $631 million (f.o.b., 2000 est.)
Exports - commodities: coffee, shrimp and lobster,
cotton, tobacco, beef, sugar, bananas; gold
Exports - partners: US 37.7%, El Salvador 12.5%,
Germany 9.8%, Costa Rica 5,1 %, Spain 2.5%, France
2.1% (1999)
Imports: $1 .6 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
raw materials, petroleum products, consumer goods
Imports - partners: US 34.5%, Costa Rica 1 1 .4%,
Guatemala 7.3%, Panama 6.9%, Venezuela 5.9%, El
Salvador 5.5% (1999)
Debt - external: $6.4 billion (2000 est.)
Economic aid - recipient: NA
Currency: gold cordoba (NIC)
Currency code: NIC
Exchange rates: gold cordobas per US dollar -
12.96 (November 2000), 12.69 (2000 est.), 11.81
(1999), 10.58 (1998), 9.45 (1997), 8.44 (1996)
Fiscal year: calendar year','ecf48b69ff403b681448e9a82c057e497796eba6b18460211092dd7f12261def','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e849caec20994e61dd6918adc6e78233c93f3ce6a49f40d8a52596c0ae22b679',2001,'NE','Niger','economy',897,'Economy - overview: Niger is a poor, landlocked
Sub-Saharan nation, whose economy centers on
subsistence agriculture, animal husbandry, reexport
trade, and increasingly less on uranium, because of
declining world demand. The 50% devaluation of the
West African franc in January 1 994 boosted exports of
livestock, cowpeas, onions, and the products of
Niger''s small cotton Industry. The government relies
on bilateral and multilateral aid - which was
suspended following the April 1999 coup d''etat - for
operating expenses and public investment. In 2000,
the World Bank approved a structural adjustment loan
of $35 million to help support fiscal reforms. However,
reforms could prove difficult given the government''s
bleak financial situation.
GDP: purchasing power parity - $10 billion
(2000 est.)
GDP - real growth rate: 3.5% (2000 est.)
GDP - per capita: purchasing power parity - $1 ,000
(2000 est.)
372
Nigor (continued)
GDP - composition by sector:
agriculture: 40%
industry: 18%
services: 42% (1998)
Popuiation below poverty line: 63% (1993 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.8%
highest 10%: 35.4% (1995)
Inflation rate (consumer prices): 2.8% (2000 est.)
Labor force: 70,000 receive regular wages or
salaries
Labor force - by occupation: agriculture 90%,
industry and commerce 6%, government 4%
Unemployment rate: NA%
Budget:
revenues: $377 million, including $146 million from
foreign sources
expenditures: $377 million, Including capital
expenditures of $105 million (1999 est.)
Industries: uranium mining, cement, brick, textiles,
food processing, chemicals, slaughterhouses
Industrial production growth rate: NA%
Electricity - production: 200 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(1999)
Electricity - consumption: 401 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 215 million kWh (1999)
Agriculture - products: cowpeas, cotton, peanuts,
millet, sorghum, cassava (tapioca), rice; cattle, sheep,
goats, camels, donkeys, horses, poultry
Exports: $385 million (f.o.b., 1999)
Exports - commodities: uranium ore 65%, livestock
products, cowpeas, onions (1998 est.)
Exports - partners: France 45%, Nigeria 27%, UK
11% (1999)
Imports: $317 million (f.o.b., 1999)
Imports - commodities: consumer goods, primary
materials, machinery, vehicles and parts, petroleum,
cereals
Imports - partners: France 22%, Cote d''Ivoire 1 5%,
Nigeria 8%, US 3% (1999)
Debt - external: $1 .3 billion (1 999 est.)
Economic aid - recipient: $341 million (1997)
note: the IMF approved a $73 million poverty
reduction and growth facility for Niger in 2000 and
announced $115 million in debt relief under the
Heavily Indebted Poor Countries (HIPC) initiative
Currency: Communaute Financiere Africaine franc
(XOF): note responsible authority is the Central
Bank of the West African States
Currency code: XOF
Exchange rates: Communaute Financiere Africaine
francs (XOF) per US dollar - 699.21 (January 2001),
711.98 (2000), 615.70 (1999), 589.95 (1998), 583.67
(1 997), 51 1 .55 (1 996); note - from 1 January 1 999,
the XOF is pegged to the euro at a rate of 655.957
XOF per euro
Fiscal year: calendar year
Economy - overview: The oil-rich Nigerian
economy, long hobbled by political instability,
corruption, and poor macroeconomic management, is
undergoing substantial economic reform under the
new civilian administration. Nigeria''s former military
rulers failed to diversify the economy away from
overdependence on the capital-intensive oil sector,
which provides 20% of GDP, 95% of foreign exchange
earnings, and about 65% of budgetary revenues. The
largely subsistence agricultural sector has failed to
keep up with rapid population growth, and Nigeria,
once a large net exporter of food, now must import
food. Following the signing of an IMF stand-by
agreement in August 2000, Nigeria received a
debt-restructuring deal from the Paris Club and a $1
billion loan from the IMF, both contingent on economic
reforms. Increases in foreign investment and oil
production combined with high world oil prices should
push growth over 4% in 2001-02.
GDP: purchasing power parity - $1 1 7 billion
(2000 est.)
GDP - real growth rate: 3.5% (2000 est.)
GDP - per capita: purchasing power parity - $950
(2000 est.)
GDP - composition by sector:
agriculture: 40%
industry: 40%
services: 20% (1999 est.)
Popuiation beiow poverty line: 45% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 1.6%
highest 10%: 40.8% (1996-97)
Infiation rate (consumer prices): 6.5% (2000 est.)
Labor force: 66 million (1999 est.)
Labor force - by occupation: agriculture 70%,
industry 10%, services 20% (1999 est.)
Unemployment rate: 28% (1992 est.)
Budget:
revenues: $3.4 billion
expenditures: $3.6 billion, including capital
expenditures of $NA (2000 est.)
Industries: crude oil, coal, tin, columbite, palm oil,
peanuts, cotton, rubber, wood, hides and skins,
textiles, cement and other construction materials, food
products, footwear, chemicals, fertilizer, printing,
ceramics, steel
Industrial production growth rate; 1.5%
(2000 est.)
Electricity - production: 18.7 billion kWh (1999)
Electricity - production by source:
fossil fuel: 52.94%
hydro: 47.06%
nuclear: 0%
other: 0%(1999)
Electricity - consumption: 17.372 billion kWh
(1999)
Electricity - exports: 1 9 million kWh (1 999)
Electricity - imports; 0 kWh (1999)
Agriculture ■ products: cocoa, peanuts, palm oil,
corn, rice, sorghum, millet, cassava (tapioca), yams,
rubber; cattle, sheep, goats, pigs; timber; fish
Exports: $22.2 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum and petroleum
products 95%, cocoa, rubber
Exports - partners: US 36%, India 9%, Spain 8%,
Brazil 6%, France 6%, (1999)
Imports: $10.7 billion (f.o.b., 2000 est.)
Imports - commodities: machinery, chemicals,
transport equipment, manufactured goods, food and
live animals
Imports - partners: UK 11%, Germany 10%, US
9%, France 8%, China 6% (1999)
Debt - external: $32 billion (2000 est.)
Economic aid ■ recipient: ODA $250 million (1 998)
Currency: naira (NGN)
Currency code: NGN
Exchange rates: nairas per US dollar - 1 1 0.005
(January 2001), 101.697 (2000), 92.338 (1999),
21.886 (1998), 21.886 (1997), 21.884 (1996)
Fiscal year: calendar year','c13576e4809f6623e64980b20793650bad1f0f53f5da4e30892c88c1ab1ebdcf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4c0e839b2a4872b1a25c4090a165dfcc40b789fb20219b9ef8488b3fb4f09dc',2001,'NU','Niue','economy',906,'Economy - overview: Government expenditures
regularly exceed revenues, and the shortfall is made
up by critically needed grants from New Zealand that
are used to pay wages to public employees. Niue has
cut government expenditures by reducing the public
service by almost half. The agricultural sector consists
mainly of subsistence gardening, although some cash
crops are grown for export. Industry consists primarily
of small factories to process passion fruit, lime oil,
honey, and coconut cream. The sale of postage
stamps to foreign collectors is an important source of
revenue. The island in recent years has suffered a
serious loss of population because of migration of
Niueans to New Zealand. Efforts to increase GDP
include the promotion of tourism and a financial
services industry.
GDP: purchasing power parity - $4.5 million
(1997 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $2,800
(1997 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1% (1995)
Labor force: 450 (1992 est.)
Labor force - by occupation: most work on family
plantations; paid work exists only in government
service, small industry, and the Niue Development
Board
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: tourism, handicrafts, food processing
Industrial production growth rate: NA%
Electricity ■ production: 3 million kWh (1999)
Electricity ■ production by source:
foss/7 fue/.'' 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 2.8 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coconuts, passion fruit,
honey, limes, taro, yams, cassava (tapioca), sweet
potatoes; pigs, poultry, beef cattle
Exports: $117,500 (f.o.b., 1989)
Exports - commodities: canned coconut cream,
copra, honey, passion fruit products, pawpaws, root
crops, limes, footballs, stamps, handicrafts
Exports - partners: NZ 89%, Fiji, Cook Islands,','21365a8158e95e633e9caab7644545778d401b04bf53485b79a0d8f8367c8061','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('954f80bbb695738ffb5f93e60e178d45cc8fa57447cb4193d2b1641589062365',2001,'MP','Northern Mariana Islands','economy',908,'Economy - overview: The economy benefits
substantially from financial assistance from the US.
The rate of funding has declined as locally generated
government revenues have grown. The key tourist
industry employs about 50% of the work force and
accounts for roughly one-fourth of GDP. Japanese
tourists predominate. Annual tourist entries have
exceeded one-half million in recent years, but
financial difficulties in Japan have caused a temporary
slowdown. The agricultural sector is made up of cattle
ranches and small farms producing coconuts,
breadfruit, tomatoes, and melons. Garment
production is by far the most important industry with
employment of 12,000 mostly Chinese workers and
sizable shipments to the US under duty and quota
exemptions.
GDP: purchasing power parity - $900 million
(2000 est.)
note: GDP numbers reflect US spending
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$12,500 (2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household Income or consumption by percentage
share;
lowest 10%: NA%
highest f0%.-NA%
Inflation rate (consumer prices): 1 .2% (1 997 est.)
Labor force: 6,006 total indigenous labor force;
2,699 unemployed; 28,717 foreign workers (1995)
380
Northern Mariana Islands (continued)
Labor force -by occupation: NA
Unemployment rate: NA%
Budget:
revenues: $221 million
expenditures: $213 million, including capital
expenditures of $17.7 million (1996)
Industries: tourism, construction, garments,
handicrafts
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - consumption: NA kWh
Agriculture - products: coconuts, fruits,
vegetables; cattle
Exports: $NA
Exports - commodities: garments
Exports - partners: US
Imports: $NA
Imports - commodities: food, construction
equipment and materials, petroleum products
Imports - partners: US, Japan
Debt -external: $NA
Economic aid - recipient: extensive funding from
US
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September
Economy - overview: Economic activity Is limited to
providing services to contractors located on the
island. All food and manufactured goods must be
imported.
Electricity - production; NA kWh','437811e69276ceca5c2660db75c61e892ad24678eac11a20291127caabdfd10c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69b86618d129372435d34923e844366d8bd79075f97c5737e1dfc763c0af333c',2001,'PA','Panama','economy',917,'Economy - overview: Panama''s economy is based
primarily on a well-developed services sector that
accounts for three-fourths of GDP. Services include
the Panama Canal, banking, the Colon Free Zone,
insurance, container ports, flagship registry, and
tourism. A slump in Colon Free Zone and agricultural
exports, high oil prices, and the withdrawal of US
military forces held back economic growth in 2000.
The government plans public works programs, tax
reforms, and new regional trade agreements in order
to stimulate growth in 2001.
GDP: purchasing power parity - $1 6.6 billion
(2000 est.)
GDP - real growth rate: 2.5% (2000 est.)
GDP - per capita: purchasing power parity - $6,000
(2000 est.)
GDP - composition by sector:
agriculture: 7%
industry: 16.5%
services: 76.5% (1999 est.)
Population beiow poverty line: 37% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 1 .2%
highest 10%: 35.7% (1997)
Inflation rate (consumer prices): 1 .8% (2000 est.)
393
Panama (continued)
Labor force: 1.1 million (2000 est.)
note: shortage of skilled labor, but an oversupply of
unskilled labor
Labor force - by occupation: agriculture 20.8%,
industry 18%, services 61.2% (1995 est.)
Unemployment rate: 13% (2000 est.)
Budget:
revenues; $2.8 billion
expenditures: $2.9 billion, including capital
expenditures of $471 million (2000 est.)
Industries: construction, petroleum refining,
brewing, cement and other construction materials,
sugar milling ^
Industrial production growth rate: 2% (2000 est.)
Electricity - production: 4.413 billion kWh (1999)
Electricity - production by source:
fossil fuel: 27.78%
hydro: 71.65%
nuclear: 0%
ote 0.57% (1999)
Electricity - consumption: 4.049 billion kWh (1999)
Electricity - exports: 95 million kWh (1999)
Electricity - imports: 40 million kWh (1999)
Agriculture - products: bananas, rice, corn, coffee,
sugarcane, vegetables; livestock; shrimp
Exports: $5.7 billion (f.o.b., 2000 est.)
Exports - commodities: bananas, shrimp, sugar,
coffee, clothing
Exports - partners: US 42%, Germany 11%, Costa
Rica 5%, Benelux 4%, Italy 4% (1999)
Imports: $6.9 billion (f.o.b., 2000 est.)
Imports - commodities: capital goods, crude oil,
foodstuffs, consumer goods, chemicals
Imports - partners: US 39%, Colon Free Zone 14%,
Japan 8%, Ecuador 6%, Mexico 5% (1999)
Debt ■ external: $7.56 billion (2000 est.)
Economic aid - recipient: $197.1 million (1995)
Currency: balboa (PAB); US dollar (USD)
Currency code: PAB; USD
Exchange rates; balboas per US dollar - 1 .000
(fixed rate)
Fiscal year: calendar year','a3e97cde8e5fc66688a023e933fba1cef7d28ce4d9488dae7b34ecc74515621e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9332df9cf443cfebda15c0873890c563cb08f2afb783083f0890c7a206aed6c1',2001,'AR','Argentina','economy',922,'Economy - overview: Paraguay has a market
economy marked by a large informal sector. The
informal sector features both reexport of imported
consumer goods to neighboring countries as well as
the activities of thousands of microenterprises and
urban street vendors. Because of the importance of
the informal sector, accurate economic measures are
difficult to obtain. A large percentage of the population
derives their living from agricultural activity, often on a
subsistence basis. The formal economy grew by an
average of about 3% annually in 1995-97, but GDP
declined slightly in 1998 and 1999. On a per capita
basis, real income has stagnated at 1980 levels. Most
observers attribute Paraguay''s poor economic
performance to political uncertainty, corruption, lack of
progress on structural reform, substantial internal and
external debt, and deficient infrastructure. Growth
rebounded slightly in 2000.
GDP: purchasing power parity - $26.2 billion
(2000 est.)
GDP - real growth rate: 1% (2000 est.)
GDP - per capita: purchasing power parity - $4,750
(2000 est.)
GDP - composition by sector;
agriculture: 28%
industry: 2^%
services: 5^/0 (1999 est.)
Population below poverty line: 36% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.7%
highest 10%; 46.6% (1995)
inflation rate (consumer prices): 8% (2000 est.)
Labor force: 2 million (2000 est.)
Labor force - by occupation: agriculture 45%
Unemployment rate: 16% (2000 est.)
Budget:
revenues: $1 .3 billion
expenditures: $2 billion, including capital
expenditures of $700 million (1999 est.)
Industries: sugar, cement, textiles, beverages,
wood products
Industrial production growth rate: 0% (2000 est.)
Electricity - production: 51 .554 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 0.07%
hydro: 99.79%
nuclear: 0%
other; 0.1 5% (1999)
Electricity - consumption: 1 .91 5 billion kWh (1 999)
Electricity - exports: 46.03 billion kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cotton, sugarcane,
soybeans, corn, wheat, tobacco, cassava (yucca),
fruits, vegetables; beef, pork, eggs, milk; timber
Exports: $3.5 billion (f.o.b., 2000 est.)
Exports - commodities: electricity, soybeans, feed,
cotton, meat, edible oils
Exports - partners: Brazil, Argentina, EU
Imports: $3.3 billion (f.o.b., 2000 est.)
Imports - commodities: road vehicles, consumer
goods, tobacco, petroleum products, electrical
machinery
Imports - partners: Brazil, US, Argentina, Uruguay,
EU, Hong Kong
Debt “ external: $3 billion (2000 est.)
Economic aid - recipient: $NA
Currency: guarani (PYG)
Currency code: PYG
Exchange rates: guarani per US dollar - 3,570.0
(January 2001), 3,486.4 (2000), 3,119.1 (1999),
2,726.5 (1998), 2,177.9 (1997), 2,056.8 (1996); note -
since early 1998, the exchange rate has operated as
a managed float; prior to that, the exchange rate was
determined freely in the market
Fiscal year: calendar year','b8adefbf4e3eb7f8684793a403e42c1a354324a7d263c4367ce574e8e3277f0a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6234ed29c22f0aafe725d56956061d0d993f49a0a5f5b633e170f95c09907a4',2001,'PN','Pitcairn','economy',930,'Economy - overview: The inhabitants of this tiny
economy exist on fishing, subsistence farming,
handicrafts, and postage stamps. The fertile soil of the
valleys produces a wide variety of fruits and
vegetables, including citrus, sugarcane, watermelons,
bananas, yams, and beans. Bartering is an important
part of the economy. The major sources of revenue
are the sale of postage stamps to collectors and the
sale of handicrafts to passing ships.
GDP: purchasing power parity - $NA
GDP - real growth rate: NA%
GDP ■ per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%:
Inflation rate (consumer prices): NA%
Labor force: 1 2 able-bodied men (1 997)
Labor force - by occupation: no business
community in the usual sense; some public works;
subsistence farming and fishing
Unemployment rate: NA%
Budget:
revenues: $729,884
expenditures: $878,1 19, Including capital
expenditures of $NA (FY94/95 est.)
Industries: postage stamps, handicrafts
Industrial production growth rate: NA%
Electricity - production: NA kWh; note - electric
power Is provided by a small diesel-powered
generator
Electricity - consumption: NA kWh
Agriculture - products: wide variety of fruits and
vegetables, goats, chickens
Exports: $NA
Exports - commodities: fruits, vegetables, curios,
stamps
Exports - partners: NA
Imports: $NA
Imports - commodities: fuel oil, machinery, building
materials, flour, sugar, other foodstuffs
Imports - partners: NA
Debt - external: $NA
Economic aid - recipient: $NA
Currency: New Zealand dollar (NZD)
Currency code: NZD
Exchange rates; New Zealand dollars per US
dollar -2.2502 (January 2001), 2.1863 (2000), 1 .8886
(1999), 1.8629 (1998), 1.5083 (1997), 1.4543 (1996)
Fiscal year: 1 April - 31 March','72dc57945b8e8841debb298c997b9df53e9b9b13fb5d19548c8d776547fbd1eb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de18b8c9688f806b91720f1e6758f1d90f7475eb819b76c4201da0ac7aa06187',2001,'MX','Mexico','economy',938,'Economy - overview: Poland has steadfastly
pursued a policy of liberalizing the economy and today
stands out as one of the most successful and open
transition economies. GDP growth has been strong
and steady since 1992 - the best performance in the
region. The privatization of small and medium
state-owned companies and a liberal law on
establishing new firms has allowed for the rapid
development of a vibrant private sector. In contrast,
Poland''s large agricultural sector remains
handicapped by structural problems, surplus labor,
inefficient small farms, and lack of investment.
Restructuring and privatization of "sensitive sectors"
(e.g., coal, steel, railroads, and energy) has begun.
Structural reforms in health care, education, the
pension system, and state administration have
resulted in larger than expected fiscal pressures.
Further progress in public finance depends mainly on
privatization of Poland''s remaining state sector. The
government''s determination to enter the EU as soon
as possible affects most aspects of its economic
policies. Improving Poland''s outsized current account
deficit and reining in inflation are priorities. Warsaw
leads the region in foreign investment and needs a
continued large inflow.
408
Poland (continued)
GDP: purchasing power parity - $327.5 billion
(2000 est.)
GDP - real growth rate: 4.8% (2000 est.)
GDP - per capita: purchasing power parity - $8,500
(2000 est.)
GDP - composition by sector:
agriculture: 3.8%
industry: 36.6%
services: 59.6% (1999)
Population beiow poverty iine: 18.4% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 3%
highest 10%: 26.3% (1996)
Inflation rate (consumer prices): 10.2%
(2000 est.)
Labor force: 17.2 million (1999 est.)
Labor force - by occupation: industry 22.1%,
agriculture 27.5%, services 50.4% (1999)
Unemployment rate: 1 2% (1 999)
Budget:
revenues: $49.6 billion
expenditures: $52.3 billion, including capital
expenditures of $NA (1 999)
Industries: machine building, iron and steel, coal
mining, chemicals, shipbuilding, food processing,
glass, beverages, textiles
Industrial production growth rate: 4.3% (1999)
Electricity - production: 134.351 billion kWh (1999)
Electricity - production by source:
fossil fuel: 96.43%
hydro: 3.16%
nuclear: 0%
other: 0.41% (1999)
Electricity - consumption: 120.007 billion kWh
(1999)
Electricity - exports: 8.43 billion kWh (1999)
Electricity - imports: 3.491 billion kWh (1999)
Agriculture ■ products: potatoes, fruits, vegetables,
wheat; poultry, eggs, pork
Exports: $28.4 billion (f.o.b., 2000)
Exports - commodities: machinery and transport
equipment 30.2%, intermediate manufactured goods
25.5%, miscellaneous manufactured goods 20.9%,
food and live animals 8.5% (1999)
Exports - partners: Germany 36.1%, Italy 6.5%,
Netherlands 5.3%, France 4.8%, UK 4.0%, Czech
Republic 3.8% (1999)
Imports: $42.7 billion (f.o.b., 2000)
Imports - commodities: machinery and transport
equipment 38.2%, intermediate manufactured goods
20.8%, chemicals 14.3%, miscellaneous
manufactured goods 9.5% (1999)
Imports - partners: Germany 25.2%, Italy 9.4%,
France 6.8%, Russia 5.8%, UK 4.6%, Netherlands
3.7% (1999)
Debt -external: $57 billion (2000)
Economic aid - recipient: $NA
Currency: zloty (PLN)
Currency code: PLN
Exchange rates: zlotych per US dollar - 4.3126
(December 2000), 4.3461 (2000), 3.9671 (1999),
3.4754 (1998), 3.2793 (1997), 2.6961 (1996)
Fiscal year: calendar year','da51af41577010b94163bc972f2399333a2ce20f713c1732068ae98a1ca719c3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baa89f0b62cac18011774ae18e40657f594af55cc246260a4a7275e4fe6f60f6',2001,'QA','Qatar','economy',951,'Economy - overview: Oil accounts for more than
30% of GDP, roughly 80% of export earnings, and
66% of government revenues. Proved oil reserves of
3.7 billion barrels should ensure continued output at
current levels for 23 years. Oil has given Qatar a per
capita GDP comparable to that of the leading West
European industrial countries. Qatar''s proved
reserves of natural gas exceed 7 trillion cubic meters,
more than 5% of the world total, third largest in the
415
Qatar (continued)
world. Production and export of natural gas are
becoming increasingly important. Long-term goals
feature the development of offshore petroleum and
the diversification of the economy. In 2000, Qatar
posted its highest ever trade surplus of $6 billion, due
mainly to high oil prices and increased natural gas
exports.
GDP: purchasing power parity - $15.1 billion
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity -
$20,300 (2000 est.)
GDP “ composition by sector:
agriculture: 1%
industry: 49%
services: 50% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 2.5% (2000)
Labor force: 233,000 (1993 est.)
Unemployment rate: NA%
Budget:
revenues; $3.9 billion
expenditures: $4 billion, including capital
expenditures of $NA (1 999 est.)
Industries: crude oil production and refining,
fertilizers, petrochemicals, steel reinforcing bars,
cement
Industrial production growth rate: NA%
Electricity - production: 9 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 8.37 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: fruits, vegetables; poultry,
dairy products, beef; fish
Exports: $9.8 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum products 80%,
fertilizers, steel
Exports “ partners: Japan 52%, Singapore 9%,
South Korea 8%, US, UAE (1998)
Imports: $3.8 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment, food, chemicals
Imports - partners: UK 10%, Japan 8%, Germany
6%, US 6%, Italy 6% (1998)
Debt -external: $13.1 billion (2000 est.)
Economic aid - recipient: $NA
Currency: Qatari rial (QAR)
Currency code: QAR
Exchange rates: Qatari rials per US dollar - 3,6400
(fixed rate)
Fiscal year: 1 April - 31 March','97c13aa639c396f8d374e6f0396a4101e26f1c7e09614812485ca1db22c085f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c435b5339c3d0d2bbdeac314c58837c17659cabea67fa7329888a04a28ff576c',2001,'UA','Ukraine','economy',960,'Economy - overview: Romania, one of the poorest
countries in Central and Eastern Europe, began the
transition from communism in 1989 with a largely
obsolete industrial base and a pattern of output
unsuited to the country''s needs. Over the past decade
economic restructuring has lagged behind most other
countries in the region. Consequently, living
standards have continued to fall - real wages are
down over 40%. Corruption too has worsened. The
EU ranks Romania last among enlargement
candidates, and the European Bank for
Reconstruction and Development (EBRD) rates
Romania''s transition progress the region''s worst. The
country emerged in 2000 from a punishing three-year
recession thanks to strong demand in EU export
markets. A new government elected in November
2000 promises to promote economic reform.
Bucharest hopes to receive financial and technical
assistance from international financial institutions and
Western governments; negotiations over a new IMF
standby agreement are to begin early in 2001 . If
reform stalls, Romania''s ability to borrow from both
public and private sources could quickly dry up,
leading to another financial crisis.
GDP: purchasing power parity - $132.5 billion
(2000 est.)
GDP - real growth rate: 2.2% (2000 est.)
GDP ■ per capita: purchasing power parity - $5,900
(2000 est.)
GDP - composition by sector:
agriculture: 13.9%
industry: 32.6%
sen/ices: 53.5% (2000)
Population below poverty line: 44.5% (2000)
Household income or consumption by percentage
share:
lowest 10%: 3.8%
highest10%>: 20.2% (1992)
Inflation rate (consumer prices): 45.7%
(2000 est.)
Labor force: 9.9 million (1 999 est.)
Labor force - by occupation: agriculture 40%,
industry 25%, services 35% (1998)
Unemployment rate: 1 1 .5% (1 999)
Budget:
revenues; $11.7 billion
expencf/Yures; $12.4 billion, including capital
expenditures of $NA (1 999 est.)
Industries: textiles and footwear, light machinery
and auto assembly, mining, timber, construction
materials, metallurgy, chemicals, food processing,
petroleum refining
Industrial production growth rate: 8% (2000)
Electricity - production: 49.036 billion kWh (1999)
Electricity - production by source:
fossil fuel: 53.99%
hydro; 36. 18%
nuc/ear;9.81%
other; 0.02% (1999)
Electricity - consumption: 44.768 billion kWh
(1999)
Electricity - exports: 1 .935 billion kWh (1 999)
Electricity - imports: 1.1 billion kWh (1999)
Agriculture - products: wheat, corn, sugar beets,
sunflower seed, potatoes, grapes; eggs, sheep
Exports: $1 1 .2 billion (f.o.b., 2000 est.)
Exports - commodities: textiles and footwear 26%,
metals and metal products 15%, machinery and
equipment 11%, minerals and fuels 6% (1999)
Exports - partners: Italy 23%, Germany 18%,
France 6%, Turkey 5%, US (1999)
Imports: $1 1 .9 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment
23%, fuels and minerals 12%, chemicals 9%, textile
and products 19% (1999)
Imports ■ partners: Italy 20%, Germany 19%,
France 7%, Russia 6% (1999)
Debt - external: $9.3 billion (2000 est.)
Currency: leu(ROL)
Currency code: ROL
Exchange rates: lei per US dollar - 26,243.0
(January 2001), 21,708.7 (2000), 15,332.8 (1999),
8,875.6 (1998), 7,167.9 (1997), 3,084.2 (1996); note -
lei is the plural form of leu
Fiscal year: calendar year
Economy ■ overview: A decade after the implosion
of the Soviet Union in 1 991 , Russia is still struggling to
establish a modern market economy and achieve
strong economic growth. In contrast to its trading
partners in Central Europe - which were able to
overcome the initial production declines that
accompanied the launch of market reforms within
three to five years - Russia saw its economy contract
for five years, as the executive and legislature
dithered over the implementation of many of the basic
foundations of a market economy. Russia achieved a
slight recovery in 1 997, but the government''s stubborn
budget deficits and the country''s poor business
climate made it vulnerable when the global financial
crisis swept through in 1998. The crisis culminated in
the August depreciation of the ruble, a debt default by
the government, and a sharp deterioration in living
standards for most of the population. The economy
rebounded in 1999 and 2000, buoyed by the
competitive boost from the weak ruble and a surging
trade surplus fueled by rising world oil prices. This
recovery, along with a renewed government effort in
2000 to advance lagging structural reforms, have
raised business and investor confidence over
Russia''s prospects in its second decade of transition.
Yet serious problems persist. Russia remains heavily
dependent on exports of commodities, particularly oil,
natural gas, metals, and timber, which account for
over 80% of exports, leaving the country vulnerable to
swings in world prices. Russia''s agricultural sector
remains beset by uncertainty over land ownership
rights, which has discouraged needed investment and
restructuring. Another threat is negative demographic
trends, fueled by low birth rates and a deteriorating
health situation - including an alarming rise in AIDS
cases - that have contributed to a nearly 2% drop in
the population since 1992. Russia''s industrial base is
increasingly dilapidated and must be replaced or
modernized if the country is to achieve sustainable
economic growth. Other problems include widespread
corruption, capital flight, and brain drain.
GDP: purchasing power parity - $1.12 trillion
(2000 est.)
GDP ■ real growth rate: 6.3% (2000 est.)
GDP - per capita: purchasing power parity - $7,700
(2000 est.)
GDP - composition by sector:
agriculture: 7%
industry: 34%
services: 59% (1999 est.)
Population below poverty line: 40% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: M%
highest 38.7% (1998)
Inflation rate (consumer prices): 20.6%
(2000 est.)
Labor force: 66 million (1997)
Labor force - by occupation: agriculture 15%,
industry 30%, services 55% (1999 est.)
Unemployment rate: 10.5% (2000 est.), plus
considerable underemployment
Budget:
revenues: $40 billion
expenditures: ^33.7 billion, including capital
expenditures of $NA (2000 est.)
Industries: complete range of mining and extractive
industries producing coal, oil, gas, chemicals, and
metals; all forms of machine building from rolling mills
to high-performance aircraft and space vehicles;
shipbuilding; road and rail transportation equipment;
communications equipment; agricultural machinery,
tractors, and construction equipment; electric power
generating and transmitting equipment; medical and
scientific instruments; consumer durables, textiles,
foodstuffs, handicrafts
Industrial production growth rate: 8.8%
(2000 est.)
Electricity - production: 798.065 billion kWh (1 999)
Electricity - production by source:
foss/7 tee/; 66.31%
/?ycfro; 19.79%
nuclear: 13.9%
other: 0% (1999)
Electricity - consumption: 728.2 billion kWh (1 999)
Electricity - exports: 20 billion kWh (1999)
Electricity - Imports: 6 billion kWh (1999)
Agriculture - products: grain, sugar beets,
sunflower seed, vegetables, fruits; beef, milk
Exports: $105.1 billion (2000 est.)
Exports - commodities: petroleum and petroleum
products, natural gas, wood and wood products,
metals, chemicals, and a wide variety of civilian and
military manufactures
Exports - partners: US 8.8%, Germany 8.5%,
Ukraine 6.5%, Belarus 5.1%, Italy 5%, Netherlands
4.8% (1999)
Imports: $44.2 billion (2000 est.)
Imports - commodities: machinery and equipment,
consumer goods, medicines, meat, grain, sugar,
semifinished metal products
423
Russia (continued)
Imports - partners: Germany 13.8%, Belarus
10.7%, Ukraine 8.3%, US 7.9%, Kazakhstan 4.6%,
Italy 3.8% (1999)
Debt - external: $163 billion (2000 est.)
Economic aid - recipient: $8,523 billion (1995)
Currency: Russian ruble (RUR)
Currency code: RUR
Exchange rates: Russian rubles per US dollar -
28.3592 (January 2001), 28.1292 (2000), 24.6199
(1999), 9.7051 (1998), 5,785 (1997), 5,121 (1996)
note.'' the post-1 January 1998 ruble is equal to 1,000
of the pre-1 January 1998 rubles
Fiscal year: calendar year
Economy - overview: Rwanda is a rural country
with about 90% of the population engaged in (mainly
subsistence) agriculture. It is the most densely
populated country in Africa; is landlocked; and has few
natural resources and minimal industry. Primary
exports are coffee and tea. The 1994 genocide
decimated Rwanda''s fragile economic base, severely
impoverished the population, particularly women, and
eroded the country''s ability to attract private and
external investment. However, Rwanda has made
significant progress in stabilizing and rehabilitating its
economy. GDP has rebounded, and inflation has
been curbed. In June 1998, Rwanda signed an
Enhanced Structural Adjustment Facility (ESAF) with
the IMF. Rwanda has also embarked upon an
ambitious privatization program with the World Bank.
Continued growth in 2001 depends on the
maintenance of international aid levels and the
strengthening of world prices of coffee and tea.
GDP: purchasing power parity - $6.4 billion
(2000 est.)
GDP - real growth rate: 5.8% (2000 est.)
GDP - per capita: purchasing power parity - $900
(2000 est.)
GDP - composition by sector:
agriculture: 40%
industry: 20%
services: A0% (2000 est.)
Population below poverty line: 70% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: 42%
highest 10%: 242% (1983-85)
Inflation rate (consumer prices): 4% (2000)
Labor force: 3.6 million
Labor force - by occupation: agriculture 90%
Unemployment rate: NA%
Budget:
revenues; $198 million
expenditures: $41 1 million, including capital
expenditures of $NA (2000 est.)
Industries: cement, agricultural products,
small-scale beverages, soap, furniture, shoes, plastic
goods, textiles, cigarettes
Industrial production growth rate: 8.7%
(1998 est.)
Electricity - production: 1 32 million kWh (1 999)
Electricity - production by source:
fossil fuel: 3.03%
f?yflfro; 96.97%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 191.8 million kWh
(1999)
Electricity - exports: 1 million kWh (1999)
Electricity - imports: 70 million kWh (1999)
Agriculture ■ products: coffee, tea, pyrethrum
(insecticide made from chrysanthemums), bananas,
beans, sorghum, potatoes; livestock
Exports: $68.4 million (f.o.b., 2000 est.)
Exports - commodities: coffee, tea, hides, tin ore
Exports ■ partners: Germany, Belgium, Pakistan,
Italy, Kenya
Imports: $245.9 million (f.o.b., 2000 est.)
Imports - commodities: foodstuffs, machinery and
equipment, steel, petroleum products, cement and
construction material
Imports - partners: Kenya, Tanzania, US, Benelux,
France, India
Debt ■ external: $1.3 billion (1999)
Economic aid - recipient: $591.5 million (1997);
note - in summer 1998, Rwanda presented its policy
objectives and development priorities to donor
governments resulting in multiyear pledges in the
amount of $250 million
Currency: Rwandan franc (RWF)
Currency code: RWF
Exchange rates: Rwandan francs per US dollar -
432.24 (January 2001), 389.70 (2000), 333.94 (1999)
312.31 (1998), 301.53 (1997), 306.82 (1996)
Fiscal year: calendar year
Economy - overview: The economy depends
largely on financial assistance from the UK, which
amounted to about $5 million in 1997 or almost
one-half of annual budgetary revenues. The local
population earns income from fishing, the raising of
livestock, and sales of handicrafts. Because there are
few jobs, 25% of the work force has left to seek
employment on Ascension Island, on the Falklands,
and in the UK.
GDP; purchasing power parity ■ $18 million
(1998 est.)
GDP - real growth rate: NA%
GDP ■ per capita: purchasing power parity - $2,500
(1998 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 3.2% (1997 est.)
Labor force: 3,500 (1998 est.)
note: 1 ,200 of whom are working offshore
Labor force - by occupation: agriculture and
fishing 6%, industry (mainly construction) 48%,
services 46% (1987 est.)
Unemployment rate: 14% (1998 est.)
Budget:
revenues.'' $11.2 million
expenditures: million, including capital
expenditures of $NA (FY92)
Industries: construction, crafts (furniture, lacework,
fancy woodwork), fishing
Industrial production growth rate: NA%
Electricity - production: 6 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
of/?er; 0% (1999)
Electricity - consumption: 5.6 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: corn, potatoes, vegetables;
timber; fish, crawfish (on Tristan da Cunha)
Exports: $704,000 (f.o.b., 1995)
Exports - commodities: fish (frozen, canned, and
salt-dried skipjack, tuna), coffee, handicrafts
Exports ■ partners: South Africa, UK
Imports: $14,434 million (c.i.f., 1995)
Imports - commodities: food, beverages, tobacco,
fuel oils, animal feed, building materials, motor
vehicles and parts, machinery and parts
Imports - partners: UK, South Africa
Debt - external: $NA
Economic aid - recipient: $12.6 million (1995);
note - $5.3 million from UK (1997)
Currency: Saint Helenian pound (SHP)
Currency code: SHP
Exchange rates: Saint Helenian pounds per US
dollar - 0.6764 (January 2001), 0.6596 (2000), 0.6180
(1999), 0.6037 (1998), 0.6047 (1997), 0.6403 (1996);
note - the Saint Helenian pound is at par with the
British pound
Fiscal year: 1 April - 31 March','ee6765f3967d7322b98cd0ea7ecb65d7645419ff62bf79e5cf3e896aa9cfd72c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c5ea4a312039cfbe195f0fa5394bb3beccf1143801849121c5117e37e67e3b0',2001,'TT','Trinidad and Tobago','economy',969,'Economy - overview: The economy has
traditionally depended on the growing and processing
of sugarcane; decreasing world prices have hurt the
industry in recent years. Tourism, export-oriented
manufacturing, and offshore banking activity have
assumed larger roles. Most food is imported. The
government has undertaken a program designed to
revitalize the faltering sugar sector. It is also working
to improve revenue collection in order to better fund
social programs. In 1997 some leaders in Nevis were
urging separation from Saint Kitts on the basis that
Nevis was paying far more in taxes than it was
receiving in government services, but the vote on
cessation failed in August 1998. In late September
1 998, Hurricane Georges caused approximately $445
million in damages and limited GDP growth for the
year.
GDP: purchasing power parity - $274 million
(2000 est.)
GDP “ real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $7,000
(2000 est.)
GDP - composition by sector:
agriculture: 5.5%
industry: 22.5%
sen/ices: 72% (1996)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.5% (2000 est.)
Laborforce: 18,172 (June 1995)
Labor force -by occupation: NA
Unemployment rate: 4.5% (1997)
Budget:
revenues.'' $64.1 million
expenditures: $73.3 million, including capital
expenditures of $10.4 million (1997 est.)
Industries: sugar processing, tourism, cotton, salt,
copra, clothing, footwear, beverages
Industrial production growth rate: NA%
Electricity - production: 90 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(m9)
Electricity - consumption: 83.7 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: sugarcane, rice, yams,
vegetables, bananas; fish
Exports: $53.2 million (2000 est.)
Exports ■ commodities: machinery, food,
electronics, beverages, tobacco
Exports - partners: US 68.5%, UK 22.3%, Caricom
countries 5.5% (1995 est.)
Imports: $151.5 million (2000 est.)
Imports ■ commodities: machinery, manufactures,
food, fuels
Imports ■ partners: US 42.4%, Caricom countries
17.2%, UK 11.3% (1995 est.)
Debt -external: $115.1 million (1998)
Economic aid ■ recipient: $5.5 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Fiscal year: calendar year','3b7fb2cf20a3e28b1732cae209cf82f835da1cea6af4f3237b55a610718deaa7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08746dacd5031c7ddc7430f39d933a6693205da3389c11696d84ed6ba9d1d6e5',2001,'MQ','Martinique','economy',980,'Economy - overview: The inhabitants have
traditionally earned their livelihood by fishing and by
servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining,
however, because of disputes with Canada over
fishing quotas and a steady decline in the number of
ships stopping at Saint Pierre. In 1 992, an arbitration
panel awarded the islands an exclusive economic
zone of 12,348 sq km to settle a longstanding
territorial dispute with Canada, although it
represents only 25% of what France had sought. The
islands are heavily subsidized by France to the great
betterment of living standards. The government
hopes an expansion of tourism will boost economic
prospects.
GDP: purchasing power parity - $74 million
(1996 est.); supplemented by annual payments from
France of about $60 million
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$11,000 (1996 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.1% (1991-96
average)
Labor force: 3,000(1997)
Labor force - by occupation: fishing 18%, industry
(mainly fish-processing) 41%, services 41%
(1996 est.)
Unemployment rate: 9.8% (1997)
Budget:
revenues: $70 million
expenditures: $60 million, including capital
expenditures of $24 million (1996 est.)
Industries: fish processing and supply base for
fishing fleets; tourism
Industrial production growth rate: NA%
Electricity - production: 40 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
other: 0% (1990)
Electricity - consumption: 37.2 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: vegetables; poultry, cattle,
sheep, pigs; fish
Exports: $12 million (f.o.b., 1999)
Exports - commodities: fish and fish products,
soybeans, animal feed, mollusks and crustaceans, fox
and mink pelts
Exports - partners: US 43%, Egypt 14%, Japan
11%, Colombia 8% (1999)
Imports: $55 million (f.o.b., 1999)
Imports ■ commodities: meat, clothing, fuel,
electrical equipment, machinery, building materials
Imports - partners: France 44%, Canada 40%
(1999)
Debt -external: $NA
Economic aid - recipient: approximately $65
million in annual grants from France
Currency: French franc (FRF); euro (EUR)
Currency code: FRF; EUR
Exchange rates: euros per US dollar - 1 .06594
(January 2001), 1.08540 (2000), 0.93863 (1999);
French francs per US dollar - 5.8995 (1998), 5.8367
(1997), 5.1155 (1996)
Fiscal year: calendar year','37dc6c6a285cb5dad40bbf2ac3195750b1434a4540e3e32253d500d80c6378ec','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a449f1162dcc228728c40a31948ed2cbc46e8a9661b757b1ac8e8b7e551de549',2001,'SC','Seychelles','economy',993,'Economy - overview: Since independence in 1976,
per capita output in this Indian Ocean archipelago has
expanded to roughly seven times the old
near-subsistence level. Growth has been led by the
tourist sector, which employs about 30% of the labor
force and provides more than 70% of hard currency
earnings, and by tuna fishing. In recent years the
government has encouraged foreign investment in
order to upgrade hotels and other services. At the
same time, the government has moved to reduce the
dependence on tourism by promoting the
development of farming, fishing, and small-scale
manufacturing. The vulnerability of the tourist sector
was illustrated by the sharp drop in 1991-92 due
largely to the Gulf war. Although the industry has
rebounded, the government recognizes the continuing
need for upgrading the sector in the face of stiff
international competition. Other issues facing the
government are the curbing of the budget deficit and
further privatization of public enterprises. Growth
slowed in 1998-2000, due to sluggish tourist and tuna
sectors. Tight controls on exchange rates and the
scarcity of foreign exchange have hindered short-term
economic prospects. The black market value of the
Seychelles ruppee is half the official exchange rate;
without a devaluation of the currency the tourist sector
should remain sluggish as vacationers seek cheaper
destinations such as Comoros, Mauritius, and
Madagascar.
GDP: purchasing power parity - $61 0 million
(2000 est.)
GDP - real growth rate: 1 .5% (2000 est.)
GDP - per capita: purchasing power parity - $7,700
(2000 est.)
GDP - composition by sector:
agriculture: 3.^%
industry: 26.3%
services: 70.8% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
448
Seychelles (continued)
Inflation rate (consumer prices): 6% (1999 est.)
Labor force: 30,900(1996)
Labor force - by occupation: industry 19%,
services 71%, agriculture 10% (1989)
Unemployment rate: NA%
Budget:
revenues: $2A9 million
expenditures: P62 million, including capital
expenditures of $NA (1998 est.)
Industries: fishing; tourism; processing of coconuts
and vanilla, coir (coconut fiber) rope, boat building,
printing, furniture; beverages
Industrial production growth rate: NA%
Electricity - production: 160 million kWh (1999)
Electricity - production by source:
fossil fuel: ^00%
hydro: 0%
nuclear: 0%
other: 0% 0999)
Electricity - consumption: 148.8 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coconuts, cinnamon,
vanilla, sweet potatoes, cassava (tapioca), bananas;
broiler chickens; tuna fish
Exports: $111 million (f.o.b., 1999)
Exports - commodities: fish, cinnamon bark, copra,
petroleum products (reexports)
Exports ■ partners: France, UK, Netherlands, Italy,
China, Germany, Japan
Imports: $440 million (c.i.f., 1999)
Imports - commodities: machinery and equipment,
foodstuffs, petroleum products, chemicals
Imports ■ partners: South Africa, UK, China,
Singapore, France, Italy
Debt - external: $240 million (1999 est.)
Economic aid - recipient: $1 6.4 million (1 995)
Currency: Seychelles rupee (SCR)
Currency code: SCR
Exchange rates: Seychelles rupees per US dollar -
6.0397 (November 2000), 5.6009 (2000), 5,3426
(1999), 5.2622 (1998), 5.0263 (1997), 4.9700 (1996)
Fiscal year: calendar year','8dcc05196500d8f06e4bcabbcce971583636ea02f119d22c29a131f317284f85','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cad5b2f1e06d973b96066f38c0e1581cf207625e63951dc4638df0b6e0a87e5',2001,'SL','Sierra Leone','economy',1001,'Economy - overview: Sierra Leone is an extremely
poor African nation with tremendous inequality in
income distribution. It does have substantial mineral,
agricultural, and fishery resources. However, the
economic and social Infrastructure is not well
developed, and serious social disorders continue to
hamper economic development. About two-thirds of
the working-age population engages in subsistence
agriculture. Manufacturing consists mainly of the
processing of raw materials and of light manufacturing
for the domestic market. Bauxite and rutile mines have
been shut down by civil strife. The major source of
hard currency is found In the mining of diamonds, the
large majority of which are smuggled out of the
country. The resurgence of internal warfare in 1999
brought another substantial drop in GDP, with GNP
recovering part of the way in 2000. The fate of the
economy depends upon the maintenance of domestic
peace and the continued receipt of substantial aid
from abroad.
GDP: purchasing power parity - $2.7 billion
(2000 est.)
GDP - real growth rate: 4.2% (2000 est.)
GDP - per capita: purchasing power parity - $510
(2000 est.)
GDP - composition by sector:
agriculture: 43%
industry: 26%
se/v/ces;31%(1999)
Population below poverty line: 68% (1989 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.5%
highest 43.6% (1989)
inflation rate (consumer prices); 15% (2000 est.)
Labor force: 1.369 million (1981 est.)
note: only about 65,000 wage earners (1985)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: NA%
Budget;
revenues: $96 million
expenditures: $351 million, including capital
expenditures of $NA (2000 est.)
Industries; mining (diamonds); small-scale
manufacturing (beverages, textiles, cigarettes,
footwear); petroleum refining
Industrial production growth rate: NA%
Electricity - production; 240 million kWh (1999)
Electricity •* production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%{im)
Electricity - consumption: 223.2 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rice, coffee, cocoa, palm
kernels, palm oil, peanuts; poultry, cattle, sheep, pigs;
fish
Exports: $65 million (f.o.b., 2000 est.)
Exports - commodities: diamonds, rutile, cocoa,
coffee, fish
Exports ■ partners: Belgium 38%, US 6%, Italy 4%,
UK 4% (1999)
Imports: $145 million (f.o.b., 2000 est.)
Imports - commodities; foodstuffs, machinery and
equipment, fuels and lubricants, chemicals
Imports ■ partners: UK 34%, US 8%, Italy 7%,
Nigeria 5% (1999)
Debt - external: $1.28 billion (1999)
Economic aid - recipient: $203.7 million (1995)
Currency: leone (SLL)
Currency code: SLL
Exchange rates: leones per US dollar - 1 ,653.39
(January 2001), 2,092.13 (2000), 1 ,804.20 (1999),
1,563.62 (1998), 981.48 (1997), 920.73 (1996)
Fiscal year: calendar year','df427370b91d22e1e125008f2709db9c12227ca8a1c2645fc868d4325ba392cf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9b569d5ef1985d7dc11da5b69713336cd1e0cb425bbfcfca262fc2b786a95b7',2001,'HU','Hungary','economy',1009,'Economy - overview: Slovakia continues the
difficult transition from a centrally planned economy to
a modern market economy. The economic slowdown
in 1999 stemmed from large budget and current
account deficits, fast-growing external debt, and
persistent corruption. Even though GDP growth
reached only 2.2% in 2000, the year was marked by
positive developments such as foreign direct
investment of $1 .5 billion, strong export performance,
restructuring and privatization in the banking sector,
entry into the OECD, and initial efforts to stem
corruption. Strong challenges face the government in
2001 , especially the maintenance of fiscal balance,
the further privatization of the economy, and the
reduction of unemployment.
GDP: purchasing power parity - $55.3 billion
(2000 est.)
GDP - real growth rate: 2.2% (2000 est.)
GDP - per capita: purchasing power parity -
$10,200 (2000 est.)
GDP - composition by sector:
agriculture: 4.5%
industry: 29.3%
services: 66.2% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 5.1%
highest 10%: 18.2% {1992}
Inflation rate (consumer prices): 12.2%
(2000 est.)
Labor force: 3 million (1999)
455
Slovakia (continued)
Labor force - by occupation: industry 29.3%,
agriculture 8.9%, construction 8%, transport and
communication 8.2%, services 45.6% (1994)
Unemployment rate: 17% (2000 est.)
Budget:
revenues: $5.2 billion
expenditures: $5.6 billion, including capital
expenditures of $NA (1999)
Industries: metal and metal products; food and
beverages; electricity, gas, coke, oil, nuclear fuel;
chemicals and manmade fibers; machinery; paper
and printing; earthenware and ceramics; transport
vehicles; textiles; electrical and optical apparatus;
rubber products
Industrial production growth rate: 9.3%
(2000 est.)
Electricity - production: 22.582 billion kWh (1999)
Electricity - production by source:
fossil fuel: 37.56%
hydro: 18.27%
nuclear: 44.17%
other: 0%(1999)
Electricity - consumption: 21.471 billion kWh
(1999)
Electricity - exports: 930 million kWh (1 999)
Electricity - imports: 1 .4 billion kWh (1 999)
Agriculture - products: grains, potatoes, sugar
beets, hops, fruit; pigs, cattle, poultry; forest products
Exports: $12 billion (f.o.b., 2000 est.)
Exports - commodities: machinery and transport
equipment 39.4%, intermediate manufactured goods
27.5%, miscellaneous manufactured goods 13%,
chemicals 8% (1999)
Exports - partners: EU 59.7% (Germany 27.8%,
Austria 8%, Italy 8.9%), Czech Republic 18.1% (1999)
Imports: $12.8 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment 37.7%, intermediate manufactured goods
18%, fuels 13%, chemicals 11%, miscellaneous
manufactured goods 9.5% (1999)
Imports - partners: EU 51 .4% (Germany 26%, Italy
7.1%), Czech Republic 16.6%, Russia 11.9% (1999)
Debt - external: $10.3 billion (2000 est.)
Economic aid - recipient: $421.9 million (1995)
Currency: Slovak koruna (SKK)
Currency code: SKK
Exchange rates: koruny per US dollar - 48.09
(March 2001), 46.395 (2000), 41.363 (1999), 35.233
(1998), 33.616 (1997), 30.654 (1996)
Fiscal year: calendar year','361178c7fcfeda0f3a17e44ed3fd68a632ab2c685d982c64c0be28ae6c4f4e29','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c22e26bce2e4ad51010bd62acfa8d020939b99ff8b769ca4a66b40189b256d',2001,'SB','Solomon Islands','economy',1018,'Economy - overview: The bulk of the population
depends on agriculture, fishing, and forestry for at
least part of their livelihood. Most manufactured goods
and petroleum products must be imported. The
islands are rich in undeveloped mineral resources
such as lead, zinc, nickel, and gold. However, severe
ethnic violence, the closing of key business
enterprises, and an empty government treasury have
led to a continuing economic downslide. Deliveries of
crucial fuel supplies (including those for electrical
generation) by tankers have become sporadic due to
the government''s inability to pay and attacks against
ships. Telecommunications are threatened by the lack
of technical and maintenance staff many of whom
have left the country.
GDP: purchasing power parity - $900 million
(2000 est.)
GDP - real growth rate: 1% (2000 est.)
GDP " per capita: purchasing power parity - $2,000
(2000 est.)
GDP ■ composition by sector:
agriculture: 50%
industry: 3.5%
serv/ces; 46.5% (1995)
460
Solomon Islands (continued)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: m%
Inflation rate (consumer prices): 10% (1999 est.)
Labor force: 26,842
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: NA%
Budget:
revenues: $147 million
expenditures: million, including capital
expenditures of $NA (1997 est.)
Industries: fish (tuna), mining, timber
Industrial production growth rate: NA%
Electricity - production: 30 million kWh (1999)
Electricity ■ production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
ofoer; 0% (1999)
Electricity - consumption: 27.9 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cocoa, beans, coconuts,
palm kernels, rice, potatoes, vegetables, fruit; cattle,
pigs; timber; fish
Exports: $165 million (f.o.b., 1999 est.)
Exports - commodities: timber, fish, palm oil,
cocoa, copra
Exports - partners: Japan 35.5%, other Asian
countries 47.3% (1999)
Imports: $152 million (f.o.b., 1999 est.)
Imports - commodities: plant and equipment,
manufactured goods, food and live animals, fuels,
chemicals
Imports - partners: Australia 38.5%, Singapore
15%, Japan 10.6%, NZ 6.2% (1999)
Debt - external: $1 52.4 million (1 998)
Economic aid - recipient: $47 million (1 999 est.),
mainly from Japan, Australia, China, and NZ
Currency: Solomon Islands dollar (SBD)
Currency code: SBD
Exchange rates: Solomon Islands dollars per US
dollar - 5.0968 (November 2000), 5.0864 (2000),
4.8381 (1999), 4.8156 (1998), 3.7169 (1997), 3.5664
(1996)
Fiscal year: calendar year','1e39f28108669b2d2dde98c77a6ba31aa3e1d8496392cf1f1abf33cd7b91293e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('093c97310d03043f855aa6dcd44122efabe191a83dd3f43672d3b985966ed443',2001,'SO','Somalia','economy',1026,'Economy - overview: One of the world''s poorest
and least developed countries, Somalia has few
resources. Moreover, much of the economy has been
devastated by the civil war. Agriculture is the most
important sector, with livestock accounting for about
40% of GDP and about 65% of export earnings.
Nomads and semi-nomads, who are dependent upon
livestock for their livelihood, make up a large portion of
462
Somalia (continued)
the population. Livestock and bananas are the
principal exports; sugar, sorghum, corn, fish, and qat
are products for the domestic market. The small
industrial sector, based on the processing of
agricultural products, accounts for 10% of GDP; most
facilities have been shut down because of the civil
strife. Moreover, ongoing civil disturbances in
Mogadishu and outlying areas have interfered with
any substantial economic advance and with
International aid arrangements. Due to the civil strife,
economic data is susceptible to an exceptionally wide
margin of error.
GDP: purchasing power parity - $4.3 billion
(2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $600
(2000 est.)
GDP - composition by sector:
agriculture: 60%
industry: 10% (largely shut down in 2000)
services: 30% (2000 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
/owesM0%.-NA%
highest 10%: NA%
Inflation rate (consumer prices): over 100%
(businesses print their own money) (2000 est.)
Labor force; 3.7 million (very few are skilled
laborers) (1993 est.)
Labor force - by occupation: agriculture (mostly
pastoral nomadism) 71%, industry and services 29%
Unemployment rate: NA%
Budget;
revenues: $NA
expenditures: including capita! expenditures of
$NA
Industries: a few small industries, including sugar
refining, textiles, petroleum refining (mostly shut
down), wireless communication
Industrial production growth rate; NA%
Electricity ■ production: 260 million kWh (1999)
Electricity - production by source:
fossi! fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(m9)
Electricity - consumption: 241 .8 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cattle, sheep, goats;
bananas, sorghum, corn, sugarcane, mangoes,
sesame seeds, beans; fish
Exports: $186 million (f.o.b., 1999 est.)
Exports - commodities: livestock, bananas, hides,
fish (1999)
Exports - partners: Saudi Arabia 53%, Yemen 1 9%,
UAE 14%, Italy 5%, Pakistan 2% (1999)
Imports: $314 million (f.o.b., 1999 est.)
Imports - commodities: manufactures, petroleum
products, foodstuffs, construction materials (1995)
Imports - partners: Djibouti 24%, Kenya 1 4%, Brazil
13%, Saudi Arabia 10%, India 9% (1999)
Debt - external: $2.6 billion (1999 est.)
Economic aid - recipient: $191.5 million (1995)
Currency: Somali shilling (SOS)
Currency code: SOS
Exchange rates: Somali shillings per US dollar -
11,000 (November 2000), 2,620 (January 1999),
7,500 (November 1997 est.), 7,000 (January
1996 est.), 5,000 (1 January 1995), 2,616 (1 July
1993)
note.- the Republic of Somaliland, a self-declared
independent country not recognized by any foreign
government, issues its own currency, the Somaliland
shilling
Fiscal year: NA','d2c8664e576790a9cc61688bab2b5137c0de1ef7159508d68d6a8a3a99e886a9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('344be45dd7f11ec9b6253e998f9bd9e7ff57fde1423bd9f4176cde0a4e36108c',2001,'ES','Spain','economy',1037,'Economy - overview: Spain''s mixed capitalist
economy supports a GDP that on a per capita basis is
80% that of the four leading West European
economies. Its center-right government successfully
worked to gain admission to the first group of
countries launching the European single currency on
1 January 1999. The AZNAR administration has
continued to advocate liberalization, privatization, and
deregulation of the economy and has introduced
some tax reforms to that end. Unemployment has
been steadily falling under the AZNAR administration
but remains the highest in the EU at 14%. The
government intends to make further progress in
changing labor laws and reforming pension schemes,
which are key to the sustainability of both Spain''s
internal economic advances and its competitiveness
in a single currency area. Adjusting to the monetary
and other economic policies of an integrated Europe -
and further reducing unemployment - will pose
challenges to Spain in the next few years.
GDP: purchasing power parity - $720.8 billion
(2000 est.)
GDP - real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity -
$18,000 (2000 est.)
GDP “ composition by sector:
agriculture: 4%
industry: 31%
services: 65% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.6%
highest m; 25.2% (1990)
Inflation rate (consumer prices): 3.4% (2000 est.)
Labor force: 17 million (2000)
Labor force ■ by occupation: services 64%,
manufacturing, mining, and construction 28%,
agriculture 8% (1997 est.)
Unemployment rate: 14% (2000 est.)
Budget:
revenues; $105 billion
expenditures: $109 billion, including capital
expenditures of $12.8 billion (2000 est.)
Industries: textiles and apparel (including footwear),
food and beverages, metals and metal manufactures,
chemicals, shipbuilding, automobiles, machine tools,
tourism
Industrial production growth rate: 4.5%
(2000 est.)
Electricity - production: 1 97.694 billion kWh (1 999)
Electricity - production by source:
foss/7 fue/; 57.71%
hydro: 12.1%
nuclear: 28.28%
of/?er; 1.91% (1999)
Electricity - consumption: 189.57 billion kWh
(1999)
Electricity - exports: 6.23 billion kWh (1999)
Electricity - Imports: 1 1 .945 billion kWh (1 999)
Agriculture - products: grain, vegetables, olives,
wine grapes, sugar beets, citrus; beef, pork, poultry,
dairy products; fish
Exports: $120.5 billion (f.o.b., 2000 est.)
Exports - commodities: machinery, motorvehicles;
foodstuffs, other consumer goods
Exports - partners: EU 71% (France 20%,
Germany 12%, Italy 9%, Portugal 9%, UK 8%), Latin
America 6%, US 5% (2000)
Imports: $153.9 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
fuels, chemicals, semifinished goods; foodstuffs,
consumer goods (1997)
Imports - partners: EU 68% (France 1 8%, Germany
16%, Italy 9%, UK 7%, Benelux 8%), US 8%, OPEC
5%, Latin America 4%, Japan 3% (1999)
Debt - external: $90 billion (1993 est.)
Economic aid - donor: ODA, $1 .3 billion (1995)
Currency: Spanish peseta (ESP); euro (EUR)
note: on 1 January 1999, the EU introduced the euro
as a common currency that is now being used by
financial institutions in Spain at a fixed rate of 1 66.386
Spanish pesetas per euro and will replace the local
currency for all transactions in 2002
Currency code: ESP; EUR
Exchange rates: euros per US dollar - 1 .0659
(January 2001), 1.0854 (2000), 0.9386 (1999);
pesetas per US dollar - 149.40 (1998), 146.41 (1997),
126.66 (1996)
Fiscal year: calendar year','c69be4585c5a24928fcfbdd0e0296bdd12ebe99d30672306673098b27ec2b70d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc8fd785909c7debca0e0ffce4ecc1acd79e9e1672489cc3243e378e473d6eb1',2001,'LK','Sri Lanka','economy',1045,'Economy - overview: In 1977, Colombo
abandoned statist economic policies and its import
substitution trade policy for market-oriented policies
and export-oriented trade. Sri Lanka''s most dynamic
sectors now are food processing, textiles and apparel,
food and beverages, telecommunications, and
insurance and banking. By 1996 plantation crops
made up only 20% of exports (compared with 93% in
1970), while textiles and garments accounted for
63%. GDP grew at an annual average rate of 5.5%
throughout the 1990s until a drought and a
deteriorating security situation lowered growth to
3.8% in 1996. The economy rebounded in 1997-98
with growth of 6.4% and 4.7% - but slowed to 4.3% in
1999. Growth increased to 5.6% in 2000, with growth
in tourism and exports leading the way. But a
resurgence of civil war between the Sinhalese and the
minority Tamils and a possible slowdown in tourism
dampen prospects for 2001 . For the next round of
reforms, the central bank of Sri Lanka recommends
that Colombo expand market mechanisms in
nonplantation agriculture, dismantle the government''s
monopoly on wheat imports, and promote more
competition in the financial sector.
GDP: purchasing power parity - $62.7 billion
(2000 est.)
GDP - real growth rate: 5.6% (2000 est.)
GDP - per capita: purchasing power parity - $3,250
(2000 est.)
GDP - composition by sector:
agriculture: 2^%
industry: 19%
services: 60% (1998)
Population below poverty line: 22% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%: 1.8%
highest 10%: 39.7% (1995-96 est.)
Inflation rate (consumer prices): 8.5% (2000 est.)
Labor force: 6.6 million (1998)
Labor force - by occupation: services 45%,
agriculture 38%, industry 17% (1998 est.)
Unemployment rate: 8.8% (1999 est.)
Budget;
revenues: $3 billion
expenditures: $3 billion, including capital
expenditures of $NA (2000 est.)
Industries: processing of rubber, tea, coconuts, and
other agricultural commodities; clothing, cement,
petroleum refining, textiles, tobacco
Industrial production growth rate; 4% (1999)
Electricity - production: 6.026 billion kWh (1999)
Electricity - production by source:
fossil fuel: 29.9%
hydro: 70.1%
nuclear: 0%
other: 0%(1999)
Electricity - consumption: 5.604 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rice, sugarcane, grains,
pulses, oilseed, spices, tea, rubber, coconuts; milk,
eggs, hides, beef
Exports: $5.2 billion (f.o.b., 2000)
Exports - commodities: textiles and apparel, tea,
diamonds, coconut products, petroleum products
Exports - partners: US 39%, UK 13%, Middle East
8%, Germany 5%, Japan 4% (1999)
Imports: $6.1 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment,
textiles, petroleum, foodstuffs
Imports - partners: Japan 10%, India 9%, Hong
Kong 8%, Singapore 8%, South Korea 6% (1999)
Debt - external: $9.9 billion (2000)
Economic aid - recipient: $577 million (1998)
Currency: Sri Lankan rupee (LKR)
Currency code: LKR
Exchange rates: Sri Lankan rupees per US dollar -
83.506 (January 2001), 77.005 (2000), 70.635 (1999),
64.450 (1998), 58.995 (1997), 55.271 (1996)
Fiscal year: calendar year','01dd07e11d1b3f56b856229778948117e89bb62e7d5ebf57a7b636abcb067352','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('763980d44a4125de67f8c3e961feb265707ad65528e2336a0a68af886f2797fb',2001,'SD','Sudan','economy',1054,'Economy - overview: Sudan is buffeted by civil war,
chronic instability, adverse weather, weak world
agricultural prices, a drop in remittances from abroad,
and counterproductive economic policies. The private
sector''s main areas of activity are agriculture (which
employs 80% of the work force), trading, and light
industry which is mostly processing of agricultural
goods. Most of the 1990s were characterized by
sluggish economic growth as the IMF suspended
lending, declared Sudan a non-cooperative state, and
threatened to expel Sudan from the IMF. Starting in
1997, Sudan began implementing IMF
macroeconomic reforms which have successfully
stabilized inflation at 10% or less. Sudan continues to
have limited international credit resources as over
75% of Sudan''s debt of $24.9 billion is in arrears and
Khartoum''s continued prosecution of the civil war
works to isolate Sudan. In 1999, Sudan began
exporting oil and in 1999-2000 had recorded its first
trade surpluses. Current oil production stands at
185,000 barrels per day, of which about 70% is
exported and the rest refined for domestic
consumption. Despite its many infrastructure
problems, Sudan''s increased oil production, the return
of regular rainfall, and recent investments in irrigation
schemes should allow the country to achieve
economic growth of 6% in 2001 .
475
Sudan (continued)
GDP; purchasing power parity - $357 billion
(2000 est.)
GDP - real growth rate: 7% (2000 est.)
GDP ■ per capita: purchasing power parity - $1 ,000
(2000 est.)
GDP - composition by sector:
agriculture: 39%
industry: 17%
services: A4% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 10% (2000 est.)
Labor force: 11 million (1996 est.)
Labor force - by occupation: agriculture 80%,
industry and commerce 10%, government 6%,
unemployed 4% (1996 est.)
Unemployment rate: 4% (1996 est.)
Budget:
revenues; $1.2 billion
expenditures: $1 .3 billion, including capital
expenditures of $NA (2000 est.)
Industries: cotton ginning, textiles, cement, edible
oils, sugar, soap distilling, shoes, petroleum refining,
pharmaceuticals, armaments
Industrial production growth rate: 5% (1996 est.)
Electricity ■ production: 1.76 billion kWh (1999)
Electricity - production by source:
fossil fuel: 42.05%
hydro: 57.95%
nuclear: 0%
of/ier; 0% (1999)
Electricity - consumption: 1 .637 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cotton, groundnuts
(peanuts), sorghum, millet, wheat, gum arable,
sugarcane, cassara, mangos, papaya, bananas,
sweet potatoes, sesame; sheep, livestock
Exports: $1.7 billion (f.o.b., 2000 est.)
Exports - commodities: oil and petroleum products,
cotton, sesame, livestock, groundnuts, gum arable,
sugar
Exports - partners: Saudi Arabia 16%, Italy 10%,
Germany 5%, France 3%, Thailand 3% (1999)
Imports: $1 .2 billion (f.o.b., 2000 est.)
Imports - commodities: foodstuffs, manufactured
goods, machinery and transport equipment,
medicines and chemicals, textiles
Imports - partners: China 14.7%, Libya 14.7%,
Saudi Arabia 8.9%, UK 8.7%, France 6.7% (1999)
Debt - external: $24.9 billion (2000 est.)
Economic aid - recipient: $187 million (1997)
Currency: Sudanese dinar (SDD)
Currency code: SDD
Exchange rates: Sudanese dinars per US dollar -
257.44 (January 2001), 257.12 (2000), 252.55 (1 999),
200.80 (1998), 157.57 (1997), 125.08 (1996)
Fiscal year: calendar year','bf77d4611090b635384d2e250db3bf46d001915d9713523b37cbafb9217d3d96','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aeb4d2b8e326343929c71dee2a381193437f6d33f48f081bbce67f3c8f07208',2001,'PK','Pakistan','economy',1069,'Economy - overview: Tajikistan has the lowest per
capita GDP among the 15 former Soviet republics.
Cotton is the most important crop. Mineral resources,
varied but limited in amount, include silver, gold,
uranium, and tungsten. Industry consists only of a
large aluminum plant, hydropower facilities, and small
obsolete factories mostly in light industry and food
processing. The Tajikistan! economy has been
gravely weakened by six years of civil conflict and by
the loss of subsidies from Moscow and of markets for
its products. Most of its people live in abject poverty.
Tajikistan depends on aid from Russia and
Uzbekistan and on international humanitarian
assistance for much of its basic subsistence needs.
The future of Tajikistan''s economy and the potential
for attracting foreign investment depend upon stability
and continued progress in the peace process.
GDP: purchasing power parity - $7.3 billion
(2000 est.)
GDP - real growth rate: 5.1% (2000 est.)
GDP - per capita: purchasing power parity - $1,140
(2000 est.)
GDP - composition by sector:
agriculture: 1 9.8%
industry: ^S^%
services: 62A% (1998)
Population below poverty line: 80% (2000 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 33% (2000 est.)
Labor force: 1 .9 million (1 996)
Labor force ■ by occupation: agriculture 50%,
industry 20%, services 30% (1997 est.)
Unemployment rate: 5.7% includes only officially
registered unemployed; also large numbers of
underemployed workers and unregistered
unemployed people (December 1 998)
Budget:
revenues.'' $146 million
expenditures: $196 million, including capital
expenditures of $NA (2000 est.)
Industries: aluminum, zinc, lead, chemicals and
fertilizers, cement, vegetable oil, metal-cutting
machine tools, refrigerators and freezers
Industrial production growth rate: 10%
(2000 est.)
Electricity - production: 15.623 billion kWh (1999)
Electricity - production by source:
fossil fuel: 1 .9%
hydro; 98.1%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 14.729 billion kWh
(1999)
492
Tajikistan (continued)
Electricity - exports: 3.9 billion kWh (1 999)
Electricity - Imports: 4.1 billion kWh (1999)
Agriculture - products: cotton, grain, fruits, grapes,
vegetables; cattle, sheep, goats
Exports: $761 million (f.o.b., 2000 est.)
Exports ■ commodities: aluminum, electricity,
cotton, fruits, vegetable oil, textiles
Exports - partners: Liechtenstein 26%, Uzbekistan
20%, Russia 8% (1998)
Imports: $782 million (f.o.b., 2000 est.)
Imports - commodities: electricity, petroleum
products, aluminum oxide, machinery and equipment,
foodstuffs
Imports - partners: Europe 32.3%, Uzbekistan
29%, Russia 13.6% (1998)
Debt - external: $1 .3 billion (1 999 est.)
Economic aid - recipient: $64.7 million (1995)
Currency: somoni
Currency code: SM
Exchange rates: Tajikistan! somoni per US dollar -
2.2 (January 2001), 1550 (January 2000), 998
(January 1999), 350 (January 1997), 284 (January
1996)
note; the new unit of exchange was introduced on
30 October 2000, with one somoni equal to 1 ,000 of
the old Tajikistan! rubles
Fiscal year: calendar year
Economy - overview: Tanzania is one of the
poorest countries in the world. The economy is heavily
dependent on agriculture, which accounts for half of
GDP, provides 85% of exports, and employs 80% of
the work force. Topography and climatic conditions,
however, limit cultivated crops to only 4% of the land
area. Industry is mainly limited to processing
agricultural products and light consumer goods. The
World Bank, the International Monetary Fund, and
bilateral donors have provided funds to rehabilitate
Tanzania''s deteriorated economic infrastructure.
Growth in 1991-2000 featured a pick up in industrial
production and a substantial increase in output of
minerals, led by gold. Natural gas exploration in the
Rufiji Delta looks promising and production could start
by 2002. Recent banking reforms have helped
increase private sector growth and investment.
Continued donor support and solid macroeconomic
policies should allow Tanzania to achieve real GDP
growth of 6% in 2001 and in 2002.
GDP: purchasing power parity - $25.1 billion
(2000 est.)
GDP ■ real growth rate: 5.2% (2000 est.)
GDP - per capita: purchasing power parity - $710
(2000 est.)
GDP ■ composition by sector:
agriculture: 49%
industry: 17%
services: 34% (1998 est.)
Population below poverty line: 51.1% (1991 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.9%
highest 30.2% (1993)
Inflation rate (consumer prices): 6% (2000 est.)
Labor force: 1 3.495 million
Labor force - by occupation: agriculture 80%,
industry and commerce 20% (2000 est.)
Unemployment rate: NA%
Budget:
revenues; $1.21 billion
expenditures: $1.30 billion, including capital
expenditures of $NA (1999 est.)
Industries: primarily agricultural processing (sugar,
beer, cigarettes, sisal twine), diamond and gold
mining, oil refining, shoes, cement, textiles, wood
products, fertilizer, salt
Industrial production growth rate: 8.4%
(1999 est.)
Electricity - production: 2.248 billion kWh (1999)
Electricity - production by source:
fossil fuel: 22.24%
hydro: 77. 76%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 2,134 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity ■ imports: 43 million kWh (1999)
Agriculture - products: coffee, sisal, tea, cotton,
pyrethrum (insecticide made from chrysanthemums),
cashew nuts, tobacco, cloves (Zanzibar), corn, wheat,
cassava (tapioca), bananas, fruits, vegetables; cattle,
sheep, goats
Exports: $937 million (f.o.b., 2000 est.)
Exports - commodities: coffee, manufactured
goods, cotton, cashew nuts, minerals, tobacco, sisal
(1996)
Exports - partners: India 20%, UK 10%, Germany
8%, Japan 8%, Netherlands 8%, Belgium 4% (1998)
Imports: $1.57 billion (f.o.b., 2000 est.)
Imports “ commodities: consumer goods,
machinery and transportation equipment, industrial
raw materials, crude oil
Imports - partners: South Africa 8%, Japan 8%, UK
8%, Kenya 7%, India 6%, US 5% (1998)
Debt - external: $6.8 billion (2000 est.)
Economic aid ■ recipient: $963 million (1997)
Currency: Tanzanian shilling (TZS)
Currency code: TZS
Exchange rates: Tanzanian shillings per US dollar -
803.34 (December 2000), 800.41 (2000), 744.76
(1999), 664.67 (1998), 612.12 (1997), 579.98 (1996)
Fiscal year: 1 July - 30 June','4edaaaae49e858156e83253a5aa1bc67ab6f2c6d50b897dcaec977315697d72b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23ccba0ca69bd661a29237bbc446e785a8477f3cb120d2a2848d5917e29b1284',2001,'TV','Tuvalu','economy',1083,'Economy - overview: Tuvalu consists of a densely
populated, scattered group of nine coral atolls with
poor soil. The country has no known mineral
resources and few exports. Subsistence farming and
fishing are the primary economic activities.
Government revenues largely come from the sale of
stamps and coins and worker remittances. About
1 ,000 Tuvaluans work in Nauru in the phosphate
mining industry. Nauru has begun repatriating
Tuvaluans, however, as phosphate resources decline.
Substantial income is received annually from an
international trust fund established in 1987 by
Australia, NZ, and the UK and supported also by
Japan and South Korea. Thanks to wise investments
and conservative withdrawals, this Fund has grown
from an initial $17 million to over $35 million in 1999.
The US government is also a major revenue source
forTuvalu, with 1999 payments from a 1988 treaty on
fisheries at about $9 million, a total which is expected
to rise annually. In an effort to reduce its dependence
on foreign aid, the government is pursuing public
sector reforms, including privatization of some
government functions and personnel cuts of up to 7%.
In 1998, Tuvalu began deriving revenue from use of its
area code for ”900" lines and in 2000, from the sale of
its ".tv" Internet domain name. Royalties from these
new technology sources could raise GDP three or
more times over the next decade. In 1999, with
merchandise exports falling and finance reaching less
than 5% of imports, continued reliance was placed on
fishing and telecommunications license fees,
remittances from overseas workers, official transfers,
and investment income from overseas assets to cover
the trade deficit.
GDP: purchasing power parity - $1 1 .6 million
(1999 est.)
GDP - real growth rate: 3% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,100
(1999 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
sen/ices: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%>: NA%
Infiation rate (consumer prices): 7% (1999 est.)
Labor force: NA
Labor force - by occupation: people make a living
mainly through exploitation of the sea, reefs, and
atolls and from wages sent home by those working
abroad (mostly workers in the phosphate industry and
sailors)
Unemployment rate: NA%
Budget:
revenues; $6.2 million
expenditures: A million, including capital
expenditures of $NA (1 998 est.)
Industries: fishing, tourism, copra
Industrial production growth rate: NA%
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Agriculture - products: coconuts; fish
Exports: $165,000 (f.o.b., 1989)
Exports ■ commodities: copra
Exports - partners: Fiji, Australia, NZ
Imports: $4.4 million (c.i.f., 1989)
Imports - commodities: food, animals, mineral
fuels, machinery, manufactured goods
Imports - partners: Fiji, Australia, NZ
Debt -external: $NA
Economic aid - recipient: $13 million (1999 est.);
note - major donors are Japan and Australia
Currency: Australian dollar (AUD); note - there is
also a Tuvaluan dollar
Currency code: AUD
Exchange rates: Tuvaluan dollars or Australian
dollars per US dollar - 1 .7995 (January 2001 ), 1 .71 73
(2000), 1 .5497 (1 999), 1 .5888 (1 998), 1 .3439 (1 997),
1.2773 (1996)
Fiscal year: calendar year
Economy - overview: Uganda has substantial
natural resources, including fertile soils, regular
rainfall, and sizable mineral deposits of copper and
cobalt. Agriculture is the most important sector of the
economy, employing over 80% of the work force.
Coffee is the major export crop and accounts for the
bulk of export revenues. Since 1986, the
government - with the support of foreign countries and
International agencies - has acted to rehabilitate and
stabilize the economy by undertaking currency
reform, raising producer prices on export crops,
increasing prices of petroleum products, and
improving civil service wages. The policy changes are
especially aimed at dampening inflation and boosting
production and export earnings. In 1990-2000, the
economy turned in a solid performance based on
continued investment in the rehabilitation of
infrastructure. Improved incentives for production and
exports, reduced inflation, gradually improved
domestic security, and the return of exiled
Indian-Ugandan entrepreneurs. Ongoing Ugandan
involvement in the war in the Democratic Republic of
the Congo, corruption within the government, and
slippage in the government’s determination to press
reforms raise doubts about the continuation of strong
growth. In 2000, Uganda qualified for enhanced HIPC
debt relief worth $1.3 billion and Paris Club debt relief
worth $1 45 million. These amounts combined with the
original Highly Indebted Poor Countries HIPC debt
relief add up to about $2 billion. Growth for 2001
should be somewhat lower than in 2000, because of a
decline in the price of coffee, Uganda''s principal
export.
GDP: purchasing power parity - $26.2 billion
(2000 est.)
GDP -real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity - $1,100
(2000 est.)
GDP - composition by sector:
agriculture: 43%
industry: 17%
senrices: 40% (1998 est.)
Popuiation below poverty line: 55% (1993 est.)
Household income or consumption by percentage
share:
lowest 10%: 3%
highest 10%: 33 A% (1992)
Inflation rate (consumer prices): 6.5% (2000)
Labor force: 8.361 million (1993 est.)
Labor force - by occupation; agriculture 82%,
industry 5%, services 13% (1999 est.)
Unemployment rate: NA%
Budget;
revenues; $959 million
expenditures: $1.04 billion, including capital
expenditures of $NA (FY98/99 est.)
Industries: sugar, brewing, tobacco, cotton textiles,
cement
Industrial production growth rate: 7% (1999)
Electricity - production: 1 .326 billion kWh (1999)
Electricity - production by source:
fossil fuel: 0.98%
hydro; 99.02%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 1.06 billion kWh (1999)
Electricity - exports: 174 million kWh (1999)
Electricity - imports: 1 million kWh (1999)
Agriculture - products; coffee, tea, cotton, tobacco,
cassava (tapioca), potatoes, corn, millet, pulses; beef,
goat meat, milk, poultry
Exports: $500.1 million (f.o.b., 1999)
Exports ■ commodities: coffee, fish and fish
products, tea; electrical products. Iron and steel
Exports - partners: Spain, Germany, Belgium,
Netherlands, Hungary, Kenya (1999)
Imports: $1.1 billion (f.o.b., 1999)
Imports - commodities: vehicles, petroleum,
medical supplies; cereals
Imports - partners: Kenya 27.5%, US 21 .2%,
France 19.3, UK 5%, India 4% (1999)
Debt ■ external: $3.6 billion (2000 est.)
Economic aid - recipient: $1.4 billion (2000)
Currency; Ugandan shilling (UGX)
Currency code: UGX
Exchange rates: Ugandan shillings per US dollar -
1 ,700 (February 2001 ), 1 ,830.4 (January 2001 ),
1,644.5 (2000), 1,454.8 (1999), 1,240.2 (1998),
1,083.0 (1997), 1,046.1 (1996)
Fiscal year: 1 July - 30 June
Economy - overview: After Russia, the Ukrainian
republic was far and away the most important
economic component of the former Soviet Union,
producing about four times the output of the
next-ranking republic. Its fertile black soil generated
more than one-fourth of Soviet agricultural output, and
its farms provided substantial quantities of meat, milk,
grain, and vegetables to other republics. Likewise, its
diversified heavy industry supplied the unique
equipment (for example, large diameter pipes) and
raw materials to industrial and mining sites (vertical
drilling apparatus) in other regions of the former
USSR. Ukraine depends on imports of energy,
especially natural gas, to meet some 85% of Its annual
energy requirements. Shortly after independence in
late 1991, the Ukrainian Government liberalized most
prices and erected a legal framework for privatization,
but widespread resistance to reform within the
government and the legislature soon stalled reform
efforts and led to some backtracking. Output in
1992-99 fell to less than 40% the 1991 level. Loose
monetary policies pushed inflation to hyperinflationary
levels in late 1993. Ukraine''s dependence on Russia
for energy supplies and the lack of significant
structural reform have made the Ukrainian economy
vulnerable to external shocks. Now in his second
term, President KUCHMA has pledged to reduce the
number of government agencies and streamline the
regulation process, create a legal environment to
encourage entrepreneurs and protect ownership
rights, and enact a comprehensive tax overhaul.
Reforms in the more politically sensitive areas of
structural reform and land privatization are still
lagging. Outside institutions ■ particularly the IMF -
have encouraged Ukraine to quicken the pace and
scope of reforms and have threatened to withdraw
financial support. GDP in 2000 showed strong
export-based growth of 6% - the first growth since
independence - and industrial production grew 1 2.9%.
As the capacity for further export-based economic
expansion diminishes, GDP growth in 2001 is likely to
decline to around 3%.
GDP: purchasing power parity - $1 89.4 billion
(2000 est.)
GDP - real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity - $3,850
(2000 est.)
GDP ■ composition by sector:
agriculture: 12%
industry: 26%
services: 62% (1998 est.)
Population below poverty line: 50% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.9%
highest r0%; 26.4% (1996)
Inflation rate (consumer prices): 25.8%
(2000 est.)
Labor force: 22.8 million (yearend 1997)
Labor force - by occupation: industry 32%,
agriculture 24%, services 44% (1996)
Unemployment rate: 4.3% officially registered;
large number of unregistered or underemployed
workers (December 1999)
Budget;
revenues; $8.3 billion
expenditures: $8.8 billion, including capital
expenditures of $NA (1999 est.)
Industries: coal, electric power, ferrous and
nonferrous metals, machinery and transport
equipment, chemicals, food processing (especially
sugar)
Industrial production growth rate: 12.9%
(2000 est.)
Electricity - production: 157.823 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 47.67%
hydro; 9.65%
nuclear: 42.67%
ofoer; 0.01% (1999)
Electricity - consumption: 146.675 billion kWh
(1999)
Electricity - exports: 2.3 billion kWh (1999)
Electricity - Imports: 2.2 billion kWh (1999)
Agriculture - products: grain, sugar beets,
sunflower seeds, vegetables; beef, milk
Exports: $14.6 billion (2000 est.)
Exports - commodities: ferrous and nonferrous
metals, fuel and petroleum products, machinery and
transport equipment, food products
Exports - partners: Russia 24%, Europe 30%, US
5% (2000 est.)
Imports: $15 billion (2000 est.)
Imports ■ commodities: energy, machinery and
parts, transportation equipment, chemicals
Imports ■ partners: Russia 42%, Europe 29%, US
3% (2000 est.)
Debt - external: $10.3 billion (2000)
Economic aid - recipient: $637.7 million (1995);
IMF Extended Funds Facility $2.2 billion (1998)
Currency: hryvnia (UAH)
Currency code: UAH
Exchange rates: hryvnia per US dollar - 5.4331
(January 2001 ), 5.4402 (2000), 4.1 304 (1 999), 2.4495
(1998), 1.8617(1997), 1.8295(1996)
Fiscal year: calendar year','7816a07b46dc9a420dad742ceead80377dafc2b70bbb4187b147e96d787b46ff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('335956e1a8d4cb3248e8a10573fa92d9f8185df14e7f709f9a0cc1ce46f4c025',2001,'OM','Oman','economy',1092,'Economy - overview: The UAE has an open
economy with a high per capita income and a sizable
annual trade surplus. Its wealth is based on oil and
gas output (about 33% of GDP), and the fortunes of
the economy fluctuate with the prices of those
commodities. Since 1973, the UAE has undergone a
profound transformation from an impoverished region
of small desert principalities to a modern state with a
high standard of living. At present levels of production,
oil and gas reserves should last for more than 100
years. Despite higher oil revenues in 1999-2000, the
government has not drawn back from the economic
reforms implemented during the 1998 oil price
depression. The government has increased spending
on job creation and infrastructure expansion and Is
opening up its utilities to greater private-sector
involvement.
GDP: purchasing power parity - $54 billion
(2000 est.)
GDP ■ real growth rate: 4% (2000 est.)
GDP - per capita: purchasing power parity -
$22,800 (2000 est.)
GDP - composition by sector:
agriculture: 3%
industry: 52%
services: 45% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%:UA%
Inflation rate (consumer prices): 4.5% (2000 est.)
Labor force: 1 .4 million (1 998 est.)
note: 75% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Labor force - by occupation: services 60%,
industry 32%, agriculture 8% (1996 est.)
Unemployment rate: NA%
Budget:
revenues; $6.5 billion
expenditures: $7.3 billion, including capital
expenditures of $NA (2000 est.)
Industries: petroleum, fishing, petrochemicals,
construction materials, some boat building,
handicrafts, pearling
Industrial production growth rate: 4% (2000)
Electricity ■ production: 36.7 billion kWh (1999)
Electricity - production by source:
foss/7 tee/; 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
525
United Arab Emirates (continued)
Electricity - consumption: 34.131 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: dates, vegetables,
watermelons; poultry, eggs, dairy products; fish
Exports: $46 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil 45%, natural gas,
reexports, dried fish, dates
Exports - partners: Japan 30%, India 7%,
Singapore 6%, South Korea 4%, Oman, Iran (1999)
Imports: $34 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment, chemicals, food
Imports ■ partners: Japan 9%, US 8%, UK 8%, Italy
6%, Germany, South Korea (1999)
Debt ■ external: $12.6 billion (2000 est.)
Economic aid ■ recipient: $NA
Currency: Emirati dirham (AED)
Currency code: AED
Exchange rates: Emirati dirhams per US dollar -
central bank mid-point rate: 3.6725 (since 1998);
3.6711 (1997), 3.6710 (1995-96)
Fiscal year: calendar year','b5d9cd1ef59d2e0ead8c90299e29f5fdf0f437d66b1e000f54d44d3c276b8adf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad59d6b730a5e337bc5b9f2e0009501a5de1d68a1fd703cecbf683bed1eb287a',2001,'UY','Uruguay','economy',1104,'Economy - overview: Uruguay''s economy is
characterized by an export-oriented agricultural
sector, a well-educated workforce, relatively even
income distribution, and high levels of social
spending. After averaging growth of 5% annually in
1996-98, in 1999-2000 the economy suffered from
lower demand in Argentina and Brazil, which together
account for about half of Uruguay''s exports. Despite
the severity of the trade shocks, Uruguay’s financial
indicators remained more stable than those of its
neighbors, a reflection of its solid reputation among
investors and its investment-grade sovereign bond
rating - one of only two in Latin America. Challenges
for the government of President Jorge BATLLE
include expanding Uruguay''s trade ties beyond its
MERCOSUR trade partners and reducing the costs of
public services. GDP fell by 1.1% in 2000 and will
grow by perhaps 1 .5% in 2001 .
GDP; purchasing power parity - $31 billion
(2000 est.)
GDP - real growth rate: -1.1% (2000 est.)
GDP - per capita: purchasing power parity - $9,300
(2000 est.)
GDP - composition by sector:
agriculture: 10%
industry: 28%
serv/ces.* 62% (1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%:
highest 10%: NA%
Inflation rate (consumer prices): 4.8% (2000 est.)
Labor force: 1 .5 million (1 999 est.)
Labor force - by occupation; agriculture NA%,
industry NA%, services NA%
Unemployment rate: 14% (2000 est.)
Budget:
revenues: $4 billion
expenditures: U-0 billion, including capital
expenditures of $500 million (2000 est.)
Industries: food processing, electrical machinery,
transportation equipment, petroleum products,
textiles, chemicals, beverages
Industrial production growth rate: -2.1%
(2000 est.)
Electricity - production: 5.704 billion kWh (1999)
Electricity - production by source:
fossil fuel: 3.86%
hydro; 95.44%
nuclear: 0%
ofher; 0.7% (1999)
Electricity - consumption: 5.89 billion kWh (1999)
Electricity ■ exports: 21 5 million kWh (1 999)
Electricity - imports: 800 million kWh (1999)
Agriculture ■ products: wheat, rice, barley, corn,
sorghum: livestock; fish
Exports: $2.6 billion (f.o.b., 2000 est.)
Exports - commodities: meat, rice, leather
products, vehicles, dairy products, wool, electricity
Exports - partners: MERCOSUR partners 45%, EU
20%, US 7% (1999 est.)
Imports: $3.4 billion (f.o.b., 2000 est.)
Imports - commodities: road vehicles, electrical
machinery, metal manufactures, heavy industrial
machinery, crude petroleum
Imports - partners: MERCOSUR partners 43%, EU
20%, US 11% (1999 est.)
Debt ■ external: $8 billion (2000 est.)
Economic aid ■ recipient: $NA
Currency: Uruguayan peso (UYU)
Currency code: UYU
Exchange rates: Uruguayan pesos per US dollar -
12.5610 (January 2001), 12.0996 (2000), 11.3393
(1 999), 1 0.471 9 (1 998), 9.441 8 (1 997), 7.971 8 (1 996)
Fiscal year: calendar year','e6623bdaea795028ea365a9dbd0518e5779a9221c176ba3847e3c4a3ed0b2c77','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('294e60044f51664d9d8568ee3cf901277acaded904c7f877de79d180707eb73b',2001,'UZ','Uzbekistan','economy',1111,'Economy - overview: Uzbekistan is a dry,
landlocked country of which 1 0% consists of intensely
cultivated, irrigated river valleys. More than 60% of its
population lives in densely populated rural
communities. Uzbekistan is now the world’s third
largest cotton exporter, a large producer of gold and
oil, and a regionally significant producer of chemicals
and machinery. Following independence in December
1991 , the government sought to prop up its
Soviet-style command economy with subsidies and
tight controls on production and prices. Faced with
high rates of inflation, however, the government
began to reform in mid-1994, by introducing tighter
monetary policies, expanding privatization, slightly
reducing the role of the state in the economy, and
improving the environment for foreign investors. The
state continues to be a dominating influence in the
economy and has so far failed to bring about
much-needed structural changes. The IMF
suspended Uzbekistan''s $185 million standby
arrangement in late 1996 because of governmental
steps that made impossible fulfillment of Fund
conditions. Uzbekistan has responded to the negative
external conditions generated by the Asian and
Russian financial crises by tightening export and
currency controls within its already largely closed
economy. Economic policies that have repelled
foreign investment are a major factor in the economy''s
stagnation. A growing debt burden, persistent
inflation, and a poor business climate led to stagnant
growth in 2000, with little improvement predicted for
2001.
GDP: purchasing power parity - $60 billion
(2000 est.)
GDP - real growth rate: 2.1% (2000 est.)
GDP - per capita: purchasing power parity - $2,400
(2000 est.)
GDP - composition by sector:
agriculture: 28%
industry: 21%
serv/ces; 51% (1999 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: 3.1%
highest 10%:25.2% (1993)
Inflation rate (consumer prices): 40% (2000 est.)
Labor force: 1 1 .9 million (1 998 est.)
Labor force ■ by occupation: agriculture 44%,
industry 20%, services 36% (1995)
Unemployment rate: 1 0% plus another 20%
underemployed (1999 est.)
Budget:
revenues: $4 billion
expenditures: $4.1 billion, including capital
expenditures of $NA (1 999 est.)
Industries: textiles, food processing, machine
building, metallurgy, natural gas, chemicals
Industrial production growth rate: 6.4%
(2000 est.)
Electricity - production: 42.876 billion kWh (1999)
Electricity - production by source:
fossil fuel: 86.4%
hydro: 13.6%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 43.455 billion kWh
(1999)
Electricity - exports: 3.92 billion kWh (1999)
Electricity - Imports: 7.5 billion kWh (1999)
Agriculture - products: cotton, vegetables, fruits,
grain; livestock
Exports: $2.9 billion (f.o.b., 2000 est.)
Exports - commodities: cotton, gold, natural gas,
mineral fertilizers, ferrous metals, textiles, food
products, automobiles
Exports ■ partners: Russia 13%, Switzerland 10%,
UK 10%, Belgium 3%, Kazakhstan 4%, Tajikistan 4%
(1999)
Imports: $2.6 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
chemicals, metals; foodstuffs
Imports - partners: Russia 14%, South Korea 14%,
Germany 11%, US 8%, Turkey 4%, Kazakhstan 4%
(1999)
537
Uzbekistan (continued)
Debt - external: $3.3 billion (1999 est.)
Economic aid ■ recipient: $276.6 million (1995)
Currency: Uzbekistani sum (UZS)
Currency code: UZS
Exchange rates: Uzbekistani sums per US dollar -
325.0 (January 2001 ), 1 41 .4 (January 2000), 1 1 1 .9
(February 1999), 110.95 (December 1998), 75.8
(September 1997), 41.1 (1996)
Fiscal year: calendar year','2ac12f9f2bf5875b412c51eaac2c2eb3cd7a6290d06b3b8621b380fdf13bd0ff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('484b7e93f1b86642443277c7ad4557a847802a6a6e7feec7f52c697f0feaa24f',2001,'AF','Afghanistan','economy',1119,'Economy - overview: The economy is based
primarily on subsistence or small-scale agriculture
which provides a living for 65% of the population.
Fishing, offshore financial services, and tourism, with
about 50,000 visitors in 1997, are other mainstays of
the economy. Mineral deposits are negligible; the
country has no known petroleum deposits. A small
light industry sector caters to the local market. Tax
revenues come mainly from import duties. Economic
development is hindered by dependence on relatively
few commodity exports, vulnerability to natural
disasters, and long distances from main markets and
between constituent islands. The most recent natural
disaster, a severe earthquake in November 1999
followed by a tsunami, caused extensive damage to
the northern island of Pentecote and left thousands
539
Vanuatu (continued)
homeless. GDP growth has risen less than 3% on
average in the 1990s. In response to foreign
concerns, the government is moving to tighten
regulation of its offshore financial center.
GDP: purchasing power parity - $245 million
(1999 est.)
GDP - real growth rate: -2.5% (1 999 est.)
GDP - per capita: purchasing power parity - $1 ,300
(1999 est.)
GDP - composition by sector:
agriculture: 20%
industry: 9%
sen/ices: 71 % (1 999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 2.5% (1999 est.)
Labor force: NA
Labor force ■ by occupation: agriculture 65%,
services 32%, industry 3% (1995 est.)
Unemployment rate: NA%
Budget:
revenues; $94.4 million
expenditures: $99.8 million, including capital
expenditures of $30.4 million (1996 est.)
Industries: food and fish freezing, wood processing,
meat canning
Industrial production growth rate: 1% (1997 est.)
Electricity - production: 35 million kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
ofher; 0% (1999)
Electricity - consumption: 32.6 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: copra, coconuts, cocoa,
coffee, taro, yams, coconuts, fruits, vegetables; fish,
beef
Exports: $25.3 million (f.o.b., 1999)
Exports - commodities: copra, kava, beef, cocoa,
timber, coffee
Exports - partners: Japan 32%, Germany 14%,
Spain 8%, New Caledonia 7%, Australia 2%
(1997 est.)
Imports: $77.2 million (f.o.b., 1999)
Imports - commodities: machinery and equipment,
foodstuffs, fuels
Imports - partners: Japan 52%, Australia 20%, New
Caledonia, Singapore, New Zealand, France, Fiji
(1997 est.)
Debt - external: $48 million (1997 est.)
Economic aid - recipient: $45.8 million (1995)
Currency: vatu (VUV)
Currency code: VUV
Exchange rates: vatu per US dollar - 143.95
(December 2000), 137.82 (2000), 129.08 (1999),
1 27.52 (1 998), 1 1 5.87 (1 997), 1 1 1 .72 (1 996)
Fiscal year: calendar year
Economy - overview: The petroleum sector
dominates the economy, accounting for roughly a
third of GDP, around 80% of export earnings, and
more than half of government operating revenues.
Venezuelan officials estimate that GDP grew by 3.2%
in 2000. A strong rebound in international oil prices
fueled the recovery from the steep recession in 1 999.
Nevertheless, a weak nonoil sector and capital flight
undercut the recovery. The bolivar is widely believed
to be overvalued by as much as 50%. The
government is still rebuilding after massive flooding
and landslides in December 1999 caused an
estimated $15 billion to $20 billion in damage.
GDP: purchasing power parity - $146.2 billion
(2000 est.)
GDP - real growth rate: 3.2% (2000 est.)
GDP - per capita: purchasing power parity - $6,200
(2000 est.)
GDP - composition by sector:
agriculture: 5%
industry: 24%
services: 71 % (1 999 est.)
Population below poverty line: 67% (1997 est.)
Household Income or consumption by percentage
share:
lowest 10%:^.5%
highest 10%: 3b.e%{m5)
Inflation rate (consumer prices): 13% (2000)
Labor force: 9.9 million (1999)
Labor force - by occupation: services 64%,
industry 23%, agriculture 13% (1997 est.)
Unemployment rate: 14% (2000 est.)
Budget:
revenues: $26.4 billion
expenditures: $27 billion, including capital
expenditures of $NA (2000 est.)
Industries: petroleum, iron ore mining, construction
materials, food processing, textiles, steel, aluminum,
motor vehicle assembly
Industrial production growth rate: NA
Electricity ■ production: 81.215 billion kWh (1999)
Electricity - production by source:
fossil fuel: 32,mo
hydro.- 67.84%
nuclear: 0%
of/?or0%(1999)
Electricity - consumption: 75.53 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: corn, sorghum, sugarcane,
rice, bananas, vegetables, coffee; beef, pork, milk,
eggs; fish
Exports: $32.8 billion (f.o.b., 2000)
Exports - commodities: petroleum, bauxite and
aluminum, steel, chemicals, agricultural products,
basic manufactures
Exports ■ partners: US and Puerto Rico 57%,
Colombia, Brazil, Japan, Germany, Netherlands, Italy
(1999)
Imports: $14.7 billion (f.o.b., 2000)
Imports - commodities: raw materials, machinery
and equipment, transport equipment, construction
materials
Imports - partners: US 53%, Japan, Colombia,
Italy, Germany, France, Brazil, Canada (1999)
Debt - external: $34 billion (2000)
Economic aid - recipient: $35 million with more
assistance likely as a result of flooding (1999)
Currency: bolivar (VEB)
Currency code: VEB
Exchange rates: bolivares per US dollar - 699.700
(January 2001), 679.960 (2000), 605.717 (1999),
547.556 (1998), 488.635 (1997), 417.333 (1996)
Fiscal year: calendar year
Economy ■ overview: Vietnam is a poor, densely
populated country that has had to recover from the
ravages of war, the loss of financial support from the
old Soviet Bloc, and the rigidities of a centrally planned
economy. Substantial progress was achieved from
1 986 to 1 996 in moving forward from an extremely low
starting point - growth averaged around 9% per year
from 1993 to 1997. The 1997 Asian financial crisis
highlighted the problems existing in the Vietnamese
economy but, rather than prompting reform, reaffirmed
the government''s belief that shifting to a market
oriented economy leads to disaster. GDP growth of
8.5% in 1997 fell to 6% in 1998 and 5% in 1999.
Growth continued at the moderately strong level of
5.5%, a level that should be matched in 2001 . These
numbers mask some major difficulties in economic
performance. Many domestic industries, including
coal, cement, steel, and paper, have reported large
stockpiles of inventory and tough competition from
more efficient foreign producers; this problem
apparently eased in 2000. Foreign direct investment
fell dramatically, from $8.3 billion in 1 996 to about $1 .6
billion in 1999. Meanwhile, Vietnamese authorities
have moved slowly in implementing the structural
reforms needed to revitalize the economy and produce
more competitive, export-driven industries.
GDP: purchasing power parity - $154.4 billion
(2000 est.)
GDP ■ real growth rate: 5.5% (2000 est.)
GDP ■ per capita: purchasing power parity - $1 ,950
(2000 est.)
GDP - composition by sector:
agriculture: 25%
industry: 35%
services: 40% (1 999 est.)
Population below poverty line: 37% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.5%
highest 10%: 29% (1993)
Inflation rate (consumer prices): -0.6% (2000 est.)
Labor force: 38.2 million (1998 est.)
Labor force - by occupation: agriculture 67%,
industry and services 33% (1997 est.)
Unemployment rate: 25% (1995 est.)
Budget:
revenues: $5.3 billion
expenditures: $5.6 billion, including capital
expenditures of $1 .8 billion (1999 est.)
Industries: food processing, garments, shoes,
machine building, mining, cement, chemical fertilizer,
glass, tires, oil, coal, steel, paper
Industrial production growth rate: 10.7%
(2000 est.)
Electricity - production: 22.985 billion kWh (1999)
Electricity - production by source:
foss/7 fue/; 47.71%
hydro: 52.29%
nuclear: 0%
other: 0%(^999)
Electricity - consumption: 21 .376 billion kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture ■ products: paddy rice, corn, potatoes,
rubber, soybeans, coffee, tea, bananas, sugar;
poultry, pigs; fish
Exports: $14.3 billion (f.o.b., 2000 est.)
Exports “ commodities: crude oil, marine products,
rice, coffee, rubber, tea, garments, shoes
Exports - partners: China, Japan, Germany,
Australia, US, France, Singapore, UK, Taiwan
Imports: $15.2 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment,
petroleum products, fertilizer, steel products, raw
cotton, grain, cement, motorcycles
Imports - partners: Japan, Singapore, South Korea,
Taiwan, China, Thailand, Hong Kong, Malaysia,
Indonesia, France, US, Sweden
Debt - external: $13.2 billion (2000)
Economic aid - recipient: $2.1 billion in credits and
grants pledged by international donors for 2000
Currency: dong(VND)
Currency code: VND
Exchange rates: dong per US dollar - 14,530
(January 2001), 14,020 (January 2000), 13,900
(December 1 998), 1 1 , 1 00 (December 1 996), 1 1 ,1 93
(1995 average), 1 1,000 (October 1994)
Fiscal year: calendar year','574583cba59e14e9cc706347e0c60d5ebfd0f018132fcecec4f803211e4538e0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38ca39455f134d4af932c44b9715bf142b40db26f68e5c519a77b5f3a715b9a6',2001,'PR','Puerto Rico','economy',1125,'Economy - overview: Tourism is the primary
economic activity, accounting for more than 70% of
GDP and 70% of employment. The islands normally
host 2 million visitors a year. The manufacturing
sector consists of petroleum refining, textiles,
electronics, pharmaceuticals, and watch assembly.
The agricultural sector is small, with most food being
imported. International business and financial
services are a small but growing component of the
economy. One of the world''s largest petroleum
refineries is at Saint Croix. The islands are subject to
substantial damage from storms. The government is
working to improve fiscal discipline, support
construction projects in the private sector, expand
tourist facilities, and protect the environment.
GDP: purchasing power parity - $1 .8 billion
(2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$15,000 (2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%o: NA%
Inflation rate (consumer prices): NA%
Labor force: 47,443 (1990 est.)
Labor force - by occupation: agriculture 1%,
industry 20%, services 79% (1990 est.)
Unemployment rate: 4.9% (March 1999)
Budget:
revenues; $364.4 million
expencf/teres; $364.4 million, including capital
expenditures of $NA (1990 est.)
Industries: tourism, petroleum refining, watch
assembly, rum distilling, construction,
pharmaceuticals, textiles, electronics
Industrial production growth rate: NA%
Electricity > production: 1 .02 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
546
Virgin Islands (continued)
Electricity - consumption: 948.6 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: fruit, vegetables, sorghum;
Senepol cattle
Exports: $NA
Exports - commodities: refined petroleum products
Exports - partners: US, Puerto Rico
Imports: $NA
Imports - commodities: crude oil, foodstuffs,
consumer goods, building materials
Imports - partners; US, Puerto Rico
Debt - external: $NA
Economic aid - recipient: $NA
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar Is used
Fiscal year: 1 October - 30 September','c7163bcbe80a5d3e700af2a2f74ac2fdccc009669a28edad74fcd7a31ed9f4e5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4be102000283659d875655f15878f672d0b7d54f8e2e4126455022b230a18ffe',2001,'YE','Yemen','economy',1137,'Economy - overview: Yemen, one of the poorest
countries in the Arab world, reported strong growth in
the mid-1 990s with the onset of oil production, but was
harmed by low oil prices in 1998, Yemen has
embarked on an IMF-supported structural adjustment
program designed to modernize and streamline the
economy, which has led to foreign debt relief and
restructuring. Aided by higher oil prices in 1 999-2000,
Yemen worked to maintain tight control over spending
and implement additional components of the IMF
program. A high population growth rate of nearly 3.4%
and internal political dissension complicate the
government''s task.
GDP: purchasing power parity - $14.4 billion
(2000 est.)
GDP - real growth rate: 6% (2000 est.)
GDP - per capita: purchasing power parity - $820
(2000 est.)
GDP - composition by sector:
agriculture: 20%
industry: 42%
services: 38% (1998)
Population below poverty line: 1 9% (1 992 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.3%
highest /(}%; 30.8% (1992)
Inflation rate (consumer prices): 10% (2000 est.)
Labor force: NA
Labor force - by occupation: most people are
employed in agriculture and herding; services,
construction, industry, and commerce account for less
than one-fourth of the labor force
Unemployment rate: 30% (1995 est.)
Budget:
revenues: $3 billion
expenditures: $3.1 billion, including capital
expenditures of $NA (2001 est.)
Industries: crude oil production and petroleum
refining; small-scale production of cotton textiles and
leather goods; food processing; handicrafts; small
aluminum products factory; cement
556
Yemen (continued)
Industrial production growth rate: NA%
Electricity - production: 2.4 billion kWh (1999)
Electricity < production by source:
fossil fuel: ^Q0%
hydro: 0%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 2.232 billion kWh (1 999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1999)
Agriculture - products: grain, fruits, vegetables,
pulses, qat (mildly narcotic shrub), coffee, cotton;
dairy products, livestock (sheep, goats, cattle,
camels), poultry; fish
Exports: $4.2 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil, coffee, dried and
salted fish
Exports - partners: Thailand 34%, China 26%,
South Korea 14%, Japan 3% (1999)
Imports: $2.7 billion (f.o.b., 2000 est.)
Imports - commodities: food and live animals,
machinery and equipment
Imports " partners: Saudi Arabia 1 0%, UAE 8%, US
7%, France 7%. Italy 6% (1999)
Debt - external: $4.4 billion (2000)
Economic aid - recipient: $176.1 million (1995)
Currency: Yemeni rial (YER)
Currency code: YER
Exchange rates: Yemeni rials per US dollar -
164.590 (October 2000), 160.683 (2000), 155.718
(1 999), 1 35.882 (1 998), 1 29.281 (1 997), 94.1 57 (1 996)
Fiscal year: calendar year
Economy - overview: The swift collapse of the
Yugoslav federation in 1991 was followed by highly
destructive warfare, the destabilization of republic
boundaries, and the breakup of important interrepublic
trade flows. Output in Yugoslavia dropped by half in
1992-93. Like the other former Yugoslav republics, it
had depended on its sister republics for large amounts
of energy and manufactures. Wide differences in
climate, mineral resources, and levels of technology
among the republics accentuated this
interdependence, as did the communist practice of
concentrating much industrial output in a small
number of giant plants. The breakup of many of the
trade links, the sharp drop in output as industrial plants
lost suppliers and markets, and the destruction of
physical assets in the fighting all have contributed to
the economic difficulties of the republics.
Hyperinflation ended with the establishment of a new
currency unit in June 1993; prices were relatively
stable from 1995 through 1997, but inflationary
pressures resurged in 1998. Reliable statistics
continue to be hard to come by, and the GDP estimate
Is extremely rough. The economic boom anticipated
by the government after the suspension of UN
sanctions in December 1 995 has failed to materialize.
Government mismanagement of the economy is
largely to blame, but the damage to Yugoslavia''s
infrastructure and industry by the NATO bombing
during the war in Kosovo have added to problems. All
sanctions now have been lifted. Yugoslavia is in the
first stage of economic reform. Severe electricity
shortages are chronic, the result of lack of investment
by former regimes, depleted hydropower reservoirs
due to extended drought, and lack of funds. GDP
growth in 2000 was perhaps 15%, which made up for
a large part of the 20% decline of 1999.
GDP: purchasing power parity - $24.2 billion
(2000 est.)
GDP - real growth rate: 15% (2000 est.)
GDP - per capita: purchasing power parity - $2,300
(2000 est.)
GDP ■ composition by sector:
agriculture: 20%
industry: 50%
services: 30% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 42% (1999 est.)
Labor force: 1 .6 million (1 999 est.)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 30% (2000 est.)
Budget;
revenues: $NA
expenditures: WA, including capital expenditures of
$NA
Industries: machine building (aircraft, trucks, and
automobiles; tanks and weapons; electrical
equipment: agricultural machinery); metallurgy (steel,
aluminum, copper, lead, zinc, chromium, antimony,
bismuth, cadmium): mining (coal, bauxite, nonferrous
ore, iron ore, limestone); consumer goods (textiles,
footwear, foodstuffs, appliances); electronics,
petroleum products, chemicals, and pharmaceuticals
Industrial production growth rate: -22%
(1999 est.)
Electricity - production: 34.455 billion kWh (1999)
Electricity - production by source:
fossil fuel: 70%
hydro: 30%
nuclear: 0%
other: 0% (1999)
Electricity ■ consumption: 33.006 billion kWh
(1999)
Electricity - exports: 960 million kWh (1999)
Electricity - imports: 1 .923 billion kWh (1999)
Agriculture - products: cereals, fruits, vegetables,
tobacco, olives; cattle, sheep, goats
Exports: $1.5 billion (1999)
Exports - commodities: manufactured goods, food
and live animals, raw materials
Exports - partners: Bosnia and Herzegovina, Italy,
The Former Yugoslav Republic of Macedonia,
Germany (1998)
Imports: $3.3 billion (1999)
Imports - commodities: machinery and transport
equipment, fuels and lubricants, manufactured goods,
chemicals, food and live animals, raw materials
Imports - partners; Germany, Italy, Russia, The
Former Yugoslav Republic of Macedonia (1998)
Debt -external: $14.1 billion (1999 est.)
Economic aid - recipient: $NA
Currency: new Yugoslav dinar (YUM); note - in
Montenegro the German deutsche mark is legal
tender (1999)
Currency code: YUM
Exchange rates: new Yugoslav dinars per US
dollar - official rate: 10.0 (December 1998), 5.85
(December 1997), 5.02 (September 1996), 1.5 (early
1995); black market rate: 14.5 (December 1998), 8.9
(December 1997), 2 to 3 (early 1995)
Fiscal year: calendar year','1cbc24188232793a3fdefa759e132f1c19c8e494d07df25fa1670dbf2295f167','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51beedf013e72ec2d3b0fc9c97ea6f93108ff05de4e94c2d1fd21ca28517f503',2001,'ZM','Zambia','economy',1146,'Economy - overview: Despite progress in
privatization and budgetary reform, Zambia''s
economy has a long way to go. Privatization of
government-owned copper mines relieved the
government from covering mammoth losses
generated by the industry and greatly improved the
chances for copper mining to return to profitability and
spur economic growth. In late 2000, Zambia was
determined to be eligible for debt relief under the
Heavily Indebted Poor Countries (HIPC) initiative.
Inflation and unemployment rates remain high, but the
GDP growth rate should rise in 2001.
GDP: purchasing power parity - $8.5 billion
(2000 est.)
561
Zambia (continued)
GDP - real growth rate; 4% (2000 est.)
GDP - per capita: purchasing power parity - $880
(2000 est.)
GDP - composition by sector:
agriculture: 18%
industry: 27%
services: 55% (1999 est.)
Population below poverty line: 86% (1993 est.)
Household income or consumption by percentage
share:
lowest 10%: 1 .6%
highest 10%: 39.2% (1 995)
Inflation rate (consumer prices): 27.3%
(2000 est.)
Labor force; 3.4 million
Labor force - by occupation: agriculture 85%,
industry 6%, services 9%
Unemployment rate: 50% (2000 est.)
Budget;
revenues; $900 million
expenditures: billion, including capital
expenditures of NA million (1999 est.)
Industries; copper mining and processing,
construction, foodstuffs, beverages, chemicals,
textiles, fertilizer
Industrial production growth rate; 6.1%
(2000 est.)
Electricity - production: 7.642 billion kWh (1999)
Electricity - production by source;
fossil fuel: 0.55%
hydro: 99.45%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 5.926 billion kWh (1999)
Electricity - exports: 1 .6 billion kWh (1 999)
Electricity - imports: 419 million kWh (1999)
Agriculture - products: corn, sorghum, rice,
peanuts, sunflower seed, vegetables, flowers,
tobacco, cotton, sugarcane, cassava (tapioca); cattle,
goats, pigs, poultry, milk, eggs, hides; coffee
Exports: $928 million (f.o.b., 2000 est.)
Exports - commodities; copper, cobalt, electricity,
tobacco
Exports - partners: Japan, Saudi Arabia, India,
Thailand, South Africa, US, Malaysia (1997)
Imports: $1 .05 billion (f.o.b., 2000 est.)
Imports - commodities: machinery, transportation
equipment, fuels, petroleum products, electricity,
fertilizer; foodstuffs, clothing
Imports - partners: South Africa 48%, Saudi Arabia,
UK, Zimbabwe (1997)
Debt -external: $6.5 billion (2000)
Economic aid - recipient; $1 .99 billion (1995)
Currency: Zambian kwacha (ZMK)
Currency code: ZMK
Exchange rates: Zambian kwacha per US dollar -
4,024.53 (January 2001), 3,1 10.84 (2000), 2,388.02
(1999), 1,862.07 (1998), 1,314.50(1997), 1,207.90
(1996)
Fiscal year: calendar year
Economy - overview: The government of
Zimbabwe faces a wide variety of difficult economic
problems as it struggles to consolidate earlier moves
to develop a market-oriented economy. Its
involvement in the war in the Democratic Republic of
the Congo, for example, has already drained
hundreds of millions of dollars from the economy.
Badly needed support from the IMF suffers delays in
part because of the country''s failure to meet
budgetary goals. Inflation rose from an annual rate of
32% in 1998 to 59% in 1999 and 60% in 2000. The
economy is being steadily weakened by excessive
government deficits and AIDS; Zimbabwe has the
highest rate of infection in the world. Per capita GDP,
which is twice the average of the poorer sub-Saharan
nations, will increase little if any in the near-term, and
Zimbabwe will suffer continued frustrations in
developing its agricultural and mineral resources.
GDP: purchasing power parity - $28.2 billion
(2000 est.)
GDP - real growth rate: -6.1% (2000 est.)
GDP ■ per capita: purchasing power parity - $2,500
(2000 est.)
GDP - composition by sector:
agriculture: 28%
industry: 32%
services: 40% (1 997 est.)
Population below poverty line: 60% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 8%
highest y0%; 46.9% (1990)
Inflation rate (consumer prices): 60% (2000 est.)
Labor force: 5.5 million (2000 est.)
Labor force - by occupation: agriculture 66%,
services 24%, industry 10% (1996 est.)
Unemployment rate: 50% (2000 est.)
Budget:
revenues: $2.5 billion
expenditures: $2.9 billion, including capital
expenditures of $279 million (FY96/97 est.)
Industries: mining (coal, gold, copper, nickel, tin,
clay, numerous metallic and nonmetallic ores), steel,
wood products, cement, chemicals, fertilizer, clothing
and footwear, foodstuffs, beverages
Industrial production growth rate: NA%
Electricity - production: 5.78 billion kWh (1999)
Electricity - production by source:
fossil fuel: 69.98%
hydro: 30.02%
nuclear: 0%
other: 0% (1 999)
Electricity - consumption: 6.939 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 1.564 billion kWh (1999)
Agriculture - products: corn, cotton, tobacco,
wheat, coffee, sugarcane, peanuts; cattle, sheep,
goats, pigs
Exports: $1.8 billion (f.o.b., 2000 est.)
Exports - commodities: tobacco 29%, gold 7%,
ferroalloys 7%, cotton 5% (1999 est.)
Exports - partners: South Africa 10%, UK 9%,
Malawi 8%, Botswana 8%, Japan 7%, (1999 est.)
Imports: $1 .3 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and transport
equipment 35%, other manufactures 18%, chemicals
17%, fuels 14% (1999 est.)
Imports ■ partners: South Africa 46%, UK 6%,
China 4%, Germany 4%, US 3% (1999 est.)
Debt - external: $4.1 billion (2000 est.)
Economic aid - recipient: $200 million (2000 est.)
Currency: Zimbabwean dollar (ZWD)
Currency code: ZWD
Exchange rates: Zimbabwean dollars per US
dollar - 54.9451 (January 2001), 43.2900 (2000),
38.31 42 (1 999), 21 .41 33 (1 998), 1 1 .8906 (1 997),
9.9206 (1996)
Fiscal year: 1 July - 30 June','2848be8bbf2b716d074a97ef1cc0b7d2ba0e61bbe481846c1651003d234245f7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f31f4d96709f106c108a0b3634ce3f25f55e4360c634c198ec2683098a7dd09',2001,'ZW','Zimbabwe','economy',8,'This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview
This entry briefly describes the type of economy, including the degree
of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It
also characterizes major economic events and policy changes in the most
recent 12 months and may include a statement about one or two key
future macroeconomic trends.
Electricity - consumption
This entry consists of total electricity generated annually plus
imports and minus exports, expressed in kilowatt-hours. The discrepancy
between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in
transmission and distribution.
Electricity - exports
This entry is the total exported electricity in kilowatt-hours.
Electricity - imports
This entry is the total imported electricity in kilowatt-hours.
Electricity - production
This entry is the annual electricity generated expressed in kilowatt-
hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted
for as loss in transmission and distribution.
Electricity - production by source
This entry indicates the percentage share of annual electricity
production of each energy source. These are fossil fuel, hydro,
nuclear, and other (solar, geothermal, and wind).
Elevation extremes
This entry includes both the highest point and the lowest point.
Entities
Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. "Independent state" refers to a people politically
organized into a sovereign state with a definite territory.
"Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an
independent state. "Country" names used in the table of contents or for
page headings are usually the short-form names as approved by the US
Board on Geographic Names and may include independent states,
dependencies, and areas of special sovereignty, or other geographic
entities. There are a total of 267 separate geographic entities in The
World Factbook that may be categorized as follows:
INDEPENDENT STATES
191 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,
OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island,
French Guiana, French Polynesia, French Southern and Antarctic Lands,
Glorioso Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte,
New Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island,','81d297868386e827ee1462df212a310bd9aedb31848679b0af334f3a2b82a963','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a49da713303020638093d06b15a71a032364e67b2ae1212197c6ffcaeeed4a79',2001,'WF','Wallis and Futuna','economy',9,'2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
15 UK - Anguilla, Bermuda, British Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey,
Jersey, Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South
Georgia and the South Sandwich Islands, Turks and Caicos Islands
14 US - American Samoa, Baker Island, Guam, Howland Island, Jarvis
Island, Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island,
Northern Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands,
Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West
Bank, Western Sahara
OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific
Ocean, Southern Ocean
1 World
267 total
Environment - current issues
This entry lists the most pressing and important environmental
problems. The following terms and abbreviations are used throughout
the entry:
acidification - the lowering of soil and water pH due to acid
precipitation and deposition usually through precipitation; this
process disrupts ecosystem nutrient flows and may kill freshwater fish
and plants dependent on more neutral or alkaline conditions (see acid
rain).
acid rain - characterized as containing harmful levels of sulfur
dioxide or nitrogen oxide; acid rain is damaging and potentially deadly
to the earth''s fragile ecosystems; acidity is measured using the pH
scale where 7 is neutral, values greater than 7 are considered
alkaline, and values below 5.6 are considered acid precipitation; note
- a pH of 2.4 (the acidity of vinegar) has been measured in rainfall in
New England.
aerosol - a collection of airborne particles dispersed in a gas,
smoke, or fog.
afforestation - converting a bare or agricultural space by
planting trees and plants; reforestation involves replanting trees on
areas that have been cut or destroyed by fire.
asbestos - a naturally occurring soft fibrous mineral commonly
used in fireproofing materials and considered to be highly carcinogenic
in particulate form.
biodiversity - also biological diversity; the relative number of
species, diverse in form and function, at the genetic, organism,
community, and ecosystem level; loss of biodiversity reduces an
ecosystem''s ability to recover from natural or man-induced disruption.
bio-indicators - a plant or animal species whose presence,
abundance, and health reveal the general condition of its habitat.
biomass - the total weight or volume of living matter in a given
area or volume.
carbon cycle - the term used to describe the exchange of carbon
(in various forms, e.g., as carbon dioxide) between the atmosphere,
ocean, terrestrial biosphere, and geological deposits.
catchments - assemblages used to capture and retain rainwater and
runoff; an important water management technique in areas with limited
freshwater resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless
insecticide that has toxic effects on most animals; the use of DDT was
banned in the US in 1972.
defoliants - chemicals which cause plants to lose their leaves
artificially; often used in agricultural practices for weed control,
and may have detrimental impacts on human and ecosystem health.
deforestation - the destruction of vast areas of forest (e.g.,
unsustainable forestry practices, agricultural and range land clearing,
and the over exploitation of wood products for use as fuel) without
planting new growth.
desertification - the spread of desert-like conditions in arid or
semi-arid areas, due to overgrazing, loss of agriculturally productive
soils, or climate change.
dredging - the practice of deepening an existing waterway; also, a
technique used for collecting bottom-dwelling marine organisms (e.g.,
shellfish) or harvesting coral, often causing significant destruction
of reef and ocean-floor ecosystems.
drift-net fishing - done with a net, miles in extent, that is
generally anchored to a boat and left to float with the tide; often
results in an over harvesting and waste of large populations of non-
commercial marine species (by-catch) by its effect of "sweeping the
ocean clean".
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke, sewage, or industrial
waste which are released into the environment, subsequently polluting
it.
endangered species - a species that is threatened with extinction
either by direct hunting or habitat destruction.
freshwater - water with very low soluble mineral content; sources
include lakes, streams, rivers, glaciers, and underground aquifers.
greenhouse gas - a gas that "traps" infrared radiation in the
lower atmosphere causing surface warming; water vapor, carbon dioxide,
nitrous oxide, methane, hydrofluorocarbons, and ozone are the primary
greenhouse gases in the Earth''s atmosphere.
groundwater - water sources found below the surface of the earth
often in naturally occurring reservoirs in permeable rock strata; the
source for wells and natural springs.
Highlands Water Project - a series of dams constructed jointly by
Lesotho and South Africa to redirect Lesotho''s abundant water supply
into a rapidly growing area in South Africa; while it is the largest
infrastructure project in southern Africa, it is also the most costly
and controversial; objections to the project include claims that it
forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 125,000 Inuits
of Russia, Alaska, Canada, and Greenland in international environmental
issues; a panel convenes every three years to determine the focus of
the ICC; the most current concerns are long-range transport of
pollutants, sustainable development, and climate change.
metallurgical plants - industries which specialize in the science,
technology, and processing of metals; these plants produce highly
concentrated and toxic wastes which can contribute to pollution of
ground water and air when not properly disposed.
noxious substances - injurious, very harmful to living beings.
overgrazing - the grazing of animals on plant material faster than
it can naturally regrow leading to the permanent loss of plant cover, a
common effect of too many animals grazing limited range land.
ozone shield - a layer of the atmosphere composed of ozone gas (O3)
that resides approximately 25 miles above the Earth''s surface and
absorbs solar ultraviolet radiation that can be harmful to living
organisms.
poaching - the illegal killing of animals or fish, a great concern
with respect to endangered or threatened species.
pollution - the contamination of a healthy environment by man-made
waste.
potable water - water that is drinkable, safe to be consumed.
salination - the process through which fresh (drinkable) water
becomes salt (undrinkable) water; hence, desalination is the reverse
process; also involves the accumulation of salts in topsoil caused by
evaporation of excessive irrigation water, a process that can
eventually render soil incapable of supporting crops.
siltation - occurs when water channels and reservoirs become
clotted with silt and mud, a side effect of deforestation and soil
erosion.
slash-and-burn agriculture - a rotating cultivation technique in
which trees are cut down and burned in order to clear land for
temporary agriculture; the land is used until its productivity declines
at which point a new plot is selected and the process repeats; this
practice is sustainable while population levels are low and time is
permitted for regrowth of natural vegetation; conversely, where these
conditions do not exist, the practice can have disastrous consequences
for the environment .
soil degradation - damage to the land''s productive capacity
because of poor agricultural practices such as the excessive use of
pesticides or fertilizers, soil compaction from heavy equipment, or
erosion of topsoil, eventually resulting in reduced ability to produce
agricultural products.
soil erosion - the removal of soil by the action of water or wind,
compounded by poor agricultural practices, deforestation, overgrazing,
and desertification.
ultraviolet (UV) radiation - a portion of the electromagnetic
energy emitted by the sun and naturally filtered in the upper
atmosphere by the ozone layer; UV radiation can be harmful to living
organisms and has been linked to increasing rates of skin cancer in
humans.
water-born diseases - those in which the bacteria survive in, and
is transmitted through, water; always a serious threat in areas with an
untreated water supply.
Environment - international agreements
This entry separates country participation in international
environmental agreements into two levels - party to and signed but not
ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements
This information is presented in Appendix C: Selected International
Environmental Agreements, which includes the name, abbreviation, date
opened for signature, date entered into force, objective, and parties
by category.
Ethnic groups
This entry provides a rank ordering of ethnic groups starting with the
largest and normally includes the percent of total population.
Exchange rates
This entry provides the official value of a country''s monetary unit at
a given date or over a given period of time, as expressed in units of
local currency per US dollar and as determined by international market
forces or official fiat.
Executive branch
This entry includes several subfields. Chief of state includes the name
and title of the titular leader of the country who represents the state
at official and ceremonial functions but may not be involved with the
day-to-day activities of the government. Head of government includes
the name and title of the top administrative leader who is designated
to manage the day-to-day activities of the government. For example, in
the UK, the monarch is the chief of state, and the prime minister is
the head of government. In the US, the president is both the chief of
state and the head of government. Cabinet includes the official name
for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession
to power, date of the last election, and date of the next election.
Election results includes the percent of vote for each candidate in the
last election.
Exports
This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports - commodities
This entry provides a rank ordering of exported products starting with
the most important; it sometimes includes the percent of total dollar
value.
Exports - partners
This entry provides a rank ordering of trading partners starting with
the most important; it sometimes includes the percent of total dollar
value.
Fiscal year
This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but
which may begin in any month. All yearly references are for the
calendar year (CY) unless indicated as a noncalendar fiscal year (FY).
Flag description
This entry provides a written flag description produced from actual
flags or the best information available at the time the entry was
written. The flags of independent states are used by their dependencies
unless there is an officially recognized local flag. Some disputed and
other areas do not have flags.
Flag graphic
Most versions of the Factbook include a color flag at the beginning of
the country profile. The flag graphics were produced from actual flags
or the best information available at the time of preparation. The flags
of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not
have flags.
GDP
This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. GDP dollar
estimates in the Factbook are derived from purchasing power parity
(PPP) calculations. See the note on GDP methodology for more
information.
GDP methodology
In the Economy section, GDP dollar estimates for all countries are
derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method
involves the use of standardized international dollar price weights,
which are applied to the quantities of final goods and services
produced in a given economy. The data derived from the PPP method
provide the best available starting point for comparisons of economic
strength and well-being between countries. The division of a GDP
estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries
are often rough approximations. Most of the GDP estimates are based on
extrapolation of PPP numbers published by the UN International
Comparison Program (UNICP) and by Professors Robert Summers and Alan
Heston of the University of Pennsylvania and their colleagues. In
contrast, the currency exchange rate method involves a variety of
international and domestic financial forces that often have little
relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically
one-fourth to one-half the PPP estimate. Furthermore, exchange rates
may suddenly go up or down by 10% or more because of market forces or
official fiat whereas real output has remained unchanged. On 12 January
1994, for example, the 14 countries of the African Financial Community
(whose currencies are tied to the French franc) devalued their
currencies by 50%. This move, of course, did not cut the real output of
these countries by half. One important caution: the proportion of,
say, defense expenditures as a percentage of GDP in local currency
accounts may differ substantially from the proportion when GDP accounts
are expressed in PPP terms, as, for example, when an observer tries to
estimate the dollar level of Russian or Japanese military expenditures.
Note: the numbers for GDP and other economic data can not be chained
together from successive volumes of the Factbook because of changes in
the US dollar measuring rod, revisions of data by statistical agencies,
use of new or different sources of information, and changes in national
statistical methods and practices.
GDP - composition by sector
This entry gives the percentage contribution of agriculture, industry,
and services to total GDP.
GDP - per capita
This entry shows GDP on a purchasing power parity basis divided by
population as of 1 July for the same year.
GDP - real growth rate
This entry gives GDP growth on an annual basis adjusted for inflation
and expressed as a percent.
Geographic coordinates
This entry includes rounded latitude and longitude figures for the
purpose of finding the approximate geographic center of an entity and
is based on the Gazetteer of Conventional Names, Third Edition, August
1988, US Board on Geographic Names and on other sources.
Geographic names
This information is presented in Appendix F: Cross-Reference List of
Geographic Names. It includes a listing of various alternate names,
former names, local names, and regional names referenced to one or more
related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.','ba6dde1a2e702d19da7069ecb1db7559e3b4e5eef3f945e20a50746df96099d3','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf1bd0aa48e1597ad2355f6a37e7c1698bd1ef92e8eb8dbf049427af9d6e6674',2001,'','','raw',1,'Central Intelligence Agency
The Central Intelligence Agency (CIA) publishes The World
Factbook in printed and Internet versions. US Government
officials may obtain information about availability of the Factbook
from their organizations or through liaison channels to the CIA,
Other users may obtain sales information about printed copies
from the following:
Superintendent of Documents
P. 0. Box 371954
Pittsburgh, PA 15250-7954
Teiephone: [1](202) 512-1800
FAX: [1] (202) 512-2250
http://bookstore.gpo.gov/
Nationai Technical information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntls.gov/
The World Factbook can be accessed on the Internet at:
http://www.cia.gov/cia/publications/factbook/index.html
Imaging k Publishing Support
...where mission comes first
Central
Intelligence
Agency
The
World
Factbook
2001
DISTRIBUTfON STATEMENT A
Approved for Public Release
Distribution Unlimited
In general, information available as of 1 January
2001 was used in the preparation of this edition.
The World Factbook \\s prepared by the Central
Intelligence Agency for the use of US Government
officials, and the style, format, coverage, and
content are designed to meet their specific
requirements. Information is provided by Antarctic
Information Program (National Science
Foundation), Bureau of the Census (Department of
Commerce), Bureau of Labor Statistics (Department
of Labor), Central Intelligence Agency, Council of
Managers of National Antarctic Programs, Defense
Intelligence Agency (Department of Defense),
Department of State, Fish and Wildlife Service
(Department of the Interior), Maritime Administration
(Department of Transportation), National Imagery
and Mapping Agency (Department of Defense),
Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs
(Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on
Geographic Names (Department of the Interior), US
T ransportation Command (Department of Defense),
and other public and private sources.
The Factbook\\s in the public domain. Accordingly, it
may be copied freely without permission of the
Central Intelligence Agency (CIA). The official seal
of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50
U.S.C. section 403m). Misuse of the official seal of
the CIA could result in civil and criminal penalties.
Comments and queries are welcome and may be
addressed to;
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Telephone; [1](703) 482-0623
FAX; [1] (703) 482-1739
Reproduced From
Best Available Copy
A Brief History of Basic Inteiligence and
The World Factbook
The Intelligence Cycle is the process by which information
is acquired, converted into inteiligence, and made available to
policymakers. Information is raw data from any source, data
that may be fragmentary, contradictory, unreliable,
ambiguous, deceptive, or wrong. Intelligence is information
that has been collected, integrated, evaluated, analyzed, and
interpreted. Finished inteliigence is the final product of the
Intelligence Cycle ready to be delivered to the policymaker.
The three types of finished intelligence are: basic, current,
and estimative. Basic intelligence provides the fundamental
and factual reference material on a country or issue. Current
intelligence reports on new developments. Estimative
intelligence judges probable outcomes. The three are
mutually supportive: basic intelligence is the foundation on
which the other two are constructed; current intelligence
continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of
country and issue prospects for guidance of basic and current
intelligence. The World Factbook, The President''s Daily Brief,
and the National Intelligence Estimates are examples of the
three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington but only
since World War II have they been coordinated on a
government-wide basis. Three programs have highlighted the
development of coordinated basic intelligence since that time:
(1) the Joint Army Navy Intelligence Studies (JANIS), (2) the
National Intelligence Survey (NIS), and (3) The World
Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different components of
the US Government resulted in a great duplication of effort
and conflicting information. The Japanese attack on Pearl
Harbor in 1941 brought home to leaders in Congress and the
executive branch the need for integrating departmental
reports to national policymakers. Detailed and coordinated
information was needed not only on such major powers as
Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and
Marines had to launch amphibious operations against many
islands about which information was unconfirmed or
nonexistent. Intelligence authorities resolved that the United
States should never again be caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train
(Office of Naval Intelligence - ONI), and Gen. William J,
Donovan (Director of the Office of Strategic Services - OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS was
the first interdepartmental basic intelligence program to fulfill
the needs of the US Government for an authoritative and
coordinated appraisal of strategic basic intelligence. Between
April 1943 and July 1947, the board published 34 JANIS
studies. JANIS performed well in the war effort, and
numerous letters of commendation were received, including a
statement from Adm. Forrest Sherman, Chief of Staff, Pacific
Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based planners."
The need for more comprehensive basic intelligence in
the postwar world was well expressed in 1946 by George S.
Pettee, a noted author on national security. He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1946, page 46) that world leadership in peace requires
even more elaborate intelligence than in war. "The conduct of
peace involves all countries, all human activities - not just the
enemy and his war production."
The Central Intelligence Agency was established on 26
July 1947 and officially began operating on 18 September
1947. Effective 1 October 1947, the Director of Central
Intelligence assumed operational responsibility for JANIS. On
13 January 1948, the National Security Council issued
Intelligence Directive (NSCID) No. 3, which authorized the
National Intelligence Survey (H\\S) program as a peacetime
replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced,
government agencies had to develop more comprehensive
gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the
maps.
The Hoover Commission''s Clark Committee, set up in
1954 to study the structure and administration of the CIA,
reported to Congress in 1955 that: "The National Intelligence
Survey is an invaluable publication which provides the
essential elements of basic intelligence on all areas of the
world. There will always be a continuing requirement for
keeping the Survey up-to-date." The Factbookms created as
an annual summary and update to the encyclopedic NIS
studies. The first classified Factbookms published in August
1 962, and the first unclassified version was published in June
1 971 . The NIS program was terminated in 1 973 except for the
Factbook, map, and gazetteer components. The 1975
Factbookms the first to be made available to the public with
sales through the US Government Printing Office (GPO). The
1996 edition was printed by GPO, and the 1997 edition was
reprinted by GPO. The year 2001 marks the 54th anniversary
of the establishment of the Central Intelligence Agency and
the 58th year of continuous basic intelligence support to the
US Government by The World Factbook and Its two
predecessor programs.
II
Contents
Page
Page
Page
Notes and Definitions
vii','dd412243ba7db2aa75e9b3c0b20bc3d85af99108525163375c9bf0293f7fc5e0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d97494056a1dc4f7b82df94869079fdc5d8707bddbab25ea689a658052aaeda',2001,'BT','Bhutan','raw',2,'58
Europa Island
164
Johnston Atoll
261
Bolivia
60
Falkland Islands (Islas Malvinas)
164','d8a2a268136990ff4183aa26f4824ca8a1fc5668ff5cbab77d36756eaacd71f3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0465a722c3436119518075102a1bbbb542a77398ccaf6ee14d8173dc99896dd',2001,'PF','French Polynesia','raw',3,'178
Korea, North
273
Brunei
73
French Southern and Antarctic Lands
180
Korea, South
275','b041c0c853bcf535533244bcbee56ec16feb4824edcabf0cb4b31876f49aa431','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48c73c4438d64828c173a93d6e1f59d1ed6ee0ce6bbd12858f1645f820e2c6bf',2001,'US','United States','raw',4,'530
V
Notes and Definitions
In addition to the updating of information, the following changes have been made
in this edition of The World Factbook. The entity of Serbia and Montenegro is now
officially known as Yugoslavia. There are new entries on: Currency code, HIV/
AIDS - adult prevalence rate, HIV/AIDS - people living with HIV/AIDS, HIV/
AIDS - deaths, Internet users, and Internet country code. The Background
entry, which was introduced in the 1999 edition, has now been completed for all
267 entities in the Factbook. The individual country maps are being revised. Some
new maps with elevation extremes and a partial geographic grid are included in
this edition.
Abbreviations: This information is included in Appendix A; Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Acronyms; An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up solely from
the first letter of the major words in the expanded form is rendered in all capital
letters (NATO from North Atlantic Treaty Organization; an exception would be
ASEAN for Association of Southeast Asian Nations). In general, an acronym made
up of more than the first letter of the major words in the expanded form is rendered
with only an initial capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned Movement). Hybrid
forms are sometimes used to distinguish between initially identical terms (WTO:
WTrO for World Trade Organization and WToO for World Tourism Organization.)
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64 years, 65
years and over). The age structure of a population affects a nation''s key
socioeconomic issues. Countries with young populations (high percentage under
age 15) need to invest more in schools, while countries with older populations
(high percentage ages 65 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential political issues. For
example, the rapid growth of a young adult population unable to find employment
can lead to unrest.
Agriculture - products: This entry is a rank ordering of major crops and products
starting with the most important.
Airports: This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or gravel
surfaces), but must be usable. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Airports ■ with paved runways; This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces). For airports with more than one
runway, only the longest runway is included according to the following five groups -
(1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437 m, (4) 914 to 1 ,523 m,
and (5) under 914 m. Only airports with usable runways are included in this listing.
Not all airports have facilities for refueling, maintenance, or air traffic control.
vii
Notes and Definitions (continued)
Airports - with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces). For airports with
more than one runway, only the longest runway is included according to the
following five groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437
m, (4) 91 4 to 1 ,523 m, and (5) under 914 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control
Appendixes: This section includes Factbook-re\\a\\e6 material by topic.
Area: This entry includes three subfields. Total area Is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is
the sum of all water surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes, reservoirs, rivers).
Area - comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and current
issues and may include a statement about one or two key future trends.
Birth rate: This entry gives the average annual number of births during a year per
1,000 persons in the population at midyear; also known as crude birth rate. The
birth rate is usually the dominant factor in determining the rate of population
growth. It depends on both the level of fertility and the age structure of the
population.
Budget: This entry includes revenues, total expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms
Capital: This entry gives the location of the seat of government.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging Information
and includes the telephone, radio, television, and Internet service provider entries.
Communications - note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Country data codes: see Data codes
Country map: Most versions of the Facfboo/r provide a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
viii
Notes and Definitions (continued)
Country name: This entry includes all forms of the country''s name approved by
the US Board on Geographic Names (Italy is used as an example); conventiona!
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica Italiana), local short form (Italia), former (Kingdom of Italy), as well as
the abbreviation. Also see the Terminology note.
Currency: This entry identifies the national medium of exchange and its basic
subunit.
Currency code: This entry gives the ISO 4217 alphabetic currency code for each
country.
Data codes: This information is presented in Appendix D: Cross-Reference List
of Country Data Codes and Appendix E: Cross-Reference List of
Hydrographic Data Codes. This appendix includes the US Government
approved Federal Information Processing Standards (FIPS) codes, the
International Organization for Standardization (ISO) codes, and Internet codes for
land entities. The appendix also includes the International Hydrographic
Organization (IHO) codes, Aeronautical Chart and Information Center (ACIC; now
a part of the National Imagery and Mapping Agency or NIMA) codes, and Defense
Intelligence Agency (DIA) codes for hydrographic entities. The US Government
has not yet approved a standard for hydrographic data codes similar to the FIPS
10-4 standard for country data codes.
Date of information: In general, information available as of 1 January 2001 , was
used in the preparation of this edition.
Death rate: This entry gives the average annual number of deaths during a year
per 1 ,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show
a rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt - external: This entry gives the total amount of public foreign financial
obligations.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
185 independent states, including 183 of the 189 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, and the US itself). In addition,
the US has diplomatic relations with 2 independent states that are not in the UN -
Holy See and Switzerland.
Diplomatic representation from the US: This entry Includes the chief of mission,
embassy address, mailing address, telephone number, FAX number, branch office
locations, consulate genera/ locations, and consulate locations.
IX
Notes and Definitions (continued)
Disputes - international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
Inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
Economic aid - donor: This entry refers to net official development assistance
(ODA) from OECD nations to developing countries and multilateral organizations.
ODA is defined as financial assistance that is concessional in character, has the
main objective to promote economic development and welfare of the less
developed countries (LDCs), and contains a grant element of at least 25%. The
entry does not cover other official flows (OOF) or private flows.
Economic aid - recipient: This entry, which Is subject to major problems of
definition and statistical coverage, refers to the net Inflow of Official Development
Finance (ODF) to recipient countries. The figure includes assistance from the
World Bank, the IMF, and other international organizations and from individual
nation donors. Formal commitments of aid are included in the data. Omitted from
the data are grants by private organizations. Aid comes in various forms Including
outright grants and loans. The entry thus is the difference between new inflows
and repayments.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview: This entry briefly describes the type of economy, including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes In the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Electricity ■ consumption: This entry consists of total electricity generated
annually plus Imports and minus exports, expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in transmission and
distribution.
Electricity - exports: This entry is the total exported electricity in kilowatt-hours.
Electricity - Imports: This entry is the total Imported electricity in kilowatt-hours.
Electricity - production: This entry is the annual electricity generated expressed
in kilowatt-hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted for as
loss in transmission and distribution.
Electricity - production by source: This entry indicates the percentage share of
annual electricity production of each energy source. These are fossil fuel, hydro,
nuclear, and other (solar, geothermal, and wind).
Elevation extremes: This entry includes both the highest point ar\\6 the lowest
point.
x
Notes and Definitions (continued)
Entitles: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government. "Independent
state" refers to a people politically organized into a sovereign state with a definite
territory. "Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an independent
state. "Country" names used in the table of contents or for page headings are
usually the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a total of 267 separate
geographic entities in The World Factbook \\ha.\\ may be categorized as follows:
INDEPENDENT STATES
191 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,','9aed3228ef3a34a3fd960df0eeb745389d113d4cf46dc759a1f862f63a332ad8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65c33a44a9d17c0148de7e94ad665e1ac1d3125ad8b3485f7d088e1f9a130fa5',2001,'EH','Western Sahara','raw',5,'552
World
553
Y
OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
267 total
Environment - current issues: This entry lists the most pressing and important
environmental problems. The following terms and abbreviations are used
throughout the entry:
acidification - the lowering of soil and water pH due to acid precipitation and
deposition usually through precipitation; this process disrupts ecosystem nutrient
flows and may kill freshwater fish and plants dependent on more neutral or alkaline
conditions (see acid rain).
acid rain - characterized as containing harmful levels of sulfur dioxide or
nitrogen oxide; acid rain is damaging and potentially deadly to the earth''s fragile
ecosystems; acidity is measured using the pH scale where 7 is neutral, values
greater that 7 are considered alkaline, and anything measured below 5.6 is
considered acid precipitation; note - a pH of 2.4 (the acidity of vinegar) has been
measured in rainfall In New England.
aerosol - a collection of airborne particles dispersed in a gas, smoke, or fog.
afforestation - converting a bare or agricultural space by planting trees and
plants; reforestation involves replanting trees on areas that have been cut or
destroyed by fire.
asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in particulate form.
biodiversity - also biological diversity; the relative number of species, diverse
in form and function, at the genetic, organism, community, and ecosystem level;
loss of biodiversity reduces an ecosystem’s ability to recover from natural or
man-induced disruption.
bio-indicators - a plant or animal species whose presence, abundance, and
health reveal the general condition of its habitat.
biomass - the total weight or volume of living matter in a given area or volume.
carbon cycle - the term used to describe the exchange of carbon (in various
forms, e.g., as carbon dioxide) between the atmosphere, ocean, terrestrial
biosphere, and geological deposits.
catchments - assemblages used to capture and retain rainwater and runoff; an
important water management technique in areas with limited freshwater
resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless insecticide
that has toxic effects on most animals; the use of DDT was banned in the US in
1972.
xii
Notes and Definitions (continued)
defoliants - chemicals which cause plants to lose their leaves artificially; often
used in agricultural practices for weed control, and may have detrimental impacts
on human and ecosystem health.
deforestation - the destruction of vast areas of forest (e.g., unsustainable
forestry practices, agricultural and range land clearing, and the over exploitation of
wood products for use as fuel) without planting new growth.
desertification - the spread of desert-like conditions in arid or semi-arid areas,
due to overgrazing, loss of agriculturally productive soils, or climate change.
dredging - the practice of deepening an existing waterway; also, a technique
used for collecting bottom-dwelling marine organisms (e.g., shellfish) or harvesting
coral, often causing significant destruction of reef and ocean-floor ecosystems.
drift-net fishing ■ done with a net, miles in extent, that is generally anchored to
a boat and left to float with the tide; often results in an over harvesting and waste
of large populations of non-commercial marine species (by-catch) by its effect of
“sweeping the ocean clean”.
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke, sewage, or industrial waste which
are released into the environment, subsequently polluting it.
endangered species - a species that is threatened with extinction either by
direct hunting or habitat destruction.
freshwater - water with very low soluble mineral content; sources include lakes,
streams, rivers, glaciers, and underground aquifers.
greenhouse gas - a gas that “traps” infrared radiation in the lower atmosphere
causing surface warming; water vapor, carbon dioxide, nitrous oxide, methane,
hydrofluorocarbons, and ozone are the primary greenhouse gases in the Earth’s
atmosphere.
groundwater - water sources found below the surface of the earth often in
naturally occurring reservoirs in permeable rock strata; the source for wells and
natural springs.
Highlands Water Project - a series of dams constructed jointly by Lesotho and
South Africa to redirect Lesotho''s abundant water supply into a rapidly growing
area in South Africa; while it is the largest infrastructure project in southern Africa,
it is also the most costly and controversial; objections to the project include claims
that it forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 125,000 Inuits of Russia,
Alaska, Canada, and Greenland in international environmental issues; a panel
convenes every three years to determine the focus of the ICC; the most current
concerns are long-range transport of pollutants, sustainable development, and
climate change.
metallurgical plants - industries which specialize in the science, technology,
and processing of metals; these plants produce highly concentrated and toxic
wastes which can contribute to pollution of ground water and air when not properly
disposed.
noxious substances - injurious, very harmful to living beings,
overgrazing - the grazing of animals on plant material faster than it can
naturally regrow leading to the permanent loss of plant cover, a common effect of
too many animals grazing limited range land.
ozone shield - a layer of the atmosphere composed of ozone gas (03) that
resides approximately 25 miles above the Earth''s surface and absorbs solar
ultraviolet radiation that can be harmful to living organisms.
poaching - the illegal killing of animals or fish, a great concern with respect to
endangered or threatened species.
xiii
Notes and Definitions (continued)
pollution - the contamination of a healthy environment by man-made waste,
potabie water - water that is drinkable, safe to be consumed,
salination - the process through which fresh (drinkabie) water becomes sait
(undrinkabie) water; hence, desalination is the reverse process; aiso involves the
accumulation of saits in topsoil caused by evaporation of excessive irrigation
water, a process that can eventually render soil incapable of supporting crops.
siltation - occurs when water channels and reservoirs become clotted with silt
and mud, a side effect of deforestation and soil erosion.
slash-and-burn agriculture - a rotating cultivation technique in which trees are
cut down and burned in order to clear land for temporary agriculture; the land is
used until its productivity declines at which point a new plot is selected and the
process repeats; this practice is sustainable while population levels are low and time
is permitted for regrowth of natural vegetation; conversely, where these conditions
do not exist, the practice can have disastrous consequences for the environment .
soil degradation - damage to the land''s productive capacity because of poor
agricultural practices such as the excessive use of pesticides or fertilizers, soil
compaction from heavy equipment, or erosion of topsoil, eventually resulting in
reduced ability to produce agricultural products.
soil erosion - the removal of soil by the action of water or wind, compounded
by poor agricultural practices, deforestation, overgrazing, and desertification.
ultraviolet (UV) radiation - a portion of the electromagnetic energy emitted by
the sun and naturally filtered in the upper atmosphere by the ozone layer; UV
radiation can be harmful to living organisms and has been linked to increasing
rates of skin cancer in humans.
water-born diseases - those in which the bacteria survive in, and is transmitted
through, water; always a serious threat in areas with an untreated water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two levels ■ party to
and signed but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements: This information is presented in Appendix C:
Selected International Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups starting with
the largest and normally includes the percent of total population.
Exchange rates: This entry provides the official value of a country''s monetary unit
at a given date or over a given period of time, as expressed in units of local currency
per US dollar and as determined by international market forces or official fiat.
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government. Head of government includes the name and title of
the top administrative leader who is designated to manage the day-to-day
activities of the government. For example, in the UK, the monarch is the chief of
state, and the prime minister is the head of government. In the US, the president
is both the chief of state and the head of government. CaWnef includes the official
name for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession to power,
date of the last election, and date of the next election. Election results includes the
percent of vote for each candidate in the last election.
Notes and Definitions (continued)
Exports: This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports - commodities; This entry provides a rank ordering of exported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Exports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Fiscal year: This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but which may
begin in any month. All yearly references are for the calendar year (CY) unless
indicated as a noncalendar fiscal year (FY).
Flag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile. The flag graphics were produced from actual flags or the
best information available at the time of preparation. The flags of independent
states are used by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. GDP dollar estimates in the
Factbook are derived from purchasing power parity (PPP) calculations. See the
note on GDP methodology for more information.
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method involves
the use of standardized international dollar price weights, which are applied to the
quantities of final goods and services produced in a given economy. The data
derived from the PPP method provide the best available starting point for
comparisons of economic strength and well-being between countries. The division
of a GDP estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries are often
rough approximations. Most of the GDP estimates are based on extrapolation of
PPP numbers published by the UN International Comparison Program (UNICP)
and by Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. In contrast, the currency exchange rate
method involves a variety of international and domestic financial forces that often
have little relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically one-fourth to
one-half the PPP estimate. Furthermore, exchange rates may suddenly go up or
down by 1 0% or more because of market forces or official fiat whereas real output
has remained unchanged. On 12 January 1994, for example, the 14 countries of
the African Financial Community (whose currencies are tied to the French franc)
devalued their currencies by 50%. This move, of course, did not cut the real output
of these countries by half. One important caution: the proportion of, say, defense
XV
ri
Notes and Definitions (continued)
expenditures as a percentage of GDP in local currency accounts may differ
substantially from the proportion when GDP accounts are expressed in PPP
terms, as, for example, when an observer tries to estimate the dollar level of
Russian or Japanese military expenditures. Note: the numbers for GDP and other
economic data can not be chained together from successive volumes of the
Factooo/c because of changes in the US dollar measuring rod, revisions of data by
statistical agencies, use of new or different sources of information, and changes in
national statistical methods and practices.
GDP ■ composition by sector: This entry gives the percentage contribution of ''
agriculture, industry, and services to total GDP
GDP - per capita: This entry shows GDP on a purchasing power parity basis
divided by population as of 1 July for the same year.
GDP - real growth rate: This entry gives GDP growth on an annual basis adjusted
for inflation and expressed as a percent.
Geographic coordinates: This entry includes rounded latitude and longitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the Gazetteer of Conventional Names, Third Edition, August 1 988,
US Board on Geographic Names and on other sources.
Geographic names: This information is presented in Appendix F:
Cross-Reference List of Geographic Names. It includes a listing of various
alternate names, former names, local names, and regional names referenced to
one or more related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
GNP: Gross national product (GNP) is the value of all final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad, (
minus income earned by foreigners from domestic production. The Factbook,
following current practice, uses GDP rather than GNP to measure national
production. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to national well-being. I
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.g., republic,
constitutional monarchy, federal republic, parliamentary democracy, military
dictatorship).
Government - note: This entry includes miscellaneous government information
of significance not included elsewhere. i
Gross domestic product: see GDP
Gross national product: see GNP
XVI
Notes and Definitions (continued)
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of established helicopter takeoff and
landing sites (which may or may not have fuel or other services).
Highways: This entry includes the tofa/ length of the highway system as well as
the length of the paved and unpaved components.
HIV/AIDS - adult prevalence rate: This entry gives an estimate of the percentage
of adults (aged 1 5-49) living with HIV/AIDS. The adult prevalence rate is calculated
by dividing the estimated number of adults living with HiV/AIDS at yearend by the
total adult population at yearend.
HIV/AIDS - deaths: This entry gives an estimate of the number of adults and
children who died of AIDS during a given calendar year.
HIV/AIDS - people living with HIV/AIDS: This entry gives an estimate of all
people (adults and children) alive at yearend with HIV infection, whether or not
they have developed symptoms of AIDS.
Household Income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted for
household size. Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a more unequal
distribution than surveys based on consumption. The quality of surveys is
improving with time, yet caution is still necessary in making inter-country
comparisons.
Hydrographic data codes: see Data codes
Illicit drugs: This entry gives information on the five categories of illicit drugs -
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which
comes from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional,
or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Notes and Definitions (continued)
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(POP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaf of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia and Africa.
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine. (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature, dried opium
poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
ephedrine, ecstasy (clarity, essence, doctor, Adam), phenmetrazine (Preludin),
methylphenidate (Ritalin), and others (Cylert, Sanorex, Tenuate).
Imports: This entry provides the total US dollar amount of imports on a c.i.f. (cost,
insurance, and freight) or f.o.b. (free on board) basis.
Imports - commodities: This entry provides a rank ordering of imported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Imports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Independence: For most countries, this entry gives the date that sovereignty was
achieved and from which nation, empire, or trusteeship. For the other countries,
the date given may not represent "independence" in the strict sense, but rather
some significant nationhood event such as the traditional founding date or the date
of unification, federation, confederation, establishment, fundamental change in the
form of government, or state succession. Dependent areas include the notation
"none" followed by the nature of their dependency status. Also see the
Terminology note.
xviii
Notes and Definitions (continued)
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and
construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1,000 live births in the same year. This rate is often
used as an indicator of the level of health in a country.
Inflation rate (consumer prices): This entry furnishes the annual percent change
in consumer prices compared with the previous year’s consumer prices.
Internet country code: This entry includes the two-letter codes maintained by the
International Organization for Standardization (ISO) in the ISO 3166 Alpha''2 list
and used by the Internet Assigned Numbers Authority (lANA) to establish
country-coded top-level domains (ccTLDs).
Internet Service Providers (ISPs): This entry supplies the number of Internet
Service Providers within a country. An ISP is defined as a company that provides
access to the Internet.
Internet users: This entry gives the number of users within a country that access
the Internet. Statistics vary from country to country and may include users who
access the Internet at least several times a week to those who access it only once
within a period of several months.
International disputes: see Disputes - internationai
International or','4ceb0e630231594fb9a72c08cb6c9e505f910d0146aac9521853834c2b96aa44','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f929da4ce30762e9a73799f2751a2cd1985f46e140f975f1b551a62691806e77',2001,'EH','Western Sahara','raw',6,'ganization participation: This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
International organizations: This information is presented in Appendix B:
International Organizations and Groups which includes the name, abbreviation,
date established, aim, and members by category.
Introduction: This category includes one entry. Background.
Irrigated land: This entry gives the number of square kilometers of land area that
is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry contains a rank ordering of component
parts of the labor force by occupation.
Land boundaries: This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries.
Land use: This entry contains the percentage shares of total land area for five
different types of land use: arable land’ land cultivated for crops that are replanted
after each harvest like wheat, maize, and rice; permanent crops - land cultivated
Notes and Definitions (continued)
for crops that are not replanted after each harvest like citrus, coffee, and rubber;
permanent pastures - land permanently used for herbaceous forage crops; forests
and woodland- land under dense or open stands of trees; other- any land type
not specifically mentioned above, such as urban areas, roads, desert, etc.
Languages: This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system''s
historical roots, role in government, and acceptance of International Court of
Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and term of office. Elections
includes the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as indicating the potential return on Investment In human capital and is necessary
for the calculation of various actuarial measures.
Literacy: This entry Includes a definition of literacy and Census Bureau
percentages for the total population, males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition - the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
Location: This entry identifies the country''s regional location, neighboring
countries, and adjacent bodies of water.
Map references: This entry includes the name of the Factbook reference map on
which a country may be found. The entry on Geographic coordinates may be
helpful in finding some smaller countries.
Maritime claims: This entry includes the following claims: contiguous zone,
continental shelf, exclusive economic zone, exclusive fishing zone, extended
fishing zone, none (usually for a landlocked country), other (unique maritime
claims like Libya’s Gulf of Sidra Closing Line or North Korea’s Military Boundary
Line), and territorial sea. The proximity of neighboring states may prevent some
national claims from being extended the full distance.
Merchant marine: Merchant marine may be defined as all ships engaged in the
carriage of goods; or all commercial vessels (as opposed to all nonmilitary ships),
which excludes tugs, fishing vessels, offshore oil rigs, etc.; or a grouping of
XX
Notes and Definitions (continued)
merchant ships by nationality or register. This entry contains information in two
subfields - total an(j ships by type. Tofa/ includes the total number of ships (1,000
GRT or over), total DWT for those ships, and total GRT for those ships. DWT or
dead weight tonnage is the total weight of cargo, plus bunkers, stores, etc. that a
ship can carry when immersed to the appropriate load line. GRT or gross register
tonnage is a figure obtained by measuring the entire sheltered volume of the ship
available for cargo and passengers and converting it to tons on the basis of 100
cubic feet per ton; there is no stable relationship between GRT and DWT. Ships by
type includes a listing of barge carriers, bulk cargo ships, cargo ships, chemical
tankers, combination bulk carriers, combination ore/oil carriers, container ships,
liquefied gas tankers, livestock carriers, multifunctional large-load carriers,
petroleum tankers, passenger ships, passenger/cargo ships, railcar carriers,
refrigerated cargo ships, roll-on/roll-off cargo ships, short-sea passenger ships,
specialized tankers, and vehicle carriers.
A captive register Is a register of ships maintained by a territory, possession,
or colony primarily or exclusively for the use of ships owned in the parent country;
it is also referred to as an offshore register, the offshore equivalent of an internal
register. Ships on a captive register will fly the same flag as the parent country, or
a local variant of it, but will be subject to the maritime laws and taxation rules of
the offshore territory. Although the nature of a captive register makes it especially
desirable for ships owned in the parent country, just as in the Internal register, the
ships may also be owned abroad. The captive register then acts as a flag of
convenience register, except that it is not the register of an independent state.
A flag of convenience register is a national register offering registration to a
merchant ship not owned in the flag state. The major flags of convenience (FOC)
attract ships to their registers by virtue of low fees, low or nonexistent taxation of
profits, and liberal manning requirements. True FOC registers are characterized by
having relatively few of the registered ships actually owned in the flag state. Thus,
while virtually any flag can be used for ships under a given set of circumstances,
an FOC register is one where the majority of the merchant fleet is owned abroad.
It is also referred to as an open register.
A flag state is the nation in which a ship is registered and which holds legal
jurisdiction over operation of the ship, whether at home or abroad. Maritime
legislation of the flag state determines how a ship is crewed and taxed and
whether a foreign-owned ship may be placed on the register.
An Internal register is a register of ships maintained as a subset of a national
register. Ships on the internal register fly the national flag and have that nationality
but are subject to a separate set of maritime rules from those on the main national
register. These differences usually Include lower taxation of profits, use of foreign
nationals as crewmembers, and, usually, ownership outside the flag state (when it
functions as an FOC register). The Norwegian International Ship Register and
Danish International Ship Register are the most notable examples of an internal
register. Both have been instrumental in stemming flight from the national flag to
flags of convenience and in attracting foreign-owned ships to the Norwegian and
Danish flags.
A merchant ship is a vessel that carries goods against payment of freight; it is
commonly used to denote any nonmilitary ship but accurately restricted to
commercial vessels only.
A register Is the record of a ship''s ownership and nationality as listed with the
maritime authorities of a country; also, it is the compendium of such individual
ships'' registrations. Registration of a ship provides it with a nationality and makes
it subject to the laws of the country in which registered (the flag state) regardless
of the nationality of the ship''s ultimate owner.
XXI
Notes and Definitions (continued)
Military: This category includes the entries dealing with a country''s military
structure, manpower, and expenditures.
Military branches; This entry lists the names of the ground, naval, air, marine,
and other defense or security forces.
Military expenditures - dollar figure: This entry gives current military
expenditures in US dollars; the figure is calculated by multiplying the estimated
defense spending in percentage terms by the gross domestic product (GDP)
calculated on an exchange rate basis nof purchasing power parity (PPP) terms.
However, in the case of Russia, estimates of military expenditures have been
made using PPP. Dollar figures for military expenditures should be treated with
caution because of different price patterns and accounting methods among
nations, as well as wide variations in the strength of their currencies.
Military expenditures - percent of GDP; This entry gives current military
expenditures as an estimated percent of gross domestic product (GDP).
Military manpower ■ availability: This entry gives the total numbers of males and
females age 15-49 and assumes that every individual is fit to serve.
Military manpower - fit for military service: This entry gives the number of
males and females age 15-49 fit for military service. This is a more refined
measure of potential military manpower availability which tries to correct for the
health situation in the country and reduces the maximum potential number to a
more realistic estimate of the actual number fit to serve.
Military manpower - military age: This entry gives the minimum age at which an
individual may volunteer for military service or be subject to conscription.
Military manpower - reaching military age annually: This entry gives the
number of draft-age males and females entering the military manpower pool in any
given year and is a measure of the availability of draft-age young adults.
Military - note: This entry includes miscellaneous military information of
significance not included elsewhere.
Money figures: All money figures are expressed in contemporaneous US dollars
unless otherwise indicated.
National holiday: This entry gives the primary national day of celebration - usually
independence day.
Nationality: This entry provides the identifying terms for citizens - noun and
acf/ecf/Ve.
Natural hazards: This entry lists potential natural disasters.
Natural resources: This entry lists a country''s mineral, petroleum, hydropower,
and other resources of commercial importance.
Net migration rate: This entry includes the figure for the difference between the
number of persons entering and leaving a country during the year per 1 ,000
persons (based on midyear population). An excess of persons entering the
country is referred to as net immigration (e.g., 3.56 migrants/1 ,000 population): an
Notes and Definitions (continued)
excess of persons leaving the country as net emigration (e.g., -9.26 migrants/
1 ,000 population). The net migration rate indicates the contribution of migration to
the overall level of population change. High levels of migration can cause problems
such as increasing unemployment and potential ethnic strife (if people are coming
in) or a reduction in the labor force, perhaps in certain key sectors (if people are
leaving).
People: This category includes the entries dealing with the characteristics of the
people and their society.
People - note: This entry includes miscellaneous demographic information of
significance not included elsewhere.
Personal Names - Capitalization: The Facfboo/c capitalizes the surname or
family name of individuals for the convenience of our users who are faced with a
world of different cultures and naming conventions. An example would be
President SADDAM Husayn of Iraq. Saddam is his name and Husayn is his
father''s name. He may be referred to as President SADDAM Husayn or President
SADDAM, but not President Husayn. The need for capitalization, bold type,
underlining, italics, or some other indicator of the individual''s surname is apparent
in the following examples: MAO Zedong, Fidel CASTRO Ruz, George W. BUSH,
and TUNKU SALAHUDDIN Abdul Aziz Shah ibni Al-Marhum Sultan Hisammuddin
Alam Shah. By knowing the surname, a short form without all capital letters can
be used with confidence as in President Saddam, President Castro, Chairman
Mao, President Bush, or Sultan Tunku Salahuddin. The same system of
capitalization is extended to the names of leaders with surnames that are not
commonly used such as Queen ELIZABETH II.
Personal Names - Spelling: The romanization of personal names in the Factbook
normally follows the same transliteration system used by the US Board on
Geographic Names for spelling place names. At times, however, a foreign leader
expressly indicates a preference for, or the media or official documents regularly
use, a romanized spelling that differs from the transliteration derived from the US
Government standard. In such cases, the Factbook uses the alternative spelling.
Personal Names ■ Titles: The Factooo/c capitalizes any valid title (or short form of
it) immediately preceding a person''s name. A title standing alone is lowercased.
Examples: President PUTIN and President BUSH are chiefs of state. In Russia,
the president is chief of state and the premier is the head of the government, while
in the US, the president is both chief of state and head of government.
Pipelines: This entry gives the lengths and types of pipelines for transporting
products like natural gas, crude oil, or petroleum products.
Political parties and leaders: This entry includes a listing of significant political
organizations and their leaders.
Political pressure groups and leaders: This entry includes a listing of
organizations with leaders involved in politics, but not standing for legislative
election.
Population: This entry gives an estimate from the US Bureau of the Census
based on statistics from population censuses, vital statistics registration systems,
or sample surveys pertaining to the recent past and on assumptions about future
trends. The total population presents one overall measure of the potential impact
xxiii
Notes and Definitions (continued)
of the country on the world and within its region. Note: starting with the 1993
Factbook, demographic estimates for some countries (mostly African) have
explicitly taken into account the effects of the growing impact of the HIV/AIDS
epidemic. These countries are currently: The Bahamas, Benin, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central African Republic,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Ethiopia,
Gabon, Ghana, Guyana, Haiti, Honduras, Kenya, Lesotho, Malawi, Mozambique,
Namibia, Nigeria, Rwanda, South Africa, Swaziland, Tanzania, Thailand, Togo,
Uganda, Zambia, and Zimbabwe.
Population below poverty line: National estimates of the percentage of the
population lying below the poverty line are based on surveys of sub-groups, with
the results weighted by the number of people in each group. Definitions of poverty
vary considerably among nations. For example, rich nations generally employ
more generous standards of poverty than poor nations.
Population growth rate: The average annual percent change in the population,
resulting from a surplus (or deficit) of births over deaths and the balance of
migrants entering and leaving a country. The rate may be positive or negative. The
growth rate is a factor in determining how great a burden would be imposed on a
country by the changing needs of its people for infrastructure (e.g., schools,
hospitals, housing, roads), resources (e.g., food, water, electricity), and jobs.
Rapid population growth can be seen as threatening by neighboring countries.
Ports and harbors: This entry lists the major ports and harbors selected on the
basis of overall importance to each country. This is determined by evaluating a
number of factors (e.g., dollar value of goods handled, gross tonnage, facilities,
military significance).
Radio broadcast stations: This entry includes the total number of AM, FM, and
shortwave broadcast stations.
Radios: This entry gives the total number of radio receivers.
Railways: This entry includes the total route length of the railway network and of
its component parts by gauge: broad, dual, narrow, standard, and other.
Reference maps: This section includes world, regional, and special or current
interest maps.
Religions: This entry includes a rank ordering of religions by adherents starting
with the largest group and sometimes Includes the percent of total population.
Sex ratio: This entry includes the number of males for each female in five age
groups - at birth, under 15 years, 15-64 years, 65 years and over, and for the total
population. Sex ratio at birth has recently emerged as an indicator of certain kinds
of sex discrimination in some countries. For instance, high sex ratios at birth in
some Asian countries are now attributed to sex-selective abortion and infanticide
due to a strong preference for sons. This will affect future marriage patterns and
fertility patterns. Eventually it could cause unrest among young adult males who
are unable to find partners.
Suffrage: This entry gives the age at enfranchisement and whether the right to
vote is universal or restricted.
xxiv
Notes and Definitions (continued)
Telephone numbers: All telephone numbers in the Factooo/f consist of the
country code in brackets, the city or area code (where required) in parentheses,
and the local number. The one component that is not presented is the international
access code, which varies from country to country. For example, an international
direct dial telephone call placed from the US to Madrid, Spain, would be as follows:
011 [34] (1)577-xxxx, where
Oil is the international access code for station-to-station calls
(01 is for calls other than station-to-station calls),
[34] is the country code for Spain,
(1) is the city code for Madrid,
577 is the local exchange, and
xxxx is the local telephone number.
An international direct dial telephone call placed from another country to the US
would be as follows:
international access code + [1] (202) 939-xxxx, where
[1] Is the country code for the US,
(202) is the area code for Washington, DC,
939 is the local exchange, and
xxxx is the local telephone number.
Telephone system: This entry includes a brief characterization of the system with
details on the cfomesf/c and /ntemaf/ona/ components. The following terms and
abbreviations are used throughout the entry:
Africa ONE - a fiber-optic submarine cable link encircling the continent of
Africa.
Arabsat - Arab Satellite Communications Organization (Riyadh, Saudi Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen’s band mobile radio communications,
cellular telephone system - the telephones in this system are radio
transceivers, with each instrument having its own private radio frequency and
sufficient radiated power to reach the booster station in Its area (cell), from which
the telephone signal is fed to a regular telephone exchange.
Central American Microwave System ■ a trunk microwave radio relay system
that links the countries of Central America and Mexico with each other.
coaxial cable - a multichannel communication cable consisting of a centra!
conducting wire, surrounded by and insulated from a cylindrical conducting shell;
a large number of telephone channels can be made available within the insulated
space by the use of a large number of carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network or
Autovon): basic general-purpose, switched voice network of the Defense
Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization (Paris),
fiber-optic cable - a multichannel communications cable using a thread of
optical glass fibers as a transmission medium in which the signal (voice, video,
etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised by the
Groupe Special Mobile of the pan-European standardization organization.
Conference Europeanne des Posts et Telecommunications (CEPT) in 1982.
HF - high frequency; any radio frequency in the 3,000- to 30,000-kHz range.
Inmarsat - International Mobile Satellite Organization (London); provider of
global mobile satellite communications for commercial, distress, and safety
applications at sea, in the air, and on land.
XXV
Notes and Definitions (continued)
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - international Organization of Space Communications (Moscow);
first established in the former Soviet Union and the East European countries, it is
now marketing its services worldwide with earth stations in North America, Africa,
and East Asia.
landline - communication wire or cable of any sort that is installed on poles or
buried in the ground.
Marecs - Maritime European Communications Satellite used in the Inmarsat
system on lease from the European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in the Inmarsat
system.
Medarabtei - the Middle East Telecommunications Project of the International
Telecommunications Union (ITU) providing a modern telecommunications
network, primarily by microwave radio relay, linking Algeria, Djibouti, Egypt,
Jordan, Libya, Morocco, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, and
Yemen; it was initially started in Morocco in 1 970 by the Arab Telecommunications
Union (ATU) and was known at that time as the Middle East Mediterranean
Telecommunications Network.
microwave radio relay - transmission of long distance telephone calls and
television programs by highly directional radio microwaves that are received and
sent on from one booster station to another on an optical path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system that was
developed jointly by the national telecommunications authorities of the Nordic
countries (Denmark, Finland, Iceland, Norway, and Sweden).
Orbita - a Russian television service; also the trade name of a packet-switched
digital telephone network.
radiotelephone communications - the two-way transmission and reception of
sounds by broadcast radio on authorized frequencies using telephone handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
satellite communication system - a communication system consisting of two or
more earth stations and at least one satellite that provide long distance
transmission of voice, data, and television: the system usually serves as a trunk
connection between telephone exchanges; if the earth stations are in the same
country, it is a domestic system.
satellite earth station - a communications facility with a microwave radio
transmitting and receiving antenna and required receiving and transmitting
equipment for communicating with satellites.
satellite link - a radio connection between a satellite and an earth station
permitting communi','91c7859a5e623c0382522235ea26afe0eb9c2e1a0058ed5428423be9983e7bd2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4413e109446cfb3f87395ad833b36385b7763dbd7005dbb68aca8abb3055b0c6',2001,'EH','Western Sahara','raw',7,'cation between them, either one-way (down link from satellite
to earth station - television receive-only transmission) or two-way (telephone
channels).
SHF - super high frequency; any radio frequency in the 3,000- to 30,000-MHz
range.
shortwave - radio frequencies (from 1 .605 to 30 MHz) that fall above the
commercial broadcast band and are used for communication over long distances.
Solidaridad - geosynchronous satellites in Mexico''s system of international
telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite telecommunications.
submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity submarine
coaxial telephone cables linking Europe with North America.
telefax - facsimile service between subscriber stations via the public switched
telephone network or the international Datel network.
Notes and Definitions (continued)
telegraph - a telecommunications system designed for unmodulated electric
impulse transmission.
telex - a communication service involving teletypewriters connected by wire
through automatic exchanges.
tropospheric scatter - a form of microwave radio transmission in which the
troposphere is used to scatter and reflect a fraction of the incident radio waves
back to earth; powerful, highly directional antennas are used to transmit and
receive the microwave signals; reliable over-the-horizon communications are
realized for distances up to 600 miles in a single hop; additional hops can extend
the range of this system for very long distances.
trunk network - a network of switching centers, connected by multichannel
trunk lines.
UHF - ultra high frequency; any radio frequency in the 300- to 3,000-MHz
range.
VHF - very high frequency; any radio frequency in the 30- to 300-MHz range.
Telephones - main lines in use: This entry gives the total number of main
telephone lines in use.
Telephones - mobile cellular: This entry gives the total number of mobile cellular
telephones in use.
Television - broadcast stations: This entry gives the total number of separate
broadcast stations plus any repeater stations.
Televisions: This entry gives the total number of television sets.
Terminology: Due to the highly structured nature of the Factooo/c database, some
collective generic terms have to be used. For example, the word Country in the
Country name entry refers to a wide variety of dependencies, areas of special
sovereignty, uninhabited islands, and other entities in addition to the traditional
countries or independent states. Military is also used as an umbrella term for
various civil defense, security, and defense activities in many entries. The
Independence entry includes the usual colonial independence dates and former
ruling states as well as other significant nationhood dates such as the traditional
founding date or the date of unification, federation, confederation, establishment,
or state succession that are not strictly independence dates. Dependent areas
have the nature of their dependency status noted in this same entry.
Terrain: This entry contains a brief description of the topography.
Total fertility rate: This entry gives a figure for the average number of children that
would be born per woman if all women lived to the end of their childbearing years
and bore children according to a given fertility rate at each age. The total fertility
rate is a more direct measure of the level of fertility than the crude birth rate, since
it refers to births per woman. This indicator shows the potential for population
growth in the country. High rates will also place some limits on the labor force
participation rates for women. Large numbers of children born to women indicate
large family sizes that might limit the ability of the families to feed and educate their
children.
Transnational Issues: This category includes only two entries at the present
time - Disputes - International and Illicit drugs - that deal with current issues
going beyond national boundaries.
Notes and Definitions (continued)
Transportation: This category includes the entries dealing with the means for
movement of people and goods.
Transportation - note: This entry includes miscellaneous transportation
information of significance not included elsewhere.
Unemployment rate: This entry contains the percent of the labor force that is
without jobs. Substantial underemployment might be noted.
Waterways: This entry gives the total length and Individual names of navigable
rivers, canals, and other inland bodies of water.
Years: All year references are for the calendar year (CY) unless indicated as fiscal
year (FY). The calendar year is an accounting period of 12 months from 1 January
to 31 December. The fiscal year is an accounting period of 12 months other than
1 January to 31 December.
xxviii
Guide to Country Profiles ( categories , Fields, and suMe/ds)','19cf0bfc4f30579f66a2b1d0b5027ef93fb01f10c25a403aaa19ebfcf086ea4a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d14870e8e68154dc9c4e9e0ceb944b75b82726afa5f9e1bb5438a8d0712b7fc5',2001,'ZW','Zimbabwe','raw',8,'563
Taiwan
565
IV
Appendixes A: Abbreviations _ _ _ _ _ ^
B: International Organizations and Groups _ ^
C: Selected International Environmental Agreements _ ^
D: Cross-Reference List of Country Data Codes 618
E: Cross-Reference List of Hydrographic Data Codes _ ^
F: Cross-Reference List of Geographic Names ^
Reference Maps Africa _
Antarctic Region
Arctic Region
Asia
Central Africa
Central America and the Caribbean
Central Balkan Region
Commonwealth of Independent States
Europe
Kosovo
Middle East
North America
Oceania
Physical Map of the World
Political Map of the World
South America
Southeast Asia
Standard Time Zones of the World
OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island and McDonald Islands, Norfolk
Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island, French
Guiana, French Polynesia, French Southern and Antarctic Lands, Glorioso
Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New
Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island, Wallis
and Futuna
XI
Notes and Definitions (continued)
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
15 UK - Anguilla, Bermuda, British Indian Ocean Territory, British Virgin
Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey, Jersey,
Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South Georgia and
the South Sandwich Islands, Turks and Caicos Islands
14 US - American Samoa, Baker Island, Guam, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island, Northern
Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands, Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','b00fab99aed6d23448ef7f2c1a262986e443c96815ed5e581863672e225fa6c7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('345708e45730cf1bde0a32a05dfa81def5948642b48a9ebee277f23477041374',2001,'','','raw',1,'The Project Gutenberg EBook of The 2001 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2001 CIA World Factbook
Author: United States. Central Intelligence Agency.
Release Date: December 27, 2008 [EBook #27638]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2001 CIA WORLD FACTBOOK ***
Produced by Al Haines
THE CIA WORLD FACTBOOK 2001
CONTENTS
Countries and Locations
Field Listings
Appendixes
Notes and Definitions
History of The World Factbook
Contributors and Copyright Information
Purchasing Information
=====================================================================
In general, information available as of 1 January 2001 was used in
the preparation of The World Factbook 2001.
Selected data and maps in The World Factbook are updated periodically.
=====================================================================
Country Listing
[Transcriber''s note: To search on a country name in this file, prefix
the name with "@", e.g. "@Afghanistan". "Afghanistan" will find all
occurrences; prefixing it with "@" will find the correct location.]
A','2214dfbbf03e5d3b84a2f4dbf45be6a77ec7b6e5889667d084ad32b1fd1f598f','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ed8ba8baa555126cbfbf1a2fafbd12ac509799ab1fc590ddca6fbf17b8e6f63',2001,'ZW','Zimbabwe','raw',2,'Taiwan
=====================================================================
Field Listings
[Transcriber''s note: To search on a field code in this file, prefix
the code number with "@", e.g. "@Airports". "Airports" will find all
occurrences; prefixing it with "@" will find the correct location.]
Field Description
Administrative divisions
Age structure
Agriculture - products
Airports
Airports - with paved runways
Airports - with unpaved runways
Area
Area - comparative','0c16d3d9b176b23afa5848585826773379c90e40ee018b2c134145c11ce95870','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

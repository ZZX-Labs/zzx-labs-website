SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeab899f1a4c9e32f8dd55d558b9451403959fdf9fcd9bee3140c8939d649922',2001,'AU','Australia','space',269,'Bhutan:
soil erosion; limited access to potable water
Bolivia:
the clearing of land for agricultural purposes and the
international demand for tropical timber are contributing to
deforestation; soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture); desertification;
loss of biodiversity; industrial pollution of water supplies used
for drinking and irrigation
Bosnia and Herzegovina:
air pollution from metallurgical plants;
sites for disposing of urban waste are limited; water shortages and
destruction of infrastructure because of the 1992-95 civil strife
Botswana:
overgrazing; desertification; limited fresh water resources
Bouvet Island:
NA
Brazil:
deforestation in Amazon Basin destroys the habitat and
endangers the existence of a multitude of plant and animal species
indigenous to the area; air and water pollution in Rio de Janeiro,
Sao Paulo, and several other large cities; land degradation and
water pollution caused by improper mining activities
note: President CARDOSO in September 1999 signed into force an
environmental crime bill which for the first time defines pollution
and deforestation as crimes punishable by stiff fines and jail
sentences
British Indian Ocean Territory:
NA
British Virgin Islands:
limited natural fresh water resources
(except for a few seasonal streams and springs on Tortola, most of
the islands'' water supply comes from wells and rainwater catchment)
Brunei:
seasonal smoke/haze resulting from forest fires in Indonesia
Bulgaria:
air pollution from industrial emissions; rivers polluted
from raw sewage, heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical plants and
industrial wastes
Burkina Faso:
recent droughts and desertification severely affecting
agricultural activities, population distribution, and the economy;
overgrazing; soil degradation; deforestation
Burma:
deforestation; industrial pollution of air, soil, and water;
inadequate sanitation and water treatment contribute to disease
Burundi:
soil erosion as a result of overgrazing and the expansion
of agriculture into marginal lands; deforestation (little forested
land remains because of uncontrolled cutting of trees for fuel);
habitat loss threatens wildlife populations
Cambodia:
illegal logging activities throughout the country and
strip mining for gems in the western region along the border with
Thailand have resulted in habitat loss and declining biodiversity
(in particular, destruction of mangrove swamps threatens natural
fisheries); soil erosion; in rural areas, a majority of the
population does not have access to potable water; toxic waste
delivery from Taiwan sparked unrest in Kampong Saom (Sihanoukville)
in December 1998
Cameroon:
water-borne diseases are prevalent; deforestation;
overgrazing; desertification; poaching; overfishing
Canada:
air pollution and resulting acid rain severely affecting
lakes and damaging forests; metal smelting, coal-burning utilities,
and vehicle emissions impacting on agricultural and forest
productivity; ocean waters becoming contaminated due to
agricultural, industrial, mining, and forestry activities
Cape Verde:
overgrazing of livestock and improper land use such as
the cultivation of crops on steep slopes has led to soil erosion;
demand for wood used as fuel has resulted in deforestation;
desertification; environmental damage has threatened several species
of birds and reptiles; overfishing
Cayman Islands:
no natural fresh water resources; drinking water
supplies must be met by rainwater catchment
Central African Republic:
tap water is not potable; poaching has
diminished its reputation as one of the last great wildlife refuges;
desertification; deforestation
Chad:
inadequate supplies of potable water; improper waste disposal
in rural areas contributes to soil and water pollution;
desertification
Chile:
air pollution from industrial and vehicle emissions; water
pollution from raw sewage
China:
air pollution (greenhouse gases, sulfur dioxide particulates)
from reliance on coal, produces acid rain; water shortages,
particularly in the north; water pollution from untreated wastes;
deforestation; estimated loss of one-fifth of agricultural land
since 1949 to soil erosion and economic development;
desertification; trade in endangered species
Christmas Island:
NA
Clipperton Island:
NA
Cocos (Keeling) Islands:
fresh water resources are limited to
rainwater accumulations in natural underground reservoirs
Colombia:
deforestation; soil damage from overuse of pesticides; air
pollution, especially in Bogota, from vehicle emissions
Comoros:
soil degradation and erosion results from crop cultivation
on slopes without proper terracing; deforestation
Congo, Democratic Republic of the:
poaching threatens wildlife
populations; water pollution; deforestation; refugees who arrived in
mid-1994 were responsible for significant deforestation, soil
erosion, and wildlife poaching in the eastern part of the country
(most of those refugees were repatriated in November and December
1996)
Congo, Republic of the:
air pollution from vehicle emissions; water
pollution from the dumping of raw sewage; tap water is not potable;
deforestation
Cook Islands:
NA
Coral Sea Islands:
no permanent fresh water resources
Costa Rica:
deforestation and land use change, largely a result of
the clearing of land for cattle ranching and agriculture; soil
erosion; water pollution (rivers); coastal marine pollution;
wetlands degradation; fisheries protection; solid waste management;
air pollution
Cote d''Ivoire:
deforestation (most of the country''s forests - once
the largest in West Africa - have been heavily logged); water
pollution from sewage and industrial and agricultural effluents
Croatia:
air pollution (from metallurgical plants) and resulting
acid rain is damaging the forests; coastal pollution from industrial
and domestic waste; landmine removal and reconstruction of
infrastructure consequent to 1992-95 civil strife
Cuba:
pollution of Havana Bay; overhunting threatens wildlife
populations; deforestation
Cyprus:
water resource problems (no natural reservoir catchments,
seasonal disparity in rainfall, sea water intrusion to island''s
largest aquifer, increased salination in the north); water pollution
from sewage and industrial wastes; coastal degradation; loss of
wildlife habitats from urbanization
Czech Republic:
air and water pollution in areas of northwest
Bohemia and in northern Moravia around Ostrava present health risks;
acid rain damaging forests
Denmark:
air pollution, principally from vehicle and power plant
emissions; nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from animal wastes and
pesticides
Djibouti:
inadequate supplies of potable water; desertification
Dominica:
NA
Dominican Republic:
water shortages; soil eroding into the sea
damages coral reefs; deforestation; Hurricane Georges damage
Ecuador:
deforestation; soil erosion; desertification; water
pollution; pollution from oil production wastes
Egypt:
agricultural land being lost to urbanization and windblown
sands; increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs, beaches, and
marine habitats; other water pollution from agricultural pesticides,
raw sewage, and industrial effluents; very limited natural fresh
water resources away from the Nile which is the only perennial water
source; rapid growth in population overstraining natural resources
El Salvador:
deforestation; soil erosion; water pollution;
contamination of soils from disposal of toxic wastes; Hurricane
Mitch damage
Equatorial Guinea:
tap water is not potable; desertification
Eritrea:
deforestation; desertification; soil erosion; overgrazing;
loss of infrastructure from civil warfare
Estonia:
air heavily polluted with sulfur dioxide from oil-shale
burning power plants in northeast; contamination of soil and
groundwater with petroleum products, chemicals at former Soviet
military bases; Estonia has more than 1,400 natural and manmade
lakes, the smaller of which in agricultural areas are heavily
affected by organic waste; coastal sea water is polluted in many
locations
Ethiopia:
deforestation; overgrazing; soil erosion; desertification
Europa Island:
NA
Falkland Islands (Islas Malvinas):
NA
Faroe Islands:
NA
Fiji:
deforestation; soil erosion
Finland:
air pollution from manufacturing and power plants
contributing to acid rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife populations
France:
some forest damage from acid rain (major forest damage
occurred as a result of severe December 1999 windstorm); air
pollution from industrial and vehicle emissions; water pollution
from urban wastes, agricultural runoff
French Guiana:
NA
French Polynesia:
NA
French Southern and Antarctic Lands:
NA
Gabon:
deforestation; poaching
Gambia, The:
deforestation; desertification; water-borne diseases
prevalent
Gaza Strip:
desertification; salination of fresh water; sewage
treatment; water-borne disease; soil degradation
Georgia:
air pollution, particularly in Rust''avi; heavy pollution of
Mtkvari River and the Black Sea; inadequate supplies of potable
water; soil pollution from toxic chemicals
Germany:
emissions from coal-burning utilities and industries
contribute to air pollution; acid rain, resulting from sulfur
dioxide emissions, is damaging forests; pollution in the Baltic Sea
from raw sewage and industrial effluents from rivers in eastern
Germany; hazardous waste disposal; government currently attempting
to define mechanism for ending the use of nuclear power; government
working to meet EU commitment to identify nature preservation areas
in line with the EU''s Flora, Fauna, and Habitat directive
Ghana:
recent drought in north severely affecting agricultural
activities; deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations; water pollution;
inadequate supplies of potable water
Gibraltar:
limited natural freshwater resources; large concrete or
natural rock water catchments collect rainwater
Glorioso Islands:
NA
Greece:
air pollution; water pollution
Greenland:
protection of the arctic environment; preservation of the
Inuit traditional way of life, including whaling and seal hunting
Grenada:
NA
Guadeloupe:
NA
Guam:
extirpation of native bird population by the rapid
proliferation of the brown tree snake, an exotic species
Guatemala:
deforestation; soil erosion; water pollution; Hurricane
Mitch damage
Guernsey:
NA
Guinea:
deforestation; inadequate supplies of potable water;
desertification; soil contamination and erosion; overfishing,
overpopulation in forest region
Guinea-Bissau:
deforestation; soil erosion; overgrazing; overfishing
Guyana:
water pollution from sewage and agricultural and industrial
chemicals; deforestation
Haiti:
extensive deforestation (much of the remaining forested land
is being cleared for agriculture and used as fuel); soil erosion;
inadequate supplies of potable water
Heard Island and McDonald Islands:
NA
Holy See (Vatican City):
NA
Honduras:
urban population expanding; deforestation results from
logging and the clearing of land for agricultural purposes; further
land degradation and soil erosion hastened by uncontrolled
development and improper land use practices such as farming of
marginal lands; mining activities polluting Lago de Yojoa (the
country''s largest source of fresh water) as well as several rivers
and streams with heavy metals; severe Hurricane Mitch damage
Hong Kong:
air and water pollution from rapid urbanization
Howland Island:
no natural fresh water resources
Hungary:
the approximation of Hungary''s standards in waste
management, energy efficiency, and air, soil, and water pollution
with environmental requirements for EU accession will require large
investments
Iceland:
water pollution from fertilizer runoff; inadequate
wastewater treatment
India:
deforestation; soil erosion; overgrazing; desertification;
air pollution from industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural pesticides; tap
water is not potable throughout the country; huge and growing
population is overstraining natural resources
Indian Ocean:
endangered marine species include the dugong, seals,
turtles, and whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
Indonesia:
deforestation; water pollution from industrial wastes,
sewage; air pollution in urban areas; smoke and haze from forest
fires
Iran:
air pollution, especially in urban areas, from vehicle
emissions, refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution in the
Persian Gulf; inadequate supplies of potable water
Iraq:
government water control projects have drained most of the
inhabited marsh areas east of An Nasiriyah by drying up or diverting
the feeder streams and rivers; a once sizable population of Shi''a
Muslims, who have inhabited these areas for thousands of years, has
been displaced; furthermore, the destruction of the natural habitat
poses serious threats to the area''s wildlife populations; inadequate
supplies of potable water; development of Tigris-Euphrates Rivers
system contingent upon agreements with upstream riparian Turkey; air
and water pollution; soil degradation (salination) and erosion;
desertification
Ireland:
water pollution, especially of lakes, from agricultural
runoff
Israel:
limited arable land and natural fresh water resources pose
serious constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from industrial and
domestic waste, chemical fertilizers, and pesticides
Italy:
air pollution from industrial emissions such as sulfur
dioxide; coastal and inland rivers polluted from industrial and
agricultural effluents; acid rain damaging lakes; inadequate
industrial waste treatment and disposal facilities
Jamaica:
heavy rates of deforestation; coastal waters polluted by
industrial waste, sewage, and oil spills; damage to coral reefs; air
pollution in Kingston results from vehicle emissions
Jan Mayen:
NA
Japan:
air pollution from power plant emissions results in acid
rain; acidification of lakes and reservoirs degrading water quality
and threatening aquatic life; Japan is one of the largest consumers
of fish and tropical timber, contributing to the depletion of these
resources in Asia and elsewhere
Jarvis Island:
no natural fresh water resources
Jersey:
NA
Johnston Atoll:
no natural fresh water resources
Jordan:
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Juan de Nova Island:
NA
Kazakhstan:
radioactive or toxic chemical sites associated with its
former defense industries and test ranges are found throughout the
country and pose health risks for humans and animals; industrial
pollution is severe in some cities; because the two main rivers
which flowed into the Aral Sea have been diverted for irrigation, it
is drying up and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are then picked up by
the wind and blown into noxious dust storms; pollution in the
Caspian Sea; soil pollution from overuse of agricultural chemicals
and salination from poor infrastructure and wasteful irrigation
practices
Kenya:
water pollution from urban and industrial wastes; degradation
of water quality from increased use of pesticides and fertilizers;
water hyacinth infestation in Lake Victoria; deforestation; soil
erosion; desertification; poaching
Kingman Reef:
none
Kiribati:
heavy pollution in lagoon of south Tarawa atoll due to
heavy migration mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Korea, North:
water pollution; inadequate supplies of potable water;
water-borne disease; deforestation; soil erosion and degradation
Korea, South:
air pollution in large cities; acid rain; water
pollution from the discharge of sewage and industrial effluents;
drift net fishing
Kuwait:
limited natural fresh water resources; some of world''s
largest and most sophisticated desalination facilities provide much
of the water; air and water pollution; desertification
Kyrgyzstan:
water pollution; many people get their water directly
from contaminated streams and wells; as a result, water-borne
diseases are prevalent; increasing soil salinity from faulty
irrigation practices
Laos:
unexploded ordnance; deforestation; soil erosion; a majority
of the population does not have access to potable water
Latvia:
air and water pollution because of a lack of waste
conversion equipment; Gulf of Riga and Daugava River heavily
polluted; contamination of soil and groundwater with chemicals and
petroleum products at military bases
Lebanon:
deforestation; soil erosion; desertification; air pollution
in Beirut from vehicular traffic and the burning of industrial
wastes; pollution of coastal waters from raw sewage and oil spills
Lesotho:
population pressure forcing settlement in marginal areas
results in overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls, stores, and
redirects water to South Africa
Liberia:
tropical rain forest subject to deforestation; soil
erosion; loss of biodiversity; pollution of coastal waters from oil
residue and raw sewage
Libya:
desertification; very limited natural fresh water resources;
the Great Manmade River Project, the largest water development
scheme in the world, is being built to bring water from large
aquifers under the Sahara to coastal cities
Liechtenstein:
NA
Lithuania:
contamination of soil and groundwater with petroleum
products and chemicals at military bases
Luxembourg:
air and water pollution in urban areas, soil pollution
of farmland
Macau:
NA
Macedonia, The Former Yugoslav Republic of:
air pollution from
metallurgical plants
Madagascar:
soil erosion results from deforestation and overgrazing;
desertification; surface water contaminated with raw sewage and
other organic wastes; several species of flora and fauna unique to
the island are endangered
Malawi:
deforestation; land degradation; water pollution from
agricultural runoff, sewage, industrial wastes; siltation of
spawning grounds endangers fish populations
Malaysia:
air pollution from industrial and vehicular emissions;
water pollution from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
Maldives:
depletion of freshwater aquifers threatens water supplies;
global warming and sea level rise; coral reef bleaching
Mali:
deforestation; soil erosion; desertification; inadequate
supplies of potable water; poaching
Malta:
very limited natural fresh water resources; increasing
reliance on desalination
Man, Isle of:
waste disposal (both household and industrial);
transboundary air pollution
Marshall Islands:
inadequate supplies of potable water
Martinique:
NA
Mauritania:
overgrazing, deforestation, and soil erosion aggravated
by drought are contributing to desertification; very limited natural
fresh water resources away from the Senegal which is the only
perennial river
Mauritius:
water pollution, degradation of coral reefs
Mayotte:
NA
Mexico:
natural fresh water resources scarce and polluted in north,
inaccessible and poor quality in center and extreme southeast; raw
sewage and industrial effluents polluting rivers in urban areas;
deforestation; widespread erosion; desertification; serious air
pollution in the national capital and urban centers along US-Mexico
border
Micronesia, Federated States of:
overfishing
Midway Islands:
NA
Moldova:
heavy use of agricultural chemicals, including banned
pesticides such as DDT, has contaminated soil and groundwater;
extensive soil erosion from poor farming methods
Monaco:
NA
Mongolia:
limited natural fresh water resources in some areas;
policies of the former communist regime promoting rapid urbanization
and industrial growth have raised concerns about their negative
effects on the environment; the burning of soft coal in power plants
and the lack of enforcement of environmental laws have severely
polluted the air in Ulaanbaatar; deforestation, overgrazing, the
converting of virgin land to agricultural production have increased
soil erosion from wind and rain; desertification and mining
activities have also had a deleterious effect on the environment
Montserrat:
land erosion occurs on slopes that have been cleared for
cultivation
Morocco:
land degradation/desertification (soil erosion resulting
from farming of marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw sewage; siltation of
reservoirs; oil pollution of coastal waters
Mozambique:
a long civil war and recurrent drought in the
hinterlands have resulted in increased migration of the population
to urban and coastal areas with adverse environmental consequences;
desertification; pollution of surface and coastal waters
Namibia:
very limited natural fresh water resources; desertification
Nauru:
limited natural fresh water resources, roof storage tanks
collect rainwater, but mostly dependent on a single, aging
desalination plant; intensive phosphate mining during the past 90
years - mainly by a UK, Australia, and NZ consortium - has left the
central 90% of Nauru a wasteland and threatens limited remaining
land resources
Navassa Island:
NA
Nepal:
deforestation (overuse of wood for fuel and lack of
alternatives); contaminated water (with human and animal wastes,
agricultural runoff, and industrial effluents); wildlife
conservation; vehicular emissions
Netherlands:
water pollution in the form of heavy metals, organic
compounds, and nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Netherlands Antilles:
NA
New Caledonia:
erosion caused by mining exploitation and forest fires
New Zealand:
deforestation; soil erosion; native flora and fauna
hard-hit by species introduced from outside
Nicaragua:
deforestation; soil erosion; water pollution; Hurricane
Mitch damage
Niger:
overgrazing; soil erosion; deforestation; desertification;
wildlife populations (such as elephant, hippopotamus, giraffe, and
lion) threatened because of poaching and habitat destruction
Nigeria:
soil degradation; rapid deforestation; desertification
Niue:
increasing attention to conservationist practices to counter
loss of soil fertility from traditional slash and burn agriculture
Norfolk Island:
NA
Northern Mariana Islands:
contamination of groundwater on Saipan may
contribute to disease; clean-up of landfill; protection of
endangered species conflicts with development
Norway:
water pollution; acid rain damaging forests and adversely
affecting lakes, threatening fish stocks; air pollution from vehicle
emissions
Oman:
rising soil salinity; beach pollution from oil spills; very
limited natural fresh water resources
Pacific Ocean:
endangered marine species include the dugong, sea
lion, sea otter, seals, turtles, and whales; oil pollution in
Philippine Sea and South China Sea
Pakistan:
water pollution from raw sewage, industrial wastes, and
agricultural runoff; limited natural fresh water resources; a
majority of the population does not have access to potable water;
deforestation; soil erosion; desertification
Palau:
inadequate facilities for disposal of solid waste; threats to
the marine ecosystem from sand and coral dredging, illegal fishing
practices, and overfishing
Palmyra Atoll:
NA
Panama:
water pollution from agricultural runoff threatens fishery
resources; deforestation of tropical rain forest; land degradation
and soil erosion threatens siltation of Panama Canal
Papua New Guinea:
rain forest subject to deforestation as a result
of growing commercial demand for tropical timber; pollution from
mining projects; severe drought
Paracel Islands:
NA
Paraguay:
deforestation (an estim','cfde501b057c5cbcd6749c3253bdce1b8456f0a1a8f2aa87bbf69857d2890469','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2be98fe7728e0787ed90a2743ac54bc428d9d0056b9a72697a19e90018d90e92',2001,'AU','Australia','space',270,'ated 2 million hectares of forest
land were lost from 1958-85); water pollution; inadequate means for
waste disposal present health risks for many urban residents
Peru:
deforestation (some the result of illegal logging);
overgrazing of the slopes of the costa and sierra leading to soil
erosion; desertification; air pollution in Lima; pollution of rivers
and coastal waters from municipal and mining wastes
Philippines:
uncontrolled deforestation in watershed areas; soil
erosion; air and water pollution in Manila; increasing pollution of
coastal mangrove swamps which are important fish breeding grounds
Pitcairn Islands:
deforestation (only a small portion of the
original forest remains because of burning and clearing for
settlement)
Poland:
situation has improved since 1989 due to decline in heavy
industry and increased environmental concern by postcommunist
governments; air pollution nonetheless remains serious because of
sulfur dioxide emissions from coal-fired power plants, and the
resulting acid rain has caused forest damage; water pollution from
industrial and municipal sources is also a problem, as is disposal
of hazardous wastes
Portugal:
soil erosion; air pollution caused by industrial and
vehicle emissions; water pollution, especially in coastal areas
Puerto Rico:
erosion; occasional drought causing water shortages
Qatar:
limited natural fresh water resources are increasing
dependence on large-scale desalination facilities
Reunion:
NA
Romania:
soil erosion and degradation; water pollution; air
pollution in south from industrial effluents; contamination of
Danube delta wetlands
Russia:
air pollution from heavy industry, emissions of coal-fired
electric plants, and transportation in major cities; industrial,
municipal, and agricultural pollution of inland waterways and sea
coasts; deforestation; soil erosion; soil contamination from
improper application of agricultural chemicals; scattered areas of
sometimes intense radioactive contamination; ground water
contamination from toxic waste
Rwanda:
deforestation results from uncontrolled cutting of trees for
fuel; overgrazing; soil exhaustion; soil erosion; widespread poaching
Saint Helena:
NA
Saint Kitts and Nevis:
NA
Saint Lucia:
deforestation; soil erosion, particularly in the
northern region
Saint Pierre and Miquelon:
NA
Saint Vincent and the Grenadines:
pollution of coastal waters and
shorelines from discharges by pleasure yachts and other effluents;
in some areas, pollution is severe enough to make swimming
prohibitive
Samoa:
soil erosion
San Marino:
NA
Sao Tome and Principe:
deforestation; soil erosion and exhaustion
Saudi Arabia:
desertification; depletion of underground water
resources; the lack of perennial rivers or permanent water bodies
has prompted the development of extensive seawater desalination
facilities; coastal pollution from oil spills
Senegal:
wildlife populations threatened by poaching; deforestation;
overgrazing; soil erosion; desertification; overfishing
Seychelles:
water supply depends on catchments to collect rainwater
Sierra Leone:
rapid population growth pressuring the environment;
overharvesting of timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in deforestation and soil
exhaustion; civil war depleting natural resources; overfishing
Singapore:
industrial pollution; limited natural fresh water
resources; limited land availability presents waste disposal
problems; seasonal smoke/haze resulting from forest fires in','6ca12ac1b1116ab92fc8e9d1bca794c032e68079a3692a752841cbd5681f348b','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf7a54ee81cd3d7b8b9264570b872e45384fb3ffa430d1e4c5f99878c7de157',2001,'ID','Indonesia','space',271,'Slovakia:
air pollution from metallurgical plants presents human
health risks; acid rain damaging forests
Slovenia:
Sava River polluted with domestic and industrial waste;
pollution of coastal waters with heavy metals and toxic chemicals;
forest damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid rain
Solomon Islands:
deforestation; soil erosion; much of the
surrounding coral reefs are dead or dying
Somalia:
famine; use of contaminated water contributes to human
health problems; deforestation; overgrazing; soil erosion;
desertification
South Africa:
lack of important arterial rivers or lakes requires
extensive water conservation and control measures; growth in water
usage threatens to outpace supply; pollution of rivers from
agricultural runoff and urban discharge; air pollution resulting in
acid rain; soil erosion; desertification
South Georgia and the South Sandwich Islands:
NA
Southern Ocean:
increased solar ultraviolet radiation resulting from
the Antarctic ozone hole in recent years, reducing marine primary
productivity (phytoplankton) by as much as 15% and damaging the DNA
of some fish; illegal, unreported, and unregulated fishing in recent
years, especially the landing of an estimated five to six times more
Patagonian toothfish than the regulated fishery, which is likely to
affect the sustainability of the stock; large amount of incidental
mortality of seabirds resulting from long-line fishing for toothfish
note: the now-protected fur seal population is making a strong
comeback after severe overexploitation in the 18th and 19th centuries
Spain:
pollution of the Mediterranean Sea from raw sewage and
effluents from the offshore production of oil and gas; water quality
and quantity nationwide; air pollution; deforestation;
desertification
Spratly Islands:
NA
Sri Lanka:
deforestation; soil erosion; wildlife populations
threatened by poaching and urbanization; coastal degradation from
mining activities and increased pollution; freshwater resources
being polluted by industrial wastes and sewage runoff; waste
disposal; air pollution in Colombo
Sudan:
inadequate supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion; desertification
Suriname:
deforestation as timber is cut for export; pollution of
inland waterways by small-scale mining activities
Svalbard:
NA
Swaziland:
limited supplies of potable water; wildlife populations
being depleted because of excessive hunting; overgrazing; soil
degradation; soil erosion
Sweden:
acid rain damaging soils and lakes; pollution of the North
Sea and the Baltic Sea
Switzerland:
air pollution from vehicle emissions and open-air
burning; acid rain; water pollution from increased use of
agricultural fertilizers; loss of biodiversity
Syria:
deforestation; overgrazing; soil erosion; desertification;
water pollution from dumping of raw sewage and wastes from petroleum
refining; inadequate supplies of potable water
Tajikistan:
inadequate sanitation facilities; increasing levels of
soil salinity; industrial pollution; excessive pesticides; part of
the basin of the shrinking Aral Sea suffers from severe
overutilization of available water for irrigation and associated
pollution
Tanzania:
soil degradation; deforestation; desertification;
destruction of coral reefs threatens marine habitats; recent
droughts affected marginal agriculture
Thailand:
air pollution from vehicle emissions; water pollution from
organic and factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
Togo:
deforestation attributable to slash-and-burn agriculture and
the use of wood for fuel; water pollution presents health hazards
and hinders the fishing industry; air pollution increasing in urban
areas
Tokelau:
very limited natural resources and overcrowding are
contributing to emigration to New Zealand
Tonga:
deforestation results as more and more land is being cleared
for agriculture and settlement; some damage to coral reefs from
starfish and indiscriminate coral and shell collectors; overhunting
threatens native sea turtle populations
Trinidad and Tobago:
water pollution from agricultural chemicals,
industrial wastes, and raw sewage; oil pollution of beaches;
deforestation; soil erosion
Tromelin Island:
NA
Tunisia:
toxic and hazardous waste disposal is ineffective and
presents human health risks; water pollution from raw sewage;
limited natural fresh water resources; deforestation; overgrazing;
soil erosion; desertification
Turkey:
water pollution from dumping of chemicals and detergents;
air pollution, particularly in urban areas; deforestation; concern
for oil spills from increasing Bosporus ship traffic
Turkmenistan:
contamination of soil and groundwater with
agricultural chemicals, pesticides; salination, water-logging of
soil due to poor irrigation methods; Caspian Sea pollution;
diversion of a large share of the flow of the Amu Darya into
irrigation contributes to that river''s inability to replenish the
Aral Sea; desertification
Turks and Caicos Islands:
limited natural fresh water resources,
private cisterns collect rainwater
Tuvalu:
since there are no streams or rivers and groundwater is not
potable, most water needs must be met by catchment systems with
storage facilities (the Japanese Government has built one
desalination plant and plans to build one other); beachhead erosion
because of the use of sand for building materials; excessive
clearance of forest undergrowth for use as fuel; damage to coral
reefs from the spread of the Crown of Thorns starfish; Tuvalu is
very concerned about global increases in greenhouse gas emissions
and their effect on rising sea levels, which threaten the country''s
underground water table
Uganda:
draining of wetlands for agricultural use; deforestation;
overgrazing; soil erosion; water hyacinth infestation in Lake
Victoria; poaching is widespread
Ukraine:
inadequate supplies of potable water; air and water
pollution; deforestation; radiation contamination in the northeast
from 1986 accident at Chornobyl'' Nuclear Power Plant
United Arab Emirates:
lack of natural freshwater resources being
overcome by desalination plants; desertification; beach pollution
from oil spills
United Kingdom:
continues to reduce greenhouse gas emissions (has
meet Kyoto Protocol target of a 12.5% reduction from 1990 levels and
hopes to reduce even more); small particulate emissions, largely
from vehicular traffic, remain a problem; solid waste continues to
rise and recycling is very limited
United States:
air pollution resulting in acid rain in both the US
and Canada; the US is the largest single emitter of carbon dioxide
from the burning of fossil fuels; water pollution from runoff of
pesticides and fertilizers; very limited natural fresh water
resources in much of the western part of the country require careful
management; desertification
Uruguay:
water pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
Uzbekistan:
drying up of the Aral Sea is resulting in growing
concentrations of chemical pesticides and natural salts; these
substances are then blown from the increasingly exposed lake bed and
contribute to desertification; water pollution from industrial
wastes and the heavy use of fertilizers and pesticides is the cause
of many human health disorders; increasing soil salination; soil
contamination from agricultural chemicals, including DDT
Vanuatu:
a majority of the population does not have access to a
potable and reliable supply of water; deforestation
Venezuela:
sewage pollution of Lago de Valencia; oil and urban
pollution of Lago de Maracaibo; deforestation; soil degradation;
urban and industrial pollution, especially along the Caribbean
coast; threat to the rainforest ecosystem from irresponsible mining
operations
Vietnam:
logging and slash-and-burn agricultural practices
contribute to deforestation and soil degradation; water pollution
and overfishing threaten marine life populations; groundwater
contamination limits potable water supply; growing urban
industrialization and population migration are rapidly degrading
environment in Hanoi and Ho Chi Minh City
Virgin Islands:
lack of natural freshwater resources
Wake Island:
NA
Wallis and Futuna:
deforestation (only small portions of the
original forests remain) largely as a result of the continued use of
wood as the main fuel source; as a consequence of cutting down the
forests, the mountainous terrain of Futuna is particularly prone to
erosion; there are no permanent settlements on Alofi because of the
lack of natural fresh water resources
West Bank:
adequacy of fresh water supply; sewage treatment
Western Sahara:
sparse water and lack of arable land
World:
large areas subject to overpopulation, industrial disasters,
pollution (air, water, acid rain, toxic substances), loss of
vegetation (overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
Yemen:
very limited natural fresh water resources; inadequate
supplies of potable water; overgrazing; soil erosion; desertification
Yugoslavia:
pollution of coastal waters from sewage outlets,
especially in tourist-related areas such as Kotor; air pollution
around Belgrade and other industrial cities; water pollution from
industrial wastes dumped into the Sava which flows into the Danube
Zambia:
air pollution and resulting acid rain in the mineral
extraction and refining region; chemical runoff into watersheds;
poaching seriously threatens rhinoceros, elephant, antelope, and
large cat populations; deforestation; soil erosion; desertification;
lack of adequate water treatment presents human health risks
Zimbabwe:
deforestation; soil erosion; land degradation; air and
water pollution; the black rhinoceros herd - once the largest
concentration of the species in the world - has been significantly
reduced by poaching
Taiwan:
air pollution; water pollution from industrial emissions,
raw sewage; contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste disposal
======================================================================
@Environment - international agreements
Afghanistan:
party to: Desertification, Endangered Species,
Environmental Modification, Marine Dumping, Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Life Conservation
Albania:
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Algeria:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Andorra:
party to: Hazardous Wastes
signed, but not ratified: none of the selected agreements
Angola:
party to: Biodiversity, Climate Change, Desertification,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Antigua and Barbuda:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected agreements
Argentina:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine
Life Conservation
Armenia:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants
Australia:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Austria:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Azerbaijan:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Bahamas, The:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Bahrain:
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Bangladesh:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Barbados:
party to: Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Biodiversity
Belarus:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Belgium:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Air Pollution-Sulphur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Belize:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Benin:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Bhutan:
party to: Biodiversity, Climate Change, Nuclear Test Ban
signed, but not ratified: Law of the Sea
Bolivia:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection
Bosnia and Herzegovina:
party to: Air Pollution, Climate Change,
Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
Botswana:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Brazil:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Brunei:
party to: Endangered Species, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Bulgaria:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Climate Change-Kyoto Protocol
Burkina Faso:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Nuclear Test Ban
Burma:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Burundi:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea, Nuclear Test Ban
Cambodia:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Marine Life Conservation, Ship Pollution,
Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
Cameroon:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Nuclear Test Ban
Canada:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Climate Change-Kyoto Protocol, Law
of the Sea, Marine Life Conservation
Cape Verde:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping
signed, but not ratified: none of the selected agreements
Central African Republic:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
Chad:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Nuclear Test Ban, Ozone Layer Protection,
Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
Chile:
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
China:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine
Life Conservation
Colombia:
party to: Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol, Law of
the Sea, Marine Dumping
Comoros:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Congo, Democratic Republic of the:
party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Congo, Republic of the:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Cook Islands:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea
signed, but not ratified: Climate Change-Kyoto Protocol
Costa Rica:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine
Life Conservation
Cote d''Ivoire:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Croatia:
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Cuba:
party to: Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol, Marine Life Conservation
Cyprus:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants
Czech Republic:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modific','4bf54167ab402f6d1ca9a08cff832e3ee5d29950a7a59fa5be9ae6b5db3400e0','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6f5e8ab4c601c49ff6d094066c57391d151a37dee3db5abc3422010c4c1dc7c',2001,'ID','Indonesia','space',272,'ation, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Denmark:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol, Law of the Sea
Djibouti:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected agreements
Dominica:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Dominican Republic:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Law of the Sea
Ecuador:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Egypt:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
El Salvador:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Equatorial Guinea:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species, Law of
the Sea, Ship Pollution
signed, but not ratified: none of the selected agreements
Eritrea:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species
signed, but not ratified: none of the selected agreements
Estonia:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds,
Biodiversity, Climate Change, Endangered Species, Hazardous Wastes,
Ship Pollution, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Ethiopia:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Environmental Modification, Law of the
Sea, Nuclear Test Ban
Fiji:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Finland:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
France:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Gabon:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Gambia, The:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected agreements
Georgia:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Germany:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Ghana:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Greece:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Antarctic
Treaty, Climate Change-Kyoto Protocol
Grenada:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
Guatemala:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol
Guinea:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands,
Whaling
signed, but not ratified: none of the selected agreements
Guinea-Bissau:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Wetlands
signed, but not ratified: none of the selected agreements
Guyana:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Haiti:
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection
signed, but not ratified: Hazardous Wastes, Nuclear Test Ban
Holy See (Vatican City):
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental Modification
Honduras:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
Hong Kong:
party to: Marine Dumping (associate member), Ship
Pollution (associate member)
Hungary:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Law of the Sea
Iceland:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Marine Life Conservation
India:
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Indonesia:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine
Life Conservation
Iran:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Environmental Modification, Law of the
Sea, Marine Life Conservation
Iraq:
party to: Law of the Sea, Nuclear Test Ban
signed, but not ratified: Environmental Modification
Ireland:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Biodiversity, Climate Change,
Desertification, Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Endangered Species,
Marine Life Conservation
Israel:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine
Life Conservation
Italy:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Jamaica:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species, Law of
the Sea, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Japan:
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Jordan:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Kazakhstan:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
Kenya:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Kiribati:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Korea, North:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Antarctic-Environmental Protocol, Law of
the Sea
Korea, South:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Kuwait:
party to: Climate Change, Desertification, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Biodiversity, Endangered Species, Marine
Dumping
Kyrgyzstan:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Laos:
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
Latvia:
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Lebanon:
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification, Marine
Dumping, Marine Life Conservation
Lesotho:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Marine
Life Conservation, Ozone Layer Protection
signed, but not ratified: Endangered Species, Law of the Sea,
Marine Dumping
Liberia:
party to: Biodiversity, Desertification, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Climate Change, Environmental
Modification, Law of the Sea, Marine Dumping, Marine Life
Conservation
Libya:
party to: Climate Change, Desertification, Marine Dumping,
Ozone Layer Protection, Wetlands
signed, but not ratified: Biodiversity, Law of the Sea, Nuclear
Test Ban
Liechtenstein:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Law of the Sea
Lithuania:
party to: Biodiversity, Climate Change, Hazardous
Wastes, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Luxembourg:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur
85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol,
Environmental Modification
Macedonia, The Former Yugoslav Republic of:
party to: Air
Pollution, Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Madagascar:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Malawi:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Wetlands
signed, but not ratified: Law of the Sea
Malaysia:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Maldives:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
Mali:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
Malta:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Marshall Islands:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
Mauritania:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected agreements
Mauritius:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Mexico:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Micronesia, Federated States of:
party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Moldova:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants
Monaco:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Mongolia:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Morocco:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Environmental Modification, Law of the Sea
Mozambique:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Namibia:
party to: Antarctic-Marine Living Resources, Biodiversity,
Climate Change, Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Nauru:
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Dumping
signed, but not ratified: none of the selected agreements
Nepal:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Marine Dumping, Marine Life Conservation
Netherlands:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Biodiversity, Climate Change-Kyoto
Protocol
New Zealand:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic Seals, Climate Change-Kyoto
Protocol, Marine Life Conservation
Nicaragua:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
Niger:
party to: Biodiversity, Climate C','76eb0991564b9975174304f42b4a82f22f759d254e2b1fcda47e914ec478e35b','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('458dfdceb6c4557cd83ff624f6cf5f85a57ba6698a0d0e1648645936cd7f1575',2001,'ID','Indonesia','space',273,'hange, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Law of the
Sea
Nigeria:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
Niue:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification
signed, but not ratified: Law of the Sea
Norway:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Climate Change-Kyoto Protocol
Oman:
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Pakistan:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation, Nuclear Test Ban
Palau:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea
signed, but not ratified: none of the selected agreements
Panama:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Papua New Guinea:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol
Paraguay:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: Nuclear Test Ban
Peru:
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Philippines:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Poland:
party to: Air Pollution, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94,
Climate Change-Kyoto Protocol
Portugal:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Climate
Change-Kyoto Protocol, Environmental Modification, Nuclear Test Ban
Qatar:
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Romania:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Russia:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol
Rwanda:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Nuclear Test Ban
signed, but not ratified: Law of the Sea
Saint Kitts and Nevis:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Saint Lucia:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Saint Vincent and the Grenadines:
party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Samoa:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
San Marino:
party to: Biodiversity, Climate Change,
Desertification, Nuclear Test Ban
signed, but not ratified: Air Pollution
Sao Tome and Principe:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of the Sea, Ship
Pollution
signed, but not ratified: none of the selected agreements
Saudi Arabia:
party to: Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Senegal:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Marine Dumping
Seychelles:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
Sierra Leone:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification, Law
of the Sea, Marine Life Conservation, Nuclear Test Ban, Wetlands
signed, but not ratified: none of the selected agreements
Singapore:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Slovakia:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Slovenia:
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Solomon Islands:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Somalia:
party to: Endangered Species, Law of the Sea
signed, but not ratified: Marine Dumping, Nuclear Test Ban
South Africa:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Southern Ocean:
the Southern Ocean is subject to all international
agreements regarding the world''s oceans; in addition, it is subject
to these agreements specific to the Antarctic region: International
Whaling Commission (prohibits commercial whaling south of 40 degrees
south [south of 60 degrees south between 50 degrees and 130 degrees
west]); Convention on the Conservation of Antarctic Seals (limits
sealing); Convention on the Conservation of Antarctic Marine Living
Resources (regulates fishing)
note: many nations (including the US) prohibit mineral resource
exploration and exploitation south of the fluctuating Polar Front
(Antarctic Convergence) which is in the middle of the Antarctic
Circumpolar Current and serves as the dividing line between the very
cold polar surface waters to the south and the warmer waters to the
north
Spain:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Desertification
Sri Lanka:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Sudan:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
Suriname:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
Swaziland:
party to: Biodiversity, Climate Change, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Desertification, Law of the Sea
Sweden:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Switzerland:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol, Law of the Sea
Syria:
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
Tajikistan:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Tanzania:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: Nuclear Test Ban
Thailand:
party to: Climate Change, Endangered Species, Hazardous
Wastes, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Biodiversity, Climate Change-Kyoto
Protocol, Law of the Sea
Togo:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
Tonga:
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Trinidad and Tobago:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Tunisia:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Turkey:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Desertification, Endangered Species, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol,
Environmental Modification
Turkmenistan:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
Tuvalu:
party to: Climate Change, Climate Change-Kyoto Protocol,
Desertification, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Biodiversity, Law of the Sea
Uganda:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Environmental Modification
Ukraine:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
United Arab Emirates:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: Law of the Sea
United Kingdom:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
United States:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Marine Dumping, Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change-Kyoto Protocol, Hazardous Wastes
Uruguay:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Nuclear Test Ban
Uzbekistan:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Vanuatu:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Venezuela:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species, Hazardous Wastes,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping
Vietnam:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
Western Sahara:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Yemen:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: Nuclear Test Ban
Yugoslavia:
party to: Air Pollution, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Biodiversity
Zambia:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Zimbabwe:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Taiwan:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
======================================================================
@Ethnic groups
Afghanistan:
Pashtun 38%, Tajik 25%, Hazara 19%, minor ethnic groups
(Aimaks, Turkmen, Baloch, and others) 12%, Uzbek 6%
Albania:
Albanian 95%, Greeks 3%, other 2% (Vlachs, Gypsies, Serbs,
and Bulgarians) (1989 est.)
note: in 1989, other estimates of the Greek population ranged from
1% (official Albanian statistics) to 12% (from a Greek organization)
Algeria:
Arab-Berber 99%, European less than 1%
American Samoa:
Samoan (Polynesian) 89%, Caucasian 2%, Tongan 4%,
other 5%
Andorra:
Spanish 43%, Andorran 33%, Portuguese 11%, French 7%, other
6% (1998)
Angola:
Ovimbundu 37%, Kimbundu 25%, Bakongo 13%, mestico (mixed
European and Native African) 2%, European 1%, other 22%
Anguilla:
black
Antigua and Barbuda:
black, British, Portuguese, Lebanese, Syrian
Argentina:
white (mostly Spanish and Italian) 97%, mestizo,
Amerindian, or other nonwhite groups 3%
Armenia:
Armenian 93%, Azeri 3%, Russian 2%, other (mostly Yezidi
Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had emigrated
from Armenia
Aruba:
mixed white/Caribbean Amerindian 80%
Australia:
Caucasian 92%, Asian 7%, aboriginal and other 1%
Austria:
German 98%, Croatian, Slovene, other (includes Hungarians,
Czechs, Slovaks, Roma)
Azerbaijan:
Azeri 90%, Dagestani 3.2%, Russian 2.5%, Armenian 2%,
other 2.3% (1998 est.)
note: almost all Armenians live in the separatist Nagorno-Karabakh
region
Bahamas, The:
black 85%, white 12%, Asian and Hispanic 3%
Bahrain:
Bahraini 63%, Asian 19%, other Arab 10%, Iranian 8%
Bangladesh:
Bengali 98%, tribal groups, non-Bengali Muslims (1998)
Barbados:
black 80%, white 4%, other 16%
Belarus:
Byelorussian 81.2%, Russian 11.4%, Polish, Ukrainian, and
other 7.4%
Belgium:
Fleming 58%, Walloon 31%, mixed or other 11%
Belize:
mestizo 43.7%, Creole 29.8%, Maya 10%, Garifuna 6.2%, other
10.3%
Benin:
African 99% (42 ethnic groups, most important being Fon,
Adja, Yoruba, Bariba), Europeans 5,500
Bermuda:
black 58%, white 36%, other 6%
Bhutan:
Bhote 50%, ethnic Nepalese 35%, indigenous or migrant tribes
15%
Bolivia:
Quechua 30%, Aymara 25%, mestizo (mixed white and
Amerindian ancestry) 30%, white 15%
Bosnia and Herzegovina:
Serb 31%, Bosniak 44%, Croat 17%, Yugoslav
5.5%, other 2.5% (1991)
note: Bosniak has replaced muslim as an ethnic term in part to
avoid confusion with the religious term Muslim - an adherent of Islam
Botswana:
Tswana (or Setswana) 79%, Kalanga 11%, Basarwa 3%, other,
including Kgalagadi and white 7%
Brazil:
white (includes Portuguese, German, Italian, Spanish,
Polish) 55%, mixed white and black 38%, black 6%, other (includes
Japanese, Arab, Amerindian) 1%
British Virgin Islands:
black 90%, white, Asian
Brunei:
Malay 67%, Chinese 15%, indigenous 6%, other 12%
Bulgaria:
Bulgarian 83%, Turk 8.5%, Roma 2.6%, Macedonian, Armenian,
Tatar, Gagauz, Circassian, others (1998)
Burkina Faso:
Mossi over 40%, Gurunsi, Senufo, Lobi, Bobo, Mande,
Fulani
Burma:
Burman 68%, Shan 9%, Karen 7%, Rakhine 4%, Chinese 3%, Mon
2%, Indian 2%, other 5%
Burundi:
Hutu (Bantu) 85%, Tutsi (Hamitic) 14%, Twa (Pygmy) 1%,
Europeans 3,000, South Asians 2,000
Cambodia:
Khmer 90%, Vietnamese 5%, Chinese 1%, other 4%
Cameroon:
Cameroon Highlanders 31%, Equatorial Bantu 19%, Kirdi 11%,
Fulani 10%, Northwest','ea93112d9fb9feddc3e1a0c67edd79d41b7d7a43d0709721e463b8b5f099fc76','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ca56e33a219e8d8df0ccbbd1d9886126d7d64e9c15dd260624c91f75ec6eed0',2001,'ID','Indonesia','space',274,'ern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
Canada:
British Isles origin 28%, French origin 23%, other European
15%, Amerindian 2%, other, mostly Asian, African, Arab 6%, mixed
background 26%
Cape Verde:
Creole (mulatto) 71%, African 28%, European 1%
Cayman Islands:
mixed 40%, white 20%, black 20%, expatriates of
various ethnic groups 20%
Central African Republic:
Baya 34%, Banda 27%, Sara 10%, Mandjia
21%, Mboum 4%, M''Baka 4%, Europeans 6,500 (including 1,500 French)
Chad:
Muslims, commonly referred to as "northerners" or "gorane"
(Arabs, Toubou, Hadjerai, Fulbe, Kotoko, Kanembou, Baguirmi,
Boulala, Zaghawa, and Maba); non-Muslims, commonly referred to as
"southerners" (Sara, Ngambaye, Mbaye, Goulaye, Moundang, Moussei,
Massa) including nonindigenous 150,000 (of whom 1,000 are French)
note: ethnicity and regional background more commonly used to
identify Chadians than religious affiliation
Chile:
white and white-Amerindian 95%, Amerindian 3%, other 2%
China:
Han Chinese 91.9%, Zhuang, Uygur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Buyi, Korean, and other nationalities 8.1%
Christmas Island:
Chinese 61%, Malay 25%, European 11%, other 3%, no
indigenous population
Cocos (Keeling) Islands:
Europeans, Cocos Malays
Colombia:
mestizo 58%, white 20%, mulatto 14%, black 4%, mixed
black-Amerindian 3%, Amerindian 1%
Comoros:
Antalote, Cafre, Makoa, Oimatsaha, Sakalava
Congo, Democratic Republic of the:
over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes - Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic) make up about
45% of the population
Congo, Republic of the:
Kongo 48%, Sangha 20%, M''Bochi 12%, Teke
17%, Europeans NA%; note - Europeans estimated at 8,500, mostly
French, before the 1997 civil war; may be half that of 1998,
following the widespread destruction of foreign businesses in 1997
Cook Islands:
Polynesian (full blood) 81.3%, Polynesian and European
7.7%, Polynesian and non-European 7.7%, European 2.4%, other 0.9%
Costa Rica:
white (including mestizo) 94%, black 3%, Amerindian 1%,
Chinese 1%, other 1%
Cote d''Ivoire:
Akan 42.1%, Voltaiques or Gur 17.6%, Northern Mandes
16.5%, Krous 11%, Southern Mandes 10%, other 2.8% (1998)
Croatia:
Croat 78.1%, Serb 12.2%, Bosniak 0.9%, Hungarian 0.5%,
Slovenian 0.5%, Czech 0.4%, Albanian 0.3%, Montenegrin 0.3%, Roma
0.2%, others 6.6% (1991)
Cuba:
mulatto 51%, white 37%, black 11%, Chinese 1%
Cyprus:
Greek 78% (99.5% of the Greeks live in the Greek Cypriot
area; 0.5% of the Greeks live in the Turkish Cypriot area), Turkish
18% (1.3% of the Turks live in the Greek Cypriot area; 98.7% of the
Turks live in the Turkish Cypriot area), other 4% (99.2% of the
other ethnic groups live in the Greek Cypriot area; 0.8% of the
other ethnic groups live in the Turkish Cypriot area)
Czech Republic:
Czech 81.2%, Moravian 13.2%, Slovak 3.1%, Polish
0.6%, German 0.5%, Silesian 0.4%, Roma 0.3%, Hungarian 0.2%, other
0.5% (1991)
Denmark:
Scandinavian, Inuit, Faroese, German, Turkish, Iranian,
Somali
Djibouti:
Somali 60%, Afar 35%, French, Arab, Ethiopian, and Italian
5%
Dominica:
black, Carib Amerindian
Dominican Republic:
white 16%, black 11%, mixed 73%
Ecuador:
mestizo (mixed Amerindian and white) 65%, Amerindian 25%,
Spanish and others 7%, black 3%
Egypt:
Eastern Hamitic stock (Egyptians, Bedouins, and Berbers) 99%,
Greek, Nubian, Armenian, other European (primarily Italian and
French) 1%
El Salvador:
mestizo 90%, Amerindian 1%, white 9%
Equatorial Guinea:
Bioko (primarily Bubi, some Fernandinos), Rio
Muni (primarily Fang), Europeans less than 1,000, mostly Spanish
Eritrea:
ethnic Tigrinya 50%, Tigre and Kunama 40%, Afar 4%, Saho
(Red Sea coast dwellers) 3%
Estonia:
Estonian 65.1%, Russian 28.1%, Ukrainian 2.5%, Byelorussian
1.5%, Finn 1%, other 1.8% (1998)
Ethiopia:
Oromo 40%, Amhara and Tigre 32%, Sidamo 9%, Shankella 6%,
Somali 6%, Afar 4%, Gurage 2%, other 1%
Falkland Islands (Islas Malvinas):
British
Faroe Islands:
Scandinavian
Fiji:
Fijian 51% (predominantly Melanesian with a Polynesian
admixture), Indian 44%, European, other Pacific Islanders, overseas
Chinese, and other 5% (1998 est.)
Finland:
Finn 93%, Swede 6%, Sami 0.11%, Roma 0.12%, Tatar 0.02%
France:
Celtic and Latin with Teutonic, Slavic, North African,
Indochinese, Basque minorities
French Guiana:
black or mulatto 66%, white 12%, East Indian,
Chinese, Amerindian 12%, other 10%
French Polynesia:
Polynesian 78%, Chinese 12%, local French 6%,
metropolitan French 4%
Gabon:
Bantu tribes including four major tribal groupings (Fang,
Eshira, Bapounou, Bateke), other Africans and Europeans 154,000,
including 10,700 French and 11,000 persons of dual nationality
Gambia, The:
African 99% (Mandinka 42%, Fula 18%, Wolof 16%, Jola
10%, Serahuli 9%, other 4%), non-African 1%
Gaza Strip:
Palestinian Arab and other 99.4%, Jewish 0.6%
Georgia:
Georgian 70.1%, Armenian 8.1%, Russian 6.3%, Azeri 5.7%,
Ossetian 3%, Abkhaz 1.8%, other 5%
Germany:
German 91.5%, Turkish 2.4%, other 6.1% (made up largely of
Serbo-Croatian, Italian, Russian, Greek, Polish, Spanish)
Ghana:
black African 99.8% (major tribes - Akan 44%, Moshi-Dagomba
16%, Ewe 13%, Ga 8%), European and other 0.2%
Gibraltar:
Spanish, Italian, English, Maltese, Portuguese
Greece:
Greek 98%, other 2%
note: the Greek Government states there are no ethnic divisions in','1c5c0cdc79485db9c25e80cc4a5ca664cddc69bd945640b4dc010cdb72d20566','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('041e029534ad5182a2d397d593c8560028821d37b32b79f5078655233bdeb073',2001,'GR','Greece','space',275,'Greenland:
Greenlander 88% (Inuit and Greenland-born whites), Danish
and others 12% (January 2000)
Grenada:
black 82% some South Asians (East Indians) and Europeans,
trace Arawak/Carib Amerindian
Guadeloupe:
black or mulatto 90%, white 5%, East Indian, Lebanese,
Chinese less than 5%
Guam:
Chamorro 47%, Filipino 25%, white 10%, Chinese, Japanese,
Korean, and other 18%
Guatemala:
Mestizo (mixed Amerindian-Spanish or assimilated
Amerindian - in local Spanish called Ladino), approximately 55%,
Amerindian or predominantly Amerindian, approximately 43%, whites
and others 2%
Guernsey:
UK and Norman-French descent
Guinea:
Peuhl 40%, Malinke 30%, Soussou 20%, smaller ethnic groups
10%
Guinea-Bissau:
African 99% (Balanta 30%, Fula 20%, Manjaca 14%,
Mandinga 13%, Papel 7%), European and mulatto less than 1%
Guyana:
East Indian 49%, black 32%, mixed 12%, Amerindian 6%, white
and Chinese 1%
Haiti:
black 95%, mulatto and white 5%
Holy See (Vatican City):
Italians, Swiss, other
Honduras:
mestizo (mixed Amerindian and European) 90%, Amerindian
7%, black 2%, white 1%
Hong Kong:
Chinese 95%, other 5%
Hungary:
Hungarian 89.9%, Roma 4%, German 2.6%, Serb 2%, Slovak
0.8%, Romanian 0.7%
Iceland:
homogeneous mixture of descendants of Norse and Celts
India:
Indo-Aryan 72%, Dravidian 25%, Mongoloid and other 3% (2000)
Indonesia:
Javanese 45%, Sundanese 14%, Madurese 7.5%, coastal
Malays 7.5%, other 26%
Iran:
Persian 51%, Azeri 24%, Gilaki and Mazandarani 8%, Kurd 7%,
Arab 3%, Lur 2%, Baloch 2%, Turkmen 2%, other 1%
Iraq:
Arab 75%-80%, Kurdish 15%-20%, Turkoman, Assyrian or other 5%
Ireland:
Celtic, English
Israel:
Jewish 80.1% (Europe/America-born 32.1%, Israel-born 20.8%,
Africa-born 14.6%, Asia-born 12.6%), non-Jewish 19.9% (mostly Arab)
(1996 est.)
Italy:
Italian (includes small clusters of German-, French-, and
Slovene-Italians in the north and Albanian-Italians and
Greek-Italians in the south)
Jamaica:
black 90.9%, East Indian 1.3%, white 0.2%, Chinese 0.2%,
mixed 7.3%, other 0.1%
Japan:
Japanese 99.4%, Korean 0.6% (1999)
Jersey:
UK and Norman-French descent
Jordan:
Arab 98%, Circassian 1%, Armenian 1%
Kazakhstan:
Kazakh (Qazaq) 53.4%, Russian 30%, Ukrainian 3.7%, Uzbek
2.5%, German 2.4%, Uighur 1.4%, other 6.6% (1999 census)
Kenya:
Kikuyu 22%, Luhya 14%, Luo 13%, Kalenjin 12%, Kamba 11%,
Kisii 6%, Meru 6%, other African 15%, non-African (Asian, European,
and Arab) 1%
Kiribati:
predominantly Micronesian with some Polynesian
Korea, North:
racially homogeneous; there is a small Chinese
community and a few ethnic Japanese
Korea, South:
homogeneous (except for about 20,000 Chinese)
Kuwait:
Kuwaiti 45%, other Arab 35%, South Asian 9%, Iranian 4%,
other 7%
Kyrgyzstan:
Kirghiz 52.4%, Russian 18%, Uzbek 12.9%, Ukrainian 2.5%,
German 2.4%, other 11.8%
Laos:
Lao Loum (lowland) 68%, Lao Theung (upland) 22%, Lao Soung
(highland) including the Hmong ("Meo") and the Yao (Mien) 9%, ethnic
Vietnamese/Chinese 1%
Latvia:
Latvian 56.5%, Russian 30.4%, Byelorussian 4.3%, Ukrainian
2.8%, Polish 2.6%, other 3.4%
Lebanon:
Arab 95%, Armenian 4%, other 1%
Lesotho:
Sotho 99.7%, Europeans, Asians, and other 0.3%,
Liberia:
indigenous African tribes 95% (including Kpelle, Bassa,
Gio, Kru, Grebo, Mano, Krahn, Gola, Gbandi, Loma, Kissi, Vai, and
Bella), Americo-Liberians 2.5% (descendants of immigrants from the
US who had been slaves), Congo People 2.5% (descendants of
immigrants from the Caribbean who had been slaves)
Libya:
Berber and Arab 97%, Greeks, Maltese, Italians, Egyptians,
Pakistanis, Turks, Indians, Tunisians
Liechtenstein:
Alemannic 87.5%, Italian, Turkish, and other 12.5%
Lithuania:
Lithuanian 80.6%, Russian 8.7%, Polish 7%, Byelorussian
1.6%, other 2.1%
Luxembourg:
Celtic base (with French and German blend), Portuguese,
Italian, Slavs (from Montenegro, Albania, and Kososvo) and European
(guest and resident workers)
Macau:
Chinese 95%, Macanese (mixed Portuguese and Asian ancestry),
Portuguese, other
Macedonia, The Former Yugoslav Republic of:
Macedonian 66.6%,
Albanian 22.7%, Turkish 4%, Roma 2.2%, Serb 2.1%, other 2.4% (1994)
Madagascar:
Malayo-Indonesian (Merina and related Betsileo), Cotiers
(mixed African, Malayo-Indonesian, and Arab ancestry -
Betsimisaraka, Tsimihety, Antaisaka, Sakalava), French, Indian,
Creole, Comoran
Malawi:
Chewa, Nyanja, Tumbuko, Yao, Lomwe, Sena, Tonga, Ngoni,
Ngonde, Asian, European
Malaysia:
Malay and other indigenous 58%, Chinese 27%, Indian 8%,
others 7% (2000)
Maldives:
South Indians, Sinhalese, Arabs
Mali:
Mande 50% (Bambara, Malinke, Soninke), Peul 17%, Voltaic 12%,
Songhai 6%, Tuareg and Moor 10%, other 5%
Malta:
Maltese (descendants of ancient Carthaginians and
Phoenicians, with strong elements of Italian and other Mediterranean
stock)
Man, Isle of:
Manx (Norse-Celtic descent), Briton
Marshall Islands:
Micronesian
Martinique:
African and African-white-Indian mixture 90%, white 5%,
East Indian, Chinese less than 5%
Mauritania:
mixed Maur/black 40%, Maur 30%, black 30%
Mauritius:
Indo-Mauritian 68%, Creole 27%, Sino-Mauritian 3%,
Franco-Mauritian 2%
Mayotte:
NA
Mexico:
mestizo (Amerindian-Spanish) 60%, Amerindian or
predominantly Amerindian 30%, white 9%, other 1%
Micronesia, Federated States of:
nine ethnic Micronesian and
Polynesian groups
Moldova:
Moldovan/Romanian 64.5%, Ukrainian 13.8%, Russian 13%,
Gagauz 3.5%, Jewish 1.5%, Bulgarian 2%, other 1.7% (1989 est.)
note: internal disputes with ethnic Slavs in the Transnistrian
region
Monaco:
French 47%, Monegasque 16%, Italian 16%, other 21%
Mongolia:
Mongol (predominantly Khalkha) 85%, Turkic (of which
Kazakh is the largest group) 7%, Tungusic 4.6%, other (including
Chinese and Russian) 3.4% (1998)
Montserrat:
black, white
Morocco:
Arab-Berber 99.1%, other 0.7%, Jewish 0.2%
Mozambique:
indigenous tribal groups 99.66% (Shangaan, Chokwe,
Manyika, Sena, Makua, and others), Europeans 0.06%, Euro-Africans
0.2%, Indians 0.08%
Namibia:
black 87.5%, white 6%, mixed 6.5%
note: about 50% of the population belong to the Ovambo tribe and 9%
to the Kavangos tribe; other ethnic groups are: Herero 7%, Damara
7%, Nama 5%, Caprivian 4%, Bushmen 3%, Baster 2%, Tswana 0.5%
Nauru:
Nauruan 58%, other Pacific Islander 26%, Chinese 8%, European
8%
Nepal:
Brahman, Chetri, Newar, Gurung, Magar, Tamang, Rai, Limbu,
Sherpa, Tharu, and others (1995)
Netherlands:
Dutch 91%, Moroccans, Turks, and other 9% (1999 est.)
Netherlands Antilles:
mixed black 85%, Carib Amerindian, white, East
Asian
New Caledonia:
Melanesian 42.5%, European 37.1%, Wallisian 8.4%,
Polynesian 3.8%, Indonesian 3.6%, Vietnamese 1.6%, other 3%
New Zealand:
New Zealand European 74.5%, Maori 9.7%, other European
4.6%, Pacific Islander 3.8%, Asian and others 7.4%
Nicaragua:
mestizo (mixed Amerindian and white) 69%, white 17%,
black 9%, Amerindian 5%
Niger:
Hausa 56%, Djerma 22%, Fula 8.5%, Tuareg 8%, Beri Beri
(Kanouri) 4.3%, Arab, Toubou, and Gourmantche 1.2%, about 1,200
French expatriates
Nigeria:
Nigeria, which is Africa''s most populous country, is
composed of more than 250 ethnic groups; the following are the most
populous and politically influential: Hausa and Fulani 29%, Yoruba
21%, Igbo (Ibo) 18%, Ijaw 10%, Kanuri 4%, Ibibio 3.5%, Tiv 2.5%
Niue:
Polynesian (with some 200 Europeans, Samoans, and Tongans)
Norfolk Island:
descendants of the Bounty mutineers, Australian, New
Zealander, Polynesians
Northern Mariana Islands:
Chamorro, Carolinians and other
Micronesians, Caucasian, Japanese, Chinese, Korean
Norway:
Norwegian (Nordic, Alpine, Baltic), Sami 20,000
Oman:
Arab, Baluchi, South Asian (Indian, Pakistani, Sri Lankan,
Bangladeshi), African
Pakistan:
Punjabi, Sindhi, Pashtun (Pathan), Baloch, Muhajir
(immigrants from India at the time of partition and their
descendants)
Palau:
Palauan (Micronesian with Malayan and Melanesian admixtures)
70%, Asian (mainly Filipinos, followed by Chinese, Taiwanese, and
Vietnamese) 28%, white 2% (2000 est.)
Panama:
mestizo (mixed Amerindian and white) 70%, Amerindian and
mixed (West Indian) 14%, white 10%, Amerindian 6%
Papua New Guinea:
Melanesian, Papuan, Negrito, Micronesian,
Polynesian
Paraguay:
mestizo (mixed Spanish and Amerindian) 95%
Peru:
Amerindian 45%, mestizo (mixed Amerindian and white) 37%,
white 15%, black, Japanese, Chinese, and other 3%
Philippines:
Christian Malay 91.5%, Muslim Malay 4%, Chinese 1.5%,
other 3%
Pitcairn Islands:
descendants of the Bounty mutineers and their
Tahitian wives
Poland:
Polish 97.6%, German 1.3%, Ukrainian 0.6%, Byelorussian 0.5%
(1990 est.)
Portugal:
homogeneous Mediterranean stock; citizens of black African
descent who immigrated to mainland during decolonization number less
than 100,000
Puerto Rico:
white (mostly Spanish origin) 80.5%, black 8%,
Amerindian 0.4%, Asian 0.2%, mixed and other 10.9%
Qatar:
Arab 40%, Pakistani 18%, Indian 18%, Iranian 10%, other 14%
Reunion:
French, African, Malagasy, Chinese, Pakistani, Indian
Romania:
Romanian 89.5%, Hungarian 7.1%, Roma 1.8%, German 0.5%,
Ukrainian 0.3%, other 0.8% (1992)
Russia:
Russian 81.5%, Tatar 3.8%, Ukrainian 3%, Chuvash 1.2%,
Bashkir 0.9%, Byelorussian 0.8%, Moldavian 0.7%, other 8.1%
Rwanda:
Hutu 84%, Tutsi 15%, Twa (Pygmoid) 1%
Saint Helena:
African descent 50%, white 25%, Chinese 25%
Saint Kitts and Nevis:
predominantly black some British, Portuguese,
and Lebanese
Saint Lucia:
black 90%, mixed 6%, East Indian 3%, white 1%
Saint Pierre and Miquelon:
Basques and Bretons (French fishermen)
Saint Vincent and the Grenadines:
black 66%, mixed 19%, East Indian
6%, Carib Amerindian 2%
Samoa:
Samoan 92.6%, Euronesians 7% (persons of European and
Polynesian blood), Europeans 0.4%
San Marino:
Sammarinese, Italian
Sao Tome and Principe:
mestico, angolares (descendants of Angolan
slaves), forros (descendants of freed slaves), servicais (contract
laborers from Angola, Mozambique, and Cape Verde), tongas (children
of servicais born on the islands), Europeans (primarily Portuguese)
Saudi Arabia:
Arab 90%, Afro-Asian 10%
Senegal:
Wolof 43.3%, Pular 23.8%, Serer 14.7%, Jola 3.7%, Mandinka
3%, Soninke 1.1%, European and Lebanese 1%, other 9.4%
Seychelles:
Seychellois (mixture of Asians, Africans, Europeans)
Sierra Leone:
20 native African tribes 90% (Temne 30%, Mende 30%,
other 30%), Creole 10% (descendants of freed Jamaican slaves who
were settled in the Freetown area in the late-18th century),
refugees from Liberia''s recent civil war, small numbers of
Europeans, Lebanese, Pakistanis, and Indians
Singapore:
Chinese 76.7%, Malay 14%, Indian 7.9%, other 1.4%
Slovakia:
Slovak 85.7%, Hungarian 10.6%, Roma 1.6% (the 1992 census
figures underreport the Gypsy/Romany community, which is about
500,000), Czech, Moravian, Silesian 1.1%, Ruthenian and Ukrainian
0.6%, German 0.1%, Polish 0.1%, other 0.2% (1996)
Slovenia:
Slovene 88%, Croat 3%, Serb 2%, Bosniak 1%, Yugoslav 0.6%,
Hungarian 0.4%, other 5% (1991)
Solomon Islands:
Melanesian 93%, Polynesian 4%, Micronesian 1.5%,
European 0.8%, Chinese 0.3%, other 0.4%
Somalia:
Somali 85%, Bantu, Arabs 30,000
South Africa:
black 75.2%, white 13.6%, Colored 8.6%, Indian 2.6%
Spain:
composite of Mediterranean and Nordic types
Sri Lanka:
Sinhalese 74%, Tamil 18%, Moor 7%, Burgher, Malay, and
Vedda 1%
Sudan:
black 52%, Arab 39%, Beja 6%, foreigners 2%, other 1%
Suriname:
Hindustani (also known locally as "East Indians"; their
ancestors emigrated from northern India in the latter part of the
19th century) 37%, Creole (mixed white and black) 31%, Javanese 15%,
"Maroons" (their African ancestors were brought to the country in
the 17th and 18th centuries as slaves and escaped to the interior)
10%, Amerindian 2%, Chinese 2%, white 1%, other 2%
Svalbard:
Norwegian 55.4%, Russian and Ukrainian 44.3%, other 0.3%
(1998)
Swaziland:
African 97%, European 3%
Sweden:
indigenous population: Swedes and Finnish and Sami
minorities; foreign-born or first-generation immigrants: Finns,
Yugoslavs, Danes, Norwegians, Greeks, Turks
Switzerland:
German 65%, French 18%, Italian 10%, Romansch 1%, other
6%
Syria:
Arab 90.3%, Kurds, Armenians, and other 9.7%
Tajikistan:
Tajik 64.9%, Uzbek 25%, Russian 3.5% (declining because
of emigration), other 6.6%
Tanzania:
mainland - native African 99% (of which 95% are Bantu
consisting of more than 130 tribes), other 1% (consisting of Asian,
European, and Arab); Zanzibar - Arab, native African, mixed Arab and
native African
Thailand:
Thai 75%, Chinese 14%, other 11%
Togo:
native African (37 tribes; largest and most important are Ewe,
Mina, and Kabre) 99%, European and Syrian-Lebanese less than 1%
Tokelau:
Polynesian
Tonga:
Polynesian, Europeans about 300
Trinidad and Tobago:
black 39.5%, East Indian (a local term -
primarily immigrants from northern India) 40.3%, mixed 18.4%, white
0.6%, Chinese and other 1.2%
Tunisia:
Arab 98%, European 1%, Jewish and other 1%
Turkey:
Turkish 80%, Kurdish 20%
Turkmenistan:
Turkmen 77%, Uzbek 9.2%, Russian 6.7%, Kazakh 2%,
other 5.1% (1995)
Turks and Caicos Islands:
black
Tuvalu:
Polynesian 96%
Uganda:
Baganda 17%, Karamojong 12%, Basogo 8%, Iteso 8%, Langi 6%,
Rwanda 6%, Bagisu 5%, Acholi 4%, Lugbara 4%, Bunyoro 3%, Batoro 3%,
non-African (European, Asian, Arab) 1%, other 23%
Ukraine:
Ukrainian 73%, Russian 22%, Jewish 1%, other 4%
United Arab Emirates:
Emirati 19%, other Arab and Iranian 23%, South
Asian 50%, other expatriates (includes Westerners and East Asians)
8% (1982)
note: less than 20% are UAE citizens (1982)
United Kingdom:
English 81.5%, Scottish 9.6%, Irish 2.4%, Welsh
1.9%, Ulster 1.8%, West Indian, Indian, Pakistani, and other 2.8%
United States:
white 83.5%, black 12.4%, Asian 3.3%, Amerindian 0.8%
(1992)
note: a separate listing for Hispanic is not included because the
US Census Bureau considers Hispanic to mean a person of Latin
American descent (especially of Cuban, Mexican, or Puerto Rican
origin) living in the US who may be of any race or ethnic group
(white, black, Asian, etc.)
Uruguay:
white 88%, mestizo 8%, black 4%, Amerindian, practically
nonexistent
Uzbekistan:
Uzbek 80%, Russian 5.5%, Tajik 5%, Kazakh 3%, Karakalpak
2.5%, Tatar 1.5%, other 2.5% (1996 est.)
Vanuatu:
indigenous Melanesian 94%, French 4%, Vietnamese, Chinese,
Pacific Islanders
Venezuela:
Spanish, Italian, Portuguese, Arab, German, African,
indigenous people
Vietnam:
Vietnamese 85%-90%, Chinese, Hmong, Thai, Khmer, Cham,
mountain groups
Virgin Islands:
black 80%, white 15%, other 5%
note: West Indian (45% born in the Virgin Islands and 29% born
elsewhere in the West Indies) 74%, US mainland 13%, Puerto Rican 5%,
other 8%
Wallis and Futuna:
Polynesian
West Bank:
Palestinian Arab and other 83%, Jewish 17%
Western Sahara:
Arab, Berber
Yemen:
predominantly Arab; but also Afro-Arab, South Asians,
Europeans
Yugoslavia:
Serb 62.6%, Albanian 16.5%, Montenegrin 5%, Hungarian
3.3%, other 12.6% (1991)
Zambia:
African 98.7%, European 1.1%, other 0.2%
Zimbabwe:
African 98% (Shona 71%, Ndebele 16%, other 11%), mixed and
Asian 1%, white less than 1%
Taiwan:
Taiwanese (including Hakka) 84%, mainland Chinese 14%,
aborigine 2%
======================================================================
@Exchange rates
Afghanistan:
afghanis per US dollar - 4,700 (January 2000), 4,750
(February 1999), 17,000 (December 1996), 7,000 (January 1995), 1,900
(January 1994), 1,019 (March 1993), 850 (1991); note - these rates
reflect the free market exchange rates rather than the official
exchange rate, which was fixed at 50.600 afghanis to the dollar
until 1996, when it rose to 2,262.65 per dollar, and finally became
fixed again at 3,000.00 per dollar in April 1996
Albania:
leke per US dollar - 146.08 (December 2000),143.71 (2000)
137.69 (1999), 150.63 (1998), 148.93 (1997), 104.50 (1996); note -
leke is the plural of lek
Algeria:
Algerian dinars per US dollar - 74,813 (January 2001),
75.260 (2000), 66.574 (1999), 58.739 (1998), 57.707 (1997), 54.749
(1996)
American Samoa:
the US dollar is used
Andorra:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); French francs per US dollar - 5.8995 (1998), 5.8367
(1997), 5.1155 (1996); Spanish pesetas per US dollar - 149.40
(1998), 146.41 (1997), 126.66 (1996)
Angola:
kwanza per US dollar - 17,910,800 (January 2001), 10,041,000
(2000), 2,790,706 (1999), 392,824 (1998), 229,040 (1997), 128,029
(1996); note - in December 1999 the kwanza was revalued with six
zeroes dropped off the old value
Anguilla:
East Caribbean dollars per US dollar - 2.7000 (fixed rate
since 1976)
Antigua and Barbuda:
East Caribbean dollars per US dollar - 2.7000
(fixed rate since 1976)
Argentina:
Argentine pesos per US dollar - 1.000 (fixed rate pegged
to the US dollar)
Armenia:
drams per US dollar - 554.29 (1 February 2001), 539.53
(2000), 535.06 (1999), 504.92 (1998), 490.85 (1997), 414.04 (1996)
Aruba:
Aruban guilders/florins per US dollar - 1.7900 (fixed rate
since 1986)
Australia:
Australian dollars per US dollar - 1.7995 (January 2001),
1.7173 (2000), 1.5497 (1999), 1.5888 (1998), 1.3439 (1997), 1.2773
(1996)
Austria:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); Austrian schillings per US dollar - 11.86 (January
1999), 12.91 (1999), 12.379 (1998), 12.204 (1997), 10.587 (1996)
Azerbaijan:
Azerbaijani manats per US dollar - 4,579 (1 February
2001), 4,342 (October 1999), 4,373 (1999), 3,869 (1998), 3,985.38
(1997), 4,301.26 (1996)
Bahamas, The:
Bahamian dollars per US dollar - 1.000 (fixed rate
pegged to the dollar)
Bahrain:
Bahraini dinars per US dollar - 0.3760 (fixed rate pegged
to the US dollar)
Bangladesh:
taka per US dollar - 54.000 (January 2001), 52.142
(2000), 49.085 (1999), 46.906 (1998), 43.892 (1997), 41.794 (1996)
Barbados:
Barbadian dollars per US dollar - 2.0000 (fixed rate
pegged to the US dollar)
Belarus:
Belarusian rubles per US dollar - 1,180 (yearend 2000),
730,000 (15 December 1999), 139,000 (25 January 1999), 46,080
(second quarter 1998), 25,964 (1997), 15,500 (yearend 1996); note -
on 1 January 2000, the national currency was redenominated at one
new ruble to 2,000 old rubles
Belgium:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); Belgian francs per US dollar - 34.77 (January 1999),
36.229 (1998), 35.774 (1997), 30.962 (1996)
Belize:
Belizean dollars per US dollar - 2.0000 (fixed rate pegged
to the US dollar)
Benin:
Communaute Financiere Africaine francs (XOF) per US dollar -
699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95 (1998),
583.67 (1997), 511.55 (1996); note - from 1 January 1999, the XOF is
pegged to the euro at a rate of 655.957 XOF per euro
Bermuda:
Bermudian dollar per US dollar - 1.0000 (fixed rate pegged
to the US dollar)
Bhutan:
ngultrum per US dollar - 46.540 (January 2001), 44.942
(2000), 43.055 (1999), 41.259 (1998), 36.313 (1997), 35.433 (1996);
note - the Bhutanese ngultrum is at par with the Indian rupee which
is also legal tender
Bolivia:
bolivianos per US dollar - 6.4071 (January 2001), 6.1835
(2000), 5.8124 (1999), 5.5101 (1998), 5.2543 (1997), 5.0746 (1996)
Bosnia and Herzegovina:
marka per US dollar - 2.086 (January 2001),
2.124 (2000), 1.837 (1999), 1.760 (1998), 1.734 (1997), 0.015 (1996)
Botswana:
pulas per US dollar - 5.4585 (January 2001), 5.1018
(2000), 4.6244 (1999), 4.2259 (1998), 3.6508 (1997), 3.3242 (1996)
Brazil:
reals per US dollar - 1.954 (January 2001), 1.830 (2000),
1.815 (1999), 1.161 (1998), 1.078 (1997), 1.005 (1996)
note: from October 1994 through 14 January 1999, the official rate
was determined by a managed float; since 15 January 1999, the
official rate floats independently with respect to the US dollar
British Virgin Islands:
the US dollar is used
Brunei:
Bruneian dollars per US dollar - 1.7365 (January 2001),
1.7240 (2000), 1.6950 (1999), 1.6736 (1998), 1.4848 (1997), 1.4100
(1996); note - the Bruneian dollar is at par with the Singapore
dollar
Bulgaria:
leva per US dollar - 2.0848 (January 2001), 2.1233 (2000),
1.8364 (1999), 1,760.36 (1998), 1,681.88 (1997), 177.89 (1996)
note: on 5 July 1999, the lev was redenominated; the post-5 July
1999 lev is equal to 1,000 of the pre-5 July 1999 lev
Burkina Faso:
Communaute Financiere Africaine francs (XOF) per US
dollar - 699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95
(1998), 583.67 (1997), 511.55 (1996); note - from 1 January 1999,
the XOF is pegged to the euro at a rate of 655.957 XOF per euro
Burma:
kyats per US dollar - official rate - 6.5972 (January 2001),
6.5167 (2000), 6.2858 (1999), 6.3432 (1998), 6.2418 (1997), 5.9176
(1996); kyats per US dollar - black market exchange rate - 435
(yearend 2000)
Burundi:
Burundi francs per US dollar - 782.36 (January 2001),
720.67 (2000), 563.56 (1999), 477.77 (1998), 352.35 (1997), 302.75
(1996)
Cambodia:
riels per US dollar - 3,909.0 (January 2001), 3,840.8
(2000), 3,807.8 (1999), 3,744.4 (1998), 2,946.3 (1997), 2,624.1
(1996)
Cameroon:
Communaute Financiere Africaine francs (XAF) per US dollar
- 699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95
(1998), 583.67 (1997), 511.55 (1996); note - from 1 January 1999,
the XAF is pegged to the euro at a rate of 655.957 XAF per euro
Canada:
Canadian dollars per US dollar - 1.5032 (January 2001),
1.4851 (2000), 1.4857 (1999), 1.4835 (1998), 1.3846 (1997), 1.3635
(1996)
Cape Verde:
Cape Verdean escudos per US dollar - 123.080 (December
2000), 115.877 (2000), 102.700 (1999), 98.158 (1998), 93.177 (1997),
82.591 (1996)
Cayman Islands:
Caymanian dollars per US dollar - 0.83 (3 November
1995), 0.85 (22 November 1993)
Central African Republic:
Communaute Financiere Africaine francs
(XAF) per US dollar - 699.21 (January 2001), 711.98 (2000), 615.70
(1999), 589.95 (1998), 583.67 (1997), 511.55 (1996); note - from 1
January 1999, the XAF is pegged to the euro at a rate of 655.957 XAF
per euro
Chad:
Communaute Financiere Africaine francs (XAF) per US dollar -
699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95 (1998),
583.67 (1997), 511.55 (1996); note - from 1 January 1999, the XAF is
pegged to the euro at a rate of 655.957 XAF per euro
Chile:
Chilean pesos per US dollar - 571.12 (January 2001), 535.47
(2000), 508.78 (1999), 460.29 (1998), 419.30 (1997), 412.27 (1996)
China:
yuan per US dollar - 8.2776 (January 2001), 8.2785 (2000),
8.2783 (1999), 8.2790 (1998), 8.2898 (1997), 8.3142 (1996)
note: beginning 1 January 1994, the People''s Bank of China quotes
the midpoint rate against the US dollar based on the previous day''s
prevailing rate in the interbank foreign exchange market
Christmas Island:
Australian dollars per US dollar - 1.7995 (January
2001), 1.7173 (2000), 1.5497 (1999), 1.5888 (1998), 1.3439 (1997),
1.2773 (1996)
Cocos (Keeling) Islands:
Australian dollars per US dollar - 1.7995
(January 2001), 1.7173 (2000), 1.5497 (1999), 1.5888 (1998), 1.3439
(1997), 1.2773 (1996)
Colombia:
Colombian pesos per US dollar - 2,241.43 (January 2001),
2087.90 (2000), 1,756.23 (1999), 1,426.04 (1998), 1,140.96 (1997),
1,036.69 (1996)
Comoros:
Comoran francs per US dollar - 524.41 (January 2001),
533.98 (2000), 461.77 (1999), 442.46 (1998), 437.75 (1997), 383.66
(1996)
note: prior to January 1999, the official rate was pegged to the
French franc at 75 Comoran francs per French franc; since 1 January
1999, the Comoran franc is pegged to the euro at a rate of 491.9677
Comoran francs per euro
Congo, Democratic Republic of the:
Congolese francs per US dollar -
50 (January 2001), 4.5 (January 2000), 4.02 (1999), 1.61 (1998),
1.31 (1997), 0.50 (1996)
note: on 30 June 1998 the Congolese franc was introduced, replacing
the new zaire
Congo, Republic of the:
Communaute Financiere Africaine francs (XAF)
per US dollar - 699.21 (January 2001), 711.98 (2000), 615.70 (1999),
589.95 (1998), 583.67 (1997), 511.55 (1996); note - from 1 January
1999, the XAF is pegged to the euro at a rate of 655.957 XAF per euro
Cook Islands:
New Zealand dollars per US dollar - 2.2502 (January
2001), 2.1863 (2000), 1.8886 (1999), 1.8632 (1998), 1.5083 (1997),
1.4543 (1996)
Costa Rica:
Costa Rican colones per US dollar - 318.95 (2001),
308.19 (2000), 285.68 (1999), 257.23 (1998), 232.60 (1997), 207.69
(1','a52aab87daafd2ed9fe6ddc1bd2b06bdc738495122e604bc10c7332e54d88e76','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bf017390b9ab0dbcd9cf261eae382fd2817a1d2616efe327ea9c29e0bcf9ee2',2001,'GR','Greece','space',276,'996)
Cote d''Ivoire:
Communaute Financiere Africaine francs (XOF) per US
dollar - 699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95
(1998), 583.67 (1997), 511.55 (1996); note - from 1 January 1999,
the XOF is pegged to the euro at a rate of 655.957 XOF per euro
Croatia:
kuna per US dollar - 8.089 (January 2001), 8.277 (2000),
7.112 (1999), 6.362 (1998), 6.101 (1997), 5.434 (1996)
Cuba:
Cuban pesos per US dollar - 1.0000 (nonconvertible, official
rate, for international transactions, pegged to the US dollar);
convertible peso sold for domestic use at a rate of 1.00 US dollar
per 22 pesos by the Government of Cuba (January 2001)
Cyprus:
Cypriot pounds per US dollar - 0.6146 (January 2001), 0.6208
(2000), 0.5423 (1999), 0.5170 (1998), 0.5135 (1997), 0.4663 (1996);
Turkish liras per US dollar - 677,621 (December 2000), 625,219
(2000), 418,783 (1999), 260,724 (1998), 151,865 (1997), 81,405 (1996)
Czech Republic:
koruny per US dollar - 37.425 (January 2001), 38.598
(2000), 34.569 (1999), 32.281 (1998), 31.698 (1997), 27.145 (1996)
Denmark:
Danish kroner per US dollar - 7.951 (January 2001), 8.083
(2000), 6.976 (1999), 6.701 (1998), 6.604 (1997), 5.799 (1996); note
- the Danes rejected the Euro in a 28 September 2000 referendum
Djibouti:
Djiboutian francs per US dollar - 177.721 (fixed rate
since 1973)
Dominica:
East Caribbean dollars per US dollar - 2.7000 (fixed rate
since 1976)
Dominican Republic:
Dominican pesos per US dollar - 16.888 (January
2001), 16.415 (2000), 16.033 (1999), 15.267 (1998), 14.265 (1997),
13.775 (1996)
Ecuador:
sucres per US dollar - 25,000 (January 2001), 24,988.4
(2000), 11,786.8 (1999), 5,446.6 (1998), 3,988.3 (1997), 3,189.5
(1996)
note: on 7 January 2000, the government passed a decree
"dollarizing" the economy; on 13 March 2000, the National Congress
approved a new exchange system whereby the US dollar is adopted as
the main legal tender in Ecuador for all purposes; on 20 March 2000,
the Central Bank of Ecuador started to exchange sucres for US
dollars at a fixed rate of 25,000 sucres per US dollar; since 30
April 2000, all transactions are denominated in US dollars
Egypt:
Egyptian pounds per US dollar - market rate - 3.8400 (January
2001), 3.6900 (2000), 3.4050 (1999), 3.3880 (1998), 3.3880 (1997),
3.3880 (1996)
El Salvador:
Salvadoran colones per US dollar - 8.755 (fixed rate
since 1993)
Equatorial Guinea:
Communaute Financiere Africaine francs (XAF) per
US dollar - 699.21 (January 2001), 711.98 (2000), 615.70 (1999),
589.95 (1998), 583.67 (1997), 511.55 (1996); note - from 1 January
1999, the XAF is pegged to the euro at a rate of 655.957 XAF per euro
Eritrea:
nakfa per US dollar = 9.5 (January 2000), 7.6 (January
1999), 7.2 (March 1998 est.)
Estonia:
krooni per US dollar - 16.663 (January 2001), 16.969
(2000), 14.678 (1999), 14.075 (1998), 13.882 (1997), 12.034 (1996);
note - krooni are tied to the German deutsche mark at a fixed rate
of 8 to 1
Ethiopia:
birr per US dollar (end of period) - 8.3140 (December
2000), 8.3140 (2000), 8.1340 (1999), 7.5030 (1998), 6.8640 (1997),
6.4260 (1996)
note: since May 1993, the birr market rate has been determined in
an interbank market supported by weekly wholesale auction
Falkland Islands (Islas Malvinas):
Falkland pounds per US dollar -
0.6764 (January 2001), 0.6596 (2000), 0.6180 (1999), 0.6037 (1998),
0.6106 (1997), 0.6403 (1996); note - the Falkland pound is at par
with the British pound
Faroe Islands:
Danish kroner per US dollar - 7.951 (January 2001),
8.093 (2000), 6.976 (1999), 6.701 (1998), 6.604 (1997), 5.799 (1966)
Fiji:
Fijian dollars per US dollar - 2.1814 (January 2001), 2.1286
(2000), 1.9696 (1999), 1.9868 (1998), 1.4437 (1997), 1.4033 (1996)
Finland:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); markkaa per US dollar - 5.3441 (1998), 5.1914 (1997),
4.5936 (1996)
France:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); French francs per US dollar - 5.65 (January 1999),
5.8995 (1998), 5.8367 (1997), 5.1155 (1996)
French Guiana:
Euros per US dollar - 1.0659 (January 2001), 1.0854
(2000), 0.9386 (1999); French francs per US dollar - 5.8995 (1998),
5.8367 (1997), 5.1155 (1996)
French Polynesia:
Comptoirs Francais du Pacifique francs (XPF) per
US dollar - 127.11 (January 2001), 129.44 (2000), 111.93 (1999),
107.25 (1998), 106.11 (1997), 93.00 (1996); note - pegged at the
rate of 119.25 XPF to the euro
Gabon:
Communaute Financiere Africaine francs (XAF) per US dollar -
699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95 (1998),
583.67 (1997), 511.55 (1996); note - from 1 January 1999, the XAF is
pegged to the euro at a rate of 655.957 XAF per euro
Gambia, The:
dalasi per US dollar - 15.000 (January 2001), 12.729
(3d quarter 1999), 11.395 (1999), 10.643 (1998), 10.200 (1997),
9.789 (1996)
Gaza Strip:
new Israeli shekels per US dollar - 4.0810 (December
2000), 4.0773 (2000), 4.1397 (1999), 3.8001 (1998), 3.4494 (1997),
3.1917 (1996)
Georgia:
lari per US dollar - 1.9798 (December 2000), 1.9762 (2000),
2.0245 (1999), 1.3898 (1998), 1.2975 (1997), 1.2628 (1996)
Germany:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); deutsche marks per US dollar - 1.69 (January 1999),
1.7597 (1998), 1.7341 (1997), 1.5048 (1996)
Ghana:
cedis per US dollar - 6,895.77 (January 2001), 5,321.68
(2000), 2,647.32 (1999), 2,314.15 (1998), 2,050.17 (1997), 1,637.23
(1996)
Gibraltar:
Gibraltar pounds per US dollar - 0.6764 (January 2001),
0.6596 (2000), 0.6180 (1999), 0.6037 (1998), 0.6106 (1997), 0.6403
(1996); note - the Gibraltar pound is at par with the British pound
Greece:
drachmae per US dollar - 380.21 (December 2000), 365.40
(2000), 305.65 (1999), 295.53 (1998), 273.06 (1997), 240.71 (1996)
Greenland:
Danish kroner per US dollar - 7.951 (January 2001), 8.083
(2000), 6.976 (1999), 6.701 (1998), 6.604 (1997), 5.799 (1996)
Grenada:
East Caribbean dollars per US dollar - 2.7000 (fixed rate
since 1976)
Guadeloupe:
Euros per US dollar - 1.0659 (January 2001), 1.0854
(2000), 0.9386 (1999); French francs per US dollar - 5.8995 (1998),
5.8367 (1997), 5.1155 (1996)
Guam:
the US dollar is used
Guatemala:
quetzales per US dollar - 7.8020 (January 2001), 7.7632
(2000), 7.3856 (1999), 6.3947 (1998), 6.0653 (1997), 6.0495 (1996),
5.8103 (1995)
Guernsey:
Guernsey pounds per US dollar - 0.6764 (January 2001),
0.6596 0.6180 (1999), 0.6037 (1998), 0.6106 (1997), 0.6403 (1996);
note - the Guernsey pound is at par with the British pound
Guinea:
Guinean francs per US dollar - 1,855.0 (October 2000),
1,572.0 (2000), 1,387.4 (1999), 1,236.8 (1998), 1,095.3 (1997),
1,004.0 (1996)
Guinea-Bissau:
Communaute Financiere Africaine francs (XOF) per US
dollar - 699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95
(1998), 583.67 (1997); Guinea-Bissauan pesos per US dollar - 26,373
(1996)
note: as of 1 May 1997, Guinea-Bissau adopted the CFA franc as the
national currency; since 1 January 1999, the CFA franc is pegged to
the euro at a rate of 655.957 CFA francs per euro
Guyana:
Guyanese dollars per US dollar - 184.1 (November 2000),
182.2 (2000), 178.0 (1999), 150.5 (1998), 142.4 (1997), 140.4 (1996)
Haiti:
gourdes per US dollar - 23.761 (January 2001), 22.524 (2000),
17.965 (1999), 16.505 (1998), 17.311 (1997), 15.093 (1996)
Holy See (Vatican City):
euros per US dollar - 1.0659 (January
2001), 1.0854 (2000), 0.9386 (1999); Vatican lire per US dollar -
2,099 (2000), 1817.2 (1999), 1,736.2 (1998), 1,703.1 (1997), 1,542.9
(1996); note - the Vatican lira is at par with the Italian lira; the
Vatican will start using euros in 2002 in conjunction with Italy at
a fixed rate of 1,936.17 lire per euro
Honduras:
lempiras per US dollar - 15.1407 (December 2000), 15.1407
(2000), 14.5039 (1999), 13.8076 (1998), 13.0942 (1997), 12.8694
(1996)
Hong Kong:
Hong Kong dollars per US dollar - 7.7990 (January 2001),
7.7912 (2000), 7.7575 (1999), 7.7453 (1998), 7.7421 (1997), 7.7343
(1996); note - Hong Kong became a special administrative region of
China on 1 July 1997; before then, the Hong Kong dollar was linked
to the US dollar at the rate of about 7.8 Hong Kong dollars per US
dollar
Hungary:
forints per US dollar - 282.240 (January 2001), 282.179
(2000), 237.146 (1999), 214.402 (1998), 186.789 (1997), 152.647
(1996)
Iceland:
Icelandic kronur per US dollar - 84.810 (January 2001),
78.676 (2000), 72.335 (1999), 70.958 (1998), 70.904 (1997), 66.500
(1996)
India:
Indian rupees per US dollar - 46.540 (January 2001), 44.942
(2000), 43.055 (1999), 41.259 (1998), 36.313 (1997), 35.433 (1996)
Indonesia:
Indonesian rupiahs per US dollar - 10,000 (January 2001),
8,421.8 (2000), 7,855.2 (1999), 10,013.6 (1998), 2,909.4 (1997),
2,342.3 (1996)
Iran:
Iranian rials per US dollar - 1,754.71 (January 2001),
1,764.43 (2000), 1,725.93 (1999), 1,751.86 (1998), 1,752.92 (1997),
1,750.76 (1996)
note: Iran has three officially recognized exchange rates; the
averages for 1999 are as follows: the official floating rate of
1,750 rials per US dollar, the "export" rate of 3,000 rials per US
dollar, and the variable Tehran Stock Exchange rate, which averages
7,863 rials per US dollar; the market rate averages 8,615 rials per
US dollar
Iraq:
Iraqi dinars per US dollar - 0.3109 (fixed official rate since
1982); black market rate - Iraqi dinars per US dollar - 1,910
(December 1999), 1,815 (December 1998), 1,530 (December 1997), 910
(December 1996), 3,000 (December 1995); note - subject to wide
fluctuations
Ireland:
Irish pounds per US dollar - 1.0658 (January 2001), 1.0823
(2000), 0.9374 (1999), 0.7014 (1998), 0.6588 (1997), 0.6248 (1996)
Israel:
new Israeli shekels per US dollar - 4.0810 (December 2000),
4.0773 (2000), 4.1397 (1999), 3.8001 (1998), 3.4494 (1997), 3.1917
(1996)
Italy:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); Italian lire per US dollar - 1,688.7 (January 1999),
1,736.2 (1998), 1,703.1 (1997), 1,542.9 (1996)
Jamaica:
Jamaican dollars per US dollar - 45.557 (January 2001),
42.701 (2000), 39.044 (1999), 36.550 (1998), 35.404 (1997), 37.120
(1996)
Japan:
yen per US dollar - 117.10 (January 2001), 107.77 (2000),
113.91 (1999), 130.91 (1998), 120.99 (1997), 108.78 (1996)
Jersey:
Jersey pounds per US dollar - 0.6764 (January 2001), 0.6596
(2000), 0.6180 (1999), 0.6037 (1998), 0.6106 (1997), 0.6403 (1996);
the Jersey pound is at par with the British pound
Jordan:
Jordanian dinars per US dollar - 0.7090 (1996-present )
note: since May 1989, the Jordanian dinar has been pegged to a
group of currencies
Kazakhstan:
tenge per US dollar - 145.09 (January 2001), 142.13
(2000), 119.52 (1999), 78.30 (1998), 75.44 (1997), 67.30 (1996)
Kenya:
Kenyan shillings per US dollar - 78.733 (December 2000),
76.176 (2000), 70.326 (1999), 60.367 (1998), 58.732 (1997), 57.115
(1996)
Kiribati:
Australian dollars per US dollar - 1.7995 (January 2001),
1.7173 (2000), 1.5497 (1999), 1.5888 (1998), 1.3439 (1997), 1.2773
(1996)
Korea, North:
official: North Korean won per US dollar - 2.15 (May
1994), 2.13 (May 1992), 2.14 (September 1991), 2.1 (January 1990),
2.3 (December 1989); market: North Korean won per US dollar - 200
Korea, South:
South Korean won per US dollar - 1,271.89 (January
2001), 1,130.96 (2000), 1,188.82 (1999), 1,401.44 (1998), 951.29
(1997), 804.45 (1996)
Kuwait:
Kuwaiti dinars per US dollar - 0.3057 (January 2001), 0.3067
(2000), 0.3044 (1999), 0.3047 (1998), 0.3033 (1997), 0.2994 (1996)
Kyrgyzstan:
soms per US dollar - 48.701 (January 2001), 47.704
(2000), 39.008 (1999), 20.838 (1998), 17.362 (1997), 12.810 (1996)
Laos:
kips per US dollar - 7,578.00 (December 2000), 7,102.03
(1999), 3,298.33 (1998), 1,259.98 (1997), 921.02 (1996)
Latvia:
lati per US dollar - 0.614 (January 2001), 0.607 (2000),
0.585 (1999), 0.590 (1998), 0.581 (1997), 0.551 (1996)
Lebanon:
Lebanese pounds per US dollar - 1,507.5 (January 2001),
1,507.5 (2000), 1,507.8 (1999), 1,516.1 (1998), 1,539.5 (1997),
1,571.4 (1996)
Lesotho:
maloti per US dollar - 7.78307 (January 2001), 6.93983
(2000), 6.10948 (1999), 5.52828 (1998), 4.60796 (1997), 4.29935
(1996); note - the Lesotho loti is at par with the South African
rand which is also legal tender; maloti is the plural form of loti
Liberia:
Liberian dollars per US dollar - 39.8100 (December 2000),
41.0483 (2000), 41.9025 (1999), 41.5075 (1998), 1.0000 (officially
fixed rate 1940-97); market exchange rate: Liberian dollars per US
dollar - 40 (December 1998), 50 (October 1995)
note: until December 1997, rates were based on a fixed relationship
with the US dollar; beginning in January 1998, rates are market
determined
Libya:
Libyan dinars per US dollar - 0.5101 (January 2001), 0.5081
(2000), 0.4616 (1999), 0.3785 (1998), 0.3891 (1997), 0.3651 (1996)
note: Libya currently has two rates for foreign trade; one for
government operations and foreign companies and one for Libyan
individuals (0.45 dinars per US dollar in December 1998)
Liechtenstein:
Swiss francs per US dollar - 1.6303 (January 2001),
1.6888 (2000), 1.5022 (1999), 1.4498 (1998), 1.4513 (1997), 1.2360
(1996)
Lithuania:
litai per US dollar - 4.000 (fixed rate since 1 May
1994); note - litai is the plural of litas
Luxembourg:
euros per US dollar - 1.0659 (January 2001), 1.0854
(2000), 0.9386 (1999); Luxembourg francs per US dollar - 34.77
(January 1999), 36.299 (1998), 35.774 (1997), 30.962 (1996); note -
the Luxembourg franc is at par with the Belgian franc, which
circulates freely in Luxembourg
Macau:
patacas per US dollar - 8.033 (January 2001), 8.025 (2000),
7.990 (1999), 7.978 (1998), 7.974 (1997), 7.966 (1996); note -
linked to the Hong Kong dollar at the rate of 1.03 patacas per Hong
Kong dollar
Macedonia, The Former Yugoslav Republic of:
Macedonian denars per US
dollar - 64.757 (January 2001), 65.904 (2000), 56.902 (1999), 54.462
(1998), 50.004 (1997), 39.981 (1996)
Madagascar:
Malagasy francs per US dollar - 6,656.3 (November 2000),
6,283.8 (1999), 5,441.4 (1998), 5,090.9 (1997), 4,061.3 (1996)
Malawi:
Malawian kwachas per US dollar - 80.0946 (December 2000),
59.5438 (2000), 44.0881 (1999), 31.0727 (1998), 16.4442 (1997),
15.3085 (1996)
Malaysia:
ringgits per US dollar - 3.8000 (January 2001), 3.8000
(2000), 3.8000 (1999), 3.9244 (1998), 2.8133 (1997), 2.5159 (1996)
Maldives:
rufiyaa per US dollar - 11.770 (fixed rate since 1995)
Mali:
Communaute Financiere Africaine francs (XOF) per US dollar -
699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95 (1998),
583.67 (1997), 511.55 (1996); note - from 1 January 1999, the XOF is
pegged to the euro at a rate of 655.957 XOF per euro
Malta:
Maltese liri per US dollar - 0.4370 (January 2001), 0.4376
(2000), 0.3994 (1999), 0.3885 (1998), 0.3857 (1997), 0.3604 (1996)
Man, Isle of:
Manx pounds per US dollar - 0.6764 (January 2001),
0.6596 (2000), 0.6180 (1999), 0.6037 (1998), 0.6106 (1997), 0.6403
(1996); the Manx pound is at par with the British pound
Marshall Islands:
the US dollar is used
Martinique:
euros per US dollar - 1.0659 (January 2001), 1.0854
(2000), 0.9386 (1999); French francs per US dollar - 5.8995 (1998),
5.8367 (1997), 5.1155 (1996)
Mauritania:
ouguiyas per US dollar - 250.870 (December 2000),
238.923 (2000), 209.514 (1999), 188.476 (1998), 151.853 (1997),
137.222 (1996)
Mauritius:
Mauritian rupees per US dollar - 27.900 (January 2001),
26.250 (2000), 25.186 (1999), 22.993 (1998), 21.057 (1997), 17.948
(1996)
Mayotte:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); French francs per US dollar - 5.8995 (1998), 5.8367
(1997), 5.1155 (1996)
Mexico:
Mexican pesos per US dollar - 9.7701 (January 2001), 9.4556
(2000), 9.5604 (1999), 9.1360 (1998), 7.9185 (1997), 7.5994 (1996)
Micronesia, Federated States of:
the US dollar is used
Moldova:
lei per US dollar - 12.3728 (January 2001), 12.4342 (2000),
10.5158 (1999), 5.3707 (1998), 4.6236 (1997), 4.6045 (1996); note -
lei is the plural form of leu
Monaco:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); French francs per US dollar - 5.8995 (1998), 5.8367
(1997), 5.1155 (1996)
Mongolia:
togrogs/tugriks per US dollar - 1,097.00 (December 2000),
1,076.67 (2000), 1,072.37 (1999), 840.83 (1998), 789.99 (1997),
548.40 (1996)
Montserrat:
East Caribbean dollars per US dollar - 2.7000 (fixed
rate since 1976)
Morocco:
Moroccan dirhams per US dollar - 10.590 (January 2001),
10.626 (2000), 9.804 (1999), 9.604 (1998), 9.527 (1997), 8.716 (1996)
Mozambique:
meticais per US dollar - 17,331.0 (January 2001),
5,199.8 (2000), 12,775.1 (1999), 11,874.6 (1998), 11.543.6 (1997),
11,293.8 (1996)
Namibia:
Namibian dollars per US dollar - 7.78307 (January 2001),
6.93983 (2000), 6.10948 (1999), 5.52828 (1998), 4.60796 (1997),
4.29935 (1996)
Nauru:
Australian dollars per US dollar - 1.7995 (January 2001),
1.7173 (2000), 1.5497 (1999), 1.5888 (1998), 1.3439 (1997), 1.2773
(1996)
Nepal:
Nepalese rupees per US dollar - 74.129 (January 2001), 71.104
(2000), 68.239 (1999), 65.976 (1998), 58.010 (1997), 56.692 (1996)
Netherlands:
euros per US dollar - 1.0659 (January 2001), 1.0854
(2000), 0.9386 (1999); Netherlands guilders per US dollar - 1.9837
(1998), 1.9513 (1997), 1.6859 (1996)
Netherlands Antilles:
Netherlands Antillean guilders per US dollar -
1.790 (fixed rate since 1989)
New Caledonia:
Comptoirs Francais du Pacifique francs (XPF) per US
dollar - 127.11 (January 2001), 129.44 (2000), 111.93 (1999), 107.25
(1998), 106.11 (1997), 93.00 (1996); note - linked at the rate of
119.25 XPF to the euro
New Zealand:
New Zealand dollars per US dollar - 2.2502 (January
2001), 2.1863 (2000), 1.8886 (1999), 1.8632 (1998), 1.5083 (1997),
1.4543 (1996)
Nicaragua:
gold cordobas per US dollar - 12.96 (November 2000),
12.69 (2000 est.), 11.81 (1999), 10.58 (1998), 9.45 (1997), 8.44
(1996)
Niger:
Communaute Financiere Africaine francs (XOF) per US dollar -
699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95 (1998),
583.67 (1997), 511.55 (1996); note - from 1 January 1999, the XOF is
pegged to the euro at a rate of 655.957 XOF per euro
Nigeria:
nairas per US dollar - 110.005 (January 2001), 101.697
(2000), 92.338 (1999), 21.886 (1998), 21.886 (1997), 21.884 (1996)
Niue:
New Zealand dollars per US dollar - 2.2502 (January 2001),
2.1863 (2000), 1.8886 (1999), 1.8629 (1998), 1.5082 (1997), 1.4543
(1996)
Norfolk Island:
Australian dollars per US dollar - 1.7995 (January
2001), 1.7173 (2000), 1.5497 (1999), 1.5888 (1998), 1.3439 (1997),
1.2773 (1996)
Northern Mariana Islands:
the US dollar is used
Norway:
Norwegian kroner per US dollar - 8.7784 (January 2001),
8.8018 (2000), 7.7992 (1999), 7.5451 (1998), 7.0734 (1997), 6.4498
(1996)
Oman:
Omani rials per US dollar - 0.3845 (fixed rate since 1986)
Pakistan:
Pakistani rupees per US dollar - 59.152 (January 2001),
52.814 (2000), 49.118 (1999), 44.943 (1998), 40.918 (1997), 35.909
(1996)
Palau:
the US dollar is used
Panama:
balboas per US dollar - 1.000 (fixed rate)
Papua New Guinea:
kina per US dollar - 2.81 (October 2000), 2.696
(2000), 2.539 (1999), 2.058 (1998), 1.434 (1997), 1.318 (1996)
Paraguay:
guarani per US dollar - 3,570.0 (January 2001), 3,486.4
(2000), 3,119.1 (1999), 2,726.5 (1998), 2,177.9 (1997), 2,056.8
(1996); note - since early 1998, the exchange rate has operated as a
managed float; prior to that, the exchange rate was determined
freely in the market
Peru:
nuevo sol per US dollar - 3.5230 (January 2001), 3.4900
(2000), 3.383 (1999), 2.930 (1998), 2.664 (1997), 2.453 (1996)
Philippines:
Philippine pesos per US dollar - 50.969 (January 2001),
44.192 (2000), 39.089 (1999), 40.893 (1998), 29.471 (1997), 26.216
(1996)
Pitcairn Islands:
New Zealand dollars per US dollar - 2.2502
(January 2001), 2.1863 (2000), 1.8886 (1999), 1.8629 (1998), 1.5083
(1997), 1.4543 (1996)
Poland:
zlotych per US dollar - 4.3126 (December 2000), 4.3461
(2000), 3.9671 (1999), 3.4754 (1998), 3.2793 (1997), 2.6961 (1996)
Portugal:
euros per US dollar - 1.0659 (January 2001), 1.0854
(2000), 0.9386 (1999); Portuguese escudos per US dollar - 180.10
(1998), 175.31 (1997), 154.24 (1996)
Puerto Rico:
the US dollar is used
Qatar:
Qatari rials per US dollar - 3.6400 (fixed rate)
Reunion:
euros per US dollar - 1.06594 (January 2001), 1.08540
(2000), 0.9386 (1999); French francs per US dollar - 5.8995 (1998),
5.8367 (1997), 5.1155 (1996)
Romania:
lei per US dollar - 26,243.0 (January 2001), 21,708.7
(2000), 15,332.8 (1999), 8,875.6 (1998), 7,167.9 (1997), 3,084.2
(1996); note - lei is the plural form of leu
Russia:
Russian rubles per US dollar - 28.3592 (January 2001),
28.1292 (2000), 24.6199 (1999), 9.7051 (1998), 5,785 (1997), 5,121
(1996)
note: the post-1 January 1998 ruble is equal to 1,000 of the pre-1
January 1998 rubles
Rwanda:
Rwandan francs per US dollar - 432.24 (January 2001), 389.70
(2000), 333.94 (1999) 312.31 (1998), 301.53 (1997), 306.82 (1996)
Saint Helena:
Saint Helenian pounds per US dollar - 0.6764 (January
2001), 0.6596 (2000), 0.6180 (1999), 0.6037 (1998), 0.6047 (1997),
0.6403 (1996); note - the Saint Helenian pound is at par with the
British pound
Saint Kitts and Nevis:
East Caribbean dollars per US dollar - 2.7000
(fixed rate since 1976)
Saint Lucia:
East Caribbean dollars per US dollar - 2.7000 (fixed
rate since 1976)
Saint Pierre and Miquelon:
euros per US dollar - 1.06594 (January
2001), 1.08540 (2000), 0.93863 (1999); French francs per US dollar -
5.8995 (1998), 5.8367 (1997), 5.1155 (1996)
Saint Vincent and the Grenadines:
East Caribbean dollars per US
dollar - 2.7000 (fixed rate since 1976)
Samoa:
tala per US dollar - 3.3400 (January 2001), 3.2712 (2000),
3.0120 (1999), 2.9429 (1998), 2.5562 (1997), 2.4618 (1996)
San Marino:
euros per US dollar - 1.06594 (January 2001), 1.08540
(2000), 0.93863 (1999); Italian lire per US dollar - 1,736.2 (1998),
1,703.1 (1997), 1,542.9 (1996)
Sao Tome and Principe:
dobras per US dollar - 2390.04 (December
2000), 7,119.0 (1999), 6,883.2 (1998), 4,552.5 (1997), 2,203.2 (1996)
Saudi Arabia:
Saudi riyals per US dollar - 3.7450 (fixed rate since
June 1986)
Senegal:
Communaute Financiere Africaine francs (XOF) per US dollar
- 699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95
(1998), 583.67 (1997), 511.55 (1966); note - from 1 January 1999,
the XOF is pegged to the euro at a rate of 655.957 XOF per euro
Seychelles:
Seychelles rupees per US dollar - 6.0397 (November
2000), 5.6009 (2000), 5,3426 (1999), 5.2622 (1998), 5.0263 (1997),
4.9700 (1996)
Sierra Leone:
leones per US dollar - 1,653.39 (January 2001),
2,092.13 (2000), 1,804.20 (1999), 1,563.62 (1998), 981.48 (1997),
920.73 (1996)
Singapore:
Singapore dollars per US dollar - 1.7365 (January 2001),
1.7240 (2000), 1.6950 (1999), 1.6736 (1998), 1.4848 (1997), 1.4100
(1996)
Slovakia:
koruny per US dollar - 48.09 (March 2001), 46.395 (2000),
41.363 (1999), 35.233 (1998), 33.616 (1997), 30.654 (1996)
Slovenia:
tolars per US dollar - 225.93 (January 2001), 222.66
(2000), 181.77 (1999), 166.13 (1998), 159.69 (1997), 135.36 (1996)
Solomon Islands:
Solomon Islands dollars per US dollar - 5.0968
(November 2000), 5.0864 (2000), 4.8381 (1999), 4.8156 (1998), 3.7169
(1997), 3.5664 (1996)
Somalia:
Somali shillings per US dollar - 11,000 (November 2000),
2,620 (January 1999), 7,500 (November 1997 est.), 7,000 (January
1996 est.), 5,000 (1 January 1995), 2,616 (1 July 1993)
note: the Republic of Somaliland, a self-declared independent
country not recognized by any foreign government, issues its own
currency, the Somaliland shilling
South Africa:
rand per US dollar - 7.60 (March 2001), 6.93983
(2000), 6.10948 (1999), 5.52828 (1998), 4.60796 (1997), 4.29935
(1996)
Spain:
euros per US dollar - 1.0659 (January 2001), 1.0854 (2000),
0.9386 (1999); pesetas per US dollar - 149.40 (1998), 146.41 (1997),
126.66 (1996)
Sri Lanka:
Sri Lankan rupees per US dollar - 83.506 (January 2001),
77.005 (2000), 70.635 (1999), 64.450 (1998), 58.995 (1997), 55.271
(1996)
Sudan:
Sudanese dinars per US dollar - 257.44 (January 2001), 257.12
(2000), 252.55 (1999), 200.80 (1998), 157.57 (1997), 125.08 (1996)
Suriname:
Surinamese guilders per US dol','6f80371de0bcb24c834a0f73f885e390052c11a685649a74dcc24f9a4d610f21','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e355a47e1f8a04fc5239ad4575a054b5a9408b504fa0f56ccbd37ee8aef24f1a',2001,'GR','Greece','space',277,'lar - 2,178.50 (December
2000), 987.50 (December 1999), 401.00 (December 1998), 401.00
(December 1997), 401.26 (December 1996)
note: beginning in July 1994, the central bank midpoint exchange
rate was unified and became market determined; during 1998, the
exchange rate splintered into four distinct rates; in January 1999
the government floated the guilder, but subsequently fixed it when
the black-market rate plunged; the government currently allows
trading within a band of SRG 500 around the official rate
Svalbard:
Norwegian kroner per US dollar - 8.7784 (January 2001),
8.8018 (2000), 7.7992 (1999), 7.5451 (1998), 7.0734 (1997), 6.4498
(1996)
Swaziland:
emalangeni per US dollar - 7.7803 (January 2001), 6.9056
(2000), 6.1087 (1999), 5.4807 (1998), 4.6032 (1997), 4.2706 (1996);
note - the Swazi lilangeni is at par with the South African rand;
emalangeni is the plural form of lilangeni
Sweden:
Swedish kronor per US dollar - 9.4669 (January 2001), 9.1622
(2000), 8.2624 (1999), 7.9499 (1998), 7.6349 (1997), 6.7060 (1996)
Switzerland:
Swiss francs per US dollar - 1.6303 (January 2001),
1.6888 (2000), 1.5022 (1999), 1.4498 (1998), 1.4513 (1997), 1.2360
(1996)
Syria:
Syrian pounds per US dollar - 46 (2000), 46 (1998), 41.9
(January 1997)
Tajikistan:
Tajikistani somoni per US dollar - 2.2 (January 2001),
1550 (January 2000), 998 (January 1999), 350 (January 1997), 284
(January 1996)
note: the new unit of exchange was introduced on 30 October 2000,
with one somoni equal to 1,000 of the old Tajikistani rubles
Tanzania:
Tanzanian shillings per US dollar - 803.34 (December
2000), 800.41 (2000), 744.76 (1999), 664.67 (1998), 612.12 (1997),
579.98 (1996)
Thailand:
baht per US dollar - 43.078 (January 2001), 40.112 (2000),
37.814 (1999), 41.359 (1998), 31.364 (1997), 25.343 (1996)
Togo:
Communaute Financiere Africaine francs (XOF) per US dollar -
699.21 (January 2001), 711.98 (2000), 615.70 (1999), 589.95 (1998),
583.67 (1997), 511.55 (1996); note - from 1 January 1999, the XOF is
pegged to the euro at a rate of 655.957 XOF per euro
Tokelau:
New Zealand dollars per US dollar - 2.2502 (January 2001),
2.1863 (2000), 1.8886 (1999), 1.8632 (1998), 1.5083 (1997), 1.4543
(1996)
Tonga:
pa''anga per US dollar - 1.9885 (January 2001), 1.7585 (2000),
1.5991 (1999), 1.4920 (1998), 1.2635 (1997), 1.2323 (1996)
Trinidad and Tobago:
Trinidad and Tobago dollars per US dollar -
6.2688 (January 2001), 6.2998 (2000), 6.2989 (1999), 6.2983 (1998),
6.2517 (1997), 6.0051 (1996)
Tunisia:
Tunisian dinars per US dollar - 1.3753 (January 2001),
1.4667 (November 2000), 1.1862 (1999), 1.1387 (1998), 1.1059 (1997),
0.9734 (1996)
Turkey:
Turkish liras per US dollar - 677,621 (December 2000),
625,219 (2000), 418,783 (1999), 260,724 (1998), 151,865 (1997),
81,405 (1996)
Turkmenistan:
Turkmen manats per US dollar - 5,200 (January 2001),
5,200 (January 2000), 5,350 (January 1999), 4,070 (January 1997),
2,400 (January 1996)
Turks and Caicos Islands:
the US dollar is used
Tuvalu:
Tuvaluan dollars or Australian dollars per US dollar -
1.7995 (January 2001), 1.7173 (2000), 1.5497 (1999), 1.5888 (1998),
1.3439 (1997), 1.2773 (1996)
Uganda:
Ugandan shillings per US dollar - 1,700 (February 2001),
1,830.4 (January 2001), 1,644.5 (2000), 1,454.8 (1999), 1,240.2
(1998), 1,083.0 (1997), 1,046.1 (1996)
Ukraine:
hryvnia per US dollar - 5.4331 (January 2001), 5.4402
(2000), 4.1304 (1999), 2.4495 (1998), 1.8617 (1997), 1.8295 (1996)
United Arab Emirates:
Emirati dirhams per US dollar - central bank
mid-point rate: 3.6725 (since 1998); 3.6711 (1997), 3.6710 (1995-96)
United Kingdom:
British pounds per US dollar - 0.6764 (January
2001), 0.6596 (2000), 0.6180 (1999), 0.6037 (1998), 0.6106 (1997),
0.6403 (1996)
United States:
British pounds per US dollar - 0.6764 (January 2001),
0.6596 (2000), 0.6180 (1999), 0.6037 (1998), 0.6106 (1997), 0.6403
(1996); Canadian dollars per US dollar - 1.5032 (January 2001),
1.4851 (2000), 1.4857 (1999), 1.4835 (1998), 1.3846 (1997), 1.3635
(1996); French francs per US dollar - 5.65 (January 1999), 5.8995
(1998), 5.8367 (1997), 5.1155 (1996), 4.9915 (1995), 5.5520 (1994);
Italian lire per US dollar - 1,668.7 (January 1999), 1,763.2 (1998),
1,703.1 (1997), 1,542.9 (1996), 1,628.9 (1995), 1,612.4 (1994);
Japanese yen per US dollar - 117.10 (January 2001), 107.77 (2000),
113.91 (1999), 130.91 (1998), 120.99 (1997), 108.78 (1996); German
deutsche marks per US dollar - 1.69 (January 1999), 1.9692 (1998),
1.7341 (1997), 1.5048 (1996), 1.4331 (1995), 1.6228 (1994); euros
per US dollar - 1.06594 (January 2001), 1.08540 (2000), 0.93863
(1999)
note: financial institutions in France, Italy, and Germany and
eight other European countries started using the euro on 1 January
1999 with the euro replacing the local currency in consenting
countries for all transactions in 2002
Uruguay:
Uruguayan pesos per US dollar - 12.5610 (January 2001),
12.0996 (2000), 11.3393 (1999), 10.4719 (1998), 9.4418 (1997),
7.9718 (1996)
Uzbekistan:
Uzbekistani sums per US dollar - 325.0 (January 2001),
141.4 (January 2000), 111.9 (February 1999), 110.95 (December 1998),
75.8 (September 1997), 41.1 (1996)
Vanuatu:
vatu per US dollar - 143.95 (December 2000), 137.82 (2000),
129.08 (1999), 127.52 (1998), 115.87 (1997), 111.72 (1996)
Venezuela:
bolivares per US dollar - 699.700 (January 2001), 679.960
(2000), 605.717 (1999), 547.556 (1998), 488.635 (1997), 417.333
(1996)
Vietnam:
dong per US dollar - 14,530 (January 2001), 14,020 (January
2000), 13,900 (December 1998), 11,100 (December 1996), 11,193 (1995
average), 11,000 (October 1994)
Virgin Islands:
the US dollar is used
Wallis and Futuna:
Comptoirs Francais du Pacifique francs (XPF) per
US dollar - 1127.11 (January 2001), 129.43 (2000), 111.93 (1999),
107.25 (1998), 106.11 (1997), 93.00 (1996); note - linked at the
rate of 119.25 XPF to the euro
West Bank:
new Israeli shekels per US dollar - 4.0810 (December
2000), 4.0773 (2000), 4.1397 (1999), 3.8001 (1998), 3.4494 (1997),
3.1917 (1996); Jordanian dinars per US dollar - fixed rate of 0.7090
(from 1996)
Western Sahara:
Moroccan dirhams per US dollar - 10.590 (January
2001), 10.626 (2000), 9.804 (1999), 9.604 (1998), 9.527 (1997),
8.716 (1996)
Yemen:
Yemeni rials per US dollar - 164.590 (October 2000), 160.683
(2000), 155.718 (1999), 135.882 (1998), 129.281 (1997), 94.157 (1996)
Yugoslavia:
new Yugoslav dinars per US dollar - official rate: 10.0
(December 1998), 5.85 (December 1997), 5.02 (September 1996), 1.5
(early 1995); black market rate: 14.5 (December 1998), 8.9 (December
1997), 2 to 3 (early 1995)
Zambia:
Zambian kwacha per US dollar - 4,024.53 (January 2001),
3,110.84 (2000), 2,388.02 (1999), 1,862.07 (1998), 1,314.50 (1997),
1,207.90 (1996)
Zimbabwe:
Zimbabwean dollars per US dollar - 54.9451 (January 2001),
43.2900 (2000), 38.3142 (1999), 21.4133 (1998), 11.8906 (1997),
9.9206 (1996)
Taiwan:
new Taiwan dollars per US dollar - 33.082 (yearend 2000),
31.395 (yearend 1999), 32.216 (1998), 32.052 (1997), 27.5 (1996)
======================================================================
@Executive branch
Afghanistan:
on 27 September 1996, the ruling members of the Afghan
Government were displaced by members of the Islamic Taliban
movement; the Islamic State of Afghanistan has no functioning
government at this time, and the country remains divided among
fighting factions
note: the Taliban have declared themselves the legitimate
government of Afghanistan; however, the UN still recognizes the
government of Burhanuddin RABBANI; the Organization of the Islamic
Conference has left the Afghan seat vacant until the question of
legitimacy can be resolved through negotiations among the warring
factions; the country is essentially divided along ethnic lines; the
Taliban controls the capital of Kabul and approximately two-thirds
of the country including the predominately ethnic Pashtun areas in
southern Afghanistan; opposing factions have their stronghold in the
ethnically diverse north
Albania:
chief of state: President of the Republic Rexhep MEIDANI
(since 24 July 1997)
head of government: Prime Minister Ilir META (since 29 October 1999)
cabinet: Council of Ministers nominated by the prime minister and
approved by the president
elections: president elected by the People''s Assembly for a
five-year term; election last held 24 July 1997 (next to be held NA
2002); prime minister appointed by the president
election results: Rexhep MEIDANI elected president; People''s
Assembly vote by number - total votes 122, for 110, against 3,
abstained 2, invalid 7
Algeria:
chief of state: President Abdelaziz BOUTEFLIKA (since 28
April 1999)
head of government: Prime Minister Ali BENFLIS (since 26 August
2000)
cabinet: Cabinet of Ministers appointed by the president
elections: president elected by popular vote for a five-year term;
election last held 15 April 1999 (next to be held NA April 2004);
prime minister appointed by the president
election results: Abdelaziz BOUTEFLIKA elected president; percent
of vote - Abdelaziz BOUTEFLIKA over 70%; note - his six opposing
candidates withdrew on the eve of the election citing electoral fraud
American Samoa:
chief of state: President George W. BUSH of the US
(since 20 January 2001) and Vice President Richard B. CHENEY (since
20 January 2001)
head of government: Governor Tauese P. SUNIA (since 3 January 1997)
and Lieutenant Governor Togiola TULAFONO (since 3 January 1997)
cabinet: NA
elections: US president and vice president elected on the same
ticket for four-year terms; governor and lieutenant governor elected
on the same ticket by popular vote for four-year terms; election
last held 7 November 2000 (next to be held NA November 2004)
election results: Tauese P. SUNIA reelected governor; percent of
vote - Tauese P. SUNIA (Democrat) 50.7%, Lealaifuaneva Peter REID
(independent) 47.8%
Andorra:
chief of state: French Coprince Jacques CHIRAC (since 17
May 1995), represented by Frederic de SAINT-SERNIN (since NA);
Spanish Coprince Episcopal Monseigneur Joan MARTI Alanis (since 31
January 1971), represented by Nemesi MARQUES OSTE (since NA)
head of government: Executive Council President Marc FORNE Molne
(since 21 December 1994)
cabinet: Executive Council or Govern designated by the Executive
Council president
elections: Executive Council president elected by the General
Council and formally appointed by the coprinces for a four-year
term; election last held 16 February 1997 (next to be held NA 2001)
election results: Marc FORNE Molne elected executive council
president; percent of General Council vote - 64%
Angola:
chief of state: President Jose Eduardo DOS SANTOS (since 21
September 1979); note - the president is both chief of state and
head of government
head of government: President Jose Eduardo DOS SANTOS (since 21
September 1979); note - the president is both chief of state and
head of government
cabinet: Council of Ministers appointed by the president
elections: President DOS SANTOS originally elected (in 1979)
without opposition under a one-party system and stood for reelection
in Angola''s first multiparty elections 29-30 September 1992 (next to
be held NA)
election results: DOS SANTOS 49.6%, Jonas SAVIMBI 40.1%, making a
run-off election necessary; the run-off was not held and SAVIMBI''s
National Union for the Total Independence of Angola (UNITA)
repudiated the results of the first election; the civil war resumed
Anguilla:
chief of state: Queen ELIZABETH II (since 6 February
1952); represented by Governor Peter JOHNSTON (since NA February
2000)
head of government: Chief Minister Osbourne FLEMING (since 3 March
2000)
cabinet: Executive Council appointed by the governor from among the
elected members of the House of Assembly
elections: none; the monarch is hereditary; governor appointed by
the monarch; chief minister appointed by the governor from among the
members of the House of Assembly
Antigua and Barbuda:
chief of state: Queen ELIZABETH II (since 6
February 1952), represented by Governor General James B. CARLISLE
(since NA 1993)
head of government: Prime Minister Lester Bryant BIRD (since 8
March 1994)
cabinet: Council of Ministers appointed by the governor general on
the advice of the prime minister
elections: none; the monarch is hereditary; governor general chosen
by the monarch on the advice of the prime minister; prime minister
appointed by the governor general
Argentina:
chief of state: President Fernando DE LA RUA (since 10
December 1999); Vice President Carlos "Chacho" ALVAREZ resigned 6
October 2000 and a replacement has not yet been named; note - the
president is both the chief of state and head of government
head of government: President Fernando DE LA RUA (since 10 December
1999); Vice President Carlos "Chacho" ALVAREZ resigned 6 October
2000 and a replacement has not yet been named; note - the president
is both the chief of state and head of government
cabinet: Cabinet appointed by the president
elections: president and vice president elected on the same ticket
by popular vote for four-year terms; election last held 24 October
1999 (next to be held NA October 2003)
election results: Fernando DE LA RUA elected president; percent of
vote - 48.5%
Armenia:
chief of state: President Robert KOCHARIAN (since 30 March
1998)
head of government: Prime Minister Andranik MARKARYAN (since 12 May
2000)
cabinet: Council of Ministers appointed by the prime minister
elections: president elected by popular vote for a five-year term;
special election last held 30 March 1998 (next to be held NA March
2003); prime minister appointed by the president
election results: Robert KOCHARIAN elected president; percent of
vote - Robert KOCHARIAN 59.5%, Karen DEMIRCHYAN 40.5%
Aruba:
chief of state: Queen BEATRIX Wilhelmina Armgard of the
Netherlands (since 30 April 1980), represented by Governor General
Olindo KOOLMAN (since 1 January 1992)
head of government: Prime Minister Jan (Henny) H. EMAN (since 29
July 1994) and Deputy Prime Minister Lili BEKE-MARTINEZ
cabinet: Council of Ministers (elected by the Staten)
elections: the monarch is hereditary; governor general appointed
for a six-year term by the monarch; prime minister and deputy prime
minister elected by the Staten for four-year terms; election last
held 12 July 1997 (next to be held by December 2001)
election results: Jan (Henny) H. EMAN elected prime minister;
percent of legislative vote - NA%; Lili BEKE-MARTINEZ elected deputy
prime minister; percent of legislative vote - NA%
Australia:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Rev. Peter HOLLINGSWORTH
(since 29 June 2001)
head of government: Prime Minister John Winston HOWARD (since 11
March 1996); Deputy Prime Minister John ANDERSON (since NA)
cabinet: Cabinet selected from among the members of Federal
Parliament by the governor general on the advice of the prime
minister
elections: none; the monarch is hereditary; governor general
appointed by the monarch; following legislative elections, the
leader of the majority party or leader of a majority coalition is
usually appointed prime minister by the governor general for a
three-year term
note: government coalition - Liberal Party and National Party
Austria:
chief of state: President Thomas KLESTIL (since 8 July
1992)
head of government: Chancellor Wolfgang SCHUESSEL (OeVP)(since 4
February 2000); Vice Chancellor Susanne RIESS-PASSER (FPOe) (since 4
February 2000)
cabinet: Council of Ministers chosen by the president on the advice
of the chancellor
elections: president elected by direct popular vote for a six-year
term; presidential election last held 19 April 1998 (next to be held
in the spring of 2004); chancellor traditionally chosen by the
president from the plurality party in the National Council; in the
case of the current coalition, the chancellor was chosen from
another party after the plurality party failed to form a government;
vice chancellor chosen by the president on the advice of the
chancellor
election results: Thomas KLESTIL reelected president; percent of
vote - Thomas KLESTIL 63%, Gertraud KNOLL 14%, Heide SCHMIDT 11%,
Richard LUGNER 10%, Karl NOWAK 2%
note: government coalition - OeVP and FPOe
Azerbaijan:
chief of state: President Heydar ALIYEV (since 18 June
1993)
head of government: Prime Minister Artur RASIZADE (since 26
November 1996)
cabinet: Council of Ministers appointed by the president and
confirmed by the National Assembly
elections: president elected by popular vote to a five-year term;
election last held 11 October 1998 (next to be held NA October
2003); prime minister and first deputy prime ministers appointed by
the president and confirmed by the National Assembly
election results: Heydar ALIYEV reelected president; percent of
vote - Heydar ALIYEV 77.6%, Etibar MAMEDOV 11.8%, Nizami SULEYMANOV
8.2%
Bahamas, The:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Orville TURNQUEST (since
2 January 1995)
head of government: Prime Minister Hubert Alexander INGRAHAM (since
19 August 1992) and Deputy Prime Minister Frank WATSON (since
December 1994)
cabinet: Cabinet appointed by the governor general on the prime
minister''s recommendation
elections: none; the monarch is hereditary; governor general
appointed by the monarch; prime minister and deputy prime minister
appointed by the governor general
Bahrain:
chief of state: Amir HAMAD bin Isa Al Khalifa (since 6
March 1999); Heir Apparent Crown Prince SALMAN bin Hamad (son of the
monarch, born 21 October 1969)
head of government: Prime Minister KHALIFA bin Salman Al Khalifa
(since NA 1971)
cabinet: Cabinet appointed by the monarch
elections: none; the monarch is hereditary; prime minister
appointed by the monarch
Bangladesh:
chief of state: President Shahabuddin AHMED (since 9
October 1996); note - the president''s duties are normally
ceremonial, but with the 13th amendment to the constitution
("Caretaker Government Amendment"), the president''s role becomes
significant at times when Parliament is dissolved and a caretaker
government is installed - at presidential direction - to supervise
the elections
head of government: Prime Minister Sheikh HASINA (since 13 July
1996)
cabinet: Cabinet selected by the prime minister and appointed by
the president
elections: president elected by National Parliament for a five-year
term; election last held 24 July 1996 (next to be held by NA October
2001); following legislative elections, the leader of the party that
wins the most seats is usually appointed prime minister by the
president
election results: Shahabuddin AHMED elected president without
opposition; percent of National Parliament vote - NA%
Barbados:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Clifford Straughn
HUSBANDS (since 1 June 1996)
head of government: Prime Minister Owen Seymour ARTHUR (since 6
September 1994); Deputy Prime Minister Billie MILLER (since 6
September 1994)
cabinet: Cabinet appointed by the governor general on the advice of
the prime minister
elections: none; the monarch is hereditary; governor general
appointed by the monarch; prime minister appointed by the governor
general
Belarus:
chief of state: President Aleksandr LUKASHENKO (since 20
July 1994)
head of government: Prime Minister Vladimir YERMOSHIN (since 18
February 2000); First Deputy Prime Minister Andrey KOBYAKOV (since
13 March 2000); Deputy Prime Ministers Mikhail DEMCHUK (since 14
July 2000), Mikhail KHORSTOV (since 27 November 2000), Valeriy
KOKOREV (since 23 August 1994), Leonid KOZIK (since 4 February
1997), Gennadiy NOVITSKIY (since 11 February 1997), Aleksandr POPKOV
(since 10 November 1998)
cabinet: Council of Ministers
elections: president elected by popular vote for a five-year term;
first election took place 23 June and 10 July 1994 (next to be held
NA; according to the 1994 constitution, the next election should
have been held in 1999, however LUKASHENKO extended his term to 2001
via the November 1996 referendum); prime minister and deputy prime
ministers appointed by the president
election results: Aleksandr LUKASHENKO elected president; percent
of vote - Aleksandr LUKASHENKO 85%, Vyacheslav KEBICH 15%
Belgium:
chief of state: King ALBERT II (since 9 August 1993); Heir
Apparent Prince PHILIPPE, son of the monarch
head of government: Prime Minister Guy VERHOFSTADT (since 13 July
1999)
cabinet: Council of Ministers appointed by the monarch and approved
by Parliament
elections: none; the monarch is hereditary; prime minister
appointed by the monarch and then approved by Parliament
note: government coalition - VLD, PRL, PS, SP, AGALEV, and ECOLO
Belize:
chief of state: Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Sir Colville YOUNG (since 17
November 1993)
head of government: Prime Minister Said MUSA (since 27 August
1998); Deputy Prime Minister John BRICENO (since 1 September 1998)
cabinet: Cabinet appointed by the governor general on the advice of
the prime minister
elections: none; the monarch is hereditary; governor general
appointed by the monarch; governor general appoints the member of
the House of Representatives who is leader of the majority party to
be prime minister
Benin:
chief of state: President Mathieu KEREKOU (since 4 April
1996); note - the president is both the chief of state and head of','d3cf3a9718fabce8ddd3890b478872d6de4fc4b6763f2e928d2ceb1f189279fc','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

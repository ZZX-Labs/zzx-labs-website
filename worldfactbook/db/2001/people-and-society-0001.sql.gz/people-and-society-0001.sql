SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96e9460e64ba76264f2274ec19337404691d1c61dbc59440854c2f82e2699337',2001,'EH','Western Sahara','people-and-society',10,'Population
Age structure
0-14 years
15-64 years
65 years and over
Population growth rate
Birth rate
Death rate
Net migration rate
Sex ratio
at birth
under 15 years
15-64 years
65 years and over
total population
Infant mortality rate
Life expectancy at birth
total population
male
female
Total fertility rate
HIV/AIDS • adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS -deaths
Nationality
noun
adjective
Ethnic groups
Religions
Languages
Literacy
definition
total population
male
female
People - note
Population: 26,813,057 (July 2001 est.)
Age structure:
0-14 years: 422% (male 5,775,921; female
5,538,836)
15-64 years; 55.01% (male 7,644,242; female
7,106,568)
55 years and over: 2.79% (male 394,444; female
353,046) (2001 est.)
Population growth rate: 3.48% (2001 est.)
note: this rate reflects the continued return of refugees
from Iran
Birth rate: 41.42 births/1,000 population (2001 est.)
Death rate: 17.72 deaths/1 ,000 population
(2001 est.)
Net migration rate: 11.11 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1.12 male(s)/female
total population: ^ 25 male(s)/female (2001 est.)
Infant mortality rate: 147.02 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 46.24 years
male: 46.97 years
fema/e; 45.47 years (2001 est.)
Total fertility rate: 5.79 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Hazara
19%, minor ethnic groups (Aimaks, Turkmen, Baloch,
and others) 12%, Uzbek 6%
Religions: Sunni Muslim 84%, Shi''a Muslim 15%,
other 1%
Languages: Pashtu 35%, Afghan Persian (Dari)
50%, Turkic languages (primarily Uzbek and
T urkmen) 1 1 %, 30 minor languages (primarily Balochi
and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 3^.5%
male: 47.2%
female: 15% (1999 est.)
Population: 250,559 (July 2001 est.)
Age structure:
0-14 years: U^%
15-64 years: NA%
65 years and over: NA%
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun; Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy:
definition: NA
total population:
male: NA%
female: NA%
Population: 6,157,400,560 (July 2001 est.)
Age structure:
0-14 years: 29.6% (male 933,647,850; female
886,681,514)
15-64 years: 03 A% (male 1,975,418,386; female
1,931,021,694)
65 years and over: 7% (male 188,760,223; female
241,449,691) (2001 est.)
Population growth rate: 1 .25% (2001 est.)
Birth rate: 21.37 births/1,000 population (2001 est.)
Death rate: 8.93 deaths/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 .05 male(s)/female (2001 est.)
Infant mortality rate: 52.61 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 63.79 years
ma/e.'' 62.15 years
female: 65.51 years (2001 est.)
Total fertility rate: 2.73 children born/woman
(2001 est.)
HiV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA','62c25d365249b136289bee1a687082587818cb85b8a5986eba26110ae4499910','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41582c82ec7a1302fa4b7cdb6374342a34bbe1625c9c626be30124a70baa5d64',2001,'AL','Albania','people-and-society',19,'Population: 3,510,484 (July 2001 est.)
Age structure:
0-14 years: 29.53% (male 536,495; female 500,026)
15-64 years: 63.48% (male 1 ,073,351 ; female
1,155,115)
65 years and over: 0.99% (male 107,476; female
138,021) (2001 est.)
Population growth rate: 0.88% (2001 est.)
Birth rate: 19.01 births/1,000 population (2001 est.)
Death rate: 6.5 deaths/1,000 population (2001 est.)
Net migration rate: -3.69 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 male(s)/fema!e
15-64 years: 0.93 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.90 male(s)/female (2001 est.)
Infant mortality rate: 39.99 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .83 years
male: 69.01 years
femate: 74.87 years (2001 est.)
Total fertility rate: 2.32 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (2000 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greeks 3%, other 2%
(Vlachs, Gypsies, Serbs, and Bulgarians) (1989 est.)
3
Albania (continued)
note: in 1 989, other estimates of the Greek population
ranged from 1% (official Albanian statistics) to 12%
(from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%,
Roman Catholic 10%
note: all mosques and churches were closed in 1967
and religious observances prohibited; in November
1990, Albania began allowing private religious
practice
Languages: Albanian (Tosk is the official dialect),
Greek
Literacy:
definition: age 9 and over can read and write
total population: 93% (1997 est.)
male: NA%
female: NA%
Population: 31 ,736,053 (July 2001 est.)
Age structure:
0-14 years: 34.21% (male 5,528,755; female
5,328,083)
15-64 years: eM2% (male 9,901,319; female
9,687,449)
65 years and over: 4.07% (male 594,973; female
695,474) (2001 est.)
Population growth rate: 1.71% (2001 est.)
Birth rate: 22.76 births/1,000 population (2001 est.)
Death rate: 5.22 deaths/1,000 population
(2001 est.)
Net migration rate: -0.45 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 40.56 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.95 years
male: 68.6 years
female: 71 .34 years (2001 est.)
Total fertility rate: 2.72 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
r?0[7n;Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less
than 1%
Religions: Sunni Muslim (state religion) 99%,
Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 15 and over can read and write
total population: 01.0%
male: 73.9%
fema/e;49%(1995 est.)','ca4a6a33dd2a2f1992f913cb31a046c32d9b4acefac4aed5504dad4979d0fb38','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b8870cdce211083c89f90f9a5065ef36833e2c958af687194e63b4895688168',2001,'AS','American Samoa','people-and-society',29,'Population: 67,084 (July 2001 est.)
Age structure;
0-14 years: 3QM% (male 13,278; female 12,512)
15-64 years: 56.57% (male 18,784; female 19,163)
65 years and over: 4.99% (male 1 ,779; female 1 ,568)
(2001 est.)
Population growth rate: 2.42% (2001 est.)
Birth rate: 24.88 births/1 ,000 population (2001 est.)
Death rate: 4.31 deaths/1,000 population
(2001 est.)
Net migration rate: 3.58 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 10.36 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.32 years
male: 70.89 years
female: 80.02 years (2001 est.)
Total fertility rate: 3.5 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%,
Caucasian 2%, Tongan 4%, other 5%
Religions: Christian Congregationalist 50%, Roman
Catholic 20%, Protestant and other 30%
Languages: Samoan (closely related to Hawaiian
and other Polynesian languages), English
note: most people are bilingual
8
American Samoa (continued)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
fema/e; 97% (1980 est.)','635f556ebb34e8720f44114706d19382238790357c1c904de3301993b1164271','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8f303cac72e0bcc8463223d18d54f1f9c536d653550c51b79925c5222aacf4c',2001,'AD','Andorra','people-and-society',36,'Population: 67,627 (July 2001 est.)
Age structure:
0-14 years: 15.29% (male 5,425; female 4,917)
15-64 years: 72.06% (male 25,654; female 23,078)
65 years and over; 12.65% (male 4,299; female
4,254) (2001 est.)
Population growth rate: 1.17% (2001 est.)
Birth rate: 10.29 births/1,000 population (2001 est.)
Death rate: 5.41 deaths/1,000 population
(2001 est.)
Net migration rate: 6.82 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: male(s)/fema!e
15-64 years: 1.11 male(s)/female
65 years and over: 1.01 ma!e(s)/female
total population: 1.1 male(s)/female (2001 est.)
Infant mortality rate: 4.08 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 83.47 years
male: 80.57 years
female: 86.57 years (2001 est.)
Total fertility rate: 1 .25 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HiV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 43%, Andorran 33%,
Portuguese 1 1 %, French 7%, other 6% (1 998)
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy:
definition: NA
total population: 100%
male: NA%
female: NA%','ad40b0b156ad5d5e84e830847548266143cd81b8afda7df072d4d54dc525f05b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e81b3219ae80779e05ed0df52227f2ad4e982cbadc860be55c2a686370a84572',2001,'AI','Anguilla','people-and-society',51,'Population: 12,132 (July 2001 est.)
Age structure:
0-14 years: 25.55% (male 1,574; female 1,526)
15-64 years: 67.47% (male 4,200; female 3,985)
65 years and over: 6.98% (male 376; female 471)
(2001 est.)
Population growth rate: 2.68% (2001 est.)
Birth rate: 15.17 births/1 ,000 population (2001 est.)
Death rate: 5.61 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1 7.23 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1.03 male(s)/female (2001 est.)
Infant mortality rate: 24.56 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.31 years
male: 73.41 years
female: 79.29 years (2001 est.)
Total fertility rate: 1 .79 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HiV/AIDS- deaths: NA
Nationality:
noun: Anguil!an(s)
adjective: Anguillan
Ethnic groups: black
Religions: Anglican 40%, Methodist 33%,
Seventh-Day Adventist 7%, Baptist 5%, Roman
Catholic 3%, other 12%
Languages: English (official)
Literacy:
definition: age 12 and over can read and write
total population: 95%
male: 95%
fema/e.'' 95% (1984 est.)','48e02271c5e9709cf06507780afde4b14e601a24abc99b51ec0c58bb1077585e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ee70ed88adb988a6153d3eed6d7c945f08ca743cd773986ce9ab108cb90c97d',2001,'AQ','Antarctica','people-and-society',58,'Population: no indigenous inhabitants, but there are
seasonally staffed research stations
note: approximately 29 nations, all signatory to the
Antarctic Treaty, send personnel to perform seasonal
(summer) and year-round research on the continent
and in its surrounding oceans; the population of
persons doing and supporting science on the
continent and its nearby islands south of 60 degrees
south latitude (the region covered by the Antarctic
Treaty) varies from approximately 4,000 in summer to
1,000 in winter; in addition, approximately 1,000
personnel including ship''s crew and scientists doing
onboard research are present in the waters of the
treaty region; Summer (January) population - 3,687
total; Argentina 302, Australia 201 , Belgium 1 3, Brazil
80, Bulgaria 16, Chile 352, China 70, Finland 1 1 ,
France 100, Germany 51 , India 60, Italy 106, Japan
136, South Korea 14, Netherlands 10, NZ 60, Norway
40, Peru 28, Poland 70, Russia 254, South Africa 80,
Spain 43, Sweden 20, UK 192, US 1 ,378 (1998-99);
Winter (July) population - 964 total; Argentina 165,
Australia 75, Brazil 12, Chile 129, China 33, France
33, Germany 9, India 25, Japan 40, South Korea 14,
NZ 10, Poland 20, Russia 102, South Africa 10, UK
39, US 248 (1 998-99); year-round stations - 42 total;
Argentina 6, Australia 4, Brazil 1, Chile 4, China 2,
Finland 1 , France 1 , Germany 1 , India 1 , Italy 1 , Japan
1, South Korea 1, NZ 1, Norway 1, Poland 1, Russia
6, South Africa 1 , Spain 1 , Ukraine 1 , UK 2, US 3,
Uruguay 1 (1 998-99); Summer-only stations - 32 total;
Argentina 3, Australia 4, Bulgaria 1 , Chile 7, Germany
1 , India 1 , Japan 3, NZ 1 , Peru 1 , Russia 3, Sweden
2, UK 5 (1998-99); in addition, during the austral
summer some nations have numerous occupied
locations such as tent camps, summer-long
temporary facilities, and mobile traverses in support of
research (July 2001 est.)
Population: 3,336,100 (July 2001 est.)
Age structure:
0-14 years: 23.23% (male 394,194; female 380,91 1)
15-64 years: 67.04% (male 1 ,094,646; female
1,141,760)
65 years and over: 9.73% (male 1 35,477; female
189,112) (2001 est.)
Population growth rate: -0.21% (2001 est.)
Birth rate: 1 1 .47 births/1 ,000 population (2001 est.)
Death rate: 9.74 deaths/1 ,000 population
(2001 est.)
Net migration rate: -3.87 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 41 .27 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 66.49 years
ma/e.- 62.12 years
female: 71.08 years (2001 est.)
Total fertility rate: 1 .5 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian
2%, other (mostly Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had
emigrated from Armenia
Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy;
definition: age 15 and over can read and write
total population: 99%
male: 99%
fema/e.- 98% (1989 est.)
Population: 70,007 (July 2001 est.)
Age structure:
0-14 years: 21.29% (male 7,709; female 7,193)
15-64 years: 68.52% (male 23,1 1 1 ; female 24,859)
65 years and over; 10. 19% (male 2,954; female
4,181) (2001 est.)
Population growth rate: 0.64% (2001 est.)
Birth rate: 12.64 births/1,000 population (2001 est.)
Death rate: 6.21 deaths/1,000 population
(2001 est.)
Net migration rate: NEGL
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years.* 1.07 male(s)/female
15-64 years: 0.93 male(s)/female
55 years and over; 0.71 ma!e(s)/fema!e
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 6.39 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.52 years
ma/e; 75.1 6 years
female: 82.04 years (2001 est.)
Total fertility rate: 1 .8 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Aruban(s)
adjective: Aruban; Dutch
Ethnic groups: mixed white/Caribbean Amerindian
80%
Religions: Roman Catholic 82%, Protestant 8%,
Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish,
Portuguese, Dutch, English dialect), English (widely
spoken), Spanish
Literacy:
definition: NA
total population: 97%
male: NA%
female: NA%
Population: no indigenous inhabitants
nofe; there are only seasonal caretakers (July
2001 est.)','c13159e645281cc639581c81872ddb05f96d55364a5c5f97b69c6a81afab2fce','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cbe61ea8ea80b4a556f091109b4c7fe8bc66d2d8cd4bfd17ce00867e748466b',2001,'AG','Antigua and Barbuda','people-and-society',66,'Population: 66,970 (July 2001 est.)
Age structure;
0-14 years: 27.97% (male 9,527; female 9,203)
15-64 years: 67.15% (male 22,450; female 22,519)
65 years and over: 4.88% (male 1 ,360; female 1 ,91 1 )
(2001 est.)
Population growth rate; 0.74% (2001 est.)
Birth rate: 19.5 births/1 ,000 population (2001 est.)
Death rate: 5.87 deaths/1,000 population
(2001 est.)
Net migration rate: -6.27 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7^ male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 22.33 deaths/1,000 live births
(2001 est.)
Life expectancy at birth;
total population: 70.74 years
male: 68.45 years
fema/e; 73.1 4 years (2001 est.)
Total fertility rate: 2.31 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate; NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
not/n; Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese,
Lebanese, Syrian
Religions: Anglican (predominant), other Protestant,
some Roman Catholic
Languages: English (official), local dialects
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 89%
male: 90%
fema/e; 88% (1960 est.)','01c5a92f03834fea1e94d2ebc64eaa5016a415b87700721b0889be6faa1d3e87','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7e60ec5cbf25110c0ef47b451b448c509205a79585dc8fcbaab911c2b7ed03',2001,'AR','Argentina','people-and-society',79,'Population: 37,384,816 (July 2001 est.)
Age structure:
0-14 years: 26.54% (male 5,077,593; female
4,842,811)
15-64 years: 63.04% (male 1 1 ,795,282; female
11,773,855)
21
Argentina (continued)
65 years and over: 10.42% (male 1 ,609,672; female
2,285,603) (2001 est.)
Population growth rate: 1.15% (2001 est.)
Birth rate: 18.41 births/1,000 population (2001 est.)
Death rate: 7.58 deaths/1,000 population
(2001 est.)
Net migration rate: 0.64 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1,06 male(s)/female
under 15 years: 1.0b male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 17.75 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.26 years
male: 71. QQ years
female: 78.82 years (2001 est.)
Total fertility rate: 2.44 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.69%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 1 ,800 (1 999 est.)
Nationality;
noun: Argentine(s)
adjective: Argentine
Ethnic groups: white (mostly Spanish and Italian)
97%, mestizo, Amerindian, or other nonwhite groups
3%
Religions: nominally Roman Catholic 92% (less
than 20% practicing), Protestant 2%, Jewish 2%,
other 4%
Languages: Spanish (official), English, Italian,
German, French
Literacy:
definition: age 15 and over can read and write
total population: 96.2%
male: 96.2%
fema/e; 96.2% (1995 est.)
Population: 5,734,139 (July 2001 est.)
Age structure:
0-14 years: 33.9% (male 1,133,306; female
1,097,360)
15-64 years: 56.39% (male 1 ,622,743; female
1,610,659)
65 years and over: 4.71 % (male 1 24,321 ; female
145,750) (2001 est.)
Population growth rate: 2.6% (2001 est.)
Birth rate: 30.88 births/1,000 population (2001 est.)
Death rate: 4.75 deaths/1,000 population
(2001 est.)
Net migration rate: -0.09 migrant{s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female (2001 est.)
Infant mortality rate: 29.78 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.92 years
mate; 71.44 years
female: 76.52 years (2001 est.)
Total fertility rate: 4.1 1 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1 1%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS - deaths: 220 (1 999 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and
Amerindian) 95%
Religions: Roman Catholic 90%, Mennonite, and
other Protestant
Languages: Spanish (official), Guarani (official)
Literacy:
definition: age 15 and over can read and write
total popuiation: 92.1%
male: 93.5%
femate: 90.6% (1995 est.)','fe64f91d354734d3dfbd3c10833b4e1984cf826dfaf38d5eb117190a752e72b6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bf5cd16e3a3029d0c48f503556b47d2a4f1e0b5f466b871ec085c0872b4ac3a',2001,'AU','Australia','people-and-society',86,'Population: 19,357,594 (July 2001 est.)
Age structure:
0-14 years: 20.64% (male 2,045,892; female
1,948,949)
15-64 years: 66.86% (male 6,538,096; female
6,405,014)
65yearsand over: 12.5% (male 1,059,107; female
1,360,536) (2001 est)
Population growth rate: 0.99% (2001 est.)
Birth rate: 12.86 births/1,000 population (2001 est.)
Death rate: 7.18 deaths/1 ,000 population
(2001 est.)
Net migration rate: 4.1 9 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 4.97 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.87 years
male: 77.02 years
female: 82.87 years (2001 est.)
Total fertility rate: 1 .77 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS - deaths: 1 00 (1 999 est.)
Nationality:
noi/r?;Australian(s)
adjective: Australian
Ethnic groups: Caucasian 92%, Asian 7%,
aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%,
other Christian 24.3%, non-Christian 11%
Languages: English, native languages
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% {1980 est.)
Population: 8,150,835 (July 2001 est.)
Age structure:
0-14 years: 16.57% (male 691,925; female 658,375)
15-64 years: 68.05% (male 2,802,01 9; female
2,744,536)
65 years and over: 15.38% (male 478,498; female
775,482) (2001 est.)
Population growth rate: 0.24% (2001 est.)
Birth rate: 9.74 births/1,000 population (2001 est.)
Death rate: 9.8 deaths/1,000 population (2001 est.)
Net migration rate: 2.45 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 4.44 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.84 years
male: 74.68 years
female: 81 .15 years (2001 est.)
Totai fertility rate: 1 .39 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.23%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 9,000
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic groups: German 98%, Croatian, Slovene,
other (includes Hungarians, Czechs, Slovaks, Roma)
Religions: Roman Catholic 78%, Protestant 5%,
Muslim and other 17%
Languages: German
Literacy:
definition: age 1 5 and over can read and write
total population: 9Q%
male: NA%
female: NA%
Population: uninhabited (July 2001 est.)
Population: 890 (July 2001 est.)
Population growth rate: 1 .15% (2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HiV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: none
adjective: none
Ethnic groups: Italians, Swiss, other
Religions; Roman Catholic
Languages; Italian, Latin, French, various other
languages
Literacy:
definition: NA
total population: 100%
male: NA%
female: NA%
Population: uninhabited
note; American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War li, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service (July 2001 est.)
Population; 1,879 (July 2001 est.)
Age structure:
0‘14years:UA%
15’64 years: m%
65 years and over: NA%
Population growth rate: -0.71% (2001 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate; NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty
mutineers, Australian, New Zealander, Polynesians
Religions: Anglican 39%, Roman Catholic 1 1 .7%,
Uniting Church in Australia 16.4%, Seventh-Day
Adventist 4.4%, none 9.2%, unknown 16.9%, other
2.4% (1986)
Languages: English (official), Norfolk a mixture of
18th century English and ancient Tahitian
Population: 74,612 (July 2001 est.)
Age structure:
0-14 years: 23.55% (male 8,929; female 8,639)
15-64 years: 74.72% (male 26,242; female 29,509)
65 years and over: 1 .73% (male 639; female 654)
(2001 est.)
Population growth rate: 3.62% (2001 est.)
Birth rate: 20.6 births/1,000 population (2001 est.)
Death rate: 2.4 deaths/1,000 population (2001 est.)
Net migration rate: 1 8 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 03 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 0.92 male(s)/female (2001 est.)
Infant mortality rate: 5.7 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.74 years
male: 72.65 years
female: 79.02 years (2001 est.)
Total fertility rate: 1.76 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Chamorro, Carolinians and other
Micronesians, Caucasian, Japanese, Chinese,
Korean
Religions: Christian (Roman Catholic majority,
although traditional beliefs and taboos may still be
found)
Languages: English, Chamorro, Carolinian
note: 86% of population speaks a language other than
English at home
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
fema/e; 96% (1980 est.)','03509e8805ecccc290b2a32a686e151e4546fd52992015770901aa0fa3bb9345','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c3ccb9da525947d0d2a3ff63e7f3dc1096ade8c94d660ed329876b770e05852',2001,'AZ','Azerbaijan','people-and-society',93,'Population: 7,771,092 (July 2001 est.)
Age structure:
0-14 years: 28.95% (male 1,146,315; female
1,103,393)
15-54 years; 63.93% (male 2,415,678; female
2,552,759)
65 years and over: 7.1 2% (male 21 9,549; female
333,398) (2001 est.)
Population growth rate: 0.32% (2001 est.)
Birth rate; 18.44 births/1 ,000 population (2001 est.)
Death rate: 9.55 deaths/1 ,000 population
(2001 est.)
Net migration rate: -5.67 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 83.08 deaths/1 ,000 live births
(2001 est.)
34
Azerbaijan (continued)
Life expectancy at birth:
total population: 62.96 years
male: 58.65 years
female: 67.49 years (2001 est.)
Total fertility rate: 2.24 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani 3.2%,
Russian 2.5%, Armenian 2%, other 2.3% (1998 est.)
note: almost all Armenians live in the separatist
Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian Orthodox 2.5%,
Armenian Orthodox 2.3%, other 1 .8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
percentages for actual practicing adherents are much
lower
Languages: Azerbaijani (Azeri) 89%, Russian 3%,
Armenian 2%, other 6% (1995 est.)
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 99%
fema/e;96%(1989 est.)
Population: 297,852
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure;
0-14 years: 29.43% (male 44,179; female 43,486)
15-64 years: 64.46% (male 94,329; female 97,674)
65 years and over: 6.1 1 % (male 7,618; female
10,566) (2001 est.)
Population growth rate: 0.93% (2001 est.)
Birth rate: 19.1 births/1,000 population (2001 est.)
Death rate: 7.14 deaths/1 ,000 population
(2001 est.)
Net migration rate: -2.65 migrant{s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2001 est.)
Infant mortality rate: 1 7.03 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 70.46 years
male: 67.27 years
female: 73.71 years (2001 est.)
Total fertility rate; 2.3 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 4.13%
(1999 est.)
HIV/AIDS - people living with HIV/AiDS: 6,900
(1999 est.)
HIV/AIDS ■ deaths: 500 (1999 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 12%, Asian and
Hispanic 3%
Religions: Baptist 32%, Anglican 20%, Roman
Catholic 1 9%, Methodist 6%, Church of God 6%, other
Protestant 12%, none or unknown 3%, other 2%
Languages: English, Creole (among Haitian
immigrants)
Literacy:
definition: age 15 and over can read and write
total population: 982%
male: 98.5%
fema/e;98%(1995 est.)','533c3fa3d4eff286d7a457b45a915bd40654e8aafe094d269525ab2f03e90c4b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('845f90fc6440ec6e55fc2a05e8be3cb68c6802ea93847613979514a928cba43d',2001,'BH','Bahrain','people-and-society',106,'Population: 645,361
note: includes 228,424 non-nationals (July 2001 est.)
Age structure:
0-14 years: 29.6% (male 96,697; female 94,330)
15-64 years: 67.43% (male 257,360; female 177,839)
65 years and over: 2.97% (male 9,721 ; female 9,41 4)
(2001 est.)
Population growth rate: 1 .73% (2001 est.)
Birth rate: 20.07 births/1 ,000 population (2001 est.)
Death rate: 3.92 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1.1 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .45 ma!e(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1 .29 male(s)/female (2001 est.)
Infant mortality rate: 1 9.77 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.2 years
ma/e: 70.81 years
female: 75.67 years (2001 est.)
Total fertility rate: 2.79 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 63%, Asian 19%, other
Arab 10%, Iranian 8%
Religions: Shi''a Muslim 70%, Sunni Muslim 30%
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 15 and over can read and write
total population: 85.2%
mate.'' 89.1%
fema/e; 79.4% (1995 est.)
Population: uninhabited
note: American civilians evacuated in 1942 after
Japanese air and naval attacks during World War li;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; a cemetery and remnants of structures
from early settlement are located near the middle of
the west coast; visited annually by US Fish and
Wildlife Service (July 2001 est.)','049f4844e9198d4136f9eae09cb6d4b48ac61ea047c3b05875c47bc38fc6340c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3731081e287c610d3f000e19e2e0b3f0f680e800e0e5888ab1c7e3f617e3dca2',2001,'BD','Bangladesh','people-and-society',115,'Population: 131 ,269,860 (July 2001 est.)
Age structure:
0-14 years: 35.04% (male 23,550,607; female
22.451,006)
^5-64 years; 61 .6% (male 41,432,123; female
39,434,633)
65 years and over: 3.36% (male 2,389,639; female
2,011,852) (2001 est.)
Population growth rate: 1.59% (2001 est.)
Birth rate: 25.3 births/1 ,000 population (2001 est.)
Death rate: 8.6 deaths/1,000 population (2001 est.)
Net migration rate: -0.76 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: male(s)/female
under 15 years: 05 male(s)/female
/5-54 years; 1.05 male(s)/femaie
55 years and over: 1.19 male(s)/female
total population: 1 .05 male(s)/female (2001 est.)
Infant mortality rate: 69.85 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 60.54 years
male: 60.74 years
female: 60.33 years (2001 est.)
Total fertility rate: 2.78 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 13,000
(1999 est.)
HIV/AIDS - deaths: 1 ,000 (1 999 est.)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladeshi
Ethnic groups: Bengali 98%, tribal groups,
non-Bengali Muslims (1998)
Religions: Muslim 83%, Hindu 16%, other 1%
(1998)
Languages: Bangla (official, also known as Bengali),
English
Literacy:
definition: age 15 and over can read and write
total population: 56%
male: 63%
fema/e;49%(2000 est.)','fed783ee97290fee0a7b6cb27ad0ea52254b880e63848b9dd31f6c47f580a470','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ef7b09ea6c0f2f9ff75c1ff12ddef4a8887c71886e7af15e75ac5f0c0babfa6',2001,'BB','Barbados','people-and-society',123,'Population: 275,330 (July 2001 est.)
Age structure:
0-14 years: 21 .68% (male 30,122; female 29,572)
15-64 years: 69.44% (male 93,283; female 97,915)
65 years and over: 8.88% (male 9,432; female
15,006) (2001 est.)
Population growth rate: 0.46% (2001 est.)
Birth rate: 13.47 births/1,000 population (2001 est.)
Death rate: 8.53 deaths/1,000 population
(2001 est.)
Net migration rate: -0.32 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.01 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0,93 male(s)/female (2001 est.)
Infant mortality rate: 12.04 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.25 years
male: 70.66 years
female: 75.86 years (2001 est.)
Total fertility rate: 1.64 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1.17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,800
(1999 est.)
HIV/AIDS -deaths: 130 (1999 est.)
Nationality:
noun: Barbadian(s) or Bajan (colloquial)
adjective: Barbadian or Bajan (colloquial)
Ethnic groups: black 80%, white 4%, other 16%
Religions: Protestant 67% (Anglican 40%,
Pentecostal 8%, Methodist 7%, other 12%), Roman
Catholic 4%, none 17%, other 12%
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97.4%
male: 98%
fema/e; 96.8% (1995 est.)','3fa80bc059c211cae6d0ecec41c73b04387072b1ee6c6585317eaa299f651c60','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eae632c774ce5e3de92560aae21b9e1c0c90fdc128ad81e2e2ef6784b7c638b',2001,'LC','Saint Lucia','people-and-society',131,'Population: uninhabited (July 2001 est.)
Population: 158,178 (July 2001 est.)
Age structure:
0-14 years: 32A3% (male 25,951 ; female 24,874)
15-64 years: 62.59% (male 48,568; female 50,430)
65 years and over: 5.28% (male 3,120; female 5,235)
(2001 est.)
Population growth rate: 1.23% (2001 est.)
Birth rate: 21.8 births/1,000 population (2001 est.)
Death rate: 5.36 deaths/1,000 population
(2001 est.)
Net migration rate: -4.15 migrant(s)/1, 000
population (2001 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.6 male(s)/female
total population: male(s)/female (2001 est.)
Infant mortality rate: 1 5.22 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 72.57 years
male: 69 years
female: 76.39 years (2001 est.)
Total fertility rate: 2.38 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East Indian
3%, white 1%
Religions: Roman Catholic 90%, Protestant 7%,
Anglican 3%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 67%
male: 65%
fema/e.- 69% (1980 est.)
Country name:
conventional long form: none
conventional short form: Saint Lucia
Government type: Westminster-style parliamentary
democracy
Capital: Castries
Administrative divisions: 1 1 quarters;
Anse-la-Raye, Castries, ChoiseuI, Dauphin, Dennery,
Gros Islet, Laborie, Micoud, Praslin, Soufriere, Vieux
Fort
Independence: 22 February 1979 (from UK)
National holiday: Independence Day, 22 February
(1979)
Constitution: 22 February 1979
Legal system: based on English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Dr. Perlette
LOUISY (since September 1997)
head of government: Prime Minister Kenneth
ANTHONY (since 24 May 1997) and Deputy Prime
Minister Mario MICHEL (since 24 May 1997)
cabinet: Cabinet appointed by the governor generai
on the advice of the prime minister
elections: none; the monarch is hereditary; the
governor general is appointed by the monarch;
following legislative elections, the leader of the
majority party or leader of a majority coalition is
usually appointed prime minister by the governor
general
Legislative branch: bicameral Parliament consists
of the Senate (1 1 seats; six members appointed on
the advice of the prime minister, three on the advice of
the leader of the opposition, and two after consultation
with religious, economic, and social groups) and the
House of Assembly (17 seats; members are elected
by popular vote from single-member constituencies to
serve five-year terms)
elections: House of Assembly - last held 23 May 1 997
(next to be held NA 2002)
election results: House of Assembly - percent of vote
by party ■ NA%; seats by party - SLP 16, UWP 1
Judicial branch: Eastern Caribbean Supreme Court
(jurisdiction extends to Anguilla, Antigua and
Barbuda, the British Virgin Islands, Dominica,
Grenada, Montserrat, Saint Kitts and Nevis, Saint
Lucia, and Saint Vincent and the Grenadines)
Political parties and leaders: National Freedom
Party or NFP [Martinus FRANCOIS]; Saint Lucia
Labor Party or SLP [Kenneth ANTHONY]; United
Workers Party or UWP [Dr. Morelia JOSEPH]
Political pressure groups and leaders: NA
International organization participation: ACCT
(associate), ACP, C, Caricom, CDB, ECLAC, FAO,
G-77, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user),
Interpol, IOC, ISO (subscriber), ITU, NAM, OAS,
OECS, OPANAL, OPCW, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WlPO, WMO.
WTrO
Saint Lucia (continued)
Diplomatic representation in the US:
chief of mission: Ambassador Sonia Merlyn JOHNNY
chancery: 3216 New Mexico Avenue NW,
Washington, DC 20016
telephone: [1] (202) 364-6792 through 6795
FAX; [1] (202) 364-6728
consulate(s) general: Miami and New York
Diplomatic representation from the US: the US
does not have an embassy in Saint Lucia; the US
Ambassador in Barbados is accredited to Saint Lucia
Flag description: blue, with a gold isosceles triangle
below a black arrowhead; the upper edges of the
arrowhead have a white border','2126fa7d57e29e73c7ed7403f9e096bcdf5998e49ec4604e537120767cb70b11','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1daa1413b9fdb4ee2cf4e49c75d69ea1e464c05b497a19789867ede5fd7043e9',2001,'FR','France','people-and-society',138,'Population: 10,350,194 (July 2001 est.)
Age structure:
0-14 years: 17.93% (male 947,820; female 908,210)
15-64 years: 68.21 % (male 3,428,920; female
3,631,290)
65 years and over: 13.86% (male 473,992; female
959,962) (2001 est.)
Population growth rate: -0.15% (2001 est.)
Birth rate: 9.57 births/1,000 population (2001 est.)
Death rate: 13.97 deaths/1,000 population
(2001 est.)
Net migration rate: 2.89 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.49 male(s)/female
total population: O.BB male(s)/female (2001 est.)
Infant mortality rate: 1 4.38 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.14 years
male: 62.06 years
female: 74.52 years (2001 est.)
Total fertility rate: 1.28 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.28%
(1999 est.)
HIV/AIDS " people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS - deaths: 400 (1999 est.)
Nationality:
noun.’ Belarusian (s)
adjective: Belarusian
Ethnic groups: Byelorussian 81.2%, Russian
1 1 .4%, Polish, Ukrainian, and other 7.4%
Religions: Eastern Orthodox 80%, other (including
Roman Catholic, Protestant, Jewish, and Muslim)
20% (1997 est.)
Languages: Byelorussian, Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
fema/e;97%(1989 est.)
Population: 10,258,762 (July 2001 est.)
Age structure:
0-14 years: MAS% (male 916,957; female 876,029)
15-64 years: 65.57% (male 3,390,1 45; female
3,336,908)
65 years and over: 16.95% (male 709,212; female
1,029,511) (2001 est.)
Population growth rate: 0.16% (2001 est.)
Birth rate: 10.74 biilhs/1,000 population (2001 est.)
Death rate: 10.1 deaths/1,000 population
(2001 est.)
Net migration rate: 0.97 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 male(s)/female (2001 est.)
Infant mortality rate: 4.7 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.96 years
male: 74.63 years
female: 81 .46 years (2001 est.)
Total fertility rate: 1.61 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,700
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 58%, Walloon 31%, mixed
or other 11%
Religions: Roman Catholic 75%, Protestant or other
25%
Languages: Dutch 58%, French 32%, German 1 0%,
legally bilingual (Dutch and French)
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: NA%
female: NA%
Population: 633 (July 2001 est.)
Age structure:
0-14 years:
15-64 years: NA%
65 years and over: NA%
Population growth rate: -0.21% (2001 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Religions: Sunni Muslim 57%, Christian 22%, other
21% (1981 est.)
Languages: English, Malay
Population: 2,895 (July 2001 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: 2.43% (2001 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions: primarily Anglican, Roman Catholic,
United Free Church, Evangelist Church, Jehovah''s
Witnesses, Lutheran, Seventh-Day Adventist
Languages: English
Population: 59,551,227 (July 2001 est.)
Age structure:
0-M years; 18.68% (male 5,698,604; female
5,426,838)
15-64 years: 65.19% (male 19,424,018; female
19,399,588)
65 years and over: 16.13% (male 3,900,579; female
5,701,600) (2001 est.)
Population growth rate: 0.37% (2001 est.)
Birth rate: 12.1 births/1,000 population (2001 est.)
Death rate: 9.09 deaths/1 ,000 population (2001 est.)
Net migration rate: 0.64 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.% male(s)/female (2001 est.)
Infant mortality rate: 4.46 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.9 years
male: 75.01 years
female: 53.01 years (2001 est.)
Total fertility rate: 1 .75 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.44%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 2,000 (1999 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque minorities
Religions: Roman Catholic 90%, Protestant 2%,
Jewish 1%, Muslim (North African workers) 3%,
unaffiliated 4%
Languages: French 1 00%, rapidly declining regional
dialects and languages (Provencal, Breton, Alsatian,
Corsican, Catalan, Basque, Flemish)
Literacy:
definition: age 1 5 and over can read and write
total population: 09%
male: 99%
female: 99% (1980 est.)
Population: no indigenous inhabitants (July
2001 est.)
note: in 1997, there were about 100 researchers
whose numbers vary from winter (July) to summer
(January)
Population: 1,221,175
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 33.29% (male 203,677; female 202,833)
15-64 years: 60.77% (male 373,828; female 368,282)
65 years and over: 5.94% (male 35,867; female
36,688) (2001 est.)
Population growth rate: 1.02% (2001 est.)
Birth rate: 27.42 births/1 ,000 population (2001 est.)
Death rate: 1 7.22 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 ma!e(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1 .01 male(s)/female (2001 est.)
Infant mortality rate: 94.91 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 49.59 years
male: 48.47 years
female: 50.75 years (2001 est.)
Total fertility rate: 3.69 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 4.16%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 23,000
(1999 est.)
HIV/AIDS -deaths: 2,000 (1999 est.)
Nationality;
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups: Bantu tribes including four major
tribal groupings (Fang, Eshira, Bapounou, Bateke),
other Africans and Europeans 154,000, including
1 0,700 French and 1 1 ,000 persons of dual nationality
Religions: Christian 55%-75%, animist, Muslim less
than 1%
Languages: French (official). Fang, Myene, Bateke,
Bapounou/Eschira, Bandjabi
Literacy;
definition: age 15 and over can read and write
total population: 63.2%
male: 73.7%
fema/e; 53.3% (1995 est.)
Population: 1 ,41 1 ,205 (July 2001 est.)
Age structure:
0-/4 years; 45.22% (male 320,458; female 317,647)
15-64 years: 52.1 3% (male 364,900; female 370,717)
65 years and over: 2.65% (male 19,660; female
17,823) (2001 est.)
Population growth rate: 3.14% (2001 est.)
Birth rate: 41.76 births/1,000 population (2001 est.)
Death rate: 12.92 deaths/1 ,000 population
(2001 est.)
Net migration rate: 2.59 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1 .1 male(s)/female
total population: 1 male(s)/female (2001 est.)
183
Gambia, The (continued)
Infant mortality rate: 77.84 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 53.59 years
ma/e; 51.65 years
female: 55.58 years (2001 est.)
Total fertility rate: 5.68 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .95%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 13,000
(1999 est.)
HIV/AIDS -deaths: 1,400 (1999 est.)
Nationality;
noun: Gambian(s)
adjective: Gambian
Ethnic groups: African 99% (Mandinka 42%, Fula
18%, Wolof 16%, Jola 10%, Serahuli 9%, other 4%),
non-African 1%
Religions: Muslim 90%, Christian 9%, indigenous
beliefs 1%
Languages: English (official), Mandinka, Wolof,
Fula, other indigenous vernaculars
Literacy:
definition: age 15 and over can read and write
total population: 47.5%
male: 58.4%
fema/e.- 37.1% (2001 est.)
Population: 1,178,119 (July 2001 est.)
note: in addition, there are some 6,900 Israeli settlers
in the Gaza Strip (August 2000 est.)
Age structure:
0-14 years: 49.89% (male 301 ,288; female 286,481 )
15-64 years: 47.32% (male 283,274; female 274,1 89)
65 years and over: 2.79% (male 14,121; female
18,766) (2001 est.)
Population growth rate: 4.01% (2001 est.)
Birth rate: 42.48 births/1,000 population (2001 est.)
Death rate: 4.21 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1 .8 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 05 ma!e(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1.03 male(s)/female (2001 est.)
Infant mortality rate: 25.37 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .01 years
male: 69.76 years
female: 72.32 years (2001 est.)
185
Gaza Strip (continued)
Total fertility rate: 6.42 children born/woman
(2001 est.)
HiV/AIDS - adult prevaience rate: NA%
HiV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%,
Jewish 0.6%
Religions: Muslim (predominantly Sunni) 987%,
Christian 07%, Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition: NA
total popu!ation''M^%
male: NA%
female: NA%
Population: 4,989,285 (July 2001 est.)
Age structure:
0-14 years: 19.59% (male 498,575; female 478,663)
15-64 years: 67.91% (male 1 ,632,338; female
1,755,910)
65 years and over: 12.5% (male 241 ,824; female
381,975) (2001 est.)
Population growth rate: -0.59% (2001 est.)
Birth rate: 11.18 births/1,000 population (2001 est.)
Death rate: 14.58 deaths/1 ,000 population
(2001 est.)
Net migration rate: -2.48 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 0.93 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.91 male(s)/female (2001 est.)
Infant mortality rate: 52.37 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 64.57 years
male: 61 .04 years
female: 68.28 years (2001 est.)
Total fertility rate: 1 .45 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS ■ deaths: less than 100 (1999 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 70.1%, Armenian 8.1%,
Russian 6.3%, Azeri 5.7%, Ossetian 3%, Abkhaz
1.8%, other 5%
Religions: Georgian Orthodox 65%, Muslim 11%,
Russian Orthodox 10%, Armenian Apostolic 8%,
unknown 6%
Languages: Georgian 71% (official), Russian 9%,
Armenian 7%, Azeri 6%, other 7%
note: Abkhaz is the official language in Abkhazia
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 100%
fema/e;98%(1989 est.)
Population: 2,654,999 (July 2001 est.)
Age structure:
0^14 years: 32.99% (male 445,252; female 430,758)
15S4 years: 63.1 3% (male 837,771 ; female 838,384)
65 years and over: 3.88% (male 44,436; female
58,398) (2001 est.)
Population growth rate: 1.47% (2001 est.)
Birth rate: 21.8 births/1,000 population (2001 est.)
Death rate: 7.1 deaths/1,000 population (2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth:]. 05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years:] male(s)/female
65 years and over: 0.76 male(s)/female
total population: ] male(s)/female (2001 est.)
infant mortality rate: 53.5 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 64.26 years
ma/e; 62.1 4 years
female: 66.5 years (2001 est.)
Total fertility rate: 2.39 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HiV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS -deaths: NA
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol (predominantly Khalkha)
85%, Turkic (of which Kazakh is the largest group)
7%, Tungusic 4.6%, other (including Chinese and
Russian) 3.4% (1998)
Religions: Tibetan Buddhist Lamaism 96%, Muslim
(primarily in the southwest). Shamanism, and
Christian 4% (1998)
Languages: Khalkha Mongol 90%, Turkic, Russian
(1999)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
fema/e.'' 97.5% (2000)
Population: 59,647,790 (July 2001 est.)
Age structure:
0-14 years; 18.89% (male 5,778,415; female
5,486,114)
15-64 years: 65.41% (male 19,712,932; female
19,304,771)
65 years and over: 15.7% (male 3,895,921; female
5,469,637) (2001 est.)
Population growth rate: 0.23% (2001 est.)
Birth rate: 1 1.54 births/1,000 population (2001 est.)
Death rate: 1 0.35 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1 .07 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 5.54 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.82 years
ma/e; 75.1 3 years
female: 80.66 years (2001 est.)
Total fertility rate: 1 .73 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1 1 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 31 ,000
(1999 est.)
HIV/AIDS -deaths: 450 (1999 est.)
Nationality:
noun: Briton(s), British (collective plural)
adjective: British
Ethnic groups: English 81.5%, Scottish 9.6%, Irish
2.4%, Welsh 1.9%, Ulster 1.8%, West Indian, Indian,
Pakistani, and other 2.8%
Religions: Anglican 27 million, Roman Catholic 9
million, Muslim 1 million, Presbyterian 800,000,
Methodist 760,000, Sikh 400,000, Hindu 350,000,
Jewish 300,000 (1991 est.)
Languages: English, Welsh (about 26% of the
population of Wales), Scottish form of Gaelic (about
60,000 in Scotland)
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 99% (1978 est.)
male: NA%
female: NA%
527
United Kingdom (continued)
Population: 2,090,713 (July 2001 est.)
note: in addition, there are some 176,000 Israeli
settlers in the West Bank and about 173,000 in East
Jerusalem (August 1999 est.)
Age structure:
0-14 years: 44.61% (male 478,232; female 454,439)
15-64 years: 51 .8% (male 552,661 ; female 530,230)
65 years and over: 3.59% (male 32,629; female
42,522) (2001 est.)
Population growth rate: 3.48% (2001 est.)
Birth rate: 35.83 biilhs/1,000 population (2001 est.)
Death rate: 4.37 deaths/1,000 population
(2001 est.)
Net migration rate: 3.29 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1.04 male(s)/female (2001 est.)
Infant mortality rate: 21 .78 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 72.28 years
male: 70.58 years
female: 74.07 years (2001 est.)
Total fertility rate: 4.9 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%,
Jewish 17%
Religions: Muslim 75% (predominantly Sunni),
Jewish 17%, Christian and other 8%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition: NA
total population:
male: NA%
female: NA%','daf95a6ab66237ca400f93f457a686112e180af59cdba6cbc102d33424e3a7ea','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89bc18ef8c60ba089a87efea89bc293399f974607202813d97076c67974f6b7b',2001,'BZ','Belize','people-and-society',151,'Population: 256,062 (July 2001 est.)
Age structure:
0-14 years: 42.04% (male 54,876; female 52,780)
15-64 years: 54.43% (male 70,534; female 68,837)
65 years and over: 3.53% (male 4,403; female 4,632)
(2001 est.)
Population growth rate: 2.7% (2001 est.)
Birth rate: 31.69 births/1,000 population (2001 est.)
Death rate: 4.7 deaths/1,000 population (2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/femaie
15-64 years: 1.02 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 .03 maie(s)/femaie (2001 est.)
Infant mortality rate: 25.14 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71.19 years
male: 68.91 years
female: 73.57 years (2001 est.)
Total fertility rate: 4.05 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,400
(1999 est.)
HIV/AIDS -deaths: 170 (1999 est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo 43.7%, Creole 29.8%, Maya
10%, Garifuna 6.2%, other 10.3%
Religions: Roman Catholic 62%, Protestant 30%
(Anglican 12%, Methodist 6%, Mennonite 4%,
Seventh-Day Adventist 3%, Pentecostal 2%, Jehovah''s
Witnesses 1%, other 2%), none 2%, other 6% (1980)
Languages: English (official), Spanish, Mayan,
Garifuna (Carib), Creole
Literacy:
definition: age 15 and over can read and write
total population: 70.3%
male: 70.3%
fema/e.- 70.3% (1991 est.)
note: other sources list the literacy rate as high as 75%
Population: 6,590,782
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 47.32% (male 1,574,124; female
1,544,741)
15-64 years: 50.38% (male 1 ,607,900; female
1,712,360)
65 years and over: 2.3% (male 64,756; female
86,901) (2001 est.)
Population growth rate: 2.97% (2001 est.)
Birth rate: 44.23 birlhs/1,000 population (2001 est.)
Death rate: 14.51 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 89.68 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 49.94 years
male: 49.02 years
female: 50.88 years (2001 est.)
Total fertility rate: 6.23 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.45%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 70,000
(1999 est.)
HIV/AIDS -deaths: 5,600 (1999 est.)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic groups: African 99% (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba),
Europeans 5,500
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: French (official), Fon and Yoruba (most
common vernaculars in south), tribal languages (at
least six major ones in north)
Literacy:
definition: age 15 and over can read and write
total population: 37.5%
male: 52.2%
fema/e; 23.6% (2000)','5a38fbd5f1af109b9bda2655d94d93a3c7d6be60ea3cdbae37d39cb837d26913','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da25e03bc5044b80dec752c81d0ce3b55142acbbe74378bff1026cc8df24fc1d',2001,'BM','Bermuda','people-and-society',160,'Population; 63,503 (July 2001 est.)
Age structure:
0-14 years: 19 A% (male 6,091 ; female 6,230)
15-64 years: 69.43% (male 21,783; female 22,309)
65 years and over: 1 1 .17% (male 3,073; female
4,017) (2001 est.)
Population growth rate: 0.74% (2001 est.)
Birth rate: 12.16 births/1,000 population (2001 est.)
Death rate: 7.42 deaths/1,000 population
(2001 est.)
Net migration rate: 2.66 migrant{s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: OM male(s)/female
under 15 years: 0.98 male(s)/female
15-64 years: 0.98 ma!e{s)/female
65 years and over: 0.76 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 9.55 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77. 1 2 years
male: 75.04 years
female: 79.05 years (2001 est.)
Total fertility rate: 1 .81 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate; NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic groups: black 58%, white 36%, other 6%
Religions: non-Anglican Protestant 39%, Anglican
27%, Roman Catholic 15%, other 19%
Languages: English (official), Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
fema/e.- 99% (1970 est.)
Population: 2,049,412 (July 2001 est.)
note: other estimates range as low as 800,000
Age structure:
0-14 years: 39.99% (male 424,832; female 394,725)
15-64 years: 56.05% (male 591 ,1 52; female 557,498)
65 years and over: 3.96% (male 41,125; female
40,080) (2001 est.)
Population growth rate: 2.17% (2001 est.)
Birth rate: 35.73 births/1,000 population (2001 est.)
Death rate: 14.03 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.07 male(s)/female (2001 est.)
Infant mortality rate: 1 08.89 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 52.79 years
ma/e.- 53.16 years
female: 52.41 years (2001 est.)
Total fertility rate: 5.07 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(1999 est.)
HIV/AIDS- deaths: NA
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%,
indigenous or migrant tribes 15%
Religions: Lamaistic Buddhist 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak
various Tibetan dialects, Nepalese speak various
Nepalese dialects
Literacy:
definition: age 15 and over can read and write
total population: 42.2%
male: 56.2%
fema/e; 28.1% (1995 est.)
People - note: refugee issue over the presence in
Nepal of approximately 98,700 Bhutanese refugees,
90% of whom are in seven United Nations Office of the
High Commissioner for Refugees (UNHCR) camps
Population: 8,300,463 (July 2001 est.)
Age structure:
0-14 years: 38.46% (male 1 ,626,698; female
1,565,748)
15-64 years: 57.07% (male 2,315,098; female
2,421,987)
65 years and over: 4.47% (male 1 66,986; female
203,946) (2001 est.)
Population growth rate: 1 .76% (2001 est.)
Birth rate: 27.27 births/1,000 population (2001 est.)
Death rate: 8.2 deaths/1,000 population (2001 est.)
Net migration rate: -1 .45 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.82 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 58.98 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 64.06 years
male: 61 .53 years
female: 66.72 years (2001 est.)
Total fertility rate: 3.51 children born/woman
(2001 est.)
HIV/AIDS " adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,200
(1999 est.)
HIV/AIDS - deaths: 380 (1 999 est.)
Nationality:
noun: Bolivian(s)
adjective: Bolivian
Ethnic groups: Quechua 30%, Aymara 25%,
mestizo (mixed white and Amerindian ancestry) 30%,
white 15%
Religions: Roman Catholic 95%, Protestant
(Evangelical Methodist)
Languages: Spanish (official), Quechua (official),
Aymara (official)
Literacy:
definition: age 15 and over can read and write
total population: 83. 1 %
male: 90.5%
fema/e;76%(1995 est.)
Population: 3,922,205
note: all data dealing with population are subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2001 est.)
Age structure:
0-14 years: 20.13% (male 405,713; female 383,850)
15-64 years: 70.78% (male 1 ,422,796; female
1,353,410)
65 years and over: 9.09% (male 1 50,802; female
205,634) (2001 est.)
Population growth rate: 1 .38% (2001 est.)
Birth rate: 12.86 births/1,000 population (2001 est.)
Death rate: 7.99 deaths/1,000 population
(2001 est.)
62
Bosnia and Herzegovina (continued)
Net migration rate: 8.91 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15’64 years: 1 .05 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 24.35 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .75 years
male: 69.04 years
female: 74.65 years (2001 est.)
Total fertility rate: 1.71 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Serb 31%, Bosniak 44%, Croat
17%, Yugoslav 5.5%, other 2.5% (1991)
note: Bosniak has replaced muslim as an ethnic term
in part to avoid confusion with the religious term
Muslim - an adherent of Islam
Religions: Muslim 40%, Orthodox 31%, Roman
Catholic 15%, Protestant 4%, other 10%
Languages: Croatian, Serbian, Bosnian
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','5bd986b737dd8f842695e196984ff6cf28ed44c96c98dc93e26bd54245dc1215','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('516e2e3af63b46a8f371137bbe7eba4c33367a40a0cc198276f534ad1c4086c4',2001,'BW','Botswana','people-and-society',175,'Population: 1,586,119
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 40.3% (male 321,164; female 318,007)
15-64 years: 55.56% (male 423,954; female 457,227)
65 years and over; 4.1 4% (male 26,691; female
39,076) (2001 est.)
Population growth rate: 0.47% (2001 est.)
Birth rate: 28.85 births/1 ,000 population (2001 est.)
Death rate: 24.1 8 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 63.2 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 37.13 years
maie: 36.77 years
female: 37.51 years (2001 est.)
Total fertility rate: 3.7 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 35.8%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 290,000
(1999 est.)
HIV/AIDS - deaths: 24,000 (1999 est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Tswana (or Botswana) 79%,
Kalanga 11%, Basarwa 3%, other, including
Kgalagadi and white 7%
65
Botswana (continued)
Religions: indigenous beliefs 50%, Christian 50%
Languages: English (official), Setswana
Literacy:
definition: age 1 5 and over can read and write
total population: 69.8%
male: 80.5%
fema/a’ 59.9% (1995 est.)','806d34ed8f1ff0e96ed446fbf6e5e77b477f4aa32e23bbf3ee7ff77afc812119','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59db47bebd620a8fa9fb314e71c3846e66b7540e28c0cd4789c8f848e265d7bd',2001,'BR','Brazil','people-and-society',189,'Population: 174,468,575
note: Brazil took an intercensal count in August 1996
which reported a population of 157,079,573; that
figure was about 5% lower than projections by the US
Census Bureau, which is close to the implied
underenumeration of 4.6% for the 1991 census;
estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can
result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates,
and changes in the distribution of population by age
and sex than would otherwise be expected (July
2001 est.)
Age structure:
0-14 years: 28.57% (male 25,390,039; female
24,449,902)
15-64 years: 65.98% (male 56,603,895; female
58,507,289)
65 years and over: 5.45% (male 3,857,564; female
5,659,886) (2001 est.)
Population growth rate: 0.91% (2001 est.)
Birth rate: 18.45 births/1,000 population (2001 est.)
Death rate: 9.34 deaths/1,000 population
(2001 est.)
Net migration rate; -0.03 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.07 male(s)/female (2001 est.)
Infant mortality rate: 36.96 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 63.24 years
male: 58.96 years
female: 67.73 years (2001 est.)
Total fertility rate: 2.09 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.57%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 540,000
(1999 est.)
HIV/AIDS - deaths: 1 8,000 (1 999 est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic groups: white (includes Portuguese,
German, Italian, Spanish, Polish) 55%, mixed white
and black 38%, black 6%, other (includes Japanese,
Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 80%
Languages: Portuguese (official), Spanish, English,
French
Literacy:
definition: age 15 and over can read and write
total population: 83.3%
male: 83.3%
female: 83.2% (1995 est.)','9ef5086f5e5ccc1280ffdfb12d3409e7d179d8ee643e5fd8770de6a9815c8a77','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e91207d0b1e7c95eb2c2906315a6224916f5dd92175a365c266756ce041af4c9',2001,'ID','Indonesia','people-and-society',196,'Population: no indigenous inhabitants
note: approximately 1 ,200 former agricultural workers
resident in the Chagos Archipelago, often referred to
as Chagossians or Hois, were relocated to Mauritius
and the Seychelles around the time of the construction
of UK-US military facilities; in 1995, there were
approximateiy 1,700 UK and US military personnel
and 1 ,500 civilian contractors living on the island of
Diego Garcia
Population: 20,812 (July 2001 est.)
Age structure:
0-14 years: 22.77% (male 2,399; female 2,339)
15-64 years: 72.31 % (male 7,741 ; female 7,309)
65 years and over: 4.92% (male 555; female 469)
(2001 est.)
Population growth rate: 2.22% (2001 est.)
Birth rate: 15.18 births/1,000 population (2001 est.)
Death rate: 4.42 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1 1 .39 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/fema(e
under 15 years: 1.03 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1.18 male(s)/female
total population: 1 .06 male(s)/female (2001 est.)
Infant mortality rate: 20.3 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.64 years
male: 74.74 years
female: 76.59 years (2001 est.)
Total fertility rate: 1 .72 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: black 90%, white, Asian
Religions: Protestant 86% (Methodist 45%, Anglican
21%, Church of God 7%, Seventh-Day Adventist 5%,
Baptist 4%, Jehovah’s Witnesses 2%, other 2%),
Roman Catholic 6%, none 2%, other 6% (1981)
Languages: English (official)
Literacy:
definition: age 15 and over can read and write
total population: 97.3% (1991 est.)
male: NA%
female: NA%
Population: 343,653 (July 2001 est.)
Age structure:
0-14 years: 30.77% (male 53,977; female 51 ,772)
15-64 years: 66.52% (male 1 21 ,601 ; female 1 07,007)
65 years and over: 2.71 % (male 4,449; female 4,847)
(2001 est.)
Population growth rate: 2.11% (2001 est.)
Birth rate: 20.45 births/1,000 population (2001 est.)
Death rate: 3.38 deaths/1,000 population
(2001 est.)
Net migration rate: 4.07 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.14 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1.1 male(s)/female (2001 est.)
Infant mortality rate: 14.4 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 73.82 years
male: 71 .45 years
female: 76.31 years (2001 est.)
Total fertility rate: 2.44 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.2% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS- deaths: NA
Nationality:
noun: Bruneian(s)
adjective: Bruneian
Ethnic groups: Malay 67%, Chinese 15%,
indigenous 6%, other 12%
Religions: Muslim (official) 67%, Buddhist 13%,
Christian 10%, indigenous beliefs and other 10%
Languages: Malay (official), English, Chinese
73
Brunei (continued)
Literacy:
definition: age 15 and over can read and write
total population: 88.2%
male: 92.6%
femate.’ 83.4% (1995 est.)
Population: 134,597 (July 2001 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: N A%
HiV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Micronesian(s)
adyecf/Ve; Micronesian; Kosrae(s), Pohnpeian(s),
Trukese, Yapese
Ethnic groups; nine ethnic Micronesian and
Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%,
other and none 3%
Languages: English (official and common
language), Trukese, Pohnpeian, Yapese, Kosrean
Literacy:
definition: age 1 5 and over can read and write
total population: S9%
male:9^%
fema/e; 88% (1980 est.)
Population: no indigenous inhabitants;
approximately 150 people make up the staff of US
Fish and Wildlife Service and their services
cooperator living at the atoll (July 2001 est.)
Population: 4,431 ,570 (July 2001 est.)
Age structure:
0-14 years: 22.44% (male 506,303; female 488,31 1 )
15-64 years: 67.62% (male 1 ,437,492; female
1,559,090)
65 years and over: 9.94% (male 163,473; female
276,901) (2001 est.)
Population growth rate: 0.05% (2001 est.)
Birthrate: 13.35 births/1 ,000 population (2001 est.)
Death rate: 12.6 deaths/1,000 population
(2001 est.)
Net migration rate: -0.3 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.91 male(s)/female (2001 est.)
Infant mortality rate: 42.74 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 64.6 years
ma/e; 60.1 5 years
female: 69.26 years (2001 est.)
Total fertility rate: 1 .67 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.2% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,500
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldovan/Romanian 64.5%,
Ukrainian 13.8%, Russian 13%, Gagauz 3.5%,
Jewish 1.5%, Bulgarian 2%, other 1.7% (1989 est.)
note: internal disputes with ethnic Slavs in the
Transnistrian region
Religions: Eastern Orthodox 98.5%, Jewish 1.5%,
Baptist (only about 1,000 members) (1991)
Languages: Moldovan (official, virtually the same as
the Romanian language), Russian, Gagauz (a Turkish
dialect)
Literacy:
definition: age 15 and over can read and write
total population: 96%
male: 99%
fema/e; 94% (1989 est.)
Population: 4,300,419 (July 2001 est.)
Age structure:
0^14 years: M. 39% (male 397,124; female 372,058)
15-64 years: 75A3% (male 1,575,381; female
1,656,838)
65 years and over: 6.95% (male 1 30,81 5; female
168,203) (2001 est.)
Population growth rate: 3.5% (2001 est.)
Birth rate: 12.8 births/1,000 population (2001 est.)
Death rate: 4.24 deaths/1 ,000 population
(2001 est.)
Net migration rate: 26.45 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.07 male(s)/fema}e
15-64 years: 0.95 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 3.62 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 80.17 years
male: 77.22 years
female: 83.35 years (2001 est.)
Total fertility rate: 1 .22 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.19%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,000
(1999 est.)
HIV/AIDS ■ deaths: 210 (1999 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 76.7%, Malay 14%, Indian
7.9%, other 1.4%
Religions: Buddhist (Chinese), Muslim (Malays),
Christian, Hindu, Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and
national), Tamil (official), English (official)
Literacy:
definition: age 15 and over can read and write
total population: 93.5%
male: 97%
female: 39.3% (1999)','ad5792deeb209bb68c0bda9a0b4cd6ab3f15833ed01bbf24b50452001c722d55','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd72f23e85f83e9fc42e083f6287b7634f965a80b07c573d84864a8a6645561b',2001,'BG','Bulgaria','people-and-society',207,'Population: 7,707,495 (July 2001 est.)
Age structure:
0‘14years: 15.11% (male 597,765; female 567,030)
15-64 years: 68.17% (male 2,588,805; female
2,665,736)
65 years and over: 16.72% (male 543,665; female
744,494) (2001 est.)
Population growth rate: -1.14% (2001 est.)
Birth rate: 8.06 births/1,000 population (2001 est.)
Death rate; 1 4.53 deaths/1 ,000 population
(2001 est.)
Net migration rate: -4.9 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1,06 male(s)/female
under 15 years: 1,05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.73 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 14.65 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .2 years
male: 67.72 years
female: 74.89 years (2001 est.)
Total fertility rate; 1.13 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups: Bulgarian 83%, Turk 8.5%, Roma
2.6%, Macedonian, Armenian, Tatar, Gagauz,
Circassian, others (1998)
Religions: Bulgarian Orthodox 83.5%, Muslim 13%,
Roman Catholic 1.5%, Uniate Catholic 0.2%, Jewish
0.8%, Protestant, Gregorian-Armenian, and other 1%
(1998)
Languages: Bulgarian, secondary languages
closely correspond to ethnic breakdown
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 99%
fema/e.-98%(1999)','03380f924d9eb4d28b44623fc7c6c8eb2bc4a3a9048adb5537307a3924557dd3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfdfa2747f752be18329e882eb62198e1ea4ffe907f94e26fdcb5442e681efc0',2001,'BF','Burkina Faso','people-and-society',213,'Population: 12,272,289
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 47,5% (male 2,937,285; female
2,892,107)
15-64 years: 49.59% (male 2,903,153; female
3,183,121)
65 years and over: 2.91 % (male 1 50,688; female
205,935) (2001 est.)
Population growth rate: 2,68% (2001 est.)
Birth rate: 44.79 births/1,000 population (2001 est.)
Death rate: 17.05 deaths/1,000 population
(2001 est.)
Net migration rate: -0.97 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0,91 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 1 06.92 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 46.41 years
male: 45.86 years
female: 46.93 years (2001 est.)
Total fertility rate: 6.35 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 6.44%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 350,000
(1999 est.)
HIV/AIDS -deaths: 43,000 (1999 est.)
Nationality;
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi over 40%, Gurunsi, Senufo,
Lobi, Bobo, Mande, Fulani
78
Burkina Faso (continued)
Religions: indigenous beliefs 40%, Muslim 50%,
Christian (mainly Roman Catholic) 10%
Languages: French (official), native African
languages belonging to Sudanic family spoken by
90% of the population
Literacy:
definition: age 15 and over can read and write
total population: ^9 2%
male: 29.5%
female: 92% (1995 est.)','5cb5ba13285e56b9b34648c25aba23cb964125ca373aa58cc34ff20392147e42','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('047adf490805f11564b946b346eec4e1d3c5d887910bf304281c706d1956b96c',2001,'ET','Ethiopia','people-and-society',222,'Population: 41,994,678
note: estimates for this country explicitly take Into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 29.14% (male 6,245,798; female
5,992,074)
15-64 years: 66.08% (male 1 3,779,571 ; female
13,970,707)
65 years and over: 4.78% (male 895,554; female
1,110,974) (2001 est.)
Population growth rate: 0.6% (2001 est.)
Birth rate: 20.13 births/1,000 population (2001 est.)
Death rate: 12.3 deaths/1,000 population
(2001 est.)
Net migration rate: -1 .84 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over 0.81 mate{s)/female
total population: 0,99 male(s)/fema!e (2001 est.)
Infant mortality rate: 73.71 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 55.1 6 years
male: 53.73 years
female: 56.68 years (2001 est.)
Total fertility rate: 2.3 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 530,000
(1999 est.)
HIV/AIDS -deaths: 48,000 (1999 est.)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%,
Rakhine 4%, Chinese 3%, Mon 2%, Indian 2%, other
5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%,
Roman Catholic 1%), Muslim 4%, animist 1%, other
2%
Languages: Burmese, minority ethnic groups have
their own languages
Literacy;
definition: age 15 and over can read and write
total population: 83.1%
male: 88.7%
fema/e; 77.7% (1995 est.)
nofe.'' these are official statistics; estimates of
functional literacy are likely closer to 30% (1999 est.)
Population: 65,891,874
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
O-M years; 47.1 8% (male 15,647,675; female
15,442,348)
15-64 years: 50.03% (male 1 6,584,765; female
16,378,060)
65 years and over: 2.79% (male 834,825; female
1,004,201) (2001 est.)
Population growth rate: 2.7% (2001 est.)
Birth rate; 44.68 births/1,000 population (2001 est.)
Death rate: 17.84 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0.13 migrant(s)/1 ,000
population (2001 est.)
note: repatriation of Ethiopians who fled to Sudan for
refuge from war and famine in earlier years is
expected to continue for several years; small numbers
of Sudanese and Somali refugees, who fled to
Ethiopia from the fighting or famine in their own
countries, continue to return to their homes
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1.01 male(s)/female (2001 est.)
Infant mortality rate: 99.96 deaths/1 ,000 live births
(2001 est.)
161
Ethiopia (continued)
Life expectancy at birth:
total population: 44.68 years
male: 43.88 years
female: 45.51 years (2001 est.)
Total fertility rate: 7 children born/woman
(2001 est.)
HiV/AIDS - adult prevalence rate: 10.63%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3 million
(1999 est.)
HIV/AIDS - deaths: 280,000 (1999 est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigre
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religions: Muslim 45%"50%, Ethiopian Orthodox
35%-40%, animist 12%, other 3%-8%
Languages: Amharic, Tigrinya, Oromigna,
Guaragigna, Somali, Arabic, other local languages,
English (major foreign language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 35.5%
male: 45.5%
female: 25.3% (1995 est.)
Population: no indigenous inhabitants
note; there is a small French military garrison (July
2001 est.)
Population: 697,181
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 28.19% (male 100,194; female 96,309)
15-64 years: 66.89% (male 234,976; female 231 ,360)
65 years and over: 4.92% (male 1 5,324; female
19,018) (2001 est.)
Population growth rate: 0.07% (2001 est.)
Birth rate: 17.92 births/1,000 population (2001 est.)
Death rate: 8.87 deaths/1,000 population
(2001 est.)
Net migration rate: -8.38 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1.01 male(s)/female (2001 est.)
Infant mortality rate: 38.72 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 03.31 years
male: 60.52 years
female: 66.24 years (2001 est.)
Total fertility rate: 2.1 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 3.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 15,000
(1999 est.)
HIV/AIDS - deaths: 900 (1999 est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 49%, black 32%, mixed
12%, Amerindian 6%, white and Chinese 1%
Religions: Christian 50%, Hindu 33%, Muslim 9%,
other 8%
Languages: English, Amerindian dialects, Creole,
Hindi, Urdu
Literacy:
definition: age 15 and over has ever attended school
total population: 98.1%
male: 98.6%
fema/e; 97,5% (1995 est.)
Population: 22,757,092
note: includes 5,360,526 non-nationals (July
2001 est.)
Age structure:
0-14 years: 42.52% (male 4,932,465; female
4,743,908)
15-64 years: 54.8% (male 7,290,840; female
5,179,393)
65 years and over: 2.68% (male 334,981 ; female
275,505) (2001 est.)
Population growth rate: 3.27% (2001 est.)
Birth rate: 37.34 births/1,000 population (2001 est.)
Death rate: 5.94 deaths/1,000 population
(2001 est.)
Net migration rate: 1 .32 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: male(s)/female
65 years and over: 1 .22 male(s)/female
total population: 1 .23 male(s)/female (2001 est.)
Infant mortality rate: 51 .25 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.09 years
male: 66.4 years
female: 69.85 years (2001 est.)
Total fertility rate: 6.25 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 62.8%
male: 71, 5%
fema/e.* 50.2% (1995 est.)
Population: 10,284,929 (July 2001 est.)
Age structure:
0-14 years: 44.07% (male 2,279,996; female
2,252,255)
15-64 years: 52.88% (male 2,603,829; female
2,834,328)
65 years and over: 3.05% (male 1 55,877; female
158,644) (2001 est.)
Population growth rate: 2.93% (2001 est.)
Birth rate: 37.46 births/1,000 population (2001 est.)
Death rate: 8.35 deaths/1,000 population
(2001 est.)
Net migration rate: 0.21 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 56.75 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 62.56 years
male: 60.94 years
female: 64.22 years (2001 est.)
Total fertility rate: 5.12 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .77%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 79,000
(1999 est.)
HIV/AIDS - deaths: 7,800 (1999 est.)
445
Senegal (continued)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular 23.8%, Serer
14.7%, Jola 3.7%, Mandinka 3%, Soninke 1.1%,
European and Lebanese 1%, other 9.4%
Religions: Muslim 92%, indigenous beliefs 6%,
Christian 2% (mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar, Jola,
Mandinka
Literacy:
definition: age 1 5 and over can read and write
total population: 33.1%
male: 43%
female: 232% {ms est.)','eccdbd605ff099fdb47bba1227bd017d8cc9f8132b2b641fd3a8129d4bebcd98','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bee8233f075a43e6389d1d297ce2b10fec7c0a7be38c27d8c6f1b7ece815e45',2001,'TH','Thailand','people-and-society',231,'Population: 6,223,897
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 46.82% (male 1 ,472,618; female
1,441,548)
15-64 years: 50.37% (male 1 ,541 ,1 31 ; female
1,593,743)
65 years and over: 2.81% (male 71 ,984; female
102,873) (2001 est.)
Population growth rate: 2.38% (2001 est.)
Birth rate; 40.13 births/1,000 population (2001 est.)
Death rate: 16.36 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1.03 ma!e(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 70.74 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 46.06 years
ma/e; 45.15 years
femate: 46.99 years (2001 est.)
83
Burundi (continued)
Total fertility rate: 6.16 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 1 .32%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 360,000
(1999 est.)
HIV/AIDS - deaths: 39,000 (1999 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic)
14%, Twa (Pygmy) 1%, Europeans 3,000, South
Asians 2,000
Religions: Christian 67% (Roman Catholic 62%,
Protestant 5%), indigenous beliefs 23%, Muslim 10%
Languages: Kirundi (official), French (official),
Swahili (along Lake Tanganyika and in the Bujumbura
area)
Literacy:
definition: age 15 and over can read and write
total population: 35.3%
male: 49.3%
fema/e; 22.5% (1995 est.)
Population: 61,797,751
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 23.43% (male 7,380,273; female
7,099,506)
15-64 years: 69.95% (male 21 ,304,051 ; female
21,921,383)
65 years and over: 6.62% (male 1 ,796,325; female
2,296,213) (2001 est.)
Population growth rate: 0.91% (2001 est.)
496
Thailand (continued)
Birth rate: 16.63 births/1,000 population (2001 est.)
Death rate: 7.54 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.78 male(s)/fefnale
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 30.49 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.86 years
male: 65.64 years
female: 72.24 years (2001 est.)
Total fertility rate: 1 .87 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.15%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 755,000
(1999 est.)
HIV/AIDS -deaths: 66,000 (1999 est.)
Nationality:
noun: Thai (singular and plural)
adjective: lha\\
Ethnic groups: Thai 75%, Chinese 14%, other 11%
Religions: Buddhism 95%, Muslim 3.8%,
Christianity 0.5%, Hinduism 0.1%, other 0.6% (1991)
Languages: Thai, English (secondary language of
the elite), ethnic and regional dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.6%
male: 96%
fema/e.'' 91 .6% (1995 est.)
Population: 5,153,088
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 45.63% (male 1,179,650; female
1,171,748)
15-64 years: 51 .92% (male 1 ,302,1 97; female
1,373,247)
65 years and over: 2.45% (male 54,651 ; female
71,595) (2001 est.)
Population growth rate: 2.6% (2001 est.)
Birth rate: 37.04 births/1 ,000 population (2001 est.)
Death rate: 1 1 .24 deaths/1 ,000 population
(2001 est.)
Net migration rate; 0.15 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 70.43 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 54.35 years
male: 52.38 years
female: 56.38 years (2001 est.)
Total fertility rate: 5.32 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 5.98%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 1 4,000 (1 999 est.)
Nationality:
noun: Togolese (singular and plural)
acfyecf/Ve; Togolese
Ethnic groups: native African (37 tribes; largest and
most important are Ewe, Mina, and Kabre) 99%,
European and Syrian-Lebanese less than 1%
Religions: indigenous beliefs 59%, Christian 29%,
Muslim 12%
Languages: French (official and the language of
commerce), Ewe and Mina (the two major African
languages in the south), Kabye (sometimes spelled
Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition: age 15 and over can read and write
total population: 51 .7%
male: 67%
fema/e;37%(1995 est.)
Population: 1 ,445 (July 2001 est.)
Age structure:
0-/4 years; NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -0.92% (2001 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
r70un;Tokelauan(s)
acf/ecf/Ve; Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%,
Roman Catholic 28%, other 2%
note: on Atafu, all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations, with the
Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language),
English','df31f5bd6c3711954fb95723c25bc9b3bc8d93dd3bec9d272f006ffdb7cb5f85','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c44ddf17ac83a23a6ef1975d4450d45b2ee0e5459260c2ef4879dcf5bc617d97',2001,'KH','Cambodia','people-and-society',235,'Population: 12,491,501
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 41 .25% (male 2,626,821 ; female
2,526,510)
15-64 years: 55.28% (male 3,253,61 1 ; female
3,651,129)
65 years and over: 3.47% (male 177,577; female
255,853) (2001 est.)
Population growth rate: 2.25% (2001 est.)
Birth rate: 33.16 births/1,000 population (2001 est.)
Death rate: 10.65 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.30 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.04 male(s)/female (2001 est.)
Infant mortality rate: 65.41 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 56.82 years
male: 54.62 years
fema/e; 59.1 2 years (2001 est.)
Total fertility rate: 4.74 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 4.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 220,000
(1999 est.)
HIV/AIDS - deaths: 14,000 (1999 est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%,
Chinese 1%, other 4%
Religions: Theravada Buddhist 95%, other 5%
Languages: Khmer (official) 95%, French, English
Literacy:
definition: age 1 5 and over can read and write
total population: 35%
male: 48%
fema/e; 22% (1990 est.)','7ec0a8a28d349dcc89391ebd2396c958aad8dc2d65be59678770a1c6c1dace78','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('428fd897b089e477c7ff8be1997de5423e6dca7a308b35272ea22aaa1b853303',2001,'CM','Cameroon','people-and-society',243,'Population: 15,803,220
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 42.37% (male 3,385,898; female
3,310,504)
15-64 years: 54.28% (male 4,305,354; female
4,271,958)
65 years and over: 3.35% (male 244,41 9; female
285,087) (2001 est.)
Population growth rate: 2.41% (2001 est.)
Birth rate: 36.12 births/1,000 population (2001 est.)
Death rate: 1 1 .99 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.) NA migrant(s)/1 ,000 population
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .01 ma!e(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .01 male{s)/female (2001 est.)
Infant mortality rate: 69.83 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 54.59 years
male: 53.76 years
female: 55.44 years (2001 est.)
Total fertility rate: 4.8 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 7,73%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 540,000
(1999 est.)
HIV/AIDS - deaths: 52,000 (1999 est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%,
Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
Religions: Indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: 24 major African language groups,
English (official), French (official)
Literacy:
definition: age 15 and over can read and write
total population: 63.4%
male: 75%
fema/e.- 52.1% (1995 est.)','df6f0d330e73718f8a2475b3d2fbe4efd6d7ff4bc29a1b5b28b8db1da910e072','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6737307cb8f5408898a5a943e65dfe844be22c256dff3a77c8f6fb5ce4ee043f',2001,'CA','Canada','people-and-society',252,'Population: 31,592,805 (July 2001 est.)
Age structure:
0-14 years: ^S.95% (male 3,067,102; female
2,918,839)
15-64 years: 68.28% (male 10,846,151; female
10,725,800)
65yearsand oi/er12.77% (male 1,715,071; female
2,319,842) (2001 est.)
Population growth rate: 0.99% (2001 est.)
Birth rate: 11.21 births/1,000 population (2001 est.)
Death rate: 7.47 deaths/1 ,000 population
(2001 est.)
Net migration rate: 6.13 migrant(s)/1, 000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 5.02 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.56 years
mate; 76. 16 years
fema/e; 83.1 3 years (2001 est.)
Total fertility rate; 1.6 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.3% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 49,000
(1999 est.)
HIV/AIDS - deaths: 400 (1999 est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups: British Isles origin 28%, French
origin 23%, other European 15%, Amerindian 2%,
other, mostly Asian, African, Arab 6%, mixed
background 26%
Religions: Roman Catholic 42%, Protestant 40%,
other 18%
Languages; English 59.3% (official), French 23.2%
(official), other 17.5%
Literacy;
definition: age 15 and over can read and write
total population: 97% (1 986 est.)
male: NA%
female: NA%
Population: 405,163 (July 2001 est.)
Age structure:
0-14 years: 42.79% (male 87,458; female 85,895)
15-64 years: 50.76% (male 97,812; female 107,834)
65 years and over: 6.45% (male 1 0,204; female
15,960) (2001 est.)
Population growth rate: 0.92% (2001 est.)
Birthrate: 28.71 births/l ,000 population (2001 est.)
Death rate: 7.19 deaths/1 ,000 population
(2001 est.)
Net migration rate: -12.37 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.91 ma!e(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 53.22 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.21 years
male: 85.93 years
female: 72.6 years (2001 est.)
Total fertility rate: 4.05 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS “ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%,
European 1 %
Religions: Roman Catholic (infused with indigenous
beliefs); Protestant (mostly Church of the Nazarene)
Languages: Portuguese, Crioulo (a blend of
Portuguese and West African words)
Literacy:
definition: age 15 and over can read and write
total population: 71 .6%
male: 81 .4%
fema/e.'' 63.8% (1995 est.)','94bd90acd948906b108929bd3771d01e3196ad5d03e647eb35e1121fbc8efd54','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be40e72c2a67d2de94a749276bc40ba33cdafcf678f39a2f581b952bea75c728',2001,'HN','Honduras','people-and-society',269,'Population: 35,527 (July 2001 est.)
Age structure:
0-14 years: 22.21% (male 3,807; female 4,084)
15-64 years: 69.74% (male 12,102; female 12,676)
65 years and over: 8.05% (mate 1 ,31 8; female 1 ,540)
(2001 est.)
Population growth rate: 2.12% (2001 est.)
Birthrate: 13.79 births/1 ,000 population (2001 est.)
Death rate: 5.15 deaths/1,000 population
(2001 est.)
Net migration rate: 12.58 migrant(s)/1 ,000
population (2001 est.)
note: major destination for Cubans trying to migrate to
the US
Sex ratio:
at birth: 0.86 male(s)/female
under 15 years: 0.93 male(s)/fema!e
15-64 years: 0.95 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.94 male(s)/female (2001 est.)
Infant mortality rate: 10.16 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.03 years
male: 76.24 years
female: 81 .43 years (2001 est.)
Total fertility rate: 2.04 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HiV/AlDS - deaths: NA
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%,
expatriates of various ethnic groups 20%
Religions: United Church (Presbyterian and
Congregational), Anglican, Baptist, Roman Catholic,
Church of God, other Protestant
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 98%
male: 98%
fema/e; 98% (1970 est.)
Population: 3,576,884
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 4323% (male 778,885; female 767,414)
15-64 years: 53% (male 929,717; female 965,947)
65 years and over: 3.77% (male 59,364; female
75,557) (2001 est.)
Population growth rate: 1.85% (2001 est.)
Birth rate: 37.05 births/1 ,000 population (2001 est.)
Death rate: 1 8.53 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.79 male(s)/female
tota! population: OM male(s)/female (2001 est.)
Infant mortality rate: 1 05.25 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 43.8 years
ma/e; 42.17 years
female: 45A3 years (2001 est.)
Total fertility rate: 4.86 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 1 3.84%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS ■ deaths: 23,000 (1999 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 34%, Banda 27%, Sara 10%,
Mandjia 21%, Mboum 4%, M''Baka 4%, Europeans
6,500 (including 1 ,500 French)
Religions: indigenous beliefs 24%, Protestant 25%,
Roman Catholic 25%, Muslim 15%, other 11%
note: animistic beliefs and practices strongly influence
the Christian majority
Languages: French (official), Sangho (lingua franca
and national language), Arabic, Hunsa, Swahili
Literacy:
definition: age 15 and over can read and write
total population: 60%
male: 68.5%
fema/e; 52.4% (1995 est.)
Population: 6,406,052
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 4222% (male 1,381,823; female
1,322,684)
15-64 years: 54.21 % (male 1 ,71 9,593; female
1,753,003)
65 years and over: 3.57% (male 108,271 ; female
120,678) (2001 est.)
Population growth rate: 2.43% (2001 est.)
Birth rate: 31.94 birlhs/1,000 population (2001 est.)
Death rate: 5.52 deaths/1,000 population
(2001 est.)
Net migration rate: -2.12 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 30.88 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.35 years
male: 67.51 years
female: 71 .28 years (2001 est.)
Total fertility rate: 4.15 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .92%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 63,000
(1999 est.)
HIV/AIDS - deaths: 4,200 (1999 est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and
European) 90%, Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 15 and over can read and write
total population: 72.7%
male: 72.6%
female: 72.7% {1995 est.)','a694dd59f80ac6ddb1faba8eaa50d6f946de6f54b3a5706b5b43bda84937dab8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ab12c4ef6775723b9ab234611c76119653899e2884fae9cc99f6f909c786cd6',2001,'TD','Chad','people-and-society',279,'Population: 8,707,078 (July 2001 est.)
Age structure:
0-14 years: 47.73% (male 2,091 ,724; female
2,064,514)
15-64 years: 49.46% (male 2,035,099; female
2,271,389)
65 years and over; 2.81% (male 101,579; female
142,773) (2001 est.)
Population growth rate: 3.29% (2001 est.)
Birth rate: 48.28 births/1 ,000 population (2001 est.)
Death rate: 15.4 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1,01 male(s)/female
15-64 years: 0.9 male(s)/female
55 years ancf over; 0.71 male(s)/female
total population: 0,94 male(s)/female (2001 est.)
Infant mortality rate: 95.06 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 50.88 years
male: 48.86 years
female: 52.98 years (2001 est.)
Total fertility rate: 6.56 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.69%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 92,000
(1999 est.)
HIV/AIDS - deaths: 1 0,000 (1 999 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: Muslims, commonly referred to as
"northerners" or "gorane" (Arabs, Toubou, Hadjerai,
Fulbe, Kotoko, Kanembou, Baguirmi, Boulala,
Zaghawa, and Maba); non-Muslims, commonly
referred to as "southerners" (Sara, Ngambaye,
Mbaye, Goulaye, Moundang, Moussei, Massa)
including nonindigenous 150,000 (of whom 1,000 are
French)
note: ethnicity and regional background more
commonly used to identify Chadians than religious
affiliation
Religions: Muslim 50%, Christian 25%, indigenous
beliefs (mostly animism) 25%
Languages: French (official), Arabic (official), Sara
and Sango (in south), more than 100 different
languages and dialects
Literacy:
definition: age 1 5 and over can read and write French
or Arabic
total population: 43.1%
male: 32.1%
female: 34.7% (1995 est.)
Population: 15,328,467 (July 2001 est.)
Age structure:
0-14 years: 27.25% (male 2,135,755; female
2,041,552)
15-64 years: 65,39% (male 4,993,41 6; female
5,029,739)
65 years and over: 7.36% (male 467,477; female
660,528) (2001 est.)
Population growth rate: 1.13% (2001 est.)
Birth rate: 16.8 births/1 ,000 population (2001 est.)
Death rate: 5.55 deaths/1 ,000 population
(2001 est.)
101
Chile (continued)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 maie(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 maie(s)/female (2001 est.)
Infant mortality rate: 9.36 deaths/1,000 iive births
(2001 est.)
Life expectancy at birth:
total population: 75.94 years
male: 72.63 years
fema/e: 79.42 years (2001 est.)
Total fertility rate: 2.16 children born/woman
(2001 est.)
HIV/AIDS - aduit prevalence rate: 0.19%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 15,000
(1999 est.)
HIV/AIDS -deaths: 1,000 (1999 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups; white and white-Amerindian 95%,
Amerindian 3%, other 2%
Religions: Roman Catholic 89%, Protestant 11%,
Jewish NEGL%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.2%
male: 95.4%
fema/e.'' 95% (1995 est.)','934f9dc7377f5df96235a5e6befde16803ae0f006097d3ab91c54962ea68fff4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('084b19a328d3f489a724f01e0dd7d796c8bf0b2ec722e933dc48ace9a34e08cb',2001,'CN','China','people-and-society',289,'Population: 1 ,273,1 1 1 ,290 (July 2001 est.)
Age structure:
0-14 years: 25.0^% (male 166,754,893; female
151,598,117)
15-64 years: 67.88% (male 445,222,858; female
418,959,646)
65 years and over: 7.1 1% (male 42,547,296; female
48,028,480) (2001 est.)
Population growth rate: 0.88% (2001 est.)
Birth rate: 15.95 births/1 ,000 population (2001 est.)
Death rate: 6.74 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.39 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .09 male(s)/female
under 15 years: 1 A male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.06 male(s)/female (2001 est.)
Infant mortality rate: 28.08 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .62 years
male: 69.81 years
female: 73.59 years (2001 est.)
Total fertility rate: 1 .82 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 500,000
(1999 est.)
HIV/AIDS - deaths: 1 7,000 (1 999 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91 .9%, Zhuang,
Uygur, Hui, Yi, Tibetan, Miao, Manchu, Mongol, Buyi,
Korean, and other nationalities 8.1%
Religions: Daoist (Taoist), Buddhist, Muslim
2%-3%, Christian 1% (est.)
note: officially atheist
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect), Yue
(Cantonese), Wu (Shanghaiese), Minbei (Fuzhou),
Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, minority languages (see Ethnic groups entry)
Literacy:
definition: age 15 and over can read and write
total population: 81 .5%
male: 89.9%
fema/e; 72.7% (1995 est.)
104
China (continued)','c66e9ada321df2d07fc4c1d09d276e0aded35534ee6188a073004f5a3fddae96','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c427de3e4495d51ded548279d2abe3f1427e9e0e8d8c679a8467b0210b4408e',2001,'CX','Christmas Island','people-and-society',297,'Population: 2,771 (July 2001 est.)
Age structure:
0-/4 years; NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: 7.77% (2001 est.)
Birth rate: NA births/l ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic groups: Chinese 61%, Malay 25%,
European 11%, other 3%, no indigenous population
Religions: Buddhist 55%, Christian 15%, Muslim
10%, other 20% (1991)
Languages: English, Chinese, Malay','85f9698affa6de954dcb27abe393f9f37fd0597a4f1e65ce52b3cd72af6327d1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e1237fceda8df013caed94466590e2d34b2bbe36f42a1f145c3a11a765c6c4a',2001,'CO','Colombia','people-and-society',304,'Population: 40,349,388 (July 2001 est.)
Age structure:
0-14 years: 31 .88% (male 6,507,282; female
6,354,454)
15-64 years: 83.37% (male 12,452,182; female
13,117,707)
65 years and over: 4.75% (male 859,967; female
1,057,796) (2001 est.)
Population growth rate: 1.64% (2001 est.)
Birth rate: 22.41 births/1,000 population (2001 est.)
Death rate: 5.69 deaths/1,000 population
(2001 est.)
Net migration rate: -0.33 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 23.96 deaths/1 ,000 live births
(2001 est.)
110
Colombia (continued)
Life expectancy at birth;
total population: 70.57 years
mate; 66.71 years
female: 74.55 years (2001 est.)
Totai fertility rate: 2.66 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.31%
(1999 est.)
HIV/AIDS - people living with HiV/AiDS: 71 ,000
(1999 est.)
HiV/AIDS - deaths; 1 ,700 (1 999 est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto
14%, black 4%, mixed black-Amerindian 3%,
Amerindian 1%
Religions: Roman Catholic 90%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 91 .3%
male: 91 .2%
femate; 91 .4% (1995 est.)','a523f043d466b7cfa0d5d3d22c1a44aca074adb829538323bfb4eb486a4f60c4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69d9d99b59c934d8af6bea21146c01097151c9d1824389e58cc96600a8ebb465',2001,'MZ','Mozambique','people-and-society',312,'Population: 596,202 (July 2001 est.)
Age structure:
0-14 years: 42.81% (male 127,955; female 127,267)
15-64 years: 54.26% (male 159,560; female 163,949)
65 years and over: 2.93% (male 8,326; female 9,145)
(2001 est.)
Population growth rate: 3.02% (2001 est.)
Birthrate: 39.52 births/1,000 population (2001 est.)
Death rate: 9.35 deaths/1,000 population
(2001 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.97 ma!e(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.08 male(s)/female (2001 est.)
Infant mortality rate: 84.07 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 80.41 years
ma/e; 58.2 years
female: 62.68 years (2001 est.)
Total fertility rate: 5.32 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.12%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha,
Sakalava
Religions: Sunni Muslim 98%, Roman Catholic 2%
Languages: Arabic (official), French (official),
Comoran (a blend of Swahili and Arabic)
Literacy:
definition: age 15 and over can read and write
total population: 57.3%
male: 64.2%
fema/e; 50.4% (1995 est.)
Population: 53,624,718
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 4824% (male 12,988,488; female
12,878,232)
15-64 years: 4921% (male 12,931,886; female
13,459,109)
65 years and over: 2.55% (male 575,1 1 3; female
791,890) (2001 est.)
Population growth rate: 3.1% (2001 est.)
Birth rate: 46.02 births/1,000 population (2001 est.)
Death rate: 1 5.1 5 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0.14 migrant(s)/1,000
population (2001 est.)
note: one million refugees fled into Zaire (now called
the Democratic Republic of the Congo or DROC) in
1994 to escape the fighting between the Hutus and
the Tutsis; fighting in the DROC between rebels and
government forces in October 1996 caused 875,000
refugees to return to Rwanda in late 1996 and early
1997; an additional 173,000 Rwandan refugees
disappeared in early 1997 and are assumed to have
been killed by Zairian forces; fighting between the
Congolese government and Uganda- and
Rwanda-backed Congolese rebels spawned a
regional war in DROC in August 1998, which left 1.8
million Congolese displaced in DROC and caused
300,000 Congolese refugees to flee to surrounding
countries
Sex ratio:
at birth: 1 ,03 ma!e(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 99.88 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 48.94 years
male: 46.96 years
female: 50.98 years (2001 est.)
Total fertility rate: 6.84 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 5,07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .1
million (1999 est.)
HIV/AIDS -deaths: 95,000 (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes -
Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of
the population
Religions: Roman Catholic 50%, Protestant 20%,
Kimbanguist 10%, Muslim 10%, other syncretic sects
and indigenous beliefs 10%
Languages: French (official), Lingala (a lingua
franca trade language), Kingwana (a dialect of
Kiswahili or Swahili), Kikongo, Tshiluba
Literacy:
definition: age 1 5 and over can read and write French,
Lingala, Kingwana, or Tshiluba
total population: 77.3%
male: 86.6%
fema/e; 67.7% (1995 est.)
Population: no indigenous inhabitants
nofe.- there is a small French military garrison (July
2001 est.)
Population: 19,371,057
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected; the 1997 Mozambican census reported a
population of 16,099,246 (July 2001 est.)
Age structure:
0-14 years: 42.72% (male 4,124,093; female
4,152,135)
15-64 years: 54.53% (male 5,222,477; female
5,339,615)
65 years and over: 2.75% (male 221 ,678; female
311,059) (2001 est.)
Population growth rate: 1 .3% (2001 est.)
Birth rate: 37.2 births/1 ,000 population (2001 est.)
Death rate: 24.21 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.03 ma!e(s)/female
under 15 years: 0.90 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.9S male(s)/female (2001 est.)
Infant mortality rate: 139.2 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 36.45 years
male: 37.25 years
female: 35.62 years (2001 est.)
Total fertility rate: 4.82 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 13.22%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .2
million (1999 est.)
HIV/AIDS - deaths: 98,000 (1999 est.)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66%
(Shangaan, Chokwe, Manyika, Sena, Makua, and
others), Europeans 0.06%, Euro-Africans 0.2%,
Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: Portuguese (official), indigenous
dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 42.3%
male: 58.4%
female: 27% (1998 est.)
Population; 22,370,461 (July 2001 est.)
Age structure:
0-14 years: 21 .22% (male 2,470,270; female
2,276,108)
15-64 years: 69.97% (male 7,944,451 ; female
7,707,250)
65 years and over; 8.81% (male 1,034,230; female
938,152) (2001 est.)
Population growth rate: 0.8% (2001 est.)
Birthrate: 14.31 births/1,000 population (2001 est.)
Death rate: 6 deaths/1 ,000 population (2001 est.)
Net migration rate: -0.34 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .09 male(s)/female
under 15 years: 1 .09 male(s)/fema!e
15-64 years: 1 .03 male(s)/female
65 years and over: 1.1 male(s)/female
total population: 1 .05 male(s)/female (2001 est.)
Infant mortality rate: 6.93 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.54 years
male: 73.81 years
female: 79.5^ years (2001 est.)
Total fertility rate: 1.76 children born/woman
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths; NA
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Taiwanese (including Hakka) 84%,
mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and
Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese
(Min), Hakka dialects
565
Taiwan (continued)
Literacy:
definition: age 15 and over can read and write
total population: 86% (1980 est.); note - literacy for
the total population has reportedly increased to 94%
(1998 est.)
ma/e: 93% (1980 est.)
fema/e;79%(1980 est.)','d60244902fe7a1419da5aa3189425809a71d24518355d9261e382f2467c82db6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f648bdde5e74c3a3e35151c3f96438f07f1bc7b4e238c51ff349ac39db140233',2001,'CG','Congo','people-and-society',327,'Population: 2,894,336
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0^14 years: 42.43% (male 618,411; female 609,633)
15-64 years: 54.23% (male 765,501 ; female 804,1 25)
65 years and over: 3.34% (male 38,772; female
57,894) (2001 est.)
Population growth rate: 2.2% (2001 est.)
Birth rate: 38.24 births/1,000 population (2001 est.)
Death rate: 16.22 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 ma!e(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.97 ma!e(s)/female (2001 est.)
Infant mortality rate: 99.73 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 47.57 years
male: 44.38 years
female: 50.85 years (2001 est.)
Total fertility rate: 5 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 6.43%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 86,000
(1999 est.)
HIV/AIDS - deaths: 8,600 (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%, M''Bochi
12%, Teke 17%, Europeans NA%; note - Europeans
estimated at 8,500, mostly French, before the 1997
civil war; may be half that of 1998, following the
widespread destruction of foreign businesses in 1997
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Lingala and
Monokutuba (lingua franca trade languages), many
local languages and dialects (of which Kikongo has
the most users)
Literacy:
definition: age 1 5 and over can read and write
total population: 74.9%
ma/e;83.1%
fema/e.- 67.2% (1995 est.)','763d9e90926e5c8de12ece9532e5d4f713938c8be929770bc961adc3b417749e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd4cbcf14db46a48f16aa9fe7828d110964dae58dac623d92741e255d10ec748',2001,'CK','Cook Islands','people-and-society',331,'Population: 20,611 (July 2001 est.)
Age structure:
0-14 years: NA%
15-64 years: m%
65 years and over: N A%
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality;
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Polynesian (full blood) 81 .3%,
Polynesian and European 7.7%, Polynesian and
non-European 7.7%, European 2.4%, other 0,9%
Religions: Christian (majority of populace are
members of the Cook Islands Christian Church)
Languages: English (official), Maori
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%
Population: no indigenous inhabitants
note: there is a staff of three to four at the
meteorological station (July 2001 est.)
Population: uninhabited
note: Millersville settlement on western side of island
occasionally used as a weather station from 1 935 until
World War II, when it was abandoned; reoccupied in
1957 during the International Geophysical Year by
scientists who left in 1958; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service (July 2001 est.)
Population: 89,361 (July 2001 est.)
Age structure:
0-14 years: M .77% (male 8,214; female 7,667)
15-64 years: 67.59% (male 30,065; female 30,331)
65 years and over: 14.64% (male 5,603; female
7,481) (2001 est.)
Population growth rate: 0.48% (2001 est.)
Birth rate; 1 1 .28 births/1 ,000 population (2001 est.)
Death rate: 9.27 deaths/1 ,000 population
(2001 est.)
Net migration rate: 2.8 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1. OS male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.% male(s)/female (2001 est.)
Infant mortality rate; 5.62 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.63 years
male: 76.21 years
female: 81 .23 years (2001 est.)
Total fertility rate: 1 .56 children born/woman
(2001 est.)
HiV/AIDS “ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Baptist,
Congregational New Church, Methodist, Presbyterian
Languages: English (official), French (official),
Norman-French dialect spoken in country districts
Literacy:
definition: NA
total population: Hk
male: NA
female: NA
Population: no indigenous inhabitants
note: in previous years, there was an average of 1 ,1 00
US military and civilian contractor personnel present;
as of 1 October 2000, population decreased to
approximately 970 when US Army Chemical Activity
Pacific (USACAP) departed (January 2001 est.)
Population growth rate: -5.94% (2001 est.)','6c0b8b017dc9c2e8dab537a3ff78d6a3a95d7a692a750aad647137dd90433f82','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34e0fa57268c1a3a4817df54cf011d9ce2dc4719fcae12ddffe66e7b8532d5a5',2001,'CR','Costa Rica','people-and-society',339,'Population: 3,773,057 (July 2001 est.)
Age structure:
0-14 years: 31 .38% (male 605,728; female 578,128)
15-64 years: 63.37% (male 1 ,209,084; female
1,181,754)
65 years and over: 5.25% (male 92,31 4; female
106,049) (2001 est.)
Population growth rate: 1.65% (2001 est.)
Birth rate: 20.27 births/1,000 population (2001 est.)
Death rate: 4.3 deaths/1,000 population (2001 est.)
Net migration rate: 0.53 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 02 male(s)/female (2001 est.)
Infant mortality rate: 11.18 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.02 years
male: 73.49 years
female: 78.5S years (2001 est.)
Total fertility rate; 2.47 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 12,000
(1999 est.)
HIV/AIDS - deaths: 750 (1999 est.)
Nationality:
noun: Costa Rican(s)
adjective: Costa Rican
122
Costa Rica (continued)
Ethnic groups: white (including mestizo) 94%, black
3%, Amerindian 1%, Chinese 1%, other 1%
Religions: Roman Catholic 76.3%, Evangelical
13.7%, other Protestant 0.7%, Jehovah''s Witnesses
1 .3%, other 4.8%, none 3.2%
Languages: Spanish (official), English spoken
around Puerto Limon
Literacy:
definition: age 15 and over can read and write
total population: 94.8%
male: 94.7%
fema/e.'' 95% (1995 est.)','ba72ea6dd3ea3a7fcbdd948094e6cacfa227b8f17db5c61be7c50794c4983863','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4b0953c12740641189fa2cb8ba77f283758e1bc640f90a20be3addcc3c02fbf',2001,'NI','Nicaragua','people-and-society',348,'Population: 16,393,221
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
years; 46.21% (male 3,802,397; female
3,773,455)
15^64 years: 51 .57% (male 4,343,518; female
4,110,805)
65 years and over: 2.22% (male 1 80,463; female
182,583) (2001 est.)
Population growth rate: 2.51% (2001 est.)
Birth rate: 40.38 births/1,000 population (2001 est.)
Death rate: 16.65 deaths/1,000 population
(2001 est.)
Net migration rate: 1 .4 migrant(s)/1 ,000 population
(2001 est.)
note: after Liberia''s civil war started in 1990, more
than 350,000 refugees fled to Cote d''Ivoire; by the end
of 1 999 most Liberian refugees were assumed to have
returned
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .03 male(s)/fema!e (2001 est.)
Infant mortality rate: 93.65 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 44.93 years
male: 43.58 years
fema/e; 46.33 years (2001 est.)
Total fertility rate: 5.7 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 10.76%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 760,000
(1999 est.)
HIV/AIDS -deaths: 72,000 (1999 est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic groups: Akan 42.1 %, Voltaiques or Gur
17.6%, Northern Mandes 16.5%, Krous 11%,
Southern Mandes 10%, other 2.8% (1998)
Religions: Christian 34%, Muslim 27%, no religion
21%, animist 15%, other 3% (1998)
note: the majority of foreigners (migratory workers)
are Muslim (70%) and Christian (20%)
Languages: French (official), 60 native dialects with
Dioula the most widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 48.5%
male: 57%
female: 40%
Population: 4,918,393 (July 2001 est.)
Age structure:
0-14 years: 3SM% (male 976,087; female 941,141)
15-64 years: 58.08% (male 1 ,41 8,555; female
1,438,096)
65 years and over: 2.94% (male 62,963; female
81,551) (2001 est.)
Population growth rate: 2.15% (2001 est.)
Birth rate: 27.64 births/1,000 population (2001 est.)
Death rate: 4.82 deaths/1 ,000 population
(2001 est.)
Net migration rate; -1 .33 migrant(s)/1 ,000
population (2001 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 maie(s)/female (2001 est.)
Infant mortality rate: 33.66 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.05 years
male: 67.1 years
female: 71.1 1 years (2001 est.)
Total fertility rate: 3.18 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.2% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,900
(1999 est.)
HIV/AIDS -deaths: 360 (1999 est.)
Nationality;
noun: Nicaraguan(s)
adjective: Nicaraguan
Ethnic groups: mestizo (mixed Amerindian and
white) 69%, white 17%, black 9%, Amerindian 5%
369
Nicaragua (continued)
Religions: Roman Catholic 85%, Protestant
Languages: Spanish (official)
note: English and indigenous languages on Atlantic
coast
Literacy:
definition: age 15 and over can read and write
total population: 65.7%
male: 64.6%
fema/e.- 66.6% (1995 est.)','8bbef0a19a5e309c6124d5220fa4703279c44b7609a0d2962d9d60299d652a03','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c91b7519544b934f3bdbae674a30c14f034a6c937d4a05228eaf7d043a0b1b9',2001,'SI','Slovenia','people-and-society',353,'Population: 4,334,142 (July 2001 est.)
Age structure:
0-14years: 18.16% (male 403,722; female 383,151)
15’64 years: %.6^% (male 1 ,452,872; female
1,434,086)
65 years and over: 15.23% (male 245,727; female
414,584) (2001 est.)
Population growth rate: 1.48% (2001 est.)
Birth rate: 12.82 births/1,000 population (2001 est.)
Death rate: 1 1 .41 deaths/1 ,000 population
(2001 est.)
Net migration rate: 13.37 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-54 years.'' 1.01 male(s)/female
65 years and over: 0.59 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 7.21 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.9 years
male: 70.28 years
female: 77.73 years (2001 est.)
Total fertility rate: 1 .94 children born/woman
(2001 est.)
127
Croatia (continued)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 350
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic groups: Croat 78.1%, Serb 12.2%, Bosniak
0,9%, Hungarian 0.5%, Slovenian 0.5%, Czech 0.4%,
Albanian 0.3%, Montenegrin 0.3%, Roma 0.2%,
others 6.6% (1991)
Religions: Roman Catholic 76.5%, Orthodox 1 1 .1%,
Muslim 1.2%, Protestant 0.4%, others and unknown
10.8% (1991)
Languages: Croatian 96%, other 4% (including
Italian, Hungarian, Czech, Slovak, and German)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 95% (1991 est.)','d488a0c27b89ad0d9457097382a9685ad843ad1ebe8313142b2fcafdec530852','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f854486ddef2ed291c53b1a0b3b89672dcd778ed63f3ca828c357e3280965bf1',2001,'CU','Cuba','people-and-society',362,'Population: 11,184,023 (July 2001 est.)
Age structure:
0‘14 years: 20.99% (male 1 ,205,159; female
1,142,070)
15-64 years: 69.14% (male 3,876,432; female
3,855,878)
65 years and over: 9.87% (male 51 1 ,589; female
592,895) (2001 est.)
Population growth rate: 0.37% (2001 est.)
Birth rate: 12.36 births/1,000 population (2001 est.)
Death rate: 7.33 deaths/1,000 population
(2001 est.)
Net migration rate: -1.36 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-54 years; 1.01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 7.39 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.41 years
male: 74.02 years
female: 78.94 years (2001 est.)
Total fertility rate: 1 .6 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.03%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,950
(1999 est.)
HIV/AIDS - deaths: 120 (1999 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51 %, white 37%, black 1 1 %,
Chinese 1%
Religions: nominally 85% Roman Catholic prior to
CASTRO assuming power; Protestants, Jehovah''s
Witnesses, Jews, and Santeria are also represented
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.7%
male: 96.2%
fema/e; 95,3% (1995 est.)
People - note: illicit migration is a continuing
problem: Cubans attempt to depart the island and
enter the US using homemade rafts, alien smugglers,
direct flights, or falsified visas; some 3,000 Cubans
took to the Straits of Florida in 2000; the US Coast
Guard interdicted about 35% of these migrants;
Cubans also use non-maritime routes to enter the US;
some 2,400 Cubans arrived overland via the
southwest border and direct flights to Miami
Population: 6,964,549
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years.- 40.31% (male 1,421,945; female
1,385,580)
15-64 years: 55,52% (male 1,869,323; female
1,997,246)
65 years and over: 4.1 7% (male 140,556; female
149,899) (2001 est.)
Population growth rate: 1 .4% (2001 est.)
Birth rate: 31 .68 births/1 ,000 population (2001 est.)
Death rate: 15 deaths/1,000 population (2001 est.)
Net migration rate: -2.64 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.94 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 95.23 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 49.38 years
male: 47.87 years
female: 51.17 years (2001 est.)
218
Haiti (continued)
Total fertility rate; 4.4 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 5.17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 21 0,000
(1999 est.)
HIV/AIDS ■ deaths: 23,000 (1 999 est.)
Nationality:
noun: Haitian(s)
adjective: Haitian
Ethnic groups: black 95%, mulatto and white 5%
Religions: Roman Catholic 80%, Protestant 16%
(Baptist 10%, Pentecostal 4%, Adventist 1%, other
1%), none 1%, other 3% (1982)
note: roughly one-half of the population also practices
Voodoo
Languages: French (official). Creole (official)
Literacy:
definition: age 15 and over can read and write
totai population: 45%
male:4B%
female: 422% (^995 est.)','8331388926bc56a2b67529eb8cafba3daab448b1f21eda5739e7722119b6d87c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d068267c7c0434e5425cc3555a1b66201ee4fb5657a090a2ea8e391e4f792cb',2001,'CY','Cyprus','people-and-society',371,'Population: 762,887 (July 2001 est.)
Age structure:
0-14 years: 22,95% (male 89,532; female 85,518)
15-64 years: 66.26% (male 255,368; female 250,140)
65 years and over: 10.79% (male 35,864; female
46,465) (2001 est.)
Population growth rate: 0.59% (2001 est.)
Birth rate: 13.08 births/1,000 population (2001 est.)
Death rate: 7.65 deaths/1,000 population
(2001 est.)
Net migration rate: 0.44 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 7.89 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.89 years
male: 74.6 years
female: 79.3 years (2001 est.)
Total fertility rate: 1 .93 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 400
(1999 est.)
HIV/AIDS ■ deaths: NA
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic groups: Greek 78% (99.5% of the Greeks
live in the Greek Cypriot area; 0.5% of the Greeks live
in the Turkish Cypriot area), Turkish 18% (1 .3% of the
Turks live in the Greek Cypriot area; 98.7% of the
Turks live in the Turkish Cypriot area), other 4%
(99.2% of the other ethnic groups live in the Greek
Cypriot area; 0.8% of the other ethnic groups live in
the Turkish Cypriot area)
Religions: Greek Orthodox 78%, Muslim 18%,
Maronite, Armenian Apostolic, and other 4%
Languages; Greek, Turkish, English
Literacy:
definition: age 15 and over can read and write
total population: 94%
male: 98%
fema/e; 91% (1987 est.)
Population: 10,264,212 (July 2001 est.)
Age structure:
0-14 years: 16.09% (male 847,219; female 804,731)
15-64 years: 69.99% (male 3,592,984; female
3,590,802)
65 years and over: 13.92% (male 549,538; female
878,938) (2001 est.)
Population growth rate: -0.07% (2001 est.)
Birth rate: 9.11 births/1.000 population (2001 est.)
Death rate: 10.81 deaths/1,000 population
(2001 est.)
Net migration rate: 0.96 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 05 male(s)/female
15-64 years: 1 ma!e(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 5.55 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 74.73 years
male: 71 .23 years
fema/e.- 78.43 years (2001 est.)
Total fertility rate: 1.18 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Czech(s)
adjective: Czech
Ethnic groups: Czech 81.2%, Moravian 13.2%,
Slovak 3.1%, Polish 0.6%, German 0.5%, Silesian
0.4%, Roma 0.3%, Hungarian 0.2%, other 0.5%
(1991)
Religions: atheist 39.8%, Roman Catholic 39.2%,
Protestant 4.6%, Orthodox 3%, other 13.4%
Languages: Czech
Literacy:
definition: NA
total population: 99.9% (1999 est.)
male: NA%
female: NA%
Population: 5,352,815 (July 2001 est.)
Age structure:
0-/4 years; 18.59% (male 510,826; female 484,385)
/5-04 years; 66.56% (male 1,804,617; female
1,758,019)
65 years and over: 14.85% (male 331 ,906; female
463,062) (2001 est.)
Population growth rate: 0.3% (2001 est.)
Birth rate: 11.96 births/1,000 population (2001 est.)
Death rate: 1 0.9 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1 .98 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 5.04 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.72 years
ma/e; 74.1 2 years
Denmark (continued)
female: 79.47 years (2001 est.)
Total fertility rate: 1 .73 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,300
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Dane(s)
adjective: Danish
Ethnic groups: Scandinavian, Inuit, Faroese,
German, Turkish, Iranian, Somali
Religions: Evangelical Lutheran 95%, other
Protestant and Roman Catholic 3%, Muslims 2%
Languages: Danish, Faroese, Greenlandic (an Inuit
dialect), German (small minority)
note: English is the predominant second language
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: NA%
female: NA%','dfa8aa92ead869540dad9263f17f333203b9d5aba6e615c014471cfd93f3e610','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd25ee03c153d66a780946d54419d598c2b6cc0dc5149b87c757583c88f2c5cb',2001,'DJ','Djibouti','people-and-society',380,'Population: 460,700 (July 2001 est.)
Age structure:
0-14 years: 42.58% (male 98,314; female 97,859)
15-64 years: 54.58% (male 1 32,61 9; female 1 1 8,841 )
65 years and over: 2.84% (male 6,787; female 6,280)
(2001 est.)
Population growth rate: 2.6% (2001 est.)
Birth rate: 40.66 births/1 ,000 population (2001 est.)
Death rate; 14.66 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 03 male(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: ^^2 male(s)/female
65 years and over: 1 .08 male(s)/fema!e
total population: 1.07 male(s)/female (2001 est.)
Infant mortality rate; 1 01 .51 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 51 .21 years
male: 49.37 years
female: 53.1 years (2001 est.)
Total fertility rate: 5.72 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 1 .75%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 37,000
(1999 est.)
HIV/AIDS - deaths: 3,100 (1999 est.)
Nationality:
noun: Djiboutian(s)
adjective: Djibouti an
Ethnic groups: Somali 60%, Afar 35%, French,
Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official),
Somali, Afar
Literacy:
definition: age 15 and over can read and write
total population: 46.2%
male: 60.3%
fema/e; 32.7% (1995 est.)
Population: 70,786 (July 2001 est.)
Age structure:
0-14 years: 28.72% (male 10,300; female 10,027)
15-64 years: 63.45% (male 23,056; female 21 ,855)
65 years and over: 7.83% (male 2,267; female 3,281 )
(2001 est.)
Population growth rate: -0.98% (2001 est.)
Birth rate: 17.81 births/1 ,000 population (2001 est.)
Death rate: 7.1 9 deaths/1 ,000 population
(2001 est.)
Net migration rate: -20.37 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 1.01 male{s)/female (2001 est.)
Infant mortality rate: 1 6.54 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.6 years
male: 70.74 years
female: 78.81 years (2001 est.)
Total fertility rate: 2.03 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: black, Carib Amerindian
Religions: Roman Catholic 77%, Protestant 15%
(Methodist 5%, Pentecostal 3%, Seventh-Day
Adventist 3%, Baptist 2%, other 2%), none 2%, other
6%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 94%
male: 94%
fema/e.'' 94% (1970 est.)
Country name:
conventional long form: Commonwealth of Dominica
conventional short form: Dominica
Government type: parliamentary democracy;
republic within the Commonwealth
Capital: Roseau
Administrative divisions: 10 parishes; Saint
Andrew, Saint David, Saint George, Saint John, Saint
Joseph, Saint Luke, Saint Mark, Saint Patrick, Saint
Paul, Saint Peter
Independence: 3 November 1978 (from UK)
National holiday: Independence Day, 3 November
(1978)
Constitution: 3 November 1978
Legal system: based on English common law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Vernon Lordon SHAW (since
6 October 1998)
head of government: Prime Minister Pierre
CHARLES (since 1 October 2000); note - assumed
post after death of Roosevelt DOUGLAS
cabinet: Cabinet appointed by the president on the
advice of the prime minister
elections: president elected by the House of
Assembly for a five-year term; election last held
6 October 1998 (next to be held NA October 2003);
prime minister appointed by the president
election resu/fs.- Vernon Lordon SHAW elected
president; percent of legislative vote - NA%
Legislative branch: unicameral House of Assembly
(30 seats, 9 appointed senators, 21 elected by popular
vote; members serve five-year terms)
elections: last held 31 January 2000 (next to be held
by NA 2005)
election results: percent of vote by party - NA%; seats
byparty-DLPII.UWP 8, DFP2
Judicial branch: Eastern Caribbean Supreme
Court, consisting of the Court of Appeal and the High
Court (located in Saint Lucia; one of the six judges
must reside in Dominica and preside over the Court of
Summary Jurisdiction)
Political parties and leaders: Dominica Freedom
Party or DFP [Charles SAVARIN]; Dominica Labor
Party or DLP [Pierre CHARLES]; United Workers
Party or UWP [Edison JAMES]
Political pressure groups and leaders: Dominica
Liberation Movement or DLM (a small leftist party)
International organization participation: ACCT,
ACP, C. Caricom, CDB, ECLAC, FAO, G-77, IBRD,
ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO,
Interpol, IOC, ITU, NAM (observer), OAS, OECS,
OPANAL, OPCW, UN, UNCTAD, UNESCO, UNIDO,
UPU, WCL, WHO, WlPO, WMO, WTrO
Diplomatic representation in the US:
ch/ef of m/ss/on; Ambassador Nicholas J. 0.
LIVERPOOL (resident in Dominica)
chancery: 3216 New Mexico Avenue NW,
Washington, DC 20016
telephone: [1] (202) 364-6781
143
Dominica (continued)
E4X;[1](202) 364-6791
consu!ate(s) general: New York
Diplomatic representation from the US: the US
does not have an embassy in Dominica; US interests
are served by the embassy in Bridgetown, Barbados
Flag description: green, with a centered cross of
three equal bands - the vertical part is yellow (hoist
side), black, and white and the horizontal part is yellow
(top), black, and white; superimposed in the center of
the cross is a red disk bearing a sisserou parrot
encircled by 10 green, five-pointed stars edged in
yellow; the 10 stars represent the 10 administrative
divisions (parishes)','b4bd3c936c248975cfe4ad8afff4448174692bef3bded14f70100b1d6447933b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('360def96db334534c46ecf1e63270287360c9a2d7a88b8d0661aca1033d994f7',2001,'DO','Dominican Republic','people-and-society',388,'Population: 8,581,477 (July 2001 est.)
Age structure:
0-14 years: 34.1 1 % (male 1 ,495,477; female
1,431,406)
15-64 years: 60.99% (male 2,664,679; female
2,569,398)
65 years and over: 4.9% (male 1 99,240; female
221,277) (2001 est.)
Population growth rate: 1 .63% (2001 est.)
Birth rate: 24.77 births/1 ,000 population (2001 est.)
Death rate: 4.7 deaths/1 ,000 population (2001 est.)
Net migration rate: -3.81 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.03 male(s)/female (2001 est.)
Infant mortality rate: 34.67 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.44 years
male: 7 1.34 years
female: 75.64 years (2001 est.)
Total fertility rate: 2.97 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.8% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 4,900 (1999 est.)
Nationality;
noun: Dominican(s)
adjective: Dominican
Ethnic groups: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 32.1%
male: 82%
fema/e; 82.2% (1995 est.)
Population: 3,937,31 6 (July 2001 est.)
Age structure;
0-14 years: 23.73% (male 478,441 ; female 455,800)
15-64 years: 66.72% (male 1 ,242,245; female
1,345,421)
65 years and over: 10.55% (male 177,083; female
238,326) (2001 est.)
Population growth rate: 0.54% (2001 est.)
Birth rate: 15.26 births/1,000 population (2001 est.)
Death rate: 7.77 deaths/1,000 population
(2001 est.)
Net migration rate: -2.13 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 9.51 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.76 years
mate; 71.28 years
female: 80.48 years (2001 est.)
Total fertility rate: 1 .9 children born/woman
(2001 est.)
412
Puerto Rico (continued)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: NA
Religions: Roman Catholic 85%, Protestant and
other 15%
Languages: Spanish, English
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 90%
fema/e; 88% (1980 est.)','61226dfb751d66e8c510b3c4a6e03c7ed3e2ea2330c8dc196655ebafcf8f3ab1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f53151cbc142bf99a111e652350a6d31d376b06719ace64ac78461ed62b4c63',2001,'PE','Peru','people-and-society',397,'Population; 13,183,978 (July 2001 est.)
Age structure:
0-14 years: 35.8% (male 2,398,801 ; female
2,320,537)
)5-64 years; 59.81% (male 3,900,193; female
3,984,797)
65 years and over: 4.39% (male 269,372; female
310,278) (2001 est.)
Population growth rate: 2% (2001 est.)
Birth rate: 25.99 births/1 ,000 population (2001 est.)
Death rate: 5.44 deaths/1,000 population
(2001 est.)
Net migration rate: -0.55 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 0.00 male(s)/female (2001 est.)
Infant mortality rate: 34.08 deaths/1,000 live births
(2001 est.)
Life expectancy at birth;
total population: 71 .33 years
male: 68.52 years
female: 74.28 years (2001 est.)
Total fertility rate: 3.12 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.29%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 19,000
(1999 est.)
HIV/AIDS -deaths: 1,400 (1999 est.)
Nationality:
noun: Ecuadorian(s)
adjective: Ecuadorian
147
Ecuador (continued)
Ethnic groups: mestizo (mixed Amerindian and
white) 65%, Amerindian 25%, Spanish and others 7%,
black 3%
Religions: Roman Catholic 95%
Languages: Spanish (official), Amerindian
languages (especially Quechua)
Literacy:
definition: age 15 and over can read and write
total population: 90A%
male: 92%
fema/e; 88.2% (1995 est.)
Population: 27,483,864 (July 2001 est.)
Age structure:
0-14 years: 34.41% (male 4,803,464; female
4,654,890)
15-64 years: 60.8% (male 8,408,210; female
8,302,943)
65 years and over: 4.79% (male 603,309; female
711,048) (2001 est.)
Population growth rate: 1 .7% (2001 est.)
Birth rate: 23.9 births/1,000 population (2001 est.)
Death rate: 5.78 deaths/1 ,000 population
(2001 est.)
Net migration rate: -1 .08 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1,01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/fema!e (2001 est.)
Infant mortality rate: 39.39 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 70.3 years
male: 67.9 years
female: 72.81 years (2001 est.)
Total fertility rate: 2.96 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.35%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 48,000
(1999 est.)
HIV/AIDS - deaths: 4,100 (1999 est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
400
Peru (continued)
Ethnic groups: Amerindian 45%, mestizo (mixed
Amerindian and white) 37%, white 15%, black,
Japanese, Chinese, and other 3%
Religions: Roman Catholic 90%
Languages: Spanish (official), Quechua (official),
Aymara
Literacy:
definition: age 15 and over can read and write
total population: 88.7%
male: 94.5%
fema/e; 83% (1995 est.)','46e11b79627dfb59e5966c7c904795c3d3f4e9c1f36f81a6be3108180aff0e29','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e92241bb521be0251af74c80fe3bc7d71898d3a5b020287d780d2071e13fc9d',2001,'EG','Egypt','people-and-society',406,'Population: 69,536,644 (July 2001 est.)
Age structure:
0-14 years: 34.59% (male 12,313,585; female
11,739,072)
15-64 years: 61 .6% (male 21 ,61 4,284; female
21,217,978)
65 years and over: 3.81 % (male 1 ,1 60,967; female
1,490,758) (2001 est.)
Population growth rate: 1.69% (2001 est.)
Birth rate: 24.89 births/1,000 population (2001 est.)
Death rate: 7.7 deaths/1,000 population (2001 est.)
Net migration rate: -0.24 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: Ob male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1.02 male(s)/femaie (2001 est.)
Infant mortality rate: 60.46 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 63.69 years
mate; 61.62 years
female: 65.85 years (2001 est.)
Total fertility rate: 3.07 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AiDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Eastern Hamitic stock (Egyptians,
Bedouins, and Berbers) 99%, Greek, Nubian,
Armenian, other European (primarily Italian and
French) 1%
Religions: Muslim (mostly Sunni) 94%, Coptic
Christian and other 6%
Languages: Arabic (official), English and French
widely understood by educated classes
Literacy:
definition: age 1 5 and over can read and write
total population: 51 .4%
male: 63.6%
femate; 38.8% (1995 est.)','2e2da00d86cd1142ad0fc6b8094335db162298f0f3e1e749220d2bcd99d31a2d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce5a1265256ed4d56df1fb8a699dc83b7483edea4b756f9c95d9b0ad84cd166f',2001,'SV','El Salvador','people-and-society',415,'Population: 6,237,662 (July 2001 est.)
Age structure:
0-14 years: 37.68% (male 1 ,1 98,623; female
1,151,584)
15-64 years: 57.27% (male 1 ,693,865; female
1,878,254)
65 years and over: 5.05% (male 1 42,345; female
172,991) (2001 est)
Population growth rate: 1.85% (2001 est.)
Birth rate: 28.67 births/1,000 population (2001 est.)
Death rate: 6.18 deaths/1 ,000 population
(2001 est.)
Net migration rate: -3.95 mjgrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 ,04 male(s)/female
15-64 years: 0.9 male(s)/female
El Salvador (continued)
65 years and over: 0.82 male(s)/female
total population: 0.% male(s)/female (2001 est.)
Infant mortality rate: 28.4 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 70.03 years
male: 66.43 years
female: 73.81 years (2001 est.)
Total fertility rate: 3.34 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate; 0.6% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 20,000
(1999 est.)
HIV/AIDS ■ deaths: 1 ,300 (1 999 est.)
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic groups: mestizo 90%, Amerindian 1%, white
9%
Religions: Roman Catholic 86%
note: there is extensive activity by Protestant groups
throughout the country; by the end of 1 992, there were
an estimated 1 million Protestant evangelicals in El
Salvador
Languages: Spanish, Nahua (among some
Amerindians)
Literacy:
definition: age 10 and over can read and write
total population: 7 1.5%
male: 73.5%
fema/e; 69.8% (1995 est.)','0bfba50a8896c5d3ed1746b2cf8f45962668d7a187415ecb1c9b89be8909fa76','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2c3931ae7bff7c61343d1af3121ed4d4e47d45fa7046d745c24b56128142c73',2001,'GQ','Equatorial Guinea','people-and-society',424,'Population: 486,060 (July 2001 est.)
Age structure:
0-M years; 42.56% (male 103,909; female 102,946)
15S4 years: 53.68% (male 1 24,808; female 1 36,088)
65 years and over: 3.76% (male 8,1 78; female
10,131) (2001 est.)
Population growth rate: 2.46% (2001 est.)
Birth rate: 37.72 births/1 ,000 population (2001 est.)
Death rate: 1 3.1 1 deaths/1 ,000 population
(2001 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: ^.0^ male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.05 male(s)/female (2001 est.)
Infant mortality rate: 92.9 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 53.95 years
male: 51 .89 years
female: 56.07 years (2001 est.)
Total fertility rate: 4.88 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.51%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1,100
(1999 est.)
HIV/AIDS - deaths: 1 20 (1 999 est.)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some
Fernandinos), Rio Muni (primarily Fang), Europeans
less than 1 ,000, mostly Spanish
Religions: nominally Christian and predominantly
Roman Catholic, pagan practices
Languages: Spanish (official), French (official),
pidgin English, Fang, Bubi, Ibo
Literacy:
definition: age 15 and over can read and write
total population: 78.5%
male: 89.6%
fema/e; 68.1% (1995 est.)','73302ae936ea86a35a0c964e8700d2ec3d07f068bddeaacae81123328f3a6e48','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('377056905eaea48a5a0118f950ba3fab6c034597cc9a5f03457b36169b48ce06',2001,'GN','Guinea','people-and-society',433,'Population: 4,298,269 (July 2001 est.)
Age structure:
0-M years; 42.85% (male 922,691 ; female 918,916)
15-64 years: 53.87% (male 1 ,147,927; female
1,167,705)
65 years and over: 3.28% (male 71 ,232; female
69,798) (2001 est.)
Population growth rate: 3.84% (2001 est.)
Birth rate: 42.52 births/1 ,000 population (2001 est.)
Death rate: 12.07 deaths/1 ,000 population
(2001 est.)
Net migration rate: 7.91 migrant(s)/1 ,000
population (2001 est.)
note: according to the UNHCR, about 150,000
Eritrean refugees in Sudan have registered for
voluntary repatriation, following the restoration of
diplomatic relations between Eritrea and Sudan in
January 2000
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 75.14 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 56.18 years
male: 53.79 years
female: 58.71 years (2001 est.)
Total fertility rate: 5.87 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.87%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and
Kunama 40%, Afar 4%, Saho (Red Sea coast
dwellers) 3%
Religions: Muslim, Coptic Christian, Roman
Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and
Kunama, Tigrinya, other Cushitic languages
Literacy:
definition: NA
total population: 25%
male: NA%
female: NA%
Population: 7,61 3,870 (July 2001 est.)
Age structure:
0-14 years: 43.12% (male 1 ,637,000; female
1,645,786)
15-64 years: 54.19% (male 2,015,199; female
2,110,745)
65 years and over: 2.69% (male 84,586; female
120,554) (2001 est.)
Population growth rate: 1.96% (2001 est.)
Birth rate: 39.78 births/1 ,000 population (2001 est.)
Death rate: 17.53 deaths/1 ,000 population
(2001 est.)
Net migration rate: -2.63 migrant(s)/1 ,000
population (2001 est.)
note: as a result of civil war in neighboring countries,
Guinea is host to almost half a million Liberian and
Sierra Leonean refugees
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 male(s)/female (2001 est.)
Infant mortality rate: 1 29.03 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 45.91 years
male: 43.49 years
female: 48.42 years (2001 est.)
Total fertility rate: 5.39 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS; 55,000
(1999 est.)
HIV/AIDS -deaths; 5,600 (1999 est.)
Nationality:
noun: Guinean(s)
adjective: Guinean
211
Guinea (continued)
Ethnic groups: Peuh! 40%, Malinke 30%, Soussou
20%, smaller ethnic groups 10%
Religions: Muslim 85%, Christian 8%, indigenous
beliefs 7%
Languages: French (official), each ethnic group has
its own language
Literacy:
definition: age 15 and over can read and write
total population: 35.9%
male: 49.9%
fema/e.* 21.9% (1995 est.)','b0a75a50c6f07a78ac615b533c1350899c78824648f7095cac6960df903fa9a2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ffe35406f1f7833ec0fa25f1e1fcbee9cb1c38f504f7549bad867cb3079f0a3',2001,'EE','Estonia','people-and-society',436,'Population: 1,423,316 (July 2001 est.)
Age structure:
0-14 years; 17.08% (male 123,997; female 119,166)
15-64 years: 68.14% (male 466,823; female 503,032)
65 years and over: 14.78% (male 68,802; female
141,496) (2001 est.)
Population growth rate: -0.55% (2001 est.)
Birth rate: 8.7 births/1,000 population (2001 est.)
Death rate: 1 3.48 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.76 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-54 years; 0.93 male(s)/female
65 years and over: 0.49 male(s)/female
total population: 0.86 male(s)/female (2001 est.)
Infant mortality rate: 1 2.62 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.73 years
male: 63.72 years
female: 76.05 years (2001 est.)
Total fertility rate: 1.21 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 65.1%, Russian 28.1%,
Ukrainian 2.5%, Byelorussian 1.5%, Finn 1%, other
1.8% (1998)
Religions: Evangelical Lutheran, Russian Orthodox,
Estonian Orthodox, Baptist, Methodist, Seventh-Day
Adventist, Roman Catholic, Pentecostal, Word of Life,
Jewish
Languages: Estonian (official), Russian, Ukrainian,
English, Finnish, other
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
fema/e; 100% (1998 est.)','adb912b36ffe119ea31d4b7a6858c46be0168f37843fc0bf9945c905c42b685e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2fccc1bae5d9dba288e8ae14c66cab08ccd9fa99384a04e294d0b8c257d1acd',2001,'FO','Faroe Islands','people-and-society',444,'Population: 45,661 (July 2001 est.)
Age structure:
0-14 years: 22.62% (male 5,193; female 5,136)
15-64 years: 33M% (male 15,463; female 13,596)
65 years and over: 13.74% (male 2,802; female
3,471) (2001 est.)
Population growth rate: 0.78% (2001 est.)
Birth rate: 13.64 births/1 ,000 population (2001 est.)
Death rate: 8.69 deaths/1 ,000 population
(2001 est.)
Net migration rate: 2.89 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth:] male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1.14 male(s)/female
65 years and over 0.81 male(s)/female
total population: 1 .06 male(s)/female (2001 est.)
Infant mortality rate: 6.8 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.59 years
ma/e.‘ 75.12 years
female: 82.06 years
Total fertility rate; 2.3 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality;
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages; Faroese (derived from Old Norse),
Danish
Literacy:
definition: NA
total population:
male: NA%
female: NA%
note: similar to Denmark proper','0bfd7b55c4ebe6ecbc3e2e8c5626b91f3579e6e151f5dc6cc08100fd399664da','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caeda8f2d0cfc81d2373dc50479623eb17d9aacd6178c2e357d21a4981cd1035',2001,'JE','Jersey','people-and-society',455,'Population: 844,330 (July 2001 est.)
Age structure:
0-/4 years; 32.92% (male 141,724; female 136,216)
15-64 years: 63.52% (male 268,41 1 ; female 267,871 )
65 years and over: 3.56% (male 14,007; female
16,101) (2001 est.)
Population growth rate: 1.41% (2001 est.)
Birth rate: 23.33 births/1 ,000 population (2001 est.)
Death rate: 5.75 deaths/1,000 population
(2001 est.)
Net migration rate: -3.45 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 .01 male(s)/female (2001 est.)
Infant mortality rate: 1 4.08 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.25 years
male: 65.83 years
female: 70.78 years (2001 est.)
Total fertility rate: 2.86 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Fijian(s)
adjective: Fijian
168
Fiji (continued)
Ethnic groups: Fijian 51% (predominantly
Melanesian with a Polynesian admixture), Indian
44%, European, other Pacific Islanders, overseas
Chinese, and other 5% (1998 est.)
Religions: Christian 52% (Methodist 37%, Roman
Catholic 9%), Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu,
and there is a Muslim minority (1986)
Languages: English (official), Fijian, Hindustani
Literacy:
definition: age 15 and over can read and write
totai population: 91 .6%
male: 93.8%
fema/e; 89.3% (1995 est.)
Population: 5,175,783 (July 2001 est.)
Age structure:
0-/4 years.'' 18% (male 474,967; female 456,584)
15-64 years: 66.97% (male 1 ,750,660; female
1,715,358)
65 years and over: 15.03% (male 300,569; female
477,645) (2001 est.)
Population growth rate: 0.16% (2001 est.)
Birth rate: 10.69 births/1 ,000 population (2001 est.)
Death rate: 9.75 deaths/1,000 population
(2001 est.)
Net migration rate: 0.61 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 3.79 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.58 years
male: 73.92 years
female: 81 .36 years (2001 est.)
Total fertility rate: 1 .7 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1,100
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93%, Swede 6%, Sami 0.1 1%,
Roma 0.12%, Tatar 0.02%
Religions: Evangelical Lutheran 89%, Greek
Orthodox 1%, none 9%, other 1%
Languages: Finnish 93.4% (official), Swedish 5.9%
(official), small Lapp- and Russian-speaking
minorities
Literacy:
definition: age 15 and over can read and write
total population: 100% (1980 est.)
male: NA%
female: NA%
Population: 2,041,961
note.'' includes 1,159,913 non-nationals (July
2001 est.)
Age structure:
0-14 years: 28.76% (male 299,080; female 288,125)
15-64 years: 68.82% (male 897,839; female 507,527)
65 years and over: 2.42% (male 31 ,843; female
17,547) (2001 est.)
Population growth rate: 3.38% (2001 est.)
note: this rate reflects a return to pre-Gulf crisis
immigration of expatriates
Birth rate: 21.91 births/1 ,000 population (2001 est.)
Death rate: 2.45 deaths/1,000 population
(2001 est.)
Net migration rate: 14.31 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1M male(s)/female
under 15 years: 1.04 male(s)/fema!e
15-64 years: 1.77 male(s)/female
65 years and over: 1 .81 male(s)/female
total population: 1.51 male(s)/female (2001 est.)
Infant mortality rate: 11.18 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.27 years
male: 75.42 years
fema/e.'' 77.15 years (2001 est.)
Total fertility rate: 3.2 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.12%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South
Asian 9%, Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 45%, Shi''a 40%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 1 5 and over can read and write
total population: 78.6%
male: 82.2%
femate.'' 74.9% (1995 est.)
Population: 204,863 (July 2001 est.)
Age structure:
044 years; 30.31% (male 31,674; female 30,416)
15-64 years: 63.95% (male 66,014; female 65,006)
65 years and over: 5.74% (male 5,548; female 6,205)
(2001 est.)
Population growth rate: 1.48% (2001 est.)
Birth rate: 20.37 births/1 ,000 population (2001 est.)
Death rate: 5.62 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 8.4 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 73.02 years
male: 70.08 years
female: 76M years (2001 est.)
Total fertility rate: 2.48 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European
37.1%, Wallisian 8.4%, Polynesian 3.8%, Indonesian
3.6%, Vietnamese 1.6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%,
other 10%
Languages: French (official), 33
Melanesian-Polynesian dialects
Literacy:
definition: age 15 and over can read and write
total population: 91%
male: 92%
fema/e; 90% (1976 est.)
Population; 1 ,930, 1 32 (July 2001 est.)
Age structure;
0-14 years; 16.09% (male 159,428; female 151,134)
15-64 years: 69.61% (male 681 ,333; female 662,170)
65 years and over: 14.3% (male 101,354; female
174,713) (2001 est.)
Population growth rate: 0.14% (2001 est.)
Birthrate: 9.32 births/1,000 population (2001 est.)
Death rate: 9.98 deaths/1,000 population
(2001 est.)
Net migration rate: 2.11 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-54 years; 1.03 male(s)/female
65 years and over: 0.58 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 4.51 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.08 years
male: 71 .2 years
female: 79.17 years (2001 est.)
Total fertility rate: 1 .28 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: S!ovene(s)
adjective: Slovenian
Ethnic groups: Slovene 88%, Croat 3%, Serb 2%,
Bosniak 1%, Yugoslav 0.6%, Hungarian 0.4%, other
5% (1991)
Religions: Roman Catholic 68.8%, Uniate Catholic
2%, Lutheran 1%, Muslim 1%, atheist 4.3%, other
22.9%
Languages: Slovenian 91%, Serbo-Croatian 6%,
other 3%
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%
Population: 1,104,343
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years; 45.53% (male 250,327; female 252,479)
15-64 years: 51 .88% (male 276,186; female 296,728)
65 years and over: 2.59% (male 1 1 ,687; female
16,936) (2001 est.)
Population growth rate; 1.83% (2001 est.)
Birth rate: 40.12 births/1,000 population (2001 est.)
Death rate; 21.84 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio;
at birth: 1 .03 male{s)/female
under 15 years: OM ma!e(s)/female
15-64 years: 0.93 male{s)/female
65 years and over: 0.69 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 1 09.1 9 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 38.62 years
male: 37.86 years
female: 39.4 years (2001 est.)
Total fertility rate: 5.82 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 25.25%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 7,100 (1999 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Protestant 55%, Muslim 10%, Roman
Catholic 5%, indigenous beliefs 30%
Languages: English (official, government business
conducted in English), siSwati (official)
Literacy:
definition: age 15 and over can read and write
total population: 76.7%
male: 78%
fema/e; 75.6% (1995 est.)
Population: 8,875,053 (July 2001 est.)
Age structure:
0-14 years; 18.19% (male 828,308; female 786,353)
15-64 years: 64.53% (male 2,91 1 ,949; female
2,814,730)
65 years and over: 17.28% (male 649,296; female
884,417) (2001 est.)
Population growth rate: 0.02% (2001 est.)
Sweden (continued)
Birthrate: 9.91 births/1,000 population
(2001 est.)
Death rate: 10.61 deaths/1,000 population
(2001 est.)
Net migration rate: 0.91 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 06 male(s)/female
under 15 years: 05 nnale(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.96 male(s)/female (2001 est.)
Infant mortality rate: 3.47 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.71 years
male: 77.07 years
female: 82.5 years (2001 est.)
Total fertility rate: 1.53 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Swede(s)
adjective: Swedish
Ethnic groups: indigenous population: Swedes and
Finnish and Sami minorities; foreign-born or
first-generation immigrants: Finns, Yugoslavs, Danes,
Norwegians, Greeks, Turks
Religions: Lutheran 87%, Roman Catholic,
Orthodox, Baptist, Muslim, Jewish, Buddhist
Languages: Swedish
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1 979 est.)
male: NA%
female: NA%','8e9f399def5bd45a50afb65f243fee996bd7f9db713515d6f99d30b3ce89c23c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f1341627e4b1b0d66e8388622798a57464dd61c855edbebd89e1e23711c739',2001,'GF','French Guiana','people-and-society',472,'Population: 177,562 (July 2001 est)
Age structure:
0-14 years: 30.47% (male 27,669; female 26,428)
15-64 years: 64.05% (male 61 ,457; female 52,266)
65 years and over: 5.48% (male 4,937; female 4,805)
(2001 est.)
Population grovirth rate: 2.74% (2001 est.)
Birth rate: 22.02 births/1 ,000 population (2001 est.)
Death rate: 4.77 deaths/1 ,000 population
(2001 est.)
Net migration rate: 10.14 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
afb/rth.-1.05male(s)/femate
under 15 years: 1 .05 male(s)/female
15-64 years: 1.18 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: ^ A3 male(s)/female (2001 est.)
Infant mortality rate: 13.61 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.3 years
male: 72.97 years
female: 79.79 years (2001 est.)
Total fertility rate: 3.17 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 12%,
East Indian, Chinese, Amerindian 12%, other 10%
Religions; Roman Catholic
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 83%
male: 84%
female: 32% {1932 est.)','1d08b7d82e711592453b6856e14247dc694d2f158ce7b4212963c08abbbfa244','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81b37385417ae29aa95bb73230cdc3d655b7f37b09fe69496f1d4c589db72650',2001,'KI','Kiribati','people-and-society',478,'Population: 253,506 (July 2001 est.)
Age structure:
0-/4 years; 29.74% (male 38,473; female 36,925)
15-64 years: 65.17% (male 86,128; female 79,076)
65 years and over: 5.09% (male 6,481 ; female 6,423)
(2001 est.)
Population growth rate: 1.72% (2001 est.)
Birth rate: 18.6 births/1,000 population (2001 est.)
Death rate: 4.45 deaths/1 ,000 population
(2001 est.)
Net migration rate: 3.09 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .09 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1 .07 male(s)/female (2001 est.)
Infant mortality rate: 9.12 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.01 years
male: 72.67 years
female: 77.46 years (2001 est.)
Total fertility rate: 2.23 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
Ethnic groups: Polynesian 78%, Chinese 12%,
local French 6%, metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%,
other 16%
Languages: French (official), Tahitian (official)
Literacy:
definition: age 14 and over can read and write
total population: 98%
male: 98%
fema/e; 98% (1977 est.)
Population: 94,149 (July 2001 est.)
Age structure:
0-/4 years; 40.53% (male 19,322; female 18,833)
15-64 years: 56.27% (male 26,136; female 26,841)
65 years and over: 3.2% (male 1 ,291 ; female 1 ,726)
(2001 est.)
Population growth rate: 2.31% (2001 est.)
Birth rate: 31.98 births/1,000 population (2001 est.)
Death rate: 8.88 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.75 male(s)/femaie
total population: 0.90 male(s)/female (2001 est.)
Infant mortality rate: 54 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 60.16 years
male: 57.25 years
female: 63.22 years (2001 est.)
Total fertility rate: 4.36 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS ■ people living with HiV/AIDS: NA
HIV/AIDS- deaths: NA
271
Kiribati (continued)
Nationality:
noun: (-Kiribati (singular and plural)
adjective: (-Kiribati
Ethnic groups: predominantly Micronesian with
some Polynesian
Religions: Roman Catholic 54%, Protestant
(Congregational) 30%, some Seventh-Day Adventist,
Baha''i, Latter-day Saints, and Church of God (1996)
Languages: English (official), (-Kiribati
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: 21 ,968,228 (July 2001 est.)
Age structure:
0-14 years: 25.52% (male 2,873,390; female
2,733,163)
15-64 years: 67.63% (male 7,301 ,531 ; female
7,556,554)
65 years and over: 6.85% (male 486,805; female
1,016,785) (2001 est.)
Population growth rate: 1.22% (2001 est.)
Birth rate: 19.1 births/1,000 population (2001 est.)
Death rate: 6.92 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.94 male(s)/female (2001 est.)
Infant mortality rate: 23.55 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .02 years
male: 68.04 years
female: 74.15 years (2001 est.)
Total fertility rate: 2.26 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
273
Korea, North (continued)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: racially homogeneous; there is a
small Chinese community and a few ethnic Japanese
Religions: traditionally Buddhist and Confucianist,
some Christian and syncretic Chondogyo (Religion of
the Heavenly Way)
note: autonomous religious activities now almost
nonexistent: government-sponsored religious groups
exist to provide illusion of religious freedom
Languages: Korean
Literacy:
definition: age 1 5 and over can read and write Korean
total population: 99%
male: 99%
female: 99% (1990 est.)
Population: 47,904,370 (July 2001 est.)
Age structure:
0-14 years: 21.59% (male 5,475,453; female
4,864,918)
15-64 years: 71. 14% (male 17,291,202; female
16,789,380)
65 years and over: 7.27% (male 1 ,352,312; female
2,131,105) (2001 est.)
Population growth rate: 0.89% (2001 est.)
Birth rate: 14.85 births/1,000 population (2001 est.)
Death rate: 5.93 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.11 male(s)/female
under 15 years: 1.13 ma!e(s)/female
15-64 years; 1.03 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 1.01 male(s)/female (2001 est.)
Infant mortality rate: 7.71 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 74.65 years
male: 70.97 years
female: 78.74 years (2001 est.)
Total fertility rate: 1 .72 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,800
(1999 est.)
HIV/AIDS -deaths: 180 (1999 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about
20,000 Chinese)
Religions: Christian 49%, Buddhist 47%,
Confucianist 3%, Shamanist, Chondogyo (Religion of
the Heavenly Way), and other 1%
Languages: Korean, English widely taught in junior
high and high school
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99.3%
fema/e; 96.7% (1995 est.)','5163fb7d9de379a75ea7ffb315ccfa7fbb7ff5a375eb698a61c9c30b388eeeb0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e2348c6986457438b6e583281ce0fef7b0844593a929ed2196614693fc1263d',2001,'DE','Germany','people-and-society',486,'Population: 83,029,536 (July 2001 est.)
Age structure:
0-14 years: 15.57% (male 6,635,328; female
6,289,994)
15-64 years: 67.82% (male 28,61 9,237; female
27,691,698)
65 years and over: 16.61 % (male 5,336,664; female
8.456,615) (2001 est.)
Population growth rate: 0.27% (2001 est.)
Birth rate: 9.16 births/1,000 population (2001 est.)
Death rate: 10.42 deaths/1,000 population
(2001 est.)
Net migration rate: 4 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.% male(s)/female (2001 est.)
Infant mortality rate: 4.71 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 77.61 years
male: 74.47 years
female: 80.92 years (2001 est.)
Total fertility rate: 1 .38 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HiV/AIDS: 37,000
(1999 est.)
HIV/AIDS -deaths: 600 (1999 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91.5%, Turkish 2.4%, other
6.1% (made up largely of Serbo-Croatian, Italian,
Russian, Greek, Polish, Spanish)
Religions: Protestant 38%, Roman Catholic 34%,
Muslim 1 .7%, unaffiliated or other 26.3%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99% (1977 est.)
male: NA%
female: NA%
Population: 442,972 (July 2001 est.)
Age structure:
0-14 years: 1 8.91 % (male 43,051 ; female 40,71 1 )
15-64 years: 67.03% (male 149,781 ; female 147,1 65)
65 years and over: 14.06% (male 24,921 ; female
37,343) (2001 est.)
Population growth rate: 1 .26% (2001 est.)
Birth rate: 12.25 births/1,000 population (2001 est.)
Death rate: 8.88 deaths/1,000 population
(2001 est.)
Net migration rate: 9.26 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 4.77 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.3 years
male: 74.02 years
female: 80.8 years (2001 est.)
Total fertility rate: 1 .7 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1 6%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: less than 100 (1999 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
301
Luxembourg (continued)
Ethnic groups: Celtic base (with French and
German blend), Portuguese, Italian, Slavs (from
Montenegro, Albania, and Kososvo) and European
(guest and resident workers)
Religions: the greatest preponderance of the
population is Roman Catholic with a very few
Protestants, Jews, and Muslims
note: 1 979 legislation forbids the collection of religious
statistics
Languages: Luxembourgish (national language),
German (administrative language), French
(administrative language)
Literacy:
definition: age 15 and over can read and write
total population: W0%
male: 100%
female: 100% (2000 est.)
Population: 453,733 (July 2001 est.)
Age structure:
0-14 years: 22.68% (male 53,291 ; female 49,615)
15-64 years: 70.08% (male 1 50,538; female 1 67,431 )
65 years and over: 7.24% (male 1 3,287; female
19,571) (2001 est.)
Population growth rate: 1.79% (2001 est.)
Birth rate: 12.36 births/1,000 population (2001 est.)
Death rate: 3.71 deaths/1 ,000 population
(2001 est.)
Net migration rate: 9.25 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.92 ma!e(s)/female (2001 est.)
Infant mortality rate: 4.47 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 81 .69 years
male: 78.88 years
female: 84.64 years (2001 est.)
Total fertility rate: 1 .31 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS; NA
HIV/AIDS -deaths: NA
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, Macanese (mixed
Portuguese and Asian ancestry), Portuguese, other
Religions: Buddhist 50%, Roman Catholic 15%,
none and other 35% (1997 est.)
Languages: Portuguese, Chinese (Cantonese)
Literacy:
definition: age 1 5 and over can read and write
total population: 90%
male: 93%
female: m%(19S1 est.)
Population: 2,046,209 (July 2001 est.)
Age structure:
0^14 years: 22.92% (male 243,715; female 225,349)
15-64 years: 66.94% (male 688,484; female 681 ,225)
65 years and over: 10.14% (male 92,043; female
115,393) (2001 est.)
Population growth rate: 0.43% (2001 est.)
Birth rate: 13.5 biilhs/1,000 population (2001 est.)
Death rate: 7.7 deaths/1,000 population (2001 est.)
Net migration rate: -1 .54 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 12.95 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 74.02 years
male: 7 1.79 years
tomato; 76.43 years (2001 est.)
Total fertility rate: 1 .79 children born/woman
(2001 est.)
HIV/AIDS " adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic groups: Macedonian 66.6%, Albanian
22.7%, Turkish 4%, Roma 2.2%, Serb 2.1%, other
2.4% (1994)
Religions: Macedonian Orthodox 67%, Muslim 30%,
other 3%
Languages: Macedonian 70%, Albanian 21%,
Turkish 3%, Serbo-Croatian 3%, other 3%
Literacy:
definition: NA
total population: N A%
male: NA%
female: NA%
Population: 15,981,472 (July 2001 est.)
Age structure:
0-14 years: 18.38% (male 1 ,501 ,925; female
1,436,017)
f 5-64 years.'' 67.9% (male 5,518,575; female
5,333,442)
65 years and over: 13.72% (male 899,052; female
1,292,461) (2001 est.)
Population growth rate: 0.55% (2001 est.)
Birth rate: 1 1 .85 births/1 ,000 population (2001 est.)
Death rate: 8.69 deaths/1,000 population
(2001 est.)
Net migration rate: 2.34 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 ,04 male(s)/female
under 15 years: 1 .05 male(s)/female
y5-64 years; 1.03 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0. 98 male(s)/female (2001 est.)
Infant mortality rate: 4.37 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.43 years
male: 75.85 years
female: 81 .44 years (2001 est.)
Total fertility rate: 1 .65 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.19%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 15,000
(1999 est.)
HIV/AIDS - deaths: 1 00 (1 999 est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 91%, Moroccans, Turks, and
other 9% (1999 est.)
Religions: Roman Catholic 31 %, Protestant 21 %,
Muslim 4.4%, other 3.6%, unaffiliated 40% (1998)
Languages: Dutch
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (2000 est.)
male: NA%
female: NA%','178888c61c8d60cb4566a67a20946daeb7a4a7011e65c2b9ced6eff2a8105457','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e231d006cc3fe6108c27ec39f3494235e61adbcce5a184efbe6634f1d7ab3c',2001,'GH','Ghana','people-and-society',494,'Population: 19,894,014
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 41.18% (male 4,123,317; female
4,068,786)
15-64 years: 55.35% (male 5,455,577; female
5,555,278)
65 years and over: 3.47% (male 328,809; female
362,247) (2001 est.)
Population growth rate: 1.79% (2001 est.)
Birth rate: 28.95 births/1,000 population (2001 est.)
Death rate: 10.26 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.83 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years anof over; 0.91 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 56.54 deaths/1 ,000 live births
(2001 est.)
192
Ghana (continued)
Life expectancy at birth:
total population: 57.24 years
male: 55.86 years
female: 58.66 years (2001 est.)
Total fertiiity rate: 3.82 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 3.6% (1999 est.)
HIV/AIDS - people living with HiV/AIDS: 340,000
(1999 est.)
HIV/AIDS - deaths: 33,000 (1 999 est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic groups: black African 99.8% (major tribes -
Akan 44%, Moshi-Dagomba 16%, Ewe 13%, Ga 8%),
European and other 0.2%
Religions: indigenous beliefs 38%, Muslim 30%,
Christian 24%, other 8%
Languages; English (official), African languages
(including Akan, Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition: age 1 5 and over can read and write
total population: 64.5%
male: 75.9%
fema/e; 53.5% (1995 est.)','ad146cec9b44468bd0be183cfa58b9eb5ba69c9320d2b855805cd52fdd04a659','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba7b0d470843fbaac6ab0228f6b30ea1ba9652a2ba9782b094c7c74a4070ad18',2001,'GI','Gibraltar','people-and-society',502,'Population: 27,649 (July 2001 est.)
Age structure:
0-14 years: 1 8.73% (male 2,652; female 2,528)
15-64 years: 66.33% (male 9,473; female 8,866)
65 years and over: 1 4.94% (male 1 ,733; female
2,397) (2001 est.)
Population growth rate: 0.24% (2001 est.)
Birth rate: 1 1 .25 births/1 ,000 population (2001 est.)
Death rate: 8.82 deaths/1,000 population
(2001 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 5.49 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.09 years
male: 76.23 years
female: S2.1 years (2001 est.)
Total fertility rate: 1 .64 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Spanish, Italian, English, Maltese,
Portuguese
Religions: Roman Catholic 76.9%, Church of
England 6.9%, Muslim 6.9%, Jewish 2.3%, none or
other 7% (1991)
Languages: English (used in schools and for official
purposes), Spanish, Italian, Portuguese, Russian
Literacy:
definition: NA
total population: above 80%
male: NA%
female: NA%
Population: no indigenous inhabitants
note; there is a small French military garrison (July
2001 est.)
Population: 30,645,305 (July 2001 est.)
Age structure:
0-14 years: 34.39% (male 5,368,784; female
5,170,891)
15-64 years: 60.93% (male 9,270,095; female
9,402,561)
65 years and over: 4.68% (male 646,567; female
786,407) (2001 est.)
Population growth rate: 1.71% (2001 est.)
Birth rate: 24.16 births/1,000 population (2001 est.)
Death rate: 5.94 deaths/1,000 population
(2001 est.)
Net migration rate: -1 .15 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 48.1 1 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.43 years
male: 67.2 years
female: 71 .76 years (2001 est.)
Total fertility rate: 3.05 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.03%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: NA
347
Morocco (continued)
HIV/AIDS -deaths: NA
Nationality:
noun: l\\/loroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99.1%, other 0.7%,
Jewish 0.2%
Reiigions: Muslim 987%, Christian 1.1%, Jewish
0.2%
Languages: Arabic (official), Berber dialects, French
often the language of business, government, and
diplomacy
Literacy:
definition: age 15 and over can read and write
total population: 43.7%
male: 56.6%
female: 3^% {ms est.)','166050b319c0aa4ad994bb88ce552a6ce22f922f82f439ae3d828127dbf1e96d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18ab0d1719eacc60d407acc7f6744346385934f7834c64e7c0d9d2e469ef65a9',2001,'GR','Greece','people-and-society',511,'Population; 10,623,835 (July 2001 est.)
Age structure:
0-14 years: 14.98% (male 820,219; female 771,466)
15-64 years: 67.3% (male 3,580,535; female
3,569,755)
65 years and over: 17.72% (male 834,234; female
1,047,626) (2001 est.)
Population growth rate: 0.21% (2001 est.)
Birth rate: 9.83 births/1,000 population (2001 est.)
Death rate: 9.73 deaths/1,000 population
(2001 est.)
Net migration rate: 1 .96 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 6.38 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.59 years
male: 70.03 years
female: 81.32 years (2001 est.)
Total fertility rate: 1 .33 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1 6%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 8,000
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox 98%, Muslim 1 .3%,
other 0.7%
Languages: Greek 99% (official), English, French
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 98%
fema/e;93%(1991 est.)','b9d47cb851a5ab66fd61863f3d5fe288913a93e8c2f83038bd18748a660afb7d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b59d61e370bd3ea7a60450e255f3a574a5ad3da129dd3703220d25557a5d3a8',2001,'GL','Greenland','people-and-society',519,'Population: 56,352 (July 2001 est.)
Age structure:
0-14 years: 26.69% (male 7,649; female 7,392)
15-64 years: 67.87% (male 20,868; female 17,376)
65 years and over: 5.44% (male 1 ,385; female 1 ,682)
(2001 est.)
Population growth rate: 0.06% (2001 est.)
Birth rate: 16.52 births/1,000 population (2001 est.)
Death rate: 7.58 deaths/1,000 population
(2001 est.)
Net migration rate: -8.38 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: ^.02 male(s)/female
under 15 years: 03 male(s)/female
15-64 years: 1 .2 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1.13 male(s)/female (2001 est.)
Infant mortality rate: 17.77 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.37 years
male: 64.82 years
female: 72.01 years (2001 est.)
Total fertility rate: 2.44 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: 100
(1999)
HIV/AIDS - deaths: NA
199
Greenland (continued)
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 88% (Inuit and
Greenland-born whites), Danish and others 12%
(January 2000)
Religions: Evangelical Lutheran
Languages: Greenlandic (East Inuit), Danish,
English
Literacy:
definition: NA
total population: HA%
male: NA%
female: NA%
note: similar to Denmark proper','5f09a74e6249eeeb7dcc339c84165be1994c0358f89e8a123fb7cfb5a4c5a0f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18f5aeef28b1302b0666eef9c023d7cad77a4eccdf6919f0f4e74004f01816ba',2001,'GD','Grenada','people-and-society',526,'Population: 89,227 (July 2001 est.)
Age structure:
0-/4 years; 37.05% (male 16,739; female 16,318)
15-64 years: 59.03% (male 27,850; female 24,820)
65 years and over: 3.92% (male 1 ,592; female 1 ,908)
(2001 est.)
Population growth rate: -0.06% (2001 est.)
Birth rate: 23.12 births/1,000 population (2001 est.)
Death rate: 7.82 deaths/1,000 population
(2001 est.)
Net migration rate: -15.86 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: ^ male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .07 male(s)/female (2001 est.)
Infant mortality rate: 1 4.63 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 64.52 years
male: 62.74 years
female: 66.31 years (2001 est.)
Total fertility rate; 2.54 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic groups: black 82% some South Asians (East
Indians) and Europeans, trace Arawak/Carib
Amerindian
Religions: Roman Catholic 53%, Anglican 13.8%,
other Protestant 33.2%
Languages: English (official), French patois
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
fema/e;98%(1970 est.)
201
Grenada (continued)
Population: 115,942 (July 2001 est.)
Age structure:
0-14 years; 29.61% (male 17,466; female 16,865)
15-64 years: 64.04% (male 38,074; female 36,179)
65 years and over: 6.35% (male 3,1 62; female 4,1 96)
(2001 est.)
Population growth rate: 0.4% (2001 est.)
Birth rate: 17.91 births/1,000 population (2001 est.)
Death rate: 6.16 deaths/1 ,000 population
(2001 est.)
Net migration rate: -7.72 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1 .03 male(s)/female (2001 est.)
Infant mortality rate: 16.61 deaths/1,000 live births
(2001 est.)
Life expectancy at birth;
total population: 72.56 years
male: 70.83 years
female: 74.34 years (2001 est.)
Total fertility rate: 2.06 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate; NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths; NA
Nationality;
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black 66%, mixed 19%, East Indian
6%, Carib Amerindian 2%
Religions: Anglican 47%, Methodist 28%, Roman
Catholic 13%, Seventh-Day Adventist, Hindu, other
Protestant
Languages: English, French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 96%
male: 96%
fema/e; 96% (1970 est.)','1abbf1d2dd7f29a2cb3915c4b7561d42e74fceb77b5fcbcdfab4a9fade189b6c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b21d692077550cffba82d665f4a1dd891ddff500e9993bccf0acb0a5f1909fe',2001,'GP','Guadeloupe','people-and-society',532,'Population: 431,170 (July 2001 est.)
Age structure:
0‘14 years: 24.99% (male 55,030; female 52,722)
15-64 years: 66.22% (male 141 ,294; female 144,232)
65 years and over: 8.79% (male 1 5,901 ; female
21 ,991) (2001 est.)
Population growth rate: 1 .07% (2001 est.)
Birth rate: 16.91 births/1,000 population (2001 est.)
Death rate: 6.02 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.15 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: OM male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 9.53 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.1 6 years
male: 74.01 years
female: 80.48 years (2001 est.)
Total fertility rate: 1 .93 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%,
East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 4%, Protestant 1%
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 90%
fema/e;90%(1982 est.)','63c4a63ccdfc46f115a9f963eff8295c37cd114369b3be380abd42decb8877a6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b214d84ffa8e37433357d84de8390fdad024f78ad9147260660fd826a35f921',2001,'GU','Guam','people-and-society',537,'Population: 157,557 (July 2001 est.)
Age structure:
0-14 years: 35.07% (male 28,978; female 26,270)
15-64 years: 58.78% (male 48,704; female 43,902)
65 years and over: 6.1 5% (male 4,871 ; female 4,832)
(2001 est.)
Population growth rate: 2.09% (2001 est.)
Birth rate: 25.07 births/1,000 population (2001 est.)
Death rate: 4.2 deaths/1 ,000 population (2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.14 male(s)/female
under 15 years: 1 A male(s)/female
15-64 years: 1M male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1 A male(s)/female (2001 est.)
Infant mortality rate: 6.71 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.94 years
male: 75.66 years
female: 80.55 years (2001 est.)
Total fertility rate: 3.85 children born/woman
(2001 est.)
HIV/AiDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic groups: Chamorro 47%, Filipino 25%, white
10%, Chinese, Japanese, Korean, and other 18%
Religions: Roman Catholic 85%, other 15%
(1999 est.)
Languages: English, Chamorro, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
fema/e; 99% (1990 est.)
205
Guam (continued)','e1ca86777d05a3e55f88d0eaceb35cee00ea60374bb5c2114031c103422ea52b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a781d056000f0f4dbcf9aa68288813369345c22c80fd4bbc11e91d42f483b170',2001,'GT','Guatemala','people-and-society',544,'Population: 12,974,361 (July 2001 est.)
Age structure:
0A4 years: 42.11% (male 2,789,189; female
2,674,747)
15-64 years: 54.25% (male 3,518,209; female
3,519,851)
65 years and over: 3.64% (male 220,640; female
251,725) (2001 est.)
Population growth rate: 2.6% (2001 est.)
Birth rate: 34.61 births/1,000 population (2001 est.)
Death rate: 6.79 deaths/1,000 population
(2001 est.)
Net migration rate: -1 .84 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0,88 male(s)/female
total population: 1 .01 male(s)/female (2001 est.)
Infant mortality rate: 45.79 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 66.51 years
male: 63.85 years
female: 69.31 years (2001 est.)
Total fertility rate: 4.58 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .38%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 73,000
(1999 est.)
HIV/AIDS ■ deaths: 3,600 (1999 est.)
Nationality:
noun: Guatemalan(s)
207
Guatemala (continued)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed Amerindian-Spanish
or assimilated Amerindian - in local Spanish called
Ladino), approximately 55%. Amerindian or
predominantly Amerindian, approximately 43%,
whites and others 2%
Religions: Roman Catholic, Protestant, indigenous
Mayan beliefs
Languages: Spanish 60%, Amerindian languages
40% (more than 20 Amerindian languages, including
Quiche, Cakchiquel, Kekchi, Mam, Garifuna, and
Xinca)
Literacy:
definition: age 15 and over can read and write
total population: S3.6%
male: 68.7%
fema/e; 58.5% (2000 est.)','182898c6a61a98c349ccee9e2f78482e4686dc9f1bb0b5e4c5ca69d01553eef9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85aef6d9675978d5c47a725ef6a2c401e50c1cb911e5d2f509039ac7b4aa3d6f',2001,'GG','Guernsey','people-and-society',552,'Population: 64,342 (July 2001 est.)
Age structure:
0-14 years: 16.22% (male 5,285; female 5,151)
15-64 years: 66.67% (male 21 ,264; female 21 ,630)
65 years and over: 17.11% (male 4,546; female
6,466) (2001 est.)
Population growth rate: 0.39% (2001 est.)
Birth rate: 9.9 births/1 ,000 population (2001 est.)
Death rate: 9.87 deaths/1 ,000 population
(2001 est.)
Net migration rate: 3.89 migrant{s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 5 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.78 years
male: 76.78 years
female: 82.88 years (2001 est.)
Total fertility rate: 1 .36 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HlV/AiDS- deaths: NA
Nationality:
noun: Channel islander{s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian,
Baptist, Congregational, Methodist
Languages: English, French, Norman-French
dialect spoken in country districts
Literacy:
definition: NA
total population: N A%
male: NA%
female: NA%','56084368d83a894b79cf3271bb8e7f252106771c5ce9be4b5d0d6cfe58ccf500','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d011a988aa277d8929dff2b36fcf92876cee4a86c8a2e78b4a8c088b7912a0e3',2001,'GW','Guinea-Bissau','people-and-society',561,'Population: 1,315,822 (July 2001 est.)
Age structure:
0-14 years: 42m% (male 276,312; female 277,536)
15-64 years: 55.05% (male 344,493; female 379,889)
65 years and over: 2.86% (male 1 6,850; female
20,742) (2001 est.)
Population growth rate: 2.23% (2001 est.)
Birth rate: 39.29 births/1,000 population (2001 est.)
Death rate: 15.33 deaths/1 ,000 population
(2001 est.)
Net migration rate: -1 .66 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.91 male{s)/female
65 years and over; 0.81 male(s)/female
total population: 0.94 male(s)/female (2001 est.)
Infant mortality rate: 1 10.4 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 49.42 years
ma/e; 47.12 years
female: 51 .78 years (2001 est.)
Total fertility rate: 5.2 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.5% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS - deaths: 1 ,300 (1 999 est.)
Nationality:
noun: Guinean (s)
adjective: Guinean
Ethnic groups: African 99% (Balanta 30%, Fula
20%, Manjaca 14%, Mandinga 13%, Papel 7%),
European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%,
Christian 5%
Languages: Portuguese (official), Crioulo, African
languages
Literacy:
definition: age 15 and over can read and write
total population: 53.9%
male: 07.1%
female: 40.7% [1997 est.)','5e5027accd4f507c7a4b56a01b68325e9cf81e2d99af22af0fa680335c757faf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66f5d96923d241440fe6499b185e418fb8950ecc48af61dd7317203ff4c80978',2001,'HK','Hong Kong','people-and-society',573,'Population: 7,210,505 (July 2001 est.)
Age structure:
0^14 years: 17.73% (male 677,785; female 600,781 )
15-64 years: 71 .52% (male 2,554,329; female
2,602,662)
65 years and over: 10.75% (male 354,199; female
420,749) (2001 est.)
Population growth rate: 1.3% (2001 est.)
Birthrate: 11.13 births/1,000 population (2001 est.)
Death rate: 6.02 deaths/1,000 population
(2001 est.)
Net migration rate: 7.9 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .13 male(s)/fema!e
15-64 years: 0.98 ma!e(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 5.83 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.67 years
male: 76.97 years
female: 82.55 years (2001 est.)
Total fertility rate: 1.29 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.06%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 2,500
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%,
Christian 10%
Languages: Chinese (Cantonese), English; both are
official
Literacy:
definition: age 15 and over has ever attended school
total population: 92.2%
male: 96%
fema/e; 88.2% (1996 est.)','4a0242f0378e9ff7c74614345041064cd6af2d991d969d18cdb4fa7801becbc5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e449bb041fb2a6892ba2c23b673be115acfd752cbd35643233a1ad970b65d4d4',2001,'HU','Hungary','people-and-society',581,'Population: 10,106,017 (July 2001 est.)
Age structure;
0-14 years: ^b.63% (male 862,468; female 818,052)
15-64 years: bQM% (male 3,406,717; female
3,532,008)
65 years and over: 14.71% (male 546,992; female
939,780) (2001 est.)
Population growth rate: -0.32% (2001 est.)
Birth rate: 9.32 births/1,000 population (2001 est.)
Death rate: 13.21 deaths/1 ,000 population
(2001 est.)
228
Hungary (continued)
Net migration rate: 0.74 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 07 male{s)/female
under 15 years: 1 .05 male(s)/fenriale
15-64 years: 0.96 male(s)/female
65 years and over: 0.58 male(s)/female
total population: 0.91 male(s)/female (2001 est.)
Infant mortality rate: 8.96 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .63 years
male: 67.28 years
female: 76.3 years (2001 est.)
Total fertility rate: 1 .25 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,500
(1999 est.)
HIV/AIDS - death§: less than 100 (1999 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 89.9%, Roma 4%,
German 2.6%, Serb 2%, Slovak 0.8%, Romanian
0.7%
Religions: Roman Catholic 67.5%, Calvinist 20%,
Lutheran 5%, atheist and other 7.5%
Languages: Hungarian 98.2%, other 1.8%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1980 est.)
Goverfimen!
Country name:
conventional long form: Republic of Hungary
conventional short form: Hungary
local long form: Magyar Koztarsasag
local short form: Magyarorszag
Government type: parliamentary democracy
Capital: Budapest
Administrative divisions: 19 counties (megyek,
singular - megye), 20 urban counties* (singular -
megyei varos), and 1 capital city** (fovaros);
Bacs-Kiskun, Baranya, Bekes, Bekescsaba*,
Borsod-Abauj-Zemplen, Budapest**, Csongrad,
Debrecen*, Dunaujvaros*, Eger*, Fejer, Gyor*,
Gyor-Moson-Sopron, Hajdu-Bihar, Heves,
Hodmezovasarhely*, Jasz-Nagykun-Szolnok,
Kaposvar*, Kecskemet*, Komarom-Esztergom,
Miskolc*, Nagykanizsa*, Nograd, Nyiregyhaza*,
Pecs*, Pest, Somogy, Sopron*,
Szabolcs-Szatmar-Bereg, Szeged*,
Szekesfehervar*, Szoinok*, Szombathely*,
Tatabanya*, Tolna, Vas, Veszprem, Veszprem*,
Zala, Zalaegerszeg*
Independence: 1001 (unification by King Stephen I)
National holiday: St. Stephen''s Day, 20 August
Constitution: 18 August 1949, effective 20 August
1 949, revised 1 9 April 1 972; 1 8 October 1 989 revision
ensured legal rights for individuals and constitutional
checks on the authority of the prime minister and also
established the principle of parliamentary oversight:
1997 amendment streamlined the judicial system
Legal system: rule of law based on Western model
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Ferenc MADL (since NA August 2000)
head of government: Prime Minister Viktor ORBAN
(since 6 July 1998)
cabinet: Council of Ministers elected by the National
Assembly on the recommendation of the president
elections: president elected by the National Assembly
for a five-year term; election last held 6 June 2000
(next to be held by June 2005); prime minister elected
by the National Assembly on the recommendation of
the president
election results: Ferenc MADL elected president;
percent of legislative vote - NA% (but by a simple
majority in the third round of voting); Viktor ORBAN
elected prime minister; percent of legislative vote -
NA%
note: to be elected, the president must win two-thirds
of legislative vote in the first two rounds or a simple
majority in the third round
Legislative branch: unicameral National Assembly
or Orszaggyules (386 seats; members are elected by
popular vote under a system of proportional and direct
representation to serve four-year terms)
elections: last held on 1 0 and 24 May 1 998 (next to be
held May/June 2002)
election results: percent of vote by party (5% or more
of the vote required for parliamentary representation
in the first round) - MSZP 32.0%, FIDESZ 28.2%,
FKGP 13.8%, SZDSZ 7.9%, MIEP 5.5%, MMP 4.1%,
MDF 2.8%, KDNP 2.3%, MDNP 1 .5%; seats by party -
MSZP 134, FIDESZ 148, FKGP 48, SZDSZ 24, MDF
17, MIEP 1 4, independent 1 ; note - seating as of 2000
by party - MSZP 1 36, FIDESZ 1 41 , FKGP 48, SZDSZ
24, MDF 16, MIEP 12, independents 9
Judicial branch: Constitutional Court (judges are
elected by the National Assembly for nine-year terms)
Political parties and leaders: Alliance of Free
Democrats or SZDSZ [Gabor DEMSZKYj; Christian
Democratic People''s Party or KDNP [Gyorgy GICZY,
president]; Federation of Young
Democrats-Hungarian Civic Party or FYD-HCP
[Laszio KOVER]: note - used to be Hungarian Civic
Party or FIDESZ; Hungarian Democratic Forum or
MDF [Iboiya DAVID]; Hungarian Democratic People''s
Party or MDNP [Erzsebet PUSZTAI, chairman];
Hungarian Justice and Life Party or MIEP [Istvan
CSURKA, chairman]; Hungarian Socialist Party or
MSZP [Laszio KOVACS, chairman]; Hungarian
Workers'' Party or MMP [Gyula THURMER, chairman];
independent Smallholders or FKGP [Jozsef
TORGYAN, president]
Political pressure groups and leaders: NA
International organization participation: ABEDA,
Australia Group, BIS, CCC, CE, CEI, CERN, EAPC,
EBRD, ECE, EU (applicant), FAO, G- 9, IAEA, IBRD,
ICAO, ICC, ICFTU, iCRM, IDA, lEA, IFC, IFRCS, ILO,
IMF. IMO, Inmarsat. Intelsat, Interpol, IOC, iOM, ISO,
ITU, MINURSO. NAM (guest), NATO, NEA, NSG,
OAS (observer), OECD, OPCW, OSCE, PCA, PFP,
UN, UNCTAD, UNESCO, UNFICYP, UNHCR,
UNIDO, UNIKOM, UNMIBH, UNMIK, UNMOGIP,
UNOMIG, UNU, UPU, WCL, WEU (associate),
WFTU, WHO, WlPO, WMO, WToO, WTrO, ZC
Diplomatic representation in the US;
chief of mission: Ambassador Geza JESZENSZKY
chancery: 3910 Shoemaker Street NW, Washington,
DC 20008
telephone: [1] (202) 362-6730
FAX:[\\] (202) 966-8135
consulate(s) general: Los Angeles and New York
Diplomatic representation from the US:
chief of mission: Ambassador Peter F. TUFO
embassy: Szabadsag Ter 12, H.-1054 Budapest
mailing address: pouch: American Embassy
Budapest, 5270 Budapest Place, Department of
State, Washington, DC 20521-5270
telephone: [36] (1) 475-4400, 475-4703 (after hours)
FAX;[36] (1)475-4764
Flag description: three equal horizontal bands of
red (top), white, and green
Economy - overview: Hungary continues to
demonstrate strong economic growth and to work
toward accession to the European Union. The private
sector accounts for over 80% of GDP. Foreign
ownership of and investment In Hungarian firms is
widespread, with cumulative foreign direct investment
totaling $23 billion by 2000. Hungarian sovereign debt
was upgraded in 2000 to the second-highest rating
among all the Central European transition economies.
Inflation - a top economic concern in 2000 - Is still high
at almost 1 0%, pushed upward by higher world oil and
gas and domestic food prices. Economic reform
measures such as health care reform, tax reform, and
local government financing have not yet been
addressed by the ORBAN government.
GDP: purchasing power parity - $1 1 3.9 billion
(2000 est.)
GDP - real growth rate: 5.5% (2000 est.)
GDP - per capita: purchasing power parity -
$11,200 (2000 est.)
GDP - composition by sector:
agriculture: 5%
industry: 35%
services: 60% (2000 est.)
Population below poverty line: 8.6% (1993 est.)
Household Income or consumption by percentage
share:
lowest 10%: 3.9%
highest 10%; 24.8% (1996)
Inflation rate (consumer prices): 9.8% (1999 est.)
Labor force: 4.2 million (1997)
229
Hungsry (continued)
Labor force - by occupation; services 65%,
industry 27%, agriculture 8% (1996)
Unemployment rate: 9.4% (2000 est.)
Budget;
revef?ues; $13 billion
expenditures: A billion, including capital
expenditures of SNA (2000 est.)
Industries: mining, metallurgy, construction
materials, processed foods, textiles, chemicals
(especially pharmaceuticals), motor vehicles
Industrial production growth rate; 18%
(2000 est.)
Electricity - production; 36.75 billion kWh (1999)
Electricity - production by source;
fossil fuel: 61 .09%
hydro: 0.51 %
nuclear: 38.4%
other; 0% (1999)
Electricity - consumption: 35.234 billion kWh
(1999)
Electricity - exports; 2.35 billion kWh (1999)
Electricity - imports: 3.406 billion kWh (1999)
Agriculture - products: wheat, corn, sunflower
seed, potatoes, sugar beets; pigs, cattle, poultry, dairy
products
Exports: $25.2 billion (f.o.b., 2000)
Exports - commodities; machinery and equipment
59.5%, other manufactures 29.4%, food products
6.9%, raw materials 2.4%, fuels and electricity 1 .8%
(2000)
Exports - partners: Germany 37%, Austria 9%, Italy
6%, Netherlands 5% (2000)
Imports: $27.6 billion (f.o.b., 2000)
Imports - commodities: machinery and equipment
51.1%, other manufactures 35.9%, fuels and
electricity 8.1%, food products 2.8%, raw materials
2.1% (2000)
Imports - partners: Germany 25%, Russia 8%,
Austria 7%, Italy 7% (2000)
Debt - external: $29.6 billion (2000)
Economic aid - recipient: $122.7 million (1995)
Currency: forint (HUF)
Currency code: HUF
Exchange rates: forints per US dollar - 282.240
(January 2001), 282.179 (2000), 237.146 (1999),
214.402 (1998), 186.789 (1997), 152.647 (1996)
Fiscal year: calendar year
C o fii m u n f c a t i o n a
Telephones - main lines in use: 3.095 million
(1997)
Telephones - mobile cellular: 1 .269 million (July
1999)
Telephone system:
general assessment: the telephone system has been
modernized and is capable of satisfying all requests
for telecommunication service
domestic: the system is digitalized and highly
automated; trunk services are carried by fiber-optic
cable and digital microwave radio relay; a program for
fiber-optic subscriber connections was initiated in
1996; heavy use is made of mobile cellular telephones
international: Hungary has fiber-optic cable
connections with all neighboring countries; the
international switch is in Budapest; satellite earth
stations - 2 Intelsat (Atlantic Ocean and Indian Ocean
regions), 1 Inmarsat, 1 very small aperture terminal
(VSAT) system of ground terminals
Radio broadcast stations: AM 17, FM 57,
shortwave 3 (1998)
Radios: 7.01 million (1997)
Television broadcast stations: 35 (plus 161
low-power repeaters) (1995)
Televisions: 4.42 million (1997)
Internet country code: hu
Internet Service Providers (ISPs): 16 (2000)
Internet users: 650,000 (2000)
Railways:
fofa/; 7,606 km
broad gauge: 36 km 1 .524-m gauge
standard gauge: 7,394 km 1 .435-m gauge (2,270 km
electrified; 1 ,236 km double track)
narrow gauge: 176 km 0.760-m gauge (1998)
note: Hungary and Austria jointly manage the
cross-border standard-gauge railway connecting
Gyor, Sopron, and Ebenfurt (Gysev railroad) a
distance of about 101 km in Hungary and 65 km in
Population: 5,414,937 (July 2001 est.)
Age structure:
0-14 years: 18.86% (male 522,563; female 498,832)
15-64 years: 69.6% (male 1,872,496; female
1,896,249)
65 years and over: 1 1 .54% (male 236,996; female
387,801) (2001 est.)
Population growth rate: 0.13% (2001 est.)
Birth rate: 10.05 births/1,000 population (2001 est.)
Death rate: 9.25 deaths/1,000 population
(2001 est.)
Net migration rate: 0.53 migrant(s)/1,000
population (2001 est.)
Slovakia (continued)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 05 male(s)/female
15-64 years: 0.99 male(s)/femaie
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 8.97 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.97 years
male: 69.95 years
female: 78.2 years (2001 est.)
Total fertility rate: 1 .25 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HiV/AIDS: 400
(1999 est.)
HiV/AiDS ■ deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.7%, Hungarian 10.6%,
Roma 1 .6% (the 1 992 census figures underreport the
Gypsy/Romany community, which is about 500,000),
Czech, Moravian, Silesian 1.1%, Ruthenian and
Ukrainian 0.6%, German 0.1%, Polish 0.1%, other
0.2% (1996)
Religions: Roman Catholic 60.3%, atheist 9.7%,
Protestant 8.4%, Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy:
definition: NA
total population: Hk%
male: NA%
female: NA%','92d6915f7e3ab4c7d3eb32aa862e78341527286b3ab1a0a6d518e9b67528b9ad','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dcf33839753b08af103e0243dc6a021c61d436b277c74b18fd417f1085ac5fe',2001,'AT','Austria','people-and-society',582,'Highways:
total: 188,203 km
paved: 81 ,680 km (including 448 km of expressways)
unpaved: 106,523 km (1998 est.)
Waterways: 1,373 km (permanently navigable)
(1997)
Pipelines: crude oil 1 ,204 km; natural gas 4,387 km
(1991)
Ports and harbors: Budapest, Dunaujvaros
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,1 99 GRT/
1,050 DWT
ships by type: cargo 1 (2000 est.)
Airports: 43 (2000 est.)
Airports - with paved runways:
total:
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m:^ (2000 est.)
Airports - with unpaved runways:
total: 27
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m-A2
under 914 m: 8 (2000 est.)
Heliports: 5 (2000 est.)
Military branches: Ground Forces, Air Force; note -
there is a paramilitary Border Guard which is under
the Ministry of Interior
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49:2,573,119(2001 est.)
Military manpower - fit for military service;
males age /5-49; 2,050,404 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 64,121 (2001 est.)
Military expenditures - dollar figure: $822 million ^
(FYOO)
Military expenditures - percent of GDP: 1 .6%
(FYOO)
Disputes - International: Gabcikovo/Nagymaros
Dam dispute with Slovakia is before the ICJ
Illicit drugs: major transshipment point for
Southwest Asian heroin and cannabis and transit
point for South American cocaine destined for
Western Europe; limited producer of precursor
chemicals, particularly for amphetamine and
methamphetamine
230
IceM
Introduetljgn
Background: Settled by Norwegian and Celtic
(Scottish and Irish) immigrants during the late 9th and
10th centuries A.D., Iceland boasts the world''s oldest
functioning legislative assembly, the Althing,
established in 930. Independent for over 300 years,
Iceland was subsequently ruled by Norway and
Denmark. Fallout from the Askja volcano of 1875
devastated the Icelandic economy and caused
widespread famine. Over the next quarter century,
20% of the island''s population emigrated, mostly to
Canada and the US. Limited home rule from Denmark
was granted in 1874 and complete independence
attained In 1944. Literacy, longevity, income, and
social cohesion are first-rate by world standards.
Population: 1,029,991,145 (July 2001 est.)
Age structure:
0-M years; 33.12% (male 175,630,537; female
165,540,672)
15-64 years: 62.2% (male 331 ,790,850; female
308,902,864)
65 years and over: 4.68% (male 24,439,022; female
23,687,200) (2001 est.)
Population growth rate: 1.55% (2001 est.)
Birth rate: 24.28 births/1,000 population (2001 est.)
Death rate: 8.74 deaths/1 ,000 population
(2001 est.)
233
India (continued)
Net migration rate: -0.08 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 05 male (s)/fe male
under 15 years: 1 .06 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1 .07 male(s)/female (2001 est.)
Infant mortality rate: 63.19 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 62.86 years
male: 62.22 years
female: 63.53 years (2001 est.)
Total fertility rate: 3.04 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.7% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 3.7
million (1999 est.)
HIV/AIDS ■ deaths: 310,000 (1999 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%,
Mongoloid and other 3% (2000)
Religions: Hindu 81.3%, Muslim 12%, Christian
2.3%, Sikh 1 .9%, other groups including Buddhist,
Jain, Parsi 2.5% (2000)
Languages: English enjoys associate status but is
the most important language for national, political, and
commercial communication, Hindi the national
language and primary tongue of 30% of the people,
Bengali (official), Telugu (official), Marathi (official),
Tamil (official), Urdu (official), Gujarati (official),
Malayalam (official), Kannada (official), Oriya
(official), Punjabi (official), Assamese (official),
Kashmiri (official), Sindhi (official), Sanskrit (official),
Hindustani (a popular variant of Hindi/Urdu spoken
widely throughout northern India)
note: 24 languages each spoken by a million or more
persons; numerous other languages and dialects, for
the most part mutually unintelligible
Literacy:
definition: age 15 and over can read and write
total population: 52%
male: 65.5%
fema/e.’ 37.7% (1995 est.)
Population: 228,437,870 (July 2001 est.)
Age structure:
0-14 years: 30.26% (male 35,144,702; female
33,973,879)
15-64 years: Q5M% (male 74,273,519; female
74,458,291)
65 years and over: 4.63% (male 4,641 ,816; female
5,945,663) (2001 est.)
Population growth rate: 1.6% (2001 est.)
Birth rate: 22.26 births/1 ,000 population (2001 est.)
Death rate: 6.3 deaths/1,000 population (2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 40.91 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 6S27 years
male: 65.9 years
female: 70.75 years (2001 est.)
Total fertility rate: 2.58 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 52,000
(1999 est.)
HIV/AIDS -deaths: 3,100 (1999 est.)
Nationality:
noun: Indonesian(s)
adjective: Indonesian
Ethnic groups: Javanese 45%, Sundanese 14%,
Madurese 7.5%, coastal Malays 7.5%, other 26%
Religions: Muslim 88%, Protestant 5%, Roman
Catholic 3%, Hindu 2%, Buddhist 1 %, other 1 % ( 1 998)
Languages: Bahasa Indonesia (official, modified
form of Malay), English, Dutch, local dialects, the most
widely spoken of which Is Javanese
Literacy:
definition: age 15 and over can read and write
total population: 83.8%
male: 89.6%
fema/e;78%(1995 est.)
■ , : I ■
Country name:
conventional long form: Republic of Indonesia
conventional short form: Indonesia
local long form: Republik Indonesia
local short form: Indonesia
former: Netherlands East Indies; Dutch East Indies
Government type: republic
Capital: Jakarta
Administrative divisions: 27 provinces
(propinsi-propinsi, singular - propinsi), 2 special
regions* (daerah-daerah Istimewa, singular - daerah
istimewa), and 1 special capital city district** (daerah
khusus ibukota); Aceh*, Bali, Banten, Bengkulu,
Gorontalo, Irian Jaya, Jakarta Raya**, Jambi, Jawa
Barat, Jawa Tengah, Jawa Timur, Kalimantan Barat,
Kalimantan Selatan, Kalimantan Tengah, Kalimantan
Timur, Kepulauan Bangka Belitung, Lampung,
Maluku, Maluku Utara, Nusa Tenggara Barat, Nusa
Tenggara Timur, Riau, Sulawesi Selatan, Sulawesi
Tengah, Sulawesi Tenggara, Sulawesi Utara,
Sumatera Barat, Sumatera Selatan, Sumatera Utara,
237
IndonGSia (continued)
Yogyakarta*; note - the province of Irian Jaya may
have been divided into two new provinces - Central
Irian Jaya and West Irian Jaya; with the
implementation of decentralization on 1 January
2001, the 357 districts (regencies) may become the
key administrative units
note: following the 30 August 1999 provincial
referendum for independence which was
overwhelmingly approved by the people of Timor Timur
and the October 1999 concurrence of Indonesia''s
national legislature, the name East Timor was adopted
as a provisional name for the political entity formerly
known as Propinsi Timor Timur; East Timor is under
UN administration pending its formal independence
Independence: 1 7 August 1 945 (proclaimed
independence; on 27 December 1949, Indonesia
became legally independent from the Netherlands)
National holiday: Independence Day, 17 August
(1945)
Constitution: August 1945, abrogated by Federal
Constitution of 1949 and Provisional Constitution of
1950, restored 5 July 1959
Legal system: based on Roman-Dutch law,
substantially modified by indigenous concepts and by
new criminal procedures code; has not accepted
compulsory ICJ jurisdiction
Suffrage: 17 years of age; universal and married
persons regardless of age
Executive branch:
chief of state: President Abdurrahman WAHID (since
20 October 1999) and Vice President MEGAWATI
Sukarnoputri (since 21 October 1999); note - the
president is both the chief of state and head of
Population: 66,128,965 (July 2001 est.)
Age structure:
0-14 years: 32.97% (male 1 1 ,150,053; female
10,654,884)
15-64 years: 62.38% (male 20,765,001 ; female
20,488,672)
65 years and over: 4.65% (male 1 ,617,045; female
1,453,310) (2001 est.)
Population growth rate: 0.72% (2001 est.)
Birth rate: 17.1 births/1,000 population (2001 est.)
Death rate: 5.41 deaths/1 ,000 population
(2001 est.)
Net migration rate: -4.51 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
/5-64 years; 1.01 male(s)/femaie
65 years and over: 1.11 male(s)/female
total population: 03 male(s)/female (2001 est.)
Infant mortality rate: 29.04 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.95 years
male: 68.61 years
female: 71 .37 years (2001 est.)
Total fertility rate: 2.02 children born/woman
(2001 est.)
HIV/AIDS " adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azeri 24%, Gilaki and
Mazandarani 8%, Kurd 7%, Arab 3%, Lur 2%, Baloch
2%, Turkmen 2%, other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%,
Zoroastrian, Jewish, Christian, and Baha''i 1%
Languages: Persian and Persian dialects 58%,
Turkic and Turkic dialects 26%, Kurdish 9%, Luri 2%,
Balochi 1%, Arabic 1%, Turkish 1%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 72.1%
male: 78.4%
female: 65.8% (1994 est.)
Population: 23,331,985 (July 2001 est.)
Age structure:
0-14 years: 41 .64% (male 4,934,340; female
4,781,206)
15-64 years: 55.28% (male 6,528,854; female
6,368,823)
65 years and over: 3.08% (male 335,953; female
382,809) (2001 est.)
Population growth rate: 2.84% (2001 est.)
Birth rate: 34.64 births/1,000 population (2001 est.)
Death rate: 6.21 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 .02 male(s)/female (2001 est.)
242
Iraq (continued)
Infant mortality rate: 60.05 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 66.95 years
male: 65.92 years
female: 68.03 years (2001 est.)
Total fertility rate: 4.75 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HlV/AIDS - people living with HIV/AlDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 15%-20%,
Turkoman, Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%"65%, Sunni
32%-37%), Christian or other 3%
Languages: Arabic, Kurdish (official in Kurdish
regions), Assyrian, Armenian
Literacy:
definition: age 15 and over can read and write
total population: 5Q%
male: 70.7%
female: 45% (1995 est.)','dc05e3adcc82cbb9a77636ae6cd5f4c71118b6604e7ba55bc80596d84a26a3ab','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f99a50902fd6004bad580db4b07c17d85a72ea0ff1f8585afa564145364baa99',2001,'IE','Ireland','people-and-society',593,'Population: 3,840,838 (July 2001 est.)
Age structure:
0-14 years: 21.57% (male 425,328; female 403,204)
15-64 years: 67.08% (male 1 ,290,002; female
1,286,312)
65 years and over: 1 1 .35% (male 1 88,868; female
247,124) (2001 est.)
Population growth rate: 1.12% (2001 est.)
Birth rate: 14.57 births/1,000 population (2001 est.)
Death rate: 8.07 deaths/1 ,000 population
(2001 est.)
Net migration rate: 4.69 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 5.53 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.99 years
male: 74.23 years
female: 79.93 years (2001 est.)
Totai fertility rate; 1 .9 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,200
(1999 est.)
HIV/AIDS - deaths; less than 100 (1999 est.)
Nationality;
noun; Irishman(men), Irishwoman(women), Irish
(collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 91 .6%, Church of Ireland
2.5%, other 5.9% (1998)
Languages: English is the language generally used,
Irish (Gaelic) spoken mainly in areas located along the
western seaboard
Literacy:
definition: age 1 5 and over can read and write
fofa/popL//af/on;98% (1981 est.)
male: NA%
female: NA%','27addd039600188c91c2428d1a3828ad879857006154cbe7f6abdcb2dafa15e5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53ce156eb3b66814a9d40a9de9e285b4f86eeefc8ac7205fbc9be5f489db6b56',2001,'IL','Israel','people-and-society',601,'Population: 5,938,093 (July 2001 est.)
note: includes about 176,000 Israeli settlers in the
West Bank, about 20,000 In the Israeli-occupied
Golan Heights, about 6,900 in the Gaza Strip, and
about 173,000 in East Jerusalem (August 2000 est.)
247
Isra©! (continued)
Age structure;
0-14 years: 27.36% (male 831,523; female 792,982)
15-64 years: 6273% (male 1 ,869, 114; female
1,855,707)
65 years and over: 9.91% (male 253,105; female
335,662) (2001 est.)
Population growth rate: 1.58% (2001 est.)
Birth rate: 19.12 births/1,000 population (2001 est.)
Death rate: 6.22 deaths/1,000 population
(2001 est.)
Net migration rate: 2.85 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.75 male(s)/female
totai population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 7.72 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 76.71 years
male: 76.69 years
female: 80.84 years (2001 est.)
Total fertility rate: 2.57 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,400
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 80.1% (Europe/
America-born 32.1%, israel-born 20.8%, Africa-born
14.6%, Asia-born 12.6%), non-Jewish 19.9% (mostly
Arab) (1996 est.)
Religions: Jewish 80.1%, Muslim 14.6% (mostly
Sunni Muslim), Christian 2.1 %, other 3.2% (1 996 est.)
Languages: Hebrew (official), Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy;
definition: age 15 and over can read and write
total population: 95%
male: 97%
fema/e;93%(1992 est.)','1d943616878a1d8c8f26173dd5885589d7b9e08eeb29f4b39f002c5640f97b8b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c8622392ce71f0f067167891d27212ff841294729ac2af5f8aaf8be9d1bdbb9',2001,'TN','Tunisia','people-and-society',609,'Population: 57,679,825 (July 2001 est.)
Age structure:
0-14 years: 14.17% (male 4,209,102; female
3,964,765)
15-64 years: 67.48% (male 1 9,375,742; female
19,546,332)
65 years and over: 13.35% (male 4,368,264; female
6,215,620) (2001 est.)
Population growth rate: 0.07% (2001 est.)
Birth rate: 9.05 births/1,000 population (2001 est.)
Death rate: 10.07 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1 .73 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.94 male(s)/female (2001 est.)
Infant mortality rate: 5.84 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.14 years
male: 75.97 years
female: 82.52 years (2001 est.)
Total fertility rate: 1.18 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate; 0.35%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 95,000
(1999 est.)
HIV/AIDS - deaths: 1 ,000 (1 999 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Italian (includes small clusters of
German-, French-, and Slovene-ltalians in the north
and Albanian-ltalians and Greek-ltalians in the south)
Religions: predominately Roman Catholic with
mature Protestant and Jewish communities and a
growing Muslim immigrant community
Languages: Italian (official), German (parts of
Trentino-Alto Adige region are predominantly German
speaking), French (small French-speaking minority in
Valle d''Aosta region), Slovene (Slovene-speaking
minority in the Trieste-Gorizia area)
Literacy:
definition: age 1 5 and over can read and write
total population: 98% (1 998)
male: NA%
female: NA%
Population: 9,705,102 (July 2001 est.)
Age structure:
0-14 years: 28.74% (male 1,440,636; female
1,348,133)
15-64 years: 65.12% (male 3,157,988; female
3,161,596)
65 years and over: 6.14% (male 296,930; female
299,819) (2001 est.)
Population growth rate: 1.15% (2001 est.)
Birthrate: 17.11 births/1,000 population (2001 est.)
Death rate: 4.99 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.67 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .02 male(s)/female (2001 est.)
Infant mortality rate: 29.04 deaths/1,000 live births
(2001 est.)
Lite expectancy at birth:
total population: 73.92 years
male: 72.35 years
female: 75.62 years (2001 est.)
Total fertility rate: 1 .99 children born/woman
(2001 est.)
HIV/AIDS “ adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun.- Tunisian(s)
ad/ecf/Ve.- Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish
and other 1%
Religions: Muslim 98%, Christian 1%, Jewish and
other 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
Literacy:
definition: age 15 and over can read and write
total population: 66.7%
male: 78.6%
fema/e.’ 54.6% (1995 est.)
Population; 66,493,970 (July 2001 est.)
Age structure:
0-14 years: 28.42% (male 9,620,291 ; female
9,276,347)
15-64 years: 65.45% (male 22,1 1 6,599; female
21,401,165)
65 years and over: 6.1 3% (male 1 ,878,571 ; female
2,200,997) (2001 est.)
Population growth rate: 1 .24% (2001 est.)
Birth rate; 18.31 births/1,000 population (2001 est.)
Death rate: 5.95 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 47.34 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .24 years
male: 68.89 years
female: 73.7^ years (2001 est.)
Total fertility rate: 2.12 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
r?oun;Turk(s)
acf/ecf/Ve; Turkish
Ethnic groups: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2%
(Christian and Jews)
Languages: Turkish (official), Kurdish, Arabic,
Armenian, Greek
Literacy:
definition: age 15 and over can read and write
total population: 65%
male: 94%
female: 77% (2000)
Population: 4,603,244 (July 2001 est.)
Age structure:
0-/4 years: 37.88% (male 891 ,758; female 852,104)
15-64 years: 58.09% (male 1 ,313,303; female
1,360,690)
65 years and over: 4.03% (male 70,800; female
114,589) (2001 est.)
Population growth rate: 1 .85% (2001 est.)
Birth rate: 28.55 births/1 ,000 population (2001 est.)
Death rate: 8.98 deaths/1 ,000 population
(2001 est.)
Net migration rate: -1 .04 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 73.25 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 61 years
male: 57.43 years
female: 64.76 years (2001 est.)
Total fertility rate: 3.58 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 77%, Uzbek 9.2%,
Russian 6.7%, Kazakh 2%, other 5.1% (1995)
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Languages: Turkmen 72%, Russian 12%, Uzbek
9%, other 7%
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 18,122 (July 2001 est.)
Age structure:
0-14 years: 32.58% (male 2,996; female 2,908)
15-64 years: 63.51% (male 6,050; female 5,459)
65 years and over: 3,91% (male 316; female 393)
(2001 est.)
Population growth rate: 3.41% (2001 est.)
Birth rate: 24.89 births/1,000 population (2001 est.)
Death rate: 4.47 deaths/1,000 population
(2001 est.)
Net migration rate: 1 3.69 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 maie(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .1 1 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 .07 male(s)/female (2001 est.)
Infant mortality rate: 1 8.06 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73,52 years
male: 71 .37 years
female: 75.77 years (2001 est.)
Total fertility rate: 3.22 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: none
adjective: none
Ethnic groups: black
Religions: Baptist 41.2%, Methodist 18.9%,
Anglican 18.3%, Seventh-Day Adventist 1 .7%, other
19.9% (1980)
Languages; English (official)
Literacy:
definition: age 15 and over has ever attended school
total population: 98%
male: 99%
fema/e; 98% (1970 est.)','2da29993a4763a3ed1d5e65e399cdae3157f9f45b150a066430e8e9dbe6e8945','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fa51b22a426b0ec7dc3db25d71498cfc0db2d0052bc20eba2c523105c74751f',2001,'JM','Jamaica','people-and-society',618,'Population: 2,665,636 (July 2001 est.)
Age structure:
0-14 years: 297% (male 405,189; female 386,555)
15-64 years: 63.52% (male 845,226; female 847,944)
65 years and over: 6.78% (male 80,667; female
100,055) (2001 est.)
Population growth rate: 0.51% (2001 est.)
Birth rate: 18.12 births/1,000 population (2001 est.)
Death rate: 5.48 deaths/1 ,000 population (2001 est.)
Net migration rate: -7.52 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1,05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 14.16 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.42 years
male: 73.45 years
female: 77.49 years (2001 est.)
Total fertility rate: 2.08 children born/woman
(2001 est.)
HiV/AIDS - adult prevalence rate: 0.71 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 9,900
(1999 est.)
HIV/AIDS -deaths: 650 (1999 est.)
Nationality:
noun: Jamaican(s)
adjective: Jamaican
Ethnic groups: black 90.9%, East Indian 1.3%,
white 0.2%, Chinese 0.2%, mixed 7.3%, other 0.1%
Religions: Protestant 61 .3% (Church of God 21 .2%,
Baptist 8.8%, Anglican 5.5%, Seventh-Day Adventist
9%, Pentecostal 7.6%, Methodist 2.7%, United
Church 2.7%, Brethren 1.1%, Jehovah''s Witness
1 .6%, Moravian 1 .1%), Roman Catholic 4%, other,
including some spiritual cults 34.7%
Languages: English, Creole
Literacy:
definition: age 15 and over has ever attended school
total population: 85%
male: 80.8%
fema/e; 89.1% (1995 est.)
Population: no indigenous inhabitants
note: there are personnel who operate the Long
Range Navigation (Loran-C) base and the weather
and coastal services radio station (July 2001 est.)','97ca02cac06dde34687b06361258fcbc83a5b59a317428696ba08133abddb780','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0e3f90bf491872d4a770f59fb20a952ca6f1dbebbe7a8b868dc403912465823',2001,'NO','Norway','people-and-society',630,'Population: 126,771,662 (July 2001 est.)
Age structure:
0-14 years: H.64% (male 9,510,296; female
9,043,074)
15-64 years: 67.83% (male 43,202,513; female
42,790,187)
65 years and over: 17.53% (male 9,351 ,340; female
12,874,252) (2001 est.)
Population growth rate: 0.17% (2001 est.)
Birth rate: 10.04 births/1,000 population (2001 est.)
Death rate: 8.34 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.73 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 3.88 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 80.8 years
male: 77.62 years
female: 84.1 5 years (2001 est.)
Total fertility rate: 1 .41 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 10,000
(1999 est.)
HIV/AIDS - deaths: 1 50 (1 999 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 99.4%, Korean 0.6%
(1999)
Religions: observe both Shinto and Buddhist 84%,
other 16% (including Christian 0.7%)
Languages: Japanese
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1970 est.)
male: NA%
female: NA%
Population: 4,503,440 (July 2001 est.)
Age structure:
years; 19.99% (male 462,673; female 437,514)
15-64 years: 64.91 % (male 1 ,482,346; female
1,440,832)
65 years and over: 15.1% (male 282,307; female
397,768) (2001 est.)
Population growth rate: 0.49% (2001 est.)
Birth rate: 12.6 births/1 ,000 population (2001 est.)
Death rate: 9.83 deaths/1,000 population
(2001 est.)
Net migration rate: 2.11 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years ar7cy over; 0.71 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 3.94 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.79 years
male: 75.87 years
female: 31.92 years (2001 est.)
Total fertility rate: 1 .81 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 100
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,600
(1999 est.)
HIV/AIDS - deaths: 8 (1999)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Norwegian (Nordic, Alpine, Baltic),
Sami 20,000
Religions: Evangelical Lutheran 86% (state church),
other Protestant and Roman Catholic 3%, other 1%,
none and unknown 10% (1997)
Languages: Norwegian (official)
note: small Sami- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 1 00%
male: NA%
female: NA%
Population: 2,622,198
note: includes 527,078 non-nationals (July 2001 est.)
Age structure:
0-14 years: 41 .51% (male 554,727; female 533,627)
15-64 years: 56.12% (male 894,978; female 576,672)
65 years and over: 2.37% (male 32,863; female
29,331) (2001 est.)
Population growth rate: 3.43% (2001 est.)
Birth rate: 37.96 births/1 ,000 population (2001 est.)
Death rate: 4.1 deaths/1,000 population (2001 est.)
Net migration rate: 0.48 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 55 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1 .3 male(s)/female (2001 est.)
Infant mortality rate: 22.52 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 72.04 years
male: 69.9 years
female: 74.29 years (2001 est.)
Total fertility rate: 6.04 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1 1%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Omani(s)
adjective: Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian,
Pakistani, Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a
Muslim, Hindu
Languages; Arabic (official), English, Baluchi, Urdu,
Indian dialects
Literacy:
definition: NA
total population: approaching 80%
male: NA%
female: NA%
Population: 144,616,639 (July 2001 est.)
Age structure:
0-1 4 years: 40.47% (male 30,131,400; female
28,391,891)
15-64 years: 55.42% (male 40,977,543; female
39,164,663)
65 years and over: 4.1 1 % (male 2,91 8,872; female
3,032,270) (2001 est.)
Population growth rate: 2.11% (2001 est.)
Birthrate: 31.21 births/1 ,000 population (2001 est.)
Death rate: 9.26 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.84 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1.05 male(s)/female (2001 est.)
Infant mortality rate: 80.5 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 61 .45 years
male: 80.81 years
female: 62.32 years (2001 est.)
Total fertility rate: 4.41 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 74,000
(1999 est.)
HIV/AIDS -deaths: 6,500 (1999 est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan),
Baloch, Muhajir (immigrants from India at the time of
partition and their descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%),
Christian, Hindu, and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a
Punjabi variant) 10%, Pashtu 8%, Urdu (official) 8%,
Balochi 3%, Hindko 2%, Brahui 1%, English (official
and lingua franca of Pakistani elite and most
government ministries), Burushaski, and other 8%
Literacy:
definition: age 15 and over can read and write
total population: 42.7%
male: 55.3%
fema/e;29%(1998)
Population: 19,092 (July 2001 est.)
Age structure:
0-14 years: 26.88% (male 2,641 ; female 2,491 )
15-64 years: 68.46% (male 7,128; female 5,943)
65 years and over: 4.66% (male 420; female 469)
(2001 est.)
Population growth rate: 1 .69% (2001 est.)
Birth rate: 19.64 births/1,000 population (2001 est.)
Death rate: 7.23 deaths/1,000 population
(2001 est.)
Net migration rate: 4.45 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 12 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 .14 male(s)/female (2001 est.)
Infant mortality rate: 1 6.67 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.89 years
male: 65.77 years
fema/e; 72.19 years (2001 est.)
Total fertility rate: 2.47 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic groups: Palauan (Micronesian with Malayan
and Melanesian admixtures) 70%, Asian (mainly
Filipinos, followed by Chinese, Taiwanese, and
Vietnamese) 28%, white 2% (2000 est.)
Religions: Christian (Catholics, Seventh-Day
Adventists, Jehovah''s Witnesses, the Assembly of
God, the Liebenzell Mission, and Latter-Day Saints),
Modekngei religion (one-third of the population
observes this religion which is indigenous to Palau)
Languages: English and Palauan official in all states
except Sonsoral (Sonsorolese and English are
official), Tobi (Tobi and English are official), and
Angaur (Angaur, Japanese, and English are official)
Literacy:
definition: age 15 and over can read and write
total population: 92%
male: 93%
fema/e.-90%(1980 est.)','e63cc7cbde9e0b9f1a8d4cbd9d48c1af3986667734921d5be8c348568cb21b11','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3de00ecd2e477a08facb8be6ed292d859425d69eaa34f8e0f64790870237b16e',2001,'JO','Jordan','people-and-society',637,'Background: For most of its history since
independence from British administration in 1946,
Jordan was ruled by King HUSSEIN (1953-1999). A
pragmatic ruler, he successfully navigated competing
pressures from the major powers (US, USSR, and
UK), various Arab states, Israel, and a large internal
Palestinian population, through several wars and
coup attempts. In 1989 he resumed parliamentary
elections and gradually permitted political
liberalization; in 1994 a formal peace treaty was
signed with Israel. King ABDALLAH II - the eldest son
of King HUSSEIN and Princess MUNA - assumed the
throne following his father''s death in February 1999.
Since then, he has consolidated his power and
established his domestic priorities.','68abcb2fc0fbd440e3fdc6d465bb2e48a4dbe12d3dc7c7ec31937be96e298b20','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69b69df3abe6e7d56ec995827e571337d4fe678731606afe36a531a6c53108eb',2001,'KZ','Kazakhstan','people-and-society',647,'Population: 16,731,303 (July 2001 est.)
Age structure:
0-14 years: 26.73% (male 2,271 ,866; female
2,200,078)
15-64 years: 66.03% (male 5,358,535; female
5,688,550)
65 years and over: 7.24% (male 41 2,761 ; female
799,513) (2001 est.)
Population growth rate: 0.03% (2001 est.)
Birth rate: 17.3 births/1,000 population (2001 est.)
Death rate: 10.61 deaths/1 ,000 population
(2001 est.)
Net migration rate: -6.43 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.52 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 59.17 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 63.29 years
male: 57.87 years
female: 68.97 years (2001 est.)
Total fertility rate: 2.07 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,500
(1999 est.)
HIV/AIDS - deaths; less than 100 (1999 est.)
Nationality:
noun: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaq) 53.4%, Russian
30%, Ukrainian 3.7%, Uzbek 2.5%, German 2.4%,
Uighur 1 .4%, other 6.6% (1999 census)
Religions: Muslim 47%, Russian Orthodox 44%,
Protestant 2%, other 7%
Languages: Kazakh (Qazaq, state language) 40%,
Russian (official, used in everyday business) 66%
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
fema/e;96% (1989 est.)','57d175c3f92652155d1c24c448803afb2801716beb8d7adc134826f04aa613a4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d45e14ccf347cd4211d0f271aa3736fc933b89b62cba8cd8fa470a31b6b85ef',2001,'KE','Kenya','people-and-society',656,'Population: 30,765,916
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 41 .95% (male 6,524,776; female
6,381,192)
15-64 years: 55.26% (male 8,529,842; female
8,471,609)
65 years and over: 2.79% (male 376,151 ; female
482,346) (2001 est.)
Population growth rate: 1.27% (2001 est.)
Birth rate: 28.5 births/1 ,000 population (2001 est.)
Death rate: 14.35 deaths/1, 000 population (2001 est.)
Net migration rate: -1 .5 migrant(s)/1 ,000 population
(2001 est.)
note: according to UNHCR, by the end of 1 999 Kenya
was host to 223,700 refugees from neighboring
countries, including: Somalia 141,000 and Sudan
64,250
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.78 male(s)/female
total population: tot male(s)/female (2001 est.)
Infant mortality rate: 67.99 deaths/1,000 live births
(2001 est.)
Life expectancy at birth;
total population: 47.49 years
mate; 46.57 years
female: 48.44 years (2001 est.)
Total fertility rate: 3.5 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 13.95%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2.1
million (1999 est.)
HIV/AIDS - deaths: 180,000 (1999 est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%,
Kalenjin 12%, Kamba 11%, Kisii 6%, Meru 6%, other
African 15%, non-African (Asian, European, and
Arab) 1%
Religions: Protestant 38%, Roman Catholic 28%,
indigenous beliefs 26%, Muslim 7%, other 1%
note: a large majority of Kenyans are Christian, but
estimates for the percentage of the population that
adheres to Islam or indigenous beliefs vary widely
Languages: English (official), Kiswahili (official),
numerous indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 7QA%
male: 86.3%
femate; 70% (1995 est.)','3d4ef91c6947d22fa9e357c9651d77a8a6faf38f3d8ad542fffe6e686bb73c8e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36c9c8e8565162914a65e6332376f68f870277787ef0b2f3f45f4f61d294a89b',2001,'WS','Samoa','people-and-society',664,'Population: uninhabited (July 2001 est.)
Population: no indigenous inhabitants; 4 to 20
Nature Conservancy staff, US Fish and Wildlife staff
(July 2001 est.)
Population: 179,058 (July 2001 est.)
Age structure:
0-14 years: 31 .88% (male 29,009; female 28,069)
15-64 years: 62.44% (male 70,491 ; female 41 ,304)
65 years and over: 5.68% (male 4,739; female 5,446)
(2001 est.)
Population growth rate: -0.23% (2001 est.)
Birth rate: 15.59 births/1,000 population (2001 est.)
Death rate: 6.29 deaths/1 ,000 population (2001 est.)
Net migration rate: -1 1 .62 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/femaie
under 15 years: 1 .03 male(s)/female
15-64 years: 1.71 male(s)/female
65 years and over: 0.87 mate(s)/female
total population: 39 male(s)/female (2001 est.)
Infant mortality rate: 31 .75 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.5 years
male: 66.77 years
fema/e; 72.37 years (2001 est.)
Total fertility rate: 3.4 children born/woman
(2001 est.)
HIV/AIDS " adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Samoan(s)
adjective: Samoan
Ethnic groups: Samoan 92.6%, Euronesians 7%
(persons of European and Polynesian blood),
Europeans 0.4%
Religions: Christian 99.7% (about one-half of
population associated with the London Missionary
Society; includes Congregational, Roman Catholic,
Methodist, Latter-Day Saints, Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
fema/e; 97% (1971 est.)','a23084667cd01fbfb5aa8b1e90de063a93787691612b09a2746061eb43b004a4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('296e72e52b44ce8395f9759bcbdef1e6188c9898c17e76d55d04d8949e6ffab9',2001,'KG','Kyrgyzstan','people-and-society',672,'Population: 4,753,003 (July 2001 est.)
Age structure:
0-14 years: 35.03% (male 841 ,029; female 823,723)
15-64 years: 58.83% (male 1 ,369,842; female
1,426,522)
65 years and over: 6.1 4% (male 1 1 0,340; female
181,547) (2001 est.)
Population growth rate: 1 .44% (2001 est.)
Birth rate: 26.18 births/1,000 population (2001 est.)
Death rate: 9.13 deaths/1,000 population
(2001 est.)
Net migration rate: -2.66 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 76.5 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 63.46 years
male: 59.2 years
female: 67,94 years (2001 est.)
Total fertility rate: 3.19 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Kyrgyzstani(s)
adjective: Kyrgyzstan!
Ethnic groups: Kirghiz 52.4%, Russian 18%, Uzbek
12.9%, Ukrainian 2.5%, German 2.4%, other 1 1.8%
Religions: Muslim 75%, Russian Orthodox 20%,
other 5%
Languages: Kirghiz (Kyrgyz) - official language,
Russian - official language
note: in May 2000, the Kyrgyzstan! legislature made
Russian an official language, equal in status to Kirghiz
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
fema/e;96%(1989 est.)
Population: 5,635,967 (July 2001 est.)
Age structure:
0-14 years: 42.75% (male 1 ,212,577; female
1,196,795)
15-64 years: 53.94% (male 1,494,927; female
1,544,851)
65 years and over: 3.31 % (male 85,632; female
101,185) (2001 est.)
Population growth rate: 2.48% (2001 est.)
Birth rate: 37.84 births/1,000 population (2001 est.)
Death rate: 13.02 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.85 male(s)/female
total popuiation: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 92.89 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 53.48 years
male: 51.58 years
female: 55.44 years (2001 est.)
Total fertility rate: 5.12 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,400
(1999 est.)
HIV/AIDS - deaths: 1 30 (1 999 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao
Theung (upland) 22%, Lao Soung (highland) including
the Hmong ("Meo") and the Yao (Mien) 9%, ethnic
Vietnamese/Chinese 1%
Religions: Buddhist 60%, animist and other 40%
Languages: Lao (official), French, English, and
various ethnic languages
Literacy:
definition: age 15 and over can read and write
total population: 57%
male: 70%
female: 44% (1999 est.)','eda9d4e4af189afa743c74e0164d04d938d3bdc63285d9aea6dd51232a373392','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aba60d65bd428ba1daccf79d570165009c648872aadb4db8d5a900fa64362737',2001,'LV','Latvia','people-and-society',681,'Population: 2,385,231 (July 2001 est.)
Age structure:
0~14 years: 16.55% (male 201 ,746; female 193,036)
15-64 years: 68.1 5% (male 776,509; female 848,908)
65 years and over: 1 5.3% (male 1 1 8,1 1 0; female
246,922) (2001 est.)
Population growth rate: -0.81% (2001 est.)
Birth rate: 8.03 births/1 ,000 population (2001 est.)
Death rate: 14.8 deaths/1,000 population
(2001 est.)
Net migration rate: -1 .27 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 05 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.85 male(s)/female (2001 est.)
Infant mortality rate: 15.34 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.7 years
male: 62.8 years
female: 74.9 years (2001 est.)
Total fertility rate: 1.15 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.1 1 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,250
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 56.5%, Russian 30.4%,
Byelorussian 4.3%, Ukrainian 2.8%, Polish 2.6%,
other 3.4%
Religions: Lutheran, Roman Catholic, Russian
Orthodox
Languages: Latvian or Lettish (official), Lithuanian,
Russian, other
Literacy:
definition: age 1 5 and over can read and write
total population: ^100%
male: 100%
female: 99% (1989 est.)','84c7ea93c1e1b67733902a1c4b34e32c452d74d58e855e43e873228886408ba4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6c4c78e4df469fa5c153ae0704ba9c6f7962630109ddf2a6540102afdfa87bd',2001,'LB','Lebanon','people-and-society',690,'Population: 3,627,774 (July 2001 est.)
Age structure:
0-14 years: 27.57% (male 509,975; female 490,031)
15-64 years: 65.72% (male 1 ,1 36,995; female
1,247,184)
65 years and over: 3.71% (male 110,964; female
132,625) (2001 est.)
Population growth rate: 1.38% (2001 est.)
Birth rate: 20.16 births/1,000 population (2001 est.)
Death rate: 6.39 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.94 male(s)/female (2001 est.)
287
Lebanon (continued)
Infant mortality rate: 28.35 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71.52 years
male: 69.13 years
female: 74.03 years (2001 est.)
Total fertility rate: 2.05 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Muslim 70% (including Shi''a, Sunni,
Druze, Isma''ilite, Alawite or Nusayri), Christian 30%
(including Orthodox Christian, Catholic, Protestant),
Jewish NEGL%
Languages: Arabic (official), French, English,
Armenian
Literacy:
definition: age 15 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)','47c16f2f7aac85d1cc409f40923a0dc07030cf066c74d74f6d55f0019f747a01','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f138a527850705fa3cb56bc9c408fc46835dfae2d439a65e04fbc2fdf449b3ea',2001,'ZA','South Africa','people-and-society',697,'Population: 2,177,062
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 39.28% (male 430,147; female 424,994)
15-64 years: 56.03% (male 588,440; female 631 ,404)
65 years and over: 4.69% (male 43,033; female
59,044) (2001 est.)
Population growth rate: 1 .49% (2001 est.)
Birth rate: 31.24 births/1,000 population (2001 est.)
Death rate: 1 5.7 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.63 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/fema}e
15-64 years: 0.93 male(s)/fema!e
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 82.77 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 48.84 years
male: 47.97 years
female: 49.74 years (2001 est.)
Total fertility rate: 4.08 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 23.57%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS - deaths: 16,000 (1999 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans, Asians,
and other 0.3%,
Religions: Christian 80%, indigenous beliefs 20%
Languages: Sesotho (southern Sotho), English
(official), Zulu, Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 83%
male: 72%
fema/e; 93% (1999 est.)
Population: 43,586,097
note: South Africa took a census October 1 996 which
showed a population of 40,583,61 1 (after an official
adjustment for a 6.8% underenumeration based on a
postenumeration survey); estimates for this country
explicitly take into account the effects of excess
mortality due to AIDS; this can result in lower life
expectancy, higher infant mortality and death rates,
lower population and growth rates, and changes in the
distribution of population by age and sex than would
otherwise be expected (July 2001 est.)
Age structure:
0-14 years: 32.01% (male 7,023,639; female
6,928,559)
15-64 years: 63.11% (male 13,264,654; female
14,244,484)
65 years and over: 4.88% (male 798,914; female
1,325,847) (2001 est.)
Population growth rate: 0.26% (2001 est.)
Birthrate: 21.12 births/1 ,000 population (2001 est.)
Death rate: 16.77 deaths/1,000 population
(2001 est.)
Net migration rate: -1 .73 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.94 male(s)/fema!e (2001 est.)
Infant mortality rate: 60.33 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 48.09 years
male: 47.64 years
female: years (2001 est.)
Total fertility rate: 2.43 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 9.94%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4.2
million (1999 est.)
HIV/AIDS - deaths: 250,000 (1999 est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic groups: black 75.2%, white 13.6%, Colored
8.6%, Indian 2.6%
Religions: Christian 68% (includes most whites and
Coloreds, about 60% of blacks and about 40% of
Indians), Muslim 2%, Hindu 1.5% (60% of Indians),
indigenous beliefs and animist 28.5%
Languages: 1 1 official languages, including
Afrikaans, English, Ndebele, Pedi, Sotho, Swazi,
Tsonga, Tswana, Venda, Xhosa, Zulu
Literacy:
definition: age 15 and over can read and write
total population: 81 .8%
male: SI. 9%
female: SI. 7% {1995 est.)
Population: no indigenous inhabitants
note: the small military garrison on South Georgia
withdrew in March 2001 , to be replaced by a
permanent group of scientists of the British Antarctic
Survey which also has a biological station on Bird
Island; the South Sandwich Islands are uninhabited
(July 2001 est.)','9c44987af4976ceeee5ad29306888f41083abb12f9299428884f64cd4e95b876','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('483df23aa9f5d59b8277885a09cf725e8c27b9cd9bf0dad01d6ab9bbba4fe3b6',2001,'LR','Liberia','people-and-society',706,'Population: 3,225,837 (July 2001 est.)
Age structure:
0-14 years: 43.21% (male 698,178; female 695,599)
15-64 years: 53.34% (male 840,1 03; female 880,403)
65 years and over: 3.45% (male 56,073; female
55,481) (2001 est.)
Population growth rate: 1.92% (2001 est.)
Birth rate: 46.55 births/1 ,000 population (2001 est.)
Death rate: 16.36 deaths/1 ,000 population
(2001 est.)
Net migration rate: -1 1 migrant(s)/1 ,000 population
(2001 est.)
note: by the end of 1999, all Liberian refugees, who
had fled the domestic strife, were assumed to have
returned
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 132.42 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 51 A1 years
male: 49.96 years
female: 52.91 years (2001 est.)
Total fertility rate: 6.36 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.8% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 39,000
(1999 est.)
HIV/AIDS - deaths: 4,500 (1999 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: Indigenous African tribes 95%
(including Kpelle, Bassa, Gio, Kru, Grebo, Mano,
Krahn, Gola, Gbandi, Loma, Kissi, Vai, and Bella),
292
Liboria (continued)
Americo-Liberians 2.5% (descendants of immigrants
from the US who had been slaves), Congo People
2.5% (descendants of immigrants from the Caribbean
who had been slaves)
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: English 20% (official), some 20 ethnic
group languages, of which a few can be written and
are used in correspondence
Literacy:
definition: age 15 and over can read and write
total population: 38.3%
male: 53.9%
fema/e.'' 22.4% (1995 est.)
note; these figures are increasing because of the
improving school system','f710c847d601331594480d3b543604e0d43b4afed54d9d86b265ea99e0a48f68','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cb3345f82806e52b17dbd003f6c623c1ddaa352c81430e52e294918b145a7d2',2001,'LY','Libya','people-and-society',714,'Population: 5,240,599
note: includes 662,669 non-nationals, of which an
estimated 500,000 or more are Africans living in Libya
(July 2001 est.)
Age structure:
0-14 years: 35A1% (male 947,645; female 907,854)
15-64 years: 60.64% (male 1 ,645,085; female
1,533,066)
65 years and over: 3.95% (male 101 ,701 ; female
105,248) (2001 est.)
Population growth rate: 2.42% (2001 est.)
Birth rate: 27.67 births/1 ,000 population (2001 est.)
Death rate: 3.51 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 0.97 male(s)/female
total population''^. 06 male(s)/female (2001 est.)
Infant mortality rate: 28.99 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.65 years
male: 73.53 years
female: 77. 88 years (2001 est.)
Total fertility rate: 3.64 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HiV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks,
Maltese, Italians, Egyptians, Pakistanis, Turks,
Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely
understood in the major cities
Literacy:
definition: age 15 and over can read and write
total population: 782%
male: 87.9%
fema/e;63%(1995 est.)','bace4a09fe061b9a24bcd3aceab77b3fb9cdb14bf290e5c8cc1a815ba78bbdb4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb9e937ceba51757b9956840b0993926e3cb1ac5910559875df7facf54141539',2001,'CH','Switzerland','people-and-society',722,'Population: 32,528 (July 2001 est.)
Age structure;
0-14 years: ^SA^% (male 2,992; female 2,996)
15-64 years: 70.6% (male 1 1 ,455; female 11,511)
65 years and over: 1 0.99% (male 1 ,439; female
2,135) (2001 est.)
Population growth rate: 0.98% (2001 est.)
Birth rate: 1 1 .53 births/1 ,000 population (2001 est.)
Death rate: 6.7 deaths/1 ,000 population (2001 est.)
Net migration rate: 4.98 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: ^.0^ male{s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 ma!e(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 4.99 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 78.95 years
male: 75.32 years
female: 82.6 years (2001 est.)
Total fertility rate; 1 .5 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic groups: Alemannic 87.5%, Italian, Turkish,
and other 12.5%
Religions: Roman Catholic 80%, Protestant 7.4%,
unknown 7.7%, other 4.9% (1 996)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 10 and over can read and write
total population: 100%
ma/e;100%
fema/e; 100% (1981 est.)
Population: 3,610,535 (July 2001 est.)
Age structure:
0-14 years: 18.75% (male 345,694; female 331,125)
15-64 years: 67.69% (male 1,181,119; female
1,262,872)
65 years and over: 13.56% (male 165,732; female
323,993) (2001 est.)
Population growth rate: -0.27% (2001 est.)
Birth rate: 10 births/1,000 population (2001 est.)
Death rate: 12.86 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0.15 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1M male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0.3B male(s)/female (2001 est.)
Infant mortality rate: 14.5 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.25 years
male: 63.3 years
female: 75.5 years (2001 est.)
Total fertility rate: 1 .37 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 100(1 999 est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 80.6%, Russian 8.7%,
Polish 7%, Byelorussian 1.6%, other 2.1%
Religions: Roman Catholic (primarily), Lutheran,
Russian Orthodox, Protestant, Evangelical Christian
Baptist, Muslim, Jewish
Languages: Lithuanian (official), Polish, Russian
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 98% (1989 est.)','d4442b036fc4145abc1f8a6e7d97d0501a701ee08f03e5ab3a0dc0f02117a9ce','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49bc57a6ffe6efafd1cc479092e45c590f3f393853033a7bb480c3b2516b07c3',2001,'MG','Madagascar','people-and-society',737,'Population: 15,982,563 (July 2001 est.)
Age structure:
0-14 years: 45.02% (male 3,607,803; female
3,587,532)
15-64 years: 51 .77% (male 4,093,720; female
4,180,430)
65 years and over: 3.21 % (male 239,839; female
273,239) (2001 est.)
Population growth rate: 3.02% (2001 est.)
Birth rate: 42.66 births/1 ,000 population (2001 est.)
Death rate: 12.42 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
infant mortality rate: 83.58 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 55.35 years
male: 53.08 years
female: 57.68 years (2001 est.)
Total fertility rate: 5.8 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 1 ,000
(1999 est.)
HIV/AIDS - deaths: 870 (1 999 est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-Indonesian (Merina and
related Betsileo), Cotiers (mixed African,
Malayo-Indonesian, and Arab ancestry -
Betsimisaraka, Tsimihety, Antaisaka, Sakalava),
French, Indian, Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%,
Muslim 7%
Languages: French (official), Malagasy (official)
Literacy:
definition: age 15 and over can read and write
total population: 80%
male: 88%
fema/e;73%(1990 est.)','9020b03d10c12445f420bc0a1cc99d85785018191ee679b9c4c0af24784e8b35','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76f19ad736daf7f2fa4ec4df546d28634de0d89d0cf8d25ebe1422b4727f9b34',2001,'MW','Malawi','people-and-society',745,'Population: 10,548,250
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 44.43% (male 2,348,940; female
2,337,290)
15-64 years: 52.78% (male 2,741 ,622; female
2,825,966)
65 years and over: 2.79% (male 1 1 9,283; female
175,149) (2001 est.)
Population growth rate: 1.5% (2001 est.)
Birth rate: 37.8 births/1,000 population (2001 est.)
Death rate: 22.81 deaths/1 ,000 population (2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 121 .12 deaths/1 ,000 live
births (2001 est.)
310
Malawi (continued)
Life expectancy at birth:
total population: 37.08 years
ma/e; 36.61 years
female: 37.55 years (2001 est.)
Total fertility rate: 5.18 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 5.96%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 800,000
(1999 est.)
HIV/AIDS -deaths: 70,000 (1999 est.)
Nationality:
noun: Ma!awian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja, Tumbuko, Yao,
Lomwe, Sena, Tonga, Ngoni, Ngonde, Asian,
European
Religions; Protestant 55%, Roman Catholic 20%,
Muslim 20%, indigenous beliefs
Languages: English (official), Chichewa (official),
other languages important regionally
Literacy:
definition: age 1 5 and over can read and write
total population: 58%
male: 72,8%
fema/e: 43.4% (1999 est.)','678b3f5815bb2c0e389b188cc03e33c9f4ac2ae1247c98a7559b74b606b3555c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2744fe4db2b4666b4df37176e9ad6a9f697f9629e63a0098df107984358e210d',2001,'PH','Philippines','people-and-society',755,'Population: 22,229,040 (July 2001 est.)
Age structure:
0-14 years: 34.5% (male 3,943,324; female
3.724,634)
15-64 years: 61 .35% (male 6,828,670; female
6,808,623)
65 years and over: 4.1 5% (male 404,042; female
519,747) (2001 est.)
Population growth rate: 1.96% (2001 est.)
Birth rate: 24.75 births/1,000 population (2001 est.)
Death rate: 5.2 deaths/1 ,000 population (2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
312
Malaysia (continued)
note: does not reflect net flow of an unknown number
of illegal immigrants from other countries in the region
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 .01 maie(s)/female (2001 est.)
Infant mortality rate: 20.31 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: JIM years
male: 68.48 years
female: 73.92 years (2001 est.)
Total fertility rate: 3.24 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.42%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 49,000
(1999 est.)
HIV/AIDS - deaths: 1,900 (1999 est.)
Nationality:
noun: Ma!aysian(s)
adjective: Malaysian
Ethnic groups: Malay and other indigenous 58%,
Chinese 27%, Indian 8%, others 7% (2000)
Religions: Islam, Buddhism, Daoism, Hinduism,
Christianity, Sikhism; note - in addition. Shamanism is
practiced in East Malaysia
Languages: Bahasa Melayu (official), English,
Chinese dialects (Cantonese, Mandarin, Hokkien,
Hakka, Hainan, Foochow), Tamil, Telugu, Malayalam,
Panjabi, Thai; note - in addition, in East Malaysia
several indigenous languages are spoken, the largest
of which are Iban and Kadazan
Literacy:
definition: age 1 5 and over can read and write
total population: 83.5%
ma/e;89.1%
fema/e.'' 78.1% (1995 est.)
Population: no indigenous inhabitants
note.'' there are scattered Chinese garrisons (July
2001 est.)
Population: 82,841 ,51 8 (July 2001 est.)
Age structure:
0^14 years: 36.87% (male 15,547,712; female
14,997,544)
15-64 years: 59.45% (male 24,374,849; female
24,873,595)
65 years and over: 3.68% (male 1 ,355,046; female
1,692,772) (2001 est.)
Population growth rate: 2.03% (2001 est.)
Birth rate: 27.37 births/1,000 population (2001 est.)
Death rate: 6.04 deaths/1,000 population
(2001 est.)
Net migration rate: -1.01 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 28.7 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 67.8 years
male: 64.96 years
female: 70.79 years (2001 est.)
Total fertility rate: 3.42 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 28,000
(1999 est.)
HIV/AIDS - deaths: 1 ,200 (1 999 est.)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic groups: Christian Malay 91.5%, Muslim
Malay 4%, Chinese 1 .5%, other 3%
Religions: Roman Catholic 83%, Protestant 9%,
Muslim 5%, Buddhist and other 3%
Languages: two official languages - Filipino (based
on Tagalog) and English, eight major dialects -
Tagalog, Cebuano, llocan, Hiligaynon or llonggo,
Bicol, Waray, Pampango, and Pangasinense
Literacy:
definition: age 15 and over can read and write
total population: 94.6%
male: 95%
fema/e; 94.3% (1995 est.)','10f1f1f6f8dfa04a7d5453d09af6fb12925e3bb6603957ed36bf863c604ce1c5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b4f9676281a9ae3c3378023a3ef5bd4a2dcecb11552200375f8d2775e8eca1f',2001,'MV','Maldives','people-and-society',760,'Population; 310,764 (July 2001 est.)
Age structure:
0-14 years: 45.63% (male 72,920; female 68,895)
15-64 years: 51 .37% (male 81 ,506; female 78,1 49)
65 years and over: 3% (male 4,806; female 4,488)
(2001 est.)
Population growth rate: 3.01% (2001 est.)
Birth rate: 38.15 births/1,000 population (2001 est.)
Death rate: 8.09 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1.0A male(s)/female
65 years and over: 1 .07 male(s)/female
total population: 1 .05 male(s)/female (2001 est.)
Infant mortality rate: 63.72 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 62.56 years
male: 61 .39 years
female: 63.8 years (2001 est.)
Total fertility rate: 5.5 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic groups: South Indians, Sinhalese, Arabs
Religions: Sunni Muslim
Languages: Maldivian Dhivehi (dialect of Sinhala,
script derived from Arabic), English spoken by most
government officials
Literacy:
definition: age 15 and over can read and write
total population: 93.2%
male: 93.3%
female: 99% (1995 est.)
315
Maldives (continued)','aba7b3537e39c13e69d7b8c60fc5e9b1bae0e3495765afe92ff55ee854fa1b02','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54948d03bda0991ecaba6362c4c7a3bb044964661711c77320c3fd9a8891a23d',2001,'ML','Mali','people-and-society',768,'Population: 11,008,518 (July 2001 est.)
Age structure:
0-14 years: 47.2% (male 2,612,215; female
2,583,370)
15-64 years: 49.73% (male 2,610,142; female
2,864,127)
65 years and over: 3.07% (male 1 58,486; female
180,178) (2001 est.)
Population growth rate: 2.97% (2001 est.)
Birth rate: 48.79 biilhs/1,000 population (2001 est.)
Death rate: 18.71 deaths/1,000 population
(2001 est.)
Net migration rate: -0.36 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: ’{.03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.9^ male(s)/female
65 years and over: 0.88 male(s)/female
total population: 0.90 male(s)/female (2001 est.)
Infant mortality rate: 121 .44 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 47.02 years
male: 45.84 years
fema/e.'' 48.24 years (2001 est.)
Total fertility rate: 6.81 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.03%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 100,000
(1999 est.)
HIV/AIDS - deaths: 9,900 (1999 est.)
Nationality:
noun: Malian(s)
adjective: Malian
317
Mali (continued)
Ethnic groups: Mande 50% (Bambara, Malinke,
Soninke), Peu1 17%, Voltaic 12%, Songhai 6%,
Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%,
Christian 1%
Languages: French (official), Bambara 80%,
numerous African languages
Literacy:
definition: age 15 and over can read and write
total population: 3^%
male: 39.4%
fema/e.- 23,1% (1995 est.)','1a45b625ba1fcb766a860d095c45f80788069df239cb722996e975c2247bef55','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57da642fd3bb703c563fe8f12cb47b9b8609f8c5c49778ad43a1576a59465c91',2001,'MT','Malta','people-and-society',776,'Population: 394,583 (July 2001 est.)
Age structure:
0-14 years: 1 9.98% (male 40,791 ; female 38,062)
15-64 years: 67.49% (male 1 33,91 4; female 1 32,402)
65 years and over: 12.53% (male 20,643; female
28,771) (2001 est.)
Population growth rate: 0.74% (2001 est.)
Birth rate: 12.75 births/1,000 population (2001 est.)
Death rate: 7.74 deaths/1,000 population
(2001 est.)
Net migration rate: 2.37 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 09 male(s)/female
under 15 years:]. 07 male(s)/female
15-64 years: ].0] male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 5.83 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78. 1 years
male: 75.64 years
female: 80.79 years (2001 est.)
Total fertility rate: 1.92 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.52%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient
Carthaginians and Phoenicians, with strong elements
of Italian and other Mediterranean stock)
Religions: Roman Catholic 91%
Languages: Maltese (official), English (official)
Literacy:
definition: age 10 and over can read and write
total population: 88.76%
male: 80.9]%
female: 89.55% (1995 census)
Population: 73,489 (July 2001 est.)
Age structure:
0-14 years: 17.51% (male 6,562; female 6,306)
15-64 years: 65.19% (male 24,061 ; female 23,845)
65 years and over: 17.3% (male 5,076; female 7,639)
(2001 est.)
Population growth rate: 0.52% (2001 est.)
Birth rate: 1 1 .58 births/1 ,000 population (2001 est.)
Death rate: 1 1 .84 deaths/1 ,000 population
(2001 est.)
Net migration rate: 5.44 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 04 male(s)/female
15-64 years: ^.0^ male(s)/female
65 years and over: 0.66 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 6.42 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.64 years
male: 74.26 years
female: 81 .2 years (2001 est.)
Total fertility rate: 1 .65 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Manxman (men), Manxwoman (women)
adjective: Manx
Ethnic groups: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist,
Baptist, Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy:
definition: NA
total population: U/\\%
male: NA%
female: NA%','4b90906672c37b3641eb627f812dad66160fa1217f683c016c5dfd7c04bf38ad','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e59613da2b63ea152e91d2476394cd7183bc941d8a54e3453dd91d7e4ac2061e',2001,'MH','Marshall Islands','people-and-society',784,'Population: 70,822 (July 2001 est.)
Age structure;
0-14 years: 4929% (male 17,808; female 17,101)
15-64 years: 48.61% (male 17,573; female 16,853)
65 years and over: 2.1% (male 707; female 780)
(2001 est.)
Population growth rate: 3.88% (2001 est.)
Birth rate: 45.07 births/1,000 population (2001 est.)
Death rate: 6.23 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over; 0.91 male(s)/female
total population: 1 ,04 male(s)/female (2001 est.)
Infant mortality rate: 39.82 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 65.84 years
male: 64.04 years
female: 67.73 years (2001 est.)
Total fertility rate: 6.55 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (universally spoken and is the
official language), two major Marshallese dialects
from the Malayo-Polynesian family, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 100%
fema/e;88%(1980 est.)
323
Marshall Islands (continued)','b3783e6fcf57ba5b06640519248a682cb7ba8ec8fc16e1a8772856c00fda1190','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaff96e651ac313fdcd0efa05f171bad3ca4e7a7a35dff1a41ba593847407dfa',2001,'MQ','Martinique','people-and-society',792,'Population: 418,454 (July 2001 est.)
Age structure;
0-14 years: 23.1% (male 49,016; female 47,653)
15-64 years: 66.77% (male 139,106; female 140,291)
65 years and over: 1 0.1 3% (male 1 8,893; female
23,495) (2001 est.)
Population growth rate: 0.93% (2001 est.)
Birth rate: 15.76 births/1,000 population (2001 est.)
Death rate: 6.39 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.08 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 7.8 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.41 years
male: 79.11 years
female: 77.69 years (2001 est.)
Total fertility rate; 1.8 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AiDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-Indian
mixture 90%, white 5%, East Indian, Chinese less
than 5%
Religions; Roman Catholic 95%, Hindu and pagan
African 5%
Languages: French, Creole patois
Literacy;
definition: age 1 5 and over can read and write
total population: 93%
male: 92%
female: 93% (1982 est.)
Population: 6,928 (July 2001 est.)
Age structure:
0‘14 years: 25.85% (male 917; female 874)
15-64 years: 64.22% (male 2,273; female 2,176)
65 years and over: 9.93% (male 291 ; female 397)
(2001 est.)
Population growth rate: 0.43% (2001 est.)
Birth rate: 15.88 births/1,000 population (2001 est.)
Death rate: 6.64 deaths/1,000 population
(2001 est.)
Net migration rate: 4.91 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1.01 male(s)/female (2001 est.)
Infant mortality rate: 8.39 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.77 years
male: 75.51 years
female: 80.13 years (2001 est.)
Total fertility rate; 2.12 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Basques and Bretons (French
fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy;
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)','419e398139c89b184eb00f3a1a4f82e727a9e1ae9132180bb4c5f0aae90a268f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86d32e2cff12afbba8c36481a008ae84c1c684482c436058a863a7e5f3a39d26',2001,'MR','Mauritania','people-and-society',796,'Population: 2,747,312 (July 2001 est.)
Age structure:
0‘14 years: 46.14% (male 634,940; female 632,654)
15-64 years: 51 .59% (male 698,433; female 718,883)
65 years and over: 2.27% (male 25,840; female
36,562) (2001 est.)
Population growth rate: 2.93% (2001 est.)
Birthrate; 42.95 births/1 ,000 population (2001 est.)
Death rate: 13.65 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 76.7 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 51.14 years
male: 49.06 years
female: 53.29 years (2001 est.)
Total fertility rate: 6.22 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .8% (2000 est.)
327
Mauritania (continued)
HIV/AIDS ■ people living with HIV/AIDS: 6,600
(1999 est.)
HIV/AIDS - deaths: 610 (1999 est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic groups: mixed Maur/black 40%, Maur 30%,
black 30%
Religions: Muslim 100%
Languages: Hasaniya Arabic (official), Pular,
Soninke, Wolof (official), French
Literacy:
definition: age 15 and over can read and write
total population: 46.7%
male: 53.4%
fe/T)a/e;40%(1998 est.)','21ee58d05e1a39a842b380059695755d5a939c3323e097471137c95c22998c56','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfb8fdb086a9417b018ff3fa6fcc8018de86b59dfcdf18317dd555c432a7e518',2001,'MU','Mauritius','people-and-society',805,'Population: 1,189,825 (July 2001 est.)
Age structure:
0‘14 years: 25.53% (male 153,691; female 150,094)
15-64 years: 68.24% (male 404,940; female 407,056)
65 years and over: 6.23% (male 29,588; female
44,456) (2001 est.)
Population growth rate: 0.88% (2001 est.)
Birth rate: 16.5 births/1 ,000 population (2001 est.)
Death rate: 6.82 deaths/1.000 population
(2001 est.)
Net migration rate: -0.92 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 17.19 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .25 years
male: 67.26 years
female: 75.31 years (2001 est.)
Total fertility rate: 2.01 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%,
Sino-Mauritian 3%, Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman
Catholic 26%, Protestant 2.3%), Muslim 16.6%, other
3.1%
Languages: English (official), Creole, French, Hindi,
Urdu, Hakka, Bojpoori
Literacy:
definition: age 15 and over can read and write
total population: 82.9%
male: 37.1%
female: 73.3% (1995 est.)','4b50a354f5bc9ca4f7e4de8db2c6a3d38586020693bbc13431768f89b46b3c82','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00c334237f0fad5de9129f867aab1faba76e815aea58dfa06e166739bcb061fd',2001,'YT','Mayotte','people-and-society',814,'Population: 163,366 (July 2001 est.)
Age structure:
0^14 years: 46.59% (male 38,188; female 37,920)
15-64 years: 51 .73% (male 46,1 32; female 38,378)
65 years and over: 1 .68% (male 1 ,361 ; female 1 ,387)
(2001 est.)
Population growth rate: 4.58% (2001 est.)
Birth rate: 44.39 births/1,000 population (2001 est.)
Death rate: 8.84 deaths/1,000 population
(2001 est.)
Net migration rate: 1 0.28 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1 .2 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1.1 male(s)/female (2001 est.)
Infant mortality rate: 69.54 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 59.83 years
male: 57.77 years
female: 61 .96 years (2001 est.)
Total fertility rate: 6.24 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 97%, Christian (mostly Roman
Catholic)
Languages: Mahorian (a Swahili dialect), French
(official language) spoken by 35% of the population
Literacy:
definition: NA
total population:
male: NA%
female: NA%','dfb861debd69557783391d464d1b7fe2a855c47a00100c96b1537f5456af81bf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15883af0982349de1e81f4b6c4dc6426ad2e6255bf7240964dc4098a33842b32',2001,'US','United States','people-and-society',824,'Population: 101,879,171 (July 2001 est.)
Age structure:
0-14 years: 33.32% (male 17,312,220; female
16,635,438)
Mexico (continued)
15-64 years: 62.28% (male 30,888,015; female
32,558,359)
65 years and over: 4.4% (male 1 ,997,21 9; female
2,487,920) (2001 est.)
Population growth rate: 1 .5% (2001 est.)
Birth rate: 22.77 births/1 ,000 population (2001 est.)
Death rate: 5.02 deaths/1 ,000 population
(2001 est.)
Net migration rate: -2.77 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 25.36 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .76 years
male: 68.73 years
female: 74.93 years (2001 est.)
Total fertility rate: 2.62 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.29%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 50,000
(1999 est.)
HIV/AIDS - deaths: 4,700 (1999 est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%,
Amerindian or predominantly Amerindian 30%, white
9%, other 1%
Religions: nominally Roman Catholic 89%,
Protestant 6%, other 5%
Languages: Spanish, various Mayan, Nahuatl, and
other regional indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 89.6%
mate.* 91.8%
fema/e.'' 87.4% (1995 est.)
Population: 278,058,881 (July 2001 est.)
Age structure:
0-14 years: 21.12% (male 30,034,674; female
28,681,253)
15-64 years: 66.27% (male 91 ,371 ,753; female
92,907,199)
65 years and over: 12.61% (male 14,608,948;
female 20,455,054) (2001 est.)
Population growth rate: 0.9% (2001 est.)
Birth rate: 14.2 births/1,000 population (2001 est.)
Death rate: 8.7 deaths/1,000 population (2001 est.)
Net migration rate: 3.5 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (2001 est.)
Infant mortality rate: 6.76 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.26 years
male: 74.37 years
female: 80.05 years (2001 est.)
Total fertility rate: 2.06 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.61%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 850,000
(1999 est.)
HIV/AIDS - deaths: 20,000 (1999 est.)
Nationality:
noun: American(s)
adjective: American
Ethnic groups: white 83.5%, black 12.4%, Asian
3.3%, Amerindian 0.8% (1992)
note: a separate listing for Hispanic is not included
because the US Census Bureau considers Hispanic
to mean a person of Latin American descent
(especially of Cuban, Mexican, or Puerto Rican origin)
living in the US who may be of any race or ethnic
group (white, black, Asian, etc.)
Religions; Protestant 56%, Roman Catholic 28%,
Jewish 2%, other 4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable
minority)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
fema/e; 97% (1979 est.)','805740ea5ec9b3fc1f1bd437a5cf63194b7291f9c7a0ca4e05ca092115dbb267','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d53fa9d164222dca8e7d723334d8788998627c8618cb5983fef03eb5614fc205',2001,'MC','Monaco','people-and-society',832,'Population: 31 ,842 (July 2001 est.)
Age structure:
0-/4 years.- 15.32% (male 2,503; female 2,375)
15-64 years: 62.23% (male 9,731 ; female 10,083)
65 years and over: 22.45% (male 2,921 ; female
4,229) (2001 est.)
Population growth rate: 0.46% (2001 est.)
Birthrate: 9.74 birlhs/1 ,000 population (2001 est.)
Death rate: 13 deaths/1 ,000 population (2001 est.)
Net migration rate: 7.85 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.91 male(s)/female (2001 est.)
Infant mortality rate: 5.83 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth;
total population: 78.98 years
male: 75.04 years
female: 83.12 years (2001 est.)
Total fertility rate; 1.76 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups: French 47%, Monegasque 16%,
Italian 16%, other 21%
Religions: Roman Catholic 90%
Languages: French (official), English, Italian,
Monegasque
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%','4f24626ee1434305d108094c646f262e0118bb105caa6563e7cd8f5781d1f674','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f60cb33aa3f79a60d8cdc11cbea3f2eca84987ce8201277b45e21e3db9643b3',2001,'MS','Montserrat','people-and-society',839,'Population: 7,574
note: an estimated 8,000 refugees left the island
following the resumption of volcanic activity in July
1995; some have returned (July 2001 est.)
Age structure:
0-14 years: 23.83% (male 907; female 898)
15-64 years: 64.66% (male 2,341 ; female 2,556)
65 years and over: 1 1 .51 % (male 464; female 408)
(2001 est.)
Population growth rate: 13.39% (2001 est.)
Birth rate: 17.43 births/1,000 population (2001 est.)
Death rate: 7.53 deaths/1 ,000 population
(2001 est.)
Net migration rate: 123.98 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under f 5 years; 1.01 male(s)/fema!e
15-64 years: 0.02 male(s)/female
65 years and over: 1.14 male(s)/female
total population: 0.96 male(s)/female (2001 est.)
Infant mortality rate: 8.19 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.03 years
male: 75.95 years
female: 80.22 years (2001 est.)
Total fertility rate: 1 .82 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman Catholic,
Pentecostal, Seventh-Day Adventist, other Christian
denominations
Languages; English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
fema/e; 97% (1970 est.)','4f7928305f37180052ae6243038f6aec6fc6e2b98ff5260495263f360986d3eb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe16802eb98256193d10813929faf353ad89f3d14b774c559c4d6eec118c5a25',2001,'NA','Namibia','people-and-society',849,'Population: 1,797,677
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 42.74% (male 389,028; female 379,229)
15-64 years: 53.54% (male 480,075; female 482,375)
65 years and over: 3.72% (male 29,109; female
37,861) (2001 est.)
Population growth rate: 1.38% (2001 est.)
Birth rate: 34.71 births/1,000 population (2001 est.)
Death rate: 20.9 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 71 .66 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 40.62 years
male: 42.48 years
female: 38.71 years (2001 est.)
Total fertility rate: 4.83 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 19.54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 160,000
(1999 est.)
HIV/AIDS - deaths: 1 8,000 (1999 est.)
Nationality;
noun: Namibian(s)
adjective: Namibian
352
Namibia (continued)
Ethnic groups: black 87.5%, white 6%, mixed 6.5%
nofe; about 50% of the population belong to the
Ovambo tribe and 9% to the Kavangos tribe; other
ethnic groups are: Herero 7%, Damara 7%, Nama 5%,
Caprivian 4%, Bushmen 3%, Baster 2%, Tswana
0.5%
Religions: Christian 80% to 90% (Lutheran 50% at
least), Indigenous beliefs 10% to 20%
Languages: English 7% (official), Afrikaans common
language of most of the population and about 60% of
the white population, German 32%, indigenous
languages: Oshivambo, Herero, Nama
Literacy:
definition: age 15 and over can read and write
total population: 3B%
male: 45%
fe/7?a/e;31% (1960 est.)','6f9bf62f23a24fd82eb5bdf762d04b70b3dc5a28584f5f65c8e614948ddd5c11','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('275c5038c8c3ebd1c16e44c0393d85d78074bfb9ab4f2ab1dba675053f1999e3',2001,'NR','Nauru','people-and-society',857,'Population: 12,088 (July 2001 est.)
Age structure:
0-/4 years; 40.33% (male 2,510; female 2,365)
15-64 years: 57.97% (male 3,475; female 3,533)
65 years and over: 1 .7% (male 1 03; female 1 02)
(2001 est.)
Population growth rate: 2% (2001 est.)
Birthrate: 27.22 births/1,000 population (2001 est.)
Death rate: 7.2 deaths/1 ,000 population (2001 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1,01 male(s)/female (2001 est.)
Infant mortality rate: 10.71 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 61 .2 years
male: 57.7 years
female: 64.88 years (2001 est.)
Total fertility rate: 3.61 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths; NA
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander
26%, Chinese 8%, European 8%
Religions: Christian (two-thirds Protestant, one-third
Roman Catholic)
Languages; Nauruan (official, a distinct Pacific
Island language), English widely understood, spoken,
and used for most government and commercial
purposes
Literacy:
definition: NA
total population: UA%
male: NA%
female: NA%
Population: uninhabited
note; transient Haitian fishermen and others camp on
the island (July 2001 est.)','fb7d76663e96e5d53aa99b2e3b60259f861a96792e83d3da7d65a853bb58083f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d484a075ac6f81111cc5cc9e8f96c1d9f660bedb16045cfa48935ad6a0cd48b',2001,'NP','Nepal','people-and-society',865,'Population: 25,284,463 (July 2001 est.)
Age structure:
0-14 years: 40.35% (male 5,267,234; female
4,933,910)
15-64 years: 56.1 6% (male 7,264,575; female
6,934,384)
65 years and over: 3.49% (male 437,813; female
446,547) (2001 est.)
Population growth rate: 2.32% (2001 est.)
Birth rate: 33.4 births/1,000 population (2001 est.)
Death rate: 1 0.22 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
357
Nepal (continued)
Sex ratio:
atbirth‘A.05 male(s)/female
under /5 years; 1.07 male(s)/fema!e
15^64 years: 1.05 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 05 male(s)/femate (2001 est.)
Infant mortality rate: 74.14 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 58.22 years
male: 58.05 years
female: 57.77 years (2001 est.)
Total fertility rate: 4.58 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.29%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 34,000
(1999 est.)
HIV/AIDS - deaths: 2,500 (1999 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Brahman, Chetri, Newar, Gurung,
Magar, Tamang, Rai, Limbu, Sherpa, Tharu, and
others (1995)
Religions: Hinduism 86.2%, Buddhism 7.8%, Islam
3.8%, other 2.2%
note: only official Hindu state in the world (1995)
Languages: Nepali (official; spoken by 90% of the
population), about a dozen other languages and about
30 major dialects; note - many in government and
business also speak English (1995)
Literacy:
definition: age 15 and over can read and write
total population: 27.5%
male: 40.9%
female: 14% (1995 est.)
People - note: refugee issue over the presence in
Nepal of approximately 98,700 Bhutanese refugees,
90% of whom are in seven United Nations Office of
the High Commissioner for Refugees (UNHCR)
camps','cc0130e9bfe0b4b66100c6c9c4a7eaa54452a2f11e24214d24549dbeb8a3386f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40f0989c392404806265d2404f065c9318af7697fde91fc75fe86a94e16b4c78',2001,'NL','Netherlands','people-and-society',874,'Population: 212,226 (July 2001 est.)
Age structure:
0-14 years: 25.21% (male 27,332; female 26,169)
15-64 years: 66.99% (male 67,562; female 74,599)
65 years and over: 7.8% (male 6,874; female 9,690)
(2001 est.)
Population growth rate: 0.97% (2001 est.)
Birth rate: 16.55 births/1 ,000 population (2001 est.)
Death rate: 6.41 deaths/1,000 population
(2001 est.)
Net migration rate: -0.42 migrant(s)/1 ,000
population (2001 est.)
Sex ratio;
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.92 male(s)/female (2001 est.)
Infant mortality rate: 1 1 .4 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 74.94 years
male: 72.76 years
femate; 77.22 years (2001 est.)
Total fertility rate: 2.07 children born/woman
(2001 est.)
HIV/AIDS “ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Dutch Antillean(s)
adjective: Dutch Antillean
Ethnic groups: mixed black 85%, Carib Amerindian,
white, East Asian
Religions: Roman Catholic, Protestant, Jewish,
Seventh-Day Adventist
Languages: Dutch (official), Papiamento (a
Spanish-Portuguese-Dutch-English dialect)
predominates, English widely spoken, Spanish
Literacy;
definition: age 15 and over can read and write
total population: 98%
362
Netherlands Antilles (continued)
male: 98%
fema/e: 99% (1981 est.)','5e9d251608c56acc10363c3d1f53dfc505a3bdbfe0c3ba1fa1ec97dbe087be50','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ecd6202c286514c6b30e2abb040f8f49fe91004117bfb19940f05417f545275',2001,'NZ','New Zealand','people-and-society',883,'Population: 3,864,129 (July 2001 est.)
Age structure:
0^14 years: 22.36% (male 442,738; female 421 ,462)
15-64 years: 66.1 1 % (male 1 ,281 ,781 ; female
1,272,674)
65 years and over: 1 1 .53% (male 1 93,895; female
251,579) (2001 est.)
Population growth rate: 1.14% (2001 est.)
Birthrate: 14.28 births/1,000 population (2001 est.)
Death rate: 7.56 deaths/1,000 population
(2001 est.)
Net migration rate: 4.71 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .04 male(s)/fema!e
under 15 years: 1.05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 ma!e(s)/female (2001 est.)
Infant mortality rate: 6.28 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.99 years
ma/e: 75.01 years
female: 81.1 years (2001 est.)
Total fertility rate: 1 .8 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 0.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: New Zealand European 74.5%,
Maori 9.7%, other European 4.6%, Pacific Islander
3.8%, Asian and others 7.4%
Religions: Anglican 24%, Presbyterian 1 8%, Roman
Catholic 15%, Methodist 5%, Baptist 2%, other
Protestant 3%, unspecified or none 33% (1986)
Languages: English (official), Maori
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 104,227 (July 2001 est.)
Age structure;
0-/4 years; 40.93% (male 21,739; female 20,916)
15’64 years: 54.99% (male 28,231 ; female 29,082)
65 years and over: 4.08% (male 1 ,91 2; female 2,347)
(2001 est.)
Population growth rate: 1 .79% (2001 est.)
Birth rate: 23.59 births/1 ,000 population (2001 est.)
Death rate: 5.74 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over; 0.81 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 14.08 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.25 years
male: 65.83 years
female: 70.78 years (2001 est.)
Total fertility rate: 3 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths; NA
Nationality:
nonn; Tongan(s)
adjective: Tongan
Ethnic groups: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims
over 30,000 adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
total population: 98.5%
male: 98.4%
fema/e; 98.7% (1996 est.)
Population: 1,169,682 (July 2001 est.)
Age structure:
0-14 years: 24A% (male 143,730; female 138,160)
15-64 years: 69.2% (male 415,898; female 393,551)
65 years and over: 6.7% (male 34,785; female
43,558) (2001 est.)
Population growth rate: -0.51% (2001 est.)
Birth rate: 13.73 births/1 ,000 population (2001 est.)
Death rate; 8.82 deaths/1 ,000 population
(2001 est.)
Net migration rate: -9.97 migrant{s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 06 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 .03 male(s)/female (2001 est.)
infant mortality rate: 24.98 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.27 years
male: 65.74 years
female: 70.92 years (2001 est.)
Total fertility rate: 1.81 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 1 .05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,800
(1999 est.)
HIV/AIDS -deaths: 530 (1999 est.)
Nationality:
noun; Trinidadian (s), Tobagonian(s)
aof/ecf/Ve; Trinidadian, Tobagonian
Ethnic groups: black 39.5%, East Indian (a local
term - primarily immigrants from northern India)
40.3%, mixed 18.4%, white 0.6%, Chinese and other
1.2%
Religions: Roman Catholic 29.4%, Hindu 23.8%,
Anglican 10.9%, Muslim 5.8%, Presbyterian 3.4%,
other 26.7%
Languages: English (official), Hindi, French,
Spanish, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 97.9%
male: 98.8%
fe™/e;97%(1995 est.)
Population: uninhabited (July 2001 est.)
Population: 15,435 (July 2001 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA%
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun; Wa!iisian(s), Futunan(s), or Wallis and Futuna
Islanders
aofeef/Ve; WalHsian, Futunan, or Wallis and Futuna
Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous
Polynesian language)
Literacy:
definition: age 1 5 and over can read and write
total population: 50%
male: 50%
fema/e; 50% (1969 est.)','f2fb4ac3c68328725bfbd0e563cc136663db141333ddd3e14968d119c0e85ba4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('799e2a3cf5981da1a2a6f8c143c1e5da24da999156f56e87dca5362d13147e20',2001,'NE','Niger','people-and-society',895,'Population: 10,355,156 (July 2001 est.)
Age structure:
0-14 years: 47.97% (male 2,528,484; female
2,439,051)
15-64 years: 49.75% (male 2,518,400; female
2,633,677)
65 years and over: 2.28% (male 1 23,589; female
111,955) (2001 est.)
Population growth rate: 2.72% (2001 est.)
Birth rate: 50.68 births/1,000 population (2001 est.)
Death rate: 22.71 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.73 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 0.96 male(s)/female
65 years and over: 1.1 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 1 23.57 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 41 .59 years
male: 41.74 years
female: 41 .44 years (2001 est.)
Total fertility rate: 7.08 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .35%
(1999 est.)
HIV/AIDS " people living with HIV/AIDS: 64,000
(1999 est.)
HIV/AIDS - deaths: 6,500 (1999 est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula
8.5%, Tuareg 8%, Beri Beri (Kanouri) 4.3%, Arab,
Toubou, and Gourmantche 1 .2%, about 1 ,200 French
expatriates
Religions: Muslim 80%, remainder indigenous
beliefs and Christians
Languages: French (official), Hausa, Djerma
Literacy:
definition: age 15 and over can read and write
total population: 1 3.6%
male: 20.9%
fema/e; 6.6% (1995 est.)
Population: 126,635,626
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0^14 years: 43.71% (male 27,842,225; female
27,514,197)
15-64 years: 53.47% (male 34,456,738; female
33,259,194)
65 years and over: 2.82% (male 1 ,780,862; female
1,782,410) (2001 est.)
Population growth rate: 2.61% (2001 est.)
Birth rate: 39.69 births/1,000 population (2001 est.)
Death rate: 13.91 deaths/1,000 population
(2001 est.)
Net migration rate: 0.28 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.04 male (s)/fe male
65 years and over: 1 male(s)/female
total population: 1 .02 male(s)/female (2001 est.)
Infant mortality rate: 73.34 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 51 .07 years
male: 51.07 years
female: 51.07 years (2001 est.)
Total fertility rate: 5.57 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 5.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2.7
million (1999 est.)
HIV/AIDS - deaths: 250,000 (1 999 est.)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Nigeria, which is Africa''s most
populous country, is composed of more than 250
ethnic groups; the following are the most populous
and politically influential: Hausa and Fulani 29%,
Yoruba 21%, Igbo (Ibo) 18%, Ijaw 10%, Kanuri 4%,
Ibibio 3.5%, Tiv 2.5%
Religions: Muslim 50%, Christian 40%, indigenous
beliefs 10%
Languages: English (official), Hausa, Yoruba, Igbo
(Ibo), Fulani
Literacy:
definition: age 15 and over can read and write
total population: 57.1%
male: 67.3%
fema/e; 47.3% (1995 est.)','6cc1c1d01f0ddc0287699178428e75eec4236748cd39263b118fadc7334ac831','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('964eb11c9af5ac070456dab167f2539f20f6e63a969bf7eaeda94f055f686a47',2001,'NU','Niue','people-and-society',904,'Population: 2,124 (July 2001 est.)
Age structure:
0-14 years: NA%
15-54 years; NA%
55 years and over: NA%
Population growth rate: 0.5% (2001 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic groups: Polynesian (with some 200
Europeans, Samoans, and Tongans)
Religions: Ekalesia Niue (Niuean Church - a
Protestant church closely related to the London
Missionary Society) 75%, Latter-Day Saints 10%,
other 15% (mostly Roman Catholic, Jehovah''s
Witnesses, Seventh-Day Adventist)
Languages: Polynesian closely related to Tongan
and Samoan, English
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%','36845462450f0cbc858a1c0291604fd58449578e490c5000ebdbb5ee8cf851a1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1340523208ba0a07f98bb8a55f5262bb708b7e24b23aa69f208a5a601956ae53',2001,'PA','Panama','people-and-society',915,'Population: 2,845,647 (July 2001 est.)
Age structure:
0-/4 years; 30.1 3% (male 436,661 ; female 420,625)
392
Panama (continued)
15’64 years: 63.86% (male 920,787; female 896,520)
65 years and over: 6.01 % (male 81 ,682; female
89,372) (2001 est.)
Population growth rate: 1,3% (2001 est.)
Birth rate: 19.06 births/1 ,000 population (2001 est.)
Death rate: 4.95 deaths/1 ,000 population
(2001 est.)
Net migration rate: -1.1 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: male(s)/female
under 15 years: 1 .04 male(s)/femaie
15-64 years: 1 .03 male(s)/female
65 years and over: 0.91 male(s)/fema!e
totai population: 1.02 ma!e(s)/female (2001 est.)
Infant mortality rate: 20.18 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.68 years
male: 72.94 years
female: 78.53 years (2001 est.)
Total fertility rate: 2.27 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 1 .54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 24,000
(1999 est.)
HIV/AIDS - deaths: 1 ,200 (1 999 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and
white) 70%, Amerindian and mixed (West Indian)
14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy:
definition: age 15 and over can read and write
total population: 90.8%
male: 91 .4%
fema/e; 90.2% (1995 est.)','2366fab98a4349e53b3bd05c9fd494f8fc91e0df271788d8c732b4400c08bd72','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5019fe911870b7986a37b8562aba94d50484a6873d0821e79d6ac6ca1378926',2001,'PN','Pitcairn','people-and-society',928,'Population: 47 (July 2001 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: N A%
Population growth rate: -2.08% (2001 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS “ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty
mutineers and their Tahitian wives
Religions: Seventh-Day Adventist 100%
Languages: English (official), Pitcairnese (mixture of
an 18th century English dialect and a Tahitian dialect)','d7134d766c05d37ef2314206e869b29ac42dc37e9ef394c6d91a3afdaa32d44f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4ef65df028616f5ee3e2882ae4d5f8f01d2beb6824448d060cbaef9fe41528f',2001,'MX','Mexico','people-and-society',936,'Population: 38,633,912 (July 2001 est.)
Age structure:
O’Uyears: 18.39% (male 3,640,451; female
3,463,604)
15-64 years: 69.17% (male 13,288,471 ; female
13,434,753)
65 years and over: 12.44% (male 1,836,816; female
2,969,817) (2001 est.)
Population growth rate: -0.03% (2001 est.)
Birth rate: 10.2 births/1,000 population (2001 est.)
Death rate: 9.98 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.49 mlgrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.94 male(s)/female (2001 est.)
Infant mortality rate: 9.39 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.42 years
407
Poland (continued)
male: 69.26 years
female: 77.82 years (2001 est.)
Total fertility rate: 1 .37 children born/woman
(2001 est.)
HiV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic groups: Polish 97.6%, German 1.3%,
Ukrainian 0.6%, Byelorussian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75%
practicing), Eastern Orthodox, Protestant, and other
5%
Languages: Polish
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
fema/e.-98%(1978 est.)','c2776d573913627724085f904449621a2136630100b138157ffc281f91a4f36f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02a72dd6268b36dfaa76b7d6739dcd913f3329282d72e0721278066e88199bf2',2001,'PT','Portugal','people-and-society',943,'Population: 10,066,253 (July 2001 est.)
Age structure:
O-M years; 16.96% (male 877,379; female 830,242)
15-64 years: 67.42% (male 3,321 ,473; female
3,465,481)
65 years and over: 15.62% (male 637,207; female
934,471) (2001 est.)
Population growth rate: 0.18% (2001 est.)
Birth rate: 1 1 .51 births/1 ,000 population (2001 est.)
Death rate: 10.21 deaths/1,000 population
(2001 est.)
Net migration rate: 0.5 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0,90 male (s)/fe male
65 years and over: 0.68 male(s)/female
total population: 0.92 male(s)/female (2001 est.)
Infant mortality rate: 5.94 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.94 years
maie: 72.44 years
fema/e; 79.68 years (2001 est.)
Total fertility rate: 1 .48 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.74%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 36,000
(1999 est.)
HIV/AIDS - deaths: 280 (1999 est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic groups: homogeneous Mediterranean stock;
citizens of black African descent who immigrated to
mainland during decolonization number less than
100,000
Religions: Roman Catholic 94%, Protestant (1995)
Languages: Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 87.4%
male: NA%
female: NA%','f171593083f3c8442672eecb1a3f005e5dcf890b8cd54462238c6d46b8419d16','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11e1dfd02e3d077cbedbc3b9787473978f511260b52e15bd7809b524fc993717',2001,'QA','Qatar','people-and-society',949,'Population: 769,152 (July 2001 est.)
Age structure:
0-14 years: 25.77% (male 101 ,155; female 97,086)
1&64 years: 71 .75% (male 391 ,178; female 160,665)
65 years and over: 2.48% (male 13,625; female
5,443) (2001 est.)
Population growth rate: 3.18% (2001 est.)
Birthrate: 15.91 births/1 ,000 population (2001 est.)
Death rate: 4.26 deaths/1,000 population
(2001 est.)
Net migration rate: 20.12 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: Ob male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 2.43 male(s)/femate
65 years and over: 2.5 male(s)/female
total population: 1 .92 male(s)/female (2001 est.)
Infant mortality rate: 21 .44 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 72.62 years
ma/e; 70.16 years
female: 75.21 years (2001 est.)
Total fertility rate: 3.17 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Qatari(s)
adjective: Qatari
Ethnic groups: Arab 40%, Pakistani 18%, Indian
18%, Iranian 10%, other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly
used as a second language
Literacy:
definition: age 15 and over can read and write
total population: 79%
male: 79%
fema/e;80%(1995 est.)
Population: 732,570 (July 2001 est.)
Age structure:
0^14 years: 32.07% (male 120,259; female 1 14,669)
15’64 years: 62.25% (male 224,347; female 231 ,698)
65 years and over: 5.68% (male 1 6,892; female
24,705) (2001 est.)
Population growth rate: 1.57% (2001 est.)
Birthrate: 21 .26 births/1 ,000 population (2001 est.)
Death rate: 5.52 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.07 male(s)/female (2001 est.)
Infant mortality rate: 8.49 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 72.93 years
mate; 69.53 years
female: 76.49 years (2001 est.)
Total fertility rate: 2.58 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AiDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups: French, African, Malagasy, Chinese,
Pakistani, Indian
Religions: Roman Catholic 86%, Hindu, Muslim,
Buddhist (1995)
Languages: French (official). Creole widely used
Literacy:
definition: age 15 and over can read and write
total population: 79%
male: 70%
femate; 80% (1982 est.)','f54d2667ce91be9b9e998886c03091b095f3301012fcde1e2b18680d67d65ee6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99f0063cd30a1f58ffe6365547ae9a012a06dc17f009dc3ba86e4111e8f16685',2001,'UA','Ukraine','people-and-society',958,'Population: 22,364,022 (July 2001 est.)
Age structure:
0-14 years: M. 95% (male 2,054,323; female
1,959,196)
15-64 years: 68.51% (male 7,605,751 ; female
7,715,434)
65 years and over: 1 3.54% (male 1 ,255,880; female
1,773,438) (2001 est.)
Population growth rate: -0.21% (2001 est.)
Birthrate: 10.8 births/1,000 population (2001 est.)
Death rate: 12.28 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.6 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 1 9.36 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 70. 1 6 years
male: 66.36 years
fema/e;74.19 years (2001 est.)
Total fertility rate: 1 .35 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,000
(1999 est.)
HIV/AIDS -deaths: 350 (1999 est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic groups: Romanian 89.5%, Hungarian 7.1%,
Roma 1.8%, German 0.5%, Ukrainian 0.3%, other
0.8% (1992)
Religions: Romanian Orthodox 70%, Roman
Catholic 3%, Uniate Catholic 3%, Protestant 6%,
unaffiliated 18%
Languages: Romanian, Hungarian, German
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 95% (1992 est.)
Population: 145,470,197 (July 2001 est.)
Age structure:
0‘14years: 17.41% (male 12,915,026; female
12,405,341)
15-64 years: 69.78% (male 49,183,000; female
52,320,962)
65 years and over: 12.81% (male 5,941,944; female
12,703,924) (2001 est.)
Population growth rate: -0.35% (2001 est.)
Birth rate: 9.35 births/1,000 population (2001 est.)
Death rate: 13.85 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0.98 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: IM male(s)/female
15-64 years; 0.94 male(s)/female
65 years and over: 0.47 male(s)/female
total population: 0.8S male(s)/female (2001 est.)
Infant mortality rate; 20.05 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 67.34 years
ma/e; 62.12 years
female: 72.83 years (2001 est.)
Total fertility rate: 1 .27 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.18%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS -deaths: 850 (1999 est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic groups: Russian 81 .5%, Tatar 3.8%,
Ukrainian 3%, Chuvash 1 .2%, Bashkir 0.9%,
Byelorussian 0.8%, Moldavian 0.7%, other 8.1%
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy;
definition: age 15 and over can read and write
total population: 98%
male: 100%
fema/e;97%(1989 est.)
Population: 7,312,756
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: A2A% (male 1,555,878; female
1,544,942)
15-64 years: 54.73% (male 1 ,989,501 ; female
2,013,012)
65 years and over: 2.87% (male 83,769; female
125,654) (2001 est.)
Population growth rate: 1.16% (2001 est.)
Birth rate: 33.97 births/1 ,000 population (2001 est.)
Death rate: 21.13 deaths/1 ,000 population
(2001 est.)
Net migration rate: -1.21 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 1 1 8.92 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 38.99 years
male: 38.35 years
female: 39.65 years (2001 est.)
Total fertility rate: 4.89 children born/woman
(2001 est.)
HIV/AIDS " adult prevalence rate: 1 1 .21%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 400,000
(1999 est.)
HIV/AIDS -deaths: 40,000 (1999 est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 84%, Tutsi 15%, Twa
(Pygmoid) 1%
Religions: Roman Catholic 52.7%, Protestant 24%,
Adventist 10.4%, Muslim 1.9%, indigenous beliefs
and other 6.5%, none 4.5% (1996)
Languages: Kinyarwanda (official) universal Bantu
vernacular, French (official), English (official),
Kiswahili (Swahili) used in commercial centers
Literacy:
definition: age 15 and over can read and write
total population: 48%
male: 52%
fema/e;45% (1995 est.)
Population: 7,266 (July 2001 est.)
Age structure:
0-14 years: 19.08% (male 699; female 687)
15-64 years: 71 .72% (male 2,71 1 ; female 2,500)
65 years and over: 9.2% (male 286; female 383)
(2001 est.)
Population growth rate: 0.72% (2001 est.)
Birth rate: 13.49 births/1,000 population (2001 est.)
Death rate: 6.33 deaths/1.000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1 .04 male(s)/female (2001 est.)
Infant mortality rate: 22.38 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.01 years
ma/e; 74.13 years
female: 80.04 years (2001 est.)
Total fertility rate: 1 .53 children born/woman
(2001 est.)
427
Saint Helena (continued)
HIV/AIDS " adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
Ethnic groups: African descent 50%, white 25%,
Chinese 25%
Religions: Anglican (majority), Baptist, Seventh-Day
Adventist, Roman Catholic
Languages: English
Literacy:
definition: age 20 and over can read and write
total population: 97%
male: 97%
fema/e; 98% (1987 est.)','a656cc11cf79f852a68f0c0c8d5316708dc78348bd00885e21b4906ccd98d3ba','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cf0b64c82c7cab1c224558a864624eeca01779f6152351c38cbdd6ec5f827a0',2001,'TT','Trinidad and Tobago','people-and-society',968,'Population: 38,756 (July 2001 est.)
Age structure:
0-14 years: 29.84% (male 5,909; female 5,654)
15-64 years: 61 .37% (male 1 1 ,870; female 1 1 ,91 5)
65 years and over: 8.79% (male 1 ,406; female 2,002)
(2001 est.)
Population growth rate: -0.11% (2001 est.)
Birth rate: 18.78 births/1,000 population (2001 est.)
Death rate: 9.21 deaths/1 ,000 population
(2001 est.)
Net migration rate; -10.68 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.9S male(s)/fema!e (2001 est.)
Infant mortality rate: 1 6.28 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 7 1.01 years
male: 68.22 years
female: 73.97 years (2001 est.)
Total fertility rate: 2.41 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS; NA
HIV/AIDS -deaths; NA
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: predominantly black some British,
Portuguese, and Lebanese
Religions: Anglican, other Protestant, Roman
Catholic
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 98% (1980 est.)
Country name:
conventional long form: Federation of Saint Kitts and
Nevis
conventional short form: Saint Kitts and Nevis
former: Federation of Saint Christopher and Nevis
Government type: constitutional monarchy with
Westminster-style parliament
Capital: Basseterre
Administrative divisions: 14 parishes; Christ
Church NicholaTown, Saint Anne Sandy Point, Saint
George Basseterre, Saint George Gingerland, Saint
James Windward, Saint John Capisterre, Saint John
Figtree, Saint Mary Cayon, Saint Paul Capisterre,
Saint Paul Charlestown, Saint Peter Basseterre, Saint
Thomas Lowland, Saint Thomas Middle Island, Trinity
Palmetto Point
Independence: 19 September 1983 (from UK)
National holiday: Independence Day,
19 September (1983)
Constitution: 1 9 September 1 983
Legal system: based on English common law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Perlette
LOUISY (since September 1 997)
head of government: Prime Minister Dr. Denzil
DOUGLAS (since 6 July 1995) and Deputy Prime
Minister Sam CONDOR (since 6 July 1995)
cabinet: Cabinet appointed by the governor general in
consultation with the prime minister
elections: none; the monarch is hereditary; the
governor general is appointed by the monarch;
following legislative elections, the leader of the
majority party or leader of a majority coalition is
usually appointed prime minister by the governor
general; deputy prime minister appointed by the
governor general
Legislative branch: unicameral National Assembly
(14 seats, 3 appointed and 1 1 popularly elected from
single-member constituencies; members serve
five-year terms)
elections: last held 6 March 2000 (next to be held by
July 2005)
election results: percent of vote by party - NA%; seats
byparty-SKNLP8, CCM 2, NRP 1
Judicial branch: Eastern Caribbean Supreme Court
(based on Saint Lucia; one judge of the Supreme
Court resides in Saint Kitts and Nevis)
Political parties and leaders: Concerned Citizens
Movement or CCM [Vance AMORY]; Nevis Reformation
Party or NRP [Joseph PARRY]; People''s Action
Movement or PAM [Lindsey GRANT]; Saint Kitts and
Nevis Labor Party or SKNLP [Dr. Denzil DOUGLAS]
Political pressure groups and leaders: NA
International organization participation: ACP, C,
Caricom, CDB, ECLAC, FAO, G-77, IBRD, ICFTU,
ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, Interpol,
IOC, OAS, OECS, OPANAL, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WHO, WlPO, WTrO
429
Saint Kitts and Nevis (continued)
Diplomatic representation In the US:
chief of mission: Ambassador Dr. Osbert W. LIBURD
chancery: 3216 New Mexico Avenue NW,
Washington, DC 20016
telephone: [1] (202) 686-2636
FAX.- [1] (202) 686-5740
Diplomatic representation from the US: the US
does not have an embassy in Saint Kitts and Nevis;
the US Ambassador in Barbados is accredited to Saint
Kitts and Nevis
Flag description: divided diagonally from the lower
hoist side by a broad black band bearing two white,
five-pointed stars; the black band is edged in yellow;
the upper triangle is green, the lower triangle is red','7bf107a69963053b6087a0512b24147f863b5a6708dedb760dd20498b3c5d115','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa67cfb05c9cb9b7e405421c6c817ec0dcc7e3ee9761659bfca590197a2f258e',2001,'IT','Italy','people-and-society',986,'Population: 27,336 (July 2001 est.)
Age structure:
O-M years.* 15.88% (male 2,241; female 2,100)
15‘64 years: 67.94% (male 9,048; female 9,525)
65 years and over: 1 6.1 8% (male 1 ,902; female
2,520) (2001 est.)
Population growth rate: 1.45% (2001 est.)
Birthrate: 10.76 births/l, 000 population (2001 est.)
Death rate: 7.68 deaths/1,000 population
(2001 est.)
Net migration rate: 1 1 .45 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .09 male(s)/female
under 15 years: 07 male(s)/female
15‘64 years: 0.95 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 023 male(s)/female (2001 est.)
Infant mortality rate: 6.21 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 81 .23 years
male: 77.68 years
female: 85A years (2001 est.)
Total fertility rate: 1 .3 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy:
definition: age 10 and over can read and write
total population: 96%
male: 97%
fema/e.'' 95% (1976 est.)
Population: 165,034 (July 2001 est.)
Age structure:
0-14 years: 47.7% (male 39,857; female 38,859)
15-64 years: 48.28% (male 38,430; female 41 ,246)
65 years and over: 4.02% (male 3,034; female 3,608)
(2001 est.)
Population growth rate: 3.18% (2001 est.)
Birth rate: 42.74 births/1,000 population
(2001 est.)
Death rate: 7.54 deaths/1,000 population
(2001 est.)
Net migration rate: -3.38 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 48.96 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 65.59 years
ma/e.- 64.15 years
female: 67.07 years (2001 est.)
Total fertility rate: 6.02 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths; NA
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups: mestico, angolares (descendants of
Angolan slaves), forros (descendants of freed slaves),
servicais (contract laborers from Angola,
Mozambique, and Cape Verde), tongas (children of
servicais born on the islands), Europeans (primarily
Portuguese)
Religions: Christian 80% (Roman Catholic,
Evangelical Protestant, Seventh-Day Adventist)
Languages: Portuguese (official)
Literacy:
definition: age 15 and over can read and write
total population: 73%
male: 85%
fema/e; 62% (1991 est.)
Country name:
conventional long form: Democratic Republic of Sao
Tome and Principe
conventional short form: Sao Tome and Principe
local long form: Republica Democratica de Sao Tome
e Principe
local short form: Sao Tome e Principe
Government type; republic
Capital: Sao Tome
Administrative divisions: 2 provinces; Principe,
Sao Tome
note: Principe has had self-government since 29 April
1995
Independence: 12 July 1975 (from Portugal)
National holiday: Independence Day, 12 July
(1975)
Constitution: approved March 1990; effective
10 September 1990
Legal system: based on Portuguese legal system
and customary law; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Miguel TROVOADA (since
4 April 1991)
head of government: Prime Minister Guilherma
Posser da COSTA (since 30 December 1998)
cabinet: Council of Ministers appointed by the
president on the proposal of the prime minister
elections: president elected by popular vote for a
five-year term; election last held 30 June and 21 July
1996 (next to be held NA July 2001); prime minister
chosen by the National Assembly and approved by
the president
election results: Miguel TROVOADA reelected
president in Sao Tome''s second multiparty
presidential election; percent of vote - Miguel
TROVOADA 52.74%, Manuel Pinto da COSTA
47.26%
Legislative branch: unicameral National Assembly
or Assembleia Nacional (55 seats; members are
elected by direct popular vote to serve five-year terms)
elections: last held 8 November 1 998 (next to be held
NA November 2003)
election results: percent of vote by party -
MLSTP-PSD 56%, PCD 14.5%, ADI 29%; seats by
party - MLSTP-PSD 31 , AD1 1 6, PCD 8
Judicial branch: Supreme Court (judges are
appointed by the National Assembly)
Political parties and leaders; Independent
Democratic Action or ADI [Carlos NEVES]; Movement
for the Liberation of Sao Tome and Principe-Social
Democratic Party or MLSTP-PSD [Manuel Pinto Da
COSTA]; Party for Democratic Convergence or PCD
[Aldo BANDEIRA]: Democratic Renovation Party
[Armindo GRACA]; other small parties
Political pressure groups and leaders: NA
International organization participation: ACCT,
ACP, AfDB, CEEAC, EGA, FAO, G-77, IBRD, ICAO,
ICRM, IDA, IFAD, IFRCS, ILO, IMF, IMO, Intelsat
441
Sao Tome and Principe (continued)
(nonsignatory user), Interpol, IOC, lOM (observer),
ITU, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO,
UPU, WCL, WHO, WlPO, WMO, WToO, WTrO
(observer)
Diplomatic representation in the US: Sao Tome
and Principe does not have an embassy in the US, but
does have a Permanent Mission to the UN, headed by
First Secretary Domingos Augusto FERREIRA,
located at 122 East 42nd Street, Suite 1604, New
York, NY 10168, telephone [1] (212) 317-0533
Diplomatic representation from the US: the US
does not have an embassy in Sao Tome and Principe;
the Ambassador to Gabon is accredited to Sao Tome
and Principe on a nonresident basis and makes
periodic visits to the islands
Flag description: three horizontal bands of green
(top), yellow (double width), and green with two black
five-pointed stars placed side by side in the center of
the yellow band and a red isosceles triangle based on
the hoist side; uses the popular pan-African colors of
Population: 7,283,274 (July 2001 est.)
Age structure:
0-14 years: 1 6.97% (male 634,030; female 601 ,929)
15-64 years: 67.73% (male 2,505,450; female
2,427,408)
65 years and over: 15.3% (male 453,366; female
661,091) (2001 est.)
Population growth rate: 0.27% (2001 est.)
Birth rate: 10.12 births/1,000 population (2001 est.)
Death rate: 8.77 deaths/1 ,000 population (2001 est.)
Net migration rate: 1 .37 migrant(s)/1 ,000
population (2001 est.)
Sex ratio;
at birth: 05 male(s)/female
under 15 years: 05 male(s)/female
15-64 years: 1,03 male(s)/female
65 years and over: 0.69 ma!e(s)/female
total population: 0,97 male(s)/female (2001 est.)
Infant mortality rate: 4.48 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
totai population: 79.73 years
male: 76.85 years
female: 82.76 years (2001 est.)
Total fertility rate: 1 .47 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.46%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 17,000
(1999 est.)
HIV/AIDS- deaths: 150 (1999 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French 18%, Italian
10%, Romansch 1%, other 6%
Religions: Roman Catholic 46.1%, Protestant 40%,
other 5%, none 8.9% (1990)
Languages: German (official) 63.7%, French
(official) 19.2%, Italian (official) 7.6%, Romansch
0.6%, other 8.9%
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 980 est.)
male: NA%
female: NA%
Population: 16,728,808
note: in addition, there are about 38,200 people living
in the Israeli-occupied Golan Heights - 18,200 Arabs
(1 6,500 Druze and 1 ,700 Alawites) and about 20,000
Israeli settlers (July 2001 est.)
Age structure:
0-14 years: 39.92% (male 3,440,060; female
3,238,576)
15-64 years: 56.87% (male 4,868,816; female
4,644,870)
65 years and over: 3.21 % (male 261 ,036; female
275,450) (2001 est.)
Population growth rate: 2.54% (2001 est.)
Birth rate: 30.64 births/1 ,000 population (2001 est.)
Death rate: 5.21 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1,05 male(s)/female (2001 est.)
Infant mortality rate: 33.8 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 68.77 years
male: 67.63 years
female: 69.98 years (2001 est.)
Total fertility rate: 3.95 children born/woman
(2001 est.)
HIV/AIDS " adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic groups: Arab 90.3%, Kurds, Armenians, and
other 9.7%
Religions: Sunni Muslim 74%, Alawite, Druze, and
other Muslim sects 16%, Christian (various sects)
10%, Jewish (tiny communities in Damascus, Al
Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish, Armenian,
Aramaic, Circassian widely understood; French,
English somewhat understood
Literacy:
definition: age 15 and over can read and write
total population: 70.8%
male: 85.7%
fema/e.’ 55.8% (1997 est.)','059e0b791520af2ff531b0c8718bd16b59837dc54384722b580e9ca10fc7d464','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15b30b0e7a091454c0f34dcdb3ddcddb293a8c48221c015a54e0fc4a6adb2782',2001,'SC','Seychelles','people-and-society',991,'Population: 79,71 5 (July 2001 est.)
Age structure:
0- 14 years: 28.27% (male 1 1 ,367; female 1 1 , 1 67)
15-64 years: 65.47% (male 25,453; female 26,737)
65 years and over: 6.26% (male 1 ,673; female 3,31 8)
(2001 est.)
Population growth rate: 0.49% (2001 est.)
Birth rate: 17.66 births/1,000 population (2001 est.)
Death rale: 6.65 deaths/1 ,000 population
(2001 est.)
Net migration rate: -6.15 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 03 male(s)/female
under 15 years: 02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 17.3 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 70.69 years
mate.'' 65.17 years
femate; 76.37 years (2001 est.)
Total fertility rate: 1 .83 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychelles
Ethnic groups: Seychellois (mixture of Asians,
Africans, Europeans)
Religions: Roman Catholic 90%, Anglican 8%,
other 2%
Languages: English (official), French (official).
Creole
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 56%
femate; 60% (1971 est.)','4feb3745bdd072f756892113d563cd3f5e228c9c20bf056be2f12d20ea9f673c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f78738368745c306e34fb9c958b257ea794b3e9730df4f81b18c7a8a012007e4',2001,'SL','Sierra Leone','people-and-society',999,'Population: 5,426,618 (July 2001 est.)
Age structure:
0-14 years: 44.73% (male 1 ,190,207; female
1,237,326)
15-64 years: 52.12% (male 1 ,351 ,455; female
1,477,155)
65 years and over: 3.1 5% (male 84,364; female
86,111) (2001 est.)
Population growth rate: 3.61% (2001 est.)
Birth rate; 45.11 births/1,000 population (2001 est.)
Death rate: 19.1 9 deaths/1 ,000 population
(2001 est.)
Net migration rate: 10.23 migrant(s)/1 ,000
population (2001 est.)
note: by the end of 1999 refugees from Sierra Leone
are assumed to be returning
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: OM male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.98 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 1 46.52 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 45.6 years
male: 42.69 years
female: 43.61 years (2001 est.)
Total fertility rate: 6.01 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 2.99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 68,000
(1999 est.)
HIV/AIDS - deaths: 8,200 (1999 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne
30%, Mende 30%, other 30%), Creole 10%
(descendants of freed Jamaican slaves who were
settled in the Freetown area in the late-18th century),
refugees from Liberia''s recent civil war, small
numbers of Europeans, Lebanese, Pakistanis, and
Indians
Religions: Muslim 60%, indigenous beliefs 30%,
Christian 10%
Languages: English (official, regular use limited to
literate minority), Mende (principal vernacular in the
south), Temne (principal vernacular in the north), Krio
(English-based Creole, spoken by the descendants of
freed Jamaican slaves who were settled in the
Freetown area, a lingua franca and a first language for
10% of the population but understood by 95%)
Literacy:
definition: age 1 5 and over can read and write English,
Mende, Temne, or Arabic
total population: 31 .4%
male: 45.4%
fema/e; 18,2% (1995 est.)','b50f251861deb542a5757d0c8c4b61dd9140ac79e1588d524a2988e64bc8ecf3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('397d42ccb3f7f031a738f8adcf37a24345971fd9779b5ee27b63351f0eb769fd',2001,'SB','Solomon Islands','people-and-society',1016,'Population: 480,442 (July 2001 est.)
Age structure.
0^14 years. 43.79% (male 107,229; female 103,162)
15-64 years. 53.15% (male 129,315; female 126,021 )
65 years and over. 3.06% (male 7,1 90; female 7,525)
(2001 est.)
Population growth rate. 2.98% (2001 est.)
Birth rate. 34.05 births/1,000 population (2001 est.)
Death rate. 4.27 deaths/1,000 population (2001 est.)
Net migration rate, 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio.
at birth. 1.05 male(s)/female
under 15 years. 1.04 male(s)/female
15-64 years. 1.03 male(s)/female
65 years and over. 0.96 male(s)/female
total population. 1.03 male(s)/female (2001 est.)
Infant mortality rate. 24.47 deaths/1,000 live births
(2001 est.)
Life expectancy at birth.
total population. 71.55 years
male. 69.12 years
female. 74.1 years (2001 est.)
Total fertility rate. 4.65 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate. NA%
HIV/AIDS ■ people living with HIV/AIDS. NA
HIV/AIDS - deaths. NA
Nationality.
noun. Solomon Islander(s)
adjective. Solomon Islander
Ethnic groups. Melanesian 93%, Polynesian 4%,
Micronesian 1.5%, European 0.8%, Chinese 0.3%,
other 0.4%
Religions. Anglican 34%, Roman Catholic 19%,
Baptist 17%, United (Methodist/Presbyterian) 11%,
Seventh-Day Adventist 10%, other Protestant 5%,
indigenous beliefs 4%
Languages. Melanesian pidgin in much of the
country is lingua franca, English spoken by 1%-2% of
population
note. 120 indigenous languages
Literacy.
definition. NA
total population. NA%
male. NA%
female. NA%','23141d7a7120c5029eb21259ee4f4428b6ea3754b621af5e80a3cbed47008020','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85df0af86fcfae6ae18a14d04f99626031c89c8fbdf95504daae9046d5f9f64d',2001,'SO','Somalia','people-and-society',1024,'Population: 7,488,773
note: this estimate was derived from an official census
taken in 1975 by the Somali Government; population
counting in Somalia is complicated by the large
number of nomads and by refugee movements in
response to famine and clan warfare (July 2001 est.)
Age structure:
0-14 years: 44.54% (male 1,670,320; female
1,665,329)
15-64 years: 52.69% (male 1 ,993,750; female
1,952,437)
65 years and over: 2.77% (male 91,511; female
115,426) (2001 est.)
Population growth rate: 3.48% (2001 est.)
Birth rate: 47.23 births/1,000 population (2001 est.)
Death rate: 18.35 deaths/1 ,000 population
(2001 est.)
Net migration rate: 5.96 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1.01 male(s)/female (2001 est.)
Infant mortality rate: 1 23.97 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 46.6 years
male: 44.99 years
female: 48.25 years (2001 est.)
Total fertility rate: 7.11 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS; NA
HIV/AIDS -deaths: NA
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic groups: Somali 85%, Bantu, Arabs 30,000
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy:
definition: age 15 and over can read and write
total population: 24%
male: 36%
female: 14% (1990 est.)','6313fd363c7b25be5455ae4787163ca1368a7e2b033f2503116b97a3a8d12525','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71160fff6784555e3fa9cf472580110fe7a46b8025f51d29412d50b55ae93581',2001,'ES','Spain','people-and-society',1035,'Population: 40,037,995 (July 2001 est.)
Age structure:
0-14 years: U.62% (male 3,015,851; female
2,835,763)
15-64 years: 68.2% (male 13,701 ,065; female
13,605,314)
65 years and over: 17.18% (male 2,881 ,334; female
3,998,668) (2001 est.)
Population growth rate: 0.1% (2001 est.)
Birth rate: 9.26 births/1,000 population (2001 est.)
Death rate: 9.13 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0.87 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.% male(s)/female (2001 est.)
Infant mortality rate: 4.92 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 78.93 years
male: 75.47 years
female: 82.62 years (2001 est.)
Total fertility rate: 1.15 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.58%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 120,000
(1999 est.)
HIV/AIDS -deaths: 2,000 (1999 est.)
Nationality;
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and
Nordic types
Religions: Roman Catholic 99%, other 1%
Languages: Castilian Spanish (official) 74%,
Catalan 17%, Galician 7%, Basque 2%
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: NA%
female: NA%','484ba315c4437382f141d6421e3ed3fae6a4335575e1a8a10dbcc6d7981d2fab','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88bc7efeede07d3ead5b7cefd67e22ba11360cadda341e9cc0ed8ed426510c77',2001,'LK','Sri Lanka','people-and-society',1043,'Population: 19,408,635 (July 2001 est.)
note: since the outbreak of hostilities between the
government and armed Tamil separatists in the
mid-1980s, several hundred thousand Tamil civilians
have fled the island; as of mid-1999, approximately
66,000 were housed in 133 refugee camps in south
India, another 40,000 lived outside the Indian camps,
and more than 200,000 Tamils have sought refuge in
the West
Age structure:
0-M years; 25.99% (male 2,578,618; female
2,464,928)
15-64 years: 67.39% (male 6,369,881 ; female
6,708,852)
65 years and over: 6.62% (male 61 5,253; female
671,103) (2001 est.)
Population growth rate: 0.87% (2001 est.)
Birth rate: 16.58 births/1 ,000 population (2001 est.)
Death rate: 6.43 deaths/1 ,000 population
(2001 est.)
Net migration rate: -1.43 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1. OS male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 0,97 male(s)/female (2001 est.)
Infant mortality rate: 16.08 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 72.09 years
male: 69.58 years
fema/e; 74.73 years (2001 est.)
Total fertility rate: 1 .95 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,500
(1999 est.)
HIV/AIDS ■ deaths: 490 (1999 est.)
Nationality:
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 74%, Tamil 18%, Moor
7%, Burgher, Malay, and Vedda 1%
Religions: Buddhist 70%, Hindu 15%, Christian 8%,
Muslim 7% (1999)
Languages: Sinhala (official and national language)
74%, Tamil (national language) 18%, other 8%
note: English is commonly used in government and is
spoken competently by about 10% of the population
Literacy:
definition: age 15 and over can read and write
total population: 90.2%
male: 93.4%
fema/e: 87.2% (1995 est.)','edc87528fbead7132ff7e7ab9212c12673491da4734b3de00292773ea42a299e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a70fbd37fbfdab6a7d282d31aac78d56ae8d77335b21daea6ab3e3547161cbb2',2001,'SD','Sudan','people-and-society',1052,'Population: 36,080,373 (July 2001 est.)
Age structure:
0-14 years: 44.62% (male 8,227,01 1 ; female
7,870,783)
15-64 years: 53.29% (male 9,619,218; female
9,608,469)
65 years and over: 2.09% (male 425,898; female
328,994) (2001 est.)
Population growth rate: 2.79% (2001 est.)
Birth rate: 37.89 births/1,000 population (2001 est.)
Death rate: 10.04 deaths/1 ,000 population (2001 est.)
Net migration rate: 0.04 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1 .29 male(s)/female
total population: 1 .03 male(s)/female (2001 est.)
Infant mortality rate: 68.67 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 56.94 years
male: 55.85 years
female: 58,08 years (2001 est.)
Total fertility rate: 5.35 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
474
Sudan (continued)
Ethnic groups: black 52%, Arab 39%, Beja 6%,
foreigners 2%, other 1%
Reiigions: Sunni Muslim 70% (in north), indigenous
beliefs 25%, Christian 5% (mostly in south and
Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie,
diverse dialects of Nilotic, Nilo-Hamitic, Sudanic
languages, English
note: program of "Arabization" in process
Literacy:
definition: age 15 and over can read and write
total population: 46A7o
male: 57.7%
fema/e; 34.6% (1995 est.)','375a22040e1bd4c321708060dbaa26f91f8a904fa1c99c3d816f53fbf1c5ca30','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b488df12c44f2103d7822b39fe81581879947dde4b833f2385806c578bf3aa38',2001,'GY','Guyana','people-and-society',1061,'Population: 433,998 (July 2001 est.)
Age structure:
0’14 years: 31.62% (male 70,314; female 66,924)
15-64 years: 62.71 % (male 1 38,969; female 1 33,1 93)
65 years and over: 5.67% (male 1 1 ,1 94; female
13,404) (2001 est.)
Population growth rate: 0.6% (2001 est.)
Birth rate: 20.53 births/1,000 population (2001 est.)
Death rate: 5.68 deaths/1 ,000 population
(2001 est.)
Net migration rate: -8.87 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.03 male(s)/female (2001 est.)
Infant mortality rate: 24.27 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 71 .63 years
male: 68.97 years
fema/e; 74.42 years (2001 est.)
Total fertility rate: 2.47 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 1 .26%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS - deaths: 210 (1999 est.)
Nationality:
noun;Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as
"East Indians"; their ancestors emigrated from
northern India in the latter part of the 19th century)
37%, Creole (mixed white and black) 31%, Javanese
1 5%, "Maroons" (their African ancestors were brought
to the country in the 1 7th and 1 8th centuries as slaves
and escaped to the interior) 10%, Amerindian 2%,
Chinese 2%, white 1%, other 2%
Religions: Hindu 27.4%, Muslim 19.6%, Roman
Catholic 22.8%, Protestant 25.2% (predominantly
Moravian), indigenous beliefs 5%
Languages: Dutch (official), English (widely
spoken), Sranang Tongo (Surinamese, sometimes
called Taki-Taki, is native language of Creoles and
much of the younger population and is lingua franca
among others), Hindustani (a dialect of Hindi),
Javanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
maie: 95%
fema/e;91%(1995 est.)
Population: 2,332 (July 2001 est.)
Age structure:
0-/4 years; NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -3.55% (2001 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: 0% (2001)
HIV/AIDS - people living with HIV/AIDS: 0 (2001)
HIV/AIDS - deaths: 0(2001)
Ethnic groups: Norwegian 55.4%, Russian and
Ukrainian 44.3%, other 0.3% (1998)
Languages: Russian, Norwegian','4395f5e1161a0be8053f1ccc946965e33e7739c8dd729699df87b9b71491dd7c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea4dd1044a65395c3838c906a1c2d5dc2b63d425690346e3b5eb176648691927',2001,'PK','Pakistan','people-and-society',1067,'Population: 6,578,681 (July 2001 est.)
Age structure:
0-14 years: 41.18% (male 1,367,194; female
1,341,967)
15-64 years: 54.22% (male 1 ,773,605; female
1,793,345)
65 years and over: 4.6% (male 1 31 ,009; female
171,561) (2001 est.)
Population growth rate: 2.12% (2001 est.)
Birth rate: 33.23 births/1,000 population (2001 est.)
Death rate: 8.57 deaths/1 ,000 population
(2001 est.)
Net migration rate: -3.49 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years; 0.99 male(s)/female
491
Tajikistan (continued)
65 years and over: 0.76 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 1 1 6.09 deaths/l ,000 live
births (2001 est.)
Life expectancy at birth;
total population: 64.1 8 years
ma/e.‘ 61.09 years
female: 67.42 years (2001 est.)
Total fertility rate: 4.29 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
r?oun.‘Tajikistani(s)
acfjecf/Ve; Tajikistan!
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian
3.5% (declining because of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in
government and business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
fema/e;97%(1989 est.)
Population: 36,232,074
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 44.76% (male 8,152,438; female
8,063,520)
15-64 years: 52.35% (male 9,387,737; female
9,581,518)
65 years and over: 2.89% (male 473,498; female
573,363) (2001 est.)
Population growth rate: 2.61% (2001 est.)
Birth rate: 39.65 births/1,000 population (2001 est.)
Death rate: 12.95 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.64 migrant{s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: ^.03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 79.41 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 51 .98 years
male: 51 .04 years
female: 52.95 years (2001 est.)
Total fertility rate: 5.42 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 8.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .3
million (1999 est.)
HIV/AIDS - deaths: 1 40,000 (1 999 est.)
Nationality:
noun;Tanzanian(s)
adjective: Tanzanian
Ethnic groups: mainland - native African 99% (of
which 95% are Bantu consisting of more than 130
tribes), other 1% (consisting of Asian, European, and
Arab); Zanzibar - Arab, native African, mixed Arab
and native African
Religions: mainland - Christian 45%, Muslim 35%,
indigenous beliefs 20%; Zanzibar - more than 99%
Muslim
Languages: Kiswahili or Swahili (official), Kiunguju
(name for Swahili in Zanzibar), English (official,
primary language of commerce, administration, and
higher education), Arabic (widely spoken in Zanzibar),
many local languages
note: Kiswahili (Swahili) is the mother tongue of the
Bantu people living in Zanzibar and nearby coastal
Tanzania; although Kiswahili is Bantu in structure and
origin, its vocabulary draws on a variety of sources,
including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first
language of most people is one of the local
languages
Literacy:
definition: age 15 and over can read and write
Kiswahili (Swahili), English, or Arabic
total population: 67.8%
male: 79.4%
female: 56.8% (1995 est.)','899b022f81cd50470931eb1a5414c39482262b887e5fd947a5c1b5927b5c952e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e05aae4d4c4bd3076443726cf47bd75680635c801f92c48c5cc5ac06cd808fde',2001,'TV','Tuvalu','people-and-society',1081,'Population: 10,991 (July 2001 est.)
Age structure:
0-14 years: 33.28% (male 1 ,862; female 1 ,796)
15-64 years: 61 .6% (male 3,241 ; female 3,529)
65 years and over: 5.12% (male 236; female 327)
(2001 est.)
Population growth rate: 1.4% (2001 est.)
Birth rate: 21 .56 births/1 ,000 population
(2001 est.)
Death rate: 7.55 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.72 male(s)/female
total population: OM male(s)/female (2001 est.)
Infant mortality rate: 22.65 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 66.65 years
male: 64.52 years
female: 68.88 years (2001 est.)
Total fertility rate: 3.09 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun; Tuvaluan(s)
adjective: Tuvaluan
Ethnic groups: Polynesian 96%
Religions: Church of Tuvalu (Congregationalist)
97%, Seventh-Day Adventist 1 .4%, Baha''i 1%, other
0.6%
Languages: Tuvaluan, English
Literacy:
definition: NA
total population:
male: NA%
female: NA%
Population: 23,985,712
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0‘14 years: 51 .08% (male 6,150,038; female
6,100,880)
15-64 years: 46.78% (male 5,613,499; female
5,607,526)
65 years and over: 2.1 4% (male 244,21 6; female
269,553) (2001 est.)
Population growth rate: 2.93% (2001 est.)
Birth rate: 47.52 births/1,000 population (2001 est.)
Death rate: 17.97 deaths/1 ,000 population
(2001 est.)
Net migration rate; -0.29 migrant(s)/1 ,000
population (2001 est.)
note: according to the UNHCR, by the end of 1999,
Uganda was host to 21 8,000 refugees from a number
of neighboring countries, including: Sudan 200,600,
Rwanda 8,000, and Democratic Republic of the
Congo 8,000
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.0^ male(s)/female
15-64 years: 1 male(s)/female
65 years ancf over; 0.91 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 91 .3 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 43.37 years
male: 42.59 years
fema/e; 44.17 years (2001 est.)
Total fertility rate; 6.88 children born/woman
(2001 est.)
HIV/AIDS ■ adult prevalence rate: 8.3% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 820,000
(1999 est.)
HIV/AIDS - deaths: 1 1 0,000 (1 999 est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Karamojong 12%,
Basogo 8%, Iteso 8%, Langi 6%, Rwanda 6%, Bagisu
5%, Acholi 4%, Lugbara 4%, Bunyoro 3%, Batoro 3%,
non-African (European, Asian, Arab) 1%, other 23%
Religions: Roman Catholic 33%, Protestant 33%,
Muslim 16%, indigenous beliefs 18%
Languages: English (official national language,
taught in grade schools, used in courts of law and by
most newspapers and some radio broadcasts),
Ganda or Luganda (most widely used of the
Niger-Congo languages, preferred for native
language publications in the capital and may be taught
in school), other Niger-Congo languages,
Nilo-Saharan languages, Swahili, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 61.8%
male: 73.7%
female: 50.2% (1995 est.)
Population: 48,760,474 (July 2001 est.)
Age structure:
0-14 years: 17.3% (male 4,310,158; female
4,127,677)
15-64 years: m.57% (male 15,965,079; female
17,468,035)
65 years and over: 14.13% (male 2,275,004; female
4,614,521) (2001 est.)
Population growth rate: -0.78% (2001 est.)
Birth rate: 9.31 births/1,000 population (2001 est.)
Death rate: 16.43 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.63 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 06 male(s)/female
under 15 years:]. 04 male(s)/female
)5-54 years.* 0.91 male(s)/female
65 years and over: 0.49 ma!e(s)/female
total population: O.QO male(s)/female (2001 est.)
Infant mortality rate: 21 .4 deaths/l ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 66. 1 5 years
male: 60.62 years
female: 71 .96 years (2001 est.)
Total fertility rate: 1 .29 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.96%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS -deaths: 4,000 (1999 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 73%, Russian 22%,
Jewish 1%, other 4%
Religions: Ukrainian Orthodox - Moscow
Patriarchate, Ukrainian Orthodox - Kiev Patriarchate,
Ukrainian Autocephalous Orthodox, Ukrainian
Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish,
Hungarian
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 100%
fema/e;97%(1989 est.)','818c8646c69d086aa288a54d1a47085bb8e410fa079aaa172f11d884619da08e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('252091b7d16cf6444313aacf011da07f563eba44a08cce61b5d986c0836021f8',2001,'OM','Oman','people-and-society',1090,'Population: 2,407,460
note: includes 1,576,472 non-nationals (July
2001 est.)
Age structure:
0-14 years: 28.86% (male 354,298; female 340,498)
15-64 years: 68.74% (male 1 ,047,839; female 607,020)
65 years and over: 2.4% (male 40,626; female
17,179) (2001 est.)
Population growth rate: 1.59% (2001 est.)
Birthrate: 18.11 births/1 ,000 population (2001 est.)
Death rate: 3.79 deaths/1 ,000 population
(2001 est.)
Net migration rate: 1.61 migrant(s)/1,000
population (2001 est.)
United Arab Emirates (continued)
Sex ratio:
at birth: t05 male(s)/female
under 15 years: 1.04 male(s)/fema!e
15-64 years: 1 73 male(s)/female
65 years and over: 2.36 male(s)/female
total population: 1 .5 male(s)/female (2001 est.)
Infant mortality rate: 1 6.68 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 74.29 years
ma/e; 71.84 years
female: 70.60 years (2001 est.)
Total fertility rate: 3.23 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.18%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Emirati(s)
adjective: Emirati
Ethnic groups: Emirati 19%, other Arab and Iranian
23%, South Asian 50%, other expatriates (includes
Westerners and East Asians) 8% (1982)
note: less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian,
Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi,
Urdu
Literacy:
definition: age 15 and over can read and write
total population: 79.2%
male: 78.9%
fema/e; 79.8% (1995 est.)','49d67b6d6d087b7110caa2f4fe784fd62b64aef0c771618939093392b3ac3a0f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7f80a5ba12addea52d3abdf17bd9915fbe340f106b3af18ce5b11b6ff2811a0',2001,'UY','Uruguay','people-and-society',1102,'Population: 3,360,105 (July 2001 est.)
Age structure:
0-14 years: 2A.39% (male 419,932; female 399,605)
15-64 years: 62.61% (male 1 ,038,785; female
1,064,891)
65 years and over: 13% (male 180,130; female
256,762) (2001 est.)
Population growth rate: 0.78% (2001 est.)
Birth rate: 17.36 births/1,000 population (2001 est.)
Death rate: 9.03 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.51 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 14.7 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 75.44 years
male: 72.11 years
female: 78.96 years (2001 est.)
Total fertility rate: 2.36 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.33%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 6,000
(1999 est.)
HIV/AIDS - deaths: 150 (1999 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%,
Amerindian, practically nonexistent
Religions: Roman Catholic 66% (less than one-half
of the adult population attends church regularly),
Protestant 2%, Jewish 1%, nonprofessing or other
31%
Languages: Spanish, Portunol, or Brazilero
(Portuguese-Spanish mix on the Brazilian frontier)
Literacy:
definition: age 15 and over can read and write
total population: 97.3%
male: 96.9%
fema/e.'' 97.7% (1995 est.)','a28ed4c98380de850ac1e1f2c913effea08d5ceb302ad0abca967620a64e6da9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b472449aeed9fd87b47ebb0bd8d5060128c7ebead2d153eda0033d7e1ffe2005',2001,'UZ','Uzbekistan','people-and-society',1109,'Population: 25,155,064 (July 2001 est.)
Age structure:
0-14 years: 36.32% (male 4,646,341; female
4,489,265)
15-64 years: 59.06% (male 7,351 ,908; female
7,504,626)
65 years and over: 4.62% (male 466,029; female
696,895) (2001 est.)
Population growth rate: 1 .6% (2001 est.)
Birth rate: 26.1 births/1,000 population (2001 est.)
Death rate: 8 deaths/1 ,000 population (2001 est.)
Net migration rate: -2.06 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.93 male(s)/female (2001 est.)
Infant mortality rate: 71 .92 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 33.31 years
male: 60.24 years
female: 37.53 years (2001 est.)
Total fertility rate: 3.06 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Uzbekistani(s)
adjective: Uzbekistan!
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik
5%, Kazakh 3%, Karakalpak 2.5%, Tatar 1.5%, other
2.5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern
Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik
4.4%, other 7.1%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (yearend 1996)','a77e13d04eaa28b09c02a92b2e5aed7b257ac618715219c47189dac2f05d5dcd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aced0c9a426f4c6d184225d5d56906598933b038f3466496d97bf947eb96e3e2',2001,'AF','Afghanistan','people-and-society',1117,'Population: 192,910 (July 2001 est.)
Age structure:
0-14 years: 36.35% (male 35,822; female 34,299)
15-64 years: 60.43% (male 59,764; female 56,808)
65 years and over: 3.22% (male 3,348; female 2,869)
(2001 est.)
Population growth rate: 1 .7% (2001 est.)
Birth rate: 25.4 births/1 ,000 population (2001 est.)
Death rate: 8.38 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1 .17 male(s)/female
total population: 1.05 male(s)/female (2001 est.)
Infant mortality rate: 61 .05 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 60.95 years
male: 59.58 years
female: 62.39 years (2001 est.)
Total fertility rate: 3.19 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic groups: indigenous Melanesian 94%,
French 4%, Vietnamese, Chinese, Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%,
Roman Catholic 15%, indigenous beliefs 7.6%,
Seventh-Day Adventist 6.2%, Church of Christ 3.8%,
other 15.7%
Languages: English (official), French (official),
pidgin (known as Bislama or Bichelama)
Literacy:
definition: age 15 and over can read and write
total population: 53%
male: 57%
female: 48% {im est.)
Population: 23,916,810 (July 2001 est.)
Age structure:
0-14 years: 32^^% (male 3,962,517; female
3,716,880)
15-64 years: 63.17% (male 7,581 ,589; female
7,526,467)
65 years and over: 4.72% (male 515,687; female
613,670) (2001 est.)
Population growth rate: 1.56% (2001 est.)
Birth rate: 20.65 births/1,000 population (2001 est.)
Death rate: 4.92 deaths/1,000 population
(2001 est.)
Net migration rate: -0.15 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .02 male(s)/female (2001 est.)
Infant mortality rate: 25.37 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 73.3) years
male: 70.29 years
female: 76.56 years (2001 est.)
Total fertility rate: 2.46 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.49%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 62,000
(1999 est.)
HIV/AIDS ■ deaths: 2,000 (1999 est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: Spanish, Italian, Portuguese, Arab,
German, African, indigenous people
Religions; nominally Roman Catholic 96%,
Protestant 2%, other 2%
Languages: Spanish (official), numerous indigenous
dialects
Literacy:
definition: age 15 and over can read and write
totalpopuiation:9).)%
mate; 91.8%
femate; 90.3% (1995 est.)
Population; 79,939,014 (July 2001 est.)
Age structure:
0-14 years: 32.13% (male 13,266,585; female
12,415,384)
15-64 years: 62.44% (male 24,357,343; female
25,556,187)
65 years and over: 5.43% (male 1 ,722,094; female
2,621,421) (2001 est.)
Population growth rate: 1.45% (2001 est.)
Birthrate: 21 .23 births/1 ,000 population (2001 est.)
Death rate: 6.22 deaths/1,000 population
(2001 est.)
Net migration rate: -0.49 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.97 male(s)/female (2001 est.)
Infant mortality rate: 30.24 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 69.56 years
ma/e; 67.12 years
female: 72.19 years (2001 est.)
Total fertility rate: 2.49 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.24%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS; 100,000
(1999 est.)
HIV/AIDS - deaths: 2,500 (1999 est.)
Nationality:
noun: Vietnamese (singular and plural)
ad/ecf/Ve; Vietnamese
Ethnic groups: Vietnamese 85%-90%, Chinese,
Hmong, Thai, Khmer, Cham, mountain groups
Religions: Buddhist, Hoa Hao, Cao Dai, Christian
(predominantly Roman Catholic, some Protestant),
indigenous beliefs, Muslim
Languages: Vietnamese (official), English
(increasingly favored as a second language), some
French, Chinese, and Khmer; mountain area
languages (Mon-Khmer and Malayo-Polynesian)
Literacy:
definition: age 15 and over can read and write
total population: 93.7%
male: 96.5%
fema/e;91.2%(1995 est.)','81d4ae6119bc4cdbd15a2fbc6c080fd243bf9cc95bce24a1bda4e2f4a63c9224','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a620fa7d71f7523e7efb46d22802c44ea2ff22ecea4598530cb0c722f8eea97a',2001,'PR','Puerto Rico','people-and-society',1123,'Population: 122,211 (July 2001 est.)
Age structure:
0-1 4 years: 27 27% (male 17,121; female 16,204)
15-64 years: 63.92% (male 35,391 ; female 42,727)
65 years and over: 8.81% (male 4,638; female 6,130)
(2001 est.)
Population growth rate: 1.06% (2001 est.)
Birth rate: 15.9 births/1,000 population (2001 est.)
Death rate: 5.47 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0.12 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.83 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0. SO male(s)/female (2001 est.)
Infant mortality rate: 9.43 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 7S27 years
male: 74.SS years
female: 82.39 years (2001 est.)
Total fertility rate: 2.25 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun; Virgin Islander(s)
ad/eof/Ve; Virgin Islander
Ethnic groups: black 80%, white 15%, other 5%
note: West Indian (45% born in the Virgin Islands and
29% born elsewhere in the West Indies) 74%, US
mainland 13%, Puerto Rican 5%, other 8%
Religions: Baptist 42%, Roman Catholic 34%,
Episcopalian 17%, other 7%
Languages: English (official), Spanish, Creole
Literacy:
definition: NA
total population: HA%
male: NA%
female: NA%','4d048b7eb44c2f5f3ff9624b8b33b010a7ded09842e92fb6362074799547bb68','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5364da6d9965a63503ad3a5ec15be875544df94f4a34a9644bf33539745715d',2001,'MP','Northern Mariana Islands','people-and-society',1129,'Population: no indigenous inhabitants
note: US military personnel have left the island, but
civilian personnel remain; as of December 2000, one
US Army civilian and 1 23 civilian contractor personnel
were present (January 2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA','8fb5a039cbb13cec1df482a6202254befe1442426f7db1a0aa7a950b7a5f13f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5fbb3bcfb5b541e620f1766a8be28daac9deea396a206969336420f26a49f33',2001,'YE','Yemen','people-and-society',1135,'Population: 18,078,035 (July 2001 est.)
Age structure:
0-/4 years: 47.21 % (male 4,340,436; female
4,195,076)
15-64 years: 49.79% (male 4,598,301 ; female
4,402,402)
65 years and over: 3% (male 274,202; female
267,618) (2001 est.)
Population growth rate: 3.38% (2001 est.)
Birth rate: 43.36 births/1,000 population (2001 est.)
Death rate: 9.58 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1 .04 male(s)/female (2001 est.)
Infant mortality rate: 68.53 deaths/1 ,000 live births
(2001 est.)
555
Yemen (continued)
Life expectancy at birth:
total population: 6021 years
male: 58.45 years
female: 62.05 years (2001 est.)
Total fertility rate: 6.97 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun; Yenneni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; but also
Afro-Arab, South Asians, Europeans
Religions: Muslim including Shafi (Sunni) and Zaydi
(Shi''a), small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 53%
fema/e;26%(1990 est.)
Population: 10,677,290
note: all data dealing with population is subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2001 est.)
Age structure:
O’Uyears: 19.8% (male 1,095,905; female
1,024,123)
15-64 years: 65.3% (male 3,415,728; female
3,553,343)
65 years and over: 14.9% (male 681 ,559; female
906,632) (2001 est.)
Population growth rate: -0.27% (2001 est.)
Birth rate; 12.61 births/1,000 population (2001 est.)
Death rate: 1 0.54 deaths/1 ,000 population
(2001 est.)
Net migration rate: -4.71 migrant(s)/1 ,000
population (2001 est.)
Sex ratio;
at birth: 1 .08 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years; 0.96 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.95 male(s)/female (2001 est.)
Infant mortality rate: 17.42 deaths/1,000 live births
(2001 est.)
Life expectancy at birth;
total population: 73.5 years
male: 70.57 years
female: 76.67 years (2001 est.)
Total fertility rate; 1 .75 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Serb{s)] Montenegrin(s)
adjective: Serbian; Montenegrin
Ethnic groups: Serb 62.6%, Albanian 16.5%,
Montenegrin 5%, Hungarian 3.3%, other 12.6%
(1991)
Religions: Orthodox 65%, Muslim 19%, Roman
Catholic 4%, Protestant 1%, other 11%
Languages: Serbian 95%, Albanian 5%
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 97.2%
tomato: 88.9% (1991)','f72bcb80cab83f409bbe16aff4fc30449b48afd1fa2445f5585aab9a345254f5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4bab53bdb2c3154dd6f9850c98a5678d70a5dc7ddf3d3a779e45ca15794100',2001,'ZM','Zambia','people-and-society',1144,'Population: 9,770,199
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 47 (male 2,324,128; female
2,303,349)
15-64 years: 50.14% (male 2,433,250; female
2,465,747)
65 years and over: 2.5% (male 105,694; female
138,031) (2001 est.)
Population growth rate: 1.93% (2001 est.)
Birth rate: 41.46 births/1,000 population (2001 est.)
Death rate: 21 .97 deaths/1 ,000 population
(2001 est.)
Net migration rate: -0.16 migrant(s)/1, 000
population (2001 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-54 years.'' 0.99 male(s)/female
55 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 90.89 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 37.29 years
male: 37.06 years
female: 37.53 years (2001 est.)
Totai fertility rate: 5.53 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 19.95%
(1999 est.)
HIV/AIDS “ people living with HIV/AIDS: 870,000
(1999 est.)
HIV/AIDS - deaths: 99,000 (1999 est.)
Nationality:
noun: Zambian(s)
ac}ecf/Ve; Zambian
Ethnic groups: African 98.7%, European 1.1%,
other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu
24%-49%, indigenous beliefs 1%
Languages: English (official), major vernaculars -
Bemba, Kaonda, Lozi, Lunda, Luvale, Nyanja, Tonga,
and about 70 other indigenous languages
Literacy:
definition: age 15 and over can read and write English
total population: 78.2%
male: 85.6%
fema/e;71.3%(1995 est.)
Population: 11,365,366
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2001 est.)
Age structure:
0-14 years: 38.68% (male 2,223,332; female
2,172,479)
15-64 years: 57.69% (male 3,319,982; female
3,236,286)
65 years and over: 3.63% (male 208,785; female
204,502) (2001 est.)
Population growth rate: 0.15% (2001 est.)
Birth rate: 24.68 births/1,000 population (2001 est.)
Death rate: 23.22 deaths/1,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2001 est.)
note: there is a small but steady flow of Zimbabweans
into South Africa in search of better paid employment
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: t02 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 62.61 deaths/1 ,000 live births
(2001 est.)
Life expectancy at birth:
total population: 37.1 3 years
male: 38.51 years
female: 35.7 years (2001 est.)
Total fertility rate: 3.28 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 25.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .5
million (1999 est.)
HIV/AIDS - deaths: 1 60,000 (1 999 est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona71%, Ndebele
16%, other 11%), mixed and Asian 1%, white less
than 1%
Religions: syncretic (part Christian, part indigenous
beliefs) 50%, Christian 25%, indigenous beliefs 24%,
Muslim and other 1%
Languages: English (official), Shona, Sindebele (the
language of the Ndebele, sometimes called Ndebele),
numerous but minor tribal dialects
Literacy:
definition: age 15 and over can read and write
English
total population:
male: 90%
fema/e.'' 80% (1995 est.)','d3b8c8e02b9e5253cd268e470b4b27c62ba2610d583765a8015c734b58b83b3b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b563c5ea9c489a82e83a6a718781f7489be31ece07218a8ab5a8fb25d6b8ee7',2001,'WF','Wallis and Futuna','people-and-society',15,'This category includes the entries dealing with the characteristics of
the people and their society.
People - note
This entry includes miscellaneous demographic information of
significance not included elsewhere.
Personal Names - Capitalization
The Factbook capitalizes the surname or family name of individuals for
the convenience of our users who are faced with a world of different
cultures and naming conventions. An example would be President SADDAM
Husayn of Iraq. Saddam is his name and Husayn is his father''s name. He
may be referred to as President SADDAM Husayn or President SADDAM, but
not President Husayn. The need for capitalization, bold type,
underlining, italics, or some other indicator of the individual''s
surname is apparent in the following examples: MAO Zedong, Fidel
CASTRO Ruz, George W. BUSH, and TUNKU SALAHUDDIN Abdul Aziz Shah ibni
Al-Marhum Sultan Hisammuddin Alam Shah. By knowing the surname, a
short form without all capital letters can be used with confidence as
in President Saddam, President Castro, Chairman Mao, President Bush, or
Sultan Tunku Salahuddin. The same system of capitalization is extended
to the names of leaders with surnames that are not commonly used such
as Queen ELIZABETH II.
Personal Names - Spelling
The romanization of personal names in the Factbook normally follows the
same transliteration system used by the US Board on Geographic Names
for spelling place names. At times, however, a foreign leader
expressly indicates a preference for, or the media or official
documents regularly use, a romanized spelling that differs from the
transliteration derived from the US Government standard. In such
cases, the Factbook uses the alternative spelling.
Personal Names - Titles
The Factbook capitalizes any valid title (or short form of it)
immediately preceding a person''s name. A title standing alone is
lowercased. Examples: President PUTIN and President BUSH are chiefs of
state. In Russia, the president is chief of state and the premier is
the head of the government, while in the US, the president is both
chief of state and head of government.
Pipelines
This entry gives the lengths and types of pipelines for transporting
products like natural gas, crude oil, or petroleum products.
Political parties and leaders
This entry includes a listing of significant political organizations
and their leaders.
Political pressure groups and leaders
This entry includes a listing of organizations with leaders involved in
politics, but not standing for legislative election.
Population
This entry gives an estimate from the US Bureau of the Census based on
statistics from population censuses, vital statistics registration
systems, or sample surveys pertaining to the recent past and on
assumptions about future trends. The total population presents one
overall measure of the potential impact of the country on the world and
within its region. Note: starting with the 1993 Factbook, demographic
estimates for some countries (mostly African) have explicitly taken
into account the effects of the growing impact of the HIV/AIDS
epidemic. These countries are currently: The Bahamas, Benin, Botswana,
Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central
African Republic, Democratic Republic of the Congo, Republic of the
Congo, Cote d''Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti, Honduras,
Kenya, Lesotho, Malawi, Mozambique, Namibia, Nigeria, Rwanda, South
Africa, Swaziland, Tanzania, Thailand, Togo, Uganda, Zambia, and
Zimbabwe.
Population below poverty line
National estimates of the percentage of the population lying below the
poverty line are based on surveys of sub-groups, with the results
weighted by the number of people in each group. Definitions of poverty
vary considerably among nations. For example, rich nations generally
employ more generous standards of poverty than poor nations.
Population growth rate
The average annual percent change in the population, resulting from a
surplus (or deficit) of births over deaths and the balance of migrants
entering and leaving a country. The rate may be positive or negative.
The growth rate is a factor in determining how great a burden would be
imposed on a country by the changing needs of its people for
infrastructure (e.g., schools, hospitals, housing, roads), resources
(e.g., food, water, electricity), and jobs. Rapid population growth can
be seen as threatening by neighboring countries.
Ports and harbors
This entry lists the major ports and harbors selected on the basis of
overall importance to each country. This is determined by evaluating a
number of factors (e.g., dollar value of goods handled, gross tonnage,
facilities, military significance).
Radio broadcast stations
This entry includes the total number of AM, FM, and shortwave broadcast
stations.
Radios
This entry gives the total number of radio receivers.
Railways
This entry includes the total route length of the railway network and
of its component parts by gauge: broad, dual, narrow, standard, and
other.
Reference maps
This section includes world, regional, and special or current interest
maps.
Religions
This entry includes a rank ordering of religions by adherents starting
with the largest group and sometimes includes the percent of total
population.
Sex ratio
This entry includes the number of males for each female in five age
groups - at birth, under 15 years, 15-64 years, 65 years and over, and
for the total population. Sex ratio at birth has recently emerged as an
indicator of certain kinds of sex discrimination in some countries. For
instance, high sex ratios at birth in some Asian countries are now
attributed to sex-selective abortion and infanticide due to a strong
preference for sons. This will affect future marriage patterns and
fertility patterns. Eventually it could cause unrest among young adult
males who are unable to find partners.
Suffrage
This entry gives the age at enfranchisement and whether the right to
vote is universal or restricted.
Telephone numbers
All telephone numbers in the Factbook consist of the country code in
brackets, the city or area code (where required) in parentheses, and
the local number. The one component that is not presented is the
international access code, which varies from country to country. For
example, an international direct dial telephone call placed from the US
to Madrid, Spain, would be as follows:
011 [34] (1) 577-xxxx, where
011 is the international access code for station-to-station calls;
01 is for calls other than station-to-station calls,
[34] is the country code for Spain,
(1) is the city code for Madrid,
577 is the local exchange, and
xxxx is the local telephone number.
An international direct dial telephone call placed from another country
to the US would be as follows:
international access code + [1] (202) 939-xxxx, where
[1] is the country code for the US,
(202) is the area code for Washington, DC,
939 is the local exchange, and
xxxx is the local telephone number.
Telephone system
This entry includes a brief characterization of the system with details
on the domestic and international components. The following terms and
abbreviations are used throughout the entry:
Africa ONE - a fiber-optic submarine cable link encircling the
continent of Africa.
Arabsat - Arab Satellite Communications Organization (Riyadh,
Saudi Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen''s band mobile radio communications.
cellular telephone system - the telephones in this system are
radio transceivers, with each instrument having its own private radio
frequency and sufficient radiated power to reach the booster station in
its area (cell), from which the telephone signal is fed to a regular
telephone exchange.
Central American Microwave System - a trunk microwave radio relay
system that links the countries of Central America and Mexico with each
other.
coaxial cable - a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a cylindrical
conducting shell; a large number of telephone channels can be made
available within the insulated space by the use of a large number of
carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network
or Autovon); basic general-purpose, switched voice network of the
Defense Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization
(Paris).
fiber-optic cable - a multichannel communications cable using a
thread of optical glass fibers as a transmission medium in which the
signal (voice, video, etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised
by the Groupe Special Mobile of the pan-European standardization
organization, Conference Europeanne des Posts et Telecommunications
(CEPT) in 1982.
HF - high frequency; any radio frequency in the 3,000- to 30,000-
kHz range.
Inmarsat - International Mobile Satellite Organization (London);
provider of global mobile satellite communications for commercial,
distress, and safety applications at sea, in the air, and on land.
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia.
landline - communication wire or cable of any sort that is
installed on poles or buried in the ground.
Marecs - Maritime European Communications Satellite used in the
Inmarsat system on lease from the European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in
the Inmarsat system.
Medarabtel - the Middle East Telecommunications Project of the
International Telecommunications Union (ITU) providing a modern
telecommunications network, primarily by microwave radio relay, linking
Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, and Yemen; it was initially started in
Morocco in 1970 by the Arab Telecommunications Union (ATU) and was
known at that time as the Middle East Mediterranean Telecommunications
Network.
microwave radio relay - transmission of long distance telephone
calls and television programs by highly directional radio microwaves
that are received and sent on from one booster station to another on an
optical path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system
that was developed jointly by the national telecommunications
authorities of the Nordic countries (Denmark, Finland, Iceland, Norway,
and Sweden).
Orbita - a Russian television service; also the trade name of a
packet-switched digital telephone network.
radiotelephone communications - the two-way transmission and
reception of sounds by broadcast radio on authorized frequencies using
telephone handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
satellite communication system - a communication system consisting
of two or more earth stations and at least one satellite that provide
long distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system.
satellite earth station - a communications facility with a
microwave radio transmitting and receiving antenna and required
receiving and transmitting equipment for communicating with satellites.
satellite link - a radio connection between a satellite and an
earth station permitting communication between them, either one-way
(down link from satellite to earth station - television receive-only
transmission) or two-way (telephone channels).
SHF - super high frequency; any radio frequency in the 3,000- to
30,000-MHz range.
shortwave - radio frequencies (from 1.605 to 30 MHz) that fall
above the commercial broadcast band and are used for communication over
long distances.
Solidaridad - geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite
telecommunications.
submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity
submarine coaxial telephone cables linking Europe with North America.
telefax - facsimile service between subscriber stations via the
public switched telephone network or the international Datel network.
telegraph - a telecommunications system designed for unmodulated
electric impulse transmission.
telex - a communication service involving teletypewriters
connected by wire through automatic exchanges.
tropospheric scatter - a form of microwave radio transmission in
which the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances.
trunk network - a network of switching centers, connected by
multichannel trunk lines.
UHF - ultra high frequency; any radio frequency in the 300- to
3,000-MHz range.
VHF - very high frequency; any radio frequency in the 30- to 300-
MHz range.
Telephones - main lines in use
This entry gives the total number of main telephone lines in use.
Telephones - mobile cellular
This entry gives the total number of mobile cellular telephones in use.
Television - broadcast stations
This entry gives the total number of separate broadcast stations plus
any repeater stations.
Televisions
This entry gives the total number of television sets.
Terminology
Due to the highly structured nature of the Factbook database, some
collective generic terms have to be used. For example, the word Country
in the Country name entry refers to a wide variety of dependencies,
areas of special sovereignty, uninhabited islands, and other entities
in addition to the traditional countries or independent states.
Military is also used as an umbrella term for various civil defense,
security, and defense activities in many entries. The Independence
entry includes the usual colonial independence dates and former ruling
states as well as other significant nationhood dates such as the
traditional founding date or the date of unification, federation,
confederation, establishment, or state succession that are not strictly
independence dates. Dependent areas have the nature of their dependency
status noted in this same entry.
Terrain
This entry contains a brief description of the topography.
Total fertility rate
This entry gives a figure for the average number of children that would
be born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each
age. The total fertility rate is a more direct measure of the level of
fertility than the crude birth rate, since it refers to births per
woman. This indicator shows the potential for population growth in the
country. High rates will also place some limits on the labor force
participation rates for women. Large numbers of children born to women
indicate large family sizes that might limit the ability of the
families to feed and educate their children.','62d26e862f55e3d2c03182ea8af88970f3ca3995e165db70b3cc490a13235b4b','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

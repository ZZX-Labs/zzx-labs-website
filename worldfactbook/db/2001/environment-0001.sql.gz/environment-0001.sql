SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fc45751e113b6c744c68657e50f440d2231f65e273f710316fadd8f234d0961',2001,'AU','Australia','environment',265,'Wake Island:
Economic activity is limited to providing services to
contractors located on the island. All food and manufactured goods
must be imported.
Wallis and Futuna:
The economy is limited to traditional subsistence
agriculture, with about 80% of the labor force earning its
livelihood from agriculture (coconuts and vegetables), livestock
(mostly pigs), and fishing. About 4% of the population is employed
in government. Revenues come from French Government subsidies,
licensing of fishing rights to Japan and South Korea, import taxes,
and remittances from expatriate workers in New Caledonia.
West Bank:
Economic output in the West Bank is governed by the Paris
Economic Protocol of April 1994 between Israel and the Palestinian
Authority. Real per capita GDP for the West Bank and Gaza Strip
(WBGS) declined by 36.1% between 1992 and 1996 owing to the combined
effect of falling aggregate incomes and rapid population growth. The
downturn in economic activity was largely the result of Israeli
closure policies - the imposition of border closures in response to
security incidents in Israel - which disrupted established labor and
commodity market relationships between Israel and the WBGS. The most
serious social effect of this downturn was rising unemployment;
unemployment in the WBGS during the 1980s was generally under 5%; by
1995 it had risen to over 20%. Since 1997 Israel''s use of
comprehensive closures has decreased and, in 1998, Israel
implemented new policies to reduce the impact of closures and other
security procedures on the movement of Palestinian goods and labor.
These changes fueled an almost three-year long economic recovery in
the West Bank and Gaza Strip; real GDP grew by 5% in 1998 and 6% in
1999. Recovery was upended in the last quarter of 2000 with the
outbreak of Palestinian violence, which triggered tight Israeli
closures of Palestinian self-rule areas and a severe disruption of
trade and labor movements.
Western Sahara:
Western Sahara, a territory poor in natural
resources and lacking sufficient rainfall, depends on pastoral
nomadism, fishing, and phosphate mining as the principal sources of
income for the population. Most of the food for the urban population
must be imported. All trade and other economic activities are
controlled by the Moroccan Government. Incomes and standards of
living are substantially below the Moroccan level.
World:
Growth in global output (gross world product, GWP) rose to
4.8% in 2000 from 3.5% in 1999, despite continued low growth in
Japan, severe financial difficulties in other East Asian countries,
and widespread dislocations in several transition economies. The US
economy continued its remarkable sustained prosperity, growing at 5%
in 2000, although growth slowed in fourth quarter 2000; the US
accounted for 23% of GWP. The EU economies grew at 3.3% and produced
20% of GWP. China, the second largest economy in the world,
continued its strong growth and accounted for 10% of GWP. Japan grew
at only 1.3% in 2000; its share in GWP is 7%. As usual, the 15
successor nations of the USSR and the other old Warsaw Pact nations
experienced widely different rates of growth. The developing nations
also varied in their growth results, with many countries facing
population increases that eat up gains in output. Externally, the
nation-state, as a bedrock economic-political institution, is
steadily losing control over international flows of people, goods,
funds, and technology. Internally, the central government often
finds its control over resources slipping as separatist regional
movements - typically based on ethnicity - gain momentum, e.g., in
many of the successor states of the former Soviet Union, in the
former Yugoslavia, in India, and in Canada. In Western Europe,
governments face the difficult political problem of channeling
resources away from welfare programs in order to increase investment
and strengthen incentives to seek employment. The addition of 80
million people each year to an already overcrowded globe is
exacerbating the problems of pollution, desertification,
underemployment, epidemics, and famine. Because of their own
internal problems and priorities, the industrialized countries
devote insufficient resources to deal effectively with the poorer
areas of the world, which, at least from the economic point of view,
are becoming further marginalized. Continued financial difficulties
in East Asia, Russia, and many African nations, as well as the
slowdown in US economic growth, cast a shadow over short-term global
economic prospects; GWP probably will grow at 3-4% in 2001. The
introduction of the euro as the common currency of much of Western
Europe in January 1999, while paving the way for an integrated
economic powerhouse, poses serious economic risks because of varying
levels of income and cultural and political differences among the
participating nations. (For specific economic developments in each
country of the world in 2000, see the individual country entries.)
Yemen:
Yemen, one of the poorest countries in the Arab world,
reported strong growth in the mid-1990s with the onset of oil
production, but was harmed by low oil prices in 1998. Yemen has
embarked on an IMF-supported structural adjustment program designed
to modernize and streamline the economy, which has led to foreign
debt relief and restructuring. Aided by higher oil prices in
1999-2000, Yemen worked to maintain tight control over spending and
implement additional components of the IMF program. A high
population growth rate of nearly 3.4% and internal political
dissension complicate the government''s task.
Yugoslavia:
The swift collapse of the Yugoslav federation in 1991
was followed by highly destructive warfare, the destabilization of
republic boundaries, and the breakup of important interrepublic
trade flows. Output in Yugoslavia dropped by half in 1992-93. Like
the other former Yugoslav republics, it had depended on its sister
republics for large amounts of energy and manufactures. Wide
differences in climate, mineral resources, and levels of technology
among the republics accentuated this interdependence, as did the
communist practice of concentrating much industrial output in a
small number of giant plants. The breakup of many of the trade
links, the sharp drop in output as industrial plants lost suppliers
and markets, and the destruction of physical assets in the fighting
all have contributed to the economic difficulties of the republics.
Hyperinflation ended with the establishment of a new currency unit
in June 1993; prices were relatively stable from 1995 through 1997,
but inflationary pressures resurged in 1998. Reliable statistics
continue to be hard to come by, and the GDP estimate is extremely
rough. The economic boom anticipated by the government after the
suspension of UN sanctions in December 1995 has failed to
materialize. Government mismanagement of the economy is largely to
blame, but the damage to Yugoslavia''s infrastructure and industry by
the NATO bombing during the war in Kosovo have added to problems.
All sanctions now have been lifted. Yugoslavia is in the first stage
of economic reform. Severe electricity shortages are chronic, the
result of lack of investment by former regimes, depleted hydropower
reservoirs due to extended drought, and lack of funds. GDP growth in
2000 was perhaps 15%, which made up for a large part of the 20%
decline of 1999.
Zambia:
Despite progress in privatization and budgetary reform,
Zambia''s economy has a long way to go. Privatization of
government-owned copper mines relieved the government from covering
mammoth losses generated by the industry and greatly improved the
chances for copper mining to return to profitability and spur
economic growth. In late 2000, Zambia was determined to be eligible
for debt relief under the Heavily Indebted Poor Countries (HIPC)
initiative. Inflation and unemployment rates remain high, but the
GDP growth rate should rise in 2001.
Zimbabwe:
The government of Zimbabwe faces a wide variety of
difficult economic problems as it struggles to consolidate earlier
moves to develop a market-oriented economy. Its involvement in the
war in the Democratic Republic of the Congo, for example, has
already drained hundreds of millions of dollars from the economy.
Badly needed support from the IMF suffers delays in part because of
the country''s failure to meet budgetary goals. Inflation rose from
an annual rate of 32% in 1998 to 59% in 1999 and 60% in 2000. The
economy is being steadily weakened by excessive government deficits
and AIDS; Zimbabwe has the highest rate of infection in the world.
Per capita GDP, which is twice the average of the poorer sub-Saharan
nations, will increase little if any in the near-term, and Zimbabwe
will suffer continued frustrations in developing its agricultural
and mineral resources.
Taiwan:
Taiwan has a dynamic capitalist economy with gradually
decreasing guidance of investment and foreign trade by government
authorities. In keeping with this trend, some large government-owned
banks and industrial firms are being privatized. Real growth in GDP
has averaged about 8% during the past three decades. Exports have
grown even faster and have provided the primary impetus for
industrialization. Inflation and unemployment are low; the trade
surplus is substantial; and foreign reserves are the world''s fourth
largest. Agriculture contributes 3% to GDP, down from 35% in 1952.
Traditional labor-intensive industries are steadily being moved
offshore and replaced with more capital- and technology-intensive
industries. Taiwan has become a major investor in China, Thailand,
Indonesia, the Philippines, Malaysia, and Vietnam. The tightening of
labor markets has led to an influx of foreign workers, both legal
and illegal. Because of its conservative financial approach and its
entrepreneurial strengths, Taiwan suffered little compared with many
of its neighbors from the Asian financial crisis in 1998-99. Growth
in 2001 will depend largely on conditions in Taiwan''s export markets
and may be about 5%.
======================================================================
@Electricity - consumption
Afghanistan:
480.6 million kWh (1999)
Albania:
5.379 billion kWh (1999)
Algeria:
21.613 billion kWh (1999)
American Samoa:
120.9 million kWh (1999)
Andorra:
NA kWh
Angola:
1.372 billion kWh (1999)
Anguilla:
NA kWh
Antigua and Barbuda:
88.4 million kWh (1999)
Argentina:
77.111 billion kWh (1999)
Armenia:
6.201 billion kWh (1999)
Aruba:
418.5 million kWh (1999)
Australia:
178.306 billion kWh (1999)
Austria:
53.231 billion kWh (1999)
Azerbaijan:
15.432 billion kWh (1999)
Bahamas, The:
1.362 billion kWh (1999)
Bahrain:
5.752 billion kWh (1999)
Bangladesh:
11.216 billion kWh (1999)
Barbados:
667.7 million kWh (1999)
Belarus:
27.647 billion kWh (1999)
Belgium:
75.089 billion kWh (1999)
Belize:
172.1 million kWh (1999)
Benin:
510.2 million kWh (1999)
Bermuda:
511.5 million kWh (1999)
Bhutan:
191.1 million kWh (1999)
Bolivia:
3.377 billion kWh (1999)
Bosnia and Herzegovina:
2.684 billion kWh (1999)
Botswana:
1.517 billion kWh (1999)
Brazil:
353.674 billion kWh (1999)
British Indian Ocean Territory:
NA kWh
British Virgin Islands:
39.1 million kWh (1999)
Brunei:
2.274 billion kWh (1999)
Bulgaria:
33.182 billion kWh (1999)
Burkina Faso:
265.1 million kWh (1999)
Burma:
4.476 billion kWh (1999)
Burundi:
160.1 million kWh (1999)
Cambodia:
136.7 million kWh (1999)
Cameroon:
3.227 billion kWh (1999)
Canada:
497.532 billion kWh (1999)
Cape Verde:
37.2 million kWh (1999)
Cayman Islands:
306.9 million kWh (1999)
Central African Republic:
94.9 million kWh (1999)
Chad:
83.7 million kWh (1999)
Chile:
35.426 billion kWh (1999)
China:
1.084 trillion kWh (1999)
Christmas Island:
NA kWh
Cocos (Keeling) Islands:
NA kWh
Colombia:
40.532 billion kWh (1999)
Comoros:
15.8 million kWh (1999)
Congo, Democratic Republic of the:
4.55 billion kWh (1999)
Congo, Republic of the:
406.9 million kWh (1999)
Cook Islands:
19.5 million kWh (1999)
Costa Rica:
5.303 billion kWh (1999)
Cote d''Ivoire:
3.183 billion kWh (1999)
Croatia:
13.643 billion kWh (1999)
Cuba:
13.353 billion kWh (1999)
Cyprus:
2.744 billion kWh (1999); Turkish Cypriot area: NA kWh
Czech Republic:
52.898 billion kWh (2000)
Denmark:
32.916 billion kWh (1999)
Djibouti:
167.4 million kWh (1999)
Dominica:
57.7 million kWh (1999)
Dominican Republic:
6.78 billion kWh (1999)
Ecuador:
9.386 billion kWh (1999)
Egypt:
60.157 billion kWh (1999)
El Salvador:
3.638 billion kWh (1999)
Equatorial Guinea:
19.5 million kWh (1999)
Eritrea:
153.5 million kWh (1999)
Estonia:
6.807 billion kWh (1999)
Ethiopia:
1.511 billion kWh (1999)
Falkland Islands (Islas Malvinas):
11.2 million kWh (1999)
Faroe Islands:
158.1 million kWh (1999)
Fiji:
474.3 million kWh (1999)
Finland:
81.611 billion kWh (1999)
France:
398.752 billion kWh (1999)
French Guiana:
409.2 million kWh (1999)
French Polynesia:
399.9 million kWh (1999)
Gabon:
948.6 million kWh (1999)
Gambia, The:
69.8 million kWh (1999)
Gaza Strip:
NA kWh
Georgia:
7.117 billion kWh (1999)
Germany:
495.181 billion kWh (1999)
Ghana:
5.573 billion kWh (1999)
Gibraltar:
88.4 million kWh (1999)
Greece:
43.343 billion kWh (1999)
Greenland:
232.5 million kWh (1999)
Grenada:
111.6 million kWh (1999)
Guadeloupe:
1.209 billion kWh (1999)
Guam:
744 million kWh (1999)
Guatemala:
3.295 billion kWh (1999)
Guernsey:
NA kWh
Guinea:
697.5 million kWh (1999)
Guinea-Bissau:
51.2 million kWh (1999)
Guyana:
423.2 million kWh (1999)
Haiti:
625 million kWh (1999)
Holy See (Vatican City):
NA kWh
Honduras:
3.232 billion kWh (1999)
Hong Kong:
32.202 billion kWh (1999)
Hungary:
35.234 billion kWh (1999)
Iceland:
6.574 billion kWh (1999)
India:
424.032 billion kWh (1999)
Indonesia:
73.167 billion kWh (1999)
Iran:
95.84 billion kWh (1999)
Iraq:
27.361 billion kWh (1999)
Ireland:
18.414 billion kWh (1999)
Israel:
31.899 billion kWh (1999)
Italy:
272.35 billion kWh (1999)
Jamaica:
6.073 billion kWh (1999)
Japan:
947.038 billion kWh (1999)
Johnston Atoll:
NA kWh
Jordan:
6.594 billion kWh (1999)
Kazakhstan:
44.132 billion kWh (1999)
Kenya:
4.075 billion kWh (1999)
Kiribati:
6.5 million kWh (1999)
Korea, North:
26.598 billion kWh (1999)
Korea, South:
232.767 billion kWh (1999)
Kuwait:
29.357 billion kWh (1999)
Kyrgyzstan:
10.236 billion kWh (1999)
Laos:
173.6 million kWh (1999)
Latvia:
4.316 billion kWh (1999)
Lebanon:
7.86 billion kWh (1999)
Lesotho:
55 million kWh (1999)
Liberia:
401.8 million kWh (1999)
Libya:
17.577 billion kWh (1999)
Liechtenstein:
NA kWh
Lithuania:
9.817 billion kWh (1999)
Luxembourg:
6.149 billion kWh (1999)
Macau:
1.422 billion kWh (1999)
Macedonia, The Former Yugoslav Republic of:
5.992 billion kWh (1999)
Madagascar:
753.3 million kWh (1999)
Malawi:
950 million kWh (1999)
Malaysia:
54.872 billion kWh (1999)
Maldives:
93.9 million kWh (1999)
Mali:
413.9 million kWh (1999)
Malta:
1.534 billion kWh (1999)
Martinique:
1.023 billion kWh (1999)
Mauritania:
140.4 million kWh (1999)
Mauritius:
1.172 billion kWh (1999)
Mayotte:
NA kWh
Mexico:
170.754 billion kWh (1999)
Micronesia, Federated States of:
NA kWh
Moldova:
5.78 billion kWh (1999)
Monaco:
NA kWh
Mongolia:
2.767 billion kWh (1999)
Montserrat:
9.3 million kWh (1999)
Morocco:
13.441 billion kWh (1999)
Mozambique:
307 million kWh (1999)
Namibia:
1.948 billion kWh (1999)
Nauru:
27.9 million kWh (1999)
Nepal:
1.309 billion kWh (1999)
Netherlands:
97.76 billion kWh (1999)
Netherlands Antilles:
1.032 billion kWh (1999)
New Caledonia:
1.414 billion kWh (1999)
New Zealand:
35.295 billion kWh (1999)
Nicaragua:
2.265 billion kWh (1999)
Niger:
401 million kWh (1999)
Nigeria:
17.372 billion kWh (1999)
Niue:
2.8 million kWh (1999)
Norfolk Island:
NA kWh
Northern Mariana Islands:
NA kWh
Norway:
110.795 billion kWh (1999)
Oman:
8.026 billion kWh (1999)
Pakistan:
57.732 billion kWh (1999)
Panama:
4.049 billion kWh (1999)
Papua New Guinea:
1.693 billion kWh (1999)
Paraguay:
1.915 billion kWh (1999)
Peru:
17.565 billion kWh (1999)
Philippines:
37.893 billion kWh (1999)
Pitcairn Islands:
NA kWh
Poland:
120.007 billion kWh (1999)
Portugal:
37.915 billion kWh (1999)
Puerto Rico:
15.587 billion kWh (1999)
Qatar:
8.37 billion kWh (1999)
Reunion:
1.023 billion kWh (1999)
Romania:
44.768 billion kWh (1999)
Russia:
728.2 billion kWh (1999)
Rwanda:
191.8 million kWh (1999)
Saint Helena:
5.6 million kWh (1999)
Saint Kitts and Nevis:
83.7 million kWh (1999)
Saint Lucia:
102.3 million kWh (1999)
Saint Pierre and Miquelon:
37.2 million kWh (1999)
Saint Vincent and the Grenadines:
76.3 million kWh (1999)
Samoa:
93 million kWh (1999)
San Marino:
NA kWh
Sao Tome and Principe:
15.8 million kWh (1999)
Saudi Arabia:
111.6 billion kWh (1999)
Senegal:
1.181 billion kWh (1999)
Seychelles:
148.8 million kWh (1999)
Sierra Leone:
223.2 million kWh (1999)
Singapore:
25.464 billion kWh (1999)
Slovakia:
21.471 billion kWh (1999)
Slovenia:
10.024 billion kWh (1999)
Solomon Islands:
27.9 million kWh (1999)
Somalia:
241.8 million kWh (1999)
South Africa:
172.393 billion kWh (1999)
South Georgia and the South Sandwich Islands:
NA kWh
Spain:
189.57 billion kWh (1999)
Sri Lanka:
5.604 billion kWh (1999)
Sudan:
1.637 billion kWh (1999)
Suriname:
1.801 billion kWh (1999)
Svalbard:
NA kWh
Swaziland:
198 million kWh (1999)
Sweden:
128.819 billion kWh (1999)
Switzerland:
51.862 billion kWh (1999)
Syria:
16.684 billion kWh (1999)
Tajikistan:
14.729 billion kWh (1999)
Tanzania:
2.134 billion kWh (1999)
Thailand:
83.991 billion kWh (1999)
Togo:
511.6 million kWh (1999)
Tokelau:
NA kWh
Tonga:
32.6 million kWh (1999)
Trinidad and Tobago:
4.557 billion kWh (1999)
Tunisia:
8.677 billion kWh (1999)
Turkey:
119.5 billion kWh (2000 est.)
Turkmenistan:
4.785 billion kWh (1999)
Turks and Caicos Islands:
4.6 million kWh (1999)
Uganda:
1.06 billion kWh (1999)
Ukraine:
146.675 billion kWh (1999)
United Arab Emirates:
34.131 billion kWh (1999)
United Kingdom:
333.012 billion kWh (1999)
United States:
3.45 trillion kWh (1999)
Uruguay:
5.89 billion kWh (1999)
Uzbekistan:
43.455 billion kWh (1999)
Vanuatu:
32.6 million kWh (1999)
Venezuela:
75.53 billion kWh (1999)
Vietnam:
21.376 billion kWh (1999)
Virgin Islands:
948.6 million kWh (1999)
Wallis and Futuna:
NA kWh
West Bank:
NA kWh
Western Sahara:
83.7 million kWh (1999)
Yemen:
2.232 billion kWh (1999)
Yugoslavia:
33.006 billion kWh (1999)
Zambia:
5.926 billion kWh (1999)
Zimbabwe:
6.939 billion kWh (1999)
Taiwan:
129.899 billion kWh (1999)
======================================================================
@Electricity - exports
Afghanistan:
0 kWh (1999)
Albania:
100 million kWh (1999)
Algeria:
307 million kWh (1999)
American Samoa:
0 kWh (1999)
Andorra:
NA kWh
Angola:
0 kWh (1999)
Antigua and Barbuda:
0 kWh (1999)
Argentina:
1.08 billion kWh (1999)
Armenia:
0 kWh (1999)
Aruba:
0 kWh (1999)
Australia:
0 kWh (1999)
Austria:
13.507 billion kWh (1999)
Azerbaijan:
600 million kWh (1999)
Bahamas, The:
0 kWh (1999)
Bahrain:
0 kWh (1999)
Bangladesh:
0 kWh (1999)
Barbados:
0 kWh (1999)
Belarus:
2.62 billion kWh (1999)
Belgium:
8.207 billion kWh (1999)
Belize:
0 kWh (1999)
Benin:
0 kWh (1999)
Bermuda:
0 kWh (1999)
Bhutan:
1.55 billion kWh (1999)
Bolivia:
4 million kWh (1999)
Bosnia and Herzegovina:
150 million kWh (1999)
Botswana:
0 kWh (1999)
Brazil:
5 million kWh (1999)
British Virgin Islands:
0 kWh (1999)
Brunei:
0 kWh (1999)
Bulgaria:
2.2 billion kWh (1999)
Burkina Faso:
0 kWh (1999)
Burma:
0 kWh (1999)
Burundi:
0 kWh (1999)
Cambodia:
0 kWh (1999)
Cameroon:
0 kWh (1999)
Canada:
42.911 billion kWh (1999)
Cape Verde:
0 kWh (1999)
Cayman Islands:
0 kWh (1999)
Central African Republic:
0 kWh (1999)
Chad:
0 kWh (1999)
Chile:
0 kWh (1999)
China:
7.2 billion kWh (1999)
Colombia:
27 million kWh (1999)
Comoros:
0 kWh (1999)
Congo, Democratic Republic of the:
404 million kWh (1999)
Congo, Republic of the:
0 kWh (1999)
Cook Islands:
0 kWh (1999)
Costa Rica:
165 million kWh (1999)
Cote d''Ivoire:
593 million kWh (1999)
Croatia:
1 billion kWh (1999)
Cuba:
0 kWh (1999)
Cyprus:
0 kWh (1999)
Czech Republic:
18.744 billion kWh (2000)
Denmark:
7.28 billion kWh (1999)
Djibouti:
0 kWh (1999)
Dominica:
0 kWh (1999)
Dominican Republic:
0 kWh (1999)
Ecuador:
0 kWh (1999)
Egypt:
0 kWh (1999)
El Salvador:
208 million kWh (1999)
Equatorial Guinea:
0 kWh (1999)
Eritrea:
0 kWh NA kWh (1999)
Estonia:
530 million kWh (1999)
Ethiopia:
0 kWh (1999)
Falkland Islands (Islas Malvinas):
0 kWh (1999)
Faroe Islands:
0 kWh (1999)
Fiji:
0 kWh (1999)
Finland:
232 million kWh (1999)
France:
68.7 billion kWh (1999)
French Guiana:
0 kWh (1999)
French Polynesia:
0 kWh (1999)
Gabon:
0 kWh (1999)
Gambia, The:
0 kWh (1999)
Gaza Strip:
0 kWh (1999)
Georgia:
850 million kWh (1999)
Germany:
39.5 billion kWh (1999)
Ghana:
400 million kWh (1999)
Gibraltar:
0 kWh (1999)
Greece:
1.65 billion kWh (1999)
Greenland:
0 kWh (1999)
Grenada:
0 kWh (1999)
Guadeloupe:
0 kWh (1999)
Guam:
0 kWh (1999)
Guatemala:
435 million kWh (1999)
Guernsey:
NA kWh
Guinea:
0 kWh (1999)
Guinea-Bissau:
0 kWh (1999)
Guyana:
0 kWh (1999)
Haiti:
0 kWh (1999)
Honduras:
0 kWh (1999)
Hong Kong:
633 million kWh (1999)
Hungary:
2.35 billion kWh (1999)
Iceland:
0 kWh (1999)
India:
200 million kWh (1999)
Indonesia:
0 kWh (1999)
Iran:
0 kWh (1999)
Iraq:
0 kWh (1999)
Ireland:
50 million kWh (1999)
Israel:
1.061 billion kWh (1999)
Italy:
530 million kWh (1999)
Jamaica:
0 kWh (1999)
Japan:
0 kWh (1999)
Jordan:
4 million kWh (1999)
Kazakhstan:
200 million kWh (1999)
Kenya:
0 kWh (1999)
Kiribati:
0 kWh (1999)
Korea, North:
0 kWh (1999)
Korea, South:
0 kWh (1999)
Kuwait:
0 kWh (1999)
Kyrgyzstan:
2.02 billion kWh (1999)
Laos:
705 million kWh (1999)
Latvia:
400 million kWh (1999)
Lebanon:
0 kWh (1999)
Lesotho:
0 kWh (1999)
Liberia:
0 kWh (1999)
Libya:
0 kWh (1999)
Liechtenstein:
NA kWh
Lithuania:
3.2 billion kWh (1999)
Luxembourg:
655 million kWh (1999)
Macau:
3 million kWh (1999)
Macedonia, The Former Yugoslav Republic of:
30 million kWh (1999)
Madagascar:
0 kWh (1999)
Malawi:
3 million kWh (1999)
Malaysia:
50 million kWh (1999)
Maldives:
0 kWh (1999)
Mali:
0 kWh (1999)
Malta:
0 kWh (1999)
Martinique:
0 kWh (1999)
Mauritania:
0 kWh (1999)
Mauritius:
0 kWh (1999)
Mexico:
11 million kWh (1999)
Moldova:
0 kWh (1999)
Mongolia:
80 million kWh (1999)
Montserrat:
0 kWh (1999)
Morocco:
0 kWh (1999)
Mozambique:
1.9 billion kWh (1999)
Namibia:
56 million kWh (1999)
Nauru:
0 kWh (1999)
Nepal:
68 million kWh (1999)
Netherlands:
3.97 billion kWh (1999)
Netherlands Antilles:
0 kWh (1999)
New Caledonia:
0 kWh (1999)
New Zealand:
0 kWh (1999)
Nicaragua:
20 million kWh (1999)
Niger:
0 kWh (1999)
Nigeria:
19 million kWh (1999)
Niue:
0 kWh (1999)
Norway:
8.28 billion kWh (1999)
Oman:
0 kWh (1999)
Pakistan:
0 kWh (1999)
Panama:
95 million kWh (1999)
Papua New Guinea:
0 kWh (1999)
Paraguay:
46.03 billion kWh (1999)
Peru:
0 kWh (1999)
Philippines:
0 kWh (1999)
Poland:
8.43 billion kWh (1999)
Portugal:
4.49 billion kWh (1999)
Puerto Rico:
0 kWh (1999)
Qatar:
0 kWh (1999)
Reunion:
0 kWh (1999)
Romania:
1.935 billion kWh (1999)
Russia:
20 billion kWh (1999)
Rwanda:
1 million kWh (1999)
Saint Helena:
0 kWh (1999)
Saint Kitts and Nevis:
0 kWh (1999)
Saint Lucia:
0 kWh (1999)
Saint Pierre and Miquelon:
0 kWh (1999)
Saint Vincent and the Grenadines:
0 kWh (1999)
Samoa:
0 kWh (1999)
San Marino:
0 kWh
note: electric power supplied by Italy (1999)
Sao Tome and Principe:
0 kWh (1999)
Saudi Arabia:
0 kWh (1999)
Senegal:
0 kWh (1999)
Seychelles:
0 kWh (1999)
Sierra Leone:
0 kWh (1999)
Singapore:
0 kWh (1999)
Slovakia:
930 million kWh (1999)
Slovenia:
2.2 billion kWh (1999)
Solomon Islands:
0 kWh (1999)
Somalia:
0 kWh (1999)
South Africa:
3.884 billion kWh (1999)
Spain:
6.23 billion kWh (1999)
Sri Lanka:
0 kWh (1999)
Sudan:
0 kWh (1999)
Suriname:
0 kWh (1999)
Swaziland:
852 million kWh (1999)
Sweden:
15.9 billion kWh (1999)
Switzerland:
31.955 billion kWh (1999)
Syria:
0 kWh (1999)
Tajikistan:
3.9 billion kWh (1999)
Tanzania:
0 kWh (1999)
Thailand:
200 million kWh (1999)
Togo:
0 kWh (1999)
Tonga:
0 kWh (1999)
Trinidad and Tobago:
0','f147f2dbceded66e85bc4022c54c402b024ce857140dad1f2106f82ceccdea50','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66635d9db3ab738ca226280f50e1957ef08384de86225ad766d3b87dc952e1fe',2001,'AU','Australia','environment',266,'kWh (1999)
Tunisia:
19 million kWh (1999)
Turkey:
350 million kWh (2000 est.)
Turkmenistan:
4.1 billion kWh (1999)
Turks and Caicos Islands:
0 kWh (1999)
Uganda:
174 million kWh (1999)
Ukraine:
2.3 billion kWh (1999)
United Arab Emirates:
0 kWh (1999)
United Kingdom:
265 million kWh (1999)
United States:
14 billion kWh (1999)
Uruguay:
215 million kWh (1999)
Uzbekistan:
3.92 billion kWh (1999)
Vanuatu:
0 kWh (1999)
Venezuela:
0 kWh (1999)
Vietnam:
0 kWh (1999)
Virgin Islands:
0 kWh (1999)
Western Sahara:
0 kWh (1999)
Yemen:
0 kWh (1999)
Yugoslavia:
960 million kWh (1999)
Zambia:
1.6 billion kWh (1999)
Zimbabwe:
0 kWh (1999)
Taiwan:
0 kWh (1999)
======================================================================
@Electricity - imports
Afghanistan:
90 million kWh (1999)
Albania:
600 million kWh (2000)
Algeria:
330 million kWh (1999)
American Samoa:
0 kWh (1999)
Andorra:
NA kWh
note: most electricity supplied by Spain and France; Andorra
generates a small amount of hydropower
Angola:
0 kWh (1999)
Antigua and Barbuda:
0 kWh (1999)
Argentina:
6.5 billion kWh (1999)
Armenia:
0 kWh (1999)
Aruba:
0 kWh (1999)
Australia:
0 kWh (1999)
Austria:
11.605 billion kWh (1999)
Azerbaijan:
800 million kWh (1999)
Bahamas, The:
0 kWh (1999)
Bahrain:
0 kWh (1999)
Bangladesh:
0 kWh (1999)
Barbados:
0 kWh (1999)
Belarus:
7.1 billion kWh (1999)
Belgium:
9.055 billion kWh (1999)
Belize:
0 kWh (1999)
Benin:
300 million kWh (1999)
Bermuda:
0 kWh (1999)
Bhutan:
15 million kWh (1999)
Bolivia:
10 million kWh (1999)
Bosnia and Herzegovina:
430 million kWh (1999)
Botswana:
950 million kWh (1999)
Brazil:
39.86 billion kWh
note: supplied by Paraguay (1999)
British Virgin Islands:
0 kWh (1999)
Brunei:
0 kWh (1999)
Bulgaria:
1.7 billion kWh (1999)
Burkina Faso:
0 kWh (1999)
Burma:
0 kWh (1999)
Burundi:
29 million kWh
note: supplied by the Democratic Republic of the Congo (1999)
Cambodia:
0 kWh (1999)
Cameroon:
0 kWh (1999)
Canada:
12.953 billion kWh (1999)
Cape Verde:
0 kWh (1999)
Cayman Islands:
0 kWh (1999)
Central African Republic:
0 kWh (1999)
Chad:
0 kWh (1999)
Chile:
0 kWh (1999)
China:
90 million kWh (1999)
Colombia:
35 million kWh (1999)
Comoros:
0 kWh (1999)
Congo, Democratic Republic of the:
55 million kWh (1999)
Congo, Republic of the:
126 million kWh (1999)
Cook Islands:
0 kWh (1999)
Costa Rica:
69 million kWh (1999)
Cote d''Ivoire:
0 kWh (1999)
Croatia:
4.45 billion kWh (1999)
Cuba:
0 kWh (1999)
Cyprus:
0 kWh (1999)
Czech Republic:
8.735 billion kWh (2000)
Denmark:
4.963 billion kWh (1999)
Djibouti:
0 kWh (1999)
Dominica:
0 kWh (1999)
Dominican Republic:
0 kWh (1999)
Ecuador:
25 million kWh (1999)
Egypt:
0 kWh (1999)
El Salvador:
460 million kWh (1999)
Equatorial Guinea:
0 kWh (1999)
Eritrea:
0 kWh NA kWh (1999)
Estonia:
100 million kWh (1999)
Ethiopia:
0 kWh (1999)
Falkland Islands (Islas Malvinas):
0 kWh (1999)
Faroe Islands:
0 kWh (1999)
Fiji:
0 kWh (1999)
Finland:
11.356 billion kWh (1999)
France:
5 billion kWh (1999)
French Guiana:
0 kWh (1999)
French Polynesia:
0 kWh (1999)
Gabon:
0 kWh (1999)
Gambia, The:
0 kWh (1999)
Gaza Strip:
NA kWh; note - electricity supplied by Israel
Georgia:
550 million kWh (1999)
Germany:
40.5 billion kWh (1999)
Ghana:
890 million kWh (1999)
Gibraltar:
0 kWh (1999)
Greece:
1.811 billion kWh (1999)
Greenland:
0 kWh (1999)
Grenada:
0 kWh (1999)
Guadeloupe:
0 kWh (1999)
Guam:
0 kWh (1999)
Guatemala:
210 million kWh (1999)
Guernsey:
NA kWh
Guinea:
0 kWh (1999)
Guinea-Bissau:
0 kWh (1999)
Guyana:
0 kWh (1999)
Haiti:
0 kWh (1999)
Holy See (Vatican City):
NA kWh; note - electricity supplied by Italy
Honduras:
145 million kWh (1999)
Hong Kong:
7.05 billion kWh (1999)
Hungary:
3.406 billion kWh (1999)
Iceland:
0 kWh (1999)
India:
1.49 billion kWh (1999)
Indonesia:
0 kWh (1999)
Iran:
0 kWh (1999)
Iraq:
0 kWh (1999)
Ireland:
290 million kWh (1999)
Israel:
4 million kWh (1999)
Italy:
42.539 billion kWh (1999)
Jamaica:
0 kWh (1999)
Japan:
0 kWh (1999)
Jersey:
NA kWh
note: electricity supplied by France
Jordan:
407 million kWh (1999)
Kazakhstan:
3.077 billion kWh (1999)
Kenya:
146 million kWh (1999)
Kiribati:
0 kWh (1999)
Korea, North:
0 kWh (1999)
Korea, South:
0 kWh (1999)
Kuwait:
0 kWh (1999)
Kyrgyzstan:
184 million kWh (1999)
Laos:
142 million kWh (1999)
Latvia:
1 billion kWh (1999)
Lebanon:
654 million kWh (1999)
Lesotho:
55 million kWh
note: electricity supplied by South Africa (1999)
Liberia:
0 kWh (1999)
Libya:
0 kWh (1999)
Liechtenstein:
NA kWh
Lithuania:
400 million kWh (1999)
Luxembourg:
6.201 billion kWh (1999)
Macau:
165 million kWh (1999)
Macedonia, The Former Yugoslav Republic of:
75 million kWh (1999)
Madagascar:
0 kWh (1999)
Malawi:
0 kWh (1999)
Malaysia:
11 million kWh (1999)
Maldives:
0 kWh (1999)
Mali:
0 kWh (1999)
Malta:
0 kWh (1999)
Martinique:
0 kWh (1999)
Mauritania:
0 kWh (1999)
Mauritius:
0 kWh (1999)
Mexico:
1.047 billion kWh (1999)
Moldova:
1.916 billion kWh (1999)
Monaco:
NA kWh
note: electricity supplied by France (1999)
Mongolia:
363 million kWh (1999)
Montserrat:
0 kWh (1999)
Morocco:
705 million kWh (1999)
Mozambique:
68 million kWh (1999)
Namibia:
890 million kWh
note: supplied by South Africa (1999)
Nauru:
0 kWh (1999)
Nepal:
210 million kWh (1999)
Netherlands:
22.407 billion kWh (1999)
Netherlands Antilles:
0 kWh (1999)
New Caledonia:
0 kWh (1999)
New Zealand:
0 kWh (1999)
Nicaragua:
100 million kWh (1999)
Niger:
215 million kWh (1999)
Nigeria:
0 kWh (1999)
Niue:
0 kWh (1999)
Norway:
6.467 billion kWh (1999)
Oman:
0 kWh (1999)
Pakistan:
0 kWh (1999)
Panama:
40 million kWh (1999)
Papua New Guinea:
0 kWh (1999)
Paraguay:
0 kWh (1999)
Peru:
1 million kWh (1999)
Philippines:
0 kWh (1999)
Poland:
3.491 billion kWh (1999)
Portugal:
3.628 billion kWh (1999)
Puerto Rico:
0 kWh (1999)
Qatar:
0 kWh (1999)
Reunion:
0 kWh (1999)
Romania:
1.1 billion kWh (1999)
Russia:
6 billion kWh (1999)
Rwanda:
70 million kWh (1999)
Saint Helena:
0 kWh (1999)
Saint Kitts and Nevis:
0 kWh (1999)
Saint Lucia:
0 kWh (1999)
Saint Pierre and Miquelon:
0 kWh (1999)
Saint Vincent and the Grenadines:
0 kWh (1999)
Samoa:
0 kWh (1999)
San Marino:
NA kWh
note: electricity supplied by Italy
Sao Tome and Principe:
0 kWh (1999)
Saudi Arabia:
0 kWh (1999)
Senegal:
0 kWh (1999)
Seychelles:
0 kWh (1999)
Sierra Leone:
0 kWh (1999)
Singapore:
0 kWh (1999)
Slovakia:
1.4 billion kWh (1999)
Slovenia:
645 million kWh (1999)
Solomon Islands:
0 kWh (1999)
Somalia:
0 kWh (1999)
South Africa:
2.457 billion kWh (1999)
Spain:
11.945 billion kWh (1999)
Sri Lanka:
0 kWh (1999)
Sudan:
0 kWh (1999)
Suriname:
0 kWh (1999)
Swaziland:
701 million kWh
note: supplied by South Africa (1999)
Sweden:
8.35 billion kWh (1999)
Switzerland:
21.723 billion kWh (1999)
Syria:
0 kWh (1999)
Tajikistan:
4.1 billion kWh (1999)
Tanzania:
43 million kWh (1999)
Thailand:
1.02 billion kWh (1999)
Togo:
426 million kWh
note: electricity supplied by Ghana (1999)
Tonga:
0 kWh (1999)
Trinidad and Tobago:
0 kWh (1999)
Tunisia:
165 million kWh (1999)
Turkey:
3.35 billion kWh (2000 est.)
Turkmenistan:
1.1 billion kWh (1999)
Turks and Caicos Islands:
0 kWh (1999)
Uganda:
1 million kWh (1999)
Ukraine:
2.2 billion kWh (1999)
United Arab Emirates:
0 kWh (1999)
United Kingdom:
14.5 billion kWh (1999)
United States:
43 billion kWh (1999)
Uruguay:
800 million kWh (1999)
Uzbekistan:
7.5 billion kWh (1999)
Vanuatu:
0 kWh (1999)
Venezuela:
0 kWh (1999)
Vietnam:
0 kWh (1999)
Virgin Islands:
0 kWh (1999)
West Bank:
NA kWh
Western Sahara:
0 kWh (1999)
Yemen:
0 kWh (1999)
Yugoslavia:
1.923 billion kWh (1999)
Zambia:
419 million kWh (1999)
Zimbabwe:
1.564 billion kWh (1999)
Taiwan:
0 kWh (1999)
======================================================================
@Electricity - production
Afghanistan:
420 million kWh (1999)
Albania:
5.332 billion kWh (1999)
Algeria:
23.215 billion kWh (1999)
American Samoa:
130 million kWh (1999)
Angola:
1.475 billion kWh (1999)
Anguilla:
NA kWh
Antigua and Barbuda:
95 million kWh (1999)
Argentina:
77.087 billion kWh (1999)
Armenia:
6.668 billion kWh (1999)
Aruba:
450 million kWh (1999)
Australia:
191.727 billion kWh (1999)
Austria:
59.283 billion kWh (1999)
Azerbaijan:
16.378 billion kWh (1999)
Bahamas, The:
1.465 billion kWh (1999)
Bahrain:
6.185 billion kWh (1999)
Bangladesh:
12.06 billion kWh (1999)
Barbados:
718 million kWh (1999)
Belarus:
24.911 billion kWh (1999)
Belgium:
79.829 billion kWh (1999)
Belize:
185 million kWh (1999)
Benin:
226 million kWh (1999)
Bermuda:
550 million kWh (1999)
Bhutan:
1.856 billion kWh (1999)
Bolivia:
3.625 billion kWh (1999)
Bosnia and Herzegovina:
2.585 billion kWh (1999)
Botswana:
610 million kWh (1999)
Brazil:
337.44 billion kWh (1999)
British Indian Ocean Territory:
NA kWh; note - electricity supplied
by the US military
British Virgin Islands:
42 million kWh (1999)
Brunei:
2.445 billion kWh (1999)
Bulgaria:
36.217 billion kWh (1999)
Burkina Faso:
285 million kWh (1999)
Burma:
4.813 billion kWh (1999)
Burundi:
141 million kWh (1999)
Cambodia:
147 million kWh (1999)
Cameroon:
3.47 billion kWh (1999)
Canada:
567.193 billion kWh (1999)
Cape Verde:
40 million kWh (1999)
Cayman Islands:
330 million kWh (1999)
Central African Republic:
102 million kWh (1999)
Chad:
90 million kWh (1999)
Chile:
38.092 billion kWh (1999)
China:
1.173 trillion kWh (1999)
Christmas Island:
NA kWh
Cocos (Keeling) Islands:
NA kWh
Colombia:
43.574 billion kWh (1999)
Comoros:
17 million kWh (1999)
Congo, Democratic Republic of the:
5.268 billion kWh (1999)
Congo, Republic of the:
302 million kWh (1999)
Cook Islands:
21 million kWh (1999)
Costa Rica:
5.805 billion kWh (1999)
Cote d''Ivoire:
4.06 billion kWh (1999)
Croatia:
10.96 billion kWh (1999)
Cuba:
14.358 billion kWh (1999)
Cyprus:
2.951 billion kWh (1999); Turkish Cypriot area: NA kWh
Czech Republic:
67.642 billion kWh (2000)
Denmark:
37.885 billion kWh (1999)
Djibouti:
180 million kWh (1999)
Dominica:
62 million kWh (1999)
Dominican Republic:
7.29 billion kWh (1999)
Ecuador:
10.065 billion kWh (1999)
Egypt:
64.685 billion kWh (1999)
El Salvador:
3.641 billion kWh (1999)
Equatorial Guinea:
21 million kWh (1999)
Eritrea:
165 million kWh (1999)
Estonia:
7.782 billion kWh (1999)
Ethiopia:
1.625 billion kWh (1999)
Falkland Islands (Islas Malvinas):
12 million kWh (1999)
Faroe Islands:
170 million kWh (1999)
Fiji:
510 million kWh (1999)
Finland:
75.792 billion kWh (1999)
France:
497.26 billion kWh (1999)
French Guiana:
440 million kWh (1999)
French Polynesia:
430 million kWh (1999)
Gabon:
1.02 billion kWh (1999)
Gambia, The:
75 million kWh (1999)
Gaza Strip:
NA kWh; note - electricity supplied by Israel
Georgia:
7.975 billion kWh (1999)
Germany:
531.377 billion kWh (1999)
Ghana:
5.466 billion kWh (1999)
Gibraltar:
95 million kWh (1999)
Greece:
46.432 billion kWh (1999)
Greenland:
250 million kWh (1999)
Grenada:
120 million kWh (1999)
Guadeloupe:
1.3 billion kWh (1999)
Guam:
800 million kWh (1999)
Guatemala:
3.785 billion kWh (1999)
Guernsey:
NA kWh
Guinea:
750 million kWh (1999)
Guinea-Bissau:
55 million kWh (1999)
Guyana:
455 million kWh (1999)
Haiti:
672 million kWh (1999)
Honduras:
3.319 billion kWh (1999)
Hong Kong:
27.726 billion kWh (1999)
Hungary:
36.75 billion kWh (1999)
Iceland:
7.069 billion kWh (1999)
India:
454.561 billion kWh (1999)
Indonesia:
78.674 billion kWh (1999)
Iran:
103.054 billion kWh (1999)
Iraq:
29.42 billion kWh (1999)
Ireland:
19.542 billion kWh (1999)
Israel:
35.437 billion kWh (1999)
Italy:
247.679 billion kWh (1999)
Jamaica:
6.53 billion kWh (1999)
Japan:
1.018 trillion kWh (1999)
Johnston Atoll:
approximately 1,000,000 kWh weekly; note - there are
six 25,000 kWh generators supplied by the base operating support
contractor (1999)
Jordan:
6.657 billion kWh (1999)
Kazakhstan:
44.36 billion kWh (1999)
Kenya:
4.225 billion kWh (1999)
Kiribati:
7 million kWh (1999)
Korea, North:
28.6 billion kWh (1999)
Korea, South:
250.287 billion kWh (1999)
Kuwait:
31.567 billion kWh (1999)
Kyrgyzstan:
12.981 billion kWh (1999)
Laos:
792 million kWh (1999)
Latvia:
3.996 billion kWh (1999)
Lebanon:
7.748 billion kWh (1999)
Lesotho:
0 kWh; note - electricity supplied by South Africa (1999)
Liberia:
432 million kWh (1999)
Libya:
18.9 billion kWh (1999)
Lithuania:
13.567 billion kWh (1999)
Luxembourg:
648 million kWh (1999)
Macau:
1.355 billion kWh (1999)
Macedonia, The Former Yugoslav Republic of:
6.395 billion kWh (1999)
Madagascar:
810 million kWh (1999)
Malawi:
1.025 billion kWh (1999)
Malaysia:
59.044 billion kWh (1999)
Maldives:
101 million kWh (1999)
Mali:
445 million kWh (1999)
Malta:
1.65 billion kWh (1999)
Martinique:
1.1 billion kWh (1999)
Mauritania:
151 million kWh (1999)
Mauritius:
1.26 billion kWh (1999)
Mayotte:
NA kWh
Mexico:
182.492 billion kWh (1999)
Micronesia, Federated States of:
NA kWh
Moldova:
4.155 billion kWh (1999)
Mongolia:
2.671 billion kWh (1999)
Montserrat:
10 million kWh (1999)
Morocco:
13.695 billion kWh (1999)
Mozambique:
2.3 billion kWh (1999)
Namibia:
1.198 billion kWh (1999)
Nauru:
30 million kWh (1999)
Nepal:
1.255 billion kWh (1999)
Netherlands:
85.294 billion kWh (1999)
Netherlands Antilles:
1.11 billion kWh (1999)
New Caledonia:
1.52 billion kWh (1999)
New Zealand:
37.952 billion kWh (1999)
Nicaragua:
2.349 billion kWh (1999)
Niger:
200 million kWh (1999)
Nigeria:
18.7 billion kWh (1999)
Niue:
3 million kWh (1999)
Norfolk Island:
NA kWh
Northern Mariana Islands:
NA kWh
Norway:
121.084 billion kWh (1999)
Oman:
8.63 billion kWh (1999)
Pakistan:
62.078 billion kWh (1999)
Panama:
4.413 billion kWh (1999)
Papua New Guinea:
1.82 billion kWh (1999)
Paraguay:
51.554 billion kWh (1999)
Peru:
18.886 billion kWh (1999)
Philippines:
40.745 billion kWh (1999)
Pitcairn Islands:
NA kWh; note - electric power is provided by a
small diesel-powered generator
Poland:
134.351 billion kWh (1999)
Portugal:
41.696 billion kWh (1999)
Puerto Rico:
16.76 billion kWh (1999)
Qatar:
9 billion kWh (1999)
Reunion:
1.1 billion kWh (1999)
Romania:
49.036 billion kWh (1999)
Russia:
798.065 billion kWh (1999)
Rwanda:
132 million kWh (1999)
Saint Helena:
6 million kWh (1999)
Saint Kitts and Nevis:
90 million kWh (1999)
Saint Lucia:
110 million kWh (1999)
Saint Pierre and Miquelon:
40 million kWh (1999)
Saint Vincent and the Grenadines:
82 million kWh (1999)
Samoa:
100 million kWh (1999)
San Marino:
NA kWh
Sao Tome and Principe:
17 million kWh (1999)
Saudi Arabia:
120 billion kWh (1999)
Senegal:
1.27 billion kWh (1999)
Seychelles:
160 million kWh (1999)
Sierra Leone:
240 million kWh (1999)
Singapore:
27.381 billion kWh (1999)
Slovakia:
22.582 billion kWh (1999)
Slovenia:
12.451 billion kWh (1999)
Solomon Islands:
30 million kWh (1999)
Somalia:
260 million kWh (1999)
South Africa:
186.903 billion kWh (1999)
Spain:
197.694 billion kWh (1999)
Sri Lanka:
6.026 billion kWh (1999)
Sudan:
1.76 billion kWh (1999)
Suriname:
1.937 billion kWh (1999)
Svalbard:
NA kWh
Swaziland:
375 million kWh (1999)
Sweden:
146.633 billion kWh (1999)
Switzerland:
66.768 billion kWh (1999)
Syria:
17.94 billion kWh (1999)
Tajikistan:
15.623 billion kWh (1999)
Tanzania:
2.248 billion kWh (1999)
Thailand:
89.431 billion kWh (1999)
Togo:
92 million kWh (1999)
Tokelau:
NA kWh
Tonga:
35 million kWh (1999)
Trinidad and Tobago:
4.9 billion kWh (1999)
Tunisia:
9.173 billion kWh (1999)
Turkey:
125.3 billion kWh (2000 est.)
Turkmenistan:
8.371 billion kWh (1999)
Turks and Caicos Islands:
5 million kWh (1999)
Uganda:
1.326 billion kWh (1999)
Ukraine:
157.823 billion kWh (1999)
United Arab Emirates:
36.7 billion kWh (1999)
United Kingdom:
342.771 billion kWh (1999)
United States:
3.678 trillion kWh (1999)
Uruguay:
5.704 billion kWh (1999)
Uzbekistan:
42.876 billion kWh (1999)
Vanuatu:
35 million kWh (1999)
Venezuela:
81.215 billion kWh (1999)
Vietnam:
22.985 billion kWh (1999)
Virgin Islands:
1.02 billion kWh (1999)
Wake Island:
NA kWh
Wallis and Futuna:
NA kWh
West Bank:
NA kWh; note - most electricity imported from Israel;
East Jerusalem Electric Company buys and distributes electricity to
Palestinians in East Jerusalem and its concession in the West Bank;
the Israel Electric Company directly supplies electricity to most
Jewish residents and military facilities; at the same time, some
Palestinian municipalities, such as Nablus and Janin, generate their
own electricity from small power plants
Western Sahara:
90 million kWh (1999)
Yemen:
2.4 billion kWh (1999)
Yugoslavia:
34.455 billion kWh (1999)
Zambia:
7.642 billion kWh (1999)
Zimbabwe:
5.78 billion kWh (1999)
Taiwan:
139.676 billion kWh (1999)
======================================================================
@Electricity - production by source
Afghanistan:
fossil fuel: 35.71%
hydro: 64.29%
nuclear: 0%
other: 0% (1999)
Albania:
fossil fuel: 3.81%
hydro: 96.19%
nuclear: 0%
other: 0% (1999)
Algeria:
fossil fuel: 99.14%
hydro: 0.86%
nuclear: 0%
other: 0% (1999)
American Samoa:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Andorra:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Angola:
fossil fuel: 32.2%
hydro: 67.8%
nuclear: 0%
other: 0% (1999)
Anguilla:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Antigua and Barbuda:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Argentina:
fossil fuel: 60.3%
hydro: 30.7%
nuclear: 8.75%
other: 0.25% (1999)
Armenia:
fossil fuel: 45.56%
hydro: 23.25%
nuclear: 31.19%
other: 0% (1999)
Aruba:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Australia:
fossil fuel: 89.93%
hydro: 8.36%
nuclear: 0%
other: 1.71% (1999)
Austria:
fossil fuel: 29.53%
hydro: 67.65%
nuclear: 0%
other: 2.82% (1999)
Azerbaijan:
fossil fuel: 86.46%
hydro: 13.54%
nuclear: 0%
other: 0% (1999)
Bahamas, The:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Bahrain:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Bangladesh:
fossil fuel: 93.7%
hydro: 6.3%
nuclear: 0%
other: 0% (1999)
Barbados:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Belarus:
fossil fuel: 99.9%
hydro: 0.1%
nuclear: 0%
other: 0% (1999)
Belgium:
fossil fuel: 40.01%
hydro: 0.42%
nuclear: 58.33%
other: 1.24% (1999)
Belize:
fossil fuel: 56.76%
hydro: 43.24%
nuclear: 0%
other: 0% (1999)
Benin:
fossil fuel: 24.78%
hydro: 75.22%
nuclear: 0%
other: 0% (1999)
Bermuda:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Bhutan:
fossil fuel: 0.05%
hydro: 99.95%
nuclear: 0%
other: 0% (1999)
Bolivia:
fossil fuel: 56.61%
hydro: 41.6%
nuclear: 0%
other: 1.79% (1999)
Bosnia and Herzegovina:
fossil fuel: 38.68%
hydro: 61.32%
nuclear: 0%
other: 0% (1999)
Botswana:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Brazil:
fossil fuel: 5.28%
hydro: 90.66%
nuclear: 1.12%
other: 2.94% (1999)
British Virgin Islands:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Brunei:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Bulgaria:
fossil fuel: 51.52%
hydro: 8.35%
nuclear: 40.12%
other: 0.01% (1999)
Burkina Faso:
fossil fuel: 71.93%
hydro: 28.07%
nuclear: 0%
other: 0% (1999)
Burma:
fossil fuel: 68.56%
hydro: 31.44%
nuclear: 0%
other: 0% (1999)
Burundi:
fossil fuel: 0.71%
hydro: 99.29%
nuclear: 0%
other: 0% (1999)
Cambodia:
fossil fuel: 59.18%
hydro: 40.82%
nuclear: 0%
other: 0% (1999)
Cameroon:
fossil fuel: 2.59%
hydro: 97.41%
nuclear: 0%
other: 0% (1999)
Canada:
fossil fuel: 26.38%
hydro: 60%
nuclear: 12.31%
other: 1.31% (1999)
Cape Verde:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Cayman Islands:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Central African Republic:
fossil fuel: 20.59%
hydro: 79.41%
nuclear: 0%
other: 0% (1999)
Chad:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Chile:
fossil fuel: 61%
hydro: 35%
nuclear: 0%
other: 4% (1999)
China:
fossil fuel: 79.82%
hydro: 18.98%
nuclear: 1.2%
other: 0.01% (1999)
Christmas Island:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Cocos (Keeling) Islands:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Colombia:
fossil fuel: 22.27%
hydro: 76.19%
nuclear: 0%
other: 1.54% (1999)
Comoros:
fossil fuel: 88.24%
hydro: 11.76%
nuclear: 0%
other: 0% (1999)
Congo, Democratic Republic of the:
fossil fuel: 2.05%
hydro: 97.95%
nuclear: 0%
other: 0% (1999)
Congo, Republic of the:
fossil fuel: 0.66%
hydro: 99.34%
nuclear: 0%
other: 0% (1999)
Cook Islands:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Costa Rica:
fossil fuel: 2.41%
hydro: 83.32%
nuclear: 0%
other: 14.27% (1999)
Cote d''Ivoire:
fossil fuel: 75.37%
hydro: 24.63%
nuclear: 0%
other: 0% (1999)
Croatia:
fossil fuel: 40.89%
hydro: 59%
nuclear: 0%
other: 0.11% (1999)
Cuba:
fossil fuel: 94.2%
hydro: 0.7%
nuclear: 0%
other: 5.1% (1999)
Cyprus:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Czech Republic:
fossil fuel: 77.8%
hydro: 3.43%
nuclear: 18.77%
other: 0% (2000)
Denmark:
fossil fuel: 88.4%
hydro: 0.07%
nuclear: 0%
other: 11.53% (1999)
Djibouti:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Dominica:
fossil fuel: 48.39%
hydro: 51.61%
nuclear: 0%
other: 0% (1999)
Dominican Republic:
fossil fuel: 87.19%
hydro: 12.4%
nuclear: 0%
other: 0.41% (1999)
Ecuador:
fossil fuel: 29.51%
hydro: 70.49%
nuclear: 0%
other: 0% (1999)
Egypt:
fossil fuel: 76.59%
hydro: 23.41%
nuclear: 0%
other: 0% (1999)
El Salvador:
fossil fuel: 45.65%
hydro: 41.01%
nuclear: 0%
other: 13.34% (1999)
Equatorial Guinea:
fossil fuel: 85.71%
hydro: 14.29%
nuclear: 0%
other: 0% (1999)
Eritrea:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Estonia:
fossil fuel: 99.72%
hydro: 0.09%
nuclear: 0%
other: 0.19% (1999)
Ethiopia:
fossil fuel: 3.08%
hydro: 96.92%
nuclear: 0%
other: 0% (1999)
Falkland Islands (Islas Malvinas):
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Faroe Islands:
fossil fuel: 58.82%
hydro: 41.18%
nuclear: 0%
other: 0% (1999)
Fiji:
fossil fuel: 17.65%
hydro: 82.35%
nuclear: 0%
other: 0% (1999)
Finland:
fossil fuel: 41.88%
hydro: 16.77%
nuclear: 28.82%
other: 12.53% (1999)
France:
fossil fuel: 9.69%
hydro: 14.39%
nuclear: 75.43%
other: 0.49% (1999)
French Guiana:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
French Polynesia:
fossil fuel: 51.16%
hydro: 48.84%
nuclear: 0%
other: 0% (1999)
Gabon:
fossil fuel: 29.9%
hydro: 70.1%
nuclear: 0%
other: 0% (1999)
Gambia, The:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Georgia:
fossil fuel: 20.38%
hydro: 79.62%
nuclear: 0%
other: 0% (1999)
Germany:
fossil fuel: 63.29%
hydro: 3.59%
nuclear: 30.3%
other: 2.82% (1999)
Ghana:
fossil fuel: 26.82%
hydro: 73.18%
nuclear: 0%
other: 0% (1999)
Gibraltar:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Greece:
fossil fuel: 89.6%
hydro: 9.72%
nuclear: 0%
other: 0.68% (1999)
Greenland:
fossil fuel: 41%
hydro: 59%
nuclear: 0%
other: 0%
note: Greenland is shifting its electricity production from fossil
fuel to hydroelectric power production (1999)
Grenada:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Guadeloupe:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Guam:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Guatemala:
fossil fuel: 38.31%
hydro: 61.69%
nuclear: 0%
other: 0% (1999)
Guernsey:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Guinea:
fossil fuel: 46.67%
hydro: 53.33%
nuclear: 0%
other: 0% (1999)
Guinea-Bissau:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Guyana:
fossil fuel: 98.9%
hydro: 1.1%
nuclear: 0%
other: 0% (1999)
Haiti:
fossil fuel: 52.83%
hydro: 47.17%
nuclear: 0%
other: 0% (1999)
Holy See (Vatican City):
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Honduras:
fossil fuel: 44.71%
hydro: 55.29%
nuclear: 0%
other: 0% (1999)
Hong Kong:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Hungary:
fossil fuel: 61.09%
hydro: 0.51%
nuclear: 38.4%
other: 0% (1999)
Iceland:
fossil fuel: 0.07%
hydro: 84.64%
nuclear: 0%
other: 15.29% (1999)
India:
fossil fuel: 79.41%
hydro: 17.77%
nuclear: 2.52%
other: 0.3% (1999)
Indonesia:
fossil fuel: 80.36%
hydro: 14.63%
nuclear: 0%
other: 5.01% (1999)
Iran:
fossil fuel: 93.16%
hydro: 6.84%
nuclear: 0%
other: 0% (1999)
Iraq:
fossil fuel: 97.96%
hydro: 2.04%
nuclear: 0%
other: 0% (1999)
Ireland:
fossil fuel: 94.42%
hydro: 4.23%
nuclear: 0%
other: 1.35% (1999)
Israel:
fossi','98ccdcbbe3ffa8b6f23189fbe2340cd0524bd027826da4121bda256e95e1f508','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae8a69bd0abd0885a7bd97b9ca70489069cba8c92d8d7672a3dbacb4fad65f17',2001,'AU','Australia','environment',267,'l fuel: 99.89%
hydro: 0.11%
nuclear: 0%
other: 0% (1999)
Italy:
fossil fuel: 79.09%
hydro: 18.08%
nuclear: 0%
other: 2.83% (1999)
Jamaica:
fossil fuel: 92.28%
hydro: 1.36%
nuclear: 0%
other: 6.36% (1999)
Japan:
fossil fuel: 58.91%
hydro: 8.35%
nuclear: 30.31%
other: 2.43% (1999)
Jordan:
fossil fuel: 99.79%
hydro: 0.21%
nuclear: 0%
other: 0% (1999)
Kazakhstan:
fossil fuel: 87.12%
hydro: 12.65%
nuclear: 0.23%
other: 0% (1999)
Kenya:
fossil fuel: 31%
hydro: 67%
nuclear: 0%
other: 2% (1999 est.)
Kiribati:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Korea, North:
fossil fuel: 34.62%
hydro: 65.38%
nuclear: 0%
other: 0% (1999)
Korea, South:
fossil fuel: 59.22%
hydro: 1.64%
nuclear: 39.12%
other: 0.02% (1999)
Kuwait:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Kyrgyzstan:
fossil fuel: 6.67%
hydro: 93.33%
nuclear: 0%
other: 0% (1999)
Laos:
fossil fuel: 2.78%
hydro: 97.22%
nuclear: 0%
other: 0% (1999)
Latvia:
fossil fuel: 31.78%
hydro: 68.22%
nuclear: 0%
other: 0% (1999)
Lebanon:
fossil fuel: 91.29%
hydro: 8.71%
nuclear: 0%
other: 0% (1999)
Lesotho:
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Liberia:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Libya:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Liechtenstein:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Lithuania:
fossil fuel: 23.89%
hydro: 3.43%
nuclear: 72.68%
other: 0% (1999)
Luxembourg:
fossil fuel: 36.88%
hydro: 53.09%
nuclear: 0%
other: 10.03% (1999)
Macau:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Macedonia, The Former Yugoslav Republic of:
fossil fuel: 82.25%
hydro: 17.75%
nuclear: 0%
other: 0% (1999)
Madagascar:
fossil fuel: 37.04%
hydro: 62.96%
nuclear: 0%
other: 0% (1999)
Malawi:
fossil fuel: 2.44%
hydro: 97.56%
nuclear: 0%
other: 0% (1999)
Malaysia:
fossil fuel: 91.61%
hydro: 8.39%
nuclear: 0%
other: 0% (1999)
Maldives:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Mali:
fossil fuel: 44.94%
hydro: 55.06%
nuclear: 0%
other: 0% (1999)
Malta:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Marshall Islands:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Martinique:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Mauritania:
fossil fuel: 82.78%
hydro: 17.22%
nuclear: 0%
other: 0% (1999)
Mauritius:
fossil fuel: 91.27%
hydro: 8.73%
nuclear: 0%
other: 0% (1999)
Mayotte:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Mexico:
fossil fuel: 74.12%
hydro: 17.75%
nuclear: 5.21%
other: 2.92% (1999)
Micronesia, Federated States of:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Moldova:
fossil fuel: 93.62%
hydro: 6.38%
nuclear: 0%
other: 0% (1999)
Mongolia:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Montserrat:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Morocco:
fossil fuel: 89.19%
hydro: 10.81%
nuclear: 0%
other: 0% (1999)
Mozambique:
fossil fuel: 13.04%
hydro: 86.96%
nuclear: 0%
other: 0% (1999)
Namibia:
fossil fuel: 2%
hydro: 98%
nuclear: 0%
other: 0% (1999)
Nauru:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Nepal:
fossil fuel: 9.56%
hydro: 90.44%
nuclear: 0%
other: 0% (1999)
Netherlands:
fossil fuel: 90.25%
hydro: 0.11%
nuclear: 4.27%
other: 5.37% (1999)
Netherlands Antilles:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
New Caledonia:
fossil fuel: 78.95%
hydro: 21.05%
nuclear: 0%
other: 0% (1999)
New Zealand:
fossil fuel: 30.49%
hydro: 61.42%
nuclear: 0%
other: 8.09% (1999)
Nicaragua:
fossil fuel: 67.26%
hydro: 17.71%
nuclear: 0%
other: 15.03% (1999)
Niger:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Nigeria:
fossil fuel: 52.94%
hydro: 47.06%
nuclear: 0%
other: 0% (1999)
Niue:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Norfolk Island:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Norway:
fossil fuel: 0.63%
hydro: 99.11%
nuclear: 0%
other: 0.26% (1999)
Oman:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Pakistan:
fossil fuel: 63.38%
hydro: 36.51%
nuclear: 0.11%
other: 0% (1999)
Panama:
fossil fuel: 27.78%
hydro: 71.65%
nuclear: 0%
other: 0.57% (1999)
Papua New Guinea:
fossil fuel: 54.95%
hydro: 45.05%
nuclear: 0%
other: 0% (1999)
Paraguay:
fossil fuel: 0.07%
hydro: 99.79%
nuclear: 0%
other: 0.15% (1999)
Peru:
fossil fuel: 23.04%
hydro: 76.43%
nuclear: 0%
other: 0.53% (1999)
Philippines:
fossil fuel: 61.03%
hydro: 18.68%
nuclear: 0%
other: 20.29% (1999)
Poland:
fossil fuel: 96.43%
hydro: 3.16%
nuclear: 0%
other: 0.41% (1999)
Portugal:
fossil fuel: 79.97%
hydro: 17.25%
nuclear: 0%
other: 2.78% (1999)
Puerto Rico:
fossil fuel: 98.45%
hydro: 1.55%
nuclear: 0%
other: 0% (1999)
Qatar:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Reunion:
fossil fuel: 54.55%
hydro: 45.45%
nuclear: 0%
other: 0% (1999)
Romania:
fossil fuel: 53.99%
hydro: 36.18%
nuclear: 9.81%
other: 0.02% (1999)
Russia:
fossil fuel: 66.31%
hydro: 19.79%
nuclear: 13.9%
other: 0% (1999)
Rwanda:
fossil fuel: 3.03%
hydro: 96.97%
nuclear: 0%
other: 0% (1999)
Saint Helena:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Saint Kitts and Nevis:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Saint Lucia:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Saint Pierre and Miquelon:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Saint Vincent and the Grenadines:
fossil fuel: 73.17%
hydro: 26.83%
nuclear: 0%
other: 0% (1999)
Samoa:
fossil fuel: 60%
hydro: 40%
nuclear: 0%
other: 0% (1999)
San Marino:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Sao Tome and Principe:
fossil fuel: 41.18%
hydro: 58.82%
nuclear: 0%
other: 0% (1999)
Saudi Arabia:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Senegal:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Seychelles:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Sierra Leone:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Singapore:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Slovakia:
fossil fuel: 37.56%
hydro: 18.27%
nuclear: 44.17%
other: 0% (1999)
Slovenia:
fossil fuel: 34.44%
hydro: 29.58%
nuclear: 35.98%
other: 0% (1999)
Solomon Islands:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Somalia:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
South Africa:
fossil fuel: 92.74%
hydro: 0.39%
nuclear: 6.87%
other: 0% (1999)
South Georgia and the South Sandwich Islands:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Spain:
fossil fuel: 57.71%
hydro: 12.1%
nuclear: 28.28%
other: 1.91% (1999)
Sri Lanka:
fossil fuel: 29.9%
hydro: 70.1%
nuclear: 0%
other: 0% (1999)
Sudan:
fossil fuel: 42.05%
hydro: 57.95%
nuclear: 0%
other: 0% (1999)
Suriname:
fossil fuel: 25.92%
hydro: 74.08%
nuclear: 0%
other: 0% (1999)
Svalbard:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Swaziland:
fossil fuel: 53.33%
hydro: 46.67%
nuclear: 0%
other: 0% (1999)
Sweden:
fossil fuel: 5.53%
hydro: 47.24%
nuclear: 45.42%
other: 1.81% (1999)
Switzerland:
fossil fuel: 3.44%
hydro: 59.16%
nuclear: 35.43%
other: 1.97% (1999)
Syria:
fossil fuel: 57.64%
hydro: 42.36%
nuclear: 0%
other: 0% (1999)
Tajikistan:
fossil fuel: 1.9%
hydro: 98.1%
nuclear: 0%
other: 0% (1999)
Tanzania:
fossil fuel: 22.24%
hydro: 77.76%
nuclear: 0%
other: 0% (1999)
Thailand:
fossil fuel: 91.17%
hydro: 3.81%
nuclear: 0%
other: 5.02% (1999)
Togo:
fossil fuel: 97.83%
hydro: 2.17%
nuclear: 0%
other: 0% (1999)
Tokelau:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Tonga:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Trinidad and Tobago:
fossil fuel: 99.59%
hydro: 0%
nuclear: 0%
other: 0.41% (1999)
Tunisia:
fossil fuel: 99.2%
hydro: 0.8%
nuclear: 0%
other: 0% (1999)
Turkey:
fossil fuel: 71%
hydro: 29%
nuclear: 0%
other: 0% (2000 est.)
Turkmenistan:
fossil fuel: 99.94%
hydro: 0.06%
nuclear: 0%
other: 0% (1999)
Turks and Caicos Islands:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Tuvalu:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Uganda:
fossil fuel: 0.98%
hydro: 99.02%
nuclear: 0%
other: 0% (1999)
Ukraine:
fossil fuel: 47.67%
hydro: 9.65%
nuclear: 42.67%
other: 0.01% (1999)
United Arab Emirates:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
United Kingdom:
fossil fuel: 69.38%
hydro: 1.55%
nuclear: 26.68%
other: 2.39% (1999)
United States:
fossil fuel: 69.64%
hydro: 8.31%
nuclear: 19.8%
other: 2.25% (1999)
Uruguay:
fossil fuel: 3.86%
hydro: 95.44%
nuclear: 0%
other: 0.7% (1999)
Uzbekistan:
fossil fuel: 86.4%
hydro: 13.6%
nuclear: 0%
other: 0% (1999)
Vanuatu:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Venezuela:
fossil fuel: 32.16%
hydro: 67.84%
nuclear: 0%
other: 0% (1999)
Vietnam:
fossil fuel: 47.71%
hydro: 52.29%
nuclear: 0%
other: 0% (1999)
Virgin Islands:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Wallis and Futuna:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
West Bank:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Western Sahara:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
World:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Yemen:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Yugoslavia:
fossil fuel: 70%
hydro: 30%
nuclear: 0%
other: 0% (1999)
Zambia:
fossil fuel: 0.55%
hydro: 99.45%
nuclear: 0%
other: 0% (1999)
Zimbabwe:
fossil fuel: 69.98%
hydro: 30.02%
nuclear: 0%
other: 0% (1999)
Taiwan:
fossil fuel: 67.26%
hydro: 6.32%
nuclear: 26.42%
other: 0% (1999)
======================================================================
@Elevation extremes
Afghanistan:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Albania:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,753 m
Algeria:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
American Samoa:
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Andorra:
lowest point: Riu Runer 840 m
highest point: Coma Pedrosa 2,946 m
Angola:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Anguilla:
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Antarctica:
lowest point: Bentley Subglacial Trench -2,540 m
highest point: Vinson Massif 5,140 m
note: the lowest known land point in Antarctica is hidden in the
Bentley Subglacial Trench; at its surface is the deepest ice yet
discovered and the world''s lowest elevation not under sea water
Antigua and Barbuda:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Arctic Ocean:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Argentina:
lowest point: Salinas Chicas -40 m (located on Peninsula
Valdes)
highest point: Cerro Aconcagua 6,960 m
Armenia:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Aruba:
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Ashmore and Cartier Islands:
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Atlantic Ocean:
lowest point: Milwaukee Deep in the Puerto Rico
Trench -8,605 m
highest point: sea level 0 m
Australia:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciuszko 2,229 m
Austria:
lowest point: Neusiedler See 115 m
highest point: Grossglockner 3,798 m
Azerbaijan:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Bahamas, The:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat Island 63 m
Bahrain:
lowest point: Persian Gulf 0 m
highest point: Jabal ad Dukhan 122 m
Baker Island:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 8 m
Bangladesh:
lowest point: Indian Ocean 0 m
highest point: Keokradong 1,230 m
Barbados:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Bassas da India:
lowest point: Indian Ocean 0 m
highest point: unnamed location 2.4 m
Belarus:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Belgium:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
Belize:
lowest point: Caribbean Sea 0 m
highest point: Victoria Peak 1,160 m
Benin:
lowest point: Atlantic Ocean 0 m
highest point: Mont Sokbaro 658 m
Bermuda:
lowest point: Atlantic Ocean 0 m
highest point: Town Hill 76 m
Bhutan:
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Bolivia:
lowest point: Rio Paraguay 90 m
highest point: Nevado Sajama 6,542 m
Bosnia and Herzegovina:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Botswana:
lowest point: junction of the Limpopo and Shashe Rivers
513 m
highest point: Tsodilo Hills 1,489 m
Bouvet Island:
lowest point: South Atlantic Ocean 0 m
highest point: Olav Peak 935 m
Brazil:
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
British Indian Ocean Territory:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego Garcia 15 m
British Virgin Islands:
lowest point: Caribbean Sea 0 m
highest point: Mount Sage 521 m
Brunei:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1,850 m
Bulgaria:
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Burkina Faso:
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Tena Kourou 749 m
Burma:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Burundi:
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,670 m
Cambodia:
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1,810 m
Cameroon:
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m
Canada:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,959 m
Cape Verde:
lowest point: Atlantic Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano on Fogo Island)
Cayman Islands:
lowest point: Caribbean Sea 0 m
highest point: The Bluff 43 m
Central African Republic:
lowest point: Oubangui River 335 m
highest point: Mont Ngaoui 1,420 m
Chad:
lowest point: Djourab Depression 160 m
highest point: Emi Koussi 3,415 m
Chile:
lowest point: Pacific Ocean 0 m
highest point: Nevado Ojos del Salado 6,880 m
China:
lowest point: Turpan Pendi -154 m
highest point: Mount Everest 8,850 m (1999 est.)
Christmas Island:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Clipperton Island:
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Cocos (Keeling) Islands:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Colombia:
lowest point: Pacific Ocean 0 m
highest point: Pico Cristobal Colon 5,775 m
note: nearby Pico Simon Bolivar also has the same elevation
Comoros:
lowest point: Indian Ocean 0 m
highest point: Le Kartala 2,360 m
Congo, Democratic Republic of the:
lowest point: Atlantic Ocean 0 m
highest point: Pic Marguerite on Mont Ngaliema (Mount Stanley)
5,110 m
Congo, Republic of the:
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Cook Islands:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Coral Sea Islands:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Costa Rica:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Cote d''Ivoire:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1,752 m
Croatia:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1,830 m
Cuba:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Cyprus:
lowest point: Mediterranean Sea 0 m
highest point: Olympus 1,951 m
Czech Republic:
lowest point: Elbe River 115 m
highest point: Snezka 1,602 m
Denmark:
lowest point: Lammefjord -7 m
highest point: Yding Skovhoej 173 m
Djibouti:
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Dominica:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Dominican Republic:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Ecuador:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Egypt:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
El Salvador:
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Equatorial Guinea:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Eritrea:
lowest point: near Kulul within the Denakil depression -75
m
highest point: Soira 3,018 m
Estonia:
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Ethiopia:
lowest point: Denakil Depression -125 m
highest point: Ras Dejen 4,620 m
Europa Island:
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Falkland Islands (Islas Malvinas):
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Faroe Islands:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Fiji:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1,324 m
Finland:
lowest point: Baltic Sea 0 m
highest point: Haltiatunturi 1,328 m
France:
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
French Guiana:
lowest point: Atlantic Ocean 0 m
highest point: Bellevue de l''Inini 851 m
French Polynesia:
lowest point: Pacific Ocean 0 m
highest point: Mont Orohena 2,241 m
French Southern and Antarctic Lands:
lowest point: Indian Ocean 0 m
highest point: Mont Ross on Iles Kerguelen 1,850 m
Gabon:
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1,575 m
Gambia, The:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Gaza Strip:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Georgia:
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek) 5,048 m
Germany:
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2,963 m
Ghana:
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Gibraltar:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Glorioso Islands:
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Greece:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,917 m
Greenland:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
Grenada:
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Guadeloupe:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1,467 m
Guam:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Guatemala:
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,211 m
Guernsey:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114 m
Guinea:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1,752 m
Guinea-Bissau:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the northeast corner of the
country 300 m
Guyana:
lowest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Haiti:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Heard Island and McDonald Islands:
lowest point: Southern Ocean 0 m
highest point: Big Ben 2,745 m
Holy See (Vatican City):
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Honduras:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Hong Kong:
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Howland Island:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 3 m
Hungary:
lowest point: Tisza River 78 m
highest point: Kekes 1,014 m
Iceland:
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,119 m
India:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Indian Ocean:
lowest point: Java Trench -7,258 m
highest point: sea level 0 m
Indonesia:
lowest point: Indian Ocean 0 m
highest point: Puncak Jaya 5,030 m
Iran:
lowest point: Caspian Sea -28 m
highest point: Qolleh-ye Damavand 5,671 m
Iraq:
lowest point: Persian Gulf 0 m
highest point: Haji Ibrahim 3,600 m
Ireland:
lowest point: Atlantic Ocean 0 m
highest point: Carrauntoohil 1,041 m
Israel:
lowest point: Dead Sea -408 m
highest point: Har Meron 1,208 m
Italy:
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc (Monte Bianco) 4,807 m
Jamaica:
lowest point: Caribbean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Jan Mayen:
lowest point: Norwegian Sea 0 m
highest point: Haakon VII Toppen/Beerenberg 2,277 m
Japan:
lowest point: Hachiro-gata -4 m
highest point: Fujiyama 3,776 m
Jarvis Island:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 7 m
Jersey:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Johnston Atoll:
lowest point: Pacific Ocean 0 m
highest point: Summit Peak 5 m
Jordan:
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1,734 m
Juan de Nova Island:
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Kazakhstan:
lowest point: Vpadina Kaundy -132 m
highest point: Khan Tangiri Shyngy (Pik Khan-Tengri) 6,995 m
Kenya:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Kingman Reef:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 1 m
Kiribati:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Korea, North:
lowest point: Sea of Japan 0 m
highest point: Paektu-san 2,744 m
Korea, South:
lowest point: Sea of Japan 0 m
highest point: Halla-san 1,950 m
Kuwait:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Kyrgyzstan:
lowest point: Kara-Darya 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Laos:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Latvia:
lowest point: Baltic Sea 0 m
highest point: Gaizinkalns 312 m
Lebanon:
lowest point: Mediterranean Sea 0 m
highest point: Qurnat as Sawda'' 3,088 m
Lesotho:
lowest point: junction of the Orange and Makhaleng Rivers
1,400 m
highest point: Thabana Ntlenyana 3,482 m
Liberia:
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1,380 m
Libya:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Liechtenstein:
lowest point: Ruggeller Riet 430 m
highest point: Grauspitz 2,599 m
Lithuania:
lowest point: Baltic Sea 0 m
highest point: Juozapines/Kalnas 292 m
Luxembourg:
lowest point: Moselle River 133 m
highest point: Buurgplaatz 559 m
Macau:
lowest point: South China Sea 0 m
highest point: Coloane Alto 174 m
Macedonia, The Former Yugoslav Republic of:
lowest point: Vardar
River 50 m
highest point: Golem Korab (Maja e Korabit) 2,753 m
Madagascar:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Malawi:
lowest point: junction of the Shire River and international
boundary with Mozambique 37 m
highest point: Sapitwa 3,002 m
Malaysia:
lowest point: Indian Ocean 0 m
highest point: Gunung Kinabalu 4,100 m
Maldives:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Wilingili island in the Addu
Atoll 2.4 m
Mali:
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1,155 m
Malta:
lowest point: Mediterranean Sea 0 m
highest point: Ta''Dmejrek 253 m (near Dingli)
Man, Isle of:
lowest point: Irish Sea 0 m
highest point: Snaefell 621 m
Marshall Islands:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Martinique:
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1,397 m
Mauritania:
lowest point: Sebkha de Ndrhamcha -3 m
highest point: Kediet Ijill 910 m
Mauritius:
lowest point: Indian Ocean 0 m
highest point: Mont Piton 828 m
Mayotte:
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Mexico:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Micronesia, Federated States of:
lowest point: Pacific Ocean 0 m
highest point: Totolom 791 m
Midway Islands:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 13 m
Moldova:
lowest point: Nistru (Dnister) River 2 m
highest point: Dealul Balanesti 430 m
Monaco:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Mongolia:
lowest point: Hoh Nuur 518 m
highest point: Nayramadlin Orgil (Huyten Orgil) 4,374 m
Montserrat:
lowest point: Caribbean Sea 0 m
highest point: Chances Peak (in the Soufriere Hills) 914 m
Morocco:
lowest point: Sebkha Tah -55 m
highest point: Jbel Toubkal 4,165 m
Mozambique:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Namibia:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Nauru:
lowest point: Pacific Ocean 0 m
highest poin','bd9921e9d4b55f9c1de36070ad6786360a896fa9c0d2cb8eae355cbefeb1dbe2','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3205771a196f5b6fb91a61a21a8d24204b46dff6cbc99490dcde8c97a06d102',2001,'AU','Australia','environment',268,'t: unnamed location along plateau rim 61 m
Navassa Island:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side 77 m
Nepal:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,850 m (1999 est.)
Netherlands:
lowest point: Prins Alexanderpolder -7 m
highest point: Vaalserberg 321 m
Netherlands Antilles:
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
New Caledonia:
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1,628 m
New Zealand:
lowest point: Pacific Ocean 0 m
highest point: Mount Cook 3,764 m
Nicaragua:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Niger:
lowest point: Niger River 200 m
highest point: Mont Greboun 1,944 m
Nigeria:
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,419 m
Niue:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau settlement 68 m
Norfolk Island:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Northern Mariana Islands:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Agrihan 965 m
Norway:
lowest point: Norwegian Sea 0 m
highest point: Galdhopiggen 2,469 m
Oman:
lowest point: Arabian Sea 0 m
highest point: Jabal Shams 2,980 m
Pacific Ocean:
lowest point: Challenger Deep in the Mariana Trench
-10,924 m
highest point: sea level 0 m
Pakistan:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen) 8,611 m
Palau:
lowest point: Pacific Ocean 0 m
highest point: Mount Ngerchelchauus 242 m
Palmyra Atoll:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Panama:
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Papua New Guinea:
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Paracel Islands:
lowest point: South China Sea 0 m
highest point: unnamed location on Rocky Island 14 m
Paraguay:
lowest point: junction of Rio Paraguay and Rio Parana 46 m
highest point: Cerro Pero (Cerro Tres Kandu) 842 m
Peru:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Philippines:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Pitcairn Islands:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Poland:
lowest point: Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Portugal:
lowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico (Pico or Pico Alto) on Ilha do Pico in
the Azores 2,351 m
Puerto Rico:
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1,338 m
Qatar:
lowest point: Persian Gulf 0 m
highest point: Qurayn Abu al Bawl 103 m
Reunion:
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Romania:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Russia:
lowest point: Caspian Sea -28 m
highest point: Gora El''brus 5,633 m
Rwanda:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Saint Helena:
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak on Tristan da Cunha 2,060 m
Saint Kitts and Nevis:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Saint Lucia:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Saint Pierre and Miquelon:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Saint Vincent and the Grenadines:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1,234 m
Samoa:
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili 1,857 m
San Marino:
lowest point: Torrente Ausa 55 m
highest point: Monte Titano 755 m
Sao Tome and Principe:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Saudi Arabia:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda'' 3,133 m
Senegal:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near Nepen Diakha 581 m
Seychelles:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Sierra Leone:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Singapore:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 166 m
Slovakia:
lowest point: Bodrok River 94 m
highest point: Gerlachovsky Stit 2,655 m
Slovenia:
lowest point: Adriatic Sea 0 m
highest point: Triglav 2,864 m
Solomon Islands:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu 2,447 m
Somalia:
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2,416 m
South Africa:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
South Georgia and the South Sandwich Islands:
lowest point:
Atlantic Ocean 0 m
highest point: Mount Paget (South Georgia) 2,934 m
Southern Ocean:
lowest point: -7,235 m at the southern end of the
South Sandwich Trench
highest point: sea level 0 m
Spain:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on Canary Islands 3,718 m
Spratly Islands:
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay 4 m
Sri Lanka:
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Sudan:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Suriname:
lowest point: unnamed location in the coastal plain -2 m
highest point: Juliana Top 1,230 m
Svalbard:
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Swaziland:
lowest point: Great Usutu River 21 m
highest point: Emlembe 1,862 m
Sweden:
lowest point: Baltic Sea 0 m
highest point: Kebnekaise 2,111 m
Switzerland:
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Syria:
lowest point: unnamed location near Lake Tiberias -200 m
highest point: Mount Hermon 2,814 m
Tajikistan:
lowest point: Syrdariya 300 m
highest point: Pik Imeni Ismail Samani 7,495 m
Tanzania:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Thailand:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Togo:
lowest point: Atlantic Ocean 0 m
highest point: Mont Agou 986 m
Tokelau:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Tonga:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao Island 1,033 m
Trinidad and Tobago:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Tromelin Island:
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Tunisia:
lowest point: Shatt al Gharsah -17 m
highest point: Jebel ech Chambi 1,544 m
Turkey:
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Turkmenistan:
lowest point: Vpadina Akchanaya -81.00 m; note -
Sarygamysh Koli is a lake in northern Turkmenistan with a water
level that fluctuates above and below the elevation of Vpadina
Akchanaya (the lake has dropped as low as -110 m)
highest point: Gora Ayribaba 3,139 m
Turks and Caicos Islands:
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Tuvalu:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Uganda:
lowest point: Lake Albert 621 m
highest point: Margherita Peak on Mount Stanley 5,110 m
Ukraine:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
United Arab Emirates:
lowest point: Persian Gulf 0 m
highest point: Jabal Yibir 1,527 m
United Kingdom:
lowest point: Fenland -4 m
highest point: Ben Nevis 1,343 m
United States:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Uruguay:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Uzbekistan:
lowest point: Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Vanuatu:
lowest point: Pacific Ocean 0 m
highest point: Tabwemasana 1,877 m
Venezuela:
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna) 5,007 m
Vietnam:
lowest point: South China Sea 0 m
highest point: Ngoc Linh 3,143 m
Virgin Islands:
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Wake Island:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Wallis and Futuna:
lowest point: Pacific Ocean 0 m
highest point: Mont Singavi 765 m
West Bank:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1,022 m
Western Sahara:
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
World:
lowest point: Bentley Subglacial Trench -2,540 m
highest point: Mount Everest 8,850 m (1999 est.)
Yemen:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Yugoslavia:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Zambia:
lowest point: Zambezi river 329 m
highest point: unnamed location in Mafinga Hills 2,301 m
Zimbabwe:
lowest point: junction of the Runde and Save rivers 162 m
highest point: Inyangani 2,592 m
Taiwan:
lowest point: South China Sea 0 m
highest point: Yu Shan 3,997 m
======================================================================
@Environment - current issues
Afghanistan:
soil degradation; overgrazing; deforestation (much of
the remaining forests are being cut down for fuel and building
materials); desertification
Albania:
deforestation; soil erosion; water pollution from
industrial and domestic effluents
Algeria:
soil erosion from overgrazing and other poor farming
practices; desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is leading to the
pollution of rivers and coastal waters; Mediterranean Sea, in
particular, becoming polluted from oil wastes, soil erosion, and
fertilizer runoff; inadequate supplies of potable water
American Samoa:
limited natural fresh water resources; the water
division of the government has spent substantial funds in the past
few years to improve water catchments and pipelines
Andorra:
deforestation; overgrazing of mountain meadows contributes
to soil erosion; air pollution; wastewater treatment and solid waste
disposal
Angola:
overuse of pastures and subsequent soil erosion attributable
to population pressures; desertification; deforestation of tropical
rain forest, in response to both international demand for tropical
timber and to domestic use as fuel, resulting in loss of
biodiversity; soil erosion contributing to water pollution and
siltation of rivers and dams; inadequate supplies of potable water
Anguilla:
supplies of potable water sometimes cannot meet increasing
demand largely because of poor distribution system
Antarctica:
in 1998, NASA satellite data showed that the antarctic
ozone hole was the largest on record, covering 27 million square
kilometers; researchers in 1997 found that increased ultraviolet
light coming through the hole damages the DNA of icefish, an
antarctic fish lacking hemoglobin; ozone depletion earlier was shown
to harm one-celled antarctic marine plants
Antigua and Barbuda:
water management - a major concern because of
limited natural fresh water resources - is further hampered by the
clearing of trees to increase crop production, causing rainfall to
run off quickly
Arctic Ocean:
endangered marine species include walruses and whales;
fragile ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
Argentina:
environmental problems (urban and rural) typical of an
industrializing economy such as soil degradation, desertification,
air pollution, and water pollution
note: Argentina is a world leader in setting voluntary greenhouse
gas targets
Armenia:
soil pollution from toxic chemicals such as DDT; energy
blockade, the result of conflict with Azerbaijan, has led to
deforestation when citizens scavenged for firewood; pollution of
Hrazdan (Razdan) and Aras Rivers; the draining of Sevana Lich (Lake
Sevan), a result of its use as a source for hydropower, threatens
drinking water supplies; restart of Metsamor nuclear power plant
without adequate (IAEA-recommended) safety and backup systems
Aruba:
NA
Ashmore and Cartier Islands:
NA
Atlantic Ocean:
endangered marine species include the manatee,
seals, sea lions, turtles, and whales; drift net fishing is
hastening the decline of fish stocks and contributing to
international disputes; municipal sludge pollution off eastern US,
southern Brazil, and eastern Argentina; oil pollution in Caribbean
Sea, Gulf of Mexico, Lake Maracaibo, Mediterranean Sea, and North
Sea; industrial waste and municipal sewage pollution in Baltic Sea,
North Sea, and Mediterranean Sea
Australia:
soil erosion from overgrazing, industrial development,
urbanization, and poor farming practices; soil salinity rising due
to the use of poor quality water; desertification; clearing for
agricultural purposes threatens the natural habitat of many unique
animal and plant species; the Great Barrier Reef off the northeast
coast, the largest coral reef in the world, is threatened by
increased shipping and its popularity as a tourist site; limited
natural fresh water resources
Austria:
some forest degradation caused by air and soil pollution;
soil pollution results from the use of agricultural chemicals; air
pollution results from emissions by coal- and oil-fired power
stations and industrial plants and from trucks transiting Austria
between northern and southern Europe
Azerbaijan:
local scientists consider the Abseron Yasaqligi
(Apsheron Peninsula) (including Baku and Sumqayit) and the Caspian
Sea to be the ecologically most devastated area in the world because
of severe air, water, and soil pollution; soil pollution results
from the use of DDT as a pesticide and also from toxic defoliants
used in the production of cotton
Bahamas, The:
coral reef decay; solid waste disposal
Bahrain:
desertification resulting from the degradation of limited
arable land, periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and sea vegetation)
resulting from oil spills and other discharges from large tankers,
oil refineries, and distribution stations; no natural fresh water
resources so that groundwater and sea water are the only sources for
all water needs
Baker Island:
no natural fresh water resources
Bangladesh:
many people are landless and forced to live on and
cultivate flood-prone land; water-borne diseases prevalent in
surface water; water pollution, especially of fishing areas, results
from the use of commercial pesticides; ground water contaminated by
naturally-occurring arsenic; intermittent water shortages because of
falling water tables in the northern and central parts of the
country; soil degradation and erosion; deforestation; severe
overpopulation
Barbados:
pollution of coastal waters from waste disposal by ships;
soil erosion; illegal solid waste disposal threatens contamination
of aquifers
Bassas da India:
NA
Belarus:
soil pollution from pesticide use; southern part of the
country contaminated with fallout from 1986 nuclear reactor accident
at Chornobyl'' in northern Ukraine
Belgium:
the environment is exposed to intense pressures from human
activities: urbanization, dense transportation network, industry,
intense animal breeding and crop cultivation; air and water
pollution also have repercussions for neighboring countries;
uncertainties regarding federal and regional responsibilities (now
resolved) have impeded progress in tackling environmental challenges
Belize:
deforestation; water pollution from sewage, industrial
effluents, agricultural runoff; solid waste disposal
Benin:
inadequate supplies of potable water; poaching threatens
wildlife populations; deforestation; desertification
Bermuda:
asbestos disposal; water pollution; preservation of open','312443e4976d87624c72ac92ffbcc19d010b799e8127fed84c4dfe37d3547ed9','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

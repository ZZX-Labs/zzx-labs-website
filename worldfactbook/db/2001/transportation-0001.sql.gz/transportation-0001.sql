SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6eecaeecdbecebdf99c7c7e641b9b9400e208584d032c0659af7b6b95f3fa2e',2001,'EH','Western Sahara','transportation',16,'Railways:
fofa/; 24.6 km
broad gauge: 9.6 km 1 .524-m gauge from Gushgy
(Turkmenistan) to Towraghondi; 15 km 1. 524-m
gauge from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu Darya
Highways:
total: 2^fi00 km
paved: 2,793 km
unpaved: 207 km (1998 est.)
Waterways: 1,200 km
note: chiefly Amu Darya, which handles vessels with
DWT up to about 500 (2001)
Pipelines: petroleum products - Uzbekistan to Bagram
and Turkmenistan to Shindand; natural gas 180 km
Ports and harbors: Kheyrabad, Shir Khan
Airports: 45 (2000 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 35
2,438 to 3,047 m: 4
1,524 to 2,437 m: 15
914 to 1,523 m: 4
under 914 m: 12 (2000 est.)
Heliports: 3 (2000 est.)
Railways: 0 km
Highways:
total: 6,200 km
paved.- 1,350 km
unpaved- 4,850 km (1991 est.)
Waterways: none
Ports and harbors: Ad Dakhia, Cabo Bojador,
Laayoune (El Aaiun)
Airports: 11 (2000 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 {2000 est.)
Airports - with unpaved runways:
total: 8
1,524 to 2,437 m:^
914 to 1,523 m: A
under 914 m.* 3 (2000 est.)
Heliports: 1 (2000 est.)
Railways:
total: 1 ,201 ,337 km includes about 1 90,000 to
195,000 km of electrified routes of which 147,760 km
are in Europe, 24,509 km in the Far East, 1 1 ,050 km
in Africa, 4,223 km in South America, and 4,160 km in
North America; note - fastest speed in daily service is
300 km/hr attained by France''s Societe Nationals des
Chemins-de-Fer Francais (SNCF) Le Train a Grande
Vitesse (TGV) - Atlantique line
broad gauge: 251 , 1 53 km
standard gauge: l^QJbA km
narrow gauge: 239,430 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Chiba, Houston, Kawasaki,
Kobe, Marseille, Mina'' al Ahmadi (Kuwait), New
Orleans, New York, Rotterdam, Yokohama','501d7dc4e92d2d56f2fcbbc83586e6cdec72b498d551ed2ca65c3a9919ab76e6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec6ccbde3f516334277a916de7fec0d0bcaf4016f687c9eda19f953dbd1b8b0',2001,'AL','Albania','transportation',23,'Railways:
total: 447 km
standard gauge: A47 km 1.435-m gauge (2001)
Highways:
/ofa/.‘ 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1998 est.)
Waterways: 43 km
note: includes Albanian sections of Lake Scutari, Lake
Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55
km; natural gas 64 km (1991)
Ports and harbors: Durres, Sarande, Shengjin,
Vlore
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 17,797
GRT/26,324 DWT
ships by type: cargo 9 (2000 est.)
Airports: 11 (2000 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 {2000 est.)
Airports - with unpaved runways:
total: 8
over 3,047 m:^
1,524 to 2,437 m:^
914 to 1,523 m: 2
under 914 m: 4 (2000 est.)
Heliports: 1 (2000 est.)
Railways:
total: 4,820 km
standard gauge: 3,664 km 1 .435-m gauge (301 km
electrified; 215 km double track)
narrow gauge: 1 ,1 56 km 1 .055-m gauge (1 996)
Highways:
tofa/; 104,000 km
paved: 71 ,656 km (including 640 km of expressways)
unpaved: 32,344 km (1996 est.)
Waterways: none
Pipelines: crude oil 6,612 km; petroleum products
298 km; natural gas 2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia,
Beni Saf, Dellys, Djendjene, Ghazaouet, Jijel,
Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 73 ships (1 ,000 GRT or over) totaling 896,91 1
GRT/1 ,047,991 DWT
ships by type: bulk 9, cargo 25, chemical tanker 7,
liquefied gas 1 0, petroleum tanker 4, roll on/roll off 1 3,
short-sea passenger 4, specialized tanker 1
(2000 est.)
Airports: 135 (2000 est.)
Airports - with paved runways:
total: 51
over 3,047 m: 9
2,438 to 3,047 m: 24
1,524 to 2,437 m: 12
914 to 1,523 m: 5
under 914 m:1 (2000 est.)
Airports ■ with unpaved runways:
tofa/;84
2,438 to 3,047m: 3
1,524 to 2,437 m: 23
914 to 1,523 m: 40
under 914 m: 18 (2000 est.)
Heliports: 1 (2000 est.)
7
Algoria (continued)','21cd804c6f7cbbf57e2314461bc33d3204ccce29e6d1d5799bedf6ab0645aeb4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f410a4ee60f0f87e7a6821ab13d8af3747835b533a85617c76836af652754f7',2001,'AS','American Samoa','transportation',33,'Railways: 0 km
Highways:
total: 350 km
paved: 150 km
unpaved: 200 km
Waterways: none
Ports and harbors: Aunu''u (new construction),
Auasi, Faleosao, Ofu, Pago Pago, Ta''u
Merchant marine: none (2000 est.)
Airports: 4 (2000 est.)
9
American Samoa (continued)
Airports - with paved runways:
total: 2
2,438 to 3,047
under 914 m:''\\ (2000 est.)
Airports - with unpaved runways:
total: 2
under 914 m; 2 (2000 est.)','33d7605cdf53f5245bd8640616bee1d455f0aa659cc3c87add622923593bf7ae','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38d5c8b76c646c4154c5e80e722c53abfcb72a9596d58b5dc749a5462177b2a3',2001,'AD','Andorra','transportation',40,'Railways: 0 km
Highways:
total: 269 km
paved: 198 km
unpaved: 7^ km (1994 est.)
Waterways: none
Ports and harbors: none
Airports: none (2000 est.)','65b328c64aafbec174e03a48c5ac328d100f111660fa8ed896f01f6f53d0da26','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a947cc9a402e0002cc694e758d2cd12359a7b16bef1a1a522e2599c57e37ff12',2001,'AO','Angola','transportation',46,'Railways:
total: 2,952 km (inland, much of the track is unusable
because of land mines still in place from the civil war)
narrow gauge: 2,798 km 1.067-m gauge; 154 km
0.600-m gauge (1997)
Highways:
total: 76,626 km
paved; 19,156 km
unpaved: 57,470 km (1 997)
Waterways: 1,295 km
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito,
Luanda, Malongo, Mocamedes, Namibe, Porto
Amboim, Soyo
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 39,305
GRT/63,067 DWT
ships by type: cargo 8, petroleum tanker 1 (2000 est.)
Airports: 247 (2000 est.)
Airports - with paved runways:
total: 31
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m:]2
914 to 1,523 m: 8
under 914 m:^ (2000 est.)
Airports - with unpaved runways:
total: 216
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 80
914 to 1,523 m: 96
under 914 m: 83 (2000 est.)','4d5ce71315e9a9bafd083e37de11183f506761b35ca7f2b8c26be3d9e2896a50','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('935c2d121ceaeb0e43133732298294cf3ad2ca7fd0fcb6ce006adc4be9578044',2001,'AI','Anguilla','transportation',55,'Railways: 0 km
Highways:
total: 279 km
paved: 253 km
unpaved: 26 km (1998 est.)
Waterways: none
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m:\\ (2000 est.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2000 est.)','013486e0bba2bd9e524dbe674f48727b3d1576a22e77ba58da943bb0365d15ec','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('777e11ea17705edbc038850fac8ad0b6323b328fbe50d4cc24abc35a5ff01050',2001,'AQ','Antarctica','transportation',62,'Ports and harbors: there are no developed ports
and harbors in Antarctica; most coastal stations have
offshore anchorages, and supplies are transferred
from ship to shore by small boats, barges, and
helicopters: a few stations have a basic wharf facility
US coastal stations include McMurdo (77 51 S, 1 66 40
E), Palmer (64 43 S, 64 03 W); government use only
except by permit (see Permit Office under "Legal
System"); offshore anchorage is sparse and
intermittent
Airports: 19
note: 27 stations, operated by 16 national
governments party to the Antarctic Treaty, have
aircraft landing facilities for either helicopters and/or
fixed-wing aircraft; commercial enterprises operate
two additional aircraft landing facilities; helicopter
pads are available at 27 stations; runways at 15
locations are gravel, sea-ice, biue-ice, or compacted
snow suitable for landing wheeled, fixed-wing aircraft;
of these, 1 is greater than 3 km in length, 6 are
between 2 km and 3 km in length, 3 are between 1 km
and 2 km in length, 3 are less than 1 km in length, and
2 are of unknown length; snow surface skiways,
limited to use by ski-equipped, fixed-wing aircraft, are
available at another 15 locations; of these, 4 are
greater than 3 km in length, 3 are between 2 km and
3 km in length, 2 are between 1 km and 2 km in length,
2 are less than 1 km in length, and 4 are of unknown
length; aircraft landing facilities generally subject to
severe restrictions and limitations resulting from
extreme seasonal and geographic conditions; aircraft
landing facilities do not meet ICAO standards;
advance approval from the respective governmental
or nongovernmental operating organization required
for landing (2001 est.)
Airports - with unpaved runways:
total: 19
over 3,047 m:e
2,438 to 3,047 m: 3
1,524 to 2,437 m-A
914 to 1,523 m: 4
under 914 m: 5 (2000 est.)
Heliports: 27 stations have helicopter landing
facilities (helipads) (2001 est.)
Railways:
total: 38,326 km (160 km electrified)
broad gauge: 24,481 km 1 .676-m gauge (134 km
electrified)
standard gauge: 2 J65 km 1.435-m gauge (26 km
electrified)
narrow gauge: 1 1 ,080 km 1 .000-m gauge (1999)
Highways;
tofa/; 21 5,434 km
paved: 63,553 km (including 734 km of expressways)
unpaved: ,881 km (1998 est.)
Waterways: 10,950 km
Pipelines: crude oil 4,090 km; petroleum products
2,900 km; natural gas 9,918 km
Ports and harbors: Bahia Blanca, Buenos Aires,
Comodoro Rivadavia, Concepcion del Uruguay, La
Plata, Mar del Plata, Necochea, Rio Gallegos,
Rosario, Santa Fe, Ushuaia
Merchant marine:
total: 26 ships (1 ,000 GRT or over) totaling 185,355
GRT/281,475 DWT
ships by type: cargo 9, petroleum tanker 1 1 , railcar
carrier 1, refrigerated cargo 2, roll on/roll off 1,
short-sea passenger 2 (2000 est.)
Airports: 1 ,359 (2000 est.)
Airports - with paved runways:
total: 143
over 3,047 m: 4
2,438 to 3,047 m: 25
1,524 to 2,437 m: 57
914 to 1,523 m: AS
under 914 m:0 {2000 est.)
Airports ■ with unpaved runways:
total: 210
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 50
914 to 1,523 m: 001
under 914 m: 555 (2000 est.)
Railways:
total: 852 km in common carrier service; does not
include industrial lines
broad gauge: 852 km 1 .520-m gauge (779 km
electrified) (2001)
Highways:
total: 8,431 km ()
paved: NA
unpaved: M (1997)
Waterways: NAkm
Pipelines: natural gas 900 km (1991)
Ports and harbors: none
Airports: 7 (2000 est.)
Airports - with unpaved runways:
total: 1
over^fiAl rr\\:\\
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m:) (2000 est.)
Railways: 0 km
Highways:
total: 800 km
pavecf; 51 3 km
unpaved: 287 km
note: most coastal roads are paved, while unpaved
roads serve large tracts of the interior (1995)
Waterways: none
Ports and harbors: Barcadera, Oranjestad, Sint
Nicolaas
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 3,120 GRT/
3,635 DWT
ships by type: cargo 1 (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only','858468c8e41ec78437f100c34fbca5a2bcce0755c6981cd08fb979b13bab3e15','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('109aa817c9f029839a4ebc4644700df1392e7852da71c1f76de2cf1625c4ed9a',2001,'GP','Guadeloupe','transportation',71,'Railways:
total: 77 km
narrow gauge: Q4 km 0.760-m gauge; 13 km 0.61 0-m
gauge (used almost exclusively for handling
sugarcane)
Highways:
tofo/; 1,165 km
paved: 384 km
unpaved: 781 km (1999 est.)
Waterways: none
Ports and harbors: Saint John''s
Merchant marine:
total: ships (1,000 GRT or over) totaling
4,070,390 GRT/5, 289,904 DWT
ships by type: bulk 1 5, cargo 424, chemical tanker 1 0,
combination bulk 4, container 176, liquefied gas 4,
multi-functional large-load carrier 6, petroleum tanker
2, refrigerated cargo 1 1 , roll on/roll off 29
note: includes some foreign-owned ships registered
here as a flag of convenience: Cyprus 2, Germany 4,
Slovenia 2 (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 2
2A38 to 3,047 m:^
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2000 est.)
Ports and harbors: Churchill (Canada), Murmansk
(Russia), Prudhoe Bay (US)
Transportation - note: sparse network of air, ocean,
river, and land routes; the Northwest Passage (North
America) and Northern Sea Route (Eurasia) are
important seasonal waterways','b5e5792e122013b869dd8b10d5d3108c9accfcd7c1ad5c7d2185f0ed5a5db851','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1da650d1b672975175bd8eb95b9c6e12a311799c7234eb2449b011d08646fdaf',2001,'AU','Australia','transportation',84,'Ports and harbors: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US),
New York (US), Oran (Algeria), Oslo (Norway),
Peiraiefs or Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Saint Petersburg (Russia),
Stockholm (Sweden)
Railways:
total: 33, 8^9 km (2,540 km electrified)
broad gauge: 3,719 km 1.600-m gauge
standard gauge: 15,422 km 1.435-m gauge
narrow gauge: 14,506 km 1.067-m gauge
dual gauge: 172 km NA gauges (1999)
Highways:
total: 913,000 km
paved: 353,331 km (including 1,363 km of
expressways)
unpaved: 559,889 km (1996)
Waterways: 8,368 km (mainly used by small,
shallow-draft craft)
Pipelines: crude oil 2,500 km; petroleum products
500 km; natural gas 5,600 km
Ports and harbors: Adelaide, Brisbane, Cairns,
Darwin, Devonport (Tasmania), Fremantle, Geelong,
Hobart (Tasmania), Launceston (Tasmania), Mackay,
Melbourne, Sydney, Townsville
Merchant marine:
total: 54 ships (1 ,000 GRT or over) totaling 1 ,558,371
GRT/2,038,776 DWT
ships by type: bulk 26, cargo 3, chemical tanker 5,
container 1 , liquefied gas 4, passenger 2, petroleum
tanker 7, roll on/roll off 6 (2000 est.)
Airports: 41 1 (2000 est.)
Airports - with paved runways:
total: 271
over 3,047 m: 10
2,438 to 3,047 m: 12
1,524 to 2,437 m: 118
914 to 1,523 m: 122
under 914 m; 9 (2000 est.)
Airports - with unpaved runways:
total: 140
1,524 to 2,437 m: 17
914 to 1,523 m: 112
under 914 m: 11 (2000 est.)
Railways:
total: 6,095.2 km (3,643.3 km electrified)
standard gauge: 5,564.2 km 1 .435-m gauge (3,521 .2
km electrified)
narrow gauge: ^97 A km (33.9 km 1.000-m gauge -
28.1 km electrified, 497.1 km 0.760-m gauge - 94 km
electrified) (2001)
Highways:
tofa/; 133,361 km
paved: 133,361 km (including 1,613 km of
expressways)
t/npaveaf.''0km(1998)
Waterways: 358 km (1999)
Pipelines: crude oil 777 km; natural gas 840 km
(1999)
Ports and harbors: Linz, Vienna, Enns, Krems
Merchant marine:
total: 23 ships (1 ,000 GRT or over) totaling 86,905
GRT/117,417DWT
ships by type: bulk 1 , cargo 18, combination bulk 2,
container 2 (2000 est.)
Airports: 55 (2000 est.)
Airports - with paved runways:
total: 24
over 3,047 m:^
2,438 to 3,047 m: 5
1, 524 to 2,437 m''A
914 to 1,523 m: 3
under 914 m: 14 (2000 est.)
Airports - with unpaved runways:
total: 31
1,524 to 2,437 m:^
914 to 1,523 m: 3
under 914 m: 27 (2000 est.)
Heliports: 1 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only
Railways:
total: 862 m; note - a spur of the Italian Railways
system, serving Rome''s Saint Peter''s station
standard gauge: 802 m 1.435-m gauge (1999)
Highways: none; all city streets
Waterways: none
Ports and harbors: none
Airports: none
Heliports: 1 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only;
note - there is one small boat landing area along the
middle of the west coast
Airports: airstrip constructed in 1937 for scheduled
refueling stop on the round-the-world flight of Amelia
EARHART and Fred NOONAN - they left Lae, New
Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable (2000 est.)
Transportation - note: Earhart Light is a day
beacon near the middle of the west coast that was
partially destroyed during World War II, but has since
been rebuilt; named in memory of famed aviatrix
Amelia EARHART
227
Howland Island (continued)
Railways: 0 km
Highways:
total: 234 km
paved: 86 km
unpaved: 148 km (106 km of which is access and
plantation road) (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1524 to 2,437 m:1 (2000 est.)
Railways: 0 km
Highways:
total: 80 km
paved: 53 km
unpaved: 27 km (2001)
Waterways: none
Ports and harbors: none; loading jetties at Kingston
and Cascade
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2000 est.)','cac24cc211a371ad4bb5cef6692bada9720da93bcbc7ca10e2fdb02082f45ada','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ace482b73d6686b0624939307176f14284cedaae9d8ff18a5d364babbf9ed93',2001,'AZ','Azerbaijan','transportation',97,'Railways:
total: 2,125 km in common carrier service; does not
include industrial lines
broad gauge: 2,125 km 1.520-m gauge (1,278 km
electrified) (1993)
Highways:
tofa/; 24,981 km
paved: 23,057 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: 1 ,924 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1998)
Waterways: none
Pipelines: crude oil 1,130 km; petroleum products
630 km; natural gas 1,240 km
Ports and harbors: Baku (Baki)
Merchant marine:
total: 56 ships (1 ,000 GRT or over) totaling 253,882
GRT/31 3,252 DWT
ships by type: bulk 1 , cargo 12, petroleum tanker 40,
roll on/roll off 2, short-sea passenger 1 (2000 est.)
Airports: 52 (2000 est.)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 5
1,524 to 2,437 m: 4 (2000 est.)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m: 7
914 to 1,523 m: 8
under 914 m:28 (2000 est.)','4ab59f43e4849eca98e9640da429c5581b3d8abd3f2fa3e0550cd8d11901e301','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f78b46666e610ab0b9190e2d381f520031470f68a6828cb5b8b7930876be97ce',2001,'BS','Bahamas','transportation',102,'Railways: 0 km
Highways:
total: 2,693 km
paved: 1 ,546 km
unpaved: 1,147 km (1997)
Waterways: none
Ports and harbors: Freeport, Matthew Town,
Nassau
Merchant marine:
total: 1 ,049 ships (1 ,000 GRT or over) totaling
30,000,221 GRT/44,601,471 DWT
ships by type: bulk 185, cargo 214, chemical tanker
36, combination bulk 15, combination ore/oil 22,
container 66, liquefied gas 33, livestock carrier 1,
multi-functional large-load carrier 4, passenger 79,
passenger/cargo 1, petroleum tanker 182, railcar
carrier 1 , refrigerated cargo 118, roll on/roll off 50,
short-sea passenger 1 5, specialized tanker 3, vehicle
carrier 24
note: includes some foreign-owned ships registered
here as a flag of convenience: Algeria 2, Australia 1,
Austria 1 , Bermuda 6, Belgium 1 4, Canada 1 , Cuba 1 ,
Cyprus 2, Denmark 1 7, Finland 7, France 9, Germany
9, Greece 89, Hong Kong 7, Indonesia 2, India 1,
Israel 4, Italy 8, Japan 23, Jamaica 1, Kenya 1,
Lebanon 2, Luxembourg 2, Monaco 15, Malaysia 1,
Netherlands 16, Norway 139, Poland 3, Portugal 2,
Russia 2, Saudi Arabia 5, Singapore 12, Spain 7,
Sweden 14, Syria 1, Switzerland 7, UAE 1, Trinidad
and Tobago 2, UK 67, Ukraine 3, US 50, British Virgin
Islands 1, British Virgin Islands 1 (2000 est.)
Airports: 65 (2000 est.)
Airports - with paved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 13
under 914 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 29
914 to 1,523 m: 6
under 914 m: 23 (2000 est.)
Heliports: 1 (2000 est.)
M i i i t a r y
Miiitary branches: Royal Bahamas Defense Force
(Coast Guard only), Royal Bahamas Police Force
Military expenditures - doilar figure: $20 million
(FY95/96)
Military expenditures ■ percent of GDP: NA%','c670b98506e1ac548e0376b0636a83e753b00761b12fad42a47f6ca5682d467e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a61c6501fb8c6f30c0dcd9393c5d0caa507e37a337b9a97eb171a3ba4a80d64d',2001,'BH','Bahrain','transportation',110,'Railways: 0 km
Highways:
total: 3,104 km
paved: 2,433 km
unpaved: 731 km
note; there is a paved causeway connecting Bahrain
to Saudi Arabia (1997)
Waterways: none
Pipelines: crude oil 56 km; petroleum products 16
km; natural gas 32 km
Ports and harbors: Manama, Mina'' Salman, Sitrah
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 175,609
GRT/207,652 DWT
ships by type: bulk 2, cargo 3, container 2 (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m:1 (2000 est.)
Heliports: 1 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only;
note - there is one small boat landing area along the
middle of the west coast
Airports: 1 abandoned World War II runway of 1 ,665
m, completely covered with vegetation and unusable
(2000 est.)
Transportation - note: there is a day beacon near
the middle of the west coast','9ba9df2ec46741fc0c359155bc693208fc93940059ef226fcfddf0de12e93a05','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e41ef6791963d9337fb4b5d4bafb2dbd16073a6a41da2e3454d8b91ca022527',2001,'BD','Bangladesh','transportation',119,'Railways:
total: 2, 745 km
broad gauge: 923 km 1 .676-m gauge
narrow gauge: 1 ,822 km 1.000-m gauge (2000)
Highways:
fofa/; 201,182 km
paved; 19,1 12 km
unpaved; 182,070 km (1997)
Waterways: up to 8,046 km depending on season
note: includes 3,058 km main cargo routes
Pipelines: natural gas 1 ,250 km
Ports and harbors: Chittagong, Dhaka, Mongla
Port, Narayanganj (2001)
Merchant marine:
total: 35 ships (1 ,000 GRT or over) totaling 268,566
GRT/375,110DWT
ships by type: bulk 2, cargo 25, container 3,
petroleum tanker 2, refrigerated cargo 1 , roll on/rol! off
2 (2000 est.)
Airports: 18 (2000 est.)
Airports - with paved runways:
total: 15
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m; 5 (2000 est.)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m:1
under 914 m; 2 (2000 est.)','e46a350b777065eb952286db09e32b570f84f471072e90265cdc7c4808414f73','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ebc184b96a5d155ab6e17c8f082b6e18d12064017452198ae3bfe8ac2cdbd1',2001,'LC','Saint Lucia','transportation',128,'Railways: 0 km
Highways:
total: 1 ,600 km
paved: 1 ,578 km
unpaved: 22 km (1998)
Waterways: none
Ports and harbors: Bridgetown, Speightstown (Port
Charles Marina)
Merchant marine:
total: 47 ships (1 ,000 GRT or over) totaling 671 ,545
GRT/1,125,635 DWT
ships by type: bulk 10, cargo 28, combination bulk 1 ,
container 2, petroleum tanker 4, refrigerated cargo 1 ,
roll on/roll off 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Canada 2, Hong Kong
1 (2000 est.)
Airports: 1 (2000 est.)
Airports ■ with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only','fd118e160dad79b998ce9a37c83a8831540cf2fe59c87940f1eb4aa4409dacf0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a21d211e59c0e7931c4adeabc38c3a6e2c6b114e34cdf03e20f15eff8aa73b4',2001,'BY','Belarus','transportation',134,'Background: This atoll is a volcanic rock
surrounded by reefs and is awash at high tide. A
French possession since 1897, it was placed under
the administration of a commissioner residing in
Reunion in 1968.','c7e40b67a1cbbe3571854e228dfdf25d883ff92005fc5b96138fe4641eff5ae4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5d19667a74c14255137e614f52c16d3fddb5176fc2758a60f9cb149ac7100e9',2001,'FR','France','transportation',146,'Railways:
total: 5,563 km
broad gauge: 5,563 km 1 .520-m gauge (894 km
electrified)
Highways:
total: 63,355 km
paved: 60,567 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: 2 JBS km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1998)
Waterways: NA km; note - Belarus has extensive
and widely used canal and river systems
Pipelines: crude oil 1 ,470 km; refined products
1,100 km; natural gas 1,980 km (1992)
Ports and harbors: Mazyr
Airports: 136 (2000 est.)
Airports - with paved runways:
total: 33
over 3,047 m: 2
2,438 to 3,047 m: 19
1,524 to 2,437 m:1
under 914 m: 1 1 (2000 est.)
Airports - with unpaved runways:
total: 103
over 3,047 m: 3
2,438 to 3,047m: 10
1,524 to 2,437 m: 11
914 to 1,523 m: 14
under 914 m: 65 (2000 est.)
Railways:
total: 3,437 km (2,446 km electrified; 2,563 km double
track)
standard gauge: 3 ,437 km 1.435-m gauge (1998)
Highways:
total: 145,774 km
pa vecf; 116,182 km (including 1,674 km of
expressways)
unpaved: 29,592 km (1999)
Waterways: 2,043 km (1 ,528 km in regular
commercial use)
Pipelines: crude oil 161 km; petroleum products
1,167 km; natural gas 3,300 km
Ports and harbors: Antwerp (one of the world''s
busiest ports), Brugge, Gent, Hasselt, Liege, Mons,
Namur, Oostende, Zeebrugge
Merchant marine:
total: 21 ships (1,000 GRT or over) totaling 32,912
GRT/53,161 DWT
ships by type: cargo 6, chemical tanker 9, petroleum
tanker 6 (2000 est.)
Airports: 42 (2000 est.)
Airports - with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 914 m; 6 (2000 est.)
Airports - with unpaved runways:
total: 13
914 to 1,523 m: 2
under 914 m: 16 (2000 est.)
Heiiports: 1 (2000 est.)
Railways: 0 km
Highways:
total: 15 km
paved: NA km
unpaved: HA km (2001)
Waterways: none
Ports and harbors: none; lagoon anchorage only
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: ^ (2000 est.)
Railways:
total: 660 km
narrow gauge: 660 km 1 .000-meter gauge; 25 km
double track (1995 est.)
Highways:
total: 50,400 km
paved: 4,889 km
unpaved: 45,511 km (1996)
Waterways: 980 km (navigable rivers, canals, and
numerous coastal lagoons)
Ports and harbors: Abidjan, Aboisso, Dabou,
San-Pedro
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,200 GRT/
1,500 DWT
ships by type: petroleum tanker 1 (2000 est.)
Airports: 36 (2000 est.)
Airports - with paved runways:
total: 7
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2000 est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m: 8
914 to 1,523 m: 12
under 914 m; 9 (2000 est.)
Railways: 0 km
Highways:
total: 440 km
paved: 50 km
unpaved: 390 km
Waterways: none
Ports and harbors: Stanley
Merchant marine: none (2000 est.)
Airports: 5 (2000 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:]
under 914 m:] (2000 est.)
Airports - with unpaved runways:
total: 3
under 914 m; 3 (2000 est.)
Railways: 0 km (1995)
Highways:
fofa/; 1,817 km
paved: 727 km
unpaved: 1,090 km (1995)
Waterways: 3,300 km navigable by native craft
note: 460 km navigable by small oceangoing vessels
and coastal and river steamers
Ports and harbors: Cayenne, Degrad des Cannes,
Saint-Laurent du Maroni
Merchant marine: none (2000 est.)
Airports: 1 1 (2000 est.)
Airports - with paved runways:
total: 4
over 3,047 m:1
914 to 1,523 m: 2
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine:
total: 74 ships (1 ,000 GRT or over) totaling 3,024,1 94
GRT/5,255,703 DWT
ships by type: bulk 7, cargo 5, chemical tanker 9,
container 1 1 , liquefied gas 7, petroleum tanker 23, roll
on/roll off 12
note: includes some foreign-owned ships registered
here as a flag of convenience: France 1 (2000 est.)
Airports: none
Railways:
total: 649 km (Gabon State Railways or OCTRA)
standard gauge: 649 km 1 .435-m gauge; single track
(1994)
Highways:
total: 7,670 km
paved: 629 km (including 30 km of expressways)
unpaved: 7,041 km (1996)
Waterways: 1,600 km (perennially navigable)
Pipelines: crude oil 270 km; petroleum products 14
km
Ports and harbors: Cap Lopez, Kango, Lambarene,
Libreville, Mayumba, Owendo, Port-Gentil
Airports: 59 (2000 est.)
182
Gabon (continued)
Airports - with paved runways:
total: ^0
over 3,047 m:\\
2,433 to 3,047 rr\\:\\
1,524 to 2,437 m:l
914 to 1,523 mil (2000 est.)
Airports - with unpaved runways:
total: A9
1,524 to 2,437 m: 3
914 to 1,523 m:M
under 914 m: 24 (2000 est.)
Railways: 0 km
Highways:
total: 2,700 km
paved: 956 km
unpaved: ^,74A km (1996)
Waterways: 400 km
Ports and harbors: Banjul
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)
Railways:
total: NA km; note - one line, abandoned and in
disrepair, little trackage remains
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: small, poorly developed road network
Waterways: none
Ports and harbors: Gaza
Airports: 2
note: includes Gaza International Airport that opened
on 24 November 1998 as part of agreements
stipulated in the September 1995 Oslo II Accord and
the 23 October 1998 Wye River Memorandum
(2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2000 est.)
Railways:
total: 1 ,583 km in common carrier service; does not
include industrial lines
broad gauge: 5^3 km 1.520-m gauge (1993)
Highways:
total: 33,900 km
paved: 29,500 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: 4,400 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: none
Pipelines: crude oil 370 km; refined products 300
km; natural gas 440 km (1992)
Ports and harbors: Bat''umi, P’ot''i, Sokhumi
Merchant marine:
total: 37 ships (1 ,000 GRT or over) totaling 1 31 ,31 6
GRT/1 90,289 DWT
ships by type: bulk 3, cargo 25, chemical tanker 2,
container 2, petroleum tanker 4, roll on/roll off 1
(2000 est.)
Airports: 31 (2000 est.)
Airports - with paved runways:
total: 16
over 3,047 m: 1
2,438 to 3,047m: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 3 {2000 est.)
Airports - with unpaved runways:
total: 15
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 8 {2000 est.)
Transportation - note: transportation network is in
poor condition resulting from ethnic conflict, criminal
activities, and fuel shortages; network lacks
maintenance and repair
Railways:
total: NA km; privately owned, narrow-gauge
plantation lines
Highways:
total: 2,560 km
paved: 965 km
unpaved: 1,595 km (1996)
204
Guadeloupe (continued)
Waterways: none
Ports and harbors: Basse-Terre, Gustavia (on
Saint Barthelemy), Marigot, Pointe-a-Pitre
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,240 GRT/
109 DWT
ships by type: passenger 1 (2000 est.)
Airports: 9 (2000 est.)
Airports - with paved runways:
total: 8
over 3,047 m: ^
914 to 1,523 m: 2
under 914 m: 5 (2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m''A (2000 est.)
Railways: 0 km
Highways:
total: 2,724 km (1994)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Fort-de-France, La Trinite
Merchant marine: none (2000 est.)
Airports: 2 (2000 est.)
Airports ■ with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2000 est.)
326
Martinique (continued)
Railways: 1,815 km
broad gauge: 1 ,81 5 km 1 .524-m gauge (2001 )
Highways:
total: 3,387 km
paved: 1 ,563 km
unpaved: 1 ,824 km
note: [here are also 45,862 km of rural roads that
consist of rough, unimproved, cross-country tracks
(2000)
Waterways: 400 km (1999)
Ports and harbors: none
Airports: 34(2000est.)
Airports ■ with paved runways:
total: 8
2,438 to 3,047m: 7
under 914 m:^ (2000 est.)
Airports - with unpaved runways:
total: 26
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 91 4 m: 5 (2000 est.)
Railways: 0 km
Highways;
total: 2,784 km
paved: 2,187 km
unpaved: 597 km (1987 est.)
Waterways; none
Ports and harbors: Le Port, Pointe des Galets
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 28,264 GRT/
44,885 DWT
ships by type: chemical tanker 1 (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914 to 1,523 m:1 (2000 est.)
Railways:
total: 16,878 km
broad gauge: 342 km 1 .600-m gauge (1 90 km double
track); note - all 1 .600-m gauge track, of which 342 km
is in common carrier use, and is in Northern Ireland
standard gauge: 1 6,536 km 1 .435-m gauge (4,928 km
electrified; 12,591 km double or multiple track) (1996)
Highways:
tofa/; 371,603 km
paved: 371 ,603 km (including 3,303 km of
expressways)
unpaved: 0 km (1 998 est.)
Waterways: 3,200 km
Pipelines: crude oil (almost all insignificant) 933 km;
petroleum products 2,993 km; natural gas 12,800 km
Ports and harbors: Aberdeen, Belfast, Bristol,
Cardiff, Dover, Falmouth, Felixstowe, Glasgow,
Grangemouth, Hull, Leith, Liverpool, London,
Manchester, Peterhead, Plymouth, Portsmouth,
Scapa Flow, Southampton, Sullom Voe, Tees, Tyne
Merchant marine;
total: 200 ships (1 ,000 GRT or over) totaling
3,934,776 GRT/3,760,240 DWT
ships by type: bulk 4, cargo 31 , chemical tanker 1 1 ,
combination ore/oil 1, container 47, liquefied gas 3,
passenger 14, passenger/cargo 1, petroleum tanker
52, refrigerated cargo 4, roll on/roll off 19, short-sea
passenger 10, specialized tanker 1, vehicle carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 1 (2000 est.)
Airports; 489 (2000 est.)
Airports - with paved runways:
tofa/;349
over 3,047 m: 10
2,438 to 3,047 m: 33
529
United Kingdom (continued)
1,524 to 2,437 m:m
914 to 1,523 m: 89
under 914 m: 55 (2000 est.)
Airports - with unpaved runways:
total: 140
1,524 to 2,437 m:1
914 to 1,523 m: 23
under 914 m: 116 (2000 est.)
Heliports: 1 1 (2000 est.)
M M i t a r y
Miiitary branches: Army, Royal Navy (includes
Royal Marines), Royal Air Force
Military manpower ■ avaiiability:
males age 15-49: 14,599,199 (2001 est.)
Military manpower - fit for miiitary service:
males age 15-49: 12,139,930 (2001 est.)
Miiitary expenditures - doliar figure: $36,884
billion (FY97)
Military expenditures - percent of GDP: 2.7%
(FY97)
Railways: 0 km
Highways:
total: 4,500 km
paved: 2,700 km
unpaved: 1 ,800 km (1997 est.)
note: Israelis have developed many highways to
service Jewish settlements
Waterways: none
Ports and harbors: none
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:1
1,524 to 2,437 m:1
under 914 m: 1 (2000 est.)','8187511b2176ad72b9387e304d8f73b27406f49db09844556bfa0a165b489104','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2b5f01d59409ebc7e925f615b30c4a8875851b4c2310441992d143251a3bf18',2001,'BZ','Belize','transportation',155,'Railways: 0 km
Highways:
total: 2fi72 km
paved: 488 km
unpaved: 2,384 km (1998 est.)
Waterways; 825 km (river network used by
shallow-draft craft; seasonally navigable)
Ports and harbors: Belize City, Big Creek, Corozol,
Punta Gorda
Merchant marine;
total: 402 ships (1 ,000 GRT or over) totaling
1,575,851 GRT/2,241,731 DWT
ships by type: bulk 27, cargo 265, chemical tanker 6,
combination ore/oil 1, container 14, passenger 1,
passenger/cargo 2, petroleum tanker 56, refrigerated
cargo 18, roll on/roll off 7, short-sea passenger 1,
specialized tanker 1 , vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Cuba 1 , Singapore 1 ,
US 1 (2000 est.)
Airports: 44 (2000 est.)
Airports - with paved runways:
total: 4
1,524 to 2,437 m-A
914 tot, 523 m:\\
under 914 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 40
2,438 to 3,047 m:1
914 to 1,523 m: 10
under 914 m: 29 (2000 est.)
Railways:
total: 578 km (single track)
narrow gauge: 573 km 1 .000-m gauge (1995 est.)
Highways:
total: 6,787 km
paved; 1,357 km (including 10 km of expressways)
unpaved: 5,430 km (1997 est.)
Waterways: streams navigable along small sections,
important only locally
Ports and harbors: Cotonou, Porto-Novo
Merchant marine: none (2000 est.)
Airports: 5 (2000 est.)
Airports - with paved runways:
total: 1
7.524 to 2,437 m; 1 (2000 est.)
Airports - with unpaved runways:
total: 4
2,438 to 3,047 m''A
1.524 to 2,437 m:]
914 to 1,523 m: 2 (2000 est.)','959b9aefd6a04c2a29dccaeec39ae2c03115c94cefd050c9be73e8d449a55507','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9afcd3753c18ff2de3a321af58f97e4eee5ea891f8be7815932240ed4a473ba3',2001,'BM','Bermuda','transportation',164,'Railways: 0 km
Highways:
total: 225 km
paved: 225 km
unpaved: 0 km
note: in addition, there are 232 km of paved and
unpaved roads that are privately owned (1997)
Waterways: none
Ports and harbors: Hamilton, Saint George
Merchant marine:
total: 105 ships (1 ,000 GRT or over) totaling
5,836,538 GRT/9,728,045 DWT
ships by type: bulk 27, cargo 4, container 1 5, liquefied
gas 7, passenger 2, petroleum tanker 23, refrigerated
cargo 16, roll on/ro!l off 8, short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Canada 1 0, Hong Kong
10, Japan 1, Nigeria 4, Saudi Arabia 1, Sweden 3,
Switzerland 2, UK 10, US 7 (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (2000 est.)
Railways: 0 km
Highways;
total: 3,285 km
pavecf.'' 1,994 km
unpaved: 1 ,291 km (1996)
Waterways: none
Ports and harbors: none
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m.- 1 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2000 est.)
Railways:
total: 3,691 km (single track)
narrow gauge: 3,652 km 1 .000-m gauge; 39 km
0.760-m gauge (13 km electrified) (1995)
Highways:
total: 49,400 km
paved; 2,500 km (including 30 km of expressways)
unpaved; 46,900 km (1996)
Waterways: 10,000 km (commercially navigable)
Pipelines; crude oil 1 ,800 km; petroleum products
580 km; natural gas 1 ,495 km
61
Bolivia (continued)
Ports and harbors: none; however, Bolivia has free
port privileges in maritime ports in Argentina, Brazil,
Chile, and Paraguay
Merchant marine:
total: 42 ships (1 ,000 GRT or over) totaling 141 ,017
GRT/21 1,058 DWT
ships by type: bulk 5, cargo 20, chemical tanker 3,
container 1, petroleum tanker 10, roll on/roll off 3
(2000 est.)
Airports: 1 ,093 (2000 est.)
Airports - with paved runways:
total:
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m:2 {2m est.)
Airports - with unpaved runways:
tofa/; 1,080
2,438 to 3,047 m: 3
1,524 to 2,437 m: 65
914 to 1,523 m: 212
under 91 4 m: 800 (2000 est.)','e26ea127498a3e13d13f151107d0362e04cc0d7d350863f64a000a3c4ee28d03','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4af18b2237667c9bc8ea2558c8fcd3d366fe357deef60f094d6e8ed1e7be2734',2001,'IT','Italy','transportation',170,'Railways:
total: 1 ,021 km (electrified 795 km; operating as diesel
or steam until grids are repaired)
standard gauge: 1 ,021 km 1 .435-m gauge (1 995);
note - many segments still need repair and/or
reconstruction
64
Bosnia and Herzegovina (continued)
Highways:
total: 21 ,846 km
paired; 14,020 km
unpaved: 7,826 km
note: road system is in need of maintenance and
repair (2001)
Waterways: NA km; large sections of the Sava
blocked by downed bridges, silt, and debris
Pipelines: crude oil 174 km; natural gas 90 km
(1992)
Ports and harbors: Bosanska Gradiska, BosanskI
Brod, Bosanski Samac, and Brcko (all inland
waterway ports on the Sava), Orasje
Merchant marine: none (2000 est.)
Airports: 28 (2000 est.)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 91 4 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 19
1,524 to 2,437 m:\\
914 to 1,523 m:7
under 914 m:M (2000 est.)
Heliports: 4 (2000 est.)
Railways: 0 km; note - there is a 1 .5 km cable
railway connecting the city of San Marino to Borgo
Maggiore
Highways:
total: 220 km
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: none
Airports: none
Railways:
total: 4,492 km (1 ,564 km double track)
standard gauge: 3,317 km 1 .435-m gauge (3,288 km
electrified)
narrow gauge: ^ ^65 km 1.000-m gauge (1,165 km
electrified): 10 km 0.800-m gauge (1998)
Highways:
total: 71 ,059 km (including 1 ,638 km of expressways)
(1998 est.)
paved: NA km
unpaved: NA km
Waterways: 65 km
note.'' The Rhine carries heavy traffic on the
Basel-Rheinfelden and Schaffhausen-Bodensee
stretches: there are also 12 navigable lakes
Pipelines: crude oil 314 km: natural gas 1,506 km
Ports and harbors: Basel
Merchant marine:
total: 24 ships (1 ,000 GRT or over) totaling 435,966
GRT/780,458 DWT
ships by type: bulk 12, cargo 6, chemical tanker 5,
petroleum tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: UK 1 (2000 est.)
Airports: 67 (2000 est.)
Airports * with paved runways:
total: 42
over 3,047 m: 3
2,438 to 3,047 m: A
1,524 to 2,437 m‘A3
914 to 1,523 m: 7
under 914 m: 15 (2000 est.)
Airports ■ with unpaved runways:
total: 25
under 914 m: 25 (2000 est.)
Railways:
total: 2,750 km
standard gauge: 2,423 km 1,435-m gauge
narrow gauge: 327 km 1.050-m gauge
note: rail link between Syria and Iraq replaced in 2000
(2000)
Highways:
total: 36,377 km
paved: 26,299 km (including 877 km of expressways)
unpaved: 10,078 km (1999 est.)
Waterways: 870 km (minimal economic importance)
Pipelines: crude oil 1 ,304 km; petroleum products
515 km
Ports and harbors: Baniyas, Jablah, Latakia,
Tartus
Merchant marine:
total: 133 ships (1,000 GRT or over) totaling 425,392
GRT/612,097 DWT
ships by type: bulk 1 1 , cargo 117, livestock carrier 4,
roll on/roll off 1 (2000 est.)
Airports: 100 (2000 est.)
Airports - with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m:ie
914 to 1,523 m:\\
under 914 m; 2 (2000 est.)
Airports - with unpaved runways:
total: 76
1,524 to 2,437 m: 2
914 to 1,523 m:
under 914 m: 63 (2000 est.)
Heliports: 2 (2000 est.)','978c4f6feb0e2529681dd3c3401c2d6fa6bf354c93ce2244009b6f745e05d135','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c1f086301aed44e1a17bf551c367cd0d57a1197de5cfeceec4edf18fddc7fb0',2001,'BW','Botswana','transportation',179,'Railways:
total: 97 ^ km
narrow gauge: 97^ km 1.067-m gauge (1995)
Highways:
tofa/: 18,482 km
paved: 4,343 km
unpaved: 14,139 km (1996)
Waterways: none
Ports and harbors: none
Airports: 92(2000est.)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 8
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 81
1,524 to 2,437 m: 3
914 to 1,523 m: 56
under 914 m: 22 (2000 est.)','c7b76dac28998b8663369ccea2debb30a14814436c718100addefb598557dd89','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4427150f880fe76daa092a6d7c0d7a589e1fe86d45bea95c3dc9368d9c0c9a3f',2001,'BR','Brazil','transportation',193,'Railways:
total: 27,882 km (1,122 km electrified); note -
excludes urban rail
broad gauge: 4,057 km 1.600-m gauge
narrow gauge: 23,489 km 1.000-m gauge
dual gauge: 336 km 1 .000-m and 1 .600-m gauges
(three rails) (1999 est.)
Highways:
total: 1 .98 million km
paved; 184,140 km
unpaved; 1,795,860 km (1996)
Waterways: 50,000 km
Pipelines: crude oil 2,980 km; petroleum products
4,762 km; natural gas 4,246 km (1998)
Ports and harbors: Belem, Fortaleza, llheus,
Imbituba, Manaus, Paranagua, Porto Alegre, Recife,
Rio de Janeiro, Rio Grande, Salvador, Santos, Vitoria
Merchant marine:
total: 171 ships (1 ,000 GRT or over) totaling
3,788,999 GRT/6,067,31 4 DWT
ships by type: bulk 33, cargo 26, chemical tanker 5,
combination ore/oil 9, container 12, liquefied gas 1 1 ,
multi-functional large-load carrier 1, passenger/cargo
5, petroleum tanker 56, roll on/roll off 12, short-sea
passenger 1 (2000 est.)
Airports: 3,264 (2000 est.)
Airports - with paved runways:
total: 570
over 3,047 m: 5
2,438 to 3,047 m:2]
1,524 to 2,437 m-A4\\
914 to 1,523 m: 370
under 914 m: 33 (2000 est.)
Airports - with unpaved runways:
tote/; 2,694
1,524 to 2,437 m: 88
914 to 1,523 m: 1,279
under 914 m; 1,347 (2000 est.)','3c0ac488a28c929324025880f0a5ff0eaa942e037fe655c9ea48bd91172b534a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99a661d8f9ee7622e7b725f7bc110545466c759bdb4081bb9b7adba82b5b3d7a',2001,'ID','Indonesia','transportation',200,'Highways:
total: NA km
paved: short stretch of paved road of NA km between
port and airfield on Diego Garcia
unpaved: NA km
Waterways; none
Ports and harbors: Diego Garcia
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m:^ (2000 est.)
Miiitary
Military - note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
Railways: 0 km
Highways:
total: 132 km
pavecf; 132 km
unpaved: 0 km (1997)
Waterways: none
Ports and harbors: Road Town
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 70,285 GRT/
6,946 DWT
ships by type: passenger 1 (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 2
914 to 1,523 m:1
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2000 est.)
Railways: 0 km
Highways:
total: 240 km
paved: 42 km
unpaved: 198 km (1996)
Waterways: none
Ports and harbors: Colonia (Yap), Kolonia
(Pohnpei), Lele, Moen
Merchant marine: none (2000 est.)
Airports: 7 (2000 est.)
Airports - with paved runways:
total: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2000 est.)
Highways;
total: 32 km
paved: NA km
unpaved: NA km
Waterways: none
Pipelines; 7.8 km
Ports and harbors: Sand Island
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2000 est.)
Railways:
total: 1 ,328 km
broad gauge: 1 ,328 km 1.520-m gauge (1992)
Highways:
total: 12,300 km
paved: 10,738 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
340
Moldova (continued)
unpaved: 1 ,562 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1996)
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports and harbors: none
Airports: 30(2000est.)
Airports - with paved runways:
total:!
over 3,047 n\\:\\
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
under 914 m: 1 (2000 est.)
Airports ■ with unpaved runways:
total: 23
2,438 to 3,047 m: 4
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m: 14 (2000 est.)
Railways:
total: 38.6 km
narrow gauge: 38.6 km 1 .000-m gauge
note: there is a 83 km mass transit system with 48
stations
Highways:
tofa/;3,150 km
paved: 3,066 km (including 150 km of expressways)
unpaved: 84 km (2000)
Waterways: none
Ports and harbors: Singapore
Merchant marine:
total: 879 ships (1 ,000 GRT or over) totaling
20,849,168 GRT/33,21 5,317 DWT
ships by type: bulk 1 34, cargo 111, chemical tanker
63, combination bulk 10, combination ore/oil 6,
container 167, liquefied gas 28, livestock carrier 2,
multi-functional large-load carrier 4, passenger 1 ,
petroleum tanker 295, refrigerated cargo 7, roll on/roll
off 7, short-sea passenger 1, specialized tanker 10,
vehicle carrier 33
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , Bermuda 1 2,
Belgium 6, China 9, Denmark 29, Germany 8, Greece
1 , Hong Kong 20, Indonesia 9, Japan 32, South Korea
3, Netherlands 2, Norway 9, Russia 1 , Sweden 22,
Thailand 22, Taiwan 17, UK 3, US 10 (2000 est.)
Airports: 9 (2000 est.)
Airports - with paved runways:
total: 9
over 3,047 m: 2
2,438 to 3,047 m:\\
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m:1 (2000 est.)
Heliports: 1 (2000 est.)
453
Singapore (continued)','9b675e89e6df5241f74abf9f8479a809f5cbe37b7dac3b91d20dce4542c7b89f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a5ed5b1ef293d7ff512e1d8fccfb12b82ad7903d67e4215f3887a2e6d2908ae',2001,'BG','Bulgaria','transportation',204,'Railways:
total: ^3 km (private line)
narrow gauge: ^3 km 0.61 0-m gauge
Highways:
tofa/; 1,712 km
paved: 1,284 km
unpaved: 428 km (1996)
Waterways: 209 km; navigable by craft drawing less
than 1.2 m
Pipelines: crude oil 135 km; petroleum products 41 8
km; natural gas 920 km
Ports and harbors: Bandar Seri Begawan, Kuala
Belait, Muara, Seria, Tutong
Merchant marine:
tofa/.'' 7 ships (1,000 GRT or over) totaling 348,476
GRT/340,635 DWT
ships by type: liquefied gas 7 (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2000 est.)
Heliports: 3 (2000 est.)
Railways:
total: 4,294 km
standard gauge: 4, 0A9 km 1.435-m gauge (2,710 km
electrified; 917 km double track)
narrow gauge: 245 km 0.760-m gauge (1998)
Highways:
total: 36,724 km
paved: 33,786 km (including 314 km of expressways)
unpaved: 2,938 km (1999)
Waterways: 470 km (1987)
Pipelines: petroleum products 525 km; natural gas
1,500 km (1999)
Ports and harbors: Burgas, Lorn, Nesebur, Ruse,
Varna, Vidin
Merchant marine:
total: 81 ships (1 ,000 GRT or over) totaling 938,706
GRT/1 ,440,374 DWT
ships by type: bulk 44, cargo 1 6, chemical tanker 4,
container 2, passenger/cargo 1 , petroleum tanker 6,
railcar carrier 2, refrigerated cargo 1 , roll on/roll off 3,
short-sea passenger 1 , specialized tanker 1
(2000 est.)
Airports: 215 (2000 est.)
Airports - with paved runways:
total: 128
over 3,047 m: 1
2,438 to 3,047 m: 19
1,524 to 2,437 m: 15
914 to 1,523 m:1
under 914 m: 92 (2000 est.)
Airports - with unpaved runways:
total: 87
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 75 (2000 est.)
Heliports: 1 (2000 est.)','91e3df8ad21ed61b73ac1056f7db7e58057e2cdef61fef462861fa483c50718a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ea59154cfbec095402248da201b4bd7911b94c13d17c01fc02ea31eda235288',2001,'ET','Ethiopia','transportation',217,'Railways:
total: 622 km (517 km from Ouagadougou to the Cote
d''Ivoire border and 105 km from Ouagadougou to
Kaya)
narrow gauge: 622 km I.OOO-m gauge (1995 est.)
Highways:
total: ^2, 506 km
paved.'' 2,001 km
t/npaved.'' 10,505 km (1996)
Waterways: none
Ports and harbors: none
Airports: 33 (2000 est.)
Airports ■ with paved runways:
total: 2
over 3,047 m-A
2,438 to 3,047 m:^ (2000 est.)
Airports ■ with unpaved runways:
total: 31
1,524 to 2,437 m: 3
914 to 1,523 m: 12
under 914 m: 16 (2000 est.)
Railways;
total: 681 km (Ethiopian segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 681 km 1.000-m gauge
note: in April 1998, Djibouti and Ethiopia announced
plans to revitalize the century-old railroad that links
their capitals; since May 1998 Ethiopia has expended
considerable effort to repair and maintain the lines
Highways:
total: 24,145 km
paved: 3,290 km
t/npavecf; 20,855 km (1998)
Waterways: none
Ports and harbors: none; Ethiopia is landlocked
and was by agreement with Eritrea using the ports of
Assab and Massawa; since the border dispute with
Eritrea flared, Ethiopia has used the port of Djibouti for
nearly all of its imports
Merchant marine:
total: 1 1 ships (1 ,000 GRT or over) totaling 85,382
GRT/1 08,526 DWT
ships by type: cargo 6, container 1 , petroleum tanker
1 , roll on/roll off 3 (2000 est.)
Airports: 86 (2000 est.)
Airports - with paved runways:
total: 12
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 3
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 74
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 10
914 to 1,523 m: 35
under 914 m: 20 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2000 est.)
Railways: 0 km
Highways:
total: 4,400 km
paved: 453 km
unpaved: 3,947 km (1996)
Waterways: several rivers are accessible to coastal
shipping
Ports and harbors: Bissau, Buba, Cacheu, Farim
Merchant marine: none (2000 est.)
Airports: 29 (2000 est.)
Airports - with paved runways:
total: 3
over 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 26
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m: 21 (2000 est.)
Railways: 0 km
Highways:
total: 320 km
pavecf; 21 8 km
unpaved: 102 km (1996 est.)
Waterways: none
Ports and harbors: Santo Antonio, Sao Tome
Merchant marine:
total: 39 ships (1 ,000 GRT or over) totaling 130,843
GRT/1 49,048 DWT
ships by type: bulk 3, cargo 21 , chemical tanker 1 ,
container 3, liquefied gas 1, livestock carrier 1,
petroleum tanker 1 , refrigerated cargo 2, roll on/roll off
5, specialized tanker 1 (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m:1 {2000 esl)
Railways:
total: 1,390 km
standard gauge: 1 ,390 km 1 .435-m gauge (448 km
double track) (1992)
Highways;
total: 146,524 km
paved: 44,104 km
unpaved: 102,420 km (1997 est.)
Waterways; none
Pipelines: crude oil 6,400 km; petroleum products
150 km; natural gas 2,200 km (includes natural gas
liquids 1,600 km)
Ports and harbors: Ad Dammam, Al Jubayl, Duba,
Jiddah, Jizan, Rabigh, Ra''s al Khafji, Mishab, Ras
Tanura, Yanbu'' al Bahr, Madinat Yanbu'' al Sinaiyah
Merchant marine:
total:71 ships (1 ,000 GRT or over) totaling 1,154,619
GRT/1 ,533,732 DWT
ships by type: cargo 1 1 , chemical tanker 8, container
5, liquefied gas 1 , livestock carrier 3, passenger 1 ,
petroleum tanker 18, refrigerated cargo 3, roll on/roll
off 1 3, short-sea passenger 8 (2000 est.)
Airports: 206 (2000 est.)
Airports - with paved runways:
total: 70
over 3,047 m: 31
2,438 to 3,047 m: 11
1,524 to 2,437 m: 23
914 to 1,523 m: 3
under 914 m: 2 (2000 est.)
444
Saudi Arabia (continued)
Airports - with unpaved runways:
total: 136
2,438 to 3,047 m: 5
1,524 to 2,437 m:ll
914 to 1,523 m: 39
under 914 m: 1 5 (2000 est.)
Heliports: 5 (2000 est.)
Railways:
total: 906 km
narrow gauge: 906 km 1 .000-meter gauge (70 km
double track)
Highways:
tofa/; 14,576 km
paved.'' 4,271 km
unpaved: 10,305 km (1996 est.)
Waterways: 897 km
note: 785 km on the Senegal river, and 1 1 2 km on the
Saloum river
Ports and harbors: Dakar, Kaolack, Matam, Podor,
Richard Toll, Saint-Louis, Ziguinchor
Airports: 20 (2000 est.)
Airports - with paved runways:
total:
over 3,047 m: "I
1,524 to 2,437 m: 7
914 to 1,523 m: 2 {2000 est.)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m:1 (2000 est.)','b15d382a22761ee95c24f98954f2af04785e2f731a0499c7acbcd3a1625cbf43','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('759768b0721498bfe7e711d1b4eea058d3b477f7b0ebe5759a1bd7db746a5840',2001,'TH','Thailand','transportation',226,'Railways:
total: 3,991 km
narrow gauge: 3, 99t km 1.000-m gauge
Highways:
total: 28,200 km
paved: 3,440 km
unpaved: 24,760 km (1996)
Waterways: 12,800 km
note: 3,200 km navigable by large commercial
vessels
Pipelines: crude oil 1 ,343 km; natural gas 330 km
Ports and harbors: Bassein, Bhamo, Chauk,
Mandalay, Moulmein, Myitkyina, Rangoon, Akyab
(Sittwe), Tavoy
Merchant marine:
total: 37 ships (1 ,000 GRT or over) totaling 411,181
GRT/632,769 DWT
ships by type: bulk 1 1 , cargo 20, container 1 ,
passenger/cargo 3, petroleum tanker 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Japan 2 (2000 est.)
Airports: 80 (2000 est.)
Airports - with paved runways:
total: 9
over 3,047 m: 3
2,438 to 3,047 m-A
1,524 to 2,437 m: 4
914 to 1,523 m:\\ (2000 est.)
Airports - with unpaved runways:
total: 71
over 3,047 m: 2
1,524 to 2,437 m: 1b
914 to 1,523 m: 22
under 914 m: 32 (2000 est.)
Heliports: 1 (2000 est.)
Railways: 0 km
Highways:
total: 14,480 km
paved: 1 ,028 km
unpaved: ^3A52 km (1996)
Waterways: Lake Tanganyika
Ports and harbors: Bujumbura
Airports: 4 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 3 {2000 est.)
Railways:
total: 3,940 km
narrow gauge: 3,940 km 1 .000-m gauge (99 km
double track)
Highways:
fofo/; 64,600 km
paved; 62,985 km
unpaved: 1 ,615 km (1996 est.)
Waterways: 4,000 km
note: 3,701 km are navigable throughout the year by
boats with drafts up to 0.9 meters; numerous minor
waterways serve shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas
350 km
Ports and harbors: Bangkok, Laem Chabang,
Pattani, Phuket, Sattahip, Si Racha, Songkhia
Merchant marine:
total: 294 ships (1 ,000 GRT or over) totaling
1,845,972 GRT/2,923, 91 4 DWT
ships by type: bulk 36, cargo 1 33, chemical tanker 3,
combination bulk 1 , container 14, liquefied gas 20,
multi-functional large-load carrier 3, passenger 1,
petroleum tanker 61 , refrigerated cargo 13, roll on/roll
off 2, short-sea passenger 2, specialized tanker 5
(2000 est.)
Airports: 110 (2000 est.)
Airports - with paved runways:
total: 59
over 3,047 m:Q
2,438 to 3,047 m:^^
1,524 to 2,437 m:2\\
914 to 1,523 m:M
under 914 m; 4 (2000 est.)
Airports - with unpaved runways:
total: 51
1,524 to 2,437 m:\\
914 to 1,523 m:\\3
under 914 m: 34 (2000 est.)
Heliports: 2 (2000 est.)
Railways:
total: 525 km (1995)
narrow gauge: 525 km 1.000-m gauge
Highways:
total: 7,520 km
paved: 2,376 km
unpaved: 5^44 km (1996 est.)
Waterways: 50 km (Mono river)
Ports and harbors: Kpeme, Lome
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 2,603 GRT/
2,800 DWT
ships by type: specialized tanker 1 (2000 est.)
Airports: 9 (2000 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 2 {2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 5
under 914 m; 2 (2000 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine: none (2000 est.)
Airports: none; lagoon landings by amphibious
aircraft from Samoa','e7b619736c8eaac19c57c310d1541e3ed6a97e5535c7e91c12909d2212496933','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c30c50a44e2f42e99802ddc65c6d7accaa9eb3e02e86a632cef26fe0c84041b3',2001,'KH','Cambodia','transportation',239,'Railways:
total: 603 km
narrow gauge: 603 km 1 .000-m gauge
Highways:
total: 35,769 km
paved: 4,1 65 km
unpaved: 31 ,604 km (1 997)
Waterways: 3,700 km
note: navigable all year to craft drawing 0.6 m or less;
282 km navigable to craft drawing as much as 1 .8 m
Ports and harbors: Kampong Saom
(Sihanoukville), Kampot, Krong Kaoh Kong, Phnom
Penh
Merchant marine:
total: 295 ships (1 ,000 GRT or over) totaling
1,305,932 GRT/1 ,853,487 DWT
ships by type: bulk 22, cargo 237, chemical tanker 1 ,
combination bulk 3, container 8, liquefied gas 1 ,
livestock carrier 2, multi-functional large-load carrier
1 , passenger/cargo 1 , petroleum tanker 7, refrigerated
cargo 6, roll on/roll off 5, short-sea passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Cyprus 3, South Korea
1, Malta 1, Panama 1, Russia 1, Singapore 1
(2000 est.)
Airports: 19 (2000 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 (r\\: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 13
1,524 to 2,437 m: 2
914 to 1,523 m: 11 (2000 est.)
Heliports: 3 (2000 est.)','0227115c2d55d5af8661e0965d88f6f7d24848f61908af5623db06e8f7d18d5e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d5d405c7fd6462a11c38605888504114ef74a60f99a25fd0d518c02487d2b39',2001,'CM','Cameroon','transportation',247,'Railways:
tofa/; 1,104 km
narrow gauge: 1,10^ km 1.000-m gauge (1995 est.)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,012 km (1 995)
Waterways: 2,090 km (of decreasing importance)
Ports and harbors: Bonaberi, Douala, Garoua,
Kribi, Tiko
Airports: 49 (2000 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 2
89
Cameroon (continued)
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m:-\\
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 38
1,524 to 2,437 m: 7
91 4 to 1,523 m: 21
under 91 4 m: 10 (2000 est.)','abc4eef3c905083d8c426e28af9a059309e5285cfae335f9d12755e2a27aceee','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5630a11c5c376363c6b4ecf802c2aa232f4fef3db0ee3d50792df514dc3b5e68',2001,'CA','Canada','transportation',256,'Railways:
total: 36,1 14 km; note - there are two major
transcontinental freight railway systems: Canadian
National (privatized November 1995) and Canadian
Pacific Railway; passenger service provided by
government-operated firm VIA, which has no trackage
of its own
standard gauge: 88^^ A km 1.435-m gauge (156 km
electrified) (1998)
Highways:
fofa/.’ 901,902 km
pa vecf.* 318,371 km (including 16,571 km of
expressways)
unpaved: 588, 58^ km (1999)
Waterways: 3,000 km (including Saint Lawrence
Seaway)
Pipelines: crude and refined oil 23,564 km; natural
gas 74,980 km
Ports and harbors: Becancour (Quebec), Churchill,
Halifax, Hamilton, Montreal, New Westminster, Prince
Rupert, Quebec, Saint John (New Brunswick), St.
John''s (Newfoundland), Sept Isles, Sydney,
Trois-Rivieres, Thunder Bay, Toronto, Vancouver,
Windsor
Merchant marine:
total: 121 ships (1 ,000 GRT or over) totaling
1,767,259 GRT/2,633, 290 DWT
ships by type: barge carrier 1 , bulk 67, cargo 1 3,
chemical tanker 5, combination bulk 1 , passenger 3,
passenger/cargo 1, petroleum tanker 17, railcar
carrier 2, roll on/roll off 7, short-sea passenger 3,
specialized tanker 1 (2000 est.)
Airports: 1,417 (2000 est.)
Airports - with paved runways:
fofa/.‘517
over 3,047 m: 18
2,438 to 3,047 m: 15
1,524 to 2,437 m: 151
914 to 1,523 m: 244
under 914 m: 89 (2000 est.)
Airports ■ with unpaved runways:
total: 900
1,524 to 2,437 m: 74
914 to 1,523 m: 882
under 914 m: 464 (2000 est.)
Heliports: 18 (2000 est.)','bf77c726530683107a6ba17ff34c83d85f80c340673cd29e12e438ce98bcf837','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c71d0dafa22880a82ec1d0490aa5b21083f3d5d75f3f1e0d25faef05d7d7a7c',2001,'PT','Portugal','transportation',262,'Railways: 0 km
Highways:
total: 1,100 km
paved: 858 km
unpaved: 242 km (1996)
Waterways: none
Ports and harbors: Mindelo, Praia, Tarrafal
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 9,523 GRT/
11,798 DWT
ships by type: cargo 4, chemical tanker 1 (2000 est.)
Airports: 8 (2000)
Airports - with paved runways:
total: 3
over 3,047 m:1
914 to 1,523 m: 7 (2000)
Railways:
total: 2,850 km
broad gauge: 2,576 km 1 .668-m gauge (623 km
electrified; 426 km double track)
411
Portugal (continued)
narrow gauge: 274 km 1.000-m gauge (1998)
Highways:
total: 6SJ32 km
paved: 59,1 10 km (including 797 km of expressways)
unpaved: 9,622 km (1999)
Waterways: 820 km
note: relatively unimportant to national economy,
used by shallow-draft craft limited to 300 metric-ton or
less cargo capacity
Pipelines: crude oil 22 km; petroleum products 58
km; natural gas 700 km
note: the secondary lines for the natural gas pipeline
that will be 300 km long have not yet been built
Ports and harbors: Aveiro, Funchal (Madeira
Islands), Horta (Azores), Leixoes, Lisbon, Porto,
Ponta Delgada (Azores), Praia da Vitoria (Azores),
Setubal, Viana do Castelo
Merchant marine:
total: 1 58 ships (1 ,000 GRT or over) totaling
1,053,586 GRT/1 ,61 1,238 DWT
ships by type: bulk 14, cargo 84, chemical tanker 16,
container 10, liquefied gas 7, multi-functional
large-load carrier 1 , petroleum tanker 1 1 , refrigerated
cargo 1 , roll on/roll off 6, short-sea passenger 4,
vehicle carrier 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Spain 1 (2000 est.)
Airports: 66 (2000 est.)
Airports - with paved runways:
total: 40
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4
914 to 1,523 m:M
under 914 m; 5 (2000 est.)
Airports • with unpaved runways:
total: 26
914 to 1,523 m:^
under 914 m: 25 (2000 est.)','c380c8a92442ee24a524a3b77818e8aa0b210c6a36ea6853fbaaa3f970ac8b84','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9f28f454cae9bb4e93323dee3eba7cb6f687daecb60a8d23e2b0683a08373ac',2001,'HN','Honduras','transportation',273,'Railways: 0 km
Highways:
total: 406 km
paved: 304 km
unpaved: ^02 km
Waterways: none
Ports and harbors: Cayman Brae, George Town
Merchant marine:
total: 106 ships (1,000 GRT or over) totaling
1,656,452 GRT/2,643, 036 DWT
ships by type: bulk 21 , cargo 5, chemical tanker 27,
container 4, liquefied gas 1 , petroleum tanker 13,
refrigerated cargo 30, roll on/roll off 4, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Cyprus 2, Denmark 2,
Finland 1 , Greece 1 1 , Norway 3, UK 3, US 3
(2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:^ (2000 est.)
Railways: 0 km
Highways:
fofa/; 23,810 km
paved: 429 km
unpaved: 23,381 km (1998 est.)
Waterways: 900 km
note: traditional trade carried on by means of
shallow-draft dugouts; Oubangui is the most important
river, navigable all year to craft drawing 0.6 m or less;
282 km navigable to craft drawing as much as 1.8 m
Ports and harbors: Bangui, Nola
Airports: 52 (2000 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:1
1,524 to 2,437 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 49
2,438 to 3,047 m:1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 15 (2000 est.)
Railways:
total: 595 km
narrow gauge: 349 km 1.067-m gauge; 246 km
0.91 4-m gauge (1999)
Highways:
total: 15,400 km
pavecf; 3, 126 km
unpaved: 12,274 km (1999 est.)
Waterways: 465 km (navigable by small craft)
Ports and harbors: La Ceiba, Puerto Castilla,
Puerto Cortes, San Lorenzo, Tela, Puerto Lempira
Merchant marine:
total: 313 ships (1 ,000 GRT or over) totaling 760,81 9
GRT/820,582 DWT
ships by type: bulk 21 , cargo 187, chemical tanker 7,
container 4, livestock carrier 2, passenger 2,
passenger/cargo 4, petroleum tanker 52, refrigerated
cargo 17, roll on/roll off 8, short-sea passenger 5,
specialized tanker 2, vehicle carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Russia 4, Singapore 2,
Vietnam 1 (2000 est.)
Airports: 119 (2000 est.)
Airports - with paved runways:
total: 12
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 107
1,524 to 2,437 m: 2
914 to 1,523 m: 21
under 914 m: 84 (2000 est.)','8ed48cb0699a746362d603cbb6c2554da719db83b9f14984d57feba0daf0e2d4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c99cca7f6f1e535bbc1879850a00dee81d571f398e9515ff3aaf161f2c3f6738',2001,'TD','Chad','transportation',283,'Railways: 0 km
Highways:
total: 33,400 km
paved: 267 km
unpaved: 33,133 km (1996)
Waterways: 2,000 km
Ports and harbors: none
Airports: 50 (2000 est.)
Airports - with paved runways:
total:?
over 3,047 m: 2
2,438 to 3,047 m: 3
100
Chad (continued)
1, 524 to 2,437 m-A
under 914 mA (2000 est.)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m: 12
914 to 1,523 m: 20
under 914 m: 1 1 (2000 est.)
Railways:
total: 6,782 km
broad gauge: 3,743 km 1 .676-m gauge (1 ,653 km
electrified)
narrow gauge: 1 16 km 1 .067‘m gauge; 2,923 km
1.000-m gauge (40 km electrified) (1995)
Highways:
total: 79,800 km
paved.'' 11,012 km
unpaved.'' 68,788 km (1996)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785
km; natural gas 320 km
Ports and harbors: Antofagasta, Arica, Chanaral,
Coquimbo, Iquique, Puerto Montt, Punta Arenas, San
Antonio, San Vicente, Talcahuano, Valparaiso
Merchant marine:
total: 44 ships (1 ,000 CRT or over) totaling 606,506
GRT/884,023 DWT
ships by type: bulk 1 1 , cargo 7, chemical tanker 8,
container 4, liquefied gas 2, passenger 3, petroleum
tanker 4, roll on/roll off 3, vehicle carrier 2 (2000 est.)
Airports: 366 (2000 est.)
Airports - with paved runways:
total: 69
over 3,047 m: 6
2,438 to 3,047 m: 6
1,524 to 2,437 m: 22
914 to 1,523 m: 21
under 914 m: 14 (2000 est.)
Airports - with unpaved runways:
total: 297
over 3,047 m:1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 62
under 914 m:219 (2000 est.)','ae7e5c543b5424c0ce9d1e5a845ea20c55b89cad6a66cfe1bde723633d69f336','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c2bdc75472f6404ebdd13447f1c465d72d3e6e3ed632785fc34590e8ea9f292',2001,'CN','China','transportation',293,'Railways:
total: 67,524 km (including 5,400 km of provincial
"local" rails)
standard gauge: 63,924 km 1.435-m gauge (13,362
km electrified: 20,250 km double track)
narrow gauge: 3,600 km 0.750-m and 1 .000-m gauge
local industrial lines (1998 est.)
note: a new total of 68,000 km was estimated for early
1 999 to take new construction programs into account
(1999)
Highways:
total: 1 .4 million km
paved: 271 ,300 km (with at least 16,000 km of
expressways)
unpaved: 1,128,700 km (1999)
Waterways: 1 1 0,000 km (1 999)
Pipelines: crude oil 9,070 km; petroleum products
560 km; natural gas 9,383 km (1998)
Ports and harbors: Dalian, Fuzhou, Guangzhou,
Haikou, Huangpu, Lianyungang, Nanjing, Nantong,
Ningbo, Qingdao, Qinhuangdao, Shanghai, Shantou,
Tianjin, Xiamen, Xingang, Yantai, Zhanjiang
Merchant marine:
total: 1 ,745 ships (1 ,000 GRT or over) totaling
16,533,521 GRT/24,746,859 DWT
ships by type: barge carrier 2, bulk 324, cargo 825,
chemical tanker 21 , combination bulk 1 1 , combination
ore/oil 1, container 132, liquefied gas 24,
multi-functional large-load carrier 5, passenger 7,
passenger/cargo 45, petroleum tanker 258,
refrigerated cargo 22, roll on/roll off 23, short-sea
passenger 41 , specialized tanker 3, vehicle carrier 1
(2000 est.)
Airports: 489 (2000 est.)
Airports ■ with paved runways:
total: 324
over 3,047 m: 27
2,438 to 3,047 m: 66
1,324 to 2,437 m:\\47
914 to 1,523 m: 30
under 914 m: 32 (2000 est.)
Airports - with unpaved runways:
total: 165
over 3,047 m:^
2,438 to 3,047 m-A
1,524 to 2,437 m: 29
914 to 1,523 m: 56
under 914 m: 78 (2000 est.)','3e5be3567684080d9ac4715de1cc070aaf0c70c17668cf5de7f322a9f6743b03','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98c8da4039674304d9cc08013f3f4878c863d654ab6ef787c194f414cd48ae82',2001,'CX','Christmas Island','transportation',301,'Railways; 24 km to serve phosphate mines
Highways:
total: 140 km (not including 100 km that is maintained
by private industry)
paved: 30 km
unpaveof; 110 km (1999)
Waterways: none
Ports and harbors: Flying Fish Cove
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:^ {2000 est.)','b1747026b14bab0b179009d914074ab7989cd6a2b09940a9faab37c44e6f07f2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9748fa22017cb1f3aadb67d3944778cad39ac552620e2b7053b54ce898483c40',2001,'CO','Colombia','transportation',308,'Railways:
total: 3,380 km
standard gauge: 1 50 km 1 .435-m gauge (connects
Cerrejon coal mines to maritime port at Bahia de
Portete)
narrow gauge: 3,230 km 0.91 4-m gauge (1 ,830 km in
use) (1995)
Highways:
fofa/: 11 0,000 km
paved: 26,000 km
unpaved: 84,000 km (2000)
Waterways: 18,140 km (navigable by river boats)
(April 1996)
Pipelines: crude oil 3,585 km; petroleum products
1,350 km; natural gas 830 km; natural gas liquids 125
km
Ports and harbors: Bahia de Portete, Barranquilla,
Buenaventura, Cartagena, Leticia, Puerto Bolivar,
San Andres, Santa Marta, Tumaco, Turbo
Merchant marine:
total: 13 ships (1,000 GRT or over) totaling 53,322
GRT/69,444 DWT
ships by type: bulk 5, cargo 4, container 1 ,
multi-functional large-load carrier 1 , petroleum tanker
2 (2000 est.)
Airports: 1 ,091 (2000 est.)
Airports - with paved runways:
total: 92
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 38
914 to 1,523 m: 36
under 914 m: 8 (2000 est.)
Airports - with unpaved runways:
total: 999
2,438 to 3,047 m:1
1,524 to 2,437 m: 64
914 to 1,523 m: 321
under 914 m: 61 3 (2000 est.)','f0bc98d96b8bebf1c706905caee2ece002100e9297e51490d58a79d34381a88a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77c8b0ee75e66ae9e23a670d23852e2ff078fe51b6e1309143e27b76826df6ef',2001,'MZ','Mozambique','transportation',316,'Railways: 0 km
Highways:
total: 880 km
paved: 673 km
unpaved: 207 km (1996)
Waterways: none
Ports and harbors: Fomboni, Moroni,
Moutsamoudou
Merchant marine:
fofa/;2 ships (1,000 GRT or over) totaling 19,122
GRT/29,817 DWT
ships by type: cargo 2 (2000 est.)
Airports: 4 (2000 est.)
Airports - with paved runways:
total: 4
2,438 to 3,047 m:1
914 to 1,523 m: 3 (2000 est.)
Railways:
total: NA km; short line going to a jetty
Waterways; none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2000 est.)
Railways:
fofa/; 3,131 km
narrow gauge: 2, 9BQ km 1.067-m gauge; 143 km
0.762‘m gauge (1994)
Highways:
total: 30,400 km
paved: 5,685 km
unpaved: 24 J^5 km (1996)
Waterways: 3,750 km (navigable routes)
Pipelines: crude oil 306 km; petroleum products
289 km
note: not operating
Ports and harbors: Beira, Inhambane, Maputo,
Nacala, Pemba, Quelimane
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 4,125 GRT/
7,024 DWT
ships by type: cargo 3 (2000 est.)
Airports: 168 (2000 est.)
Airports - with paved runways:
total: 22
over 3,047 m:\\
2,438 to 3,047 m: 3
1,524 to 2,437 m:]0
914 to 1,523 m: 3
under 914 m: 5 (2000 est.)
Airports - with unpaved runways:
total: 146
2,438 to 3,047 m: 1
1,524 to 2,437 m:W
914 to 1,523 m: 37
under 914 m: 92 (2000 est.)
Pipelines: petroleum products 212 km
Ports and harbors: Binga, Kariba
Airports: 455 (2000 est.)
Airports - with paved runways:
total: IS
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914to 1,523 m: 9 {2000 est.)
Airports - with unpaved runways:
tofa/;437
1,524 to 2,437 m: 4
91 4 to 1,523 m: 209
under 914 m: 224 (2000 est.)
Railways:
total: 4,600 km (519 km electrified)
narrow gauge: 4,600 km 1 .067-m
note: only 1 ,108 km of route length (including the
electrified part) is used in common carrier service by
the Taiwan Railway Administration; the remaining
3,492 km is dedicated to industrial use (1999)
Highways:
total: 34,901 km
paved: 31 ,271 km (including 538 km of expressways)
unpaved: 3,830 km (1998 est.)
Waterways: NA
Pipelines: petroleum products 3,400 km; natural gas
1,800 km (1999)
Ports and harbors: Chi-lung (Keelung), Hua-lien,
Kao-hsiung, Su-ao, Tai-chung
Merchant marine:
total: 187 ships (1 ,000 GRT or over) totaling
4,768,145 GRT/7,508,941 DWT
ships by type: bulk 45, cargo 29, combination bulk 1 ,
container 65, petroleum tanker 17, refrigerated cargo
8, roll on/roll off 2 (2000 est.)
Airports: 39 (2000 est.)
Airports - with paved runways:
total: 35
over 3,047 m: 8
2,438 to 3,047 m: 9
1,524 to 2,437 m: 8
914 to 1,523 m: 7
under 914 m; 3 (2000 est.)
Airports - with unpaved runways:
total: 4
1,524 to 2,437 m:1
under 914 m: 3 (2000 est.)
Heliports: 3 (2000 est.)','a2cfba3f9a4983157d90e7003cac9cb1147641c536196f03689073910f88973b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07c6c84df9c93c93559a74824c8caf92a5cea4012bc63c24c0753403bb0bf86c',2001,'CG','Congo','transportation',323,'Railways:
total: 5,138 km (1995); note - severely reduced
route-distance in use because of damage to facilities
by civil strife
narrow gauge: 3,987 km 1.067-m gauge (858 km
electrified); 125 km 1.000-m gauge; 1,026 km
0.600-m gauge
Highways:
tofa/.- 157,000 km (including 30 km of
expressways)(1996)
paved: NA km
unpaved: NA km
Waterways: 1 5,000 km (including the Congo and its
tributaries, and unconnected lakes)
Pipelines: petroleum products 390 km
Ports and harbors: Banana, Boma, Bukavu,
Bumba, Goma, Kalemie, Kindu, Kinshasa, Kisangani,
Matadi, Mbandaka
Merchant marine: none (2000 est.)
Airports: 232 (2000 est.)
Airports - with paved runways:
total: 2A
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m‘A8
914 to 1,523 m: 2 {2000 est.)
Airports - with unpaved runways:
tofa/;208
1,524 to 2,437 m: 20
914 to 1,523 m: 96
under 914 m: 92 (2000 est.)
Railways;
total: 795 km (includes 285 km private track)
narrow gauge: 795 km 1 .067-m gauge (1995 est.)
Highways:
total: 12,800 km
paved: 1 ,242 km
unpaved: 1 1 ,558 km (1996)
Waterways: 1,120 km
note; the Congo and Ubangi (Oubangui) rivers
provide 1,120 km of commercially navigable water
transport; other rivers are used for local traffic only
Pipelines: crude oil 25 km
Ports and harbors: Brazzaville, Impfondo, Ouesso,
Oyo, Pointe-Noire
Airports: 33 (2000 est.)
Airports - with paved runways;
total: 4
over 3,047 m:1
1,524 to 2,437 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m: 7
914 to 1,523 m: 12
under 914 m: 1 0 (2000 est.)','7a001f6c7361007caaf6829ed00abdf36569f53355180d306b5cd4a386addbef','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('879544b21acc954be3836d394cfa5b97c7bcd0f6d1feeaae02f6408fa9f5bea8',2001,'CK','Cook Islands','transportation',335,'Railways: 0 km
Highways:
total: 320 km (1992)
paved: NA
unpaved: NA
Waterways: none
Ports and harbors: Avarua, Avatiu
Merchant marine;
total: 1 ship (1 ,000 GRT or over) totaling 2,310 GRT/
2,181 DWT
ships by type: cargo 1 (2000 est.)
Airports: 7 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2000 est.)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3 {2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only
Waterways: none
Ports and harbors; none; offshore anchorage only;
note - there is one small boat landing area in the
middle of the west coast and another near the
southwest corner of the island
Transportation - note: there is a day beacon near
the middle of the west coast
Railways: 0 km
Highways:
total: 577 km
paved: NA km
unpaved: HA km (1995)
Waterways: none
Ports and harbors: Gorey, Saint Aubin, Saint Helier
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2000 est.)
Waterways: none
Ports and harbors: Johnston Island
Airports: 1 ; note - six flights per week; three
commercial, three military (2001 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:U2000 est.)','c2b92ef5a0e493a09450cbe660e7ea3e6ac49e26711d5eb0ca99508fff9afe56','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d107938ea58b65af95ee7c1091491e03e2eb90452c799cd2ee99fd2e59d73ec9',2001,'CR','Costa Rica','transportation',343,'Railways:
total: 950 km
narrow gauge: 950 km 1.067-m gauge (260 km
electrified)
Highways:
tofa/; 37,273 km
paved: 7,827 km
unpaved: 29, km (1998 est.)
Waterways: 730 km (seasonally navigable)
Pipelines: petroleum products 176 km
Ports and harbors: Caldera, Golfito, Moin, Puerto
Limon, Puerto Quepos, Puntarenas
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,716 GRT/
NA DWT
ships by type: passenger 1 (2000 est.)
Airports: 152 (2000 est.)
Airports - with paved runways:
total: 29
2,438 to 3,047 m: 2
1,524 to 2,437 m’A
914 to 1,523 m: 19
under 914 m: 7 (2000 est.)
Airports - with unpaved runways:
total: 123
914 to 1,523 m: 28
under 914 m: 95 (2000 est.)','50286799703664e1e35e12b2d612070d3bdc4aa1d7c8a03a6fdb78a9d0208ae5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bee95d87f4ba091e72f2dfc78cbc4a675a39eaee1fec0a960c8dfe425fa7b2e',2001,'SI','Slovenia','transportation',357,'Railways:
total: 2,296 km
standard gauge: 2,298 km 1.435-m gauge (983 km
electrified) (1997)
Highways:
total: 27,840 km
paved: 23,497 km (including 330 km of expressways)
unpaved: 4,343 km (1998)
Waterways: 785 km
note: (perennially navigable; large sections of Sava
blocked by downed bridges, silt, and debris)
Pipelines: crude oil 670 km; petroleum products 20
km; natural gas 310 km (1992)
Ports and harbors: Dubrovnik, Dugi Rat, Omisalj,
Ploce, Pula, Rijeka, Sibenik, Split, Vukovar (inland
waterway port on Danube), Zadar
Merchant marine:
total: 53 ships (1 ,000 GRT or over) totaling 631 ,853
GRT/969,739 DWT
ships by type: bulk 1 1 , cargo 1 8, chemical tanker 1 ,
combination bulk 5, container 3, multi-functional
large-load carrier 3, passenger 1 , petroleum tanker 2,
refrigerated cargo 2, roll on/roll off 4, short-sea
passenger 3 (2000 est.)
Airports: 67 (2000 est.)
Airports - with paved runways;
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m; 8 (2000 est.)
Airports ■ with unpaved runways:
total: 45
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 914 m: 36 (2000 est.)
Heliports: 1 (2000 est.)','163e1354dbb78c5ecf467eeaa483529fd92a8a619e4b93e72a27dff91372323a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f52410665a553c2fd367ea53d326f0f064a467b63958159deb307a63145ea488',2001,'CU','Cuba','transportation',366,'Railways:
total: 1 1 ,969 km
standard gauge: 4,807 km 1 .435-m gauge (147 km
electrified)
note: in addition to the 4,807 km of standard gauge
track in public use, 7,162 km of track is in private use
by sugar plantations; about 90% of the private use
track is standard gauge and the rest is narrow gauge
Highways:
/ofa/.‘ 60,858 km
pavecf: 29,820 km (including 638 km of expressway)
unpaved: 31 ,038 km (1 997)
Waterways: 240 km
Ports and harbors: Cienfuegos, Havana,
Manzanillo, Mariel, Matanzas, Nuevitas, Santiago de
Merchant marine:
total: 15 ships (1 ,000 GRT or over) totaling 54,821
GRT/78,062 DWT
ships by type: bulk 1 , cargo 7, liquefied gas 1 ,
petroleum tanker 1 , refrigerated cargo 5 (2000 est.)
Airports: 171 (2000 est.)
Airports - with paved runways:
total: 77
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2,437 m:\\%
914to1,523m:\\9
under 91 4 m: 35 (2000 est.)
Airports - with unpaved runways:
total: 94
914 to 1,523 m: 31
under 914 m: 63 (2000 est.)
Railways:
total: 40 km (single track; privately owned industrial
line) - closed in early 1990s
narrow gauge: 40 km 0.760-m gauge
Highways:
total: 4, ^ 60 km
paved; 1,011 km
unpaved: 3^49 km (1996)
Waterways: NEGL; less than 100 km navigable
Ports and harbors: Cap-Haitien, Gonaives, Jacmel,
Jeremie, Les Cayes, Miragoane, Port-au-Prince,
Port-de-Paix, Saint-Marc
Merchant marine: none (2000 est.)
Airports: 13 (2000 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:^
914 to 1,523 m: 2 {2000 est.)
Airports ■ with unpaved runways:
total: 10
914 to 1,523 m: 2
under 914 m: 3(2000 est.)','e8fb96aeae095d6f0fa43f549dff2ba34cc7ca3d74f472a8d49311cca48b7baa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98d4bef6ee2a3cb56b765a8140ce62f1dfffae9337af3d8d69cab80d72f8d420',2001,'CY','Cyprus','transportation',375,'Railways: 0 km
Highways:
total: Greek Cypriot area: 10,663 km (1998 est.);
Turkish Cypriot area: 2,350 km (1996 est.)
paved: Greek Cypriot area: 6,249 km (1998 est.);
Turkish Cypriot area: 1 ,370 km (1996 est.)
unpaved: Greek Cypriot area: 4,414 km (1998 est.);
Turkish Cypriot area: 980 km (1996 est.)
Waterways: none
Ports and harbors: Famagusta, Kyrenia, Larnaca,
Limassol, Paphos, Vasilikos
Merchant marine:
total: 1 ,328 ships (1 ,000 GRT or over) totaling
22,905,542 GRT/36,312,219 DWT
ships by type: barge carrier 2, bulk 431 , cargo 438,
chemical tanker 23, combination bulk 36, combination
ore/oil 4, container 140, liquefied gas 6, passenger 8,
passenger/cargo 1 , petroleum tanker 143,
refrigerated cargo 40, roll on/roll off 42, short-sea
passenger 9, specialized tanker 2, vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Austria 8, Belgium 7,
China 10, Cuba 10, Denmark 2, Germany 79, Greece
385, Hong Kong 9, Croatia 2, India 5, Iran 1 , Israel 4,
Italy 2, Japan 19, South Korea 3, Latvia 10, Lithuania
1, Monaco 1, Netherlands 13, Norway 11, Poland 9,
Portugal 3, Russia 42, Singapore 1 , Spain 5, Sudan 2,
Sweden 3, Switzerland 2, UAE 6, UK 8, Ukraine 2,
US 9, Venezuela 2 (2000 est.)
Airports: 15 (2000 est.)
Airports - with paved runways:
total: 12
2,438 to 3,047 m: 7
1,524 to 2,437 m''A
914 to 1,523 m: 3
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 914 m: 2 {2000 est.)
Heliports: 7 (2000 est.)
Railways:
total: 9,444 km
standard gauge: 9,350 km 1.435-m standard gauge
(2,843 km electrified at three voltages; 1,929 km
double track)
narrow gauge: 94 km 0.760-m narrow gauge (2000)
Highways:
total: 55,432 km
paved: 55,432 km (including 499 km of expressways)
unpaved: 0 km (2000)
Waterways: 303 km
note: (the Labe (Elbe) is the principal river) (2000)
Pipelines: natural gas 3,550 km (2000)
Ports and harbors: Decin, Prague, Usti nad Labem
Airports: 114 (2000 est.)
Airports ■ with paved runways:
total: 43
over 3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2,437 m: 14
914 to 1,523 m:1
under 914 m; 16 (2000 est.)
Airports - with unpaved runways:
total: 71
1,524 to 2,437 m:1
914 to 1,523 m: 23
under 914 m: 42 (2000 est.)
Heliports: 1 (2000 est.)
Railways:
total: 2,859 km (508 km privately owned and
operated)
standard gauge: 2,859 km 1 .435-m gauge (600 km
electrified; 760 km double track) (1998)
Highways:
total: 71 ,474 km
paved: 71 ,474 km (including 880 km of expressways)
unpaved: 0 km (1999)
Waterways: 417 km
Pipelines: crude oil 1 1 0 km; petroleum products 578
km; natural gas 700 km
Ports and harbors: Abenra, Alborg, Arhus,
Copenhagen, Esbjerg, Fredericia, Kolding, Odense,
Roenne (Bornholm), Vejie
Merchant marine:
total: 342 ships (1 ,000 GRT or over) totaling
6,073,489 GRT/8, 027,002 DWT
ships by type: bulk 10, cargo 128, chemical tanker 27,
container 76, liquefied gas 26, livestock carrier 6,
petroleum tanker 22, railcar carrier 1 , refrigerated
cargo 13, roll on/roll off 23, short-sea passenger 7,
specialized tanker 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Finland 1 (2000 est.)
Airports: 119 (2000 est.)
Airports - with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m:\\2
under 914 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 91
1,524 to 2,437 m:^
914 to 1,523 m: 7
under 914 m: 83 (2000 est.)','93e7818662bbea50d435e652745e1f83085a65248bc9060d163e0d3e292ace98','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b995ada5c957d43652eb02e21eb323a47e46d762cfb2790f9ffd0058153f80c',2001,'DJ','Djibouti','transportation',384,'Railways:
total: 100 km (Djibouti segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 1 00 km 1 .000-m gauge
note: Djibouti and Ethiopia plan to revitalize the
century-old railroad that links their capitals by 2003
Highways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1996)
Waterways: none
Ports and harbors: Djibouti
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 1,369 GRT/
3,030 DWT
ships by type: cargo 1 (2000 est.)
Airports: 12 (2000 est.)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m:1 (2000 est.)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 {2000 est.)
Railways: 0 km
Highways:
total: 750 km
paved: 375 km
unpaved: 375 km (2001)
Waterways: none
Ports and harbors: Portsmouth, Roseau
Merchant marine: none (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 2
914 to 1,523 m: 2 [2000 est.)','d13abb946391c72d594a871fc98631c421ae0414f0d90876e1315e38b6571999','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('699974a63bcda7ef3f2ebdbe8f08955b692dafa05145ae613b968a662c330d73',2001,'DO','Dominican Republic','transportation',392,'Railways:
total: 757 km
standard gauge: 375 km 1 .435-m gauge (Central
Romana Railroad)
narrow gauge: 142 km 0.762-m gauge (Dominican
Republic Government Railway); 240 km operated by
sugar companies in various gauges (0.558-m,
0.762-m, 1.067-m gauges) (1995)
Highways:
total: 12,600 km
paved: 6,224 km
unpaved: 6,376 km (1 996)
Waterways: none
Pipelines: crude oil 96 km; petroleum products 8 km
Ports and harbors: Barahona, La Romana, Puerto
Plata, San Pedro de Macoris, Santo Domingo
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,587 GRT/
1,165 DWT
ships by type: cargo 1 (2000 est.)
Airports: 29 (2000 est.)
Airports - with paved runways:
total: 13
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
fofa/;16
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 10 (2000 est.)
Railways:
total: % km
narrow gauge: 96 km 1 .000-m gauge, rural,
narrow-gauge system for hauling sugarcane; no
passenger service
Highways:
total: 14,400 km
paved; 14,400 km
unpaved; 0 km (1996 est.)
Waterways: none
Ports and harbors: Guanica, Guayanilla,
Guayama, Playa de Ponce, San Juan
Airports: 28 (2000 est.)
Airports - with paved runways:
total: ^9
over 3,047 m: 3
1,524 to 2,437 m: 3
91 4 to 1,523 m: 7
under 914 m; 6 (2000 est.)
Airports - with unpaved runways:
total: 9
914 to 1,523 m: 2
under 914 m; 7 (2000 est.)','e4762ab799718a4f49904ed69b6de56063d4239e8f6f039de885d30da3603164','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c3d1639ad4e8239d51d59ac98fa553b64bdb9a9d46344d852b0c32d2e50584a',2001,'PE','Peru','transportation',401,'Railways:
total: 8^2 km (single track)
narrow gauge: 812 km 1 .067-m gauge
Highways:
tofa/,'' 43,197 km
paved,'' 8,1 65 km
unpaved: 35,032 km (1999 est.)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products
1 ,358 km
Ports and harbors: Esmeraldas, Guayaquil, La
Libertad, Manta, Puerto Bolivar, San Lorenzo
Merchant marine:
total: 30 ships (1,000 GRT or over) totaling 233,312
GRT/385,784 DWT
ships by type: cargo 2, chemical tanker 1 , liquefied
gas 1 , passenger 3, petroleum tanker 22, specialized
tanker 1 (2000 est.)
Airports: 180 (2000 est.)
Airports - with paved runways:
total: 59
over 3,047 m: 2
2,438 to 3,047 m:b
1, 524 to 2,437 m''A3
9Utot,523m:\\b
under 914 m: 19 (2000 est.)
Airports - with unpaved runways:
fofo/.''121
91 4 to 1,523 m: 32
under 914 m: 89 (2000 est.)
Heliports: 1 (2000 est.)
Railways:
total: 1 ,988 km
standard gauge: 1 ,608 km 1 .435-m gauge
narrow gauge: 380 km 0.91 4-m gauge
Highways;
total: 72,900 km
paved: 8,700 km
unpaved: 64,200 km (1999 est.)
Waterways: 8,808 km
note: 8,600 km of navigable tributaries of Amazon
system and 208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural
gas liquids 64 km
Ports and harbors: Callao, Chimbote, Ho, Matarani,
Paita, Puerto Maldonado, Salaverry, San Martin,
Talara, Iquitos, Pucallpa, Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the
upper reaches of the Amazon and its tributaries
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 40,623
GRT/61,769 DWT
ships by type: cargo 5, petroleum tanker 1 (2000 est.)
Airports: 233 (2000 est.)
Airports ■ with paved runways:
total: 46
over 3,047 m: 6
2,438 to 3,047 m: 16
1,524 to 2,437 m: 13
914 to 1,523 m: 6
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 167
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m: 25
914 to 1,523 m: 65
under 914 m: 95 (2000 est.)','15f5ad8feb6dbc4428de64e4c07a8883e7c87cf14f19a6b559f80b727cfb39fb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8ff0e1025cb03ce3cda3278be4e9a565902910bdb2ed28c678df63e9d6a817b',2001,'EG','Egypt','transportation',410,'Railways:
total: 4,955 km
standard gauge: 4,955 km 1,435-m gauge (42 km
electrified; 1,560 km double track)
Highways;
total: 64,000 km
paved: 50,000 km
unpaved: 14,000 km (1 996)
Waterways: 3,500 km
note: including the Nile, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller
canals in the delta; Suez Canal (193.5 km including
approaches), used by oceangoing vessels drawing up
to 16.1 m of water
Pipelines: crude oil 1,171 km; petroleum products
596 km; natural gas 460 km
Ports and harbors: Alexandria, Al Ghardaqah,
Aswan, Asyut, Bur Safajah, Damietta, Marsa Matruh,
Port Said, Suez
Merchant marine;
total: 1 81 ships (1 ,000 GRT or over) totaling
1,336,678 GRT/1 ,982,220 DWT
ships by type: bulk 23, cargo 61 , container 2, liquefied
gas 1 , passenger 61, petroleum tanker 15, roll on/roll
off 15, short-sea passenger 3 (2000 est.)
Airports: 90 (2000 est.)
Airports - with paved runways:
total: 69
over 3,047 m: 12
2,438 to 3,047 m: 35
1,524 to 2,437 m: 17
914 to 1,523 m: 2
under 914 m: 3 (2000 est.)
Airports > with unpaved runways;
total: 21
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m:7
under 914 m: 10 (2000 est.)
Heliports: 2 (2000 est.)
151
Egypt (continued)','804a2b6786860aec2576d237c9de57e1fb4ccec5071a7f4ad04c0d40f88cbcea','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aa77ab5b2b6d231ca04ab2ff5824b3496bd05ee3e0e4cec918bc35043d54ad6',2001,'SV','El Salvador','transportation',419,'Railways:
total: 602 km (single track; note ■ some sections
abandoned, unusable, or operating at reduced
capacity)
narrow gauge: 602 km 0.91 4-m gauge
Highways:
total: 10,029 km
paved; 1,986 km (including 327 km of expressways)
unpaved: 8,043 km (1 997)
Waterways: Rio Lempa partially navigable
Ports and harbors: Acajutia, Puerto Cutuco, La
Libertad, La Union, Puerto El Triunfo
Merchant marine: none (2000 est.)
Airports: 83 (2000 est.)
Airports - with paved runways:
total: 4
over 3,047 m:]
1,524 to 2,437 m:]
914 to 1,523 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 79
914 to 1,523 m:]7
under 914 m: 62 (2000 est.)
Heliports: 1 (2000 est.)','465de3667e5eaf514a39f12740960640fd30e343e9c931165a96d7ee8ab22db4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c2d73bcaeb6780ca2e43774cf8f7bc2eae420682dd94d6d9f011e40fccb19b4',2001,'GN','Guinea','transportation',428,'Railways;
total: 0 km
Highways:
total: 2,880 km
paved: 0 km
unpaved: 2,880 km (1996)
Waterways: none
Ports and harbors: Bata, Luba, Malabo
Merchant marine:
total: 12 ships (1 ,000 CRT or over) totaling 26,035
GRT/27,927 DWT
ships by type: bulk 1 , cargo 7, combination bulk 1 ,
passenger 2, passenger/cargo 1 (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
1,524 to 2,437 m:^ (2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2000 est.)
Railways:
fofa/; 317 km
narrow gauge: 317 km 0.950-m gauge (1999)
note: links Ak''ordat and Asmara with the port of
Massawa; nonoperational since 1 978 except for about
a 5 km stretch that was reopened in Massawa in 1 994;
rehabilitation of the remainder and of the rolling stock
Is under way
Highways:
total: 3,850 km
paved; 810 km
unpaved: 3,040 km (2000)
Waterways: none
Ports and harbors: Assab (Aseb), Massawa
(Mits''iwa)
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 16,069
GRT/1 9,549 DWT
ships by type: bulk 1 , cargo 1 , liquefied gas 1 ,
petroleum tanker 1 , roll on/roll off 1 (2000 est.)
Airports: 20 (2000 est.)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m:1 (2000 est.)
Airports - with unpaved runways:
total: 18
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 7
under 914 m; 2 (2000 est.)
Railways: 0 km
Highways:
total: 19,500 km
paved: 686 km
unpaved: 18,914 km (1996 est.)
Waterways: 10,940 km
Ports and harbors: Kieta, Lae, Madang, Port
Moresby, Rabaul
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 35,361
GRT/51,096 DWT
ships by type: bulk 1 , cargo 9, chemical tanker 1 ,
combination ore/oil 3, container 1 , petroleum tanker 3,
roll on/roll off 2 (2000 est.)
396
Papua New Guinea (continued)
Airports: 492 (2000 est.)
Airports - with paved runways:
total: 20
2,438 to 3,047 m: 2
1,524 to 2,437 m:-\\3
914 to 1,523 m: 4
under 914 m''A (2000 est.)
Airports ■ with unpaved runways:
total: 472
1,524 to 2,437 m: 13
914 to 1,523 m: 57
under 914 m: 402 (2000 est.)
Heliports: 2 (2000 est.)','2528edac60df9e8b4a28f22106aacdbbe03d75e387f6ebb4a050c36af9da4c15','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c59702b1aec1fcfa22a77de027511612f455e0bf8e04003a9d8dd9acd8303d9d',2001,'EE','Estonia','transportation',440,'Railways:
total: 1 ,018 km common carrier lines only; does not
include dedicated industrial lines
broad gauge: 1 ,01 8 km 1 .520-m gauge (1 32 km
electrified) (1995)
Highways:
total: 30,300 km
Estonia (continued)
paved: 29,200 km (including 75 km of expressways);
note - these roads are said to be hard-surfaced, and
include, in addition to conventionally paved roads,
some that are surfaced with gravel or other coarse
aggregate, making them trafficable in all weather
unpaved: km (2000)
Waterways: 320 km (perennially navigable)
Pipelines: natural gas 420 km (1992)
Ports and harbors: Haapsalu, Kunda, Muuga,
Paldiski, Parnu, Tallinn
Merchant marine:
total: 44 ships (1,000 GRT or over) totaling 253,460
GRT/21 9,727 DWT
ships by type: bulk 2, cargo 1 9, combination bulk 1 ,
container 5, petroleum tanker 1, roll on/roll off 10,
short-sea passenger 6 (2000 est.)
Airports: 32 (2000 est.)
Airports - with paved runways:
total: Q
2,438 to 3,047 m: 7
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 24
over 3,047 m:\\
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 5
under 914 m; 6 (2000 est.)','6336ef336c9b96fb74f778c56a4cb3a2a0b7cd1e514a0a87e254921b24c78339','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27d8ae992615f1a8265c4e37ec0124cb80cde17c0fc56928191668b48448e73a',2001,'FO','Faroe Islands','transportation',448,'Railways: 0 km
Highways:
total: 463 km
paved: 454 km
unpaved: 9 km (1999)
Waterways; none
167
Faroe Islands (continued)
Ports and harbors: Torshavn, Klaksvik, Tvoroyri,
Runavik, Fuglafjorour
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 23,247
GRT/1 1,736 DWT
ships by type: cargo 2, petroleum tanker 1 ,
refrigerated cargo 1, roll on/roll off 1, short-sea
passenger 1 (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m:^ (2000 est.)','c0183cf2a697aeb137a67851326688b013a66ae2a5097cf05e68346166ac559b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d072a8dd9f450efd8c61c58f107d563359dda0ae1065ffaf21c783978b1ad81d',2001,'JE','Jersey','transportation',460,'Railways:
total: 597 km; note - belongs to the
government-owned Fiji Sugar Corporation
narrow gauge: 597 km 0.61 0-m gauge (1995)
Highways;
total: 3,440 km
paved: 1 ,692 km
unpaved: 1 ,748 km (1 996)
Waterways: 203 km
note: 122 km navigable by motorized craft and
200-metric-ton barges
Ports and harbors: Lambasa, Lautoka, Levuka,
Savusavu, Suva
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 1 ,870
GRT/1 4,787 DWT
ships by type: chemical tanker 2, passenger 1 ,
petroleum tanker 1 , roll on/roll off 1 , specialized tanker
1 (2000 est.)
Airports: 27 (2000 est.)
Airports - with paved runways:
total: 3
over 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 24
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m; 19 (2000 est.)
M i i 1 1 a r y
Military branches: Republic of Fiji Military Forces
(RFMF; includes ground and naval forces)
Military manpower - military age: 18 years of age
Military manpower - avaiiabiiity:
males age 15-49: 227,599 (2001 est.)
Military manpower - fit for miiitary service:
males age 15-49: 125,238 (2001 est.)
Military manpower - reaching military age
annualiy:
males: 9,471 (2001 est.)
Military expenditures - doilar figure: $24 miilion
(FY98)
Military expenditures - percent of GDP: 1 .1%
(FY98)
Railways:
total: 5,865 km
broad gauge: 5,865 km 1.524-m gauge (2,192 km
electrified; 480 km double or multiple track) (1998)
Highways:
total: 77,796 km
paved: 49,789 km (including 444 km of expressways)
unpaved: 28,042 km (1999)
Waterways: 6,675 km
note: includes Saimaa Canal; 3,700 km suitable for
large ships
Pipelines: natural gas 580 km
Ports and harbors: Hamina, Helsinki, Kokkola,
Kotka, Loviisa, Oulu, Pori, Rauma, Turku,
Uusikaupunki, Varkaus
Merchant marine:
total: 98 ships (1 ,000 GRT or over) totaling 1 ,172,808
GRT/1,138,175 DWT
ships by type: bulk 9, cargo 23, chemical tanker 5,
passenger 1 , petroleum tanker 1 1 , railcar carrier 1 , roli
on/roll off 37, short-sea passenger 11 (2000 est.)
Airports: 159 (2000 est.)
Airports ■ with paved runways:
total: 69
over 3,047 m: 3
2,438 to 3,047 m: 26
1,524 to 2,437 m:\\0
914 to 1,523 m: 20
under 914 m: 10 (2000 est.)
Airports - with unpaved runways:
total: 90
914 to 1,523 m: 6
under 914 m: 84 (2000 est.)
Railways: 0 km
Highways:
total: 4,450 km
paved: 3,590 km
unpaved: 860 km (1999 est.)
Pipelines: crude oil 877 km; petroleum products 40
km; natural gas 165 km
Ports and harbors: Ash Shu''aybah, Ash Shuwaykh,
Kuwait, Mina'' ''Abd Allah, Mina'' al Ahmadi, Mina'' Su''ud
Merchant marine:
total: 45 ships (1 ,000 GRT or over) totaling 2,461 ,072
GRT/3,966,645 DWT
ships by type: bulk 1 , cargo 6, container 6, liquefied
gas 7, livestock carrier 5, petroleum tanker 20
(2000 est.)
Airports; 8 (2000 est.)
Airports - with paved runways:
tofa/;4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2000 est.)
Airports - with unpaved runways:
tofa/;4
1,524 to 2,437 m:1
under 914 m: 3 (2000 est.)
Heliports: 3 (2000 est.)
Railways: 0 km
Highways:
total: 4,825 km
paved: 2,287 km
unpaved: 2,538 km (1999)
Waterways: none
Ports and harbors: Mueo, Noumea, Thio
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 1,261 GRT/
1,600 DWT
ships by type: cargo 1 (2000 est.)
Airports: 29 (2000 est.)
Airports - with paved runways:
total: 6
over 3,047 m:^
914 to 1,523 m: 4
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 23
914 to 1,523 m: 12
under 914 m:M (2000 est.)
Heliports: 6 (2000 est.)
Railways:
total: 297 km; note - includes 71 km which are not in
use
narrow gauge: 297 km 1 .067-m gauge
Highways:
total: 2, B% km (1997 est.)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors; none
Airports: 18 (2000 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (2000 est.)
Airports - with unpaved runways:
total: 17
914 to 1,523 m: 7
under 914 m: 10 (2000 est.)
Railways:
total: ^2,S2^ km (includes 3,594 km of privately
owned railways)
standard gauge: 1 2,821 km 1 .435''m gauge (7,918 km
electrified and 1,152 km double track) (1998)
Highways:
fofa/.- 21 0,907 km
paved: 163,453 km (including 1 ,439 km of
expressways)
unpaved: 47,454 km (1998 est.)
Waterways: 2,052 km
note: navigable for small steamers and barges
Pipelines: natural gas 84 km
Ports and harbors: Gavie, Goteborg, Halmstad,
Helsingborg, Hudiksvall, Kalmar, Karlshamn, Malmo,
Solvesborg, Stockholm, Sundsvall
Merchant marine:
total: 1 67 ships (1 ,000 GRT or over) totaling
2,205,370 GRT/1 ,663,091 DWT
ships by type: bulk 5, cargo 28, chemical tanker 31 ,
combination ore/oil 4, liquefied gas 1, passenger 1,
petroleum tanker 29, railcar carrier 1 , roll on/roll off 40,
short-sea passenger 4, specialized tanker 6, vehicle
carrier 17 (2000 est.)
Airports: 255 (2000 est.)
Airports - with paved runways:
total: 147
over 3,047 m: 3
2,438 to 3,047 m: 11
1,524 to 2,437 m: 80
914 to 1,523 m: 28
under 914 m: 25 (2000 est.)
Airports ■ with unpaved runways:
total: 108
914 to 1,523 m: 5
under 914 m: 103 (2000 est.)
Heliports: 1 (2000 est.)','437ce3e4c09977bf571f8d250a4a9e01d588af4c644727f268b5a66ba99be29b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb43f4492b4a4b33a13be65bdc3450cc5cc3b83e033753d557c3a23b42f6dffb',2001,'WF','Wallis and Futuna','transportation',467,'Railways:
total: 31 ,939 km (31 ,939 km are operated by French
National Railways (SNCF); 14,176 km of SNCF routes
are electrified and 12,132 km are double- or
multiple-tracked)
standard gauge: 31 ,840 km 1 .435-m gauge
narrow gauge: 99 km 1.000-m gauge (1998)
Highways:
total: 892,900 km
paved: 892,900 km (including 9,900 km of
expressways)
unpaved: 0 km (1999)
Waterways: 14,932 km (6,969 km heavily traveled)
Pipelines: crude oil 3,059 km; petroleum products
4,487 km; natural gas 24,746 km
Ports and harbors: Bordeaux, Boulogne,
Cherbourg, Dijon, Dunkerque, La Pallice, Le Havre,
Lyon, Marseille, Mullhouse, Nantes, Paris, Rouen,
Saint Nazaire, Saint Malo, Strasbourg
Merchant marine:
total: 46 ships (1 ,000 GRT or over) totaling 942,333
GRT/1 ,304,754 DWT
ships by type: bulk 3, cargo 4, chemical tanker 6,
combination bulk 1 , container 1 , liquefied gas 3,
multi-functional large-load carrier 1 , passenger 3,
petroleum tanker 17, roll on/roll off 4, short-sea
passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 (2000 est.)
Airports: 475 (2000 est.)
Airports - with paved runways:
total: 268
over 3,047 m: 14
2,438 to 3,047 m: 30
1,524 to 2,437 m: 94
914 to 1,523 m: 72
under 914 m: 58 (2000 est.)
Airports - with unpaved runways:
total: 207
1,524 to 2,437 m: 4
914 to 1,523 m: 73
under 914 m: 130 (2000 est.)
Heliports: 3 (2000 est.)','1a4009f5348fe2e25652eb4ebdd87372991ab670a1d121faa71f99dc4ad40121','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0787cf1757ea71d0fb9ea38f22c6507be687683fed5518bc42f27cf288151176',2001,'KI','Kiribati','transportation',482,'Railways: 0 km
Highways:
total: 792 km
paved: 264 km
unpaved: 528 km (2000)
Waterways: none
Ports and harbors: Mataura, Papeete, Rikitea,
Uturoa
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 5,240 GRT/
7,765 DWT
ships by type: cargo 1 , passenger/cargo 2,
refrigerated cargo 1 (2000 est.)
Airports: 45 (2000 est.)
Airports ■ with paved runways:
total: 32
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 19
under 914 m; 6 (2000 est.)
Airports - with unpaved runways:
total: 13
914 to 1,523 m: 3
under 914 m; 10 (2000 est.)
Railways: 0 km
Highways:
total: m km
paved: NA km
unpaved: NA km (1 996)
Waterways: 5 km (small network of canals in Line
Islands)
Ports and harbors: Banaba, Betio, English Harbor,
Kanton
Merchant marine;
total: 1 ship (1 ,000 GRT or over) totaling 1 ,291 GRT/
1,295 DWT
ships by type: passenger/cargo 1 (2000 est.)
Airports: 21 (2000 est.)
Airports - with paved runways:
total: 4
1,524 to 2,437 m: 4 (2000 est.)
Airports - with unpaved runways:
total: 17
914 to 1,523 m: 12
under 914 m: 5 (2000 est.)
Railways:
total: 5,000 km
standard gauge: 4,095 km 1 .435-m gauge (3,500 km
electrified; 159 km double track)
narrow gauge: 665 km 0.762-m gauge
dual gauge: 240 km 1. 435-m and 1.600-m gauges
(four rails interlaced) (1996 est.)
Highways:
total: 31 ,200 km
pavecf: 1,997 km
unpaved: 29,203 km (1996)
Waterways; 2,253 km
note: mostly navigable by small craft only
Pipelines: crude oil 37 km; petroleum product 180
km
Ports and harbors: Ch''ongjin, Haeju, Hungnam
(Hamhung), Kimch''aek, Kosong, Najin, Namp''o,
Sinuiju, Songnim, Sonbong (formerly Unggi),
Ungsang, Wonsan
Merchant marine;
total: 1 1 0 ships (1 ,000 GRT or over) totaling 661 ,792
GRT/903,367 DWT
ships by type: bulk 4, cargo 94, combination bulk 1 ,
multi-functional large-load carrier 1 , passenger 2,
passenger/cargo 1, petroleum tanker 4, refrigerated
cargo 1 , short-sea passenger 2 (2000 est.)
Airports: 87 (2000 est.)
Airports - with paved runways:
total: 39
over 3,047 m: 3
2,438 to 3,047 m: 20
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 48
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
914 to 1,523 m: 13
under 914 m: 8 (2000 est.)
Railways:
total: 6,240 km
standard gauge: 6,240 km 1 .435-m gauge (525 km
electrified) (1998 est.)
Highways:
total: 87,534 km
paved: 65,388 km (including 1 ,996 km of expressways)
unpaved: 22,14^ kni (1999)
Waterways: 1,609 km
note: restricted to small native craft
Pipelines: petroleum products 455 km; note -
additionally, there is a parallel petroleum, oils, and
lubricants (POL) pipeline being completed
Ports and harbors: Chinhae, Inch''on, Kunsan,
Masan, Mokp''o, P''ohang, Pusan, Tonghae-hang,
Ulsan, Yosu
Merchant marine:
total: 496 ships (1 ,000 GRT or over) totaling
5,421 ,993 GRT/8,757, 034 DWT
ships by type: bulk 105, cargo 168, chemical tanker
38, combination bulk 5, container 49, liquefied gas 1 6,
multi-functional large-load carrier 1, passenger 3,
petroleum tanker 70, refrigerated cargo 27, roll on/roll
off 4, short-sea passenger 1 , specialized tanker 4,
vehicle carrier 5 (2000 est.)
Airports; 102 (2000 est.)
Airports - with paved runways:
total: 88
over 3,047 m: 2
2,438 to 3,047 m: 18
1,524 to 2,437 m: 18
914 to 1,523 m: 11
under 914 m: 21 (2000 est.)
Airports - with unpaved runways:
tofa/;34
914 to 1,523 m: 2
under 914 m: 32 (2000 est.)
Heliports: 203 (2000 est.)','008f384e5a897daafee2ddc5b10fa73f959ec05fcc0f884218c221f2b6624f72','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66a0309e5e7718570dac9b1b4c7e83784763b29a43eb8b0263dc95f40c090b58',2001,'DE','Germany','transportation',489,'Railways:
tofa/; 40,826 km including at least 14,253 km
electrified and 14,768 km double- or multiple-tracked
(1998)
note: since privatization in 1994, Deutsche Bahn AG
(DBAG) no longer publishes details of the tracks It
owns; in addition to the DBAG system there are 102
privately owned railway companies which own an
approximate 3,000 km to 4,000 km of the total tracks
Highways:
tofa/; 656,1 40 km
paved: 650,891 km (including 11,400 km of
expressways)
191
Germany (continued)
unpaved: 5,249 km (all-weather) (1998 est.)
Waterways: 7,500 km
note: major rivers include the Rhine and Elbe; Kiel
Canal is an important connection between the Baltic
Sea and North Sea (1999)
Pipelines: crude oil 2,500 km (1998)
Ports and harbors: Berlin, Bonn, Brake, Bremen,
Bremerhaven, Cologne, Dresden, Duisburg, Emden,
Hamburg, Karlsruhe, Kiel, Luebeck, Magdeburg,
Mannheim, Rostock, Stuttgart
Merchant marine:
total: 457 ships (1 ,000 CRT or over) totaling
6,414,724 GRT/7,952,776 DWT
ships by type: cargo 169, chemical tanker 10,
combination ore/oil 1 , container 243, liquefied gas 2,
passenger 3, petroleum tanker 7, railcar carrier 2,
refrigerated cargo 1, roll on/roll off 12, short-sea
passenger 7 (2000 est.)
Airports: 613 (2000 est.)
Airports - with paved runways:
total: 322
over 3,047 m:^3
2,438 to 3,047 m: 55
1,524 to 2,437 m: 67
914 to 1,523 m: 63
under 914 m:^24 (2000 est.)
Airports - with unpaved runways:
total: 291
over 3,047 m: 2
2,438 to 3,047m: 6
1,524 to 2,437 m: 5
914 to 1,523 m: 53
under 914 m:225 (2000 est.)
Heliports: 59 (2000 est.)
Railways:
total: 274 km
standard gauge: 274 km 1.435-m gauge (242 km
electrified; 178 km double track) (1998)
Highways:
tote/: 5,166 km
paved: 5,166 km (including 1 18 km of expressways)
unpaved: 0 km (1999)
Waterways: 37 km (on the Moselle)
Pipelines: petroleum products 48 km
Ports and harbors: Mertert
Merchant marine:
total: 50 ships (1 ,000 GRT or over) totaling 988,450
GRT/1 ,313,498 DWT
ships by type: bulk 2, chemical tanker 1 1 , container 2,
liquefied gas 18, passenger 4, petroleum tanker 6, roll
on/roll off 7
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 4 (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m:] (2000 est.)
Heliports: 1 (2000 est.)
Railways: 0 km
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: Macau
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2000 est.)
Railways:
total: 699 km
standard gauge: 699 km 1 .435-m gauge (233 km
electrified)
note: a 56-km extension of the Kumanovo-Beljakovci
line to the Bulgarian border at Gyveshevo is under
construction (2001)
Highways:
total: 8,684 km
paved: 5,540 km (including 133 km of expressways)
unpaved: km (1997)
Waterways:
note: lake transport only, on the Greek and Albanian
borders
Pipelines: 10 km
Ports and harbors: none
Airports: 16 (2000 est.)
Airports - with paved runways:
total: ^0
2,438 to 3,047 m: 2
under 914 m: 8 {2000 est.)
Airports - with unpaved runways:
total: 6
914 to 1523 m: 3
under 914 m: 3 (2000 est.)
Railways:
total: 2,739 km
standard gauge: 2,739 km 1 .435-m gauge; (1 ,991 km
electrified) (1998)
361
Netherlands (continued)
Highways:
fo/a/; 125,575 km
pai/ec/; 113,018 km (including 2,235 km of
expressways)
unpaved: ^2,5b7 km (1998 est.)
Waterways: 5,046 km
note: 47% of total route length is usable by craft of
1 ,000 metric ton capacity or larger
Pipelines: crude oil 41 8 km; petroleum products 965
km; natural gas 10,230 km
Ports and harbors: Amsterdam, DelfzijI, Dordrecht,
Eemshaven, Groningen, Haarlem, Ijmuiden,
Maastricht, Rotterdam, Terneuzen, Utrecht,
Vlissingen
Merchant marine:
total: 596 ships (1 ,000 GRT or over) totaling
4,321 ,500 GRT/4, 877,632 DWT
ships by type: bulk 3, cargo 371 , chemical tanker 43,
container 59, liquefied gas 21, livestock carrier 1,
multi-functional large-load carrier 9, passenger 8,
petroleum tanker 26, refrigerated cargo 29, roll on/roll
off 18, short-sea passenger 3, specialized tanker 5
(2000 est.)
Airports: 28 (2000 est.)
Airports - with paved runways:
total: 1 9
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m:e
914 to 1,523 m: 3
under 914 m:^ (2000 est.)
Airports ■ with unpaved runways:
total: 9
914 to 1,523 m: 3
under 914 m; 6 (2000 est.)
Heliports: 1 (2000 est.)','ed4b959f785dd1afb2b8357f196d3afe3fb50a1b183dd79193c84e02477c3ff1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36785cbbc521f29f5514b516581db433b4c9fa3eba0fec2e3ec8e795f237e248',2001,'GH','Ghana','transportation',498,'Railways:
total: 953 km (undergoing major rehabilitation)
narrow gauge: 953 km 1 .067-m gauge (32 km double
track) (1997 est.)
Highways:
total: 39,409 km
paved: 1 1 ,653 km (including 30 km of expressways)
unpaved: 27,756 km (1997)
Waterways: 1,293 km
note; Volta, Ankobra, and Tano Rivers provide 168
km of perennial navigation for launches and lighters;
Lake Volta provides 1 ,125 km of arterial and feeder
waterways
Pipelines: 0 km
Ports and harbors: Takoradi, Tema
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 3,484
GRT/1 8,583 DWT
ships by type: petroleum tanker 2, refrigerated cargo
4 (2000 est.)
Airports: 12 (2000 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m:^
1,524 to 2,437 m: 3
914 to 1,523 m: 2 {2000 est.)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m:1
914 to 1,523 m: 3
under 914 m: 2 (2000 est.)','45afcf0f214dc9b4dcb578316df2f6f9ff395c92f283d4c347bc1ae6a0719b0a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2758bb2eed382f9ace77361786a0c61afde562fa5eb92f03836fc22662a886',2001,'GI','Gibraltar','transportation',506,'Railways:
total: NA km; 1 .000-m gauge system in dockyard area
only
Highways:
total: 46.25 km
paved: 4625 km
unpaved: 0 km (2001)
Waterways: none
Pipelines: 0 km
Ports and harbors: Gibraltar
Merchant marine:
total: 49 ships (1 ,000 GRT or over) totaling 669,056
GRT/1 ,003,809 DWT
ships by type: bulk 1 , cargo 15, chemical tanker 6,
container 7, multi-functional large-load carrier 3,
passenger 2, petroleum tanker 14, roll on/roll off 1
(2000 est.)
Airports: 1 (2000 est.)
Airports ■ with paved runways:
total: 1
1,524 to 2,437 m: 1(2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2000 est.)
Railways:
total: 1 ,907 km
standard gauge: 1 ,907 km 1 .435-m gauge (1 ,003 km
electrified; 540 km double track)
Highways:
total: 57,847 km
paved: 30,254 km (including 327 km of expressways)
unpaved: 27, 593 km (1998)
Waterways: none
Pipelines: crude oil 362 km; petroleum products 491
km (abandoned); natural gas 241 km
Ports and harbors: Agadir, El Jadida, Casablanca,
El Jorf Lasfar, Kenitra, Mohammedia, Nador, Rabat,
Safi, Tangier; also Spanish-controlled Ceuta and
Melilla
Merchant marine;
total: 41 ships (1,000 GRT or over) totaling 223,052
GRT/272,786 DWT
ships by type: cargo 9, chemical tanker 6, container 5,
petroleum tanker 3, refrigerated cargo 9, roll on/roll off
8, short-sea passenger 1 (2000 est.)
Airports: 69 (2000 est.)
Airports - with paved runways:
total: 26
over 3,047 m: 10
2,438 to 3,047 m: 6
1,524 to 2,437 m: 9
914 to 1,523 m:1
under 914 m:1 (2000 est.)
Airports ■ with unpaved runways:
total: 43
2,438 to 3,047 m:1
1,524 to 2,437 m: 11
91 4 to 1,523 m: 20
under 914 m: 11 (2000 est.)
Heliports: 1 (2000 est.)','45e88a8c32762dd0965743806029d63487f57c400333d521c9c8a21890cea1d4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6060fd1c23e2c415d7a1fc05af09934841e51353f4529524f1ef097a65822c9b',2001,'GR','Greece','transportation',515,'Railways:
total: 2,548 km
standard gauge: 1 ,565 km 1 .435-m gauge (36 km
electrified; 23 km double track)
narrow gauge: 961 km 1.000-m gauge; 22 km
0.750-m gauge (a rack-type railway for steep grades)
Highways:
fofa/: 117,000 km
paved: 107,406 km (including 470 km of
expressways)
unpaved: 9,594 km (1996)
Waterways: 80 km
note: system consists of three coastal canals
including the Corinth Canal (6 km) which crosses the
Isthmus of Corinth connecting the Gulf of Corinth with
the Saronic Gulf and shortens the sea voyage from
the Adriatic to Peiraiefs (Piraeus) by 325 km; there are
also three unconnected rivers
198
Greece (continued)
Pipelines: crude oil 26 km; petroleum products
547 km
Ports and harbors: Alexandroupolis, Elefsis,
irakleion (Crete), Kavala, Kerkyra, Chalkis,
Igoumenitsa, Lavrion, Patrai, Peiraiefs (Piraeus),
Thessaloniki, Volos
Merchant marine:
total: 780 ships (1 ,000 GRT or over) totaling
25,564,988 GRT/44,761 ,916 DWT
ships by type: bulk 272, cargo 55, chemical tanker 22,
combination bulk 5, combination ore/oil 6, container
51 , liquefied gas 5, multi-functional large-load carrier
1, passenger 14, passenger/cargo 2, petroleum
tanker 255, refrigerated cargo 3, roll on/roll off 20,
short-sea passenger 63, specialized tanker 5, vehicle
carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: South Korea 1 , UK 4
(2000 est.)
Airports: 81 (2000 est.)
Airports ■ with paved runways:
total: 65
over 3,047 m: 6
2,438 to 3,047 m’AS
1,524 to 2,437 m::2
914 to 1,523 m:^6
under 914 m; 9 (2000 est.)
Airports ■ with unpaved runways:
to/a/; 16
over 3,047 m:1
1,524 to 2,437 m:^
914 to 1,523 m: 4
under 914 m: 10 (2000 est.)
Heliports: 2 (2000 est.)','e33e85571091ac61728649481da4cff2ee266b526ec94345abdccb3b6c2aa7c4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffe5153f2c83ec7a75fbc3f865fc40d6003ac8f02d6844b1dadaaf636942e895',2001,'GL','Greenland','transportation',523,'Railways: 0 km
Highways:
total: ^50 km
paved: 60 km
unpaved: 90 km
Waterways: none
Ports and harbors: Aasiaat (Egedesminde),
llulissat (Jakobshavn), Kangerlussuaq, Nanortalik,
Narsarsuaq, Nuuk (Godthab), Qaqortoq (Julianehab),
Sisimiut (Holsteinsborg), Tasiilaq (March 2001)
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 3,289 GRT/
1,500 DWT
ships by type: cargo 1 , passenger 1 (2000 est.)
Airports: 13 (2000 est.)
Airports - with paved runways:
totai: 8
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m:1
under 914 m: 4 (2000 est.)
Airports - with unpaved runways:
totai: 5
1,524 to 2,437 m:1
914 to 1523 m: 3
under 914 m:^ (2000 est.)','1fe500308f15d3bc0b131a148ef30b29f7f166f07c9e1d25787408d60ff74dd8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ab488069bf202120ea4527ce276435c8a2a42c05cf19cd621a0f32ad47ae005',2001,'GD','Grenada','transportation',530,'Railways: 0 km
Highways:
total: 040 km
paved: 638 km
unpaved: 402 km (1996)
Waterways: none
Ports and harbors: Grenville, Saint George''s
Merchant marine: none (2000 est.)
Airports: 3 (2000 est.)
202
Grenada (continued)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:^
1,524 to 2,437 wA
under 914 m:1 (2000 est.)
Railways: 0 km
Highways:
total: 1 ,040 km
paved: 320 km
unpaved: 720 km (1996 est.)
Waterways: none
Ports and harbors: Kingstown
Merchant marine:
total: 800 ships (1 ,000 GRT or over) totaling
6,705,336 GRT/1 0,1 34,002 DWT
ships by type: barge carrier 1 , bulk 1 31 , cargo 395,
chemical tanker 29, combination bulk 12, combination
ore/oil 1 , container 46, liquefied gas 7, livestock carrier
3, multi-functional large-load carrier 4, passenger 2,
petroleum tanker 56, refrigerated cargo 42, roll on/roll
off 49, short-sea passenger 1 1 , specialized tanker 1 0,
vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience; China 4, Ireland 1 ,
France 1 , Greece 3, Hong Kong 1 , Croatia 1 0, India 1 ,
Japan 2, Monaco 1, Netherlands 1 , Norway 2,
Netherlands Antilles 1 , Pakistan 1 , Russia 1 , Slovenia
5, UAE 1 (2000 est.)
Airports: 6 (2000 est.)
Airports - with paved runways:
total: 5
914 to 1,523 m: 3
under 914 m: 2 {2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2000 est.)','acce5ea16cf4e35199659303f7e9ea10cd26a17109a025066606288b8a9e269c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06cf1c825b348f044d36ce18412947b5deb14168141d1f1b8cf9486cd1df8e91',2001,'GU','Guam','transportation',541,'Railways: 0 km
Highways:
total: 885 km
paved: 675 km
unpaved: 210 km
note: there are also 685 km of roads classified
non-public, including roads located on federal
government installations
Waterways: none
Ports and harbors: Apra Harbor
Merchant marine: none (2000 est.)
Airports: 5 (2000 est.)
206
Guam (continued)
Airports ■ with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m-A
914 to 1,523 m:^ (2000 est.)
Airports «• with unpaved runways:
total: 1
under 914 m:^ (2000 est.)','aa88104d1b80a2f40dd9322079bbc340b2d9de29da8e01519b85c43d42bdcba8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb70511effbcccc8841db7b58606709c70a922c4de6435e0af0b9165c8a046d1',2001,'GT','Guatemala','transportation',548,'Railways:
total: 884 km (102 km privately owned)
narrow gauge: 884 km 0.91 4-m gauge (single track)
Highways:
total: 13,856 km
paved: 4,870 km (including 140 km of expressways)
unpaved: 9,486 km (1998)
Waterways: 990 km
note: 260 km navigable year round; additional 730 km
navigable during highwater season
Pipelines: crude oil 275 km
Ports and harbors: Champerico, Puerto Barrios,
Puerto Quetzal, San Jose, Santo Tomas de Castilla
Merchant marine: none (2000 est.)
Airports: 477 (2000 est.)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 8
1,524 to 2,437 m''A
914 to 1,523 m:b
under 914 m; 2 (2000 est.)
Airports ■ with unpaved runways:
total: 488
2,438 to 3,047 m:1
1,524 to 2,437 m: 9
914 to 1,523 m: 124
under 914 m: 332 (2000 est.)','2bfcd22b3f175ffb83a57320f27853702764067e3e62da578f85b9ec7a49c09e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f60eea2b7e12ba4f370f175897409c78ef629e86129b4d06afa379500787d128',2001,'GG','Guernsey','transportation',556,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Waterways; none
Ports and harbors: Saint Peter Port, Saint
Sampson
Merchant marine: none (2000 est.)
Airports: 2 (2000 est.)
Airports ■ with paved runways:
total: 2
914 to 1,523 m‘A
under 914 m:^ (2000 est.)','fb6dc8063961de140c1273cc46aa5914277225a0f0a56729b480f899c51f697f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73e25c049c7f901e1283a4a917353cbe8f112d422b9d45c5766e55991c485b7d',2001,'GW','Guinea-Bissau','transportation',559,'Railways:
total: 1 ,086 km
standard gauge: 279 km 1 .435-m gauge
narrow gauge: 807 km 1 .000-m gauge (includes 662
km in common carrier service from Kankan to
Conakry)
Highways:
total: 30,500 km
paved: 5,033 km
unpaved: 25,4^7 km (1996)
Waterways: 1 ,295 km (navigable by shallow-draft
native craft)
Ports and harbors: Boke, Conakry, Kamsar
Merchant marine: none (2000 est.)
Airports: 15 (2000 est.)
Airports - with paved runways:
total: 5
over 3,047 m:1
2,438 to 3,047 m-A
1,524 to 2,437 m: 3 {2m est.)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m:0
914 to 1,523 m: 3
under 914 m:1 (2000 est.)
Background: In 1 994, 20 years after independence
from Portugal, the country’s first multiparty legislative
and presidential elections were held. An army uprising
that triggered a bloody civil war in 1998, created
hundreds of thousands of displaced persons. The
president was ousted by a military junta in May 1 999.
An interim government turned over power in February
2000 when opposition leader Koumba YALLA took
office following two rounds of transparent presidential
elections. Guinea-Bissau''s transition back to
democracy will be complicated by a crippled economy
devastated by civil war and the military''s predilection
for governmental meddling.','2b4b2fc6f28cbe43906f1d40ee5af6d755406cf0f9602430f6d9bdc20b1f789a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cd02fedb1ef342844b0d94fd3855688caf5a82ce82c9e9dec44f8fc42d69bc1',2001,'GY','Guyana','transportation',566,'Railways;
total: ^S7 km (all dedicated to ore transport)
standard gauge: 139 km 1.435-m gauge
narrow gauge: 4S km 0.91 4-m gauge
Highways:
total: 7, 970 km
paved: 590 km
unpaved: 7,380 km (1 996)
Waterways: 5,900 km (total length of navigable
waterways)
note: Berbice, Demerara, and Essequibo rivers are
navigable by oceangoing vessels for 1 50 km, 1 00 km,
and 80 km, respectively
Ports and harbors: Bartica, Georgetown, Linden,
New Amsterdam, Parika
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 2,929 GRT/
4,507 DWT
ships by type: cargo 2 (2000 est.)
Airports: 51 (2000 est.)
217
Guyana (continued)
Airports - with paved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m:^
under 914 m: 2 {2000 est.)
Airports - with unpaved runways:
total: 45
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 914 m: 36 (2000 est.)
Railways:
total: km (single track)
standard gauge: 80 km 1 .435-m gauge
narrow gauge: 86 km 1 .000-m gauge
note: Suriname railroads are not in operation (2000)
Highways:
total: 4,530 km
paved: M3 km
unpaved: 3,352 km (1 996 est.)
Waterways: 1,200 km
note: most important means of transport; oceangoing
vessels with drafts ranging up to 7 m can navigate
many of the principal waterways
Ports and harbors: Albina, Moengo, New Nickerie,
Paramaribo, Paranam, Wageningen
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 3,432 GRT/
4,525 DWT
ships by type: cargo 1 , container 1 , petroleum tanker
1 (2000 est.)
Airports: 46 (2000 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
914 to 1,523 m:^
under 914 m.* 3 (2000 est.)
Airports - with unpaved runways:
total: 41
1,524 to 2,437 m:1
914 to 1,523 m: 5
under 91 4 m: 35 (2000 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden
Merchant marine: none (2000 est.)
Airports: 4 (2000 est.)
Airports - with paved runways:
total: 1
1524 to 2,437 m:U2000 est.)
Airports ■ with unpaved runways:
total: 3
under 914 m: 3 (2000 est.)','46847b79a18b85f926ade9cd186873abe7a1f614578b3bbf6bc94f089cc4226a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17e01bbe31c411415b0c62ceb730b887a9ff7140795e14c5360035b18ee331ea',2001,'HK','Hong Kong','transportation',577,'Railways:
total: 34 km
standard gauge: 34 km 1 .435-m gauge (all electrified)
(1996 est.)
Highways:
total: IfiOl km
paved: IfiOl km
unpaved: 0 km (1 997)
Waterways: none
Ports and harbors: Hong Kong
Merchant marine:
total: 354 ships (1 ,000 GRT or over) totaling
1 0,330,662 GRT/1 7,227,31 5 DWT
ships by type: barge carrier 1 , bulk 208, cargo 36,
chemical tanker 7, combination bulk 2, container 59,
liquefied gas 6, multi-functional large-load carrier 2,
petroleum tanker 26, refrigerated cargo 3, short-sea
passenger 1 , vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Bermuda 2, Belgium 1 ,
Canada 2, China 9, Japan 3, Mongolia 1, Norway 1,
SouthAfrica1,UK7(2000 est.)
Airports: 3 (2000 est.)
226
Hong Kong (continued)
Airports - with paved runways:
total: 3
over 3,047 m: 2
1,524 to 2,437 m:1 (2000 est.)
Heliports: 2 (2000 est.)','5ad9f2595f95a1fedcb5ad0a7adc83b397441c62f6d86cd57ab2f2745c918851','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7f5043063564136cd8444ade36b08ea010a6c08538b0ef7c5ecc540e7267739',2001,'AT','Austria','transportation',587,'Railways: 0 km
Highways:
total: 12,689 km
paved: 3,439 km
unpaved: 9,250 km (1998 est.)
Waterways: none
Ports and harbors: Akureyri, Hornafjordur,
Isafjordhur, Keflavik, Raufarhofn, Reykjavik,
Seydhisfjordhur, Straumsvik, Vestmannaeyjar
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 3,435 GRT/
4,538 DWT
ships by type: chemical tanker 1 , petroleum tanker 1
(2000 est.)
Airports: 87 (2000 est.)
Airports - with paved runways:
total: 12
over 3,047 m:1
232
Iceland (continued)
1,524 to 2,437 m: A
914to1,523m:l{2m est.)
Airports - with unpaved runways:
total: 75
1,524 to 2,437 m: 3
914 to 1,523 m: 20
under 914 m: 52 (2000 est.)
M I i i t a r y
Military branches: no regular armed forces; Police,
Coast Guard; note - Iceland''s defense is provided by
the US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Military manpower ■ availability:
males age 15-49:7^,24] (2001 est.)
Military manpower - fit for military service:
males age 15-49: 62,704 (2001 est.)
Military expenditures - dollar figure: $0
Military - note: defense is provided by the
US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Railways:
total: 62,915 km (12,307 km electrified; 12,617 km
double track)
broad gauge: 40 fi20 km 1 .676-m gauge
narrow gauge: 18,501 km 1.000-m gauge; 3,794 km
0.762-m and 0.61 0-m gauge (1998 est.)
Highways:
tofa/; 3,31 9,644 km
paved; 1,517,077 km
unpaved: 1,802,567 km (1996)
Waterways: 16,180 km
note: 3,631 km navigable by large vessels
Pipelines: crude oil 3,005 km; petroleum products
2,687 km; natural gas 1,700 km (1995)
Ports and harbors: Chennai (Madras), Cochin,
Jawaharal Nehru, Kandia, Kolkata (Calcutta), Mumbai
(Bombay), Vishakhapatnam
Merchant marine:
total: 315 ships (1 ,000 GRT or over) totaling
6,433,831 GRT/1 0,691 ,973 DWT
ships by type: bulk 1 1 7, cargo 70, chemical tanker 1 5,
combination bulk 1, combination ore/oil 3, container
15, liquefied gas 9, passenger/cargo 5, petroleum
tanker 76, short-sea passenger 2, specialized tanker
2 (2000 est.)
Airports: 337 (2000 est.)
Airports - with paved runways:
total: 235
over 3,047 m: ^3
2,438 to 3,047 m: 45
1,524 to 2,437 m:5\\
914 to 1,523 m: 77
under 914 m; 16 (2000 est.)
Airports - with unpaved runways:
total: 102
2,438 to 3,047 m:^
1,524 to 2,437 m: 5
914 to 1,523 m: 40
under 914 m: 55 (2000 est.)
Heliports: 16 (2000 est.)
Ports and harbors: Chennai (Madras; India),
Colombo (Sri Lanka), Durban (South Africa), Jakarta
(Indonesia), Kolkata (Calcutta; India) Melbourne
(Australia), Mumbai (Bombay; India), Richards Bay
(South Africa)
Railways:
total: 6,458 km
narrow gauge: 5, km 1.067-m gauge (101 km
electrified; 101 km double track); 497 km 0.750-m
gauge (1995)
Highways:
fofa/; 342,700 km
paved: 158,670 km
unpaved: 184,030 km (1997)
Waterways: 21 ,579 km total
note: Sumatra 5,471 km, Java and Madura 820 km,
Kalimantan 10,460 km, Sulawesi (Celebes) 241 km,
Irian Jaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum products
456 km; natural gas 1 ,703 km (1989)
Ports and harbors: Cilacap, Cirebon, Jakarta,
Kupang, Makassar, Palembang, Semarang,
Surabaya
Merchant marine:
total: 609 ships (1 ,000 GRT or over) totaling
2,698,157 GRT/3,723,933 DWT
ships by type: bulk 36, cargo 357, chemical tanker 1 0,
container 25, liquefied gas 3, livestock carrier 1 ,
passenger 7, passenger/cargo 14, petroleum tanker
117, refrigerated cargo 1 , roll on/roll off 15, short-sea
passenger 8, specialized tanker 10, vehicle carrier 5
(2000 est.)
Airports: 453 (2000 est.)
Airports - with paved runways:
fofa/.''136
over 3,047 m: 4
2,438 to 3,047 m: 12
1,524 to 2,437 m: 39
914 to 1,523 m: 44
under 914 m: 37 (2000 est.)
Airports - with unpaved runways:
/ofa/;317
1,524 to 2,437 m: 6
914 to 1,523 m: 23
under 914 m: 283 (2000 est.)
Heliports: 4 (2000 est.)
Railways:
total: 5,600 km
broad gauge: 94 km 1 .676-m gauge
standard gauge: 5,506 km 1 .435-m gauge (146 km
electrified)
note: broad gauge track is employed at the borders
with Azerbaijan and Turkmenistan which have
broad-gauge rail systems (2001)
Highways:
fofa/; 140,200 km
paved: 49,440 km (including 470 km of expressways)
unpaved: 90,760 km (1998 est.)
Waterways: 904 km
note: the Shaft al Arab is usually navigable by
maritime traffic for about 130 km; channel has been
dredged to 3 m and is in use
Pipelines: crude oil 5,900 km; petroleum products
3,900 km; natural gas 4,550 km
Ports and harbors: Abadan (largely destroyed in
fighting during 1980-88 war), Ahvaz, Bandar ''Abbas,
Bandar-e Anzali, Bushehr, Bandar-e Emam
Khomeyni, Bandar-e Lengeh, Bandar-e Mahshahr,
Bandar-e Torkaman, Chabahar (Bandar Beheshti),
Jazireh-ye Khark, Jazireh-ye Lavan, Jazireh-ye Sirri,
Khorramshahr (limited operation since November
1992), Now Shahr
Merchant marine:
total: 152 ships (1 ,000 GRT or over) totaling
4,097,977 GRT/7, 131 ,688 DWT
ships by type: bulk 49, cargo 38, chemical tanker 4,
combination bulk 1, container 10, liquefied gas 1,
multi-functional large-load carrier 6, petroleum tanker
32, refrigerated cargo 1, roll on/roll off 9, short-sea
passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Singapore 1 (2000 est.)
Airports: 317 (2000 est.)
Airports - with paved runways:
tofa/;117
over 3,047 m: 33
2,438 to 3,047 m: 23
1,524 to 2,437 m: 25
914 to 1,523 m: 24
under 914 m; 7 (2000 est.)
Airports - with unpaved runways:
total: 200
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m‘A3
914 to 1,523 m‘A22
under 914 m:30 (2000 est.)
Heliports: 1 1 (2000 est.)
241
Iran (continued)
Railways:
total: 2,032 km
standard gauge: 2,032 km 1 .435-m gauge
note: rail link between Iraq and Syria restored in 2000
after 19 years
Highways:
total: 45,550 km
paved: 38,400 km
unpaved: 7,150 km (1996 est.)
Waterways: 1,015 km
note: Shatt al Arab is usually navigable by maritime
traffic for about 1 30 km; channel has been dredged to
3 m and is in use; Tigris and Euphrates Rivers have
navigable sections for shallow-draft boats; Shatt al
Basrah canal was navigable by shallow-draft craft
before closing in 1991 because of the Gulf war
Pipelines: crude oil 4,350 km; petroleum products
725 km; natural gas 1 ,360 km
Ports and harbors: Umm Qasr, Khawr az Zubayr,
and Al Basrah have limited functionality
Merchant marine:
total: 30 ships (1 ,000 GRT or over) totaling 453,273
GRT/779,662 DWT
ships by type: cargo 14, passenger 1 , passenger/
cargo 1 , petroleum tanker 1 2, refrigerated cargo 1 , roll
on/roll off 1 (2000 est.)
Airports: 110 (2000 est.)
Airports - with paved runways:
total: 76
over 3,047 m: 20
2,438 to 3,047 m: 30
1,524 to 2,437 m:0
914 to 1,523 m: 7
under 914 m:7 (2000 est.)
Airports - with unpaved runways:
total: 34
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 4
914 to 1,523 m: 10
under 914 m.- 12 (2000 est.)
Heliports: 4 (2000 est.)','f83dc156c97320a06be9d7d45c4d31eb0a914a83918fb63a93429fa576cb1df6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02078ceca4812038732a28353788dffcb909ecf5fe9340974c0144b236850478',2001,'IE','Ireland','transportation',597,'Railways:
total: 1 ,947 km
broad gauge: 947 km 1.600-m gauge (38 km
electrified; 485 km double track) (1998)
Highways:
total: 92,500 km
paved: 87,043 km (including 1 15 km of expressways)
unpaved: 5,457 km (1999 est.)
Waterways: 700 km (limited facilities for commercial
traffic) (1998)
Pipelines: natural gas 7,592 km (transmission 1,158
km; distribution 6,434 km) (2000)
Ports and harbors: Arklow, Cork, Drogheda,
Dublin, Foynes, Galway, Limerick, New Ross,
Waterford
246
Ireland (continued)
Merchant marine:
total: 29 ships (1,000GRT or over) totaling 115,554
GRT/1 35,391 DWT
ships by type: bulk 4, cargo 22, container 2, short-sea
passenger 1 (2000 est.)
Airports: 44 (2000 est.)
Airports - with paved runways:
total: 17
over 3,047 m:^
2,438 to 3,047 m:\\
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 7 (2000 est.)
Airports ■ with unpaved runways:
total: 27
914 to 1,523 m: 2
under 914 m: 25 (2000 est.)','95cfa32b42d47815c3566191fd48e384edfc34c8952bcbed122e9f93d55124cd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b98c05f49765bfb7a14897258e7ea3d589026e58ec7dafc35a47cc704a001c1',2001,'IL','Israel','transportation',605,'Railways:
tofa/.''610km
standard gauge: 6^0 km 1.435-m gauge (1996)
Highways:
tofa/.'' 15,965 km
paved: 15,965 km (including 56 km of expressways)
unpaved: 0 km (1 998 est.)
Waterways: none
Pipelines: crude oil 708 km; petroleum products 290
km; natural gas 89 km
Ports and harbors: Ashdod, Ashqelon, Elat (Eilat),
Hadera, Haifa, Tel Aviv-Yafo
Merchant marine:
total: 1 7 ships (1 ,000 GRT or over) totaling 631 ,582
GRT/745,011 DWT
ships by type: container 16, roll on/roll off 1
(2000 est.)
Airports: 55 (2000 est.)
Airports - with paved runways:
total: 30
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 7
914 to 1,523 m:W
under 914 m; 7 (2000 est.)
Airports - with unpaved runways:
total: 25
1,524 to 2,437 m:)
914 to 1,523 m: 4
under 914 m: 20 (2000 est.)
Heliports: 2 (2000 est.)','2d1f3f82185f6a244b4ed935a180ba031f3d01cbd01d93260e64288e712757a1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00ece9d42453dee1bb79bfb5b4dbe0e16ceda8e9aa02c8d794181fd830f33686',2001,'TN','Tunisia','transportation',613,'Railways:
tete/; 19,394 km
standard gauge: ^8,07^ km 1.435-m gauge; Italian
Railways (FS) operates 16,014 km of the total
standard gauge routes (1 1,322 km electrified)
narrow gauge: ^^2 km 1.000-m gauge (112 km
electrified); 1,211 km 0.950-m gauge (153 km
electrified) (1998)
Highways:
total: 654,676 km
paved: 654,676 km (including 6460 km of
expressways)
unpaved: 0 km (1997)
Waterways: 2,400 km
note: for various types of commercial traffic, although
of limited overall value
Pipelines: crude oil 1,703 km; petroleum products
2,148 km; natural gas 19,400 km
Ports and harbors: Augusta (Sicily), Bagnoli, Bari,
Brindisi, Gela, Genoa, La Spezia, Livorno, Milazzo,
Naples, Porto Foxi, Porto Torres (Sardinia), Salerno,
Savona, Taranto, Trieste, Venice (2001)
Merchant marine:
total: 445 ships (1 ,000 GRT or over) totaling
8,005,136 GRT/10,556,244 DWT
ships by type: bulk 44, cargo 41 , chemical tanker 77,
combination ore/oii 4, container 24, liquefied gas 38,
multi-functional large-load carrier 1 , passenger 1 1 ,
petroleum tanker 85, refrigerated cargo 1 , roll on/roll
off 64, short-sea passenger 26, specialized tanker 1 4,
vehicle carrier 15 (2000 est.)
Airports: 135 (2000 est.)
Airports - with paved runways:
total: 97
over 3,047 m: 5
2,438 to 3,047 m: 32
1, 524 to 2,437 m-A7
914 to 1,523 m:3\\
under 914 m: 12 (2000 est.)
Airports ■ with unpaved runways:
total: 38
1,524 to 2,437 m: 2
914 to 1,523 m:^S
under 914 m: 18 (2000 est.)
Heliports: 4 (2000 est.)
Railways:
total: 2,168 km
standard gauge: 471 km 1.435-m gauge
narrow gauge: 1 ,687 km 1 .000-m gauge
dual gauge: 10 km 1. 000-m and 1.435-m gauges
(three rails)
Highways:
total: 23,100 km
paved: 18,226 km
unpaved: 4,874 km (1996 est.)
Waterways: none
Pipelines: crude oil 797 km; petroleum products 86
km; natural gas 742 km
Ports and harbors: Bizerte, Gabes, La Goulette,
Sfax, Sousse, Tunis, Zarzis
Merchant marine:
total: 15 ships (1 ,000 GRT or over) totaling 149,554
GRT/1 56,861 DWT
ships by type: bulk 2, cargo 4, chemical tanker 3,
liquefied gas 1 , petroleum tanker 1 , short-sea
passenger 3, specialized tanker 1 (2000 est.)
Airports: 32 (2000 est.)
Airports - with paved runways:
total: 15
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3 {2000 est.)
Airports - with unpaved runways:
total: 17
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 7 {2000 est.)
Railways:
total: 8,607 km
standard gauge: 8,607 km 1 .435-m gauge (1 ,524 km
electrified) (1999)
Highways:
total: 382,397 km
paved: 95,599 km (including 1 ,726 km of
expressways)
unpavecf.'' 286,798 km (1999 est.)
Waterways: 1,200 km (approximately)
Pipelines: crude oil 1 ,738 km; petroleum products
2,321 km; natural gas 708 km
Ports and harbors: Gemlik, Hopa, Iskenderun,
Istanbul, Izmir, Kocaeli (Izmit), Icel (Mersin), Samsun,
Trabzon
Merchant marine:
total: 548 ships (1 ,000 GRT or over) totaling
5,617,302 GRT/9,088,451 DWT
ships by type: bulk 140, cargo 242, chemical tanker
41 , combination bulk 5, combination ore/oil 6,
container 21 , liquefied gas 6, passenger/cargo 1,
petroleum tanker 43, refrigerated cargo 3, roll on/roll
off 25, short-sea passenger 10, specialized tanker 5
(2000 est.)
Airports: 121 (2000 est.)
Airports - with paved runways:
total: 86
over 3,047 m:
2,438 to 3,047 m: 29
1,524 to 2,437 m''A9
914 to 1,523 m: 16
under 914 m: 6 (2000 est.)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m:1
914 to 1,523 m: 6
under 914 m: 26 (2000 est.)
Heliports: 2 (2000 est.)
Railways:
total: 2,^87 km
broad gauge: 2, ^87 km 1.520-m gauge (1996 est.)
Highways:
total: 24,000 km
pai/ed; 19,488 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: A, 5^2 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1996)
Waterways: the Amu Darya is an important inland
waterway for Turkmenistan
Pipelines: crude oil 250 km; natural gas 4,400 km
Ports and harbors: Turkmenbashi
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 6,459 GRT/
8,865 DWT
ships by type: container 1 (2000 est.)
Airports: 76 (2000 est.)
Airports - with paved runways:
total: 13
2,438 to 3,047 m: 9
1,524 to 2,437 m: A {2000 est.)
Airports - with unpaved runways;
total: 63
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m:^0
under 914 m:A1 (2000 est.)
Railways: 0 km
Highways:
total: 121 km
paved: 24 km
unpaved: 97 km
Waterways: none
Ports and harbors: Grand Turk, Providenciales
Merchant marine: none (2000 est.)
Airports: 8 (2000 est.)
Airports - with paved runways:
total: 4
1,524 to 2,437 m: 3
914 to 1,523 m:^ (2000 est.)
Airports - with unpaved runways:
total: 4
914 to 1,523 m: 2
under 914 m:2 (2000 est.)','e6f4780bd65aa32ffc49c682e54cbc114370a75d6dead72b193708e4f9df98f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac749527ec50df2a8be4709b03cac74bee0a20e15bb890368b059db3cd15c164',2001,'JM','Jamaica','transportation',622,'Railways:
total: 370 km
standard gauge: 370 km 1.435-m gauge; note - 207
km belong to the Jamaica Railway Corporation in
common carrier service, but are no longer operational;
the remaining track is privately owned and used to
transport bauxite
Highways:
total: 18,700 km
paved; 13,100 km
unpaved: 5,600 km (1997 est.)
Waterways: none
Pipelines: petroleum products 10 km
Ports and harbors: Alligator Pond, Discovery Bay,
Kingston, Montego Bay, Ocho Rios, Port Antonio,
Rocky Point, Port Esquivel (Longswharf)
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,930 GRT/
3,065 DWT
ships by type: petroleum tanker 1 (2000 est.)
Airports: 35 (2000 est.)
Airports - with paved runways:
total: M
2,438 to 3,047 m: 2
254
Jamaica (continued)
1,524to2,437m:\\
91 4 to 1,523 m: 3
under 914 m; 5 (2000 est.)
Airports - with unpaved runways:
total: 24
914 to 1,523 m: 2
under 914 m: 22 (2000 est.)','e39e344db3ff28b503a32784dc7a199bf5a74735fb7c37f75832ea72d0cd0ccf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c79ee279e7fa51307616f809be09985d532c90cd903f86daae01cc9e8ee8d9d0',2001,'IS','Iceland','transportation',627,'Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m:1 (2000 esl)','aeb9cc11b5137c14261cc07c206034c65b506fd32f0a77957afe9012e064214c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('850aa12f76b0aa54360bc8a9e247d08cdf3a92fbdc422f5bb7aa8b51c98e1b05',2001,'NO','Norway','transportation',634,'Railways:
fote/.'' 23,670.7 km
standard gauge: 2, S93A km 1.435-m gauge (entirely
electrified)
narrow gauge: 89.8 km 1 .372-m gauge (89.8 km
electrified): 20,656.8 km 1 .067-m gauge (1 0,383.6 km
electrified): 31 km 0.762-m gauge (3.6 km electrified)
(1994)
Highways:
tofa/; 1,152,207 km
paved: 863,003 km (including 6,1 14 km of
expressways)
unpaved: 289,204 km (1997 est.)
Waterways: 1,770 km approximately
note: seagoing craft ply all coastal inland seas
Pipelines: crude oil 84 km; petroleum products 322
km; natural gas 1,800 km
Ports and harbors: Akita, Amagasaki, Chiba,
Hachinohe, Hakodate, Higashi-Harima, Himeji,
Hiroshima, Kawasaki, Kinuura, Kobe, Kushiro,
Mizushima, Moji, Nagoya, Osaka, Sakai, Sakaide,
Shimizu, Tokyo, Tomakomai
Merchant marine:
total: 630 ships (1 ,000 GRT or over) totaling
11,691,174 GRT/15,484,848 DWT
ships by type: bulk 1 37, cargo 51 , chemical tanker 1 5,
combination bulk 22, combination ore/oil 3, container
22, liquefied gas 49, passenger 9, passenger/cargo 2,
petroleum tanker 194, refrigerated cargo 15, roll on/
roll off 49, short-sea passenger 6, vehicle carrier 56
(2000 est.)
Airports: 173 (2000 est.)
Airports - with paved runways:
total: 142
over 3,047 m: 8
2,438 to 3,047 m: 38
1,524 to 2,437 m: 38
914 to 1,523 m: 30
under 914 m: 30 (2000 est.)
Airports ■ with unpaved runways:
total: 31
914 to 1,523 m: 4
under 914 m: 27 (2000 est.)
Heliports: 16 (2000 est.)
Railways:
total: 4, 0^2 km
standard gauge: 4, 0]2 km 1.435-m gauge (2,530 km
electrified; 96 km double track) (1998)
Highways:
tofa/; 91,180 km
paved: 67,838 km (including 109 km of expressways)
unpaved: 23,342 km (1999)
Waterways: 1 ,577 km (along west coast)
note: navigable by 2.4 m maximum draft vessels
Pipelines: refined petroleum products 53 km
Ports and harbors: Bergen, Drammen, Floro,
Flammerfest, Harstad, Flaugesund, Kristiansand,
Larvik, Narvik, Oslo, Porsgrunn, Stavanger, Tromso,
Trondheim
Merchant marine:
total: 764 ships (1 ,000 GRT or over) totaling
20,667,370 GRT/32, 100,208 DWT
ships by type: bulk 89, cargo 1 39, chemical tanker
114, combination bulk 9, combination ore/oil 37,
container 15, liquefied gas 84, passenger 10,
petroleum tanker 151, refrigerated cargo 10, roll on/
roll off 45, short-sea passenger 22, specialized tanker
1, vehicle carrier 38
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Japan 1 ,
Mexico 1 , Sweden 1 (2000 est.)
Airports: 103 (2000 est.)
Airports - with paved runways:
total: 67
over 3,047 m:^
2,438 to 3,047 m:\\2
1, 524 to 2,437 m''A2
m to 1,523 m:\\4
under 914 m: 28 (2000 est.)
Airports - with unpaved runways:
total: 36
914 to 1,523 m: 5
under 91 4 m: 31 (2000 est.)
Heliports: 1 (2000 est.)
Railways: 0 km
Highways:
total: 32,800 km
paved: 9,840 km (including 550 km of expressways)
unpaved: 22,960 km (1996)
Pipelines: crude oil 1 ,300 km; natural gas 1 ,030 km
Ports and harbors: Matrah, Mina'' al Fahl, Mina''
Raysut
Merchant marine:
total: A ships (1,000 GRT or over) totaling 18,167
GRT/1 1,307 DWT
ships by type: cargo 2, passenger 1 , passenger/cargo
1 (2000 est.)
Airports: 143 (2000 est.)
Airports ■ with paved runways:
total: 6
over 3,047 m: 4
2,438 to 3,047 m:\\
914to1,523m:\\ (2000 est.)
Airports - with unpaved runways:
total: 137
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 56
914 to 1,523 m: 37
under 914 m: 36 (2000 est.)
Heliports: 1 (2000 est.)
Ports and harbors: Bangkok (Thailand), Hong
Kong, Kao-hsiung (Taiwan), Los Angeles (US),
Manila (Philippines), Pusan (South Korea), San
Francisco (US), Seattle (US), Shanghai (China),
Singapore, Sydney (Australia), Vladivostok (Russia),
Wellington (NZ), Yokohama (Japan)
Transportation - note: Inside Passage offers
protected waters from southeast Alaska to Puget
Sound (Washington state)
Railways:
fofa/; 8, 163 km
broad gauge: 7, 718 km 1.676-m gauge (293 km
electrified; 1,037 km double track)
narrow gauge: ^45 km 1.000-m gauge (1996 est.)
(2000)
Highways:
total: 247,811 km
paved: 141,252 km (including 339 km of
expressways)
unpaved: 106,559 km (1998)
Waterways: none
Pipelines: crude oil 250 km; petroleum products 885
km; natural gas 4,044 km (1987)
Ports and harbors: Karachi, Port Muhammad bin
Qasim
Merchant marine:
fofa/.'' 17 ships (1,000 GRT or over) totaling 240,605
GRT/367,040 DWT
ships by type: cargo 1 3, container 3, petroleum tanker
1 (2000 est.)
Airports: 117 (2000 est.)
Airports - with paved runways:
total: 82
over 3,047 m: 12
2,438 to 3,047 m: 21
1,524 to 2,437 m: 82
914 to 1,523 m: 14
under 914 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m: 7
914 to 1,523 m: 11
under 91 4 m: 17 (2000 est.)
Heliports: 8 (2000 est.)
Railways: 0 km
Highways:
total: 61 km
paved: 36 km
unpaved: 25 km
Waterways: none
Ports and harbors: Koror
Merchant marine: none (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 1
1524 to 2,437 m:1 (2000 est.)
Airports - with unpaved runways:
total: 2
1,524 to 2,437 m: 2 {2000 est.)','d6fb15f23537f7fc572f7a2d03f40ae2cefc7af3f5e72fa3b82101755c9a9639','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb20ce62317ba827b3a04db4632505dd0f88e61151ee2fbe9eab0bf2beb36bb0',2001,'JO','Jordan','transportation',642,'Railways:
total: 677 km
narrow gauge: 677 km 1 .050-m gauge (2000)
Highways:
total: 8,000 km
paved: 8,000 km
unpaved: 0 km (2000 est.)
Waterways: none
Pipelines: crude oil 209 km; note - may not be in use
Ports and harbors: Al ''Aqabah
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 40,91 9
GRT/57,777 DWT
ships by type: bulk 1 , cargo 3, container 1 , roll on/roll
off 1 (2000 est.)
Airports: 18 (2000 est.)
263
Jordan (continued)
Airports - with paved runways:
total: 15
over 3,047 m: 7
2,438 to 3,047 !n:e
914 to 1,523 m:1
under 914 m:) (2000 est.)
Airports - with unpaved runways:
total: 3
under 914 m: 3 (2000 est.)
Heliports: 1 (2000 est.)','42a4070ed1358adfe541e4047be22cab717068a6e5827d9787422496fe215066','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7e0ded15ede119dc2be6312586bb9a76776b8fb1d85dae32fd589fe70f032ef',2001,'KZ','Kazakhstan','transportation',651,'Railways:
total: 14,400 km in common carrier service; does not
include industrial lines
broad gauge: 14,400 km 1 .520-m gauge (3,299 km
electrified) (1997)
Highways:
total: NA km
paved: 150,000 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: NA km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (2000 est.)
Waterways: 3,900 km
note: on the Syrdariya (Syr Darya) and Ertis (Irtysh)
rivers
Pipelines: crude oil 2,850 km; refined products
1 ,500 km; natural gas 3,480 km (1992)
Ports and harbors: Aqtau (Shevchenko), Atyrau
(Gur''yev), Oskemen (Ust-Kamenogorsk), Pavlodar,
Semey (Semipalatinsk)
Airports: 449 (2000 est.)
Airports - with paved runways:
total: 28
over 3,047 m: 8
2,438 to 3,047 m:U
1,524 to 2,437 m: 5
under 914 m; 3 (2000 est.)
Airports - with unpaved runways:
total: 421
over 3,047 m: M
2,438 to 3,047 m: 18
1,524 to 2,437 m: 45
914 to 1,523 m: 101
under 914 m: 246 (2000 est.)','304fd99add4f2f51cbc3a099b753d3aaf821ff40f7b14421cc83ddf8fcd95d2c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7680c1d100f0ab29732a83ac83273c76f3bd15d6a0b09ff12609bacaa88242f9',2001,'KE','Kenya','transportation',660,'Railways:
total: 2,778 km
narrow gauge: 2, 77Q km 1.000-m gauge
note.'' the line connecting Nairobi with the port of
Mombasa is the most important in the country
Highways:
total: 63,800 km
paved: 8,868 km
unpaved.'' 54,932 km (1996)
Waterways: NA
note; part of the Lake Victoria system is within the
boundaries of Kenya
Pipelines: petroleum products 483 km
Ports and harbors: Kisumu, Lamu, Mombasa
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 4,893 GRT/
6,255 DWT
ships by type: petroleum tanker 1 , roll on/roll off 1
(2000 est.)
Airports: 230 (2000 est.)
Airports - with paved runways:
total: 22
over 3,047 m: 4
2,438 to 3,047 m-A
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 208
2,438 to 3,047 m:1
1,524 to 2,437 m:U
914 to 1,523 m:m
under 914 m: 84 (2000 est.)','4213d6645e9ad5ac75e94f93d6b1c6adf3c53ef3d4fd53f186bd08a2ec4633e4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('915a756445bedf8bad15b661946537828adba41e76f67316cd6ddb80a3b0e23b',2001,'WS','Samoa','transportation',667,'Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: lagoon was used as a halfway station
between Hawaii and American Samoa by Pan
American Airways for flying boats in 1937 and 1938
(2000 est.)
Highways: much of the road and many causeways
built during World War I! are unserviceable and
overgrown (2001)
Waterways: none
Ports and harbors: West Lagoon
Airports: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m:^ {2000 est.)
Railways: 0 km
Highways:
total: 790 km
paved: 332 km
unpaved: 458 km (1996 est.)
Waterways: none
Ports and harbors: Apia, Asau, Mulifanua,
Salelologa
Airports: 3 (2000 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: ^ (2000 est.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2000 est.)','cf4dec9254dca654f04087e909213d6a9329db3ffbc0603d74a13addc9dcdf1f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ce668872bf628a30f9d15ce35e7460c799caad01fb112f24336ac87b53dc204',2001,'KG','Kyrgyzstan','transportation',676,'Railways:
total: 370 km in common carrier service; does not
include industrial lines
broad gauge: 370 km 1 .520-m gauge (1 990)
Highways:
total: 500 km (including 140 km of expressways)
paved: 16,854 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpavecf: 1,646 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1996)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or
Rybach''ye)
Airports: 50 (2000 est.)
Airports - with paved runways:
total: A
over 3,047 m:^
2,438 to 3,047 m‘A
1, 524 to 2,437 m:\\
9U to 1,523 m''A (2000 est.)
Airports - with unpaved runways:
total: 45
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 32 (2000 est.)
Railways: 0 km
Highways:
total: 14,000 km
paved: 3,360 km
unpaved: 640 km (1991)
Waterways: 4,587 km approximately
note: primarily Mekong and tributaries; 2,897
additional km are intermittently navigable by craft
drawing less than 0.5 m
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 2,370 GRT/
3,000 DWT
ships by type: cargo 1 (2000 est.)
Airports: 51 (2000 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m::
1,524 to 2,437 m: 5
914 to 1,523 m; 2 (2000 est.)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m::
914 to 1,523 m::7
under 914 m: 25 (2000 est.)','e09388988a020f185210ab8f5c232dfe5d4eae0c253f6c6ab7e6d3ad3a00279c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94520aeb3a088100b227cca3f81d59985debbc3adcb88e381fa2ed7b46d53bf6',2001,'LV','Latvia','transportation',685,'Railways:
total: 2,412 km
broad gauge: 2,379 km 1.520-m gauge (271 km
electrified) (1992)
narrow gauge: 33 km 0.750-m gauge (1994)
Highways;
total: 59,178 km
paved: 22,843 km
unpaved: 36,335 km (1998 est.)
Waterways: 300 km (perennially navigable)
Pipelines: crude oil 750 km; refined products 780
km; natural gas 560 km (1992)
Ports and harbors: Daugavpils, Liepaja, Riga,
Ventspils
Merchant marine;
total: 8 ships (1,000 GRT or over) totaling 27,984
GRT/29,978 DWT
ships by type: cargo 2, petroleum tanker 3,
refrigerated cargo 3 (2000 est.)
Airports: 25 (2000 est.)
Airports - with paved runways:
total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 4 (2000 est.)
Airports - with unpaved runways;
total: 12
2,438 to 3,047m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 7 (2000 est.)','eab3d4ff09007b9bd44853064bc04d9d94a99312ac64963f29c1c4f2be69d3ed','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c98f8daa031be2188371279c450f2628a0409a7367b7de4c926f88478ad54c98',2001,'LB','Lebanon','transportation',694,'Railways:
total: 399 km (mostly unusable because of damage in
civil war)
standard gauge: 31 7 km 1 .435-m
narrow gauge: S2 km (1999)
Highways:
total: 7,300 km
paved: 6,350 km
unpaved: 950 km (1999 est.)
Waterways: none
Pipelines: crude oil 72 km (none in operation)
Ports and harbors: Antilyas, Batroun, Beirut,
Chekka, El Mina, Ez Zahrani, Jbail, Jounie, Naqoura,
Sidon, Tripoli, Tyre
Merchant marine:
total: 71 ships (1 ,000 GRT or over) totaling 379,705
GRT/592,672 DWT
ships by type: bulk 1 0, cargo 42, chemical tanker 1 ,
combination bulk 1 , combination ore/oil 1 , container 4,
liquefied gas 1 , livestock carrier 5, refrigerated cargo
1 , roll on/roli off 2, vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Netherlands 1 , Syria 1
(2000 est.)
Airports: 8 (2000 est.)
Airports - with paved runways:
total: 5
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m:^
under 914 m:^ (2000 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m:^ (2000 est.)','1a5348211b623e26e2cae43d14abd90adf2aa4c8a0e6210a40c8efc26392144e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36b37a435268cd9a21649d511830d563f56553c7c70158bc362d4c868357028f',2001,'ZA','South Africa','transportation',701,'Railways:
total: 2.6 km; note - owned by, operated by, and
included in the statistics of South Africa
narrow gauge: 2.6 km 1 .067-m gauge (1 995)
Highways:
total: 4,955 km
paved: 887 km
unpaved: 4,033 km (1996)
Waterways: none
Ports and harbors: none
Airports: 29 (2000 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m:1
under 914 m; 2 (2000 est.)
Airports - with unpaved runways:
total: 25
914 to 1,523 m: 4
under 914 m: 21 (2000 est.)
291
Losotho (continued)
Railways:
total: 21 ,431 km
narrow gauge: 20,995 km 1 .067-m gauge (9,087 km
electrified); 436 km 0.61 0-m gauge (1995)
Highways:
fofa/; 534,1 31 km
paved: 63,027 km (including 2,032 km of
expressways)
unpa veof.'' 471,104 km (1998 est.)
Waterways: NA
Pipelines: crude oil 931 km; petroleum products
1 ,748 km; natural gas 322 km
Ports and harbors: Cape Town, Durban, East
London, Mosselbaai, Port Elizabeth, Richards Bay,
Saldanha
Merchant marine:
total: 8 ships (1 ,000 CRT or over) totaling 271 ,650
GRT/268,604 DWT
ships by type: container 6, petroleum tanker 2
(2000 est.)
Airports: 741 (2000 est.)
Airports - with paved runways:
total: 142
over 3,047 m: 9
2,438 to 3,047 m: 5
1,524 to 2,437 m: 41
914 to 1,523 m: 71
under 914 m: 10 (2000 est.)
Airports - with unpaved runways:
total: 599
1,524 to 2,437 m: 33
914 to 1,523 m: 304
under 914 m: 262 (2000 est.)
Waterways: none
Ports and harbors: Grytviken
Airports: none
Ports and harbors: McMurdo, Palmer, and offshore
anchorages in Antarctica
note: few ports or harbors exist on the southern side
of the Southern Ocean; ice conditions limit use of most
of them to short periods in midsummer; even then
some cannot be entered without icebreaker escort;
most antarctic ports are operated by government
research stations and, except in an emergency, are
not open to commercial or private vessels; vessels in
any port south of 60 degrees south are subject to
inspection by Antarctic Treaty observers
Transportation - note: Drake Passage offers
alternative to transit through the Panama Canal','c645bbe7b929e81334fd042679c86eb47e38e570368a77cfeb2fbc103a3e399d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('928a8fde1201b420464a91e6295225ac7ccded649aa912c33e98b097bdb50f0e',2001,'LR','Liberia','transportation',710,'Railways:
tofa/.*490 km (328 km single track); note - three rail
systems owned and operated by foreign steel and
financial interests in conjunction with the Liberian
Government; one of these, the Lamco Railroad,
closed in 1989 after iron ore production ceased; the
other two were shut down by the civil war; large
sections of the rail lines have been dismantled:
approximately 60 km of railroad track was exported for
scrap
standard gauge: 345 km 1 .435-m gauge
narrow gauge: US km 1 .067-m gauge
Highways:
total: 10,600 km
paved: 657 km
unpaved: 9,943 km
note: (there is major deterioration on all highways due
to heavy rains and lack of maintenance) (1996 est.)
Waterways: none
Ports and harbors: Buchanan, Greenville, Harper,
Monrovia
Merchant marine:
total: 1 ,478 ships (1 ,000 GRT or over) totaling
49,456,361 GRT/76,620,648 DWT
ships by type: barge carrier 3, bulk 324, cargo 97,
chemical tanker 163, combination bulk 20,
combination ore/oil 38, container 245, liquefied gas
97, multi-functional large-load carrier 4, passenger 24,
petroleum tanker 310, refrigerated cargo 74, roll on/
roll off 19, short-sea passenger 3, specialized tanker
12, vehicle carrier 45
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 8, Australia
1 , Ashmore and Cartier Islands 1 , Austria 5, Bermuda
5, Belgium 5, Burma 1 , Brazil 8, Canada 1 , China 28,
Chile 7, Costa Rica 8, Cyprus 27, Denmark 4,
Ecuador 1 , Germany 1 1 7, Greece 83, Hong Kong 54,
Croatia 9, Indonesia 2, India 8, Israel 1 , Italy 8, Japan
85, South Korea 8, Latvia 15, Monaco 28, Mexico 6,
Malaysia 1 , Nigeria 1 , Netherlands 7, Norway 86,
Netherlands Antilles 1 , NZ 1 , Poland 2, Portugal 2,
Philippines 1, Russia 22, Saudi Arabia 20, South
Africa 1, Slovenia 1, Singapore 30, Spain 1, Sweden
8, Switzerland 23, UAE 5, Taiwan 10, UK 15, US 85,
Uruguay 1, Vietnam 1 (2000 est.)
Airports: 46 (2000 est.)
Airports - with paved runways:
total: 2
over 3,047 m:^
1,524 to 2,437 m:U2000es\\.)
Airports ■ with unpaved runways:
total: 44
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 36 (2000 est.)','563b155dda8cc848a52f77500af0e1c1dfa67681d9d5c410ae4b808b1f360d8a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3521d3f43cfb30074f8413976c74180a3a85ea233814d3420c5933345914871',2001,'LY','Libya','transportation',718,'Railways:
note: Libya has had no railroad in operation since
1965, all previous systems having been dismantled;
current plans are to construct a 1 .435-m standard
gauge line from the Tunisian frontier to Tripoli and
Misratah, then inland to Sabha, center of a
mineral-rich area, but there has been little progress;
other plans made jointly with Egypt would establish a
rail line from As Sallum, Egypt, to Tobruk with
completion originally set for mid-1 994; Libya signed
contracts with two private companies - Bahne of
Egypt and Jez Sistemas Ferroviarios of Spain - in
1 998 for the supply of crossings and pointwork (1001)
Highways:
total: 24,484 km
paved: 6,800 km
unpaved: M fiS4 km (1996)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products
443 km (includes liquefied petroleum gas or LPG 256
km); natural gas 1,947 km
Ports and harbors: Al Khums, Banghazi, Darnah,
Marsa al Burayqah, Misratah, Ra''s Lanuf, Tobruk,
Tripoli, Zuwarah
Merchant marine:
total: 28 ships (1 ,000 GRT or over) totaling 399,725
GRT/654,843 DWT
ships by type: cargo 1 0, chemical tanker 1 , liquefied
gas 3, petroleum tanker 6, roll on/roll off 4, short-sea
passenger 4 (2000 est.)
Airports: 136 (2000 est.)
Airports - with paved runways:
total: 58
over 3,047 m: 23
2,438 to 3,047 m: 3
1,524 to 2,437 m: 22
914 to 1,523 m:b
under 914 m: 2 (2000 est.) ''
Airports - with unpaved runways:
total: 78
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m-A4
914 to 1,523 m: 40
under 914 m; 18 (2000 est.)','2326cea301935a2c6a53d8efb8147172b8b63fcfcfdc5eb39ed5ef1b6f50f78a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bde40dbdb242a4fa497eb01aad2d7afe87e06b22e5ece4f296e1de69d2260f1',2001,'LI','Liechtenstein','transportation',727,'Railways:
total: 18.5 km; note - owned, operated, and included
in statistics of Austrian Federal Railways
standard gauge: 18.5 km 1.435-m gauge (electrified)
Highways;
total: 250 km
paved: 250 km
unpaved: 0 km
Waterways: none
Ports and harbors: none
Airports: none','06efc335e63e0d675d35cee0397a323793c3981d2f63d8133833714532c2f09a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('819be00c1819d56318db832de1fa96d0d60d297c0018ed4c1d7b8654ad3bd7e8',2001,'CH','Switzerland','transportation',732,'Railways;
total: 2,002 km
broad gauge: 2,002 km 1 .524-m gauge (1 22 km
electrified) (1994)
Highways:
total: 44,000 km
paved: 35,500 km
unpaved: 8,500 km (2000)
Waterways: 600 km (perennially navigable)
Pipelines; crude oil, 105 km; natural gas 760 km
(1992)
Ports and harbors: Butinge, Kaunas, Klaipeda
Merchant marine:
total: 50 ships (1 ,000 GRT or over) totaling 293,168
GRT/327,827 DWT
300
Lithuania (continued)
ships by type: cargo 26, combination bulk 10,
petroleum tanker 2, railcar carrier 1, refrigerated cargo
7, roll on/roll off 1 , short-sea passenger 3 (2000 est.)
Airports: 72 (2000 est.)
Airports - with paved runways:
total: 9
over 3,047 m: 2
1,524 to 2, 437 m: 4
under 91 4 m: 3 (2000 est.)
Airports ■ with unpaved runways:
total: 63
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 55 (2000 est.)','a60da7fbd4c64c83e3ea1169c5d9995a368a9536b984b2e6595935f647b0e14e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e65bced5e493f7c2b92f978d99d31c4225623a6eb2e2c9ffe13fb9875dbe81b',2001,'MG','Madagascar','transportation',741,'Railways:
total: 883 km
narrow gauge: 883 km 1 .000-m gauge (1994)
Highways:
total: 49,337 km
pavecf; 5,781 km
unpaved: 44,056 km (1996)
Waterways:
note: of local importance only
Ports and harbors: Antsiranana,
Antsohimbondrona, Mahajanga, Toamasina, Toliara
Merchant marine:
total: :3 ships (1,000 GRT or over) totaling 24,819
GRT/34,173 DWT
ships by type: cargo 7, chemical tanker 1 , liquefied
gas 1 , petroleum tanker 2, roll on/roll off 2 (2000 est.)
309
Madagascar (continued)
Airports: 130 (2000 est.)
Airports - with paved runways:
total: 29
over 3,047 m: ‘I
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1.523 m: 19
under 914 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 101
1,524 to 2,437 m: 2
914 to 1,523 m: 56
under 91 4 m: 43 (2000 est.)','c5af1d819de2db4377f26873321715c6be199d25b54c32667c03b79109856f94','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b677a49cae5272a8592eedd984518b5f137ad6ae91074534b6faffeea356116',2001,'PH','Philippines','transportation',751,'Railways:
total: 789 km
narrow gauge: 789 km 1 .067-m gauge
Highways:
fofa/; 16,451 km
pavecf; 3,126 km
unpaved: 325 km (1997)
Waterways: 144 km
note: on Lake Nyasa (Lake Malawi) and Shire Riverall
Ports and harbors: Chipoka, Monkey Bay, Nkhata
Bay, Nkhotakota, Chilumba
Airports: 44(2000est.)
Airports - with paved runways:
total: 6
over 3,047 m: 1
1,524 to 2,437 m:^
914 to 1,523 m: 4 (2000 est.)
Airports - with unpaved runways:
total: 38
1,524 to 2,437 m:1
914 to 1,523 m: 14
under 914 m: 23 (2000 est.)
Railways:
total: km
narrow gauge: 1,801 km 1.000-m gauge (148 km
electrified) (2000)
Highways:
total: 64,672 km
paved: 48,707 km (including 1 ,192 km of
expressways)
unpaved: 15,965 km
note: in addition to these national and main regional
roads, Malaysia has thousands of kilometers of local
roads that are maintained by local jurisdictions (1999)
Waterways: 7,296 km
note: Peninsular Malaysia 3,209 km, Sabah 1 ,569 km,
Sarawak 2,518 km
Pipelines: crude oil 1 ,307 km; natural gas 379 km
Ports and harbors: Bintulu, Kota Kinabalu,
Kuantan, Kuching, Kudat, Labuan, Lahad Datu,
Lumut, Miri, Pasir Gudang, Penang, Port Dickson,
Port Kelang, Sandakan, Sibu, Tanjung Berhala,
Tanjung Kidurong, Tawau
Merchant marine:
total: 362 ships (1 ,000 GRT or over) totaling
5,103,657 GRT/7,574,999 DWT
ships by type: bulk 62, cargo 1 1 0, chemical tanker 35,
container 60, liquefied gas 20, livestock carrier 1,
passenger 2, petroleum tanker 58, refrigerated cargo
1 , roll on/roll off 6, specialized tanker 1 , vehicle carrier
6 (2000 est.)
Airports: 115 (2000 est.)
Airports ■ with paved runways:
total: 33
over 3,047 m: 5
2,438 to 3,047 m: A
1,524 to 2,437 m: 11
914 to 1,523 m: 8
under 914 m; 7 (2000 est.)
Airports - with unpaved runways:
total: 82
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 914 m:78 (2000 est.)
Heliports: 1 (2000 est.)
Waterways: none
Ports and harbors: small Chinese port facilities on
Woody Island and Duncan Island being expanded
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2000 est.)
Railways:
total: 492 km (an additional 405 km are not in
operation)
narrow gauge: A92 km 1.067-m gauge (1996)
Highways:
tote/; 199,950 km
paved; 39,590 km
unpaved: 160,360 km (1998 est.)
Waterways: 3,219 km
note: limited to vessels with a draft of less than 1 .5 m
Pipelines: petroleum products 357 km
Ports and harbors: Batangas, Cagayan de Oro,
Cebu, Davao, Guimaras Island, lligan, Iloilo, Jolo,
Legaspi, Manila, Masao, Puerto Princesa, San
Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 459 ships (1 ,000 GRT or over) totaling
5,653,062 GRT/8,512,326 DWT
ships by type: bulk 149, cargo 123, chemical tanker 4,
combination bulk 10, container 5, liquefied gas 13,
livestock carrier 10, passenger 4, passenger/cargo
12, petroleum tanker 42, refrigerated cargo 21 , roll on/
roll off 1 7, short-sea passenger 31 , specialized tanker
2, vehicle carrier 16
note: includes some foreign-owned ships registered
here as a flag of convenience: Cyprus 1 , Denmark 1 ,
Hong Kong 5, Japan 14, Netherlands 1, Singapore 1,
UK 1 (2000 est.)
Airports: 288 (2000 est.)
Airports - with paved runways:
total: 76
over 3,047 m: A
2,438 to 3,047 m:b
1,524 to 2,437 m: 26
914 to 1,523 m: 26
under 914 m:M (2000 est.)
Airports - with unpaved runways:
total: 212
2,438 to 3,047 m:1
1,524 to 2,437 m:1
91 4 to 1,523 m: 61
under 914 m: 129 (2000 est.)
Heliports: 1 (2000 est.)
Waterways; none
Ports and harbors: none; offshore anchorage only
Airports: 4 (2000 est.)
Airports - with paved runways:
total: 1
9/4 to f, 523 m;1 (2000 est.)
Airports - with unpaved runways:
total: 3
9/4to/,523m;1
under 914 m:2 (2000 est.)','096bd0d79a25be12557f4d5339ebe6336fbd37b477251a9974608e3adfda88ec','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2229fb5fc828bf5c96b92db8270606325478f5008cba7f98a14dc5b1d2ed3871',2001,'MV','Maldives','transportation',764,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km; note - Male has 9.6 km of coral
highways within the city (1988 est.)
Waterways: none
Ports and harbors: Gan, Male
Merchant marine;
total: 17 ships (1 ,000 GRT or over) totaling 58,604
GRT/81,451 DWT
ships by type: cargo 16, short-sea passenger 1
(2000 est.)
Airports: 5 (2000 est.)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m:^ (2000 est.)
316
Maldives (continued)
Airports ■ with unpaved runways:
total: 3
914 to 1,523 m: 3 {2000 est.)','ddd139174b57da040a17f7468c7c18b2198a77768c39c5dc83d05f5b5d213601','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ed473cb3eb1f1c2c43dd1e557d0d9edb15cfa6587c494a30b5328e98435215d',2001,'ML','Mali','transportation',772,'Military expenditures - dollar figure: $49 million
(FY96)
Military expenditures - percent of GDP: 2%
(FY96)','5169523f292fda1f60c8876fed6a9572ed304099242263c10d61336fc624a489','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a0be2b121e66af3c9ab60b2bdaac9018d7c35e7fe0e063874bc78ea17286d72',2001,'MT','Malta','transportation',780,'Railways: 0 km
Highways:
total: 7 42 km
paved: 1 ,677 km
unpaved: km (1997)
Waterways: none
Ports and harbors: Marsaxiokk, Valletta
Merchant marine:
total: 1 ,414 ships (1 ,000 GRT or over) totaling
28,191,090 GRT/46,773,603 DWT
ships by type: bulk 443, cargo 394, chemical tanker
48, combination bulk 12, combination ore/oil 14,
container 69, liquefied gas 2, livestock carrier 3,
multi-functional large-load carrier 2, passenger 7,
passenger/cargo 1 , petroleum tanker 296,
refrigerated cargo 37, roll on/roll off 50, short-sea
passenger 1 5, specialized tanker 3, vehicle carrier 1 8
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 1 , Bermuda
1 , Belgium 1 , Bangladesh 2, Bulgaria 1 1 , China 7,
Costa Rica 1 , Cuba 2, Cyprus 1 5, Denmark 1 , Estonia
2, Finland 1 , Germany 23, Greece 258, Hong Kong 3,
Croatia 9, Hungary 1 , India 2, Israel 2, Italy 17, South
Korea 1, Lebanon 2, Latvia 2, Lithuania 1, Monaco 14,
Nigeria 1, Netherlands 10, Norway 31, Poland 8,
Romania 3, Russia 39, Singapore 6, Spain 3, Sweden
3, Syria 1, Switzerland 25, UAE 2, Turkey 24, UK 8,
Ukraine 9, US 9, Venezuela 1 , Vietnam 1 (2000 est.)
Airports: 1 (2000 est.)
Airports ■ with paved runways:
total: 1
over 3,047 m-A (2000 est.)
Railways:
total: 68.5 km (43.5 km electrified)
Highways:
total: 800 km
paved: 800 km
unpaved: 0 km (1999)
Waterways: none
Ports and harbors: Castletown, Douglas, Peel,
Ramsey
Merchant marine:
total: W ships (1,000 GRT or over) totaling
4,917,402 GRT/8.333,858 DWT
ships by type: bulk 27, cargo 1 3, chemical tanker 1 1 ,
combination bulk 3, container 20, liquefied gas 13,
petroleum tanker 43, refrigerated cargo 3, roll on/roll
off 18, specialized tanker 1, vehicle carrier 5
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 1 , Denmark 1 ,
Germany 1, Netherlands 1, Sweden 1, UK 3
(2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways;
total: 1
1,524 to 2,437 m:) (2000 est.)','72ff07b96d5500f9e07da9f489174400ccf2a7dc564488a7a586f7ddb1c6ffd1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ec98da29cdca08504118eb3290b3d0d583dd3cf2cf4da6dde1b94a2155ded72',2001,'MH','Marshall Islands','transportation',788,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
324
Marshall Islands (continued)
note: paved roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or
laterite-surfaced roads and tracks
Waterways: none
Ports and harbors: Majuro
Merchant marine:
total: 21 2 ships (1 ,000 GRT or over) totaling
9,768,406 GRT/1 6, 242,699 DWT
ships by type: bulk 63, cargo 9, chemical tanker 1 0,
combination ore/oil 2, container 29, liquefied gas 10,
multi-functional large-load carrier 1, petroleum tanker
87, vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Cyprus 1 , Germany 1 ,
Japan 1, US 6 (2000 est.)
Airports: 16 (2000 est.)
Airports ■ with paved runways:
total: A
1,524 to 2,437 m: 3
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 12
914 to 1,523 m: 9
under 914 m; 3 (2000 est.)','9dc6c4186d8e21062a1a8dc9a17fe60af2d525caacb7cf5642ecbccaea72b046','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('825edc2fea60175aa045d66da892d5489be0f99c984f3dc2ef6dd0abb4efca66',2001,'MR','Mauritania','transportation',800,'Railways:
tofa/.-750 km (single track); note - owned and
operated by government mining company
standard gauge: 7b0 km 1.435-m gauge (1995)
Highways:
total: 7,660 km
paved: 866 km
unpaved: 6,794 km (1996)
Waterways:
note: ferry traffic on the Senegal River
Ports and harbors: Bogue, Kaedi, Nouadhibou,
Nouakchott, Rosso
Merchant marine: none (2000 est.)
Airports: 26 (2000 est.)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5 {2000 est.)
Airports - with unpaved runways:
total: ^6
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m: 3 (2000 est.)','1e5fb7edb36c8e3721a79e512c373233377e55753684d470b4383de67e5c4573','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a305398601d89f2b19130010aa77240e424aea6f65cecd9731e46be0c634f21e',2001,'MU','Mauritius','transportation',809,'Railways: 0 km
Highways:
fofa/; 1,910 km
paved; 1,834 km (including 36 km of expressways)
unpaved: 78 km (1998)
Waterways: none
Ports and harbors: Port Louis
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 61 ,909
GRT/87,313 DWT
ships by type: cargo 2, combination bulk 2, container
2, liquefied gas 1, refrigerated cargo 2
note: includes a foreign-owned ship registered here
as a flag of convenience: India 1 (2000 est.)
Airports: 5 (2000 est.)
Airports - with paved runways:
total: 2
over 3,047 m:1
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 914 m; 2 (2000 est.)','030c4221a3928d2231e201003aabfb653e6b1ed5174241d64c7e013dd18b4d45','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('772b8df67e522fd13d1c371974e1d1fdfec461d22fbf06691e5fe5bcb34436f2',2001,'YT','Mayotte','transportation',818,'Railways: 0 km
Highways;
total: 93 km
paved: 72 km
unpaved: 21 km
Waterways: none
Ports and harbors: Dzaoudzi
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:^ (2000 est.)','de7ecbb68963bb5b2101fc1d3215838a156dad8bd495c296c213fbefd8d9d25c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b14679017bb13c963cb9f9522efe74864d7ffac8a13a924940076183a5ffa5ef',2001,'US','United States','transportation',828,'Railways:
total: 31 ,048 km
standard gauge: 30,958 km 1 .435-m gauge (246 km
electrified)
narrow gauge: 90 km 0.91 4-m gauge (1998 est.)
Highways:
total: 323,977 km
paved: 96,221 km (including 6,335 km of
expressways)
unpaved: 227,756 km (1997)
Waterways: 2,900 km
note: navigable rivers and coastal canals
Pipelines: crude oil 28,200 km; petroleum products
10,150 km; natural gas 13,254 km; petrochemical
1,400 km
Ports and harbors: Acapulco, Altamira,
Coatzacoalcos, Ensenada, Guaymas, La Paz, Lazaro
Cardenas, Manzanillo, Mazatlan, Progreso, Salina
Cruz, Tampico, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 43 ships (1 ,000 GRT or over) totaling 590,657
GRT/920,456 DWT
ships by type: bulk 2, cargo 1 , chemical tanker 4,
liquefied gas 3, petroleum tanker 28, roll on/roll off 2,
short-sea passenger 3 (2000 est.)
Airports: 1 ,848 (2000 est.)
Airports - with paved runways:
total: 238
over 3,047 m:M
2,438 to 3,047 m: 26
1,524 to 2,437 m: 90
914 to 1,523 m: 62
under 91 4 m: 27 (2000 est.)
Airports - with unpaved runways:
total: 1,610
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m: 65
914 to 1,523 m: 470
under 914 m: 1,073 (2000 est.)
Heliports: 2 (2000 est.)
335
Mexico (continued)
Railways:
total: 240,000 km mainline routes (nongovernment
owned)
standard gauge: 240,000 km 1.435-m gauge (1989)
Highways:
tofa/.'' 6,348,227 km
paved: 3,732,757 km (including 88,727 km of
expressways)
unpaved.- 2,61 5,470 km (1997 est.)
Waterways: 41,009 km
note: navigable inland channels, exclusive of the
Great Lakes
Pipelines: petroleum products 276,000 km; natural
gas 331,000 km (1991)
532
United States (continued)
Ports and harbors: Anchorage, Baltimore, Boston,
Charleston, Chicago, Duluth, Hampton Roads,
Honolulu, Houston, Jacksonville, Los Angeles, New
Orleans, New York, Philadelphia, Port Canaveral,
Portland (Oregon), Prudhoe Bay, San Francisco,
Savannah, Seattle, Tampa, Toledo
Merchant marine:
total: 376 ships (1 ,000 CRT or over) totaling
10,814,622 GRT/14,416,517DWT
ships by type: barge carrier 9, bulk 68, cargo 29,
chemical tanker 1 3, combination bulk 3, container 80,
liquefied gas 1, multi-functional large-load carrier 3,
passenger 9, passenger/cargo 1 , petroleum tanker
98, roll on/roll off 49, short-sea passenger 3,
specialized tanker 1 , vehicle carrier 9 (2000 est.)
Airports: 14,720 (2000 est.)
Airports - with paved runways:
fofa/: 5,174
over 3,047 m: ]S2
2,438 to 3,047 m: 220
1,524 to 2,437 m:^, 33^
914 to 1,523 m: 2, 440
under 914 m: 1,001 (2000 est.)
Airports - with unpaved runways:
total: 9,546
over 3,047 m: 3
2,438 to 3,047 m:0
1,524 to 2,437 m: 104
914to1,523m:im
under 914 m: 7, 698 (2000 est.)
Heliports: 131 (2000 est.)','560a637e9a561502256bdccd6ad9ec478cbd0aea960e1b62f2158031a0df3308','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8399d27698c1447c377429c07d2c3d4e26d0e16ce3c15a40c74156a7861de40e',2001,'MC','Monaco','transportation',836,'Railways:
total: 1 .7 km
standard gauge: 1 .7 km 1 .435-m gauge
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: Monaco
Merchant marine: none (2000 est.)
Airports: linked to airport in Nice, France, by
helicopter service
Heliports: 1 (shuttle service between the
international airport at Nice, France, and Monaco''s
heliport at Fontvieille)','f17c03b9965a5ab4200c83b75d7449ba97e5bd74ed9e9c60e572cb5930f3a1c1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70a4099a05e449cd681cbb3d8f2a3242192f8bd7cfce1bd3689071170ffd2ef2',2001,'MS','Montserrat','transportation',843,'Railways: 0 km
Highways:
total: 269 km
paved: 203 km
unpaved: % km (1995)
Waterways: none
Ports and harbors: Plymouth (abandoned). Little
Bay (anchorages and ferry landing), Carr''s Bay
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
under 914 m:^ (2000 est.)','6eddb9995f4c5c5582bef6eba09a856a1b9239ed2b2ed5b4eccb2cd10f4eed11','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b1bd61f1e4390983d170f36cdd989a36ab8fea71940516f4beb51e27d481e06',2001,'NA','Namibia','transportation',853,'Railways:
total: 2,382 km
narrow gauge: 2,382 km 1 .067-m gauge; single track
(1995)
Highways:
total: 63,258 km
paved: 5,250 km
unpaved: 88,008 km (1997 est.)
Waterways: none
Ports and harbors: Luderitz, Walvis Bay
Merchant marine: none (2000 est.)
Airports: 131 (2000 est.)
Airports - with paved runways:
total: 21
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m’A3
914 to 1,523 m: 4 (2000 est.)
Airports - with unpaved runways:
total: MO
2,438 to 3,047m: 2
1,524 to 2,437 m: 21
914 to 1,523 m: 89
under 914 m: 18 (2000 est.)','43e10cf0c6ba7f507070ff4e92249ef97e5036c4c2720244d03898accf47993f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e3d4e5fa4d740f6b282ff512f98508a5b573e47054a692fdf48c6369939f9b6',2001,'NR','Nauru','transportation',860,'355
Nauru (continued)
Unemployment rate: 0%
Budget:
revenues: $23.4 million
expenditures: $64.8 million, including capital
expenditures of $NA (FY95/96)
Industries: phosphate mining, financial services,
coconut products
Industrial production growth rate: NA%
Electricity - production: 30 million kWh (1999)
Electricity - production by source:
foss/7 fue/; 100%
hydro: 0%
nuclear: 0%
other: 0%(^999)
Electricity - consumption: 27.9 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: coconuts
Exports: $25.3 million (f.o.b., 1991)
Exports - commodities: phosphates
Exports - partners: Australia, NZ
Imports: $21.1 million (c.i.f., 1991)
Imports - commodities: food, fuel, manufactures,
building materials, machinery
Imports - partners: Australia, UK, NZ, Japan
Debt - external: $33.3 million
Economic aid - recipient: $2.25 million from
Australia (FY96/97est.)
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates: Australian dollars per US dollar -
1 .7995 (January 2001 ), 1 .71 73 (2000), 1 .5497 (1 999),
1.5888 (1998), 1.3439 (1997), 1.2773 (1996)
Fiscal year: 1 July - 30 June
Railways:
total: 5 km; note - used to haul phosphates from the
center of the island to processing facilities on the
southwest coast
Highways:
total: 30 km
paved: 24 km
unpaved: 6 km (^99S est.)
Waterways: none
Ports and harbors: Nauru
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:U2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only','7a5ab2ee439e39e03a72560d9ee109a8334f2c6835c5be27dec44cfaa9b034d8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be58acb1bf2530f0519ee2ac768dab07c66e89e29dbe02ffb63657ddbc2529b3',2001,'NP','Nepal','transportation',869,'Railways:
total: 59 km; note - all in Kosi close to Indian border
narrow gauge: 59 km 0.762-m gauge (2000)
Highways:
total: 13,223 km
paved; 4,073 km
L/npavecf; 9,1 50 km (April 1999)
Waterways: none
Ports and harbors: none
Airports: 45 (2000 est.)
Airports - with paved runways:
total: 8
over 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m: 3(2000 est.)
Airports - with unpaved runways:
total: 37
1,524 to 2,437 m:1
914 to 1,523 m:7
under 914 m: 29 (2000 est.)','828883bd4052d1edf797113c2d7a03c6a09bbc9416956f565ff824fbe7b5e49a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ade1a6014c0786546a5dc06d163b9686fc885da4e8f813b56be8c14c255e6dd3',2001,'NL','Netherlands','transportation',878,'Railways: 0 km
Highways:
total: 600 km
paved: 300 km
unpaved: 300 km (1992)
Waterways: none
Ports and harbors: Kralendijk, Philipsburg,
Willemstad
Merchant marine:
total: 1 23 ships (1 ,000 GRT or over) totaling
1,113,774 GRT/1, 397, 841 DWT
ships by type: bulk 1 , cargo 35, chemical tanker 2,
combination ore/oil 3, container 19, liquefied gas 4,
multi-functional large-load carrier 19, passenger 1,
petroleum tanker 4, refrigerated cargo 28, roll on/roll
off 7
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 8, Germany 1 ,
Italy 1 (2000 est.)
Airports: 5 (2000 est.)
Airports - with paved runways:
total: 5
over 3,047 m:^
1,524 to 2,437 m: 2
914 to 1,523 m:1
under 914 m: 1 (2000 est.)','1122dc362788e525e1175669fa1ff61d5c6c56f55c9a95ff1ec79dddcb8276ff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee90e37713200225b44c9de7ee56d92e19518e824e5117928398327aee7591dc',2001,'NZ','New Zealand','transportation',887,'Railways:
total: 3,913 km
narrow gauge; 3,913 km 1.067-m gauge (519 km
electrified) (1999)
Highways:
total: 92,200 km
paved: 53,568 km (including at least 144 km of
expressways)
unpaved: 38,632 km (1 996)
Waterways: 1,609 km
note: of little importance in satisfying total
transportation requirements
Pipelines: petroleum products 160 km; natural gas
1,000 km; liquefied petroleum gas or LPG 150 km
Ports and harbors: Auckland, Christchurch,
Dunedin, Tauranga, Wellington
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 72,389
GRT/109,018DWT
ships by type: bulk 3, cargo 1 , container 1 , petroleum
tanker 2, railcar carrier 1, roll on/roll off 1 (2000 est.)
Airports: 1 1 1 (2000 est.)
Airports ■ with paved runways:
total: 44
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 67
1,524 to 2,437 m:1
914 to 1,523 m: 24
under 914 m:42 (2000 est.)
368
New Zealand (continued)
Railways: 0 km
Highways:
total: 680 km
paved; 184 km
unpaved: 496 km (1996 est.)
Waterways: none
Ports and harbors: Neiafu, Nuku''alofa, Pangai
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 20,626
GRT/29,468 DWT
ships by type: bulk 1 , cargo 2, liquefied gas 3,
petroleum tanker 1, roll on/roll off 1 (2000 est.)
^rports: 6 (2000 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (2000 est.)
Airports - with unpaved runways:
total: 5
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m: 2 (2000 est.)
Railways: minimal agricultural railroad system near
San Fernando; railway service was discontinued in
1968
Highways:
total: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (1996 est.)
Waterways: none
Pipelines: crude oil 1,032 km; petroleum products
19 km; natural gas 904 km
Ports and harbors: Pointe-a-Pierre, Point Fortin,
Point Lisas, Port-of-Spain, Scarborough, Tembladora
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 2,439 GRT/
4,040 DWT
ships by type: cargo 1 , petroleum tanker 1 (2000 est.)
Airports: 6 (2000 est.)
Airports - with paved runways:
total: 3
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m:^ (2000 est.)
Airports ■ with unpaved runways:
total: 3
914 to 1,523 m:^
under 914 m: 2 (2000 est.)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2000 est.)
Airports - with unpaved runways:
total: 1
under 914 m:^ (2000 est.)
Railways: 0 km
Highways:
total: 120 km (lie Uvea 100 km, He Futuna 20 km)
paved: 16 km (all on He Uvea)
unpaved: 104 km (He Uvea 84 km, He Futuna 20 km)
Waterways: none
Ports and harbors: Leava, Mata-Utu
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 48,853
GRT/43,128 DWT
ships by type: passenger 3, petroleum tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: France 1 (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2000 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2000 est.)','aaf39aae8f6e69aa48eb173168b43edf99fa0bcec3cf07bfd9d5af39485ce791','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e345edd4848ba62e0357619f6077574723b4b40a68e65e01d62efade8ffe65',2001,'NI','Nicaragua','transportation',891,'Highways:
tofa/; 16,382 km
paved; 1,818 km
unpaved: 14,564 km (1998)
Waterways: 2,220 km (including 2 large lakes)
Pipelines: crude oil 56 km
Ports and harbors: Bluefields, Corinto, El Bluff,
Puerto Cabezas, Puerto Sandino, Rama, San Juan
del Sur
Merchant marine: none (2000 est.)
Airports: 182 (2000 est.)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m; 3 (2000 est.)
Airports - with unpaved runways:
tofa/;171
1,524 to 2,437 m:1
914 to 1,523 m: 25
under 914 m: 145 (2000 est.)','d2e12e1420fe013b8b8a25b1f17b69495edc846022551f063353870c8255b66c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b1906c2b3fb93569908f8e511212bd520e40657143f5afcad8df3c9ae32a309',2001,'NE','Niger','transportation',899,'Railways: 0 km
Highways:
total: 10, m km
paved: 798 km
unpaved: 0,302 km (1996)
Waterways: 300 km
note: the Niger River is navigable from Niamey to
Gaya on the Benin frontier from mid-December
through March
Ports and harbors: none
Airports: 27 (2000 est.)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m:0
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 18
1,524 to 2,437 m:1
914 to 1,523 m: 15
under 91 4 m: 2 {2000 est.)
Railways:
total. 3,557 km
narrow gauge. 3,505 km 1.067-m gauge
standard gauge. 52 km 1.435-m gauge
note, years of neglect of both the rolling stock and the
right-of-way have seriously reduced the capacity and
utility of the system; a project to restore Nigeria''s
railways is now underway
Highways.
total. 194,394 km
paved. 60,068 km (including 1,194 km of
expressways)
unpaved. 134,326 km
note, many of the roads reported as paved may be
graveled; because of poor maintenance and years of
heavy freight traffic - in part the result of the failure of
the railroad system - most of the road system is barely
usable (1997)
Waterways. 8,575 km
note, consisting of the Niger and Benue rivers and
smaller rivers and creeks
Pipelines, crude oil 2,042 km; petroleum products
3,000 km; natural gas 500 km
375
Nigeria (continued)
Ports and harbors: Calabar, Lagos, Onne, Port
Harcourt, Sapele, Warri
Merchant marine:
total: 41 ships (1 ,000 GRT or over) totaling 357,372
GRT/636,254 DWT
ships by type: bulk 1 , cargo 10, chemical tanker 4,
petroleum tanker 24, roll on/roll off 1 , specialized
tanker 1 (2000 est.)
Airports: 70 (2000 est.)
Airports - with paved runways:
total: %
over 3,047 m: 7
2,438 to 3,047 m:^Q
1,524 to 2,437 m''AO
914 to 1,523 m: 7
under 914 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 34
1,524 to 2,437 m: 2
914 to 1,523 m:U
under 914 m: 18 (2000 est.)
Heliports: 1 (2000 est.)','1f138e07d3be4d09b841707a4aa2bb1f0b2108bfdca5d15be02911813f98383a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79c150438df0197f7687efcb7651b8c4b94d81c921541c598083fe9ff5be39e3',2001,'MP','Northern Mariana Islands','transportation',910,'Airports - with unpaved runways:
total: 3
2,438 to 3,047 m:1
under 914 m; 2 (2000 est.)
Heliports: 1 (2000 est.)
Waterways: none
Ports and harbors: none; two offshore anchorages
for large ships
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (2000 est.)
547
Wake Island (continued)
Transportation ■ note: formerly an important
commercial aviation base, now used by US military,
some commercial cargo planes, and for emergency
landings','4b52afb1f111d9b2a2498c6e496291f9761c1022c6c013f5a92c800bec756c1c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b46a35b92f478b4e99d1c49a74341509c6abacd47b9acb68931cbaf66f0d871d',2001,'PA','Panama','transportation',919,'Railways:
total: 355 km
broad gauge: 76 km 1.524-m gauge
narrow gauge: 279 km 0.91 4-m gauge
Highways:
total: 11,592 km
paved: A, 079 km (including 30 km of expressways)
unpaved: 7,513 km (2000)
Waterways: 882 km
note: 800 km navigable by shallow draft vessels; 82
km Panama Canal
Pipelines: crude oil 130 km (2001)
Ports and harbors: Balboa, Cristobal, Coco Solo,
Manzanillo (part of Colon area), Vacamonte
Merchant marine;
total: 4,71 1 ships (1 ,000 GRT or over) totaling
1 1 1 ,51 5,984 GRT/1 69,655,363 DWT
ships by type: bulk 1 ,381 , cargo 925, chemical tanker
314, combination bulk 71, combination ore/oil 18,
container 525, liquefied gas 193, livestock carrier 5,
multi-functional large-load carrier 12, passenger 41,
passenger/cargo 4, petroleum tanker 544, railcar
carrier 2, refrigerated cargo 297, roll on/roll off 106,
short-sea passenger 36, specialized tanker 29,
vehicle carrier 208
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 1 1 , Australia
1 , Austria 1 , Bermuda 21 , Belgium 4, The Bahamas 7,
Brazil 2, Canada 4, China 154, Chile 4, Cayman
Islands 1 , Colombia 6, Cuba 7, Cyprus 4, Denmark 1 2,
Egypt 8, Ireland 2, Equatorial Guinea 1, Finland 1,
France 4, Germany 17, Greece 248, Hong Kong 158,
Honduras 2, Croatia 3, Indonesia 40, India 1 1 , Iran 1 ,
Israel 3, Italy 7, Japan 1 ,007, Jordan 2, South Korea
223, Latvia 4, Lithuania 1 , Liberia 2, Monaco 43, Malta
1 , Mexico 5, Malaysia 6, Netherlands 6, Norway 36,
Netherlands Antilles 1, Peru 5, Pakistan 1 , Portugal 5,
Philippines 10, Russia 6, Saudi Arabia 6, Seychelles 2,
South Africa 5, Singapore 73, Spain 35, Sweden 4,
Syria 1 1 , Switzerland 53, UAE 1 1 , Thailand 1 5, Taiwan
1 70, UK 18, US 79, Venezuela 18, Samoa 1 (2000 est.)
Airports: 107 (2000 est.)
Airports - with paved runways:
total: 42
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m:22 (2000 est.)
Airports - with unpaved runways:
total: 65
914 to 1,523 m: 13
under 914 m: 52 (2000 est.)','a3ba2b2d1167213160af0252c1a1b475004525f8726e7d2fb557d5e64eeb8a55','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc7fd47e0c3cd8a576780c7dfd3dad1499e27ee3fa3a5409eeebd59b39ddec0d',2001,'AR','Argentina','transportation',924,'Railways:
total: 971 km
standard gauge: 441 km 1 .435-m gauge
narrow gauge: 50 km 1.000-m gauge
note: there are 470 km of various gauges that are
privately owned
Highways;
total: 25,901 km
paved: 3,067 km
unpaved: 22,834 km (2001)
Waterways: 3,100 km
Ports and harbors: Asuncion, Villeta, San Antonio,
Encarnacion
Merchant marine;
total: 20 ships (1 ,000 GRT or over) totaling 31 ,066
GRT/35,441 DWT
399
Paraguay (continued)
ships by type: cargo 14, chemical tanker 1 , petroleum
tanker 3, roll on/roll off 2 (2000 est.)
Airports: 915 (2000 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 4 {2000 est.)
Airports - with unpaved runways:
total: 904
1,524 to 2,437 m: 29
91 4 to 1,523 m: 340
under 914 m: 535 (2000 est.)','e2bc50b0f2d2bece56a10808fa0e58c1a8719250967097b8bb408540f9f32b9d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e548fc86be70e47a9ee1c1fe9f3923322750439c159fadb96d331b76e297e98',2001,'PN','Pitcairn','transportation',932,'Railways: 0 km
Highways:
total: 6.4 km
paved: 0 km
unpaved: 6.4 km
Waterways: none
Ports and harbors: Bounty Bay
Merchant marine: none (2000 est.)
Airports: none
406
Pitcairn islands (continued)','d9a819fd7a63669969d43aeffb28a1afc73d1c89fe4a2728306fb07a6b7adefd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c498a4142d7979f78a7ed65248dff4adaf29a68214181c9402bafc477adde5e6',2001,'MX','Mexico','transportation',940,'Railways:
total: 23,420 km
broad gauge: 646 km 1 .524-m gauge
standard gauge: 21 ,639 km 1 .435-m gauge (1 1 ,626
km electrified; 8,978 km double track)
narrow gauge: 1 ,^35 km various gauges including
1.000-m, 0.785-m, 0.750-m, and 0.600-m (1998)
Highways:
tofa/.'' 381,046 km
paved: 249,966 km (including 268 km of
expressways)
unpaved: 1 31 ,080 km (1 998)
Waterways: 3,812 km (navigable rivers and canals)
(1996)
Pipelines: crude oil and petroleum products 2,280
km; natural gas 17,000 km (1996)
Ports and harbors: Gdansk, Gdynia, Giiwice,
Kolobrzeg, Szczecin, Swinoujscie, Ustka, Warsaw,
Wroclaw
Merchant marine:
total: A6 ships (1,000 GRT or over) totaling 943,540
GRT/1 ,532,694 DWT
ships by type: bulk 41 , cargo 2, chemical tanker 1 , roll
on/roll off 1, short-sea passenger 1 (2000 est.)
Airports: 122 (2000 est.)
Airports - with paved runways:
total: 83
over 3,047 m: 3
2,438 to 3,047 m: 29
1,524 to 2,437 m: 42
914 to 1,523 m: 6
under 914 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 39
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m:^3
under 914 m: 21 (2000 est.)
Heliports: 3 (2000 est.)','5e38d138eab53f5697eb82afec5455434634989df3320290174008ce3c26422e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c475f46821d2034d559f78f2b573f4ab3eb912951260b871b2fbc17500f7605',2001,'QA','Qatar','transportation',953,'Railways: 0 km
Highways:
total: 1 ,230 km
paved; 1,107 km
unpaved: 123 km (1996 est.)
Waterways: none
Pipelines: crude oil 235 km; natural gas 400 km
Ports and harbors: Doha, Halul Island, Umm Sa''id
(Musay''id)
Merchant marine:
total: 25 ships (1 ,000 GRT or over) totaling 677,992
GRT/1 ,049,447 DWT
ships by type: cargo 10, combination ore/oil 2,
container 7, petroleum tanker 6 (2000 est.)
Airports: 4 (2000 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 2 {2000 est.)
Airports ■ with unpaved runways:
total: 2
914 to 1,523 m:1
under 914 m:1 (2000 est.)
Heliports: 1 (2000 est.)','bf7c6bb9819279f20a6e31c80c440e0e624e467c70d44b7ccbaba76f7ab3851e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c13fa4385bec55c90e5ce128ea64a185344fada57310f767b849f59cfce225be',2001,'UA','Ukraine','transportation',962,'Railways:
total: 1 1 ,385 km (3,888 km electrified)
standard gauge: 10,898 km
narrow gauge: 487 km (1996)
Highways:
fofa/; 153,359 km
paved: 103,671 km (including 133 km of
expressways)
unpaved: 49, QQS km (1998 est.)
Waterways: 1 ,724 km (1 984)
Pipelines: crude oil 2,800 km; petroleum products
1,429 km; natural gas 6,400 km (1992)
Ports and harbors: Braila, Constanta, Galati,
Mangalia, Sulina, Tulcea
Merchant marine:
total: 95 ships (1 ,000 GRT or over) totaling 695,227
GRT/931,598 DWT
ships by type: bulk 1 0, cargo 71 , container 1 ,
passenger 1 , passenger/cargo 1 , petroleum tanker 4,
railcar carrier 2, roll on/roll off 4, specialized tanker 1
(2000 est.)
Airports: 62 (2000 est.)
Airports - with paved runways:
total: 25
over 3,047 m: 3
2,438 to 3,047 m''AO
1,524to2,437m‘A2[2m est.)
Airports - with unpaved runways:
total: 37
1,524 to 2,437 m: 2
91 4 to 1,523 m: 12
under 91 4 m: 23 (2000 est.)
Heliports: 1 (2000 est.)
Railways:
total: 149,000 km
note: 86,000 km are in common carrier service;
63,000 km serve specific industries and are not
available for common carrier use; 40,000 km of the
railway in common carrier use are electrified
broad gauge: 149,000 km 1.520-m gauge (1998)
Highways:
total: 952,000 km
paved; 752,000 km (including, in addition to about
336,000 km of conventionally paved roads, about
416,000 km of roads, the surfaces of which have been
stabilized with gravel or other coarse aggregates,
making them trafficabie in wet weather)
unpaved: 200,000 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1998)
Waterways: 95,900 km (total routes in general use)
note: routes with navigation guides serving the
Russian River Fleet-95,900 km; routes with night
navigational aids-60,400 km; man-made navigable
routes-1 6,900 km (Jan 1994)
Pipelines: crude oil 48,000 km; petroleum products
15,000 km; natural gas 140,000 km (June 1993 est.)
Ports and harbors: Arkhangel''sk, Astrakhan'',
Kaliningrad, Kazan'', Khabarovsk, Kholmsk,
Krasnoyarsk, Moscow, Murmansk, Nakhodka,
Nevel''sk, Novorossiysk, Petropavlovsk-Kamchatskiy,
Saint Petersburg, Rostov, Sochi, Tuapse,
Vladivostok, Volgograd, Vostochnyy, Vyborg
Merchant marine:
total: 878 ships (1 ,000 GRT or over) totaling
4,314,485 GRT/5,344,958 DWT
ships by type: barge carrier 1 , bulk 20, cargo 543,
chemical tanker 4, combination bulk 21 , combination
ore/oil 7, container 31 , multi-functional large-load
carrier 1 , passenger 35, passenger/cargo 3,
petroleum tanker 164, refrigerated cargo 24, roll on/
roll off 17, short-sea passenger 7
note; includes a foreign-owned ship registered here
as a flag of convenience: Reunion 1 (2000 est.)
Airports: 2,743 (2000 est.)
Airports - with paved runways:
total: 471
over 3,047 m: b6
2,438 to 3,047 m: MS
1,524 to 2,437 m: 76
914 to 1,523 m: 69
under 914 m: 92 (2000 est.)
Airports ■ with unpaved runways:
total: 2,272
over 3,047 m: 26
2,438 to 3,047 m: m
1,524 to 2,437 m: 204
914 to 1,523 m: 324
under 914 m: 1 ,598 (2000 est.)
Railways: 0 km
Highways:
total: 12,000 km
paved: 1 ,000 km
unpaved: 1 1 ,000 km (1 997 est.)
Waterways:
note: Lac Kivu navigable by shallow-draft barges and
native craft
Ports and harbors: Cyangugu, Gisenyi, Kibuye
Airports: 8 (2000 est.)
Airports - with paved runways:
total: 4
over 3,047 m:^
914 to 1523 m: 2
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 4
914 to 1,523 m:1
under 914 m: 3 (2000 est.)
Railways: 0 km
Highways:
total: NA km (Saint Helena 1 1 8 km, Ascension NA km,
Tristan da Cunha NA km)
paved: 180.7 km (Saint Helena 100 km. Ascension
480 km, Tristan da Cunha 2.70 km)
unpaved: NA km (Saint Helena 20 km. Ascension NA
km, Tristan da Cunha NA km)
Waterways: none
Ports and harbors: Georgetown (on Ascension),
Jamestown
Merchant marine: none (2000 est.)
Airports: 1 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)','8b281cffd162a297af5dab5242fc561cd85306d202f167237c81022dd5642bbd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88d59d16377210d024bfa85aef5f87fb0c9199b80de04819fed2ca206ff4d5b0',2001,'TT','Trinidad and Tobago','transportation',971,'Railways:
total: 58 km
narrow gauge: 58 km 0.762-m gauge on Saint Kitts to
serve sugarcane plantations (1995)
Highways:
total: 320 km
paved; 136 km
unpaved; 184 km (1996 est.)
Waterways: none
Ports and harbors: Basseterre, Charlestown
Merchant marine: none (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 2
1524 to 2,437 m:1
914 to 1,523 m:1 (2000 est.)','b10f81e6fb45402e60dd50dc9e839de45953e595ed2ad118303db900d9fc0b5c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c78061e491dbb67ee65e5d5687d098594b1fb7316d3bfe58b0bda40a2db59f3e',2001,'MQ','Martinique','transportation',977,'Railways: 0 km
Highways:
total: 1,210 km
paved: 63 km
unpaved: 1 ,147 km (1996 est.)
Waterways: none
Ports and harbors: Castries, Vieux Fort
Merchant marine: none (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
1,524 to 2,437 m:1 (2000 est.)
Railways: 0 km
Highways:
total: 1 14 km
paved: 69 km
unpaved: 45 km (1 994 est.)
Waterways: none
Ports and harbors: Saint Pierre
Merchant marine: none (2000 est.)
Airports: 2 (2000 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m:1 (2000 esl)','8e92960f91a2ff0071698615a48cbe99c399e39b45ff3c891bb4eb7520795e86','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12e641e2fc26f1c0bd7d1ce8eccd3b4f34ba9e359a0879b8cbfdf8d0efdac969',2001,'SC','Seychelles','transportation',995,'Railways: 0 km
Highways:
total: 280 km
paved: 176 km
unpaved: 104 km (1996 est.)
Waterways: none
Ports and harbors: Victoria
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 5,353 GRT/
7,638 DWT
ships by type: cargo 1 (2000 est.)
Airports: 14 (2000 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m:^
914 to 1,523 m: 3
under 91 4 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 8
914 to 1,523 m: 4
under 914 m: 4 (2000 est.)','c185ae7931cc08a7cc988218425da4ee60d5c54d1938792923661e261852fd0c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214a25e62e2ea1c7e10e0edfb9cd6f1bed8ecb635d8af17ca3a4616d6bfa1c6e',2001,'SL','Sierra Leone','transportation',1003,'Railways:
total: 84 km used on a limited basis because the mine
at Marampa is closed
narrow gauge: 84 km 1.067-m gauge
Highways:
total: 11,300 km
paved: 904 km
unpaved: 10,3% km (1999 est.)
Waterways: 800 km (of which 600 km navigable
year round)
Ports and harbors: Bonthe, Freetown, Pepel
Merchant marine;
total: 1 ship (1 ,000 GRT or over) totaling 2,057 GRT/
3,498 DWT
ships by type: cargo 1 (2000 est.)
Airports: 11 (2000 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 10
914 to 1,523 m: 7
under 914 m: 3 (2000 est.)
Heliports: 1 (2000 est.)','d173ad6ba6fc5d3e6c9c54e35b52a6c89d70e33fd340f3bab31940c9c58aab44','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('480135bad8b3f0eb14744bf4c535364ba8a8f027948a317a23c7ea2aadc1df93',2001,'HU','Hungary','transportation',1011,'Railways:
total: 3,660 km
broad gauge: 1 02 km 1 .520-m gauge
standard gauge: 3,507 km 1 .435-m gauge (1 ,505 km
electrified; 1,01 1 km double track)
narrovi/ gauge: 51 km (46 km 1 ,000-m gauge; 5 km
0.750-m gauge) (1998)
Highways:
/ote/; 17,710 km
paved: 17,533 km (including 288 km of expressways)
unpaved: 177 km (1998 est.)
Waterways: 172 km (all on the Danube)
Pipelines: petroleum products NA km; natural gas
2,700 km
Ports and harbors: Bratislava, Komarno
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 15,041
GRT/19,517DWT
ships by type: cargo 3 (2000 est.)
Airports: 35 (2000 est.)
Airports - with paved runways:
total: 18
over 3,047 m:1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 8 (2000 est.)
Airports - with unpaved runways:
total: 17
2,438 to 3,047 m:^
914 to 1,523 m: 9
under 914 m: 7 (2000 est.)','bae4b37bbe9bc677cb63b0ccc336e06112f49264c281e38a1bc3a55ba69f9ca8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ec09c2885ac563d1b21b417125bb52de61b49248dac3684efde900fafdbefbc',2001,'SB','Solomon Islands','transportation',1015,'Railways:
total: 1,201 km
standard gauge: 1 ,201 km 1 .435-m gauge (489 km
electrified) (1999)
Highways:
total: 19,586 km
paved: 17,745 km (including 249 km of expressways)
unpaved: 1 ,841 km (1 998 est.)
Waterways: NA
Pipelines: crude oil 290 km; natural gas 305 km
Ports and harbors: Izola, Koper, Piran
Airports: 14 (2000 est.)
Airports - with paved runways:
total: 6
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m:1 (2000 est.)
Airports - with unpaved runways;
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (2000 est.)
Location: Oceania, group of islands in the South
Pacific Ocean, east of Papua New Guinea
Geographic coordinates: 8 00 S, 159 00 E
Map references: Oceania
Area;
total: 28,450 sq km
land: 27,540 sq km
water: 910sqkm
Area - comparative: slightly smaller than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical monsoon; few extremes of
temperature and weather
Terrain; mostly rugged mountains with some low
coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu 2,447 m
Natural resources: fish, forests, gold, bauxite,
phosphates, lead, zinc, nickel
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 88%
other: 9% (1993 est.)
Irrigated land: NAsqkm
459
Solomon Islands (continued)
Natural hazards; typhoons, but they are rarely
destructive: geologically active region with frequent
earth tremors; volcanic activity
Environment - current Issues: deforestation; soil
erosion; much of the surrounding coral reefs are dead
or dying
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Railways: 0 km
Highways:
total: 1 ,360 km
paved: 34 km
unpaved: 1 ,326 km (includes about 800 km of private
plantation roads) (1996 est.)
Waterways: none
Ports and harbors: Aola Bay, Honiara, Lofung,
Noro, Viru Harbor, Yandina
Merchant marine: none (2000 est.)
Airports: 31 (2000 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m:1
914 to 1,523 m: 10
under 914 m: 18 (2000 est.)','fc735dfe56000a7e5243867f3ce35623ea3c04301b4a37a2af7b225dc25192bd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8096ca9b63d00fe8cd120aaa359ef73253493e2944a4688a13dc8c4b45bea9a8',2001,'SO','Somalia','transportation',1028,'Railways: 0 km
Highways:
tete/.''22,100 km
paved:2fiOS km
unpaved: 10 km (1996 est.)
Waterways: none
Pipelines; crude oil 15 km
Ports and harbors: Bender Cassim (Boosaaso),
Berbera, Chisimayu (Kismaayo), Merca, Mogadishu
Merchant marine: none (2000 est.)
Airports: 62 (2000 est.)
Airports - with paved runways:
total: 5
over 3,047 m: A
1,524 to 2,437 m:1 (2000 est.)
Airports - with unpaved runways:
total: 57
2,438 to 3,047 m: 4
1,524 to 2,437 m: 13
914 to 1,523 m: 20
under 914 m: 11 (2000 est.)','3314561cd3a1c7f2420f35fea39814fad7d43ab8a1190a193c91c66ec279feff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f466536b31fa43991716ced0e4bb792978e43ea8a29905c5180a9b10bf32dec',2001,'ES','Spain','transportation',1039,'Railways:
fofa/; 13,950 km
broad gauge: 12,781 km 1.668-m gauge (6,358 km
electrified; 2,295 km double track)
standard gauge: 525 km 1.435-m gauge (525 km
electrified)
narrow gauge: 644 km 1.000-m gauge (438 km
electrified) (1998)
Highways:
total: 346,858 km
paved: 343,389 km (including 9,063 km of
expressways)
unpaved: 3,469 km (1997 est.)
Waterways: 1 ,045 km (of minor economic
importance)
Pipelines: crude oil 265 km; petroleum products
1,794 km; natural gas 1,666 km
Ports and harbors: Aviles, Barcelona, Bilbao,
Cadiz, Cartagena, Castellon de la Plana, Ceuta,
Huelva, La Coruna, Las Palmas (Canary Islands),
470
Spain (continued)
Malaga, Melilla, Pasajes, Gijon, Santa Cruz de
Tenerife (Canary Islands), Santander, Tarragona,
Valencia, Vigo
Merchant marine:
total: 135 ships (1,000 CRT or over) totaling
1,208,730 GRT/1 ,773,378 DWT
ships by type: bulk 1 0, cargo 26, chemical tanker 1 0,
container 9, liquefied gas 2, livestock carrier 1 ,
passenger 1 , petroleum tanker 24, refrigerated cargo
5, roll on/roll off 35, short-sea passenger 8,
specialized tanker 1 , vehicle carrier 3 (2000 est.)
Airports: 110 (2000 est.)
Airports - with paved runways:
total: 76
over 3,047 m:
2,438 to 3,047 m:\\0
1,524 to 2,437 m:]Q
914 to 1,523 m: 19
under 91 4 m; 13 (2000 est.)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m:1
914 to 1,523 m: 9
under 914 m: 25 (2000 est.)
Heliports: 2 (2000 est.)','496097199d842b40cefbdf415d537ef06bb278b8c7ef1f25d607fbec6f1c00b7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ce0ef830f28262035eb2d5f665b424ed65ded50a606652ae3c0a0b88f1217e6',2001,'LK','Sri Lanka','transportation',1047,'Railways:
total: 1 ,463 km
broad gauge: 1,404 km 1.676-m gauge
narrow gauge: 59 km 0.762-m gauge (1996)
Highways:
tofaM 1,285 km
paved; 10,721 km
unpaved: 564 km (1998 est.)
Waterways: 430 km (navigable by shallow-draft
craft)
Pipelines: crude oil and petroleum products 62 km
(1987)
Ports and harbors: Colombo, Galle, Jaffna,
Trincomalee
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 149,902
GRT/247,852 DWT
ships by type: bulk 1 , cargo 1 6, container 1 ,
petroleum tanker 1 , refrigerated cargo 1 (2000 est.)
Airports: 14 (2000 est.)
Airports - with paved runways:
total: 12
over 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m: 5 {2009 est.)
Airports - with unpaved runways:
total: 2
1,524 to 2,437 m:1
under 914 m:^ (2000 est.)','5f215e2988026d960c8a7118fd307a67f1cb192b8dfcc9a35a1ff2c31d3e164d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bcc3e99af2929f61bc6c963b8f31910063504b10b5544b8aad9021391c05d0b',2001,'SD','Sudan','transportation',1056,'Railways:
total: 5,311 km
narrow gauge: 4,595 km 1.067-m gauge; 716 km
1 .6096-m gauge plantation line
note: the main line linking Khartoum to Port Sudan
carries over two-thirds of Sudan''s rail traffic
Highways;
total: 1 1 ,900 km
paved: 4,320 km
unpaved: 7,580 km (1996 est.)
Waterways: 5,310 km
Pipelines: refined products 815 km
Ports and harbors: Juba, Khartoum, Kusti, Malakal,
Nimule, Port Sudan, Sawakin
Merchant marine:
total: 4 ships (1,000 GRT or over) totaling 38,093
GRT/49,727 DWT
ships by type: cargo 2, roll on/roll off 2 (2000 est.)
Airports: 61 (2000 est.)
Airports - with paved runways:
total: 12
over 3,047 m:1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3 (2000 est.)
Airports - with unpaved runways:
total: 49
1,524 to 2,437 m: 15
914 to 1,523 m:25
under 914 m; 9 (2000 est.)
Heliports: 1 (2000 est.)','2d6c40ef53ad0c1ae90ab84eb52ebf18aa1fcadc20d6b5c12ae6ee15fbdba029','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5afc812b876f279c9186aea9d622247544617ecceb9f129565c17a42039933a6',2001,'PK','Pakistan','transportation',1071,'Railways:
total: ASO km in common carrier service; does not
include industrial lines (1990)
Highways:
total: 700 km
paved: 1 1 ,330 km (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: 2,370 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1996)
Waterways: none
Pipelines: natural gas 400 km (1992)
Ports and harbors: none
Airports; 53 (2000 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
under 914 m: 1 (2000 est.)
Airports - with unpaved runways:
total: 5^
over 3,047 m’A
1,524 to 2,437 m: 2
914 to 1,523 m: 12
under 914 m;36 (2000 est.)
Tanzania
Railways;
total: 3,569 km (1995)
narrow gauge: 2,600 km 1 .000-m gauge; 969 km
1.067-m gauge
note: the Tanzania-Zambia Railway Authority
(TAZARA), which operates 1 ,860 km of 1 .067-m
narrow gauge track between Dar es Salaam and
Kapiri Mposhi in Zambia (of which 969 km are in
Tanzania and 891 km are in Zambia) is not a part of
Tanzania Railways Corporation; because of the
difference in gauge, this system does not connect to
Tanzania Railways
Highways:
total: 88,200 km
paved: 3,704 km
unpaved: 84,496 km (1996 est.)
Waterways:
note: Lake Tanganyika, Lake Victoria, and Lake
Nyasa are principal avenues of commerce between
Tanzania and its neighbors on those lakes
Pipelines: crude oil 982 km
Ports and harbors: Bukoba, Dar es Salaam,
Kigoma, Kilwa Masoko, Lindi, Mtwara, Mwanza,
Pangani, Tanga, Wete, Zanzibar
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 21 ,987
GRT/27,121 DWT
ships by type: cargo 2, passenger/cargo 2, petroleum
tanker 2, roll on/roll off 1 , short-sea passenger 1
(2000 est.)
Airports: 126 (2000 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m:\\
under 914 m:1 (2000 est.)
495
Tanzania (continued)
Airports - with unpaved runways:
total:
1,524 to 2,437 m:M
914 to 1,523 m: 63
under 914 m: 35 (2000 est.)','dac66193f214114668b751ae263f20bfd5ec13bd376ec8dec37e84e0d3aaee38','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82631e6909f714f9d693d65a51cd21e2bf60713c32df6c77968d329626bc7bbe',2001,'TV','Tuvalu','transportation',1085,'Railways: 0 km
Highways:
total: S km (1996 est.)
paved: 0 km
unpaved: 8 km
Waterways: none
Ports and harbors: Funafuti, Nukufetau
Merchant marine:
tofa/; 9 ships (1,000 GRT or over) totaling 52,135
GRT/68,300 DWT
ships by type: cargo 5, passenger/cargo 1 , petroleum
tanker 1 , roll on/roll off 2 (2000 est.)
Airports: 1 (2000 est.)
Airports ■ with unpaved runways:
total: 1
1,524 to 2,437 m:1 (2000 est.)
Railways:
total: ^,24^ km
narrow gauge: 1 ,241 km 1 .000-m gauge
note: a program to rehabilitate the railroad is
underway (1995)
Highways:
total: 27,000 km
paved: 1 ,800 km
unpaved: 25,200 km (of which about 4,800 km are
all-weather roads) (1990 est.)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga,
Lake George, Lake Edward, Victoria Nile, Albert Nile
Ports and harbors: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 5,091 GRT/
8,229 DWT
ships by type: roll on/roll off
note: these ships are in cargo and passenger service
on Uganda''s inland waterways (2000 est.)
Airports: 28 (2000 est.)
Airports ■ with paved runways:
total: 4
over 3,047 m: 3
1,524 to 2,437 m:^ (2000 est.)
Airports - with unpaved runways;
total: 24
2,438 to 3,047 m:1
1,524 to 2,437 m: 6
914 to 1,523 m: 9
under 914 m; 8 (2000 est.)
Heliports: 1 (2000 est.)
Railways:
total: 23,350 km
broad gauge: 23,350 km 1.524-m gauge (8,600 km
electrified)
Highways:
tofa/; 176,310 km
paved: 170,139 km (including 1 ,770 km of
expressways); note - (these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: 6,171 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1998 est.)
Waterways: 4,499 km
note: (1 ,672 km are on the Pryp''yat'' and Dnistr) (1 990)
Pipelines: crude oil 4,000 km (1995); petroleum
products 4,500 km (1995); natural gas 34,400 km
(1998)
Ports and harbors: Berdyans''k, lllichivs''k, Izmayil,
Kerch, Kherson, Kiev (Kyyiv), Mariupol'', Mykolayiv,
Odesa, Reni, Sevastopol''
523
Ukraine (continued)
Merchant marine:
tofa/; 156 ships (1,000 GRT or over) totaling 757,582
GRT/841,755 DWT
ships by type: bulk 8, cargo 1 1 0, container 3, liquefied
gas 2, passenger 11, passenger/cargo 2, petroleum
tanker 14, railcar carrier 2, roll on/roll off 2, short-sea
passenger 2 (2000 est.)
Airports: 718 (2000 est.)
Airports ■ with paved runways:
tofa/;114
over 3,047 m:^A
2,438 to 3,047 m:b0
1,524 to 2,437 m:2^
914 to 1,523 m: 3
under 914 m: 26 (2000 est.)
Airports - with unpaved runways:
tofa/.''604
over 3,047 m: ^3
2,438 to 3,047 m: 37
1,524 to 2,437 m: 52
914 to 1,523 m: 45
under 914 m: 457 (2000 est.)','d9bc9f9fa99af634d1eaf18f8610d87981ffdf0d64e3a29915956c2ed4dcda0d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d5646bba908eb5b8adfbc24c55860b878c673f9a3c557b7dc1d8f15a16e9a9d',2001,'OM','Oman','transportation',1094,'Railways: 0 km
Highways:
tofa/; 1,088 km
paved; 1,088 km
unpaved: 0 km (1998 est.)
Waterways: none
Pipelines: crude oil 830 km; natural gas, including
natural gas liquids, 870 km
Ports and harbors: ''Ajman, A1 Fujayrah, Das
Island, Khawr Fakkan, Mina'' Jabal ''Ali, Mina'' Khalid,
Mina'' Rashid, Mina'' Saqr, Mina'' Zayid, Umm al
Qaywayn
Merchant marine:
total: 70 ships (1 ,000 GRT or over) totaling 1 ,094,256
GRT/1,421,333 DWT
ships by type: cargo 16, chemical tanker 3, container
17, liquefied gas 1 , livestock carrier 1 , passenger 1 ,
petroleum tanker 24, roll on/roll off 6, specialized
tanker 1 (2000 est.)
Airports: 40 (2000 est.)
Airports - with paved runways:
total: 22
over 3,047 m:Q
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m; 4 (2000 est.)
Airports - with unpaved runways:
total: 18
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m; 3 (2000 est.)
Heliports: 2 (2000 est.)','4431ca144a9d32bcaf26e52401f726bceb8311f38829947392d10453f2511637','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b26cd56a2360ad2879585752beb1556aa144615085bb87194b7265755fbbb53',2001,'UY','Uruguay','transportation',1106,'Railways:
total: 2,073 km
standard gauge: 2,073 km 1 .435-m gauge (2000)
Highways;
total: 8,983 km
paved: 8,085 km
unpaved: 898 km (1999 est.)
Waterways: 1 ,600 km ( used by coastal and
shallow-draft river craft)
Ports and harbors: Fray Bentos, Montevideo,
Nueva Palmira, Paysandu, Punta del Este, Colonia,
Piriapolis
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 7,752 GRT/
5,228 DWT
ships by type: petroleum tanker 1 , roll on/roll off 1
(2000 est.)
^rports: 64 (2000 est.)
Airports - with paved runways:
total: 15
2A38 to 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m: 8
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 49
1,524 to 2,437 m: 2
914 to 1,523 m:ie
under 914 m: 31 (2000 est.)','52ba9f2cd0af327830d2fd9709c37c1a367950fe7139c6de5144dc33a4b36272','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f3734cdae89997fbd0f7c7d1cbd8695eb67fabf6dfd25662272d4a48a0f6385',2001,'UZ','Uzbekistan','transportation',1113,'Railways:
total: 3,380 km in common carrier service; does not
include industrial lines
broad gauge: 3,380 km 1 .520-m gauge (300 km
electrified) (1993)
Highways:
to/a/.'' 81 ,600 km
paved: 71 ,237 km ((these roads are said to be
hard-surfaced, and include, in addition to
conventionally paved roads, some that are surfaced
with gravel or other coarse aggregate, making them
trafficable in all weather)
unpaved: 10,363 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1996)
Waterways: 1,100 km (1990)
Pipelines: crude oil 250 km; petroleum products 40
km; natural gas 810 km (1992)
Ports and harbors: Termiz (Amu Darya river)
Airports: 267 (2000 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 3
2,438 to 3,047 m: 5
under 914 m: 2 (2000 est.)
Airports - with unpaved runways:
total: 257
over 3,047 m: 3
2,438 to 3,047 m:S
1,524 to 2,437 m:U
914 to 1,523 m: 13
under 914 m:222','75ccd5791d53ca20a36f7bd1510343d9d95d8211ee1a43bebf7d663ae651499c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4474456d4411480facf9c487354b1a4c8ea55c35b8e169bc4dedc53650121c0',2001,'AF','Afghanistan','transportation',1121,'Railways: 0 km
Highways:
total: 1 ,070 km
paved: 256 km
unpaved: 814 km (1996 est.)
Waterways: none
Ports and harbors: Forari, Port- Vila, Santo (Espiritu
Santo)
Merchant marine:
total: 54 ships (1 ,000 GRT or over) totaling 1 ,067,384
GRT/1 ,330,543 DWT
ships by type: bulk 23, cargo 7, chemical tanker 3,
combination bulk 2, container 1 , liquefied gas 3,
petroleum tanker 2, refrigerated cargo 7, vehicle
carrier 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 2, Canada 1 ,
China 1 , France 1 , Greece 1 , Hong Kong 1 , Japan 22,
Netherlands 1 , Norway 1 , Switzerland 1 , US 4
(2000 est.)
Airports: 32 (2000 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914 to 1,523 m:1 (2000 est.)
Airports - with unpaved runways:
total: 30
1,524 to 2,437 m: 2
914 to 1,523 m;11
under 914 m: 17 (2000 est.)
Railways:
total: 584 km (248 km privately owned)
standard gauge: 584 km 1.435-m gauge
Highways:
fofa/; 96,155 km
paved: 32,308 km
unpaved: 63M7 km (1997 est.)
Waterways: 7,100 km
note: Rio Orinoco and Lago de Maracaibo accept
oceangoing vessels
Pipelines: crude oil 6,370 km; petroleum products
480 km; natural gas 4,010 km
Ports and harbors: Amuay, Bajo Grande, El
Tablazo, La Guaira, La Salina, Maracaibo, Matanzas,
Palua, Puerto Cabello, Puerto la Cruz, Puerto Ordaz,
Puerto Sucre, Punta Cardon
Merchant marine:
total: 36 ships (1 ,000 GRT or over) totaling 490,160
GRT/897,694 DWT
ships by type: bulk 7, cargo 10, liquefied gas 2,
passenger^argo 1 , petroleum tanker 7, roll on/roll off
8, short-sea passenger 1 (2000 est.)
Airports: 371 (2000 est.)
Airports - with paved runways:
total: 124
over 3,047 m''A
2,438 to 3,047 m’A2
1,524 to 2,437 m: 32
914 to 1,523 m: 59
under 914 m: 17 (2000 est.)
Airports - with unpaved runways:
total: 247
1,524 to 2,437 m’AQ
914 to 1,523 m: 97
under 914 m: 140 (2000 est.)
Heliports: 1 (2000 est.)
Railways:
total: 2 fi52 km
standard gauge: km 1.435-m gauge
narrow gauge: 2,249 km 1.000-m gauge
dual gauge: 237 km NA-m gauges (three rails) (1998)
Highways:
total: 93,300 km
paved: 23,41 8 km
unpaved: 69,882 km (1996 est.)
Waterways: 17,702 km
note: more than 5,1 49 km are navigable at all times by
vessels up to 1.8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang,
Haiphong, Ho Chi Minh City, Ha Long, Quy Nhon, Nha
Trang, Vinh, Vung Tau
Merchant marine:
total: 143 ships (1 ,000 CRT or over) totaling 705,388
GRT/1,071,902 DWT
ships by type: bulk 8, cargo 1 08, chemical tanker 1 ,
combination bulk 1 , container 2, liquefied gas 2,
petroleum tanker 18, refrigerated cargo 3 (2000 est.)
Airports: 34 (2000 est.)
Airports - with paved runways:
total: M
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
under 914 m; 2 (2000 est.)
Airports - with unpaved runways:
total: M
over 3,047 m:^
1,524 to 2,437 m:1
914 to 1,523 m: 7
under 914 m; 8 (2000 est.)','6660bf509c25177ae5c16eb877a2e2be88ab097bf0815b90c4bc7eafc429aa61','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd6770dd9e87170cd143f8d5f8c3600931ff7053e48dbb7d2f2a2ecac8ff7f03',2001,'PR','Puerto Rico','transportation',1127,'Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Charlotte Amalie, Christiansted,
Cruz Bay, Port Alucroix
Merchant marine; none (2000 est.)
Airports: 2
note: international airports on Saint Thomas and Saint
Croix (2000 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2 (2000 est.)','58f209fc3a211b3bd14e8ba425750201f29830619c9d269c96f67b28221c7fa1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bafecd64ae6a7089194ab1ec5f573e1e2cee6d634fea17935a081b5ad646a3bc',2001,'YE','Yemen','transportation',1139,'Railways: 0 km
Highways:
total: 69,263 km
paved: 9,963 km
unpaved: 59,300 km (1999)
Waterways: none
Pipelines: crude oil 644 km; petroleum products
32 km
Ports and harbors: Aden, Al Hudaydah, Ai Mukalla,
As Salif, Mocha, Nishtun
Merchant marine:
tofa/;4 ships (1,000 GRT or over) totaling 15,075
GRT/23,562 DWT
ships by type: cargo 1 , petroleum tanker 3 (2000 est.)
Airports: 50 (2000 est.)
Airports - with paved runways:
total:
over 3,047 m: 2
2,438 to 3,047 m:S
1,524 to 2,437 m:\\
914 to 1,523 m:1
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 37
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 8
914 to 1,523 m:^3
under 914 m; 5 (2000 est.)
Railways:
tote/; 4,095 km
standard gauge: 4,095 km 1 .435-m gauge (1 ,377 km
partially electrified since 1992)
note: during to the 1999 Kosovo conflict, the Serbian
rail system suffered significant damage due to bridge
destruction; many rail bridges have been rebuilt, but
the bridge over the Danube at Novi Sad was still down
in early 2000; however, a by-pass is available;
Montenegrin rail lines remain intact
559
Yugoslavia (continued)
Highways:
total: 48,603 km
paved: 28,822 km (including 560 km of expressways)
unpaved: 19,781 km (1998 est.)
note: because of the 1 999 Kosovo conflict, many road
bridges were destroyed; since the end of the conflict
in June 1999, there has been an intensive program to
either rebuild bridges or build by-pass routes
Waterways: 587 km
note: The Danube River, which connects Europe with
the Black Sea, runs through Serbia; since early 2000,
a pontoon bridge, replacing a destroyed conventional
bridge, has obstructed river traffic at Novi Sad; the
obstruction can be bypassed by a canal system but
inadequate lock size limits the size of vessels which
may pass (2001)
Pipelines: crude oil 415 km; petroleum products 130
km; natural gas 2,110 km
Ports and harbors: Bar, Belgrade, Kotor, Novi Sad,
Pancevo, Tivat, Zelenika
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 2,437 GRT/
400 DWT
ships by type: short-sea passenger 1 (2000 est.)
Airports: 47 (2000 est.)
Airports - with paved runways:
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m; 4 (2000 est.)
Airports ■ with unpaved runways:
total: 28
1,524 to 2,437 m: 2
914 to 1,523 m: 12
under 914 m: 14 (2000 est.)
Heliports: 2 (2000 est.)','4c1efad5950ff02d553e7993837e434d3ad00853fd0e04b5ed15c5032ce4146c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dc9c34d3c16417f83a68b65b54951d67a123cb57d8f898f984012ed06002cc9',2001,'ZM','Zambia','transportation',1148,'Railways:
total: 2, m km (1995)
narrow gauge: 2,164 km 1.067-m gauge (13 km
double track)
note: the total includes 891 km of the
Tanzania-Zambia Railway Authority (TAZARA), which
operates 1 ,860 km of 1 .067-m narrow gauge track
between Dar es Salaam and Kapiri Mposhi where it
connects to the Zambia Railways system; TAZARA is
not a part of the Zambia Railways system; Zambia
Railways assets are scheduled for concessioning in
2001
Highways:
total: 66,781 km
paved: NA km
unpaved: NA km (1997 est.)
Waterways: 2,250 km
note: includes Lake Tanganyika and the Zambezi and
Luapula rivers
Pipelines: crude oil 1 ,724 km
Ports and harbors: Mpulungu
Airports: 112 (2000 est.)
Airports - with paved runways:
total: 13
over 3,047 m:1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m:1 (2000 est.)
Airports - with unpaved runways:
total: 99
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 65
under 914 m;31 (2000 est.)
Railways:
total: 2,759 km (1995)
narrow gauge: 2,759 km 1.067-m gauge (313 km
electrified; 42 km double track) (1995 est.)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (1996 est.)
564
Zimbabwe (continued)
Waterways: the Mazoe and Zambezi rivers are used
for transporting chrome ore from Harare to','5aa9f810f5e8b5b46ae6b28112f4c015453bfeb902202a6d1d4f25df86f7a4e5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e6b1b20c2db9eece08ef9137fd344640234845d5790ab0dfc7df0d32a10dd1a',2001,'WF','Wallis and Futuna','transportation',17,'This category includes the entries dealing with the means for movement
of people and goods.
Transportation - note
This entry includes miscellaneous transportation information of
significance not included elsewhere.
Unemployment rate
This entry contains the percent of the labor force that is without
jobs. Substantial underemployment might be noted.
Waterways
This entry gives the total length and individual names of navigable
rivers, canals, and other inland bodies of water.
Years
All year references are for the calendar year (CY) unless indicated as
fiscal year (FY). The calendar year is an accounting period of 12
months from 1 January to 31 December. The fiscal year is an accounting
period of 12 months other than 1 January to 31 December.
Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates.
=====================================================================
A Brief History of Basic Intelligence and The World Factbook
The Intelligence Cycle is the process by which information is acquired,
converted into intelligence, and made available to policymakers.
Information is raw data from any source, data that may be fragmentary,
contradictory, unreliable, ambiguous, deceptive, or wrong.
Intelligence is information that has been collected, integrated,
evaluated, analyzed, and interpreted. Finished intelligence is the
final product of the Intelligence Cycle ready to be delivered to the
policymaker.
The three types of finished intelligence are: basic, current, and
estimative. Basic intelligence provides the fundamental and factual
reference material on a country or issue. Current intelligence reports
on new developments. Estimative intelligence judges probable outcomes.
The three are mutually supportive: basic intelligence is the foundation
on which the other two are constructed; current intelligence
continually updates the inventory of knowledge; and estimative
intelligence revises overall interpretations of country and issue
prospects for guidance of basic and current intelligence. The World
Factbook, The President''s Daily Brief, and the National Intelligence
Estimates are examples of the three types of finished intelligence.
The United States has carried on foreign intelligence activities since
the days of George Washington but only since World War II have they
been coordinated on a government-wide basis. Three programs have
highlighted the development of coordinated basic intelligence since
that time: (1) the Joint Army Navy Intelligence Studies (JANIS), (2)
the National Intelligence Survey (NIS), and (3) The World Factbook.
During World War II, intelligence consumers realized that the
production of basic intelligence by different components of the US
Government resulted in a great duplication of effort and conflicting
information. The Japanese attack on Pearl Harbor in 1941 brought home
to leaders in Congress and the executive branch the need for
integrating departmental reports to national policymakers. Detailed and
coordinated information was needed not only on such major powers as
Germany and Japan, but also on places of little previous interest. In
the Pacific Theater, for example, the Navy and Marines had to launch
amphibious operations against many islands about which information was
unconfirmed or nonexistent. Intelligence authorities resolved that the
United States should never again be caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train (Office of Naval
Intelligence - ONI), and Gen. William J. Donovan (Director of the
Office of Strategic Services - OSS) decided that a joint effort should
be initiated. A steering committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study Publishing
Board to assemble, edit, coordinate, and publish the Joint Army Navy
Intelligence Studies (JANIS). JANIS was the first interdepartmental
basic intelligence program to fulfill the needs of the US Government
for an authoritative and coordinated appraisal of strategic basic
intelligence. Between April 1943 and July 1947, the board published 34
JANIS studies. JANIS performed well in the war effort, and numerous
letters of commendation were received, including a statement from Adm.
Forrest Sherman, Chief of Staff, Pacific Ocean Areas, which said,
"JANIS has become the indispensable reference work for the shore-based
planners."
The need for more comprehensive basic intelligence in the postwar world
was well expressed in 1946 by George S. Pettee, a noted author on
national security. He wrote in The Future of American Secret
Intelligence (Infantry Journal Press, 1946, page 46) that world
leadership in peace requires even more elaborate intelligence than in
war. "The conduct of peace involves all countries, all human activities
- not just the enemy and his war production."
The Central Intelligence Agency was established on 26 July 1947 and
officially began operating on 18 September 1947. Effective 1 October
1947, the Director of Central Intelligence assumed operational
responsibility for JANIS. On 13 January 1948, the National Security
Council issued Intelligence Directive (NSCID) No. 3, which authorized
the National Intelligence Survey (NIS) program as a peacetime
replacement for the wartime JANIS program. Before adequate NIS country
sections could be produced, government agencies had to develop more
comprehensive gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the Interior produced
the gazetteers; and CIA produced the maps.
The Hoover Commission''s Clark Committee, set up in 1954 to study the
structure and administration of the CIA, reported to Congress in 1955
that: "The National Intelligence Survey is an invaluable publication
which provides the essential elements of basic intelligence on all
areas of the world. There will always be a continuing requirement for
keeping the Survey up-to-date." The Factbook was created as an annual
summary and update to the encyclopedic NIS studies. The first
classified Factbook was published in August 1962, and the first
unclassified version was published in June 1971. The NIS program was
terminated in 1973 except for the Factbook, map, and gazetteer
components. The 1975 Factbook was the first to be made available to the
public with sales through the US Government Printing Office (GPO). The
1996 edition was printed by GPO, and the 1997 edition was reprinted by
GPO. The year 2001 marks the 54th anniversary of the establishment of
the Central Intelligence Agency and the 58th year of continuous basic
intelligence support to the US Government by The World Factbook and its
two predecessor programs.
=====================================================================
Contributors and Copyright Information
In general, information available as of 1 January 2001 was used in the
preparation of this edition.
The World Factbook is prepared by the Central Intelligence Agency for
the use of US Government officials, and the style, format, coverage,
and content are designed to meet their specific requirements.
Information is provided by Antarctic Information Program (National
Science Foundation), Bureau of the Census (Department of Commerce),
Bureau of Labor Statistics (Department of Labor), Central Intelligence
Agency, Council of Managers of National Antarctic Programs, Defense
Intelligence Agency (Department of Defense), Department of State, Fish
and Wildlife Service (Department of the Interior), Maritime
Administration (Department of Transportation), National Imagery and
Mapping Agency (Department of Defense), Naval Facilities Engineering
Command (Department of Defense), Office of Insular Affairs (Department
of the Interior), Office of Naval Intelligence (Department of Defense),
US Board on Geographic Names (Department of the Interior), US
Transportation Command (Department of Defense), and other public and
private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA).
The official seal of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50 U.S.C. section
403m). Misuse of the official seal of the CIA could result in civil
and criminal penalties.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
=====================================================================
Purchasing Information
The Central Intelligence Agency (CIA) publishes The World Factbook in
printed and Internet versions. US Government officials may obtain
information about availability of the Factbook from their organizations
or through liaison channels to the CIA. Other users may obtain sales
information about printed copies from the following:
Superintendent of Documents
P. O. Box 371954
Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512-1800
FAX: [1] (202) 512-2250
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The World Factbook can be accessed on the Internet at:
http://www.cia.gov/cia/publications/factbook/index.html
=====================================================================
@Afghanistan
Afghanistan Introduction
Background: Afghanistan was invaded and occupied by the Soviet Union
in 1979. The USSR was forced to withdraw 10 years later by
anti-communist mujahidin forces supplied and trained by the US,
Saudi Arabia, Pakistan, and others. Fighting subsequently continued
among the various mujahidin factions, but the fundamentalist Islamic
Taliban movement has been able to seize most of the country. In
addition to the continuing civil strife, the country suffers from
enormous poverty, a crumbling infrastructure, and widespread land
mines.
Afghanistan Geography
Location: Southern Asia, north and west of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area: total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries: total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
Elevation extremes: lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal, copper, chromite,
talc, barites, sulfur, lead, zinc, iron ore, salt, precious and
semiprecious stones
Land use: arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% (1993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in Hindu Kush mountains;
flooding; droughts
Environment - current issues: soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification
Environment - international agreements: party to: Desertification,
Endangered Species, Environmental Modification, Marine Dumping,
Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Life Conservation
Geography - note: landlocked
Afghanistan People
Population: 26,813,057 (July 2001 est.)
Age structure: 0-14 years: 42.2% (male 5,775,921; female 5,538,836)
15-64 years: 55.01% (male 7,644,242; female 7,106,568)
65 years and over: 2.79% (male 394,444; female 353,046) (2001 est.)
Population growth rate: 3.48% (2001 est.)
note: this rate reflects the continued return of refugees from Iran
Birth rate: 41.42 births/1,000 population (2001 est.)
Death rate: 17.72 deaths/1,000 population (2001 est.)
Net migration rate: 11.11 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.08 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1.06 male(s)/female (2001 est.)
Infant mortality rate: 147.02 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 46.24 years
male: 46.97 years
female: 45.47 years (2001 est.)
Total fertility rate: 5.79 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality: noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Hazara 19%, minor ethnic
groups (Aimaks, Turkmen, Baloch, and others) 12%, Uzbek 6%
Religions: Sunni Muslim 84%, Shi''a Muslim 15%, other 1%
Languages: Pashtu 35%, Afghan Persian (Dari) 50%, Turkic languages
(primarily Uzbek and Turkmen) 11%, 30 minor languages (primarily
Balochi and Pashai) 4%, much bilingualism
Literacy: definition: age 15 and over can read and write
total population: 31.5%
male: 47.2%
female: 15% (1999 est.)
Afghanistan Government
Country name: conventional long form: Islamic State of Afghanistan;
note - the self-proclaimed Taliban government refers to the country
as Islamic Emirate of Afghanistan
conventional short form: Afghanistan
local long form: Dowlat-e Eslami-ye Afghanestan
local short form: Afghanestan
former: Republic of Afghanistan
Government type: no functioning central government, administered by
factions
Capital: Kabul
Administrative divisions: 30 provinces (velayat, singular -
velayat); Badakhshan, Badghis, Baghlan, Balkh, Bamian, Farah,
Faryab, Ghazni, Ghowr, Helmand, Herat, Jowzjan, Kabol, Kandahar,
Kapisa, Konar, Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Oruzgan,
Paktia, Paktika, Parvan, Samangan, Sar-e Pol, Takhar, Vardak, Zabol;
note - there may be two new provinces of Nurestan (Nuristan) and
Khowst
Independence: 19 August 1919 (from UK control over Afghan foreign
affairs)
National holiday: Independence Day, 19 August (1919)
Constitution: none
Legal system: a new legal system has not been adopted but all
factions tacitly agree they will follow Shari''a (Islamic law)
Suffrage: NA; previously males 15-50 years of age
Executive branch: on 27 September 1996, the ruling members of the
Afghan Government were displaced by members of the Islamic Taliban
movement; the Islamic State of Afghanistan has no functioning
government at this time, and the country remains divided among
fighting factions
note: the Taliban have declared themselves the legitimate
government of Afghanistan; however, the UN still recognizes the
government of Burhanuddin RABBANI; the Organization of the Islamic
Conference has left the Afghan seat vacant until the question of
legitimacy can be resolved through negotiations among the warring
factions; the country is essentially divided along ethnic lines; the
Taliban controls the capital of Kabul and approximately two-thirds
of the country including the predominately ethnic Pashtun areas in
southern Afghanistan; opposing factions have their stronghold in the
ethnically diverse north
Legislative branch: non-functioning as of June 1993
Judicial branch: upper courts were non-functioning as of March 1995
(local Shari''a or Islamic law courts are functioning throughout the
country)
Political parties and leaders: Taliban (Religious Students Movement)
[Mullah Mohammad OMAR]; United National Islamic Front for the
Salvation of Afghanistan or UNIFSA [Burhanuddin RABBANI, chairman;
Gen. Abdul Rashid DOSTAM, vice chairman; Ahmad Shah MASOOD, military
commander; Mohammed Yunis QANUNI, spokesman]; note - made up of 13
parties opposed to the Taliban including Harakat-i-Islami
Afghanistan (Islamic Movement of Afghanistan), Hizb-i-Islami
(Islamic Party), Hizb-i-Wahdat-i-Islami (Islamic Unity Party),
Jumaat-i-Islami Afghanistan (Islamic Afghan Society),
Jumbish-i-Milli (National Front), Mahaz-i-Milli-i-Islami (National
Islamic Front)
Political pressure groups and leaders: Afghan refugees in Pakistan,
Australia, US, and elsewhere have organized politically; Mellat
(Social Democratic Party) [leader NA]; Peshawar, Pakistan-based
groups such as the Coordination Council for National Unity and
Understanding in Afghanistan or CUNUA [Ishaq GAILANI]; tribal elders
represent traditional Pashtun leadership; Writers Union of Free
Afghanistan or WUFA [A. Rasul AMIN]
International organization participation: AsDB, CP, ECO, ESCAP, FAO,
G-77, IAEA, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF,
Intelsat, IOC, IOM (observer), ITU, NAM, OIC, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO, WMO, WToO
Diplomatic representation in the US: none; note - embassy operations
suspended 21 August 1997
consulate(s) general: New York
Diplomatic representation from the US: the US embassy in Kabul has
been closed since January 1989 due to security concerns
Flag description: three equal horizontal bands of green (top),
white, and black with a gold emblem centered on the three bands; the
emblem features a temple-like structure with Islamic inscriptions
above and below, encircled by a wreath on the left and right and by
a bolder Islamic inscription above, all of which are encircled by
two crossed scimitars
note: the Taliban uses a plain white flag
Afghanistan Economy
Economy - overview: Afghanistan is an extremely poor, landlocked
country, highly dependent on farming and livestock raising (sheep
and goats). Economic considerations have played second fiddle to
political and military upheavals during two decades of war,
including the nearly 10-year Soviet military occupation (which ended
15 February 1989). During that conflict one-third of the population
fled the country, with Pakistan and Iran sheltering a combined peak
of more than 6 million refugees. In early 2000, 2 million Afghan
refugees remained in Pakistan and about 1.4 million in Iran. Gross
domestic product has fallen substantially over the past 20 years
because of the loss of labor and capital and the disruption of trade
and transport; severe drought added to the nation''s difficulties in
1998-2000. The majority of the population continues to suffer from
insufficient food, clothing, housing, and medical care. Inflation
remains a serious problem throughout the country. International aid
can deal with only a fraction of the humanitarian problem, let alone
promote economic development. In 1999-2000, internal civil strife
continued, hampering both domestic economic policies and
international aid efforts. Numerical data are likely to be either
unavailable or unreliable. Afghanistan was by far the largest
producer of opium poppies in 2000, and narcotics trafficking is a
major source of revenue.
GDP: purchasing power parity - $21 billion (2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $800 (2000 est.)
GDP - composition by sector: agriculture: 53%
industry: 28.5%
services: 18.5% (1990)
Population below poverty line: NA%
Household income or consumption by percentage share: lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 10 million (2000 est.)
Labor force - by occupation: agriculture 70%, industry 15%, services
15% (1990 est.)
Unemployment rate: NA%
Budget: revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Industries: small-scale production of textiles, soap, furniture,
shoes, fertilizer, and cement; handwoven carpets; natural gas, oil,
coal, copper
Electricity - production: 420 million kWh (1999)
Electricity - production by source: fossil fuel: 35.71%
hydro: 64.29%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 480.6 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 90 million kWh (1999)
Agriculture - products: opium poppies, wheat, fruits, nuts; wool,
mutton, karakul pelts
Exports: $80 million (does not include opium) (1996 est.)
Exports - commodities: opium, fruits and nuts, handwoven carpets,
wool, cotton, hides and pelts, precious and semi-precious gems
Exports - partners: FSU, Pakistan, Iran, Germany, India, UK,
Belgium, Luxembourg, Czech Republic
Imports: $150 million (1996 est.)
Imports - commodities: capital goods, food and petroleum products;
most consumer goods
Imports - partners: FSU, Pakistan, Iran, Japan, Singapore, India,
South Korea, Germany
Debt - external: $5.5 billion (1996 est.)
Economic aid - recipient: US provided about $70 million in
humanitarian assistance in 1997; US continues to contribute to
multilateral assistance through the UN programs of food aid,
immunization, land mine removal, and a wide range of aid to refugees
and displaced persons
Currency: afghani (AFA)
Currency code: AFA
Exchange rates: afghanis per US dollar - 4,700 (January 2000), 4,750
(February 1999), 17,000 (December 1996), 7,000 (January 1995), 1,900
(January 1994), 1,019 (March 1993), 850 (1991); note - these rates
reflect the free market exchange rates rather than the official
exchange rate, which was fixed at 50.600 afghanis to the dollar
until 1996, when it rose to 2,262.65 per dollar, and finally became
fixed again at 3,000.00 per dollar in April 1996
Fiscal year: 21 March - 20 March
Afghanistan Communications
Telephones - main lines in use: 29,000 (1996)
note: there were 21,000 main lines in service in Kabul in 1998
Telephones - mobile cellular: NA
Telephone system: general assessment: very limited telephone and
telegraph service
domestic: in 1997, telecommunications links were established
between Mazar-e Sharif, Herat, Kandahar, Jalalabad, and Kabul
through satellite and microwave systems
international: satellite earth stations - 1 Intelsat (Indian Ocean)
linked only to Iran and 1 Intersputnik (Atlantic Ocean region);
commercial satellite telephone center in Ghazni
Radio broadcast stations: AM 7 (6 are inactive; the active station
is in Kabul), FM 1, shortwave 1 (broadcasts in Pushtu, Dari, Urdu,
and English) (1999)
Radios: 167,000 (1999)
Television broadcast stations: at least 10 (one government run
central television station in Kabul and regional stations in nine of
the 30 provinces; the regional stations operate on a reduced
schedule; also, in 1997, there was a station in Mazar-e Sharif
reaching four northern Afghanistan provinces) (1998)
Televisions: 100,000 (1999)
Internet country code: .af
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Afghanistan Transportation
Railways: total: 24.6 km
broad gauge: 9.6 km 1.524-m gauge from Gushgy (Turkmenistan) to
Towraghondi; 15 km 1.524-m gauge from Termiz (Uzbekistan) to
Kheyrabad transshipment point on south bank of Amu Darya
Highways: total: 21,000 km
paved: 2,793 km
unpaved: 18,207 km (1998 est.)
Waterways: 1,200 km
note: chiefly Amu Darya, which handles vessels with DWT up to about
500 (2001)
Pipelines: petroleum products - Uzbekistan to Bagram and
Turkmenistan to Shindand; natural gas 180 km
Ports and harbors: Kheyrabad, Shir Khan
Airports: 45 (2000 est.)
Airports - with paved runways: total: 10
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 1 (2000 est.)
Airports - with unpaved runways: total: 35
2,438 to 3,047 m: 4
1,524 to 2,437 m: 15
914 to 1,523 m: 4
under 914 m: 12 (2000 est.)
Heliports: 3 (2000 est.)
Afghanistan Military
Military branches: NA; note - the military does not exist on a
national basis; some elements of the former Army, Air and Air
Defense Forces, National Guard, Border Guard Forces, National Police
Force (Sarandoi), and tribal militias still exist but are
factionalized among the various groups
Military manpower - military age: 22 years of age
Military manpower - availability: males age 15-49: 6,645,023 (2001
est.)
Military manpower - fit for military service: males age 15-49:
3,561,957 (2001 est.)
Military manpower - reaching military age annually: males: 252,869
(2001 est.)
Military expenditures -','c3816289872eb38143504ccb4bb33c760cb3e24f16eb71863584cd0229dc82af','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7946308d2540ff90862eb98e74f223a0d331516eb4b6a9c9743435300bfb4ad9',2001,'WF','Wallis and Futuna','transportation',18,'dollar figure: $NA
Military expenditures - percent of GDP: NA%
Afghanistan Transnational Issues
Disputes - international: support to Islamic militants worldwide by
some factions; question over which group should hold Afghanistan''s
seat at the UN
Illicit drugs: world''s largest illicit opium producer, surpassing
Burma (potential production in 1999 - 1,670 metric tons; cultivation
in 1999 - 51,500 hectares, a 23% increase over 1998); a major source
of hashish; increasing number of heroin-processing laboratories
being set up in the country; major political factions in the country
profit from drug trade
======================================================================
@Albania
Albania Introduction
Background: In 1990 Albania ended 44 years of xenophobic communist
rule and established a multiparty democracy. The transition has
proven difficult as corrupt governments have tried to deal with high
unemployment, a dilapidated infrastructure, widespread gangsterism,
and disruptive political opponents. International observers judged
local elections in 2000 to be acceptable and a step toward
democratic development, but serious deficiencies remain to be
corrected before the the 2001 parliamentary elections.
Albania Geography
Location: Southeastern Europe, bordering the Adriatic Sea and Ionian
Sea, between Greece and the Federal Republic of Yugoslavia
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area: total: 28,748 sq km
land: 27,398 sq km
water: 1,350 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries: total: 720 km
border countries: Greece 282 km, The Former Yugoslav Republic of
Macedonia 151 km, Yugoslavia 287 km
Coastline: 362 km
Maritime claims: continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 NM
Climate: mild temperate; cool, cloudy, wet winters; hot, clear, dry
summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains along coast
Elevation extremes: lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,753 m
Natural resources: petroleum, natural gas, coal, chromium, copper,
timber, nickel, hydropower
Land use: arable land: 21%
permanent crops: 5%
permanent pastures: 15%
forests and woodland: 38%
other: 21% (1993 est.)
Irrigated land: 3,410 sq km (1993 est.)
Natural hazards: destructive earthquakes; tsunamis occur along
southwestern coast; drought
Environment - current issues: deforestation; soil erosion; water
pollution from industrial and domestic effluents
Environment - international agreements: party to: Biodiversity,
Climate Change, Desertification, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
Geography - note: strategic location along Strait of Otranto (links
Adriatic Sea to Ionian Sea and Mediterranean Sea)
Albania People
Population: 3,510,484 (July 2001 est.)
Age structure: 0-14 years: 29.53% (male 536,495; female 500,026)
15-64 years: 63.48% (male 1,073,351; female 1,155,115)
65 years and over: 6.99% (male 107,476; female 138,021) (2001 est.)
Population growth rate: 0.88% (2001 est.)
Birth rate: 19.01 births/1,000 population (2001 est.)
Death rate: 6.5 deaths/1,000 population (2001 est.)
Net migration rate: -3.69 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.96 male(s)/female (2001 est.)
Infant mortality rate: 39.99 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 71.83 years
male: 69.01 years
female: 74.87 years (2001 est.)
Total fertility rate: 2.32 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: less than 0.01% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than 100 (2000 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality: noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greeks 3%, other 2% (Vlachs, Gypsies,
Serbs, and Bulgarians) (1989 est.)
note: in 1989, other estimates of the Greek population ranged from
1% (official Albanian statistics) to 12% (from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%, Roman Catholic 10%
note: all mosques and churches were closed in 1967 and religious
observances prohibited; in November 1990, Albania began allowing
private religious practice
Languages: Albanian (Tosk is the official dialect), Greek
Literacy: definition: age 9 and over can read and write
total population: 93% (1997 est.)
male: NA%
female: NA%
Albania Government
Country name: conventional long form: Republic of Albania
conventional short form: Albania
local long form: Republika e Shqiperise
local short form: Shqiperia
former: People''s Socialist Republic of Albania
Government type: emerging democracy
Capital: Tirana
Administrative divisions: 36 districts (rrethe, singular - rreth)
and 1 municipality* (bashki); Berat, Bulqize, Delvine, Devoll
(Bilisht), Diber (Peshkopi), Durres, Elbasan, Fier, Gjirokaster,
Gramsh, Has (Krume), Kavaje, Kolonje (Erseke), Korce, Kruje, Kucove,
Kukes, Kurbin, Lezhe, Librazhd, Lushnje, Malesi e Madhe (Koplik),
Mallakaster (Ballsh), Mat (Burrel), Mirdite (Rreshen), Peqin,
Permet, Pogradec, Puke, Sarande, Shkoder, Skrapar (Corovode),
Tepelene, Tirane (Tirana), Tirane* (Tirana), Tropoje (Bajram Curri),
Vlore
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
Independence: 28 November 1912 (from Ottoman Empire)
National holiday: Independence Day, 28 November (1912)
Constitution: a new constitution was adopted by popular referendum
on 28 November 1998; note - the opposition Democratic Party
boycotted the vote
Legal system: has not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal and compulsory
Executive branch: chief of state: President of the Republic Rexhep
MEIDANI (since 24 July 1997)
head of government: Prime Minister Ilir META (since 29 October 1999)
cabinet: Council of Ministers nominated by the prime minister and
approved by the president
elections: president elected by the People''s Assembly for a
five-year term; election last held 24 July 1997 (next to be held NA
2002); prime minister appointed by the president
election results: Rexhep MEIDANI elected president; People''s
Assembly vote by number - total votes 122, for 110, against 3,
abstained 2, invalid 7
Legislative branch: unicameral People''s Assembly or Kuvendi Popullor
(155 seats; most members are elected by direct popular vote and some
by proportional vote for four-year terms)
elections: last held 29 June 1997 (next held 24 June 2001, 2nd
round 8 July 2001)
election results: percent of vote by party - PS 53.36%, PD 25.33%,
PSD 2.5%, PBDNJ 2.78%, PBK 2.36%, PAD 2.85%, PR 2.25%, PLL 3.09%,
PDK 1.00%, PBSD 0.84%; seats by party - PS 101, PD 27, PSD 8, PBDNJ
4, PBK 3, PAD 2, PR 2, PLL 2, PDK 1, PBSD 1, PUK 1, independents 3
Judicial branch: Supreme Court (chairman is elected by the People''s
Assembly for a four-year term)
Political parties and leaders: Albanian National Front (Balli
Kombetar) or PBK [Abaz ERMENJI]; Albanian Republican Party or PR
[Fatmir MEDIU]; Albanian Socialist Party or PS (formerly the Albania
Workers Party) [Fatos NANO, chairman]; Christian Democratic Party or
PDK [Zef BUSHATI]; Democratic Alliance or PAD [Neritan CEKA];
Democratic Party or PD [Sali BERISHA]; Group of Reformist Democrats
[Leonard NDOKA]; Liberal Union Party [Teodor LACO]; note - Teodor
LACO of the Liberal Union Party was leader of the Social Democratic
Union of Albania or PBSD; Movement of Legality Party or PLL [Nderim
KUPI]; OMONIA [Vagjelis DULES]; Party of National Unity or PUK
[Idajet BEQUIRI]; Social Democratic Party or PSD [Skender GJINUSHI];
Unity for Human Rights Party or PBDNJ [Vasil MELO, chairman]
Political pressure groups and leaders: NA
International organization participation: ACCT (associate), BSEC,
CCC, CE, CEI, EAPC, EBRD, ECE, FAO, IAEA, IBRD, ICAO, ICRM, IDA,
IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user),
Interpol, IOC, IOM, ISO (correspondent), ITU, OIC, OPCW, OSCE, PFP,
UN, UNCTAD, UNESCO, UNIDO, UNOMIG, UPU, WFTU, WHO, WIPO, WMO, WToO,
WTrO
Diplomatic representation in the US: chief of mission: Ambassador
Petrit BUSHATI
chancery: 2100 S Street NW, Washington, DC 20008
telephone: [1] (202) 223-4942
FAX: [1] (202) 628-7342
Diplomatic representation from the US: chief of mission: Ambassador
Joseph LIMPRECHT
embassy: Rruga Elbasanit Labinoti 103, Tirana
mailing address: PSC 59, Box 100(A), APO AE 09624
telephone: [355] (42) 32875, 33520
FAX: [355] (42) 32222
Flag description: red with a black two-headed eagle in the center
Albania Economy
Economy - overview: Poor by European standards, Albania is making
the difficult transition to a more open-market economy. The economy
rebounded in 1993-95 after a severe depression accompanying the end
of the previous centrally planned system in 1990 and 1991. However,
a weakening of government resolve to maintain stabilization policies
in the election year of 1996 contributed to renewal of inflationary
pressures, spurred by the budget deficit which exceeded 12% of GDP.
The collapse of financial pyramid schemes in early 1997 - which had
attracted deposits from a substantial portion of Albania''s
population - triggered severe social unrest which led to more than
1,500 deaths, widespread destruction of property, and a 7% drop in
GDP. The government has taken measures to curb violent crime and to
revive economic activity and trade. The economy is bolstered by
remittances from some 20% of the labor force that works abroad,
mostly in Greece and Italy. These remittances supplement GDP and
help offset the large foreign trade deficit. Most agricultural land
was privatized in 1992, substantially improving peasant incomes. In
1998, Albania recovered the 7% drop in GDP of 1997 and pushed ahead
by 8% in 1999 and by 7.5% in 2000. International aid helped defray
the high costs of receiving and returning refugees from the Kosovo
conflict. Privatization scored some successes in 2000, but other
reforms lagged.
GDP: purchasing power parity - $10.5 billion (2000 est.)
GDP - real growth rate: 7.5% (2000 est.)
GDP - per capita: purchasing power parity - $3,000 (2000 est.)
GDP - composition by sector: agriculture: 55%
industry: 24%
services: 21% (2000)
Population below poverty line: 19.6% (1996 est.)
Household income or consumption by percentage share: lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1% (2000 est.)
Labor force: 1.692 million (including 352,000 emigrant workers and
261,000 domestically unemployed) (1994 est.)
Labor force - by occupation: agriculture 50%, industry and services
50%
Unemployment rate: 16% (2000 est.) officially; may be as high as 25%
Budget: revenues: $393 million
expenditures: $676 million, including capital expenditures of $NA
(1997 est.)
Industries: food processing, textiles and clothing; lumber, oil,
cement, chemicals, mining, basic metals, hydropower
Industrial production growth rate: 9% (2000 est.)
Electricity - production: 5.332 billion kWh (1999)
Electricity - production by source: fossil fuel: 3.81%
hydro: 96.19%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 5.379 billion kWh (1999)
Electricity - exports: 100 million kWh (1999)
Electricity - imports: 600 million kWh (2000)
Agriculture - products: wheat, corn, potatoes, vegetables, fruits,
sugar beets, grapes; meat, dairy products
Exports: $310 million (f.o.b., 2000 est.)
Exports - commodities: textiles and footwear; asphalt, metals and
metallic ores, crude oil; vegetables, fruits, tobacco
Exports - partners: Italy 67%, Greece 15%, Germany 5%, Austria 2%,
The Former Yugoslav Republic of Macedonia 2% (2000)
Imports: $1 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and equipment, foodstuffs,
textiles, chemicals
Imports - partners: Italy 37%, Greece 28%, Turkey 6%, Germany 6%,
Bulgaria 3% (2000)
Debt - external: $1 billion (2000)
Economic aid - recipient: $NA; aid for energy from China, Germany,
Norway (2000)
Currency: lek (ALL)
Currency code: ALL
Exchange rates: leke per US dollar - 146.08 (December 2000),143.71
(2000) 137.69 (1999), 150.63 (1998), 148.93 (1997), 104.50 (1996);
note - leke is the plural of lek
Fiscal year: calendar year
Albania Communications
Telephones - main lines in use: 87,000 (1997)
Telephones - mobile cellular: 3,100 (1999)
Telephone system: general assessment: Albania has the poorest
telephone service in Europe with fewer than two telephones per 100
inhabitants; it is doubtful that every village has telephone service
domestic: obsolete wire system; no longer provides a telephone for
every village; in 1992, following the fall of the communist
government, peasants cut the wire to about 1,000 villages and used
it to build fences
international: inadequate; international traffic carried by
microwave radio relay from the Tirana exchange to Italy and Greece
Radio broadcast stations: AM 16, FM 3, shortwave 2 (1999)
Radios: 810,000 (1997)
Television broadcast stations: 9 (plus 264 repeaters) (1995)
Televisions: 405,000 (1997)
Internet country code: .al
Internet Service Providers (ISPs): 7 (2000)
Internet users: 2,500 (2000)
Albania Transportation
Railways: total: 447 km
standard gauge: 447 km 1.435-m gauge (2001)
Highways: total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1998 est.)
Waterways: 43 km
note: includes Albanian sections of Lake Scutari, Lake Ohrid, and
Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55 km; natural gas
64 km (1991)
Ports and harbors: Durres, Sarande, Shengjin, Vlore
Merchant marine: total: 9 ships (1,000 GRT or over) totaling 17,797
GRT/26,324 DWT
ships by type: cargo 9 (2000 est.)
Airports: 11 (2000 est.)
Airports - with paved runways: total: 3
2,438 to 3,047 m: 3 (2000 est.)
Airports - with unpaved runways: total: 8
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 4 (2000 est.)
Heliports: 1 (2000 est.)
Albania Military
Military branches: Army, Navy, Air and Air Defense Forces, Interior
Ministry Troops, Border Guards
Military manpower - military age: 19 years of age
Military manpower - availability: males age 15-49: 870,768 (2001
est.)
Military manpower - fit for military service: males age 15-49:
712,763 (2001 est.)
Military manpower - reaching military age annually: males: 35,792
(2001 est.)
Military expenditures - dollar figure: $42 million (FY99)
Military expenditures - percent of GDP: 1.5% (FY99)
Albania Transnational Issues
Disputes - international: the Albanian Government supports
protection of the rights of ethnic Albanians outside of its borders
but has downplayed them to further its primary foreign policy goal
of regional cooperation; Albanian majority in Kosovo seeks
independence from Yugoslavia; Albanians in The Former Yugoslav
Republic of Macedonia claim discrimination in education, access to
public-sector jobs, and representation in government
Illicit drugs: increasingly active transshipment point for Southwest
Asian opiates, hashish, and cannabis transiting the Balkan route and
- to a far lesser extent - cocaine from South America destined for
Western Europe; limited opium and cannabis production; ethnic
Albanian narcotrafficking organizations active and rapidly expanding
in Europe
======================================================================
@Algeria
Algeria Introduction
Background: After a century of rule by France, Algeria became
independent in 1962. The surprising first round success of the
fundamentalist FIS (Islamic Salvation Front) party in December 1991
balloting caused the army to intervene, crack down on the FIS, and
postpone the subsequent elections. The FIS response has resulted in
a continuous low-grade civil conflict with the secular state
apparatus, which nonetheless has allowed elections featuring
pro-government and moderate religious-based parties. FIS''s armed
wing, the Islamic Salvation Army, disbanded itself in January 2000
and many armed militants surrendered under an amnesty program
designed to promote national reconciliation. Nevertheless, residual
fighting continues. Other concerns include large-scale unemployment
and the need to diversify the petroleum-based economy.
Algeria Geography
Location: Northern Africa, bordering the Mediterranean Sea, between
Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area: total: 2,381,740 sq km
land: 2,381,740 sq km
water: 0 sq km
Area - comparative: slightly less than 3.5 times the size of Texas
Land boundaries: total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km, Mauritania 463 km,
Morocco 1,559 km, Niger 956 km, Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims: exclusive fishing zone: 32-52 NM
territorial sea: 12 NM
Climate: arid to semiarid; mild, wet winters with hot, dry summers
along coast; drier with cold winters and hot summers on high
plateau; sirocco is a hot, dust/sand-laden wind especially common in
summer
Terrain: mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
Elevation extremes: lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore, phosphates,
uranium, lead, zinc
Land use: arable land: 3%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 2%
other: 82% (1993 est.)
Irrigated land: 5,550 sq km (1993 est.)
Natural hazards: mountainous areas subject to severe earthquakes;
mud slides
Environment - current issues: soil erosion from overgrazing and
other poor farming practices; desertification; dumping of raw
sewage, petroleum refining wastes, and other industrial effluents is
leading to the pollution of rivers and coastal waters; Mediterranean
Sea, in particular, becoming polluted from oil wastes, soil erosion,
and fertilizer runoff; inadequate supplies of potable water
Environment - international agreements: party to: Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography - note: second-largest country in Africa (after Sudan)
Algeria People
Population: 31,736,053 (July 2001 est.)
Age structure: 0-14 years: 34.21% (male 5,528,755; female 5,328,083)
15-64 years: 61.72% (male 9,901,319; female 9,687,449)
65 years and over: 4.07% (male 594,973; female 695,474) (2001 est.)
Population growth rate: 1.71% (2001 est.)
Birth rate: 22.76 births/1,000 population (2001 est.)
Death rate: 5.22 deaths/1,000 population (2001 est.)
Net migration rate: -0.45 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 40.56 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 69.95 years
male: 68.6 years
female: 71.34 years (2001 est.)
Total fertility rate: 2.72 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: 0.07% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality: noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less than 1%
Religions: Sunni Muslim (state religion) 99%, Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy: definition: age 15 and over can read and write
total population: 61.6%
male: 73.9%
female: 49% (1995 est.)
Algeria Government
Country name: conventional long form: People''s Democratic Republic
of Algeria
conventional short form: Algeria
local long form: Al Jumhuriyah al Jaza''iriyah ad Dimuqratiyah ash
Sha''biyah
local short form: Al Jaza''ir
Government type: republic
Capital: Algiers
Administrative divisions: 48 provinces (wilayas, singular - wilaya);
Adrar, Ain Defla, Ain Temouchent, Alger, Annaba, Batna, Bechar,
Bejaia, Biskra, Blida, Bordj Bou Arreridj, Bouira, Boumerdes, Chlef,
Constantine, Djelfa, El Bayadh, El Oued, El Tarf, Ghardaia, Guelma,
Illizi, Jijel, Khenchela, Laghouat, Mascara, Medea, Mila,
Mostaganem, M''Sila, Naama, Oran, Ouargla, Oum el Bouaghi, Relizane,
Saida, Setif, Sidi Bel Abbes, Skikda, Souk Ahras, Tamanghasset,
Tebessa, Tiaret, Tindouf, Tipaza, Tissemsilt, Tizi Ouzou, Tlemcen
Independence: 5 July 1962 (from France)
National holiday: Revolution Day, 1 November (1954)
Constitution: 19 November 1976, effective 22 November 1976; revised
3 November 1988, 23 February 1989, and 28 November 1996; note -
referendum approving the revisions of 28 November 1996 was signed
into law 7 December 1996
Legal system: socialist, based on French and Islamic law; judicial
review of legislative acts in ad hoc Constitutional Council composed
of various public officials, including several Supreme Court
justices; has not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch: chief of state: President Abdelaziz BOUTEFLIKA
(since 28 April 1999)
head of government: Prime Minister Ali BENFLIS (since 26 August
2000)
cabinet: Cabinet of Ministers appointed by the president
elections: president elected by popular vote for a five-year term;
election last held 15 April 1999 (next to be held NA April 2004);
prime minister appointed by the president
election results: Abdelaziz BOUTEFLIKA elected president; percent
of vote - Abdelaziz BOUTEFLIKA over 70%; note - his six opposing
candidates withdrew on the eve of the election citing electoral fraud
Legislative branch: bicameral Parliament consists of the National
People''s Assembly or Al-Majlis Ech-Chaabi Al-Watani (380 seats;
members elected by popular vote to serve five-year terms) and the
Council of Nations (144 seats; one-third of the members appointed by
the president, two-thirds elected by indirect vote; members serve
six-year terms; the constitution requires half the council to be
renewed every three years)
elections: National People''s Assembly - last held 5 June 1997 (next
to be held NA 2002); Council of Nations - last held 30 December 2000
(next to be held NA 2003)
election results: National People''s Assembly - percent of vote by
party - RND 40.8%, MSP 18.2%, FLN 16.8%, Nahda Movement 8.9%, FFS
5%, RCD 5%, PT 1.1%, Progressive Republican Party 0.8%, Union for
Democracy and Liberty 0.3%, Social Liberal Party 0.3%, independents
2.8%; seats by party - RND 155, MSP 69, FLN 64, Nahda Movement 34,
FFS 19, RCD 19, PT 4, Progressive Republican Party 3, Union for
Democracy and Liberty 1, Social Liberal Party 1, independents 11;
Council of Nations - percent of vote by party - NA%; seats by party
- RND 79, FLN 12, FFS 4, MSP 1 (remaining 48 seats appointed by the
president, party breakdown NA)
Judicial branch: Supreme Court or Cour Supreme
Political parties and leaders: Democratic National Rally or RND
[Ahmed OUYAHIA, chairman]; Islamic Salvation Front or FIS (outlawed
April 1992) [Ali BELHADJ and Dr. Abassi MADANI (imprisoned), Rabeh
KEBIR (self-exile in Germany)]; Movement of a Peaceful Society or
MSP [Mahfoud NAHNAH, chairman]; National Liberation Front or FLN
[Boualem BENHAMOUDA, secretary general]; Progressive Republican
Party [Khadir DRISS]; Rally for Culture and Democracy or RCD [Said
SAADI, secretary general]; Renaissance Movement or EnNahda Movement
[Lahbib ADAMI]; Social Liberal Party or PSL [Ahmed KHELIL];
Socialist Forces Front or FFS [Hocine Ait AHMED, secretary general
(self-exile in Switzerland)]; Union for Democracy and Liberty
[Mouley BOUKHALAFA]; Workers Party or PT [Louisa HANOUN]
note: a party law banning political parties based on religion was
enacted in March 1997
Political pressure groups and leaders: NA
International organization participation: ABEDA, AfDB, AFESD, AL,
AMF, AMU, CCC, ECA, FAO, G-15, G-19, G-24, G-77, IAEA, IBRD, ICAO,
ICC, ICF','89f7f510154ac0ae9951aecabd6662bb7b3f48c0d448ccb62f8f47b970cd28e4','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('912d5fdb9afa586efb750146e72229190eb7b5490a6bf785c0209144bb2219fd',2001,'WF','Wallis and Futuna','transportation',19,'TU, ICRM, IDA, IDB, IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, IOM, ISO, ITU, MONUC, NAM, OAPEC,
OAS (observer), OAU, OIC, OPCW, OPEC, OSCE (partner), UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UNMEE, UPU, WHO, WIPO, WMO, WToO, WTrO
(observer)
Diplomatic representation in the US: chief of mission: Ambassador
Idriss JAZAIRY
chancery: 2118 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 265-2800
FAX: [1] (202) 667-2174
Diplomatic representation from the US: chief of mission: Ambassador
Janet A. SANDERSON
embassy: 4 Chemin Cheikh Bachir El-Ibrahimi, Algiers
mailing address: B. P. Box 549, Alger-Gare, 16000 Algiers
telephone: [213] (21) 69-11-86, 69-12-55, 69-18-54, 69-38-75
FAX: [213] (21) 69-39-79
Flag description: two equal vertical bands of green (hoist side) and
white; a red, five-pointed star within a red crescent centered over
the two-color boundary; the crescent, star, and color green are
traditional symbols of Islam (the state religion)
Algeria Economy
Economy - overview: The hydrocarbons sector is the backbone of the
economy, accounting for roughly 60% of budget revenues, 30% of GDP,
and over 95% of export earnings. Algeria has the fifth-largest
reserves of natural gas in the world and is the second largest gas
exporter; it ranks fourteenth for oil reserves. Algiers'' efforts to
reform one of the most centrally planned economies in the Arab world
stalled in 1992 as the country became embroiled in political
turmoil. Algeria''s financial and economic indicators improved during
the mid-1990s, in part because of policy reforms supported by the
IMF and debt rescheduling from the Paris Club. Algeria''s finances in
2000 benefited from the spike in oil prices and the government''s
tight fiscal policy, leading to a large increase in the trade
surplus, the near tripling of foreign exchange reserves, and
reduction in foreign debt. The government continues efforts to
diversify the economy by attracting foreign and domestic investment
outside the energy sector, but has had little success in reducing
high unemployment and improving living standards.
GDP: purchasing power parity - $171 billion (2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $5,500 (2000 est.)
GDP - composition by sector: agriculture: 11%
industry: 37%
services: 52% (1999 est.)
Population below poverty line: 23% (1999 est.)
Household income or consumption by percentage share: lowest 10%:
2.8%
highest 10%: 26.8% (1995)
Inflation rate (consumer prices): 2% (2000 est.)
Labor force: 9.1 million (2000 est.)
Labor force - by occupation: government 29%, agriculture 25%,
construction and public works 15%, industry 11%, other 20% (1996
est.)
Unemployment rate: 30% (1999 est.)
Budget: revenues: $15.8 billion
expenditures: $16 billion, including capital expenditures of $5.3
billion (2001 est.)
Industries: petroleum, natural gas, light industries, mining,
electrical, petrochemical, food processing
Industrial production growth rate: 7% (1999 est.)
Electricity - production: 23.215 billion kWh (1999)
Electricity - production by source: fossil fuel: 99.14%
hydro: 0.86%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 21.613 billion kWh (1999)
Electricity - exports: 307 million kWh (1999)
Electricity - imports: 330 million kWh (1999)
Agriculture - products: wheat, barley, oats, grapes, olives, citrus,
fruits; sheep, cattle
Exports: $19.6 billion (f.o.b., 2000 est.)
Exports - commodities: petroleum, natural gas, and petroleum
products 97%
Exports - partners: Italy 22%, US 15%, France 12%, Spain 11%, Brazil
8%, Netherlands 5% (1999)
Imports: $9.2 billion (f.o.b., 2000 est.)
Imports - commodities: capital goods, food and beverages, consumer
goods
Imports - partners: France 30%, Italy 9%, Germany 7%, Spain 6%, US
5%, Turkey 5% (1999)
Debt - external: $25 billion (2000 est.)
Economic aid - recipient: $100 million (1999 est.)
Currency: Algerian dinar (DZD)
Currency code: DZD
Exchange rates: Algerian dinars per US dollar - 74,813 (January
2001), 75.260 (2000), 66.574 (1999), 58.739 (1998), 57.707 (1997),
54.749 (1996)
Fiscal year: calendar year
Algeria Communications
Telephones - main lines in use: 2.3 million (1998)
Telephones - mobile cellular: 33,500 (1999)
Telephone system: general assessment: telephone density in Algeria
is very low, not exceeding five telephones per 100 persons; the
number of fixed main lines has been increased in the last few years
to a little more than 2,000,000, but only about two-thirds of these
have subscribers; much of the infrastructure is outdated and
inefficient
domestic: good service in north but sparse in south; domestic
satellite system with 12 earth stations (20 additional domestic
earth stations are planned)
international: 5 submarine cables; microwave radio relay to Italy,
France, Spain, Morocco, and Tunisia; coaxial cable to Morocco and
Tunisia; participant in Medarabtel; satellite earth stations - 2
Intelsat (1 Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik, and
1 Arabsat (1998)
Radio broadcast stations: AM 25, FM 1, shortwave 8 (1999)
Radios: 7.1 million (1997)
Television broadcast stations: 46 (plus 216 repeaters) (1995)
Televisions: 3.1 million (1997)
Internet country code: .dz
Internet Service Providers (ISPs): 2 (2000)
Internet users: 20,000 (2000)
Algeria Transportation
Railways: total: 4,820 km
standard gauge: 3,664 km 1.435-m gauge (301 km electrified; 215 km
double track)
narrow gauge: 1,156 km 1.055-m gauge (1996)
Highways: total: 104,000 km
paved: 71,656 km (including 640 km of expressways)
unpaved: 32,344 km (1996 est.)
Waterways: none
Pipelines: crude oil 6,612 km; petroleum products 298 km; natural
gas 2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia, Beni Saf, Dellys,
Djendjene, Ghazaouet, Jijel, Mostaganem, Oran, Skikda, Tenes
Merchant marine: total: 73 ships (1,000 GRT or over) totaling
896,911 GRT/1,047,991 DWT
ships by type: bulk 9, cargo 25, chemical tanker 7, liquefied gas
10, petroleum tanker 4, roll on/roll off 13, short-sea passenger 4,
specialized tanker 1 (2000 est.)
Airports: 135 (2000 est.)
Airports - with paved runways: total: 51
over 3,047 m: 9
2,438 to 3,047 m: 24
1,524 to 2,437 m: 12
914 to 1,523 m: 5
under 914 m: 1 (2000 est.)
Airports - with unpaved runways: total: 84
2,438 to 3,047 m: 3
1,524 to 2,437 m: 23
914 to 1,523 m: 40
under 914 m: 18 (2000 est.)
Heliports: 1 (2000 est.)
Algeria Military
Military branches: National Popular Army, Navy, Air Force,
Territorial Air Defense, National Gendarmerie
Military manpower - military age: 19 years of age
Military manpower - availability: males age 15-49: 8,794,622 (2001
est.)
Military manpower - fit for military service: males age 15-49:
5,383,770 (2001 est.)
Military manpower - reaching military age annually: males: 388,939
(2001 est.)
Military expenditures - dollar figure: $1.87 billion (FY99)
Military expenditures - percent of GDP: 4.1% (FY99)
Algeria Transnational Issues
Disputes - international: part of southeastern region claimed by
Libya; Algeria supports exiled West Saharan Polisario Front and
rejects Moroccan administration of Western Sahara
======================================================================
@American Samoa
American Samoa Introduction
Background: Settled as early as 1000 B. C., Samoa was "discovered"
by European explorers in the 18th century. International rivalries
in the latter half of the 19th century were settled by an 1899
treaty in which Germany and the US divided the Samoan archipelago.
The US formally occupied its portion - a smaller group of eastern
islands with the excellent harbor of Pago Pago - the following year.
American Samoa Geography
Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 14 20 S, 170 00 W
Map references: Oceania
Area: total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area - comparative: slightly larger than Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims: exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine, moderated by southeast trade winds; annual
rainfall averages about 3 m; rainy season from November to April,
dry season from May to October; little seasonal temperature variation
Terrain: five volcanic islands with rugged peaks and limited coastal
plains, two coral atolls (Rose Island, Swains Island)
Elevation extremes: lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use: arable land: 5%
permanent crops: 10%
permanent pastures: 0%
forests and woodland: 70%
other: 15% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons common from December to March
Environment - current issues: limited natural fresh water resources;
the water division of the government has spent substantial funds in
the past few years to improve water catchments and pipelines
Geography - note: Pago Pago has one of the best natural deepwater
harbors in the South Pacific Ocean, sheltered by shape from rough
seas and protected by peripheral mountains from high winds;
strategic location in the South Pacific Ocean
American Samoa People
Population: 67,084 (July 2001 est.)
Age structure: 0-14 years: 38.44% (male 13,278; female 12,512)
15-64 years: 56.57% (male 18,784; female 19,163)
65 years and over: 4.99% (male 1,779; female 1,568) (2001 est.)
Population growth rate: 2.42% (2001 est.)
Birth rate: 24.88 births/1,000 population (2001 est.)
Death rate: 4.31 deaths/1,000 population (2001 est.)
Net migration rate: 3.58 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 10.36 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 75.32 years
male: 70.89 years
female: 80.02 years (2001 est.)
Total fertility rate: 3.5 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality: noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%, Caucasian 2%, Tongan 4%,
other 5%
Religions: Christian Congregationalist 50%, Roman Catholic 20%,
Protestant and other 30%
Languages: Samoan (closely related to Hawaiian and other Polynesian
languages), English
note: most people are bilingual
Literacy: definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 97% (1980 est.)
American Samoa Government
Country name: conventional long form: Territory of American Samoa
conventional short form: American Samoa
abbreviation: AS
Dependency status: unincorporated and unorganized territory of the
US; administered by the Office of Insular Affairs, US Department of
the Interior
Government type: NA
Capital: Pago Pago
Administrative divisions: none (territory of the US); there are no
first-order administrative divisions as defined by the US
Government, but there are three districts and two islands* at the
second order; Eastern, Manu''a, Rose Island*, Swains Island*, Western
Independence: none (territory of the US)
National holiday: Flag Day, 17 April (1900)
Constitution: ratified 1966, in effect 1967
Legal system: NA
Suffrage: 18 years of age; universal
Executive branch: chief of state: President George W. BUSH of the
US (since 20 January 2001) and Vice President Richard B. CHENEY
(since 20 January 2001)
head of government: Governor Tauese P. SUNIA (since 3 January 1997)
and Lieutenant Governor Togiola TULAFONO (since 3 January 1997)
cabinet: NA
elections: US president and vice president elected on the same
ticket for four-year terms; governor and lieutenant governor elected
on the same ticket by popular vote for four-year terms; election
last held 7 November 2000 (next to be held NA November 2004)
election results: Tauese P. SUNIA reelected governor; percent of
vote - Tauese P. SUNIA (Democrat) 50.7%, Lealaifuaneva Peter REID
(independent) 47.8%
Legislative branch: bicameral Fono or Legislative Assembly consists
of the House of Representatives (21 seats - 20 of which are elected
by popular vote and 1 is an appointed, nonvoting delegate from
Swains Island; members serve two-year terms) and the Senate (18
seats; members are elected from local chiefs and serve four-year
terms)
elections: House of Representatives - last held 7 November 2000
(next to be held NA November 2002); Senate - last held 7 November
2000 (next to be held NA November 2004)
election results: House of Representatives - percent of vote by
party - NA%; seats by party - NA; Senate - percent of vote by party
- NA%; seats by party - NA; note - only independents elected
note: American Samoa elects one delegate to the US House of
Representatives; election last held 7 November 2000 (next to be held
NA November 2002); results - Eni F. H. FALEOMAVAEGA (Democrat)
reelected as delegate for a sixth term
Judicial branch: High Court (chief justice and associate justices
are appointed by the US Secretary of the Interior)
Political parties and leaders: Democratic Party [leader NA];
Republican Party [leader NA]
Political pressure groups and leaders: NA
International organization participation: ESCAP (associate),
Interpol (subbureau), IOC, SPC
Diplomatic representation in the US: none (territory of the US)
Diplomatic representation from the US: none (territory of the US)
Flag description: blue, with a white triangle edged in red that is
based on the outer side and extends to the hoist side; a brown and
white American bald eagle flying toward the hoist side is carrying
two traditional Samoan symbols of authority, a staff and a war club
American Samoa Economy
Economy - overview: This is a traditional Polynesian economy in
which more than 90% of the land is communally owned. Economic
activity is strongly linked to the US, with which American Samoa
conducts the great bulk of its foreign trade. Tuna fishing and tuna
processing plants are the backbone of the private sector, with
canned tuna the primary export. Transfers from the US Government add
substantially to American Samoa''s economic well-being. Attempts by
the government to develop a larger and broader economy are
restrained by Samoa''s remote location, its limited transportation,
and its devastating hurricanes. Tourism, a developing sector, has
been held back by the recurring financial difficulties in East Asia.
GDP: purchasing power parity - $500 million (2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $8,000 (2000 est.)
GDP - composition by sector: agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage share: lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 14,000 (1996)
Labor force - by occupation: government 33%, tuna canneries 34%,
other 33% (1990)
Unemployment rate: 16% (1993)
Budget: revenues: $121 million (37% in local revenue and 63% in US
grants)
expenditures: $127 million, including capital expenditures of $NA
(FY96/97)
Industries: tuna canneries (largely dependent on foreign fishing
vessels), handicrafts
Industrial production growth rate: NA%
Electricity - production: 130 million kWh (1999)
Electricity - production by source: fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 120.9 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, coconuts, vegetables, taro,
breadfruit, yams, copra, pineapples, papayas; dairy products,
livestock
Exports: $500 million (1998)
Exports - commodities: canned tuna 93%
Exports - partners: US 99.6%
Imports: $471 million (1996)
Imports - commodities: materials for canneries 56%, food 8%,
petroleum products 7%, machinery and parts 6%
Imports - partners: US 62%, Japan 9%, NZ 7%, Australia 11%, Fiji 4%,
other 7%
Debt - external: $NA
Economic aid - recipient: important financial support from the US,
more than $40 million in 1994
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September
American Samoa Communications
Telephones - main lines in use: 13,000 (1997)
Telephones - mobile cellular: 2,550 (1997)
Telephone system: general assessment: NA
domestic: good telex, telegraph, facsimile and cellular telephone
services; domestic satellite system with 1 Comsat earth station
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0 (1998)
Radios: 57,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 14,000 (1997)
Internet country code: .as
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
American Samoa Transportation
Railways: 0 km
Highways: total: 350 km
paved: 150 km
unpaved: 200 km
Waterways: none
Ports and harbors: Aunu''u (new construction), Auasi, Faleosao, Ofu,
Pago Pago, Ta''u
Merchant marine: none (2000 est.)
Airports: 4 (2000 est.)
Airports - with paved runways: total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2000 est.)
Airports - with unpaved runways: total: 2
under 914 m: 2 (2000 est.)
American Samoa Military
Military - note: defense is the responsibility of the US
American Samoa Transnational Issues
Disputes - international: none
======================================================================
@Andorra
Andorra Introduction
Background: Long isolated and impoverished, mountainous Andorra has
achieved considerable prosperity since World War II through its
tourist industry. Many immigrants (legal and illegal) are attracted
to the thriving economy with its lack of income taxes.
Andorra Geography
Location: Southwestern Europe, between France and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area: total: 468 sq km
land: 468 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of Washington, DC
Land boundaries: total: 120.3 km
border countries: France 56.6 km, Spain 63.7 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm, dry summers
Terrain: rugged mountains dissected by narrow valleys
Elevation extremes: lowest point: Riu Runer 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water, timber, iron ore, lead
Land use: arable land: 4%
permanent crops: 0%
permanent pastures: 45%
forests and woodland: 35%
other: 16% (1998 est.)
Irrigated land: NA sq km
Natural hazards: snowslides, avalanches
Environment - current issues: deforestation; overgrazing of mountain
meadows contributes to soil erosion; air pollution; wastewater
treatment and solid waste disposal
Environment - international agreements: party to: Hazardous Wastes
signed, but not ratified: none of the selected agreements
Geography - note: landlocked
Andorra People
Population: 67,627 (July 2001 est.)
Age structure: 0-14 years: 15.29% (male 5,425; female 4,917)
15-64 years: 72.06% (male 25,654; female 23,078)
65 years and over: 12.65% (male 4,299; female 4,254) (2001 est.)
Population growth rate: 1.17% (2001 est.)
Birth rate: 10.29 births/1,000 population (2001 est.)
Death rate: 5.41 deaths/1,000 population (2001 est.)
Net migration rate: 6.82 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.07 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1.01 male(s)/female
total population: 1.1 male(s)/female (2001 est.)
Infant mortality rate: 4.08 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 83.47 years
male: 80.57 years
female: 86.57 years (2001 est.)
Total fertility rate: 1.25 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality: noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 43%, Andorran 33%, Portuguese 11%, French 7%,
other 6% (1998)
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy: definition: NA
total population: 100%
male: NA%
female: NA%
Andorra Government
Country name: conventional long form: Principality of Andorra
conventional short form: Andorra
local long form: Principat d''Andorra
local short form: Andorra
Government type: parliamentary democracy (since March 1993) that
retains as its heads of state a coprincipality; the two princes are
the president of France and bishop of Seo de Urgel, Spain, who are
represented locally by coprinces'' representatives
Capital: Andorra la Vella
Administrative divisions: 7 parishes (parroquies, singular -
parroquia); Andorra la Vella, Canillo, Encamp, La Massana,
Escaldes-Engordany, Ordino, Sant Julia de Loria
Independence: 1278 (was formed under the joint suzerainty of France
and Spain)
National holiday: Our Lady of Meritxell Day, 8 September (1278)
Constitution: Andorra''s first written constitution was drafted in
1991; approved by referendum 14 March 1993; came into force 4 May
1993
Legal system: based on French and Spanish civil codes; no judicial
review of legislative acts; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch: chief of state: French Coprince Jacques CHIRAC
(since 17 May 1995), represented by Frederic de SAINT-SERNIN (since
NA); Spanish Coprince Episcopal Monseigneur Joan MARTI Alanis (since
31 January 1971), represented by Nemesi MARQUES OSTE (since NA)
head of government: Executive Council President Marc FORNE Molne
(since 21 December 1994)
cabinet: Executive Council or Govern designated by the Executive
Council president
elections: Executive Council president elected by the General
Council and formally appointed by the coprinces for a four-year
term; election last held 16 February 1997 (next to be held NA 2001)
election results: Marc FORNE Molne elected executive council
president; percent of General Council vote - 64%
Legislative branch: unicameral General Council of the Valleys or
Consell General de las Valls (28 seats; members are elected by
direct popular vote, 14 from a single national constituency and 14
to represent each of the 7 parishes; members serve four-year terms)
elections: last held 16 February 1997 (next to be held NA February
2001)
election results: percent of vote by party - UL 57%, AND 21%, IDN
7%, ND 7%, other 8%; seats by party - UL 16, AND 6, ND 2, IDN 2, UPO
2
Judicial branch: Tribunal of Judges or Tribunal de Batlles; Tribunal
of the Courts or Tribunal de Corts; Supreme Court of Justice of
Andorra or Tribunal Superior de Justicia d''Andorra; Supreme Council
of Justice or Consell Superior de la Justicia; Fiscal Ministry or
Ministeri Fiscal; Constitutional Tribunal or Tribunal Constitucional
Political parties and leaders: Liberal Union or UL [Marc Forne
MOLNE] (renamed Liberal Party of Andorra or PLA); National
Democratic Group or AND [Ladislau BARO SOLA]; National Democratic
Initiative or IDN [Vincenc MATEU Zamora]; New Democracy or ND [Jaume
BARTOMEU Cassany]; Union of the People of Ordino (Unio Parroquial
d''Ordino) or UPO [Simo DURO Coma]
note: there are two other small parties
Political pressure groups and leaders: NA
International organization participation: CCC, CE, ECE, ICAO, ICRM,
IFRCS, Interpol, IOC, ITU, OSCE, UN, UNESCO, WHO, WIPO, WToO, WTrO
(observer)
Diplomatic representation in the US: chief of mission: Ambassador
(vacant)
chancery: 2 United Nations Plaza, 25th Floor, New York, NY 10017
telephone: [1] (212) 750-8064
FAX: [1] (212) 750-6630
Diplomatic representation from the US: the US does not have an
embassy in Andorra; the US Ambassador to Spain is accredited to
Andorra; US interests in Andorra are represented by the Consulate
General''s office in Barcelona (Spain); mailing address: Paseo Reina
Elisenda, 23, 08034 Barcelona, Spain; telephone: (3493) 280-2227;
FAX: (3493) 205-7705
Flag description:','ecfc8c6347a14667624ddbed64fb13dfc3201625ef48cfd0a8608c0b63221a3c','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('790c3fd927d4bfb9f79e1ed60272953b1560b492d9e83d59fa4030395699cc24',2001,'WF','Wallis and Futuna','transportation',20,'three equal vertical bands of blue (hoist side),
yellow, and red with the national coat of arms centered in the
yellow band; the coat of arms features a quartered shield; similar
to the flags of Chad and Romania, which do not have a national coat
of arms in the center, and the flag of Moldova, which does bear a
national emblem
Andorra Economy
Economy - overview: Tourism, the mainstay of Andorra''s tiny,
well-to-do economy, accounts for roughly 80% of GDP. An estimated 9
million tourists visit annually, attracted by Andorra''s duty-free
status and by its summer and winter resorts. Andorra''s comparative
advantage has recently eroded as the economies of neighboring France
and Spain have been opened up, providing broader availability of
goods and lower tariffs. The banking sector, with its "tax haven"
status, also contributes substantially to the economy. Agricultural
production is limited by a scarcity of arable land, and most food
has to be imported. The principal livestock activity is sheep
raising. Manufacturing output consists mainly of cigarettes, cigars,
and furniture. Andorra is a member of the EU Customs Union and is
treated as an EU member for trade in manufactured goods (no tariffs)
and as a non-EU member for agricultural products.
GDP: purchasing power parity - $1.2 billion (1996 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $18,000 (1996 est.)
GDP - composition by sector: agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage share: lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1.62% (1998)
Labor force: 30,787 salaried employees (1998)
Labor force - by occupation: agriculture 1%, industry 21%, services
78% (1998)
Unemployment rate: 0%
Budget: revenues: $385 million
expenditures: $342 million, including capital expenditures of $NA
(1997)
Industries: tourism (particularly skiing), cattle raising, timber,
tobacco, banking
Industrial production growth rate: NA%
Electricity - production by source: fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
note: most electricity supplied by Spain and France; Andorra
generates a small amount of hydropower
Agriculture - products: small quantities of tobacco, rye, wheat,
barley, oats, vegetables; sheep
Exports: $58 million (f.o.b., 1998)
Exports - commodities: tobacco products, furniture
Exports - partners: France 34%, Spain 58% (1998)
Imports: $1.077 billion (c.i.f., 1998)
Imports - commodities: consumer goods, food, electricity
Imports - partners: Spain 48%, France 35%, US 2.3% (1998)
Debt - external: $NA
Economic aid - recipient: none
Currency: French franc (FRF); Spanish peseta (ESP); euro (EUR)
Currency code: FRF; ESP; EUR
Exchange rates: euros per US dollar - 1.0659 (January 2001), 1.0854
(2000), 0.9386 (1999); French francs per US dollar - 5.8995 (1998),
5.8367 (1997), 5.1155 (1996); Spanish pesetas per US dollar - 149.40
(1998), 146.41 (1997), 126.66 (1996)
Fiscal year: calendar year
Andorra Communications
Telephones - main lines in use: 32,946 (December 1998)
Telephones - mobile cellular: 14,117 (December 1998)
Telephone system: general assessment: NA
domestic: modern system with microwave radio relay connections
between exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 0, FM 15, shortwave 0 (1998)
Radios: 16,000 (1997)
Television broadcast stations: 0 (1997)
Televisions: 27,000 (1997)
Internet country code: .ad
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000 (2000)
Andorra Transportation
Railways: 0 km
Highways: total: 269 km
paved: 198 km
unpaved: 71 km (1994 est.)
Waterways: none
Ports and harbors: none
Airports: none (2000 est.)
Andorra Military
Military - note: defense is the responsibility of France and Spain
Andorra Transnational Issues
Disputes - international: none
======================================================================
@Angola
Angola Introduction
Background: Civil war has been the norm in Angola since independence
from Portugal in 1975. A 1994 peace accord between the government
and the National Union for the Total Independence of Angola (UNITA)
provided for the integration of former UNITA insurgents into the
government and armed forces. A national unity government was
installed in April of 1997, but serious fighting resumed in late
1998, rendering hundreds of thousands of people homeless. Up to 1.5
million lives may have been lost in fighting over the past quarter
century.
Angola Geography
Location: Southern Africa, bordering the South Atlantic Ocean,
between Namibia and Democratic Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area: total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size of Texas
Land boundaries: total: 5,198 km
border countries: Democratic Republic of the Congo 2,511 km (of
which 220 km is the boundary of discontiguous Cabinda Province),
Republic of the Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims: contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: semiarid in south and along coast to Luanda; north has
cool, dry season (May to October) and hot, rainy season (November to
April)
Terrain: narrow coastal plain rises abruptly to vast interior plateau
Elevation extremes: lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore, phosphates,
copper, feldspar, gold, bauxite, uranium
Land use: arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other: 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes periodic flooding on
the plateau
Environment - current issues: overuse of pastures and subsequent
soil erosion attributable to population pressures; desertification;
deforestation of tropical rain forest, in response to both
international demand for tropical timber and to domestic use as
fuel, resulting in loss of biodiversity; soil erosion contributing
to water pollution and siltation of rivers and dams; inadequate
supplies of potable water
Environment - international agreements: party to: Biodiversity,
Climate Change, Desertification, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
Geography - note: Cabinda is separated from rest of country by the
Democratic Republic of the Congo
Angola People
Population: 10,366,031 (July 2001 est.)
Age structure: 0-14 years: 43.31% (male 2,266,870; female 2,222,262)
15-64 years: 53.98% (male 2,847,089; female 2,748,091)
65 years and over: 2.71% (male 127,798; female 153,921) (2001 est.)
Population growth rate: 2.15% (2001 est.)
Birth rate: 46.54 births/1,000 population (2001 est.)
Death rate: 24.68 deaths/1,000 population (2001 est.)
Net migration rate: -0.34 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1.02 male(s)/female (2001 est.)
Infant mortality rate: 193.72 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 38.59 years
male: 37.36 years
female: 39.87 years (2001 est.)
Total fertility rate: 6.48 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: 2.78% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 160,000 (1999 est.)
HIV/AIDS - deaths: 15,000 (1999 est.)
Nationality: noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%, Bakongo 13%, mestico
(mixed European and Native African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic 38%, Protestant
15% (1998 est.)
Languages: Portuguese (official), Bantu and other African languages
Literacy: definition: age 15 and over can read and write
total population: 42%
male: 56%
female: 28% (1998 est.)
Angola Government
Country name: conventional long form: Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People''s Republic of Angola
Government type: transitional government, nominally a multiparty
democracy with a strong presidential system
Capital: Luanda
Administrative divisions: 18 provinces (provincias, singular -
provincia); Bengo, Benguela, Bie, Cabinda, Cuando Cubango, Cuanza
Norte, Cuanza Sul, Cunene, Huambo, Huila, Luanda, Lunda Norte, Lunda
Sul, Malanje, Moxico, Namibe, Uige, Zaire
Independence: 11 November 1975 (from Portugal)
National holiday: Independence Day, 11 November (1975)
Constitution: 11 November 1975; revised 7 January 1978, 11 August
1980, 6 March 1991, and 26 August 1992
Legal system: based on Portuguese civil law system and customary
law; recently modified to accommodate political pluralism and
increased use of free markets
Suffrage: 18 years of age; universal
Executive branch: chief of state: President Jose Eduardo DOS SANTOS
(since 21 September 1979); note - the president is both chief of
state and head of government
head of government: President Jose Eduardo DOS SANTOS (since 21
September 1979); note - the president is both chief of state and
head of government
cabinet: Council of Ministers appointed by the president
elections: President DOS SANTOS originally elected (in 1979)
without opposition under a one-party system and stood for reelection
in Angola''s first multiparty elections 29-30 September 1992 (next to
be held NA)
election results: DOS SANTOS 49.6%, Jonas SAVIMBI 40.1%, making a
run-off election necessary; the run-off was not held and SAVIMBI''s
National Union for the Total Independence of Angola (UNITA)
repudiated the results of the first election; the civil war resumed
Legislative branch: unicameral National Assembly or Assembleia
Nacional (220 seats; members elected by proportional vote to serve
four-year terms)
elections: last held 29-30 September 1992 (next to be held NA)
election results: percent of vote by party - MPLA 54%, UNITA 34%,
others 12%; seats by party - MPLA 129, UNITA 70, PRS 6, FNLA 5, PLD
3, others 7
Judicial branch: Supreme Court or Tribunal da Relacao (judges are
appointed by the president)
Political parties and leaders: Liberal Democratic Party or PLD
[Analia de Victoria PEREIRA]; National Front for the Liberation of
Angola or FNLA [disputed leadership: Lucas NGONDA, Holden ROBERTO];
National Union for the Total Independence of Angola or UNITA [Jonas
SAVIMBI], largest opposition party has engaged in years of armed
resistance; Popular Movement for the Liberation of Angola or MPLA
[Jose Eduardo DOS SANTOS] ruling party in power since 1975; Social
Renewal Party or PRS [disputed leadership: Eduardo KUANGANA, Antonio
MUACHICUNGO]; UNITA-Renovada [Eugenio NGOLO "Manuvakola", leader]
note: about a dozen minor parties participated in the 1992
elections but won few seats and have little influence in the
National Assembly
Political pressure groups and leaders: Front for the Liberation of
the Enclave of Cabinda or FLEC [N''zita Henriques TIAGO; Antonio
Bento BEMBE]
note: FLEC is waging a small-scale, highly factionalized, armed
struggle for the independence of Cabinda Province
International organization participation: ACP, AfDB, CCC, CEEAC,
ECA, FAO, G-77, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat, Interpol, IOC, IOM, ITU, NAM, OAS
(observer), OAU, SADC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WIPO, WMO, WToO, WTrO
Diplomatic representation in the US: chief of mission: Ambassador
Josefina Perpetua Pitra DIAKIDI
chancery: 1615 M Street, NW, Suite 900, Washington, DC 20036
telephone: [1] (202) 785-1156
FAX: [1] (202) 785-1258
consulate(s) general: New York
Diplomatic representation from the US: chief of mission: Ambassador
Joseph G. SULLIVAN
embassy: number 32 Rua Houari Boumeddienne, Luanda
mailing address: international mail: Caixa Postal 6484, Luanda;
pouch: American Embassy Luanda, Department of State, Washington, DC
20521-2550
telephone: [244] (2) 345-481, 346-418
FAX: [244] (2) 346-924
Flag description: two equal horizontal bands of red (top) and black
with a centered yellow emblem consisting of a five-pointed star
within half a cogwheel crossed by a machete (in the style of a
hammer and sickle)
Angola Economy
Economy - overview: Angola is an economy in disarray because of a
quarter century of nearly continuous warfare. Despite its abundant
natural resources, output per capita is among the world''s lowest.
Subsistence agriculture provides the main livelihood for 85% of the
population. Oil production and the supporting activities are vital
to the economy, contributing about 45% to GDP and 90% of exports.
Violence continues, millions of land mines remain, and many farmers
are reluctant to return to their fields. As a result, much of the
country''s food must still be imported. To fully take advantage of
its rich resources - gold, diamonds, extensive forests, Atlantic
fisheries, and large oil deposits - Angola will need to end its
conflict and continue reforming government policies. Despite the
increase in the pace of civil warfare in late 1998, the economy grew
by an estimated 5% in 2000. The government introduced new currency
denominations in 1999, including 1 and 5 kwanza notes. Internal
strife discourages investment outside of the petroleum sector, which
is producing roughly 800,000 barrels of oil per day. Angola has
entered into a Staff Monitored Program (SMP) with the IMF. Continued
growth depends on sharp cuts in inflation, further economic reform,
and a lessening of fighting.
GDP: purchasing power parity - $10.1 billion (2000 est.)
GDP - real growth rate: 4.9% (2000 est.)
GDP - per capita: purchasing power parity - $1,000 (2000 est.)
GDP - composition by sector: agriculture: 7%
industry: 60%
services: 33% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage share: lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 325% (2000 est.)
Labor force: 5 million (1997 est.)
Labor force - by occupation: agriculture 85%, industry and services
15% (1997 est.)
Unemployment rate: extensive unemployment and underemployment
affecting more than half the population (2000 est.)
Budget: revenues: $928 million
expenditures: $2.5 billion, including capital expenditures of $963
million (1992 est.)
Industries: petroleum; diamonds, iron ore, phosphates, feldspar,
bauxite, uranium, and gold; cement; basic metal products; fish
processing; food processing; brewing; tobacco products; sugar;
textiles
Industrial production growth rate: NA%
Electricity - production: 1.475 billion kWh (1999)
Electricity - production by source: fossil fuel: 32.2%
hydro: 67.8%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 1.372 billion kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: bananas, sugarcane, coffee, sisal, corn,
cotton, manioc (tapioca), tobacco, vegetables, plantains; livestock;
forest products; fish
Exports: $7.8 billion (f.o.b., 2000 est.)
Exports - commodities: crude oil 90%, diamonds, refined petroleum
products, gas, coffee, sisal, fish and fish products, timber, cotton
Exports - partners: US 54%, South Korea 14%, Benelux 11%, China 7%,
Taiwan 6% (1999)
Imports: $2.5 billion (f.o.b., 2000 est.)
Imports - commodities: machinery and electrical equipment, vehicles
and spare parts; medicines, food, textiles, military goods
Imports - partners: South Korea 16%, Portugal 15%, US 13%, South
Africa 10%, France 8% (1999)
Debt - external: $10.8 billion (2000 est.)
Economic aid - recipient: $493.1 million (1995)
Currency: kwanza (AOA)
Currency code: AOA
Exchange rates: kwanza per US dollar - 17,910,800 (January 2001),
10,041,000 (2000), 2,790,706 (1999), 392,824 (1998), 229,040 (1997),
128,029 (1996); note - in December 1999 the kwanza was revalued with
six zeroes dropped off the old value
Fiscal year: calendar year
Angola Communications
Telephones - main lines in use: 62,000 (1997)
Telephones - mobile cellular: 7,052 (1997)
Telephone system: general assessment: telephone service limited
mostly to government and business use; HF radiotelephone used
extensively for military links
domestic: limited system of wire, microwave radio relay, and
tropospheric scatter
international: satellite earth stations - 2 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 34, FM 7, shortwave 9 (1999)
Radios: 630,000 (1997)
Television broadcast stations: 7 (1999)
Televisions: 150,000 (1997)
Internet country code: .ao
Internet Service Providers (ISPs): 1 (2000)
Internet users: 12,000 (1999)
Angola Transportation
Railways: total: 2,771 km (inland, much of the track is unusable
because of land mines still in place from the civil war)
narrow gauge: 2,648 km 1.067-m gauge; 123 km 0.600-m gauge (2000)
Highways: total: 76,626 km
paved: 19,156 km
unpaved: 57,470 km (1997)
Waterways: 1,295 km
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito, Luanda, Malongo,
Mocamedes, Namibe, Porto Amboim, Soyo
Merchant marine: total: 9 ships (1,000 GRT or over) totaling 39,305
GRT/63,067 DWT
ships by type: cargo 8, petroleum tanker 1 (2000 est.)
Airports: 247 (2000 est.)
Airports - with paved runways: total: 31
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 12
914 to 1,523 m: 6
under 914 m: 1 (2000 est.)
Airports - with unpaved runways: total: 216
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 30
914 to 1,523 m: 96
under 914 m: 83 (2000 est.)
Angola Military
Military branches: Army, Navy, Air and Air Defense Forces, National
Police Force
Military manpower - military age: 18 years of age
Military manpower - availability: males age 15-49: 2,480,016 (2001
est.)
Military manpower - fit for military service: males age 15-49:
1,246,224 (2001 est.)
Military manpower - reaching military age annually: males: 103,807
(2001 est.)
Military expenditures - dollar figure: $1.2 billion (FY97)
Military expenditures - percent of GDP: 22% (1999)
Angola Transnational Issues
Disputes - international: none
Illicit drugs: increasingly used as a transshipment point for
cocaine and heroin destined for Western Europe and other African
states
======================================================================
@Anguilla
Anguilla Introduction
Background: Colonized by English settlers from Saint Kitts in 1650,
Anguilla was administered by Great Britain until the early 19th
century, when the island - against the wishes of the inhabitants -
was incorporated into a single British dependency along with Saint
Kitts and Nevis. Several attempts at separation failed. In 1971, two
years after a revolt, Anguilla was finally allowed to secede; this
arrangement was formally recognized in 1980 with Anguilla becoming a
separate British dependency.
Anguilla Geography
Location: Caribbean, island in the Caribbean Sea, east of Puerto Rico
Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the Caribbean
Area: total: 91 sq km
land: 91 sq km
water: 0 sq km
Area - comparative: about half the size of Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims: exclusive fishing zone: 200 NM
territorial sea: 3 NM
Climate: tropical; moderated by northeast trade winds
Terrain: flat and low-lying island of coral and limestone
Elevation extremes: lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use: arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly rock with sparse scrub oak, few trees, some
commercial salt ponds)
Irrigated land: NA sq km
Natural hazards: frequent hurricanes and other tropical storms (July
to October)
Environment - current issues: supplies of potable water sometimes
cannot meet increasing demand largely because of poor distribution
system
Anguilla People
Population: 12,132 (July 2001 est.)
Age structure: 0-14 years: 25.55% (male 1,574; female 1,526)
15-64 years: 67.47% (male 4,200; female 3,985)
65 years and over: 6.98% (male 376; female 471) (2001 est.)
Population growth rate: 2.68% (2001 est.)
Birth rate: 15.17 births/1,000 population (2001 est.)
Death rate: 5.61 deaths/1,000 population (2001 est.)
Net migration rate: 17.23 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1.03 male(s)/female (2001 est.)
Infant mortality rate: 24.56 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 76.31 years
male: 73.41 years
female: 79.29 years (2001 est.)
Total fertility rate: 1.79 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality: noun: Anguillan(s)
adjective: Anguillan
Ethnic groups: black
Religions: Anglican 40%, Methodist 33%, Seventh-Day Adventist 7%,
Baptist 5%, Roman Catholic 3%, other 12%
Languages: English (official)
Literacy: definition: age 12 and over can read and write
total population: 95%
male: 95%
female: 95% (1984 est.)
Anguilla Government
Country name: conventional long form: none
conventional short form: Anguilla
Dependency status: overseas territory of the UK
Government type: NA
Capital: The Valley
Administrative divisions: none (overseas territory of the UK)
Independence: none (overseas territory of the UK)
National holiday: Anguilla Day, 30 May
Constitution: Anguilla Constitutional Order 1 April 1982; amended
1990
Legal system: based on English common law
Suffrage: 18 years of age; universal
Executive branch: chief of state: Queen ELIZABETH II (since 6
February 1952); represented by Governor Peter JOHNSTON (since NA
February 2000)
head of government: Chief Minister Osbourne FLEMING (since 3 March
2000)
cabinet: Executive Council appointed by the governor from among the
elected members of the House of Assembly
elections: none; the monarch is hereditary; governor appointed by
the monarch; chief minister appointed by the governor from among the
members of the House of Assembly
Legislative branch: unicameral House of Assembly (11 seats total, 7
elected by direct popular vote, 2 ex officio members and 2
appointed; members serve five-year terms)
elections: last held 3 March 2000 (next to be held NA March 2005)
election results: percent of vote by party - NA%; seats by party -
UF 4, AUM 2, independent 1
Judicial branch: High Court (judge provided by Eastern Caribbean
Supreme Court)
Political parties and leaders: Anguilla United Movement or AUM
[Hubert HUGHES]; The United Front or UF [Osbourne FLEMMING, Victor
BANKS], a coalition of the Anguilla Democratic Party or ADP and the
Anguilla National Alliance or ANA
Political pressure groups and leaders: NA
International organization participation: Caricom (associate), CDB,
Interpol (subbureau), OECS (associate), ECLAC (associate)
Diplomatic representation in the US: none (overseas territory of the
UK)
Diplomatic representation from the US: none (overseas territory of
the UK)
Flag description: blue, with the flag of the UK in the upper
hoist-side quadrant and the Anguillan coat of arms centered in the
outer half of the flag; the coat of arms depicts three orange
dolphins in an interlocking circular design on a white background
with blue wavy water below
Anguilla Economy
Economy - overview: Anguilla has few natural resources, and the
economy depends heavily on luxury tourism, offshore banking, lobster
fishing, and remittances from emigrants. The economy, and especially
the tourism sector, suffered a setback in late 1995 due to the
effects of Hurricane Luis in September but recovered in 1996.
Increased activity in the tourism industry, which has spurred the
growth of the construction sector, has contributed to economic
grow','a1d867c62a42ec889f987cdcf7cf22663f168b9cc964c53c930dd83636271cdc','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7fc260fca7aa5617632f1c2a1c484d75c72ecc7938107b511bc6fa0acec32ea',2001,'WF','Wallis and Futuna','transportation',21,'th. Anguillan officials have put substantial effort into
developing the offshore financial sector. A comprehensive package of
financial services legislation was enacted in late 1994. In the
medium term, prospects for the economy will depend on the tourism
sector and, therefore, on continuing income growth in the
industrialized nations as well as favorable weather conditions.
GDP: purchasing power parity - $96 million (1999 est.)
GDP - real growth rate: 7% (1999 est.)
GDP - per capita: purchasing power parity - $8,200 (1999 est.)
GDP - composition by sector: agriculture: 4%
industry: 18%
services: 78% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage share: lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.5% (1998 est.)
Labor force: 4,400 (1992)
Labor force - by occupation: commerce 36%, services 29%,
construction 18%, transportation and utilities 10%, manufacturing
3%, agriculture/fishing/forestry/mining 4%
Unemployment rate: 7% (1992 est.)
Budget: revenues: $20.4 million
expenditures: $23.3 million, including capital expenditures of $3.8
million (1997 est.)
Industries: tourism, boat building, offshore financial services
Industrial production growth rate: 3.1% (1997 est.)
Electricity - production: NA kWh
Electricity - production by source: fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Agriculture - products: small quantities of tobacco, vegetables;
cattle raising
Exports: $4.5 million (1998)
Exports - commodities: lobster, fish, livestock, salt
Exports - partners: NA
Imports: $57.6 million (1998)
Imports - commodities: NA
Imports - partners: NA
Debt - external: $8.8 million (1998)
Economic aid - recipient: $3.5 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US dollar - 2.7000 (fixed
rate since 1976)
Fiscal year: 1 April - 31 March
Anguilla Communications
Telephones - main lines in use: 5,000 (1997)
Telephones - mobile cellular: NA
Telephone system: general assessment: NA
domestic: modern internal telephone system
international: microwave radio relay to island of Saint Martin
(Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 5, FM 6, shortwave 1 (1998)
Radios: 3,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 1,000 (1997)
Internet country code: .ai
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA
Anguilla Transportation
Railways: 0 km
Highways: total: 279 km
paved: 253 km
unpaved: 26 km (1998 est.)
Waterways: none
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways: total: 1
914 to 1,523 m: 1 (2000 est.)
Airports - with unpaved runways: total: 2
under 914 m: 2 (2000 est.)
Anguilla Military
Military - note: defense is the responsibility of the UK
Anguilla Transnational Issues
Disputes - international: none
Illicit drugs: transshipment point for South American narcotics
destined for the US and Europe
======================================================================
@Antarctica
Antarctica Introduction
Background: Speculation over the existence of a "southern land" was
not confirmed until the early 1820s when British and American
commercial operators and British and Russian national expeditions
began exploring the Peninsula region and areas south of the
Antarctic Circle. Not until 1838 was it established that Antarctica
was indeed a continent and not just a group of islands. Various
"firsts" were achieved in the early 20th century, including: 1902,
first balloon flight (by British explorer Robert Falcon SCOTT);
1912, first to the South Pole (five Norwegian explorers under Roald
AMUNDSEN); 1928, first fixed-wing aircraft flight (by Australian
adventurer/explorer Sir Hubert WILKINS); 1929, first flight over the
South Pole (by Americans Richard BYRD and Bernt BALCHEN); and 1935,
first transantarctic flight (American Lincoln ELLSWORTH). Following
World War II, there was an upsurge in scientific research on the
continent. A number of countries have set up year-round research
stations on Antarctica. Seven have made territorial claims, but no
other country recognizes these claims. In order to form a legal
framework for the activities of nations on the continent, an
Antarctic Treaty was negotiated that neither denies nor gives
recognition to existing territorial claims; signed in 1959, it
entered into force in 1961.
Antarctica Geography
Location: continent mostly south of the Antarctic Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area: total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72 million sq km
ice-covered) (est.)
note: fifth-largest continent, following Asia, Africa, North
America, and South America, but larger than Australia and the
subcontinent of Europe
Area - comparative: slightly less than 1.5 times the size of the US
Land boundaries: 0 km
note: see entry on International disputes
Coastline: 17,968 km
Maritime claims: none; twenty of 27 Antarctic consultative nations
have made no claims to Antarctic territory (although Russia and the
US have reserved the right to do so) and do not recognize the claims
of the other nations; also see the Disputes - international entry
Climate: severe low temperatures vary with latitude, elevation, and
distance from the ocean; East Antarctica is colder than West
Antarctica because of its higher elevation; Antarctic Peninsula has
the most moderate climate; higher temperatures occur in January
along the coast and average slightly below freezing
Terrain: about 98% thick continental ice sheet and 2% barren rock,
with average elevations between 2,000 and 4,000 meters; mountain
ranges up to 5,140 meters; ice-free coastal areas include parts of
southern Victoria Land, Wilkes Land, the Antarctic Peninsula area,
and parts of Ross Island on McMurdo Sound; glaciers form ice shelves
along about half of the coastline, and floating ice shelves
constitute 11% of the area of the continent
Elevation extremes: lowest point: Bentley Subglacial Trench -2,540 m
highest point: Vinson Massif 5,140 m
note: the lowest known land point in Antarctica is hidden in the
Bentley Subglacial Trench; at its surface is the deepest ice yet
discovered and the world''s lowest elevation not under sea water
Natural resources: iron ore, chromium, copper, gold, nickel,
platinum and other minerals, and coal and hydrocarbons have been
found in small uncommercial quantities; none presently exploited;
krill, finfish, and crab have been taken by commercial fisheries
Land use: arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (ice 98%, barren rock 2%)
Irrigated land: 0 sq km (1993)
Natural hazards: katabatic (gravity-driven) winds blow coastward
from the high interior; frequent blizzards form near the foot of the
plateau; cyclonic storms form over the ocean and move clockwise
along the coast; volcanism on Deception Island and isolated areas of
West Antarctica; other seismic activity rare and weak; large
icebergs may calve from ice shelf
Environment - current issues: in 1998, NASA satellite data showed
that the antarctic ozone hole was the largest on record, covering 27
million square kilometers; researchers in 1997 found that increased
ultraviolet light coming through the hole damages the DNA of
icefish, an antarctic fish lacking hemoglobin; ozone depletion
earlier was shown to harm one-celled antarctic marine plants
Geography - note: the coldest, windiest, highest (on average), and
driest continent; during summer, more solar radiation reaches the
surface at the South Pole than is received at the Equator in an
equivalent period; mostly uninhabitable
Antarctica People
Population: no indigenous inhabitants, but there are seasonally
staffed research stations
note: approximately 29 nations, all signatory to the Antarctic
Treaty, send personnel to perform seasonal (summer) and year-round
research on the continent and in its surrounding oceans; the
population of persons doing and supporting science on the continent
and its nearby islands south of 60 degrees south latitude (the
region covered by the Antarctic Treaty) varies from approximately
4,000 in summer to 1,000 in winter; in addition, approximately 1,000
personnel including ship''s crew and scientists doing onboard
research are present in the waters of the treaty region; Summer
(January) population - 3,687 total; Argentina 302, Australia 201,
Belgium 13, Brazil 80, Bulgaria 16, Chile 352, China 70, Finland 11,
France 100, Germany 51, India 60, Italy 106, Japan 136, South Korea
14, Netherlands 10, NZ 60, Norway 40, Peru 28, Poland 70, Russia
254, South Africa 80, Spain 43, Sweden 20, UK 192, US 1,378
(1998-99); Winter (July) population - 964 total; Argentina 165,
Australia 75, Brazil 12, Chile 129, China 33, France 33, Germany 9,
India 25, Japan 40, South Korea 14, NZ 10, Poland 20, Russia 102,
South Africa 10, UK 39, US 248 (1998-99); year-round stations - 42
total; Argentina 6, Australia 4, Brazil 1, Chile 4, China 2, Finland
1, France 1, Germany 1, India 1, Italy 1, Japan 1, South Korea 1, NZ
1, Norway 1, Poland 1, Russia 6, South Africa 1, Spain 1, Ukraine 1,
UK 2, US 3, Uruguay 1 (1998-99); Summer-only stations - 32 total;
Argentina 3, Australia 4, Bulgaria 1, Chile 7, Germany 1, India 1,
Japan 3, NZ 1, Peru 1, Russia 3, Sweden 2, UK 5 (1998-99); in
addition, during the austral summer some nations have numerous
occupied locations such as tent camps, summer-long temporary
facilities, and mobile traverses in support of research (July 2001
est.)
Antarctica Government
Country name: conventional long form: none
conventional short form: Antarctica
Government type: Antarctic Treaty Summary - the Antarctic Treaty,
signed on 1 December 1959 and entered into force on 23 June 1961,
establishes the legal framework for the management of Antarctica.
The 23rd Antarctic Treaty Consultative Meeting was held in Peru in
May 1999. At the end of 2000, there were 44 treaty member nations:
27 consultative and 17 non-consultative. Consultative (voting)
members include the seven nations that claim portions of Antarctica
as national territory (some claims overlap) and 20 nonclaimant
nations. The US and Russia have reserved the right to make claims.
The US does not recognize the claims of others. Antarctica is
administered through meetings of the consultative member nations.
Decisions from these meetings are carried out by these member
nations (within their areas) in accordance with their own national
laws. The year in parentheses indicates when an acceding nation was
voted to full consultative (voting) status, while no date indicates
the country was an original 1959 treaty signatory. Claimant nations
are - Argentina, Australia, Chile, France, New Zealand, Norway, and
the UK. Nonclaimant consultative nations are - Belgium, Brazil
(1983), Bulgaria (1998) China (1985), Ecuador (1990), Finland
(1989), Germany (1981), India (1983), Italy (1987), Japan, South
Korea (1989), Netherlands (1990), Peru (1989), Poland (1977),
Russia, South Africa, Spain (1988), Sweden (1988), Uruguay (1985),
and the US. Non-consultative (nonvoting) members, with year of
accession in parentheses, are - Austria (1987), Canada (1988),
Colombia (1989), Cuba (1984), Czech Republic (1993), Denmark (1965),
Greece (1987), Guatemala (1991), Hungary (1984), North Korea (1987),
Papua New Guinea (1981), Romania (1971), Slovakia (1993),
Switzerland (1990), Turkey (1995), Ukraine (1992), and Venezuela
(1999). Article 1 - area to be used for peaceful purposes only;
military activity, such as weapons testing, is prohibited, but
military personnel and equipment may be used for scientific research
or any other peaceful purpose; Article 2 - freedom of scientific
investigation and cooperation shall continue; Article 3 - free
exchange of information and personnel, cooperation with the UN and
other international agencies; Article 4 - does not recognize,
dispute, or establish territorial claims and no new claims shall be
asserted while the treaty is in force; Article 5 - prohibits nuclear
explosions or disposal of radioactive wastes; Article 6 - includes
under the treaty all land and ice shelves south of 60 degrees 00
minutes south and reserves high seas rights; Article 7 -
treaty-state observers have free access, including aerial
observation, to any area and may inspect all stations,
installations, and equipment; advance notice of all expeditions and
of the introduction of military personnel must be given; Article 8 -
allows for jurisdiction over observers and scientists by their own
states; Article 9 - frequent consultative meetings take place among
member nations; Article 10 - treaty states will discourage
activities by any country in Antarctica that are contrary to the
treaty; Article 11 - disputes to be settled peacefully by the
parties concerned or, ultimately, by the ICJ; Articles 12, 13, 14 -
deal with upholding, interpreting, and amending the treaty among
involved nations. Other agreements - some 200 recommendations
adopted at treaty consultative meetings and ratified by governments
include - Agreed Measures for Fauna and Flora (1964) which were
later incorporated into the Environmental Protocol; Convention for
the Conservation of Antarctic Seals (1972); Convention on the
Conservation of Antarctic Marine Living Resources (1980); a mineral
resources agreement was signed in 1988 but remains unratified; the
Protocol on Environmental Protection to the Antarctic Treaty was
signed 4 October 1991 and entered into force 14 January 1998; this
agreement provides for the protection of the Antarctic environment
through five specific annexes: 1) marine pollution, 2) fauna and
flora, 3) environmental impact assessments, 4) waste management, and
5) protected area management; it prohibits all activities relating
to mineral resources except scientific research.
Legal system: Antarctica is administered through meetings of the
consultative member nations. Decisions from these meetings are
carried out by these member nations (within their areas) in
accordance with their own national laws. US law, including certain
criminal offenses by or against US nationals, such as murder, may
apply extra-territorially. Some US laws directly apply to
Antarctica. For example, the Antarctic Conservation Act, 16 U.S.C.
section 2401 et seq., provides civil and criminal penalties for the
following activities, unless authorized by regulation of statute:
the taking of native mammals or birds; the introduction of
nonindigenous plants and animals; entry into specially protected
areas; the discharge or disposal of pollutants; and the importation
into the US of certain items from Antarctica. Violation of the
Antarctic Conservation Act carries penalties of up to $10,000 in
fines and one year in prison. The National Science Foundation and
Department of Justice share enforcement responsibilities. Public Law
95-541, the US Antarctic Conservation Act of 1978, as amended in
1996, requires expeditions from the US to Antarctica to notify, in
advance, the Office of Oceans and Polar Affairs, Room 5801,
Department of State, Washington, DC 20520, which reports such plans
to other nations as required by the Antarctic Treaty. For more
information, contact Permit Office, Office of Polar Programs,
National Science Foundation, Arlington, Virginia 22230; telephone:
(703) 292-8030, or see their website at www.nsf.gov.
Antarctica Economy
Economy - overview: Fishing off the coast and tourism, both based
abroad, account for the limited economic activity. Antarctic
fisheries in 1998-99 (1 July-30 June) reported landing 119,898
metric tons. Unregulated fishing landed five to six times more than
the regulated fishery, and allegedly illegal fishing in antarctic
waters in 1998 resulted in the seizure (by France and Australia) of
at least eight fishing ships. Companies interested in commercial
fishing activities in Antarctica have put forward proposals. The
Convention on the Conservation of Antarctic Marine Living Resources
determines the recommended catch limits for marine species. A total
of 13,193 tourists visited in the 1999-2000 summer, up from the
10,013 who visited the previous year. Nearly all of them were
passengers on 24 commercial (nongovernmental) ships and several
yachts that made 143 trips during the summer. Most tourist trips
lasted approximately two weeks.
Antarctica Communications
Telephones - main lines in use: 0
note: information for US bases only (2001)
Telephones - mobile cellular: NA
Telephone system: general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM 2, shortwave 1
note: information for US bases only (1998)
Radios: NA
Television broadcast stations: 1 (the US Navy Antarctic Support
Group operates a cable system with six channels for the American
Forces Antarctic Network-McMurdo)
note: information for US bases only (2000)
Televisions: several hundred at McMurdo Sound
note: information for US bases only (2001)
Internet country code: .aq
Internet Service Providers (ISPs): NA
Antarctica Transportation
Ports and harbors: there are no developed ports and harbors in
Antarctica; most coastal stations have offshore anchorages, and
supplies are transferred from ship to shore by small boats, barges,
and helicopters; a few stations have a basic wharf facility US
coastal stations include McMurdo (77 51 S, 166 40 E), Palmer (64 43
S, 64 03 W); government use only except by permit (see Permit Office
under "Legal System"); offshore anchorage is sparse and intermittent
Airports: 19
note: 27 stations, operated by 16 national governments party to the
Antarctic Treaty, have aircraft landing facilities for either
helicopters and/or fixed-wing aircraft; commercial enterprises
operate two additional aircraft landing facilities; helicopter pads
are available at 27 stations; runways at 15 locations are gravel,
sea-ice, blue-ice, or compacted snow suitable for landing wheeled,
fixed-wing aircraft; of these, 1 is greater than 3 km in length, 6
are between 2 km and 3 km in length, 3 are between 1 km and 2 km in
length, 3 are less than 1 km in length, and 2 are of unknown length;
snow surface skiways, limited to use by ski-equipped, fixed-wing
aircraft, are available at another 15 locations; of these, 4 are
greater than 3 km in length, 3 are between 2 km and 3 km in length,
2 are between 1 km and 2 km in length, 2 are less than 1 km in
length, and 4 are of unknown length; aircraft landing facilities
generally subject to severe restrictions and limitations resulting
from extreme seasonal and geographic conditions; aircraft landing
facilities do not meet ICAO standards; advance approval from the
respective governmental or nongovernmental operating organization
required for landing (2001 est.)
Airports - with unpaved runways: total: 19
over 3,047 m: 6
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 5 (2000 est.)
Heliports: 27 stations have helicopter landing facilities (helipads)
(2001 est.)
Antarctica Military
Military - note: the Antarctic Treaty prohibits any measures of a
military nature, such as the establishment of military bases and
fortifications, the carrying out of military maneuvers, or the
testing of any type of weapon; it permits the use of military
personnel or equipment for scientific research or for any other
peaceful purposes
Antarctica Transnational Issues
Disputes - international: Antarctic Treaty freezes claims (see
Antarctic Treaty Summary in Government type entry); sections (some
overlapping) claimed by Argentina, Australia, Chile, France, New
Zealand, Norway, and UK; the US and most other nations do not
recognize the territorial claims of other nations and have made no
claims themselves (the US and Russia reserve the right to do so); no
claims have been made in the sector between 90 degrees west and 150
degrees west
======================================================================
@Antigua and Barbuda
Antigua and Barbuda Introduction
Background: The islands of Antigua and Barbuda became an independent
state within the British Commonwealth of Nations in 1981. Some 3,000
refugees fleeing a volcanic eruption on nearby Montserrat have
settled in Antigua and Barbuda since 1995.
Antigua and Barbuda Geography
Location: Caribbean, islands between the Caribbean Sea and the North
Atlantic Ocean, east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the Caribbean
Area: total: 442 sq km (Antigua 281 sq km; Barbuda 161 sq km)
land: 442 sq km
water: 0 sq km
note: includes Redonda
Area - comparative: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims: contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; little seasonal temperature variation
Terrain: mostly low-lying limestone and coral islands, with some
higher volcanic areas
Elevation extremes: lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant climate fosters tourism
Land use: arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 11%
other: 62% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and tropical storms (July to October);
periodic droughts
Environment - current issues: water management - a major concern
because of limited natural fresh water resources - is further
hampered by the clearing of trees to increase crop production,
causing rainfall to run off quickly
Environment - international agreements: party to: Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Antigua and Barbuda People
Population: 66,970 (July 2001 est.)
Age structure: 0-14 years: 27.97% (male 9,527; female 9,203)
15-64 years: 67.15% (male 22,450; female 22,519)
65 years and over: 4.88% (male 1,360; female 1,911) (2001 est.)
Population growth rate: 0.74% (2001 est.)
Birth rate: 19.5 births/1,000 population (2001 est.)
Death rate: 5.87 deaths/1,000 population (2001 est.)
Net migration rate: -6.27 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.99 male(s)/female (2001 est.)
Infant mortality rate: 22.33 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 70.74 years
male: 68.45 years
female: 73.14 years (2001 est.)
Total fertility rate: 2.31 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality: noun: Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese, Lebanese, Syrian
Religions: Anglican (predominant), other Protestant, some Roman
Catholic
Languages: English (official), local dialects
Literacy: definition: age 15 and over has completed five or more
years of schooling
total population: 89%
male: 90%
female: 88% (1960 est.)
Antigua and Barbuda Government
Country name: conventional long form: none
conventional short form: Antigua and Barbuda
Government type: constitutional monarchy with UK-style parliament
Capital: Saint John''s
Administrative divisions: 6 parishes and 2 dependencies*; Barbuda*,
Redonda*, Saint George, Saint John, Saint Mary, Saint Paul, Saint
Peter, Saint Philip
Independence: 1 November 1981 (from UK)
National holiday: Independence Day, 1 November (1981)
Constitution: 1 November 1981
Legal system: based on English common law
Suffrage: 18 years of age; universal
Executive br','d8110566d4e5d3e56f21352420709fe0fec3255e15e5004d37bec3913f4c806c','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fe5f925c684222937fcd301efa53a97a32c9aeb68a68968ed5cccd9cbcc8f40',2001,'WF','Wallis and Futuna','transportation',22,'anch: chief of state: Queen ELIZABETH II (since 6
February 1952), represented by Governor General James B. CARLISLE
(since NA 1993)
head of government: Prime Minister Lester Bryant BIRD (since 8
March 1994)
cabinet: Council of Ministers appointed by the governor general on
the advice of the prime minister
elections: none; the monarch is hereditary; governor general chosen
by the monarch on the advice of the prime minister; prime minister
appointed by the governor general
Legislative branch: bicameral Parliament consists of the Senate
(17-member body appointed by the governor general) and the House of
Representatives (17 seats; members are elected by proportional
representation to serve five-year terms)
elections: House of Representatives - last held 9 March 1999 (next
to be held NA March 2004)
election results: percent of vote by party - NA%; seats by party -
ALP 12, UPP 4, independent 1
Judicial branch: Eastern Caribbean Supreme Court (based in Saint
Lucia; one judge of the Supreme Court is a resident of the islands
and presides over the Court of Summary Jurisdiction)
Political parties and leaders: Antigua Labor Party or ALP [Lester
Bryant BIRD]; Barbuda People''s Movement or BPM [Thomas H. FRANK];
United Progressive Party or UPP [Baldwin SPENCER] (a coalition of
three opposition parties - United National Democratic Party or UNDP,
Antigua Caribbean Liberation Movement or ACLM, and Progressive Labor
Movement or PLM)
Political pressure groups and leaders: Antigua Trades and Labor
Union or ATLU [William ROBINSON]; People''s Democratic Movement or
PDM [Hugh MARSHALL]
International organization participation: ACP, C, Caricom, CDB,
ECLAC, FAO, G-77, IBRD, ICAO, ICFTU, ICRM, IFAD, IFC, IFRCS, ILO,
IMF, IMO, Intelsat (nonsignatory user), Interpol, IOC, ITU, NAM
(observer), OAS, OECS, OPANAL, UN, UNCTAD, UNESCO, UPU, WCL, WFTU,
WHO, WIPO, WMO, WTrO
Diplomatic representation in the US: chief of mission: Ambassador
Lionel Alexander HURST
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 362-5211
FAX: [1] (202) 362-5225
consulate(s) general: Miami
Diplomatic representation from the US: the US does not have an
embassy in Antigua and Barbuda (embassy closed 30 June 1994); the US
Ambassador to Barbados is accredited to Antigua and Barbuda
Flag description: red, with an inverted isosceles triangle based on
the top edge of the flag; the triangle contains three horizontal
bands of black (top), light blue, and white, with a yellow rising
sun in the black band
Antigua and Barbuda Economy
Economy - overview: Tourism continues to be the dominant activity in
the economy accounting directly or indirectly for more than half of
GDP. The budding offshore financial sector has been seriously hurt
by financial sanctions imposed by the US and UK as a result of the
loosening of its money-laundering controls. The government has made
efforts to comply with international demands in order to get the
sanctions lifted. Antigua and Barbuda was listed as a tax haven by
the OECD in 2000. The dual island nation''s agricultural production
is mainly directed to the domestic market; the sector is constrained
by the limited water supply and labor shortages that reflect the
pull of higher wages in tourism and construction. Manufacturing
comprises enclave-type assembly for export with major products being
bedding, handicrafts, and electronic components. Prospects for
economic growth in the medium term will continue to depend on income
growth in the industrialized world, especially in the US, which
accounts for about one-third of all tourist arrivals.
GDP: purchasing power parity - $533 million (1999 est.)
GDP - real growth rate: 4.6% (1999 est.)
GDP - per capita: purchasing power parity - $8,200 (1999 est.)
GDP - composition by sector: agriculture: 4%
industry: 12.5%
services: 83.5% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage share: lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1.6% (1999 est.)
Labor force: 30,000
Labor force - by occupation: commerce and services 82%, agriculture
11%, industry 7% (1983)
Unemployment rate: 7% (1999 est.)
Budget: revenues: $122.6 million
expenditures: $141.2 million, including capital expenditures of
$17.3 million (1997 est.)
Industries: tourism, construction, light manufacturing (clothing,
alcohol, household appliances)
Industrial production growth rate: 6% (1997 est.)
Electricity - production: 95 million kWh (1999)
Electricity - production by source: fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity - consumption: 88.4 million kWh (1999)
Electricity - exports: 0 kWh (1999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: cotton, fruits, vegetables, bananas,
coconuts, cucumbers, mangoes, sugarcane; livestock
Exports: $38 million (1998)
Exports - commodities: petroleum products 48%, manufactures 23%,
machinery and transport equipment 17%, food and live animals 4%,
other 8%
Exports - partners: OECS 26%, Barbados 15%, Guyana 4%, Trinidad and
Tobago 2%, US 0.3%
Imports: $330 million (1998)
Imports - commodities: food and live animals, machinery and
transport equipment, manufactures, chemicals, oil
Imports - partners: US 27%, UK 16%, Canada 4%, OECS 3%
Debt - external: $357 million (1998)
Economic aid - recipient: $2.3 million (1995)
Currency: East Caribbean dollar (XCD)
Currency code: XCD
Exchange rates: East Caribbean dollars per US dollar - 2.7000 (fixed
rate since 1976)
Fiscal year: 1 April - 31 March
Antigua and Barbuda Communications
Telephones - main lines in use: 28,000 (1996)
Telephones - mobile cellular: 1,300 (1996)
Telephone system: general assessment: NA
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite earth station -
1 Intelsat (Atlantic Ocean); tropospheric scatter to Saba
(Netherlands Antilles) and Guadeloupe
Radio broadcast stations: AM 4, FM 2, shortwave 0 (1998)
Radios: 36,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: 31,000 (1997)
Internet country code: .ag
Internet Service Providers (ISPs): 16 (2000)
Internet users: 8,000 (2000)
Antigua and Barbuda Transportation
Railways: total: 77 km
narrow gauge: 64 km 0.760-m gauge; 13 km 0.610-m gauge (used almost
exclusively for handling sugarcane)
Highways: total: 1,165 km
paved: 384 km
unpaved: 781 km (1999 est.)
Waterways: none
Ports and harbors: Saint John''s
Merchant marine: total: 681 ships (1,000 GRT or over) totaling
4,070,390 GRT/5,289,904 DWT
ships by type: bulk 15, cargo 424, chemical tanker 10, combination
bulk 4, container 176, liquefied gas 4, multi-functional large-load
carrier 6, petroleum tanker 2, refrigerated cargo 11, roll on/roll
off 29
note: includes some foreign-owned ships registered here as a flag
of convenience: Cyprus 2, Germany 4, Slovenia 2 (2000 est.)
Airports: 3 (2000 est.)
Airports - with paved runways: total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2000 est.)
Airports - with unpaved runways: total: 1
under 914 m: 1 (2000 est.)
Antigua and Barbuda Military
Military branches: Royal Antigua and Barbuda Defense Force, Royal
Antigua and Barbuda Police Force (includes Coast Guard)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Antigua and Barbuda Transnational Issues
Disputes - international: none
Illicit drugs: considered a minor transshipment point for narcotics
bound for the US and Europe; more significant as a
drug-money-laundering center
======================================================================
@Arctic Ocean
Arctic Ocean Introduction Top of Page
Background: The Arctic Ocean is the smallest of the world''s five
oceans (after the Pacific Ocean, Atlantic Ocean, Indian Ocean, and
the recently delimited Southern Ocean). The Northwest Passage (US
and Canada) and Northern Sea Route (Norway and Russia) are two
important seasonal waterways. A sparse network of air, ocean, river,
and land routes circumscribes the Arctic Ocean.
Arctic Ocean Geography
Location: body of water between Europe, Asia, and North America,
mostly north of the Arctic Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area: total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea, Chukchi Sea,
East Siberian Sea, Greenland Sea, Hudson Bay, Hudson Strait, Kara
Sea, Laptev Sea, Northwest Passage, and other tributary water bodies
Area - comparative: slightly less than 1.5 times the size of the US
Coastline: 45,389 km
Climate: polar climate characterized by persistent cold and
relatively narrow annual temperature ranges; winters characterized
by continuous darkness, cold and stable weather conditions, and
clear skies; summers characterized by continuous daylight, damp and
foggy weather, and weak cyclones with rain or snow
Terrain: central surface covered by a perennial drifting polar
icepack that averages about 3 meters in thickness, although pressure
ridges may be three times that size; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight-line movement from the
New Siberian Islands (Russia) to Denmark Strait (between Greenland
and Iceland); the icepack is surrounded by open seas during the
summer, but more than doubles in size during the winter and extends
to the encircling landmasses; the ocean floor is about 50%
continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonosov Ridge)
Elevation extremes: lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates, placer deposits,
polymetallic nodules, oil and gas fields, fish, marine mammals
(seals and whales)
Natural hazards: ice islands occasionally break away from northern
Ellesmere Island; icebergs calved from glaciers in western Greenland
and extreme northeastern Canada; permafrost in islands; virtually
ice locked from October to June; ships subject to superstructure
icing from October to May
Environment - current issues: endangered marine species include
walruses and whales; fragile ecosystem slow to change and slow to
recover from disruptions or damage; thinning polar icepack
Geography - note: major chokepoint is the southern Chukchi Sea
(northern access to the Pacific Ocean via the Bering Strait);
strategic location between North America and Russia; shortest marine
link between the extremes of eastern and western Russia; floating
research stations operated by the US and Russia; maximum snow cover
in March or April about 20 to 50 centimeters over the frozen ocean;
snow cover lasts about 10 months
Arctic Ocean Economy
Economy - overview: Economic activity is limited to the exploitation
of natural resources, including petroleum, natural gas, fish, and
seals.
Arctic Ocean Transportation
Ports and harbors: Churchill (Canada), Murmansk (Russia), Prudhoe
Bay (US)
Transportation - note: sparse network of air, ocean, river, and land
routes; the Northwest Passage (North America) and Northern Sea Route
(Eurasia) are important seasonal waterways
Arctic Ocean Transnational Issues
Disputes - international: some maritime disputes (see littoral
states)
======================================================================
@Argentina
Argentina Introduction
Background: Following independence from Spain in 1816, Argentina
experienced periods of internal political conflict between
conservatives and liberals and between civilian and military
factions. After World War II, a long period of Peronist dictatorship
was followed by a military junta that took power in 1976. Democracy
returned in 1983, and numerous elections since then have underscored
Argentina''s progress in democratic consolidation.
Argentina Geography
Location: Southern South America, bordering the South Atlantic
Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area: total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area - comparative: slightly less than three-tenths the size of the
US
Land boundaries: total: 9,665 km
border countries: Bolivia 832 km, Brazil 1,224 km, Chile 5,150 km,
Paraguay 1,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims: contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: mostly temperate; arid in southeast; subantarctic in
southwest
Terrain: rich plains of the Pampas in northern half, flat to rolling
plateau of Patagonia in south, rugged Andes along western border
Elevation extremes: lowest point: Salinas Chicas -40 m (located on
Peninsula Valdes)
highest point: Cerro Aconcagua 6,960 m
Natural resources: fertile plains of the Pampas, lead, zinc, tin,
copper, iron ore, manganese, petroleum, uranium
Land use: arable land: 9%
permanent crops: 1%
permanent pastures: 52%
forests and woodland: 19%
other: 19% (1993 est.)
Irrigated land: 17,000 sq km (1993 est.)
Natural hazards: San Miguel de Tucuman and Mendoza areas in the
Andes subject to earthquakes; pamperos are violent windstorms that
can strike the Pampas and northeast; heavy flooding
Environment - current issues: environmental problems (urban and
rural) typical of an industrializing economy such as soil
degradation, desertification, air pollution, and water pollution
note: Argentina is a world leader in setting voluntary greenhouse
gas targets
Environment - international agreements: party to:
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine
Life Conservation
Geography - note: second-largest country in South America (after
Brazil); strategic location relative to sea lanes between South
Atlantic and South Pacific Oceans (Strait of Magellan, Beagle
Channel, Drake Passage)
Argentina People
Population: 37,384,816 (July 2001 est.)
Age structure: 0-14 years: 26.54% (male 5,077,593; female 4,842,811)
15-64 years: 63.04% (male 11,795,282; female 11,773,855)
65 years and over: 10.42% (male 1,609,672; female 2,285,603) (2001
est.)
Population growth rate: 1.15% (2001 est.)
Birth rate: 18.41 births/1,000 population (2001 est.)
Death rate: 7.58 deaths/1,000 population (2001 est.)
Net migration rate: 0.64 migrant(s)/1,000 population (2001 est.)
Sex ratio: at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (2001 est.)
Infant mortality rate: 17.75 deaths/1,000 live births (2001 est.)
Life expectancy at birth: total population: 75.26 years
male: 71.88 years
female: 78.82 years (2001 est.)
Total fertility rate: 2.44 children born/woman (2001 est.)
HIV/AIDS - adult prevalence rate: 0.69% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000 (1999 est.)
HIV/AIDS - deaths: 1,800 (1999 est.)
Nationality: noun: Argentine(s)
adjective: Argentine
Ethnic groups: white (mostly Spanish and Italian) 97%, mestizo,
Amerindian, or other nonwhite groups 3%
Religions: nominally Roman Catholic 92% (less than 20% practicing),
Protestant 2%, Jewish 2%, other 4%
Languages: Spanish (official), English, Italian, German, French
Literacy: definition: age 15 and over can read and write
total population: 96.2%
male: 96.2%
female: 96.2% (1995 est.)
Argentina Government
Country name: conventional long form: Argentine Republic
conventional short form: Argentina
local long form: Republica Argentina
local short form: Argentina
Government type: republic
Capital: Buenos Aires
Administrative divisions: 23 provinces (provincias, singular -
provincia), and 1 autonomous city* (distrito federal); Buenos Aires;
Buenos Aires Capital Federal*; Catamarca; Chaco; Chubut; Cordoba;
Corrientes; Entre Rios; Formosa; Jujuy; La Pampa; La Rioja; Mendoza;
Misiones; Neuquen; Rio Negro; Salta; San Juan; San Luis; Santa Cruz;
Santa Fe; Santiago del Estero; Tierra del Fuego, Antartica e Islas
del Atlantico Sur; Tucuman
note: the US does not recognize any claims to Antarctica
Independence: 9 July 1816 (from Spain)
National holiday: Revolution Day, 25 May (1810)
Constitution: 1 May 1853; revised August 1994
Legal system: mixture of US and West European legal systems; has not
accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal and mandatory
Executive branch: chief of state: President Fernando DE LA RUA
(since 10 December 1999); Vice President Carlos "Chacho" ALVAREZ
resigned 6 October 2000 and a replacement has not yet been named;
note - the president is both the chief of state and head of','128e8e001916a179f779ebf48baf996db0b1f79bed59e0b3deb6057e379f1d7e','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

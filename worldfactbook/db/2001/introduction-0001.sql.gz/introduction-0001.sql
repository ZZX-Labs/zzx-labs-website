SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd5692c0bd1b248745726cfde591c6c11176deb206bd1fa279e34d691adbece5',2001,'AL','Albania','introduction',25,'Background; After a century of rule by France,
Algeria became independent in 1962. The surprising
first round success of the fundamentalist FIS (Islamic
Salvation Front) party in December 1991 balloting
caused the army to intervene, crack down on the FIS,
and postpone the subsequent elections. The FIS
response has resulted in a continuous low-grade civil
conflict with the secular state apparatus, which
nonetheless has allowed elections featuring
pro-government and moderate religious-based
parties. FIS''s armed wing, the Islamic Salvation Army,
disbanded itself in January 2000 and many armed
militants surrendered under an amnesty program
designed to promote national reconciliation.
Nevertheless, residual fighting continues. Other
concerns include large-scale unemployment and the
need to diversify the petroleum-based economy.','4aa81b587df0578db7b525f0be1815a86607ba33c632c5fdc47ebb483bf748a4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10f6fbb5f103bb183337d0927f2a3ec2bf50cf8cfead79c29681540b8a883216',2001,'AS','American Samoa','introduction',27,'Background: Settled as early as 1000 B. C., Samoa
was "discovered" by European explorers in the 18th
century. International rivalries in the latter half of the
19th century were settled by an 1899 treaty in which
Germany and the US divided the Samoan
archipelago. The US formally occupied its portion - a
smaller group of eastern islands with the excellent
harbor of Pago Pago - the following year.','2a1f0d8fb3444e8ff216737bb59e8a15446017125ae7fcb3ccaab4c76508a2c0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3116ddb3716410d3b2b24cfcb493d91c9a5a318a52f57ec51db95f04985e5237',2001,'AI','Anguilla','introduction',49,'Background: Colonized by English settlers from
Saint Kitts in 1650, Anguilla was administered by
Great Britain until the early 19th century, when the
island - against the wishes of the inhabitants - was
incorporated into a single British dependency along
with Saint Kitts and Nevis. Several attempts at
separation failed. In 1971, two years after a revolt,
Anguilla was finally allowed to secede; this
arrangement was formally recognized in 1980 with
Anguilla becoming a separate British dependency.','b091e64ef3067b0d44a686d7744f88f17d3ccc1cc0371f7698d72eaa0c2722f5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ae393926c081c55883d7e4355a0efdf312de86f3762d33a2854e085dd659134',2001,'GP','Guadeloupe','introduction',74,'Background: The Arctic Ocean is the smallest of the
world''s five oceans (after the Pacific Ocean, Atlantic
Ocean, Indian Ocean, and the recently delimited
Southern Ocean). The Northwest Passage (US and
Canada) and Northern Sea Route (Norway and
Russia) are two important seasonal waterways. A
sparse network of air, ocean, river, and land routes
circumscribes the Arctic Ocean.
Background: Guadeloupe has been a French
possession since 1635. The island of Saint-Martin is
divided with the Netherlands (whose southern portion
is named Sint Maarten and is part of the Netherlands
Antilles).','31e0b094f61e248b847662cb9d9b5e9cf213837e9457c6e0aae843488b44d970','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd9293dda1b3c2a7763ce58da66198b79c6061d55cec8cc63c0e48207f3ded06',2001,'AQ','Antarctica','introduction',81,'Background: An Orthodox Christian country,
Armenia was incorporated into Russia in 1 828 and the
USSR in 1920. Armenian leaders remain preoccupied
by the long conflict with Azerbaijan over
Nagorno-Karabakh, a primarily Armenian-populated
exclave, assigned to Soviet Azerbaijan in the 1920s
by Moscow. Armenia and Azerbaijan began fighting
over the exclave in 1988; the struggle escalated after
both countries attained independence from the Soviet
Union in 1991 . By May 1994, when a cease-fire took
hold, Armenian forces held not only
Nagorno-Karabakh but also a significant portion of
Azerbaijan proper. The economies of both sides have
been hurt by their inability to make substantial
progress toward a peaceful resolution.
Background: Discovered and claimed for Spain in
1499, Aruba was acquired by the Dutch in 1636. The
island''s economy has been dominated by three main
Industries. A 19th century gold rush was followed by
prosperity brought on by the opening in 1 924 of an oil
refinery. The last decades of the 20th century saw a
boom in the tourism industry. Aruba seceded from the
Netherlands Antilles in 1986 and became a separate,
autonomous member of the Kingdom of the
Netherlands. Movement toward full independence
was halted at Aruba''s request in 1990.
Background: These uninhabited islands came
under Australian authority in 1 931 ; formal
administration began two years later, Ashmore Reef
supports a rich and diverse avian and marine habitat;
in 1983 it became a National Nature Reserve. Recent
geological explorations have indicated promising
petroleum formations.
Background: The Atlantic Ocean is the
second-largest of the world''s five oceans (after the
Pacific Ocean, but larger than the Indian Ocean,
Southern Ocean, and Arctic Ocean). The Kiel Canal
(Germany), Oresund (Denmark-Sweden), Bosporus
(Turkey), Strait of Gibraltar (Morocco-Spain), and the
St. Lawrence Seaway (Canada-US) are important
strategic access waterways. The decision by the
international Hydrographic Organization in the spring
of 2000 to delimit a fifth world ocean, the Southern
Ocean, removed the portion of the Atlantic Ocean
south of 60 degrees south.','483f77b7f37b610edeb5d28b287f25c9f024b813aa47ecc56bb341a0ad8cef84','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ea0c8d6f9f294c9a2343d2593d22e3affab4dd2ff129edad228cce1671d95a8',2001,'AU','Australia','introduction',82,'Background: Australia became a commonwealth of
the British Empire in 1901 . It was able to take
advantage of its natural resources to rapidly develop
its agricultural and manufacturing industries and to
make a major contribution to the British effort in World
Wars I and II. Long-term concerns include pollution,
particularly depletion of the ozone layer, and
management and conservation of coastal areas,
especially the Great Barrier Reef. A referendum to
change Australia''s status, from a commonwealth
headed by the British monarch to an independent
republic, was defeated in 1999.
Background: Once the center of power for the large
Austro-Hungarian Empire, Austria was reduced to a
small republic after its defeat in World War 1. Following
annexation by Nazi Germany in 1 938 and subsequent
occupation by the victorious Allies, Austria''s 1 955
State Treaty declared the country "permanently
neutral" as a condition of Soviet military withdrawal.
Neutrality, once ingrained as part of the Austrian
cultural identity, has been called into question since
the Soviet collapse of 1991 and Austria''s increasingly
prominent role in European affairs. A prosperous
country, Austria joined the European Union in 1995
and the euro monetary system in 1999.
Background: Popes in their secular role ruled much
of the Italian peninsula for more than a thousand years
until the mid 19th century, when many of the Papal
States were seized by the newly united Kingdom of
Italy. In 1870, the pope''s holdings were further
circumscribed when Rome itself was annexed.
Disputes between a series of "prisoner" popes and
Italy were resolved in 1 929 by three Lateran T reaties,
which established the independent state of Vatican
City and granted Roman Catholicism special status in
Italy. In 1984, a concordat between the Vatican and
Italy modified certain of the earlier treaty provisions,
Including the primacy of Roman Catholicism as the
Italian state religion. Present concerns of the Holy See
include the failing health of Pope John Paul II,
interreligious dialogue and reconciliation, and the
adjustment of church doctrine in an era of rapid
change and globalization. About 1 billion people
worldwide profess the Catholic faith.
Background: Two British attempts at establishing
the island as a penal colony (1 788-1 814 and 1 825-55)
were ultimately abandoned. In 1856, the island was
resettled by Pitcairn Islanders, descendants of the
Bounty mutineers and their Tahitian companions.
Background: Under US administration as part of the
UN Trust Territory of the Pacific, the people of the
Northern Mariana islands decided in the 1970s not to
seek independence but instead to forge closer links
with the US, Negotiations for territorial status began in
1972. A covenant to establish a commonwealth in
political union with the US was approved in 1975. A
new government and constitution went into effect in
1978.','a72f3950399cb070a04a76a256b6f6ad422d9954ecc632006d02eb6b4c0c9b0b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af8cadf6f035f07e31f1a41b8f5977f83b5e13aa2bc8ad24b5b75e824973d332',2001,'BH','Bahrain','introduction',112,'Background; The US took possession of the island
in 1 857, and its guano deposits were mined by US and
British companies during the second half of the 19th
century. In 1935, a short-lived attempt at colonization
was begun on this island - as well as on nearby
Howland Island - but was disrupted by World War II
and thereafter abandoned. Presently the island is a
National Wildlife Refuge run by the US Department of
the Interior; a day beacon is situated near the middle
of the west coast.','8717545e9d84ea71013308b60413f77a2aa7c256dfde874f60336f25f024672e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c34c9ba2599b3fef73781b5bb58f8e6c397600d9ec1c99e514cfea235ed7690',2001,'FR','France','introduction',148,'Background: Belgium became independent from
the Netherlands in 1830 and was occupied by
Germany during World Wars I and !l. It has prospered
in the past half century as a modern, technologically
advanced European state and member of NATO and
the EU. Tensions between the Dutch-speaking
Flemings of the north and the French-speaking
Walloons of the south have led In recent years to
constitutional amendments granting these regions
formal recognition and autonomy.
Background: The islands were discovered in 1609,
but remained uninhabited until the 19th century.
Annexed by the UK in 1857, they were transferred to
the Australian Government in 1 955. The population on
the two inhabited islands is split between the mostly
Europeans on West Island and the Malays on Home
Island.
Background: Although first sighted by an English
navigator in 1592, the first landing (English) did not
occur until almost a century later in 1690, and the first
settlement (French) was not established until 1764.
The colony was turned over to Spain two years later
and the islands have since been the subject of a
territorial dispute, first between Britain and Spain, then
between Britain and Argentina. The UK asserted its
claim to the islands by establishing a naval garrison
there in 1 833. Argentina invaded the islands on 2 April
1982. The British responded with an expeditionary
force that landed seven weeks later and after fierce
fighting forced Argentine surrender on 1 4 June 1 982.
Background: The Southern Lands consist of two
archipelagos, lies Crozet and lies Kerguelen, and two
volcanic islands, He Amsterdam and lie Saint-Paul.
They contain no permanent inhabitants and are
visited only by researchers studying the native fauna.
The Antarctic portion consists of "Adelie Land," a thin
slice of the Antarctic continent discovered and
claimed by the French in 1840.
Background: Georgia was absorbed into the
Russian Empire in the 19th century. Independent for
three years (1918-1921) following the Russian
revolution, it was forcibly incorporated into the USSR
until the Soviet Union dissolved in 1991. Russian
troops remain garrisoned at four military bases and as
peacekeepers in the separatist regions of Abkhazia
and South Ossetia (but are scheduled to withdrawfrom
two of the bases by July 2001 ). Despite a badly
degraded transportation network - brought on by ethnic
conflict, criminal activities, and fuel shortages - the
country continues to move toward a market economy
and greater integration with Western institutions.','b6e5e58e54df3fd41e079ccca1ca5f48cbe9da94a561158ed9834d145fe8aafa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2975fad22ff4740e1729aa207130effa696237cc5ab01632217d040e9ebba9b0',2001,'BZ','Belize','introduction',157,'Background: Dahomey gained its independence
from France in 1 960; the name was changed to Benin
in 1 975. From 1 974 to 1 989 the country was a socialist
state; free elections were reestablished in 1991.','bbbf3761e379bd40766a8962195f1b8a0d1a5e0345bf08d776f3fb126b955361','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6f4ccc8ef603b56c000be45a55c180fe7549997c574010ee531dfa6f1c4121a',2001,'BM','Bermuda','introduction',166,'Background: Under British influence a monarchy
was set up in 1907; three years later a treaty was
signed whereby the country became a British
protectorate. Independence was attained in 1949,
with India subsequently guiding foreign relations and
supplying aid. A refugee issue of some 100,000
Bhutanese in Nepal remains unresolved; 90% of
these displaced persons are housed in seven United
Nations Office of the High Commissioner for
Refugees (UNHCR) camps. Maoist Assamese
separatists from India, who have established
themselves in the southeast portion of Bhutan, have
drawn Indian cross-border incursions.','d16a34b660a41812c533289b7ff461803e70001ce9d035134c2ba8674e8798a1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5aaa82dd606f48b238acffcfe98b9434d42ccf7ab390373bedf257408ebd81d',2001,'BR','Brazil','introduction',187,'Background: Following three centuries under the
rule of Portugal, Brazil became an independent nation
in 1 822. By far the largest and most populous country
in South America, Brazil has overcome more than half
a century of military intervention in the governance of
the country to pursue industrial and agricultural
growth and development of the interior. Exploiting
vast natural resources and a large labor pool, Brazil
became Latin America''s leading economic power by
the 1970s. Highly unequal income distribution
remains a pressing problem.
Background: Established as a territory of the UK in
1 965, a number of the British Indian Ocean Territory
(BIOT) islands were transferred to the Seychelles
when it attained independence in 1976.
Subsequently, BIOT has consisted only of the six
main island groups comprising the Chagos
Archipelago. The largest and most southerly of the
islands, Diego Garcia, contains a joint UK-US naval
support facility. All of the remaining islands are
uninhabited. Former agricultural workers, earlier
resident in the islands, were relocated primarily to
Mauritius but also to the Seychelles, between 1967
and 1973. In 2000, a British High Court ruling
invalidated the local immigration order which had
excluded them from the archipelago, but upheld the
special military status of Diego Garcia.','a051ad830b5c16027518eaa35c4d4d62d4de60f0c4b20f1d908f1c25ee77f082','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f086c955f62a7eb4b851fd3228a05ba6e1232485b5e6b9bb7d7fe2c758287e35',2001,'ET','Ethiopia','introduction',220,'Background: Despite multiparty elections in 1990
that resulted in the main opposition party winning a
decisive victory, the military junta ruling the country
refused to hand over power. Key opposition leader
and Nobel Peace Prize recipient AUNG San Suu Kyi,
under house arrest from 1989 to 1995, was again
placed under house detention in September 2000; her
supporters are routinely harassed or jailed.
Background; Guyana achieved independence from
the UK in 1966 and became a republic in 1970. In
1989 Guyana launched an Economic Recovery
Program, which marked a dramatic reversal from a
state-controlled, socialist economy towards a more
open, free market system. Results through the first
decade have proven encouraging.
Background: In 1902 Abdul al-Aziz Ibn SAUD
captured Riyadh and set out on a 30-year campaign to
unify the Arabian peninsula. In the 1930s, the
discovery of oil transformed the country. Following
Iraq''s invasion of Kuwait in 1990, Saudi Arabia
accepted the Kuwaiti royal family and 400,000
refugees while allowing Western and Arab troops to
deploy on its soil for the liberation of Kuwait the
following year. A burgeoning population, aquifer
depletion, and an economy largely dependent on
petroleum output and prices are all major
governmental concerns.
Background: Independent from France in 1960,
Senega! joined with The Gambia to form the nominal
confederation of Senegambia in 1982. However, the
envisaged integration of the two countries was never
carried out, and the union was dissolved in 1989.
Despite peace talks, a southern separatist group
sporadically has clashed with government forces
since 1 982. Senegal has a long history of participating
in international peacekeeping.','05963f5ce707a4e2399ec5c8442acee76dc0afda0f8ad8daddfef716e33bad55','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe5e70d2c3f12c808814c369b4155379ea03f527bbd786cba125a48e3efd6436',2001,'TH','Thailand','introduction',229,'Background: Between 1993 and 2000,
wide-spread, often intense ethnic violence between
Hutu and Tutsi factions in Burundi created hundreds
of thousands of refugees and left tens of thousands
dead. Although some refugees have returned from
neighboring countries, continued ethnic strife has
forced many others to flee. Burundian troops, seeking
to secure their borders, have intervened in the conflict
In the Democratic Republic of the Congo.
Background: French Togoland became Togo in
1960. General Gnassingbe EYADEMA, installed as
military ruler in 1967, is Africa''s longest-serving head
of state. Despite the facade of multiparty elections that
resulted in EYADEMA''s victory in 1993, the
government continues to be dominated by the military.
In addition, Togo has come underfire from
international organizations for human rights abuses
and is plagued by political unrest. Most bilateral and
multilateral aid to Togo remains frozen.
Background: Originally settled by Polynesian
emigrants from surrounding island groups, the Tokelau
Islands were made a British protectorate in 1 889. They
were transferred to New Zealand administration in
1925. According to a UN report, these low-lying islands
will disappear in the 21st century, if global warming
continues to raise sea levels.','238a518c32111a778df1694d8a3a559b6b1a753bcef64fc1b4f856ef980958b3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fbbe528ee69bdb235d5986761a6c6af4eab6fecd5080d65f151e8f7dee802c1',2001,'CM','Cameroon','introduction',241,'Background: The former French Cameroon and
part of British Cameroon merged in 1961 to form the
present country. Cameroon has generally enjoyed
stability, which has permitted the development of
agriculture, roads, and railways, as well as a
petroleum industry. Despite movement toward
democratic reform, political power remains firmly in
the hands of an ethnic oligarchy.','a94ec5a500ab27c6acbe8391bf5a0048ac70e295e47731687c0a25b37a8d2398','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e109653d2dc67d7b768787e26483ebe009c9da1297dd14641cc6a3dc366c80f2',2001,'CA','Canada','introduction',258,'Background: The uninhabited islands were
discovered and colonized by the Portuguese in the
15th century; they subsequently became a trading
center for African slaves. Most Cape Verdeans
descend from both groups. Independence was
achieved in 1975.','fa38e380aeb8164aee208c6d5f343b05948efcf3bf4b022276ac28b5086d5c69','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2fe42b888e34a81b55df478c8246a5470da9e622b16d5b761b72a4daae0e444',2001,'KY','Cayman Islands','introduction',266,'Background: The Cayman Islands were colonized
from Jamaica by the British during the 18th and 19th
centuries. Administered by Jamaica from 1863, they
remained a British dependency after 1962 when the
former became independent.','5501ed71b5f20bb5a8fe78878ac20d37549f4870ce29810b85f2e3acbe2741c2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d6e2e968bf34ec84dc20524b3a215cb153c8311a72de09a1fdf3120fec0588e',2001,'HN','Honduras','introduction',276,'Background: The former French colony of
Ubangi-Shari became the Central African Republic
upon independence in 1960. After three tumultuous
decades of misrule - mostly by military governments -
a civilian government was installed in 1993.
Background: Part of Spain''s vast empire in the New
World, Honduras became an independent nation in
1821. After two and one-half decades of mostly
military rule, a freely elected civilian government came
to power in 1 982. During the 1 980s, Honduras proved
a haven for anti-Sandinista contras fighting the
Marxist Nicaraguan Government and an ally to
Salvadoran Government forces fighting against leftist
guerrillas.','199fd72d8e8c4b6a9693f0fab6df5aa4563e903359b82470507541fe669d721b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80314f4d8adc926038743d24a88b7f3ed3bf64a410f35bf7d0206552e8d9621c',2001,'TD','Chad','introduction',277,'Background: Chad, part of France''s African
holdings until 1960, endured three decades of ethnic
warfare as well as invasions by Libya before a
semblance of peace was finally restored in 1990. The
government eventually suppressed or came to terms
with most political-military groups, settled a territorial
dispute with Libya on terms favorable to Chad, drafted
a democratic constitution, and held multiparty
presidential and National Assembly elections in 1996
and 1997 respectively. In 1998 a new rebellion broke
out in northern Chad, which continued to escalate
throughout 2000. Despite movement toward
democratic reform, power remains in the hands of a
northern ethnic oligarchy.','217939098a293d07ee622ad2cd94e866d71006a8526af492a669abfc2f5f79c6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da73c5d6358163df6a98674192919c5cce94c8247dc27002936a60491836e7a5',2001,'CN','China','introduction',287,'Background: For centuries China has stood as a
leading civilization, outpacing the rest of the world in
the arts and sciences. But in the first half of the 20th
century, China was beset by major famines, civil
unrest, military defeats, and foreign occupation. After
World War 11, the Communists under MAO Zedong
established a dictatorship that, while ensuring
China''s sovereignty, imposed strict controls over
everyday life and cost the lives of tens of millions of
people. After 1978, his successor DENG Xiaoping
gradually introduced market-oriented reforms and
decentralized economic decision making. Output
quadrupled in the next 20 years and China now has
the world''s second largest GDP. Political controls
remain tight even while economic controls continue to
weaken.
Background: Rich fishing grounds and the potential
for gas and oil deposits have caused this archipelago
to be claimed in its entirety by China, Taiwan, and
Vietnam, while portions are claimed by Malaysia and
the Philippines. AH five parties have occupied certain
islands or reefs, and occasional clashes have occurred
between Chinese and Vietnamese naval forces','a0b364f6e65a869271930fc35557be4e43b224bfa12d3425865b03c470403871','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d24ee6b462997e49dccab1b7fa018457a948c92baa9032cc73b23d9c94afee9',2001,'CO','Colombia','introduction',310,'Background: Unstable Comoros has endured 19
coups or attempted coups since gaining
independence from France in 1975. In 1997, the
islands of Anjouan and Moheli declared their
independence from Comoros. In 1999, military chief
Col. AZALI seized power. He has pledged to resolve
the secessionist crisis through the 2000 Fomboni
Accord, a confederal arrangement that the
Organization of African Unity has yet to recognize.','fc0c1a3127049cb3dada2385b41d9f24f72947862b419e3bec8615b3fc440fd1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9fd3aebdad54aa6ffd49b9629472147acf528454e6af7a45ec6c6a58770397d',2001,'CG','Congo','introduction',325,'Background: Upon independence In 1960, the
former French region of Middle Congo became the
Republic of the Congo. A quarter century of
experimentation with Marxism was abandoned in
1990 and a democratically elected government
installed In 1992. A brief civil war in 1997 restored
former Marxist President SASSOU-NGUESSO.','a75f9703b4dceb07a4500280c9086daa461738fdf34d24b5c3f120c97d951f73','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c808e8b6463dae1d2abb905770b3a7d29b239288b3e2ab5e45e0d7ab609635ef',2001,'CK','Cook Islands','introduction',329,'Background: Named after Captain Cook, who
sighted them in 1770, the islands became a British
protectorate in 1888. By 1900, administrative control
was transferred to New Zealand; in 1965 residents
chose self-government in free association with New
Zealand. The emigration of skilled workers to New
Zealand and government deficits are continuing
problems.
Background: Scattered over some 1 million square
kilometers of ocean, the Coral Sea Islands were
declared a territory of Australia in 1969. They are
uninhabited except for a small meteorological staff on
Willis Island. Automated weather stations, beacons,
and a lighthouse occupy many other islands and
reefs.
Background: The island of Jersey and the other
Channel Islands represent the last remnants of the
medieval Dukedom of Normandy that held sway in
both France and England. These islands were the
only British soil occupied by German troops in World
Warn.
Background: Both the US and the Kingdom of
Hawaii annexed Johnston Atoll in 1858, but it was the
US that mined the guano deposits until the late 1 880s.
The US Navy took over the atoll in 1 934, and
subsequently the US Air Force assumed control in
1 948. The site was used for high altitude nuclear tests
in the 1 950s and 1 960s, and until late in 2000 the atoll
was maintained as a storage and disposal site for
chemical weapons. Munitions destruction is now
complete, and cleanup and closure of the facility is
progressing.','765a760c3e791c0826475b16c7a07a334c3b3af05cf519ce196613e41d0daeeb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fc8ae022889542feb74df8582ea02263b488de02a45eb2fdfb3558f5f914310',2001,'NI','Nicaragua','introduction',346,'Background: Close ties to France since
independence in 1960, the development of cocoa
production for export, and foreign investment made
Cote d''Ivoire one of the most prosperous of the
tropical African states. Falling cocoa prices and
political turmoil, however, sparked an economic
downturn in 1 999 and 2000. On 25 December 1 999, a
military coup - the first ever in Cote d''Ivoire''s history -
overthrew the government led by President Henri
Konan BEDIE, Presidential and legislative elections
held in October and December 2000 provoked
violence due to the exclusion of opposition leader
Alassane OUATTARA. In October 2000, Laurent
GBAGBO replaced junta leader Robert GUEI as
president, ending 10 months of military rule.','631e0c70834b662f897c2b84e61edba2b2ceb203aac82c0297cb760ea4bbffbf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c4bb5a05ee433aadbc692806d4010706cb57adbaba8237ec5977d3302a83df2',2001,'CU','Cuba','introduction',360,'Background: Fidel CASTRO led a rebel army to
victory in 1959; his iron rule has held the country
together since. Cuba''s communist revolution, with
Soviet support, was exported throughout Latin
America and Africa during the 1960s, 70s, and 80s.
The country is now slowly recovering from a severe
economic recession in 1990, following the withdrawal
of former Soviet subsidies, worth $4 billion to $6 billion
annually. Havana portrays its difficulties as the result
of the US embargo in place since 1 961 . Illicit migration
to the US - using homemade rafts, alien smugglers, or
falsified visas - is a continuing problem. Some 3,000
Cubans took to the Straits of Florida in 2000; the US
Coast Guard interdicted only about 35% of these.
Background: One of the poorest countries in the
Western Hemisphere, Haiti has been plagued by
political violence for most of its history. Over three
decades of dictatorship followed by military rule ended
in 1990 when Jean-Bertrand ARISTIDE was elected
president. Most of his term was usurped by a military
takeover, but he was able to return to office in 1994
and oversee the installation of a close associate to the
presidency in 1996. ARISTIDE won a second term as
president in 2000, and took office early the following
year.','cde25dd4b54c545022a70f28a503b813037be3958fc3274508d16343d3bf6867','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b125154aaaac87499bedaf63bcf800d1d4ee85cd2d200f337dec481780fbe984',2001,'CY','Cyprus','introduction',369,'Background: Independence from the UK was
approved in 1960 with constitutional guarantees by
the Greek Cypriot majority to the Turkish Cypriot
minority. In 1 974, a Greek-sponsored attempt to seize
the government was met by military intervention from
Turkey, which soon controlled almost 40% of the
island. In 1983, the Turkish-held area declared itself
the "Turkish Republic of Northern Cyprus", but it is
recognized only by Turkey. UN-led talks on the status
of Cyprus resumed in December 1999 to prepare the
ground for meaningful negotiations leading to a
comprehensive settlement.
Background: Once the seat of Viking raiders and
later a major north European power, Denmark has
evolved into a modern, prosperous nation that is
participating in the political and economic integration
of Europe. So far, however, the country has opted out
of some aspects of the European Union''s Maastricht
Treaty, including the economic and monetary system
(EMU) and issues concerning certain internal affairs.','64544542f1dae15cee9c12e3d29c3a5ecabcac08d58dcdea39f55992aa35a193','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3a26e9ed60caa1646b2f625b5297caf417d0fd00b7197cc399e5581a7a8aadd',2001,'EG','Egypt','introduction',404,'Background: Nominally independent from the UK in
1 922, Egypt acquired full sovereignty following World
War II. The completion of the Aswan High Dam in
1971 and the resultant Lake Nasser have altered the
time-honored place of the Nile river in the agriculture
and ecology of Egypt. A rapidly growing population
(the largest in the Arab world), limited arable land, and
dependence on the Nile all continue to overtax
resources and stress society. The government has
struggled to ready the economy for the new
millennium through economic reform and massive
investment in communications and physical
infrastructure.','90bc1f2aa178bcff903235985a474ac1e93431f88feab957529a9f130853df0b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4e864d301f8898e84773569d455c15f77a5ba5d3a7a3c11338c4f271ae02fa8',2001,'SV','El Salvador','introduction',413,'Background: El Salvador achieved independence
from Spain in 1821 and from the Central American
Federation in 1839. A 12-year civil war, which cost the
lives of some 75,000 people, was brought to a close in
1992 when the government and leftist rebels signed a
treaty that provided for military and political reforms.','eb459c15f0fe2b0768d3ce3f27e7015d995b9b7ec31104588945ede9f2e54e26','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b999f3ded69e66de79c774e4ae9fadceb6eb0300ca8ebb84d952c2e7e0afdfa8',2001,'GN','Guinea','introduction',431,'Background: Eritrea was awarded to Ethiopia in
1952 as part of a federation. Ethiopia''s annexation of
Eritrea as a province 1 0 years later sparked a 30-year
struggle for independence that ended in 1991 with
Eritrean rebels defeating governmental forces;
independence was overwhelmingly approved in a
1993 referendum. A two and a half year border war
with Ethiopia that erupted in 1998 ended under UN
auspices on 12 December 2000.
Background: The eastern half of the island of New
Guinea - second largest in the world - was divided
between Germany (north) and the UK (south) in 1885.
The latter area was transferred to Australia in 1902,
which occupied the northern portion during World War
I and continued to administer the combined areas until
independence in 1 975. A nine-year secessionist revolt
on the island of Bougainville ended in 1997, after
claiming some 20,000 lives.
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural gas,
timber, oil, fisheries
Land use:
arable land: 0.1%
permanent crops: 1%
permanent pastures: 0%
forests and woodland: 92.9%
other: 0% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: active volcanism; situated along
the Pacific "Rim of Fire"; the country is subject to
frequent and sometimes severe earthquakes; mud
slides; tsunamis
Environment - current issues: rain forest subject to
deforestation as a result of growing commercial
demand for tropical timber; pollution from mining
projects; severe drought
Environment - international agreements:
party to; Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol
Geography - note: shares island of New Guinea
with Indonesia; one of world''s largest swamps along
southwest coast
Background: This archipelago is surrounded by
productive fishing grounds and potentially large oil
reserves. In 1932, French Indochina annexed the
islands and set up a weather station on Prattle Island;
maintenance was continued by its successor
Vietnam. China has occupied the Paracel Islands
since 1974, when its troops captured a South
Vietnamese garrison occupying the western islands.
However, the islands are still claimed by Vietnam and
Taiwan.','b263251051c4db658772bed53698e446de0a4a878faee513dd998513f69f361b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d739e57c0cb404409d534e44e7f2ec08578f88ccff5dd5f9286562ad786e462',2001,'DK','Denmark','introduction',451,'Background: Fiji became independent in 1 970, after
nearly a century as a British colony. Democratic rule
was interrupted by two military coups in 1 987, caused
by concern over a government perceived as
dominated by the Indian community (descendants of
contract laborers brought to the islands by the British
in the 19th century). A 1990 constitution favored
native Melanesian control of Fiji, but led to heavy
Indian emigration; the population loss resulted in
economic difficulties, but ensured that Melanesians
became the majority. Amendments enacted in 1997
made the constitution more equitable. Free and
peaceful elections in 1999 resulted in a government
led by an Indo-Fijian, but a coup in May of 2000
ushered in a prolonged period of political turmoil. New
elections are scheduled for August 2001 .','b7982b65f3c0c76d1a9f12a3e0dbb1583cbc17e7035892fda1e47d84c25039cd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ad6abebcaeb8424db766201099bbb8997688a4729be48c6c1331dbe312bfa32',2001,'JE','Jersey','introduction',462,'Background: Ruled by Sweden from the 1 2th to the
19th centuries and by Russia from 1809, Finland
finally won its independence in 1917. During World
War II, it was able to successfully defend its freedom
and fend off invasions by the Soviet Union and
Germany. In the subsequent half century, the Finns
have made a remarkable transformation from a farm/
forest economy to a diversified modern industrial
economy; per capita income is now on par with
Western Europe. As a member of the European
Union, Finland was the only Nordic state to join the
euro system at its initiation in January 1999.
Background: A military power during the 17th
century, Sweden has not participated in any war in
almost two centuries. An armed neutrality was
preserved in both World Wars. Sweden''s
long-successful economic formula of a capitalist
system interlarded with substantial welfare elements
has recently been undermined by high unemployment,
rising maintenance costs, and a declining position in
world markets. Indecision over the country''s role in the
political and economic integration of Europe caused
Sweden not to join the EU until 1 995, and to forgo the
introduction of the euro in 1999.
Area ■ comparative: slightly larger than California
Land boundaries:
total: 2,205 km
border countries: Finland 586 km, Norway 1,619 km
Coastline: 3,218 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: agreed boundaries or
midlines
territorial sea: 12 NM (adjustments made to return a
portion of straits to high seas)
Climate: temperate in south with cold, cloudy winters
and cool, partly cloudy summers; subarctic in north
Terrain: mostly flat or gently rolling lowlands;
mountains in west
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Kebnekaise 2,1 1 1 m
Natural resources: zinc, iron ore, lead, copper,
silver, timber, uranium, hydropower
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 1 %
forests and woodland: 68%
of/7er;24%(1993 est.)
Irrigated land: 1,150 sq km (1993 est.)
Natural hazards: ice floes in the surrounding waters,
especially in the Gulf of Bothnia, can interfere with
maritime traffic
Environment - current Issues: acid rain damaging
soils and lakes; pollution of the North Sea and the
Baltic Sea
Environment - international agreements:
party to,- Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: strategic location along Danish
Straits linking Baltic and North Seas','45ce5b7bf949912d626bd4caeae9de7507439052f55eb7a7022ac4121cd602f9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ca29b9cca1c65e6de05df432cfb7e44ec3ff9d1017b7e0e0da06ff1ec590a4',2001,'KI','Kiribati','introduction',476,'Background: The French annexed various
Polynesian island groups during the 19th century. In
September 1995, France stirred up widespread
protests by resuming nuclear testing on the Mururoa
atoll after a three-year moratorium. The tests were
suspended in January 1996.
Background: The Gilbert Islands were granted
self-rule by the UK in 1971 and complete
independence in 1 979 under the new name of Kiribati.
The US relinquished all claims to the sparsely
inhabited Phoenix and Line Island groups in a 1979
treaty of friendship with Kiribati.
Background: Kuwait was attacked and overrun by
Iraq on 2 August 1990. Following several weeks of
aerial bombardment, a US-led UN coalition began a
ground assault on 23 February 1991 that completely
liberated Kuwait in four days. Kuwait has spent more
than $5 billion to repair oil infrastructure damaged
during 1990-91.','33efc797eee3ebf84a2f9b65ca3d3bd6bf702f7505753de672d5ff56c7f64cd6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac71eb4f2e1db2d1f4558e519a6368427060a710c796b25ad7b8b5b7cb9c8e3b',2001,'DE','Germany','introduction',484,'Background: As Western Europe''s richest and most
populous nation, Germany remains a key member of
the continent''s economic, political, and defense
organizations. European power struggles immersed
the country in two devastating World Wars in the first
half of the 20th century and left the country occupied
by the victorious Allied powers of the US, UK, France,
and the Soviet Union in 1 945. With the advent of the
Cold War, two German states were formed in 1949:
the western Federal Republic of Germany (FRG) and
the eastern German Democratic Republic (GDR). The
democratic FRG embedded itself in key Western
economic and security organizations, the EC and
NATO, while the communist GDR was on the front line
of the Soviet-led Warsaw Pact. The decline of the
USSR and the end of the Cold War allowed for
German unification in 1990. Since then Germany has
expended considerable funds to bring eastern
productivity and wages up to western standards. In
January 1999, Germany and 10 other EU countries
formed a common European currency, the euro.
Background: The Kingdom of the Netherlands was
formed in 1815. In 1830 Belgium seceded and formed
a separate kingdom. The Netherlands remained
neutral in World War 1 but suffered a brutal invasion
and occupation by Germany in World War 11. A
modern, industrialized nation, the Netherlands is also
a large exporter of agricultural products. The country
was a founding member of NATO and the EC, and
participated in the introduction of the euro in 1999.','cc3ca788dff422775d36391353abbbd781166cc9b1c7666930fd5c7ef622f41d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc4daa6ab1b251b7119896722466a681f7a81fef583518ad387625e511d8a078',2001,'GI','Gibraltar','introduction',508,'Background: A French possession since 1892, the
Glorioso Islands are composed of two lushly
vegetated islands (lie Glorieuse and He du Lys) and
three rock islets. A military garrison operates a
weather and radio station on He Glorieuse.','d9385fbea9d27c060cd7a686f4585ed848d0da4568cd43f748919360491f059d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e1f66c60ebe18c40468745c5e7783cdb989047ddc82807b4782617df76bb4e2',2001,'GU','Guam','introduction',535,'Background: Guam was ceded to the US by Spain
in 1898. Captured by the Japanese in 1941, it was
retaken by the US three years later. The military
installation on the island is one of the most
strategically important US bases in the Pacific.','a1523d02d32402d3f22042645e6d790205760acb2016a3569de58d682aa4a2f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88e7bdef236dafb31a2efd94cdf4381920093a7d1fa247d2b49f21c2fc91e401',2001,'HU','Hungary','introduction',579,'Background: Hungary was part of the polyglot
Austro-Hungarian Empire, which collapsed during
World War I. The country fell under communist rule
following World War 11. In 1 956, a revolt and
announced withdrawal from the Warsaw Pact were
met with a massive military intervention by Moscow. In
the more open GORBACHEV years, Hungary led the
movement to dissolve the Warsaw Pact and steadily
shifted toward multiparty democracy and a
market-oriented economy. Following the collapse of
the USSR in 1991 , Hungary developed close political
and economic ties to Western Europe. It joined NATO
in 1999 and is a frontrunner in a future expansion of
the EU.
Background: Italy became a nation-state belatedly -
in 1861 when the city-states of the peninsula, along
with Sardinia and Sicily, were united under King Victor
EMMANUEL. An era of parliamentary government
came to a close in the early 1 920s when Benito
MUSSOLINI established a Fascist dictatorship. His
disastrous alliance with Nazi Germany led to Italy''s
defeat in World War II. A democratic republic replaced
the monarchy in 1946 and economic revival followed.
Italy was a charter member of NATO and the
European Economic Community (EEC). It has been at
the forefront of European economic and political
unification, joining the European Monetary Union in
1 999. Persistent problems include illegal immigration,
the ravages of organized crime, corruption, high
unemployment, and the low incomes and technical
standards of southern Italy compared with the more
prosperous north.
Background: In 1 91 8 the Slovaks joined the closely
related Czechs to form Czechoslovakia. Following the
chaos of World War II, Czechoslovakia became a
communist nation within Soviet-ruled Eastern Europe.
Soviet influence collapsed in 1989 and
Czechoslovakia once more became free. The Slovaks
and the Czechs agreed to separate peacefully on
1 January 1993. Historic, political, and geographic
factors have caused Slovakia to experience more
difficulty in developing a modern market economy
than some of its Central European neighbors.','355edbabe3c195c0ff1640adb709875173e74d350cec72212c8b521252e1f8f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69c0426366335232b9599e298e1fd004604899fe1f262d66e4eeeb539be4a376',2001,'AT','Austria','introduction',589,'Background: The Indus Valley civilization, one of
the oldest in the world, goes back at least 5,000 years.
Aryan tribes from the northwest invaded about 1500
B.C.; their merger with the earlier inhabitants created
classical Indian culture. Arab incursions starting in the
8th century and Turkish in 12th were followed by
European traders beginning in the late 15th century.
By the 19th century, Britain had assumed political
control of virtually all Indian lands. Nonviolent
resistance to British colonialism under Mohandas
GANDHI and Jawaharlal NEHRU led to
independence in 1947. The subcontinent was divided
into the secular state of India and the smaller Muslim
state of Pakistan. A third war between the two
countries in 1971 resulted in East Pakistan becoming
the separate nation of Bangladesh. Fundamental
concerns in India include the ongoing dispute with
Pakistan over Kashmir, massive overpopulation,
environmental degradation, extensive poverty, and
ethnic strife, all this despite impressive gains in
economic investment and output.
Background: The Indian Ocean is the third-iargest
of the world''s five oceans (after the Pacific Ocean and
Atlantic Ocean, but larger than the Southern Ocean
and Arctic Ocean). Four critically important access
waterways are the Suez Cana! (Egypt), Bab el
Mandeb (Djibouti-Yemen), Strait of Hormuz
(Iran-Oman), and Strait of Malacca
(Indonesia-Malaysia). The decision by the
International Hydrographic Organization in the spring
of 2000 to delimit a fifth ocean, the Southern Ocean,
removed the portion of the Indian Ocean south of 60
degrees south.
Background: Known as Persia until 1935, Iran
became an Islamic republic in 1979 after the ruling
shah was forced into exile. Conservative clerical
forces subsequently crushed westernizing liberal
elements. Militant Iranian students seized the US
Embassy in Tehran on 4 November 1979 and held it
until 20 January 1981. During 1980-88, Iran fought a
bloody, indecisive war with Iraq over disputed
territory. The key current issue is how rapidly the
country should open up to the modernizing influences
of the outside world.','64e93b318d42d95879268ffa78366a85daa209e68e36fbb18a61935236d06bb0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1bd296010ee34aff2fddcd75124f20b750d14f74228240fd332ab56fa4f4b25',2001,'JM','Jamaica','introduction',616,'Background: Jamaica gained full independence
within the British Commonwealth in 1962.
Deteriorating economic conditions during the 1970s
led to recurrent violence and a dropoff in tourism.
Elections in 1 980 saw the democratic socialists voted
out of office. Subsequent governments have been
open market oriented. Political violence marred
elections during the 1990s.','be008c34afa6e37932c3ccb7367e5fb85e7bff9ec68813099abb3164a7651dfa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b833abb84669ba770f4b9839e5805e19e1ff438b6d7a918f8cf4b9c3fcbb264',2001,'NO','Norway','introduction',628,'Background: While retaining its time-honored
culture, Japan rapidly absorbed Western technology
during the late 19th and early 20th centuries. After its
devastating defeat in World War II, Japan recovered
to become the second most powerful economy in the
world and a staunch ally of the US. While the emperor
retains his throne as a symbol of national unity, actual
power rests in networks of powerful politicians,
bureaucrats, and business executives. The economy
experienced a major slowdown in the 1 990s following
three decades of unprecedented growth.
Background: The Pacific Ocean is the largest of the
world''s five oceans (followed by the Atlantic Ocean,
Indian Ocean, Southern Ocean, and Arctic Ocean).
Strategically important access waterways include the
La Perouse, Tsugaru, Tsushima, Taiwan, Singapore,
and Torres Straits. The decision by the international
Hydrographic Organization in the spring of 2000 to
delimit a fifth ocean, the Southern Ocean, removed
the portion of the Pacific Ocean south of 60 degrees
south.
Background: The separation in 1947 of British India
into the Muslim state of Pakistan (with two sections
West and East) and largely Hindu India was never
satisfactorily resolved. A third war between these
countries in 1971 resulted in East Pakistan seceding
and becoming the separate nation of Bangladesh. A
dispute over the state of Kashmir is ongoing. In
response to Indian nuclear weapons testing, Pakistan
conducted its own tests in 1998.
Background: After three decades as part of the UN
Trust Territory of the Pacific under US administration,
this westernmost cluster of the Caroline Islands opted
for independent status in 1978 rather than join the
Federated States of Micronesia. A Compact of Free
Association with the US was approved in 1 986, but not
ratified until 1993. It entered into force the following
year when the islands gained their independence.','ea0514a51ded8802ff171730dd0da66e3309c0f35cb55abad04ca6bb62eaa744','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ba321c5df61be2684a95f884b75aabee22facf7093ce03629fea4897941041c',2001,'JO','Jordan','introduction',636,'Natural resources: phosphates, potash, shale oil
Land use:
arable land: 4%
permanent crops: ^%
permanent pastures: 9%
forests and woodland: 1 %
other: S5%{^993 est.)
Irrigated land: 630 sq km (1 993 est.)
Natural hazards: droughts
Environment - current Issues: limited natural fresh
water resources; deforestation; overgrazing; soil
erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements','5291203a333aa4afc2a679dc29dfc9374a0bb673b46f759c4d8e1168b42ba435','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc2a121da1b9f1cb344f9c53faca75e3dfe5ad78018660a8c448942850344a07',2001,'MZ','Mozambique','introduction',644,'Background: Named after a famous 15th century
Spanish navigator and explorer, the island has been a
French possession since 1897. It has been exploited
for its guano and phosphate. Presently a small military
garrison oversees a meteorological station.','ad8e18f7c636191b898f7d3f7522eb3468cfa74627b3472e5b4c5c513c445001','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fa17d2cf7f251e0f206320ed30357c01713fa9e684d23d0538f687df43734a',2001,'KZ','Kazakhstan','introduction',645,'Background: Native Kazakhs, a mix of Turkic and
Mongol nomadic tribes who migrated into the region in
the 13th century, were rarely united as a single nation.
The area was conquered by Russia in the 18th
century and Kazakhstan became a Soviet Republic in
1936. During the 1950s and 1960s agricultural "Virgin
Lands" program, Soviet citizens were encouraged to
help cultivate Kazakhstan''s northern pastures. This
Influx of immigrants (mostly Russians, but also some
other deported nationalities) skewed the ethnic
mixture and enabled non-Kazakhs to outnumber
natives. Independence has caused many of these
newcomers to emigrate. Current issues include:
developing a cohesive national identity; expanding the
development of the country''s vast energy resources
and exporting them to world markets; and continuing
to strengthen relations with neighboring states and
other foreign powers.','b28ac4ac7f975e729e491b3896300d132bf40890d851edeab33ccc129d1455ac','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49790a7128033fb641138a1ce183b858a5b4eacc8e24a28a44ad59795587ff40',2001,'KE','Kenya','introduction',654,'Background: Revered president and liberation
struggle icon Jomo KENYATTA led Kenya from
independence until his death in 1978, when current
President Daniel Toroitich arap MOI took power in a
constitutional succession. The country was a de facto
one-party state from 1969 until 1982 when the ruling
Kenya African National Union (KANU) made itself the
sole legal party in Kenya. MOI acceded to internal and
external pressure for political liberalization in late
1991. The ethnically fractured opposition failed to
dislodge KANU from power in elections In 1992 and
1997, which were marred by violence and fraud, but
are viewed as having generally reflected the will of the
Kenyan people. The country faces a period of political
uncertainty because MOI is constitutionally required
to step down at the next elections that have to be held
by early 2003.
Background: The US annexed the reef in 1922. Its
sheltered lagoon served as a way station for flying
boats on Hawaii-to-American Samoa flights during the
late 1930s. There is no flora on the reef, which is
frequently awash, but it does support an abundant and
diverse marine fauna. In 2001 , the waters surrounding
the reef were designated a National Wildlife Refuge.','337fe7516a3d527d174a8e44a50aa4a4a320e8f10e21c4832d32989e0603f38b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6c334a50a5b86d1a29d3c0b25c26ab84d87c9869a6199d4bb04cff4789f831d',2001,'KG','Kyrgyzstan','introduction',670,'Background: A Central Asian country of incredible
natural beauty and proud nomadic traditions,
Kyrgyzstan was annexed by Russia in 1864; it
achieved Independence from the Soviet Union in
1991. Current concerns include: privatization of
state-owned enterprises, expansion of democracy
and political freedoms. Inter-ethnic relations, and
Background: In 1975 the communist Pathet Lao
took control of the government, ending a
six-century-old monarchy. Initial closer ties to Vietnam
and socialization were replaced with a gradual return
to private enterprise, an easing of foreign investment
laws, and the admission into ASEAN in 1997.','6410a793b6ec9ecb13ad84aca08a30e59a001dcf60ba1d6e909440d349c64b54','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('545812611b00a4345d5df913d50e95f63722777f4bd0fd21850bbe8a8aabe9cf',2001,'LV','Latvia','introduction',679,'Background: After a brief period of independence
between the two World Wars, Latvia was annexed by
the USSR in 1940. It reestablished its independence
in 1991 following the breakup of the Soviet Union.
Although the last Russian troops left in 1994, the
status of the Russian minority (some 30% of the
population) remains of concern to Moscow. Latvia
continues to revamp its economy for eventual
integration into various Western European political
and economic institutions.','11cacd6000ced17d1c75c759313a7d9fe25e8a815fd8a8ae88112819a5a1b05c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fb4551832ca2f02a9892863798606fe58b1bf8477d035ebc19fe036389bd96a',2001,'LB','Lebanon','introduction',696,'Background: Basutoland was renamed the
Kingdom of Lesotho upon independence from the UK
in 1966. Constitutional government was restored in
1993 after 23 years of military rule.','fa67cffe0c367cf7a1854229326bd7f387d3e46f278494081237affe313a9032','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9963d56f147429a20ff696f7f9a082c8bc4706d6a3151626845e8a002602d24e',2001,'LY','Libya','introduction',720,'Land use:
arable land: 24%
permanent crops: 0%
permanent pastures: 16%
forests and woodland: 35%
other: 25% est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environn^ent ■ current issues: NA
Environment - international agreements;
party to; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Law of the Sea
Geography - note; along with Uzbekistan, one of
only two doubly landlocked countries in the world;
variety of microclimatic variations based on elevation
Background: The Principality of Liechtenstein was
established within the Holy Roman Empire in 1719; it
became a sovereign state in 1806. Until the end of
World War I, It was closely tied to Austria, but the
economic devastation caused by that conflict forced
Liechtenstein to conclude a customs and monetary
union with Switzerland. Since World War II (in which
Liechtenstein remained neutral) the country''s low
taxes have spurred outstanding economic growth.
However, shortcomings in banking regulatory
oversight have resulted in concerns about the use.of
the financial institutions for money laundering.','6006643bcc882010742e615a5d2a28ab22037a2f6b8796fb32b3bf2286ce364d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('690ee58c349f38effb9091083243e58275d99ee929a25c2d4514c3c65a1f0ca6',2001,'CH','Switzerland','introduction',729,'Background: Independent between the two World
Wars, Lithuania was annexed by the USSR in 1 940.
On 1 1 March 1990, Lithuania became the first of the
Soviet republics to declare its independence, but this
proclamation was not generally recognized until
September of 1991 (following the abortive coup In
Moscow). The last Russian troops withdrew in 1993.
Lithuania subsequently has restructured its economy
for eventual integration into Western European
institutions.
Background: Switzerland''s independence and
neutrality have long been honored by the major
European powers and Switzerland was not involved in
either of the two World Wars. The political and
economic integration of Europe over the past half
century, as well as Switzerland''s role in many UN and
international organizations, may be rendering
obsolete the country''s concern for neutrality.','68b9baf742b0ff822875b49bf33659f59642965a616c4c674b624ed4bdca4202','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('428b67e2b0afe986f4a616bb3b350e22ba8db132d16834764ca99b46da82c29e',2001,'PH','Philippines','introduction',749,'Background: Malaysia was created in 1963 through
^Sandakan
,
Natural resources: tin, petroleum, timber, copper,
iron ore, natural gas, bauxite
I aniH iiQA''
Background: In the disastrous War of the Triple
Alliance (1865-70), Paraguay lost two-thirds of all
adult males and much of its territory. It stagnated
economically for the next half century. In the Chaco
War of 1932-35, large, economically important areas
were won from Bolivia. The 35-year military
dictatorship of Alfredo STROESSNER was
overthrown in 1989, and, despite a marked increase in
political infighting in recent years, relatively free and
regular presidential elections have been held since
then.','9447502fae90cc62b5d2ee1ed8f68386f0f3931450a148a46a4c12dc000034a6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('035995e1308e1b366e255f976a24ca3a2fe6e51cec7401a310418ef666f71bf8',2001,'MV','Maldives','introduction',758,'Background: The Maldives were long a sultanate,
first under Dutch and then under British protection.
They became a republic in 1 968, three years after
independence. Tourism and fishing are being
developed on the archipelago.','6473ec39221ddcad1e3c944a760aa578aeb1959d5c9e1bc93ac1b27cd459ec94','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c69bc4a80783fb931bde8091c83b230ba111571df7b23ac16f7dd4f0d5d858ed',2001,'MH','Marshall Islands','introduction',782,'Background: After almost four decades under US
administration as the easternmost part of the UN Trust
Territory of the Pacific Islands, the Marshall Islands
attained independence in 1986 under a Compact of
Free Association. Compensation claims continue as a
result of US nuclear testing on some of the islands
between 1947 and 1962.','909bc433038b1d4218dca3237e47ee5a6c0674c9ba4a5ad61bcce9090d391660','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d2766a0137000b15cac4cbc3c9154bc267324664506b055cbebe04930a113a2',2001,'MR','Mauritania','introduction',794,'Background; Independent from France in 1960,
Mauritania annexed the southern third of the former
Spanish Sahara (now Western Sahara) in 1976, but
relinquished it after three years of raids by the
Polisario guerrilla front seeking independence for the
territory. Opposition parties were legalized and a new
constitution approved in 1991. Two multiparty
presidential elections since then were widely seen as
being flawed; Mauritania remains, in reality, a
one-party state. The country continues to experience
ethnic tensions between its black minority population
and the dominant Maur (Arab-Berber) populace.','0ecc10400272b69d665444231cb3cc9ae390c8b79784bb14d0148d1ffc376ab3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd446ee7a60a310b39fa18757c8b4bb100fba7ab1203359aa99d51ac789399fd',2001,'MU','Mauritius','introduction',803,'Background: Discovered by the Portuguese in 1 505,
Mauritius was subsequently held by the Dutch,
French, and British before independence was attained
in 1 968. A stable democracy with regular free elections
and a positive human rights record, the country has
attracted considerable foreign investment and has
earned one of Africa''s highest per capita incomes.
Recent poor weather and declining sugar prices have
slowed economic growth leading to some protests
over standards of living in the Creole community.','55d8580a2f2f561cfc338999527753bd1492498c5ea455fad84bc6fb7ff4c814','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b68e5e9839031e284db7d35e6f7b1a255d5fea919c64b5436e7bd140804cfb8',2001,'US','United States','introduction',822,'Background: The site of advanced Amerindian
civilizations, Mexico came under Spanish rule for
three centuries before achieving independence early
in the 19th century. A devaluation of the peso in late
1994 threw Mexico into economic turmoil, triggering
the worst recession in over half a century. The nation
continues to make an impressive recovery. Ongoing
economic and social concerns include low real wages,
underemployment for a large segment of the
population, inequitable income distribution, and few
advancement opportunities for the largely Amerindian
population in the impoverished southern states.
Background: In 1979 the Federated States of
Micronesia, a UN Trust Territory under US
administration, adopted a constitution. In 1986
independence was attained under a Compact of Free
Association with the United States. Present concerns
include large-scale unemployment, overfishing, and
overdependence on US aid.
Background: The United States became the world''s
first modern democracy after its break with Great
Britain (1776) and the adoption of a constitution
(1789). During the 19th century, many new states
were added to the original 13 as the nation expanded
across the North American continent and acquired a
number of overseas possessions. The two most
traumatic experiences in the nation''s history were the
Civil War (1861-65) and the Great Depression of the
1 930s. Buoyed by victories in World Wars I and II and
the end of the Cold War in 1 991 , the US remains the
world''s most powerful nation-state. The economy is
marked by steady growth, low unemployment and
Inflation, and rapid advances in technology.','77cc17affedf0e933d0a1b4c10daa8b4323f860428448f7aaa339221683d6485','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36a380bfbc06096cdca4e4ce4126a331a46944808634f75b28922680437186b3',2001,'MA','Morocco','introduction',845,'Background: Morocco''s long struggle for
independence from France ended in 1956. The
internationalized city of T angier was turned over to the
new country that same year. Morocco virtually
annexed Western Sahara during the late 1970s, but
final resolution on the status of the territory remains
unresolved. Gradual political reforms in the 1990s
resulted in the establishment of a bicameral
legislature in 1997.','5f4c9053a0571897ddce48826b9f79596c72f386812066f90a64e281afc9f7f1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b47e1a23c9d1f03e4665042f61ca07610e9e6cd48fd5ef068b99788e1dbbd058',2001,'NP','Nepal','introduction',863,'Background: In 1 951 , the Nepalese monarch ended
the century-old system of rule by hereditary premiers
and instituted a cabinet system of government.
Reforms in 1990 established a multiparty democracy
within the framework of a constitutional monarchy.
The refugee issue of some 100,000 Bhutanese in
Nepal remains unresolved; 90% of these displaced
persons are housed in seven United Nations Offices
of the High Commissioner for Refugees (UNHCR)
camps.','fd953ce8f28d64fe071571d54be6e34e57382279b52e764cf0176a8446a8abdf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfb69182b0f02cd015232659acb6456145c37974c9c21027b76a6fa897532a4d',2001,'NU','Niue','introduction',902,'Background: Niue''s remoteness, as well as cultural
and linguistic differences between its Polynesian
inhabitants and those of the rest of the Cook Islands,
have caused it to be separately administered. The
population of the island continues to drop (from a peak
of 5,200 in 1966 to 2,100 in 2000) with substantial
emigration to New Zealand.','a8b111f65ec94e87c40792efb1e991f10e512762c10ddc3b396ac43c6528d72d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e69e67034a8695f2da69076d43976f1df0c6b983af2f21424f80c2646f367ff0',2001,'PN','Pitcairn','introduction',926,'Background: Pitcairn Island was discovered in 1767
by the British and settled in 1790 by the Bounty
mutineers and their Tahitian companions. Pitcairn
was the first Pacific island to become a British colony
(In 1838) and today remains the last vestige of that
empire in the South Pacific. Outmigration, primarily to
New Zealand, has thinned the population from a peak
of 233 in 1937 to about 50 today.','230d83ddb63cc21f778c366eb40117cac15381231e636d8a10e9d6b8127551e3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aee556d36e0deac045ed863246222371d68f62633e7fe2a3a903e2dd0ca2b105',2001,'PL','Poland','introduction',933,'Background: Poland gained its independence in
1918 only to be overrun by Germany and the Soviet
Union in World War ll. It became a Soviet satellite
country following the war, but one that was
comparatively tolerant and progressive. Labor turmoil
in 1980 led to the formation of the independent trade
union "Solidarity" that over time became a political
force and by 1990 had swept parliamentary elections
and the presidency. A "shock therapy" program during
the early 1990s enabled the country to transform its
economy into one of the most robust in Central
Europe, boosting hopes for acceptance to the EU.
Poland joined the NATO alliance in 1999.','9377d97e30558adebdb7fe586714b8937115573941f6264e5197f060409c2c9d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fa7c5c0a1441e14720876fde3441d8b3e5da85f274996b016c84f992e9a6cc0',2001,'PR','Puerto Rico','introduction',945,'Background: Discovered by Columbus in 1493, the
island was ceded by Spain to the US in 1 898 following
the Spanish-American War. A popularly elected
governor has served since 1 948. In plebiscites held in
1 967 and 1 993, voters chose to retain commonwealth
status.','db77a5370f36bfe3149d954c538482c6d6b68558ec3eb3b6b551c6a041f3c206','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('331dae6644f2c59cc88727c7bd94533b8007246917d7db400119bf2868f6c577',2001,'QA','Qatar','introduction',955,'Background: The Portuguese discovered the
uninhabited island in 1513. From the 17th to the 19th
centuries, French immigration supplemented by
influxes of Africans, Chinese, Malays, and Malabar
Indians gave the island its ethnic mix. The opening of
the Suez Canal in 1869 cost the island its importance
as a stopover on the East Indies trade route.','4a7ff4e4c56fa3c28fecbab6faf26a09efdc7277200b098b2e18d17072bea512','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('541c6b483eea2e45326cc8b3bc7b522480b366447ed058059b77709906e2c67a',2001,'UA','Ukraine','introduction',965,'Background: The defeat of the Russian Empire in
World War I led to the seizure of power by the
communists and the formation of the USSR. The
brutal rule of Josef STALIN (1924-53) strengthened
Russian dominance of the Soviet Union at a cost of
tens of millions of lives. The Soviet economy and
society stagnated in the following decades until
General Secretary Mikhail GORBACHEV (1985-91)
introduced glasnost (openness) and perestroika
(restructuring) in an attempt to modernize
communism, but his initiatives inadvertently released
forces that by December 1991 splintered the USSR
into 1 5 independent republics. Since then, Russia has
struggled in its efforts to build a democratic political
system and market economy to replace the strict
social, political, and economic controls of the
communist period.
Background: In 1959, three years before
independence, the majority ethnic group, the Hutus
overthrew the ruling Tutsi king. Over the next several
years thousands of Tutsis were killed, and some
150,000 driven into exile in neighboring countries.
The children of these exiles later formed a rebel
group, the Rwandan Patriotic Front (RPF) and began
a civil war in 1990. The war, along with several
political and economic upheavals, exacerbated ethnic
tensions culminating in April 1994 in the genocide of
roughly 800,000 Tutsis and moderate Hutus. The
Tutsi rebels defeated the Hutu regime and ended the
killing in July 1994, but approximately 2 million Hutu
refugees - many fearing Tutsi retribution - fled to
neighboring Burundi, Tanzania, Uganda, and Zaire,
now called the Democratic Republic of the Congo
(DROC). Since then most of the refugees have
returned to Rwanda. Despite substantial international
assistance and political reforms - including Rwanda''s
first local elections in March 1999 - the country
continues to struggle to boost investment and
agricultural output and to foster reconciliation. A
series of massive population displacements, a
nagging Hutu extremist insurgency, and Rwandan
involvement in two wars over the past four years in the
neighboring DROC continue to hinder Rwanda''s
efforts.
Background: Uninhabited when first discovered by
the Portuguese in 1502, St. Helena was garrisoned by
the British during the 17th century. It acquired fame as
the place of Napoleon BONAPARTE''S exile, from
1815 until his death in 1821, but its importance as a
port of call declined after the opening of the Suez
Canal in 1 869. Ascension Island is the site of a US Air
Force auxiliary airfield; Gough Island has a
meteorological station.
Background: First settled by the British in 1 623, the
islands became an associated state with full internal
autonomy in 1 967. The island of Anguilla rebelled and
was allowed to secede in 1971 . Saint Kitts and Nevis
achieved independence in 1983. In 1998, a vote in
Nevis on a referendum to separate from Saint Kitts fell
short of the two-thirds majority needed.','8afb5fa40d2c9f475e32d4153ece991bc15de3222896b8ffc1aa5161c7bff509','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e51870af820605641fd69a78285f8dd69b3cf28cc733620de17e1c0c2d49e5',2001,'LC','Saint Lucia','introduction',974,'Background: The island, with its fine natural harbor
at Castries, was contested between England and
France throughout the 17th and early 18th centuries
(changing possession 1 4 times); it was finally ceded to
the UK in 1 81 4. Self-government was granted in 1 967
and independence in 1979.','4aedf93765b71242d8cf7e77b5ec64bb6ac2e998aa2f3b2b0a069d91e1c9965b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90b14af786f122d8b7b69d8dd8c05887bdc798be7a7f953fbc1526544b984435',2001,'MQ','Martinique','introduction',979,'Background: First settled by the French in the early
17th century, the islands represent the sole remaining
vestige of France''s once vast North American
possessions.','5a2689915f569226bd29881bb57bea76279758b5c66b83ea833263c29648cfbc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8c7bd7e5f63876f471e71fc8437eec1e5593d1c67a7436d310488a26e274df2',2001,'GD','Grenada','introduction',981,'Background: Disputed between France and Great
Britain in the 1 8th century, Saint Vincent was ceded to
the latter in 1783. Autonomy was granted in 1969, and
independence in 1979.','0fc0932eebe64b9ab1a863c257869d800b0670a8adf6ed2cd54168322f50056d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('894838b2c1e068d2797567f40a488c1d2dd0e7b3215ace77171d73f8f92b34aa',2001,'WS','Samoa','introduction',982,'Background: New Zealand occupied the German
protectorate of Western Samoa at the outbreak of
World War I in 1914. It continued to administer the
islands as a mandate and then as a trust territory until
1962, when the islands became the first Polynesian
nation to reestablish independence in the 20th
century. The country dropped the "Western" from its
name in 1997.','60d74e2d830f984a53f3ab7842cf7c5ed9282183114df739cdd57b63e383b6fd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('008b0b40b13b0c068eaaaba5e4f7b7f495ea5a7c4501ac8918fc9678534656cf',2001,'SC','Seychelles','introduction',989,'Background: A lengthy struggle between France
and Great Britain for the islands ended in 1814, when
they were ceded to the latter. Independence came in
1 976. Socialist rule was brought to a close with a new
constitution and free elections In 1 993.','b463a01fb525ff559f834a8b9373fce39571452dd4d943697cb69265a7de20d7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3082c28a8cb89a12c4c62a22ee6d287caf46bac70addcd2ae54a21985124b95',2001,'SG','Singapore','introduction',1005,'Background: Founded as a British trading colony in
1819, Singapore joined Malaysia in 1963, but
withdrew two years later and became independent. It
subsequently became one of the world''s most
prosperous countries, with strong international trading
links (its port is one of the world''s busiest) and with per
capita GDP above that of the leading nations of
Western Europe.','747da1c99aba76673b371c0a287935bfc11e3251d86c557009696396610c9119','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2878d0b976b431c1e73f048f2fdc5ea4ac808182fe3fda116a0c2a1a631dc04',2001,'SI','Slovenia','introduction',1013,'Background: In 1 91 8 the Slovenes joined the Serbs
and Croats in forming a new nation, renamed
Yugoslavia in 1929. After World War II, Slovenia
became a republic of the renewed Yugoslavia, which
though communist, distanced itself from Moscow''s
rule. Dissatisfied with the exercise of power of the
majority Serbs, the Slovenes succeeded in
establishing their independence in 1991. Historical
ties to Western Europe, a strong economy, and a
stable democracy make Slovenia a leading candidate
for future membership in the EU and NATO.','34a4fe16b0769fbac999d2734905108ec8ad53f6dde1fc32191ed4a587a30397','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a9bdd58bfdd7deab8a5cbbfd6ed847ccb28309da1a689b45a6b14100b239ae4',2001,'SB','Solomon Islands','introduction',1014,'Background: The UK established a protectorate over
the Solomon Islands in the 1890s. Some of the bitterest
fighting of World War II occurred on these islands.
Self-government was achieved in 1976 and
independence two years later. Current issues include
government deficits, deforestation, and malaria control.','b4700bae5cf99c17e3a1afd69c82d940fca5bb4fba136367e4e9748231500f69','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff9fb08755b1c4b003b1b89ef9d4f113546f6047ea6e8278de8571188df716f7',2001,'ZA','South Africa','introduction',1031,'Background: The islands lie approximately 1 ,000
km east of the Falkland Islands. Grytviken, on South
Georgia, was a 19th and early 20th century whaling
station. The famed explorer Ernest SHACKLETON
stopped there in 1914 en route to his ill-fated attempt
to cross Antarctica on foot. He returned some 20
months later with a few companions in a small boat
and arranged a successful rescue for the rest of his
crew, stranded off the Antarctic Peninsula. He died in
1922 on a subsequent expedition and is buried in
Grytviken. Today, the station houses a small military
garrison. The islands have large bird and seal
populations and, recognizing the importance of
preserving the marine stocks in adjacent waters, the
UK, in 1993, extended the exclusive fishing zone from
12 miles to 200 miles around each island.
Background: A decision by the International
Hydrographic Organization in the spring of 2000
delimited a fifth world ocean - the Southern Ocean -
from the southern portions of the Atlantic Ocean,
Indian Ocean, and Pacific Ocean. The Southern
Ocean extends from the coast of Antarctica north to
60 degrees south latitude which coincides with the
Antarctic Treaty Limit. The Southern Ocean is now the
fourth largest of the world''s five oceans (after the
Pacific Ocean, Atlantic Ocean, and Indian Ocean, but
larger than the Arctic Ocean).','1857790cd42037f5ff7504f57b795f47691ffee9bf27db5fb32dc5356e8b6562','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7c4cfa40ebc7dd102fa779880c8e2b4142dcf57c755e889c81e417ac01e1028',2001,'ES','Spain','introduction',1033,'Background: Spain''s powerful world empire of the
16th and 17th centuries ultimately yielded command
of the seas to England. Subsequent failure to embrace
the mercantile and industrial revolutions caused the
country to fall behind Britain, France, and Germany in
economic and political power. Spain remained neutral
in World Wars I and II, but suffered through a
devastating Civil War (1936-39). In the second half of
the 20th century, it has played a catch-up role in the
western international community. Continuing
concerns are large-scale unemployment and the
Basque separatist movement.','9a605745a13163915ce2e7ee3b62f85618099c23e725ee838824a04ecf0a2891','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64a972c6a02d7aaeb934473ee3865d43a369899b1acd7553d5cf6fe68e05db98',2001,'LK','Sri Lanka','introduction',1041,'Background: Occupied by the Portuguese in the
16th century and the Dutch in the 17th century, the
island was ceded to the British in 1802. As Ceylon it
became independent in 1948; its name was changed
in 1972. Tensions between the Sinhalese majority and
Tamil separatists erupted in violence in the
mid-1980s. Tens of thousands have died in an ethnic
war that continues to fester.','3f126e1810ac14305a43001737db4336c8b5c39554355ecc1fb2bf875415f502','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98834a2eb51272b944c71660d25beb993e631d913733ae115c98b751efed5e0a',2001,'PK','Pakistan','introduction',1065,'Background: Tajikistan has experienced three
changes in government and a five-year civil war since
it gained independence in 1991 from the USSR. A
peace agreement among rival factions was signed in
1997, and implementation reportedly completed by
late 1 999. Part of the agreement required the
legalization of opposition political parties prior to the
1 999 elections, which occurred, but such parties have
made little progress in successful participation in
government. Random criminal and political violence in
the country remains a complication impairing
Tajikistan''s ability to engage internationally.','23d6a17d20c7bc901d47a4ee1408c3eb47f8aa861b02faa4bef552888a695359','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25fb064c80307b9892ebc46220f381f86829dde6539568450bcf7153d89e8e84',2001,'TO','Tonga','introduction',1075,'Background: The archipelago of "The Friendly
Islands" was united into a Polynesian kingdom in
1845. It became a constitutional monarchy in 1875
and a British protectorate in 1900. Tonga acquired its
independence in 1970 and became a member of the
Commonwealth of Nations. It remains the only
monarchy in the Pacific.','b8504091058d5c679bc32e9cdd0bbf08c602f03f8c7985b348b931f84e612254','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01ccad72dacce0a79b177abbc4bce9b0d916eb1e23b23b809be2bf10b8ada8f3',2001,'TN','Tunisia','introduction',1077,'Background: Turkey was created in 1923 from the
Turkish remnants of the Ottoman Empire. Soon
thereafter the country instituted secular laws to
replace traditional religious fiats. In 1945 Turkey
joined the UN and in 1952 it became a member of
NATO. Turkey occupied the northern portion of
Cyprus in 1974 to prevent a Greek takeover of the
island; relations between the two countries remain
strained. Periodic military offensives against Kurdish
separatists have dislocated part of the population in
southeast Turkey and have drawn international
condemnation.','c525f77ae9112933d7346b2a47270eafad79b5f3b6350951cdc25d1b6377d770','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('702e06ba5e20d881bc524a6b51f01d982d438576f6b80c2979c69eeac99f25bd',2001,'TV','Tuvalu','introduction',1079,'Background: In 1974, ethnic differences within the
British colony of the Gilbert and Ellice Islands caused
the Polynesians of the Ellice Islands to vote for
separation from the Micronesians of the Gilbert
Islands. The following year, the Ellice Islands became
the separate British colony of Tuvalu. Independence
was granted in 1978. In 2000, Tuvalu negotiated a
contract leasing its Internet domain name ".tv" for $50
million in royalties over the next dozen years.
Background; Uganda achieved independence from
the UK in 1962. The dictatorial regime of Idi AMIN
(1971-79) was responsible for the deaths of some
300,000 opponents; guerrilla war and human rights
abuses under Milton OBOTE (1980-85) claimed
another 100,000 lives. During the 1990s the
government promulgated non-party presidential and
legislative elections.
Background: Richly endowed in natural resources,
Ukraine has been fought over and subjugated for
centuries; its 20th-century struggle for liberty is not yet
complete. A short-lived independence from Russia
(1917-1920) was followed by brutal Soviet rule that
engineered two artificial famines (1921-22 and
1932-33) in which over 8 million died, and World War
II, in which German and Soviet armies were
responsible for some 7 million more deaths. Although
independence was attained in 1991 with the
dissolution of the USSR, true freedom remains elusive
as many of the former Soviet elite remain entrenched,
stalling efforts at economic reform, privatization, and
civic liberties.','dfbe6a46d3a397e0790538626b5ea1d92994acd2858f1ed812fa1306d1861395','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ceb3b4449341552685ab76bc576d14892eb740c035af31b77f9fade4b44a7f6',2001,'OM','Oman','introduction',1088,'Background: The Trucial States of the Persian Gulf
coast granted the UK control of their defense and
foreign affairs in 19th century treaties. In 1971 , six of
these states - Abu Zaby, ''Ajman, Al Fujayrah, Ash
Shariqah, Dubayy, and Umm al Qaywayn - merged to
form the UAE. They were joined in 1972 by Ra''s al
Khaymah. The UAE''s per capita GDP is not far below
those of the leading West European nations. Its
generosity with oil revenues and its moderate foreign
policy stance have allowed it to play a vital role in the
affairs of the region.','09f5c146256cea3b6ba96f2d0ccf4aadb11e246fbacefb4cf5d1fa5466b77ece','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c09f329c14c38cc6077804e16abd5ffcb4d5640af0b4b95023eb1c7d7dabef0',2001,'GB','United Kingdom','introduction',1098,'Background: Great Britain, the dominant industrial
and maritime power of the 19th century, played a
leading role in developing parliamentary democracy
and in advancing literature and science. At its
zenith, the British Empire stretched over one-fourth
of the earth''s surface. The first half of the 20th
century saw the UK''s strength seriously depleted in
two World Wars. The second half witnessed the
dismantling of the Empire and the UK rebuilding
itself into a modern and prosperous European
nation. As one of five permanent members of the UN
Security Council, a founding member of NATO, and
of the Commonwealth, the UK pursues a global
approach to foreign policy; it currently is weighing
the degree of its integration with continental Europe.
A member of the EU, it chose to remain outside of
the European Monetary Union for the time being.
Constitutional reform is also a significant issue in the
UK. Regional assemblies with varying degrees of
power opened in Scotland, Wales, and Northern
Ireland in 1999.','df66f8419acbe95906f06b2c2325bdcd4c7944243c474c5f3c772c5d4c6af35d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad7fee477b2a011f299aeaac541c72bec48c09eb78e279875d0fc12345d6631',2001,'WF','Wallis and Futuna','introduction',1130,'Background: Although discovered by the Dutch and
the British in the 17th and 18th centuries, it was the
French who declared a protectorate over the islands in
1842. In 1959, the inhabitants of the islands voted to
become a French overseas territory.','e5aab78aac33e0d9fbd17889718d1f4f349337191b24958677dd56ecd27c8a81','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('822e1750abd14ded358d8af9f1fd9c5a653ce50d489d68ce88d1457178e13da5',2001,'EH','Western Sahara','introduction',1132,'Background: Globally, the 20th century was marked
by: (a) two devastating world wars; (b) the Great
Depression of the 1930s; (c) the end of vast colonial
empires; (d) rapid advances in science and
technology, from the first airplane flight at Kitty Hawk,
North Carolina (US) to the landing on the moon; (e)
the Cold War between the Western alliance and the
Warsaw Pact nations; (f) a sharp rise in living
standards in North America, Europe, and Japan; (g)
increased concerns about the environment, including
loss of forests, shortages of energy and water, the
drop in biological diversity, and air pollution; (h) the
onset of the AIDS epidemic; and (i) the ultimate
emergence of the US as the only world superpower.
The planet''s population continues to explode: from 1
billion in 1820, to 2 billion in 1930, 3 billion in 1960, 4
billion in 1974, 5 billion in 1988, and 6 billion in 2000.
For the 21st century, the continued exponential
growth in science and technology raises both hopes
(e.g., advances in medicine) and fears (e.g.,
development of even more lethal weapons of war).','4a796877f575da7630aaee072388513454480ea09b90c0ba8d04b3f13bec2402','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0286cbe295c747c248b03dd47f063b3c8f2e52c45fb41c83261c126436104248',2001,'YE','Yemen','introduction',1141,'Background: The Kingdom of Serbs, Croats, and
Slovenes was formed in 1918; its name was changed
to Yugoslavia in 1929. Occupation by Nazi Germany
In 1941 was resisted by various partisan bands that
fought themselves as well as the invaders. The group
headed by Marshal TITO took full control upon
German expulsion in 1945. Although communist in
name, his new government successfully steered its
own path between the Warsaw Pact nations and the
West for the next four and a half decades. In the early
1990s, post-TITO Yugoslavia began to unravel along
ethnic lines: Slovenia, Croatia, and The Former
Yugoslav Republic of Macedonia all declared their
independence in 1991; Bosnia and Herzegovina in
1992. The remaining republics of Serbia and
Montenegro declared a new "Federal Republic of
Yugoslavia" in 1992 and, under President Slobodan
MILOSEVIC, Serbia led various military intervention
efforts to unite Serbs in neighboring republics into a
"Greater Serbia." All of these efforts were ultimately
unsuccessful. In 1999, massive expulsions by Serbs
of ethnic Albanians living in the autonomous republic
of Kosovo provoked an international response,
including the NATO bombing of Serbia and the
stationing of NATO and Russian peacekeepers in
Kosovo. Blatant attempts to manipulate presidential
balloting in October of 2000 were followed by massive
nationwide demonstrations and strikes that saw the
election winner, Vojislav KOSTUNICA, replace
MILOSEVIC.','fa0c7ced29aa815e634b982e91be6a85e1bc3a7037da00830b9d56e77617d222','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bd25639814937888833c7b5e253ecfe9be9a1e58c7f65e151bf346c86417bf7',2001,'ZM','Zambia','introduction',1142,'Background: The territory of Northern Rhodesia
was administered by the South Africa Company from
1891 until takeover by the UK in 1923. During the
1920s and 1930s, advances in mining spurred
development and immigration. The name was
changed to Zambia upon independence in 1964. In
the 1980s and 1990s, declining copper prices and a
prolonged drought hurt the economy. Elections in
1991 brought an end to one-party rule, but the
subsequent vote in 1996 saw blatant harassment of
opposition parties.','5bd1126862ff884903bf8b36e7a0514e34d832d22af48a8f5191da2230390473','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7eae5f03a358fcc4bbede62c45d60e52047251ae3860cca5d30e80080636e5d',2001,'ZW','Zimbabwe','introduction',3,'Birth rate
Budget
Capital
Climate
Coastline
Communications - note
Constitution
Country name
Currency
Currency code
Death rate
Debt - external
Dependency status
Dependent areas
Diplomatic representation from the US
Diplomatic representation in the US
Disputes - international
Economic aid - donor
Economic aid - recipient
Economy - overview
Electricity - consumption
Electricity - exports
Electricity - imports
Electricity - production
Electricity - production by source
Elevation extremes
Environment - current issues
Environment - international agreements
Ethnic groups
Exchange rates
Executive branch
Exports
Exports - commodities
Exports - partners
Fiscal year
Flag description
GDP
GDP - composition by sector
GDP - per capita
GDP - real growth rate
Geographic coordinates
Geography - note
Government - note
Government type
Heliports
Highways
HIV/AIDS - adult prevalence rate
HIV/AIDS - deaths
HIV/AIDS - people living with HIV/AIDS
Household income or consumption by
Illicit drugs
Imports
Imports - commodities
Imports - partners
Independence
Industrial production growth rate
Industries
Infant mortality rate
Inflation rate (consumer prices)
International organization participation
Internet country code
Internet Service Providers (ISPs)
Internet users
Irrigated land
Judicial branch
Labor force
Labor force - by occupation
Land boundaries
Land use
Languages
Legal system
Legislative branch
Life expectancy at birth
Literacy
Location
Map references
Maritime claims
Merchant marine
Military - note
Military branches
Military expenditures - dollar figure
Military expenditures - percent of GDP
Military manpower - availability
Military manpower - fit for military
Military manpower - military age
Military manpower - reaching military
National holiday
Nationality
Natural hazards
Natural resources
Net migration rate
People - note
Pipelines
Political parties and leaders
Political pressure groups and leaders
Population
Population below poverty line
Population growth rate
Ports and harbors
Radio broadcast stations
Radios
Railways
Religions
Sex ratio
Suffrage
Telephone system
Telephones - main lines in use
Telephones - mobile cellular
Television broadcast stations
Televisions
Terrain
Total fertility rate
Transportation - note
Unemployment rate
Waterways
======================================================================
Appendixes
Appendix A - Abbreviations
Appendix B - International Organizations and Groups
Appendix C - Selected International Environmental Agreements
Appendix D - Cross-Reference List of Country Data Codes
Appendix E - Cross-Reference List of Hydrographic Data Codes
Appendix F - Cross-Reference List of Geographic Names
======================================================================
Notes and Definitions
In addition to the updating of information, the following changes have
been made in this edition of The World Factbook. The entity of Serbia
and Montenegro is now officially known as Yugoslavia. There are new
entries on: Currency code, HIV/AIDS - adult prevalence rate, HIV/AIDS
- deaths, HIV/AIDS - people living with HIV/AIDS, Internet users, and
Internet country code. The Background entry, which was introduced in
the 1999 edition, has now been completed for all 267 entities in the
Factbook. The individual country maps are being revised. Some new
maps with elevation extremes and a partial geographic grid are included
in this edition.
Abbreviations
This information is included in Appendix A: Abbreviations, which
includes all abbreviations and acronyms used in the Factbook, with
their expansions.
Acronyms
An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up
solely from the first letter of the major words in the expanded form is
rendered in all capital letters (NATO from North Atlantic Treaty
Organization; an exception would be ASEAN for Association of Southeast
Asian Nations). In general, an acronym made up of more than the first
letter of the major words in the expanded form is rendered with only an
initial capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned Movement).
Hybrid forms are sometimes used to distinguish between initially
identical terms (WTO: WTrO for World Trade Organization and WToO for
World Tourism Organization.)
Administrative divisions
This entry generally gives the numbers, designatory terms, and first-
order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet
acted on by BGN are noted.
Age structure
This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64
years, 65 years and over). The age structure of a population affects a
nation''s key socioeconomic issues. Countries with young populations
(high percentage under age 15) need to invest more in schools, while
countries with older populations (high percentage ages 65 and over)
need to invest more in the health sector. The age structure can also be
used to help predict potential political issues. For example, the rapid
growth of a young adult population unable to find employment can lead
to unrest.
Agriculture - products
This entry is a rank ordering of major crops and products starting with
the most important.
Airports
This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or
gravel surfaces), but must be usable. Not all airports have facilities
for refueling, maintenance, or air traffic control.
Airports - with paved runways
This entry gives the total number of airports with paved runways
(concrete or asphalt surfaces). For airports with more than one runway,
only the longest runway is included according to the following five
groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1,524 to 2,437 m,
(4) 914 to 1,523 m, and (5) under 914 m. Only airports with usable
runways are included in this listing. Not all airports have facilities
for refueling, maintenance, or air traffic control.
Airports - with unpaved runways
This entry gives the total number of airports with unpaved runways
(grass, dirt, sand, or gravel surfaces). For airports with more than
one runway, only the longest runway is included according to the
following five groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3)
1,524 to 2,437 m, (4) 914 to 1,523 m, and (5) under 914 m. Only
airports with usable runways are included in this listing. Not all
airports have facilities for refueling, maintenance, or air traffic
control
Appendixes
This section includes Factbook-related material by topic.
Area
This entry includes three subfields. Total area is the sum of all land
and water areas delimited by international boundaries and/or
coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of all water
surfaces delimited by international boundaries and/or coastlines,
including inland water bodies (lakes, reservoirs, rivers).
Area - comparative
This entry provides an area comparison based on total area equivalents.
Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of
the Census. The smaller entities are compared with Washington, DC (178
sq km, 69 sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi,
146 acres).
This entry usually highlights major historic events and current issues
and may include a statement about one or two key future trends.
Birth rate
This entry gives the average annual number of births during a year per
1,000 persons in the population at midyear; also known as crude birth
rate. The birth rate is usually the dominant factor in determining the
rate of population growth. It depends on both the level of fertility
and the age structure of the population.
Budget
This entry includes revenues, total expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis,
i.e., not in purchasing power parity (PPP) terms
Capital
This entry gives the location of the seat of government.
Climate
This entry includes a brief description of typical weather regimes
throughout the year.
Coastline
This entry gives the total length of the boundary between the land area
(including islands) and the sea.','06396c28e0817c605a828b5dfdb3bab090c8916e93b568261d87762608b6a326','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7173d3f8ebffcd7c7fc9cbbda5d09eb12d83aa020e3b30e470cb0ff9e921fac',2001,'WF','Wallis and Futuna','introduction',13,'This category includes one entry, Background.
Irrigated land
This entry gives the number of square kilometers of land area that is
artificially supplied with water.
Judicial branch
This entry contains the name(s) of the highest court(s) and a brief
description of the selection process for members.
Labor force
This entry contains the total labor force figure.
Labor force - by occupation
This entry contains a rank ordering of component parts of the labor
force by occupation.
Land boundaries
This entry contains the total length of all land boundaries and the
individual lengths for each of the contiguous border countries.
Land use
This entry contains the percentage shares of total land area for five
different types of land use: arable land - land cultivated for crops
that are replanted after each harvest like wheat, maize, and rice;
permanent crops - land cultivated for crops that are not replanted
after each harvest like citrus, coffee, and rubber; permanent pastures
- land permanently used for herbaceous forage crops; forests and
woodland - land under dense or open stands of trees; other - any land
type not specifically mentioned above, such as urban areas, roads,
desert, etc.
Languages
This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking
that language.
Legal system
This entry contains a brief description of the legal system''s
historical roots, role in government, and acceptance of International
Court of Justice (ICJ) jurisdiction.
Legislative branch
This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and term of
office. Elections includes the nature of election process or accession
to power, date of the last election, and date of the next election.
Election results includes the percent of vote and/or number of seats
held by each party in the last election.
Life expectancy at birth
This entry contains the average number of years to be lived by a group
of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as
the male and female components. Life expectancy at birth is also a
measure of overall quality of life in a country and summarizes the
mortality at all ages. It can also be thought of as indicating the
potential return on investment in human capital and is necessary for
the calculation of various actuarial measures.
Literacy
This entry includes a definition of literacy and Census Bureau
percentages for the total population, males, and females. There are no
universal definitions and standards of literacy. Unless otherwise
specified, all rates are based on the most common definition - the
ability to read and write at a specified age. Detailing the standards
that individual countries use to assess the ability to read and write
is beyond the scope of the Factbook. Information on literacy, while not
a perfect measure of educational results, is probably the most easily
available and valid for international comparisons. Low levels of
literacy, and education in general, can impede the economic development
of a country in the current rapidly changing, technology-driven world.
Location
This entry identifies the country''s regional location, neighboring
countries, and adjacent bodies of water.
Map references
This entry includes the name of the Factbook reference map on which a
country may be found. The entry on Geographic coordinates may be
helpful in finding some smaller countries.
Maritime claims
This entry includes the following claims: contiguous zone, continental
shelf, exclusive economic zone, exclusive fishing zone, extended
fishing zone, none (usually for a landlocked country), other (unique
maritime claims like Libya''s Gulf of Sidra Closing Line or North
Korea''s Military Boundary Line), and territorial sea. The proximity of
neighboring states may prevent some national claims from being extended
the full distance.
Merchant marine
Merchant marine may be defined as all ships engaged in the carriage of
goods; or all commercial vessels (as opposed to all nonmilitary ships),
which excludes tugs, fishing vessels, offshore oil rigs, etc.; or a
grouping of merchant ships by nationality or register. This entry
contains information in two subfields - total and ships by type. Total
includes the total number of ships (1,000 GRT or over), total DWT for
those ships, and total GRT for those ships. DWT or dead weight tonnage
is the total weight of cargo, plus bunkers, stores, etc. that a ship
can carry when immersed to the appropriate load line. GRT or gross
register tonnage is a figure obtained by measuring the entire sheltered
volume of the ship available for cargo and passengers and converting it
to tons on the basis of 100 cubic feet per ton; there is no stable
relationship between GRT and DWT. Ships by type includes a listing of
barge carriers, bulk cargo ships, cargo ships, chemical tankers,
combination bulk carriers, combination ore/oil carriers, container
ships, liquefied gas tankers, livestock carriers, multifunctional
large-load carriers, petroleum tankers, passenger ships,
passenger/cargo ships, railcar carriers, refrigerated cargo ships,
roll-on/roll-off cargo ships, short-sea passenger ships, specialized
tankers, and vehicle carriers.
A captive register is a register of ships maintained by a
territory, possession, or colony primarily or exclusively for the use
of ships owned in the parent country; it is also referred to as an
offshore register, the offshore equivalent of an internal register.
Ships on a captive register will fly the same flag as the parent
country, or a local variant of it, but will be subject to the maritime
laws and taxation rules of the offshore territory. Although the nature
of a captive register makes it especially desirable for ships owned in
the parent country, just as in the internal register, the ships may
also be owned abroad. The captive register then acts as a flag of
convenience register, except that it is not the register of an
independent state.
A flag of convenience register is a national register offering
registration to a merchant ship not owned in the flag state. The major
flags of convenience (FOC) attract ships to their registers by virtue
of low fees, low or nonexistent taxation of profits, and liberal
manning requirements. True FOC registers are characterized by having
relatively few of the registered ships actually owned in the flag
state. Thus, while virtually any flag can be used for ships under a
given set of circumstances, an FOC register is one where the majority
of the merchant fleet is owned abroad. It is also referred to as an
open register.
A flag state is the nation in which a ship is registered and which
holds legal jurisdiction over operation of the ship, whether at home or
abroad. Maritime legislation of the flag state determines how a ship is
crewed and taxed and whether a foreign-owned ship may be placed on the
register.
An internal register is a register of ships maintained as a subset
of a national register. Ships on the internal register fly the national
flag and have that nationality but are subject to a separate set of
maritime rules from those on the main national register. These
differences usually include lower taxation of profits, use of foreign
nationals as crewmembers, and, usually, ownership outside the flag
state (when it functions as an FOC register). The Norwegian
International Ship Register and Danish International Ship Register are
the most notable examples of an internal register. Both have been
instrumental in stemming flight from the national flag to flags of
convenience and in attracting foreign-owned ships to the Norwegian and
Danish flags.
A merchant ship is a vessel that carries goods against payment of
freight; it is commonly used to denote any nonmilitary ship but
accurately restricted to commercial vessels only.
A register is the record of a ship''s ownership and nationality as
listed with the maritime authorities of a country; also, it is the
compendium of such individual ships'' registrations. Registration of a
ship provides it with a nationality and makes it subject to the laws of
the country in which registered (the flag state) regardless of the
nationality of the ship''s ultimate owner.','31dcc3e9cd41cbbefa1ce43e5eb7ec2d9fc5400246724293e812339d39117399','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ee38c3572676897681dbf242714b0b1c1b1251db017ae0b91beee04d4037fd6',2001,'GL','Greenland','introduction',242,'Afghanistan:
Afghanistan was invaded and occupied by the Soviet
Union in 1979. The USSR was forced to withdraw 10 years later by
anti-communist mujahidin forces supplied and trained by the US,
Saudi Arabia, Pakistan, and others. Fighting subsequently continued
among the various mujahidin factions, but the fundamentalist Islamic
Taliban movement has been able to seize most of the country. In
addition to the continuing civil strife, the country suffers from
enormous poverty, a crumbling infrastructure, and widespread land
mines.
Albania:
In 1990 Albania ended 44 years of xenophobic communist rule
and established a multiparty democracy. The transition has proven
difficult as corrupt governments have tried to deal with high
unemployment, a dilapidated infrastructure, widespread gangsterism,
and disruptive political opponents. International observers judged
local elections in 2000 to be acceptable and a step toward
democratic development, but serious deficiencies remain to be
corrected before the the 2001 parliamentary elections.
Algeria:
After a century of rule by France, Algeria became
independent in 1962. The surprising first round success of the
fundamentalist FIS (Islamic Salvation Front) party in December 1991
balloting caused the army to intervene, crack down on the FIS, and
postpone the subsequent elections. The FIS response has resulted in
a continuous low-grade civil conflict with the secular state
apparatus, which nonetheless has allowed elections featuring
pro-government and moderate religious-based parties. FIS''s armed
wing, the Islamic Salvation Army, disbanded itself in January 2000
and many armed militants surrendered under an amnesty program
designed to promote national reconciliation. Nevertheless, residual
fighting continues. Other concerns include large-scale unemployment
and the need to diversify the petroleum-based economy.
American Samoa:
Settled as early as 1000 B. C., Samoa was
"discovered" by European explorers in the 18th century.
International rivalries in the latter half of the 19th century were
settled by an 1899 treaty in which Germany and the US divided the
Samoan archipelago. The US formally occupied its portion - a smaller
group of eastern islands with the excellent harbor of Pago Pago -
the following year.
Andorra:
Long isolated and impoverished, mountainous Andorra has
achieved considerable prosperity since World War II through its
tourist industry. Many immigrants (legal and illegal) are attracted
to the thriving economy with its lack of income taxes.
Angola:
Civil war has been the norm in Angola since independence
from Portugal in 1975. A 1994 peace accord between the government
and the National Union for the Total Independence of Angola (UNITA)
provided for the integration of former UNITA insurgents into the
government and armed forces. A national unity government was
installed in April of 1997, but serious fighting resumed in late
1998, rendering hundreds of thousands of people homeless. Up to 1.5
million lives may have been lost in fighting over the past quarter
century.
Anguilla:
Colonized by English settlers from Saint Kitts in 1650,
Anguilla was administered by Great Britain until the early 19th
century, when the island - against the wishes of the inhabitants -
was incorporated into a single British dependency along with Saint
Kitts and Nevis. Several attempts at separation failed. In 1971, two
years after a revolt, Anguilla was finally allowed to secede; this
arrangement was formally recognized in 1980 with Anguilla becoming a
separate British dependency.
Antarctica:
Speculation over the existence of a "southern land" was
not confirmed until the early 1820s when British and American
commercial operators and British and Russian national expeditions
began exploring the Peninsula region and areas south of the
Antarctic Circle. Not until 1838 was it established that Antarctica
was indeed a continent and not just a group of islands. Various
"firsts" were achieved in the early 20th century, including: 1902,
first balloon flight (by British explorer Robert Falcon SCOTT);
1912, first to the South Pole (five Norwegian explorers under Roald
AMUNDSEN); 1928, first fixed-wing aircraft flight (by Australian
adventurer/explorer Sir Hubert WILKINS); 1929, first flight over the
South Pole (by Americans Richard BYRD and Bernt BALCHEN); and 1935,
first transantarctic flight (American Lincoln ELLSWORTH). Following
World War II, there was an upsurge in scientific research on the
continent. A number of countries have set up year-round research
stations on Antarctica. Seven have made territorial claims, but no
other country recognizes these claims. In order to form a legal
framework for the activities of nations on the continent, an
Antarctic Treaty was negotiated that neither denies nor gives
recognition to existing territorial claims; signed in 1959, it
entered into force in 1961.
Antigua and Barbuda:
The islands of Antigua and Barbuda became an
independent state within the British Commonwealth of Nations in
1981. Some 3,000 refugees fleeing a volcanic eruption on nearby
Montserrat have settled in Antigua and Barbuda since 1995.
Arctic Ocean:
The Arctic Ocean is the smallest of the world''s five
oceans (after the Pacific Ocean, Atlantic Ocean, Indian Ocean, and
the recently delimited Southern Ocean). The Northwest Passage (US
and Canada) and Northern Sea Route (Norway and Russia) are two
important seasonal waterways. A sparse network of air, ocean, river,
and land routes circumscribes the Arctic Ocean.
Argentina:
Following independence from Spain in 1816, Argentina
experienced periods of internal political conflict between
conservatives and liberals and between civilian and military
factions. After World War II, a long period of Peronist dictatorship
was followed by a military junta that took power in 1976. Democracy
returned in 1983, and numerous elections since then have underscored
Argentina''s progress in democratic consolidation.
Armenia:
An Orthodox Christian country, Armenia was incorporated
into Russia in 1828 and the USSR in 1920. Armenian leaders remain
preoccupied by the long conflict with Azerbaijan over
Nagorno-Karabakh, a primarily Armenian-populated exclave, assigned
to Soviet Azerbaijan in the 1920s by Moscow. Armenia and Azerbaijan
began fighting over the exclave in 1988; the struggle escalated
after both countries attained independence from the Soviet Union in
1991. By May 1994, when a cease-fire took hold, Armenian forces held
not only Nagorno-Karabakh but also a significant portion of
Azerbaijan proper. The economies of both sides have been hurt by
their inability to make substantial progress toward a peaceful
resolution.
Aruba:
Discovered and claimed for Spain in 1499, Aruba was acquired
by the Dutch in 1636. The island''s economy has been dominated by
three main industries. A 19th century gold rush was followed by
prosperity brought on by the opening in 1924 of an oil refinery. The
last decades of the 20th century saw a boom in the tourism industry.
Aruba seceded from the Netherlands Antilles in 1986 and became a
separate, autonomous member of the Kingdom of the Netherlands.
Movement toward full independence was halted at Aruba''s request in
1990.
Ashmore and Cartier Islands:
These uninhabited islands came under
Australian authority in 1931; formal administration began two years
later. Ashmore Reef supports a rich and diverse avian and marine
habitat; in 1983 it became a National Nature Reserve. Recent
geological explorations have indicated promising petroleum
formations.
Atlantic Ocean:
The Atlantic Ocean is the second-largest of the
world''s five oceans (after the Pacific Ocean, but larger than the
Indian Ocean, Southern Ocean, and Arctic Ocean). The Kiel Canal
(Germany), Oresund (Denmark-Sweden), Bosporus (Turkey), Strait of
Gibraltar (Morocco-Spain), and the St. Lawrence Seaway (Canada-US)
are important strategic access waterways. The decision by the
International Hydrographic Organization in the spring of 2000 to
delimit a fifth world ocean, the Southern Ocean, removed the portion
of the Atlantic Ocean south of 60 degrees south.
Australia:
Australia became a commonwealth of the British Empire in
1901. It was able to take advantage of its natural resources to
rapidly develop its agricultural and manufacturing industries and to
make a major contribution to the British effort in World Wars I and
II. Long-term concerns include pollution, particularly depletion of
the ozone layer, and management and conservation of coastal areas,
especially the Great Barrier Reef. A referendum to change
Australia''s status, from a commonwealth headed by the British
monarch to an independent republic, was defeated in 1999.
Austria:
Once the center of power for the large Austro-Hungarian
Empire, Austria was reduced to a small republic after its defeat in
World War I. Following annexation by Nazi Germany in 1938 and
subsequent occupation by the victorious Allies, Austria''s 1955 State
Treaty declared the country "permanently neutral" as a condition of
Soviet military withdrawal. Neutrality, once ingrained as part of
the Austrian cultural identity, has been called into question since
the Soviet collapse of 1991 and Austria''s increasingly prominent
role in European affairs. A prosperous country, Austria joined the
European Union in 1995 and the euro monetary system in 1999.
Azerbaijan:
Azerbaijan - a nation of Turkic Muslims - has been an
independent republic since the collapse of the Soviet Union in 1991.
Despite a cease-fire, in place since 1994, Azerbaijan has yet to
resolve its conflict with Armenia over the Azerbaijani
Nagorno-Karabakh enclave (largely Armenian populated). Azerbaijan
has lost almost 20% of its territory and must support some 750,000
refugees and internally displaced persons (IDPs) as a result of the
conflict. Corruption is ubiquitous and the promise of widespread
wealth from Azerbaijan''s undeveloped petroleum resources remains
largely unfulfilled.
Bahamas, The:
Since attaining independence from the UK in 1973, The
Bahamas have prospered through tourism and international banking and
investment management. Because of its geography, the country is a
major transshipment point for illegal drugs, particularly shipments
to the US, and its territory is used for smuggling illegal migrants
into the US.
Bahrain:
Bahrain''s small size and central location among Persian
Gulf countries require it to play a delicate balancing act in
foreign affairs among its larger neighbors. Possessing minimal oil
reserves, Bahrain has turned to petroleum processing and refining,
and has transformed itself into an international banking center. The
new amir is pushing economic and political reforms, and has worked
to improve relations with the Shi''a community. In 2001, the
International Court of Justice awarded the Hawar Islands, long
disputed with Qatar, to Bahrain.
Baker Island:
The US took possession of the island in 1857, and its
guano deposits were mined by US and British companies during the
second half of the 19th century. In 1935, a short-lived attempt at
colonization was begun on this island - as well as on nearby Howland
Island - but was disrupted by World War II and thereafter abandoned.
Presently the island is a National Wildlife Refuge run by the US
Department of the Interior; a day beacon is situated near the middle
of the west coast.
Bangladesh:
Bangladesh came into existence in 1971 when Bengali East
Pakistan seceded from its union with West Pakistan. About a third of
this extremely poor country annually floods during the monsoon rainy
season, hampering economic development.
Barbados:
The island was uninhabited when first settled by the
British in 1627. Its economy remained heavily dependent on sugar,
rum, and molasses production through most of the 20th century. In
the 1990s, tourism and manufacturing surpassed the sugar industry in
economic importance.
Bassas da India:
This atoll is a volcanic rock surrounded by reefs
and is awash at high tide. A French possession since 1897, it was
placed under the administration of a commissioner residing in
Reunion in 1968.
Belarus:
After seven decades as a constituent republic of the USSR,
Belarus attained its independence in 1991. It has retained closer
political and economic ties to Russia than any of the other former
Soviet republics. Belarus and Russia signed a treaty on a two-state
union on 8 December 1999 envisioning greater political and economic
integration but, to date, neither side has actively sought to
implement the accord.
Belgium:
Belgium became independent from the Netherlands in 1830 and
was occupied by Germany during World Wars I and II. It has prospered
in the past half century as a modern, technologically advanced
European state and member of NATO and the EU. Tensions between the
Dutch-speaking Flemings of the north and the French-speaking
Walloons of the south have led in recent years to constitutional
amendments granting these regions formal recognition and autonomy.
Belize:
Territorial disputes between the UK and Guatemala delayed
the independence of Belize (formerly British Honduras) until 1981.
Guatemala refused to recognize the new nation until 1992. Tourism
has become the mainstay of the economy. The country remains plagued
by high unemployment, growing involvement in the South American drug
trade, and increased urban crime.
Benin:
Dahomey gained its independence from France in 1960; the name
was changed to Benin in 1975. From 1974 to 1989 the country was a
socialist state; free elections were reestablished in 1991.
Bermuda:
Bermuda was first settled in 1609 by shipwrecked English
colonists headed for Virginia. Tourism to the island to escape North
American winters first developed in Victorian times. Bermuda has
developed into a highly successful offshore financial center. A
referendum on independence was soundly defeated in 1995.
Bhutan:
Under British influence a monarchy was set up in 1907; three
years later a treaty was signed whereby the country became a British
protectorate. Independence was attained in 1949, with India
subsequently guiding foreign relations and supplying aid. A refugee
issue of some 100,000 Bhutanese in Nepal remains unresolved; 90% of
these displaced persons are housed in seven United Nations Office of
the High Commissioner for Refugees (UNHCR) camps. Maoist Assamese
separatists from India, who have established themselves in the
southeast portion of Bhutan, have drawn Indian cross-border
incursions.
Bolivia:
Bolivia, named after independence fighter Simon BOLIVAR,
broke away from Spanish rule in 1825; much of its subsequent history
has consisted of a series of nearly 200 coups and counter-coups.
Comparatively democratic civilian rule was established in the 1980s,
but leaders have faced difficult problems of deep-seated poverty,
social unrest, and drug production. Current goals include attracting
foreign investment, strengthening the educational system, continuing
the privatization program, and waging an anti-corruption campaign.
Bosnia and Herzegovina:
Bosnia and Herzegovina''s declaration of
sovereignty in October 1991, was followed by a referendum for
independence from the former Yugoslavia in February 1992. The
Bosnian Serbs - supported by neighboring Serbia - responded with
armed resistance aimed at partitioning the republic along ethnic
lines and joining Serb-held areas to form a "greater Serbia." In
March 1994, Bosniaks and Croats reduced the number of warring
factions from three to two by signing an agreement creating a joint
Bosniak/Croat Federation of Bosnia and Herzegovina. On 21 November
1995, in Dayton, Ohio, the warring parties signed a peace agreement
that brought to a halt the three years of interethnic civil strife
(the final agreement was signed in Paris on 14 December 1995). The
Dayton Agreement retained Bosnia and Herzegovina''s international
boundaries and created a joint multi-ethnic and democratic
government. This national government is charged with conducting
foreign, economic, and fiscal policy. Also recognized was a second
tier of government comprised of two entities roughly equal in size:
the Bosniak/Croat Federation of Bosnia and Herzegovina and the
Bosnian Serb-led Republika Srpska (RS). The Federation and RS
governments are charged with overseeing internal functions. In
1995-96, a NATO-led international peacekeeping force (IFOR) of
60,000 troops served in Bosnia to implement and monitor the military
aspects of the agreement. IFOR was succeeded by a smaller, NATO-led
Stabilization Force (SFOR) whose mission is to deter renewed
hostilities. SFOR remains in place at a level of approximately
21,000 troops.
Botswana:
Formerly the British protectorate of Bechuanaland,
Botswana adopted its new name upon independence in 1966. The
economy, one of the most robust on the continent, is dominated by
diamond mining.
Bouvet Island:
This uninhabited volcanic island is almost entirely
covered by glaciers and is difficult to approach. It was discovered
in 1739 by a French naval officer after whom the island was named.
No claim was made until 1825 when the British flag was raised. In
1928, the UK waived its claim in favor of Norway, which had occupied
the island the previous year. In 1971, Bouvet Island and the
adjacent territorial waters were designated a nature reserve. Since
1977, Norway has run an automated meteorological station on the
island.
Brazil:
Following three centuries under the rule of Portugal, Brazil
became an independent nation in 1822. By far the largest and most
populous country in South America, Brazil has overcome more than
half a century of military intervention in the governance of the
country to pursue industrial and agricultural growth and development
of the interior. Exploiting vast natural resources and a large labor
pool, Brazil became Latin America''s leading economic power by the
1970s. Highly unequal income distribution remains a pressing problem.
British Indian Ocean Territory:
Established as a territory of the UK
in 1965, a number of the British Indian Ocean Territory (BIOT)
islands were transferred to the Seychelles when it attained
independence in 1976. Subsequently, BIOT has consisted only of the
six main island groups comprising the Chagos Archipelago. The
largest and most southerly of the islands, Diego Garcia, contains a
joint UK-US naval support facility. All of the remaining islands are
uninhabited. Former agricultural workers, earlier resident in the
islands, were relocated primarily to Mauritius but also to the
Seychelles, between 1967 and 1973. In 2000, a British High Court
ruling invalidated the local immigration order which had excluded
them from the archipelago, but upheld the special military status of
Diego Garcia.
British Virgin Islands:
First settled by the Dutch in 1648, the
islands were soon after (1672) annexed by the English. The economy
is closely tied to the larger and more populous US Virgin Islands to
the west; the US dollar is the legal currency.
Brunei:
The Sultanate of Brunei''s heyday occurred between the 15th
and 17th centuries, when its control extended over coastal areas of
northwest Borneo and the southern Philippines. Brunei subsequently
entered a period of decline brought on by internal strife over royal
succession, colonial expansion of European powers, and piracy. In
1888, Brunei became a British protectorate; independence was
achieved in 1984. Brunei benefits from extensive petroleum and
natural gas fields, the source of one of the highest per capita GDPs
in the less developed countries. The same family has now ruled in
Brunei for over six centuries.
Bulgaria:
Bulgaria earned its independence from the Ottoman Empire
in 1878, but having fought on the losing side in both World Wars, it
fell within the Soviet sphere of influence and became a People''s
Republic in 1946. Communist domination ended in 1990, when Bulgaria
held its first multi-party election since World War II and began the
contentious process of moving toward political democracy and a
market economy while combating inflation, unemployment, corruption,
and crime. Today, reforms and democratization keep Bulgaria on a
path toward eventual integration into NATO and the EU - with which
it began accession negotiations in 2000.
Burkina Faso:
Independence from France came to Burkina Faso
(formerly Upper Volta) in 1960. Governmental instability during the
1970s and 1980s was followed by multiparty elections in the early
1990s. Several hundred thousand farm workers migrate south every
year to Cote d''Ivoire and Ghana.
Burma:
Despite multiparty elections in 1990 that resulted in the
main opposition party winning a decisive victory, the military junta
ruling the country refused to hand over power. Key opposition leader
and Nobel Peace Prize recipient AUNG San Suu Kyi, under house arrest
from 1989 to 1995, was again placed under house detention in
September 2000; her supporters are routinely harassed or jailed.
Burundi:
Between 1993 and 2000, wide-spread, often intense ethnic
violence between Hutu and Tutsi factions in Burundi created hundreds
of thousands of refugees and left tens of thousands dead. Although
some refugees have returned from neighboring countries, continued
ethnic strife has forced many others to flee. Burundian troops,
seeking to secure their borders, have intervened in the conflict in
the Democratic Republic of the Congo.
Cambodia:
Following a five-year struggle, communist Khmer Rouge
forces captured Phnom Penh in 1975 and ordered the evacuation of all
cities and towns; over 1 million displaced people died from
execution or enforced hardships. A 1978 Vietnamese invasion drove
the Khmer Rouge into the countryside and touched off 13 years of
fighting. UN-sponsored elections in 1993 helped restore some
semblance of normalcy, as did the rapid diminishment of the Khmer
Rouge in the mid-1990s. A coalition government, formed after
national elections in 1998, brought renewed political stability and
the surrender of remaining Khmer Rouge forces.
Cameroon:
The former French Cameroon and part of British Cameroon
merged in 1961 to form the present country. Cameroon has generally
enjoyed stability, which has permitted the development of
agriculture, roads, and railways, as well as a petroleum industry.
Despite movement toward democratic reform, political power remains
firmly in the hands of an ethnic oligarchy.
Canada:
A land of vast distances and rich natural resources, Canada
became a self-governing dominion in 1867 while retaining ties to the
British crown. Economically and technologically the nation has
developed in parallel with the US, its neighbor to the south across
an unfortified border. Its paramount political problem continues to
be the relationship of the province of Quebec, with its
French-speaking residents and unique culture, to the remainder of
the country.
Cape Verde:
The uninhabited islands were discovered and colonized by
the Portuguese in the 15th century; they subsequently became a
trading center for African slaves. Most Cape Verdeans descend from
both groups. Independence was achieved in 1975.
Cayman Islands:
The Cayman Islands were colonized from Jamaica by
the British during the 18th and 19th centuries. Administered by
Jamaica from 1863, they remained a British dependency after 1962
when the former became independent.
Central African Republic:
The former French colony of Ubangi-Shari
became the Central African Republic upon independence in 1960. After
three tumultuous decades of misrule - mostly by military governments
- a civilian government was installed in 1993.
Chad:
Chad, part of France''s African holdings until 1960, endured
three decades of ethnic warfare as well as invasions by Libya before
a semblance of peace was finally restored in 1990. The government
eventually suppressed or came to terms with most political-military
groups, settled a territorial dispute with Libya on terms favorable
to Chad, drafted a democratic constitution, and held multiparty
presidential and Na','ab6c7fa792174739dcdd23e2b30d59d05f09616ae8029b5ab8af9051f7242182','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c33e53308a914e078091f6812fae1c31b89d43838b823db26ee2686ccea543c',2001,'GL','Greenland','introduction',243,'tional Assembly elections in 1996 and 1997
respectively. In 1998 a new rebellion broke out in northern Chad,
which continued to escalate throughout 2000. Despite movement toward
democratic reform, power remains in the hands of a northern ethnic
oligarchy.
Chile:
A three-year-old Marxist government was overthrown in 1973 by
a dictatorial military regime led by Augusto PINOCHET, which ruled
until a freely elected president was installed in 1990. Sound
economic policies, first implemented by the PINOCHET dictatorship,
led to unprecedented growth in 1991-97 and have helped secure the
country''s commitment to democratic and representative government.
Growth slowed in 1998-99, but recovered strongly in 2000.
China:
For centuries China has stood as a leading civilization,
outpacing the rest of the world in the arts and sciences. But in the
first half of the 20th century, China was beset by major famines,
civil unrest, military defeats, and foreign occupation. After World
War II, the Communists under MAO Zedong established a dictatorship
that, while ensuring China''s sovereignty, imposed strict controls
over everyday life and cost the lives of tens of millions of people.
After 1978, his successor DENG Xiaoping gradually introduced
market-oriented reforms and decentralized economic decision making.
Output quadrupled in the next 20 years and China now has the world''s
second largest GDP. Political controls remain tight even while
economic controls continue to weaken.
Christmas Island:
Named in 1643 for the day of its discovery, the
island was annexed and settlement was begun by the UK in 1888.
Phosphate mining began in the 1890s. The UK transferred sovereignty
to Australia in 1958. The phosphate mine, closed in 1987, was
reopened four years later, but the need for an alternative industry
has spurred investment in tourism. Old mining areas are being
restored, and almost two-thirds of the island has been declared a
national park.
Clipperton Island:
This isolated island was named for John
CLIPPERTON, a pirate who made it his hideout early in the 18th
century. Annexed by France in 1855, it was seized by Mexico in 1897.
Arbitration eventually awarded the island to France, which took
possession in 1935.
Cocos (Keeling) Islands:
The islands were discovered in 1609, but
remained uninhabited until the 19th century. Annexed by the UK in
1857, they were transferred to the Australian Government in 1955.
The population on the two inhabited islands is split between the
mostly Europeans on West Island and the Malays on Home Island.
Colombia:
Colombia was one of the three countries that emerged from
the collapse of Gran Colombia in 1830 (the others being Ecuador and
Venezuela). A 40-year insurgent campaign to overthrow the Colombian
Government escalated during the 1990s, undergirded in part by funds
from the drug trade. Although the violence is deadly and large
swaths of the countryside are under guerrilla influence, the
movement lacks the military strength or popular support necessary to
overthrow the government. While Bogota continues to try to negotiate
a settlement, neighboring countries worry about the violence
spilling over their borders.
Comoros:
Unstable Comoros has endured 19 coups or attempted coups
since gaining independence from France in 1975. In 1997, the islands
of Anjouan and Moheli declared their independence from Comoros. In
1999, military chief Col. AZALI seized power. He has pledged to
resolve the secessionist crisis through the 2000 Fomboni Accord, a
confederal arrangement that the Organization of African Unity has
yet to recognize.
Congo, Democratic Republic of the:
Since 1994 the Democratic
Republic of the Congo (DROC; formerly called Zaire) has been rent by
ethnic strife and civil war, touched off by a massive inflow of
refugees from the fighting in Rwanda and Burundi. The government of
former president MOBUTU Sese Seko was toppled by a rebellion led by
Laurent KABILA in May 1997; his regime was subsequently challenged
by a Rwanda- and Uganda-backed rebellion in August 1998. Troops from
Zimbabwe, Angola, Namibia, Chad, and Sudan intervened to support the
Kinshasa regime. A cease-fire was signed on 10 July 1999, but
sporadic fighting continued. KABILA was assassinated in January 2001
and his son Joseph KABILA was named head of state. The new president
quickly began overtures to end the war.
Congo, Republic of the:
Upon independence in 1960, the former French
region of Middle Congo became the Republic of the Congo. A quarter
century of experimentation with Marxism was abandoned in 1990 and a
democratically elected government installed in 1992. A brief civil
war in 1997 restored former Marxist President SASSOU-NGUESSO.
Cook Islands:
Named after Captain Cook, who sighted them in 1770,
the islands became a British protectorate in 1888. By 1900,
administrative control was transferred to New Zealand; in 1965
residents chose self-government in free association with New
Zealand. The emigration of skilled workers to New Zealand and
government deficits are continuing problems.
Coral Sea Islands:
Scattered over some 1 million square kilometers
of ocean, the Coral Sea Islands were declared a territory of
Australia in 1969. They are uninhabited except for a small
meteorological staff on Willis Island. Automated weather stations,
beacons, and a lighthouse occupy many other islands and reefs.
Costa Rica:
Costa Rica is a Central American success story: since
the late 19th century, only two brief periods of violence have
marred its democratic development. Although still a largely
agricultural country, it has achieved a relatively high standard of
living. Land ownership is widespread. Tourism is a rapidly expanding
industry.
Cote d''Ivoire:
Close ties to France since independence in 1960, the
development of cocoa production for export, and foreign investment
made Cote d''Ivoire one of the most prosperous of the tropical
African states. Falling cocoa prices and political turmoil, however,
sparked an economic downturn in 1999 and 2000. On 25 December 1999,
a military coup - the first ever in Cote d''Ivoire''s history -
overthrew the government led by President Henri Konan BEDIE.
Presidential and legislative elections held in October and December
2000 provoked violence due to the exclusion of opposition leader
Alassane OUATTARA. In October 2000, Laurent GBAGBO replaced junta
leader Robert GUEI as president, ending 10 months of military rule.
Croatia:
In 1918, the Croats, Serbs, and Slovenes formed a kingdom
known after 1929 as Yugoslavia. Following World War II, Yugoslavia
became an independent communist state under the strong hand of
Marshal TITO. Although Croatia declared its independence from
Yugoslavia in 1991, it took four years of sporadic, but often
bitter, fighting before occupying Serb armies were mostly cleared
from Croatian lands. Under UN supervision the last Serb-held enclave
in eastern Slavonia was returned to Croatia in 1998.
Cuba:
Fidel CASTRO led a rebel army to victory in 1959; his iron
rule has held the country together since. Cuba''s communist
revolution, with Soviet support, was exported throughout Latin
America and Africa during the 1960s, 70s, and 80s. The country is
now slowly recovering from a severe economic recession in 1990,
following the withdrawal of former Soviet subsidies, worth $4
billion to $6 billion annually. Havana portrays its difficulties as
the result of the US embargo in place since 1961. Illicit migration
to the US - using homemade rafts, alien smugglers, or falsified
visas - is a continuing problem. Some 3,000 Cubans took to the
Straits of Florida in 2000; the US Coast Guard interdicted only
about 35% of these.
Cyprus:
Independence from the UK was approved in 1960 with
constitutional guarantees by the Greek Cypriot majority to the
Turkish Cypriot minority. In 1974, a Greek-sponsored attempt to
seize the government was met by military intervention from Turkey,
which soon controlled almost 40% of the island. In 1983, the
Turkish-held area declared itself the "Turkish Republic of Northern
Cyprus", but it is recognized only by Turkey. UN-led talks on the
status of Cyprus resumed in December 1999 to prepare the ground for
meaningful negotiations leading to a comprehensive settlement.
Czech Republic:
After World War II, Czechoslovakia fell within the
Soviet sphere of influence. In 1968, an invasion by Warsaw Pact
troops ended the efforts of the country''s leaders to liberalize
party rule and create "socialism with a human face." Anti-Soviet
demonstrations the following year ushered in a period of harsh
repression. With the collapse of Soviet authority in 1989,
Czechoslovakia regained its freedom through a peaceful "Velvet
Revolution." On 1 January 1993, the country underwent a "velvet
divorce" into its two national components, the Czech Republic and
Slovakia. Now a member of NATO, the Czech Republic has moved toward
integration in world markets, a development that poses both
opportunities and risks.
Denmark:
Once the seat of Viking raiders and later a major north
European power, Denmark has evolved into a modern, prosperous nation
that is participating in the political and economic integration of
Europe. So far, however, the country has opted out of some aspects
of the European Union''s Maastricht Treaty, including the economic
and monetary system (EMU) and issues concerning certain internal
affairs.
Djibouti:
The French Territory of the Afars and the Issas became
Djibouti in 1977. A peace accord in 1994 ended a three-year uprising
by Afars rebels.
Dominica:
Dominica was the last of the Caribbean islands to be
colonized by Europeans, due chiefly to the fierce resistance of the
native Caribs. France ceded possession to Great Britain in 1763,
which made the island a colony in 1805. In 1980, two years after
independence, Dominica''s fortunes improved when a corrupt and
tyrannical administration was replaced by that of Mary Eugenia
CHARLES, the first female prime minister in the Caribbean, who
remained in office for 15 years.
Dominican Republic:
A legacy of unsettled, mostly
non-representative, rule for much of the 20th century was brought to
an end in 1996 when free and open elections ushered in a new','ae7dd4688da93f950a4d5dcf00cb6f635ba0e04927a5ace3e58f5c4ef3b52c3a','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

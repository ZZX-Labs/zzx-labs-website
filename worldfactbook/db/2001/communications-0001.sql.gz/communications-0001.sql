SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fb22d823e46197427113eb752e9faeaa5b7a3bb386d0ee8ecb5d354b3b25bb5',2001,'EH','Western Sahara','communications',13,'Telephones - main lines in use
Telephones ■ mobile cellular
Telephone system
general assessment
domestic
international
Radio broadcast stations
Radios
Television broadcast stations
Televisions
Internet country code
Internet Service Providers (ISPs)
Internet users
Communications - note
T ransportation
Railways
total
broad gauge
standard gauge
narrow gauge
dual gauge
Highways
total
paved
unpaved
Waterways
Pipelines
Ports and harbors
Merchant marine
total
ships by type
Airports
Airports • with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports - with unpaved runways
total
over 3,047 m
2,438 to 3,047m
1,524 to 2,437 m
1,524 to2,437m
914 to 1,523 m
under 914 m
Heliports
Transportation - note
Telephones ■ main lines in use: 29,000 (1996)
note: there were 21 ,000 main lines in service In Kabul
in 1998
Telephones ■ mobile cellular: NA
Telephone system:
general assessment: very limited telephone and
telegraph service
domestic: in 1997, telecommunications links were
established between Mazar-e Sharif, Herat,
Kandahar, Jalalabad, and Kabul through satellite and
microwave systems
international: satellite earth stations - 1 Intelsat
(Indian Ocean) linked only to Iran and 1 Intersputnik
(Atlantic Ocean region); commercial satellite
telephone center In Ghazni
Radio broadcast stations: AM 7 (6 are inactive; the
active station is in Kabul), FM 1, shortwave 1
(broadcasts in Pushtu, Dari, Urdu, and English)
(1999)
Radios: 167,000(1999)
Television broadcast stations: at least 10 (one
government run central television station in Kabul and
regional stations In nine of the 30 provinces; the
regional stations operate on a reduced schedule; also,
in 1997, there was a station in Mazar-e Sharif
reaching four northern Afghanistan provinces) (1998)
Televisions: 100,000(1999)
Internet country code: .af
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
2
Afghanistan (continued)
Telephones - main lines in use: about 2,000
(1999 est.)
Telephones - mobile cellular: 0 (1999)
Telephone system:
general assessment: sparse and limited system
domestic: NA
international: tied into Morocco''s system by
microwave radio relay, tropospheric scatter, and
satellite; satellite earth stations - 2 Intelsat (Atlantic
Ocean) linked to Rabat, Morocco
Radio broadcast stations: AM 2, FM 0,
shortwave 0(1998)
Radios: 56,000(1997)
Television broadcast stations: NA
Televisions: 6,000(1997)
Internet country code: .eh
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Internet Service Providers (ISPs): 10,350
(2000 est.)
Internet users: 407.1 million (2000 est.)
554
World (continued)','bf63f717351b3188c1daefe3753936a945bbc530f812b1ca764706a2b37ddeb3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04aaa2b67eca566f65223bd8009cc9e09f9be6f7bb9b104f1231c52b52110867',2001,'AL','Albania','communications',22,'Telephones - main lines in use: 87,000 (1997)
Telephones - mobile cellular: 3,100 (1999)
Telephone system:
genera! assessment: Albania has the poorest
telephone service in Europe with fewer than two
telephones per 100 inhabitants; it is doubtful that
every village has telephone service
domestic: obsolete wire system; no longer provides a
telephone for every village; in 1 992, following the fall
of the communist government, peasants cut the wire
to about 1 ,000 villages and used it to build fences
international: inadequate; international traffic carried
by microwave radio relay from the Tirana exchange to
Italy and Greece
Radio broadcast stations: AM 16, FM 3,
shortwave 2 (1999)
Radios: 810,000(1997)
Television broadcast stations: 9 (plus 264
repeaters) (1995)
Televisions: 405,000(1997)
Internet country code: .al
Internet Service Providers (ISPs): 7 (2000)
Internet users: 2,500 (2000)
Telephones - main lines in use: 2.3 million (1998)
Telephones - mobile cellular: 33,500 (1999)
Telephone system:
genera/ assessment; telephone density in Algeria is
very low, not exceeding five telephones per 100
persons; the number of fixed main lines has been
increased in the last few years to a little more than
2,000,000, but only about two-thirds of these have
subscribers: much of the infrastructure is outdated
and inefficient
Economy - overview: The hydrocarbons sector is
the backbone of the economy, accounting for roughly
60% of budget revenues, 30% of GDP, and over 95%
of export earnings. Algeria has the fifth-largest
reserves of natural gas in the world and is the second
largest gas exporter; it ranks fourteenth for oil
reserves. Algiers'' efforts to reform one of the most
centrally planned economies in the Arab world stalled
in 1992 as the country became embroiled in political
turmoil. Algeria''s financial and economic indicators
improved during the mid-1 990s, in part because of
policy reforms supported by the IMF and debt
rescheduling from the Paris Club. Algeria''s finances in
2000 benefited from the spike in oil prices and the
government''s tight fiscal policy, leading to a large
increase in the trade surplus, the near tripling of
foreign exchange reserves, and reduction in foreign
debt. The government continues efforts to diversify
the economy by attracting foreign and domestic
investment outside the energy sector, but has had
little success in reducing high unemployment and
improving living standards.
GDP: purchasing power parity -$171 billion
(2000 est.)
GDP - real growth rate: 5% (2000 est.)
GDP - per capita: purchasing power parity - $5,500
(2000 est.)
GDP - composition by sector:
agriculture:
industry: 37%
services: 52% (1 999 est.)
domestic: good service in north but sparse in south;
domestic satellite system with 12 earth stations (20
additional domestic earth stations are planned)
international: 5 submarine cables; microwave radio
relay to Italy, France, Spain, Morocco, and Tunisia;
coaxial cable to Morocco and Tunisia; participant in
Medarabtel; satellite earth stations - 2 Intelsat
(1 Atlantic Ocean and 1 1ndian Ocean), 1 1ntersputnik,
and 1 Arabsat (1998)
Radio broadcast stations: AM 25, FM 1 ,
shortwave 8 (1999)
Radios: 7.1 million (1997)
Television broadcast stations: 46 (plus 216
repeaters) (1995)
Televisions: 3.1 million (1997)
Internet country code: .dz
Internet Service Providers (ISPs): 2 (2000)
Internet users: 20,000 (2000)','411437ab557d846a48ac667a581a0bc1c1bc55bea4da28fc66cca72bce267972','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54869aaba4488bd8a766629ba59c529e8ad63218374ebeb035eb92aef36e288e',2001,'AS','American Samoa','communications',32,'Telephones ■ main lines in use: 13,000 (1997)
Telephones - mobile cellular: 2,550 (1997)
Telephone system:
general assessment: NA
domestic: good telex, telegraph, facsimile and cellular
telephone services; domestic satellite system with 1
Comsat earth station
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 1 ,
shortwave 0(1998)
Radios: 57,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 14,000(1997)
Internet country code: .as
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','8feeca39e519e5805d58739f97bfab70bd40c0e21e0e1db7b055ffacb915b819','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24525ae2cac12002d4114fbe5ebf5888fecd6a50b14aeb428ad8865eb1a2b040',2001,'AD','Andorra','communications',39,'Telephones - main lines in use: 32,946
(December 1998)
Telephones ■ mobile cellular: 14,117 (December
1998)
Telephone system:
general assessment: N A
domestic: modern system with microwave radio relay
connections between exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 0, FM 15,
shortwave 0 (1998)
Radios: 16,000(1997)
Television broadcast stations: 0 (1997)
11
Andorra (continued)
Televisions: 27,000(1997)
Internet country code: .ad
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000 (2000)','9910f9073169a39ed3c01faf4b5956e5fed61270698938986bd234c935ab1e68','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('512b7f6063cc6020d02798f5c0a14a957bfb5393351221da1ba8ec42d34a6ba4',2001,'AO','Angola','communications',45,'Telephones ■ main lines in use: 62,000 (1997)
Telephones - mobile cellular: 7,052 (1 997)
Telephone system:
general assessment: telephone service limited mostly
to government and business use; HF radiotelephone
used extensively for military links
domestic: limited system of wire, microwave radio
relay, and tropospheric scatter
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 34, FM 7,
shortwave 9 (1999)
Radios: 630,000(1997)
Television broadcast stations: 7 (1999)
Televisions: 150,000(1997)
Internet country code: .ao
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 2,000 (1 999)','1cc8120dc10a4828d9a887a307da70e281c8cbf7f478fbf585f17cf48601601e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29acf2465dca3229d9caa420de108264adcc4018a4b4cb3b042625d4e372bd2b',2001,'AI','Anguilla','communications',54,'Telephones - main lines in use: 5,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: modern internal telephone system
international: microwave radio relay to island of Saint
Marlin (Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 5, FM 6,
shortwave 1 (1998)
Radios: 3,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 1,000(1997)
Internet country code: .ai
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA','cf84391ae60a3a6c969d2a5b5a130e0802d2a3ec96a2e039fcb916bc7bfebb28','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a1f4ed7a0dffcb045af8ca5a76a7bba0ba09e77f585d93885da1c818b8fd9a4',2001,'AQ','Antarctica','communications',61,'Telephones - main lines in use: 0
note: information for US bases only (2001)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM 2,
shortwave 1
note: information for US bases only (1998)
Radios: NA
Television broadcast stations: 1 (the US Navy
Antarctic Support Group operates a cable system with
six channels for the American Forces Antarctic
Network-McMurdo)
note: information for US bases only (2000)
Televisions: several hundred at McMurdo Sound
note: information for US bases only (2001)
Internet country code: .aq
Internet Service Providers (ISPs): NA
Telephones ■ main lines in use: 7.5 million (1998)
Telephones - mobile cellular: 3 million (December
1999)
Telephone system:
genera! assessment: by opening the
telecommunications market to competition and
foreign investment with the "Telecommunications
Liberalization Plan of 1998", Argentina encouraged
the growth of modern telecommunication technology:
fiber-optic cable trunk lines are being installed
between all major cities; the major networks are
entirely digital and the availability of telephone service
is being improved: however, telephone density is
presently minimal, and making telephone service
universally available will take some time
domestic: microwave radio relay, fiber-optic cable,
and a domestic satellite system with 40 earth stations
serve the trunk network; more than 1 10,000 pay
telephones are installed and mobile telephone use is
rapidly expanding
international: satellite earth stations - 8 Intelsat
(Atlantic Ocean); Atlantis II and Unisur submarine
cables; two international gateways near Buenos Aires
(1999)
Radio broadcast stations: AM 260 (including 10
inactive stations), FM NA (probably more than 1,000,
mostly unlicensed), shortwave 6 (1998)
Radios: 24.3 million (1997)
Television broadcast stations: 42 (plus 444
repeaters) (1997)
Televisions: 7.95 million (1997)
Internet country code: .ar
Internet Service Providers (ISPs): 33 (2000)
Internet users: 900,000 (2000)
Telephones - main lines In use: 568,000 (1997)
Telephones - mobile cellular: 6,220 (1997)
Telephone system:
general assessment: system inadequate; now 90%
privately owned and undergoing modernization and
expansion
cfomesf/c; the majority of subscribers and the most
modern equipment are in Yerevan (this includes
paging and mobile cellular service)
international: Yerevan is connected to the
Trans-Asia-Europe fiber-optic cable through Iran;
additional international service is available by
microwave radio relay and landline connections to the
other countries of the Commonwealth of Independent
States and through the Moscow International switch
and by satellite to the rest of the world; satellite earth
stations - 1 1ntelsat
Radio broadcast stations: AM 9, FM 6,
shortwave 1 (1998)
Radios: 850,000 (1997)
Television broadcast stations: 4 (1998)
Televisions: 825,000 (1997)
Internet country code: .am
Internet Service Providers (ISPs): 1 (1999)
Internet users: 30,000 (2000)
25
Armenia (continued)
Telephones ■ main lines In use: 33,000 (1997)
Telephones - mobile cellular: 3,402 (1997)
Telephone system:
general assessment: NA
domestic: more than adequate
international: 1 submarine cable to Sint Maarten
(Netherlands Antilles); extensive interisland
microwave radio relay links
Radio broadcast stations: AM 4, FM 6,
shortwave 0 (1998)
Radios: 50,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 20,000(1997)
Internet country code: .aw
Internet Service Providers (ISPs): NA
Internet users: 4,000 (2000)','1e836ace486c2176d07708bb91fa11f192cf2082397c83c9bc75ab6e712fec5e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40db1663a7fdd3b2aea81a8cb94c7d2d27e36ceecb4103c1a82f1517c913e2bd',2001,'AG','Antigua and Barbuda','communications',69,'Telephones - main lines in use: 28,000 (1996)
Telephones - mobile cellular: 1 ,300 (1996)
Telephone system:
genera! assessment: N A
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean); tropospheric
scatter to Saba (Netherlands Antilles) and','4da9fd2640d0c4f77a59d40689e8ca77b663f5b7df0e50e5693ec99bc0337001','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a6357b1f44595e4fc04d120d2bf10117e534ed9ad90135a2c08f2ac637e03c4',2001,'GP','Guadeloupe','communications',70,'Radio broadcast stations: AM 4, FM 2,
shortwave 0 (1998)
Radios: 36,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 31,000(1997)
Internet country code: .ag
Internet Service Providers (ISPs): 1 6 (2000)
Internet users: 8,000 (2000)','cc181e8b166365d84778da37ea0677f98d46983c10b1e5b4728c461561207c91','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d77864388ed981609be151a89458ffe108ed993dce677a0c6c21cfe3a55207f',2001,'AU','Australia','communications',88,'Telephones - main lines in use: 9.58 million (1 998)
Telephones ■ mobile cellular: 6.4 million (1998)
Telephone system:
general assessment: excellent domestic and
international service
cfomesf/c; domestic satellite system; much use of
radiotelephone in areas of low population density;
rapid growth of mobile cellular telephones
international: submarine cables to New Zealand,
Papua New Guinea, and Indonesia; satellite earth
stations - 10 Intelsat (4 Indian Ocean and 6 Pacific
Ocean), 2 Inmarsat (Indian and Pacific Ocean
regions) (1998)
Radio broadcast stations: AM 262, FM 345,
shortwave 1 (1998)
Radios: 25.5 million (1997)
Television broadcast stations: 1 04 (1 997)
Televisions: 10.15 million (1997)
internet country code: .au
Internet Service Providers (ISPs): 264 (2000)
Internet users: 7.77 million (2000)
Telephones - main lines in use: 4 million
(3,600,000 analog main lines plus 400,000 ISDN or
Integrated Services Digital Network connections)
(1999)
Telephones - mobile cellular: 4.5 million (2000)
Telephone system:
general assessment: highly developed and efficient
domestic: there are 48 main lines for every 1 00
persons and the system is nearly 100% digital; the
fiber optic net is very extensive; all telephone
applications and Internet services are available
international: satellite earth stations ■ 2 Intelsat
(1 Atlantic Ocean and 1 1ndian Ocean) and 2 Eutelsat
(1999)
Radio broadcast stations; AM 1, FM 61 (plus
several hundred repeaters), shortwave 1 (1998)
Radios; 6.08 million (1997)
Television broadcast stations: 45 (plus 960
repeaters) (1995)
Televisions: 4.25 million (1997)
Internet country code: .at
Internet Service Providers (ISPs): 37 (2000)
Internet users: 2.6 million (2000)
33
Austria (continued)
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: automatic exchange
domestic: tied into Italian system
international: uses Italian system
Radio broadcast stations: AM 3, FM 4,
shortwave 2 (1998)
Radios: NA
Television broadcast stations: 1 (1996)
Televisions: NA
Internet country code: .va
Internet Service Providers (ISPs): 93 (Holy See
and Italy) (2000)
Internet users: NA
Telephones - main lines in use: 376 (1991)
Telephones - mobile cellular: 0 (1 991 )
Telephone system:
general assessment: primitive system
domestic: slngMne telephone system connects all
villages on island
international: NA
Radio broadcast stations: AM 1 , FM 1 ,
shortwave 0 (1998)
Radios: 1,000(1997)
Television broadcast stations: 1 (1997)
Televisions: NA
Internet country code: .nu
Internet Service Providers (iSPs): 1 (2000)
Internet users: NA
Telephones - main lines In use: 1,087 (1983)
Telephones - mobile cellular: 0 (1983)
Telephone system:
general assessment: adequate
domestic: NA
international: radiotelephone service with Sydney
(Australia)
Radio broadcast stations: AM 0, FM 3,
shortwave 0 (1998)
Radios: 2,500(1996)
Television broadcast stations: 1 (local
programming station plus two repeaters that bring in
Australian programs by satellite) (1998)
Televisions: 1,200(1996)
Internet country code: .nf
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','9a44b9efa6a680452852da3eb3e1ea5f075eaeed64c4e73a76eb76ccca7bab21','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02591db7afe4018ef9f2e2f806ab62e84c7636451729414819e69bfc952c5aa4',2001,'AZ','Azerbaijan','communications',96,'Telephones ■ main lines in use: 663,000 (1997)
Telephones - mobile cellular: 40,000 (1997)
Telephone system:
general assessment: inadequate; requires
considerable expansion and modernization; teledensity
of 8.6 main lines per 100 persons is very low
domestic: the majority of telephones are in Baku and
other industrial centers - about 700 villages still do not
have public telephone service; satellite service
connects Baku to a modern switch in its exclave of
Naxcivan
international: \\he old Soviet system of cable and
microwave is still serviceable; a satellite connection to
Turkey enables Baku to reach about 200 additional
countries, some of which are directly connected to
Baku by satellite providers other than Turkey (1997)
Radio broadcast stations: AM 10, FM 17,
shortwave 1 (1998)
Radios: 175,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 170,000(1997)
Internet country code: .az
Internet Service Providers (ISPs): 2 (2000)
Internet users: 8,000 (2000)','3b07344551e0a04a68db6f0570788a9b60602c6b417d5206e6179966d75abe7a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84e6c27748ee74788aab190926c296c324fd5644f765ae493a35124a0f1509eb',2001,'BS','Bahamas','communications',101,'Telephones - main lines in use: 96,000 (1997)
Telephones ■ mobile cellular: 6,152 (1997)
Telephone system:
general assessment: modern facilities
domestic: lolaWy automatic system; highly developed
/n/ema//ona/; tropospheric scatter and submarine
cable to Florida; 3 coaxial submarine cables; satellite
earth station - 1 Intelsat (Atlantic Ocean) (1997)
Radio broadcast stations: AM 3, FM 4,
shortwave 0 (1998)
Radios: 215,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 67,000(1997)
Internet country code: .bs
Internet Service Providers (ISPs): 19 (2000)
Internet users: 15,000(2000)','cd847b10ff87d9c4d3fa68f62777cca35aab4dd5c0de918f55fb53d8bc63f1f2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5c4e7b50a538b3255bd64736f57722b399283804ac2cd693c78eccedcf6bc0',2001,'BH','Bahrain','communications',109,'Telephones - main lines In use: 152,000 (1997)
Telephones - mobile cellular: 58,543 (1997)
Telephone system:
general assessment: modern system
domestic: modern fiber-optic integrated services;
digital network with rapidly growing use of mobile
cellular telephones
international: tropospheric scatter to Qatar and UAE;
microwave radio relay to Saudi Arabia; submarine
cable to Qatar, UAE, and Saudi Arabia; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian
Ocean) and 1 Arabsat (1997)
Radio broadcast stations: AM 2, FM 3,
shortwave 0 (1998)
Radios: 338,000(1997)
Television broadcast stations: 4 (1997)
Televisions: 275,000 (1997)
Internet country code: .bh
Internet Service Providers (ISPs): 1 (2000)
Internet users: 37,500 (2000)','0cb016a0f3231b3b158b57864fa84ebed9140ebfce24fbac5355936c6b86449a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aa89bc94856fc43ad3e61282e3a779ce32688d8da6db8f14a117211d791f175',2001,'BD','Bangladesh','communications',118,'Telephones - main lines in use: 500,000 (2000)
Telephones - mobile cellular: 283,000 (2000)
Telephone system:
general assessment: totally inadequate for a modern
country
domestic: modernizing; introducing digital systems;
trunk systems include VHF and UHF microwave radio
relay links, and some fiber-optic cable in cities
international: satellite earth stations - 2 Intelsat
(Indian Ocean); international radiotelephone
communications and landline service to neighboring
countries (2000)
Radio broadcast stations: AM 12, FM 12,
shortwave 2 (1999)
Radios: 6.15 million (1997)
Television broadcast stations: 15 (1999)
Televisions: 770,000(1997)
Internet country code: .bd
Internet Service Providers (ISPs): 10 (2000)
Internet users: 30,000 (2000)','a56ad744ded3a5d89501c6bfc258bff971e16a160705c36acd3a3b5938f72bb6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6b59d067164157e8f4b00709a2d773f8d76a8d2ad9f0b69f6c37b11b9a202fc',2001,'BB','Barbados','communications',126,'Telephones - main lines in use: 108,000 (1997)
Telephones - mobile cellular: 8,013 (1997)
Telephone system:
general assessment: N A
domestic: island-wide automatic telephone system
international: satellite earth stations - 4 Intelsat
(Atlantic Ocean); tropospheric scatter to Trinidad and','1cd6623d146cfbbc55e22dbccd5c93e22b5d122b89fcd4bb796681009dc546fe','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dcba8b8dee54273fdb9109a13b7ba27878e283911bbc6f9ea76af9a48fc73ff',2001,'LC','Saint Lucia','communications',127,'Radio broadcast stations: AM 2, FM 3,
shortwave 0 (1998)
Radios: 237,000(1997)
Television broadcast stations: 1 (plus two cable
channels) (1997)
Televisions: 76,000(1997)
Internet country code: .bb
Internet Service Providers (ISPs): 19 (2000)
Internet users: 6,000 (2000)
Telephones - main lines in use: 37,000 (1997)
Telephones - mobile cellular: 1 ,600 (1 997)
Telephone system:
general assessment: adequate system
domestic: system is automatically switched
international: direct microwave radio relay link with
Martinique and Saint Vincent and the Grenadines;
tropospheric scatter to Barbados; international calls
beyond these countries are carried by Intelsat from','b2b815955d6e1d4d6c015ccca7bd7ff867e7038da3e547c9d12bd3acc26f2993','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee43b4d7dec3d3a6c778cba1fd0e0cfd96cd2a61af86a658303708968adc604a',2001,'FR','France','communications',145,'Telephones - main lines in use: 2.313 million
(1997)
Telephones - mobile cellular: 8,167 (1997)
Telephone system:
general assessment: the Ministry of
Telecommunications controls all telecommunications
through its carrier (a joint stock company) Beltelcom
which is a monopoly
domestic: local - Minsk has a digital metropolitan
network and a cellular NMT-450 network; waiting lists
for telephones are long; local service outside Minsk is
neglected and poor; intercity - Belarus has a partly
developed fiber-optic backbone system presently
serving at least 13 major cities (1998); Belarus''s fiber
optics form synchronous digital hierarchy rings
through other countries'' systems; an inadequate
analog system remains operational
international: Belarus is a member of the
Trans-European Line (TEL), Trans-Asia-Europe
(TAE) fiber-optic line, and has access to the
Trans-Siberia Line (TSL); three fiber-optic segments
provide connectivity to Latvia, Poland, Russia, and
Ukraine; worldwide service is available to Belarus
through this infrastructure; additional analog lines to
Russia; Intelsat, Eutelsat, and Intersputnik earth
stations
Radio broadcast stations: AM 28, FM 37,
shortwave 11 (1998)
Radios: 3.02 million (1997)
Television broadcast stations: 47 (plus 27
repeaters) (1995)
Televisions: 2.52 million (1997)
Internet country code: .by
Internet Service Providers (ISPs): 4 (2000)
Internet users: 10,000(2000)
Telephones - main lines in use: 4769 million
(1997)
Telephones ■ mobile cellular: 974,494 (1997)
Telephone system:
general assessment: highly developed,
technologically advanced, and completely automated
domestic and international telephone and telegraph
facilities
domestic: nationwide cellular telephone system;
extensive cable network; limited microwave radio
relay network
international: 5 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Eutelsat
Radio broadcast stations: FM 79, AM 7,
shortwave 1 (1998)
Radios: 8.075 million (1997)
Television broadcast stations: 25 (plus 10
repeaters) (1997)
Televisions: 4.72 million (1997)
Internet country code: .be
Internet Service Providers (ISPs): 61 (2000)
Internet users: 2.7 million (2000)
Telephones - main lines in use: NA (1999)
Telephones - mobile cellular: 0 (1999)
Telephone system:
general assessment: NA
domestic: NA
/nfemaf/ona/; telephone, telex, and facsimile
communications with Australia and elsewhere via
satellite: 1 satellite earth station of NA type
Radio broadcast stations: AM 1, FM 0,
shortwave 0 (1998)
Radios: 300(1992)
Television broadcast stations: 0 (1997)
Televisions: NA
Internet country code: .cc
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Telephones ■ main lines In use: 219,283
(31 December 1999)
Telephones - mobile cellular: 322,500 (May 2000)
Telephone system:
general assessment: well developed by African
standards but operating well below capacity
domestic: open-wire lines and microwave radio relay;
90% digitalized
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean); 2 coaxial
submarine cables (June 1999)
Radio broadcast stations: AM 2, FM 8,
shortwave 3 (1998)
Radios: 2.26 million (1997)
Television broadcast stations: 14 (1999)
Televisions: 900,000(1997)
Internet country code: .ci
Internet Service Providers (ISPs): 5 (2001)
Internet users: 20,000 (2000)
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: government-operated radiotelephone and
private VHF/CB radiotelephone networks provide
effective service to almost all points on both islands
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean) with links through London to other
countries
Radio broadcast stations: AM 1 , FM 7,
shortwave 0 (1998)
Radios: 1,000(1997)
Television broadcast stations: 2 (operated by the
British Forces Broadcasting Service) (1997)
Televisions: 1,000(1997)
Internet country code: .fk
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Telephones - main lines in use: 47,000 (1997)
Telephones -mobile cellular: NA
Telephone system:
general assessment: NA
domestic: ia\\r open wire and microwave radio relay
system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 14 (including
6 repeaters), shortwave 6 (including 5 repeaters)
(1998)
Radios: 104,000(1997)
Television broadcast stations: 3 (plus eight
low-power repeaters) (1997)
Televisions: 30,000(1997)
Internet country code: .gf
Internet Service Providers (ISPs): 2 (2000)
Internet users: 2,000 (2000)
Internet country code: .tf
Telephones - main lines in use: 37,000 (1997)
Telephones - mobile cellular: 9,500 (1997)
Telephone system:
general assessment: NA
domestic: adequate system of cable, microwave radio
relay, tropospheric scatter, radiotelephone
communication stations, and a domestic satellite
system with 12 earth stations
international: satellite earth stations - 3 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 6, FM 7,
shortwave 6 (1998)
Radios: 208,000(1997)
Television broadcast stations: 4 (plus five
low-power repeaters) (1997)
Televisions: 63,000(1997)
Internet country code: .ga
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 31 ,900 (2000)
Telephones - mobile cellular: 5,624 (2000)
Telephone system:
general assessment: a packet switched
data network is available
domestic: adequate network of microwave radio relay
and open wire
international: microwave radio relay links to Senegal
and Guinea-Bissau; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 5,
shortwave 0 (2000)
Radios: 196,000(1997)
Television broadcast stations: 1
(government-owned) (1997)
Televisions: 5,000 (2000)
Internet country code: ,gm
Internet Service Providers (ISPs): 2 (2001)
Internet users: 5,000(2001)
Telephones - main lines in use: 95,729 (total for
Gaza Strip and West Bank) (1997)
Telephones ■ mobile cellular: NA
Telephone system:
general assessment: NA
domestic: rudimentary telephone services provided
by an open wire system
international: NA
Radio broadcast stations: AM 0, FM 0,
shortwave 0 (1998)
Radios: NA; note - most Palestinian households
have radios (1999)
Television broadcast stations: 2 (operated by the
Palestinian Broadcasting Corporation) (1997)
Televisions: NA; note - most Palestinian
households have televisions (1997)
Internet Service Providers (ISPs): 3 (1999)
Internet users: 23,520 (1 999) (includes West Bank)
Telephones - main lines in use: 620,000 (1 997)
Telephones - mobile cellular: 30,000 (1997)
Telephone system:
general assessment: NA
domestic: local - Tbilisi and K''ut''aisi have cellular
telephone networks; urban telephone density is about
20 per 100 people; rural telephone density is about 4
per 100 people; intercity facilities include a fiber-optic
line between Tbilisi and K''ut''aisi; nationwide pager
service is available
188
Georgia (continued)
international: Georgia and Russia are working on a
fiber-optic line between P''ot''i and Sochi (Russia);
present international service is available by
microwave, landline, and satellite through the Moscow
switch; international electronic mail and telex service
are available
Radio broadcast stations: AM 7, FM 12,
shortwave 4 (1998)
Radios: 3,02 million (1997)
Television broadcast stations: 12 (plus repeaters)
(1998)
Televisions: 2.57 million (1997)
Internet country code: .ge
Internet Service Providers (ISPs): 6 (2000)
Internet users: 20,000 (2000)
Telephones - main lines in use: 171 ,000 (1 996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: domestic facilities Inadequate
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); microwave radio relay to Antigua
and Barbuda, Dominica, and Martinique
Radio broadcast stations: AM 1 , FM 17,
shortwave 0 (1998)
Radios: 113,000(1997)
Television broadcast stations: 5 (plus several
low-power repeaters) (1997)
Televisions: 118,000 (1997)
Internet country code: .gp
Internet Service Providers (ISPs): 3 (2000)
Internet users: 4,000 (2000)
Telephones - main lines in use: 170,000 (1997)
Telephones - mobile cellular: 1 5,000 (1 997)
Telephone system:
general assessment: domestic facilities are adequate
domestic: NA
international: microwave radio relay to Guadeloupe,
Dominica, and Saint Lucia; satellite earth stations - 2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 0, FM 14,
shortwave 0(1998)
Radios: 82,000(1997)
Television broadcast stations: 1 1 (plus nine
repeaters) (1997)
Televisions: 66,000(1997)
Internet country code: .mq
Internet Service Providers (ISPs): 2 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 104,100 (1999)
Telephones - mobile cellular: 110,000 (2001)
Telephone system:
general assessment: very low density: about 3.5
telephones for each thousand persons
domestic: NA
international: satellite earth station - 1 1ntersputnik
(Indian Ocean Region)
Radio broadcast stations: AM 7, FM 9,
shortwave 4 (2001)
Radios: 155,900(1999)
Television broadcast stations: 4 (plus 18
provincial repeaters and many low powered
repeaters) (1999)
Televisions: 168,800(1999)
Internet country code: .mn
Internet Service Providers (ISPs): 5 (2001)
Internet users: between 10,000 and 15,000 (2001)
Telephones - main lines in use: 236,500 (1997)
Telephones - mobile cellular: 85,000 (1999)
Telephone system:
general assessment: adequate system; principal
center is Saint-Denis
domestic: modern open wire and microwave radio
relay network
international: radiotelephone communication to
Comoros, France, Madagascar; new microwave route
to Mauritius; satellite earth station - 1 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 55,
shortwave 0 (1998)
Radios: 173,000(1997)
Television broadcast stations: 22 (plus 18
low-power repeaters) (1997)
Televisions: 127,000(1997)
Internet country code: .re
Internet Service Providers (ISPs): 1 (2000)
Internet users: 10,000(2000)
Telephones - main lines in use: 34.878 million
(1997)
Telephones - mobile cellular: 13 million (yearend
1998)
Telephone system:
general assessment: technologically advanced
domestic and international system
domestic: equal mix of buried cables, microwave
radio relay, and fiber-optic systems
international: 40 coaxial submarine cables; satellite
earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 1nmarsat (Atlantic Ocean region),
and 1 Eutelsat; at least 8 large international switching
centers
Radio broadcast stations: AM 21 9, FM 431 ,
shortwave 3 (1998)
Radios: 84.5 million (1997)
Television broadcast stations: 228 (plus 3,523
repeaters) (1995)
Televisions: 30.5 million (1997)
Internet country code: .uk, .gb
Internet Service Providers (ISPs): 245 (2000)
Internet users: 19.47 million (2000)
Telephones - main lines in use: 95,729 (total for
West Bank and Gaza Strip) (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: NA
note: Israeli company BEZEK and the Palestinian
company PALTEL are responsible for communication
services in the West Bank
Radio broadcast stations: AM 1 , FM 0,
shortwave 0
note.- the Palestinian Broadcasting Corporation
broadcasts from an AM station in Ramallah on 675
kHz; numerous local, private stations are reported to
be in operation (2000)
Radios: NA; note - most Palestinian households
have radios (1999)
Television broadcast stations: NA
Televisions: NA; note - many Palestinian
households have televisions (1999)
Internet Service Providers (ISPs): 8 (1999)
Internet users: 23,520 (includes Gaza Strip) (1999)','43e2bf46d0809ef8a1641c5e3047481ac949b84aa25c83c3266398d7467d18b4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53dc162bc5969277f855cb68d51728a7c01483c0284de02da5cd66b3ba8931c2',2001,'BZ','Belize','communications',154,'Telephones - main lines in use: 31,000 (1997)
Telephones - mobile cellular: 3,023 (1997)
Telephone system:
general assessment: above-average system
domestic''Amk network depends primarily on
microwave radio relay
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 12,
shortwave 0 (1998)
Radios: 133,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: 41 ,000 (1 997)
Internet country code: .bz
Internet Service Providers (ISPs): 2 (2000)
Internet users: 12,000(2000)
Telephones - main lines In use: 36,000 (1997)
Telephones - mobile cellular: 4,295 (1997)
Telephone system:
general assessment: NA
domestic: fair system of open wire, microwave radio
relay, and cellular connections
/nfemaf/ona/; satellite earth station - 1 Intelsat
(Atlantic Ocean); submarine cable
Radio broadcast stations: AM 2, FM 9,
shortwave 4 (1998)
Radios: 620,000 (1997)
Television broadcast stations: 2 (one
privately-owned) (1997)
Televisions: 60,000 (1997)
Internet country code: .bj
Internet Service Providers (ISPs): 1 (2000)
Internet users: 10,000(2000)','4cdd5d369302b83feb62ebb2d7f1f25c87602c569ad643e77b2e96eb8b8826b9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4fd887106f476a0e7ca562b0e13ebe51e37e1cc1a95d9a0b02031f6cd66ffbb',2001,'BM','Bermuda','communications',163,'Telephones - main lines in use: 52,000 (1997)
Telephones ■ mobile cellular: 7,980 (1996)
Telephone system:
general assessment: NA
domestic: modern, fully automatic telephone system
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 3,
shortwave 0(1998)
Radios; 82,000(1997)
Television broadcast stations: 3 (1997)
Televisions: 66,000(1997)
Internet country code: .bm
Internet Service Providers (ISPs): 20 (2000)
Internet users: 25,000 (2000)
Telephones - main lines in use: 6,000 (1997)
Telephones - mobile cellular; NA
Telephone system:
general assessment: N A
domestic: domestic telephone service is very poor
with few telephones in use
international: international telephone and telegraph
service is by landline through India; a satellite earth
station was planned (1990)
Radio broadcast stations: AMO, FM1,
shortwave 1 (1998)
Radios: 37,000(1997)
Television broadcast stations: 0 (1997)
Televisions: 11,000(1997)
Internet country code: .bt
Internet Service Providers (ISPs): NA
Internet users: 500 (2000)
Telephones - main lines in use: 327,600 (1996)
Telephones - mobile cellular: 1 1 6,000 (1 997)
Telephone system:
general assessment: new subscribers face
bureaucratic difficulties; most telephones are
concentrated in La Paz and other cities; mobile
cellular telephone use expanding rapidly
domestic: primary trunk system, which is being
expanded, employs digital microwave radio relay;
some areas are served by fiber-optic cable; mobile
cellular systems are being expanded
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 171, FM 73,
shortwave 77 (1999)
Radios: 5.25 million (1997)
Television broadcast stations: 48 (1997)
Televisions: 900,000(1997)
Internet country code: .bo
Internet Service Providers (ISPs): 9 (2000)
Internet users: 35,000 (2000)','e53264aee922e68849e1c2f88ba08013a161b7b35b43052b3c8c8fe0db578b6f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4cf3d48af4f6859ae9c31b54d845bef6c05c12b8de4009985f2ef7cd10a377',2001,'IT','Italy','communications',169,'Telephones - main lines in use: 303,000 (1997)
Telephones - mobile cellular: 9,000 (1997)
Telephone system:
general assessment: telephone and telegraph
network is in need of modernization and expansion;
many urban areas are below average when compared
with services in other former Yugoslav republics
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 8, FM 16,
shortwave 1 (1998)
Radios: 940,000(1997)
Television broadcast stations: 33 (plus 277
repeaters) (September 1995)
Televisions: NA
Internet country code: .ba
Internet Service Providers (ISPs): 3 (2000)
Internet users: 3,500 (2000)
Telephones ■ main lines in use: 18,000 (1998)
Telephones - mobile cellular: 3,010 (1998)
Telephone system:
general assessment: adequate connections
domestic: automatic telephone system completely
integrated into Italian system
international: connected to Italian international
network
Radio broadcast stations: AM 0, FM 3,
shortwave 0 (1 998)
Radios: 16,000(1997)
Television broadcast stations: 1 (San Marino
residents also receive broadcasts from Italy) (1997)
Televisions: 9,000(1997)
Internet country code: .sm
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Telephones - main lines In use: 4.82 million (1998)
Telephones ■ mobile cellular: 1.967 million (1999)
Telephone system:
general assessment: exceWenl domestic and
international services
domestic: extensive cable and microwave radio relay
networks
international: ss\\eMe earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean)
Radio broadcast stations: AM 4, FM 1 13 (plus
many low power stations), shortwave 2 (1998)
Radios: 7.1 million (1997)
Television broadcast stations: 1 1 5 (plus 1 ,91 9
repeaters) (1995)
Televisions: 3.31 million (1997)
Internet country code: .ch
Internet Service Providers (ISPs): 44 (Switzerland
and Liechtenstein) (2000)
Internet users: 2.4 million (2000)
Telephones - main lines in use: 1 .31 3 million
(1997)
Telephones - mobile cellular: NA
Telephone system:
genera! assessment: fair system currently undergoing
significant improvement and digital upgrades,
including fiber-optic technology
domestic: coaxial cable and microwave radio relay
network
international: satellite earth stations - 1 Intelsat
(Indian Ocean) and 1 Intersputnik (Atlantic Ocean
region); 1 submarine cable; coaxial cable and
microwave radio relay to Iraq, Jordan, Lebanon, and
Turkey; participant in Medarabtel
Radio broadcast stations: AM 14, FM 2,
shortwave 1 (1998)
Radios: 4.15 million (1997)
Television broadcast stations: 44 (plus 17
repeaters) (1995)
Televisions: 1 .05 million (1 997)
Internet country code: .sy
Internet Service Providers (ISPs): 1 (2000)
Internet users: 20,000 (2000)','665f0432945f82ab0006c3b6a2813bd0ae8117c3e5b7f99ee873d217ad57545a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a2b2820ed6fca30977a6355627d35d6594956c1766c2aed871a9c028179afb9',2001,'BW','Botswana','communications',178,'Telephones - main lines In use: 86,000 (1997)
Telephones ■ mobile cellular: NA
Telephone system:
general assessment: sparse system
domestic: small system of open-wire lines, microwave
radio relay links, and a few radiotelephone
communication stations
66
Botswana (continued)
international: \\m international exchanges; digital
microwave radio relay links to Zambia, Zimbabwe,
and South Africa; satellite earth station - 1 Intelsat
(Indian Ocean)
Radio broadcast stations: AM 7, FM 15,
shortwave 5 (1998)
Radios: 237,000(1997)
Television broadcast stations: 0 (1997)
Televisions: 31,000 (1997)
Internet country code: .bw
Internet Service Providers (ISPs): 3 (2000)
Internet users: 12,000(2000)','3101b4a2de7bc51ec07bf5639c6d89a25703516b6181a944427ebf77086bfa15','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('130daf64ef48f388a013e55994123b29d5e4b7b9548a14f1183a5f20b7747fa3',2001,'BV','Bouvet Island','communications',184,'Internet country code: .bv
Communications - note: automatic meteorological
station','8d1bc1387ee4d8ead078a8659b775b5e7e77a35686d308075516e4abc6509e74','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2262ac622f1757035543174ed14299407fda3a461d3d41a861c724b7dc4ddc4',2001,'BR','Brazil','communications',192,'Telephones - main lines in use: 17.039 million
(1997)
Telephones - mobile cellular: 4.4 million (1997)
Telephone system:
general assessment: good working system
domestic: extensive microwave radio relay system
and a domestic satellite system with 64 earth stations
international: 3 coaxial submarine cables; satellite
earth stations - 3 Intelsat (Atlantic Ocean), 1 1nmarsat
(Atlantic Ocean region east), connected by microwave
relay system to MERCOSUR Brazilsat B3 satellite
earth station
Radio broadcast stations: AM 1 ,365, FM 296,
shortwave 161 (of which 91 are collocated with AM
stations) (1999)
Radios: 71 million (1997)
Television broadcast stations: 138 (1997)
Televisions: 36.5 million (1997)
Internet country code: .br
Internet Service Providers (ISPs): 50 (2000)
Internet users: 8.65 million (2000)','9599ee6e3b93c2e3f026749f8ab1550dc1ec0b740c2273b3a42aca2077a3b054','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a60f1be7fd89845be0ee243bd47466140c7c5fc5448838b8279272f7b961ab7a',2001,'ID','Indonesia','communications',199,'Telephones - main lines in use: NA
Telephone system:
general assessment: separate facilities for military
and public needs are available
cfomesf/c; all commercial telephone services are
available, including connection to the Internet
international: international telephone service is
carried by satellite (2000)
Radio broadcast stations: AM 1 , FM 2,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Internet country code: Jo
Internet Service Providers (ISPs): 1 (2000)
Telephones - main lines In use: 10,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: mr\\6\\N\\6e telephone service
domestic: NA
International: submarine cable to Bermuda
Radio broadcast stations: AM 1 , FM 4,
shortwave 0 (1998)
Radios: 9,000(1997)
Television broadcast stations: 1 (plus one cable
company) (1997)
Televisions: 4,000(1997)
Internet country code: .vg
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA
Telephones - main lines in use: 8,000 (1997)
Telephones - mobile cellular: NA
Telephone system;
general assessment: adequate system
domestic: islands interconnected by
shortwave radiotelephone (used mostly for
government purposes)
international: satellite earth stations - 4 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM 5, FM 1 ,
shortwave 0(1998)
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: NA
Internet country code: .fm
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000 (2000)
Telephones ■ main lines in use: 627,000 (1997)
Telephones - mobile cellular: 2,200 (1997)
Telephone system:
genera/ assessment; inadequate, outmoded, poor
service outside Chisinau, some effort to modernize is
under way
domestic: new subscribers face long wait for service;
mobile cellular telephone service being introduced
international: service through Romania and Russia
via landline; satellite earth stations - Intelsat, Eutelsat,
and Intersputnik
Radio broadcast stations: AM 7, FM 50,
shortwave 3 (1998)
Radios: 3.22 million (1997)
Television broadcast stations: 1 (plus 30
repeaters) (1995)
Televisions: 1.26 million (1997)
Internet country code: .md
Internet Service Providers (ISPs): 2 (1999)
Internet users: 15,000(2000)
Telephones - main lines in use: 1 .928 million
(November 2000)
Telephones - mobile cellular: 2.333 million
(November 2000)
Telephone system:
general assessment: major consideration given to
serving business Interests; excellent International
service
domestic: excellent domestic facilities
international: submarine cables to Malaysia (Sabah
and Peninsular Malaysia), Indonesia, and the
Philippines; satellite earth stations - 2 Intelsat
(1 Indian Ocean and 1 Pacific Ocean), and 1 1nmarsat
(Pacific Ocean region)
Radio broadcast stations: AM 0, FM 16,
shortwave 2 (1998)
Radios: 2.6 million (2000)
Television broadcast stations: 6 (2000)
Televisions: 1.33 million (1997)
Internet country code: .sg
Internet Service Providers (ISPs): 9 (2000)
Internet users: 1 .74 million (2000)','86ab2c0f4663269e41c27c938a16663adfbb15c88bda5c11fc3b3e20136a57f8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87a8b3b5d3328f332a02b070b7cb83ed8b4d2bd31bacc5f0fb3331a3bf7068ad',2001,'BG','Bulgaria','communications',203,'Telephones - main lines in use: 79,000 (1996)
Telephones - mobile cellular: 43,524 (1996)
Telephone system:
general assessment: service throughout country is
excellent; international service good to Europe, US,
and East Asia
domestic: every service available
international: satellite earth stations - 2 Intelsat
(1 Indian Ocean and 1 Pacific Ocean); digital
submarine cable links to Malaysia, Singapore, and
Philippines (2001)
Radio broadcast stations: AM 3, FM 10,
shortwave 0 (1998)
Radios: 329,000(1998)
Television broadcast stations: 2 (1997)
Televisions: 201,900(1998)
Internet country code: .bn
Internet Service Providers (ISPs): 2 (2000)
Internet users: 28,000(2001)
Telephones ■ main lines in use: 3.255 million
(2000)
Telephones - mobile cellular: 596,000 (2000)
Telephone system:
general assessment: extensive but antiquated
domestic: more than two-thirds of the lines are
residential; telephone service is available in most
villages; a fairly modern digital cable trunk line now
connects switching centers in most of the regions, the
others are connected by digital microwave radio relay
international: direct dialing to 58 countries; satellite
earth stations - 1 intersputnik (Atlantic Ocean region);
2 Intelsat (Atlantic and Indian Ocean regions)
Radio broadcast stations: AM 24, FM 93,
shortwave 2 (1998)
Radios: 4.51 million (1997)
Television broadcast stations: 96 (plus 1 ,030
repeaters) (1995)
Televisions: 3.31 million (1997)
Internet country code: .bg
Internet Service Providers (ISPs): 26 (2000)
Internet users: 200,000 (2000)','68e50a936dc131d89ad0a7647e0a41d1c48658ffcc0151ae3e05642107926b27','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('974ea4a90a073ff6bc0182e9b8410ff2d60d261c812fece49928a3dc48d88e2e',2001,'ET','Ethiopia','communications',216,'Telephones - main lines In use: 36,000 (1997)
Telephones - mobile cellular: 1 ,503 (1 997)
Telephone system:
general assessment: all services only fair
domestic: microwave radio relay, open wire, and
radiotelephone communication stations
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 17,
shortwave 1 (1998)
Radios: 370,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 100,000(1997)
Internet country code: .bf
Internet Service Providers (ISPs): 1 (2000)
Internet users: 4,000 (2000)
Telephones ■ main lines In use: 157,000 (1997)
Telephones - mobile cellular: 4,000 (1999)
Telephone system:
yenera/ assessment; open wire and microwave radio
relay system adequate for government use
domestic: open wire; microwave radio relay; radio
communication in the HF, VHF, and UHF frequencies;
two domestic satellites provide the national trunk
service
international: open wire to Sudan and Djibouti;
microwave radio relay to Kenya and Djibouti; satellite
earth stations - 3 Intelsat (1 Atlantic Ocean and 2
Pacific Ocean)
Radio broadcast stations: AM 5, FM 0,
shortwave 2 (1999)
Radios: 11.75 million (1997)
Television broadcast stations: 25 (1999)
Televisions: 320,000(1997)
Internet country code: .et
Internet Service Providers (ISPs): 1 (2000)
Internet users: 7,200 (1999)
Communications - note: 1 meteorological station
Telephones - main lines in use: 8,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: small system
domestic: combination of microwave radio relay,
open-wire lines, radiotelephone, and cellular
international: NA
Radio broadcast stations: AM 1 , FM 2,
shortwave 0 (1998)
Radios: 49,000(1997)
Television broadcast stations: 2 (1997)
Teievisions: NA
Internet country code: .gw
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,500 (2000)
Telephones - main lines in use: 3,000 (1997)
Telephones - mobile cellular: 6,942 (1997)
Telephone system:
general assessment: adequate facilities
domestic: minimal system
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 4,
shortwave 0 (1998)
Radios: 38,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 23,000(1997)
Internet country code: .st
Internet Service Providers (ISPs): 2 (2000)
Internet users: 500 (2000)
Telephones ■ main lines in use: 3.1 million (1998)
Telephones - mobile cellular: 1 million
note: in 1998, the government contracted for the
installation of 575,000 additional Group Speciale
Mobile (GSM) cellular telephone lines over 1 5 months
to raise the total number of subscribers to more than
one million; Riyadh planned to further expand the
GSM system in 1999 by adding an additional one
million lines (1998)
Telephone system:
general assessment: modern system
domestic: extensive microwave radio relay, coaxial
cable, and fiber-optic cable systems
international: microwave radio relay to Bahrain,
Jordan, Kuwait, Qatar, UAE, Yemen, and Sudan;
coaxial cable to Kuwait and Jordan; submarine cable
to Djibouti, Egypt and Bahrain; satellite earth
stations - 5 Intelsat (3 Atlantic Ocean and 2 Indian
Ocean), 1 Arabsat, and 1 1nmarsat (Indian Ocean
region)
Radio broadcast stations: AM 43, FM 31 ,
shortwave 2 (1998)
Radios: 6.25 million (1997)
Television broadcast stations: 117(1 997)
Televisions: 5.1 million (1997)
Internet country code: .sa
Internet Service Providers (ISPs): 42 (2001)
Internet users: 400,000 (2001)
Telephones - main lines in use: 1 1 6,000 (1 997)
Telephones - mobile cellular: 1,149 (1996)
Telephone system:
general assessment: good system
ofomesf/c; above-average urban system; microwave
radio relay, coaxial cable and fiber-optic cable in trunk
system
international: 4 submarine cables; satellite earth
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 10, FM 14,
shortwave 0 (1998)
Radios: 1.24 million (1997)
Television broadcast stations: 1 (1997)
Televisions: 361,000(1997)
Internet country code; .sn
Internet Service Providers (ISPs): 1 (2000)
Internet users: 30,000 (2000)','d8ee5c3ed54a0f83e9b5f2a63544b1d4a5e88643621e0c15366504bf943957a6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8350535e0581f911a6d7a8a27628244cb338e540be01b57a4d6bb867a0661211',2001,'TH','Thailand','communications',225,'Telephones - main lines in use: 250,000 (2000)
Telephones - mobile cellular: 8,492 (1997)
Telephone system:
general assessment: meets minimum requirements
for local and intercity service for business and
government; international service is good
domestic: NA
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 3,
shortwave 3 (1998)
Radios: 4.2 million (1997)
Television broadcast stations: 2 (1998)
Televisions: 320,000 (2000)
Internet country code: .mm
Internet Service Providers (ISPs): 1
note: as of September 2000, Internet connections
were legal only for the government, tourist offices, and
a few large businesses (2000)
Internet users: 500 (2000)
Telephones - main lines in use: 16,000 (1997)
Telephones - mobile cellular: 619 (1997)
Telephone system:
general assessment: primitive system
domestic: sparse system of open wire, radiotelephone
communications, and low-capacity microwave radio
relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 2,
shortwave 0 (1998)
Radios: 440,000(1997)
Television broadcast stations: 1 (1999)
Televisions: 25,000(1997)
Internet country code: .bi
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000 (2000)
Telephones - main lines in use: 5.4 million (1998)
Telephones - mobile cellular: 2.3 million (1998)
Telephone system:
general assessment: service to general public
adequate, but investment in technological upgrades
reduced by recession; bulk of service to government
activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and multichannel
cable; domestic satellite system being developed
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 204, FM 334,
shortwave 6 (1999)
Radios: 13.96 million (1997)
Television broadcast stations: 5 (all in Bangkok;
plus 131 repeaters) (1997)
Televisions: 15.19 million (1997)
Internet country code: .th
Internet Service Providers (ISPs): 1 5 (2000)
Internet users: 1 million (2000)
Telephones - main lines In use: 25,000 (1997)
Telephones - mobile cellular: 2,995 (1997)
Telephone system:
general assessment: fair system based on a network
of microwave radio relay routes supplemented by
open-wire lines and a mobile cellular system
500
Togo (continued)
domestic: microwave radio relay and open-wire lines
for conventional system; cellular system has capacity
of 10,000 telephones
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 Symphonie
Radio broadcast stations: AM 2, FM 9,
shortwave 4 (1998)
Radios: 940,000(1997)
Television broadcast stations: 3 (plus two
repeaters) (1997)
Televisions: 73,000(1997)
Internet country code: .tg
Internet Service Providers (ISPs): 3 (2000)
Internet users: 10,000 (2000)
Telephones ■ main lines in use: NA
Telephones - mobile cellular: 0 (2001)
Telephone system:
general assessment: adequate
domestic: radiotelephone service between islands
international: radiotelephone service to Samoa;
government-regulated telephone service (TeleTok),
with 3 satellite earth stations, established in 1997
Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: each atoll has a radio broadcast station of
unknown type that broadcasts shipping and weather
reports (1998)
Radios: 1,000(1997)
Television broadcast stations: NA
Televisions: NA
Internet country code: .tk
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','b61179e8e429e0382a820f98602cf3d88f761ec4f91f3614143fc8da45fa3f82','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6004c7c1f47304f6824aa2ae67d83e8e1113604ec3db78390c007ca2b3e3041a',2001,'KH','Cambodia','communications',238,'Telephones - main lines in use: 21,800(mid-1998)
Telephones - mobile cellular: 80,000 (2000)
Telephone system:
genera/ assessment: adequate landline and/or
cellular service in Phnom Penh and other provincial
cities; rural areas have little telephone service
domestic: NA
international: adequate but expensive landline and
cellular service available to all countries from Phnom
Penh and major provincial cities; satellite earth
station - 1 1ntersputnik (Indian Ocean region)
Radio broadcast stations: AM 7, FM 3,
shortwave 3 (1999)
Radios: 1.34 million (1997)
Television broadcast stations: 5 (1999)
Televisions; 94,000(1997)
Internet country code: .kh
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','01d0ae327fc2253091a97462920f309d291f84bb6425497e8cd16b89e8559454','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3fba8f3ebcca57b6c2c2ac6e6ad3cd6ad651de8d75a97a6760ee5875b6c5929',2001,'CM','Cameroon','communications',246,'Telephones - main lines in use: 75,000 (1997)
Telephones - mobile cellular: 4,200 (1997)
Telephone system:
general assessment: available only to business and','6c84f0ff03e91653914611e5d8c8f16b9fa857bd6f116457c8130cc0d78e681b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b567fd02742995875013f6e7705552460c6c46afdd3e1291addd07fcc815f035',2001,'CA','Canada','communications',255,'Telephones ■ main lines in use: 1 8.5 million (1 999)
Telephones ■ mobile cellular: 4.207 million (1997)
Telephone system:
general assessment: excellent service provided by
modern technology
domestic: domestic satellite system with about 300
earth stations
international: 5 coaxial submarine cables; satellite
earth stations - 5 Intelsat (4 Atlantic Ocean and 1
Pacific Ocean) and 2 Intersputnik (Atlantic Ocean
region)
Radio broadcast stations: AM 535, FM 53,
shortwave 6 (1998)
Radios: 32.3 million (1997)
Television broadcast stations: 80 (plus many
repeaters) (1997)
Televisions; 21.5 million (1997)
Internet country code: .ca
Internet Service Providers (ISPs): 760 (2000 est.)
Internet users: 13.28 million (1999)','47ddfcc3fd9e5c837aa2b023b5c767224cdf7c63270ee4c851b57152af56a8e2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d53ac23564d6884b0595f6faf8f8538d649d578e502d4488ee3aa69bb408b87',2001,'PT','Portugal','communications',261,'Telephones - main lines in use; 45,644 (2000)
Telephones - mobile cellular: 1 9,729 (1 997)
Telephone system:
genera/ assessmer?f; effective system, being
improved
domestic: Interisland microwave radio relay system
with both analog and digital exchanges; work is in
progress on a submarine fiber-optic cable system
which was scheduled for completion in 1998
/nferr/af/ona/; 2 coaxial submarine cables; HF
radiotelephone to Senegal and Guinea-Bissau;
satellite earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 0, FM 11 (and 14
repeaters), shortwave 0 (1998)
Radios: 73,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 2,000(1997)
Internet country code: .cv
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000 (2000)
Telephones - main lines In use: 5.3 million (end
1998)
Telephones - mobile cellular: 3,074,1 94 (1 999)
Telephone system:
general assessment: undergoing rapid development
in recent years, Portugal''s telephone system, by the
end of 1 998, achieved a state-of-the-art network with
broadband, high-speed capabilities and a main line
telephone density of 53%
domestic: Integrated network of coaxial cables, open
wire, microwave radio relay, and domestic satellite
earth stations
/nfemaf/ona/; 6 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 1ndian
Ocean), NA Eutelsat; tropospheric scatter to Azores;
note - an earth station for Inmarsat (Atlantic Ocean
region) Is planned
Radio broadcast stations: AM 47, FM 172 (many
are repeaters), shortwave 2 (1998)
Radios: 3.02 million (1997)
Television broadcast stations: 62 (plus 166
repeaters)
note: includes Azores and Madeira Islands (1995)
Televisions: 3.31 million (1997)
Internet country code: .pt
Internet Service Providers (ISPs): 16 (2000)
Internet users: 700,000 (2000)','965855882f87ef19be8964afe91ced2fceba62741d5f653c8ad74033a637e3ad','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d217a433ac9c63961dcce83c515de1f5430da33005dab9018958401f43fc9a9f',2001,'HN','Honduras','communications',272,'Telephones - main lines in use: 19,000 (1995)
Telephones - mobile cellular: 2,534 (1995)
Telephone system:
general assessment: NA
domestic: NA
international: 1 submarine coaxial cable; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (1998)
Radios: 36,000 (1997)
Television broadcast stations: NA
Televisions: 7,000(1997)
Internet country code: .ky
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA
Telephones - main lines in use: 10,000 (1997)
Telephones - mobile cellular: 570 (1997)
Telephone system:
general assessment: fair system
domestic: network consists principally of microwave
radio relay and low-capacity, low-powered
radiotelephone communication
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 3,
shortwave 1 (1998)
Radios: 283,000(1997)
Television broadcast stations: NA
Televisions: 18,000 (1997)
Internet country code: .cf
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,000 (2000)
Telephones - main lines in use: 234,000 (1997)
Telephones - mobile cellular: 14,427 (1997)
Telephone system:
general assessment: inadequate system
domestic: NA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); connected to Central American
Microwave System
Radio broadcast stations: AM 241, FM 53,
shortwave 12 (1998)
Radios; 2.45 miliion (1997)
Television broadcast stations: 11 (plus 17
repeaters) (1997)
Televisions: 570,000(1997)
Internet country code: .hn
Internet Service Providers (ISPs); 8 (2000)
Internet users: 20,000 (2000)','43f94608bfcd53db0d90eeb8ac9d2d4dbc4bf93b9116e1d8afcf82a95c1a4d19','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a3a82eb1810099df67c097ab399d4c929398a9674086e01b591238371e4219b',2001,'TD','Chad','communications',282,'Telephones ■ main lines in use: 7,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: primitive system
domesf/a’ fair system of radiotelephone
communication stations
/nfemaf/ona/; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 3,
shortwave 5 (1998)
Radios: 1.67 million (1997)
Television broadcast stations: 1 (1997)
Televisions: 10,000(1997)
Internet country code; .td
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,000 (2000)
Telephones - main lines in use: 2.603 million
(1998)
Telephones - mobile cellular: 944,225 (1998)
Telephone system:
general assessment: modern system based on
extensive microwave radio relay facilities
domestic: extensive microwave radio relay links;
domestic satellite system with 3 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations; AM 180 (eight inactive),
FM 64, shortwave 17 (one inactive) (1998)
Radios: 5.18 million (1997)
Television broadcast stations: 63 (plus 121
repeaters) (1997)
Televisions: 3.15 million (1997)
Internet country code: .cl
Internet Service Providers (ISPs); 7 (2000)
Internet users: 625,000 (2000)','86b3b333cc9c37aa148e862cd932c29b1161ff508af7554c327cef2cf8c22365','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ac29c087c30aea2d0ce72877f069c771c8e192efa457af32f8fa95692d71405',2001,'CN','China','communications',292,'Telephones - main lines in use: 135 million (2000)
Telephones - mobile cellular: 65 million (January
2001)
Telephone system:
general assessment: domestic and international
services are increasingly available for private use;
unevenly distributed domestic system serves principal
cities, industrial centers, and many towns
domestic: interprovincial fiber-optic trunk lines and
cellular telephone systems have been installed; a
domestic satellite system with 55 earth stations is in
place
international: satellite earth stations - 5 Intelsat
(4 Pacific Ocean and 1 Indian Ocean), 1 Intersputnik
(Indian Ocean region) and 1 Inmarsat (Pacific and
Indian Ocean regions); several international
fiber-optic links to Japan, South Korea, Hong Kong,
Russia, and Germany (2000)
Radio broadcast stations: AM 369, FM 259,
shortwave 45 (1998)
Radios: 417 million (1997)
Television broadcast stations: 3,240 (of which 209
are operated by China Central Television, 31 are
provincial TV stations and nearly 3,000 are local city
stations) (1997)
Televisions: 400 million (1997)
Internet country code: .cn
Internet Service Providers (ISPs): 3 (2000)
Internet users: 22 million (January 2001)','a652cf124dc854601cbdef863f72136cd2fc0655b3ab574f60b85e8ce5b99a6f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd58bc14e5d37805b1272a044292a6819129f439c9c83fc56ab21c10f703c049',2001,'CX','Christmas Island','communications',300,'Telephones - main lines in use: NA
Telephones - mobile cellular: 0 (1999)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth stations - one Intelsat
earth station provides telephone and telex service
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (1998)
Radios: 1,000(1997)
Television broadcast stations: NA
Televisions: 600(1997)
Internet country code: .cx
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','da1869e006e2dcc000a0a3d1a934ab638a408934f7d12afef5e7e1c6df2facb0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('608dea32acdb5e352cd7d8ad4e6fe0fe41b303bb1cb94d2385dbfc7291af7b1a',2001,'CO','Colombia','communications',307,'Telephones - main lines in use: 5,433,565
(December 1997)
Telephones - mobile cellular: 1 ,800,229
(December 1998)
Telephone system:
general assessment: modern system in many
respects
domestic: nationwide microwave radio relay system;
domestic satellite system with 41 earth stations;
fiber-optic network linking 50 cities
international: satellite earth stations - 6 Intelsat, 1
Inmarsat; 3 fully digitalized international switching
centers; 8 submarine cables
Radio broadcast stations: AM 454, FM 34,
shortwave 27 (1999)
Radios: 21 million (1997)
Television broadcast stations: 60 (includes seven
low-power stations) (1997)
Televisions: 4.59 million (1997)
Internet country code: .co
Internet Service Providers (ISPs): 18 (2000)
Internet users: 600,000 (2000)','d095b635bd54e6bc40b9df2a47cac0de398defdc0f6b72b6c0ee231322d8d2f4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ac637e9f95190e7f667b975d5d5cd88ca794ed84884b6fce25a2b99ac287f65',2001,'MZ','Mozambique','communications',315,'Telephones - main lines in use: 6,000 (1997)
Telephones > mobile cellular: NA
Telephone system:
general assessment: sparse system of microwave
radio relay and HF radiotelephone communication
stations
domestic: HF radiotelephone communications and
microwave radio relay
international: HF radiotelephone communications to
Madagascar and Reunion
Radio broadcast stations: AM 1 , FM 2,
shortwave 1 (1998)
Radios: 90,000(1997)
Television broadcast stations: 0 (1998)
Televisions: 1,000(1997)
Internet country code: .km
Internet Service Providers (ISPs): 1 (2000)
Internet users: 800 (2000)
Communications - note: 1 meteorological station
Telephones - main lines in use: 65,354 (2000)
Telephones ■ mobile cellular: 18,500 (2000)
Telephone system:
general assessment: fair system but not available
generally (telephone density is only 3.5 telephones for
each 1 ,000 persons)
domestic: the system consists of open-wire lines and
trunk connection by microwave radio relay and
tropospheric scatter
/nfemaf/ona/; satellite earth stations - 5 Intelsat (2
Atlantic Ocean and 3 Indian Ocean)
Radio broadcast stations: AM 13, FM 16,
shortwave 12 (2000)
Radios: 730,000(1997)
Television broadcast stations: 1 (2000)
Televisions: 67,600 (2000)
Internet country code: .mz
351
Mozambique (continued)
Internet Service Providers (ISPs): 8 (2000)
Internet users: 6,250
note: 150 corporate accounts and 6,100 individual
accounts (2000)
Telephones - main lines in use: 12.49 million
(September 2000)
Telephones ■ mobile cellular: 16 million
(September 2000)
Telephone system:
general assessment: provides telecommunications
service for every business and private need
cfomesf/c; thoroughly modern; completely digitalized
international: satellite earth stations - 2 Intelsat (1
Pacific Ocean and 1 1ndian Ocean); submarine cables
to Japan (Okinawa), Philippines, Guam, Singapore,
Hong Kong, Indonesia, Australia, Middle East, and
Western Europe (1999)
Radio broadcast stations: AM 218, FM 333,
shortwave 50(1999)
Radios: 16 million (1994)
Television broadcast stations: 29 (plus two
repeaters) (1997)
Televisions: 8.8 million (1998)
Internet country code: .tw
Internet Service Providers (ISPs): 8 (2000)
Internet users: 6.4 million (2000)','67d21036f6784b0c5c6cf6ddc58f8c228cfcf68eb52b19667d2216a3ad91b1e4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63813b7988a0cdbbf0849bf97789538f17cf40f51dc8d5d678204ff79c02dccf',2001,'CG','Congo','communications',322,'Telephones - main lines in use: 21,000 (1997)
Telephones - mobile cellular: 8,900 (1997)
Telephone system:
general assessment: NA
domestic: barely adequate wire and microwave radio
relay service in and between urban areas; domestic
satellite system with 14 earth stations
/nfemaf/ona/; satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 12,
shortwave 1 (1999)
Radios: 18.03 million (1997)
Television broadcast stations: 20 (1999)
Televisions: 6.478 million (1997)
Internet country code: .cd
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1 ,500 (1 999)
Telephones - main lines In use: 22,000 (1997)
Telephones - mobile cellular: 1 ,000 (1 996)
Telephone system:
general assessment: services barely adequate for
government use; key exchanges are in Brazzaville,
Pointe-Noire, and Loubomo; intercity lines frequently
out-of-order
domestic: primary network consists of microwave
radio relay and coaxial cable
/ntemaf/ona/; satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 5,
shortwave 1 (1999)
Radios: 341,000(1997)
Television broadcast stations: 1 (1999)
Televisions: 33,000(1997)
Internet country code: .eg
Internet Service Providers (ISPs): 1 (2000)
Internet users: 500 (2000)','afe9989b588b370789cdd7aae4d2ce4cc93643cc6c5581d067247736dccd6333','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25c21498f4514b434b6c1c3a3017cc5bf387ec540912d685cee0647c8eec10d1',2001,'CK','Cook Islands','communications',334,'Telephones - main lines in use: 5,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: NA
domestic: the individual islands are connected by a
combination of satellite earth stations, microwave
systems, and VHF and HF radiotelephone; within the
islands, service is provided by small exchanges
connected to subscribers by open wire, cable, and
fiber-optic cable
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 2,
shortwave 0 (1998)
Radios: 14,000(1997)
Television broadcast stations: 2 (plus eight
low-power repeaters) (1 997)
Televisions: 4,000(1997)
Internet country code: ,ck
Internet Service Providers (ISPs): 3 (2000)
Internet users: NA
Communications - note: there are automatic
weather stations on many of the isles and reefs
relaying data to the mainland
Telephones - main lines in use: 65,500 (1997)
Telephones - mobile cellular: 4,400 (1997)
Telephone system:
general assessment: N A
domestic: NA
international: 3 submarine cables
Radio broadcast stations: AM NA, FM 1,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Internet country code: .je
Internet Service Providers (ISPs): NA
Internet users: NA
Telephone system:
genera/ assessment.* 13 outgoing and 10 incoming
commercial lines; adequate telecommunications
domestic: 60-channel submarine cable, 22 DSN
circuits by satellite. Autodin with standard remote
terminal, digital telephone switch. Military Affiliated
Radio System (MARS station), UHFA/HF air-ground
radio, a link to the Pacific Consolidated
Telecommunications Network (PCTN) satellite
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Television broadcast stations: commercial
satellite television system, with 16 channels (1997)
Internet Service Providers (ISPs): NA','3322ac564ca3a581850a182fe883c91fb2922ca3f6ac963bb98459b7c5f38356','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('514832d42955c15acba1cd3097055b531f55d6f98efcacee57dac6bc994855ae',2001,'CR','Costa Rica','communications',342,'Telephones - main lines in use: 450,000 (1998)
note: 584,000 installed in 1997, but only about
450,000 were in use 1998
Telephones - mobile cellular: 143,000 (2000)
Telephone system:
genera! assessment: very good domestic telephone
service
domestic: point-to-point and point-to-multi-point
microwave, fiber-optic, and coaxial cable link rural
areas; Internet service is available
international: comec\\e6 to Central American
Microwave System; satellite earth stations - 2 Intelsat
(Atlantic Ocean); two submarine cables (1999)
Radio broadcast stations: AM 50, FM 43,
shortwave 19 (1998)
Radios: 980,000 (1997)
Television broadcast stations: 6 (plus 1 1
repeaters) (1997)
Televisions: 525,000(1997)
Internet country code: .cr
Internet Service Providers (ISPs): 3 (of which only
one is legal) (2000)
Internet users: 150,000 (2000)','ff8f5fb9d7ba1aa7624ec82de2dd7cc49fe0eee57eedb95ff59e32b6124a842a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('709810b771e3d352c855409ab7726ed0c73aa8587265da3b414f71e85504218a',2001,'SI','Slovenia','communications',356,'Telephones - main lines in use: 1 .488 million
(1997)
Telephones - mobile cellular: 187,000 (yearend
1998)
Telephone system:
general assessment: NA
domestic: reconstruction plan calls for replacement of
all analog circuits with digital and enlarging the
network; a backup will be included in the plan for the
main trunk
/nternaf/ona/; digital international service is provided
through the main switch in Zagreb; Croatia
participates in the Trans-Asia-Europe (TEL)
fiber-optic project which consists of two fiber-optic
trunk connections with Slovenia and a fiber-optic trunk
line from Rijeka to Split and Dubrovnik; Croatia is also
investing in ADRIA 1 , a joint fiber-optic project with
Germany, Albania, and Greece (2000)
Radio broadcast stations: AM 16, FM 98,
shortwave 5 (1999)
Radios: 1.51 million (1997)
Television broadcast stations: 36 (plus 321
repeaters) (September 1995)
Televisions: 1.22 million (1997)
Internet country code: .hr
Internet Service Providers (ISPs): 9 (2000)
Internet users: 100,000(1999)','7ab6affbdf03a2737f0746c3a20fe3d9b12fb95f6aacd37cd67a6f9a429b57b4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('346e4e5bcd171a97f90db5adc4574c532c589fdd7ef28038126d7aca6301deeb',2001,'CU','Cuba','communications',365,'Telephones - main lines in use: 473,031 (2000)
Telephones - mobile cellular: 2,994 (1997)
Telephone system:
general assessment: NA
domestic: principal trunk system, end to end of
country, is coaxial cable; fiber-optic distribution in
Havana and on Isla de la Juventud; 2 microwave radio
relay installations (one is old, US-built; the other
newer, Soviet-built); both analog and digital mobile
cellular service established
international: satellite earth station - 1 1ntersputnik
(Atlantic Ocean region)
Radio broadcast stations: AM 169, FM 55,
shortwave 1 (1998)
Radios: 3.9 million (1997)
Television broadcast stations: 58 (1997)
Televisions: 2.64 million (1997)
Internet country code: .cu
Internet Service Providers (ISPs): 4 (2001)
Internet users: 60,000 (2000)
Telephones - main lines in use: 60,000 (1997)
Telephones - mobile cellular: 0 (1995)
Telephone system:
general assessment: domestic facilities barely
adequate; international facilities slightly better
domestic: coaxial cable and microwave radio relay
trunk service
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 41 , FM 26,
shortwave 0 (1999)
Radios: 415,000(1997)
Television broadcast stations: 2 (plus a cable TV
service) (1997)
Televisions: 38,000(1997)
Internet country code: .ht
Internet Service Providers (ISPs): 3 (2000)
Internet users: 6,000 (2000)','64220c859336864c7cf9126f5837d00d85e22e214cfd5e6ec6cd2a2145c0d7d5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1f4951b1b239778a0f75fef8b958093ec603d9dba329c31c9746b1a04c95fa1',2001,'CY','Cyprus','communications',374,'Telephones - main lines In use: Greek Cypriot
area: 405,000 (1998); Turkish Cypriot area: 83,162
(1998)
Telephones - mobile cellular: Greek Cypriot area:
68,000 (1998); Turkish Cypriot area: 70,000 (1999)
Telephone system:
general assessment: excellent in both the Greek
Cypriot and Turkish Cypriot areas
domestic: open wire, fiber-optic cable, and microwave
radio relay
international: tropospheric scatter; 3 coaxial and 5
fiber-optic submarine cables; satellite earth stations -
3 Intelsat (1 Atlantic Ocean and 2 Indian Ocean), 2
Eutelsat, 2 Intersputnik, and 1 Arabsat
Radio broadcast stations: Greek Cypriot area: AM
7, FM 60, shortwave 1 (1998); Turkish Cypriot area:
AM 3, FM 11, shortwave 1 (1998)
Radios: Greek Cypriot area: 31 0,000 (1 997); Turkish
Cypriot area: 56,450(1994)
Television broadcast stations: Greek Cypriot
area: 4 (plus 225 low-power repeaters) (September
1995); Turkish Cypriot area: 4 (plus 5 repeaters)
(September 1995)
Televisions: Greek Cypriot area: 248,000 (1997);
Turkish Cypriot area: 52,300 (1994)
Internet country code: .cy
Internet Service Providers (ISPs): 6 (2000)
Internet users: 80,000 (2000)
Telephones ■ main lines in use: 3.869 million
(2000)
Telephones - mobile cellular: 4.346 million (2000)
Telephone system:
general assessment: privatization and modernization
of the Czech telecommunication system got a late
start but is advancing steadily; growth in the use of
mobile cellular telephones is particularly vigorous
domestic: 88% of exchanges now digital; existing
copper subscriber systems now being enhanced with
Asymmetric Digital Subscriber Line (ADSL)
equipment to accommodate Internet and other digital
signals; trunk systems include fiber-optic cable and
microwave radio relay
/nfemaf/ona/; satellite earth stations - 2 Intersputnik
(Atlantic and Indian Ocean regions), 1 1ntelsat, 1
Eutelsat, 1 1nmarsat, 1 Globalstar
Radio broadcast stations: AM 31 , FM 304,
shortwave 17 (2000)
Radios: 3,159,134 (December 2000)
Television broadcast stations: 1 50 (plus 1 ,434
repeaters) (2000)
Televisions: 3,405,834 (December 2000)
Internet country code: .cz
Internet Service Providers (ISPs): more than 300
(2000)
Internet users: 900,000 (2000)
137
Czech Republic (continued)
Telephones - main lines in use: 4.785 million
(1997)
Telephones - mobile cellular: 1 ,444,01 6 (1997)
Telephone system:
general assessment: excellent telephone and
telegraph services
domestic: buried and submarine cables and
microwave radio relay form trunk network, 4 cellular
mobile communications systems
international: 18 submarine fiber-optic cables linking
Denmark with Norway, Sweden, Russia, Poland,
Germany, Netherlands, UK, Faroe Islands, Iceland,
and Canada; satellite earth stations - 6 Intelsat, 10
Eutelsat, 1 Orion, 1 Inmarsat
(Blaavand-Atlantic-East); note - the Nordic countries
(Denmark, Finland, Iceland, Norway, and Sweden)
share the Danish earth station and the Eik, Norway,
station for worldwide Inmarsat access (1997)
Radio broadcast stations: AM 2, FM 355,
shortwave 0 (1998)
Radios: 6.02 million (1997)
Television broadcast stations: 26 (plus 51
repeaters) (1998)
Televisions: 3.121 million (1997)
Internet country code: .dk
Internet Service Providers (ISPs): 1 3 (2000)
Internet users: 2.3 million (2000)','321216f55eb59883162670226a0a8c1d60d67f26d302a18be5e220c6c38444cd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09b20be937e28315e1e32203f0cc35ad999501df34beb6d2310ff1986d7b782d',2001,'DJ','Djibouti','communications',383,'Telephones - main lines in use: 8,000 (1997)
Telephones - mobile cellular: 203 (1997)
Telephone system:
general assessment: telephone facilities in the city of
Djibouti are adequate as are the microwave radio
relay connections to outlying areas of the country
domestic: microwave radio relay network
international: submarine cable to Jiddah, Suez, Sicily,
Marseilles, Colombo, and Singapore; satellite earth
stations - 1 Intelsat (Indian Ocean) and 1 Arabsat;
Medarabtel regional microwave radio relay telephone
network
Radio broadcast stations: AM 2, FM 2,
shortwave 0 (1998)
Radios: 52,000(1997)
Television broadcast stations: 1 (plus 5 low-power
repeaters) (1998)
Televisions: 28,000(1997)
Internet country code: .dj
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,000 (2000)
Telephones - main lines in use: 19,000 (1996)
Telephones - mobile ceiluiar: 461 (1996)
Telephone system:
general assessment: NA
domestic: fully automatic network
international: microwave radio relay and SHF
radiotelephone links to Martinique and Guadeloupe;
VHF and UHF radiotelephone links to Saint Lucia
Radio broadcast stations: AM 3, FM 10,
shortwave 0 (1998)
Radios: 46,000(1997)
Television broadcast stations: 0 (however, there is
one cable television company) (1997)
Televisions: 6,000(1997)
Internet country code: .dm
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2,000 (2000)','a88219301f857c4af403c24065348b83d48bb472be8676c5ebbb8cee49a99c76','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b62da9bc908cd0f432b5629b4234f834843ffdb2c71f620ef46a7943b9fd3652',2001,'DO','Dominican Republic','communications',391,'Telephones - main lines in use: 709,000 (1997)
Telephones - mobile cellular: 1 30,1 49 (1 997)
Telephone system:
general assessment: N A
domestic: relatively efficient system based on
Islandwide microwave radio relay network
international: 1 coaxial submarine cable; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 120, FM 56,
shortwave 4 (1998)
Radios: 1.44 million (1997)
Television broadcast stations: 25 (1997)
Televisions: 770,000(1997)
Internet country code: .do
Internet Service Providers (ISPs): 24 (2000)
Internet users: 25,000(1999)
Telephones - main lines in use: 1 .322 million
(1997)
Telephones - mobile cellular: 1 69,265 (1 996)
Telephone system:
general assessment: modern system, integrated with
that of the US by high-capacity submarine cable and
Intelsat with high-speed data capability
domestic: digital telephone system; cellular telephone
service
international: satellite earth station - 1 1ntelsat;
submarine cable to US
Radio broadcast stations: AM 72, FM 17,
shortwave 0 (1998)
Radios: 2.7 million (1997)
Television broadcast stations: 18 (plus three
stations of the US Armed Forces Radio and T elevision
Service) (1997)
Televisions: 1.021 million (1997)
Internet country code: .pr
Internet Service Providers (ISPs): 76 (2000)
Internet users: 1 1 0,000 (2000)','729c745a745098ca0023bf81d65f470e24e7c6ba0e78a5d7585f6328ce9f8032','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0e2374c0176ecc6f8de9daa5b5869eb881aedeca60633a8e0ca85ae315f2e03',2001,'PE','Peru','communications',400,'Telephones - main lines in use: 899,000 (1997)
Telephones - mobile cellular: 160,061 (1997)
Telephone system:
general assessmenf; NA
cfomesf/c; facilities generally inadequate and
unreliable
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 392, FM 27,
shortwave 29 (1998)
Radios: 4.15 million (1997)
Television broadcast stations: 15 (including one
station on the Galapagos Islands) (1997)
Televisions: 1.55 million (1997)
Internet country code: .ec
Internet Service Providers (ISPs): 13 (2000)
Internet users: 20,000 (2000)
Telephones - main lines in use: 1.509 million
(1998)
Telephones - mobile cellular: 504,995 (1998)
Telephone system:
general assessment: adequate for most requirements
domestic: nationwide microwave radio relay system
and a domestic satellite system with 12 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); Pan American submarine cable
Radio broadcast stations: AM 472, FM 198,
shortwave 189 (1999)
Radios: 6.65 million (1997)
Television broadcast stations: 13 (plus 112
repeaters) (1997)
Televisions: 3.06 million (1997)
Internet country code: .pe
Internet Service Providers (ISPs): 10 (2000)
Internet users: 400,000 (2000)','56208554f656b572401bf9e4d48e1f6dac2cbe62b94b4e16d2d811d4ce211467','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e2ce66fc9b685bedeb7335e6305945c676f29bc66eee44db43d9487ce692654',2001,'EG','Egypt','communications',409,'Telephones ■ main lines in use: 3,971 ,500
(December 1998)
Telephones - mobile cellular: 380,000 (1999)
Telephone system;
genera/ assessment; large system; underwent
extensive upgrading during 1990s and is reasonably
modern; Internet access and cellular service are
available
domestic: principal centers at Alexandria, Cairo, At
Mansurah, Ismailia, Suez, and Tanta are connected
by coaxial cable and microwave radio relay
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean), 1 Arabsat, and 1
Inmarsat; 5 coaxial submarine cables; tropospheric
scatter to Sudan; microwave radio relay to Israel; a
participant in Medarabtel and a signatory to Project
Oxygen (a global submarine fiber-optic cable system)
Radio broadcast stations; AM 42 (plus 15
repeaters), FM 14, shortwave 3 (1999)
Radios: 20.5 million (1997)
Television broadcast stations: 98 (September
1995)
Televisions: 7.7 million (1997)
Internet country code: .eg
Internet Service Providers (ISPs): 50 (2000)
Internet users: 300,000 (2000)','fa0afc39858522df2e6beb25e2b8955045869a23c95f1dfb99e1d29fcd4e3272','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('111ec10619090b7fe54bbd2f711e19810697a91b374b84732fc191c61ecc9b1d',2001,'SV','El Salvador','communications',418,'Telephones - main lines in use: 380,000 (1998)
Telephones - mobile cellular: 40,163 (1997)
Telephone system:
general assessment: NA
domestic: nationwide microwave radio relay system
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); connected to Central American
Microwave System
Radio broadcast stations: AM 61 (plus 24
repeaters), FM 30, shortwave 0 (1998)
Radios: 2.75 million (1997)
Television broadcast stations: 5 (1997)
Televisions: 600,000(1990)
Internet country code: .sv
Internet Service Providers (ISPs): 4 (2000)
Internet users: 40,000 (2000)','605c3c700a8337024866a26bc95aed50a2cab8dd9a001b106ef3ef51564db8d4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c58ff05cf747dd19d0d388ec473d7acd21dadb11e3c16904496afbc41d9d7b19',2001,'GN','Guinea','communications',427,'Telephones - main lines in use: 4,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: poor system with adequate
government services
domestic: NA
international: international communications from Bata
and Malabo to African and European countries;
satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 0, FM 2,
shortwave 4 (1998)
Radios: 180,000(1997)
Television broadcast stations: 1 (1997)
Televisions; 4,000(1997)
Internet country code: .gq
Internet Service Providers (ISPs): 1 (2000)
Internet users: 500 (2000)
Telephones - main lines in use: 23,578 (2000)
Teiephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: very inadequate; most telephones are in
Asmara; government is seeking international tenders
to improve the system
International: NA
Radio broadcast stations: AM 2, FM 1,
shortwave 2 (2000)
Radios: 345,000(1997)
Television broadcast stations: 1 (2000)
Televisions: 1,000(1997)
Internet country code: .er
Internet Service Providers (ISPs): 4 (2000)
Internet users: 500 (2000)
Telephones - main lines in use: 47,000 (1996)
Telephones - mobile cellular: 3,053 (1996)
Telephone system:
general assessment: services are adequate and
being improved; facilities provide radiotelephone and
telegraph, coastal radio, aeronautical radio, and
international radio communication services
domestic: mostly radiotelephone
international: submarine cables to Australia and
Guam; satellite earth station - 1 1ntelsat (Pacific
Ocean); international radio communication service
Radio broadcast stations: AM 8, FM 19,
shortwave 28 (1998)
Radios: 410,000(1997)
Television broadcast stations: 3 (1997)
Televisions: 42,000(1997)
Internet country code: .pg
Internet Service Providers (ISPs): 3 (2000)
Internet users: 2,000 (2000)','a9e94cf142cfc905464c3c31d1b05c8177578e44e553ad75dcfa0423d74ff5af','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b97aa39c9e090b14cccb6ded10af55c3b6332d6e26d86dcfc5dd156074d41f95',2001,'EE','Estonia','communications',439,'Telephones - main lines in use: 476,078 (yearend
1998)
Telephones - mobile cellular: 475,000 (yearend
2000)
Telephone system:
general assessment: foreign investment in the form of
joint business ventures greatly improved telephone
service; Internet services available throughout most of
the country; about 150,000 unfilled subscriber
requests
domestic: local - the Ministry of Transport and
Communications is expanding cellular telephone
services to form rural networks; intercity - highly
developed fiber-optic backbone (double loop) system
presently serving at least 16 major cities (1998)
international: fiber-optic cables to Finland, Sweden,
Latvia, and Russia provide worldwide
packet-switched service; two international switches
are located in Tallinn
Radio broadcast stations: AM 3 (all AM stations
inactive since July 1998), FM 82, shortwave 1 (1998)
Radios: 1.01 million (1997)
Television broadcast stations: 31 (plus five
repeaters) (September 1 995)
Televisions: 605,000(1997)
internet country code: .ee
Internet Service Providers (ISPs): 28 (2000)
Internet users: 309,000 (2000)','1a92d8ec7f7c7b521af2d61a75a75e0f89907a297b3aa66723ae780395d50b9f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f02eca78110a53a4191df136771174f27a69687f178f8e027510fcb1fb4d09e',2001,'FO','Faroe Islands','communications',447,'Telephones - main lines in use: 24,851 (1999)
Telephones - mobile cellular: 10,761 (1999)
Telephone system:
general assessment: good international
communications; good domestic facilities
domestic: digitalization was to have been completed
in 1998; both NMT (analog) and GSM (digital) mobile
telephone systems are installed
/ntemaf/ona/; satellite earth stations - 1 Orion; 1
fiber-optic submarine cable to the Shetland Islands,
linking the Faroe Islands with Denmark and Iceland;
fiber-optic submarine cable connection to
Canada-Europe cable
Radio broadcast stations: AM 1, FM 13,
shortwave 0 (1998)
Radios: 26,000(1997)
Television broadcast stations: 3 (plus 43
low-power repeaters) (September 1995)
Televisions: 15,000(1997)
Internet country code: .fo
Internet Service Providers (ISPs): 2 (2000)
Internet users; 3,000 (2000)','0f1db1b6608b9b6f15f592af88e124c845174bc00b35e93d7e49c6c64d83cbc4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb2f287011a752cfa11c0543000fd257a710f5788a368299c3a5ff9b2bb9fbac',2001,'JE','Jersey','communications',459,'Teiephones - main lines In use: 72,000 (1997)
Telephones - mobile cellular: 5,200 (1997)
Telephone system:
general assessment: modern local, Interisland, and
international (wire/radio integrated) public and
special-purpose telephone, telegraph, and teleprinter
facilities; regional radio communications center
domestic: NA
international: access to important cable links between
US and Canada as well as between NZ and Australia;
satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 13, FM 40,
shortwave 0 (1998)
Radios: 500,000(1997)
Television broadcast stations: NA
Televisions: 21,000(1997)
Internet country code: .fj
Internet Service Providers (ISPs): 2 (2000)
Internet users: 7,500 (2000)
Telephones - main lines In use: 2.861 million
(1997)
Telephones ■ mobile cellular: 2,162,574 (1997)
Telephone system:
general assessment: modern system with excellent
service
domestic: cable, microwave radio relay, and an
extensive cellular net provide domestic needs
international: 1 submarine cable; satellite earth
stations - access to Intelsat transmission service via a
Swedish satellite earth station, 1 Inmarsat (Atlantic
and Indian Ocean regions); note - Finland shares the
Inmarsat earth station with the other Nordic countries
(Denmark, Iceland, Norway, and Sweden)
Radio broadcast stations: AM 2, FM 186,
shortwave 1 (1998)
Radios: 7.7 million (1997)
Television broadcast stations: 130 (plus 385
repeaters) (1995)
Televisions: 3.2 million (1997)
Internet country code: .fi
Internet Service Providers (ISPs): 23 (2000)
Internet users: 2.27 million (2000)
Telephones ■ main lines in use: 412,000 (1997)
Telephones ■ mobile cellular: 210,000 (1997)
Telephone system:
general assessment: the quality of service is excellent
domestic: new telephone exchanges provide a large
capacity for new subscribers; trunk traffic is carried by
microwave radio relay, coaxial cable, open wire, and
fiber-optic cable; a cellular telephone system operates
throughout Kuwait, and the country is well supplied
with pay telephones
international: coaxial cable and microwave radio relay
to Saudi Arabia; linked to Bahrain, Qatar, UAE via the
Fiber-Optic Gulf (FOG) cable; satellite earth stations -
3 Intelsat (1 Atlantic Ocean, 2 Indian Ocean), 1
Inmarsat (Atlantic Ocean), and 2 Arabsat
Radio broadcast stations: AM 6, FM 1 1 ,
shortwave 1 (1998)
Radios: 1.175 million (1997)
Television broadcast stations: 13 (plus several
satellite channels) (1997)
Televisions: 875,000(1997)
Internet country code: .kw
Internet Service Providers (ISPs): 3 (2000)
Internet users: 100,000(2000)
Telephones - main lines In use: 47,000 (1997)
Telephones - mobile cellular: 1 3,040 (1 998)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 5,
shortwave 0 (1998)
Radios: 107,000(1997)
Television broadcast stations: 6 (plus 25
low-power repeaters) (1 997)
Televisions: 52,000(1997)
Internet country code: .nc
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 722,000 (1997)
Telephones - mobile cellular: 1 million (2000)
Telephone system:
general assessment: NA
domestic: 100% digital (2000)
international: NA
Radio broadcast stations: AM 17, FM 160,
shortwave 0 (1998)
Radios: 805,000(1997)
Television broadcast stations: 48 (2001)
Televisions: 710,000(1997)
Internet country code: .si
Internet Service Providers (ISPs): 11 (2000)
Internet users: 460,000(1999)
Telephones - main lines in use: 33,500 (2000)
Telephones - mobile cellular: 30,000 (2000)
Telephone system:
general assessment: not a modern system
domestic: system consists of carrier-equipped,
open-wire lines and low-capacity, microwave radio
relay
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 7, FM 6 (2000)
Radios: 155,000(1997)
Television broadcast stations: 10 (2000)
Televisions: 21,000(1997)
Internet country code: .sz
Internet Service Providers (ISPs): 3 (2000)
Internet users: 4,000 (2000)
Television broadcast stations: 169 (plus 1 ,299
repeaters) (1995)
Televisions: 4.6 million (1997)
Internet country code: .se
Internet Service Providers (ISPs): 29 (2000)
Internet users: 4.5 million (2000)','1461bbd76e59e49ace19785a189f58f6655496c43ca4e41515edf47cbf737675','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f53a90c4845007683bfe1f3592cd2a202f68baae403a1537d451e3ce816403a4',2001,'WF','Wallis and Futuna','communications',466,'Telephones - main lines In use: 34.86 million
(yearend 1998)
Telephones - mobile cellular: 1 1 .078 million
(yearend 1998)
Telephone system:
general assessment: highly developed
domestic: extensive cable and microwave radio relay;
extensive introduction of fiber-optic cable; domestic
satellite system
international: satellite earth stations - 2 Intelsat (with
total of 5 antennas - 2 for Indian Ocean and 3 for
Atlantic Ocean), NA Eutelsat, 1 1nmarsat (Atlantic
Ocean region); HF radiotelephone communications
with more than 20 countries
Radio broadcast stations: AM 41 , FM about 3,500
(this figure is an approximation and includes many
repeaters), shortwave 2 (1998)
Radios: 55.3 million (1997)
Television broadcast stations: 584 (plus 9,676
repeaters) (1995)
Televisions: 34.8 million (1997)
Internet country code: .fr
Internet Service Providers (ISPs): 62 (2000)
Internet users: 9 million (2000)','c0c3f8ee191b57a8327454cbdd0b873958afbcf41cb171f72d36f6bbbabe1dbc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a98a1d0522768073b018c0bc96b93a927b33e0d4e6f52a9dbf728f9188a612c8',2001,'KI','Kiribati','communications',481,'Telephones - main lines in use: 52,000 (1997)
Telephones - mobile cellular: 5,427 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 14,
shortwave 2 (1998)
Radios: 128,000(1997)
Television broadcast stations: 7 (plus 17
low-power repeaters) (1997)
Televisions: 40,000(1997)
Internet country code: .pf
Internet Service Providers (ISPs): 2 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 2,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: N A
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
272
Kiribati (continued)
note: Kiribati is being linked to the Pacific Ocean
Cooperative Telecommunications Network, which
should improve telephone service
Radio broadcast stations: AM 1 , FM 1 ,
shortwave 1 (1998)
Radios: 17,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 1,000(1997)
Internet country code: .ki
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,000 (2000)
Telephones - main lines in use: 1.1 million (1997)
Telephones - mobile cellular: NA
Telephone system:
genera! assessment: NA
domestic: NA
international: satellite earth stations - 1 1ntelsat (Indian
Ocean) and 1 Russian (Indian Ocean region): other
international connections through Moscow and Beijing
Radio broadcast stations: AM 16, FM 14,
shortwave 12 (1999)
Radios: 3.36 million (1997)
Television broadcast stations: 38 (1999)
Televisions: 1.2 million (1997)
Internet country code: .kp
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use; 24 million (1999)
Telephones - mobile cellular: 27 million (June
2000)
Telephone system:
general assessment: excellent domestic and
International services
domestic: NA
/nfemaf/ona/; fiber-optic submarine cable to China;
the Russia-Korea-Japan submarine cable; satellite
earth stations - 3 Intelsat (2 Pacific Ocean and 1
Indian Ocean) and 1 1nmarsat (Pacific Ocean region)
Radio broadcast stations: AM 106, FM 97,
shortwave 6 (1999)
Radios: 47.5 million (1997)
Television broadcast stations: 121 (plus 850
repeater stations and the eight-channel American
Forces Korea Network) (1999)
Televisions; 15.9 million (1997)
Internet country code: .kr
Internet Service Providers (ISPs); 1 1 (2000)
Internet users: 15.3 million (2000)','96f2cb231ba83c2beeb9804178967dd5cfc4033b3de7568e42eab809a34bce53','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a6ea449acb246b8c8bdc2d9fbbc30feabc7345c4fcd4fe370da38ee1b173827',2001,'DE','Germany','communications',488,'Telephones - main lines in use: 45.2 million (1997)
note: 46.5 million main lines were installed by yearend
1998
Telephones - mobile cellular: 15.318 million (April
1999)
Telephone system:
genera! assessment: Germany has one of the world''s
most technologically advanced telecommunications
systems; as a result of intensive capital expenditures
since reunification, the formerly backward system of
the eastern part of the country has been modernized
and integrated with that of the western part
domestic: Germany is served by an extensive system
of automatic telephone exchanges connected by
modern networks of fiber-optic cable, coaxial cable,
microwave radio relay, and a domestic satellite
system; cellular telephone service is widely available
and includes roaming service to many foreign
countries
international: sateWWe earth stations - 14 Intelsat (12
Atlantic Ocean and 2 Indian Ocean), 1 Eutelsat, 1
Inmarsat (Atlantic Ocean region), 2 Intersputnik (1
Atlantic Ocean region and 1 Indian Ocean region); 7
submarine cable connections; 2 HF radiotelephone
communication centers; tropospheric scatter links
Radio broadcast stations: AM 51 , FM 767,
shortwave 4 (1998)
Radios: 77.8 million (1997)
Television broadcast stations: 373 (plus 8,042
repeaters) (1995)
Televisions: 51 .4 million (1 998)
Internet country code: .de
Internet Service Providers (ISPs): 123 (2000)
Internet users: 18 million (2000)
Telephones - main lines in use: 314,700 (1999)
Telephones - mobile cellular: 215,741 (2000)
Telephone system:
general assessment: highly developed, completely
automated and efficient system, mainly buried cables
domestic: nationwide cellular telephone system;
buried cable
international: 3 channels leased on TAT-6 coaxial
submarine cable (Europe to North America)
Radio broadcast stations: AM 2, FM 9,
shortwave 2 (1999)
Radios: 285,000(1997)
Television broadcast stations: 5 (1999)
Televisions: 285,000 (1998 est.)
Internet country code: .lu
Internet Service Providers (ISPs): 8 (2000)
Internet users: 86,000(1999)
Telephones - main lines in use: 176,837 (2000)
Telephones - mobile cellular: 120,957 (2000)
Telephone system:
genera/ assessment fairly modern communication
facilities maintained for domestic and international
services
domestic: NA
international: HP radiotelephone communication
facility: access to international communications
carriers provided via Hong Kong and China; satellite
earth station - 1 1ntelsat (Indian Ocean)
Radio broadcast stations: AM 0, FM 2,
shortwave 0(1998)
Radios: 160,000(1997)
Television broadcast stations: 0 (receives Hong
Kong broadcasts) (1997)
Televisions: 49,000(1997)
Internet country code: .mo
Internet Service Providers (ISPs): 1 (2000)
Internet users: 40,000 (2000)
Telephones - main lines in use: 408,000 (1997)
Telephones ■ mobile cellular: 12,362 (1997)
Telephone system:
genera! assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM 29, FM 20,
shortwave 0 (1998)
Radios: 410,000(1997)
Television broadcast stations: 31 (plus 166
repeaters) (1995)
Televisions: 510,000(1997)
internet country code: .mk
internet Service Providers (iSPs): 6 (2000)
internet users: 30,000 (2000)
Telephones - main lines in use: 9,132,400 (1999)
Telephones - mobile cellular: 4,081,891 (April
1999)
Telephone system;
general assessment: highly developed and well
maintained
domestic: \\he existing system of multi-conductor
cables is gradually being replaced by fiber-optic
cables: the density of cellular telephone traffic is
rapidly increasing and further modernization of the
system is expected in the year 2001 , with the
introduction of the third generation of the Global
System for Mobile Communications (GSM)
international: 5 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean), 1 Eutelsat, and 1 1nmarsat (Atlantic and
Indian Ocean regions) (1996)
Radio broadcast stations: AM 4, FM 58,
shortwave 3 (1998)
Radios: 15.3 million (1996)
Television broadcast stations: 21 (plus 26
repeaters) (1995)
Televisions: 8.1 million (1997)
Internet country code: .nl
Internet Service Providers (ISPs); 52 (2000)
Internet users: 6.8 million (2000)','e353f493efcc3d7e55d055dc2da573a4890846fa1cca0dd745eadc99c1cf5311','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0949c581d1de51c59c9a820c881c01234eb1c31d5240a628943fe8dd5a7d455',2001,'GH','Ghana','communications',497,'Teiephones - main lines in use: 200,000 (1998)
Telephones - mobile cellular: 30,000 (yearend
1998)
Telephone system:
general assessment: poor to fair system; Internet
accessible: many rural communities not yet
connected; expansion of services is underway
domestic: primarily microwave radio relay; wireless
local loop has been installed
international: satellite earth stations - 4 Intelsat
(Atlantic Ocean); microwave radio relay link to
Panaftel system connects Ghana to its neighbors
Radio broadcast stations: AM 0, FM 18,
shortwave 3 (1999)
Radios: 4.4 million (1997)
Television broadcast stations: 11 (1999)
Televisions: 1 .73 million (1 997)
Internet country code: .gh
Internet Service Providers (ISPs): 1 (2000)
Internet users: 20,000 (2000)','06d7a8883558b40f2ba3912c27fbb2f094e72695a45d40876d60048479785b8c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0bc66d3fa14b33061c599081a13db925a4fd3e6561cf0a3658db9a195f3ed10',2001,'GI','Gibraltar','communications',505,'Telephones - main lines in use: 19,000 (1997)
Telephones - mobile cellular: 1 ,620 (1 997)
Telephone system:
genera! assessment: adequate, automatic domestic
system and adequate international facilities
domestic: automatic exchange faciiities
international: radiotelephone; microwave radio relay;
satellite earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (1998)
Radios: 37,000(1997)
Television broadcast stations: 1 (plus three
low-power repeaters) (1997)
Televisions: 10,000 (1997)
Internet country code: .gi
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Communications - note: 1 meteorological station
Telephones - main lines in use: 1 .391 million
(1998)
Telephones - mobile cellular: 1 1 6,645 (1 998)
Telephone system:
general assessment: modern system with all
important capabilities; however density is low with
only 4.6 main lines available for each 100 persons
domestic: good system composed of open-wire lines,
cables, and microwave radio relay links; Internet
available but expensive; principal switching centers
are Casablanca and Rabat; national network nearly
100% digital using fiber-optic links; improved rural
service employs microwave radio relay
international: 1 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Arabsat;
microwave radio relay to Gibraltar, Spain, and
Western Sahara; coaxial cable and microwave radio
relay to Algeria; participant in Medarabtel; fiber-optic
cable link from Agadir to Algeria and Tunisia (1 998)
Radio broadcast stations: AM 27, FM 25,
shortwave 6 (1998)
Radios: 6.64 million (1997)
Television broadcast stations: 35 (plus 66
repeaters) (1995)
Televisions; 3.1 million (1997)
Internet country code: .ma
Internet Service Providers (ISPs): 8 (2000)
Internet users: 120,000(1999)','5974f07f08713875c92f5ffb473b1d07588d895ef3d6e5f116f3e11ff2c7ed48','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e42dc920a35b6937860409c4d4059086b8c0ba34a57b7084c68be33d05a11bb',2001,'GR','Greece','communications',514,'Telephones - main lines in use: 5.431 million
(1997)
Telephones - mobile cellular: 937,700 (1 997)
Telephone system:
genera/ assessment: adequate, modern networks
reach all areas; good mobile telephone and
international service
domestic: microwave radio relay trunk system;
extensive open wire connections; submarine cable to
offshore islands
/nfernat/ona/: tropospheric scatter; 8 submarine
cables; satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean), 1 Eutelsat, and 1
Inmarsat (Indian Ocean region)
Radio broadcast stations; AM 26, FM 88,
shortwave 4 (1998)
Radios: 5.02 million (1997)
Television broadcast stations: 36 (plus 1,341
low-power repeaters); also two stations in the US
Armed Forces Radio and Television Service (1995)
Televisions: 2.54 million (1997)
Internet country code: .gr
Internet Service Providers (ISPs): 27 (2000)
Internet users: 1 .33 million (1999)','54190689e97d41d9e127408d86a19450e165aac5f6cd99fec928d618e3829b5e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5466a2363c743b3def37132a3081336d50e7442cd762aca0d516b6411b95d49d',2001,'GL','Greenland','communications',522,'Telephones ■ main lines in use: 25,61 7 (end 1 999)
Telephones - mobile cellular: 12,676 (end 1999)
Telephone system:
genera! assessment: adequate domestic and
international service provided by satellite, cables and
microwave radio relay: totally digitalized in 1995
domestic: microwave radio relay and satellite
international: sateWWe earth stations - 12 Intelsat, 1
Eutelsat, 2 Americom GE-2 (all Atlantic Ocean)
Radio broadcast stations: AM 5, FM 12,
shortwave 0(1998)
Radios: 30,000 (1998 est.)
Television broadcast stations; 1 publicly-owned
station, some local low-power stations, and three
AFRTS (US Air Force) stations (1997)
Televisions: 22,000(1997)
Internet country code: .gl
Internet Service Providers (ISPs): 1 (2000)
Internet users: 4,008(1999)','2f4373fdfb0b8c56f1d827b2b701131ed1dde1c7b7eb45ef88ba518aa23a85a0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e42456b3d23c8d972f41ec43e388c7736e728628e679a3bdc3cf719537ddc552',2001,'GD','Grenada','communications',529,'Telephones - main lines In use: 27,000 (1997)
Telephones ■ mobile cellular: 976 (1997)
Telephone system:
general assessment: automatic, islandwide
telephone system
domestic: interisland VHF and UHF radiotelephone
links
international: new SHF radiotelephone links to
Trinidad and Tobago and Saint Vincent; VHF and
UHF radio links to Trinidad
Radio broadcast stations: AM 2, FM 1,
shortwave 0 (1 998)
Radios: 57,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 33,000(1997)
Internet country code: .gd
Internet Service Providers (ISPs): 14 (2000)
Internet users: 2,000 (2000)
Telephones - main lines in use: 20,500 (1998)
Telephones - mobile cellular: NA
Telephone system:
general assessment: adequate system
domestic: islandwide, fully automatic telephone
system; VHF/UHF radiotelephone from Saint Vincent
to the other islands of the Grenadines
international: VHF/UHF radiotelephone from Saint
Vincent to Barbados; new SHF radiotelephone to
Grenada and to Saint Lucia; access to Intelsat earth
station in Martinique through Saint Lucia
Radio broadcast stations: AM 1 , FM 3,
shortwave 0 (1998)
Radios: 77,000(1997)
Television broadcast stations: 1 (plus three
repeaters) (1997)
Televisions: 18,000(1997)
Internet country code: .vc
Internet Service Providers (ISPs): 15 (2000)
Internet users: 2,000 (2000)','27d55bec3aa1f98ebd38c257121331403dd1b5ad580860f7523ffa7c8732b0eb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ee4f58f12f8cb81efa4aa3d5b2938d1c03a27b714810cf7416c3d57ac48fe00',2001,'GU','Guam','communications',540,'Telephones - main lines in use: 84,134 (1998)
Telephones - mobile cellular: 55,000 (1998)
Telephone system:
general assessment: modern system, integrated with
US facilities for direct dialing, including free use of 800
numbers
domestic: modern digital system, including cellular
mobile service and local access to the Internet
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); submarine cables to US and Japan
(Guam is a trans-Pacific communications hub for MCI,
Sprint, AT&T, IT&E, and GTE, linking the US and
Asia)
Radio broadcast stations: AM 4, FM 7,
shortwave 0 (1998)
Radios: 221,000(1997)
Television broadcast stations: 5 (1997)
Televisions: 106,000(1997)
Internet country code: .gu
Internet Service Providers (ISPs): 20 (2000)
Internet users: 5,000 (2000)','95979aeb01c615c828cea76c24f829992ccac587b2d6b124f275bbd2d253889c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4910ce58997c7383af18ca5c0d000bb1019e11626a16fa758f30307c5aeb58a',2001,'GT','Guatemala','communications',547,'Telephones - main lines in use: 665,061 (June
2000)
Telephones ■ mobile cellular: 663,296 (September
2000)
Telephone system:
genera/ assessment fairly modern network centered
in the city of Guatemala
domestic: NA
international: connected to Central American
Microwave System; satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 130, FM 487,
shortwave 15 (2000)
Radios: 835,000(1997)
Television broadcast stations: 26 (plus 27
repeaters) (1997)
Televisions: 1 .323 million (1 997)
Internet country code: .gt
Internet Service Providers (ISPs): 5 (2000)
Internet users: 65,000 (2000)','6bc9445124fcba1a97e1146d57145334718ded67942ac8eeedfc7f4ff66c124e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d605c51ff5fb753a5c8bce69849e12fe629fc9da17905c9c2b5403acfbc1492',2001,'GG','Guernsey','communications',555,'Telephones - main lines In use: 44,000 (1996)
Telephones - mobile cellular: 12,000 (1997)
Telephone system:
general assessment: N A
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Internet country code: .gg
Internet Service Providers (ISPs): NA
Internet users: NA
210
Guernsey (continued)','bd31f095f31171d0a9c46026e288a0a85cbc486847156667f1ff02140023d611','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92d4f1f78f99b7e36c0e7872b62f9e84a01688b2ab8940ca2b506acbd708efe3',2001,'GW','Guinea-Bissau','communications',558,'Telephones ■ main lines In use: 20,000 (1997)
Telephones - mobile cellular: 2,868 (1997)
Telephone system:
general assessment: poor to fair system of open-wire
lines, small radiotelephone communication stations,
and new microwave radio relay system
domestic: microwave radio relay and radiotelephone
communication
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM 8,
shortwave 3 (1998)
Radios: 357,000(1997)
Television broadcast stations: 6 (1997)
Televisions: 85,000(1997)
Internet country code: .gn
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000 (2000)','38c4e9236f52b59d0f7f8c9e783c25801db426ace6c1293bb7e5d9e6e825f35a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd41d486fadc73c458a124005474fbf697fd102e0271e5347f445d90173f56e1',2001,'GY','Guyana','communications',565,'Telephones - main lines in use: 70,000 (2000)
Telephones - mobile cellular: 6,100 (2000)
Telephone system:
genera/ assessment'' fair system for long-distance
calling
domestic: microwave radio relay network for trunk
lines
international: tropospheric scattertoTrinidad; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3,
shortwave 1 (1998)
Radios: 420,000 (1997)
Television broadcast stations: 3 (one public
station; two private stations which relay US satellite
services) (1997)
Televisions: 46,000(1997)
Internet country code: .gy
Internet Service Providers (ISPs): 3 (2000)
Internet users: 3,000 (2000)
Telephones - main lines in use: 64,000 (1997)
Telephones - mobile cellular: 4,090 (1997)
Telephone system:
general assessment: international facilities are good
domestic: microwave radio relay network
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM 13,
shortwave 1 (1998)
Radios: 300,000 (1997)
Television broadcast stations: 3 (plus seven
repeaters) (2000)
Televisions: 63,000(1997)
Internet country code: .sr
Internet Service Providers (ISPs): 2 (2000)
Internet users: 10,000 (2000)
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: probably adequate
domestic: local telephone service
international: satellite earth station - 1 of unknown
type (for communication with Norwegian mainland
only)
Radio broadcast stations: AM 1, FM 1 (plus 2
repeaters), shortwave 0 (1998)
Radios: NA
Television broadcast stations: NA
Televisions: NA
Internet country code: .sj
Internet Service Providers (ISPs): 13 (Svalbard
and Jan Mayen) (2000)
Internet users: NA','0413134d8bff23a2b4c9d71269441479479b545f1b72f7f101b8bb8590ab93d0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79e2e3a034fe230565aa355b9c92692f38925856ec39d58fc8d1f146a036b118',2001,'HK','Hong Kong','communications',576,'Telephones - main lines in use: 3.839 million
(1999)
Telephones ■ mobile cellular: 3.7 million
(December 1999)
Telephone system:
general assessment: modern facilities provide
excellent domestic and international services
domestic: microwave radio relay links and extensive
fiber-optic network
international: satellite earth stations - 3 Intelsat (1
Pacific Ocean and 2 Indian Ocean); coaxial cable to
Guangzhou, China; access to 5 international
submarine cables providing connections to ASEAN
member nations, Japan, Taiwan, Australia, Middle
East, and Western Europe
Radio broadcast stations: AM 7, FM 13,
shortwave 0 (1998)
Radios: 4.45 million (1997)
Television broadcast stations: 4 (plus two
repeaters) (1997)
Televisions: 1 .84 million (1 997)
Internet country code: .hk
Internet Service Providers (iSPs): 17 (2000)
Internet users: 1 .85 million (2000)','b65eb96a0767af4c46d24982012b2582e6ac1edb6eddd847c9f8c6a74254aa66','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('560030fc0ef69410e2b301699e8380a6b6e6ba05bfa3e3683fc64d5b65fda58c',2001,'AT','Austria','communications',586,'Telephones ■ main lines in use: 168,000 (1997)
Teiephones - mobile cellular: 65,746 (1997)
Telephone system:
genera/ assessment; adequate domestic service
cfomesf/c.''the trunk network consists of coaxial and
fiber-optic cables and microwave radio relay links
/nternat/ona/; satellite earth stations - 2 Intelsat
(Atlantic Ocean), 1 1nmarsat (Atlantic and Indian
Ocean regions); note - Iceland shares the Inmarsat
earth station with the other Nordic countries
(Denmark, Finland, Norway, and Sweden)
Radio broadcast stations: AM 3, FM about 70
(including repeaters), shortwave 1 (1998)
Radios: 260,000(1997)
Television broadcast stations: 14 (plus 156
low-power repeaters) (1997)
Televisions: 98,000(1997)
Internet country code: .is
Internet Service Providers (iSPs): 7 (2000)
internet users: 144,000(2000)
Telephones - main lines In use: 27.7 million
(October 2000)
Telephones - mobile cellular: 2.93 million
(November 2000)
Telephone system:
general assessment: mediocre service; local and long
distance service provided throughout all regions of the
country, with services primarily concentrated in the
urban areas; major objective is to continue to expand
and modernize long-distance network in order to keep
pace with rapidly growing number of local subscriber
lines; steady improvement is taking place with the
recent admission of private and private-public
investors, but, with telephone density at about two for
each 100 persons and a waiting list of over 2 million,
demand for main line telephone service will not be
satisfied for a very long time
domestic: local service is provided by microwave
radio relay and coaxial cable, with open wire and
obsolete electromechanical and manual switchboard
systems still in use in rural areas; starting in the
1 980s, a substantial amount of digital switch gear has
been introduced for local and long-distance service;
long-distance traffic is carried mostly by coaxial cable
and low-capacity microwave radio relay; since 1985
significant trunk capacity has been added in the form
of fiber-optic cable and a domestic satellite system
with 254 earth stations; mobile cellular service is
provided in four metropolitan cities
international: satellite earth stations - 8 Intelsat
(Indian Ocean) and 1 1nmarsat (Indian Ocean region);
nine gateway exchanges operating from Mumbai
(Bombay), New Delhi, Kolkata (Calcutta), Chennai
(Madras), Jalandhar, Kanpur, Gaidhinagar,
Hyderabad, and Ernakulam; 4 submarine cables -
LOCOM linking Chennai (Madras) to Penang;
Indo-UAE-Gulf cable linking Mumbai (Bombay) to Al
Fujayrah, UAE; lndia-SEA-ME-WE-3, SEA-ME-WE-2
with landing sites at Cochin and Mumbai (Bombay);
Fiber-Optic Link Around the Globe (FLAG) with
landing site at Mumbai (Bombay) (2000)
Radio broadcast stations: AM 153, FM 91 ,
shortwave 68 (1998)
Radios: 116 million (1997)
Television broadcast stations: 562 (of which 82
stations have 1 kW or greater power and 480 stations
have less than 1 kW of power) (1997)
Televisions: 63 million (1997)
Internet country code: .in
Internet Service Providers (ISPs): 43 (2000)
Internet users: 4.5 million (2000)
Telephones - main lines in use: 5,588,310 (1998)
Telephones - mobile cellular: 1 .07 million (1 998)
Telephone system:
general assessment: domestic service fair,
international service good
domestic: interisland microwave system and HF radio
police net; domestic satellite communications system
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 678, FM 43,
shortwave 82 (1998)
Radios: 31 .5 million (1997)
Television broadcast stations: 41 (1999)
Televisions: 13.75 million (1997)
Internet country code: .id
Internet Service Providers (ISPs): 24 (2000)
Internet users: 400,000 (2000)
Telephones - main lines in use: 6.313 million
(1997)
Telephones - mobile cellular: 265,000 (August
1998)
Telephone system:
general assessment: inadequate but currently being
modernized and expanded with the goal of not only
improving the efficiency and increasing the volume of
the urban service but also bringing telephone service
to several thousand villages, not presently connected
domestic: as a result of heavy investing in the
telephone system since 1994, the number of
long-distance channels in the microwave radio relay
trunk has grown substantially; many villages have
been brought into the net; the number of main lines in
the urban systems has approximately doubled; and
thousands of mobile cellular subscribers are being
served; moreover, the technical level of the system
has been raised by the installation of thousands of
digital switches
international: HF radio and microwave radio relay to
Turkey, Azerbaijan, Pakistan, Afghanistan,
Turkmenistan, Syria, Kuwait, Tajikistan, and
Uzbekistan; submarine fiber-optic cable to UAE with
access to Fiber-Optic Link Around the Globe (FLAG);
Trans-Asia-Europe (TAE) fiber-optic line runs from
Azerbaijan through the northern portion of Iran to
Turkmenistan with expansion to Georgia and
Azerbaijan; satellite earth stations - 9 Intelsat and 4
Inmarsat; internet service available but limited to
electronic mail to promote Iranian culture
Radio broadcast stations: AM 72, FM 5,
shortwave 5 (1998)
Radios: 17 million (1997)
Television broadcast stations: 28 (plus 450
low-power repeaters) (1997)
Televisions: 4.61 million (1997)
Internet country code: ,lr
Internet Service Providers (ISPs): 8 (2000)
Internet users: 100,000 (2000)
Telephones - main lines in use: 675,000 (1997)
Telephones - mobile cellular: NA; service
available in northern Iraq (2001)
Telephone system:
general assessment: reconstitution of damaged
telecommunication facilities began after the Gulf war;
most damaged facilities have been rebuilt
domestic: \\he network consists of coaxial cables and
microwave radio relay links
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik
(Atlantic Ocean region), and 1 Arabsat (inoperative);
coaxial cable and microwave radio relay to Jordan,
Kuwait, Syria, and Turkey; Kuwait line is probably
nonoperational
Radio broadcast stations: AM 19 (5 are inactive),
FM 51, shortwave 4 (1998)
Radios: 4.85 million (1997)
Television broadcast stations: 1 3 (1 997)
Televisions: 1.75 million (1997)
Internet country code: .iq
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','b5fecc8b67ef96aeeca8c76aaef8108b019868757b586b66b00ad2e67c672718','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df65806a4c9b423152f6af3c099c28e2632ca9432781de65b7d72ab4771a9ffc',2001,'IE','Ireland','communications',596,'Telephones ■ main lines in use; 1 .59 million (2001 )
Telephones - mobile cellular: 2 million (2001)
Telephone system:
general assessment: modern digital system using
cable and microwave radio relay
domestic: microwave radio relay
/ntemaf/ona/; satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 9, FM 106,
shortwave 0 (1998)
Radios: 2.55 million (1997)
Television broadcast stations: 4 (many low-power
repeaters) (2001)
Televisions: 1.82 million (2001)
Internet country code: .ie
Internet Service Providers (ISPs): 22 (2000)
Internet users: 1 million (2001)','d4f28f7fb782abb97cd53651f6719f5b3af65faaedc8c1bfec7273400ec2b3bf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc9d4b146ad5134d667466040b2751ce8c3ccd17d6f116fc59cf77ec85cc4e43',2001,'IL','Israel','communications',604,'Telephones - main lines in use: 2.8 million (1999)
Telephones - mobile cellular: 2.5 million (1999)
Telephone system:
general assessment: most highly developed system
in the Middle East although not the largest
domestic: good system of coaxial cable and
microwave radio relay; all systems are digital
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 Indian
Ocean)
Radio broadcast stations: AM 23, FM 15,
shortwave 2 (1998)
Radios: 3.07 million (1997)
Television broadcast stations: 17 (plus 36
low-power repeaters) (1995)
Televisions: 1.69 million (1997)
Internet country code: .il
Internet Service Providers (ISPs): 21 (2000)
Internet users: 1 million (2000)','b63628668c0ee7a58a0d3b96af553653a77947951e3679659483035081ac47db','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72863a33f095125194bf25bfd9f1da59c4126eadadeb468a23cffc3e9c281323',2001,'TN','Tunisia','communications',612,'Telephones - main lines in use: 25 million (1999)
Telephones - mobile cellular: 20.5 million (1999)
Telephone system:
general assessment: modern, well developed, fast;
fully automated telephone, telex, and data services
domestic: high-capacity cable and microwave radio
relay trunks
international: satellite earth stations - 3 Intelsat (with a
total of 5 antennas - 3 for Atlantic Ocean and 2 for
Indian Ocean), 1 Inmarsat (Atlantic Ocean region),
and NA Eutelsat; 21 submarine cables
Radio broadcast stations: AM about 100, FM
about 4,600, shortwave 9 (1998)
Radios: 50.5 million (1997)
Television broadcast stations: 358 (plus 4,728
repeaters) (1995)
Televisions: 30.3 million (1997)
Internet country code: .it
Internet Service Providers (ISPs): 93 (Italy and
Holy See) (2000)
Internet users: 1 1 .6 million (2000)
Telephones ■ main lines In use; 654,000 (1997)
Telephones - mobile cellular: 50,000 (1998)
Telephone system:
general assessment: above the African average and
continuing to be upgraded; key centers are Sfax,
Sousse, Bizerte, and Tunis; Internet access available
domestic: trunk facilities consist of open-wire lines,
coaxial cable, and microwave radio relay
international: 5 submarine cables; satellite earth
stations - 1 Intelsat (Atlantic Ocean) and 1 Arabsat;
coaxial cable and microwave radio relay to Algeria
and Libya; participant in Medarabtel; two international
gateway digital switches
Radio broadcast stations: AM 7, FM 20,
shortwave 2 (1998)
Radios: 2.06 million (1997)
Television broadcast stations: 26 (plus 76
repeaters) (1995)
Televisions: 920,000(1997)
Internet country code; .tn
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 1 0,000 (2000)
Telephones - main lines in use: 1 9.5 million (1 999)
Telephones - mobile cellular: 12.1 million (1999)
Telephone system:
general assessment: undergoing rapid modernization
and expansion, especially cellular telephones
domestic: additional digital exchanges are permitting
a rapid increase in subscribers; the construction of a
network of technologically advanced intercity trunk
lines, using both fiber-optic cable and digital
microwave radio relay is facilitating communication
between urban centers; remote areas are reached by
a domestic satellite system; the number of
subscribers to mobile cellular telephone service is
growing rapidly
international: international service is provided by three
submarine fiber-optic cables in the Mediterranean and
Black Seas, linking Turkey with Italy, Greece, Israel,
Bulgaria, Romania, and Russia, by 12 Intelsat earth
stations, and by 328 mobile satellite terminals in the
Inmarsat and Eutelsat systems
Radio broadcast stations: AM 16, FM 72,
shortwave 6 (1998)
Radios: 11.3 million (1997)
Television broadcast stations: 635 (plus 2,934
repeaters) (1995)
Televisions: 20.9 million (1997)
Internet country code: .tr
Internet Service Providers (ISPs): 22 (2000)
Internet users: 2 million (2000)
Telephones - main lines in use: 363,000 (1997)
Telephones - mobile cellular: 4,300 (1998)
Telephone system:
general assessment: poorly developed
domestic: NA
international: linked by cable and microwave radio
relay to other CIS republics and to other countries by
leased connections to the Moscow international
gateway switch; a new telephone link from Ashgabat
to Iran has been established; a new exchange in
Ashgabat switches international traffic through T urkey
via Intelsat; satellite earth stations - 1 Orbita and 1
Intelsat
Radio broadcast stations: AM 16, FM 8,
shortwave 2 (1998)
Radios: 1,225 million (1997)
Television broadcast stations: 3 (much
programming relayed from Russia and T urkey) (1 997)
Televisions: 820,000(1997)
Internet country code: .tm
Internet Service Providers (ISPs): NA
Internet users: 2,000 (2000)
514
Turkmenistan (continued)
Telephones - main lines in use: 3,000 (1994)
Telephones ■ mobile cellular: 0 (1994)
Telephone system:
general assessment: fair cable and radiotelephone
services
domestic: NA
international: 2 submarine cables; satellite earth
station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3 (one inactive), FM
6, shortwave 0(1998)
Radios: 8,000(1997)
Television broadcast stations: 0 (broadcasts from
The Bahamas are received; cable television is
established) (1997)
Televisions: NA
Internet country code: .tc
Internet Service Providers (ISPs); 14 (2000)
Internet users: NA','29a6f95055e299c5c44eaa61b2bb58e26f994ea37676cac8d2b55c502bfdd739','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9643a2fb0ce649566041c52888a154a29ac4891032502b80c74ca996fa3d2be',2001,'JM','Jamaica','communications',621,'Telephones - main iines in use: 353,000 (1996)
Teiephones ■ mobiie cellular: 54,640 (1996)
Telephone system:
general assessment: fully automatic domestic
telephone network
domestic: NA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); 3 coaxial submarine cables
Radio broadcast stations: AM 10, FM 13,
shortwave 0 (1998)
Radios: 1.215 million (1997)
Television broadcast stations: 7 (1997)
Televisions: 460,000(1997)
Internet country code: .jm
Internet Service Providers (ISPs): 21 (2000)
Internet users: 60,000 (2000)','2b371b0138f12e081deba4f67fa4d89091d4e2878c2a6bd54966b13e4234db18','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48e34d73d9d7e85277420d8c7990e5b5b534812fa71f149043213e1bfebb91ad',2001,'IS','Iceland','communications',626,'Radio broadcast stations: AM NA, FM NA,
shortwave NA
nofe; there is one radio and meteorological station
(1998)
Internet Service Providers (ISPs): 13 (Jan Mayen
and Svalbard) (2000)','b3a9223d69839d20806db2bd823f7cb3f8aa0553e1a4d7ef3a1140cd5a653d68','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63165ee8371befdbfe717c00133c270f45dc975903b1dbf8bd0bebf3a97b91a8',2001,'NO','Norway','communications',633,'Telephones - main lines in use: 60.381 million
(1997)
Telephones - mobile cellular: 63.88 million (2000)
Telephone system:
general assessment: excellent domestic and
international service
domestic: high level of modern technology and
excellent service of every kind
International: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 1ndian Ocean), 1 1ntersputnik
(Indian Ocean region), and 1 1nmarsat (Pacific and
Indian Ocean regions); submarine cables to China,
Philippines, Russia, and US (via Guam) (1999)
Radio broadcast stations: AM 190, FM 88,
shortwave 24 (1999)
Radios: 120.5 million (1997)
Television broadcast stations: 7,108 (plus 441
repeaters: note - in addition, US Forces are served by
3 TV stations and 2 TV cable services) (1999)
Televisions: 86.5 million (1997)
Internet country code: .jp
Internet Service Providers (ISPs): 73 (2000)
Internet users: 27.06 million (2000)
Telephones - main lines in use: 2.735 million
(1998)
Telephones ■ mobile cellular: 2,080,408 (1998)
Telephone system:
general assessment: modern in all respects; one of
the most advanced telecommunications networks in
Europe
domestic: Norway has a domestic satellite system;
moreover the prevalence of rural areas encourages
the wide use of cellular mobile systems instead of
fixed wire systems
international: 2 buried coaxial cable systems; 4 coaxial
submarine cables; satellite earth stations - NA Eutelsat,
NA Intelsat (Atlantic Ocean), and 1 1nmarsat (Atlantic
and Indian Ocean regions); note ■ Norway shares the
Inmarsat earth station with the other Nordic countries
(Denmark, Finland, Iceland, and Sweden) (1999)
Radio broadcast stations: AM 5, FM at least 650,
shortwave 1 (1998)
Radios: 4.03 million (1997)
Television broadcast stations: 360 (plus 2,729
repeaters) (1995)
Televisions: 2.03 million (1997)
Internet country code: .no
Internet Service Providers (ISPs): 1 3 (2000)
Internet users: 2.36 million (October 2000)
Telephones - main lines In use: 201,000 (1997)
Telephones - mobile cellular: 59,822 (1997)
Telephone system:
general assessment: modern system consisting of
open wire, microwave, and radiotelephone
communication stations; limited coaxial cable
domestic: open wire, microwave, radiotelephone
communications, and a domestic satellite system with
8 earth stations
/ntemaf/ona/; satellite earth stations - 2 Intelsat
(Indian Ocean) and 1 Arabsat
Radio broadcast stations: AM 3, FM 9,
shortwave 2 (1999)
Radios: 1,4 million (1997)
Television broadcast stations: 13 (plus 25
low-power repeaters) (1999)
Televisions: 1.6 million (1997)
Internet country code: .om
Internet Service Providers (ISPs): 1 (2000)
Internet users: 50,000 (2000)
Telephones - main lines In use: 2.861 million
(March 1999)
Telephones - mobile cellular: 158,000 (1998)
Telephone system:
general assessment: the domestic system is
mediocre, but improving; service is adequate for
government and business use, in part because major
businesses have established their own private
systems; since 1988, the government has promoted
Investment in the national telecommunications system
on a priority basis, significantly increasing network
capacity; despite major improvements in trunk and
urban systems, telecommunication services are still not
readily available to the majority of the rural population
domestic: microwave radio relay, coaxial cable,
fiber-optic cable, cellular, and satellite networks
international: sateWWe earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean); 3 operational
international gateway exchanges (1 at Karachi and 2
at Islamabad); microwave radio relay to neighboring
countries (1999)
Radio broadcast stations: AM 27, FM 1 ,
shortwave 21 (1998)
Radios: 13.5 million (1997)
Television broadcast stations: 22 (plus seven
low-power repeaters) (1997)
Televisions: 3.1 million (1997)
Internet country code: .pk
Internet Service Providers (ISPs): 30 (2000)
Internet users: 1 .2 million (2000)
Telephones - main lines In use: 1 ,500 (1 988)
Telephones - mobile cellular: 0 (1988)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station ■ 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1, FM 0,
shortwave 1 (1998)
Radios: 12,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 1 1 ,000 (1 997)
Internet country code: .pw
Internet Service Providers (ISPs): NA','25079f3aba03b5c2899e3db68802c48a29431d7618b6c7229d01b232a39ef5aa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f496d5e3434e264f1a5c5d18c5de104515cbdf1b44afb19155db8719eef42c5',2001,'JO','Jordan','communications',641,'Telephones - main lines In use; 403,000 (1997)
Telephones - mobile cellular: 1 1 ,500 (1 995)
Telephone system;
genera/ assessment; service has improved recently
with the increased use of digital switching equipment,
but better access to the telephone system is needed
in the rural areas and easier access to pay telephones
is needed by the urban public
domestic: microwave radio relay transmission and
coaxial and fiber-optic cable are employed on trunk
lines; considerable use is made of mobile cellular
systems; Internet service is available
international: satellite earth stations - 3 Intelsat, 1
Arabsat, and 29 land and maritime Inmarsat
terminals; fiber-optic cable to Saudi Arabia and
microwave radio relay link with Egypt and Syria;
connection to international submarine cable FLAG
(Fiber-Optic Link Around the Globe); participant in
MEDARABTEL; international links total about 4,000
Radio broadcast stations: AM 6, FM 5,
shortwave 1 (1999)
Radios: 1.66 million (1997)
Television broadcast stations: 20 (plus 96
repeaters) (1995)
Televisions: 500,000(1997)
Internet country code: .jo
Internet Service Providers (ISPs): 5 (2000)
Internet users: 87,500 (2000)','b3c40679838bf95e580e0f7fce2d4aed0d1dbfe9946b49556e7b71990d5ea574','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6919ace21f724452482928f33a9e3b915ecbd7419114a75bbfb4ede80d372cd',2001,'KZ','Kazakhstan','communications',650,'Telephones • main lines in use: 1 .818 million
(1997)
Telephones - mobile cellular: 1 1 ,202 (1 997)
Telephone system:
general assessment: service is poor; equipment
antiquated
domestic: intercity by landline and microwave radio
relay; mobile cellular systems are available in most of
international: international traffic with other former
Soviet republics and China carried by iandline and
microwave radio relay; with other countries by satellite
and by the Trans- Asia-Eu rope (TAE) fiber-optic cable;
satellite earth stations - 2 Intelsat
Radio broadcast stations: AM 60, FM 17,
shortwave 9 (1998)
Radios: 6.47 million (1997)
Television broadcast stations: 12 (plus nine
repeaters) (1998)
Televisions; 3.88 million (1997)
Internet country code: .kz
Internet Service Providers (ISPs): NA
Internet users: 70,000 (2000)','dd1c46d8c0890ac724695a2fb3abac0f6d3a7e69a2782c5d114d7781bb2b9b7c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f0e3fcd566a05e5cb98556a7e61f2b6220f2e972f01d0e4c2f038c8a7c5b446',2001,'KE','Kenya','communications',659,'Telephones - main lines in use: 290,000 (1998)
Telephones - mobile cellular: 5,345 (1997)
Telephone system:
general assessment: unreliable; little attempt to
modernize except for service to business
cfomesf/c; trunks are primarily microwave radio relay;
business data commonly transferred by a very small
aperture terminal (VSAT) system
/nfemaf/ona/; satellite earth stations - 4 Intelsat
Radio broadcast stations: AM 24, FM 8,
shortwave 6 (1999)
Radios: 3.07 million (1997)
Television broadcast stations: 8 (1997)
Televisions: 730,000 (1997)
Internet country code: .ke
Internet Service Providers (ISPs): 5 (2000)
Internet users: 45,000(1999)','35da5482f9d4e27a95192367ef863740b29597e76fcdd03f7b3fec2f215b8fb7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dde0b0e6dc5a3f52000240baa871352baf4054adfd89958ef3ca5e2df43febe0',2001,'KG','Kyrgyzstan','communications',675,'Telephones - main lines in use: 351 ,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: poorly developed; about
100,000 unsatisfied applications for household
telephones
domestic: principally microwave radio relay; one
cellular provider, probably limited to Bishkek region
international: connections with other CIS countries by
landline or microwave radio relay and with other
countries by leased connections with Moscow
international gateway switch and by satellite; satellite
earth stations - 1 Intersputnik and 1 Intelsat;
connected internationally by the Trans-Asia-Europe
(TAE) fiber-optic line
Radio broadcast stations: AM 12 (plus 10 repeater
stations), FM 14, shortwave 2 (1998)
Radios: 520,000(1997)
Television broadcast stations: NA (repeater
stations throughout the country relay programs from
Russia, Uzbekistan, Kazakhstan, and Turkey) (1997)
Televisions: 210,000(1997)
Internet country code: .kg
Internet Service Providers (ISPs): NA
Internet users: 10,000(2000)
Telephones - main lines in use: 25,000 (1997)
Telephones - mobile cellular: 4,915 (1997)
Telephone system:
genera! assessment: service to general public is poor
but improving, with over 20,000 telephones currently
in service and an additional 48,000 expected by 2001 ;
the government relies on a radiotelephone network to
communicate with remote areas
domestic: radiotelephone communications
international: satellite earth station - 1 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM 12, FM 1,
shortwave 4 (1998)
Radios: 730,000(1997)
Television broadcast stations: 4 (1999)
Televisions: 52,000(1997)
Internet country code: .la
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000 (2000)','336e2980fc65c4e22823333f618d588ee3f92d06f22e1a869e84a0944d11cc1b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('415e835b25f0fd754209ae31cf9142335eeae81d0f51f94237e505aa26389db2',2001,'LV','Latvia','communications',684,'Telephones - main lines in use: 748,000 (1997)
Telephones ■ mobile cellular: 77,100 (1997)
Telephone system:
general assessment: inadequate, but is being
modernized to provide an international capability
independent of the Moscow International switch; more
facilities are being installed for individual use
domestic: expansion underway in intercity trunk line
connections, rural exchanges, and mobile systems;
still many unsatisfied subscriber applications
international: international connections are now
available via cable and a satellite earth station at Riga,
enabling direct connections for most calls (1998)
Radio broadcast stations: AM 8, FM 56,
shortwave 1 (1998)
Radios: 1.76 million (1997)
Television broadcast stations: 44 (plus 31
repeaters) (1995)
Televisions: 1.22 million (1997)
Internet country code: .Iv
Internet Service Providers (ISPs): 42 (2000)
Internet users: 234,000 (2000)
286
Latvia (continued)','6e3e75a198c6ee5947733eb7bb0ec1cd8491fc0bb4770680d22213edfc543d6f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e91b83d913a5136ea8f2a4d9c395892fc7fe1cc577d374ad83c7b0baa6c7fb0',2001,'LB','Lebanon','communications',693,'Telephones - main lines in use: 700,000 (1999)
Telephones - mobile cellular: 580,000 (1999)
Telephone system:
general assessment: telecommunications system
severely damaged by civil war; rebuilding well
underway
domestic: primarily microwave radio relay and cable
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean) (erratic
operations); coaxial cable to Syria; microwave radio
relay to Syria but inoperable beyond Syria to Jordan;
3 submarine coaxial cables
Radio broadcast stations: AM 20, FM 22,
shortwave 4 (1998)
Radios: 2.85 million (1997)
Television broadcast stations: 15 (plus 5
repeaters) (1995)
Televisions: 1.18 million (1 997)
Internet country code: .lb
Internet Service Providers (ISPs): 22 (2000)
Internet users: 227,500 (2000)','5bb6b66e4f8707dc339e256e8ae053fe8997cc60f3d4c3a008a9a1651f7424b5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f25cef1f9ebb41d09901e0e755b0abadd1f2f1a1994635cfe5265a71fcbffb6',2001,'ZA','South Africa','communications',700,'Telephones - main lines In use: 20,000 (1997)
Telephones - mobile cellular: 1 ,262 (1 996)
Telephone system:
general assessment: rudimentary system
domestic: consists of a few landlines, a small
microwave radio relay system, and a minor
radiotelephone communication system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM1,FM2,
shortwave 1 (1998)
Radios: 104,000(1997)
Television broadcast stations: 1 (2000)
Televisions: 54,000(1997)
Internet country code: .Is
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,000 (2000)
Telephones - main lines in use: 5.075 million
(1999)
Telephones - mobile cellular: over 2,000,000
(1999)
Telephone system:
general assessment: the system is the best
developed and most modern in Africa
domestic: consists of carrier-equipped open-wire
lines, coaxial cables, microwave radio relay links,
fiber-optic cable, radiotelephone communication
stations, and wireless local loops; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria
/ntemaf/bna/; 2 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean)
Radio broadcast stations: AM 14, FM 347 (plus
243 repeaters), shortwave 1 (1998)
Radios: 13.75 million (1997)
Television broadcast stations: 556 (plus 144
network repeaters) (1997)
Televisions; 5.2 million (1997)
Internet country code: .za
Internet Service Providers (ISPs): 44 (2000)
Internet users: 1 .82 million (2000)
Telephone system:
general assessment: NA
domestic: NA
international: coastal radiotelephone station at
Grytviken
Radio broadcast stations: none
Television broadcast stations: 0 (1997)
Internet country code: .gs','71fe85c4aa714e25b26652c0b990290d9f5681ac31a747afafd1d9a21fb22cf3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2134fe8da1fe4434afa577a1ab35728f542c3b144a07a00d3196eedb2b615021',2001,'LR','Liberia','communications',709,'Telephones - main lines in use: 6,000 (1997)
Telephones - mobile cellular: 0 (1995)
Telephone system:
general assessment: telephone and telegraph service
via microwave radio relay network; main center is
Monrovia
domestic: NA
/nfemaf/ona/; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 0, FM 6,
shortwave 4 (1999)
Radios: 790,000(1997)
Television broadcast stations: 2 (plus four
low-power repeaters) (2000)
Televisions: 70,000(1997)
Internet country code: .Ir
Internet Service Providers (ISPs): 1 (2000)
Internet users: 300 (2000)','d8b53a4f600aa0183e20d076f4b4d9342b56b2e66d6e8db7d789b24e7de9bcef','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('917d3b9e5b2df1c2af61acc48e73e32ed90221210968f21e2b9ab891a2342160',2001,'LY','Libya','communications',717,'Telephones - main lines in use: 380,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment telecommunications system is
being modernized; mobile cellular telephone system
became operational in 1996
domestic: microwave radio relay, coaxial cable,
cellular, tropospheric scatter, and a domestic satellite
system with 14 earth stations
international: satellite earth stations - 4 Intelsat, NA
Arabsat, and NA Intersputnik; submarine cables to
France and Italy; microwave radio relay to Tunisia and
Egypt; tropospheric scatter to Greece; participant in
Medarabtel (1999)
Radio broadcast stations: AM 17, FM 4,
shortwave 3 (1998)
Radios: 1.35 million (1997)
Television broadcast stations: 12 (plus one
low-power repeater) (1998)
Televisions: 730,000(1997)
Internet country code: .ly
Internet Service Providers (ISPs): 1 (2000)
Internet users: 7,500 (2000)','7a4f32f5ebb54feb50c8e3fe52d2ce62dee99940c07b63e0d7f1bdf0e92baece','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9bf828be64f03002e1df0bed3bb38f07388f781342fe503765b27360b332c29',2001,'LI','Liechtenstein','communications',726,'Telephones - main lines in use: 20,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: automatic telephone system
domestic: NA
international: linked to Swiss networks by cable and
microwave radio relay
Radio broadcast stations: AM 0, FM 4,
shortwave 0 (1998)
Radios: 21,000(1997)
Television broadcast stations: NA (linked to Swiss
networks) (1997)
Televisions: 12,000(1997)
Internet country code: .li
Internet Service Providers (ISPs): 44
(Liechtenstein and Switzerland) (2000)
Internet users: NA','dc9dcc6b44e451cbf42ac0616c0feb98f1b0968ce852a6bdf33a6480f6dc9560','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5694c638e69c3ad75372a4e1e0534d5dd06f725a9e34aee08f0fea731bfc1d1',2001,'CH','Switzerland','communications',731,'Telephones - main lines in use; 1 .048 million
(1997)
Telephones - mobile cellular: 297,500 (November
1998)
Telephone system:
general assessment: inadequate, but is being
modernized to provide an improved international
capability and better residential access
domestic: a national, fiber-optic cable, interurban,
trunk system is nearing completion; rural exchanges
are being improved and expanded; mobile cellular
systems are being installed; access to the Internet is
available; still many unsatisfied telephone subscriber
applications
international: landline connections to Latvia and
Poland; major international connections to Denmark,
Sweden, and Norway by submarine cable for further
transmission by satellite
Radio broadcast stations: AM 3, FM 1 12,
shortwave 1 (1998)
Radios: 1.9 million (1997)
Television broadcast stations; 20 (plus 30
repeaters) (1995)
Televisions: 1.7 million (1997)
Internet country code: .It
Internet Service Providers (ISPs): 14 (2000)
Internet users: 225,000 (2000)','83206d9b31f397d3a12c27e59ef10fd57e8c3bf5ad8f1210a761c1127a8b0051','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53adfb1eaa8d5c56a5b96499cba91cb1ccd86397976cc8f96b7459d7f2283962',2001,'MG','Madagascar','communications',740,'Telephones - main lines in use: 43,000 (1997)
Telephones - mobile cellular: 4,000 (1997)
Telephone system:
general assessment: system is above average for the
region
domestic: o^pen-me lines, coaxial cables, microwave
radio relay, and tropospheric scatter links
international: submarine cable to Bahrain; satellite
earth stations - 1 1ntelsat (Indian Ocean) and 1
Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 2 (plus 8 repeater
stations), FM 7, shortwave 5 (1998)
Radios: 3.05 million (1997)
Television broadcast stations: 1 (plus 36
repeaters) (1997)
Televisions: 325,000 (1997)
Internet country code: .mg
Internet Service Providers (ISPs): 2 (2000)
Internet users: 8,000 (2000)','26cc3d6e0c57b7c7ee0bc97db49f6117f14b5e54d0e736a15fc74bfecd6b5f8e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91946e30911f253d7085060ce13228ab9832e0cfa8be0f0fc7192bb4603a40e4',2001,'PH','Philippines','communications',750,'Telephones - main lines in use: 37,000 (1997)
Telephones - mobile cellular: 7,000 (1 997)
Telephone system:
general assessment: NA
domestic: fair system of open-wire lines, microwave
radio relay links, and radiotelephone communications
stations
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 9, FM 4 (plus 15
repeater stations), shortwave 3 (1998)
Radios: 2.6 million (1997)
Television broadcast stations: 1 (1999)
Televisions: 0 (1999)
Internet country code: .mw
Internet Service Providers (ISPs): 8 (2001)
Internet users: 10,000(2000)
Telephones - main lines in use: 4.5 million (1999)
Telephones - mobile cellular: 2.698 million (1999)
Telephone system:
general assessment: modern system; international
service excellent
domestic: good intercity service provided on
Peninsular Malaysia mainly by microwave radio relay;
adequate intercity microwave radio relay network
between Sabah and Sarawak via Brunei; domestic
satellite system with 2 earth stations
international: submarine cables to India, Hong Kong,
and Singapore; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean) (2001)
Radio broadcast stations: AM 56, FM 31 (plus 13
repeater stations), shortwave 5 (1999)
Radios: 10.9 million (1999)
Television broadcast stations: 27 (plus 15
high-power repeaters) (1999)
Televisions: 10.8 million (1999)
Internet country code: .my
Internet Service Providers (ISPs): 7 (2000)
Internet users: 1 .5 million (2000)
Telephones - main lines in use: 1 .9 million (1 997)
Telephones - mobile cellular: 1 .959 million (1 998)
Telephone system:
general assessment: good international
radiotelephone and submarine cable services;
domestic and interisland service adequate
domestic: domestic satellite system with 1 1 earth
stations
international: 9 international gateways; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Pacific
Ocean); submarine cables to Hong Kong, Guam,
Singapore, Taiwan, and Japan
Radio broadcast stations: AM 366, FM 290,
shortwave 3 (1999)
Radios: 11.5 million (1997)
Television broadcast stations: 31 (1997)
Televisions: 3.7 million (1997)
Internet country code: .ph
Internet Service Providers (ISPs): 33 (2000)
Internet users: 500,000 (2000)','b8a4b2190ebdb2bf526783f6804c73da4a0c24fb535d185f3cb488d55fc55318','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12af0c1855c308c6efbd125fb23c3d1fd544504705e13b776b31e08ec64881d8',2001,'MV','Maldives','communications',763,'Telephones - main lines in use: 21 ,000 (1999)
Telephones - mobile cellular: 1 ,290 (1 997)
Telephone system:
general assessment: minimal domestic and
international facilities
domestic: interatoll communication through
microwave links; all inhabited islands are connected
with telephone and fax service
international: satellite earth station - 3 Intelsat (Indian
Ocean)
Radio broadcast stations: AM1,FM1,
shortwave 1 (1998)
Radios: 35,000 (1999)
Television broadcast stations: 1 (1997)
Televisions: 10,000 (1999)
Internet country code: .mv
Internet Service Providers (ISPs): 1 (2000)
Internet users; 2,000 (2000)','7945799597b988b9816760b49a7ad19e3cf8103ff03044b5a5059bfb89e43dbe','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('062c460ddff4be6db88bd94de8b5c130590205d7e7ad96ef0734ea06f45ced36',2001,'ML','Mali','communications',771,'Telephones - main lines in use: 23,000 (1997)
Telephones - mobile cellular: 2,842 (1997)
Telephone system:
general assessment: domestic system poor but
improving; provides only minimal service
domestic: network consists of microwave radio relay,
open wire, and radiotelephone communications
stations; expansion of microwave radio relay in
progress
/ntemaf/ona/; satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean)
Radio broadcast stations: AM 1, FM 14,
shortwave 7 (1998)
Radios: 570,000 (1997)
Television broadcast stations: 1 (plus two
repeaters) (1997)
Televisions: 45,000(1997)
Internet country code: .ml
Internet Service Providers (ISPs): 1 (2000)
Internet users: 10,000(2000)','65630a4e5b128d0061b61ba407afbd04971b928b801b8cc0dbdd9f0de22b449d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2ff83d8dd42c3ce97e70f659d0e39e61e73a0efdd2b35d215f8747b29343c2',2001,'MT','Malta','communications',779,'Telephones - main lines in use: 187,000 (1997)
Telephones - mobile cellular: 17,691 (1997)
Telephone system:
general assessment: automatic system satisfies
normal requirements
domestic: submarine cable and microwave radio relay
between islands
international: 2 submarine cables; satellite earth
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 18,
shortwave 6 (1999)
Radios: 255,000(1997)
Television broadcast stations: 6 (2000)
Televisions: 280,000(1997)
Internet country code: .mt
Internet Service Providers (ISPs): 2 (2000)
Internet users: 40,000 (2000)
Telephones - main lines in use: 51 ,000 (1999)
Telephones - mobile cellular: NA
Telephone system:
general assessment: N A
domestic: landline, telefax, mobile cellular telephone
system
/nfemaf/ona/; fiber-optic cable, microwave radio relay,
satellite earth station, submarine cable
322
Man, Isle of (continued)
Radio broadcast stations: AM 1, FM 1,
shortwave 0(1998)
Radios: NA
Television broadcast stations: 0 (receives
broadcasts from the UK and satellite) (1999)
Televisions: 27,490(1999)
Internet country code: .im
Internet Service Providers (ISPs): NA
Internet users: NA','30ab29437739e922ea398d59632a16405bdb6c3dee579d9c7d3564184fbcb14b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5170b4eefcb4ca05d8416a7b4e315662fabe823ff127acfc0c3fc0a5ab998299',2001,'MH','Marshall Islands','communications',787,'Telephones - main lines In use: 3,000 (1996)
Telephones - mobile cellular: 365 (1 996)
Telephone system:
general assessment: telex services
domestic: Majuro Atoll and Ebeye and Kwajalein
islands have regular, seven-digit, direct-dial
telephones; other islands interconnected by
shortwave radiotelephone (used mostly for
government purposes)
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); US Government satellite
communications system on Kwajalein
Radio broadcast stations: AM 3, FM 4,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 3 (of which two are
US military stations) (1997)
Televisions: NA
Internet country code: .mh
Internet Service Providers (ISPs): 1 (2000)
Internet users: 500 (2000)','53ea091893bae223fb5cbf52753118804928ece65f03f9c422fe61f874f7a1a2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eb2d51384b8b1ecad4b750edaa93a546ab61aa399c8925863225d807726f32f',2001,'MR','Mauritania','communications',799,'Telephones - main lines In use: 26,000 (2000)
Telephones - mobile cellular: NA
Telephone system:
general assessment: limited system of cable and
open-wire lines, minor microwave radio relay links,
and radiotelephone communications stations
(improvements being made)
domestic: mostly cable and open-wire lines; a recently
completed domestic satellite telecommunications
system links Nouakchott with regional capitals
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 2 Arabsat
Radio broadcast stations: AM 1 , FM 2,
shortwave 1 (1998)
Radios: 360,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 87,000(1998)
Internet country code: .mr
Internet Service Providers (ISPs): 5 (2000)
Internet users: 3,500 (2000)','89ddc9b38e6f00af3b3eb5a80843b2b7a483774fe157d682c52c7e6d09614a66','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ee2123719229586f0662bf4d9b17d373f9ae8692072fcc5f59afbc152defa80',2001,'MU','Mauritius','communications',808,'Telephones - main lines in use: 223,000 (1997)
Telephones - mobile cellular: 37,000 (1997)
Telephone system:
general assessment: small system with good service
domestic: primarily microwave radio relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean): new microwave link to Reunion: HF
radiotelephone links to several countries
Radio broadcast stations: AM 5, FM 9,
shortwave 2 (1998)
Radios: 420,000(1997)
Television broadcast stations: 2 (plus 1 1
repeaters) (1997)
Televisions: 258,000(1997)
Internet country code: .mu
Internet Service Providers (ISPs): 2 (2000)
Internet users: 55,000 (2000)','af7299f58d5178a5667062c28ab733bb0789f3a96e54781fc73d1fa7ff648fb8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e95cada7e6652815b78473d48c514935c75893fca81617eae821f2140f12e7d',2001,'YT','Mayotte','communications',817,'Telephones - main lines in use: 9,314 (1997)
Telephones - mobile cellular; 0 (2000)
Telephone system:
genera/ assessment; small system administered by
French Department of Posts and Telecommunications
domestic: NA
332
Mayotte (continued)
international: microwave radio relay and HF
radiotelephone communications to Comoros and
other international connections
Radio broadcast stations: AM 1, FM 4,
shortwave 0(1998)
Radios: NA
Television broadcast stations: 3 (1997)
Televisions; 3,500(1994)
Internet country code: .yt
Internet Service Providers (ISPs): NA
Internet users: NA','479a0858cafdfc7e2e7839c61457d4dddcc51c3e64d27209b0dad98333773ce3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('224f9aab8f3f85ef5b846490b6517d5736fa196ea2d34b5d739b740b01d0407e',2001,'US','United States','communications',827,'Telephones - main lines in use: 9.6 million (1998)
Telephones - mobile cellular: 2.02 million (1 998)
Telephone system:
general assessment: low telephone density with
about 11 main lines per 100 persons; privatized in
December 1990; the opening to competition in
January 1997 has brightened prospects for
development
domestic: adequate telephone service for business
and government, but the population is poorly served;
domestic satellite system with 120 earth stations;
extensive microwave radio relay network;
considerable use of fiber-optic cable, coaxial cable,
and mobile cellular service
international: satellite earth stations - 32 Intelsat, 2
Solidaridad (giving Mexico improved access to South
America, Central America, and much of the US as well
as enhancing domestic communications), numerous
Inmarsat mobile earth stations; linked to Central
American Microwave System of trunk connections;
high capacity Columbus-2 fiber-optic submarine cable
with access to the US, Virgin Islands, Canary Islands,
Morocco, Spain, and Italy (1997)
Radio broadcast stations: AM 865, FM about 500,
shortwave 13 (1999)
Radios: 31 million (1997)
Television broadcast stations: 236 (plus
repeaters) (1997)
Televisions: 25.6 million (1997)
Internet country code: .mx
Internet Service Providers (ISPs): 51 (2000)
Internet users: 2.5 million (2000)
Telephones ■ main lines In use: 194 million (1997)
Telephones - mobile cellular: 69.209 million
(1998)
Telephone system:
general assessment: a very large, technologically
advanced, multipurpose communications system
domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and domestic
satellites carries every form of telephone traffic; a
rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: 24 ocean cable systems in use; satellite
earth stations - 61 Intelsat (45 Atlantic Ocean and 16
Pacific Ocean), 5 Intersputnik (Atlantic Ocean region),
and 4 Inmarsat (Pacific and Atlantic Ocean regions)
(2000)
Radio broadcast stations: AM 4,762, FM 5,542,
shortwave 18 (1998)
Radios: 575 million (1997)
Television broadcast stations: more than 1 ,500
(including nearly 1 ,000 stations affiliated with the five
major networks - NBC, ABC, CBS, FOX, and PBS; in
addition, there are about 9,000 cable TV systems)
(1997)
Televisions: 219 million (1997)
Internet country code: .us
Internet Service Providers (ISPs): 7,800
(2000 est.)
Internet users: 148 million (2000)','6c532a4038f81419fda71301ca396a7f585d056465359e5b046244036f5008c5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cece263a8a37dd525ff9c6cb8ba925c2636fe515fc30e92b9f38e31ff521d9ba',2001,'MC','Monaco','communications',835,'Telephones - main lines in use: 31,027 (1995)
Telephones - mobile cellular: NA
Telephone system:
general assessment: modern automatic telephone
system
domestic: NA
international: no satellite earth stations; connected by
cable into the French communications system
Radio broadcast stations: AM 1 , FM NA,
shortwave 8 (1998)
Radios: 34,000(1997)
Television broadcast stations: 5 (1998)
Televisions: 25,000(1997)
Internet country code: .me
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','95f3a4caf54e3e0ffe4b528bf67217e531deea6373d2d1103a4d5cd378f07fb7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ad58ff24a1c186f36917903a149ae4f4f23f1bea2efb0ee666f100b6f0bd9b0',2001,'MS','Montserrat','communications',842,'Telephones - main iines in use: 4,000 (1997)
Telephones - mobile cellular: 70 (1994)
Telephone system:
genera! assessment: N A
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 2,
shortwave 0(1998)
Radios: 7,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 3,000(1997)
Internet country code: .ms
Internet Service Providers (ISPs): 17 (2000)
Internet users: NA','f144266b75ad2876aef04b98a67e0240753d8fb8cec7f2e7d8300e07e2a93dc9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a05fbf5e71c64e20a3849150625c16edb1d3f14a7fcbd6fe5852c9c5cc332f90',2001,'NA','Namibia','communications',852,'Telephones - main lines in use: 100,848 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: good system; about 6
telephones for each 100 persons
domestic: good urban services; fair rural service;
microwave radio relay links major towns; connections
to other populated places are by open wire; 100%
digital
international: fiber-optic cable to South Africa,
microwave radio relay link to Botswana, direct links to
other neighboring countries; connected to Africa ONE
and South African Far East (SAFE) submarine cables
through South Africa; satellite earth stations - 4
Intelsat
Radio broadcast stations; AM 2, FM 34,
shortwave 5 (1998)
Radios: 232,000(1997)
Television broadcast stations: 8 (plus about 20
low-power repeaters) (1997)
Televisions: 60,000(1997)
Internet country code: .na
Internet Service Providers (ISPs): 2 (2000)
Internet users: 9,000(1999)','8b506c3898cbc170c08466040c3a122436d25191741922a8c93e7cf4a6d4a721','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b95e64a71319e878f24d1237e2338cbb5a8d7936775c4733b56d13fb4183b927',2001,'NR','Nauru','communications',861,'Telephones ■ main lines in use: 2,000 (1996)
Telephones - mobile cellular: 450 (1 994)
Telephone system:
genera! assessment: adequate local and international
radiotelephone communications provided via
Australian facilities
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM1,FM0,
shortwave 0 (1 998)
Radios: 7,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 500(1997)
Internet country code: .nr
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','8a56634bfee3193c4b80c4d52499db09465a7d038a8496ae9f1715f6904564a5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e2a63ed8045bd873d66e54c47b02465f92b6ff1cbad01e9f4cb6776ae26a63d',2001,'NP','Nepal','communications',868,'Telephones - main lines In use: 236,816 (January
2000)
Telephones - mobile cellular: NA
Telephone system:
general assessment: poor telephone and telegraph
service; fair radiotelephone communication service
and mobile cellular telephone network
domestic: NA
international: radiotelephone communications;
microwave landline to India; satellite earth station - 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 6, FM 5,
shortwave 1 (January 2000)
Radios: 840,000 (1997)
Television broadcast stations: 1 (plus 9 repeaters)
(1998)
Televisions: 130,000(1997)
Internet country code: .np
Internet Service Providers (ISPs): 6 (2000)
Internet users: 35,000 (2000)','b55f051425bc0bb2c655a28977e90225cfcd0d9cebea28b808c3f0387a185f6a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36a7622263839a2ca1f944d3fa29f8cd4ffa947172a1187307b04ed9255bab2a',2001,'NL','Netherlands','communications',877,'Telephones - main lines in use: 76,000 (1995)
Telephones - mobile cellular: 13,977 (1996)
Telephone system:
general assessment: generally adequate facilities
domestic: extensive interisland microwave radio relay
links
international: submarine cables - 2; satellite earth
stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 4,
shortwave 0 (1998)
Radios: 217,000(1997)
Television broadcast stations: 3 (there is also a
cable service which supplies programs received from
various US satellite networks and two Venezuelan
channels) (1997)
Televisions: 69,000(1997)
Internet country code: .an
Internet Service Providers (ISPs): 6
Internet users: 2,000 (2000)','b73516772b65d5a356301c1824c1459afdefc3a05631c33d413348fed086c07f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a595c89bb0a9170559062d509fc6c57e63f9a7fcdcc98bc4f5ca57e644e88eee',2001,'NZ','New Zealand','communications',886,'Telephones - main lines in use: 1 .84 million (1 997)
Telephones - mobile cellular: 588,000 (1998)
Telephone system:
general assessment: excellent domestic and
international systems
domestic: NA
international: submarine cables to Australia and Fiji;
satellite earth stations - 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 124, FM 290,
shortwave 4 (1998)
Radios: 3.75 million (1997)
Television broadcast stations: 41 (plus 52
medium-power repeaters and over 650 low-power
repeaters) (1997)
Televisions: 1.926 million (1997)
Internet country code: .nz
Internet Service Providers (ISPs): 36 (2000)
Internet users: 1.34 million (2000)
Telephones - main lines in use: 8,000 (1996)
Telephones - mobile cellular: 302 (1996)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 2,
shortwave 1 (2001)
Radios: 61,000(1997)
Television broadcast stations: 1 (2001)
Televisions: 2,000(1997)
Internet country code: .to
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1 ,000 (2000)
Telephones - main lines in use: 243,000 (1 997)
Telephones - mobile cellular: 17,411 (1997)
Telephone system:
general assessment: excellent international service;
good local service
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); tropospheric scatter to Barbados
and Guyana
Radio broadcast stations: AM 2, FM 12,
shortwave 0 (1998)
Radios: 680,000 (1997)
Television broadcast stations: 4 (1997)
Televisions: 425,000(1997)
Internet country code: .tt
Internet Service Providers (ISPs): 17 (2000)
Internet users: 30,000 (2000)
Communications - note: important meteorological
station
Telephones - main lines In use: 1,125 (1994)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: N A
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 0,
shortwave 0 (2000)
Radios: NA
Television broadcast stations: 2 (2000)
Televisions: NA
Internet country code: .wf
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','3ed16ed65552c785ac3baa46f25a6108af7b15350c1c68418993dd630d511254','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbb4f19257694b2c455f98895132a9295c3d694ee43497d4e7ede645d450969b',2001,'NI','Nicaragua','communications',890,'Telephones - main lines in use: 140,000 (1996)
Telephones - mobile cellular: 7,911 (1997)
Telephone system:
genera/ assessmenf; inadequate system being
upgraded by foreign investment
domestic: low-capacity microwave radio relay and
wire system being expanded; connected to Central
American Microwave System
international: sateWWe earth stations - 1 1ntersputnik
(Atlantic Ocean region) and 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 63, FM 32,
shortwave 1 (1998)
Radios: 1.24 million (1997)
Television broadcast stations: 3 (plus seven
low-power repeaters) (1997)
Televisions: 320,000(1997)
Internet country code: .ni
Internet Service Providers (ISPs): 3 (2000)
Internet users: 20,000 (2000)','8e867a27975ee865ef1bcaba75ae2136ed42bf5e8f71c15a9ea17f51454a5efb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77847d6c625ae069b9f74cae51b9ea557bbab33e5ca339d9d2ca615bec98ba08',2001,'NE','Niger','communications',898,'Telephones - main lines in use: 16,000 (1997)
Teiephones - mobile cellular: 1 3,000 (1 995)
Telephone system:
general assessment: small system of wire, radio
telephone communications, and microwave radio
relay links concentrated in the southwestern area of
domestic: wire, radiotelephone communications, and
microwave radio relay; domestic satellite system with
3 earth stations and 1 planned
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean)
Radio broadcast stations: AM 5, FM 5,
shortwave 4 (1998)
Radios: 680,000(1997)
Television broadcast stations: 10 (plus seven
low-power repeaters) (1997)
Televisions: 125,000(1997)
Internet country code: .ne
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000 (2000)
Telephones - main lines in use: 500,000 (2000)
Telephones - mobile cellular: 26,700 (1997)
Telephone system:
general assessment: an inadequate system, further
limited by poor maintenance; major expansion is
required and a start has been made
domestic: intercity traffic is carried by coaxial cable,
microwave radio relay, a domestic communications
satellite system with 19 earth stations, and a coastal
submarine cable; mobile cellular facilities and the
Internet are available
international: satellite earth stations - 3 Intelsat (2
Atlantic Ocean and 1 Indian Ocean); coaxial
submarine cable SAFE (South African Far East)
Radio broadcast stations: AM 82, FM 35,
shortwave 11 (1998)
Radios: 23.5 million (1997)
Television broadcast stations; 2
government-controlled; note - in addition, in 1993, 14
licenses to operate private television stations were
granted (1999)
Televisions: 6.9 million (1997)
Internet country code: .ng
Internet Service Providers (ISPs): 1 1 (2000)
Internet users: 100,000(2000)','edfd0f46ca52f95218478cf05fbae541cbe5d635eb165e90d2ec898bf620e3e8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20eae607edf4b3edc92216be48645ecd7d512aedd18accbfcb2933e6c9eeccef',2001,'MP','Northern Mariana Islands','communications',909,'Telephones - main lines in use: 21 ,000 (1996)
Telephones - mobile cellular: 1 ,200 (1 995)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth stations - 2 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM 2, FM 3,
shortwave 1 (1998)
Radios: NA
Television broadcast stations: 1 (on Saipan and
one station pianned for Rota; in addition, two cable
services on Saipan provide varied programming from
sateilite networks) (1997)
Televisions: NA
Internet country code: .mp
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephone system:
general assessment: satellite communications; 1
DSN circuit off the Overseas Telephone System
(OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM NA,
shortwave NA
note: Armed Forces RadioATelevision Service
(AFRTS) radio service provided by satellite (1998)
Television broadcast stations: 0 (1997)','6d003b404e072250ee5470a8340e1166d2619df20e75a2d85d2fa396b780faff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08e40d2dd287376bf5587ae61ad069e6f2933d972c1e90e2f699cca018d09767',2001,'PA','Panama','communications',918,'Telephones - main lines in use: 396,000 (1997)
Telephones - mobile cellular: 17,000 (1997)
Telephone system:
genera/ assessment: domestic and international
facilities well developed
domestic: NA
International: 1 coaxial submarine cable; satellite
earth stations - 2 Intelsat (Atlantic Ocean); connected
to the Central American Microwave System
Radio broadcast stations: AM 101 , FM 134,
shortwave 0 (1998)
Radios: 815,000(1997)
Television broadcast stations: 38 (including
repeaters) (1998)
Televisions: 510,000(1997)
Internet country code: .pa
Internet Service Providers (ISPs): 6 (2000)
Internet users: 45,000 (2000)','8dd2d0cb80a3caf0d0db70834e17eaeaea800425f2f89419724b6bd7c0c30871','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68f1da8f0bcbea1690747c034f331d170764d5b17ced364a697b06e2d939631d',2001,'AR','Argentina','communications',923,'Telephones - main lines in use: 290,475 (2001)
Telephones - mobile cellular: 510,000 (2001)
Telephone system:
general assessment: meager telephone service;
principal switching center is Asuncion
domestic: ia\\r microwave radio relay network
international: sa\\e\\\\\\\\e earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 46, FM 27,
shortwave 6 (three inactive) (1998)
Radios: 925,000(1997)
Television broadcast stations; 4 (2001)
Televisions; 990,000 (2001)
Internet country code: .py
Internet Service Providers (ISPs): 4 (2000)
Internet users: 20,000 (2000)','0fbd34f25fbfaffbf31cd902d217e4c68f7852cbfc8564b4ec737b7e43124bf7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8bb7b9884c473bc81c23dd73a6bdc925cb4446cf7e1fe8c6e3756dae698954d',2001,'PN','Pitcairn','communications',931,'Telephones - main lines in use: 1 (there are 17
telephones on one party line) (1997)
Telephone system:
general assessment: only party line telephone service
is available for this small, closely related community
domestic: party line service only
international: radiotelephone
Radio broadcast stations: AM 1 , FM 0,
shortwave 0(1 998)
Radios: NA
Television broadcast stations: 0 (1997)
Televisions: NA
Internet country code: .pn
Internet Service Providers (ISPs): NA
Internet users: NA','cfd2cd417682e00ab8ec3a07eb98c1159eccf6dad411a0b276f738f29adc2fd5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4b969e599390379051a619d7bea98404ff383ad666069700ec6ceeb98487b64',2001,'MX','Mexico','communications',939,'Telephones ■ main lines In use: 8.07 million (1 998)
Telephones ■ mobile cellular: 1.78 million (1998)
Telephone system:
general assessment: underdeveloped and outmoded
system; government aimed to have 10 million
telephones in service by 2000; the process of partial
privatization of the state-owned telephone monopoly
has begun; in 1998 there were over 2 million
applicants on the waiting list for telephone service
domestic: cable, open wire, and microwave radio
relay; 3 cellular networks; local exchanges 56.6%
digital
international: satellite earth stations - 2 Intelsat, NA
Eutelsat, 2 Inmarsat (Atlantic and Indian Ocean
regions), and 1 Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 14, FM 777,
shortwave 1 (1998)
Radios: 20.2 million (1997)
Television broadcast stations: 179 (plus 256
repeaters) (September 1995)
Televisions: 13.05 million (1997)
Internet country code: .pi
Internet Service Providers (ISPs); 19 (2000)
Internet users; 2.8 million (2000)','45910639d7e6afd5a8c0ca3bea8690232159cf939a5ce1fb335956172ad249f8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fadf1d924d3d67db89befc2c6a75395d4f155ce04d29cedc004169670bf79f9f',2001,'QA','Qatar','communications',952,'Telephones - main lines in use: 142,000 (1997)
Telephones - mobile cellular: 43,476 (1997)
Telephone system:
general assessment: modern system centered in
Doha
domestic: NA
/ntemaf/ona/; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia and UAE;
submarine cable to Bahrain and UAE; satellite earth
stations - 2 Intelsat (1 Atlantic Qcean and 1 Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 6, FM 5,
shortwave 1 (1998)
Radios: 256,000(1997)
Television broadcast stations: 2 (plus three
repeaters) (1997)
Televisions: 230,000 (1997)
Internet country code: .qa
Internet Service Providers (ISPs): 1 (2000)
Internet users: 45,000 (2000)','c95e2626e1ad342d9c1077890d0a0fb66c5179e1be5cecdee65bfb3ce7b5f9fc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad34baa3e0b57bd6173524494dee7d57e61d9c53076212c2606cc34c0bad781',2001,'UA','Ukraine','communications',961,'Telephones - main lines in use: 3.777 million
(1997)
Telephones - mobile cellular: 645,500 (1999)
Telephone system:
general assessment: poor domestic service, but
improving
domestic: 90% of telephone network is automatic;
trunk network is mostly microwave radio relay, with
some fiber-optic cable; about one-third of exchange
capacity is digital; roughly 3,300 villages have no
service
/ntemaf/ona/; satellite earth station - 1 Intelsat; new
digital, international, direct-dial exchanges operate in
Bucharest; note - Romania is an active participant in
several international telecommunication network
projects (1999)
Radio broadcast stations: AM 40, FM 202,
shortwave 3 (1998)
Radios: 7.2 million (1997)
Television broadcast stations: 48 (plus 392
repeaters) (1995)
Televisions: 5.25 million (1997)
Internet country code: .ro
Internet Service Providers (ISPs): 38 (2000)
Internet users: 600,000 (2000)
420
Romania (continued)
Telephones - main lines in use: 30 million (1998)
Telephones - mobile cellular: 2.5 million (October
2000)
Telephone system:
general assessment: \\he telephone system has
undergone significant changes in the 1 990s: there are
more than 1 ,000 companies licensed to offer
communication services; access to digital lines has
improved, particularly in urban centers; Internet and
e-mail services are improving: Russia has made
progress toward building the telecommunications
infrastructure necessary for a market economy;
however, a large demand for main line service
remains unsatisfied
domestic: cross-country digital trunk lines run from
Saint Petersburg to Khabarovsk, and from Moscow to
Novorossiysk; the telephone systems in 60 regional
capitals have modern digital infrastructures; cellular
services, both analog and digital, are available in
many areas; in rural areas, the telephone services are
still outdated, inadequate, and low density
international: Russia is connected internationally by
three undersea fiber-optic cables; digital switches in
several cities provide more than 50,000 lines for
international calls; satellite earth stations provide
access to Intelsat, Intersputnik, Eutelsat, Inmarsat,
and Orbita systems
Radio broadcast stations: AM 420, FM 447,
shortwave 56 (1998)
Radios: 61.5 million (1997)
Television broadcast stations: 7,306 (1998)
Televisions: 60.5 million (1997)
Internet country code: .ru
Internet Service Providers (ISPs): 35 (2000)
Internet users: 9.2 miilion (2000)
Telephones - main lines in use: 15,000 (1995)
Telephones - mobile cellular: NA
note: however, Rwanda has mobile cellular service
between Kigali and several prefecture capitals (2000)
Telephone system:
general assessment: telephone system primarily
serves business and government
domestic: the capital, Kigali, is connected to the
centers of the prefectures by microwave radio relay;
the remainder of the network depends on wire and HF
radiotelephone
426
Rwanda (continued)
international: international connections employ
microwave radio relay to neighboring countries and
satellite communications to more distant countries;
satellite earth stations - 1 Intelsat (Indian Ocean) in
Kigali (includes telex and telefax service)
Radio broadcast stations: AM 0, FM 3,
shortwave 1 (1998)
Radios: 601,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: NA; probably less than 1,000 (1997)
Internet country code: .rw
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,000 (2000)
Telephones - main lines in use; 2,000 (1997)
Telephones - mobile cellular: 0 (1997)
Telephone system:
general assessment: can communicate with any
place in the world
domestic: automatic network
international: HF radiotelephone from Saint Helena to
Ascension which is a major coaxial submarine cable
relay point between South Africa, Portugal, and UK ;
satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM1,FM0,
shortwave 0 (1998)
Radios: 3,000(1997)
Television broadcast stations: 0 (1997)
Televisions: 2,000(1997)
Internet country code: .sh
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Communications - note: Gough Island has a
meteorological station','df8f6eac52111f84f3981b13b30d0b68c97d96f86238305b5253ead77c593c58','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfb4291a39f0ba2cb057ab7d7e98b87e8b8451d7634ed67fc34f68153be3e27c',2001,'TT','Trinidad and Tobago','communications',970,'Telephones - main lines in use: 17,000 (1997)
Telephones - mobile cellular: 205 (1 997}
Telephone system:
general assessment: good interisland and
international connections
domestic: interisland links to Antigua and Barbuda
and Saint Martin (Guadeloupe and Netherlands
Antilles) are handled by VHF/UHF/SHF
radiotelephone
international: international calls are carried by
radiotelephone to Antigua and Barbuda and switched
there to submarine cable or to Intelsat; or carried to
Saint Martin (Guadeloupe and Netherlands Antilles)
by radiotelephone and switched to Intelsat
Radio broadcast stations: AM 3, FM 1,
shortwave 0 (1998)
Radios: 28,000(1997)
Television broadcast stations: 1 (plus three
repeaters) (1997)
Televisions: 10,000(1997)
Internet country code: .kn
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2,000 (2000)','716b349b8e7bf3108326de998148d106f8ff89b5e466a7ff4d8849f5f09c8cfd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a02d252aa417927a51db1fb1613c0e7fc16f9a406116a549e1fc175faeecc70',2001,'MQ','Martinique','communications',976,'Radio broadcast stations: AM 2, FM 7 (plus 3
repeaters), shortwave 0 (1998)
Radios: 111,000(1997)
Television broadcast stations: 3 (of which two are
commercial stations and one is a community antenna
television or CATV channel) (1997)
Televisions: 32,000(1997)
Internet country code: .Ic
Internet Service Providers (ISPs); 15 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 4,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: adequate
domestic: NA
international: radiotelephone communication with
most countries in the world; 1 earth station in French
domestic satellite system
Radio broadcast stations: AM 1 , FM 4,
shortwave 0 (1998)
Radios: 4,000 (1997)
Television broadcast stations: 0 (there are,
however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions: 4,000(1997)
Internet country code: .pm
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','6a6287169217a4f217ff10f017685606aa9e30ffe601ce076f24583a7b28ebbb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de705ec2ef78d1facb6cb3f8842f41d0310005cd43a1f1d7530f1b91270b8306',2001,'WS','Samoa','communications',983,'Telephones - main lines In use: 8,000 (1997)
Telephones ■ mobile cellular: 1 ,545 (February
1998)
Telephone system:
general assessment: adequate
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1, FM 3,
shortwave 0 (1998)
Radios: 178,000(1997)
Television broadcast stations: 6 (1997)
Televisions: 1 1 ,000 (1 997)
Internet country code: .ws
Internet Service Providers (ISPs): 2 (2000)
Internet users: 500 (2000)','1f650bff301cbb90c38d8bbb67d91e2ca2d7955431685650c93a91fb96f1ae6d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac11be3d6743cacef7d154134903aedf3b44b45cec99ad65c44906211b6bf296',2001,'SC','Seychelles','communications',994,'Telephones - main lines in use: 19,635 (1997)
Telephones - mobile cellular: 1 6,31 6 (1 999)
Telephone system:
general assessment: effective system
domestic: radiotelephone communications between
islands in the archipelago
international: direct radiotelephone communications
with adjacent island countries and African coastal
countries; satellite earth station - 1 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 1, FM 2,
shortwave 2 (1998)
Radios: 42,000(1997)
Television broadcast stations: 2 (plus 9 repeaters)
(1997)
Televisions: 11,000(1997)
Internet country code: .sc
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000 (2000)','0345365c75b15ffff4147262016016901b18e9bcd8cb8c0f771f6ef38c429d58','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae4112ea855af83d2310c907a4cf2108ed76b68e2ff5902fd048365c263718cc',2001,'SL','Sierra Leone','communications',1002,'Telephones - main lines in use: 17,000 (1997)
Telephones - mobile cellular: 650 (1999)
Telephone system:
general assessment: marginal telephone and
telegraph service
domestic: national microwave radio relay trunk
system, made unserviceable by military activities, is
now operating from Freetown to Bo and Kenema
(April 2001)
/nfemaf/ona/.‘ satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM1,FM9,
shortwave 1 (1999)
Radios: 1.12 million (1997)
Television broadcast stations: 2 (1999)
Televisions: 53,000(1997)
Internet country code: .si
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000 (2000)','95027dbb087bc8fa04c87345767078a204c345cc9c09e40d1efef73b2ba2d131','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d65448da83e2e728de52b3bc3869cc4c05a0a4687662eee02c74cf12fc9eb6ba',2001,'HU','Hungary','communications',1010,'Telephones - main lines in use: 1 ,934,558 (1 998)
Telephones - mobile cellular: 736,662 (April 1999)
Telephone system:
general assessment: a modernization and
privatization program is increasing accessibility to
telephone service, reducing the waiting time for new
subscribers, and generally improving service quality
domestic: predominantly an analog system that is
now receiving digital equipment and is being enlarged
with fiber-optic cable, especially in the larger cities;
mobile cellular capability has been added
international: three international exchanges (one in
Bratislava and two in Banska Bystrica) are available;
Slovakia is participating in several international
telecommunications projects that will increase the
availability of external services
Radio broadcast stations: AM 15, FM 78,
shortwave 2 (1998)
Radios: 3.12 million (1997)
Television broadcast stations: 38 (plus 864
repeaters) (1995)
Televisions: 2.62 million (1997)
Internet country code: .sk
Internet Service Providers (ISPs): 6 (2000)
Internet users: 700,000 (2000)','56cc55b977335cd3cc6c2a50e703e9e582b002c641186f293e4b9530af86d38f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f783e762035a2c0b731fc31c23b4ce9803a3e71972598e9f5fcfde4dbba5dad',2001,'SB','Solomon Islands','communications',1019,'Telephones - main lines in use: 8,000 (1997)
Telephones - mobile cellular: 658 (1997)
Telephone system:
general assessment: N A
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 3, FM 0,
shortwave 0 (1998)
Radios: 57,000(1997)
Television broadcast stations: 0 (1997)
Televisions: 3,000(1997)
Internet country code: .sb
Internet Service Providers (ISPs): 1 (2000)
internet users: 3,000 (2000)','05f189ad4636445fe13a47277aba7c3f0c391709206ce18eb789b84679232404','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4096906413125a2d5b564f8fec3b88fefbe180ba1c0935b3cd19ed28cff67f70',2001,'SO','Somalia','communications',1027,'Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
genera/ assessment.- the public telecommunications
system was completely destroyed or dismantled by
the civil war factions; all relief organizations depend
on their own private systems
domestic: recently, local cellular telephone systems
have been established in Mogadishu and in several
other population centers
international: international connections are available
from Mogadishu by satellite
Radio broadcast stations: AM 0, FM 0,
shortwave 4 (1988)
Radios: 470,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 135,000(1997)
Internet country code: .so
Internet Service Providers (ISPs): 1 (2000)
Internet users: 200 (2000)','d7ec6dd00579eb7155a265952ce07e9870c28ffa6489264873e76f4f2b0cc36b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dec3c8a79c40f2b2c5440f04bd2300589c558b5495aa1f37dc7ba4658642383',2001,'ES','Spain','communications',1038,'Telephones - main lines in use: 17.336 million
(1999)
Telephones - mobile cellular: 8.394 million (1999)
Telephone system:
general assessment: generally adequate, modern
facilities; teledensity is 44 main lines for each 100
persons
domestic: NA
international: 22 coaxial submarine cables; satellite
earth stations - 2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean), NA Eutelsat; tropospheric scatter to
adjacent countries
Radio broadcast stations: AM 208, FM 715,
shortwave 1 (1998)
Radios: 13.1 million (1997)
Television broadcast stations: 224 (plus 2,105
repeaters)
note: these figures include 1 1 television broadcast
stations and 88 repeaters in the Canary Islands (1995)
Televisions: 16.2 million (1997)
Internet country code: .es
Internet Service Providers (ISPs): 56 (2000)
Internet users: 4.6 million (2000)','b6e3a3389526d5bf53f574504fb43eafa4b35a6473ed4c1606ef1f488c9552e7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef6fcb0d78aa800f4baf497f9dd12bc8d4309231a8201f4ab492ab2e3f4f7e7e',2001,'LK','Sri Lanka','communications',1046,'Telephones - main lines in use: 494,509 (1998)
Telephones - mobile cellular: 228,604 (1999)
Telephone system:
general assessment: very inadequate domestic
service, particularly in rural areas; some hope for
improvement with privatization of national telephone
company and encouragement to private investment;
good international service (1999)
domestic: national trunk network consists mostly of
digital microwave radio relay; fiber-optic links now in
use in Colombo area and two fixed wireless local
loops have been installed; competition is strong in
mobile cellular systems; telephone density remains
low at 2.6 main lines per 100 persons (1999)
473
Sri Lanka (continued)
international: submarine cables to Indonesia and
Djibouti; satellite earth stations - 2 Intelsat (Indian
Ocean) (1999)
Radio broadcast stations: AM 26, FM 45,
shortwave 1 (1998)
Radios: 3.85 million (1997)
Television broadcast stations: 21 (1997)
Televisions: 1.53 million (1997)
Internet country code: .Ik
Internet Service Providers (ISPs): 5 (2000)
Internet users: 65,000 (2000)','5ab7400fd7f9c6e65255e0823543562605f5f245d1043bac63bed2a4293839c3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bedc513553b3c57e95c84ef791513621f6b33a6b10f9675acae5565181afcef',2001,'SD','Sudan','communications',1055,'Telephones - main lines in use: 400,000 (2000)
Telephones - mobile cellular: 20,000 (2000)
Telephone system:
general assessment: large, well-equipped system by
regional standards and being upgraded; cellular
communications started in 1996 and have expanded
substantially
domestic: consists of microwave radio relay, cable,
radiotelephone communications, tropospheric scatter,
and a domestic satellite system with 14 earth stations
/ntemaf/ona/; satellite earth stations - 1 Intelsat
(Atlantic Ocean) and 1 Arabsat (2000)
Radio broadcast stations: AM 12, FM 1,
shortwave 1 (1998)
Radios: 7.55 million (1997)
Television broadcast stations: 3 (1997)
Televisions: 2.38 million (1997)
Internet country code: .sd
Internet Service Providers (ISPs): 1 (2000)
Internet users: 10,000(2000)','92711bf2171791035326066989abf1dd38738e759453016430ea133455c9944d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('127ee27b133f637db41c2c885c770d24130319010f1a76708604582e4834cbac',2001,'PK','Pakistan','communications',1070,'Telephones - main lines in use: 363,000 (1997)
Telephones - mobile cellular: 2,500 (1997)
Telephone system:
general assessment: poorly developed and not well
maintained; many towns are not reached by the
national network
domestic: cable and microwave radio relay
international: linked by cable and microwave radio
relay to other CIS republics and by leased
connections to the Moscow international gateway
switch; Dushanbe linked by Intelsat to international
gateway switch in Ankara (Turkey); satellite earth
stations - 1 Orbita and 2 Intelsat
Radio broadcast stations: AM 9, FM 6,
shortwave 5 (1998)
Radios: 1.291 million (1991)
Television broadcast stations: 0 (there are,
however, repeaters that relay programs from Russia,
Iran, and Turkey) (1997)
Televisions: 860,000(1991)
Internet country code: .tj
Internet Service Providers (ISPs): NA
Internet users: 2,000 (2000)
Telephones - main lines in use: 127,000 (1998)
Telephones - mobile cellular: 30,000 (1999)
Telephone system:
general assessment: fair system operating below
capacity and being modernized for better service;
VSAT (very small aperture terminal) system under
construction
domestic: \\rmk service provided by open wire,
microwave radio relay, tropospheric scatter, and
fiber-optic cable; some links being made digital
/ntemaf/ona/; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM 1 1 ,
shortwave 2 (1998)
Radios: 8.8 million (1997)
Television broadcast stations: 3 (1999)
Televisions: 103,000(1997)
Internet country code; .tz
Internet Service Providers (ISPs): 6 (2000)
Internet users: 25,000 (2000)','cad7dee30e49df56e1dd5d8475d8a822dec5ecf4475bbbd8a375341b935d884d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08ba162e36303dd1a7ce0a419a5a44040d7e64ad5c4a0c5aced19a25404678ff',2001,'TV','Tuvalu','communications',1084,'Telephones - main lines in use: 1,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: serves particular needs for
internal communications
domestic: radiotelephone communications between
islands
international: NA
Radio broadcast stations: AM1,FI\\/I0,
shortwave 0 (1998)
Radios: 4,000(1997)
Television broadcast stations: 0 (1997)
Televisions: 800
Internet country code: .tv
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 50,074; however,
80,868 main lines were installed (1998)
Telephones - mobile cellular: 9,000 (1998)
Telephone system:
general assessment: seriously inadequate; two
cellular systems have been introduced, but a sharp
increase in the number of main lines Is essential;
e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio
relay, and radiotelephone communication stations,
fixed and mobile cellular systems for short range
traffic
international: satellite earth stations - 1 Intelsat
(Atlantic Ocean) and 1 Inmarsat; analog links to
Kenya and Tanzania
Radio broadcast stations: AM 19, FM 4,
shortwave 5 (1998)
Radios: 2.6 million (1997)
Television broadcast stations: 8 (plus one
low-power repeater) (1999)
Televisions: 315,000(1997)
Internet country code: .ug
Internet Service Providers (ISPs): 2 (2000)
Internet users: 25,000 (2000)
520
Uganda (continued)
Telephones - main lines in use: 9.45 million (April
1999)
Telephones - mobile cellular: 236,000 (1998)
Telephone system:
general assessment: Ukraine''s telecommunication
development plan, running through 2005, emphasizes
improving domestic trunk lines, international
connections, and the mobile cellular system
domestic: a\\. independence in December 1991,
Ukraine inherited a telephone system that was
antiquated, inefficient, and in disrepair; more than 3.5
million applications for telephones could not be
satisfied; telephone density is now rising slowly and
the domestic trunk system is being improved; the
mobile cellular telephone system is expanding at a
high rate
international: two new domestic trunk lines are a part
of the fiber-optic Trans-Asia-Europe (TAE) system
and three Ukrainian links have been installed in the
fiber-optic Trans-European Lines (TEL) project which
connects 18 countries; additional international service
is provided by the Italy-Turkey-Ukraine-Russia (ITUR)
fiber-optic submarine cable and by earth stations in
the Intelsat, Inmarsat, and Intersputnik satellite
systems
Radio broadcast stations: AM 134, FM 289,
shortwave 4 (1998)
Radios: 45.05 million (1997)
Television broadcast stations: at least 33 (plus 21
repeaters that relay broadcasts from Russia) (1997)
Televisions: 18.05 million (1997)
Internet country code: .ua
Internet Service Providers (ISPs): 32 (2000)
Internet users: 200,000 (2000)','ebd508bdc31ab057d8cce2ac2f1793289f9c20721b79ff66a8d20cb71bcff95b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7021137404287dbf46710e185b79458f7bbda66371688468f8c60cf030f0c46',2001,'OM','Oman','communications',1093,'Telephones - main lines in use: 915,223 (1998)
Telephones - mobile cellular: 1 million (1999)
Telephone system:
general assessment: modern system consisting of
microwave radio relay and coaxial cable; key centers
are Abu Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean) and 1 Arabsat;
submarine cables to Qatar, Bahrain, India, and
Pakistan; tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia
Radio broadcast stations: AM 13, FM 7,
shortwave 2 (1998)
Radios: 820,000(1997)
Television broadcast stations: 1 5 (1 997)
Televisions: 310,000(1997)
Internet country code: .ae
Internet Service Providers (ISPs): 1 (2000)
Internet users: 400,000 (2000)','3a2cd3e3b9dd85940974a3754c5032a504f341d4089a82128729dab8f75dcef1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('915de57d108a6b84ed10ab6c53fc6585ec6ab1c1a92d653071c1c21d1049e44b',2001,'UY','Uruguay','communications',1105,'Telephones - main lines in use: 850,000 (2000)
Telephones - mobile cellular: 300,000 (2000)
Telephone system:
general assessment: some modern facilities
domestic: most modern facilities concentrated in
Montevideo; new nationwide microwave radio relay
network
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 94, FM 1 15,
shortwave 14 (seven are inactive) (1998)
Radios: 1.97 million (1997)
Television broadcast stations: 26 (plus ten
low-power repeaters for the Montevideo station)
(1997)
Televisions: 782,000(1997)
Internet country code: .uy
Internet Service Providers (ISPs): 7 (2000)
Internet users: 300,000 (2000)','725272e6cb7f2689b397ce84a67453a2d4bbb3ce2fe43bc0d4abcc4d2102c541','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c856a0cb825b3da6be81dbe67fb3bb30d64fbfec58f3e95076e9f1f521bf4a6',2001,'UZ','Uzbekistan','communications',1112,'Telephones - main lines in use: 1 .98 million (1 999)
Telephones - mobile cellular: 26,000 (1998)
Telephone system:
genera/ assessmenf.'' antiquated and inadequate; in
serious need of modernization
domestic: \\\\]e domestic telephone system is being
expanded and technologically improved, particularly
in Tashkent and Samarqand, under contracts with
prominent companies in industrialized countries;
moreover, by 1998, six cellular networks had been
placed in operation ■ four of the GSM type (Global
System for Mobile Communication), one D-AMPS
type (Digital Advanced Mobile Phone System), and
one AMPS type (Advanced Mobile Phone System)
international: linked by landline or microwave radio
relay with CIS member states and to other countries
by leased connection via the Moscow international
gateway switch; after the completion of the Uzbek link
to the Trans-Asia-Europe (TAE) fiber-optic cable,
Uzbekistan will be independent of Russian facilities
for international communications; Inmarsat also
provides an international connection, albeit an
expensive one; satellite earth stations ■ NA (1998)
Radio broadcast stations: AM 20, FM 7,
shortwave 10 (1998)
Radios: 10.8 million (1997)
Television broadcast stations: 4 (plus two
repeaters that relay Russian, Kazakh, Kyrgyz, and
Tadzhik programs) (1997)
Televisions: 6.4 million (1997)
Internet country code: .uz
Internet Service Providers (ISPs): 42 (2000)
Internet users: 7,500 (2000)','bac65b01042a6decaedc40dcedf5610c426072d36013de13999b77aa9e2818b5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94f1addd963d9c3763104bccd4e75ed4507f8c3a3891e9bbe2cf2a757404d87d',2001,'AF','Afghanistan','communications',1120,'Telephones - main lines in use: 4,000 (1996)
Telephones - mobile cellular: 1 54 (1 996)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 2,
shortwave 1 (1998)
Radios: 62,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 2,000(1997)
Internet country code: .vu
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000 (2000)
Telephones ■ main lines in use: 2,600,000.00;
however, 3,500,000 were installed (1998)
Telephones - mobile cellular: 2 million (1998)
Telephone system:
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth
stations; recent substantial improvement in telephone
service in rural areas; substantial increase in
digitalization of exchanges and trunk lines; installation
of a national interurban fiber-optic network capable of
digital multimedia services
international: 3 submarine coaxial cables; satellite
earth stations - 1 Intelsat (Atlantic Ocean) and 1
PanAmSat; participating with Colombia, Ecuador,
Peru, and Bolivia in the construction of an
International fiber-optic network
Radio broadcast stations: AM 201, FM NA (20 in
Caracas), shortwave 11 (1998)
Radios: 10.75 million (1997)
Television broadcast stations: 66 (plus 45
repeaters) (1997)
Televisions: 4.1 million (1997)
Internet country code: .ve
Internet Service Providers (ISPs): 16 (2000)
Internet users: 400,000 (2000)
Telephones ■ main lines in use: 2.6 million (2000)
Telephones - mobile cellular: 730,155 (2000)
Telephone system:
general assessment: V\\e\\nam is putting considerable
effort into modernization and expansion of its
telecommunication system, but its performance
continues to lag behind that of its more modern
neighbors
domestic: all provincial exchanges are digitalized and
connected to Hanoi, Da Nang, and Ho Chi Minh City
by fiber-optic cable or microwave radio relay
networks; since 1991, main lines in use have been
substantially increased and the use of mobile
telephones is growing rapidly
544
Vietnam (continued)
international: satellite earth stations - 2 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM 65, FM 7,
shortwave 29 (1999)
Radios: 8.2 million (1997)
Television broadcast stations: at least 7 (plus 13
repeaters) (1998)
Televisions: 3.57 million (1997)
Internet country code: .vn
Internet Service Providers (ISPs): 5 (2000)
Internet users: 121,000(2000)','263758af887b4508327e7014f863e42fec07c7dbdc4b91891da5c6bbd39e0642','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c32f6580ae9e317fb87274f6c4f81a6ea3fcd3c83493722fda6da6526b204b3c',2001,'PR','Puerto Rico','communications',1126,'Telephones - main lines in use: 62,000 (1997)
Telephones - mobile cellular: 2,000 (1992)
Telephone system:
general assessment: N A
domestic: modern, uses fiber-optic cable and
microwave radio relay
international: submarine cable and satellite
communications: satellite earth stations - NA
Radio broadcast stations: AM 5, FM 1 1 ,
shortwave 0(1998)
Radios: 107,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 68,000(1997)
Internet country code: .vi
Internet Service Providers (ISPs): 50 (2000)
Internet users: 12,000(2000)','4d7b8b8b5c4dac7dc1160801bb23aa4d3678669c636c87ef5e61026c027a6787','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54639341ac5d0f8e3c3e404bbf85b938dc631fc8480185e211ca894bbf492ce6',2001,'YE','Yemen','communications',1138,'Telephones - main lines In use: 291,359 (1999)
Telephones - mobile cellular: 32,042 (2000)
Telephone system:
genera/ assessment; since unification in 1990, efforts
have been made to create a national
telecommunications network
domestic: the national network consists of microwave
radio relay, cable, tropospheric scatter, and GSM
cellular mobile telephone systems
international: satellite earth stations - 3 Intelsat (2
Indian Ocean and 1 Atlantic Ocean), 1 1ntersputnik
(Atlantic Ocean region), and 2 Arabsat; microwave
radio relay to Saudi Arabia and Djibouti
Radio broadcast stations: AM 6, FM 1,
shortwave 2 (1998)
Radios: 1.05 million (1997)
Television broadcast stations: 7 (plus several
low-power repeaters) (1997)
Televisions: 470,000(1997)
Internet country code: .ye
Internet Service Providers (ISPs): 1 (2000)
Internet users: 12,000(2000)
Telephones - main lines in use: 2.017 million
(1995)
Telephones - mobile cellular: 87,000 (1997)
Telephone system:
general assessment: N A
domestic: NA
tetemaf/ona/; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 113, FM 194,
shortwave 2 (1998)
Radios: 3.15 million (1997)
Television broadcast stations: more than 771
(including 86 strong stations and 685 low-power
stations, plus 20 repeaters in the principal networks;
also numerous local or private stations in Serbia and
Vojvodina) (1997)
Televisions: 2.75 miliion (1997)
Internet Service Providers (ISPs): 9 (2000)
Internet users: 80,000 (2000)','e42db7258600e70871ef719d33905b037744092d63dd238d90d9ad3899d45646','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9578fd3bf5663347d41f2f3e7472f965e9644af0a16d6a9f566265129a0e5baf',2001,'ZM','Zambia','communications',1147,'Telephones - main lines in use: 77,935 (in addition
there are about 40,000 fixed telephones in wireless
local loop connections) (1997)
Telephones - mobile cellular: 6,000 (1998)
Telephone system:
general assessment; facilities are among the best in
Sub-Saharan Africa
domestic: high-capacity microwave radio relay
connects most larger towns and cities; several cellular
telephone services in operation; Internet service is
widely available; very small aperture terminal (VSAT)
networks are operated by private firms
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 19, FM 5,
shortwave 4 (1998)
Radios; 1.03 million (1997)
Television broadcast stations: 9 (1997)
Teievisions: 277,000(1997)
Internet country code: .zm
Internet Service Providers (ISPs): 3 (2000)
Internet users: 1 5,000 (2000)
Telephones - main lines in use: 212,000 (in
addition there are about 20,000 fixed telephones in
wireless local loop connections) (1997)
Telephones - mobile cellular: 70,000 (1999)
Telephone system:
general assessment: system was once one of the
best in Africa, but now suffers from poor maintenance;
more than 100,000 outstanding requests for
connection despite an equally large number of
installed but unused main lines
domestic: consists of microwave radio relay links,
open-wire lines, radiotelephone communication
stations, fixed wireless local loop installations, and a
substantial mobile cellular network; Internet
connection is available in Harare and planned for all
major towns and for some of the smaller ones
international: satellite earth stations - 2 Intelsat; two
international digital gateway exchanges (in Harare
and Gweru)
Radio broadcast stations: AM 7, FM 20 (plus 17
repeater stations), shortwave 1 (1998)
Radios: 1.14 million (1997)
Television broadcast stations: 1 6 (1997)
Televisions: 370,000(1997)
Internet country code: .zw
Internet Service Providers (ISPs): 6 (2000)
Internet users: 30,000(1999)','0eca2bdcfaa974f2c827077b85eee98bc6871fcee0c5a361a04c42de40ac6f14','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cdcfb3fa56d696048df8c6b75d6be81e8f882a2719322fb9d470dc9ff621258',2001,'ZW','Zimbabwe','communications',4,'This category deals with the means of exchanging information and
includes the telephone, radio, television, and Internet service
provider entries.
Communications - note
This entry includes miscellaneous communications information of
significance not included elsewhere.
Constitution
This entry includes the dates of adoption, revisions, and major
amendments.
Country data codes
see Data codes
Country map
Most versions of the Factbook provide a country map in color. The maps
were produced from the best information available at the time of
preparation. Names and/or boundaries may have changed subsequently.
Country name
This entry includes all forms of the country''s name approved by the US
Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local
long form (Repubblica Italiana), local short form (Italia), former
(Kingdom of Italy), as well as the abbreviation. Also see the
Terminology note.
Currency
This entry identifies the national medium of exchange and its basic
subunit.
Currency code
This entry gives the International Organization for Standardization
(ISO) 4217 alphabetic currency code for each country.
Data codes
This information is presented in Appendix D: Cross-Reference List of
Country Data Codes and Appendix E: Cross-Reference List of
Hydrographic Data Codes. This appendix includes the US Government
approved Federal Information Processing Standards (FIPS) codes, the
International Organization for Standardization (ISO) codes, and
Internet codes for land entities. The appendix also includes the
International Hydrographic Organization (IHO) codes, Aeronautical Chart
and Information Center (ACIC; now a part of the National Imagery and
Mapping Agency or NIMA) codes, and Defense Intelligence Agency (DIA)
codes for hydrographic entities. The US Government has not yet approved
a standard for hydrographic data codes similar to the FIPS 10-4
standard for country data codes.
Date of information
In general, information available as of 1 January 2001, was used in the
preparation of this edition.
Death rate
This entry gives the average annual number of deaths during a year per
1,000 population at midyear; also known as crude death rate. The death
rate, while only a rough indicator of the mortality situation in a
country, accurately indicates the current mortality impact on
population growth. This indicator is significantly affected by age
distribution, and most countries will eventually show a rise in the
overall death rate, in spite of continued decline in mortality at all
ages, as declining fertility results in an aging population.
Debt - external
This entry gives the total amount of public foreign financial
obligations.
Dependency status
This entry describes the formal relationship between a particular
nonindependent entity and an independent state.
Dependent areas
This entry contains an alphabetical listing of all nonindependent
entities associated in some way with a particular independent state.
Diplomatic representation
The US Government has diplomatic relations with 185 independent states,
including 183 of the 189 UN members (excluded UN members are Bhutan,
Cuba, Iran, Iraq, North Korea, and the US itself). In addition, the US
has diplomatic relations with 2 independent states that are not in the
UN - Holy See and Switzerland.
Diplomatic representation from the US
This entry includes the chief of mission, embassy address, mailing
address, telephone number, FAX number, branch office locations,
consulate general locations, and consulate locations.
Disputes - international
This entry includes a wide variety of situations that range from
traditional bilateral boundary disputes to unilateral claims of one
sort or another. Information regarding disputes over international
terrestrial and maritime boundaries has been reviewed by the US
Department of State. References to other situations involving borders
or frontiers may also be included, such as resource disputes,
geopolitical questions, or irredentist issues; however, inclusion does
not necessarily constitute official acceptance or recognition by the US
International Bank for Reconstruction and Development (IBRD): note -
also known as the World Bank
established - 22 July 1944; effective - 27 December 1945
aim - to provide economic development loans; a UN specialized agency
members - (182) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Chamber of Commerce (ICC): established - NA 1919
aim - to promote free trade and private enterprise and to represent
business interests at national and international levels
members - (78 national councils) Algeria, Argentina, Australia,
Austria, Bahrain, Bangladesh, Belgium, Brazil, Burkina Faso, Cameroon,
Canada, Caribbean, Chile, China, Colombia, Cote d''Ivoire, Cuba, Cyprus,
Czech Republic, Denmark, Ecuador, Egypt, Finland, France, Germany,
Ghana, Greece, Greenland, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea,
Kuwait, Lebanon, Lithuania, Luxembourg, Madagascar, Mexico, Morocco,
Netherlands, NZ, Nigeria, Norway, Pakistan, Peru, Philippines, Poland,
Portugal, Russia, Saudi Arabia, Senegal, Singapore, Slovakia, South
Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Taiwan, Tanzania,
Thailand, Togo, Tunisia, Turkey, UK, US, Uruguay, Venezuela, Yugoslavia
International Civil Aviation Organization (ICAO): established - 7
December 1944; effective - 4 April 1947
aim - to promote international cooperation in civil aviation; a UN
specialized agency
members - (187) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt,
El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
International Committee of the Red Cross (ICRC): established - 17
February 1863
aim - to provide humanitarian aid in wartime
members - (25 individuals) all Swiss nationals
International Confederation of Free Trade Unions (ICFTU): established
- NA December 1949
aim - to promote the trade union movement
members - (221 affiliated organizations in the following 148 countries)
Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria,
Azerbaijan, The Bahamas, Bangladesh, Barbados, Basque Country, Belgium,
Belize, Benin, Bermuda, Botswana, Brazil, Bulgaria, Burkina Faso,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Curacao,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, El Salvador, Eritrea, Estonia, Falkland Islands,
Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Holy See, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya,
Kiribati, South Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg,
Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Mongolia, Montserrat, Morocco, Mozambique, Nepal,
Netherlands, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Puerto Rico, Romania, Russia, Rwanda, Saint Helena,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden,
Switzerland, Taiwan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Uganda, UK, US, Vanuatu, Venezuela,
Yugoslavia, Zambia, Zimbabwe
International Court of Justice (ICJ): note - also known as the World
Court
established - 3 February 1946 superseded Permanent Court of
International Justice
aim - primary judicial organ of the UN
members - (15 judges) elected by the UN General Assembly and Security
Council to represent all principal legal systems
International Criminal Police Organization (Interpol): established -
NA September 1923 set up as the International Criminal Police
Commission; 13 June 1956 constitution modified and present name adopted
aim - to promote international cooperation among police authorities in
fighting crime
members - (178) Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
subbureaus - (14) American Samoa, Anguilla, Bermuda, British Virgin
Islands, Cayman Islands, Gibraltar, Guam, Hong Kong, Macau, Montserrat,
Northern Mariana Islands, Puerto Rico, Turks and Caicos Islands, Virgin
Islands
International Development Association (IDA): established - 26 January
1960; effective - 24 September 1960
aim - UN specialized agency and IBRD affiliate that provides economic
loans for low-income countries
members - (161)
Part I - (27 developed countries) Australia, Austria, Belgium, Canada,
Denmark, EU, Finland, France, Germany, Iceland, Ireland, Italy, Japan,
Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South
Africa, Spain, Sweden, Switzerland, UAE, UK, US
Part II - (134 less developed countries) Afghanistan, Albania, Algeria,
Angola, Argentina, Armenia, Azerbaijan, Bangladesh, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cyprus, Czech Republic, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia,
Fiji, Gabon, The Gambia, Georgia, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India,
Indonesia, Iran, Iraq, Israel, Jordan, Kazakhstan, Kenya, Kiribati,
South Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Mongolia, Morocco,
Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone,
Slovakia, Slovenia, Solomon Islands, Somalia, Sri Lanka, Sudan,
Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Uganda, Uzbekistan, Vanuatu, Vietnam,
Yemen, Zambia, Zimbabwe
International Energy Agency (IEA): established - 15 November 1974
aim - to promote cooperation on energy matters, especially emergency
oil sharing and relations between oil consumers and oil producers;
established by the OECD
members - (25) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden,
Switzerland, Turkey, UK, US
observers - (15) Commission of the European Communities, Iceland, South
Korea, Mexico, Poland
International Federation of Red Cross and Red Crescent Societies
(IFRCS): note - formerly known as League of Red Cross and Red Crescent
Societies (LORCS)
established - 5 May 1919
aim - to organize, coordinate, and direct international relief actions;
to promote humanitarian activities; to represent and encourage the
development of National Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to reduce the vulnerability
of people through development programs
members - (176) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia,
Fiji, Finland, France, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
associate members - (4) Comoros, Cyprus, Gabon, Tuvalu
International Finance Corporation (IFC): established - 25 May 1955;
effective - 24 July 1956
aim - to support private enterprise in international economic
development; a UN specialized agency and IBRD affiliate
members - (174) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Samoa, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Fund for Agricultural Development (IFAD): established -
NA November 1974
aim - to promote agricultural development; a UN specialized agency
members - (161)
Category I - (22 industrialized aid contributors) Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Ireland,
Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain,
Sweden, Switzerland, UK, US
Category II - (12 petroleum-exporting aid contributors) Algeria, Gabon,
Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia,
UAE, Venezuela
Category III - (127 aid recipients) Afghanistan, Albania, Angola,
Antigua and Barbuda, Argentina, Armenia, Azerbaijan, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India,
Israel, Jamaica, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Solomon
Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe
International Hydrographic Organization (IHO): note - name changed
from International Hydrographic Bureau on 22 September 1970
established - NA June 1919; effective - NA June 1921
aim - to train hydrographic surveyors and nautical cartographers to
achieve standardization in nautical charts and electronic chart
displays; to provide advice on nautical cartography and hydrography; to
develop the sciences in the field of hydrography and techniques used
for descriptive oceanography
members - (68) Algeria, Argentina, Australia, Bahrain, Belgium, Brazil,
Canada, Chile, China, Colombia, Democratic Republic of the Congo,
Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Ecuador, Egypt,
Estonia, Fiji, Finland, France, Germany, Greece, Guatemala, Iceland,
India, Indonesia, Iran, Italy, Japan, North Korea, South Korea,
Malaysia, Monaco, Morocco, Mozambi','2b95b3de52c59fe119434a8ce538e1260292eb22be79bbc6e38d83e8b415ff6c','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9fcf3b013298b75744e82442a774abc8be27b7e53faeb2aa40809f7302d7192',2001,'ZW','Zimbabwe','communications',5,'que, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Papua New Guinea, Peru, Philippines, Poland,
Portugal, Russia, Singapore, South Africa, Spain, Sri Lanka, Suriname,
Sweden, Syria, Thailand, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Ukraine, UAE, UK, US, Uruguay, Venezuela, Yugoslavia
membership pending - (5) Bangladesh, Bulgaria, Jamaica, Mauritania,
Warsaw Pact (WP): established 14 May 1955 to promote mutual defense;
members met 1 July 1991 to dissolve the alliance; member states at the
time of dissolution were Bulgaria, Czechoslovakia, Hungary, Poland,
Romania, and the USSR; earlier members included GDR and Albania
West African Development Bank (WADB): note - also known as Banque
Ouest-Africaine de Developpement (BOAD); is a financial institution of
WAEMU
established - 14 November 1973
aim - to promote regional economic development and integration
regional members - (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-
Bissau, Mali, Niger, Senegal, Togo
international/nonregional members - (5) African Development Bank,
Belgium, European Investment Bank, France, Germany
West African Economic and Monetary Union (WAEMU): note - also known as
Union Economique et Monetaire Ouest Africaine (UEMOA)
established - 1 August 1994
aim - to increase competitiveness of members'' economic markets; to
create a common market
members - (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali,
Niger, Senegal, Togo
Western European Union (WEU): established - 23 October 1954; effective
- 6 May 1955
aim - to provide mutual defense and to move toward political
unification
members - (10) Belgium, France, Germany, Greece, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
associate members - (6) Czech Republic, Hungary, Iceland, Norway,
Poland, Turkey
associate partners - (7) Bulgaria, Estonia, Latvia, Lithuania, Romania,
Slovakia, Slovenia
observers - (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank Group: includes International Bank for Reconstruction and
Development (IBRD), International Development Association (IDA), and
International Finance Corporation (IFC)
World Confederation of Labor (WCL): established - 19 June 1920 as the
International Federation of Christian Trade Unions (IFCTU), renamed 4
October 1968
aim - to promote the trade union movement
members - (101 national organizations) Antigua and Barbuda, Argentina,
Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Bonaire
Island, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Central
African Republic, Chad, Chile, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus,
Czech Republic, Dominica, Dominican Republic, Ecuador, El Salvador,
France, French Guiana, Gabon, The Gambia, Ghana, Guadeloupe, Guatemala,
Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia,
Iran, Italy, Japan, Kazakhstan, South Korea, Liberia, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malaysia, Malta, Martinique, Mauritania, Mauritius, Mexico,
Montserrat, Morocco, Namibia, Netherlands, Netherlands Antilles,
Nicaragua, Niger, Pakistan, Panama, Paraguay, Peru, Philippines,
Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Lucia, Saint
Vincent and the Grenadines, Sao Tome and Principe, Senegal, Sierra
Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka,
Switzerland, Taiwan, Thailand, Togo, Trinidad and Tobago, Ukraine, US,
Uruguay, Venezuela, Vietnam, Windward Islands, Zambia, Zimbabwe
World Federation of Trade Unions (WFTU): established - 3 October 1945
aim - to promote the trade union movement
members - (125 and the Palestine Liberation Organization) Afghanistan,
Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea,
Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan,
Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon,
Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Mali,
Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia, NZ,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Puerto Rico, Reunion, Romania, Russia,
Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Sierra Leone, Slovakia, Solomon
Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Program (WFP): established - 24 November 1961
aim - to provide food aid in support of economic development or
disaster relief; an ECOSOC organization
members - (36) selected on a rotating basis from all regions
World Health Organization (WHO): established - 22 July 1946; effective
- 7 April 1948
aim - to deal with health matters worldwide; a UN specialized agency
members - (191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niue, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,
associate members - (2) Puerto Rico, Tokelau
observers - (2) Holy See, Liechtenstein
World Intellectual Property Organization (WIPO): established - 14 July
1967; effective - 26 April 1970
aim - to furnish protection for literary, artistic, and scientific
works; a UN specialized agency
members - (177) Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
World Meteorological Organization (WMO): established - 11 October
1947; effective - 4 April 1951
aim - to sponsor meteorological cooperation; a UN specialized agency
members - (185) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British
Caribbean Territories, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, New Caledonia, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
World Tourism Organization (WToO): established - 2 January 1975
aim - to promote tourism as a means of contributing to economic
development, international understanding, and peace
members - (135) Afghanistan, Albania, Algeria, Andorra, Angola,
Argentina, Armenia, Austria, Bangladesh, Benin, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile,
China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-
Bissau, Haiti, Hungary, India, Indonesia, Iran, Iraq, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Libya, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger,
Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Russia, Rwanda, San Marino, Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Swaziland, Switzerland, Syria, Tanzania,
Thailand, Togo, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (6) Aruba, Flanders, Hong Kong, Macau, Madeira
Islands, Netherlands Antilles
observers - (2) Holy See, Palestine Liberation Organization
World Trade Organization (WTrO): note - succeeded General Agreement on
Tariff and Trade (GATT)
established - 15 April 1994; effective - 1 January 1995
aim - to provide a means to resolve trade conflicts between members and
to carry on negotiations with the goal of further lowering and/or
eliminating tariffs and other trade barriers
members - (140) Albania, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cameroon, Canada, Central African Republic, Chad,
Chile, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Estonia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho, Liechtenstein,
Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Mongolia, Morocco, Mozambique, Namibia,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Senegal, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka,
Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay,
Venezuela, Zambia, Zimbabwe
observers - (34) Algeria, Andorra, Armenia, Azerbaijan, The Bahamas,
Belarus, Bhutan, Bosnia and Herzegovina, Cambodia, Cape Verde, China,
Ethiopia, The Former Yugoslav Republic of Macedonia, Holy See,
Kazakhstan, Laos, Lebanon, Lithuania, Moldova, Nepal, Russia, Samoa,
Sao Tome and Principe, Saudi Arabia, Seychelles, Sudan, Taiwan, Tonga,
Ukraine, Uzbekistan, Vanuatu, Vietnam, Yemen, Yugoslavia; note - must
start accession negotiations within five years of becoming observers
Zangger Committee (ZC): established - early 1970s
aim - to establish guidelines for the export control provisions of the
Nonproliferation of Nuclear Weapons Treaty (NPT)
members - (33) Argentina, Australia, Austria, Belgium, Bulgaria,
Canada, China, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg,
Netherlands, Norway, Poland, Portugal, Romania, Russia, Slovakia, South
Africa, Spain, Sweden, Switzerland, Ukraine, UK, US
=====================================================================
Appendix C: Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature - 1 December 1959
entered into force - 23 June 1961
objective - to ensure that Antarctica is used for peaceful purposes
only (such as international cooperation in scientific research); to
defer the question of territorial claims asserted by some nations and
not recognized by others; to provide an international forum for
management of the region; applies to land and ice shelves south of 60
degrees South latitude
parties - (44) Argentina, Australia, Austria, Belgium, Brazil,
Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Finland, France, Germany, Greece, Guatemala, Hungary,
India, Italy, Japan, North Korea, South Korea, Netherlands, NZ, Norway,
Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia, South
Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay,
Venezuela
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
note - abbreviated as Hazardous Wastes
opened for signature - 22 March 1989
entered into force - 5 May 1992
objective - to reduce transboundary movements of wastes subject to the
Convention to a minimum consistent with the environmentally sound and
efficient management of such wastes; to minimize the amount and
toxicity of wastes generated and ensure their environmentally sound
management as closely as possible to the source of generation; and to
assist LDCs in environmentally sound management of the hazardous and
other wastes they generate
parties - (143) Albania, Algeria, Andorra, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Burundi, Cameroon, Canada,
Cape Verde, Chile, China, Colombia, Comoros, Democratic Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Estonia, Ethiopia, EU, Finland, France, The Gambia, Georgia,
Germany, Greece, Guatemala, Guinea, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya,
Kiribati, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria,
Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia
countries that have signed, but not yet ratified - (3) Afghanistan,
Haiti, US
Biodiversity
see Convention on Biological Diversity
Convention for the Conservation of Antarctic Seals
note - abbreviated as Antarctic Seals
opened for signature - NA
entered into force - NA
objective - NA
parties - (16) Argentina, Australia, Belgium, Brazil, Canada, Chile,
France, Germany, Italy, Japan, Norway, Poland, Russia, South Africa,
UK, US
countries that have signed, but not yet ratified - (1) NZ
Convention on Biological Diversity
note - abbreviated as Biodiversity
opened for signature - 5 June 1992
entered into force - 29 December 1993
objective - to develop national strategies for the conservation and
sustainable use of biological diversity
parties - (180) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (7) Afghanistan,
Kuwait, Libya, Thailand, Tuvalu, US, Yugoslavia
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on
Climate Change
Convention on Fishing and Conservation of Living Resources of the High
Seas
note - abbreviated as Marine Life Conservation
opened for signature - 29 April 1958
entered into force - 20 March 1966
objective - to solve through international cooperation the problems
involved in the conservation of living resources of the high seas,
considering that because of the development of modern technology some
of these resources are in danger of being overexploited
parties - (38) Australia, Belgium, Bosnia and Herzegovina, Burkina
Faso, Cambodia, Colombia, Denm','7270a7245fdb194e2c3dd51ce0a17b20c07ca3063c3e37b1cf12d489e0bc58e7','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd09d6284cac6ec6045ceaa53141f836b3dd9c94634d428060213626be74dfeb',2001,'ZW','Zimbabwe','communications',6,'ark, Dominican Republic, Fiji, Finland,
France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra
Leone, Solomon Islands, South Africa, Spain, Switzerland, Thailand,
Tonga, Trinidad and Tobago, Uganda, UK, US, Uruguay, Venezuela,
Yugoslavia
countries that have signed, but not yet ratified - (21) Afghanistan,
Argentina, Bolivia, Canada, China, Costa Rica, Cuba, Ghana, Iceland,
Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ,
Pakistan, Panama, Sri Lanka, Tunisia
Convention on Long-Range Transboundary Air Pollution
note - abbreviated as Air Pollution
opened for signature - 13 November 1979
entered into force - 16 March 1983
objective - to protect the human environment against air pollution and
to gradually reduce and prevent air pollution, including long-range
transboundary air pollution
parties - (48) Armenia, Austria, Belarus, Belgium, Bosnia and
Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece,
Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland,
Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK, US, Yugoslavia
countries that have signed, but not yet ratified - (2) Holy See, San
Marino
Convention on the Conservation of Antarctic Marine Living Resources
note - abbreviated as Antarctic-Marine Living Resources
opened for signature - NA
entered into force - NA
objective - NA
parties - (30) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada,
Chile, EU, Finland, France, Germany, Greece, India, Italy, Japan, South
Korea, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South
Africa, Spain, Sweden, Ukraine, UK, US, Uruguay
Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
note - abbreviated as Endangered Species
opened for signature - 3 March 1973
entered into force - 1 July 1975
objective - to protect certain endangered species from overexploitation
by means of a system of import/export permits
parties - (152) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Latvia, Liberia, Liechtenstein, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Mali, Malta, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (3) Ireland, Kuwait,','f9770f0f1040ee771bb568f07783d7f477313b0925a4686e28fe5ca3b24c8b1e','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b89e6b51dcdacd5b8c7f18a9b3b9785ba44c6b6e86e5406fc9e4693807aec984',2001,'MQ','Martinique','communications',311,'domestic: radiotelephone communications between islands
international: NA
Uganda:
general assessment: seriously inadequate; two cellular
systems have been introduced, but a sharp increase in the number of
main lines is essential; e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio relay, and
radiotelephone communication stations, fixed and mobile cellular
systems for short range traffic
international: satellite earth stations - 1 Intelsat (Atlantic
Ocean) and 1 Inmarsat; analog links to Kenya and Tanzania
Ukraine:
general assessment: Ukraine''s telecommunication
development plan, running through 2005, emphasizes improving
domestic trunk lines, international connections, and the mobile
cellular system
domestic: at independence in December 1991, Ukraine inherited a
telephone system that was antiquated, inefficient, and in disrepair;
more than 3.5 million applications for telephones could not be
satisfied; telephone density is now rising slowly and the domestic
trunk system is being improved; the mobile cellular telephone system
is expanding at a high rate
international: two new domestic trunk lines are a part of the
fiber-optic Trans-Asia-Europe (TAE) system and three Ukrainian links
have been installed in the fiber-optic Trans-European Lines (TEL)
project which connects 18 countries; additional international
service is provided by the Italy-Turkey-Ukraine-Russia (ITUR)
fiber-optic submarine cable and by earth stations in the Intelsat,
Inmarsat, and Intersputnik satellite systems
United Arab Emirates:
general assessment: modern system consisting
of microwave radio relay and coaxial cable; key centers are Abu
Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations - 3 Intelsat (1 Atlantic
Ocean and 2 Indian Ocean) and 1 Arabsat; submarine cables to Qatar,
Bahrain, India, and Pakistan; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
United Kingdom:
general assessment: technologically advanced
domestic and international system
domestic: equal mix of buried cables, microwave radio relay, and
fiber-optic systems
international: 40 coaxial submarine cables; satellite earth
stations - 10 Intelsat (7 Atlantic Ocean and 3 Indian Ocean), 1
Inmarsat (Atlantic Ocean region), and 1 Eutelsat; at least 8 large
international switching centers
United States:
general assessment: a very large, technologically
advanced, multipurpose communications system
domestic: a large system of fiber-optic cable, microwave radio
relay, coaxial cable, and domestic satellites carries every form of
telephone traffic; a rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: 24 ocean cable systems in use; satellite earth
stations - 61 Intelsat (45 Atlantic Ocean and 16 Pacific Ocean), 5
Intersputnik (Atlantic Ocean region), and 4 Inmarsat (Pacific and
Atlantic Ocean regions) (2000)
Uruguay:
general assessment: some modern facilities
domestic: most modern facilities concentrated in Montevideo; new
nationwide microwave radio relay network
international: satellite earth stations - 2 Intelsat (Atlantic
Ocean)
Uzbekistan:
general assessment: antiquated and inadequate; in
serious need of modernization
domestic: the domestic telephone system is being expanded and
technologically improved, particularly in Tashkent and Samarqand,
under contracts with prominent companies in industrialized
countries; moreover, by 1998, six cellular networks had been placed
in operation - four of the GSM type (Global System for Mobile
Communication), one D-AMPS type (Digital Advanced Mobile Phone
System), and one AMPS type (Advanced Mobile Phone System)
international: linked by landline or microwave radio relay with CIS
member states and to other countries by leased connection via the
Moscow international gateway switch; after the completion of the
Uzbek link to the Trans-Asia-Europe (TAE) fiber-optic cable,
Uzbekistan will be independent of Russian facilities for
international communications; Inmarsat also provides an
international connection, albeit an expensive one; satellite earth
stations - NA (1998)
Vanuatu:
general assessment: NA
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Venezuela:
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth stations; recent
substantial improvement in telephone service in rural areas;
substantial increase in digitalization of exchanges and trunk lines;
installation of a national interurban fiber-optic network capable of
digital multimedia services
international: 3 submarine coaxial cables; satellite earth stations
- 1 Intelsat (Atlantic Ocean) and 1 PanAmSat; participating with
Colombia, Ecuador, Peru, and Bolivia in the construction of an
international fiber-optic network
Vietnam:
general assessment: Vietnam is putting considerable effort
into modernization and expansion of its telecommunication system,
but its performance continues to lag behind that of its more modern
neighbors
domestic: all provincial exchanges are digitalized and connected to
Hanoi, Da Nang, and Ho Chi Minh City by fiber-optic cable or
microwave radio relay networks; since 1991, main lines in use have
been substantially increased and the use of mobile telephones is
growing rapidly
international: satellite earth stations - 2 Intersputnik (Indian
Ocean region)
Virgin Islands:
general assessment: NA
domestic: modern, uses fiber-optic cable and microwave radio relay
international: submarine cable and satellite communications;
satellite earth stations - NA
Wake Island:
general assessment: satellite communications; 1 DSN
circuit off the Overseas Telephone System (OTS)
domestic: NA
international: NA
Wallis and Futuna:
general assessment: NA
domestic: NA
international: NA
West Bank:
general assessment: NA
domestic: NA
international: NA
note: Israeli company BEZEK and the Palestinian company PALTEL are
responsible for communication services in the West Bank
Western Sahara:
general assessment: sparse and limited system
domestic: NA
international: tied into Morocco''s system by microwave radio relay,
tropospheric scatter, and satellite; satellite earth stations - 2
Intelsat (Atlantic Ocean) linked to Rabat, Morocco
World:
general assessment: NA
domestic: NA
international: NA
Yemen:
general assessment: since unification in 1990, efforts have
been made to create a national telecommunications network
domestic: the national network consists of microwave radio relay,
cable, tropospheric scatter, and GSM cellular mobile telephone
systems
international: satellite earth stations - 3 Intelsat (2 Indian
Ocean and 1 Atlantic Ocean), 1 Intersputnik (Atlantic Ocean region),
and 2 Arabsat; microwave radio relay to Saudi Arabia and Djibouti
Yugoslavia:
general assessment: NA
domestic: NA
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Zambia:
general assessment: facilities are among the best in
Sub-Saharan Africa
domestic: high-capacity microwave radio relay connects most larger
towns and cities; several cellular telephone services in operation;
Internet service is widely available; very small aperture terminal
(VSAT) networks are operated by private firms
international: satellite earth stations - 2 Intelsat (1 Indian
Ocean and 1 Atlantic Ocean)
Zimbabwe:
general assessment: system was once one of the best in
Africa, but now suffers from poor maintenance; more than 100,000
outstanding requests for connection despite an equally large number
of installed but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: satellite earth stations - 2 Intelsat; two
international digital gateway exchanges (in Harare and Gweru)
Taiwan:
general assessment: provides telecommunications service for
every business and private need
domestic: thoroughly modern; completely digitalized
international: satellite earth stations - 2 Intelsat (1 Pacific
Ocean and 1 Indian Ocean); submarine cables to Japan (Okinawa),
Philippines, Guam, Singapore, Hong Kong, Indonesia, Australia,
Middle East, and Western Europe (1999)
======================================================================
@Telephones - main lines in use
Afghanistan:
29,000 (1996)
note: there were 21,000 main lines in service in Kabul in 1998
Albania:
87,000 (1997)
Algeria:
2.3 million (1998)
American Samoa:
13,000 (1997)
Andorra:
32,946 (December 1998)
Angola:
62,000 (1997)
Anguilla:
5,000 (1997)
Antarctica:
0
note: information for US bases only (2001)
Antigua and Barbuda:
28,000 (1996)
Argentina:
7.5 million (1998)
Armenia:
568,000 (1997)
Aruba:
33,000 (1997)
Australia:
9.58 million (1998)
Austria:
4 million (3,600,000 analog main lines plus 400,000 ISDN or
Integrated Services Digital Network connections) (1999)
Azerbaijan:
663,000 (1997)
Bahamas, The:
96,000 (1997)
Bahrain:
152,000 (1997)
Bangladesh:
500,000 (2000)
Barbados:
108,000 (1997)
Belarus:
2.313 million (1997)
Belgium:
4.769 million (1997)
Belize:
31,000 (1997)
Benin:
36,000 (1997)
Bermuda:
52,000 (1997)
Bhutan:
6,000 (1997)
Bolivia:
327,600 (1996)
Bosnia and Herzegovina:
303,000 (1997)
Botswana:
86,000 (1997)
Brazil:
17.039 million (1997)
British Indian Ocean Territory:
NA
British Virgin Islands:
10,000 (1996)
Brunei:
79,000 (1996)
Bulgaria:
3.255 million (2000)
Burkina Faso:
36,000 (1997)
Burma:
250,000 (2000)
Burundi:
16,000 (1997)
Cambodia:
21,800 (mid-1998)
Cameroon:
75,000 (1997)
Canada:
18.5 million (1999)
Cape Verde:
45,644 (2000)
Cayman Islands:
19,000 (1995)
Central African Republic:
10,000 (1997)
Chad:
7,000 (1997)
Chile:
2.603 million (1998)
China:
135 million (2000)
Christmas Island:
NA
Cocos (Keeling) Islands:
NA (1999)
Colombia:
5,433,565 (December 1997)
Comoros:
6,000 (1997)
Congo, Democratic Republic of the:
21,000 (1997)
Congo, Republic of the:
22,000 (1997)
Cook Islands:
5,000 (1997)
Costa Rica:
450,000 (1998)
note: 584,000 installed in 1997, but only about 450,000 were in use
1998
Cote d''Ivoire:
219,283 (31 December 1999)
Croatia:
1.488 million (1997)
Cuba:
473,031 (2000)
Cyprus:
Greek Cypriot area: 405,000 (1998); Turkish Cypriot area:
83,162 (1998)
Czech Republic:
3.869 million (2000)
Denmark:
4.785 million (1997)
Djibouti:
8,000 (1997)
Dominica:
19,000 (1996)
Dominican Republic:
709,000 (1997)
Ecuador:
899,000 (1997)
Egypt:
3,971,500 (December 1998)
El Salvador:
380,000 (1998)
Equatorial Guinea:
4,000 (1996)
Eritrea:
23,578 (2000)
Estonia:
476,078 (yearend 1998)
Ethiopia:
157,000 (1997)
Falkland Islands (Islas Malvinas):
NA
Faroe Islands:
24,851 (1999)
Fiji:
72,000 (1997)
Finland:
2.861 million (1997)
France:
34.86 million (yearend 1998)
French Guiana:
47,000 (1997)
French Polynesia:
52,000 (1997)
Gabon:
37,000 (1997)
Gambia, The:
31,900 (2000)
Gaza Strip:
95,729 (total for Gaza Strip and West Bank) (1997)
Georgia:
620,000 (1997)
Germany:
45.2 million (1997)
note: 46.5 million main lines were installed by yearend 1998
Ghana:
200,000 (1998)
Gibraltar:
19,000 (1997)
Greece:
5.431 million (1997)
Greenland:
25,617 (end 1999)
Grenada:
27,000 (1997)
Guadeloupe:
171,000 (1996)
Guam:
84,134 (1998)
Guatemala:
665,061 (June 2000)
Guernsey:
44,000 (1996)
Guinea:
20,000 (1997)
Guinea-Bissau:
8,000 (1997)
Guyana:
70,000 (2000)
Haiti:
60,000 (1997)
Holy See (Vatican City):
NA
Honduras:
234,000 (1997)
Hong Kong:
3.839 million (1999)
Hungary:
3.095 million (1997)
Iceland:
168,000 (1997)
India:
27.7 million (October 2000)
Indonesia:
5,588,310 (1998)
Iran:
6.313 million (1997)
Iraq:
675,000 (1997)
Ireland:
1.59 million (2001)
Israel:
2.8 million (1999)
Italy:
25 million (1999)
Jamaica:
353,000 (1996)
Japan:
60.381 million (1997)
Jersey:
65,500 (1997)
Jordan:
403,000 (1997)
Kazakhstan:
1.818 million (1997)
Kenya:
290,000 (1998)
Kiribati:
2,000 (1997)
Korea, North:
1.1 million (1997)
Korea, South:
24 million (1999)
Kuwait:
412,000 (1997)
Kyrgyzstan:
351,000 (1997)
Laos:
25,000 (1997)
Latvia:
748,000 (1997)
Lebanon:
700,000 (1999)
Lesotho:
20,000 (1997)
Liberia:
6,000 (1997)
Libya:
380,000 (1996)
Liechtenstein:
20,000 (1997)
Lithuania:
1.048 million (1997)
Luxembourg:
314,700 (1999)
Macau:
176,837 (2000)
Macedonia, The Former Yugoslav Republic of:
408,000 (1997)
Madagascar:
43,000 (1997)
Malawi:
37,000 (1997)
Malaysia:
4.5 million (1999)
Maldives:
21,000 (1999)
Mali:
23,000 (1997)
Malta:
187,000 (1997)
Man, Isle of:
51,000 (1999)
Marshall Islands:
3,000 (1996)
Martinique:
170,000 (1997)
Mauritania:
26,000 (2000)
Mauritius:
223,000 (1997)
Mayotte:
9,314 (1997)
Mexico:
9.6 million (1998)
Micronesia, Federated States of:
11,000 (2001)
Moldova:
627,000 (1997)
Monaco:
31,027 (1995)
Mongolia:
104,100 (1999)
Montserrat:
4,000 (1997)
Morocco:
1.391 million (1998)
Mozambique:
65,354 (2000)
Namibia:
100,848 (1997)
Nauru:
2,000 (1996)
Nepal:
236,816 (January 2000)
Netherlands:
9,132,400 (1999)
Netherlands Antilles:
76,000 (1995)
New Caledonia:
47,000 (1997)
New Zealand:
1.84 million (1997)
Nicaragua:
140,000 (1996)
Niger:
16,000 (1997)
Nigeria:
500,000 (2000)
Niue:
376 (1991)
Norfolk Island:
1,087 (1983)
Northern Mariana Islands:
21,000 (1996)
Norway:
2.735 million (1998)
Oman:
201,000 (1997)
Pakistan:
2.861 million (March 1999)
Palau:
1,500 (1988)
Panama:
396,000 (1997)
Papua New Guinea:
47,000 (1996)
Paraguay:
290,475 (2001)
Peru:
1.509 million (1998)
Philippines:
1.9 million (1997)
Pitcairn Islands:
1 (there are 17 telephones on one party line)
(1997)
Poland:
8.07 million (1998)
Portugal:
5.3 million (end 1998)
Puerto Rico:
1.322 million (1997)
Qatar:
142,000 (1997)
Reunion:
236,500 (1997)
Romania:
3.777 million (1997)
Russia:
30 million (1998)
Rwanda:
15,000 (1995)
Saint Helena:
2,000 (1997)
Saint Kitts and Nevis:
17,000 (1997)
Saint Lucia:
37,000 (1997)
Saint Pierre and Miquelon:
4,000 (1997)
Saint Vincent and the Grenadines:
20,500 (1998)
Samoa:
8,000 (1997)
San Marino:
18,000 (1998)
Sao Tome and Principe:
3,000 (1997)
Saudi Arabia:
3.1 million (1998)
Senegal:
116,000 (1997)
Seychelles:
19,635 (1997)
Sierra Leone:
17,000 (1997)
Singapore:
1.928 million (November 2000)
Slovakia:
1,934,558 (1998)
Slovenia:
722,000 (1997)
Solomon Islands:
8,000 (1997)
Somalia:
NA
South Africa:
5.075 million (1999)
Spain:
17.336 million (1999)
Sri Lanka:
494,509 (1998)
Sudan:
400,000 (2000)
Suriname:
64,000 (1997)
Svalbard:
NA
Swaziland:
33,500 (2000)
Sweden:
6.017 million (December 1998)
Switzerland:
4.82 million (1998)
Syria:
1.313 million (1997)
Tajikistan:
363,000 (1997)
Tanzania:
127,000 (1998)
Thailand:
5.4 million (1998)
Togo:
25,000 (1997)
Tokelau:
NA
Tonga:
8,000 (1996)
Trinidad and Tobago:
243,000 (1997)
Tunisia:
654,000 (1997)
Turkey:
19.5 million (1999)
Turkmenistan:
363,000 (1997)
Turks and Caicos Islands:
3,000 (1994)
Tuvalu:
1,000 (1997)
Uganda:
50,074; however, 80,868 main lines were installed (1998)
Ukraine:
9.45 million (April 1999)
United Arab Emirates:
915,223 (1998)
United Kingdom:
34.878 million (1997)
United States:
194 million (1997)
Uruguay:
850,000 (2000)
Uzbekistan:
1.98 million (1999)
Vanuatu:
4,000 (1996)
Venezuela:
2,600,000.00; however, 3,500,000 were installed (1998)
Vietnam:
2.6 million (2000)
Virgin Islands:
62,000 (1997)
Wallis and Futuna:
1,125 (1994)
West Bank:
95,729 (total for West Bank and Gaza Strip) (1997)
Western Sahara:
about 2,000 (1999 est.)
World:
NA
Yemen:
291,359 (1999)
Yugoslavia:
2.017 million (1995)
Zambia:
77,935 (in addition there are about 40,000 fixed telephones
in wireless local loop connections) (1997)
Zimbabwe:
212,000 (in addition there are about 20,000 fixed
telephones in wireless local loop connections) (1997)
Taiwan:
12.49 million (September 2000)
======================================================================
@Telephones - mobile cellular
Afghanistan:
NA
Albania:
3,100 (1999)
Algeria:
33,500 (1999)
American Samoa:
2,550 (1997)
Andorra:
14,117 (December 1998)
Angola:
7,052 (1997)
Anguilla:
NA
Antarctica:
NA
Antigua and Barbuda:
1,300 (1996)
Argentina:
3 million (December 1999)
Armenia:
6,220 (1997)
Aruba:
3,402 (1997)
Australia:
6.4 million (1998)
Austria:
4.5 million (2000)
Azerbaijan:
40,000 (1997)
Bahamas, The:
6,152 (1997)
Bahrain:
58,543 (1997)
Bangladesh:
283,000 (2000)
Barbados:
8,013 (1997)
Belarus:
8,167 (1997)
Belgium:
974,494 (1997)
Belize:
3,023 (1997)
Benin:
4,295 (1997)
Bermuda:
7,980 (1996)
Bhutan:
NA
Bolivia:
116,000 (1997)
Bosnia and Herzegovina:
9,000 (1997)
Botswana:
NA
Brazil:
4.4 million (1997)
British Virgin Islands:
NA
Brunei:
43,524 (1996)
Bulgaria:
596,000 (2000)
Burkina Faso:
1,503 (1997)
Burma:
8,492 (1997)
Burundi:
619 (1997)
Cambodia:
80,000 (2000)
Cameroon:
4,200 (1997)
Canada:
4.207 million (1997)
Cape Verde:
19,729 (1997)
Cayman Islands:
2,534 (1995)
Central African Republic:
570 (1997)
Chad:
NA
Chile:
944,225 (1998)
China:
65 million (January 2001)
Christmas Island:
0 (1999)
Cocos (Keeling) Islands:
0 (1999)
Colombia:
1,800,229 (December 1998)
Comoros:
NA
Congo, Democratic Republic of the:
8,900 (1997)
Congo, Republic of the:
1,000 (1996)
Cook Islands:
0 (1994)
Costa Rica:
143,000 (2000)
Cote d''Ivoire:
322,500 (May 2000)
Croatia:
187,000 (yearend 1998)
Cuba:
2,994 (1997)
Cyprus:
Greek Cypriot area: 68,000 (1998); Turkish Cypriot area:
70,000 (1999)
Czech Republic:
4.346 million (2000)
Denmark:
1,444,016 (1997)
Djibouti:
203 (1997)
Dominica:
461 (1996)
Dominican Republic:
130,149 (1997)
Ecuador:
160,061 (1997)
Egypt:
380,000 (1999)
El Salvador:
40,163 (1997)
Equatorial Guinea:
NA
Eritrea:
NA
Estonia:
475,000 (yearend 2000)
Ethiopia:
4,000 (1999)
Falkland Islands (Islas Malvinas):
NA
Faroe Islands:
10,761 (1999)
Fiji:
5,200 (1997)
Finland:
2,162,574 (1997)
France:
11.078 million (yearend 1998)
French Guiana:
NA
French Polynesia:
5,427 (1997)
Gabon:
9,500 (1997)
Gambia, The:
5,624 (2000)
Gaza Strip:
NA
Georgia:
30,000 (1997)
Germany:
15.318 million (April 1999)
Ghana:
30,000 (yearend 1998)
Gibraltar:
1,620 (1997)
Greece:
937,700 (1997)
Greenland:
12,676 (end 1999)
Grenada:
976 (1997)
Guadeloupe:
NA
Guam:
55,000 (1998)
Guatemala:
663,296 (September 2000)
Guernsey:
12,000 (1997)
Guinea:
2,868 (1997)
Guinea-Bissau:
NA
Guyana:
6,100 (2000)
Haiti:
0 (1995)
Holy See (Vatican City):
NA
Honduras:
14,427 (1997)
Hong Kong:
3.7 million (December 1999)
Hungary:
1.269 million (July 1999)
Iceland:
65,746 (1997)
India:
2.93 million (November 2000)
Indonesia:
1.07 million (1998)
Iran:
265,000 (August 1998)
Iraq:
NA; service available in northern Iraq (2001)
Ireland:
2 million (2001)
Israel:
2.5 million (1999)
Italy:
20.5 million (1999)
Jamaica:
54,640 (1996)
Japan:
63.88 million (2000)
Jersey:
4,400 (1997)
Jordan:
11,500 (1995)
Kazakhstan:
11,202 (1997)
Kenya:
5,345 (1997)
Kiribati:
NA
Korea, North:
NA
Korea, South:
27 million (June 2000)
Kuwait:
210,000 (1997)
Kyrgyzstan:
NA
Laos:
4,915 (1997)
Latvia:
77,100 (1997)
Lebanon:
580,000 (1999)
Lesotho:
1,262 (1996)
Liberia:
0 (1995)
Libya:
NA
Liechtenstein:
NA
Lithuania:
297,500 (November 1998)
Luxembourg:
215,741 (2000)
Macau:
120,957 (2000)
Macedonia, The Former Yugoslav Republic of:
12,362 (1997)
Madagascar:
4,000 (1997)
Malawi:
7,000 (1997)
Malaysia:
2.698 million (1999)
Maldives:
1,290 (1997)
Mali:
2,842 (1997)
Malta:
17,691 (1997)
Man, Isle of:
NA
Marshall Islands:
365 (1996)
Martinique:
15,000 (1997)
Mauritania:
NA
Mauritius:
37,000 (1997)
Mayotte:
0 (2000)
Mexico:
2.02 million (1998)
Micronesia, Federated States of:
NA
Moldova:
2,200 (1997)
Monaco:
NA
Mongolia:
110,000 (2001)
Montserrat:
70 (1994)
Morocco:
116,645 (1998)
Mozambique:
18,500 (2000)
Namibia:
NA
Nauru:
450 (1994)
Nepal:
NA
Netherlands:
4,081,891 (April 1999)
Netherlands Antilles:
13,977 (1996)
New Caledonia:
13,040 (1998)
New Zealand:
588,000 (1998)
Nicaragua:
7,911 (1997)
Niger:
13,000 (1995)
Nigeria:
26,700 (1997)
Niue:
0 (1991)
Norfolk Island:
0 (1983)
Northern Mariana Islands:
1,200 (1995)
Norway:
2,080,408 (1998)
Oman:
59,822 (1997)
Pakistan:
158,000 (1998)
Palau:
0 (1988)
Panama:
17,000 (1997)
Papua New Guinea:
3,053 (1996)
Paraguay:
510,000 (2001)
Peru:
504,995 (1998)
Philippines:
1.959 million (1998)
Poland:
1.78 million (1998)
Portugal:
3,074,194 (1999)
Puerto Rico:
169,265 (1996)
Qatar:
43,476 (1997)
Reunion:
85,000 (1999)
Romania:
645,500 (1999)
Russia:
2.5 million (October 2000)
Rwanda:
NA
note: however, Rwanda has mobile cellular service between Kigali
and several prefecture capitals (2000)
Saint Helena:
0 (1997)
Saint Kitts and Nevis:
205 (1997)
Saint Lucia:
1,600 (1997)
Saint Pierre and Miquelon:
0 (1994)
Saint Vincent and the Grenadines:
NA
Samoa:
1,545 (February 1998)
San Marino:
3,010 (1998)
Sao Tome and Principe:
6,942 (1997)
Saudi Arabia:
1 million
note: in 1998, the government contracted for the installation of
575,000 additional Group Speciale Mobile (GSM) cellular telephone
lines over 15 months to raise the total number of subscribers to
more than one million; Riyadh planned to further expand the GSM
system in 1999 by adding an additional one million lines (1998)
Senegal:
1,149 (1996)
Seychelles:
16,316 (1999)
Sierra Leone:
650 (1999)
Singapore:
2.333 million (November 2000)
Slovakia:
736,662 (April 1999)
Slovenia:
1 million (2000)
Solomon Islands:
658 (1997)
Somalia:
NA
South Africa:
over 2,000,000 (1999)
Spain:
8.394 million (1999)
Sri Lanka:
228,604 (1999)
Sudan:
20,000 (2000)
Suriname:
4,090 (1997)
Svalbard:
NA
Swaziland:
30,000 (2000)
Sweden:
3.835 million (October 1998)
Switzerland:
1.967 million (1999)
Syria:
NA
Tajikistan:
2,500 (1997)
Tanzania:
30,000 (1999)
Thailand:
2.3 million (1998)
Togo:
2,995 (1997)
Tokelau:
0 (2001)
Tonga:
302 (1996)
Trinidad and Tobago:
17,411 (1997)
Tunisia:
50,000 (1998)
Turkey:
12.1 million (1999)
Turkmenistan:
4,300 (1998)
Turks and Caicos Islands:
0 (1994)
Tuvalu:
0 (1994)
Uganda:
9,000 (1998)
Ukraine:
236,000 (1998)
United Arab Emirates:
1 million (1999)
United Kingdom:
13 million (yearend 1998)
United States:
69.209 million (1998)
Uruguay:
300,000 (2000)
Uzbekistan:
26,000 (1998)
Vanuatu:
154 (1996)
Venezuela:
2 million (1998)
Vietnam:
730,155 (2000)
Virgin Islands:
2,000 (1992)
Wallis and Futuna:
0 (1994)
West Bank:
NA
Western Sahara:
0 (1999)
World:
NA
Yemen:
32,042 (2000)
Yugoslavia:
87,000 (1997)
Zambia:
6,000 (1998)
Zimbabwe:
70,000 (1999)
Taiwan:
16 million (September 2000)
======================================================================
@Television broadcast stations
Afghanistan:
at least 10 (one government run central television
station in Kabul and regional stations in nine of the 30 provinces;
the regional stations operate on a reduced schedule; also, in 1997,
there was a station in Mazar-e Sharif reaching four northern
Afghanistan provinces) (1998)
Albania:
9 (plus 264 repeaters) (1995)
Algeria:
46 (plus 216 repeaters) (1995)
American Samoa:
1 (1997)
Andorra:
0 (1997)
Angola:
7 (1999)
Anguilla:
1 (1997)
Antarctica:
1 (the US Navy Antarctic Support Group operates a cable
system with six channels for the American Forces Antarctic
Network-McMurdo)
note: information for US bases only (2000)
Antigua and Barbuda:
2 (1997)
Argentina:
42 (plus 444 repeaters) (1997)
Armenia:
4 (1998)
Aruba:
1 (1997)
Australia:
104 (1997)
Austria:
45 (plus 960 repeaters) (1995)
Azerbaijan:
2 (1997)
Bahamas, The:
1 (1997)
Bahrain:
4 (1997)
Bangladesh:
15 (1999)
Barbados:
1 (plus two cable channels) (1997)
Belarus:
47 (plus 27 repeaters) (1995)
Belgium:
25 (plus 10 repeaters) (1997)
Belize:
2 (1997)
Benin:
2 (one privately-owned) (1997)
Bermuda:
3 (1997)
Bhutan:
0 (1997)
Bolivia:
48 (1997)
Bosnia and Herzegovina:
33 (plus 277 repeaters) (September 1995)
Botswana:
0 (1997)
Brazil:
138 (1997)
British Indian Ocean Territory:
1 (1997)
British Virgin Islands:
1 (plus one cable company) (1997)
Brunei:
2 (1997)
Bulgaria:
96 (plus 1,030 repeaters) (1995)
Burkina Faso:
1 (1997)
Burma:
2 (1998)
Burundi:
1 (1999)
Cambodia:
5 (1999)
Cameroon:
1 (1998)
Canada:
80 (plus many repeaters) (19','5f5c106d34909bb26a93b5c8782e1cae76062ee2a431898735291e2f75552ad3','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52f79e651b261049869b0704197484a7c573e7864702038b47c8410d6d3a30e2',2001,'MQ','Martinique','communications',312,'97)
Cape Verde:
1 (1997)
Cayman Islands:
NA
Central African Republic:
NA
Chad:
1 (1997)
Chile:
63 (plus 121 repeaters) (1997)
China:
3,240 (of which 209 are operated by China Central Television,
31 are provincial TV stations and nearly 3,000 are local city
stations) (1997)
Christmas Island:
NA
Cocos (Keeling) Islands:
0 (1997)
Colombia:
60 (includes seven low-power stations) (1997)
Comoros:
0 (1998)
Congo, Democratic Republic of the:
20 (1999)
Congo, Republic of the:
1 (1999)
Cook Islands:
2 (plus eight low-power repeaters) (1997)
Costa Rica:
6 (plus 11 repeaters) (1997)
Cote d''Ivoire:
14 (1999)
Croatia:
36 (plus 321 repeaters) (September 1995)
Cuba:
58 (1997)
Cyprus:
Greek Cypriot area: 4 (plus 225 low-power repeaters)
(September 1995); Turkish Cypriot area: 4 (plus 5 repeaters)
(September 1995)
Czech Republic:
150 (plus 1,434 repeaters) (2000)
Denmark:
26 (plus 51 repeaters) (1998)
Djibouti:
1 (plus 5 low-power repeaters) (1998)
Dominica:
0 (however, there is one cable television company) (1997)
Dominican Republic:
25 (1997)
Ecuador:
15 (including one station on the Galapagos Islands) (1997)
Egypt:
98 (September 1995)
El Salvador:
5 (1997)
Equatorial Guinea:
1 (1997)
Eritrea:
1 (2000)
Estonia:
31 (plus five repeaters) (September 1995)
Ethiopia:
25 (1999)
Falkland Islands (Islas Malvinas):
2 (operated by the British Forces
Broadcasting Service) (1997)
Faroe Islands:
3 (plus 43 low-power repeaters) (September 1995)
Fiji:
NA
Finland:
130 (plus 385 repeaters) (1995)
France:
584 (plus 9,676 repeaters) (1995)
French Guiana:
3 (plus eight low-power repeaters) (1997)
French Polynesia:
7 (plus 17 low-power repeaters) (1997)
Gabon:
4 (plus five low-power repeaters) (1997)
Gambia, The:
1 (government-owned) (1997)
Gaza Strip:
2 (operated by the Palestinian Broadcasting Corporation)
(1997)
Georgia:
12 (plus repeaters) (1998)
Germany:
373 (plus 8,042 repeaters) (1995)
Ghana:
11 (1999)
Gibraltar:
1 (plus three low-power repeaters) (1997)
Greece:
36 (plus 1,341 low-power repeaters); also two stations in
the US Armed Forces Radio and Television Service (1995)
Greenland:
1 publicly-owned station, some local low-power stations,
and three AFRTS (US Air Force) stations (1997)
Grenada:
2 (1997)
Guadeloupe:
5 (plus several low-power repeaters) (1997)
Guam:
5 (1997)
Guatemala:
26 (plus 27 repeaters) (1997)
Guernsey:
1 (1997)
Guinea:
6 (1997)
Guinea-Bissau:
2 (1997)
Guyana:
3 (one public station; two private stations which relay US
satellite services) (1997)
Haiti:
2 (plus a cable TV service) (1997)
Holy See (Vatican City):
1 (1996)
Honduras:
11 (plus 17 repeaters) (1997)
Hong Kong:
4 (plus two repeaters) (1997)
Hungary:
35 (plus 161 low-power repeaters) (1995)
Iceland:
14 (plus 156 low-power repeaters) (1997)
India:
562 (of which 82 stations have 1 kW or greater power and 480
stations have less than 1 kW of power) (1997)
Indonesia:
41 (1999)
Iran:
28 (plus 450 low-power repeaters) (1997)
Iraq:
13 (1997)
Ireland:
4 (many low-power repeaters) (2001)
Israel:
17 (plus 36 low-power repeaters) (1995)
Italy:
358 (plus 4,728 repeaters) (1995)
Jamaica:
7 (1997)
Japan:
7,108 (plus 441 repeaters; note - in addition, US Forces are
served by 3 TV stations and 2 TV cable services) (1999)
Jersey:
1 (1997)
Johnston Atoll:
commercial satellite television system, with 16
channels (1997)
Jordan:
20 (plus 96 repeaters) (1995)
Kazakhstan:
12 (plus nine repeaters) (1998)
Kenya:
8 (1997)
Kiribati:
1 (1997)
Korea, North:
38 (1999)
Korea, South:
121 (plus 850 repeater stations and the eight-channel
American Forces Korea Network) (1999)
Kuwait:
13 (plus several satellite channels) (1997)
Kyrgyzstan:
NA (repeater stations throughout the country relay
programs from Russia, Uzbekistan, Kazakhstan, and Turkey) (1997)
Laos:
4 (1999)
Latvia:
44 (plus 31 repeaters) (1995)
Lebanon:
15 (plus 5 repeaters) (1995)
Lesotho:
1 (2000)
Liberia:
2 (plus four low-power repeaters) (2000)
Libya:
12 (plus one low-power repeater) (1998)
Liechtenstein:
NA (linked to Swiss networks) (1997)
Lithuania:
20 (plus 30 repeaters) (1995)
Luxembourg:
5 (1999)
Macau:
0 (receives Hong Kong broadcasts) (1997)
Macedonia, The Former Yugoslav Republic of:
31 (plus 166 repeaters)
(1995)
Madagascar:
1 (plus 36 repeaters) (1997)
Malawi:
1 (1999)
Malaysia:
27 (plus 15 high-power repeaters) (1999)
Maldives:
1 (1997)
Mali:
1 (plus two repeaters) (1997)
Malta:
6 (2000)
Man, Isle of:
0 (receives broadcasts from the UK and satellite)
(1999)
Marshall Islands:
3 (of which two are US military stations) (1997)
Martinique:
11 (plus nine repeaters) (1997)
Mauritania:
1 (1997)
Mauritius:
2 (plus 11 repeaters) (1997)
Mayotte:
3 (1997)
Mexico:
236 (plus repeaters) (1997)
Micronesia, Federated States of:
2 (1997)
Moldova:
1 (plus 30 repeaters) (1995)
Monaco:
5 (1998)
Mongolia:
4 (plus 18 provincial repeaters and many low powered
repeaters) (1999)
Montserrat:
1 (1997)
Morocco:
35 (plus 66 repeaters) (1995)
Mozambique:
1 (2000)
Namibia:
8 (plus about 20 low-power repeaters) (1997)
Nauru:
1 (1997)
Nepal:
1 (plus 9 repeaters) (1998)
Netherlands:
21 (plus 26 repeaters) (1995)
Netherlands Antilles:
3 (there is also a cable service which
supplies programs received from various US satellite networks and
two Venezuelan channels) (1997)
New Caledonia:
6 (plus 25 low-power repeaters) (1997)
New Zealand:
41 (plus 52 medium-power repeaters and over 650
low-power repeaters) (1997)
Nicaragua:
3 (plus seven low-power repeaters) (1997)
Niger:
10 (plus seven low-power repeaters) (1997)
Nigeria:
2 government-controlled; note - in addition, in 1993, 14
licenses to operate private television stations were granted (1999)
Niue:
1 (1997)
Norfolk Island:
1 (local programming station plus two repeaters that
bring in Australian programs by satellite) (1998)
Northern Mariana Islands:
1 (on Saipan and one station planned for
Rota; in addition, two cable services on Saipan provide varied
programming from satellite networks) (1997)
Norway:
360 (plus 2,729 repeaters) (1995)
Oman:
13 (plus 25 low-power repeaters) (1999)
Pakistan:
22 (plus seven low-power repeaters) (1997)
Palau:
1 (1997)
Panama:
38 (including repeaters) (1998)
Papua New Guinea:
3 (1997)
Paraguay:
4 (2001)
Peru:
13 (plus 112 repeaters) (1997)
Philippines:
31 (1997)
Pitcairn Islands:
0 (1997)
Poland:
179 (plus 256 repeaters) (September 1995)
Portugal:
62 (plus 166 repeaters)
note: includes Azores and Madeira Islands (1995)
Puerto Rico:
18 (plus three stations of the US Armed Forces Radio
and Television Service) (1997)
Qatar:
2 (plus three repeaters) (1997)
Reunion:
22 (plus 18 low-power repeaters) (1997)
Romania:
48 (plus 392 repeaters) (1995)
Russia:
7,306 (1998)
Rwanda:
2 (1997)
Saint Helena:
0 (1997)
Saint Kitts and Nevis:
1 (plus three repeaters) (1997)
Saint Lucia:
3 (of which two are commercial stations and one is a
community antenna television or CATV channel) (1997)
Saint Pierre and Miquelon:
0 (there are, however, two repeaters
which rebroadcast programs from France, Canada, and the US) (1997)
Saint Vincent and the Grenadines:
1 (plus three repeaters) (1997)
Samoa:
6 (1997)
San Marino:
1 (San Marino residents also receive broadcasts from
Italy) (1997)
Sao Tome and Principe:
2 (1997)
Saudi Arabia:
117 (1997)
Senegal:
1 (1997)
Seychelles:
2 (plus 9 repeaters) (1997)
Sierra Leone:
2 (1999)
Singapore:
6 (2000)
Slovakia:
38 (plus 864 repeaters) (1995)
Slovenia:
48 (2001)
Solomon Islands:
0 (1997)
Somalia:
1 (1997)
South Africa:
556 (plus 144 network repeaters) (1997)
South Georgia and the South Sandwich Islands:
0 (1997)
Spain:
224 (plus 2,105 repeaters)
note: these figures include 11 television broadcast stations and 88
repeaters in the Canary Islands (1995)
Sri Lanka:
21 (1997)
Sudan:
3 (1997)
Suriname:
3 (plus seven repeaters) (2000)
Svalbard:
NA
Swaziland:
10 (2000)
Sweden:
169 (plus 1,299 repeaters) (1995)
Switzerland:
115 (plus 1,919 repeaters) (1995)
Syria:
44 (plus 17 repeaters) (1995)
Tajikistan:
0 (there are, however, repeaters that relay programs
from Russia, Iran, and Turkey) (1997)
Tanzania:
3 (1999)
Thailand:
5 (all in Bangkok; plus 131 repeaters) (1997)
Togo:
3 (plus two repeaters) (1997)
Tokelau:
NA
Tonga:
1 (2001)
Trinidad and Tobago:
4 (1997)
Tunisia:
26 (plus 76 repeaters) (1995)
Turkey:
635 (plus 2,934 repeaters) (1995)
Turkmenistan:
3 (much programming relayed from Russia and Turkey)
(1997)
Turks and Caicos Islands:
0 (broadcasts from The Bahamas are
received; cable television is established) (1997)
Tuvalu:
0 (1997)
Uganda:
8 (plus one low-power repeater) (1999)
Ukraine:
at least 33 (plus 21 repeaters that relay broadcasts from
Russia) (1997)
United Arab Emirates:
15 (1997)
United Kingdom:
228 (plus 3,523 repeaters) (1995)
United States:
more than 1,500 (including nearly 1,000 stations
affiliated with the five major networks - NBC, ABC, CBS, FOX, and
PBS; in addition, there are about 9,000 cable TV systems) (1997)
Uruguay:
26 (plus ten low-power repeaters for the Montevideo
station) (1997)
Uzbekistan:
4 (plus two repeaters that relay Russian, Kazakh,
Kyrgyz, and Tadzhik programs) (1997)
Vanuatu:
1 (1997)
Venezuela:
66 (plus 45 repeaters) (1997)
Vietnam:
at least 7 (plus 13 repeaters) (1998)
Virgin Islands:
2 (1997)
Wake Island:
0 (1997)
Wallis and Futuna:
2 (2000)
West Bank:
NA
Western Sahara:
NA
World:
NA
Yemen:
7 (plus several low-power repeaters) (1997)
Yugoslavia:
more than 771 (including 86 strong stations and 685
low-power stations, plus 20 repeaters in the principal networks;
also numerous local or private stations in Serbia and Vojvodina)
(1997)
Zambia:
9 (1997)
Zimbabwe:
16 (1997)
Taiwan:
29 (plus two repeaters) (1997)
======================================================================
@Televisions
Afghanistan:
100,000 (1999)
Albania:
405,000 (1997)
Algeria:
3.1 million (1997)
American Samoa:
14,000 (1997)
Andorra:
27,000 (1997)
Angola:
150,000 (1997)
Anguilla:
1,000 (1997)
Antarctica:
several hundred at McMurdo Sound
note: information for US bases only (2001)
Antigua and Barbuda:
31,000 (1997)
Argentina:
7.95 million (1997)
Armenia:
825,000 (1997)
Aruba:
20,000 (1997)
Australia:
10.15 million (1997)
Austria:
4.25 million (1997)
Azerbaijan:
170,000 (1997)
Bahamas, The:
67,000 (1997)
Bahrain:
275,000 (1997)
Bangladesh:
770,000 (1997)
Barbados:
76,000 (1997)
Belarus:
2.52 million (1997)
Belgium:
4.72 million (1997)
Belize:
41,000 (1997)
Benin:
60,000 (1997)
Bermuda:
66,000 (1997)
Bhutan:
11,000 (1997)
Bolivia:
900,000 (1997)
Bosnia and Herzegovina:
NA
Botswana:
31,000 (1997)
Brazil:
36.5 million (1997)
British Indian Ocean Territory:
NA
British Virgin Islands:
4,000 (1997)
Brunei:
201,900 (1998)
Bulgaria:
3.31 million (1997)
Burkina Faso:
100,000 (1997)
Burma:
320,000 (2000)
Burundi:
25,000 (1997)
Cambodia:
94,000 (1997)
Cameroon:
450,000 (1997)
Canada:
21.5 million (1997)
Cape Verde:
2,000 (1997)
Cayman Islands:
7,000 (1997)
Central African Republic:
18,000 (1997)
Chad:
10,000 (1997)
Chile:
3.15 million (1997)
China:
400 million (1997)
Christmas Island:
600 (1997)
Cocos (Keeling) Islands:
NA
Colombia:
4.59 million (1997)
Comoros:
1,000 (1997)
Congo, Democratic Republic of the:
6.478 million (1997)
Congo, Republic of the:
33,000 (1997)
Cook Islands:
4,000 (1997)
Costa Rica:
525,000 (1997)
Cote d''Ivoire:
900,000 (1997)
Croatia:
1.22 million (1997)
Cuba:
2.64 million (1997)
Cyprus:
Greek Cypriot area: 248,000 (1997); Turkish Cypriot area:
52,300 (1994)
Czech Republic:
3,405,834 (December 2000)
Denmark:
3.121 million (1997)
Djibouti:
28,000 (1997)
Dominica:
6,000 (1997)
Dominican Republic:
770,000 (1997)
Ecuador:
1.55 million (1997)
Egypt:
7.7 million (1997)
El Salvador:
600,000 (1990)
Equatorial Guinea:
4,000 (1997)
Eritrea:
1,000 (1997)
Estonia:
605,000 (1997)
Ethiopia:
320,000 (1997)
Falkland Islands (Islas Malvinas):
1,000 (1997)
Faroe Islands:
15,000 (1997)
Fiji:
21,000 (1997)
Finland:
3.2 million (1997)
France:
34.8 million (1997)
French Guiana:
30,000 (1997)
French Polynesia:
40,000 (1997)
Gabon:
63,000 (1997)
Gambia, The:
5,000 (2000)
Gaza Strip:
NA; note - most Palestinian households have televisions
(1997)
Georgia:
2.57 million (1997)
Germany:
51.4 million (1998)
Ghana:
1.73 million (1997)
Gibraltar:
10,000 (1997)
Greece:
2.54 million (1997)
Greenland:
30,000 (1998 est.)
Grenada:
33,000 (1997)
Guadeloupe:
118,000 (1997)
Guam:
106,000 (1997)
Guatemala:
1.323 million (1997)
Guernsey:
NA
Guinea:
85,000 (1997)
Guinea-Bissau:
NA
Guyana:
46,000 (1997)
Haiti:
38,000 (1997)
Holy See (Vatican City):
NA
Honduras:
570,000 (1997)
Hong Kong:
1.84 million (1997)
Hungary:
4.42 million (1997)
Iceland:
98,000 (1997)
India:
63 million (1997)
Indonesia:
13.75 million (1997)
Iran:
4.61 million (1997)
Iraq:
1.75 million (1997)
Ireland:
1.82 million (2001)
Israel:
1.69 million (1997)
Italy:
30.3 million (1997)
Jamaica:
460,000 (1997)
Japan:
86.5 million (1997)
Jersey:
NA
Jordan:
500,000 (1997)
Kazakhstan:
3.88 million (1997)
Kenya:
730,000 (1997)
Kiribati:
1,000 (1997)
Korea, North:
1.2 million (1997)
Korea, South:
15.9 million (1997)
Kuwait:
875,000 (1997)
Kyrgyzstan:
210,000 (1997)
Laos:
52,000 (1997)
Latvia:
1.22 million (1997)
Lebanon:
1.18 million (1997)
Lesotho:
54,000 (1997)
Liberia:
70,000 (1997)
Libya:
730,000 (1997)
Liechtenstein:
12,000 (1997)
Lithuania:
1.7 million (1997)
Luxembourg:
285,000 (1998 est.)
Macau:
49,000 (1997)
Macedonia, The Former Yugoslav Republic of:
510,000 (1997)
Madagascar:
325,000 (1997)
Malawi:
0 (1999)
Malaysia:
10.8 million (1999)
Maldives:
10,000 (1999)
Mali:
45,000 (1997)
Malta:
280,000 (1997)
Man, Isle of:
27,490 (1999)
Marshall Islands:
NA
Martinique:
66,000 (1997)
Mauritania:
87,000 (1998)
Mauritius:
258,000 (1997)
Mayotte:
3,500 (1994)
Mexico:
25.6 million (1997)
Micronesia, Federated States of:
NA
Moldova:
1.26 million (1997)
Monaco:
25,000 (1997)
Mongolia:
168,800 (1999)
Montserrat:
3,000 (1997)
Morocco:
3.1 million (1997)
Mozambique:
67,600 (2000)
Namibia:
60,000 (1997)
Nauru:
500 (1997)
Nepal:
130,000 (1997)
Netherlands:
8.1 million (1997)
Netherlands Antilles:
69,000 (1997)
New Caledonia:
52,000 (1997)
New Zealand:
1.926 million (1997)
Nicaragua:
320,000 (1997)
Niger:
125,000 (1997)
Nigeria:
6.9 million (1997)
Niue:
NA
Norfolk Island:
1,200 (1996)
Northern Mariana Islands:
NA
Norway:
2.03 million (1997)
Oman:
1.6 million (1997)
Pakistan:
3.1 million (1997)
Palau:
11,000 (1997)
Panama:
510,000 (1997)
Papua New Guinea:
42,000 (1997)
Paraguay:
990,000 (2001)
Peru:
3.06 million (1997)
Philippines:
3.7 million (1997)
Pitcairn Islands:
NA
Poland:
13.05 million (1997)
Portugal:
3.31 million (1997)
Puerto Rico:
1.021 million (1997)
Qatar:
230,000 (1997)
Reunion:
127,000 (1997)
Romania:
5.25 million (1997)
Russia:
60.5 million (1997)
Rwanda:
NA; probably less than 1,000 (1997)
Saint Helena:
2,000 (1997)
Saint Kitts and Nevis:
10,000 (1997)
Saint Lucia:
32,000 (1997)
Saint Pierre and Miquelon:
4,000 (1997)
Saint Vincent and the Grenadines:
18,000 (1997)
Samoa:
11,000 (1997)
San Marino:
9,000 (1997)
Sao Tome and Principe:
23,000 (1997)
Saudi Arabia:
5.1 million (1997)
Senegal:
361,000 (1997)
Seychelles:
11,000 (1997)
Sierra Leone:
53,000 (1997)
Singapore:
1.33 million (1997)
Slovakia:
2.62 million (1997)
Slovenia:
710,000 (1997)
Solomon Islands:
3,000 (1997)
Somalia:
135,000 (1997)
South Africa:
5.2 million (1997)
Spain:
16.2 million (1997)
Sri Lanka:
1.53 million (1997)
Sudan:
2.38 million (1997)
Suriname:
63,000 (1997)
Svalbard:
NA
Swaziland:
21,000 (1997)
Sweden:
4.6 million (1997)
Switzerland:
3.31 million (1997)
Syria:
1.05 million (1997)
Tajikistan:
860,000 (1991)
Tanzania:
103,000 (1997)
Thailand:
15.19 million (1997)
Togo:
73,000 (1997)
Tokelau:
NA
Tonga:
2,000 (1997)
Trinidad and Tobago:
425,000 (1997)
Tunisia:
920,000 (1997)
Turkey:
20.9 million (1997)
Turkmenistan:
820,000 (1997)
Turks and Caicos Islands:
NA
Tuvalu:
800
Uganda:
315,000 (1997)
Ukraine:
18.05 million (1997)
United Arab Emirates:
310,000 (1997)
United Kingdom:
30.5 million (1997)
United States:
219 million (1997)
Uruguay:
782,000 (1997)
Uzbekistan:
6.4 million (1997)
Vanuatu:
2,000 (1997)
Venezuela:
4.1 million (1997)
Vietnam:
3.57 million (1997)
Virgin Islands:
68,000 (1997)
Wallis and Futuna:
NA
West Bank:
NA; note - many Palestinian households have televisions
(1999)
Western Sahara:
6,000 (1997)
World:
NA
Yemen:
470,000 (1997)
Yugoslavia:
2.75 million (1997)
Zambia:
277,000 (1997)
Zimbabwe:
370,000 (1997)
Taiwan:
8.8 million (1998)
======================================================================
@Terrain
Afghanistan:
mostly rugged mountains; plains in north and southwest
Albania:
mostly mountains and hills; small plains along coast
Algeria:
mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
American Samoa:
five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls (Rose Island, Swains Island)
Andorra:
rugged mountains dissected by narrow valleys
Angola:
narrow coastal plain rises abruptly to vast interior plateau
Anguilla:
flat and low-lying island of coral and limestone
Antarctica:
about 98% thick continental ice sheet and 2% barren
rock, with average elevations between 2,000 and 4,000 meters;
mountain ranges up to 5,140 meters; ice-free coastal areas include
parts of southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the coastline, and floating ice
shelves constitute 11% of the area of the continent
Antigua and Barbuda:
mostly low-lying limestone and coral islands,
with some higher volcanic areas
Arctic Ocean:
central surface covered by a perennial drifting polar
icepack that averages about 3 meters in thickness, although pressure
ridges may be three times that size; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight-line movement from the
New Siberian Islands (Russia) to Denmark Strait (between Greenland
and Iceland); the icepack is surrounded by open seas during the
summer, but more than doubles in size during the winter and extends
to the encircling landmasses; the ocean floor is about 50%
continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonosov Ridge)
Argentina:
rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western
border
Armenia:
Armenian Highland with mountains; little forest land; fast
flowing rivers; good soil in Aras River valley
Aruba:
flat with a few hills; scant vegetation
Ashmore and Cartier Islands:
low with sand and coral
Atlantic Ocean:
surface usually covered with sea ice in Labrador
Sea, Denmark Strait, and Baltic Sea from October to June; clockwise
warm-water gyre (broad, circular system of currents) in the northern
Atlantic, counterclockwise warm-water gyre in the southern Atlantic;
the ocean floor is dominated by the Mid-Atlantic Ridge, a rugged
north-south centerline for the entire Atlantic basin
Australia:
mostly low plateau with deserts; fertile plain in
southeast
Austria:
in the west and south mostly mountains (Alps); along the
eastern and northern margins mostly flat or gently sloping
Azerbaijan:
large, flat Kur-Araz Ovaligi (Kura-Araks Lowland) (much
of it below sea level) with Great Caucasus Mountains to the north,
Qarabag Yaylasi (Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian Sea
Bahamas, The:
long, flat coral formations with some low rounded hills
Bahrain:
mostly low desert plain rising gently to low central
escarpment
Baker Island:
low, nearly level coral island surrounded by a narrow
fringing reef
Bangladesh:
mostly flat alluvial plain; hilly in southeast
Barbados:
relatively flat; rises gently to central highland region
Bassas da India:
volcanic rock
Belarus:
generally flat and contains much marshland
Belgium:
flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
Belize:
flat, swampy coastal plain; low mountains in south
Benin:
mostly flat to undulating plain; some hills and low mountains
Bermuda:
low hills separated by fertile depressions
Bhutan:
mostly mountainous with some fertile valleys and savanna
Bolivia:
rugged Andes Mountains with a highland plateau (Altiplano),
hills, lowland plains of the Amazon Basin
Bosnia and Herzegovina:
mountains and valleys
Botswana:
predominantly flat to gently rolling tableland; Kalahari
Desert in southwest
Bouvet Island:
volcanic; maximum elevation about 800 m; coast is
mostly inaccessible
Brazil:
mostly flat to rolling lowlands in north; some plains,
hills, mountains, and narrow coastal belt
British Indian Ocean Territory:
flat and low (most areas do not
exceed four meters in elevation)
British Virgin Islands:
coral islands relatively flat; volcanic
islands steep, hilly
Brunei:
flat coastal plain rises to mountains in east; hilly lowland
in west
Bulgaria:
mostly mountains with lowlands in north and southeast
Burkina Faso:
mostly flat to dissected, undulating plains; hills in
west and southeast
Burma:
central lowlands ringed by steep, rugged highlands
Burundi:
hilly and mountainous, dropping to a plateau in east, some
plains
Cambodia:
mostly low, flat plains; mountains in southwest and north
Cameroon:
diverse, with coastal plain in southwest, dissected
plateau in center, mountains in west, plains in north
Canada:
mostly plains with mountains in west and lowlands in
southeast
Cape Verde:
steep, rugged, rocky, volcanic
Cayman Islands:
low-lying limestone base surrounded by coral reefs
Central African Republic:
vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
Chad:
broad, arid plains in center, desert in north, mountains in
northwest, lowlands in south
Chile:
low coastal mountains; fertile central valley; rugged Andes
in east
China:
mostly mountains, high plateaus, deserts in west; plains,
deltas, and hills in east
Christmas Island:
steep cliffs along coast rise abruptly to central
plateau
Clipperton Island:
coral atoll
Cocos (Keeling) Islands:
flat, low-lying coral atolls
Colombia:
flat coastal lowlands, central highlands, high Andes
Mountains, eastern lowland plains
Comoros:
volcanic islands, interiors vary from steep mountains to
low hills
Congo, Democratic Republic of the:
vast central basin is a low-lying
plateau; mountains in east
Congo, Republic of the:
coastal plain, southern basin, central
plateau, northern basin
Cook Islands:
low coral atolls in north; volcanic, hilly islands in
south
Coral Sea Islands:
sand and coral reefs and islands (or cays)
Costa Rica:
coastal plains separated by rugged mountains
Cote d''Ivoire:
mostly flat to undulating plains; mountains in
northwest
Croatia:
geographically diverse; flat plains along Hungarian border,
low mountains and highlands near Adriatic coastline and islands
Cuba:
mostly flat to rolling plains, with rugged hills and mountains
in the southeast
Cyprus:
central plain with mountains to north and south; scattered
but significant plains along southern coast
Czech Republic:
Bohemia in the west consists of rolling plains,
hills, and plateaus surrounded by low mountains; Moravia in the east
consists of very hilly country
Denmark:
low and flat to gently rolling plains
Djibouti:
coastal plain and plateau separated by central mountains
Dominica:
rugged mountains of volcanic origin
Dominican Republic:
rugged highlands and mountains with fertile
valleys interspersed
Ecuador:
coastal plain (costa), inter-Andean central highlands
(sierra), and flat to rolling eastern jungle (oriente)
Egypt:
vast desert plateau interrupted by Nile valley and delta
El Salvador:
mostly mountains with narrow coastal belt and central
plateau
Equatorial Guinea:
coastal plains rise to interior hills; islands
are volcanic
Eritrea:
dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
Estonia:
marshy, lowlands
Ethiopia:
high plateau with ce','297009a306be2445bc552cfdd0fd356e82b72c10dc839b1d8d5094392c269be8','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b4e56800698d213868255e20f45922dbff406a370f784d3ff73e17d21047d6c',2001,'MQ','Martinique','communications',313,'ntral mountain range divided by Great
Rift Valley
Europa Island:
low and flat
Falkland Islands (Islas Malvinas):
rocky, hilly, mountainous with
some boggy, undulating plains
Faroe Islands:
rugged, rocky, some low peaks; cliffs along most of
coast
Fiji:
mostly mountains of volcanic origin
Finland:
mostly low, flat to rolling plains interspersed with lakes
and low hills
France:
mostly flat plains or gently rolling hills in north and
west; remainder is mountainous, especially Pyrenees in south, Alps
in east
French Guiana:
low-lying coastal plains rising to hills and small
mountains
French Polynesia:
mixture of rugged high islands and low islands
with reefs
French Southern and Antarctic Lands:
volcanic
Gabon:
narrow coastal plain; hilly interior; savanna in east and
south
Gambia, The:
flood plain of the Gambia river flanked by some low
hills
Gaza Strip:
flat to rolling, sand- and dune-covered coastal plain
Georgia:
largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhet''is Dablobi
(Kolkhida Lowland) opens to the Black Sea in the west; Mtkvari River
Basin in the east; good soils in river valley flood plains,
foothills of Kolkhida Lowland
Germany:
lowlands in north, uplands in center, Bavarian Alps in south
Ghana:
mostly low plains with dissected plateau in south-central area
Gibraltar:
a narrow coastal lowland borders the Rock of Gibraltar
Glorioso Islands:
low and flat
Greece:
mostly mountains with ranges extending into the sea as
peninsulas or chains of islands
Greenland:
flat to gradually sloping icecap covers all but a narrow,
mountainous, barren, rocky coast
Grenada:
volcanic in origin with central mountains
Guadeloupe:
Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation; most of the
seven other islands are volcanic in origin
Guam:
volcanic origin, surrounded by coral reefs; relatively flat
coralline limestone plateau (source of most fresh water), with steep
coastal cliffs and narrow coastal plains in north, low-rising hills
in center, mountains in south
Guatemala:
mostly mountains with narrow coastal plains and rolling
limestone plateau (Peten)
Guernsey:
mostly level with low hills in southwest
Guinea:
generally flat coastal plain, hilly to mountainous interior
Guinea-Bissau:
mostly low coastal plain rising to savanna in east
Guyana:
mostly rolling highlands; low coastal plain; savanna in south
Haiti:
mostly rough and mountainous
Heard Island and McDonald Islands:
Heard Island - bleak and
mountainous, with a quiescent volcano; McDonald Islands - small and
rocky
Holy See (Vatican City):
low hill
Honduras:
mostly mountains in interior, narrow coastal plains
Hong Kong:
hilly to mountainous with steep slopes; lowlands in north
Howland Island:
low-lying, nearly level, sandy, coral island
surrounded by a narrow fringing reef; depressed central area
Hungary:
mostly flat to rolling plains; hills and low mountains on
the Slovakian border
Iceland:
mostly plateau interspersed with mountain peaks, icefields;
coast deeply indented by bays and fiords
India:
upland plain (Deccan Plateau) in south, flat to rolling plain
along the Ganges, deserts in west, Himalayas in north
Indian Ocean:
surface dominated by counterclockwise gyre (broad,
circular system of currents) in the southern Indian Ocean; unique
reversal of surface currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-to-northeast
winds and currents, while high pressure over northern Asia from
cold, falling, winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean floor is dominated
by the Mid-Indian Ocean Ridge and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean Ridge, and Ninetyeast Ridge
Indonesia:
mostly coastal lowlands; larger islands have interior
mountains
Iran:
rugged, mountainous rim; high, central basin with deserts,
mountains; small, discontinuous plains along both coasts
Iraq:
mostly broad plains; reedy marshes along Iranian border in
south with large flooded areas; mountains along borders with Iran
and Turkey
Ireland:
mostly level to rolling interior plain surrounded by rugged
hills and low mountains; sea cliffs on west coast
Israel:
Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
Italy:
mostly rugged and mountainous; some plains, coastal lowlands
Jamaica:
mostly mountains, with narrow, discontinuous coastal plain
Jan Mayen:
volcanic island, partly covered by glaciers
Japan:
mostly rugged and mountainous
Jarvis Island:
sandy, coral island surrounded by a narrow fringing
reef
Jersey:
gently rolling plain with low, rugged hills along north coast
Johnston Atoll:
mostly flat
Jordan:
mostly desert plateau in east, highland area in west; Great
Rift Valley separates East and West Banks of the Jordan River
Juan de Nova Island:
low and flat
Kazakhstan:
extends from the Volga to the Altai Mountains and from
the plains in western Siberia to oases and desert in Central Asia
Kenya:
low plains rise to central highlands bisected by Great Rift
Valley; fertile plateau in west
Kingman Reef:
low and nearly level
Kiribati:
mostly low-lying coral atolls surrounded by extensive reefs
Korea, North:
mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
Korea, South:
mostly hills and mountains; wide coastal plains in
west and south
Kuwait:
flat to slightly undulating desert plain
Kyrgyzstan:
peaks of Tien Shan and associated valleys and basins
encompass entire nation
Laos:
mostly rugged mountains; some plains and plateaus
Latvia:
low plain
Lebanon:
narrow coastal plain; Al Biqa'' (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
Lesotho:
mostly highland with plateaus, hills, and mountains
Liberia:
mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
Libya:
mostly barren, flat to undulating plains, plateaus,
depressions
Liechtenstein:
mostly mountainous (Alps) with Rhine Valley in
western third
Lithuania:
lowland, many scattered small lakes, fertile soil
Luxembourg:
mostly gently rolling uplands with broad, shallow
valleys; uplands to slightly mountainous in the north; steep slope
down to Moselle flood plain in the southeast
Macau:
generally flat
Macedonia, The Former Yugoslav Republic of:
mountainous territory
covered with deep basins and valleys; three large lakes, each
divided by a frontier line; country bisected by the Vardar River
Madagascar:
narrow coastal plain, high plateau and mountains in
center
Malawi:
narrow elongated plateau with rolling plains, rounded hills,
some mountains
Malaysia:
coastal plains rising to hills and mountains
Maldives:
flat, with white sandy beaches
Mali:
mostly flat to rolling northern plains covered by sand;
savanna in south, rugged hills in northeast
Malta:
mostly low, rocky, flat to dissected plains; many coastal
cliffs
Man, Isle of:
hills in north and south bisected by central valley
Marshall Islands:
low coral limestone and sand islands
Martinique:
mountainous with indented coastline; dormant volcano
Mauritania:
mostly barren, flat plains of the Sahara; some central
hills
Mauritius:
small coastal plain rising to discontinuous mountains
encircling central plateau
Mayotte:
generally undulating, with deep ravines and ancient
volcanic peaks
Mexico:
high, rugged mountains; low coastal plains; high plateaus;
desert
Micronesia, Federated States of:
islands vary geologically from high
mountainous islands to low, coral atolls; volcanic outcroppings on
Pohnpei, Kosrae, and Truk
Midway Islands:
low, nearly level
Moldova:
rolling steppe, gradual slope south to Black Sea
Monaco:
hilly, rugged, rocky
Mongolia:
vast semidesert and desert plains, grassy steppe,
mountains in west and southwest; Gobi Desert in south-central
Montserrat:
volcanic islands, mostly mountainous, with small coastal
lowland
Morocco:
northern coast and interior are mountainous with large
areas of bordering plateaus, intermontane valleys, and rich coastal
plains
Mozambique:
mostly coastal lowlands, uplands in center, high
plateaus in northwest, mountains in west
Namibia:
mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
Nauru:
sandy beach rises to fertile ring around raised coral reefs
with phosphate plateau in center
Navassa Island:
raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m high)
Nepal:
Terai or flat river plain of the Ganges in south, central
hill region, rugged Himalayas in north
Netherlands:
mostly coastal lowland and reclaimed land (polders);
some hills in southeast
Netherlands Antilles:
generally hilly, volcanic interiors
New Caledonia:
coastal plains with interior mountains
New Zealand:
predominately mountainous with some large coastal plains
Nicaragua:
extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by
volcanoes
Niger:
predominately desert plains and sand dunes; flat to rolling
plains in south; hills in north
Nigeria:
southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
Niue:
steep limestone cliffs along coast, central plateau
Norfolk Island:
volcanic formation with mostly rolling plains
Northern Mariana Islands:
southern islands are limestone with level
terraces and fringing coral reefs; northern islands are volcanic
Norway:
glaciated; mostly high plateaus and rugged mountains broken
by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
Oman:
central desert plain, rugged mountains in north and south
Pacific Ocean:
surface currents in the northern Pacific are
dominated by a clockwise, warm-water gyre (broad circular system of
currents) and in the southern Pacific by a counterclockwise,
cool-water gyre; in the northern Pacific, sea ice forms in the
Bering Sea and Sea of Okhotsk in winter; in the southern Pacific,
sea ice from Antarctica reaches its northernmost extent in October;
the ocean floor in the eastern Pacific is dominated by the East
Pacific Rise, while the western Pacific is dissected by deep
trenches, including the Mariana Trench, which is the world''s deepest
Pakistan:
flat Indus plain in east; mountains in north and
northwest; Balochistan plateau in west
Palau:
varying geologically from the high, mountainous main island
of Babelthuap to low, coral islands usually fringed by large barrier
reefs
Palmyra Atoll:
very low
Panama:
interior mostly steep, rugged mountains and dissected,
upland plains; coastal areas largely plains and rolling hills
Papua New Guinea:
mostly mountains with coastal lowlands and rolling
foothills
Paracel Islands:
mostly low and flat
Paraguay:
grassy plains and wooded hills east of Rio Paraguay; Gran
Chaco region west of Rio Paraguay mostly low, marshy plain near the
river, and dry forest and thorny scrub elsewhere
Peru:
western coastal plain (costa), high and rugged Andes in center
(sierra), eastern lowland jungle of Amazon Basin (selva)
Philippines:
mostly mountains with narrow to extensive coastal
lowlands
Pitcairn Islands:
rugged volcanic formation; rocky coastline with
cliffs
Poland:
mostly flat plain; mountains along southern border
Portugal:
mountainous north of the Tagus River, rolling plains in
south
Puerto Rico:
mostly mountains, with coastal plain belt in north;
mountains precipitous to sea on west coast; sandy beaches along most
coastal areas
Qatar:
mostly flat and barren desert covered with loose sand and
gravel
Reunion:
mostly rugged and mountainous; fertile lowlands along coast
Romania:
central Transylvanian Basin is separated from the Plain of
Moldavia on the east by the Carpathian Mountains and separated from
the Walachian Plain on the south by the Transylvanian Alps
Russia:
broad plain with low hills west of Urals; vast coniferous
forest and tundra in Siberia; uplands and mountains along southern
border regions
Rwanda:
mostly grassy uplands and hills; relief is mountainous with
altitude declining from west to east
Saint Helena:
Saint Helena - rugged, volcanic; small scattered
plateaus and plains
note: the other islands of the group have a volcanic origin
Saint Kitts and Nevis:
volcanic with mountainous interiors
Saint Lucia:
volcanic and mountainous with some broad, fertile
valleys
Saint Pierre and Miquelon:
mostly barren rock
Saint Vincent and the Grenadines:
volcanic, mountainous
Samoa:
narrow coastal plain with volcanic, rocky, rugged mountains
in interior
San Marino:
rugged mountains
Sao Tome and Principe:
volcanic, mountainous
Saudi Arabia:
mostly uninhabited, sandy desert
Senegal:
generally low, rolling, plains rising to foothills in
southeast
Seychelles:
Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
Sierra Leone:
coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
Singapore:
lowland; gently undulating central plateau contains water
catchment area and nature preserve
Slovakia:
rugged mountains in the central and northern part and
lowlands in the south
Slovenia:
a short coastal strip on the Adriatic, an alpine mountain
region adjacent to Italy and Austria, mixed mountain and valleys
with numerous rivers to the east
Solomon Islands:
mostly rugged mountains with some low coral atolls
Somalia:
mostly flat to undulating plateau rising to hills in north
South Africa:
vast interior plateau rimmed by rugged hills and
narrow coastal plain
South Georgia and the South Sandwich Islands:
most of the islands,
rising steeply from the sea, are rugged and mountainous; South
Georgia is largely barren and has steep, glacier-covered mountains;
the South Sandwich Islands are of volcanic origin with some active
volcanoes
Southern Ocean:
the Southern Ocean is deep, 4,000 to 5,000 meters
over most of its extent with only limited areas of shallow water;
the Antarctic continental shelf is generally narrow and unusually
deep - its edge lying at depths of 400 to 800 meters (the global
mean is 133 meters); the Antarctic icepack grows from an average
minimum of 2.6 million square kilometers in March to about 18.8
million square kilometers in September, better than a sixfold
increase in area; the Antarctic Circumpolar Current (21,000 km in
length) moves perpetually eastward; it is the world''s largest ocean
current, transporting 130 million cubic meters of water per second -
100 times the flow of all the world''s rivers
Spain:
large, flat to dissected plateau surrounded by rugged hills;
Pyrenees in north
Spratly Islands:
flat
Sri Lanka:
mostly low, flat to rolling plain; mountains in
south-central interior
Sudan:
generally flat, featureless plain; mountains in east and west
Suriname:
mostly rolling hills; narrow coastal plain with swamps
Svalbard:
wild, rugged mountains; much of high land ice covered;
west coast clear of ice about one-half of the year; fjords along
west and north coasts
Swaziland:
mostly mountains and hills; some moderately sloping plains
Sweden:
mostly flat or gently rolling lowlands; mountains in west
Switzerland:
mostly mountains (Alps in south, Jura in northwest)
with a central plateau of rolling hills, plains, and large lakes
Syria:
primarily semiarid and desert plateau; narrow coastal plain;
mountains in west
Tajikistan:
Pamir and Alay mountains dominate landscape; western
Fergana Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Tanzania:
plains along coast; central plateau; highlands in north,
south
Thailand:
central plain; Khorat Plateau in the east; mountains
elsewhere
Togo:
gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
Tokelau:
low-lying coral atolls enclosing large lagoons
Tonga:
most islands have limestone base formed from uplifted coral
formation; others have limestone overlying volcanic base
Trinidad and Tobago:
mostly plains with some hills and low mountains
Tromelin Island:
low, flat, and sandy
Tunisia:
mountains in north; hot, dry central plain; semiarid south
merges into the Sahara
Turkey:
mostly mountains; narrow coastal plain; high central plateau
(Anatolia)
Turkmenistan:
flat-to-rolling sandy desert with dunes rising to
mountains in the south; low mountains along border with Iran;
borders Caspian Sea in west
Turks and Caicos Islands:
low, flat limestone; extensive marshes and
mangrove swamps
Tuvalu:
very low-lying and narrow coral atolls
Uganda:
mostly plateau with rim of mountains
Ukraine:
most of Ukraine consists of fertile plains (steppes) and
plateaus, mountains being found only in the west (the Carpathians),
and in the Crimean Peninsula in the extreme south
United Arab Emirates:
flat, barren coastal plain merging into
rolling sand dunes of vast desert wasteland; mountains in east
United Kingdom:
mostly rugged hills and low mountains; level to
rolling plains in east and southeast
United States:
vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in
Alaska; rugged, volcanic topography in Hawaii
Uruguay:
mostly rolling plains and low hills; fertile coastal lowland
Uzbekistan:
mostly flat-to-rolling sandy desert with dunes; broad,
flat intensely irrigated river valleys along course of Amu Darya,
Sirdaryo (Syr Darya), and Zarafshon; Fergana Valley in east
surrounded by mountainous Tajikistan and Kyrgyzstan; shrinking Aral
Sea in west
Vanuatu:
mostly mountains of volcanic origin; narrow coastal plains
Venezuela:
Andes Mountains and Maracaibo Lowlands in northwest;
central plains (llanos); Guiana Highlands in southeast
Vietnam:
low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
Virgin Islands:
mostly hilly to rugged and mountainous with little
level land
Wake Island:
atoll of three coral islands built up on an underwater
volcano; central lagoon is former crater, islands are part of the rim
Wallis and Futuna:
volcanic origin; low hills
West Bank:
mostly rugged dissected upland, some vegetation in west,
but barren in east
Western Sahara:
mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
World:
the greatest ocean depth is the Mariana Trench at 10,924 m in
the Pacific Ocean
Yemen:
narrow coastal plain backed by flat-topped hills and rugged
mountains; dissected upland desert plains in center slope into the
desert interior of the Arabian Peninsula
Yugoslavia:
extremely varied; to the north, rich fertile plains; to
the east, limestone ranges and basins; to the southeast, ancient
mountains and hills; to the southwest, extremely high shoreline with
no islands off the coast
Zambia:
mostly high plateau with some hills and mountains
Zimbabwe:
mostly high plateau with higher central plateau (high
veld); mountains in east
Taiwan:
eastern two-thirds mostly rugged mountains; flat to gently
rolling plains in west
======================================================================
@Total fertility rate
Afghanistan:
5.79 children born/woman (2001 est.)
Albania:
2.32 children born/woman (2001 est.)
Algeria:
2.72 children born/woman (2001 est.)
American Samoa:
3.5 children born/woman (2001 est.)
Andorra:
1.25 children born/woman (2001 est.)
Angola:
6.48 children born/woman (2001 est.)
Anguilla:
1.79 children born/woman (2001 est.)
Antigua and Barbuda:
2.31 children born/woman (2001 est.)
Argentina:
2.44 children born/woman (2001 est.)
Armenia:
1.5 children born/woman (2001 est.)
Aruba:
1.8 children born/woman (2001 est.)
Australia:
1.77 children born/woman (2001 est.)
Austria:
1.39 children born/woman (2001 est.)
Azerbaijan:
2.24 children born/woman (2001 est.)
Bahamas, The:
2.3 children born/woman (2001 est.)
Bahrain:
2.79 children born/woman (2001 est.)
Bangladesh:
2.78 children born/woman (2001 est.)
Barbados:
1.64 children born/woman (2001 est.)
Belarus:
1.28 children born/woman (2001 est.)
Belgium:
1.61 children born/woman (2001 est.)
Belize:
4.05 children born/woman (2001 est.)
Benin:
6.23 children born/woman (2001 est.)
Bermuda:
1.81 children born/woman (2001 est.)
Bhutan:
5.07 children born/woman (2001 est.)
Bolivia:
3.51 children born/woman (2001 est.)
Bosnia and Herzegovina:
1.71 children born/woman (2001 est.)
Botswana:
3.7 children born/woman (2001 est.)
Brazil:
2.09 children born/woman (2001 est.)
British Virgin Islands:
1.72 children born/woman (2001 est.)
Brunei:
2.44 children born/woman (2001 est.)
Bulgaria:
1.13 children born/woman (2001 est.)
Burkina Faso:
6.35 children born/woman (2001 est.)
Burma:
2.3 children born/woman (2001 est.)
Burundi:
6.16 children born/woman (2001 est.)
Cambodia:
4.74 children born/woman (2001 est.)
Cameroon:
4.8 children born/woman (2001 est.)
Canada:
1.6 children born/woman (2001 est.)
Cape Verde:
4.05 children born/woman (2001 est.)
Cayman Islands:
2.04 children born/woman (2001 est.)
Central African Republic:
4.86 children born/woman (2001 est.)
Chad:
6.56 children born/woman (2001 est.)
Chile:
2.16 children born/woman (2001 est.)
China:
1.82 children born/woman (2001 est.)
Christmas Island:
NA children born/woman
Cocos (Keeling) Islands:
NA children born/woman
Colombia:
2.66 children born/woman (2001 est.)
Comoros:
5.32 children born/woman (2001 est.)
Congo, Democratic Republic of the:
6.84 children born/woman (2001
est.)
Congo, Republic of the:
5 children born/woman (2001 est.)
Costa Rica:
2.47 children born/woman (2001 est.)
Cote d''Ivoire:
5.7 children born/woman (2001 est.)
Croatia:
1.94 children born/woman (2001 est.)
Cuba:
1.6 children born/woman (2001 est.)
Cyprus:
1.93 children born/woman (2001 est.)
Czech Republic:
1.18 children born/woman (2001 est.)
Denmark:
1.73 children born/woman (2001 est.)
Djibouti:
5.72 children born/woman (2001 est.)
Dominica:
2.03 children born/woman (2001 est.)
Dominican Republic:
2.97 children born/woman (2001 est.)
Ecuador:
3.12 children born/woman (2001 est.)
Egypt:
3.07 children born/woman (2001 est.)
El Salvador:
3.34 children born/woman (2001 est.)
Equatorial Guinea:
4.88 children born/woman (2001 est.)
Eritrea:
5.87 children born/woman (2001 est.)
Estonia:
1.21 children born/woman (2001 est.)
Ethiopia:
7 children born/woman (2001 est.)
Falkland Islands (Islas Malvinas):
NA children born/woman
Faroe Islands:
2.3 children born/woman (2001 est.)
Fiji:
2.86 children born/woman (2001 est.)
Finland:
1.7 children born/woman (2001 est.)
France:
1.75 children born/woman (2001 est.)
French Guiana:
3.17 children born/woman (2001 est.)
French Polynesia:
2.23 children born/woman (2001 est.)
Gabon:
3.69 children born/woman (2001 est.)
Gambia, The:
5.68 children born/woman (2001 est.)
Gaza Strip:
6.42 children born/woman (2001 est.)
Georgia:
1.45 children born/woman (2001 est.)
Germany:
1.38 children born/woman (2001 est.)
Ghana:
3.82 children born/woman (2001 est.)
Gibraltar:
1.64 children born/woman (2001 est.)
Greece:
1.33 children born/woman (2001 est.)
Greenland:
2.44 children born/woman (2001 est.)
Grenada:
2.54 children born/woman (2001 est.)
Guadeloupe:
1.93 children born/woman (2001 est.)
Guam:
3.85 children born/woman (2001 est.)
Guatemala:
4.58 children born/woman (2001 est.)
Guernsey:
1.36 children born/woman (2001 est.)
Guinea:
5.39 children born/woman (2001 est.)
Guinea-Bissau:
5.2 children born/woman (2001 est.)
Guyana:
2.1 children born/woman (2001 est.)
Haiti:
4.4 children born/woman (2001 est.)
Honduras:
4.15 children born/woman (2001 est.)
Hong Kong:
1.29 children born/woman (2001 est.)
Hungary:
1.25 children born/woman (2001 est.)
Iceland:
2.01 children born/woman (2001 est.)
India:
3.04 children born/woman (2001 est.)
Indonesia:
2.58 children born/woman (2001 est.)
Iran:
2.02 children born/woman (2001 est.)
Iraq:
4.75 children born/woman (2001 est.)
Ireland:
1.9 children born/woman (2001 est.)
Israel:
2.57 children born/woman (2001 est.)
Italy:
1.18 children born/woman (2001 e','3d13db4e0156cf892874ddfcd0bb4c629572b0ad1e8a52f3aabcbfbf7860af4c','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65e8fcb0f19ed02c545b99407fb9f0915fe951fe30d30b488b58d29d5fcbb334',2001,'MQ','Martinique','communications',314,'st.)
Jamaica:
2.08 children born/woman (2001 est.)
Japan:
1.41 children born/woman (2001 est.)
Jersey:
1.56 children born/woman (2001 est.)
Jordan:
3.29 children born/woman (2001 est.)
Kazakhstan:
2.07 children born/woman (2001 est.)
Kenya:
3.5 children born/woman (2001 est.)
Kiribati:
4.36 children born/woman (2001 est.)
Korea, North:
2.26 children born/woman (2001 est.)
Korea, South:
1.72 children born/woman (2001 est.)
Kuwait:
3.2 children born/woman (2001 est.)
Kyrgyzstan:
3.19 children born/woman (2001 est.)
Laos:
5.12 children born/woman (2001 est.)
Latvia:
1.15 children born/woman (2001 est.)
Lebanon:
2.05 children born/woman (2001 est.)
Lesotho:
4.08 children born/woman (2001 est.)
Liberia:
6.36 children born/woman (2001 est.)
Libya:
3.64 children born/woman (2001 est.)
Liechtenstein:
1.5 children born/woman (2001 est.)
Lithuania:
1.37 children born/woman (2001 est.)
Luxembourg:
1.7 children born/woman (2001 est.)
Macau:
1.31 children born/woman (2001 est.)
Macedonia, The Former Yugoslav Republic of:
1.79 children born/woman
(2001 est.)
Madagascar:
5.8 children born/woman (2001 est.)
Malawi:
5.18 children born/woman (2001 est.)
Malaysia:
3.24 children born/woman (2001 est.)
Maldives:
5.5 children born/woman (2001 est.)
Mali:
6.81 children born/woman (2001 est.)
Malta:
1.92 children born/woman (2001 est.)
Man, Isle of:
1.65 children born/woman (2001 est.)
Marshall Islands:
6.55 children born/woman (2001 est.)
Martinique:
1.8 children born/woman (2001 est.)
Mauritania:
6.22 children born/woman (2001 est.)
Mauritius:
2.01 children born/woman (2001 est.)
Mayotte:
6.24 children born/woman (2001 est.)
Mexico:
2.62 children born/woman (2001 est.)
Moldova:
1.67 children born/woman (2001 est.)
Monaco:
1.76 children born/woman (2001 est.)
Mongolia:
2.39 children born/woman (2001 est.)
Montserrat:
1.82 children born/woman (2001 est.)
Morocco:
3.05 children born/woman (2001 est.)
Mozambique:
4.82 children born/woman (2001 est.)
Namibia:
4.83 children born/woman (2001 est.)
Nauru:
3.61 children born/woman (2001 est.)
Nepal:
4.58 children born/woman (2001 est.)
Netherlands:
1.65 children born/woman (2001 est.)
Netherlands Antilles:
2.07 children born/woman (2001 est.)
New Caledonia:
2.48 children born/woman (2001 est.)
New Zealand:
1.8 children born/woman (2001 est.)
Nicaragua:
3.18 children born/woman (2001 est.)
Niger:
7.08 children born/woman (2001 est.)
Nigeria:
5.57 children born/woman (2001 est.)
Niue:
NA children born/woman
Norfolk Island:
NA children born/woman
Northern Mariana Islands:
1.76 children born/woman (2001 est.)
Norway:
1.81 children born/woman (2001 est.)
Oman:
6.04 children born/woman (2001 est.)
Pakistan:
4.41 children born/woman (2001 est.)
Palau:
2.47 children born/woman (2001 est.)
Panama:
2.27 children born/woman (2001 est.)
Papua New Guinea:
4.3 children born/woman (2001 est.)
Paraguay:
4.11 children born/woman (2001 est.)
Peru:
2.96 children born/woman (2001 est.)
Philippines:
3.42 children born/woman (2001 est.)
Pitcairn Islands:
NA children born/woman
Poland:
1.37 children born/woman (2001 est.)
Portugal:
1.48 children born/woman (2001 est.)
Puerto Rico:
1.9 children born/woman (2001 est.)
Qatar:
3.17 children born/woman (2001 est.)
Reunion:
2.58 children born/woman (2001 est.)
Romania:
1.35 children born/woman (2001 est.)
Russia:
1.27 children born/woman (2001 est.)
Rwanda:
4.89 children born/woman (2001 est.)
Saint Helena:
1.53 children born/woman (2001 est.)
Saint Kitts and Nevis:
2.41 children born/woman (2001 est.)
Saint Lucia:
2.38 children born/woman (2001 est.)
Saint Pierre and Miquelon:
2.12 children born/woman (2001 est.)
Saint Vincent and the Grenadines:
2.06 children born/woman (2001
est.)
Samoa:
3.4 children born/woman (2001 est.)
San Marino:
1.3 children born/woman (2001 est.)
Sao Tome and Principe:
6.02 children born/woman (2001 est.)
Saudi Arabia:
6.25 children born/woman (2001 est.)
Senegal:
5.12 children born/woman (2001 est.)
Seychelles:
1.83 children born/woman (2001 est.)
Sierra Leone:
6.01 children born/woman (2001 est.)
Singapore:
1.22 children born/woman (2001 est.)
Slovakia:
1.25 children born/woman (2001 est.)
Slovenia:
1.28 children born/woman (2001 est.)
Solomon Islands:
4.65 children born/woman (2001 est.)
Somalia:
7.11 children born/woman (2001 est.)
South Africa:
2.43 children born/woman (2001 est.)
Spain:
1.15 children born/woman (2001 est.)
Sri Lanka:
1.95 children born/woman (2001 est.)
Sudan:
5.35 children born/woman (2001 est.)
Suriname:
2.47 children born/woman (2001 est.)
Svalbard:
NA children born/woman
Swaziland:
5.82 children born/woman (2001 est.)
Sweden:
1.53 children born/woman (2001 est.)
Switzerland:
1.47 children born/woman (2001 est.)
Syria:
3.95 children born/woman (2001 est.)
Tajikistan:
4.29 children born/woman (2001 est.)
Tanzania:
5.42 children born/woman (2001 est.)
Thailand:
1.87 children born/woman (2001 est.)
Togo:
5.32 children born/woman (2001 est.)
Tokelau:
NA children born/woman
Tonga:
3 children born/woman (2001 est.)
Trinidad and Tobago:
1.81 children born/woman (2001 est.)
Tunisia:
1.99 children born/woman (2001 est.)
Turkey:
2.12 children born/woman (2001 est.)
Turkmenistan:
3.58 children born/woman (2001 est.)
Turks and Caicos Islands:
3.22 children born/woman (2001 est.)
Tuvalu:
3.09 children born/woman (2001 est.)
Uganda:
6.88 children born/woman (2001 est.)
Ukraine:
1.29 children born/woman (2001 est.)
United Arab Emirates:
3.23 children born/woman (2001 est.)
United Kingdom:
1.73 children born/woman (2001 est.)
United States:
2.06 children born/woman (2001 est.)
Uruguay:
2.36 children born/woman (2001 est.)
Uzbekistan:
3.06 children born/woman (2001 est.)
Vanuatu:
3.19 children born/woman (2001 est.)
Venezuela:
2.46 children born/woman (2001 est.)
Vietnam:
2.49 children born/woman (2001 est.)
Virgin Islands:
2.25 children born/woman (2001 est.)
Wallis and Futuna:
NA children born/woman
West Bank:
4.9 children born/woman (2001 est.)
World:
2.73 children born/woman (2001 est.)
Yemen:
6.97 children born/woman (2001 est.)
Yugoslavia:
1.75 children born/woman (2001 est.)
Zambia:
5.53 children born/woman (2001 est.)
Zimbabwe:
3.28 children born/woman (2001 est.)
Taiwan:
1.76 children born/woman (2001 est.)
======================================================================
@Transportation - note
Arctic Ocean:
sparse network of air, ocean, river, and land routes;
the Northwest Passage (North America) and Northern Sea Route
(Eurasia) are important seasonal waterways
Atlantic Ocean:
Kiel Canal and Saint Lawrence Seaway are two
important waterways; significant domestic commercial and
recreational use of Intracoastal Waterway on central and south
Atlantic seaboard and Gulf of Mexico coast of US
Baker Island:
there is a day beacon near the middle of the west coast
Georgia:
transportation network is in poor condition resulting from
ethnic conflict, criminal activities, and fuel shortages; network
lacks maintenance and repair
Howland Island:
Earhart Light is a day beacon near the middle of the
west coast that was partially destroyed during World War II, but has
since been rebuilt; named in memory of famed aviatrix Amelia EARHART
Jarvis Island:
there is a day beacon near the middle of the west
coast
Pacific Ocean:
Inside Passage offers protected waters from southeast
Alaska to Puget Sound (Washington state)
Southern Ocean:
Drake Passage offers alternative to transit through
the Panama Canal
Wake Island:
formerly an important commercial aviation base, now
used by US military, some commercial cargo planes, and for emergency
landings
======================================================================
@Unemployment rate
Afghanistan:
NA%
Albania:
16% (2000 est.) officially; may be as high as 25%
Algeria:
30% (1999 est.)
American Samoa:
16% (1993)
Andorra:
0%
Angola:
extensive unemployment and underemployment affecting more
than half the population (2000 est.)
Anguilla:
7% (1992 est.)
Antigua and Barbuda:
7% (1999 est.)
Argentina:
15% (December 2000)
Armenia:
20% (1998 est.)
note: official rate is 9.3% for 1998
Aruba:
0.6% (1999 est.)
Australia:
6.4% (2000)
Austria:
5.4% (2000 est.)
Azerbaijan:
20% (1999 est.)
Bahamas, The:
9% (1998 est.)
Bahrain:
15% (1998 est.)
Bangladesh:
35.2% (1996)
Barbados:
11% (1999 est.)
Belarus:
2.1% officially registered unemployed (December 2000);
large number of underemployed workers
Belgium:
8.4% (2000 est.)
Belize:
12.8% (1999)
Benin:
NA%
Bermuda:
NEGL% (1995)
Bhutan:
NA%
Bolivia:
11.4% (1997)
note: widespread underemployment
Bosnia and Herzegovina:
35%-40% (1999 est.)
Botswana:
40% (2000 est.)
Brazil:
7.1% (2000 est.)
British Virgin Islands:
3% (1995)
Brunei:
4.9% (1995 est.)
Bulgaria:
17.7% (2000 est.)
Burkina Faso:
NA%
Burma:
7.1% (official FY97/98 est.)
Burundi:
NA%
Cambodia:
2.8% (1999 est.)
Cameroon:
30% (1998 est.)
Canada:
6.8% (2000 est.)
Cape Verde:
24% (1999 est.)
Cayman Islands:
4.1% (1997)
Central African Republic:
6% (1993)
Chad:
NA%
Chile:
9% (December 2000)
China:
urban unemployment roughly 10%; substantial unemployment and
underemployment in rural areas (2000 est.)
Christmas Island:
NA%
Colombia:
20% (2000 est.)
Comoros:
20% (1996 est.)
Congo, Democratic Republic of the:
NA%
Congo, Republic of the:
NA%
Cook Islands:
NA%
Costa Rica:
5.2% (2000 est.)
Cote d''Ivoire:
13% in urban areas (1998 est.)
Croatia:
22% (October 2000)
Cuba:
5.5% (2000 est.)
Cyprus:
Greek Cypriot area: 3.6% (2000 est.); Turkish Cypriot area:
6% (1998 est.)
Czech Republic:
8.7% (2000 est.)
Denmark:
5.3% (2000)
Djibouti:
50% (2000 est.)
Dominica:
20% (1999 est.)
Dominican Republic:
13.8% (1999 est.)
Ecuador:
13%; note - widespread underemployment (2000 est.)
Egypt:
11.5% (2000 est.)
El Salvador:
10% (2000 est.)
Equatorial Guinea:
30% (1998 est.)
Eritrea:
NA%
Estonia:
11.7% (1999 est.)
Ethiopia:
NA%
Falkland Islands (Islas Malvinas):
full employment; labor shortage
Faroe Islands:
1% (October 2000)
Fiji:
6% (1997 est.)
Finland:
9.8% (2000 est.)
France:
9.7% (2000 est.)
French Guiana:
21.4% (1998)
French Polynesia:
15% (1992 est.)
Gabon:
21% (1997 est.)
Gambia, The:
NA%
Gaza Strip:
40% (includes West Bank) (yearend 2000)
Georgia:
14.9% (1999 est.)
Germany:
9.9% (2000 est.)
Ghana:
20% (1997 est.)
Gibraltar:
13.5% (1996)
Greece:
11.3% (2000 est.)
Greenland:
7% (1999 est.)
Grenada:
15% (1997)
Guadeloupe:
27.8% (1998)
Guam:
15% (2000 est.)
Guatemala:
7.5% (1999 est.)
Guernsey:
0.5% (1999 est.)
Guinea:
NA%
Guinea-Bissau:
NA%
Guyana:
12% (1992 est.)
Haiti:
widespread unemployment and underemployment; more than
two-thirds of the labor force do not have formal jobs (1999)
Honduras:
28% (2000 est.)
Hong Kong:
4.5% (2000 est.)
Hungary:
9.4% (2000 est.)
Iceland:
2.7% (January 2001)
India:
NA%
Indonesia:
15%-20% (1998 est.)
Iran:
14% (1999 est.)
Iraq:
NA%
Ireland:
4.1% (2000)
Israel:
9% (2000 est.)
Italy:
10.4% (2000 est.)
Jamaica:
16% (2000 est.)
Japan:
4.7% (2000)
Jersey:
0.7% (1998 est.)
Jordan:
15% official rate; actual rate is 25%-30% (1999 est.)
Kazakhstan:
13.7% (1998 est.)
Kenya:
50% (1998 est.)
Kiribati:
2%; underemployment 70% (1992 est.)
Korea, North:
NA%
Korea, South:
4.1% (2000 est.)
Kuwait:
1.8% (official 1996 est.)
Kyrgyzstan:
6% (1998 est.)
Laos:
5.7% (1997 est.)
Latvia:
7.8% (2000 est.)
Lebanon:
18% (1997 est.)
Lesotho:
45% (2000 est.)
Liberia:
70%
Libya:
30% (2000 est.)
Liechtenstein:
1.8% (February 1999)
Lithuania:
10.8% (2000)
Luxembourg:
2.7% (2000 est.)
Macau:
6.6% (2000)
Macedonia, The Former Yugoslav Republic of:
32% (2000)
Madagascar:
NA%
Malawi:
NA%
Malaysia:
2.8% (2000 est.)
Maldives:
NEGL%
Mali:
NA%
Malta:
4.5% (3rd Quarter 2000)
Man, Isle of:
0.6% (August 2000)
Marshall Islands:
16% (1991 est.)
Martinique:
27.2% (1998)
Mauritania:
23% (1995 est.)
Mauritius:
6.4% (1999 est.)
Mayotte:
45% (1997)
Mexico:
urban - 2.2% (2000); plus considerable underemployment
Micronesia, Federated States of:
16% (1999 est.)
Moldova:
1.9% (includes only officially registered unemployed; large
numbers of underemployed workers) (November 2000)
Monaco:
3.1% (1998)
Mongolia:
NA%
Montserrat:
20% (1996 est.)
Morocco:
23% (1999 est.)
Mozambique:
21% (1997 est.)
Namibia:
30% to 40%, including underemployment (1997 est.)
Nauru:
0%
Nepal:
NA%; substantial underemployment (1999)
Netherlands:
2.6% (2000 est.)
Netherlands Antilles:
14.9% (1998 est.)
New Caledonia:
19% (1996)
New Zealand:
6.3% (2000 est.)
Nicaragua:
20% plus considerable underemployment (1999 est.)
Niger:
NA%
Nigeria:
28% (1992 est.)
Niue:
NA%
Norfolk Island:
NA%
Northern Mariana Islands:
NA%
Norway:
3% (2000 est.)
Oman:
NA%
Pakistan:
6% (FY99/00 est.)
Palau:
2.3% (2000 est.)
Panama:
13% (2000 est.)
Papua New Guinea:
NA%
Paraguay:
16% (2000 est.)
Peru:
7.7%; extensive underemployment (1997)
Philippines:
10% (2000)
Pitcairn Islands:
NA%
Poland:
12% (1999)
Portugal:
4.3% (2000 est.)
Puerto Rico:
9.5% (2000)
Qatar:
NA%
Reunion:
42.8% (1998)
Romania:
11.5% (1999)
Russia:
10.5% (2000 est.), plus considerable underemployment
Rwanda:
NA%
Saint Helena:
14% (1998 est.)
Saint Kitts and Nevis:
4.5% (1997)
Saint Lucia:
15% (1996 est.)
Saint Pierre and Miquelon:
9.8% (1997)
Saint Vincent and the Grenadines:
22% (1997 est.)
Samoa:
NA%; note - substantial underemployment
San Marino:
3% (1999)
Sao Tome and Principe:
NA%
Saudi Arabia:
NA%
Senegal:
NA%; urban youth 40%
Seychelles:
NA%
Sierra Leone:
NA%
Singapore:
3% (2000 est.)
Slovakia:
17% (2000 est.)
Slovenia:
7.1% (1997 est.)
Solomon Islands:
NA%
Somalia:
NA%
South Africa:
30% (2000 est.)
Spain:
14% (2000 est.)
Sri Lanka:
8.8% (1999 est.)
Sudan:
4% (1996 est.)
Suriname:
20% (1997)
Swaziland:
22% (1995 est.)
Sweden:
6% (2000 est.)
Switzerland:
1.9% (2000 est.)
Syria:
20% (2000 est.)
Tajikistan:
5.7% includes only officially registered unemployed;
also large numbers of underemployed workers and unregistered
unemployed people (December 1998)
Tanzania:
NA%
Thailand:
3.7% (2000 est.)
Togo:
NA%
Tokelau:
NA%
Tonga:
13.3% (FY96/97)
Trinidad and Tobago:
12.8% (2000)
Tunisia:
15.6% (2000 est.)
Turkey:
5.6% (plus underemployment of 5.6%) (2000 est.)
Turkmenistan:
NA%
Turks and Caicos Islands:
10% (1997 est.)
Tuvalu:
NA%
Uganda:
NA%
Ukraine:
4.3% officially registered; large number of unregistered or
underemployed workers (December 1999)
United Arab Emirates:
NA%
United Kingdom:
5.5% (2000 est.)
United States:
4% (2000)
Uruguay:
14% (2000 est.)
Uzbekistan:
10% plus another 20% underemployed (1999 est.)
Vanuatu:
NA%
Venezuela:
14% (2000 est.)
Vietnam:
25% (1995 est.)
Virgin Islands:
4.9% (March 1999)
Wallis and Futuna:
NA%
West Bank:
40% (includes Gaza Strip) (yearend 2000)
Western Sahara:
NA%
World:
30% combined unemployment and underemployment in many
non-industrialized countries; developed countries typically 4%-12%
unemployment (2000 est.)
Yemen:
30% (1995 est.)
Yugoslavia:
30% (2000 est.)
Zambia:
50% (2000 est.)
Zimbabwe:
50% (2000 est.)
Taiwan:
3% (2000 est.)
======================================================================
@Waterways
Afghanistan:
1,200 km
note: chiefly Amu Darya, which handles vessels with DWT up to about
500 (2001)
Albania:
43 km
note: includes Albanian sections of Lake Scutari, Lake Ohrid, and
Lake Prespa (1990)
Algeria:
none
American Samoa:
none
Andorra:
none
Angola:
1,295 km
Anguilla:
none
Antigua and Barbuda:
none
Argentina:
10,950 km
Armenia:
NA km
Aruba:
none
Ashmore and Cartier Islands:
none
Australia:
8,368 km (mainly used by small, shallow-draft craft)
Austria:
358 km (1999)
Azerbaijan:
none
Bahamas, The:
none
Bahrain:
none
Baker Island:
none
Bangladesh:
up to 8,046 km depending on season
note: includes 3,058 km main cargo routes
Barbados:
none
Bassas da India:
none
Belarus:
NA km; note - Belarus has extensive and widely used canal
and river systems
Belgium:
2,043 km (1,528 km in regular commercial use)
Belize:
825 km (river network used by shallow-draft craft;
seasonally navigable)
Benin:
streams navigable along small sections, important only locally
Bermuda:
none
Bhutan:
none
Bolivia:
10,000 km (commercially navigable)
Bosnia and Herzegovina:
NA km; large sections of the Sava blocked by
downed bridges, silt, and debris
Botswana:
none
Bouvet Island:
none
Brazil:
50,000 km
British Indian Ocean Territory:
none
British Virgin Islands:
none
Brunei:
209 km; navigable by craft drawing less than 1.2 m
Bulgaria:
470 km (1987)
Burkina Faso:
none
Burma:
12,800 km
note: 3,200 km navigable by large commercial vessels
Burundi:
Lake Tanganyika
Cambodia:
3,700 km
note: navigable all year to craft drawing 0.6 m or less; 282 km
navigable to craft drawing as much as 1.8 m
Cameroon:
2,090 km (of decreasing importance)
Canada:
3,000 km (including Saint Lawrence Seaway)
Cape Verde:
none
Cayman Islands:
none
Central African Republic:
900 km
note: traditional trade carried on by means of shallow-draft
dugouts; Oubangui is the most important river, navigable all year to
craft drawing 0.6 m or less; 282 km navigable to craft drawing as
much as 1.8 m
Chad:
2,000 km
Chile:
725 km
China:
110,000 km (1999)
Christmas Island:
none
Clipperton Island:
none
Cocos (Keeling) Islands:
none
Colombia:
18,140 km (navigable by river boats) (April 1996)
Comoros:
none
Congo, Democratic Republic of the:
15,000 km (including the Congo
and its tributaries, and unconnected lakes)
Congo, Republic of the:
1,120 km
note: the Congo and Ubangi (Oubangui) rivers provide 1,120 km of
commercially navigable water transport; other rivers are used for
local traffic only
Cook Islands:
none
Coral Sea Islands:
none
Costa Rica:
730 km (seasonally navigable)
Cote d''Ivoire:
980 km (navigable rivers, canals, and numerous
coastal lagoons)
Croatia:
785 km
note: (perennially navigable; large sections of Sava blocked by
downed bridges, silt, and debris)
Cuba:
240 km
Cyprus:
none
Czech Republic:
303 km
note: (the Labe (Elbe) is the principal river) (2000)
Denmark:
417 km
Djibouti:
none
Dominica:
none
Dominican Republic:
none
Ecuador:
1,500 km
Egypt:
3,500 km
note: including the Nile, Lake Nasser, Alexandria-Cairo Waterway,
and numerous smaller canals in the delta; Suez Canal (193.5 km
including approaches), used by oceangoing vessels drawing up to 16.1
m of water
El Salvador:
Rio Lempa partially navigable
Equatorial Guinea:
none
Eritrea:
none
Estonia:
320 km (perennially navigable)
Ethiopia:
none
Europa Island:
none
Falkland Islands (Islas Malvinas):
none
Faroe Islands:
none
Fiji:
203 km
note: 122 km navigable by motorized craft and 200-metric-ton barges
Finland:
6,675 km
note: includes Saimaa Canal; 3,700 km suitable for large ships
France:
14,932 km (6,969 km heavily traveled)
French Guiana:
3,300 km navigable by native craft
note: 460 km navigable by small oceangoing vessels and coastal and
river steamers
French Polynesia:
none
French Southern and Antarctic Lands:
none
Gabon:
1,600 km (perennially navigable)
Gambia, The:
400 km
Gaza Strip:
none
Georgia:
none
Germany:
7,500 km
note: major rivers include the Rhine and Elbe; Kiel Canal is an
important connection between the Baltic Sea and North Sea (1999)
Ghana:
1,293 km
note: Volta, Ankobra, and Tano Rivers provide 168 km of perennial
navigation for launches and lighters; Lake Volta provides 1,125 km
of arterial and feeder waterways
Gibraltar:
none
Glorioso Islands:
none
Greece:
80 km
note: system consists of three coastal canals including the Corinth
Canal (6 km) which crosses the Isthmus of Corinth connecting the
Gulf of Corinth with the Saronic Gulf and shortens the sea voyage
from the Adriatic to Peiraiefs (Piraeus) by 325 km; there are also
three unconnected rivers
Greenland:
none
Grenada:
none
Guadeloupe:
none
Guam:
none
Guatemala:
990 km
note: 260 km navigable year round; additional 730 km navigable
during highwater season
Guernsey:
none
Guinea:
1,295 km (navigable by shallow-draft native craft)
Guinea-Bissau:
several rivers are accessible to coastal shipping
Guyana:
5,900 km (total length of navigable waterways)
note: Berbice, Demerara, and Essequibo rivers are navigable by
oceangoing vessels for 150 km, 100 km, and 80 km, respectively
Haiti:
NEGL; less than 100 km navigable
Heard Island and McDonald Islands:
none
Holy See (Vatican City):
none
Honduras:
465 km (navigable by small craft)
Hong Kong:
none
Howland Island:
none
Hungary:
1,373 km (permanently navigable) (1997)
Iceland:
none
India:
16,180 km
note: 3,631 km navigable by large vessels
Indonesia:
21,579 km total
note: Sumatra 5,471 km, Java and Madura 820 km, Kalimantan 10,460
km, Sulawesi (Celebes) 241 km, Irian Jaya 4,587 km
Iran:
904 km
note: the Shatt al Arab is usually navigable by maritime traffic
for about 130 km; channel has been dredged to 3 m and is in use
Iraq:
1,015 km
note: Shatt al Arab is usually navigable by maritime traffic for
about 130 km; channel has been dredged to 3 m and is in use; Tigris
and Euphrates Rivers have navigable sections for shallow-draft
boats; Shatt al Basrah canal was navigable by shallow-draft craft
before closing in 1991 because of the Gulf war
Ireland:
700 km (limited facilities for commercial traffic) (1998)
Israel:
none
Italy:
2,400 km
note: for various types of commercial traffic, although of limited
overall value
Jamaica:
none
Jan Mayen:
none
Japan:
1,770 km approximately
note: seagoing craft ply all coastal inland seas
Jarvis Island:
none
Jersey:
none
Johnston Atoll:
none
Jordan:
none
Juan de Nova Island:
none
Kazakhstan:
3,900 km
note: on the Syrdariya (Syr Darya) and Ertis (Irtysh) rivers
Kenya:
NA
note: part of the Lake Victoria system is within the boundaries of','8edb766e6a476d72b1ebfd9c5f659eb6cc9644b5230a72b6691fbee248e5b547','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfa1fe64298f1a8a9a18594bc43210619606efae234f68f6982aee64b2f1a443',2001,'KE','Kenya','communications',315,'Kingman Reef:
none
Kiribati:
5 km (small network of canals in Line Islands)
Korea, North:
2,253 km
note: mostly navigable by small craft only
Korea, South:
1,609 km
note: restricted to small native craft
Kuwait:
none
Kyrgyzstan:
600 km (1990)
Laos:
4,587 km approximately
note: primarily Mekong and tributaries; 2,897 additional km are
intermittently navigable by craft drawing less than 0.5 m
Latvia:
300 km (perennially navigable)
Lebanon:
none
Lesotho:
none
Liberia:
none
Libya:
none
Liechtenstein:
none
Lithuania:
600 km (perennially navigable)
Luxembourg:
37 km (on the Moselle)
Macau:
none
Macedonia, The Former Yugoslav Republic of:
note: lake transport
only, on the Greek and Albanian borders
Madagascar:
note: of local importance only
Malawi:
144 km
note: on Lake Nyasa (Lake Malawi) and Shire Riverall
Malaysia:
7,296 km
note: Peninsular Malaysia 3,209 km, Sabah 1,569 km, Sarawak 2,518 km
Maldives:
none
Mali:
1,815 km
Malta:
none
Man, Isle of:
none
Marshall Islands:
none
Martinique:
none
Mauritania:
note: ferry traffic on the Senegal River
Mauritius:
none
Mayotte:
none
Mexico:
2,900 km
note: navigable rivers and coastal canals
Micronesia, Federated States of:
none
Midway Islands:
none
Moldova:
424 km (1994)
Monaco:
none
Mongolia:
400 km (1999)
Montserrat:
none
Morocco:
none
Mozambique:
3,750 km (navigable routes)
Namibia:
none
Nauru:
none
Navassa Island:
none
Nepal:
none
Netherlands:
5,046 km
note: 47% of total route length is usable by craft of 1,000 metric
ton capacity or larger
Netherlands Antilles:
none
New Caledonia:
none
New Zealand:
1,609 km
note: of little importance in satisfying total transportation
requirements
Nicaragua:
2,220 km (including 2 large lakes)
Niger:
300 km
note: the Niger River is navigable from Niamey to Gaya on the Benin
frontier from mid-December through March
Nigeria:
8,575 km
note: consisting of the Niger and Benue rivers and smaller rivers
and creeks
Niue:
none
Norfolk Island:
none
Northern Mariana Islands:
none
Norway:
1,577 km (along west coast)
note: navigable by 2.4 m maximum draft vessels
Oman:
none
Pakistan:
none
Palau:
none
Palmyra Atoll:
none
Panama:
882 km
note: 800 km navigable by shallow draft vessels; 82 km Panama Canal
Papua New Guinea:
10,940 km
Paracel Islands:
none
Paraguay:
3,100 km
Peru:
8,808 km
note: 8,600 km of navigable tributaries of Amazon system and 208 km
of Lago Titicaca
Philippines:
3,219 km
note: limited to vessels with a draft of less than 1.5 m
Pitcairn Islands:
none
Poland:
3,812 km (navigable rivers and canals) (1996)
Portugal:
820 km
note: relatively unimportant to national economy, used by
shallow-draft craft limited to 300 metric-ton or less cargo capacity
Puerto Rico:
none
Qatar:
none
Reunion:
none
Romania:
1,724 km (1984)
Russia:
95,900 km (total routes in general use)
note: routes with navigation guides serving the Russian River
Fleet-95,900 km; routes with night navigational aids-60,400 km;
man-made navigable routes-16,900 km (Jan 1994)
Rwanda:
note: Lac Kivu navigable by shallow-draft barges and native
craft
Saint Helena:
none
Saint Kitts and Nevis:
none
Saint Lucia:
none
Saint Pierre and Miquelon:
none
Saint Vincent and the Grenadines:
none
Samoa:
none
San Marino:
none
Sao Tome and Principe:
none
Saudi Arabia:
none
Senegal:
897 km
note: 785 km on the Senegal river, and 112 km on the Saloum river
Seychelles:
none
Sierra Leone:
800 km (of which 600 km navigable year round)
Singapore:
none
Slovakia:
172 km (all on the Danube)
Slovenia:
NA
Solomon Islands:
none
Somalia:
none
South Africa:
NA
South Georgia and the South Sandwich Islands:
none
Spain:
1,045 km (of minor economic importance)
Spratly Islands:
none
Sri Lanka:
430 km (navigable by shallow-draft craft)
Sudan:
5,310 km
Suriname:
1,200 km
note: most important means of transport; oceangoing vessels with
drafts ranging up to 7 m can navigate many of the principal waterways
Svalbard:
none
Swaziland:
none
Sweden:
2,052 km
note: navigable for small steamers and barges
Switzerland:
65 km
note: The Rhine carries heavy traffic on the Basel-Rheinfelden and
Schaffhausen-Bodensee stretches; there are also 12 navigable lakes
Syria:
870 km (minimal economic importance)
Tajikistan:
none
Tanzania:
note: Lake Tanganyika, Lake Victoria, and Lake Nyasa are
principal avenues of commerce between Tanzania and its neighbors on
those lakes
Thailand:
4,000 km
note: 3,701 km are navigable throughout the year by boats with
drafts up to 0.9 meters; numerous minor waterways serve
shallow-draft native craft
Togo:
50 km (Mono river)
Tokelau:
none
Tonga:
none
Trinidad and Tobago:
none
Tromelin Island:
none
Tunisia:
none
Turkey:
1,200 km (approximately)
Turkmenistan:
the Amu Darya is an important inland waterway for','590caa50706fbe2046fe4cfa2a2db20293505444266a319cf04818e537b61a94','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4222cff048816647b6d77c6cab152b977a901b0da8f2d34cd3d8483e69192d4d',2001,'TM','Turkmenistan','communications',316,'Turks and Caicos Islands:
none
Tuvalu:
none
Uganda:
Lake Victoria, Lake Albert, Lake Kyoga, Lake George, Lake
Edward, Victoria Nile, Albert Nile
Ukraine:
4,499 km
note: (1,672 km are on the Pryp''yat'' and Dnistr) (1990)
United Arab Emirates:
none
United Kingdom:
3,200 km
United States:
41,009 km
note: navigable inland channels, exclusive of the Great Lakes
Uruguay:
1,600 km ( used by coastal and shallow-draft river craft)
Uzbekistan:
1,100 km (1990)
Vanuatu:
none
Venezuela:
7,100 km
note: Rio Orinoco and Lago de Maracaibo accept oceangoing vessels
Vietnam:
17,702 km
note: more than 5,149 km are navigable at all times by vessels up
to 1.8 m draft
Virgin Islands:
none
Wake Island:
none
Wallis and Futuna:
none
West Bank:
none
Western Sahara:
none
Yemen:
none
Yugoslavia:
587 km
note: The Danube River, which connects Europe with the Black Sea,
runs through Serbia; since early 2000, a pontoon bridge, replacing a
destroyed conventional bridge, has obstructed river traffic at Novi
Sad; the obstruction can be bypassed by a canal system but
inadequate lock size limits the size of vessels which may pass (2001)
Zambia:
2,250 km
note: includes Lake Tanganyika and the Zambezi and Luapula rivers
Zimbabwe:
the Mazoe and Zambezi rivers are used for transporting
chrome ore from Harare to Mozambique
Taiwan:
NA
======================================================================
Appendix A: Abbreviations
ABEDA: Arab Bank for Economic Development in Africa
ACC: Arab Cooperation Council
ACCT: Agency for the French-Speaking Community
ACP Group: African, Caribbean, and Pacific Group of States
AfDB: African Development Bank
AFESD: Arab Fund for Economic and Social Development
Air Pollution: Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides: Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Control of Emissions of Nitrogen Oxides
or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants: Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution on Persistent
Organic Pollutants
Air Pollution-Sulphur 85: Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on the Reduction of Sulphur Emissions
or Their Transboundary Fluxes by at Least 30%
Air Pollution-Sulphur 94: Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on Further Reduction of Sulphur
Emissions
Air Pollution-Volatile Organic Compounds: Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution Concerning the
Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AL: Arab League
AMF: Arab Monetary Fund
AMU: Arab Maghreb Union
Antarctic-Environmental Protocol: Protocol on Environmental Protection
to the Antarctic Treaty
ANZUS: Australia-New Zealand-United States Security Treaty
APEC: Asia-Pacific Economic Cooperation
Arabsat: Arab Satellite Communications Organization
ARF: ASEAN Regional Forum
AsDB: Asian Development Bank
ASEAN: Association of Southeast Asian Nations
Autodin: Automatic Digital Network
Benelux: Benelux Economic Union
Biodiversity: Convention on Biological Diversity
BIS: Bank for International Settlements
BSEC: Black Sea Economic Cooperation Zone
C: Commonwealth
CACM: Central American Common Market
CAEU: Council of Arab Economic Unity
CAN: Andean Community of Nations
Caricom: Caribbean Community and Common Market
CB: citizen''s band mobile radio communications
CBSS: Council of the Baltic Sea States
CCC: Customs Cooperation Council
CDB: Caribbean Development Bank
CE: Council of Europe
CEI: Central European Initiative
CEMA: Council for Mutual Economic Assistance; also known as CMEA or
Comecon
CEMAC: Monetary and Economic Community of Central Africa
CEPGL: Economic Community of the Great Lakes Countries
CERN: European Organization for Nuclear Research
c.i.f.: cost, insurance, and freight
CIS: Commonwealth of Independent States
CITES: see Endangered Species
Climate Change: United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol: Kyoto Protocol to the United Nations
Framework Convention on Climate Change
COCOM: Coordinating Committee on Export Controls
Comsat: Communications Satellite Corporation
CP: Colombo Plan
CY: calendar year
DC: developed country
Desertification: United Nations Convention to Combat Desertification
in Those Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
DSN: Defense Switched Network
DWT: deadweight ton
EADB: East African Development Bank
EAPC: Euro-Atlantic Partnership Council
EBRD: European Bank for Reconstruction and Development
EC: European Community
ECA: Economic Commission for Africa
ECE: Economic Commission for Europe
ECLAC: Economic Commission for Latin America and the Caribbean
ECO: Economic Cooperation Organization
ECOSOC: Economic and Social Council
ECOWAS: Economic Community of West African States
ECS: European Coal and Steel Community
EEC: European Economic Community
EFTA: European Free Trade Association
EIB: European Investment Bank
EMU: European Monetary Union
Endangered Species: Convention on the International Trade in
Endangered Species of Wild Flora and Fauna (CITES)
Entente: Council of the Entente
Environmental Modification: Convention on the Prohibition of Military
or Any Other Hostile Use of Environmental Modification Techniques
ESA: European Space Agency
ESCAP: Economic and Social Commission for Asia and the Pacific
ESCWA: Economic and Social Commission for Western Asia
est.: estimate
EU: European Union
Euratom: European Atomic Energy Community
Eutelsat: European Telecommunications Satellite Organization
Ex-Im: Export-Import Bank of the United States
FAO: Food and Agriculture Organization
FAX: facsimile
f.o.b.: free on board
FLS: Front Line States
FRG: Federal Republic of Germany (West Germany); used for information
dated before 3 October 1990 or CY91
FSU: former Soviet Union
FY: fiscal year
FYROM: The Former Yugoslav Republic of Macedonia
FZ: Franc Zone
G-2: Group of 2
G-3: Group of 3
G-5: Group of 5
G-6: Group of 6
G-7: Group of 7
G-8: Group of 8
G-9: Group of 9
G-10: Group of 10
G-11: Group of 11
G-15: Group of 15
G-19: Group of 19
G-24: Group of 24
G-30: Group of 30
G-33: Group of 33
G-77: Group of 77
GATT: General Agreement on Tariffs and Trade; now WTrO
GCC: Gulf Cooperation Council
GDP: gross domestic product
GDR: German Democratic Republic (East Germany); used for information
dated before 3 October 1990 or CY91
GNP: gross national product
GRT: gross register ton
GWP: gross world product
Habitat: United Nations Center for Human Settlements
Hazardous Wastes: Basel Convention on the Control of Transboundary
Movements of Hazardous Wastes and Their Disposal
HF: high-frequency
IADB: Inter-American Development Bank
IAEA: International Atomic Energy Agency
IBEC: International Bank for Economic Cooperation
IBRD: International Bank for Reconstruction and Development (World
Bank)
ICAO: International Civil Aviation Organization
ICC: International Chamber of Commerce
ICJ: International Court of Justice (World Court)
ICRC: International Committee of the Red Cross
ICRM: International Red Cross and Red Crescent Movement
ICTR: International Criminal Tribunal for Rwanda
ICTY: International Criminal Tribunal for the former Yugoslavia
IDA: International Development Association
IDB: Islamic Development Bank
IEA: International Energy Agency
IFAD: International Fund for Agricultural Development
IFC: International Finance Corporation
IFCTU: International Federation of Christian Trade Unions
IFRCS: International Federation of Red Cross and Red Crescent
Societies
IGAD: Inter-Governmental Authority on Development
IGADD: Inter-Governmental Authority on Drought and Development
IHO: International Hydrographic Organization
IIB: International Investment Bank
ILO: International Labor Organization
IMF: International Monetary Fund
IMO: International Maritime Organization
Inmarsat: International Mobile Satellite Organization
InOC: Indian Ocean Commission
INSTRAW: International Research and Training Institute for the
Advancement of Women
Intelsat: International Telecommunications Satellite Organization
Interpol: International Criminal Police Organization
Intersputnik: International Organization of Space Communications
IOC: International Olympic Committee
IOM: International Organization for Migration
ISO: International Organization for Standardization
ITU: International Telecommunication Union
kHz: kilohertz
km: kilometer
kW: kilowatt
kWh: kilowatt-hour
LAES: Latin American Economic System
LAIA: Latin American Integration Association
Law of the Sea: United Nations Convention on the Law of the Sea (LOS)
LDC: less developed country
LLDC: least developed country
London Convention: see Marine Dumping
LOS: see Law of the Sea
m: meter
Marecs: Maritime European Communications Satellite
Marine Dumping: Convention on the Prevention of Marine Pollution by
Dumping Wastes and Other Matter
Marine Life Conservation: Convention on Fishing and Conservation of
Living Resources of the High Seas
MARPOL: see Ship Pollution
Medarabtel: Middle East Telecommunications Project of the
International Telecommunications Union
Mercosur: Southern Cone Common Market
MHz: megahertz
MINURSO: United Nations Mission for the Referendum in Western Sahara
MONUC: United Nations Organization Mission in the Democratic Republic
of the Congo
NA: not available
NAM: Nonaligned Movement
NATO: North Atlantic Treaty Organization
NC: Nordic Council
NEA: Nuclear Energy Agency
NEGL: negligible
NIB: Nordic Investment Bank
NIC: newly industrializing country
NIE: newly industrializing economy
NIS: new independent states
NM: nautical mile
NMT: Nordic Mobile Telephone
NSG: Nuclear Suppliers Group
Nuclear Test Ban: Treaty Banning Nuclear Weapons Tests in the
Atmosphere, in Outer Space, and Under Water
NZ: New Zealand
OAPEC: Organization of Arab Petroleum Exporting Countries
OAS: Organization of American States
OAU: Organization of African Unity
ODA: official development assistance
OECD: Organization for Economic Cooperation and Development
OECS: Organization of Eastern Caribbean States
OIC: Organization of the Islamic Conference
OOF: other official flows
OPCW: Organization for the Prohibition of Chemical Weapons
OPEC: Organization of Petroleum Exporting Countries
OSCE: Organization for Security and Cooperation in Europe
Ozone Layer Protection: Montreal Protocol on Substances That Deplete
the Ozone Layer
PCA: Permanent Court of Arbitration
PDRY: People''s Democratic Republic of Yemen [Yemen (Aden) or South
Yemen]; used for information dated before 22 May 1990 or CY91
PFP: Partnership for Peace
Ramsar: see Wetlands
RG: Rio Group
SAARC: South Asian Association for Regional Cooperation
SACU: Southern African Customs Union
SADC: Southern African Development Community
SFRY: Socialist Federal Republic of Yugoslavia
SHF: super-high-frequency
Ship Pollution: Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
Sparteca: South Pacific Regional Trade and Economic Cooperation
Agreement
SPC: South Pacific Commission
SPF: South Pacific Forum
sq km: square kilometer
sq mi: square mile
TAT: Trans-Atlantic Telephone
Tropical Timber 83: International Tropical Timber Agreement, 1983
Tropical Timber 94: International Tropical Timber Agreement, 1994
UAE: United Arab Emirates
UHF: ultra-high-frequency
UK: United Kingdom
UN: United Nations
UNAMIR: United Nations Assistance Mission for Rwanda
UNAMSIL: United Nations Mission in Sierra Leone
UNAVEM III: United Nations Angola Verification Mission III
UNCRO: United Nations Confidence Restoration Operation in Croatia
UNCTAD: United Nations Conference on Trade and Development
UNDCP: United Nations Drug Control Program
UNDOF: United Nations Disengagement Observer Force
UNDP: United Nations Development Program
UNEP: United Nations Environment Program
UNESCO: United Nations Educational, Scientific, and Cultural
Organization
UNFICYP: United Nations Peace-keeping Force in Cyprus
UNHCR: United Nations High Commissioner for Refugees
UNHCRHR: United Nations High Commissioner for Human Rights
UNICEF: United Nations Children''s Fund
UNICRI: United Nations Interregional Crime and Justice Research
Institute
UNIDIR: United Nations Disarmament Research
UNIDO: United Nations Industrial Development Organization
UNIFIL: United Nations Interim Force in Lebanon
UNIKOM: United Nations Iraq-Kuwait Observation Mission
UNITAR: United Nations Institute for Training and Research
UNMEE: United Nations Mission in Ethiopia and Eritrea
UNMIBH: United Nations Mission in Bosnia and Herzegovina
UNMIK: United Nations Interim Administration Mission in Kosovo
UNMOGIP: United Nations Military Observer Group in India and Pakistan
UNMOP: United Nations Mission of Observers in Prevlaka
UNMOT: United Nations Mission of Observers in Tajikistan
UNMOVIC: United Nations Monitoring and Verification Commission
UNOMIG: United Nations Observer Mission in Georgia
UNOMSIL: United Nations Mission of Observers in Sierra Leone
UNRISD: United Nations Research Institute for Social Development
UNRWA: United Nations Relief and Works Agency for Palestine Refugees
in the Near East
UNSMIH: United Nations Support Mission in Haiti
UNTAET: United Nations Transitional Administration in East Timor
UNTSO: United Nations Truce Supervision Organization
UNU: United Nations University
UPU: Universal Postal Union
US: United States
USSR: Union of Soviet Socialist Republics (Soviet Union); used for
information dated before 25 December 1991
USSR/EE: Union of Soviet Socialist Republics/Eastern Europe
VHF: very-high-frequency
VSAT: very small aperture terminal
WADB: West African Development Bank
WAEMU: West African Economic and Monetary Union
WCL: World Confederation of Labor
Wetlands: Convention on Wetlands of International Importance
Especially As Waterfowl Habitat
WEU: Western European Union
WFC: World Food Council
WFP: World Food Program
WFTU: World Federation of Trade Unions
Whaling: International Convention for the Regulation of Whaling
WHO: World Health Organization
WIPO: World Intellectual Property Organization
WMO: World Meteorological Organization
WP: Warsaw Pact
WTO: see WToO for World Tourism Organization or WTrO for World Trade
Organization
WToO: World Tourism Organization
WTrO: World Trade Organization
YAR: Yemen Arab Republic [Yemen (Sanaa) or North Yemen]; used for
information dated before 22 May 1990 or CY91
ZC: Zangger Committee
=====================================================================
Appendix B: International Organizations and Groups
advanced developing countries: another term for those less developed
countries (LDCs) with particularly rapid industrial development; see
newly industrializing economies (NIEs)
advanced economies: a term used by the International Monetary FUND
(IMF) for the top group in its hierarchy of advanced economies,
countries in transition, and developing countries; it includes the
following 28 advanced economies: Australia, Austria, Belgium, Canada,
Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland, Ireland,
Israel, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway,
Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; note -
this group would presumably also cover the following seven smaller
countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein,
Monaco, and San Marino which are included in the more comprehensive
group of "developed countries"
African, Caribbean, and Pacific Group of States (ACP Group):
established - 6 June 1975
aim - to manage their preferential economic and aid relationship with
the EU
members - (77) Angola, Antigua and Barbuda, The Bahamas, Barbados,
Belize, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cook Islands, Cote d''Ivoire, Djibouti,
Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia,
Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana,
Haiti, Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi,
Mali, Marshall Islands, Mauritania, Mauritius, Federated States of
Micronesia, Mozambique, Namibia, Nauru, Niger, Nigeria, Niue, Palau,
Papua New Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa,
Sudan, Suriname, Swaziland, Tanzania, Togo, Tonga, Trinidad and Tobago,
Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
African Development Bank (AfDB): note - also known as Banque Africaine
de Developpement (BAD)
established - 4 August 1963
aim - to promote economic and social development
regional members - (53) Algeria, Angola, Benin, Botswana, Burkina
Faso, Burundi, Cameroon, Cape Verde, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote
d''Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon,
The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco,
Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan,
Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members - (24) Argentina, Austria, Belgium, Brazil, Canada,
China, Denmark, Finland, France, Germany, India, Italy, Japan, South
Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain,
Sweden, Switzerland, UK, US
Agency for the French-Speaking Community (ACCT): note - formerly
Agency for Cultural and Technical Cooperation
established - 20 March 1970; name changed 1996
aim - to promote cultural and technical cooperation among French-
speaking countries
members - (41) Belgium, Benin, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote
d''Ivoire, Djibouti, Dominica, Equatorial Guinea, France, Gabon, Guinea,
Haiti, Laos, Lebanon, Luxembourg, Madagascar, Mali, Mauritius, Moldova,
Monaco, Niger, Romania, Rwanda, Sao Tome and Principe, Senegal,
Seychelles, Switzerland, Togo, Tunisia, Vanuatu, Vietnam
associate members - (7) Albania, Egypt, Guinea-Bissau, The Former
Yugoslav Republic of Macedonia, Mauritania, Morocco, Saint Lucia
observers - (4) Czech Republic, Lithuania, Poland, Slovenia
participating governments - (2) New Brunswick (Canada), Quebec (Canada)
Agency for the Prohibition of Nuclear Weapons in Latin America and the
Caribbean (OPANAL): note - acronym from Organismo para la Proscripcion
de las Armas Nucleares en la America Latina y el Caribe (OPANAL)
established - 14 February 1967 under the Treaty of Tlatelolco;
effective - 25 April 1969 on the 11th ratification of the treaty
aim - to encourage the peaceful uses of atomic energy and prohibit
nuclear weapons
members - (32) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Dominica,
Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana,
Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, Uruguay, Venezuela; note - Cuba signed
the treaty but did not ratify it
Andean Community of Nations (CAN): note - formerly known as the Andean
Group (AG), the Andean Parliament, and most recently as the Andean
Common Market (Ancom)
established - 26 May 1969; present name established 1 October 1992;
effective - 16 October 1969
aim - to promote harmonious development through economic integration
members - (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
Arab Bank for Economic Development in Africa (ABEDA): note - also
known as Banque Arabe de Developpement Economique en Afrique (BADEA)
established - 18 February 1974; effective - 16 September 1974
aim - to promote economic development
members - (17 plus the Palestine Liberation Organization) Algeria,
Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE,
Palestine Liberation Organization; note - these are all the members of
the Arab League excluding Comoros, Djibouti, Somalia, Yemen
Arab Cooperation Council (ACC): established - 16 February 1989
aim - to promote economic cooperation and integration, possibly leading
to an Arab Common Market
members - (4) Egypt, Iraq, Jordan, Yemen
Arab Fund for Economic and Social Development (AFESD): established -
16 May 1968
aim - to promote economic and social development
members - (20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq (suspended 1993), Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia
(suspended 1993), Sudan, Syria, Tunisia, UAE, Yemen, Palestine
Liberation Organization
Arab League (AL): note - also known as League of Arab States (LAS)
established - 22 March 1945
aim - to promote economic, social, political, and military cooperation
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Arab Maghreb Union (AMU): established - 17 February 1989
aim - to promote cooperation and integration among the Arab states of
northern Africa
members - (5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF): established - 27 April 1976; effective - 2
February 1977
aim - to promote Arab cooperation, development, and integration in
monetary and economic affairs
members - (20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria,
Tunisia, UAE, Yemen, Palestine Liberation Organization
Asia-Pacific Economic Cooperation (APEC): established - 7 November
1989
aim - to promote trade and investment in the Pacific basin
members - (21) Australia, Brunei, Canada, Chile, China, Hong Kong,
Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New Guinea,
Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers - (3) Association of Southeast Asian Nations, Pacific
Economic Cooperation Conference, South Pacific Forum
Asian Development Bank (AsDB): established - 19 December 1966
aim - to promote regional economic cooperation
regional members - (43) Afghanistan, Australia, Azerbaijan, Bangladesh,
Bhutan, Burma, Cambodia, China, Cook Islands, Fiji, Hong Kong, India,
Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos,
Malaysia, Maldives, Marshall Islands, Federated States of Micronesia,
Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan,
Thailand, Tonga, Turkmenistan, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members - (16) Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Italy, Netherlands, Norway, Spain, Sweden,
Switzerland, Turkey, UK, US
Association of Southeast Asian Nations (ASEAN): established - 8 August
1967
aim - to encourage regional economic, social, and cultural cooperation
among the non-Communist countries of Southeast Asia
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
observer - (1) Papua New Guinea
dialogue partners - (11) Australia, Canada, China, EU, India, Japan,
South Korea, NZ, Russia, US, UNDP
ASEAN Regional Forum (ARF): established - NA 1994
aim - to foster constructive dialogue and consultation on political and
security issues of common interest and concern
members - (10) Brunei, Burma, Cambodia, Ind','1818a07874ca936314b99ec652531f268588f700ddc1571a42a82f44321e2d95','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d317400a2d526ae61ecdaeb711608a82490c36026794a204b103425b008a98',2001,'TM','Turkmenistan','communications',317,'onesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
dialogue partners - (13) Australia, Canada, China, EU, India, Japan,
North Korea, South Korea, Mongolia, NZ, Papua New Guinea, Russia, US
Australia Group: established - NA 1984
aim - to consult on and coordinate export controls related to chemical
and biological weapons
members - (33) Argentina, Australia, Austria, Belgium, Canada, Cyprus,
Czech Republic, Denmark, European Commission, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea,
Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, Romania,
Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
observer - (1) Singapore
Australia-New Zealand-United States Security Treaty (ANZUS):
established - 1 September 1951; effective - 29 April 1952
aim - to implement a trilateral mutual security agreement, although the
US suspended security obligations to NZ on 11 August 1986; Australia
and the US continue to hold annual meetings
members - (3) Australia, NZ, US
Bank for International Settlements (BIS): established - 20 January
1930; effective - 17 March 1930
aim - to promote cooperation among central banks in international
financial settlements
members - (49) Argentina, Australia, Austria, Belgium, Bosnia and
Herzegovina, Brazil, Bulgaria, Canada, China, Croatia, Czech Republic,
Denmark, Estonia, Finland, France, Germany, Greece, Hong Kong, Hungary,
Iceland, India, Ireland, Italy, Japan, South Korea, Latvia, Lithuania,
The Former Yugoslav Republic of Macedonia, Malaysia, Mexico,
Netherlands, Norway, Poland, Portugal, Romania, Russia, Saudi Arabia,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Thailand, Turkey, UK, US, Yugoslavia
Benelux Economic Union (Benelux): note - acronym from Belgium,
Netherlands, and Luxembourg
established - 3 February 1958; effective - 1 November 1960
aim - to develop closer economic cooperation and integration
members - (3) Belgium, Luxembourg, Netherlands
Big Seven: note - membership is the same as the Group of 7
established - NA 1975
aim - to discuss and coordinate major economic policies
members - (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus
the US
Big Six: note - not to be confused with the Group of 6
established - NA 1967
aim - to foster economic cooperation
members - (6) Canada, France, Germany, Italy, Japan, UK
Black Sea Economic Cooperation Zone (BSEC): established - 25 June 1992
aim - to enhance regional stability through economic cooperation
members - (11) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece,
Moldova, Romania, Russia, Turkey, Ukraine
observers - (7) Austria, Egypt, Israel, Italy, Poland, Slovakia,','8d9e7ae8251d147d965b4f8f0c4d146a431a592b38efca999e0d22ee046fcede','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a94085e24029278cc0c74f4bc3b0d3583803511c3f56a7c101cd3efed9c614f9',2001,'TN','Tunisia','communications',318,'Caribbean Community and Common Market (Caricom): established - 4 July
1973; effective - 1 August 1973
aim - to promote economic integration and development, especially among
the less developed countries
members - (14) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Jamaica, Montserrat, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago
associate members - (3) Anguilla, British Virgin Islands, Turks and
Caicos Islands
observers - (10) Aruba, Bermuda, Cayman Islands, Colombia, Dominican
Republic, Haiti, Mexico, Netherlands Antilles, Puerto Rico, Venezuela;
note - when Haiti has deposited an appropriate instrument of accession
with the Secretary General, it will become a full member of the
Community
Caribbean Development Bank (CDB): established - 18 October 1969;
effective - 26 January 1970
aim - to promote economic development and cooperation
regional members - (20) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia,
Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Trinidad and
Tobago, Turks and Caicos Islands, Venezuela
nonregional members - (5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC): see Monetary and
Economic Community of Central Africa (CEMAC)
Central African States Development Bank (BDEAC): note - acronym from
Banque de Developpement des Etats de l''Afrique Centrale
established - 3 December 1975
aim - to provide loans for economic development
members - (9) Cameroon, Central African Republic, Chad, Republic of the
Congo, Equatorial Guinea, France, Gabon, Germany, Kuwait
Central American Bank for Economic Integration (BCIE): note - acronym
from Banco Centroamericano de Integracion Economico
established - 13 December 1960 signature of Articles of Agreement; 31
May 1961 began operations
aim - to promote economic integration and development
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members - (4) Argentina, Colombia, Mexico, Taiwan
Central American Common Market (CACM): established - 13 December 1960,
collapsed in 1969, reinstated in 1991
aim - to promote establishment of a Central American Common Market
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua;
note - Panama, although not a member, pursues full regional cooperation
Central European Initiative (CEI): note - evolved from the
Quadrilateral Initiative and the Hexagonal Initiative
established - 11 November 1989 as the Quadrilateral Initiative, 27 July
1991 became the Hexagonal Initiative, NA July 1992 present name adopted
aim - to form an economic and political cooperation group for the
region between the Adriatic and the Baltic Seas
members - (17) Albania, Austria, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Hungary, Italy, The Former Yugoslav
Republic of Macedonia, Moldova, Poland, Romania, Slovakia, Slovenia,
Ukraine, Yugoslavia
centrally planned economies : a term applied mainly to the
traditionally communist states that looked to the former USSR for
leadership; most are now evolving toward more democratic and market-
oriented systems; also known formerly as the Second World or as the
communist countries; through the 1980s, this group included Albania,
Bulgaria, Cambodia, China, Cuba, Czechoslovakia, GDR, Hungary, North
Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam, Yugoslavia
Colombo Plan (CP): established - NA May 1950 proposal was adopted; 1
July 1951 commenced full operations
aim - to promote economic and social development in Asia and the
Pacific
members - (24) Afghanistan, Australia, Bangladesh, Bhutan, Burma,
Cambodia, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos,
Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Singapore, Sri Lanka, Thailand, US
Commonwealth (C): note - also known as Commonwealth of Nations
established - 31 December 1931
aim - to foster multinational cooperation and assistance, as a
voluntary association that evolved from the British Empire
members - (54) Antigua and Barbuda, Australia, The Bahamas, Bangladesh,
Barbados, Belize, Botswana, Brunei, Cameroon, Canada, Cyprus, Dominica,
Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius,
Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (suspended), Papua
New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Seychelles, Sierra Leone, Singapore, Solomon
Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad
and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia, Zimbabwe
Commonwealth of Independent States (CIS): established - 8 December
1991; effective - 21 December 1991
aim - to coordinate intercommonwealth relations and to provide a
mechanism for the orderly dissolution of the USSR
members - (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan,
Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,','9abcc43bd4992f40049f7eb9fd63a06f25e65af803101507f3f9f5efedd91dae','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e380d2fc6da0473102a24a0c1663476c5127091dd3ddfa6e4341ab45a25b62f',2001,'UZ','Uzbekistan','communications',319,'communist countries: traditionally the Marxist-Leninist states with
authoritarian governments and command economies based on the Soviet
model; most of the original and the successor states are no longer
communist; see centrally planned economies
Coordinating Committee on Export Controls (COCOM): established in 1949
to control the export of strategic products and technical data from
member countries to proscribed destinations; members were Australia,
Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan,
Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US;
abolished 31 March 1994; COCOM members established a new organization,
the Wassenaar Arrangement, with expanded membership on 12 July 1996
which focuses on nonproliferation export controls as opposed to East-
West control of advanced technology
Council for Mutual Economic Assistance (CEMA): note - also known as
CMEA or Comecon
established 25 January 1949 to promote the development of socialist
economies and abolished 1 January 1991; members included Afghanistan
(observer), Albania (had not participated since 1961 break with USSR),
Angola (observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia (observer),
GDR, Hungary, Laos (observer), Mongolia, Mozambique (observer),
Nicaragua (observer), Poland, Romania, USSR, Vietnam, Yemen (observer),
Yugoslavia (associate)
Council of Arab Economic Unity (CAEU): established - 3 June 1957;
effective - 30 May 1964
aim - to promote economic integration among Arab nations
members - (11 plus the Palestine Liberation Organization) Egypt, Iraq,
Jordan, Kuwait, Libya, Mauritania, Somalia, Sudan, Syria, UAE, Yemen,
Palestine Liberation Organization
Council of Europe (CE): established - 5 May 1949; effective - 3 August
1949
aim - to promote increased unity and quality of life in Europe
members - (43) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium,
Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Malta, Moldova, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Turkey, Ukraine, UK
guests - (2) Bosnia and Herzegovina, Yugoslavia
observers - (5) Canada, Israel, Japan, Mexico, US
Council of the Baltic Sea States (CBSS): established - 6 March 1992
aim - to promote cooperation among the Baltic Sea states in the areas
of aid to new democratic institutions, economic development,
humanitarian aid, energy and the environment, cultural programs and
education, and transportation and communication
members - (12) Denmark, Estonia, EU, Finland, Germany, Iceland, Latvia,
Lithuania, Norway, Poland, Russia, Sweden
Council of the Entente (Entente): established - 29 May 1959
aim - to promote economic, social, and political coordination
members - (5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
countries in transition: a term used by the International Monetary
FUND (IMF) for the middle group in its hierarchy of advanced economies,
countries in transition, and developing countries; recently published
IMF statistics include the following 28 countries in transition:
Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic
of Macedonia, Moldova, Mongolia, Poland, Romania, Russia, Slovakia,
Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan, Yugoslavia;
note - this group is identical to the group traditionally referred to
as the "former USSR/Eastern Europe" except for the addition of Mongolia
Customs Cooperation Council (CCC): note - also known as World Customs
Organization (WCO)
established - 15 December 1950
aim - to promote international cooperation in customs matters
members - (153) Albania, Algeria, Andorra, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados,
Belarus, Belgium, Benin, Bermuda, Bolivia, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada, Cape Verde,
Central African Republic, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Haiti, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait,
Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, Macau, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
developed countries (DCs): the top group in the hierarchy of developed
countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less
developed countries (LDCs); includes the market-oriented economies of
the mainly democratic nations in the Organization for Economic
Cooperation and Development (OECD), Bermuda, Israel, South Africa, and
the European ministates; also known as the First World, high-income
countries, the North, industrial countries; generally have a per capita
GDP in excess of $10,000 although four OECD countries and South Africa
have figures well under $10,000 and two of the excluded OPEC countries
have figures of more than $10,000; the 35 DCs are: Andorra, Australia,
Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland,
France, Germany, Greece, Holy See, Iceland, Ireland, Israel, Italy,
Japan, Liechtenstein, Luxembourg, Malta, Mexico, Monaco, Netherlands,
NZ, Norway, Portugal, San Marino, South Africa, Spain, Sweden,
Switzerland, Turkey, UK, US; note - similar to the new International
Monetary Fund (IMF) term "advanced economies" which adds Hong Kong,
South Korea, Singapore, and Taiwan but drops Malta, Mexico, South
Africa, and Turkey
developing countries: a term used by the International Monetary Fund
(IMF) for the bottom group in its hierarchy of advanced economies,
countries in transition, and developing countries; recently published
IMF statistics include the following 126 developing countries:
Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba,
The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan,
Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia,
Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica,
Jordan, Kenya, Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Morocco, Mozambique, Namibia, Nepal, Netherlands Antilles, Nicaragua,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia,
South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, UAE, Uganda,
Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note -
this category would presumably also cover the following 46 other
countries that are traditionally included in the more comprehensive
group of "less developed countries": American Samoa, Anguilla, British
Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos
Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana,
French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada,
Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man,
Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk
Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico,
Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks
and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West
Bank, Western Sahara
East African Development Bank (EADB): established - 6 June 1967;
effective - 1 December 1967
aim - to promote economic development
members - (3) Kenya, Tanzania, Uganda
Economic and Social Council (ECOSOC): established - 26 June 1945;
effective - 24 October 1945
aim - to coordinate the economic and social work of the UN; includes
five regional commissions (Economic Commission for Africa, Economic
Commission for Europe, Economic Commission for Latin America and the
Caribbean, Economic and Social Commission for Asia and the Pacific,
Economic and Social Commission for Western Asia) and 9 functional
commissions (Commission for Social Development, Commission on Human
Rights, Commission on Narcotic Drugs, Commission on the Status of
Women, Commission on Population and Development, Statistical
Commission, Commission on Science and Technology for Development,
Commission on Sustainable Development, and Commission on Crime
Prevention and Criminal Justice)
members - (54) selected on a rotating basis from all regions
Economic Community of the Great Lakes Countries (CEPGL): note -
acronym from Communaute Economique des Pays des Grands Lacs
established - 20 September 1976
aim - to promote regional economic cooperation and integration
members - (3) Burundi, Democratic Republic of the Congo, Rwanda
Economic Community of West African States (ECOWAS): established - 28
May 1975
aim - to promote regional economic cooperation
members - (16) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The
Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Mauritania, Niger,
Nigeria, Senegal, Sierra Leone, Togo
Economic Cooperation Organization (ECO): established - 27-29 January
1985
aim - to promote regional cooperation in trade, transportation,
communications, tourism, cultural affairs, and economic development
members - (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan,
Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
associate member - (1) "Turkish Republic of Northern Cyprus"
Euro-Atlantic Partnership Council (EAPC): note - began as the North
Atlantic Cooperation Council (NACC); an extension of NATO
established - 8 November 1991; effective - 20 December 1991
aim - to discuss cooperation on mutual political and security issues
members - (46) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium,
Bulgaria, Canada, Croatia, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Moldova, Netherlands, Norway, Poland,
Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US,
European Bank for Reconstruction and Development (EBRD): established -
8-9 January 1990 (proposals made); 15 April 1991 (bank inaugurated)
aim - to facilitate the transition of seven centrally planned economies
in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market economies by committing
60% of its loans to privatization
members - (61) Albania, Armenia, Australia, Austria, Azerbaijan,
Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank
(EIB), Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malta, Mexico, Moldova, Mongolia,
Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan; note - includes all 25
members of the OECD; also includes the EU as a single entity
European Community (or European Communities, EC): was established 8
April 1965 to integrate the European Atomic Energy Community (Euratom),
the European Coal and Steel Community (ESC), the European Economic
Community (EEC or Common Market), and to establish a completely
integrated common market and an eventual federation of Europe; merged
into the European Union (EU) on 7 February 1992; member states at the
time of merger were Belgium, Denmark, France, Germany, Greece, Ireland,
Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA): established - 4 January 1960;
effective - 3 May 1960
aim - to promote expansion of free trade
members - (4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB): established - 25 March 1957; effective
- 1 January 1958
aim - to promote economic development of the EU and its predecessors,
the EEC and the EC
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain,
Sweden, UK
European Monetary Union (EMU): note - an integral part of the European
Union; also known as the European Economic and Monetary Union
proposed - 1-2 December 1969 at summit conference of heads of
government; signed - 7 February 1992 - Maastricht Treaty
aim - to promote a single market by creating a single currency, the
euro; time table - 2 May 1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and stock exchanges begin using
euros; 1 January 2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
members - (12) Austria, Belgium, Finland, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain; note -
Denmark, Sweden, and UK decided not to join
European Organization for Nuclear Research (CERN): note - acronym
retained from the predecessor organization Conseil Europeenne pour la
Recherche Nucleaire
established - 1 July 1953; effective - 29 September 1954
aim - to foster nuclear research for peaceful purposes only
members - (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Italy, Netherlands, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers - (7) European Commission, Israel, Japan, Russia, Turkey,
United Nations Educational, Scientific, and Cultural Organization
(UNESCO), US
European Space Agency (ESA): established - 31 May 1975
aim - to promote peaceful cooperation in space research and technology
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Ireland, Italy, Netherlands, Norway, Portugal, Spain, Sweden,
Switzerland, UK
cooperating state - (1) Canada
European Union (EU): note - evolved from the European Community (EC)
established - 7 February 1992; effective - 1 November 1993
aim - to coordinate policy among the 15 members in three fields:
economics, building on the European Economic Community''s (EEC) efforts
to establish a common market and eventually a common currency to be
called the ''euro'', which superseded the EU''s accounting unit, the ECU;
defense, within the concept of a Common Foreign and Security Policy
(CFSP); and justice and home affairs, including immigration, drugs,
terrorism, and improved living and working conditions
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain,
Sweden, UK
membership applicants - (13) Bulgaria, Cyprus, Czech Republic, Estonia,
Hungary, Latvia, Lithuania, Malta, Poland, Romania, Slovakia, Slovenia,
Turkey
First World: another term for countries with advanced, industrialized
economies; this term is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO): established - 16 October 1945
aim - to raise living standards and increase availability of
agricultural products, as a UN specialized agency
members - (180) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, UAE, UK,
US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
applicant member - (1) Yugoslavia
former Soviet Union (FSU): former term often used to identify as a
group the successor nations to the Soviet Union or USSR; this group of
15 countries consists of Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE): the middle group in the
hierarchy of developed countries (DCs), former USSR/Eastern Europe
(former USSR/EE), and less developed countries (LDCs); these countries
are in political and economic transition and may well be grouped
differently in the near future; this group of 27 countries consists of
Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic
of Macedonia, Moldova, Poland, Romania, Russia, Slovakia, Slovenia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan, Yugoslavia; this group
is identical to the IMF group "countries in transition" except for the
IMF''s inclusion of Mongolia
Four Dragons: the four small Asian less developed countries (LDCs)
that have experienced unusually rapid economic growth; also known as
the Four Tigers; this group consists of Hong Kong, South Korea,
Singapore, Taiwan; these countries are included in the IMF''s "advanced
economies" group
Franc Zone (FZ): note - also known as Conference des Ministres des
Finances des Pays de la Zone Franc
established - NA 1964
aim - to form a monetary union among countries whose currencies are
linked to the French franc
members - (16) Benin, Burkina Faso, Cameroon, Central African Republic,
Chad, Comoros, Republic of the Congo, Cote d''Ivoire, Equatorial Guinea,
France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo; note - France
includes metropolitan France, the four overseas departments of France
(French Guiana, Guadeloupe, Martinique, Reunion), the two territorial
collectivities of France (Mayotte, Saint Pierre and Miquelon), and the
three overseas territories of France (French Polynesia, New Caledonia,
Wallis and Futuna)
Front Line States (FLS): established to achieve black majority rule in
South Africa; has since gone out of existence; members included Angola,
Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT): see the World Trade
Organization (WTrO)
Group of 2 (G-2): informal term that came into use about 1986; to
facilitate bilateral economic cooperation between the two most powerful
economic giants
Japan, US
Group of 3 (G-3): established - NA September 1990
aim - mechanism for policy coordination
members - (3) Colombia, Mexico, Venezuela
Group of 5 (G-5): established - 22 September 1985
aim - to coordinate the economic policies of five major noncommunist
economic powers
members - (5) France, Germany, Japan, UK, US
Group of 6 (G-6): note - also known as Groupe des Six Sur le
Desarmement; not to be confused with the Big Six
established - 22 May 1984
aim - to achieve nuclear disarmament
members - (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7): note - membership is the same as the Big Seven
established - 22 September 1985
aim - to facilitate economic cooperation among the seven major
noncommunist economic powers
members - (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada
and Italy
Group of 8 (G-8): established - NA October 1975
aim - to facilitate economic cooperation among the developed countries
(DCs) that participated in the Conference on International Economic
Cooperation (CIEC), held in several sessions between NA December 1975
and 3 June 1977
members - (9) Canada, EU (as one member), France, Germany, Italy,
Japan, Russia, UK, US
Group of 9 (G-9): established - NA
aim - to discuss matters of mutual interest on an informal basis
members - (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary,
Romania, Sweden, Yugoslavia
Group of 10 (G-10): note - also known as the Paris Club; includes the
wealthiest members of the IMF who provide most of the money to be
loaned and act as the informal steering committee; name persists in
spite of the addition of Switzerland on NA April 1984
established - NA October 1962
aim - to coordinate credit policy
members - (11) Belgium, Canada, France, Germany, Italy, Japan,
Netherlands, Sweden, Switzerland, UK, US
nonstate participants - (4) BIS, EU, IMF, OECD
Group of 11 (G-11): note - also known as the Cartagena Group
established - 21-22 June 1984, in Cartagena, Colombia
aim - to provide a forum for largest debtor nations in Latin America
members - (11) Argentina, Bolivia, Brazil, Chile, Colombia, Dominican
Republic, Ecuador, Mexico, Peru, Uruguay, Venezuela
Group of 15 (G-15): note - byproduct of the Nonaligned Movement
established - NA September 1989
aim - to promote economic cooperation among developing nations; to act
as the main political organ for the Nonaligned Movement
members - (15) Algeria, Argentina, Brazil, Egypt, India, Indonesia,
Jamaica, Malaysia, Mexico, Nigeria, Peru, Senegal, Venezuela, former
Yugoslavia, Zimbabwe
Group of 24 (G-24): established - 1 August 1989
aim - to promote the interests of developing countries in Africa, Asia,
and Latin America within the I','9f0fc68b3e66f3ab5613220f7689d0cb0bb23b759829fdccfcd5f473ee43d3ff','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44b6a15888712f04513d47f474780dff1eb0db644a9e486ef805c8b6f68a8ed6',2001,'UZ','Uzbekistan','communications',320,'MF
members - (24) Algeria, Argentina, Brazil, Colombia, Democratic
Republic of the Congo, Cote d''Ivoire, Egypt, Ethiopia, Gabon, Ghana,
Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru,
Philippines, Sri Lanka, Syria, Trinidad and Tobago, Venezuela,
Yugoslavia
Group of 77 (G-77): established - 15 June 1964 was set up; NA October
1967 first ministerial meeting
aim - to promote economic cooperation among developing countries; name
persists in spite of increased membership
members - (131 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, Antigua and Barbuda, Argentina, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq,
Jamaica, Jordan, Kenya, North Korea, South Korea, Kuwait, Laos,
Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Federated States of Micronesia, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Qatar, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization
Gulf Cooperation Council (GCC): note - also known as the Cooperation
Council for the Arab States of the Gulf
established - 25 May 1981
aim - to promote regional cooperation in economic, social, political,
and military affairs
members - (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
high-income countries: another term for the industrialized countries
with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC): established - 21 December 1982
aim - to organize and promote regional cooperation in all sectors,
especially economic
members - (5) Comoros, France (for Reunion), Madagascar, Mauritius,
new independent states (NIS): a term referring to all those countries
of the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs): former term for the newly
industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs): that subgroup of the less
developed countries (LDCs) that has experienced particularly rapid
industrialization of their economies; formerly known as the newly
industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea,
Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM): established - 1-6 September 1961
aim - to establish political and military cooperation apart from the
traditional East or West blocs
members - (113 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic,
Chad, Chile, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Ecuador,
Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, India,
Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan,
Panama, Papua New Guinea, Peru, Philippines, Qatar, Rwanda, Saint
Lucia, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation
Organization
observers - (16) Antigua and Barbuda, Armenia, Azerbaijan, Brazil,
China, Costa Rica, Croatia, Dominica, Dominican Republic, El Salvador,
Kazakhstan, Kyrgyzstan, Mexico, Paraguay, Ukraine, Uruguay
guests - (28) Australia, Austria, Bosnia and Herzegovina, Bulgaria,
Canada, Finland, France, Germany, Greece, Holy See, Hungary, Ireland,
Italy, Japan, South Korea, Netherlands, NZ, Norway, Poland, Portugal,
Romania, Russia, Slovakia, Slovenia, Sweden, Switzerland, UK, US
Nordic Council (NC): established - 16 March 1952; effective - 12
February 1953
aim - to promote regional economic, cultural, and environmental
cooperation
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
observers - (3) the Sami (Lapp) local parliaments of Finland, Norway,
and Sweden
Nordic Investment Bank (NIB): established - 4 December 1975; effective
- 1 June 1976
aim - to promote economic cooperation and development
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
North: a popular term for the rich industrialized countries generally
located in the northern portion of the Northern Hemisphere; the
counterpart of the South; see developed countries (DCs)
North Atlantic Treaty Organization (NATO): established - 4 April 1949
aim - to promote mutual defense and cooperation
members - (19) Belgium, Canada, Czech Republic, Denmark, France,
Germany, Greece, Hungary, Iceland, Italy, Luxembourg, Netherlands,
Norway, Poland, Portugal, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA): note - also known as OECD Nuclear Energy
Agency
established - 1 February 1958
aim - to promote the peaceful uses of nuclear energy; associated with
OECD
members - (27) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway,
Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG): note - also known as the London
Suppliers Group or the London Group
established - NA 1974; effective - NA 1975
aim - to establish guidelines for exports of nuclear materials,
processing equipment for uranium enrichment, and technical information
to countries of proliferation concern and regions of conflict and
instability
members - (39) Argentina, Australia, Austria, Belarus, Belgium, Brazil,
Bulgaria, Canada, Cyprus, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Latvia,
Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK, US
observer - (1) European Commission (a policy-planning body for the EU)
Organization for Economic Cooperation and Development (OECD):
established - 14 December 1960; effective - 30 September 1961
aim - to promote economic cooperation and development
members - (30) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
special member - (1) EU
Organization for Security and Cooperation in Europe (OSCE): note -
formerly the Conference on Security and Cooperation in Europe (CSCE)
established 3 July 1975
established - 1 January 1995
aim - to foster the implementation of human rights, fundamental
freedoms, democracy, and the rule of law; to act as an instrument of
early warning, conflict prevention, and crisis management; and to serve
as a framework for conventional arms control and confidence building
measures
members - (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands,
Norway, Poland, Portugal, Romania, Russia, San Marino, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan,
Ukraine, UK, US, Uzbekistan, Yugoslavia
partners for cooperation - (9) Algeria, Egypt, Israel, Japan, Jordan,
South Korea, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW):
established - 29 April 1997
aim - to enforce the Convention on the Prohibition of the Development,
Production, Stockpiling and Use of Chemical Weapons and on Their
Destruction; to provide a forum for consultation and cooperation among
the signatories of the Convention
members - (174) Afghanistan, Albania, Algeria, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, El Salvador, Eritrea, Equatorial Guinea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
Organization of African Unity (OAU): established - 25 May 1963
aim - to promote unity and cooperation among African states
members - (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The
Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya,
Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia,
Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
Organization of American States (OAS): established - 14 April 1890 as
the International Union of American Republics; 30 April 1948 adopted
present charter; effective - 13 December 1951
aim - to promote regional peace and security as well as economic and
social development
members - (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba
(excluded from formal participation since 1962), Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, US, Uruguay, Venezuela
observers - (50) Algeria, Angola, Austria, Azerbaijan, Belgium, Bosnia
and Herzegovina, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark,
Egypt, Equatorial Guinea, EU, Finland, France, Germany, Ghana, Greece,
Holy See, Hungary, India, Ireland, Israel, Italy, Japan, Kazakhstan,
South Korea, Latvia, Lebanon, Morocco, Netherlands, Norway, Pakistan,
Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia, Spain,
Sri Lanka, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK,
Argun River China, Russia 53 20 N 121 28 E
Aru Sea Pacific Ocean 6 15 S 135 00 E
Ascension Island Saint Helena 7 57 S 14 22 W
Ashgabat (capital) Turkmenistan 37 57 N 58 23 E
Ashkhabad (see Ashgabat) Turkmenistan 37 57 N 58 23 E
Asmara (capital) Eritrea 15 20 N 38 53 E
Asmera (see Asmara) Eritrea 15 20 N 38 53 E
As-Sudan (local name for Sudan 15 00 N 30 00 E
Sudan)
Assumption Island Seychelles 9 46 S 46 34 E
Astana (Akmola) (capital) Kazakhstan 51 10 N 71 30 E
Asuncion (capital) Paraguay 25 16 S 57 40 W
Asuncion Island Northern Mariana 19 40 N 145 24 E
Islands
Atacama (desert) Chile 23 00 S 70 10 W
Atacama (region) Chile 24 30 S 69 15 W
Athens (capital) Greece 37 59 N 23 44 E
Attu Island United States 52 55 N 172 57 E
Auckland Islands New Zealand 51 00 S 166 30 E
Australes, Iles (Iles Tubuai) French Polynesia 23 20 S 151 00 W
(island group)
Avarua (capital) Cook Islands 21 12 S 159 46 W
Axel Heiberg Island Canada 79 30 N 90 00 W
Azad Kashmir (region) Pakistan 34 30 N 74 00 E
Azarbaycan (local name for Azerbaijan 40 30 N 47 30 E
Azerbaijan)
Azerbaidzhan (local name for Azerbaijan 40 30 N 47 30 E
Azerbaijan)
Azores (islands) Portugal 38 30 N 28 00 W
Azov, Sea of Atlantic Ocean 49 00 N 36 00 E
Bab el Mandeb (strait) Indian Ocean 12 40 N 43 20 E
Babuyan Channel Pacific Ocean 18 44 N 121 40 E
Babuyan Islands Philippines 19 10 N 121 40 E
Baffin Bay Arctic Ocean 73 00 N 66 00 W
Baffin Island Canada 68 00 N 70 00 W
Baghdad (capital) Iraq 33 21 N 44 25 E
Baki (see Baku) Azerbaijan 40 23 N 49 51 E
Baku (capital) Azerbaijan 40 23 N 49 51 E
Baky (see Baku) Azerbaijan 40 23 N 49 51 E
Balabac Strait Pacific Ocean 7 35 N 117 00 E
Balearic Islands Spain 39 30 N 3 00 E
Balearic Sea (Iberian Sea) Atlantic Ocean 40 30 N 2 00 E
Bali (island) Indonesia 8 20 S 115 00 E
Bali Sea Indian Ocean 7 45 S 115 30 E
Balintang Channel Pacific Ocean 19 49 N 121 40 E
Balintang Islands Philippines 19 55 N 122 10 E
Balkan Peninsula Albania, Bosnia and 42 00 N 23 00 E
Herzegovina,
Bulgaria, Croatia,
Greece, The Former
Yugoslav Republic
of Macedonia,
Romania, Slovenia,
Turkey (European
part), Yugoslavia
Balleny Islands Antarctica 67 00 S 163 00 E
Balochistan (region) Pakistan 28 00 N 63 00 E
Baltic Sea Atlantic Ocean 57 00 N 19 00 E
Bamako (capital) Mali 12 39 N 8 00 W
Banaba (Ocean Island) Kiribati 0 52 S 169 35 E
Banat (region) Hungary, Romania, 45 30 N 21 00 E
Yugoslavia
Banda Sea Pacific Ocean 5 00 S 128 00 E
Bandar Seri Begawan (capital) Brunei 4 52 S 114 55 E
Bangka (island) Indonesia 2 30 S 106 00 E
Bangkok (capital) Thailand 13 45 N 100 31 E
Bangui (capital) Central African 4 22 N 18 35 E
Republic
Banjul (capital) The Gambia 13 28 N 16 39 W
Banks Island Australia 10 12 S 142 16 E
Banks Island Canada 75 15 N 121 30 W
Banks Islands (Iles Banks) Vanuatu 14 00 S 167 30 E
Barbuda (island) Antigua and Barbuda 17 38 N 61 48 W
Barents Sea Arctic Ocean 74 00 N 36 00 E
Barranquilla (city) Colombia 10 59 N 74 48 W
Bashi Channel Pacific Ocean 22 00 N 121 00 E
Basilan Strait Pacific Ocean 6 49 N 122 05 E
Basque Provinces Spain 43 00 N 2 30 W
Bass Strait Pacific Ocean 39 20 S 145 30 E
Basse-Terre (capital) Guadeloupe 16 00 N 61 44 W
Basseterre (capital) Saint Kitts and 17 18 N 62 43 W
Nevis
Bastia (city) France (Corsica) 42 42 N 9 27 E
Basutoland (former name for Lesotho 29 30 S 28 30 E
Lesotho)
Batan Islands Philippines 20 30 N 121 50 E
Bavaria (Bayern) (region) Germany 48 30 N 11 30 E
Beagle Channel Atlantic Ocean 54 53 S 68 10 W
Bear Island (see Bjornoya) Svalbard 74 26 N 19 05 E
Beaufort Sea Arctic Ocean 73 00 N 140 00 W
Bechuanaland (former name for Botswana 22 00 S 24 00 E
Botswana)
Beijing (capital) China 39 56 N 116 24 E
Beirut (capital) Lebanon 33 53 N 35 30 E
Bekaa Valley Lebanon 34 00 N 36 05 E
Belau (Palau Islands) Palau 7 30 N 134 30 E
Belep Islands (Iles Belep) New Caledonia 19 45 S 163 40 E
Belgian Congo (former name Democratic Republic 0 00 N 25 00 E
for Democratic Republic of of the Congo
the Congo)
Belgie (local name for Belgium 50 50 N 4 00 E
Belgium)
Belgique (local name for Belgium 50 50 N 4 00 E
Belgium)
Belgrade (capital) Yugoslavia 44 50 N 20 30 E
Belize City (capital) Belize 17 30 N 88 12 W
Belle Isle, Strait of Atlantic Ocean 51 35 N 56 30 W
Bellingshausen Sea Southern Ocean 71 00 S 85 00 W
Belmopan (capital) Belize 17 15 N 88 46 W
Belorussia (former name for Belarus 53 00 N 28 00 E
Belarus)
Benadir (region; former name Somalia 4 00 N 46 00 E
of Italian Somaliland)
Bengal, Bay of Indian Ocean 15 00 N 90 00 E
Berau, Gulf of Pacific Ocean 2 30 S 132 30 E
Bering Island Russia 55 00 N 166 30 E
Bering Sea Pacific Ocean 60 00 N 175 00 W
Bering Strait Pacific Ocean 65 30 N 169 00 W
Berkner Island Antarctica 79 30 S 49 30 W
Berlin (capital) Germany 52 31 N 13 24 E
Berlin, East (former name for Germany 52 30 N 13 33 E
eastern sector of Berlin)
Berlin, West (former name for Germany 52 30 N 12 20 E
western sector of Berlin)
Bern (capital) Switzerland 46 57 N 7 26 E
Bessarabia (region) Moldova, Romania, 47 00 N 28 30 E
Fernando de Noronha (island Brazil 3 51 S 32 25 W
group)
Fernando Po (island) (see Equatorial Guinea 3 30 N 8 42 E
Bioko)
Filipinas (local name for the Philippines 13 00 N 122 00 E
Philippines)
Finland, Gulf of Atlantic Ocean 60 00 N 27 00 E
Flores (island) Indonesia 8 45 S 121 00 E
Flores Sea Pacific Ocean 7 40 S 119 45 E
Florida, Straits of Atlantic Ocean 25 00 N 79 45 W
Former Soviet Union (FSU) Armenia,
Azerbaijan,
Belarus, Estonia,
Georgia,
Kazakhstan,
Kyrgyzstan, Latvia,
Lithuania, Moldova,
Russia, Tajikistan,
Turkmenistan,
Ukraine, Uzbekistan
Formosa (island) Taiwan 23 30 N 121 00 E
Formosa Strait (see Taiwan Pacific Ocean 24 00 N 119 00 E
Strait)
Foroyar (local name for Faroe Faroe Islands 62 00 N 7 00 W
Islands)
Fort-de-France (capital) Martinique 14 36 N 61 05 W
Franz Josef Land (island Russia 81 00 N 55 00 E
group)
Freetown (capital) Sierra Leone 8 30 N 13 15 W
French Cameroon (former name Cameroon 6 00 N 12 00 E
for Cameroon)
French Guinea (former name Guinea 11 00 N 10 00 W
for Guinea)
French Indochina (former name Cambodia, Laos, 15 00 N 107 00 E
for French possessions in Vietnam
southeast Asia)
French Morocco (former name Morocco 32 00 N 5 00 W
for Morocco)
French Somaliland (former Djibouti 11 30 N 43 00 W
name for Djibouti)
French Sudan (former name for Mali 17 00 N 4 00 W
Mali)
French Territory of the Afars Djibouti 11 30 N 43 00 E
and Issas (FTAI) (former name
for Djibouti)
French Togoland (former name Togo 8 00 N 1 10 E
for Togo)
French West Indies (former Guadeloupe, 16 30 N 62 00 W
name for French possessions Martinique
in the West Indies)
Friendly Islands Tonga 20 00 S 175 00 W
Frisian Islands Denmark, Germany, 53 35 N 6 40 E','150a5b04d6c87342e4520649868231f1334398d15d56ae0ffa092398f0f1951a','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ede40d5e73ee08e4f4b41b55a9b4677226f7dd2fbd8a9d7722a2c82f144c413',2001,'SC','Seychelles','communications',321,'industrial countries: another term for the developed countries; see
developed countries (DCs)
Inter-American Development Bank (IADB): note - also known as Banco
Interamericano de Desarrollo (BID)
established - 8 April 1959; effective - 30 December 1959
aim - to promote economic and social development in Latin America
members - (46) Argentina, Austria, The Bahamas, Barbados, Belgium,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Croatia,
Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France,
Germany, Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica,
Japan, Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru,
Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and
Tobago, UK, US, Uruguay, Venezuela
Inter-Governmental Authority on Development (IGAD): note - formerly
known as Inter-Governmental Authority on Drought and Development
(IGADD)
established - 15-16 January 1986 as the Inter-Governmental Authority on
Drought and Development; revitalized - 21 March 1996 as the Inter-
Governmental Authority on Development
aim - to promote a social, economic, and scientific community among its
members
members - (6) Djibouti, Eritrea, Ethiopia, Kenya, Sudan, Uganda
International Atomic Energy Agency (IAEA): established - 26 October
1956; effective - 29 July 1957
aim - to promote peaceful uses of atomic energy
members - (130) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Australia, Austria, Bangladesh, Belarus, Belgium, Benin,
Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina Faso, Burma,
Cambodia, Cameroon, Canada, Chile, China, Colombia, Democratic Republic
of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, Ethiopia, Finland, France, Gabon, Georgia, Germany, Ghana,
Greece, Guatemala, Haiti, Holy See, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malaysia, Mali, Malta, Marshall Islands,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Namibia,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria,
Tanzania, Thailand, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,','d073172fc26e5d1c8eefe82e8412721cc6796d73c870ccdf5c43229f28aab2b6','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ccf70220a3925427948ac6bcf26e1386c28b1c45f087178683c3a526ab61f6a',2001,'QA','Qatar','communications',322,'International Labor Organization (ILO): established - 28 June 1919 set
up as part of Treaty of Versailles; 11 April 1919 became operative; 14
December 1946 affiliated with the UN
aim - to deal with world labor issues; a UN specialized agency
members - (175) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
International Maritime Organization (IMO): note - name changed from
Intergovernmental Maritime Consultative Organization (IMCO) on 22 May
1982
established - 6 March 1948 set up as the Inter-Governmental Maritime
Consultative Organization; effective - 17 March 1958
aim - to deal with international maritime affairs; a UN specialized
agency
members - (158) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and
Herzegovina, Brazil, Brunei, Bulgaria, Burma, Cambodia, Cameroon,
Canada, Cape Verde, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, North Korea, South Korea, Kuwait, Latvia, Lebanon, Liberia,
Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Ukraine,
UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia
associate members - (2) Hong Kong, Macau
International Mobile Satellite Organization (Inmarsat): note -
formerly International Maritime Satellite Organization
established - 3 September 1976; effective - 16 July 1979
aim - to provide worldwide communications for commercial, distress, and
safety applications, at sea, in the air, and on land
members - (86) Algeria, Argentina, Australia, The Bahamas, Bahrain,
Bangladesh, Belarus, Belgium, Bosnia and Herzegovina, Brazil, Brunei,
Bulgaria, Cameroon, Canada, Chile, China, Colombia, Costa Rica,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Egypt, Finland, France,
Gabon, Georgia, Germany, Ghana, Greece, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Israel, Italy, Japan, Kenya, South Korea,
Kuwait, Latvia, Lebanon, Liberia, Malaysia, Malta, Marshall Islands,
Mauritius, Mexico, Monaco, Mozambique, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Saudi Arabia, Senegal, Singapore, Slovakia,
South Africa, Spain, Sri Lanka, Sweden, Switzerland, Tanzania,
Thailand, Tunisia, Turkey, Ukraine, UAE, UK, US, Vietnam, Yugoslavia
International Monetary Fund (IMF): established - 22 July 1944;
effective - 27 December 1945
aim - to promote world monetary stability and economic development; a
UN specialized agency
members - (183) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
International Olympic Committee (IOC): established - 23 June 1894
aim - to promote the Olympic ideals and administer the Olympic games:
2002 Winter Olympics in Salt Lake City, United States; 2004 Summer
Olympics in Athens, Greece; 2006 Winter Olympics in Turin, Italy
National Olympic Committees - (199 and the Palestine Liberation
Organization) Afghanistan, Albania, Algeria, American Samoa, Andorra,
Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto
Rico, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Virgin Islands,
Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization
International Organization for Migration (IOM): note - established as
Provisional Intergovernmental Committee for the Movement of Migrants
from Europe; renamed Intergovernmental Committee for European Migration
(ICEM) on 15 November 1952; renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current name adopted 14 November 1989
established - 5 December 1951
aim - to facilitate orderly international emigration and immigration
members - (79) Albania, Algeria, Angola, Argentina, Armenia, Australia,
Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Bulgaria, Burkina
Faso, Canada, Chile, Colombia, Costa Rica, Cote d''Ivoire Croatia,
Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Finland, France, Germany, Greece, Guatemala, Guinea, Guinea-
Bissau, Haiti, Honduras, Hungary, Israel, Italy, Japan, Jordan, Kenya,
South Korea, Kyrgyzstan, Latvia, Liberia, Lithuania, Luxembourg, Mali,
Morocco, Netherlands, Nicaragua, Norway, Pakistan, Panama, Paraguay,
Peru, Philippines, Poland, Portugal, Romania, Senegal, Slovakia,
Slovenia, South Africa, Sri Lanka, Sudan, Sweden, Switzerland,
Tajikistan, Tanzania, Thailand, Tunisia, Uganda, US, Uruguay,
Venezuela, Yemen, Zambia
observers - (43) Afghanistan, Belarus, Bhutan, Bosnia and Herzegovina,
Brazil, Cambodia, Cape Verde, Democratic Republic of the Congo,
Republic of the Congo, Cuba, Estonia, Ethiopia, Georgia, Ghana, Holy
See, India, Indonesia, Iran, Ireland, Jamaica, Kazakhstan, The Former
Yugoslav Republic of Macedonia, Madagascar, Malta, Mexico, Moldova,
Mozambique, Namibia, NZ, Papua New Guinea, Russia, Rwanda, San Marino,
Sao Tome and Principe, Somalia, Spain, Turkey, Turkmenistan, Ukraine,
UK, Vietnam, Yugoslavia, Zimbabwe
International Organization for Standardization (ISO): established - NA
February 1947
aim - to promote the development of international standards with a view
to facilitating international exchange of goods and services and to
developing cooperation in the sphere of intellectual, scientific,
technological and economic activity
members - (91 national standards organizations) Algeria, Argentina,
Armenia, Australia, Austria, Bangladesh, Barbados, Belarus, Belgium,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Canada, Chile,
China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Ecuador, Egypt, Ethiopia, Finland, France, Germany, Ghana,
Greece, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel,
Italy, Jamaica, Japan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Libya, Luxembourg, The Former Yugoslav Republic of Macedonia,
Malaysia, Malta, Mauritius, Mexico, Mongolia, Morocco, Netherlands, NZ,
Nigeria, Norway, Pakistan, Panama, Philippines, Poland, Portugal,
Romania, Russia, Saudi Arabia, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania,
Thailand, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yugoslavia, Zimbabwe
correspondent members - (34) Albania, Azerbaijan, Bahrain, Bolivia,
Brunei, Cameroon, Democratic Republic of the Congo, Cote d''Ivoire, El
Salvador, Estonia, Guatemala, Honduras, Hong Kong, Jordan, Kyrgyzstan,
Latvia, Lebanon, Lithuania, Madagascar, Malawi, Moldova, Mozambique,
Namibia, Nepal, Nicaragua, Oman, Papua New Guinea, Paraguay, Peru,
Qatar, Rwanda, Sudan, Turkmenistan, Uganda
subscriber members - (11) Benin, Burkina Faso, Cambodia, Comoros,
Dominican Republic, Fiji, Grenada, Guyana, Lesotho, Mali, Saint Lucia
International Red Cross and Red Crescent Movement (ICRM): established
- NA 1928
aim - to promote worldwide humanitarian aid through the International
Committee of the Red Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent Societies (IFRCS; formerly
League of Red Cross and Red Crescent Societies or LORCS) in peacetime
National Societies - (176 countries); note - same as membership for
International Federation of Red Cross and Red Crescent Societies
(IFRCS)
International Telecommunication Union (ITU): established - 17 May 1865
set up as the International Telegraph Union; 9 December 1932 adopted
present name
effective - 1 January 1934; affiliated with the UN - 15 November 1947
aim - to deal with world telecommunications issues; a UN specialized
agency
members - (189) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE,
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
International Telecommunications Satellite Organization (Intelsat):
established - 20 August 1964 set up as the Telecommunications Satellite
Consortium; 12 February 1973 adopted present name
aim - to develop and operate a global commercial telecommunications
satellite system
members - (143) Afghanistan, Algeria, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Ethiopia, Fiji, Finland, France, Gabon, Germany, Ghana, Greece,
Guatemala, Guinea, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Lebanon, Libya,
Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saudi Arabia, Senegal, Singapore, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Uganda, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
nonsignatory users - (42) Albania, Antigua and Barbuda, Belarus,
Belize, Burma, Burundi, Cambodia, Cook Islands, Cuba, Djibouti,
Eritrea, The Gambia, Guinea-Bissau, Guyana, Kiribati, North Korea,
Laos, Latvia, Lesotho, Liberia, Lithuania, The Former Yugoslav Republic
of Macedonia, Maldives, Marshall Islands, Moldova, Nauru, Niue, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands,
Suriname, Tonga, Turkmenistan, Tuvalu, Ukraine, Vanuatu
Islamic Development Bank (IDB): established - 15 December 1973 by
declaration of intent; effective - 12 August 1974
aim - to promote Islamic economic aid and social development
members - (52 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The
Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan,
Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives,
Mali, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan, Qatar,
Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria,
Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen,
Palestine Liberation Organization
Latin American Economic System (LAES): note - also known as Sistema
Economico Latinoamericana (SELA)
established - 17 October 1975
aim - to promote economic and social development through regional
cooperation
members - (28) Argentina, The Bahamas, Barbados, Belize, Bolivia,
Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican Republic, Ecuador,
El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica,
Mexico, Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and
Tobago, Uruguay, Venezuela
observers - (21) Andean Promotion Corporation, China, Costa Rica,
Dominican Republic, El Salvador, EEC, Guatemala, Honduras, IADB, Inter-
American Institute for Agricultural Cooperation, Italy, Nicaragua, OAS,
Panama, Portugal, Romania, Russia, Spain, Switzerland, UN Development
Program, UN Economic Commission for Latin America and the Caribbean
Latin American Integration Association (LAIA): note - also known as
Asociacion Latinoamericana de Integracion (ALADI)
established - 12 August 1980; effective - 18 March 1981
aim - to promote freer regional trade
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba,
Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela
observers - (22) China, Commission of the European Communities,
Corporacion Andina de Fomento, Costa Rica, Dominican Republic, El
Salvador, Guatemala, Honduras, Inter-American Development Bank, Inter-
American Institute for Cooperation on Agriculture, Italy, Latin America
Economic System, Nicaragua, Organization of American States, Panama,
Portugal, Romania, Russia, Spain, Switzerland, United Nations
Development Program, United Nations Economic Commission for Latin
America and the Caribbean
least developed countries (LLDCs): that subgroup of the less developed
countries (LDCs) initially identified by the UN General Assembly in
1971 as having no significant economic growth, per capita GDPs normally
less than $1,000, and low literacy rates; also known as the undeveloped
countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan,
Botswana, Burkina Faso, Burma, Burundi, Cape Verde, Central African
Republic, Chad, Comoros, Djibouti, Equatorial Guinea, Eritrea,
Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos,
Lesotho, Malawi, Maldives, Mali, Mauritania, Mozambique, Nepal, Niger,
Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
less developed countries (LDCs): the bottom group in the hierarchy of
developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent
areas with low levels of output, living standards, and technology; per
capita GDPs are generally below $5,000 and often less than $1,500;
however, the group also includes a number of countries with high per
capita incomes, areas of advanced technology, and rapid rates of
growth; includes the advanced developing countries, developing
countries, Four Dragons (Four Tigers), least developed countries
(LLDCs), low-income countries, middle-income countries, newly
industrializing economies (NIEs), the South, Third World,
underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and
Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin
Islands, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape
Verde, Cayman Islands, Central African Republic, Chad, Chile, China,
Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia,
Falkland Islands, Fiji, French Guiana, French Polynesia, Gabon, The
Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, India, Indonesia, Iran, Iraq, Jamaica, Jersey,
Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos,
Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar, Malawi, Malaysia,
Maldives, Mali, Isle of Man, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia,
Montserrat, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands
Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk
Island, Northern Mariana Islands, Oman, Palau, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto Rico,
Qatar, Reunion, Rwanda, Saint Helena, Saint Kit','2487a49619049ea6ba412e27e62ce794d5836085b8a145e9759b7f54a1ca459f','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a20487ac928e6a2f026ec067aacd7ad50032c2c5773f623aced093be870d1479',2001,'QA','Qatar','communications',323,'ts and Nevis, Saint
Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Taiwan, Tanzania, Thailand, Togo, Tokelau, Tonga,
Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE,
Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis
and Futuna, West Bank, Western Sahara, Yemen, Zambia, Zimbabwe; note -
similar to the new International Monetary Fund (IMF) term "developing
countries" which adds Malta, Mexico, South Africa, and Turkey but omits
in its recently published statistics American Samoa, Anguilla, British
Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos
Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana,
French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada,
Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man,
Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk
Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico,
Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks
and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West
Bank, Western Sahara
low-income countries: another term for those less developed countries
with below-average per capita GDPs; see less developed countries (LDCs)
middle-income countries: another term for those less developed
countries with above-average per capita GDPs; see less developed
countries (LDCs)
Monetary and Economic Community of Central Africa (CEMAC): note - was
formerly the Central African Customs and Economic Union (UDEAC)
established - 8 December 1964; effective - 1 January 1966
aim - to promote the establishment of a Central African Common Market
members - (6) Cameroon, Central African Republic, Chad, Republic of the
Congo, Equatorial Guinea, Gabon
Near Abroad: Russian term for the 14 non-Russian successor states of
the USSR, in which 25 million ethnic Russians live and in which Moscow
has expressed a strong national security interest; the 14 countries are
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,','2cdaae526c447b7ce8e0955154d3b117edeeba69abb2e0e134036e936b5237fe','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b53cb60e7e9b58c18f491cca1d09a7fdf9a7aa3171d7778096ccf434336c3bc',2001,'YE','Yemen','communications',324,'Organization of Arab Petroleum Exporting Countries (OAPEC):
established - 9 January 1968
aim - to promote cooperation in the petroleum industry
members - (10) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar,
Saudi Arabia, Syria, UAE
Organization of Eastern Caribbean States (OECS): established - 18 June
1981; effective - 4 July 1981
aim - to promote political, economic, and defense cooperation
members - (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines
associate members - (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting Countries (OPEC): established - 14
September 1960
aim - to coordinate petroleum policies
members - (11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Organization of the Islamic Conference (OIC): established - 22-25
September 1969
aim - to promote Islamic solidarity in economic, social, cultural, and
political affairs
members - (55 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The
Gambia, Guinea, Guinea-Bissau, Guyana, Indonesia, Iran, Iraq, Jordan,
Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives,
Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan,
Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname,
Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE,
Uzbekistan, Yemen, Palestine Liberation Organization
observers - (12) Bosnia and Herzegovina, Central African Republic, Cote
d''Ivoire, ECO, LAS, NAM, Moro National Liberation Front of the
Philippines, OAU, Thailand, Turkish Muslim Community of Kirbris,
"Turkish Republic of Northern Cyprus", UN
Pacific Community: note - formerly known as the South Pacific
Commission (SPC)
established - 6 February 1947; effective - 29 July 1948
aim - to promote regional cooperation in economic and social matters
members - (27) American Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands,
Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon Islands,
Tokelau, Tonga, Tuvalu, UK, US, Vanuatu, Wallis and Futuna
Partnership for Peace (PFP): established - 10-11 January 1994
aim - to expand and intensify political and military cooperation
throughout Europe, increase stability, diminish threats to peace, and
build relationships by promoting the spirit of practical cooperation
and commitment to democratic principles that underpin NATO; program
under the auspices of NATO
members - (29) Albania, Armenia, Austria, Azerbaijan, Belarus,
Bulgaria, Croatia, Czech Republic, Estonia, Finland, Georgia, Hungary,
Ireland, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav
Republic of Macedonia, Moldova, Poland, Romania, Russia, Slovakia,
Slovenia, Sweden, Switzerland, Turkmenistan, Ukraine, Uzbekistan
Permanent Court of Arbitration (PCA): established - 29 July 1899
aim - to facilitate the settlement of international disputes
members - (78) Argentina, Australia, Austria, Belarus, Belgium,
Bolivia, Brazil, Bulgaria, Canada, Chile, China, Colombia, Democratic
Republic of the Congo, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Dominican Republic, Ecuador, Egypt, El Salvador, Finland, France,
Germany, Greece, Guatemala, Guyana, Haiti, Honduras, Hungary, India,
Iran, Iraq, Israel, Italy, Japan, Jordan, South Korea, Laos, Lebanon,
Luxembourg, Malta, Mexico, Netherlands, NZ, Nicaragua, Nigeria, Norway,
Pakistan, Panama, Paraguay, Peru, Poland, Portugal, Romania, Russia,
Senegal, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Switzerland, Thailand, Turkey, Uganda, Ukraine, UK,
US, Uruguay, Venezuela, Zambia, Zimbabwe
Rio Group (RG): note - formerly known as Grupo de los Ocho,
established in December 1986; composed of the Contadora Group and the
Lima Group
established - NA 1988
aim - to consult on regional Latin American issues
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador,
Mexico, Panama, Paraguay, Peru, Uruguay, Venezuela
Second World: another term for the traditionally Marxist-Leninist
states of the USSR and Eastern Europe, with authoritarian governments
and command economies based on the Soviet model; the term is fading
from use; see centrally planned economies
socialist countries: in general, countries in which the government
owns and plans the use of the major factors of production; note - the
term is sometimes used incorrectly as a synonym for communist countries
South: a popular term for the poorer, less industrialized countries
generally located south of the developed countries; the counterpart of
the North; see less developed countries (LDCs)
South Asian Association for Regional Cooperation (SAARC): established
- 8 December 1985
aim - to promote economic, social, and cultural cooperation
members - (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri
Lanka
South Pacific Forum (SPF): established - 5 August 1971
aim - to promote regional cooperation in political matters
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
South Pacific Regional Trade and Economic Cooperation Agreement
(Sparteca): established - NA 1981
aim - to redress unequal trade relationships of Australia and New
Zealand with small island economies in the Pacific region
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
Southern African Customs Union (SACU): established - 11 December 1969
aim - to promote free trade and cooperation in customs matters
members - (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
Southern African Development Community (SADC): note - evolved from the
Southern African Development Coordination Conference (SADCC)
established - 17 August 1992
aim - to promote regional economic development and integration
members - (14) Angola, Botswana, Democratic Republic of the Congo,
Lesotho, Malawi, Mauritius, Mozambique, Namibia, Seychelles, South
Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common Market: note
- also known as Mercado Comun del Cono Sur (Mercosur)
established - 26 March 1991
aim - to increase regional economic cooperation
members - (4) Argentina, Brazil, Paraguay, Uruguay
associate member - (2) Bolivia, Chile
Third World: another term for the less developed countries; the term
is obsolescent; see less developed countries (LDCs)
underdeveloped countries: refers to those less developed countries
with the potential for above-average economic growth; see less
developed countries (LDCs)
undeveloped countries: refers to those extremely poor less developed
countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
United Nations (UN): established - 26 June 1945; effective - 24
October 1945
aim - to maintain international peace and security and to promote
cooperation involving economic, social, cultural, and humanitarian
problems
constituent organizations - the UN is composed of six principal organs
and numerous subordinate agencies and bodies as follows:
1) Secretariat
2) General Assembly: International Research and Training Institute for
the Advancement of Women (INSTRAW), United Nations Center for Human
Settlements (Habitat), United Nations Children''s Fund (UNICEF), United
Nations Conference on Trade and Development (UNCTAD), United Nations
Development Program (UNDP), United Nations Drug Control Program
(UNDCP), United Nations Environment Program (UNEP), United Nations High
Commissioner for Human Rights (UNHCHR), United Nations High
Commissioner for Refugees (UNHCR), United Nations Institute for
Disarmament Research (UNIDIR), United Nations Institute for Training
and Research (UNITAR), United Nations Interregional Crime and Justice
Research Institute (UNICRI), United Nations Population Fund (UNFPA),
United Nations Relief and Works Agency for Palestine Refugees in the
Near East (UNRWA), United Nations Research Institute for Social
Development (UNRISD), and United Nations University (UNU), World Food
Program (WFP)
3) Security Council: International Criminal Tribunal for the Former
Yugoslavia (ICTY), International Criminal Tribunal for Rwanda (ICTR),
United Nations Compensation Commission, United Nations Disengagement
Observer Force (UNDOF), United Nations Interim Administration Mission
in Kosovo (UNMIK), United Nations Interim Force in Lebanon (UNIFIL),
United Nations Iraq/Kuwait Boundary Demarcation Commission, United
Nations Iraq-Kuwait Observation Mission (UNIKOM), United Nations
Military Observer Group in India and Pakistan (UNMOGIP), United Nations
Mission for the Referendum in Western Sahara (MINURSO), United Nations
Mission in Bosnia and Herzegovina (UNMIBH), United Nations Mission in
Ethiopia and Eritrea (UNMEE), United Nations Mission in Sierra Leone
(UNAMSIL), United Nations Mission of Observers in Prevlaka (UNMOP),
United Nations Monitoring and Verification Commission (UNMOVIC), United
Nations Observer Mission in Georgia (UNOMIG), United Nations
Organization Mission in the Democratic Republic of the Congo (MONUC),
United Nations Peace-Keeping Force in Cyprus (UNFICYP), United Nations
Transitional Administration in East Timor (UNTAET), and United Nations
Truce Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social
Development, Commission on Crime Prevention and Criminal Justice,
Commission on Human Rights, Commission on Narcotics Drugs, Commission
on Population and Development, Commission on Science and Technology for
Development, Commission on Sustainable Development, Commission on the
Status of Women, Economic and Social Commission for Asia and the
Pacific (ESCAP), Economic and Social Commission for Western Asia
(ESCWA), Economic Commission for Africa (ECA), Economic Commission for
Europe (ECE), Economic Commission for Latin America and the Caribbean
(ECLAC), Food and Agriculture Organization of the United Nations (FAO),
International Atomic Energy Agency (IAEA), International Bank for
Reconstruction and Development (IBRD), International Civil Aviation
Organization (ICAO), International Development Association (IDA),
International Finance Corporation (IFC), International Fund for
Agricultural Development (IFAD), International Labor Organization
(ILO), International Maritime Organization (IMO), International
Monetary Fund (IMF), International Telecommunication Union (ITU),
Statistical Commission, United Nations Educational, Scientific, and
Cultural Organization (UNESCO), United Nations Industrial Development
Organization (UNIDO), Universal Postal Union (UPU), World Health
Organization (WHO), World Intellectual Property Organization (WIPO),
World Meteorological Organization (WMO), World Tourism Organization
(WToO), and World Trade Organization (WTrO)
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
UN members - (189) Afghanistan, Albania, Algeria, Andorra, Angola,
Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,
Zimbabwe; note - all UN members are represented in the General Assembly
observers - (2 plus the Palestine Liberation Organization) Holy See,
Switzerland, Palestine Liberation Organization
United Nations Children''s Fund (UNICEF): note - acronym retained from
the predecessor organization, UN International Children''s Emergency
Fund
established - 11 December 1946
aim - to help establish child health and welfare services
members - (36) selected on a rotating basis from all regions
United Nations Civilian Police Mission in Haiti (MIPONUH): established
28 November 1997; to support the professionalization of the Haitian
National Police; established by UN Security Council; members were
Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo,
Tunisia, US; mission ended March 2000
United Nations Conference on Trade and Development (UNCTAD):
established - 30 December 1964
aim - to promote international trade
members - (191) all UN members plus Holy See, Switzerland
United Nations Development Program (UNDP): established - 22 November
1965
aim - to provide technical assistance to stimulate economic and social
development
members (executive board) - (36) selected on a rotating basis from all
regions
United Nations Disengagement Observer Force (UNDOF): established - 31
May 1974
aim - to observe the 1973 Arab-Israeli cease-fire; established by the
UN Security Council
members - (5) Austria, Canada, Japan, Poland, Slovakia
United Nations Educational, Scientific, and Cultural Organization
(UNESCO): established - 16 November 1945; effective - 4 November 1946
aim - to promote cooperation in education, science, and culture
members - (188) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
associate members - (5) Aruba, British Virgin Islands, Cayman Islands,
Macau, Netherlands Antilles
United Nations Environment Program (UNEP): established - 15 December
1972
aim - to promote international cooperation on all environmental matters
members - (58) selected on a rotating basis from all regions
United Nations General Assembly: established - 26 June 1945; effective
- 24 October 1945
aim - to function as the primary deliberative organ of the UN
members - (189) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR): established - 3
December 1949; effective - 1 January 1951
aim - to ensure the humanitarian treatment of refugees and find
permanent solutions to refugee problems
members (executive committee) - (57) Algeria, Argentina, Australia,
Austria, Bangladesh, Belgium, Brazil, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Cote d''Ivoire, Denmark, Ethiopia,
Finland, France, Germany, Greece, Holy See, Hungary, Iceland, India,
Iran, Ireland, Israel, Italy, Japan, South Korea, Lebanon, Lesotho,
Madagascar, Morocco, Mozambique, Namibia, Netherlands, Nicaragua,
Nigeria, Norway, Pakistan, Philippines, Poland, Russia, Somalia, South
Africa, Spain, Sudan, Sweden, Switzerland, Tanzania, Thailand, Tunisia,
Turkey, Uganda, UK, US, Venezuela
United Nations Industrial Development Organization (UNIDO):
established - 17 November 1966; effective - 1 January 1967
aim - UN specialized agency that promotes industrial development
especially among the members
members - (169) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
United Nations Institute for Training and Research (UNITAR):
established - 11 December 1963 adoption of the resolution establishing
the Institute; effective - 24 March 1965
aim - to help the UN become more effective through training and
research
members (Board of Trustees) - (20) Austria, Brazil, Cameroon, Chile,
China, Egypt, France, Ghana, Ireland, Japan, Kuwait, Mexico,
Netherlands, Nigeria, Russia, South Africa, Sweden, Switzerland,
Thailand, US; note - the UN Secretary General can appoint up to 30
members
United Nations Interim Administration Mission in Kosovo (UNMIK):
established - 10 June 1999
aim - to promote the establishment of substantial autonomy and self-
government in Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key infrastructure and
humanitarian and disaster relief
members - (49) Argentina, Austria, Bangladesh, Belgium, Bolivia,
Bulgaria, Canada, Czech Republic, Denmark, Egypt, Estonia, Fiji,
Finland, France, Germany, Ghana, Hungary, Iceland, India, Ireland,
Italy, Jordan, Kenya, Kyrgyzstan, Lithuania, Malawi, Malaysia, Nepal,
Netherlands, NZ, Nigeria, Norway, Pakistan, Philippines, Poland,
Portugal, Romania, Russia, Senegal, Spain, Sweden, Switzerland,
Tunisia, Turkey, Ukraine UK, US, Zambia, Zimbabwe
United Nations Interim Force in Lebanon (UNIFIL): established - 19
March 1978
aim - to confirm the withdrawal of Israeli forces, and assist in
reestablishing Lebanese authority in southern Lebanon; established by
the UN Security Council
members - (10) Fiji, Finland, France, Ghana, India, Ireland, Italy,
Nepal, Poland, Ukraine
United Nations Iraq-Kuwait Observation Mission (UNIKOM): established -
9 April 1991
aim - to observe and monitor the demilitarized zone established between
Iraq and Kuwait; established by the UN Security Council
members - (33) Argentina, Austria, Bangladesh, Canada, China, Denmark,
Fiji, Finland, France, Germany, Ghana, Greece, Hungary, India,
Indonesia, Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan, Poland,
Romania, Russia, Senegal, Singapore, Sweden, Thailand, Turkey, UK, US,
Uruguay, Venezuela
United Nations Military Observer Group in India and Pakistan (UNMOGIP):
established - 24 January 1949
aim - to observe the 1949 India-Pakistan cease-fire; established by the
UN Security Council
members - (9) Belgium, Chile, Denmark, Finland, Hungary, Italy, South
Korea, Sweden, Uruguay
United Nations Mission for the Referendum in Western Sahara (MINURSO):
established - 29 April 1991
aim - to supervise the cease-fire and conduct a referendum in Western
Sahara; established by the UN Security Council
members - (30) Argentina, Austria, Bangladesh, Belgium, China, Egypt,
El Salvador, France, Ghana, Greece, Guinea, Honduras, Hungary, India,
Ireland, Italy, Jordan, Kenya, South Korea, Malaysia, Nigeria, Norway,
Pakistan, Poland, Portugal, Russia, Senegal, Sweden, US, Uruguay
United Nations Mission in Bosnia and Herzegovina (UNMIBH): established
- 21 December 1995
aim - to establish an International Police Task Force (IPTF) to
implement the Dayton Peace Agreement in Bosnia and Herzegovina
members - (45) Argentina, Austria, Bangladesh, Bulgaria, Canada, Chile,
Czech Republic, Denmark, Egypt, Estonia, Fiji, Finland, France,
Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland,
Italy, Jordan, Kenya, Malaysia, Nepal, Netherlands, Nigeria, Norway,
Pakistan, Poland, Portugal, Romania, Russia, Senegal, Spain, Sweden,
Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, US, Vanuatu
United Nations Mission in Sierra Leone (UNAMSIL): established - 22
October 1999
aim - to cooperate with the','eae7304eff3e55a465b352db5f8cb96bb3c38d48e49d1aa5e9ef903a73916688','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93d24bedb2ac3e18466fac42c7c7427a122a405c8f62685829771c5160757d6c',2001,'YE','Yemen','communications',325,'Government of Sierra Leone and the other
parties to the Peace Agreement in the implementation of the agreement;
to monitor the military and security situation in Sierra Leone; to
monitor the disarmament and demobilization of combatants and members of
the Civil Defense Forces (CFD); to assist in monitoring respect for
international humanitarian law
members - (30) Bangladesh, Bolivia, Canada, Croatia, Czech Republic,
Denmark, Egypt, France, The Gambia, Ghana, Guinea, Indonesia, Jordan,
Kenya, Kyrgyzstan, Malaysia, Mali, Nepal, NZ, Nigeria, Norway,
Pakistan, Russia, Slovakia, Sweden, Thailand, Ukraine, UK, Uruguay,
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS)
note - abbreviated as Law of the Sea
opened for signature - 10 December 1982
entered into force - 16 November 1994
objective - to set up a comprehensive new legal regime for the sea and
oceans; to include rules concerning environmental standards as well as
enforcement provisions dealing with pollution of the marine environment
parties - (135) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Barbados, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burma, Cameroon, Cape Verde, Chile, China, Comoros,
Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominica,
Egypt, Equatorial Guinea, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iraq,
Ireland, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait,
Laos, Lebanon, Luxembourg, The Former Yugoslav Republic of Macedonia,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Nigeria,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Philippines, Poland, Portugal, Romania, Russia, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Sweden, Tanzania, Togo, Tonga, Trinidad and
Tobago, Tunisia, Uganda, Ukraine, UK, Uruguay, Vanuatu, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (35) Afghanistan,
Bangladesh, Belarus, Bhutan, Burkina Faso, Burundi, Cambodia, Canada,
Central African Republic, Chad, Colombia, Republic of the Congo,
Denmark, Dominican Republic, El Salvador, Ethiopia, Hungary, Iran,
North Korea, Lesotho, Liberia, Libya, Liechtenstein, Madagascar,
Malawi, Morocco, Niger, Niue, Qatar, Rwanda, Swaziland, Switzerland,
Thailand, Tuvalu, UAE
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in
Africa
note - abbreviated as Desertification
opened for signature - 14 October 1994
entered into force - 26 December 1996
objective - to combat desertification and mitigate the effects of
drought through national action programs that incorporate long-term
strategies supported by international cooperation and partnership
arrangements
parties - (172) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi,
Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Portugal, Qatar, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Solomon Islands, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
United Nations Framework Convention on Climate Change
note - abbreviated as Climate Change
opened for signature - 9 May 1992
entered into force - 21 March 1994
objective - to achieve stabilization of greenhouse gas concentrations
in the atmosphere at a low enough level to prevent dangerous
anthropogenic interference with the climate system
parties - (186) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (2) Afghanistan,','1edb77a2c8e3e67c3b037b4444f57a6ad21777603e975a7505dd62f7368fd5fc','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84749c18bc0a4b999cabecb885239df49595e04a4ef156001f2258371c6cffd5',2001,'ZM','Zambia','communications',326,'United Nations Mission of Observers in Prevlaka (UNMOP): established -
1 February 1996
aim - to monitor the demilitarization of the Prevlaka peninsula in
southern Croatia
members - (25) Argentina, Bangladesh, Belgium, Brazil, Canada, Czech
Republic, Denmark, Egypt, Finland, Ghana, Indonesia, Ireland, Jordan,
Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia,
Sweden, Switzerland, Ukraine
United Nations Mission of Observers in Tajikistan (UNMOT): established
16 December 1994; to monitor and investigate violations of the cease-
fire of 17 September 1994 between Tajikistan and the Tajik opposition
and to assist in the political negotiation process; established by the
UN Security Council; members were Austria, Bangladesh, Bulgaria, Czech
Republic, Denmark, Ghana, Indonesia, Jordan, Nepal, Nigeria, Poland,
Ukraine, Uruguay; mission ended May 2000
United Nations Monitoring and Verification Commission (UNMOVIC): note
- formerly known as United Nations Special Commission for the
Elimination of Iraq''s Weapons of Mass Destruction (UNSCOM)
established - NA December 1999
aim - to identify, account for, and eliminate Iraq''s weapons of mass
destruction and the capacity to produce them
members - (22) Australia, Austria, Belgium, Canada, China, Czech
Republic, Finland, France, Germany, Indonesia, Italy, Japan,
Netherlands, Nigeria, Norway, Poland, Russia, Sri Lanka, Sweden, UK,
US, Venezuela
United Nations Observer Mission in Georgia (UNOMIG): established - 24
August 1993
aim - to verify compliance with the cease-fire agreement, to monitor
weapons exclusion zone, and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security Council
members - (22) Albania, Austria, Bangladesh, Czech Republic, Denmark,
Egypt, France, Germany, Greece, Hungary, Indonesia, Jordan, South
Korea, Pakistan, Poland, Russia, Sweden, Switzerland, Turkey, UK, US,','1716d856606b0bc8ffe22c418efeab5fbbed6761c72698fb4d3d49a449943123','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5caed453c0edbb797c92a273f5405af77c34e6c03d8e8636ea07845346ec1f40',2001,'UY','Uruguay','communications',327,'United Nations Organization Mission in the Democratic Republic of the
Congo (MONUC): established - 30 November 1999
aim - to establish contacts with the signatories to the cease-fire
agreement and to plan for the observation of the cease-fire and
disengagement of forces
members - (36) Algeria, Bangladesh, Belgium, Benin, Bolivia, Burkina
Faso, Canada, Czech Republic, Denmark, Egypt, France, Ghana, India,
Jordan, Kenya, Libya, Malaysia, Mali, Morocco, Nepal, Niger, Nigeria,
Pakistan, Peru, Poland, Romania, Russia, Senegal, South Africa,
Switzerland, Tunisia, Ukraine, UK, Tanzania, Uruguay, Zambia
United Nations Peace-keeping Force in Cyprus (UNFICYP): established -
4 March 1964
aim - to serve as a peacekeeping force between Greek Cypriots and
Turkish Cypriots in Cyprus; established by the UN Security Council
members - (10) Argentina, Austria, Canada, Finland, Hungary, Ireland,
Nepal, Netherlands, Slovenia, UK
United Nations Population Fund (UNFPA): note - acronym retained from
predecessor organization UN Fund for Population Activities
established - NA July 1967
aim - to assist both developed and developing countries to deal with
their population problems
members (executive board ) - (36) selected on a rotating basis from all
regions
United Nations Preventive Deployment Force (UNPREDEP): established 31
March 1995; to monitor border activity in the Former Yugoslav Republic
of Macedonia; members were Argentina, Bangladesh, Belgium, Brazil,
Canada, Czech Republic, Denmark, Egypt, Finland, Ghana, Indonesia,
Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland,
Portugal, Russia, Sweden, Switzerland, Turkey, Ukraine, US; mandate
ended 25 March 1999
United Nations Relief and Works Agency for Palestine Refugees in the
Near East (UNRWA): established - 8 December 1949
aim - to provide assistance to Palestinian refugees
members (advisory commission) - (10) Belgium, Egypt, France, Japan,
Jordan, Lebanon, Syria, Turkey, UK, US
United Nations Research Institute for Social Development (UNRISD):
established - NA 1963
aim - to conduct research into the problems of economic development
during different phases of economic growth
members - no country members, but a Board of Directors consisting of a
chairman appointed by the UN secretary general and 11 individual
members
United Nations Secretariat: established - 26 June 1945; effective - 24
October 1945
aim - to serve as the primary administrative organ of the UN; a
Secretary General is appointed for a five-year term by the General
Assembly on the recommendation of the Security Council
members - the UN Secretary General and staff
United Nations Security Council: established - 26 June 1945; effective
- 24 October 1945
aim - to maintain international peace and security
permanent members - (5) China, France, Russia, UK, US
nonpermanent members - (10) elected for two-year terms by the UN
General Assembly; Bangladesh (2000-01), Colombia (2001-02), Ireland
(2001-02), Jamaica (2000-01), Mali (2000-01), Mauritius (2001-02),
Norway (2001-02), Singapore (2001-02), Tunisia (2000-01), Ukraine
(2000-01)
United Nations Transitional Administration in East Timor (UNTAET):
established - 25 October 1999
aim - to provide security throughout the territory of East Timor; to
establish an effective administration; to ensure the coordination and
delivery of humanitarian assistance; to support capacity-building for
self-government
members - (47) Australia, Austria, Bangladesh, Benin, Bolivia, Bosnia
and Herzegovina, Brazil, Canada, Cape Verde, Chile, China, Denmark,
Egypt, Fiji, France, Ghana, Ireland, Jordan, Kenya, South Korea,
Malaysia, Mozambique, Namibia, Nepal, NZ, Nigeria, Norway, Pakistan,
Peru, Philippines, Portugal, Russia, Senegal, Singapore, Slovenia,
Spain, Sri Lanka, Sweden, Thailand, Turkey, Ukraine, UK, US, Uruguay,
Vanuatu, Zambia, Zimbabwe
United Nations Truce Supervision Organization (UNTSO): established -
NA June 1948
aim - to supervise the 1948 Arab-Israeli cease-fire; currently supports
timely deployment of reinforcements to other peacekeeping operations in
the region as needed; initially established by the UN Security Council
members - (22) Argentina, Australia, Austria, Belgium, Canada, Chile,
China, Denmark, Estonia, Finland, France, Ireland, Italy, Netherlands,
NZ, Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
United Nations Trusteeship Council: established on 26 June 1945,
effective on 24 October 1945, to supervise the administration of the 11
UN trust territories; members were China, France, Russia, UK, US; it
formally suspended operations 1 November 1995 after the Trust Territory
of the Pacific Islands (Palau) became the Republic of Palau, a
constitutional government in free association with the US; the
Trusteeship Council was not dissolved
United Nations University (UNU): established - 3 December 1973
aim - to conduct research in development, welfare, and human survival
and to train scholars
members - (24 members of UNU Council and the Rector are appointed by
the Secretary General of the United Nations and the Director General of
UNESCO)
Universal Postal Union (UPU): established - 9 October 1874, affiliated
with the UN 15 November 1947; effective - 1 July 1948
aim - to promote international postal cooperation; a UN specialized
agency
members - (189) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Overseas Territories of the UK, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,','8d907fc0664adabbb087fb34e07f9d7dee192c8105a881deef4d425b03aeabc2','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cecd3c412021b709785ea33b3a7b9dc611cf11432c53dba045b990ceed53ee07',2001,'LS','Lesotho','communications',328,'Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter (London Convention)
note - abbreviated as Marine Dumping
opened for signature - 29 December 1972
entered into force - 30 August 1975
objective - to control pollution of the sea by dumping and to encourage
regional agreements supplementary to the Convention
parties - (78) Afghanistan, Antigua and Barbuda, Argentina, Australia,
Azerbaijan, Barbados, Belarus, Belgium, Brazil, Canada, Cape Verde,
Chile, China, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Egypt,
Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras,
Hong Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Libya,
Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru, Netherlands, NZ,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Philippines,
Poland, Portugal, Russia, Saint Lucia, Seychelles, Slovenia, Solomon
Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tonga,
Tunisia, Ukraine, UAE, UK, US, Vanuatu, Yugoslavia
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
note - abbreviated as Environmental Modification
opened for signature - 10 December 1976
entered into force - 5 October 1978
objective - to prohibit the military or other hostile use of
environmental modification techniques in order to further world peace
and trust among nations
parties - (68) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Bangladesh, Belarus, Belgium, Benin, Brazil,
Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Egypt, Finland, Germany, Ghana, Greece,
Guatemala, Hungary, Iceland, India, Ireland, Italy, Japan, North Korea,
South Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands,
NZ, Niger, Norway, Pakistan, Papua New Guinea, Poland, Romania, Russia,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Sierra Leone, Slovakia, Solomon Islands, Spain, Sri Lanka, Sweden,
Switzerland, Tajikistan, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan,
Vietnam, Yemen
countries that have signed, but not yet ratified - (15) Bolivia,
Democratic Republic of the Congo, Ethiopia, Holy See, Iran, Iraq,
Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Syria,
Turkey, Uganda
Convention on Wetlands of International Importance Especially as
Waterfowl Habitat (Ramsar)
note - abbreviated as Wetlands
opened for signature - 2 February 1971
entered into force - 21 December 1975
objective - to stem the progressive encroachment on and loss of
wetlands now and in the future, recognizing the fundamental ecological
functions of wetlands and their economic, cultural, scientific, and
recreational value
parties - (123) Albania, Algeria, Argentina, Armenia, Australia,
Austria, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia,
Canada, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Czech Republic, Denmark, Ecuador, Egypt, El Salvador, Estonia, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South
Korea, Latvia, Lebanon, Libya, Liechtenstein, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mexico, Moldova, Monaco, Mongolia,
Morocco, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Russia, Senegal, Sierra Leone,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Vietnam,
Yugoslavia, Zambia
Desertification
see United Nations Convention to Combat Desertification in those
Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use
of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal
International Convention for the Regulation of Whaling
note - abbreviated as Whaling
opened for signature - 2 December 1946
entered into force - 10 November 1948
objective - to protect all species of whales from overhunting; to
establish a system of international regulation for the whale fisheries
to ensure proper conservation and development of whale stocks; and to
safeguard for future generations the great natural resources
represented by whale stocks
parties - (41) Antigua and Barbuda, Argentina, Australia, Austria,
Brazil, Chile, China, Costa Rica, Denmark, Dominica, Finland, France,
Germany, Grenada, Guinea, India, Ireland, Italy, Japan, Kenya, South
Korea, Mexico, Monaco, Morocco, Netherlands, NZ, Norway, Oman, Peru,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Senegal, Solomon Islands, South Africa, Spain, Sweden,
Switzerland, UK, US
International Tropical Timber Agreement, 1983
note - abbreviated as Tropical Timber 83
opened for signature - 18 November 1983
entered into force - 1 April 1985; this agreement expired when the
International Tropical Timber Agreement, 1994, went into force
objective - to provide an effective framework for cooperation between
tropical timber producers and consumers and to encourage the
development of national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic resources
parties - (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cameroon, Canada, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Denmark, Ecuador, Egypt, EU,
Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras,
India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New
Guinea, Peru, Philippines, Portugal, Russia, Spain, Sweden,
Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
International Tropical Timber Agreement, 1994
note - abbreviated as Tropical Timber 94
opened for signature - 26 January 1994
entered into force - 1 January 1997
objective - to ensure that by the year 2000 exports of tropical timber
originate from sustainably managed sources; to establish a fund to
assist tropical timber producers in obtaining the resources necessary
to reach this objective
parties - (58) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cambodia, Cameroon, Canada, Central African Republic, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Denmark, Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany,
Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy,
Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands,
NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and
Tobago, UK, US, Uruguay, Vanuatu, Venezuela
countries that have signed, but not yet ratified - (1) Ireland
Kyoto Protocol to the United Nations Framework Convention on Climate
Change
note - abbreviated as Climate Change-Kyoto Protocol
opened for signature - 16 March 1998, but not yet in force
objective - to further reduce greenhouse gas emissions by enhancing the
national programs of developed countries aimed at this goal and by
establishing percentage reduction targets for the developed countries
parties - (32) Antigua and Barbuda, Azerbaijan, The Bahamas, Barbados,
Bolivia, Cyprus, Ecuador, El Salvador, Equatorial Guinea, Fiji,
Georgia, Guatemala, Guinea, Honduras, Jamaica, Kiribati, Lesotho,
Maldives, Mexico, Federated States of Micronesia, Mongolia, Nicaragua,
Niue, Palau, Panama, Paraguay, Samoa, Trinidad and Tobago,
Turkmenistan, Tuvalu, Uruguay, Uzbekistan
countries that have signed, but not yet ratified - (64) Argentina,
Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China,
Cook Islands, Costa Rica, Croatia, Cuba, Czech Republic, Denmark,
Egypt, Estonia, EU, Finland, France, Germany, Greece, Indonesia,
Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia,
Liechtenstein, Lithuania, Luxembourg, Malaysia, Mali, Malta, Marshall
Islands, Monaco, Netherlands, NZ, Niger, Norway, Papua New Guinea,
Peru, Philippines, Poland, Portugal, Romania, Russia, Saint Lucia,
Saint Vincent and the Grenadines, Seychelles, Slovakia, Slovenia,
Solomon Islands, Spain, Sweden, Switzerland, Thailand, Ukraine, UK, US,
Vietnam, Zambia
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the
High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer
note - abbreviated as Ozone Layer Protection
opened for signature - 16 September 1987
entered into force - 1 January 1989
objective - to protect the ozone layer by controlling emissions of
substances that deplete it
parties - (175) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, EU, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal,
Seychelles, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
note - abbreviated as Ship Pollution
opened for signature - 17 February 1978
entered into force - 2 October 1983
objective - to preserve the marine environment through the complete
elimination of pollution by oil and other harmful substances and the
minimization of accidental discharge of such substances
parties - (115) Algeria, Antigua and Barbuda, Argentina, Australia,
Austria, The Bahamas, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile,
China, Colombia, Comoros, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, Equatorial Guinea, Estonia, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guyana, Hong Kong
(associate member), Hungary, Iceland, India, Indonesia, Ireland,
Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya, North Korea, South
Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg, Malaysia,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Monaco,
Morocco, Netherlands, NZ, Nicaragua, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Peru, Poland, Portugal, Romania, Russia, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Senegal, Seychelles, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine, UK, US,
Uruguay, Vanuatu, Venezuela, Vietnam, Yugoslavia
Protocol on Environmental Protection to the Antarctic Treaty
note - abbreviated as Antarctic-Environmental Protocol
opened for signature - 4 October 1991
entered into force - 14 January 1998
objective - to provide for comprehensive protection of the Antarctic
environment and dependent and associated ecosystems; applies to the
area covered by the Antarctic Treaty
parties - (27) Argentina, Australia, Belgium, Brazil, Bulgaria, Chile,
China, Ecuador, Finland, France, Germany, India, Italy, Japan, South
Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa,
Spain, Sweden, UK, US, Uruguay
countries that have signed, but not yet ratified - (16) Austria,
Canada, Colombia, Cuba, Czech Republic, Denmark, Greece, Guatemala,
Hungary, North Korea, Papua New Guinea, Romania, Slovakia, Switzerland,
Turkey, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
note - abbreviated as Air Pollution-Nitrogen Oxides
opened for signature - 31 October 1988
entered into force - 14 February 1991
objective - to provide for the control or reduction of nitrogen oxides
and their transboundary fluxes
parties - (28) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, EU, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands,
Norway, Russia, Slovakia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified - (1) Poland
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
note - abbreviated as Air Pollution-Volatile Organic Compounds
opened for signature - 18 November 1991
entered into force - 29 September 1997
objective - to provide for the control and reduction of emissions of
volatile organic compounds in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Hungary, Italy, Liechtenstein,
Luxembourg, Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland,
UK
countries that have signed, but not yet ratified - (7) Canada, EU,
Greece, Norway, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
note - abbreviated as Air Pollution-Sulphur 94
opened for signature - 14 June 1994
entered into force - 5 August 1998
objective - to provide for a further reduction in sulfur emissions or
transboundary fluxes
parties - (23) Austria, Belgium, Canada, Croatia, Czech Republic,
Denmark, EU, Finland, France, Germany, Greece, Ireland, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia,
Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified - (5) Bulgaria,
Hungary, Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
note - abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature - 24 June 1998, but not yet in force
objective - to provide for the control and reduction of emissions of
persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (6) Canada, Luxembourg, Netherlands, Norway, Sweden,','02fccdf45c35ad95bf0332008e29c669782dc870b5ce98923e94467b84c04e04','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59e61b5cf82b764bc77a804960a8037422d3e81e2c56fbb4138eb444cceb0b9f',2001,'CH','Switzerland','communications',329,'countries that have signed, but not yet ratified - (30) Armenia,
Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark,
EU, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Latvia, Liechtenstein, Lithuania, Moldova, Poland, Portugal, Romania,
Slovakia, Slovenia, Spain, Ukraine, UK, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
note - abbreviated as Air Pollution-Sulphur 85
opened for signature - 8 July 1985
entered into force - 2 September 1987
objective - to provide for a 30% reduction in sulfur emissions or
transboundary fluxes by 1993
parties - (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space,
and Under Water
note - abbreviated as Nuclear Test Ban
opened for signature - 5 August 1963
entered into force - 10 October 1963
objective - to obtain an agreement on general and complete disarmament
under strict international control in accordance with the objectives of
the United Nations; to put an end to the armaments race and eliminate
incentives for the production and testing of all kinds of weapons,
including nuclear weapons
parties - (113) Afghanistan, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, The Bahamas, Bangladesh, Belgium, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma,
Canada, Central African Republic, Chad, China, Colombia, Democratic
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece,
Guatemala, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, Liberia, Luxembourg, Madagascar, Malawi,
Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Panama, Papua New
Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San
Marino, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, UK, US, Venezuela, Yugoslavia, Zambia
countries that have signed, but not yet ratified - (17) Algeria,
Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya, Mali,
Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam,','9212e45b42189a9a268870626edad5ab998b8ac402a0d61f119603226f73aff4','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e80a6f3f044432484a9070e48494f38c38a003c673ae419d4b78679f008109c',2001,'LR','Liberia','communications',330,'Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
=====================================================================
Appendix D: Cross-Reference List of Country Data Codes
FIPS 10-4: Countries, Dependencies, Areas of Special Sovereignty, and
Their Principal Administrative Divisions (FIPS PUB 10-4) is maintained
by the Office of the Geographer and Global Issues (Department of State)
and published by the National Institute of Standards and Technology
(Department of Commerce). FIPS 10-4 codes are intended for general use
throughout the US Government, especially in activities associated with
the mission of the Department of State and national defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO
3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character alphabetic
codes and three-digit numeric codes that may be needed for activities
involving exchange of data with international organizations that have
adopted that standard. Except for the numeric codes, ISO 3166 codes
have been adopted in the US as FIPS 104-1: American National Standard
Codes for the Representation of Names of Countries, Dependencies, and
Areas of Special Sovereignty for Information Interchange.
Internet: The Internet country code is the two-letter digraph
maintained by the International Organization for Standardization (ISO)
in the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers
Authority (IANA) to establish country-coded top-level domains (ccTLDs).
Entity FIPS 10-4 --- ISO 3166 -- Internet Comment
Afghanistan AF AF AFG 004 .af
Albania AL AL ALB 008 .al
Algeria AG DZ DZA 012 .dz
American Samoa AQ AS ASM 016 .as
Andorra AN AD AND 020 .ad
Angola AO AO AGO 024 .ao
Anguilla AV AI AIA 660 .ai
Antarctica AY AQ ATA 010 .aq
ISO defines as the territory south of 60 degrees south latitude
Antigua and Barbuda AC AG ATG 028 .ag
Argentina AR AR ARG 032 .ar
Armenia AM AM ARM 051 .am
Aruba AA AW ABW 533 .aw
Ashmore and
Cartier Islands AT - - - -
ISO includes with Australia
Australia AS AU AUS 036 .au
ISO includes Ashmore and Cartier Islands, Coral Sea Islands
Austria AU AT AUT 040 .at
Azerbaijan AJ AZ AZE 031 .az
Bahamas, The BF BS BHS 044 .bs
Bahrain BA BH BHR 048 .bh
Baker Island FQ - - - -
ISO includes with the US Minor Outlying Islands
Bangladesh BG BD BGD 050 .bd
Barbados BB BB BRB 052 .bb
Bassas da India BS - - - -
ISO includes with the Miscellaneous(French) Indian Ocean Islands
Belarus BO BY BLR 112 .by
Belgium BE BE BEL 056 .be
Belize BH BZ BLZ 084 .bz
Benin BN BJ BEN 204 .bj
Bermuda BD BM BMU 060 .bm
Bhutan BT BT BTN 064 .bt
Bolivia BL BO BOL 068 .bo
Bosnia and
Herzegovina BK BA BIH 070 .ba
Botswana BC BW BWA 072 .bw
Bouvet Island BV BV BVT 074 .bv
Brazil BR BR BRA 076 .br
British Indian
Ocean Territory IO IO IOT 086 .io
British Virgin
Islands VI VG VGB 092 .vg
Brunei BX BN BRN 096 .bn
Bulgaria BU BG BGR 100 .bg
Burkina Faso UV BF BFA 854 .bf
Burma BM MM MMR 104 .mm
ISO uses the name Myanmar
Burundi BY BI BDI 108 .bi
Cambodia CB KH KHM 116 .kh
Cameroon CM CM CMR 120 .cm
Canada CA CA CAN 124 .ca
Cape Verde CV CV CPV 132 .cv
Cayman Islands CJ KY CYM 136 .ky
Central African
Republic CT CF CAF 140 .cf
Chad CD TD TCD 148 .td
Chile CI CL CHL 152 .cl
China CH CN CHN 156 .cn
see also Taiwan
Christmas Island KT CX CXR 162 .cx
Clipperton Island IP - - - -
ISO includes with French Polynesia
Cocos (Keeling)
Islands CK CC CCK 166 .cc
Colombia CO CO COL 170 .co
Comoros CN KM COM 174 .km
Congo, Democratic
Republic of the CG ZR ZAR 180 .cd
formerly Zaire
Congo,
Republic of the CF CG COG 178 .cg
Cook Islands CW CK COK 184 .ck
Coral Sea Islands CR - - - -
ISO includes with Australia
Costa Rica CS CR CRI 188 .cr
Cote d''Ivoire IV CI CIV 384 .ci
Croatia HR HR HRV 191 .hr
Cuba CU CU CUB 192 .cu
Cyprus CY CY CYP 196 .cy
Czech Republic EZ CZ CZE 203 .cz
Denmark DA DK DNK 208 .dk
Djibouti DJ DJ DJI 262 .dj
Dominica DO DM DMA 212 .dm
Dominican Republic DR DO DOM 214 .do
East Timor - TP TMP 626 .tp
FIPS includes with Indonesia
Ecuador EC EC ECU 218 .ec
Egypt EG EG EGY 818 .eg
El Salvador ES SV SLV 222 .sv
Equatorial Guinea EK GQ GNQ 226 .gq
Eritrea ER ER ERI 232 .er
Estonia EN EE EST 233 .ee
Ethiopia ET ET ETH 231 .et
Europa Island EU - - - -
ISO includes with the Miscellaneous (French) Indian Ocean Islands
Falkland Islands
(Islas Malvinas) FA FK FLK 238 .fk
Faroe Islands FO FO FRO 234 .fo
Fiji FJ FJ FJI 242 .fj
Finland FI FI FIN 246 .fi
France FR FR FRA 250 .fr
France,
Metropolitan - FX FXX 249 .fx
ISO limits to the European part of France, excluding French
Guiana, French Polynesia, French Southern and Antarctic Lands,
Guadeloupe, Martinique, Mayotte, New Caledonia, Reunion,
Saint Pierre and Miquelon, Wallis and Futuna
French Guiana FG GF GUF 254 .gf
French Polynesia FP PF PYF 258 .pf
ISO includes Clipperton Island
French Southern and
Antarctic Lands FS TF ATF 260 .tf
FIPS 10-4 does not include the French-claimed portion of
Antarctica (Terre Adelie)
Gabon GB GA GAB 266 .ga
Gambia, The GA GM GMB 270 .gm
Gaza Strip GZ - - - -
Georgia GG GE GEO 268 .ge
Germany GM DE DEU 276 .de
Ghana GH GH GHA 288 .gh
Gibraltar GI GI GIB 292 .gi
Glorioso Islands GO - - - -
ISO includes with the Miscellaneous (French) Indian Ocean Islands
Greece GR GR GRC 300 .gr
Greenland GL GL GRL 304 .gl
Grenada GJ GD GRD 308 .gd
Guadeloupe GP GP GLP 312 .gp
Guam GQ GU GUM 316 .gu
Guatemala GT GT GTM 320 .gt
Guernsey GK - - - .gg
ISO includes with the United Kingdom
Guinea GV GN GIN 324 .gn
Guinea-Bissau PU GW GNB 624 .gw
Guyana GY GY GUY 328 .gy
Haiti HA HT HTI 332 .ht
Heard Island and
McDonald Islands HM HM HMD 334 .hm
Holy See
(Vatican City) VT VA VAT 336 .va
Honduras HO HN HND 340 .hn
Hong Kong HK HK HKG 344 .hk
Howland Island HQ - - - -
ISO includes with the US Minor Outlying Islands
Hungary HU HU HUN 348 .hu
Iceland IC IS ISL 352 .is
India IN IN IND 356 .in
Indonesia ID ID IDN 360 .id
Iran IR IR IRN 364 .ir
Iraq IZ IQ IRQ 368 .iq
Ireland EI IE IRL 372 .ie
Israel IS IL ISR 376 .il
Italy IT IT ITA 380 .it
Jamaica JM JM JAM 388 .jm
Jan Mayen JN - - - -
ISO includes with Svalbard
Japan JA JP JPN 392 .jp
Jarvis Island DQ - - - -
ISO includes with the US Minor Outlying Islands
Jersey JE - - - .je
ISO includes with the United Kingdom
Johnston Atoll JQ - - - -
ISO includes with the US Minor Outlying Islands
Jordan JO JO JOR 400 .jo
Juan de Nova Island JU - - - -
ISO includes with the Miscellaneous (French) Indian Ocean Islands
Kazakhstan KZ KZ KAZ 398 .kz
Kenya KE KE KEN 404 .ke
Kingman Reef KQ - - - -
ISO includes with the US Minor Outlying Islands
Kiribati KR KI KIR 296 .ki
Korea, North KN KP PRK 408 .kp
Korea, South KS KR KOR 410 .kr
Kuwait KU KW KWT 414 .kw
Kyrgyzstan KG KG KGZ 417 .kg
Laos LA LA LAO 418 .la
Latvia LG LV LVA 428 .lv
Lebanon LE LB LBN 422 .lb
Lesotho LT LS LSO 426 .ls
Liberia LI LR LBR 430 .lr
Libya LY LY LBY 434 .ly
Liechtenstein LS LI LIE 438 .li
Lithuania LH LT LTU 440 .lt
Luxembourg LU LU LUX 442 .lu
Macau MC MO MAC 446 .mo
Macedonia,
The Republic of MK MK MKD 807 .mk
Madagascar MA MG MDG 450 .mg
Malawi MI MW MWI 454 .mw
Malaysia MY MY MYS 458 .my
Maldives MV MV MDV 462 .mv
Mali ML ML MLI 466 .ml
Malta MT MT MLT 470 .mt
Man, Isle of IM - - - .im
ISO includes with the United Kingdom
Marshall Islands RM MH MHL 584 .mh
Martinique MB MQ MTQ 474 .mq
Mauritania MR MR MRT 478 .mr
Mauritius MP MU MUS 480 .mu
Mayotte MF YT MYT 175 .yt
Mexico MX MX MEX 484 .mx
Micronesia,
Federated
States of FM FM FSM 583 .fm
Midway Islands MQ - - - -
ISO includes with the US Minor Outlying Islands
Miscellaneous
(French) Indian
Ocean Islands - - - - -
ISO includes Bassas da India, Europa Island, Glorioso Islands,
Juan de Nova Island, Tromelin Island
Moldova MD MD MDA 498 .md
Monaco MN MC MCO 492 .mc
Mongolia MG MN MNG 496 .mn
Montserrat MH MS MSR 500 .ms
Morocco MO MA MAR 504 .ma
Mozambique MZ MZ MOZ 508 .mz
Myanmar - - - - -
see Burma
Namibia WA NA NAM 516 .na
Nauru NR NR NRU 520 .nr
Navassa Island BQ - - - -
Nepal NP NP NPL 524 .np
Netherlands NL NL NLD 528 .nl','84c0d3ddde35762552bbae683cc37cc09f67f23491300c0510c264b0e61374e2','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef9a958823f1b6ef90151f57a7bdc702fcdfd3219a1a4bfb68582893221acb15',2001,'NL','Netherlands','communications',331,'Antilles NT AN ANT 530 .an
New Caledonia NC NC NCL 540 .nc
New Zealand NZ NZ NZL 554 .nz
Nicaragua NU NI NIC 558 .ni
Niger NG NE NER 562 .ne
Nigeria NI NG NGA 566 .ng
Niue NE NU NIU 570 .nu
Norfolk Island NF NF NFK 574 .nf
Northern Mariana
Islands CQ MP MNP 580 .mp
Norway NO NO NOR 578 .no
Oman MU OM OMN 512 .om
Pakistan PK PK PAK 586 .pk
Palau PS PW PLW 585 .pw
Palmyra Atoll LQ - - - -
ISO includes with the US Minor Outlying Islands
Panama PM PA PAN 591 .pa
Papua New Guinea PP PG PNG 598 .pg
Paracel Islands PF - - - -
Paraguay PA PY PRY 600 .py
Peru PE PE PER 604 .pe
Philippines RP PH PHL 608 .ph
Pitcairn Islands PC PN PCN 612 .pn
Poland PL PL POL 616 .pl
Portugal PO PT PRT 620 .pt
Puerto Rico RQ PR PRI 630 .pr
Qatar QA QA QAT 634 .qa
Reunion RE RE REU 638 .re
Romania RO RO ROM 642 .ro
Russia RS RU RUS 643 .ru
Rwanda RW RW RWA 646 .rw
Saint Helena SH SH SHN 654 .sh
Saint Kitts
and Nevis SC KN KNA 659 .kn
Saint Lucia ST LC LCA 662 .lc
Saint Pierre
and Miquelon SB PM SPM 666 .pm
Saint Vincent and
the Grenadines VC VC VCT 670 .vc
Samoa WS WS WSM 882 .ws
San Marino SM SM SMR 674 .sm
Sao Tome and
Principe TP ST STP 678 .st
Saudi Arabia SA SA SAU 682 .sa
Senegal SG SN SEN 686 .sn
Seychelles SE SC SYC 690 .sc
Sierra Leone SL SL SLE 694 .sl
Singapore SN SG SGP 702 .sg
Slovakia LO SK SVK 703 .sk
Slovenia SI SI SVN 705 .si
Solomon Islands BP SB SLB 090 .sb
Somalia SO SO SOM 706 .so
South Africa SF ZA ZAF 710 .za
South Georgia and
the Islands SX GS SGS 239 .gs
Spain SP ES ESP 724 .es
Spratly Islands PG - - - -
Sri Lanka CE LK LKA 144 .lk
Sudan SU SD SDN 736 .sd
Suriname NS SR SUR 740 .sr
Svalbard SV SJ SJM 744 .sj
ISO includes Jan Mayen
Swaziland WZ SZ SWZ 748 .sz
Sweden SW SE SWE 752 .se
Switzerland SZ CH CHE 756 .ch
Syria SY SY SYR 760 .sy
Taiwan TW TW TWN 158 .tw
Tajikistan TI TJ TJK 762 .tj
Tanzania TZ TZ TZA 834 .tz
Thailand TH TH THA 764 .th
Togo TO TG TGO 768 .tg
Tokelau TL TK TKL 772 .tk
Tonga TN TO TON 776 .to
Trinidad and Tobago TD TT TTO 780 .tt
Tromelin Island TE - - - -
ISO includes with the Miscellaneous Islands
Tunisia TS TN TUN 788 .tn
Turkey TU TR TUR 792 .tr
Turkmenistan TX TM TKM 795 .tm
Turks and
Caicos Islands TK TC TCA 796 .tc
Tuvalu TV TV TUV 798 .tv
Uganda UG UG UGA 800 .ug
Ukraine UP UA UKR 804 .ua
United Arab
Emirates TC AE ARE 784 .ae
United Kingdom UK GB GBR 826 .uk
ISO includes Guernsey, Isle of Man, Jersey
United States US US USA 840 .us
Frunze (city; former name for Kyrgyzstan 42 54 N 74 36 E
Bishkek)
Funafuti (capital) Tuvalu 8 30 S 179 12 E
Fundy, Bay of Atlantic Ocean 45 00 N 66 00 W
Futuna Islands (Hoorn Wallis and Futuna 14 19 S 178 05 W
Islands/Iles de Horne)
Fyn (island) Denmark 55 20 N 10 25 E
Gaborone (capital) Botswana 24 45 S 25 55 E
Galapagos Islands Ecuador 0 00 N 90 30 W
(Archipielago de Colon)
Galicia (region) Poland, Ukraine 49 30 N 23 00 E
Galicia (region) Spain 42 45 N 8 10 E
Galilee (region) Israel 32 54 N 35 20 E
Galleons Passage Atlantic Ocean 11 00 N 60 55 W
Gambier Islands (Iles French Polynesia 23 09 S 134 58 W
Gambier)
Gaspar Strait Pacific Ocean 3 00 S 107 00 E
Gdansk (Danzig) (city) Poland 54 23 N 18 40 E
Geneva (city) Switzerland 46 12 N 6 10 E
Genoa (city) Italy 44 25 N 8 57 E
George Town (capital) Cayman Islands 19 20 N 81 23 W
George Town (city) Malaysia 5 26 N 100 16 E
George Town (city) The Bahamas 23 30 N 75 46 W
Georgetown (capital) Guyana 6 48 N 58 10 W
Georgetown (city) The Gambia 13 30 N 14 47 W
German Democratic Republic Germany 52 00 N 13 00 E
(East Germany) (former name
for eastern portion of
Germany)
German Southwest Africa Namibia 22 00 S 17 00 E
(former name for Namibia)
Germany, Federal Republic of Germany 51 00 N 9 00 E
Gibraltar (city, peninsula) Gibraltar 36 11 N 5 22 W
Gibraltar, Strait of Atlantic Ocean 35 57 N 5 36 W
Gidi Pass Egypt 30 13 N 33 09 E
Gilbert Islands Kiribati 1 25 N 173 00 E
Goa (state) India 14 20 N 74 00 E
Gobi (desert) China, Mongolia 42 30 N 107 00 E
Godthab (Nuuk) (capital) Greenland 64 11 N 51 44 W
Golan Heights (region) Syria 33 00 N 35 45 E
Gold Coast (former name for Ghana 8 00 N 2 00 W
Ghana)
Golfo San Jorge (gulf) Atlantic Ocean 46 00 S 66 00 W
Golfo San Matias (gulf) Atlantic Ocean 41 30 S 64 00 W
Good Hope, Cape of South Africa 34 24 S 18 30 E
Goteborg (city) Sweden 57 43 N 11 58 E
Gotland (island) Sweden 57 30 N 18 33 E
Gough Island Saint Helena 40 10 S 9 45 W
Graham Land (region) Antarctica 65 00 S 64 00 W
Gran Chaco (region) Argentina, Paraguay 24 00 S 60 00 W
Grand Bahama (island) The Bahamas 26 40 N 78 35 W
Grand Banks (fishing ground) Atlantic Ocean 47 06 N 55 48 W
Grand Cayman (island) Cayman Islands 19 20 N 81 20 W
Grand Turk (Cockburn Town) Turks and Caicos 21 28 N 71 08 W
(capital) Islands
Great Australian Bight Indian Ocean 35 00 S 130 00 E
Great Belt (Store Baelt) Atlantic Ocean 55 30 N 11 00 E
(strait)
Great Bitter Lake Egypt 30 20 N 32 23 E
Great Britain (island) United Kingdom 54 00 N 2 00 W
Great Channel Indian Ocean 6 25 N 94 20 E
Great Inagua (island) The Bahamas 21 00 N 73 20 W
Great Rift Valley Ethiopia, Kenya 0 30 N 36 00 E
Greater Sunda Islands Brunei, Indonesia, 2 00 S 110 00 E','18cc9f81b34d581ee262ecdfe38e2a9ee0f4cd1e47585cfa2b74697717530482','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc9413801d6c20261ed0b3934eca0c3b0ef0a4096f717677adac196fd5c427ef',2001,'US','United States','communications',332,'Minor Outlying
Islands - UM UMI 581 .um
ISO includes Baker Island, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Palmyra Atoll,
Wake Island
Uruguay UY UY URY 858 .uy
Uzbekistan UZ UZ UZB 860 .uz
Vanuatu NH VU VUT 548 .vu
Venezuela VE VE VEN 862 .ve
Vietnam VM VN VNM 704 .vn
Virgin Islands VQ VI VIR 850 .vi
Virgin Islands (UK) - - - - .vg
see British Virgin Islands
Virgin Islands (US) - - - - .vi
see Virgin Islands
Wake Island WQ - - - -
ISO includes with the US Minor Outlying Islands
Wallis and Futuna WF WF WLF 876 .wf
West Bank WE - - - -
Western Sahara WI EH ESH 732 .eh
Western Samoa - - - - .ws
see Samoa
World - - - - -
the Factbook uses the W data code from DIAM 65-18 Geopolitical
Data Elements and Related Features, Data Standard No. 3, December
1994, published by the Defense Intelligence Agency
Yemen YM YE YEM 887 .ye
Yugoslavia - YU YUG 891 .yu
Zaire - - - - -
see Democratic Republic of the Congo
Zambia ZA ZM ZWB 894 .zm
Zimbabwe ZI ZW ZWE 716 .zw
=====================================================================
Appendix E: Cross-Reference List of Hydrographic Data Codes
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft
4th Edition 1986, published by the International Hydrographic Bureau of
the International Hydrographic Organization
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd
Edition 1953, published by the International Hydrographic Organization
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958,
published by the Aeronautical Chart and Information Center (ACIC),
United States Air Force; note - ACIC is now part of the National
Imagery and Mapping Agency (NIMA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data
Standard No. 4, Defense Intelligence Agency Manual 65-18, December
1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes
similar to the Federal Information Processing Standards (FIPS) 10-4
country codes. The names and limits of the following oceans and seas
are not always directly comparable because of differences in the
customers, needs, and requirements of the individual organizations.
Even the number of principal water bodies varies from organization to
organization. Factbook users, for example, find the Atlantic Ocean and
Pacific Ocean entries useful, but none of the following standards
include those oceans in their entirety. Nor is there any provision for
combining codes or overcodes to aggregate water bodies. The recently
delimited Southern Ocean is not included.
Principal Oceans and Seas of the World
With Hydrographic Codes by Institution
IHO 23-4th IHO 23-3rd* ACIC M 49-1 DIAM 65-18
Arctic Ocean 9 17 A 5A
Atlantic Ocean - - - -
North Atlantic Ocean 1 23 B 1A
South Atlantic Ocean 4 32 C 2A
Baltic Sea 2 1 B26 7B
Indian Ocean 5 45 F 6A
Mediterranean Sea 3.1 28 B11 -
Eastern Mediterranean 3.1.2 28 B - 8E
Western Mediterranean 3.1.1 28 A - 8W
Pacific Ocean - - - -
North Pacific Ocean 7 57 D 3A
South Pacific Ocean 8 61 E 4A
South China and Eastern
Archipelagic Seas 6 49, 48 D18 plus 3U plus
others others
*The letters after the numbers are subdivisions, not footnotes.
=====================================================================
Appendix F: Cross-Reference List of Geographic Names
Entry in Latitude Longitude
Name The World Factbook (deg min) (deg min)
Abidjan (capital) Cote d''Ivoire 5 19 N 4 02 W
Abkhazia (region) Georgia 43 00 N 41 00 E
Abu Dhabi (capital) United Arab 24 28 N 54 22 E
Emirates
Abu Musa (island) Iran 25 52 N 55 03 E
Abuja (capital) Nigeria 9 12 N 7 11 E
Abyssinia (former name for Ethiopia 8 00 N 38 00 E
Ethiopia)
Acapulco (city) Mexico 16 51 N 99 55 W
Accra (capital) Ghana 5 33 N 0 13 W
Adamstown (capital) Pitcairn Islands 25 04 S 130 05 W
Addis Ababa (capital) Ethiopia 9 02 N 38 42 E
Adelie Land (Terre Adelie) Antarctica 66 30 S 139 00 E
(claimed by France)
Aden (city) Yemen 12 46 N 45 01 E
Aden, Gulf of Indian Ocean 12 30 N 48 00 E
Admiralty Island United States 57 44 N 134 20 W
(Alaska)
Admiralty Islands Papua New Guinea 2 10 S 147 00 E
Adriatic Sea Atlantic Ocean 42 30 N 16 00 E
Adygey (region) Russia 44 30 N 40 10 E
Aegean Islands Greece 38 00 N 25 00 E
Aegean Sea Atlantic Ocean 38 30 N 25 00 E
Afars and Issas, French Djibouti 11 30 N 43 00 E
Territory of the (FTAI)
(former name for Djibouti)
Afghanestan (local name for Afghanistan 33 00 N 65 00 E
Afghanistan)
Agalega Islands Mauritius 10 25 S 56 40 E
Agana (city; former name for Guam 13 28 N 144 45 E
Hagatna)
Ajaccio (city) France (Corsica) 41 55 N 8 44 E
Ajaria (region) Georgia 41 45 N 42 10 E
Akmola (city; former name for Kazakhstan 51 10 N 71 30 E
Astana)
Aksai Chin (region) China (de facto), 35 00 N 79 00 E
India (claimed)
Al Arabiyah as Suudiyah Saudi Arabia 25 00 N 45 00 E
(local name for Saudi Arabia)
Al Bahrayn (local name for Bahrain 26 00 N 50 33 E
Bahrain)
Al Imarat al Arabiyah al United Arab 24 00 N 54 00 E
Muttahidah (local name for Emirates
the United Arab Emirates)
Al Iraq (local name for Iraq) Iraq 33 00 N 44 00 E
Al Jaza''ir (local name for Algeria 28 00 N 3 00 E
Algeria)
Al Kuwayt (local name for Kuwait 29 30 N 45 45 E
Kuwait)
Al Maghrib (local name for Morocco 32 00 N 5 00 W
Morocco)
Al Urdun (local name for Jordan 31 00 N 36 00 E
Jordan)
Al Yaman (local name for Yemen 15 00 N 48 00 E
Yemen)
Aland Islands Finland 60 15 N 20 00 E
Alaska (state) United States 65 00 N 153 00 W
Alaska, Gulf of Pacific Ocean 58 00 N 145 00 W
Alboran Sea Atlantic Ocean 36 00 N 2 30 W
Aldabra Islands (Groupe Seychelles 9 25 S 46 22 E
d''Aldabra)
Alderney (island) Guernsey 49 43 N 2 12 W
Aleutian Islands United States 52 00 N 176 00 W
(Alaska)
Alexander Archipelago (island United States 57 00 N 134 00 W
group) (Alaska)
Alexander Island Antarctica 71 00 S 70 00 W
Alexandretta (region; former Turkey 36 34 N 36 08 E
name for Iskenderun)
Alexandria (city) Egypt 31 12 N 29 54 E
Algiers (capital) Algeria 36 47 N 2 03 E
Alhucemas, Penon de (island Spain 35 13 N 3 53 W
group)
Alma-Ata (city; former name Kazakhstan 43 15 N 76 57 E
for Almaty)
Almaty (former capital) Kazakhstan 43 15 N 76 57 E
Alofi (capital) Niue 19 01 S 169 55 E
Alphonse Island Seychelles 7 01 S 52 45 E
Alsace (region) France 48 30 N 7 20 E
Amami Strait Pacific Ocean 28 40 N 129 30 E
Amindivi Islands (former name India 11 30 N 72 30 E
for Laccadive Islands)
Amirante Isles (Les Seychelles 6 00 S 53 10 E
Amirantes) (island group)
Amman (capital) Jordan 31 57 N 35 56 E
Amsterdam (capital) Netherlands 52 23 N 4 54 E
Amsterdam Island (Ile French Southern and 37 52 S 77 32 E
Amsterdam) Antarctic Lands
Amundsen Sea Southern Ocean 72 30 S 112 00 W
Amur River China, Russia 52 56 N 141 10 E
Amurskiy Liman (strait) Pacific Ocean 53 00 N 141 30 E
Anadyrskiy Zaliv (gulf) Pacific Ocean 64 00 N 177 00 E
Anatolia (region) Turkey 39 00 N 35 00 E
Andaman Islands India 12 00 N 92 45 E
Andaman Sea Indian Ocean 10 00 N 95 00 E
Andorra la Vella (capital) Andorra 42 30 N 1 30 E
Andros (island) Greece 37 45 N 24 42 E
Andros Island The Bahamas 24 26 N 77 57 W
Anegada Passage Atlantic Ocean 18 30 N 63 40 W
Angkor Wat (ruins) Cambodia 13 26 N 103 50 E
Anglo-Egyptian Sudan (former Sudan 15 00 N 30 00 E
name for Sudan)
Anjouan (island) Comoros 12 15 S 44 25 E
Ankara (capital) Turkey 39 56 N 32 52 E
Annobon (island) Equatorial Guinea 1 25 S 5 36 E
Antananarivo (capital) Madagascar 18 52 S 47 30 E
Antigua (island) Antigua and Barbuda 14 34 N 90 44 W
Antipodes Islands New Zealand 49 41 S 178 43 E
Antwerp (city) Belgium 51 13 N 4 25 E
Aomen (local Chinese short- Macau 22 10 N 113 33 E
form name for Macau)
Aozou Strip (region) Chad 22 00 N 18 00 E
Apia (capital) Samoa 13 50 S 171 44 N
Aqaba, Gulf of Indian Ocean 29 00 N 34 30 E
Arab, Shatt al (river) Iran, Iraq 29 57 N 48 34 E
Arabian Sea Indian Ocean 15 00 N 65 00 E
Arafura Sea Pacific Ocean 9 00 S 133 00 E
Aral Sea Kazakhstan, 45 00 N 60 00 E','7bbfa314016f8918798743d9fba325c36f896c1fd24fdd02989321f00889a64a','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('628419a94f7df26e79e4cd0dd01e8201253d99f6a1506acf52d6d04c6370119e',2001,'UA','Ukraine','communications',333,'Bharat (local name for India) India 20 00 N 77 00 E
Bhopal (city) India 23 16 N 77 24 E
Biafra (region) Nigeria 5 30 N 7 30 E
Big Diomede Island Russia 65 46 N 169 06 W
Bijagos, Arquipelago dos Guinea-Bissau 11 25 N 16 20 W
(island group)
Bikini Atoll Marshall Islands 11 35 N 165 23 E
Bilbao (city) Spain 43 15 N 2 58 W
Bioko (island) Equatorial Guinea 3 30 N 8 42 E
Biscay, Bay of Atlantic Ocean 44 00 N 4 00 W
Bishkek (capital) Kyrgyzstan 42 54 N 74 36 E
Bishop Rock United Kingdom 49 52 N 6 27 W
Bismarck Archipelago (island Papua New Guinea 5 00 S 150 00 E
group)
Bismarck Sea Pacific Ocean 4 00 S 148 00 E
Bissau (capital) Guinea-Bissau 11 51 N 15 35 W
Bjornoya (Bear Island) Svalbard 74 26 N 19 05 E
Black Forest (region) Germany 48 00 N 8 15 E
Black Rock (island) South Georgia and 53 39 S 41 48 W
the South Sandwich
Islands
Black Sea Atlantic Ocean 43 00 N 35 00 E
Bloemfontein (city, judicial South Africa 29 12 S 26 07 E
center)
Bo Hai (gulf) Pacific Ocean 38 00 N 120 00 E
Boa Vista (island) Cape Verde 16 05 N 22 50 W
Bogota (capital) Colombia 4 36 N 74 05 W
Bohemia (region) Czech Republic 50 00 N 14 30 E
Bombay (see Mumbai) India 18 58 N 72 50 E
Bonaire (island) Netherlands 12 10 N 68 15 W
Antilles
Bonifacio, Strait of Atlantic Ocean 41 01 N 14 00 E
Bonin Islands Japan 27 00 N 140 10 E
Bonn (capital) Germany 50 44 N 7 05 E
Bophuthatswana (enclave South Africa 26 30 S 25 30 E
region)
Bora-Bora (island) French Polynesia 16 30 S 151 45 W
Bordeaux (city) France 44 50 N 0 34 W
Borneo (island) Brunei, Indonesia, 0 30 N 114 00 E','8cd7fe161787993f60722f77c92870e7bbcf6a7be1d5ab22133f0394c617970b','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37117e59a09b3978255577a2689e165a70199f0caf7de767e2edd836e9b546ba',2001,'MY','Malaysia','communications',334,'Bornholm (island) Denmark 55 10 N 15 00 E
Bosna i Hercegovina (local Bosnia and 44 00 N 18 00 E
name for Bosnia and Herzegovina
Herzegovina)
Bosnia (political region) Bosnia and 44 00 N 18 00 E
Herzegovina
Bosporus (strait) Atlantic Ocean 41 00 N 29 00 E
Bothnia, Gulf of Atlantic Ocean 63 00 N 20 00 E
Bougainville (island) Papua New Guinea 6 00 S 155 00 E
Bougainville Strait Pacific Ocean 6 40 S 156 10 E
Bounty Islands New Zealand 47 43 S 174 00 E
Bourbon Island (former name Reunion 21 06 S 55 36 E
of Reunion)
Brasilia (capital) Brazil 15 47 S 47 55 W
Bratislava (capital) Slovakia 48 09 N 17 07 E
Brazzaville (capital) Republic of the 4 16 S 15 17 E
Green Islands Papua New Guinea 4 30 S 154 10 E
Greenland Sea Arctic Ocean 79 00 N 5 00 W
Grenadines, Northern (island Saint Vincent and 13 15 N 61 12 W
group) the Grenadines
Grenadines, Southern (island Grenada 12 07 N 61 40 W
group)
Grytviken (South Georgia) South Georgia and 54 15 S 36 45 W
(town) the South Sandwich
Islands
Guadalcanal (island) Solomon Islands 9 32 S 160 12 E
Guadalupe, Isla de (island) Mexico 29 11 N 118 17 W
Guantanamo Bay (US Naval Cuba 20 00 N 75 08 W
Base)
Guatemala (capital) Guatemala 14 38 N 90 31 W
Guinea Ecuatorial (local name Equatorial Guinea 2 00 N 10 00 E
for Equatorial Guinea)
Guinea, Gulf of Atlantic Ocean 3 00 N 2 30 E
Guine-Bissau (local name for Guinea-Bissau 12 00 N 15 00 W
Guinea-Bissau)
Guinee (local name for Guinea 11 00 N 10 00 W
Guinea)
Guyane Francaise (local name French Guiana 4 00 N 53 00 W
for French Guiana)
Ha''apai Group (island group) Tonga 19 42 S 174 29
W
Habomai Islands Russia (de 43 30 N 146 10
facto) E
Hadhramaut (region) Yemen 15 00 N 50 00 E
Hagatna (Agana) (capital) Guam 13 28 N 144 45
E
Hague, The (seat of Netherlands 52 05 N 4 18 E','c58fa92ee32e777078ea8cc75da0f7d0fcd7f9748b51402167bae8abe337dfda','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c36c7da96feff507e3972b15354f4f1a0bc2787030b002df99285704deaaabee',2001,'CG','Congo','communications',335,'Bridgetown (capital) Barbados 13 06 N 59 37 W
Brisbane (city) Australia 27 28 S 153 02 E
Bristol Bay Pacific Ocean 57 00 N 160 00 W
Bristol Channel Atlantic Ocean 51 18 N 3 30 W
Britain (see Great Britain) United Kingdom 54 00 N 2 00 W
British Bechuanaland (region; South Africa 27 30 S 23 30 E
former name for northwest
South Africa)
British Central African Malawi 13 30 S 34 00 E
Protectorate (former name of
Nyasaland)
British East Africa (former Kenya, Tanzania, 1 00 N 38 00 E
name for British possessions Uganda
in eastern Africa)
British Guiana (former name Guyana 5 00 N 59 00 W
for Guyana)
British Honduras (former name Belize 17 15 N 88 45 W
for Belize)
British Solomon Islands Solomon Islands 8 00 S 159 00 E
(former name for Solomon
Islands)
British Somaliland (former Somalia 10 00 N 49 00 E
name for northern Somalia)
Brussels (capital) Belgium 50 50 N 4 20 E
Bubiyan (island) Kuwait 29 47 N 48 10 E
Bucharest (capital) Romania 44 26 N 26 06 E
Budapest (capital) Hungary 47 30 N 19 05 E
Buenos Aires (capital) Argentina 34 36 S 58 27 W
Bujumbura (capital) Burundi 3 23 S 29 22 E
Bukovina (region) Romania, Ukraine 48 00 N 26 00 E
Byelarus (local name for Belarus 53 00 N 28 00 E
Belarus)
Byelorussia (former name for Belarus 53 00 N 28 00 E
Belarus)
Cabinda (province) Angola 5 33 S 12 12 E
Cabo Verde (local name for Cape Verde 16 00 N 24 00 W
Cape Verde)
Cabot Strait Atlantic Ocean 47 20 N 59 30 W
Caicos Islands Turks and Caicos 21 56 N 71 58 W
Islands
Cairo (capital) Egypt 30 03 N 31 15 E
California, Gulf of Pacific Ocean 28 00 N 112 00 W
Cameroun (local name for Cameroon 6 00 N 12 00 E
Cameroon)
Campbell Island New Zealand 52 33 S 169 09 E
Campeche, Bay of Atlantic Ocean 20 00 N 94 00 W
Canal Zone (former name for Panama 9 00 N 79 45 W
US possessions in Panama)
Canarias Sea Atlantic Ocean 28 00 N 16 00 W
Canary Islands Spain 28 00 N 15 30 W
Canberra (capital) Australia 35 17 S 149 08 E
Cancun (city) Mexico 21 10 N 86 50 W
Canton (Guangzhou) (city) China 23 06 N 113 16 E
Canton Island (Kanton Island) Kiribati 2 49 S 171 40 W
Cape Juby (region; former Morocco 27 53 N 12 58 W
name for Southern Morocco)
Cape of Good Hope (cape; also South Africa 34 15 S 18 25 E
alternate name for Cape
Province of South Africa)
Cape Province (region; former South Africa 31 30 S 22 30 E
name for Northern, Western,
and Eastern Cape Provinces of
South Africa)
Cape Town (legislative South Africa 33 57 S 18 28 W
capital)
Caracas (capital) Venezuela 10 30 N 66 56 W
Cargados Carajos Shoals Mauritius 16 25 S 59 38 E
Caribbean Sea Atlantic Ocean 15 00 N 73 00 W
Caroline Islands Federated States of 7 30 N 148 00 E
Micronesia, Palau
Carpatho-Ukraine (region; Ukraine 48 22 N 23 32 E
former name for Zakarpats''ka
oblast'')
Carpentaria, Gulf of Pacific Ocean 14 00 S 139 00 E
Castries (capital) Saint Lucia 14 01 N 61 00 W
Catalonia (region) Spain 42 00 N 2 00 E
Cato Island Australia 23 15 S 155 32 E
Caucasus (region) Russia 42 00 N 45 00 E
Cayenne (capital) French Guiana 4 56 N 52 20 W
Celebes (island) Indonesia 2 00 S 121 00 E
Celebes Sea Pacific Ocean 3 00 N 122 00 E
Celtic Sea Atlantic Ocean 51 00 N 6 30 W
Central African Empire Central African 7 00 N 21 00 E
(former name for Central Republic
African Republic)
Ceram (Seram) Sea Pacific Ocean 2 30 S 129 30 E
Ceska Republika (local name Czech Republic 49 45 N 15 30 E
for Czech Republic)
Ceskoslovensko (former local Czech Republic, 49 00 N 17 30 E
name for Czechoslovakia) Slovakia
Ceuta (city) Spain 35 53 N 5 19 W
Ceylon (former name for Sri Sri Lanka 7 00 N 81 00 E
Lanka)
Chafarinas, Islas (island) Spain 35 12 N 2 26 W
Chagos Archipelago (Oil British Indian 6 00 S 71 30 E
Islands) Ocean Territory
Challenger Deep (Mariana Pacific Ocean 11 22 N 142 36 E
Trench)
Channel Islands Guernsey, Jersey 49 20 N 2 20 W
Charlotte Amalie (capital) Virgin Islands 18 21 N 64 56 W
Chatham Islands New Zealand 44 00 S 176 30 W
Chechnya (Chechnia) (region) Russia 43 15 N 45 40 E
Cheju Strait Pacific Ocean 34 00 N 126 30 E
Cheju-do (island) Korea, South 33 20 N 126 30 E
Chennai (Madras) (city) India 13 04 N 80 16 E
Chesterfield Islands (Iles New Caledonia 19 52 S 158 15 E
Chesterfield)
Chihli, Gulf of (see Bo Hai) Pacific Ocean 38 30 N 120 00 E
Chiloe (island) Chile 42 50 S 74 00 W
China, People''s Republic of China 35 00 N 105 00 E
China, Republic of Taiwan 23 30 N 105 00 E
Chisinau (capital) Moldova 47 00 N 28 50 E
Choiseul (island) Solomon Islands 7 05 S 121 00 E
Choson (local name for North North Korea 40 00 N 127 00 E
Korea)
Christmas Island (Indian Australia 10 25 S 105 39 E
Ocean)
Christmas Island (Kiritimati) Kiribati 1 52 N 157 20 W
(Pacific Ocean)
Chukchi Sea Arctic Ocean 69 00 N 171 00 W
Chuuk Islands (Truk Islands) Federated States of 7 25 N 151 47 W
Micronesia
Cilicia (region) Turkey 36 50 N 34 30 E
Ciskei (enclave) South Africa 33 00 S 27 00 E
Citta del Vaticano (local Holy See 41 54 N 12 27 E
name for Vatican City)
Cochin China (region) Vietnam 11 00 N 107 00 E
Coco, Isla del (island) Costa Rica 5 32 N 87 04 W
Cocos Islands Cocos (Keeling) 12 30 S 96 50 E
Islands
Colombo (capital) Sri Lanka 6 56 N 79 51 E
Colon, Archipielago de Ecuador 0 00 N 90 30 W
(Galapagos Islands)
Commander Islands Russia 55 00 N 167 00 E
(Komandorskiye Ostrova)
Comores (local name for Comoros 12 10 S 44 15 E
Comoros)
Con Son (islands) Vietnam 8 43 N 106 36 E
Conakry (capital) Guinea 9 31 N 13 43 W
Confederatio Helvetica (local Switzerland 47 00 N 8 00 E
name for Switzerland)
Congo (Brazzaville) (former Republic of the 1 00 S 15 00 E
name for Republic of the Congo
Congo)
Congo (Leopoldville) (former Democratic Republic 0 00 N 25 00 E
name for the Democratic of the Congo
Republic of the Congo)
Constantinople (city; former Turkey 41 01 N 28 58 E
name for Istanbul)
Cook Strait Pacific Ocean 41 15 S 174 30 E
Copenhagen (capital) Denmark 55 40 N 12 35 E
Coral Sea Pacific Ocean 15 00 S 150 00 E
Corfu (island) Greece 39 40 N 19 45 E
Corinth (region) Greece 37 56 N 22 56 E
Corisco (island) Equatorial Guinea 0 55 N 9 19 E
Corn Islands (Islas del Maiz) Nicaragua 12 15 N 83 00 W
Corocoro Island Guyana, Venezuela 3 38 N 66 50 W
Corsica (Corse) (island) France 42 00 N 9 00 E
Cosmoledo Group (Atoll de Seychelles 9 43 S 47 35 E
Cosmoledo) (island group)
Cotonou (seat of government) Benin 6 21 N 2 26 E
Cotopaxi (volcano) Ecuador 0 39 S 78 26 W
Courantyne River Guyana, Suriname 5 57 N 57 06 W
Cozumel (island) Mexico 20 30 N 86 55 W
Crete (island) Greece 35 15 N 24 45 E
Crimea (region) Ukraine 45 00 N 34 00 E
Crimean Peninsula Ukraine 45 00 N 34 00 E
Crooked Island Passage Atlantic Ocean 22 55 N 74 35 W
Crozet Islands (Iles Crozet) French Southern and 46 30 S 51 00 E
Antarctic Lands
Cyclades (island group) Greece 37 00 N 25 10 E
Cyrenaica (region) Libya 31 00 N 22 00 E
Czechoslovakia (former name Czech Republic, 49 00 N 18 00 E
for the entity that Slovakia
subsequently split into the
Czech Republic and Slovakia)
Dagestan (region) Russia 43 00 N 47 00 E
Dahomey (former name for Benin 9 30 N 2 15 E
Benin)
Daito Islands Japan 43 00 N 17 00 E
Dakar (capital) Senegal 14 40 N 17 26 W
Dalmatia (region) Croatia 43 00 N 17 00 E
Daman (Damao) (city) India 20 10 N 73 00 E
Damascus (capital) Syria 33 30 N 36 18 E
Danger Islands (see Pukapuka Cook Islands 10 53 S 165 49 W
Atoll)
Danish Straits Atlantic Ocean 58 00 N 11 00 E
Danish West Indies (former Virgin Islands 18 20 N 64 50 W
name for the Virgin Islands)
Danmark (local name) Denmark 56 00 N 10 00 E
Danzig (city; former name for Poland 54 23 N 18 40 E
Gdansk)
Dao Bach Long Vi (island) Vietnam 20 08 N 107 44 E
Dar es Salaam (capital) Tanzania 6 48 S 39 17 E
Dardanelles (strait) Atlantic Ocean 40 15 N 26 25 E
Davis Strait Atlantic Ocean 67 00 N 57 00 W
Dead Sea Israel, Jordan, 32 30 N 35 30 E
West Bank
Deception Island Antarctica 62 56 S 60 34 W
Denmark Strait Atlantic Ocean 67 00 N 24 00 W
D''Entrecasteaux Islands Papua New Guinea 9 30 S 150 40 E
Desolation Islands (Isles French Southern and 49 30 S 69 30 E
Kerguelen) Antarctic Lands
Deutschland (local name for Germany 51 00 N 9 00 E
Germany)
Devils Island (Ile du Diable) French Guiana 5 17 N 52 35 W
Devon Island Canada 76 00 N 87 00 W
Dhaka (capital) Bangladesh 23 43 N 90 25 E
Dhivehi Raajje (local name Maldives 3 15 N 73 00 E
for Maldives)
Dhofar (region) Oman 17 00 N 54 10 E
Diego Garcia (island) British Indian 7 20 S 72 25 E
Ocean Territory
Diego Ramirez (islands) Chile 56 30 S 68 43 W
Dilmun (former name for Bahrain 7 00 N 81 00 E
Bahrain)
Diomede Islands Russia (Big 65 47 N 169 00 W
Diomede), United
States (Little
Diomede)
Diu (region) India 20 42 N 70 59 E
Djibouti (capital) Djibouti 11 30 N 43 15 E
Dnieper (river) Belarus, Russia, 46 30 N 32 18 E
Ukraine (Dnyapro,
Dnepr, Dnipro)
Dniester (river) Moldova, Ukraine 46 18 N 30 17 E
(Nistru, Dnister)
Dobruja (region) Bulgaria, Romania 43 30 N 28 00 E
Dodecanese (island group) Greece 36 00 N 27 05 E
Dodoma (city) Tanzania 6 11 S 35 45 E
Doha (capital) Qatar 25 17 N 51 32 E
Donets Basin Russia, Ukraine 48 15 N 38 30 E
Douala (city) Cameroon 4 03 N 9 42 E
Douglas (capital) Man, Isle of 54 09 N 4 28 W
Dover, Strait of Atlantic Ocean 51 00 N 1 30 E
Drake Passage Atlantic Ocean, 60 00 S 60 00 W
Southern Ocean
Druk Yul (local name for Bhutan 27 30 N 90 30 E
Bhutan)
Dubai (city) United Arab 25 18 N 55 18 E
Emirates
Dubayy (see Dubai) United Arab 25 18 N 55 18 E
Emirates
Dublin (capital) Ireland 53 20 N 6 15 W
Dushanbe (capital) Tajikistan 38 35 N 68 48 E
Dutch Antilles (former name Netherlands 52 05 N 4 18 E
for the Netherlands Antilles) Antilles
Dutch East Indies (former Indonesia 5 00 S 120 00 E
name for Indonesia)
Dutch Guiana (former name for Suriname 4 00 N 56 00 W
Suriname)
Dutch West Indies (former Netherlands 52 05 N 4 18 E
name for the Netherlands Antilles
Antilles)
Dzungarian Gate (valley) China, Kazakhstan 45 25 N 82 25 E
Dagestan (region) Russia 43 00 N 47 00 E
Dahomey (former name for Benin 9 30 N 2 15 E
Benin)
Daito Islands Japan 43 00 N 17 00 E
Dakar (capital) Senegal 14 40 N 17 26 W
Dalmatia (region) Croatia 43 00 N 17 00 E
Daman (Damao) (city) India 20 10 N 73 00 E
Damascus (capital) Syria 33 30 N 36 18 E
Danger Islands (see Pukapuka Cook Islands 10 53 S 165 49 W
Atoll)
Danish Straits Atlantic Ocean 58 00 N 11 00 E
Danish West Indies (former Virgin Islands 18 20 N 64 50 W
name for the Virgin Islands)
Danmark (local name) Denmark 56 00 N 10 00 E
Danzig (city; former name for Poland 54 23 N 18 40 E
Gdansk)
Dao Bach Long Vi (island) Vietnam 20 08 N 107 44 E
Dar es Salaam (capital) Tanzania 6 48 S 39 17 E
Dardanelles (strait) Atlantic Ocean 40 15 N 26 25 E
Davis Strait Atlantic Ocean 67 00 N 57 00 W
Dead Sea Israel, Jordan, 32 30 N 35 30 E
West Bank
Deception Island Antarctica 62 56 S 60 34 W
Denmark Strait Atlantic Ocean 67 00 N 24 00 W
D''Entrecasteaux Islands Papua New Guinea 9 30 S 150 40 E
Desolation Islands (Isles French Southern and 49 30 S 69 30 E
Kerguelen) Antarctic Lands
Deutschland (local name for Germany 51 00 N 9 00 E
Germany)
Devils Island (Ile du Diable) French Guiana 5 17 N 52 35 W
Devon Island Canada 76 00 N 87 00 W
Dhaka (capital) Bangladesh 23 43 N 90 25 E
Dhivehi Raajje (local name Maldives 3 15 N 73 00 E
for Maldives)
Dhofar (region) Oman 17 00 N 54 10 E
Diego Garcia (island) British Indian 7 20 S 72 25 E
Ocean Territory
Diego Ramirez (islands) Chile 56 30 S 68 43 W
Dilmun (former name for Bahrain 7 00 N 81 00 E
Bahrain)
Diomede Islands Russia (Big 65 47 N 169 00 W
Diomede), United
States (Little
Diomede)
Diu (region) India 20 42 N 70 59 E
Djibouti (capital) Djibouti 11 30 N 43 15 E
Dnieper (river) Belarus, Russia, 46 30 N 32 18 E
Ukraine (Dnyapro,
Dnepr, Dnipro)
Dniester (river) Moldova, Ukraine 46 18 N 30 17 E
(Nistru, Dnister)
Dobruja (region) Bulgaria, Romania 43 30 N 28 00 E
Dodecanese (island group) Greece 36 00 N 27 05 E
Dodoma (city) Tanzania 6 11 S 35 45 E
Doha (capital) Qatar 25 17 N 51 32 E
Donets Basin Russia, Ukraine 48 15 N 38 30 E
Douala (city) Cameroon 4 03 N 9 42 E
Douglas (capital) Man, Isle of 54 09 N 4 28 W
Dover, Strait of Atlantic Ocean 51 00 N 1 30 E
Drake Passage Atlantic Ocean, 60 00 S 60 00 W
Southern Ocean
Druk Yul (local name for Bhutan 27 30 N 90 30 E
Bhutan)
Dubai (city) United Arab 25 18 N 55 18 E
Emirates
Dubayy (see Dubai) United Arab 25 18 N 55 18 E
Emirates
Dublin (capital) Ireland 53 20 N 6 15 W
Dushanbe (capital) Tajikistan 38 35 N 68 48 E
Dutch Antilles (former name Netherlands 52 05 N 4 18 E
for the Netherlands Antilles) Antilles
Dutch East Indies (former Indonesia 5 00 S 120 00 E
name for Indonesia)
Dutch Guiana (former name for Suriname 4 00 N 56 00 W
Suriname)
Dutch West Indies (former Netherlands 52 05 N 4 18 E
name for the Netherlands Antilles
Antilles)
Dzungarian Gate (valley) China, Kazakhstan 45 25 N 82 25 E
East China Sea Pacific Ocean 30 00 N 126 00 E
East Frisian Islands Germany 53 44 N 7 25 E
East Germany (German Germany 52 00 N 13 00 E
Democratic Republic) (former
name for eastern portion of
Germany)
East Korea Strait (Eastern Pacific Ocean 34 00 N 129 00 E
Channel or Tsushima Strait)
East Pakistan (former name Bangladesh 24 00 N 90 00 E
for Bangladesh)
East Siberian Sea Arctic Ocean 74 00 N 166 00 E
East Timor (Portuguese Timor) Indonesia 9 00 S 126 00 E
Easter Island (Isla de Chile 27 07 S 109 22 W
Pascua)
Eastern Channel (East Korea Pacific Ocean 34 00 N 129 00 E
Strait or Tsushima Strait)
Eastern Samoa (former name American Samoa 14 20 S 170 00 W
for American Samoa)
Eesti (local name for Estonia 59 00 N 26 00 E
Estonia)
Eire (local name for Ireland) Ireland 53 00 N 8 00 W
Elba (island) Italy 42 46 N 10 17 E
Elemi Triangle (region) Ethiopia (claimed), 5 00 N 35 30 E
Kenya (de facto),
Sudan (claimed)
Ellada (local name for Greece 39 00 N 22 00 E
Greece)
Ellas (local name for Greece) Greece 39 00 N 22 00 E
Ellef Ringnes Island Canada 78 00 N 103 00 W
Ellesmere Island Canada 81 00 N 80 00 W
Ellice Islands Tuvalu 8 00 S 178 00 E
Ellsworth Land (region) Antarctica 75 00 S 92 00 W
Elobey, Islas de (island Equatorial Guinea 0 59 N 9 33 E
group)
Enderbury Island Kiribati 3 08 S 171 05 W
Enewetak Atoll (Eniwetok Marshall Islands 11 30 N 162 15 E
Atoll)
England (region) United Kingdom 52 30 N 1 30 W
English Channel Atlantic Ocean 50 20 N 1 00 W
Eniwetok Atoll (see Enewetak Marshall Islands 11 30 N 162 15 E
Atoll)
Eolie, Isole (island group) Italy 38 30 N 15 00 E
Epirus, Northern (region) Albania, Greece 40 00 N 20 30 E
Ertra (local name for Eritrea 15 00 N 39 00 E
Eritrea)
Espana Spain 40 00 N 4 00 W
Essequibo (region) (claimed Guyana 6 59 N 58 23 W
by Venezuela)
Etorofu (Iturup) (island) Russia (de facto) 44 55 N 147 40 E
Farquhar Group (Atoll de Seychelles 10 10 S 51 10 E
Farquhar) (island group)
Fergana Valley Kyrgyzstan, 41 00 N 72 00 E
Tajikistan,','b762f5f81439e30f30ccbdfce4b5ae180a4001b5f598c9ad5be526b63259cb89','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

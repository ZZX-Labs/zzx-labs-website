SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d18183d2193364c16c76f14d6e136238cf522a94c907faf56fa516d50f6a6377',2001,'EH','Western Sahara','geography',9,'Location
Geographic coordinates
Map references
Area
total
land
water
Area - comparative
Land boundaries
total
border countries
Coastline
Maritime claims
contiguous zone
exclusive fishing zone
continental shelf
exclusive economic zone
territoriai sea
extended fishing zone
Climate
Terrain
Elevation extremes
lowest point
highest point
Natural resources
Land use
arable land
permanent crops
permanent pastures
forests and woodland
other
Irrigated land
Natural hazards
Environment - current issues
Environment ■ international agreements
party to
signed, but not ratified
Geography - note
Location: Southern Asia, north and west of
Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
tofa/; 647,500 sq km
/and; 647,500 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries;
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan
2,430 km, Tajikistan 1 ,206 km, Turkmenistan 744 km,
Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot
summers
Terrain: mostly rugged mountains; plains in north
and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal,
copper, chromite, talc, barites, sulfur, lead, zinc, iron
ore, salt, precious and semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% {^993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in
Hindu Kush mountains; flooding; droughts
Environment - current issues: soil degradation;
overgrazing; deforestation (much of the remaining
forests are being cut down for fuel and building
materials); desertification
Environment - International agreements:
party fo; Desertification, Endangered Species,
Environmental Modification, Marine Dumping,
Nuclear Test Ban, Ship Pollution
signed, but not ratified: Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation
Geography - note: landlocked
Location: Northern Africa, bordering the North
Atlantic Ocean, between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
fofa/.'' 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area - comparative: about the size of Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania 1 ,561 km,
Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of
sovereignty issue
Climate: hot, dry desert; rain is rare; cold offshore air
currents produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of
rocky or sandy surfaces rising to small mountains in
south and northeast
Elevation extremes:
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 9%
forests and woodland: 0%
other: S^%
Irrigated land: NA sq km
Natural hazards: hot, dry, dust/sand-laden sirocco
wind can occur during winter and spring; widespread
harmattan haze exists 60% of time, often severely
restricting visibility
Environment - current issues: sparse water and
lack of arable land
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Map references: World, Time Zones
Area:
fofa/.’ 51 0.072 million sq km
/and; 148.94 million sq km
wafer; 361.132 million sq km
note: 70.8% of the world''s surface is water, 29.2% is
land
Area - comparative: land area about 1 6 times the
size of the US
Land boundaries: the land boundaries in the world
total 251,480.24 km (not counting shared boundaries
twice)
Coastline: 356,000 km
Maritime claims:
contiguous zone: 24 NM claimed by most, but can
vary
continental shelf: 200-m depth claimed by most or to
depth of exploitation; others claim 200 NM or to the
edge of the continental margin
exclusive fishing zone: 200 NM claimed by most, but
can vary
exclusive economic zone: 200 NM claimed by most,
but can vary
territorial sea: 12 NM claimed by most, but can vary
note: boundary situations with neighboring states
prevent many countries from extending their fishing or
economic zones to a full 200 NM; 43 nations and other
areas that are landlocked include Afghanistan,
Andorra, Armenia, Austria, Azerbaijan, Belarus,
Bhutan, Bolivia, Botswana, Burkina Faso, Burundi,
Central African Republic, Chad, Czech Republic,
Ethiopia, Holy See (Vatican City), Hungary,
Kazakhstan, Kyrgyzstan, Laos, Lesotho,
Liechtenstein, Luxembourg, Malawi, Mali, Moldova,
Mongolia, Nepal, Niger, Paraguay, Rwanda, San
Marino, Slovakia, Swaziland, Switzerland, Tajikistan,
The Former Yugoslav Republic of Macedonia,
Turkmenistan, Uganda, Uzbekistan, West Bank,
Zambia, Zimbabwe
Climate: two large areas of polar climates separated
by two rather narrow temperate zones from a wide
equatorial band of tropical to subtropical climates
Terrain: the greatest ocean depth is the Mariana
Trench at 10,924 m in the Pacific Ocean
Elevation extremes:
lowest point: Bentley Subglacial Trench -2,540 m
highest point: Mount Everest 8,850 m (1999 est.)
Natural resources: the rapid using up of
nonrenewable mineral resources, the depletion of
forest areas and wetlands, the extinction of animal
and plant species, and the deterioration in air and
water quality (especially in Eastern Europe, the former
USSR, and China) pose serious long-term problems
that governments and peoples are only beginning to
address
553
World (continued)
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 26%
forests and woodland: 32%
oto;31%(1993 est.)
Irrigated land: 2,481,250 sq km (1993 est.)
Natural hazards: large areas subject to severe
weather (tropical cyclones), natural disasters
(earthquakes, landslides, tsunamis, volcanic
eruptions)
Environment - current issues: large areas subject
to overpopulation, industrial disasters, pollution (air,
water, acid rain, toxic substances), loss of vegetation
(overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion','e5735323dcce6788f0861efd7c5a6d79312a68a82d2681c2520761e418d10357','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f6f19af47c703a0b09c68de7a752c39442a718115e4b51d0139c82e3b2425d0',2001,'AL','Albania','geography',18,'Location: Southeastern Europe, bordering the
Adriatic Sea and Ionian Sea, between Greece and the
Federal Republic of Yugoslavia
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area:
total: 28,748 sq km
land: 27,398 sq km
water; 1,350 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 720 km
border countries: Greece 282 km. The Former
Yugoslav Republic of Macedonia 151 km, Yugoslavia
287 km
Coastline: 362 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 NM
Climate: mild temperate; cool, cloudy, wet winters;
hot, clear, dry summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains
along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,753 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, timber, nickel, hydropower
Land use:
arable land: 21%
permanent crops: 5%
permanent pastures: 1 5%
forests and woodland: 38%
oteer;21%(1993 est.)
Irrigated land: 3,410 sq km (1993 est.)
Natural hazards: destructive earthquakes; tsunamis
occur along southwestern coast; drought
Environment - current issues: deforestation; soil
erosion; water pollution from industrial and domestic
effluents
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location along Strait of
Otranto (links Adriatic Sea to Ionian Sea and
Mediterranean Sea)
Location: Northern Africa, bordering the
Mediterranean Sea, between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
tofa/; 2,381 ,740 sq km
land: 2,381 ,740 sq km
water: 0 sq km
Area ■ comparative: slightly less than 3.5 times the
size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km,
Mauritania 463 km, Morocco 1 ,559 km, Niger 956 km,
Tunisia 965 km. Western Sahara 42 km
Coastline: 998 km
Maritime claims:
exclusive fishing zone: 32-52 NM
territorial sea: 12 NM
5
Algeria (continued)
Climate: arid to semiarid; mild, wet winters with hot,
dry summers along coast; drier with cold winters and
hot summers on high plateau; sirocco is a hot, dust/
sand-laden wind especially common in summer
Terrain: mostly high plateau and desert; some
mountains; narrow, discontinuous coastal plain
Elevation extremes:
lowest point: Chott Meirhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 1 3%
forests and woodland: 2%
ote82%(1993 est.)
Irrigated land: 5,550 sq km (1993 est.)
Natural hazards: mountainous areas subject to
severe earthquakes; mud slides
Environment - current issues; soil erosion from
overgrazing and other poor farming practices;
desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is
leading to the pollution of rivers and coastal waters;
Mediterranean Sea, in particular, becoming polluted
from oil wastes, soil erosion, and fertilizer runoff;
Inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography ■ note: second-largest country in Africa
(after Sudan)','ccea137e4feb6fdb5dcbf960f12c3e1779609ec5da814847c2f25d1c466772bb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47d0e44ec6d294080fe7b430f5abb0874d4daf16440a8e8832b9db3c56b53535',2001,'AS','American Samoa','geography',28,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates; 14 20 S, 170 00 W
Map references: Oceania
Area:
total: 1 99 sq km
land: 1 99 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropica! marine, moderated by southeast
trade winds; annual rainfall averages about 3 m; rainy
season from November to April, dry season from May
to October; little seasonal temperature variation
Terrain: five volcanic islands with rugged peaks and
limited coastal plains, two coral atolls (Rose Island,
Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use;
arable land: 5%
permanent crops: 1 0%
permanent pastures: 0%
forests and woodland: 70%
of/?er; 15% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons common from December
to March
Environment - current issues: limited natural fresh
water resources; the water division of the government
has spent substantial funds in the past few years to
improve water catchments and pipelines
Geography - note: Pago Pago has one of the best
natural deepwater harbors in the South Pacific Ocean,
sheltered by shape from rough seas and protected by
peripheral mountains from high winds; strategic
location in the South Pacific Ocean','6931adc609a5c0ff634948b4ad6abc67b999c17bb2b35de94bc31a8171def8f2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07ba12bc8cb9a234662a33c92d3a8eb44b1e2180dd42eb7a19a689c879a80b53',2001,'AD','Andorra','geography',35,'Location: Southwestern Europe, between France
and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total: 468 sq km
land: 468 sq km
water: 0 sq km
Area ■ comparative: 2.5 times the size of
Washington, DC
Land boundaries:
total: 120.3 km
border countries: France 56.6 km, Spain 63.7 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm,
dry summers
Terrain: rugged mountains dissected by narrow
valleys
Elevation extremes:
lowest point: Riu Runer 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water,
timber, iron ore, lead
Land use:
arable land: 4%
permanent crops: 0%
permanent pastures: 45%
forests and woodland: 35%
other: 16% (1998 est.)
Irrigated land; NAsqkm
Natural hazards: snowslides, avalanches
Environment - current issues: deforestation;
overgrazing of mountain meadows contributes to soil
erosion; air pollution; wastewater treatment and solid
waste disposal
Environment - international agreements:
party to: Hazardous Wastes, Marine Dumping, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked','79efff89b1c309e84ed070aee460da3c1ffbaa0ff44b237a94c7ca2f7fcedf86','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('310388ee6e3fa459a90d41aa305580e3e1ffc3ff974ad0027acabf9d27aa6d5d',2001,'AO','Angola','geography',42,'Location: Southern Africa, bordering the South
Atlantic Ocean, between Namibia and Democratic
Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
tofa/; 1,246,700 sq km
/and.'' 1,246,700 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
fofa/.-5,198 km
border countries: Democratic Republic of the Congo
2,51 1 km (of which 220 km is the boundary of
discontiguous Cabinda Province), Republic of the
Congo 201 km, Namibia 1,376 km, Zambia 1 ,1 10 km
Coastline: 1,600 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: semiarid in south and along coast to
Luanda; north has cool, dry season (May to October)
and hot, rainy season (November to April)
Population: 10,366,031 (July 2001 est.)
Age structure:
0-14 years: 43.3^% (male 2,266,870; female
2,222,262)
15-64 years: 53.98% (male 2,847,089; female
2,748,091)
65 years and over: 2.71 % (male 1 27,798; female
153,921) (2001 est.)
Population growth rate: 2.15% (2001 est.)
Birth rate: 46.54 births/1,000 population (2001 est.)
Death rate: 24.68 deaths/1,000 population
(2001 est.)
Net migration rate: -0.34 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
at birth: 06 male(s)/female
under 15 years: 02 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .02 male(s)/female (2001 est.)
Infant mortality rate: 1 93.72 deaths/1 ,000 live
births (2001 est.)
Life expectancy at birth:
total population: 38.59 years
male: 37.36 years
female: 39.87 years (2001 est.)
Total fertility rate: 6.48 children born/woman
(2001 est.)
12
Angola (continued)
HIV/AIDS ■ adult prevalence rate: 2.78%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 160,000
(1999 est.)
HIV/AIDS - deaths: 1 5,000 (1 999 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%,
Bakongo 13%, mestico (mixed European and Native
African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic
38%, Protestant 15% (1998 est.)
Languages: Portuguese (official), Bantu and other
African languages
Literacy:
definition: age 15 and over can read and write
total population: A2%
male: 56%
fema/e;28%(1998 est.)','b17e9e3445321351bafff998c41f64a571f6cc50cb87f913643ba6eb802f1db0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b72e316c34c440f3e0e7c197f4205684e8c1b339692fa287dce2f7d68aec36da',2001,'AI','Anguilla','geography',50,'Location: Caribbean, island in the Caribbean Sea,
east of Puerto Rico
Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the
Caribbean
Area:
total: 91 sq km
land: 91 sq km
water: 0 sq km
Area - comparative: about half the size of
Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime ciaims:
exclusive fishing zone: 200 NM
territorial sea: 8
Ciimate: tropical; moderated by northeast trade
winds
Terrain: flat and low-lying island of coral and
limestone
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crocus Flill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: 0%
permanent crops: 0%
14
Anguilla (continued)
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly rock with sparse scrub oak, few
trees, some commercial salt ponds)
Irrigated land: NAsqkm
Natural hazards: frequent hurricanes and other
tropical storms (July to October)
Environment ■ current issues: supplies of potable
water sometimes cannot meet increasing demand
largely because of poor distribution system','2fa5bece1972cb5d3e373493af9dd66d3381124424ba20106ec15f0ed7151623','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91a215afe6318a600b70ec847c4ba17c60ecef7d8b6f2d885b84b85bb160e750',2001,'AQ','Antarctica','geography',57,'Location: continent mostly south of the Antarctic
Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72
million sq km ice-covered) (est.)
nofe.''fifth-largest continent, following Asia, Africa,
North America, and South America, but larger than
Australia and the subcontinent of Europe
Area - comparative: slightly less than 1 .5 times the
size of the US
Land boundaries: 0 km
note: see entry on International disputes
Coastline: 17,968 km
Maritime claims: none; nineteen of 26 Antarctic
consultative nations have made no claims to Antarctic
territory (although Russia and the US have reserved
the right to do so) and do not recognize the claims of
the other nations; also see the Disputes - international
entry
Climate: severe low temperatures vary with latitude,
elevation, and distance from the ocean; East
Antarctica is colder than West Antarctica because of
its higher elevation; Antarctic Peninsula has the most
moderate climate; higher temperatures occur in
January along the coast and average slightly below
freezing
Terrain: about 98% thick continental ice sheet and
2% barren rock, with average elevations between
2,000 and 4,000 meters; mountain ranges up to 5,140
meters; ice-free coastal areas include parts of
southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo
Sound; glaciers form ice shelves along about half of
the coastline, and floating ice shelves constitute 11%
of the area of the continent
Elevation extremes:
lowest point: Bentley Subglacial Trench -2,540 m
highest point: V\\nsor\\ Massif 5,140 m
note: the lowest known land point in Antarctica is
hidden in the Bentley Subgiacial Trench; at its surface
is the deepest ice yet discovered and the world''s
lowest elevation not under sea water
Natural resources: iron ore, chromium, copper,
gold, nickel, platinum and other minerals, and coal
and hydrocarbons have been found in small
uncommercial quantities; none presently exploited;
krill, finfish, and crab have been taken by commercial
fisheries
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (ice 98%, barren rock 2%)
Irrigated land: 0 sq km (1 993)
Natural hazards: katabatic (gravity-driven) winds
blow coastward from the high interior; frequent
blizzards form near the foot of the plateau; cyclonic
storms form over the ocean and move clockwise along
the coast; volcanism on Deception Island and isolated
areas of West Antarctica; other seismic activity rare
and weak; large icebergs may calve from ice shelf
Environment - current issues: in 1998, NASA
satellite data showed that the antarctic ozone hole
was the largest on record, covering 27 million square
kilometers; researchers in 1 997 found that increased
ultraviolet light coming through the hole damages the
DNA of icefish, an antarctic fish lacking hemoglobin;
ozone depletion earlier was shown to harm one-celled
antarctic marine plants
16
Antarctica (continued)
Geography ■ note: the coldest, windiest, highest (on
average), and driest continent; during summer, more
solar radiation reaches the surface at the South Pole
than is received at the Equator in an equivalent period;
mostly uninhabitable
Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent
States
Area:
total: 29,800 sq km
land: 28,400 sq km
water: 1 ,400 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 1 ,254 km
border countries: Azerbaijan-proper 566 km,
Azerbaijan-Naxcivan exclave 221 km, Georgia 164
km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold
winters
Terrain: Armenian Highland with mountains; little
forest land; fast flowing rivers; good soil in Aras River
valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of gold, copper,
molybdenum, zinc, alumina
Land use:
arable iand: M%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 1 5%
other: 41% (^993 est.)
Irrigated land: 2,870 sq km (1993 est.)
Natural hazards: occasionally severe earthquakes;
droughts
Environment - current issues: soil pollution from
toxic chemicals such as DDT; energy blockade, the
result of conflict with Azerbaijan, has led to
deforestation when citizens scavenged for firewood;
pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its
use as a source for hydropower, threatens drinking
water supplies; restart of Metsamor nuclear power
plant without adequate (IAEA-recommended) safety
and backup systems
Environment ■ international agreements:
party to.'' Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: landlocked
Location: Caribbean, island in the Caribbean Sea,
north of Venezuela
Geographic coordinates: 12 30 N, 69 58 W
Map references: Central America and the Caribbean
Area:
total: 193 sq km
land: 1 93 sq km
water: 0 sq km
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims:
territorial sea: 12 NM
Climate: tropical marine; little seasonal temperature
variation
Terrain: flat with a few hills; scant vegetation
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 1 88 m
Natural resources: NEGL; white sandy beaches
Land use:
arable land: 7% (including aloe 0.01%)
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 93% {1993 est.)
Irrigated land: 0.01 sq km
Natural hazards: lies outside the Caribbean
hurricane belt
Environment - current issues: NA
Location: Southeastern Asia, islands in the Indian
Ocean, northwest of Australia
Geographic coordinates: 12 14 S, 123 05 E
Map references: Southeast Asia
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West, Middle, and East
Islets) and Cartier Island
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims:
contiguous zone.* 12 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 NM
territorial sea: 3 NM
Climate: tropical
Terrain: low with sand and coral
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all grass and sand)
Irrigated land: 0sqkm(1993)
Natural hazards: surrounded by shoals and reefs
that can pose maritime hazards
Environment -current issues: NA
Geography - note: Ashmore Reef National Nature
Reserve established in August 1983
Location: body of water between Africa, Europe, the
Southern Ocean, and the Western Hemisphere
Geographic coordinates: 0 00 N, 25 00 W
Map references: World
Area;
fofa/: 76.762 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea,
Davis Strait, Denmark Strait, part of the Drake
Passage, Gulf of Mexico, Mediterranean Sea, North
Sea, Norwegian Sea, almost all of the Scotia Sea, and
other tributary water bodies
Area - comparative; slightly less than 6.5 times the
size of the US
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) develop off
the coast of Africa near Cape Verde and move
westward into the Caribbean Sea; hurricanes can
occur from May to December, but are most frequent
from August to November
Terrain: surface usually covered with sea ice in
Labrador Sea, Denmark Strait, and Baltic Sea from
October to June; clockwise warm-water gyre (broad,
circular system of currents) in the northern Atlantic,
counterclockwise warm-water gyre in the southern
Atlantic; the ocean floor is dominated by the
28
Atlantic Ocean (continued)
Mid-Atlantic Ridge, a rugged north-south centerline
for the entire Atlantic basin
Elevation extremes:
lowest point: Milwaukee Deep in the Puerto Rico
Trench -8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, marine
mammals (seals and whales), sand and gravel
aggregates, placer deposits, polymetallic nodules,
precious stones
Natural hazards: icebergs common in Davis Strait,
Denmark Strait, and the northwestern Atlantic Ocean
from February to August and have been spotted as far
south as Bermuda and the Madeira Islands; ships
subject to superstructure icing in extreme northern
Atlantic from October to May; persistent fog can be a
maritime hazard from May to September; hurricanes
(May to December)
Environment ■ current issues: endangered marine
species include the manatee, seals, sea lions, turtles,
and whales; drift net fishing is hastening the decline of
fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern
Brazil, and eastern Argentina; oil pollution in
Caribbean Sea, Gulf of Mexico, Lake Maracaibo,
Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North
Sea, and Mediterranean Sea
Geography - note: major chokepoints include the
Dardanelles, Strait of Gibraltar, access to the Panama
and Suez Canals; strategic straits include the Strait of
Dover, Straits of Florida, Mona Passage, The Sound
(Oresund), and Windward Passage; the Equator
divides the Atlantic Ocean into the North Atlantic
Ocean and South Atlantic Ocean
Transportation - note: Kiel Canal and Saint
Lawrence Seaway are two important waterways;
significant domestic commercial and recreational use
of Intracoastal Waterway on central and south Atlantic
seaboard and Gulf of Mexico coast of US','ac89478b7a3c1d59c63bfe03164d0c9f6a395244d91745dd397786245c14f013','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96ec127af243fb80d665ea9ebd140bc983a6aa6917b6c60cc95b2110396657ee',2001,'AG','Antigua and Barbuda','geography',65,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the
Caribbean
Area:
total: 442 sq km (Antigua 281 sq km; Barbuda 161 sq
km)
land: 442 sq km
water: 0 sq km
note: includes Redonda
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; little seasonal temperature
variation
Terrain: mostly low-lying limestone and coral
islands, with some higher volcanic areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant climate fosters
tourism
18
Antigua and Barbuda (continued)
Land use;
arable land:
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 1 1 %
other: 62% Om est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes and tropical storms
(July to October); periodic droughts
Environment - current issues; water
management - a major concern because of limited
natural fresh water resources - is further hampered by
the clearing of trees to increase crop production,
causing rainfall to run off quickly
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected
agreements','d299be952eda5e1c4392339cda99811128006cd6e58cf3baf34b11ee0514058c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc54cfd0440ac3a6295c5c1ea4375ae1320c32d89c5005dc8e7cf96f236557dd',2001,'GP','Guadeloupe','geography',75,'Location: body of water between Europe, Asia, and
North America, mostly north of the Arctic Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea, East Siberian Sea, Greenland Sea,
Hudson Bay, Hudson Strait, Kara Sea, Laptev Sea,
Northwest Passage, and other tributary water bodies
Area - comparative: slightly less than 1 .5 times the
size of the US
Coastline: 45,389 km
Climate: polar climate characterized by persistent
cold and relatively narrow annual temperature ranges;
winters characterized by continuous darkness, cold
and stable weather conditions, and clear skies;
summers characterized by continuous daylight, damp
and foggy weather, and weak cyclones with rain or
snow
Terrain: central surface covered by a perennial
drifting polar icepack that averages about 3 meters in
thickness, although pressure ridges may be three
times that size; clockwise drift pattern in the Beaufort
Gyral Stream, but nearly straight-line movement from
the New Siberian Islands (Russia) to Denmark Strait
(between Greenland and Iceland); the icepack is
surrounded by open seas during the summer, but
more than doubles in size during the winter and
20
Arctic Ocean (continued)
extends to the encircling landimasses; the ocean floor
is about 50% continental shelf (highest percentage of
any ocean) with the remainder a central basin
interrupted by three submarine ridges (Alpha
Cordillera, Nansen Cordillera, and Lomonosov Ridge)
Elevation extremes:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates,
placer deposits, polymetallic nodules, oil and gas
fields, fish, marine mammals (seals and whales)
Natural hazards: ice islands occasionally break
away from northern Ellesmere Island; icebergs calved
from glaciers in western Greenland and extreme
northeastern Canada; permafrost in islands; virtually
ice locked from October to June; ships subject to
superstructure icing from October to May
Environment - current issues: endangered marine
species include walruses and whales; fragile
ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
Geography - note: major chokepoint is the southern
Chukchi Sea (northern access to the Pacific Ocean
via the Bering Strait); strategic location between North
America and Russia; shortest marine link between the
extremes of eastern and western Russia; floating
research stations operated by the US and Russia;
maximum snow cover in March or April about 20 to 50
centimeters over the frozen ocean; snow cover lasts
about 10 months
Location: Caribbean, islands in the eastern
Caribbean Sea, southeast of Puerto Rico
Geographic coordinates: 16 15 N, 61 35 W
Map references: Central America and the Caribbean
Area:
total: 1,780 sq km
land: 1 ,706 sq km
water: 74 sq km
note: Guadeloupe is an archipelago of nine inhabited
islands, including Basse-Terre, Grande-Terre,
Marie-Galante, La Desirade, lies des Saintes (2),
Saint-Barthelemy, lies de la Petite Terre, and
Saint-Martin (French part of the island of Saint Martin
Area - comparative: 10 times the size of
Washington, DC
Land boundaries:
total: 10.2 km
border countries: Netherlands Antilles (Sint Maarten)
10.2 km
Coastline: 306 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: subtropical tempered by trade winds;
moderately high humidity
Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation;
most of the seven other islands are volcanic in origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Souime 1,467 m
Natural resources: cultivable land, beaches and
climate that foster tourism
Land use:
arable land: 14%
permanent crops: 4%
permanent pastures: 14%
forests and woodland: 39%
other: 29% (im est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: hurricanes (June to October);
Soufriere is an active volcano
Environment - current issues: NA','a2637d0adee38be52b989249089e3c4e895851e5b4c9d93faadee429da4b388e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('614c62b82834c286b1e1b6483a15ebf78bd7123c57e336c599421235fc6de50c',2001,'AR','Argentina','geography',78,'Location: Southern South America, bordering the
South Atlantic Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area:
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area - comparative: slightly less than three-tenths
the size of the US
Land boundaries:
total: 9,665 km
border countries: Bolivia 832 km, Brazil 1,224 km,
Chile 5,1 50 km, Paraguay 1 ,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: mostly temperate; arid in southeast;
subantarctic in southwest
Terrain: rich plains of the Pampas in northern half,
flat to rolling plateau of Patagonia in south, rugged
Andes along western border
Elevation extremes:
lowest point: Salinas Chicas -40 m (located on
Peninsula Valdes)
highest point: Cerro Aconcagua 6,960 m
Natural resources: fertile plains of the Pampas,
lead, zinc, tin, copper, iron ore, manganese,
petroleum, uranium
Land use:
arable land: 9%
permanent crops: ^%
permanent pastures: 52%
forests and woodland: 1 9%
ofher; 19% (1993 est.)
Irrigated land: 17,000 sq km (1993 est.)
Natural hazards: San Miguel de Tucuman and
Mendoza areas in the Andes subject to earthquakes;
pamperos are violent windstorms that can strike the
Pampas and northeast; heavy flooding
Environment - current issues: environmental
problems (urban and rural) typical of an industrializing
economy such as soil degradation, desertification, air
pollution, and water pollution
note: Argentina is a world leader in setting voluntary
greenhouse gas targets
Environment - international agreements:
party fo,'' Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: second-largest country in South
America (after Brazil); strategic location relative to sea
lanes between South Atlantic and South Pacific
Oceans (Strait of Magellan, Beagle Channel, Drake
Passage)
Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area:
tofa/; 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
Area - comparative: slightly smaller than California
Land boundaries:
total: 3,920 km
border countries: Argentina 1 ,880 km, Bolivia 750 km,
Brazil 1 ,290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to temperate; substantial rainfall
in the eastern portions, becoming semiarid in the far
west
Terrain: grassy plains and wooded hills east of Rio
Paraguay: Gran Chaco region west of Rio Paraguay
mostly low, marshy plain near the river, and dry forest
and thorny scrub elsewhere
Elevation extremes:
lowest point: junction of Rio Paraguay and Rio Parana
46 m
highest point: Cerro Pero (Cerro Tres Kandu) 842 m
Natural resources: hydropower, timber, iron ore,
manganese, limestone
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 55%
forests and woodland: 32%
other: 7% (^993 est.)
Irrigated land: 670 sq km (1 993 est.)
Natural hazards: local flooding in southeast (early
September to June); poorly drained plains may
become boggy (early October to June)
Environment - current issues: deforestation (an
estimated 2 million hectares of forest land were lost
from 1958-85); water pollution; inadequate means for
waste disposal present health risks for many urban
residents
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Nuclear Test Ban
Geography ■ note: landlocked; lies between
Argentina, Bolivia, and Brazil','db0a7124d9dad1b830bd66644796f92eb1087f735aa87e6db2eab443975baf72','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73b544efb78fb4c5e20cb4d6bc909c954792d5bc7a97f439ee9341b58760ea21',2001,'AU','Australia','geography',85,'Location: Oceania, continent between the Indian
Ocean and the South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area:
total: 7,686,850 sq km
/and.'' 7,617,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie
Island
Area ■ comparative: slightly smaller than the US
Land boundaries: 0 km
Coastline: 25,760 km
Maritime ciaims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: ^12 NM
Ciimate: generally arid to semiarid; temperate in
south and east; tropical in north
Terrain: mostly low plateau with deserts; fertile plain
in southeast
Elevation extremes:
lowest point: Lake Eyre - 1 5 m
29
Australia (continued)
highest point: Mount Kosciuszko 2,229 m
Natural resources: bauxite, coal, iron ore, copper,
tin, silver, uranium, nickel, tungsten, mineral sands,
lead, zinc, diamonds, natural gas, petroleum
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 54%
forests and woodland: 1 9%
ote21%(1993 est.)
Irrigated land: 21 ,070 sq km (1993 est.)
Natural hazards: cyclones along the coast; severe
droughts
Environment - current issues: soil erosion from
overgrazing, industrial development, urbanization,
and poor farming practices; soil salinity rising due to
the use of poor quality water; desertification; clearing
for agricultural purposes threatens the natural habitat
of many unique animal and plant species; the Great
Barrier Reef off the northeast coast, the largest coral
reef in the world, is threatened by increased shipping
and its popularity as a tourist site; limited natural fresh
water resources
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: world''s smallest continent but
sixth-largest country; population concentrated along
the eastern and southeastern coasts; regular, tropical,
invigorating, sea breeze known as "the Doctor" occurs
along the west coast in the summer
Location: Central Europe, north of Italy and Slovenia
Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area:
total: 83,858 sq km
land: 82,738 sq km
wafer; 1,120 sq km
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 2,562 km
border counfr/es; Czech Republic 362 km, Germany
784 km, Hungary 366 km, Italy 430 km, Liechtenstein
35 km, Slovakia 91 km, Slovenia 330 km, Switzerland
164 km
Coastline: 0 km (landlocked)
Maritime ciaims: none (landlocked)
Climate: temperate: continental, cloudy: cold winters
with frequent rain in lowlands and snow in mountains;
cool summers with occasional showers
Terrain: in the west and south mostly mountains
(Alps): along the eastern and northern margins mostly
flat or gently sloping
Elevation extremes:
lowest point: Neusiedler See 115 m
highest point: Grossglockner 3,798 m
Natural resources: iron ore, oil, timber, magnesite,
lead, coal, lignite, copper, hydropower
Land use;
arable land: 17%
permanent crops: 1%
permanent pastures: 23%
forests and woodland: 39%
of/?er; 20% (1996 est.)
Irrigated land: 457 sq km (1995 est.)
Natural hazards: NA
Environment - current issues: some forest
degradation caused by air and soil pollution; soil
pollution results from the use of agricultural
chemicals; air pollution results from emissions by
coal- and oil-fired power stations and industrial plants
and from trucks transiting Austria between northern
and southern Europe
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked; strategic location at
the crossroads of central Europe with many easily
traversable Alpine passes and valleys; major river is
the Danube; population is concentrated on eastern
lowlands because of steep slopes, poor soils, and low
temperatures elsewhere
Location: Middle America, atoll in the North Pacific
Ocean, 1,120 km southwest of Mexico
Geographic coordinates: 10 17 N, 109 13 W
Map references; World
Area:
total: 7 sq km
land: 7 sq km
water: 0 sq km
Area - comparative; about 12 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 11.1km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical, humid, average temperature 20-32
degrees C, rains May-October
Terrain: coral atoll
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
of/?er; 100% (all coral)
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment ■ current Issues: NA
Geography - note: reef about 8 km in circumference
Location: Southern Europe, an enclave of Rome
(Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area:
total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
Area - comparative; about 0.7 times the size of The
Mall in Washington, DC
Land boundaries:
total: 32 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters (September
to mid-May) with hot, dry summers (May to
September)
Terrain: low hill
Elevation extremes:
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
oto; 100% (urban area)
Irrigated land: 0sqkm(1993)
Natural hazards; NA
Environment - current issues: NA
Environment - international agreements:
party to: Marine Dumping, Ship Pollution
signed, but not ratified: Air Pollution, Environmental
Modification
Geography - note: urban; landlocked; enclave of
Rome, Italy; world''s smallest state; outside the
Vatican City, 13 buildings in Rome and Castel
Gandolfo (the pope''s summer residence) enjoy
extraterritorial rights
Geographic coordinates: 0 48 N, 176 38 W
Map references: Oceania
Area:
total: 1 .6 sq km
land: 1 .6 sq km
water: 0 sq km
Area - comparative: about three times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 6.4 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low-lying, nearly level, sandy, coral island
surrounded by a narrow fringing reef; depressed
central area
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 3 m
Natural resources: guano (deposits worked until
late 1800s), terrestrial and aquatic wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 5%
other: 95%
Irrigated land: 0sqkm(1998)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: no natural fresh
water resources
Geography - note: almost totally covered with
grasses, prostrate vines, and low-growing shrubs;
small area of trees in the center; primarily a nesting,
roosting, and foraging habitat for seabirds, shorebirds,
and marine wildlife
Location: Oceania, island in the South Pacific
Ocean, east of Australia
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area:
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
Area - comparative: about 0.2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 3
Climate; subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly rolling plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 0%
other: 75% {]993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons (especially May to July)
Environment - current issues: NA
Location: Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area:
total: 477 sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and
Tinian
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,482 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; moderated by northeast
trade winds, little seasonal temperature variation; dry
season December to June, rainy season July to
October
Terrain: southern islands are limestone with level
terraces and fringing coral reefs; northern islands are
volcanic
379
Northern Mariana Islands (continued)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Agrihan 965 m
Natural resources: arable land, fish
Land use:
arable land: 2^%
permanent crops: 0%
permanent pastures: 1 9%
forests and woodland: 0%
other: 60%
Irrigated land: NA sq km
Natural hazards: active volcanoes on Pagan and
Agrihan; typhoons (especially August to November)
Environment - current issues: contamination of
groundwater on Saipan may contribute to disease;
clean-up of landfill; protection of endangered species
conflicts with development
Geography - note: strategic location in the North
Pacific Ocean','f6de0b271f1b6a2831669337886d5f6852ac9cbc5c264e523e02bcea0c4d795b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4d0c21229819ee391a334558ae4170ceb0e8f5dff48cdc9c6b9d958b3feb63d',2001,'AZ','Azerbaijan','geography',92,'Location: Southwestern Asia, bordering the Caspian
Sea, between Iran and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent
States
Area:
total: 86,600 sq km
/and; 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous
Republic and the Nagorno-Karabakh region; the
region''s autonomy was abolished by Azerbaijani
Supreme Soviet on 26 November 1991
Area ■ comparative: slightly smaller than Maine
Land boundaries:
total: 2,013 km
border countries: Armenia (with Azerbaijan-proper)
566 km, Armenia (with Azerbaijan-Naxcivan exclave)
221 km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with
Azerbaijan-Naxcivan exclave) 179 km, Russia 284
km, Turkey 9 km
Coastline: 0 km (landlocked); note - Azerbaijan
borders the Caspian Sea (800 km, est.)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi (Kura-Araks
Lowland) (much of it below sea level) with Great
Caucasus Mountains to the north, Qarabag Yaylasi
(Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian
Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore,
nonferrous metals, alumina
Land use:
arable land: 18%
permanent crops: 5%
permanent pastures: 25%
forests and woodland: 11%
of/?er;41%(1993 est.)
Irrigated land: 10,000 sq km (1993 est.)
Natural hazards: droughts; some lowland areas
threatened by rising levels of the Caspian Sea
Environment - current issues; local scientists
consider the Abseron Yasaqligi (Apsheron Peninsula)
(including Baku and Sumqayit) and the Caspian Sea
to be the ecologically most devastated area in the
world because of severe air, water, and soil pollution;
soil pollution results from the use of DDT as a
pesticide and also from toxic defoliants used in the
production of cotton
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
Location: Caribbean, chain of islands in the North
Atlantic Ocean, southeast of Florida
Geographic coordinates: 24 15 N, 76 00 W
Map references: Central America and the
Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; moderated by warm waters
of Gulf Stream
Terrain: long, flat coral formations with some low
rounded hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat Island 63 m
Natural resources: salt, aragonite, timber, arable
land
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 32%
other: 67% est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes and other tropical
storms that cause extensive flood and wind damage
Environment - current issues; coral reef decay;
solid waste disposal
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location adjacent to US
and Cuba; extensive island chain','9f9bee6a5fd6a1af86b7a8de62bbf89bc453aafaa7b3d4c7707b5c94748b27ef','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb6b2fddd847c7a9e6d4d4a1b331fb85ac61d3724befe794d8317ae1f2d347af',2001,'BH','Bahrain','geography',105,'Location: Middle East, archipelago in the Persian
Gulf, east of Saudi Arabia
Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area:
total: 620 sq km
land: 620 sq km
water: 0 sq km
Area - comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime ciaims:
contiguous zone: 24 NM
continental shelf: extending to boundaries to be
determined
territorial sea.- 12 NM
Climate; arid; mild, pleasant winters; very hot, humid
summers
Terrain: mostly low desert plain rising gently to low
central escarpment
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal ad Dukhan 122 m
Natural resources: oil, associated and
nonassociated natural gas, fish, pearls
Land use;
arable land: 1%
permanent crops: ^%
permanent pastures: 6%
forests and woodland: 0%
other: 92% (^m est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: periodic droughts; dust storms
Environment ■ current issues: desertification
resulting from the degradation of limited arable land,
periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and
sea vegetation) resulting from oil spills and other
discharges from large tankers, oil refineries, and
distribution stations; no natural fresh water resources
so that groundwater and sea water are the only
sources for all water needs
Environment ■ international agreements;
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: close to primary Middle Eastern
petroleum sources; strategic location in Persian Gulf
which much of Western world''s petroleum must transit
to reach open ocean
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to Australia
Geographic coordinates: 0 13 N, 176 31 W
Map references: Oceania
Area;
total: 1 .4 sq km
land: 1 .4 sq km
water: 0 sq km
Area - comparative: about 2.5 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 4.8 km
Maritime ciaims:
exclusive economic zone: 200 NM
territorial sea: ^2 HU
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low, nearly level coral island surrounded by
a narrow fringing reef
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: unnamed location 8 m
Natural resources: guano (deposits worked until
1891), terrestrial and aquatic wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: ^00%
Irrigated land: 0sqkm(1993)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues; no natural fresh
water resources
Geography - note: treeless, sparse, and scattered
vegetation consisting of grasses, prostrate vines, and
low growing shrubs; primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds, and marine
wildlife','c4a22f36c3ddb82941cc34fbdeb9fdc8c4000394b3f5e4347ccf8c449bd2812f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('941e463d5af3f519a0051921b320c8dc0803eb57e2ca47d272db541be0b89d78',2001,'BD','Bangladesh','geography',114,'Location: Southern Asia, bordering the Bay of
Bengal, between Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
tete/: 144,000 sq km
/and; 133,910 sq km
water: 1 0,090 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries:
total: 4,246 km
border countries: Burma 193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
contiguous zone: 18 HU
continental shelf: up to the outer limits of the
continental margin
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; mild winter (October to March);
hot, humid summer (March to June); humid, warm
rainy monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
Elevation extremes;
lowest point: Indian Ocean 0 m
highest point: Keokradong 1 ,230 m
Natural resources: natural gas, arable land, timber,
coal
Land use:
arable land: 73%
permanent crops: 2%
41
Bangladesh (continued)
permanent pastures: 5%
forests and woodland: 15%
other: 5% {m3 est.)
Irrigated land: 31 ,000 sq km (1 993 est.)
Natural hazards: droughts, cyclones; much of the
country routinely inundated during the summer
monsoon season
Environment - current issues: many people are
landless and forced to live on and cultivate
flood-prone land; water-borne diseases prevalent in
surface water; water pollution, especially of fishing
areas, results from the use of commercial pesticides;
ground water contaminated by naturally-occurring
arsenic; intermittent water shortages because of
falling water tables in the northern and central parts of
the country; soil degradation and erosion;
deforestation; severe overpopulation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Law of the Sea','19408d72f2bbbce3b3b7fc46053ffbee9c77d50ab5dfe6fce4ab012f45f0af9d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d363101a174235a3d527ffec18167a8f95ec53679702430ae4bbe90eedb3d28d',2001,'BB','Barbados','geography',122,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, northeast of
Venezuela
Geographic coordinates: 13 10 N, 59 32 W
Map references; Central America and the
Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: ^2 HU
Ciimate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central highland
region
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use;
arable land: 37%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 1 2%
of/)er;46%(1993 est.)
Irrigated land: NAsqkm
Natural hazards: infrequent hurricanes; periodic
landslides
Environment - current issues: pollution of coastal
waters from waste disposal by ships; soil erosion;
illegal solid waste disposal threatens contamination of
aquifers
Environment - international agreements:
party to: Climate Change, Ciimate Change-Kyoto
Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Biodiversity
Geography - note: easternmost Caribbean island','251911eed53ae7c390e3152da4248d750ed6beb1d0bc112eb51a46c4225fe290','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5417afd001332a04190ccf49358629be0e2f98373443c7df14cd13483bc64f24',2001,'BY','Belarus','geography',135,'Location: Southern Africa, islands in the southern
Mozambique Channel, about one-half of the way from
Madagascar to Mozambique
Geographic coordinates: 21 30 S, 39 50 E
Map references: Africa
Area:
total: 0.2 sq km
land: 0.2 sq km
water: 0 sq km
Area - comparative: about one-third the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastiine: 35.2 km
Maritime ciaims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Ciimate: tropical
Terrain: volcanic rock
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 2.4 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: ]00% (all rock)
Irrigated land: 0 sq km (1993)
Natural hazards: maritime hazard since it is usually
under water during high tide and surrounded by reefs;
subject to periodic cyclones
Environment - current issues: NA','86224c86802de80767a0852b39763d79ee3149dddbd4c56a381cf5fbf4e0339b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc5499d658c4bcc3f39a22e6a4785642499d1278ade8647298065b605a08dbae',2001,'FR','France','geography',137,'Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Commonwealth of Independent
States
Area:
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
Area - comparative: slightly smaller than Kansas
Land boundaries:
total: 3,098 km
border countries: Latvia 141 km, Lithuania 502 km,
Poland 605 km, Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: cold winters, cool and moist summers;
transitional between continental and maritime
Terrain: generally flat and contains much marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits, small
quantities of oil and natural gas
Land use:
arable land: 29%
permanent crops: ^%
permanent pastures: 1 5%
forests and woodland: 34%
ofher21%(1993 est.)
46
Belarus (continued)
Irrigated land: 1 ,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: soil pollution from
pesticide use; southern part of the country
contaminated with fallout from 1986 nuclear reactor
accident at Chornobyl'' in northern Ukraine
Environment ■ international agreements:
party fo; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: landlocked
Location: Western Europe, bordering the North Sea,
between France and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area:
tofa/; 30,510 sq km
land: 30,230 sq km
water: 280 sq km
Area - comparative: about the size of Maryland
Land boundaries:
total: ^,3S5 km
border countries: France 620 km, Germany 167 km,
Luxembourg 148 km, Netherlands 450 km
Coastline: 66 km
Maritime claims:
continental shelf: median line with neighbors
exclusive fishing zone: median line with neighbors
(extends about 68 km from coast)
territorial sea: 12 NM
Climate: temperate; mild winters, cool summers;
rainy, humid, cloudy
Terrain: flat coastal plains in northwest, central
rolling hills, rugged mountains of Ardennes Forest in
southeast
Elevation extremes:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
Natural resources: coal, natural gas
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 21%
other: 34%
Irrigated land: NAsqkm
Natural hazards: flooding is a threat in areas of
reclaimed coastal land, protected from the sea by
concrete dikes
Environment - current issues: the environment is
exposed to intense pressures from human activities:
urbanization, dense transportation network, industry,
intense animal breeding and crop cultivation; air and
water pollution also have repercussions for
neighboring countries; uncertainties regarding federal
and regional responsibilities (now resolved) have
impeded progress in tackling environmental
challenges
Environment - International agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Air Pollution-Sulphur 85,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: A\\r Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: crossroads of Western Europe;
majority of West European capitals within 1 ,000 km of
Brussels which is the seat of both the EU and NATO
Location: Southeastern Asia, group of islands in the
Indian Ocean, south of Indonesia, about one-half of
the way from Australia to Sri Lanka
Geographic coordinates: 12 30 S, 96 50 E
Map references: Southeast Asia
Area:
fofa/;14sq km
land: 14 sq km
water: 0 sq km
note: includes the two main islands of West Island and
Home Island
Area - comparative: about 24 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 2.6 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea; 3 NM
Climate: pleasant, modified by the southeast trade
winds for about nine months of the year; moderate
rainfall
Terrain: fiat, low-lying coral atolls
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
oto; 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones may occur in the early
months of the year
Environment - current issues: fresh water
resources are limited to rainwater accumulations in
natural underground reservoirs
Geography - note: two coral atolls thickly covered
with coconut palms and other vegetation
Location: Southern South America, islands in the
South Atlantic Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area:
tete/;12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East and West
Falkland and about 200 small islands
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
continental shelf: 200 NM
exclusive fishing zone: 200 NM
territorial sea: 12 NM
Climate: cold marine; strong westerly winds, cloudy,
humid; rain occurs on more than half of days in year;
occasional snow all year, except in January and
February, but does not accumulate
164
Falkland Islands (Islas Malvinas)
(continued)
Terrain: rocky, hilly, mountainous with some boggy,
undulating plains
Elevation extremes:
lowest point: MMic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 99%
forests and woodland: 0%
of/?er;1%(1993 est.)
Irrigated land: NAsqkm
Natural hazards: strong winds persist throughout
the year
Environment - current issues: NA
Geography - note: deeply indented coast provides
good natural harbors; short growing season
Location: Western Europe, bordering the Bay of
Biscay and English Channel, between Belgium and
Spain, southeast of the UK; bordering the
Mediterranean Sea, between Italy and Spain
Geographic coordinates: 46 00 N, 2 00 E
Map references: Europe
Area:
total: 547,030 sq km
land: 545,630 sq km
water: 1 ,400 sq km
note: includes only metropolitan France, but excludes
the overseas administrative divisions
Area - comparative: slightly less than twice the size
of Colorado
Land boundaries:
tofa/.'' 2,889 km
border countries: Andorra 56.6 km, Belgium 620 km,
Germany 451 km, Italy 488 km, Luxembourg 73 km,
Monaco 4.4 km, Spain 623 km, Switzerland 573 km
Coastline: 3,427 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM (does not apply to
the Mediterranean)
territorial sea: ^2 HU
Climate: generally cool winters and mild summers,
but mild winters and hot summers along the
Mediterranean; occasional strong, cold, dry,
north-to-northwesterly wind known as mistral
Terrain: mostly flat plains or gently rolling hills in
north and west; remainder is mountainous, especially
Pyrenees in south, Alps in east
Elevation extremes:
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: coal, iron ore, bauxite, zinc,
potash, timber, fish
Land use:
arable land: 33%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 27%
of/?er;18%(1993 est.)
Irrigated land: 16,300 sq km (1995 est.)
Natural hazards: flooding; avalanches
Environment - current issues: some forest
damage from acid rain (major forest damage occurred
as a result of severe December 1999 windstorm); air
pollution from industrial and vehicle emissions; water
pollution from urban wastes, agricultural runoff
Environment ■ international agreements:
party to; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: largest West European nation
Location: south of Africa, islands in the southern
Indian Ocean, about equidistant between Africa,
Antarctica, and Australia; note - French Southern and
Antarctic Lands includes He Amsterdam, He
Saint-Paul, lies Crozet, and lies Kerguelen in the
southern Indian Ocean, along with the
French-claimed sector of Antarctica, "Adelie Land";
the US does not recognize the French claim to "Adelie
Land"
Geographic coordinates: 43 00 S, 67 00 E
Map references: Antarctic Region
Area:
total: 7,781 sq km
land: 7,781 sq km
water: 0 sq km
nofe; includes He Amsterdam, He Saint-Paul, lies
Crozet and lies Kerguelen; excludes "Adelie Land"
claim of about 500,000 sq km in Antarctica that is not
recognized by the US
Area - comparative: slightly less than 1 .3 times the
size of Delaware
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
exclusive economic zone: 200 NM from lies
Kerguelen only
territorial sea: ^2 NM
Climate: antarctic
Terrain: volcanic
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Ross on lies Kerguelen 1 ,850 m
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: He Amsterdam and He Saint-Paul
are extinct volcanoes
Environment - current issues: NA
Geography - note: islands component is widely
scattered across remote locations in the southern
Indian Ocean
Location; Western Africa, bordering the Atlantic
Ocean at the Equator, between Republic of the Congo
and Equatorial Guinea
Geographic coordinates: 1 00 S, 11 45 E
Map references: Africa
Area:
total: 267,667 sq km
land: 257,667 sq km
wafer 10,000 sq km
Area - comparative: slightly smaller than Colorado
Land boundaries:
total: 2,551 km
border countries: Cameroon 298 km. Republic of the
Congo 1,903 km. Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior; savanna
in east and south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1 ,575 m
Natural resources: petroleum, manganese,
uranium, gold, timber, iron ore, hydropower
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 8%
forests and woodland: 77%
other; 3% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation;
poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Western Africa, bordering the North
Atlantic Ocean and Senegal
Geographic coordinates: 13 28 N, 16 34 W
Map references: Africa
Area:
total: M, 300 sq km
land: 10,000 sq km
water: 1 ,300 sq km
Area - comparative: slightly less than twice the size
of Delaware
Land boundaries:
total: 740 km
border countries: Senegal 740 km
Coastline: 80 km
Maritime claims:
contiguous zone: 13 NM
continental shelf: not specified
exclusive fishing zone: 200 NM
territorial sea: 12 NM
Climate: tropical; hot, rainy season (June to
November); cooler, dry season (November to May)
Terrain: flood plain of the Gambia river flanked by
some low hills
Elevation extremes:
towesfpotef; Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish
permanent pastures: 9%
forests and woodland: 28%
of/?er; 45% (1993 est.)
Irrigated land: 1 50 sq km (1 993 est.)
Natural hazards: drought (rainfall has dropped by
30% in the last 30 years)
Environment - current issues: deforestation;
desertification; water-borne diseases prevalent
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: almost an enclave of Senegal;
smallest country on the continent of Africa
Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 11 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli-occupied with current
status subject to the Israeli-Palestinian Interim
Agreement - permanent status to be determined
through further negotiation
Climate: temperate, mild winters, dry and warm to
hot summers
Terrain: flat to rolling, sand- and dune-covered
coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: arable land, natural gas
Land use:
arable land: 24%
permanent crops: 39%
permanent pastures: 0%
forests and woodland: 1 1 %
other; 26% (1993 est.)
Irrigated land: 1 20 sq km (1 993 est.)
Natural hazards: droughts
Environment ■ current issues; desertification;
salination of fresh water; sewage treatment;
water-borne disease; soil degradation
Geography ■ note: there are 25 Israeli settlements
and civilian land use sites in the Gaza Strip (August
2000 est.)
Location: Southwestern Asia, bordering the Black
Sea, between Turkey and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Commonwealth of Independent
States
Area:
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
Area comparative: slightly smaller than South
Carolina
Land boundaries:
tofa/.'' 1,461 km
border counfr/es; Armenia 164 km, Azerbaijan 322
km, Russia 723 km, Turkey 252 km
Coastline: 310 km
Maritime claims: NA
Climate: warm and pleasant; Mediterranean-like on
Black Sea coast
Terrain: largely mountainous with Great Caucasus
Mountains in the north and Lesser Caucasus
Mountains in the south; Kolkhet''is Dablobi (Kolkhida
Lowland) opens to the Black Sea in the west; Mtkvari
River Basin in the east; good soils in river valley flood
plains, foothills of Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek)
5,048 m
Natural resources: forests, hydropower,
manganese deposits, iron ore, copper, minor coal and
oil deposits; coastal climate and soils allow for
important tea and citrus growth
Land use:
arable land: 9%
permanent crops: 4%
permanent pastures: 25%
forests and woodland: 34%
other; 28% (1993 est.)
Irrigated land: 4,000 sq km (1993 est.)
Natural hazards: earthquakes
Environment - current issues: air pollution,
particularly in Rust''avi; heavy pollution of Mtkvari
River and the Black Sea; inadequate supplies of
potable water; soil pollution from toxic chemicals
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area:
total: 244,820 sq km
land: 241 ,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland Islands
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
continental shelf: as defined in continental shelf
orders or in accordance with agreed upon boundaries
exclusive fishing zone: 200 NM
territorial sea: 12 NM
Climate: temperate; moderated by prevailing
southwest winds over the North Atlantic Current; more
than one-half of the days are overcast
Terrain: mostly rugged hills and low mountains; level
to rolling plains in east and southeast
Elevation extremes:
lowest point: Fen land -4 m
highest point: Ben Nevis 1,343 m
Natural resources: coal, petroleum, natural gas, tin,
limestone, iron ore, salt, clay, chalk, gypsum, lead,
silica, arable land
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 10%
of/?er; 19% (1993 est.)
Irrigated iand: 1,080 sq km (1993 est.)
Naturai hazards: NA
Environment - current issues: continues to reduce
greenhouse gas emissions (has meet Kyoto Protocol
target of a 12.5% reduction from 1990 levels and
hopes to reduce even more); small particulate
emissions, largely from vehicular traffic, remain a
problem: solid waste continues to rise and recycling is
very limited
Environment - internationai agreements:
party to.'' Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: lies near vital North Atlantic sea
lanes; only 35 km from France and now linked by
tunnel under the English Channel; because of heavily
indented coastline, no location is more than 125 km
from tidal waters
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the
northwest quarter of the Dead Sea, but excludes Mt.
Scopus; East Jerusalem and Jerusalem No Man''s
Land are also included only as a means of depicting
the entire area occupied by Israel in 1967
Area - comparative: slightly smaller than Delaware
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, temperature and precipitation
vary with altitude, warm to hot summers, cool to mild
winters
Terrain: mostly rugged dissected upland, some
vegetation in west, but barren in east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: JaW Asur 1,022 m
Natural resources: arable land
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 32%
forests and woodland: 1%
other: 40%
Irrigated land: NAsqkm
Natural hazards: droughts
Environment - current issues: adequacy of fresh
water supply: sewage treatment
Geography - note: landlocked; highlands are main
recharge area for Israel''s coastal aquifers: there are
231 Israeli settlements and civilian land use sites in
the West Bank and 29 in East Jerusalem (August
1999 est.)','199e87a131f4d1575d95498648a16d0496f6c2f74b2fa687242bf869237b9a19','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbd68bc6334a65920d517b2f386b85b08a41bf21ee33136f75644e52e7f39b5e',2001,'BZ','Belize','geography',150,'Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Central America and the Caribbean
Area:
total: 22,966 sq km
land: 22,806 sq km
water; 160 sq km
Area ■ comparative: slightly smaller than
Massachusetts
Land boundaries:
tote/; 51 6 km
border countries: Guatemala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM in the north, 3 NM in the south;
note - from the mouth of the Sarstoon River to
Ranguana Cay, Belize''s territorial sea is 3 NM;
according to Belize''s Maritime Areas Act, 1992, the
purpose of this limitation is to provide a framework for
the negotiation of a definitive agreement on territorial
differences with Guatemala
Climate: tropical; very hot and humid; rainy season
(May to November); dry season (February to May)
Terrain: flat, swampy coastal plain; low mountains in
south
Elevation extremes:
lowest point: Caribbean Sea 0 m
51
Belize (continued)
highest point: V\\c\\of\\Si Peak 1,160 m
Natural resources: arable land potential, timber,
fish, hydropower
Land use:
arable land: ^Q%
permanent crops: ^%
permanent pastures: 2%
forests and woodland: 84%
other: 3% (2000 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent, devastating hurricanes
(September to December) and coastal flooding
(especially in south)
Environment - current issues: deforestation; water
pollution from sewage, industrial effluents, agricultural
runoff; solid waste disposal
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Marine Dumping, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: only country in Central America
without a coastline on the North Pacific Ocean
Location: Western Africa, bordering the North
Atlantic Ocean, between Nigeria and Togo
Geographic coordinates: 9 30 N, 215 E
Map references: Africa
Area:
fofa/.'' 11 2,620 sq km
/and; 11 0,620 sq km
water: 2,000 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 1 ,989 km
border countries: Burkina Faso 306 km, Niger 266
km, Nigeria 773 km, Togo 644 km
Coastline: 121 km
Maritime claims:
territorial sea: 200 NM
53
Benin (continued)
Climate: tropical; hot, humid in south; semiarid in
north
Terrain: mostly flat to undulating plain; some hills
and low mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Sokbaro 658 m
Natural resources: small offshore oil deposits,
limestone, marble, timber
Land use:
arable land: 13%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 31 %
of/7e/'';48%(1993 est.)
Irrigated land: 1 00 sq km (1 993 est.)
Natural hazards: hot, dry, dusty harmattan wind
may affect north in winter
Environment - current issues: inadequate
supplies of potable water; poaching threatens wildlife
populations; deforestation; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: no natural harbors','0021480389d9d417fa951d303bc74aa8a7038df511c74d28a4c46a726b27e40c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de9c6b30a8b90b576d40f9f5f3ceafe8482691a20b561d6db5af2673c05eb556',2001,'BM','Bermuda','geography',159,'Location: North America, group of islands in the
North Atlantic Ocean, east of North Carolina (US)
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area:
fofa/; 58.8 sq km
land: 58.8 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims;
exclusive fishing zone: 200 NM
territorial sea: “{2 NM
Climate; subtropical; mild, humid; gales, strong
winds common in winter
Terrain: low hills separated by fertile depressions
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Tom Hill 76 m
Natural resources: limestone, pleasant climate
fostering tourism
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 9A% (55% developed, 39% rural/open space)
(1997 est.)
Irrigated land; NAsqkm
Natural hazards: hurricanes (June to November)
Environment - current issues: asbestos disposal;
water pollution; preservation of open space
Geography - note: consists of about 360 small coral
islands with ample rainfall, but no rivers or freshwater
lakes; some land, reclaimed and otherwise, was
leased by US Government from 1941 to 1995
Location: Southern Asia, between China and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Area - comparative: about half the size of Indiana
Land boundaries:
total: 1 ,075 km
border countries: China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies; tropical in southern plains; cool
winters and hot summers in central valleys; severe
winters and cool summers in Himalayas
Terrain: mostly mountainous with some fertile
valleys and savanna
Elevation extremes:
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Natural resources: timber, hydropower, gypsum,
calcium carbide
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 66%
of/?er; 26% (1993 est.)
Irrigated land: 340 sq km (1993 est.)
Natural hazards: violent storms coming down from
the Himalayas are the source of the country''s name
which translates as Land of the Thunder Dragon;
frequent landslides during the rainy season
Environment - current issues: soil erosion; limited
access to potable water
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Marine
Dumping, Nuclear Test Ban, Ship Pollution
signed, but not ratified: Law of the Sea
Geography - note: landlocked; strategic location
between China and India; controls several key
Himalayan mountain passes
Location: Central South America, southwest of Brazil
Geographic coordinates: 17 00 S, 65 00 W
Map references: South America
Area:
fofa/; 1,098,580 sq km
/and; 1,084,390 sq km
wafer; 14,190 sq km
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 6,743 km
border countries: Argentina 832 km, Brazil 3,400 km,
Chile 861 km, Paraguay 750 km, Peru 900 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies with altitude; humid and tropical to
cold and semiarid
Terrain: rugged Andes Mountains with a highland
plateau (Altiplano), hills, lowland plains of the Amazon
Basin
Elevation extremes:
lowest point: Rio Paraguay 90 m
highest point: Nevado Sajama 6,542 m
Natural resources: tin, natural gas, petroleum, zinc,
tungsten, antimony, silver, iron, lead, gold, timber,
hydropower
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 24%
forests and woodland: 53%
of/}er; 21% (1993 est.)
Irrigated land: 1 ,750 sq km (1993 est.)
Natural hazards: flooding in the northeast
(March-April)
Environment - current issues: the clearing of land
for agricultural purposes and the international demand
for tropical timber are contributing to deforestation;
soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture);
desertification; loss of biodiversity; industrial pollution
of water supplies used for drinking and irrigation
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification,
Marine Dumping, Marine Life Conservation, Ozone
Layer Protection
Geography - note: landlocked; shares control of
Lago Titicaca, world''s highest navigable lake
(elevation 3,805 m), with Peru
Location: Southeastern Europe, bordering the
Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Bosnia and Herzegovina, Europe
Area;
total: 51,129 sq km
land: 51,129 sq km
water: 0 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1 ,459 km
border countries: Croatia 932 km, Yugoslavia 527 km
Coastiine: 20 km
Maritime claims: NA
Climate: hot summers and cold winters; areas of
high elevation have short, cool summers and long,
severe winters; mild, rainy winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese,
forests, copper, chromium, lead, zinc, hydropower
Land use:
arable land: 14%
permanent crops: 5%
permanent pastures: 20%
forests and woodland: 39%
other: 22% (1993 est.)
Irrigated land; 20 sq km (1993 est.)
Natural hazards: destructive earthquakes
Environment - current issues: air pollution from
metallurgical plants; sites for disposing of urban waste
are limited; water shortages and destruction of
Infrastructure because of the 1992-95 civil strife
Environment - international agreements:
party to: Air Pollution, Climate Change, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: within Bosnia and Herzegovina''s
recognized borders, the country is divided into a joint
Bosniak/Croat Federation (about 51% of the territory)
and the Bosnian Serb-led Republika Srpska or RS
(about 49% of the territory); the region called
Herzegovina is contiguous to Croatia and traditionally
has been settled by an ethnic Croat majority','a82013c4cd66e133b6fca996f9f8c19a489cb6e9c7670a59acd8233b546b4314','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cb435505157f08e14ccbe2fc9c69206b41c4170a9e9cb67263fb24e017a1e7f',2001,'BW','Botswana','geography',174,'Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area:
total: 600,370 sq km
land: 535,370 sq km
water; 15,000 sq km
Area ■ comparative: slightly smaller than Texas
Land boundaries:
total: 4,013 km
border countries: Namibia 1 ,360 km. South Africa
1,840 km, Zimbabwe 813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: semiarid; warm winters and hot summers
Terrain: predominantly flat to gently rolling tableland;
Kalahari Desert in southwest
Elevation extremes:
/owesfpo/nf; junction of the Limpopo and Shashe
Rivers 513 m
highest point: Tsodilo Hills 1 ,489 m
Natural resources: diamonds, copper, nickel, salt,
soda ash, potash, coal, iron ore, silver
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 47%
oteer; 6% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: periodic droughts; seasonal
August winds blow from the west, carrying sand and
dust across the country, which can obscure visibility
Environment - current issues: overgrazing;
desertification; limited fresh water resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; population
concentrated in eastern part of the country','1d0e5a46835ae41720d846766b76b652eb6d75e05f5e022067478ce71cd3c31c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a4e05909c197e7ade944dcead7fb5abc185235fd6b40c0485c4c9d03840c5bb',2001,'BV','Bouvet Island','geography',182,'Location: Southern Africa, island in the South
Atlantic Ocean, south-southwest of the Cape of Good
Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area:
total: 58.5 sq km
land: 58.5 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 HU
Climate: antarctic
Terrain: volcanic; maximum elevation about 800 m;
coast is mostly inaccessible
Elevation extremes:
lowest point: South Atlantic Ocean 0 m
highest point: Olav Peak 935 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
of/?er; 100% (93% ice)
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current issues: NA
Geography - note: covered by glacial ice; declared
a nature reserve','665a3ecdd47b3f76457bd343c5d0e1e6973a5bf44fdc8626106e11e62ed15517','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d62b870056e4152530cb01751dfe91d80b6d28fb0a25ec7c86ad188ba314b7c',2001,'BR','Brazil','geography',188,'Location: Eastern South America, bordering the
Atlantic Ocean
Geographic coordinates: 10 00 S, 55 00 W
Map references: South America
Area:
fofa/; 8,511,965 sq km
/ancf; 8,456,51 Osq km
water: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha,
Atol das Rocas, llha da Trindade, llhas Martin Vaz,
and Penedos de Sao Pedro e Sao Paulo
Area - comparative: slightly smaller than the US
Land boundaries:
total: 14,691 km
bordercounf/''/es; Argentina 1,224 km, Bolivia 3,400
km, Colombia 1,643 km, French Guiana 673 km,
Guyana 1,119 km, Paraguay 1 ,290 km, Peru 1,560
km, Suriname 597 km, Uruguay 985 km, Venezuela
2,200 km
Coastline: 7,491 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: mostly tropical, but temperate in south
Terrain: mostly flat to rolling lowlands in north; some
plains, hills, mountains, and narrow coastal belt
Elevation extremes;
lowest point: A\\\\ant:\\c Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron ore,
manganese, nickel, phosphates, platinum, tin,
uranium, petroleum, hydropower, timber
Land use:
arable land: 5%
permanent crops: 1%
permanent pastures: 22%
forests and woodland: 58%
ofber; 14% (1993 est.)
Irrigated land: 28,000 sq km (1993 est.)
Natural hazards: recurring droughts in northeast;
floods and occasional frost in south
Environment - current Issues: deforestation in
Amazon Basin destroys the habitat and endangers
the existence of a multitude of plant and animal
species indigenous to the area; air and water pollution
in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by
improper mining activities
note: President CARDOSO in September 1999
signed into force an environmental crime bill which for
the first time defines pollution and deforestation as
crimes punishable by stiff fines and jail sentences
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: CWmale Change-Kyoto
Protocol
Geography - note: largest country in South
America; shares common boundaries with every
South American country except Chile and Ecuador
Location: Southern Asia, archipelago in the Indian
Ocean, about one-half the way from Africa to','1129bb13e8a402a14bdea6c31f9b107ac567e3579673d09213ab7a28604957cd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d981c611a8dda807a754a8ebbfaa5492dfc6e440a54aba425105b73c583f1b36',2001,'ID','Indonesia','geography',195,'Geographic coordinates: 6 00 S, 71 30 E
Map references: World
Area:
total: 60 sq km
land: 60 sq km
water: 0 sq km
note: includes the entire Chagos Archipelago
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 3
Climate: tropical marine; hot, humid, moderated by
trade winds
70
British indian Ocean Territory (continued)
Terrain: flat and low (most areas do not exceed four
meters in elevation)
Elevation extremes:
lowest point: indian Ocean 0 m
highest point: umam6 iocation on Diego Garcia 15
m
Naturai resources: coconuts, fish, sugarcane
Land use:
arabie land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: NA%
other: NA%
Irrigated iand: 0sqkm(1993)
Naturai hazards: NA
Environment - current issues: NA
Geography - note: archipeiago of 2,300 islands;
Diego Garcia, largest and southernmost island,
occupies strategic location in central Indian Ocean;
isiand is site of joint US-UK military facility
Location: Caribbean, between the Caribbean Sea
and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30 W
Map references: Central America and the
Caribbean
Area;
total: ^50 sq km
land:^5Q sq km
water: 0 sq km
note: includes the island of Anegada
Area - comparative: about 0.9 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 3 HU
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain; coral isiands relatively flat; volcanic islands
steep, hilly
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Sage 521 m
Natural resources; NEGL
Land use:
arable land: 20%
permanent crops: 7%
permanent pastures: 33%
forests and woodland: 7%
other: 33% (1993 est.)
71
British Virgin Islands (continued)
Irrigated land: NAsqkm
Natural hazards: hurricanes and tropical storms
(July to October)
Environment - current issues: limited natural fresh
water resources (except for a few seasonal streams
and springs on Tortola, most of the islands'' water
supply comes from wells and rainwater catchment)
Geography - note: strong ties to nearby US Virgin
Islands and Puerto Rico
Location: Southeastern Asia, bordering the South
China Sea and Malaysia
Geographic coordinates: 4 30 N, 1 14 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5,270 sq km
water: 500 sq km
Area ■ comparative: slightly smaller than Delaware
Land boundaries:
total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims:
exclusive economic zone: 200 NM or to median line
territorial sea: 12 NM
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in east;
hilly lowland in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural gas, timber
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 %
forests and woodland: 85%
ote''12%(1993 est.)
Irrigated land; 1 0 sq km (1 993 est.)
Natural hazards: typhoons, earthquakes, and
severe flooding are very rare
Environment - current issues: seasonal smoke/
haze resulting from forest fires in Indonesia
Environment - international agreements:
party to: Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: close to vital sea lanes through
South China Sea linking Indian and Pacific Oceans;
two parts physically separated by Malaysia; almost an
enclave of Malaysia
Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area:
total: 702 sq km
land: 702 sq km
water: 0 sq km
note: includes Pohnpei (Ponape), Truk (Chuuk)
Islands, Yap Islands, and Kosrae
Area - comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; heavy year-round rainfall,
especially in the eastern islands; located on southern
edge of the typhoon belt with occasionally severe
damage
Terrain: islands vary geologically from high
mountainous islands to low, coral atolls; volcanic
outcroppings on Pohnpei, Kosrae, and Truk
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Jotolom 791 m
Natural resources: forests, marine products,
deep-seabed minerals
Land use;
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (June to December)
Environment - current issues: overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: four major island groups totaling
607 islands
Location: Oceania, atoll in the North Pacific Ocean,
about one-third of the way from Honolulu to Tokyo
Geographic coordinates: 28 13 N, 177 22 W
Map references: Oceania
Area;
total: 6.2 sq km
land: 6.2 sq km
water: 0 sq km
note: includes Eastern Island, Sand Island, and Spit
Island
Area - comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 15 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: subtropical, but moderated by prevailing
easterly winds
Terrain; low, nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 13 m
Natural resources: wildlife, terrestrial and aquatic
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1998)
Natural hazards: NA
Environment - current issues; NA
Geography - note: a coral atoll managed as a
national wildlife refuge and open to the public for
wildlife-related recreation in the form of wildlife
observation and photography, sport fishing,
snorkeling, and scuba diving
Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Commonwealth of Independent
States
Area:
fofa/; 33,843 sq km
/and; 33,371 sq km
wafer; 472 sq km
Area - comparative: slightly larger than Maryland
Land boundaries:
total: 1 ,389 km
border countries: Romania 450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south to Black
Sea
Elevation extremes:
lowest point: Nistru (Dnister) River 2 m
highest point: Dealul Balanesti 430 m
Natural resources: lignite, phosphorites, gypsum,
arable land
Land use:
arable land: 53%
permanent crops: 14%
permanent pastures: 13%
forests and woodland: 1 3%
of/?er; 7% (1993 est.)
Irrigated land: 3,110 sq km (1993 est.)
Natural hazards: landslides (57 cases in 1998)
Environment - current issues: heavy use of
agricultural chemicals, including banned pesticides
such as DDT, has contaminated soil and
groundwater; extensive soil erosion from poor farming
methods
Environment - International agreements:
party fo; Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: landlocked
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: focal point for Southeast Asian
sea routes','bf0c192cf8e7b44d245f65e2c5b5ac97aff3f743307d11db93dfd7f11d14a3a6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78bfe9c9c2cba8c26f55a94fdf771bafc8b2d48338e8619276468b67d00c9bc3',2001,'BG','Bulgaria','geography',206,'Location: Southeastern Europe, bordering the Black
Sea, between Romania and Turkey
Geographic coordinates: 43 00 N, 25 00 E
Map references: Europe
Area:
tofa/;110,910sq km
/and; 11 0,550 sq km
water: 360 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,808 km
border countries: Greece 494 km, The Former
Yugoslav Republic of Macedonia 148 km, Romania
608 km, Yugoslavia 318 km, Turkey 240 km
Coastline: 354 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: temperate; cold, damp winters; hot, dry
summers
Terrain: mostly mountains with lowlands in north and
southeast
75
Bulgaria (continued)
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources; bauxite, copper, lead, zinc, coal,
timber, arable land
Land use:
arable land: 43%
permanent crops: 2%
permanent pastures: 14%
forests and woodland: 38%
other: 3% (m9 est.)
Irrigated land: 12,370 sq km (1993 est.)
Natural hazards: earthquakes, landslides
Environment - current issues: air pollution from
industrial emissions; rivers polluted from raw sewage,
heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical
plants and industrial wastes
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol
Geography - note: strategic location near Turkish
Straits; controls key land routes from Europe to Middle
East and Asia','8d4e9b9ae66c402a852c24b0bd13466121b16fae911ec44e7625b541550430a1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b1208882ce175b8bcf300a2a43d1bec6b80ba500e58bdebec51b65e123dcc16',2001,'BF','Burkina Faso','geography',212,'Location: Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area - comparative: slightly larger than Colorado
Land boundaries:
tofa/.* 3,192 km
border countries: Benin 306 km, Cote d''Ivoire 584 km,
Ghana 548 km, Mali 1 ,000 km, Niger 628 km, Togo
126 km
Coastline; 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; warm, dry winters; hot, wet
summers
Terrain: mostly flat to dissected, undulating plains;
hills in west and southeast
Elevation extremes:
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Jena Kourou 749 m
Natural resources: manganese, limestone, marble;
small deposits of gold, antimony, copper, nickel,
bauxite, lead, phosphates, zinc, silver
Land use:
arable land: ^3%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 50%
of/)er;15%(1993 est.)
Irrigated land: 200 sq km (1993 est.)
Natural hazards: recurring droughts
Environment - current issues: recent droughts and
desertification severely affecting agricultural activities,
population distribution, and the economy;
overgrazing; soil degradation; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea, Nuclear Test
Ban
Geography ■ note: landlocked','854fc10b02cc8d0eeaaa3dfdddf0dc747ecb656e1cf1e9bacaf48948d5e6c5fd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('175f6f403e6ee28494e843b295de17c3739d384467a2640790a6c0af3b5ceb36',2001,'ET','Ethiopia','geography',221,'Location: Southeastern Asia, bordering the
Andaman Sea and the Bay of Bengal, between
Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,876 km
80
Burma (continued)
border countries: Bangladesh 193 km, China 2,185
km, India 1 ,463 km, Laos 235 km, Thailand 1 ,800 km
Coastline: 1,930 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
terr/Ma/ sea: 12 NM
Climate: tropical monsoon; cloudy, rainy, hot, humid
summers (southwest monsoon, June to September);
iess cloudy, scant rainfall, mild temperatures, lower
humidity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep, rugged
highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Naturai resources: petroleum, timber, tin, antimony,
zinc, copper, tungsten, lead, coal, some marble,
limestone, precious stones, natural gas, hydropower
Land use:
arable land: "{5%
permanent crops: ^%
permanent pastures: 1%
forests and woodland: 49%
of/ier; 34% (1993 est.)
Irrigated land: 10,680 sq km (1993 est.)
Natural hazards: destructive earthquakes and
cyclones; flooding and landslides common during
rainy season (June to September); periodic droughts
Environment - current issues: deforestation;
industrial pollution of air, soil, and water; inadequate
sanitation and water treatment contribute to disease
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropica! Timber 83,
Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location near major
Indian Ocean shipping lanes
Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
tote/; 1,127,127 sq km
/anof; 1,1 19,683 sq km
water 7,444 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries;
total: 5,31 1 km
border countries: Djibouti 337 km, Eritrea 912 km,
Kenya 830 km, Somalia 1,626 km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide
topographic-induced variation
Terrain; high plateau with central mountain range
divided by Great Rift Valley
Elevation extremes:
lowest point: Denakil Depression -125 m
highest point: Ras Dejen 4,620 m
Natural resources: small reserves of gold, platinum,
copper, potash, natural gas, hydropower
Land use:
arabte/anc/; 12%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 25%
otoer; 22% (1993 est.)
Irrigated land: 1 ,900 sq km (1 993 est.)
Natural hazards: geologically active Great Rift
Valley susceptible to earthquakes, volcanic eruptions;
frequent droughts
Environment - current issues: deforestation;
overgrazing; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Environmental Modification,
Law of the Sea, Nuclear Test Ban
Geography - note: landlocked - entire coastline
along the Red Sea was lost with the de jure
independence of Eritrea on 24 May 1993
Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from southern
Madagascar to southern Mozambique
Geographic coordinates: 22 20 S, 40 22 E
Map references: Africa
Area:
total: 28 sq km
/and; 28 sq km
water: 0 sq km
Area - comparative: about 0.16 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 22.2 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical
Terrain: low and flat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 1 00%
other: 0%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current issues: NA
Geography - note: wildlife sanctuary
Location: Northern South America, bordering the
North Atlantic Ocean, between Suriname and
Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area:
fota/.'' 214,970 sq km
/aM- 196,850 sq km
wafer 18,120 sq km
Area - comparative: slightly smaller than Idaho
Land boundaries:
total: 2,462 km
border countries: Brazil 1 ,1 1 9 km, Suriname 600 km,
Venezuela 743 km
Coastline: 459 km
Maritime claims:
continental shelf: 200 NM or to the outer edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; hot, humid, moderated by
northeast trade winds; two rainy seasons (May to
mid-August, mid-November to mid-January)
Terrain: mostly rolling highlands; low coastal plain;
savanna in south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold, diamonds,
hardwood timber, shrimp, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 84%
other: S% (1993 est.)
Irrigated land: 1 ,300 sq km (1 993 est.)
Natural hazards: flash floods are a constant threat
during rainy seasons
Environment - current issues; water pollution from
sewage and agricultural and industrial chemicals;
deforestation
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Location: Middle East, bordering the Persian Gulf
and the Red Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area:
total: 1 ,960,582 sq km
land: 1 ,960,582 sq km
water: 0 sq km
Area - comparative: slightly more than one-fifth the
size of the US
Land boundaries:
tofa/;4,415km
border countries: Iraq 81 4 km, Jordan 728 km, Kuwait
222 km, Oman 676 km, Qatar 60 km, UAE 457 km,
Yemen 1,458 km
Coastline: 2,640 km
Maritime claims:
contiguous zone: 1 8 NM
continental shelf: not specified
territorial sea.* 12 NM
Climate: harsh, dry desert with great extremes of
temperature
Terrain: mostly uninhabited, sandy desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: 3dba\\ Sawda'' 3,133 m
Natural resources: petroleum, natural gas, iron ore,
gold, copper
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1 %
oto;41%(1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment - current issues: desertification;
depletion of underground water resources; the lack of
perennial rivers or permanent water bodies has
prompted the development of extensive seawater
desalination facilities; coastal pollution from oil spills
Environment - International agreements:
party to: Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography ■ note: extensive coastlines on Persian
Gulf and Red Sea provide great leverage on shipping
(especially crude oil) through Persian Gulf and Suez
Canal
Location: Western Africa, bordering the North Atlantic
Ocean, between Guinea-Bissau and Mauritania
Geographic coordinates: 14 00 N, 14 00 W
Map references: Africa
Area:
fofa/; 196, 190 sq km
/and; 192, 000 sq km
wafer; 4,190 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries:
total: 2,640 km
border countries: Jhe Gambia 740 km, Guinea 330
km, Guinea-Bissau 338 km, Mali 419 km, Mauritania
813 km
Coastline: 531 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; hot, humid; rainy season (May to
November) has strong southeast winds; dry season
(December to April) dominated by hot, dry, harmattan
wind
Terrain: generally low, rolling, plains rising to
foothills in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near Nepen Diakha
581 m
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 54%
other: 18% (1993 est.)
Irrigated land: 710 sq km (1993 est.)
Natural hazards: lowlands seasonally flooded;
periodic droughts
Environment - current Issues: wildlife populations
threatened by poaching; deforestation; overgrazing;
soil erosion; desertification; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Marine Dumping
Geography - note: The Gambia is almost an
enclave of Senegal','2ac7f6b76dcea4ce3a937e32824a00693924b1698f8077d99f51019ab7640624','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d94a62258de2fa71d7bd8ec311c60391d3854ab2b85b7c39dccf00b7900e49',2001,'TH','Thailand','geography',230,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water; 2,180 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of the Congo
233 km, Rwanda 290 km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable
altitude variation (772 m to 2,670 m above sea level);
average annual temperature varies with altitude from
23 to 1 7 degrees centigrade but is generally moderate
as the average altitude is about 1 ,700 m; average
annual rainfall is about 150 cm; wet seasons from
February to May and September to November, and
dry seasons from June to August and December to
January
Terrain: hilly and mountainous, dropping to a plateau
in east, some plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,670 m
Natural resources: nickel, uranium, rare earth
oxides, peat, cobalt, copper, platinum (not yet
exploited), vanadium, arable land, hydropower
Land use:
arable land: 44%
permanent crops: 9%
permanent pastures: 36%
forests and woodland: 3%
oteer;8%(1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: flooding, landslides, drought
Environment - current issues: soil erosion as a
result of overgrazing and the expansion of agriculture
into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for
fuel); habitat loss threatens wildlife populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Law of the Sea, Nuclear Test
Ban
Geography - note: landlocked; straddles crest of the
Nile-Congo watershed
Location: Southeastern Asia, bordering the
Andaman Sea and the Gulf of Thailand, southeast of
Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area:
total: 514,000 sq km
land: 511,770 sq km
water: 2,230 sq km
Area - comparative: slightly more than twice the
size of Wyoming
Land boundaries:
total: 4,863 km
border countries: Burma 1 ,800 km, Cambodia 803
km, Laos 1 ,754 km, Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; rainy, warm, cloudy southwest
monsoon (mid-May to September); dry, cool northeast
monsoon (November to mid-March); southern
isthmus always hot and humid
Terrain: central plain; Khorat Plateau in the east;
mountains elsewhere
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gypsum, lignite,
fluorite, arable land
Land use:
arable land: 34%
permanent crops: 6%
permanent pastures: 2%
forests and woodland: 26%
of/ier; 32% (1993 est.)
Irrigated land: 44,000 sq km (1993 est.)
Natural hazards: land subsidence in Bangkok area
resulting from the depletion of the water table;
droughts
Environment - current issues: air pollution from
vehicle emissions; water pollution from organic and
factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
Environment - international agreements:
party to: Climate Change, Endangered Species,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Biodiversity, Climate
Change-Kyoto Protocol, Law of the Sea
Geography - note: controls only land route from
Asia to Malaysia and Singapore
Location: Western Africa, bordering the Bight of
Benin, between Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area;
total: 56,785 sq km
land: 54,385 sq km
water: 2,400 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
to/a/.'' 1,647 km
border coun/r/es; Benin 644 km, Burkina Faso 126
km, Ghana 877 km
Coastline: 56 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 30 NM
Climate; tropical; hot, humid in south; semiarid in
north
Terrain: gently rolling savanna in north; central hills;
southern plateau; low coastal plain with extensive
lagoons and marshes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Agou 986 m
Natural resources: phosphates, limestone, marble,
arable land
Land use:
arable land: 38%
permanent crops: 7%
permanent pastures: 4%
forests and woodland: 17%
other: 34% (1993 est.)
Irrigated land: 70 sq km (1993 est.)
Natural hazards: hot, dry harmattan wind can
reduce visibility in north during winter; periodic
droughts
Environment ■ current issues: deforestation
attributable to slash-and-burn agriculture and the use
of wood for fuel; water pollution presents health
hazards and hinders the fishing industry; air pollution
increasing in urban areas
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Oceania, group of three islands in the
South Pacific Ocean, about one-half of the way from
Hawaii to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area:
total: 10 sq km
land: 10 sq km
water: 0 sq km
Area - comparative: about 17 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; moderated by trade winds (April to
November)
Terrain: low-lying coral atolls enclosing large
lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use:
arable land: 0% (soil is thin and infertile)
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
of/ier; 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies in Pacific typhoon belt
Environment - current issues: very limited natural
resources and overcrowding are contributing to
emigration to New Zealand','5ac43842d3768f2154b7d5cfd86c91a01606ffa6e74f538e956b947c11b9647b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf0e14fa4508f122372f11db16d15eeb4986e3962edfaa3583714efcd0a171d0',2001,'KH','Cambodia','geography',234,'Location: Southeastern Asia, bordering the Gulf of
Thailand, between Thailand, Vietnam, and Laos
Geographic coordinates: 13 00 N, 105 00 E
Map references: Southeast Asia
Area:
tete/;181,040 sq km
land: 176,520 sq km
water: 4,520 sq km
Area - comparative: slightly smaller than Oklahoma
Land boundaries:
total: 2,572 km
border countries: Laos 541 km, Thailand 803 km,
Vietnam 1,228 km
Coastline: 443 km
Maritime claims;
contiguous zone: 24 NM
continental shelf: 200 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; rainy, monsoon season (May to
November); dry season (December to April); little
seasonal temperature variation
Terrain: mostly low, flat plains; mountains in
southwest and north
85
Cambodia (continued)
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1 ,810 m
Natural resources: timber, gemstones, some iron
ore, manganese, phosphates, hydropower potential
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 1 1 %
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 920 sq km (1993 est.)
Natural hazards: monsoonal rains (June to
November); flooding: occasional droughts
Environment - current issues: illegal logging
activities throughout the country and strip mining for
gems in the western region along the border with
Thailand have resulted in habitat loss and declining
biodiversity (in particular, destruction of mangrove
swamps threatens natural fisheries); soil erosion; in
rural areas, a majority of the population does not have
access to potable water; toxic waste delivery from
Taiwan sparked unrest in Kampong Saom
(Sihanoukville) in December 1998
Environment - International agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Marine Life Conservation, Ship Pollution,
Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping
Geography - note: a land of paddies and forests
dominated by the Mekong River and Tonle Sap','02f708b2d0fd890772b987fff4988ed61f17317c0dd7ada6a74dc3df120ab61b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bda5b015870a1e3532195e13f06c66774b7d0953d0df27f343c7efe956f82bc',2001,'CM','Cameroon','geography',242,'Location: Western Africa, bordering the Bight of
Biafra, between Equatorial Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area:
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
Area ■ comparative: slightly larger than California
Land boundaries:
tofa/; 4,591 km
border countries: Central African Republic 797 km,
Chad 1 ,094 km, Republic of the Congo 523 km,
Equatorial Guinea 189 km, Gabon 298 km, Nigeria
1,690 km
Coastiine: 402 km
Maritime ciaims:
territorial sea: 50 NM
Climate: varies with terrain, from tropical along coast
to semiarid and hot in north
Terrain: diverse, with coastal plain in southwest,
dissected plateau in center, mountains in west, plains
in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m
Natural resources: petroleum, bauxite, iron ore,
timber, hydropower
Land use:
arable land: ''{3%
permanent crops: 2%
permanent pastures: 4%
forests and woodland: 78%
other: 3% (1993 est.)
Irrigated land: 210 sq km (1993 est.)
Natural hazards: recent volcanic activity with
release of poisonous gases
Environment - current issues: water-borne
diseases are prevalent; deforestation; overgrazing;
desertification; poaching; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Nuclear Test Ban
Geography - note: sometimes referred to as the
hinge of Africa','104a6e528625f8272d7d8f4ecda88f42ca21edc0dd5a3f7c6aa25973fc91a77a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5c72d5d4f62789c805c6be7f17ddac5b9247761ac52e28403f29fd082c89571',2001,'CA','Canada','geography',251,'Location: Northern North America, bordering the
North Atlantic Ocean and North Pacific Ocean, north
of the conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area:
tofa/.'' 9,976, 140 sq km
land: 9,220,970 sq km
water.'' 755,170 sq km
Area - comparative: slightly larger than the US
Land boundaries;
total: 8,893 km
border countries: US 8,893 km (includes 2,477 km
with Alaska)
Coastline: 243,791 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: varies from temperate in south to subarctic
and arctic in north
Terrain: mostly plains with mountains in west and
lowlands in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
gold, lead, molybdenum, potash, silver, fish, timber,
wildlife, coal, petroleum, natural gas, hydropower
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
oteer.''38%(1993 est.)
Irrigated land: 7,100 sq km (1993 est.)
Natural hazards: continuous permafrost in north is a
serious obstacle to development; cyclonic storms
form east of the Rocky Mountains, a result of the
mixing of air masses from the Arctic, Pacific, and
North American interior, and produce most of the
country''s rain and snow
Environment - current issues: air pollution and
resulting acid rain severely affecting lakes and
damaging forests; metal smelting, coal-burning
utilities, and vehicle emissions impacting on
agricultural and forest productivity; ocean waters
becoming contaminated due to agricultural, industrial,
mining, and forestry activities
Environment ■ international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Mr Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol, Law of the Sea,
Marine Life Conservation
Geography - note: second-largest country in world
(after Russia); strategic location between Russia and
90
Canada (continued)
US via north polar route; approximately 85% of the
population is concentrated within 300 km of the US/
Canada border
Location: Western Africa, group of islands in the
North Atlantic Ocean, west of Senegal
Geographic coordinates: 16 00 N, 24 00 W
Map references: World
Area:
total: 4,033 sq km
land: A, 033 sq km
water: 0 sq km
Area - comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: )2 NM
Climate: temperate; warm, dry summer; precipitation
meager and very erratic
Terrain: steep, rugged, rocky, volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano on Fogo
Island)
Natural resources: salt, basalt rock, pozzuolana (a
siliceous volcanic ash used to produce hydraulic
cement), limestone, kaolin, fish
Land use:
arable land: ^^%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 0%
other: 83% (m3 est.)
Irrigated land: 1 ,500 to 2,000 hectares (1999)
Natural hazards: prolonged droughts; harmattan
wind can obscure visibility; volcanically and
seismically active
Environment - current issues: overgrazing of
livestock and improper land use such as the
cultivation of crops on steep slopes has led to soil
erosion; demand for wood used as fuel has resulted in
deforestation; desertification; environmental damage
has threatened several species of birds and reptiles;
overfishing
Environment - International agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location 500 km from
west coast of Africa near major north-south sea
routes; important communications station; important
sea and air refueling site','188085643a5a46264a8286c55f1d4eff5930eec0de6bd6f468063aa27af78037','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7604bd335b579d3ff84ede78a40a33649ec4c836bf6d78cd895015ae47f89568',2001,'KY','Cayman Islands','geography',267,'Location: Caribbean, island group in Caribbean
Sea, nearly one-half of the way from Cuba to','fc114d802a849a7294887b6edc1f1c5585b1ebfba7a48cc3646af94203925924','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19fb875c4c4861433c1c686aeeaaeaca2d76b4a40067c075c964433a32e7945d',2001,'HN','Honduras','geography',268,'Geographic coordinates: 19 30 N, 80 30 W
Map references: Central America and the Caribbean
Area:
total: 259 sq km
land: 259 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: ^2 NM
Climate: tropical marine; warm, rainy summers (May
to October) and cool, relatively dry winters (November
to April)
Terrain: low-lying limestone base surrounded by
coral reefs
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: The Bluff 43 m
Natural resources: fish, climate and beaches that
foster tourism
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 23%
other: 69% est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes (July to November)
Environment - current issues: no natural fresh
water resources; drinking water supplies must be met
by rainwater catchment
Geography ■ note: important location between
Cuba and Central America
Location: Central Africa, north of Democratic
Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area;
total: 622,984 sq km
land: 622,984 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km, Chad 1 ,197 km,
Democratic Republic of the Congo 1 ,577 km.
Republic of the Congo 467 km, Sudan 1 , 1 65 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet
summers
Terrain: vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mont Ngaoui 1 ,420 m
Natural resources: diamonds, uranium, timber,
gold, oil, hydropower
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 75%
other: 17% (1993 est.)
Irrigated land: NAsqkm
96
Central African Republic (continued)
Natural hazards: hot, dry, dusty harmattan winds
affect northern areas; floods are common
Environment - current issues: tap water is not
potable; poaching has diminished its reputation as
one of the last great wildlife refuges; desertification;
deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94
signed, but not ratified: Law of the Sea
Geography - note: landlocked; almost the precise
center of Africa
Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Nicaragua and
bordering the North Pacific Ocean, between El
Salvador and Nicaragua
Geographic coordinates: 15 00 N, 86 30 W
Map references: Central America and the
Caribbean
Area:
total: M2, 090 sq km
land: 1 1 1 ,890 sq km
water: 200 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 520 km
border countries: Guatemala 256 km, El Salvador 342
km, Nicaragua 922 km
Coastline: 820 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: natural extension of territory or to
200 NM
exclusive economic zone: 200 NM
territorial sea; 12 NM
Climate: subtropical in lowlands, temperate in
mountains
Terrain: mostly mountains in interior, narrow coastal
plains
222
Honduras (continued)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver, copper,
lead, zinc, iron ore, antimony, coal, fish, hydropower
Land use:
arable land: ^5%
permanent crops: 3%
permanent pastures: 14%
forests and woodland: 54%
of/?er; 14% (1993 est.)
Irrigated land: 740 sq km (1993 est.)
Natural hazards: frequent, but generally mild,
earthquakes; damaging hurricanes and floods along
Caribbean coast
Environment - current issues: urban population
expanding; deforestation results from logging and the
clearing of land for agricultural purposes; further land
degradation and soil erosion hastened by uncontrolled
development and improper land use practices such as
farming of marginal lands; mining activities polluting
Lago de Yojoa (the country''s largest source of fresh
water) as well as several rivers and streams with
heavy metals; severe Hurricane Mitch damage
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: none of the selected
agreements','dbe84cc5d452f35c4dd1e2124422c941b75b948d389f6893d4928d1eea779e31','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00a44f10309d311999b08d92289613e156408589668fcf733c00ac7f40bb2c5',2001,'TD','Chad','geography',278,'Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
fofa/; 1.284 million sq km
/and; 1,259,200 sq km
water; 24,800 sq km
Area - comparative: slightly more than three times
the size of California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1 ,094 km. Central
African Republic 1,197 km, Libya 1,055 km, Niger
1,175 km, Nigeria 87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north,
mountains in northwest, lowlands in south
Elevation extremes:
lowest point: Djourab Depression 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but
exploration underway), uranium, natron, kaolin, fish
(Lake Chad)
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 36%
forests and woodland: 26%
other: 35% {^993 est.)
Irrigated land: 1 40 sq km (1 993 est.)
Natural hazards: hot, dry, dusty harmattan winds
occur in north; periodic droughts; locust plagues
Environment - current Issues: inadequate
supplies of potable water; improper waste disposal in
rural areas contributes to soil and water pollution;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping
Geography ■ note: landlocked; Lake Chad is the
most significant water body in the Sahel
Location: Southern South America, bordering the
South Atlantic Ocean and South Pacific Ocean,
between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area;
tofa/: 756,950 sq km
land: 748,800 sq km
wafer; 8,150 sq km
note: includes Easter Island (Isla de Pascua) and Isla
Sala y Gomez
Area - comparative: slightly smaller than twice the
size of Montana
Land boundaries:
total: 0, Ml km
border counfr/es; Argentina 5,150 km, Bolivia 861 km,
Peru 160 km
Coastline: 6,435 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 2001350 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: temperate; desert in north; Mediterranean
in central region; coo! and damp in south
Terrain: low coastal mountains; fertile central valley;
rugged Andes in east
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Ojos del Saiado 6,880 m
Natural resources: copper, timber, iron ore,
nitrates, precious metals, molybdenum, hydropower
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 18%
forests and woodland: 22%
ote55%(1993 est.)
Irrigated land: 12,650 sq km (1993 est.)
Natural hazards: severe earthquakes; active
volcanism; tsunamis
Environment - current issues: air pollution from
industrial and vehicle emissions; water pollution from
raw sewage
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Geography - note: strategic location relative to sea
lanes between Atlantic and Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Passage);
Atacama Desert is one of world''s driest regions','05e3766f49f028aeb700eb41dce228b35a3c5101953dde99c8f47f6c9715d173','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db7c29cf8c07c7c5a3935f58de551bdde801035a0995a9efcba5beac76bd81c2',2001,'CN','China','geography',288,'Location: Eastern Asia, bordering the East China
Sea, Korea Bay, Yellow Sea, and South China Sea,
between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area:
total: 9,596,960 sq km
/and.'' 9,326,410 sq km
wafer; 270,550 sq km
Area - comparative: slightly smaller than the US
Land boundaries:
fofa/; 22,147.24 km
border countries: Afghanistan 76 km, Bhutan 470 km,
Burma 2,185 km, Hong Kong 30 km, India 3,380 km,
Kazakhstan 1,533 km, North Korea 1,416 km,
Kyrgyzstan 858 km, Laos 423 km, Macau 0.34 km,
Mongolia 4,676.9 km, Nepal 1,236 km, Pakistan 523
km, Russia (northeast) 3,605 km, Russia (northwest)
40 km, Tajikistan 414 km, Vietnamj 1,281 km
Coastline: 14,500 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
territorial sea: ^2 NM
Climate: extremely diverse; tropical in south to
subarctic in north
Terrain: mostly mountains, high plateaus, deserts in
west; plains, deltas, and hills in east
Elevation extremes:
lowest point: lurpan Pendi -154 m
highest point: Mount Everest 8,850 m (1999 est.)
Natural resources: coal, iron ore, petroleum, natural
gas, mercury, tin, tungsten, antimony, manganese,
molybdenum, vanadium, magnetite, aluminum, lead,
zinc, uranium, hydropower potential (world''s largest)
Land use:
arable land: W/o
permanent crops: 0%
permanent pastures: 43%
forests and woodland: 14%
other: 33% (m3 est.)
Irrigated land: 498,720 sq km (1993 est.)
Natural hazards: frequent typhoons (about five per
year along southern and eastern coasts); damaging
floods; tsunamis; earthquakes; droughts
Environment - current issues: air pollution
(greenhouse gases, sulfur dioxide particulates) from
reliance on coal, produces acid rain; water shortages,
particularly in the north; water pollution from untreated
wastes; deforestation; estimated loss of one-fifth of
agricultural land since 1949 to soil erosion and
economic development; desertification; trade in
endangered species
Environment - International agreements:
party fo; Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: world''s fourth-largest country
(after Russia, Canada, and US)
Location: Oceania, island in the North Pacific
Ocean, about one-half of the way from Hawaii to
Location: Southeastern Asia, group of reefs and
Islands in the South China Sea, about two-thirds of the
way from southern Vietnam to the southern','312812e06b6207b3f96401248d963438d5d479f3ab8dbf672562c7906228f76b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6feaffed072a3eda3bdc02e9323218ebe14ecfd75407875385ea644508a3059c',2001,'CX','Christmas Island','geography',296,'Location: Southeastern Asia, island in the Indian
Ocean, south of Indonesia
Geographic coordinates: 10 30 S, 105 40 E
Map references: Southeast Asia
Area:
total: ^35 sq km
/and; 135 sq km
water: 0 sq km
Area ■ comparative: about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastilne: 138.9 km
Maritime claims:
contiguous zone: 12 NM
exclusive fishing zone: 200 NM
territorial sea: 3
Climate: tropical; heat and humidity moderated by
trade winds
Terrain: steep cliffs along coast rise abruptly to
central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
note: mainly tropical rainforest of which 60%-70% is in
a national park
Irrigated land: NAsqkm
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: NA
Geography - note: located along major sea lanes of
Indian Ocean','6d30e77b71f2fca0a178efb8463acf37660ff6e16145c771c57478edcaa55198','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b72ae37394bc7f862e46884f7d16d6cadfeb7dcf774bbadaabe7b2576ba26aea',2001,'CO','Colombia','geography',303,'Location: Northern South America, bordering the
Caribbean Sea, between Panama and Venezuela,
and bordering the North Pacific Ocean, between
Ecuador and Panama
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America, Central America
and the Caribbean
Area:
tofa/.'' 1,138,910 sq km
land: 1 ,038,700 sq km
wafer; 100,210 sq km
note: includes Isla de Maipelo, Roncador Cay,
Serrana Bank, and Serranilla Bank
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 6,004 km
border counfr/es; Brazil 1,643 km, Ecuador 590 km,
Panama 225 km, Peru 1,496 km (est.), Venezuela
2,050 km
Coastline: 3,208 km (Caribbean Sea 1,760 km,
North Pacific Ocean 1 ,448 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical along coast and eastern plains;
cooler in highlands
Terrain: flat coastal lowlands, central highlands, high
Andes Mountains, eastern lowland plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pico Cristobal Colon 5,775 m
note: nearby Pico Simon Bolivar also has the same
elevation
Natural resources: petroleum, natural gas, coal,
iron ore, nickel, gold, copper, emeralds, hydropower
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 39%
forests and woodland: 48%
other: 8% (1993 est.)
Irrigated land: 5,300 sq km (1993 est.)
Natural hazards: highlands subject to volcanic
eruptions; occasional earthquakes; periodic droughts
Environment - current issues: deforestation; soil
damage from overuse of pesticides; air pollution,
especially in Bogota, from vehicle emissions
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Law of the Sea, Marine Dumping
Geography - note: only South American country
with coastlines on both North Pacific Ocean and
Caribbean Sea
Location: Southern Africa, group of islands in the
Mozambique Channel, about two-thirds of the way
between northern Madagascar and northern','59f348c72386ead956b85a881d9be9f48cb401f4cb5dd1f9b1a5e55415f10aaf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3217410d0bc2b1b8dfac16783090c936c03b7b50030884e0d96388a09b514b97',2001,'MZ','Mozambique','geography',311,'Geographic coordinates: 12 10 S, 44 15 E
Map references: Africa
Area:
total: 2, MO sq km
land: 2, MO sq km
water: 0 sq km
Area ■ comparative: slightly more than 1 2 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; rainy season (November to
May)
Terrain: volcanic islands, interiors vary from steep
mountains to low hills
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Le Kartala 2,360 m
Natural resources: NEGL
Land use:
arable land: 35%
permanent crops: 1 0%
permanent pastures: 7%
forests and woodland: 1 8%
other; 30% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones possible during rainy
season (December to April); Le Kartala on Grand
Comoro is an active volcano
Environment - current issues: soil degradation
and erosion results from crop cultivation on slopes
without proper terracing; deforestation
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: important location at northern
end of Mozambique Channel
Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area:
fofa/; 2,345,41 Osq km
/ancf; 2,267,600 sq km
water; 77,81 Osq km
Area - comparative: slightly less than one-fourth the
size of the US
Land boundaries:
tote/; 10,744 km
border countries: Angola 2,51 1 km, Burundi 233 km.
Central African Republic 1,577 km, Republic of the
Congo 2,410 km, Rwanda 217 km, Sudan 628 km,
Tanzania 473 km, Uganda 765 km, Zambia 1 ,930 km
Coastline: 37 km
Maritime claims:
exclusive economic zone: boundaries with neighbors
terr/tor/a/ sea; 12 NM
Climate: tropical; hot and humid in equatorial river
basin; cooler and drier in southern highlands; cooler
and wetter in eastern highlands; north of Equator - wet
season April to October, dry season December to
February; south of Equator - wet season November to
March, dry season April to October
Terrain: vast central basin is a low-lying plateau;
mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Marguerite on Mont Ngaliema
(Mount Stanley) 5,110 m
Natural resources: cobalt, copper, cadmium,
petroleum, industrial and gem diamonds, gold, silver,
zinc, manganese, tin, germanium, uranium, radium,
bauxite, iron ore, coal, hydropower, timber
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 11%
other: 13% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: periodic droughts in south;
volcanic activity
Environment - current issues: poaching threatens
wildlife populations; water pollution; deforestation;
refugees who arrived in mid-1994 were responsible
for significant deforestation, soil erosion, and wildlife
poaching in the eastern part of the country (most of
those refugees were repatriated in November and
December 1996)
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: straddles Equator; very narrow
strip of land that controls the lower Congo river and is
only outlet to South Atlantic Ocean; dense tropical rain
forest in central river basin and eastern highlands
Location: Southern Africa, bordering the
Mozambique Channel, between South Africa and
Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area:
total: 801 ,590 sq km
land: 784,090 sq km
wafer; 17,500 sq km
Area ■ comparative: slightly less than twice the size
of California
Land boundaries;
fofa/; 4,571 km
border countries: Malawi 1,569 km, South Africa 491
km, Swaziland 1 05 km, Tanzania 756 km, Zambia 41 9
km, Zimbabwe 1 ,231 km
Coastline: 2,470 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: “12 NM
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands in center,
high plateaus in northwest, mountains in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas,
hydropower, tantalum, graphite
Land use;
arable land: 4%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1 8%
ofher; 22% (1993 est.)
Irrigated land: 1 ,200 sq km (2000 est.)
Natural hazards; severe droughts and floods occur
in central and southern provinces; devastating
cyclones
Environment - current issues: a long civil war and
recurrent drought in the hinterlands have resulted in
increased migration of the population to urban and
coastal areas with adverse environmental
consequences; desertification; pollution of surface
and coastal waters
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Location: Eastern Asia, islands bordering the East
China Sea, Philippine Sea, South China Sea, and
Taiwan Strait, north of the Philippines, off the
southeastern coast of China
Geographic coordinates: 23 30 N, 121 00 E
Map references: Southeast Asia
Area:
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
Area ■ comparative: slightly smaller than Maryland
and Delaware combined
Land boundaries: 0 km
Coastline: 1,566.3 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; marine; rainy season during
southwest monsoon (June to August); cloudiness is
persistent and extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Yu Shan 3,997 m
Natural resources: small deposits of coal, natural
gas, limestone, marble, and asbestos
Land use;
arable land: 24%
permanent crops: 1%
permanent pastures: 5%
forests and woodland: 55%
other: 15%
Irrigated land: NAsqkm
Natural hazards: earthquakes and typhoons
Environment - current issues: air pollution; water
pollution from industrial emissions, raw sewage;
contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste
disposal
Environment - International agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements','07c7213d464fdba63230b6244c71abaaef2384ad27ae3b9966cdf3609d79ce4a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3ecd503df8e3b199b9b7ff48962524d6fe3cfa2bfc65277f042b92e9bf39ebe',2001,'CG','Congo','geography',326,'Location; Western Africa, bordering the South
Atlantic Ocean, between Angola and Gabon
Geographic coordinates: 1 00 S, 15 00 E
Map references: Africa
Area;
total: 342,000 sq km
/and: 341 ,500 sq km
water: 500 sq km
Area - comparative; slightly smaller than Montana
Land boundaries:
total: 5,504 km
border countries: Angola 201 km, Cameroon 523 km.
Central African Republic 467 km, Democratic
Republic of the Congo 2,410 km, Gabon 1 ,903 km
Coastline: 169 km
Maritime claims;
territorial sea: 200 NM
Climate: tropical; rainy season (March to June); dry
season (June to October); constantly high
temperatures and humidity; particularly enervating
climate astride the Equator
Terrain: coastal plain, southern basin, central
plateau, northern basin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber, potash, lead,
zinc, uranium, copper, phosphates, natural gas,
hydropower
117
Congo, Republic of the (continued)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 29%
forests and woodland: 62%
other: 9% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: seasonal flooding
Environment - current Issues: air pollution from
vehicle emissions; water pollution from the dumping of
raw sewage; tap water is not potable; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: about 70% of the population
lives in Brazzaville, Pointe-Noire, or along the railroad
between them','61ffceacb73956ae1c8e04aeb0d8cb0c13ed9fb103727921eff90a2d64ec11f8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8d4710a0569d71d05c025fa50c75b868bdf27efba3085de8f58f1fe40afa69b',2001,'CK','Cook Islands','geography',330,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania
Area:
total: 240 sq km
land: 240 sq km
water: 0 sq km
Area - comparative: 1 .3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in north; volcanic, hilly
islands in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Je Manga 652 m
Natural resources: NEGL
Land use:
arable land: 9%
permanent crops: 1 3%
permanent pastures: 0%
forests and woodland: 0%
other: 7Q% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons (November to March)
Environment - current issues: NA
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea
signed, but not ratified: Climate Change-Kyoto
Protocol
Location: Oceania, islands in the Coral Sea,
northeast of Australia
Geographic coordinates: 18 00 S, 152 00 E
Map references: Oceania
Area:
total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and reefs
scattered over a sea area of about 1 million sq km,
with the Willis Islets the most important
Area - comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 3 UU
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly grass or scrub cover)
Irrigated land: 0sqkm(1993)
121
Coral Sea Islands (continued)
Natural hazards: occasional tropical cyclones
Environment - current issues: no permanent fresh
water resources
Geography - note: important nesting area for birds
and turtles
Geographic coordinates: 0 22 S, 160 03 W
Map references: Oceania
Area:
total: 4.5 sq km
land: 4.5 sq km
water: 0 sq km
Area ■ comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; scant rainfall, constant wind,
burning sun
Terrain: sandy, coral island surrounded by a narrow
fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 7 m
Natural resources: guano (deposits worked until
late 1800s), terrestrial and aquatic wildlife
258
Jarvis Island (continued)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: no natural fresh
water resources
Geography - note: sparse bunch grass, prostrate
vines, and low-growing shrubs; primarily a nesting,
roosting, and foraging habitat for seabirds, shorebirds,
and marine wildlife
Location: Western Europe, island in the English
Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area;
tofa/;116sq km
land:^^Qs(\\ km
water: 0 sq km
Area - comparative: about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims;
exclusive fishing zone: 1 2 NM
territorial sea: 3 HU
Climate: temperate; mild winters and cool summers
Terrain: gently rolling plain with low, rugged hills
along north coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: arable land
Land use:
arable land: 66%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 34%
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current Issues: NA
Geography - note: largest and southernmost of
Channel Islands; about 30% of population
concentrated in Saint Helier
Location: Oceania, atoll in the North Pacific Ocean
717 NM (1328 km) southwest of Honolulu, Hawaii,
about one-third of the way from Hawaii to the Marshal!
Islands
Geographic coordinates: 16 45 N, 169 31 W
Map references: Oceania
Area:
total: 2.8 sq km
land: 2.8 sq km
water: 0 sq km
Area - comparative: about 4.7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 10 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea:
Climate: tropical, but generally dry; consistent
northeast trade winds with little seasonal temperature
variation
Terrain: mostly flat
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Summit Peak 5 m
Natural resources: guano deposits worked until
depletion about 1890, terrestrial and aquatic wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
of^er; 100%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment - current issues: no natural fresh
water resources
Geography ■ note: strategic location in the North
Pacific Ocean; Johnston Island and Sand Island are
natural islands, which have been expanded by coral
dredging; North Island (Akau) and East Island (Hikina)
are manmade islands formed from coral dredging;
egg-shaped reef is 34 km in circumference; closed to
the public; former US nuclear weapons test site; site
of Johnston Atoll Chemical Agent Disposal System
(JACADS); some low-growing vegetation','9479387b58538d541d441c8e8a1be27aca6b8121bdc8bfb19d3484595403cd17','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41228ae86950a13f061e93700c1133d6835f6d7132d31c327d092661ebf5a830',2001,'CR','Costa Rica','geography',338,'Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Nicaragua and Panama
Geographic coordinates: 10 00 N, 84 00 W
Map references: Central America and the
Caribbean
Area:
total: sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea:
Climate: tropical and subtropical; dry season
(Decemberto April); rainy season (May to November);
cooler in highlands
Terrain: coastal plains separated by rugged
mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 46%
forests and woodland: 31 %
of/?er; 12% (1993 est.)
Irrigated land: 1,200 sq km (1993 est.)
Natural hazards: occasional earthquakes,
hurricanes along Atlantic coast; frequent flooding of
lowlands at onset of rainy season and landslides;
active volcanoes
Environment - current issues: deforestation and
land use change, largely a result of the clearing of land
for cattle ranching and agriculture; soil erosion; water
pollution (rivers); coastal marine pollution; wetlands
degradation; fisheries protection; solid waste
management; air pollution
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation','4bc6781285c880d750b9fabef111070a66cf8aee0c9d49b42631bdba1cfa439b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a1afc16cd0040a9a08699adbd45da727f837ff941d4aa42336ebde8077c718f',2001,'NI','Nicaragua','geography',347,'Location: Western Africa, bordering the North
Atlantic Ocean, between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
Area:
total: 322,460 sq km
/ancf; 31 8,000 sq km
water: 4,460 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 3,110 km
border countries: Burkina Faso 584 km, Ghana 668
km, Guinea 610 km, Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime ciaims:
continental shelf: 200 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical along coast, semiarid in far north;
three seasons - warm and dry (November to March),
hot and dry (March to May), hot and wet (June to
October)
Cote d''Ivoire (continued)
Terrain: mostly flat to undulating plains; mountains in
northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: petroleum, natural gas,
diamonds, manganese, iron ore, cobalt, bauxite,
copper, hydropower
Land use:
arable land: 8%
permanent crops: 4%
permanent pastures: 41 %
forests and woodland: 22%
other: 25% (m3 est.)
Irrigated land: 680 sq km (1 993 est.)
Natural hazards: coast has heavy surf and no
natural harbors; during the rainy season torrential
flooding is possible
Environment - current issues: deforestation (most
of the country''s forests - once the largest in West
Africa - have been heavily logged); water pollution
from sewage and industrial and agricultural effluents
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Costa Rica and Honduras
Geographic coordinates: 13 00 N, 85 00 W
Map references: Central America and the
Caribbean
Area:
tofa/.'' 129,494 sq km
/and.'' 120,254 sq km
water: 9,240 sq km
Area - comparative: slightly smaller than the state
of New York
Land boundaries:
total: 1 ,231 km
border countries: Costa Rica 309 km, Honduras 922
km
Coastline: 910 km
Maritime claims:
continental shelf : natural prolongation
territorial sea: 200 NM
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to
central interior mountains; narrow Pacific coastal plain
interrupted by volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten,
lead, zinc, timber, fish
Land use;
arable land: 9%
permanent crops:
permanent pastures: 46%
forests and woodland: 27%
of/?er; 17% (1993 est.)
Irrigated land: 880 sq km (1993 est.)
Natural hazards: destructive earthquakes,
volcanoes, landslides, and occasionally severe
hurricanes
Environment - current issues: deforestation; soil
erosion; water pollution; Hurricane Mitch damage
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification','09f85784a8ea6f81b28226882f4173ddac455d968d7a8a1b537a6ed1471ec2cb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d64df82a79ca3509c872b02b3c36ba61d581fe0fffb85f5db14c4b6c832dc1fc',2001,'HR','Croatia','geography',351,'Location: Southeastern Europe, bordering the
Adriatic Sea, between Bosnia and Flerzegovina and
Geographic coordinates: 46 00 N, 15 00 E
Map references: Europe
Area:
total: 20,253 sq km
land: 20,253 sq km
water: Osq km
Area - comparative: slightly smaller than New','b6672b71eacaf1a0f7de2c19aa0b2e90c51606bab629a04a8e04f92f499c85a8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1141f65637a2d66b1aa2fcd32d879a1fbff5413559dca5a4b0206e453b86aec',2001,'SI','Slovenia','geography',352,'Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area:
total: 56,542 sq km
/and.'' 56,414 sq km
water: 128 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 2,028 km
border countries: Bosnia and Flerzegovina 932 km,
Flungary 329 km, Yugoslavia 266 km, Slovenia 501
km
Coastline; 5,835 km (mainland 1,777 km, islands
4,058 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: ^2 NM
Climate: Mediterranean and continental; continental
climate predominant with hot summers and cold
winters; mild winters, dry summers along coast
Location: Southeastern Europe, eastern Alps
bordering the Adriatic Sea, between Austria and','07dbcfe40bf2f8c42a3c0553603eb5597aae6d8fdae90cd66c26243446d3f510','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('154658b739e11ea328e0ee8f90b89edabd70e7d45284a9347c36aee2c4567457',2001,'CU','Cuba','geography',361,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, south of Florida
Geographic coordinates: 21 30 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
tofa/; 11 0,860 sq km
/and.- 110,860 sq km
water: 0 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 29 km
border countries: US Naval Base at Guantanamo Bay
29 km
note: Guantanamo Naval Base is leased by the US
and thus remains part of Cuba
Coastline: 3,735 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; moderated by trade winds; dry
season (November to April); rainy season (May to
October)
Terrain: mostly flat to rolling plains, with rugged hills
and mountains in the southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron ore, copper,
manganese, salt, timber, silica, petroleum, arable land
Land use:
arable land: 24%
permanent crops: 7%
permanent pastures: 27%
forests and woodland: 24%
other: 18% (1993 est.)
Irrigated land: 9,100 sq km (1993 est.)
Natural hazards: the east coast is subject to
hurricanes from August to October (in general, the
country averages about one hurricane every other
year); droughts are common
Environment - current issues: pollution of Havana
Bay; overhunting threatens wildlife populations;
deforestation
Environment ■ international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol, Marine Life
Conservation
Geography - note: largest country in Caribbean
Location: Caribbean, western one-third of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, west of the Dominican Republic
Geographic coordinates: 19 00 N, 72 25 W
Map references: Central America and the
Caribbean
Area:
total: 27,750 sq km
land: 27,560 sq km
Waterloo sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 275 km
border countries: Dominican Republic 275 km
Coastline: 1,771 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: to depth of exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; semiarid where mountains in east
cut off trade winds
Terrain: mostly rough and mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: bauxite, copper, calcium
carbonate, gold, marble, hydropower
Land use:
arable land: 20%
permanent crops: 13%
permanent pastures: 18%
forests and woodland: 5%
oteer 44% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding and earthquakes;
periodic droughts
Environment • current issues: extensive
deforestation (much of the remaining forested land is
being cleared for agriculture and used as fuel); soil
erosion; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Hazardous Wastes, Nuclear
Test Ban
Geography - note: shares island of Hispaniola with
Dominican Republic (western one-third is Haiti,
eastern two-thirds is the Dominican Republic)
Location: Southern Africa, islands in the Indian
Ocean, about two-thirds of the way from Madagascar
to Antarctica
Geographic coordinates: 53 06 S, 72 31 E
Map references: Antarctic Region
Area;
tefa/;412sq km
tend; 41 2 sq km
water: 0 sq km
Area ■ comparative: slightly more than two times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9km
Maritime claims;
exclusive fishing zone: 200 NM
territorial sea: 3 HM
Climate: antarctic
Terrain: Heard Island - bleak and mountainous, with
a quiescent volcano; McDonald Islands - small and
rocky
Elevation extremes:
lowest point: Southern Ocean 0 m
highest point: Big Ben 2,745 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
220','2b832ca284ebef4996b12a17a5681d783b4b84c9cf8a7c588c3362928091d82c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99ee8e79a77191b4e259a1d8a5f9a9b98bcee868b76c584e2252dc09d0f63287',2001,'CY','Cyprus','geography',370,'Location: Middle East, island in the Mediterranean
Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area:
total: 9,250 sq km (of which 3,355 sq km are in the
Turkish Cypriot area)
land: 9,240 sq km
water: 10 sq km
Area - comparative: about 0.6 times the size of
Connecticut
Land boundaries: 0 km
Coastiine: 648 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 NM
Climate: temperate, Mediterranean with hot, dry
summers and cool, winters
Terrain: central plain with mountains to north and
south; scattered but significant plains along southern
coast
Elevation extremes:
lowest point: Mediterranean Sea 0 m
/7/ghesfpo/nf; Olympus 1,951 m
Natural resources: copper, pyrites, asbestos,
gypsum, timber, salt, marble, clay earth pigment
Land use:
arable land: ^2%
permanent crops: 5%
permanent pastures: 0%
forests and woodland: 1 3%
other: 70% (m3 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: moderate earthquake activity;
droughts
Environment - current issues: water resource
problems (no natural reservoir catchments, seasonal
disparity in rainfall, sea water intrusion to island’s
largest aquifer, increased salination in the north);
water pollution from sewage and industrial wastes;
coastal degradation: loss of wildlife habitats from
urbanization
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Location: Central Europe, southeast of Germany
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area:
total: 78,866 sq km
land: 77,276 sq km
wafer 1,590 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: km
border countries: Austria 362 km, Germany 646 km,
Poland 658 km, Slovakia 215 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: Bohemia in the west consists of rolling
plains, hills, and plateaus surrounded by low
mountains; Moravia in the east consists of very hilly
country
Elevation extremes:
lowest point: Elbe River 115m
highest point: Snezka 1 ,602 m
Natural resources: hard coal, soft coal, kaolin, clay,
graphite, timber
Land use:
arable land: 4^%
permanent crops: 2%
permanent pastures: 1 1 %
forests and woodland: 34%
of/?er12%(1993 est.)
Irrigated land: 240 sq km (1993 est.)
Natural hazards: flooding
Environment - current issues: air and water
pollution in areas of northwest Bohemia and in
northern Moravia around Ostrava present health risks;
acid rain damaging forests
Environment - international agreements:
party fo; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked; strategically located
astride some of oldest and most significant land routes
in Europe; Moravian Gate is a traditional military
corridor between the North European Plain and the
Danube in central Europe
Location: Northern Europe, bordering the Baltic Sea
and the North Sea, on a peninsula north of Germany
Geographic coordinates: 56 00 N, 10 00 E
Map references: Europe
Area:
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in the Baltic Sea
and the rest of metropolitan Denmark (the Jutland
Peninsula, and the major islands of Sjaeland and
Fyn), but excludes the Faroe Islands and Greenland
Area ■ comparative: slightly less than twice the size
of Massachusetts
Land boundaries:
total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: temperate; humid and overcast; mild, windy
winters and cool summers
Terrain: low and flat to gently rolling plains
Elevation extremes:
lowest point: Lammefjord -7 m
highest point: Y6\\ng Skovhoej 173 m
Natural resources: petroleum, natural gas, fish,
salt, limestone, stone, gravel and sand
Land use:
arable land: 60%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 10%
of/ier; 25% (1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: flooding is a threat in some areas
of the country (e.g., parts of Jutland, along the
southern coast of the island of Lolland) that are
protected from the sea by a system of dikes
Environment - current issues: air pollution,
principally from vehicle and power plant emissions;
nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from
animal wastes and pesticides
Environment - international agreements:
party to.- Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol, Law of the Sea
Geography - note: controls Danish Straits
(Skagerrak and Kattegat) linking Baltic and North
Seas; about one-quarter of the population lives in
greater Copenhagen','5239efc310c1c21f0aec90927fdd3e624f6e42c420059b2f1415918f98ff2274','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac54adb7aad73e84ea8eb14e3fc4942388185408851b173929cd5d48ba1dfa7',2001,'DJ','Djibouti','geography',379,'Location: Eastern Africa, bordering the Gulf of Aden
and the Red Sea, between Eritrea and Somalia
Geographic coordinates: 1 1 30 N, 43 00 E
Map references: Africa
Area;
total: 22,000 sq km
/and.'' 21,980 sq km
water: 20 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 508 km
border countries: Eritrea 113 km, Ethiopia 337 km,
Somalia 58 km
Coastline: 314 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated by
central mountains
Elevation extremes;
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources: geothermal areas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 0%
of/ie/''.''91%(1993 est.)
Irrigated land: NAsqkm
Natural hazards: earthquakes; droughts; occasional
cyclonic disturbances from the Indian Ocean bring
heavy rains and flash floods
Environment - current issues: inadequate
supplies of potable water; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location near world''s
busiest shipping lanes and close to Arabian oilfields;
terminus of rail traffic into Ethiopia; mostly wasteland
Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, about one-half of
the way from Puerto Rico to Trinidad and Tobago
Geographic coordinates: 15 25 N, 61 20 W
Map references: Central America and the Caribbean
Area:
total: 754 sq km
land: 754 sq km
water: 0 sq km
Area - comparative: slightly more than four times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; moderated by northeast trade
winds: heavy rainfall
Terrain: rugged mountains of volcanic origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Natural resources: timber, hydropower, arable land
Land use:
arable land: 9%
permanent crops: "13%
permanent pastures: 3%
forests and woodland: 67%
other: 8% {^9^3 est.)
Irrigated land: NAsqkm
Natural hazards: flash floods are a constant threat;
destructive hurricanes can be expected during the late
summer months
Environment ■ current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements','86823d112c25bb61b3bd87424f65f6f95d412ea7e633ca627f588f8459ca1004','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5e8bd000e4d2f13b32efbe2a30097087c31bf74f6c1c866b3d06d436e737d79',2001,'DO','Dominican Republic','geography',387,'Location: Caribbean, eastern two-thirds of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, east of Haiti
Geographic coordinates: 19 00 N, 70 40 W
Map references: Central America and the
Caribbean
Area:
total: 48,730 sq km
/anof: 48,380 sq km
water: 350 sq km
Area - comparative: slightly more than twice the
size of New Hampshire
Land boundaries:
total: 275 km
border countries: Haiti 275 km
Coastline: 1,288 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
ferr/tor/a/ sea; 6 NM
Climate: tropical maritime; little seasonal
temperature variation; seasonal variation in rainfall
Terrain; rugged highlands and mountains with fertile
valleys interspersed
Elevation extremes:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources; nickel, bauxite, gold, silver
Land use:
arable land: 2^%
permanent crops: 9%
permanent pastures: 43%
forests and woodland: 12%
other; 15% (1993 est.)
Irrigated land: 2,300 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding; periodic droughts
Environment - current issues: water shortages;
soil eroding into the sea damages coral reefs;
deforestation; Hurricane Georges damage
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Law of the Sea
Geography - note; shares island of Hispaniola with
Haiti (eastern two-thirds is the Dominican Republic,
western one-third is Haiti)
Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the
Caribbean
Area:
total: 9,104 sq km
land: 8,959 sq km
water: 145 sq km
Area - comparative: slightly less than three times
the size of Rhode Island
Land boundaries; 0 km
Coastline: 501 km
Maritime claims;
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine, mild; little seasonal
temperature variation
Terrain: mostly mountains, with coastal plain belt in
north; mountains precipitous to sea on west coast;
sandy beaches along most coastal areas
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1 ,338 m
Natural resources: some copper and nickel;
potential for onshore and offshore oil
Land use:
arable land: 4%
permanent crops: 5%
permanent pastures: 26%
forests and woodland: 1 6%
other: 49% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: periodic droughts; hurricanes
Environment - current issues: erosion; occasional
drought causing water shortages
Geography - note: important location along the
Mona Passage - a key shipping lane to the Panama
Canal; San Juan is one of the biggest and best natural
harbors in the Caribbean; many small rivers and high
central mountains ensure land is well watered; south
coast relatively dry; fertile coastal plain belt in north','2744a06bcf11f621f70556c4a934184c7cdf13cfa5655e822aec70159167a074','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf52cc18eff00c77820d6ca556751ab608c6710bcf9554fab10dee6c77d2ed2f',2001,'EC','Ecuador','geography',395,'Location: Western South America, bordering the
Pacific Ocean at the Equator, between Colombia and','6f81f4caf710e1a80364348cc3688b4555fbaf0835db1d4b6e3deaaf7c758e31','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d70d602ce8c6b6f57b73f0661ea57156b4704f8e47b58e65d4fd42cdd2f6af',2001,'PE','Peru','geography',396,'Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area:
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area - comparative: slightly smaller than Nevada
Land boundaries:
total:2,0^0 km
border countries: Colombia 590 km, Peru 1 ,420 km
Coastline: 2,237 km
Maritime claims:
continental shelf : claims continental shelf between
mainland and Galapagos Islands
territorial sea: 200 NM
Climate: tropical along coast, becoming cooler
inland at higher elevations; tropical in Amazonian
jungle lowlands
Terrain: coastal plain (costa), inter-Andean central
highlands (sierra), and flat to rolling eastern jungle
(oriente)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Natural resources; petroleum, fish, timber,
hydropower
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 1 8%
forests and woodland: 56%
other: 15% (1993 est.)
Irrigated land: 5,560 sq km (1993 est.)
Natural hazards: frequent earthquakes, landslides,
volcanic activity; periodic droughts
Environment - current issues: deforestation; soil
erosion; desertification; water pollution; pollution from
oil production wastes
Environment - International agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: Cotopaxi in Andes is highest
active volcano in world
Location: Western South America, bordering the
South Pacific Ocean, between Chile and Ecuador
Geographic coordinates: 10 00 S, 76 00 W
Map references: South America
Area:
total: 1 ,285,220 sq km
land: 1 .28 million sq km
water: 5,220 sq km
Area - comparative: slightly smaller than Alaska
Land boundaries:
total: 5,536 km
border countries: Bolivia 900 km, Brazil 1 ,560 km,
Chile 160 km, Colombia 1,496 km (est.), Ecuador
1,420 km
Coastline: 2,414 km
Maritime claims:
continental shelf: 200 NM
territorial sea: 200 NM
Climate: varies from tropical in east to dry desert in
west; temperate to frigid in Andes
Terrain: western coastal plain (costa), high and
rugged Andes in center (sierra), eastern lowland
jungle of Amazon Basin (selva)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petroleum,
timber, fish, iron ore, coal, phosphate, potash,
hydropower
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 21 %
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 12,800 sq km (1993 est.)
Natural hazards: earthquakes, tsunamis, flooding,
landslides, mild volcanic activity
Environment - current issues: deforestation (some
the result of illegal logging); overgrazing of the slopes
of the costa and sierra leading to soil erosion;
desertification; air pollution in Lima; pollution of rivers
and coastal waters from municipal and mining wastes
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: shares control of Lago Titicaca,
world''s highest navigable lake, with Bolivia','5e3064c2531cbe29d7174efbb944a4bc68812853e7b209c13a590400f858c869','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d4e51bbe4f51e3fd3e87c782a90966c862623236393f2c3aa7e02f8cdafff57',2001,'EG','Egypt','geography',405,'Location: Northern Africa, bordering the
Mediterranean Sea, between Libya and the Gaza
Strip
Geographic coordinates: 27 00 N, 30 00 E
Map references: Africa
Area:
total: 1 ,001 ,450 sq km
land: 995,450 sq km
water: 6,000 sq km
Area - comparative: slightly more than three times
the size of New Mexico
Land boundaries:
total: 2,689 km
border countries: Gaza Strip 1 1 km, Israel 255 km,
Libya 1,150 km, Sudan 1,273 km
Coastline: 2,450 km
Maritime ciaims:
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: desert; hot, dry summers with moderate
winters
149
Egypt (continued)
Terrain: vast desert plateau interrupted by Nile
valley and delta
Elevation extremes:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, manganese, limestone, gypsum, talc,
asbestos, lead, zinc
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
o//7er;98%(1993 est.)
Irrigated land: 32,460 sq km (1993 est.)
Natural hazards: periodic droughts; frequent
earthquakes, flash floods, landslides, volcanic activity;
hot, driving windstorm called khamsin occurs in
spring: dust storms, sandstorms
Environment - current issues: agricultural land
being lost to urbanization and windblown sands;
increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs,
beaches, and marine habitats; other water pollution
from agricultural pesticides, raw sewage, and
industrial effluents; very limited natural fresh water
resources away from the Nile which is the only
perennial water source; rapid growth in population
overstraining natural resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: controls Sinai Peninsula, only
land bridge between Africa and remainder of Eastern
Hemisphere: controls Suez Canal, shortest sea link
between Indian Ocean and Mediterranean Sea; size,
and juxtaposition to Israel, establish its major role in
Middle Eastern geopolitics; dependence on upstream
neighbors; dominance of Nile basin issues; prone to
Influxes of refugees','46f9b30a39bfe387d9d8947dcd6a95dbf3532ec6696ba758f3f4e032786475fe','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c53b50e34e832b743d211ed123db8c2e4c71279b5e3843400110901eb2ea95de',2001,'SV','El Salvador','geography',414,'Location: Middle America, bordering the North
Pacific Ocean, between Guatemala and Honduras
Geographic coordinates: 13 50 N, 88 55 W
Map references: Central America and the
Caribbean
Area;
total: 21,040 sq km
land: 20,720 sq km
water: 320 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 545 km
border countries: Guatemala 203 km, Honduras 342
km
Coastline: 307 km
Maritime claims;
territorial sea: 200 NM
Climate: tropical; rainy season (May to October); dry
season (November to April); tropical on coast;
temperate in uplands
Terrain: mostly mountains with narrow coastal belt
and central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cem El Pital 2,730 m
Natural resources: hydropower, geothermal power,
petroleum, arable land
Land use:
arable land: 27%
permanent crops: 8%
permanent pastures: 29%
forests and woodland: 5%
of/ier; 31% (1993 est.)
Irrigated land: 1 ,200 sq km (1993 est.)
Natural hazards: known as the Land of Volcanoes;
frequent and sometimes very destructive earthquakes
and volcanic activity
Environment - current Issues: deforestation; soil
erosion; water pollution; contamination of soils from
disposal of toxic wastes; Hurricane Mitch damage
Environment - international agreements;
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography ■ note: smallest Central American
country and only one without a coastline on Caribbean
Sea','f839d80d199322c8b055ccfe13f886076eab65e1b1291c8c233b6795922da06d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e64ab77f67f24782c1144eb5e162fbd475beb4ec26a3881068fd882f2cb176b4',2001,'GQ','Equatorial Guinea','geography',423,'Location: Western Africa, bordering the Bight of
Biafra, between Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total: 28,051 sq km
/and; 28,051 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 539 km
border countries: Cameroor] 189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: ]2 NM
Cilmate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands
are volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: oil, petroleum, timber, small
unexploited deposits of gold, manganese, uranium
Land use:
arable land: 5%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 46%
of/?er; 41% (1993 est.)
154
Equatorial Guinea (continued)
Irrigated land: NAsqkm
Natural hazards: violent windstorms, flash floods
Environment - current issues: tap water is not
potable; desertification
Environment - International agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Law of the Sea, Marine Dumping, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: insular and continental regions
rather widely separated','b836eff09db76471a063288d97060f0e1b7e8c23f8fd66f5bb9945073e4d017a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f38f227291dab680c3183acca2949f03d15ebe9d9baa766abebf6a7f5f939436',2001,'GN','Guinea','geography',432,'Location: Eastern Africa, bordering the Red Sea,
between Djibouti and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
fota/.''121,320 sq km
land: ^2^, 320 sq km
water: 0 sq km
Area - comparative: slightly larger than
Pennsylvania
Land boundaries;
total: 1 ,630 km
border countries: Djibouti 1 13 km, Ethiopia 912 km,
Sudan 605 km
Coastline: 2,234 km total; mainland on Red Sea
1,151 km, islands in Red Sea 1,083 km
Maritime claims:
territorial sea: ^2 NM
Climate: hot, dry desert strip along Red Sea coast;
cooler and wetter in the central highlands (up to 61 cm
of rainfall annually); semiarid in western hills and
lowlands; rainfall heaviest during June-September
except in coastal desert
Terrain: dominated by extension of Ethiopian
north-south trending highlands, descending on the
east to a coastal desert plain, on the northwest to hilly
terrain and on the southwest to flat-to-rolling plains
156
Eritrea (continued)
Elevation extremes:
lowest point: near Kulul within the Denakil
depression -75 m
highest point: Soira 3,018 m
Natural resources: gold, potash, zinc, copper, salt,
possibly oil and natural gas, fish
Land use:
arable land: ^2%
permanent crops: 1 %
permanent pastures: 49%
forests and woodland: 6%
cifto;32% (1998 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: frequent droughts; locust swarms
Environment - current issues: deforestation;
desertification; soil erosion; overgrazing; loss of
infrastructure from civil warfare
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: strategic geopolitical position
along world''s busiest shipping lanes; Eritrea retained
the entire coastline of Ethiopia along the Red Sea
upon de jure independence from Ethiopia on 24 May
1993
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and Sierra
Leone
Geographic coordinates: 1 1 00 N, 10 00 W
Map references: Africa
Area:
tofa/; 245,857 sq km
/and.'' 245,857 sq km
water: 0 sq km
Area ■ comparative: slightly smaller than Oregon
Land boundaries;
total: 3,399 km
border countries: Cote d''Ivoire 610 km,
Guinea-Bissau 386 km, Liberia 563 km, Mali 858 km,
Senegal 330 km. Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12
Climate: generally hot and humid; monsoonal-type
rainy season (June to November) with southwesterly
winds; dry season (December to May) with
northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to
mountainous interior
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: bauxite, iron ore, diamonds,
gold, uranium, hydropower, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 59%
other: 17% (1993 est.)
Irrigated land: 930 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season
Environment - current issues: deforestation;
inadequate supplies of potable water; desertification;
soil contamination and erosion; overfishing,
overpopulation in forest region
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Location: Southeastern Asia, group of islands
including the eastern half of the island of New Guinea
between the Coral Sea and the South Pacific Ocean,
east of Indonesia
Geographic coordinates: 6 00 S, 147 00 E
Map references: Oceania
Area:
tofa/: 462,840 sq km
/ancf: 452,860 sq km
water: 9,980 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 NM
territorial sea; 12 NM
Climate: tropical; northwest monsoon (December to
March), southeast monsoon (May to October); slight
seasonal temperature variation
Terrain: mostly mountains with coastal lowlands and
rolling foothills
Elevation extremes:
lowest point: Pacific Ocean 0 m
Population: 5,049,055 (July 2001 est.)
Age structure:
O-N years; 38.7% (male 993,248; female 960,647)
15''64 years: 57.63% (male 1 ,507,064; female
1,402,666)
65 years and over: 3.67% (male 87,779; female
97,651) (2001 est.)
Population growth rate: 2.43% (2001 est.)
Birth rate: 32.15 births/1 ,000 population (2001 est.)
Death rate: 7.88 deaths/1 ,000 population
(2001 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2001 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15’64 years: 1 .07 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.05 male(s)/female (2001 est.)
Infant mortality rate: 58.21 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 63.46 years
male: 61 .39 years
female: 65.64 years (2001 est.)
Total fertility rate: 4.3 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.22%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 5,400
(1999 est.)
HIV/AIDS - deaths: 450 (1999 est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito,
Micronesian, Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society
8%, Anglican 5%, Evangelical Alliance 4%,
Seventh-Day Adventist 1%, other Protestant 10%,
indigenous beliefs 34%
Languages: English spoken by 1%-2%, pidgin
English widespread, Motu spoken in Papua region
note: 715 indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 72.2%
male: 81%
female: 52.7% (1995 est.)
Location: Southeastern Asia, group of small islands
and reefs in the South China Sea, about one-third of
the way from central Vietnam to the northern','961cbc430b130473d6773d57da67c24de393124c508a69c0691f05b7730ee625','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15f6c54057e8d24d9fbf4bc76b4c9b1b7ab9f26096431fa93ab4f3b9bd3c631b',2001,'EE','Estonia','geography',435,'Location: Eastern Europe, bordering the Baltic Sea
and Gulf of Finland, between Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
Area:
total: 45,226 sq km
land: 43,21 1 sq km
water; 2,01 5 sq km
note: includes 1 ,520 islands in the Baltic Sea
Area ■ comparative: slightly smaller than New
Hampshire and Vermont combined
Land boundaries:
total: 633 km
border countries: Latvia 339 km, Russia 294 km
Coastline: 3,794 km
Maritime claims:
exclusive economic zone: limits fixed in coordination
with neighboring states
terr/Ma/ sea; 12 NM
Climate: maritime, wet, moderate winters, cool
summers
Terrain: marshy, lowlands
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Natural resources: shale oil (kukersite), peat,
phosphorite, amber, Cambrian blue clay, limestone,
dolomite, arable land
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 1 1 %
forests and woodland: 44%
oteer; 20% (1996 est.)
Irrigated land: 1 10 sq km (1996 est.)
Natural hazards: flooding occurs frequently in the
spring
Environment - current Issues: air heavily polluted
with sulfur dioxide from oil-shale burning power plants
in northeast; contamination of soil and groundwater
with petroleum products, chemicals at former Soviet
military bases; Estonia has more than 1 ,400 natural
and manmade lakes, the smaller of which in
agricultural areas are heavily affected by organic
waste; coastal sea water is polluted in many locations
Environment - international agreements:
party te; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Marine
Dumping, Ship Pollution, Ozone Layer Protection,
Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol','66983f1b17da45e29a16045ba33dfea5c747b91de66296819857e7eec992ad91','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('472c48b589da4c8438a9b35c5712e5c39776f3c41294264bf93ffa06cea1c593',2001,'FO','Faroe Islands','geography',443,'Location: Northern Europe, island group between
the Norwegian Sea and the North Atlantic Ocean,
about one-half of the way from Iceland to Norway
Geographic coordinates: 62 00 N, 7 00 W
Map references: Europe
Area:
total: 1 ,399 sq km
land: 1 ,399 sq km
water: 0 sq km (some lakes and streams)
Area - comparative: eight times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 3
Climate: mild winters, cool summers; usually
overcast; foggy, windy
Terrain: rugged, rocky, some low peaks; cliffs along
most of coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales, hydropower
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
of/ier; 94% (1996)
Irrigated land: 0 sq km
Natural hazards: NA
Environment - current issues: NA
Geography - note: archipelago of 17 inhabited
islands and one uninhabited island, and a few
uninhabited islets; strategically located along
Important sea lanes In northeastern Atlantic;
precipitous terrain limits habitation to small coastal
lowlands','c9f7c04f24f2a2a73a33a4b6a6495d4409b1b510970d1545d1817183d0e1de8b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('670db8ca7b4c5a718a9107d806550f7cdfcd7d110fce22683b476583814f2f78',2001,'DK','Denmark','geography',452,'Location: Oceania, island group in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','e4bf86faedb95c188cd8b877abaff33408d71932965d126d08fa01fe98478278','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66e7947fce07c7a0e1f9ac3cdcc081fb03ddbefff9099d1c73939d413df275fd',2001,'NZ','New Zealand','geography',453,'Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area:
total: 18,270 sq km
land: 18,270 sq km
water: 0 sq km
Area - comparative: slightly smaller than New
Location: Oceania, islands in the South Pacific
Ocean, southeast of Australia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area:
total: 268,680 sq km
land: 268,670 sq km
water: 10 sq km
note: includes Antipodes Islands, Auckland Islands,
Bounty Islands, Campbell Island, Chatham Islands,
and Kermadec Islands
Area - comparative: about the size of Colorado
Land boundaries: 0 km
Coastline: 15,134 km
366
Now Zealand (continued)
Maritime claims:
continental shelf: 200 NM or to the edge of the
continental margin
exclusive econofnic zone: 200 NM
territorial sea; 12 NM
Climate: temperate with sharp regional contrasts
Terrain: predominately mountainous with some
large coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Cook 3,764 m
Naturai resources: natural gas, iron ore, sand, coal,
timber, hydropower, gold, limestone
Land use:
arable land: 9%
permanent crops: 5%
permanent pastures: 50%
forests and woodland: 28%
ofher; 8% (1993 est.)
irrigated land: 2,850 sq km (1993 est.)
Natural hazards: earthquakes are common, though
usually not severe; volcanic activity
Environment - current issues: deforestation; soil
erosion; native flora and fauna hard-hit by species
introduced from outside
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Antarctic Seals, Climate
Change-Kyoto Protocol, Marine Life Conservation
Geography - note: about 80% of the population
lives in cities; Wellington is the southernmost national
capital in the world
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area:
total: 748 sq km
/and; 71 8 sq km
water: 30 sq km
Area - comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; modified by trade winds; warm
season (December to May), cool season (May to
December)
Terrain: most islands have limestone base formed
from uplifted coral formation; others have limestone
overlying volcanic base
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao Island
1,033 m
Natural resources: fish, fertile soil
Land use:
arable land: 24%
permanent crops: 43%
permanent pastures: 6%
forests and woodland: 1 1 %
ofhe/'';16%(1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones (October to April);
earthquakes and volcanic activity on Fonuafo''ou
Environment - current issues: deforestation results
as more and more land is being cleared for agriculture
and settlement; some damage to coral reefs from
starfish and indiscriminate coral and shell collectors;
overhunting threatens native sea turtle populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: archipelago of 170 islands (36
inhabited)
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
northeast of Venezuela
Geographic coordinates: 1 1 00 N, 61 00 W
Map references: Central America and the Caribbean
Area:
total: 5,^2S sq km
/and.'' 5,1 28 sq km
water: 0 sq km
Area - comparative: slightly smaller than Delaware
Land boundaries; 0 km
Coastline: 362 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the outer edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea; 12 NM
Climate: tropical; rainy season (June to December)
Terrain: mostly plains with some hills and low
mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use:
arable land: 15%
permanent crops: 9%
permanent pastures: 2%
forests and woodland: 46%
o//ier; 28% (1993 est.)
Irrigated land: 220 sq km (1993 est.)
Natural hazards: outside usual path of hurricanes
and other tropical storms
Environment - current issues: water pollution from
agricultural chemicals, industrial wastes, and raw
sewage; oil pollution of beaches; deforestation; soil
erosion
Environment - international agreements;
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates. 15 52 S, 54 25 E
Map references. Africa
Area.
total. 1 sq km
land. 1 sq km
water. 0 sq km
Area - comparative, about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries. 0 km
Coastline. 3.7 km
Maritime ciaims.
continental shelf. 200-m depth or to the depth of
exploitation
exclusive economic zone. 200 NM
territorial sea. 12 NM
Climate, tropical
Terrain, low, flat, and sandy
Elevation extremes.
lowest point. Indian Ocean 0 m
highest point, unnamed location 7 m
Natural resources, fish
Land use.
arable land. 0%
permanent crops. 0%
permanent pastures. 0%
forests and woodland. 0%
other. 100% (scattered bushes)
Irrigated land. 0 sq km (1993)
Natural hazards. NA
Environment - current issues. NA
Geography - note, climatologically important
location for forecasting cyclones; wildlife sanctuary
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
total: 274sqkm
land: 21 A sq km
water: 0 sq km
note: includes He Uvea (Wallis Island), He Futuna
(Futuna Island), lie Aiofi, and 20 islets
Area ■ comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; hot, rainy season (November to
April); cool, dry season (May to October); rains
2,500-3,000 mm per year (80% humidity); average
temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Singavi 765 m
Natural resources: NEGL
Land use:
arable iand: 5%
permanent crops: 20%
permanent pastures: 0%
forests and woodland: 0%
other: 75% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: deforestation (only
small portions of the original forests remain) largely as
a result of the continued use of wood as the main fuel
source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone
to erosion; there are no permanent settlements on
Alofi because of the lack of natural fresh water
resources
Geography - note: both island groups have fringing
reefs','a23ac8e2ee3abe12130388b070bc011313e83fca5babc3e7e55afbc217ae129d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f2d2415ba593566a3ad4a4d32a5e9187ae2e7a09931bb462f10be36da092333',2001,'JE','Jersey','geography',454,'Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation; rectilinear shelf claim added
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; only slight seasonal
temperature variation
Terrain: mostly mountains of volcanic origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Jomdinm 1,324 m
Natural resources: timber, fish, gold, copper,
offshore oil potential, hydropower
Land use:
arable land: 10%
permanent crops: 4%
permanent pastures: 1 0%
forests and woodland: 65%
other: 11% (1993 est.)
Irrigated land: 1 0 sq km (1 993 est.)
Natural hazards: cyclonic storms can occur from
November to January
Environment - current issues: deforestation; soil
erosion
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Law of the Sea, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: includes 332 islands of which
approximately 1 10 are inhabited
Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, and Gulf of Finland, between
Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area:
total: 337,030 sq km
land: 305,470 sq km
water: 31 ,560 sq km
Finland (continued)
Area - comparative: slightly smaller than Montana
Land boundaries:
total: 2,628 km
border countries: Norway 729 km, Sweden 586 km,
Russia 1,313 km
Coastline: 1 ,126 km (excludes islands and coastal
indentations)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 1 2 NM
territorial sea: 12 NM (in the Gulf of Finland - 3 NM)
Climate: cold temperate; potentially subarctic, but
comparatively mild because of moderating influence
of the North Atlantic Current, Baltic Sea, and more
than 60,000 lakes
Terrain: mostly low, flat to rolling plains interspersed
with lakes and low hills
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Haltiatunturi 1 ,328 m
Natural resources: timber, copper, zinc, iron ore,
silver
Land use:
arable land: 8%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 76%
oto;16%(1993 est.)
Irrigated land: 640 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: air pollution from
manufacturing and power plants contributing to acid
rain; water pollution from industrial wastes, agricultural
chemicals: habitat loss threatens wildlife populations
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: /\\\\r Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: long boundary with Russia;
Helsinki is northernmost national capital on European
continent; population concentrated on small
southwestern coastal plain
Land boundaries:
total: AS4 km
border countries: Iraq 242 km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
territorial sea: 12 NM
Climate: dry desert; intensely hot summers; short,
cool winters
Terrain: flat to slightly undulating desert plain
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish, shrimp, natural
gas
Land use:
arable land: 0%
pernianent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: B2% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: sudden cloudbursts are common
from October to April; they bring inordinate amounts of
rain which can damage roads and houses; sandstorms
and dust storms occur throughout the year, but are
most common between March and August
Environment - current issues: limited natural fresh
water resources; some of world''s largest and most
sophisticated desalination facilities provide much of
the water; air and water pollution; desertification
Environment - International agreements:
party to: Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: BMlmsliy, Endangered
Species, Marine Dumping
Geography - note: strategic location at head of
Persian Gulf
Land boundaries: 0 km
Coastline: 2,254 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; modified by southeast trade winds;
hot, humid
Terrain: coastal plains with interior mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1 ,628 m
Natural resources: nickel, chrome, iron, cobalt,
manganese, silver, gold, lead, copper
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 12%
forests and woodland: 39%
of/?er; 49% (1993 est.)
Irrigated land: 1 60 sq km (1 991 )
364
New Caledonia (continued)
Natural hazards: cyclones, most frequent from
November to March
Environment - current issues: erosion caused by
mining exploitation and forest fires
Land boundaries:
tofa/; 1,165 km
border countries: kus\\r\\a 330 km, Croatia 501 km,
Italy 232 km, Hungary 102 km
Coastline: 46.6 km
Maritime claims: NA
Climate: Mediterranean climate on the coast,
continental climate with mild to hot summers and cold
winters in the plateaus and valleys to the east
Terrain: a short coastal strip on the Adriatic, an alpine
mountain region adjacent to Italy and Austria, mixed
mountain and valleys with numerous rivers to the east
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Jr\\q\\ay 2,864 m
Natural resources; lignite coal, lead, zinc, mercury,
uranium, silver, hydropower
Land use:
arable land: ^2%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 54%
other: 7% (1996 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: flooding and earthquakes
Environment - current issues: Sava River polluted
with domestic and industrial waste; pollution of coastal
waters with heavy metals and toxic chemicals; forest
damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid
rain
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Land boundaries:
total: 535 km
border countries: Mozambique 105 km, South Africa
430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical to near temperate
Terrain; mostly mountains and hills; some
moderately sloping plains
Elevation extremes:
lowest point: Great Usutu River 21 m
highest point: Emiembe 1,862 m
Natural resources: asbestos, coal, clay, cassiterite,
hydropower, forests, small gold and diamond
deposits, quarry stone, and talc
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 62%
forests and woodland: 7%
other: 20% (1993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: limited supplies of
potable water; wildlife populations being depleted
because of excessive hunting; overgrazing; soil
degradation; soil erosion
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: Desertification, Law of the
Sea
Geography ■ note: landlocked; almost completely
surrounded by South Africa
Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, Kattegat, and Skagerrak,
between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total: 449,964 sq km
/anrt.'' 41 0,934 sq km
water: 39,030 sq km','02273f302d616d11ac458938655f28826f33aeb5c5c1e9689ae144bd484d65ea','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('288c106332c2317bacd399215530ba59aa266131a6920adb1811c4d622772cb6',2001,'GF','French Guiana','geography',471,'Location: Northern South America, bordering the
North Atlantic Ocean, between Brazil and Suriname
Geographic coordinates: 4 00 N, 53 00 W
Map references: South America
Area:
total: sq km
/and.'' 89,1 50 sq km
water: 1 ,850 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
/ofa/.'' 1,183 km
border countries: Brazil 673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; hot, humid; little seasonal
temperature variation
Terrain: low-lying coastal plains rising to hills and
small mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Bellevue de I''lnini 851 m
Natural resources: bauxite, timber, gold (widely
scattered), cinnabar, kaolin, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 90%
other: mo{]99e est.)
Irrigated land: 20 sq km (1993 est)
Natural hazards: high frequency of heavy showers
and severe thunderstorms; flooding
Environment - current issues: NA
Geography - note: mostly an unsettled wilderness','027838b623a9e53acd44d00fecc47e6e108afab6f6658e4f157289c756495f3f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d95bbb65a2ab35111304c6323fd59bdc3b32a2d0ea55e117f204752d16f2a4e',2001,'KI','Kiribati','geography',477,'Location: Oceania, archipelago in the South Pacific
Ocean, about one-half of the way from South America
to Australia
Geographic coordinates: 15 00 S, 140 00 W
Map references: Oceania
Area:
total: 4,167 sq km (1 18 islands and atolls)
land: 3,660 sq km
water: 507 sq km
Area - comparative: slightly less than one-third the
size of Connecticut
Land boundaries: 0 km
Coastiine: 2,525 km
Maritime ciaims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Ciimate: tropical, but moderate
Terrain: mixture of rugged high islands and low
islands with reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
h/ghesfpo/nf.'' Mont Orohena 2,241 m
Natural resources: timber, fish, cobalt, hydropower
Land use:
arable land: ^%
permanent crops: 6%
permanent pastures: 5%
forests and woodland: 31 %
of/ier; 57% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: occasional cyclonic storms in
January
Environment - current issues: NA
Geography - note: includes five archipelagoes;
Makatea in French Polynesia is one of the three great
phosphate rock islands in the Pacific Ocean - the
others are Banaba (Ocean Island) in Kiribati and Nauru
Location: Oceania, group of islands in the Pacific
Ocean, straddling the equator, about one-half of the
way from Hawaii to Australia; note - on 1 January
1 995, Kiribati proclaimed that all of its territory lies in
the same time zone as its Gilbert Islands group (GMT
+12) even though the Phoenix Islands and the Line
Islands under its jurisdiction lie on the other side of the
International Date Line
Geographic coordinates: 1 25 N, 173 00 E
Map references: Oceania
Area:
total: 7 M sq km
land: 7 Msq km
water: 0 sq km
note: includes three island groups - Gilbert Islands,
Line Islands, Phoenix Islands
Area - comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; marine, hot and humid, moderated
by trade winds
Terrain: mostly low-lying coral atolls surrounded by
extensive reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Natural resources: phosphate (production
discontinued in 1979)
Land use;
arable land: 0%
permanent crops: 5^1%
permanent pastures: 0%
forests and woodland: 3%
other 46% (1993 est.)
Irrigated land; NAsqkm
Natural hazards: typhoons can occur any time, but
usually November to March; occasional tornadoes;
low level of some of the islands make them very
sensitive to changes in sea level
Environment - current Issues: heavy pollution in
lagoon of south Tarawa atoll due to heavy migration
mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note; 20 of the 33 islands are
inhabited; Banaba (Ocean Island) in Kiribati is one of
the three great phosphate rock islands in the Pacific
Ocean - the others are Makatea in French Polynesia,
and Nauru
Location: Eastern Asia, northern half of the Korean
Peninsula bordering the Korea Bay and the Sea of
Japan, between China and South Korea
Geographic coordinates: 40 00 N, 127 00 E
Map references: Asia
Area:
total: 120,540 sq km
/and; 120,410 sq km
wafer; 130 sq km
Area - comparative: slightly smaller than
Mississippi
Land boundaries:
total: 1 ,673 km
border countries: China 1 ,41 6 km. South Korea 238
km, Russia 19 km
Coastline: 2,495 km
Maritime claims;
territorial sea: 12 NM
exclusive economic zone: 200 NM
note: military boundary line 50 NM in the Sea of Japan
and the exclusive economic zone limit in the Yellow
Sea where all foreign vessels and aircraft without
permission are banned
Climate: temperate with rainfall concentrated in
summer
Terrain: mostly hills and mountains separated by
deep, narrow valleys; coastal plains wide in west,
discontinuous in east
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Paektu-san 2,744 m
Natural resources; coal, lead, tungsten, zinc,
graphite, magnesite, iron ore, copper, gold, pyrites,
salt, fluorspar, hydropower
Land use:
arable land: 14%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 61 %
of/?er;23% (1993 est.)
Irrigated land: 14,600 sq km (1993 est.)
Natural hazards: late spring droughts often followed
by severe flooding; occasional typhoons during the
early fail
Environment - current issues: water pollution;
inadequate supplies of potable water; water-borne
disease; deforestation; soil erosion and degradation
Environment - internationai agreements;
party fo; Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Marine
Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Antarctic-Environmental
Protocol, Law of the Sea
Geography - note: strategic location bordering
China, South Korea, and Russia; mountainous interior
is isolated and sparsely populated
Location: Eastern Asia, southern half of the Korean
Peninsula bordering the Sea of Japan and the Yellow
Sea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area:
total: 98,480 sq km
land: 93,190 sq km
water: 290 sq km
Area - comparative: slightly larger than Indiana
Land boundaries:
total: 233 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: not specified
275
Korea, South (continued)
exclusive economic zone: 200 NM
territorial sea: 1 2 NM; between 3 NM and 1 2 NM in the
Korea Strait
Climate: temperate, with rainfall heavier in summer
than winter
Terrain: mostly hills and mountains; wide coastal
plains in west and south
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Halla-san 1 ,950 m
Natural resources: coal, tungsten, graphite,
molybdenum, lead, hydropower potential
Land use:
arable land: 19%
permanent crops: 2%
permanent pastures: 1 %
forests and woodland: 65%
other: 13% (1993 est.)
Irrigated land: 13,350 sq km (1993 est.)
Natural hazards: occasional typhoons bring high
winds and floods; low-level seismic activity common in
southwest
Environment - current issues: air pollution in large
cities; acid rain; water pollution from the discharge of
sewage and industrial effluents; drift net fishing
Environment - International agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Location: Middle East, bordering the Persian Gulf,
between Iraq and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
tofa/; 17,820 sq km
land: 17,820 sq km
water: 0 sq km
Area - comparative: slightly smaller than New','db2ceda14c88cff78f42690ccee7d50133d88c86396bea8f6453ca205d6f5e34','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20a739992c9fc83ce8f2994197d63a5f49c8bb5714419f2e6e1fd35737da6019',2001,'DE','Germany','geography',485,'Location: Central Europe, bordering the Baltic Sea
and the North Sea, between the Netherlands and
Poland, south of Denmark
Geographic coordinates: 51 00 N, 9 00 E
Map references: Europe
Area;
total: 357,021 sq km
land: 349,223 sq km
water: 7,798 sq km
Area - comparative: slightly smaller than Montana
Land boundaries:
tofa/; 3,61 8 km
border countries: Austria 784 km, Belgium 167 km,
Czech Republic 646 km, Denmark 68 km, France 451
km, Luxembourg 135 km, Netherlands 577 km,
Poland 456 km, Switzerland 334 km
189
Germany (continued)
Coastline; 2,389 km
Maritime claims;
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea; 12 NM
Climate: temperate and marine; cool, cloudy, wet
winters and summers; occasional warm foehn wind
Terrain: lowlands in north, uplands in center.
Bavarian Alps in south
Elevation extremes:
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2,963 m
Natural resources: iron ore, coal, potash, timber,
lignite, uranium, copper, natural gas, salt, nickel,
arable land
Land use:
arable land: 33%
permanent crops: ]%
permanent pastures: 1 5%
forests and woodland: 31 %
ote20%(1993 est.)
Irrigated land: 4,750 sq km (1993 est.)
Natural hazards: flooding
Environment - current issues: emissions from
coal-burning utilities and industries contribute to air
pollution; acid rain, resulting from sulfur dioxide
emissions, is damaging forests; pollution in the Baltic
Sea from raw sewage and industrial effluents from
rivers in eastern Germany; hazardous waste disposal;
government currently attempting to define mechanism
for ending the use of nuclear power; government
working to meet EU commitment to identify nature
preservation areas in line with the EU''s Flora, Fauna,
and Habitat directive
Environment - international agreements:
party /o; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Mr Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location on North
European Plain and along the entrance to the Baltic
Sea
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area:
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area - comparative: slightly smaller than Rhode
island
Land boundaries:
total: 356 km
border countries: Belgium 148 km, France 73 km,
Germany 135 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: modified continental with mild winters, cool
summers
Terrain: mostly gently rolling uplands with broad,
shallow valleys; uplands to slightly mountainous in the
north; steep slope down to Moselle flood plain in the
southeast
Elevation extremes:
lowest point: Moselle River 133 m
highest point: Buurgplaatz 559 m
Natural resources: iron ore (no longer exploited),
arable land
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 35%
other: 20%
Irrigated land: 10 sq km (including Belgium)
(1993 est.)
Natural hazards: NA
Environment - current issues: air and water
pollution in urban areas, soil pollution of farmland
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Environmental Modification
Geography - note: landlocked
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 10 N, 113 33 E
Map references: Southeast Asia
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area ■ comparative: about 0.1 times the size of
Washington, DC
303
Macau (continued)
Land boundaries;
total: 0.34 km
border countries: China 0.34 km
Coastline: 40 km
Maritime claims: not specified
Climate: subtropical; marine with cool winters, warm
summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 174 m
Natural resources; NEGL
Land use:
arable land: 0%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 0%
other: est.)
Irrigated land: NA sq km
Natural hazards: typhoons
Environment - current issues: NA
Geography - note: essentially urban; one causeway
and two bridges connect the two islands of Coloane
and Taipa to the peninsula on mainland
Location: Southeastern Europe, north of Greece
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Area:
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area - comparative: slightly larger than Vermont
Land boundaries;
total: 748 km
border countries: Mbam 151 km, Bulgaria 148 km,
Greece 228 km, Yugoslavia 221 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: warm, dry summers and autumns and
relatively cold winters with heavy snowfall
Terrain: mountainous territory covered with deep
basins and valleys; three large lakes, each divided by
a frontier line; country bisected by the Vardar River
Elevation extremes:
lowest point: Vardar River 50 m
highest point: Golem Korab (Maja e Korabit) 2,753 m
Natural resources; chromium, lead, zinc,
manganese, tungsten, nickel, low-grade iron ore,
asbestos, sulfur, timber, arable land
305
Macedonia, The Former Yugoslav Republic of (continued)
Land use:
arable land: 24%
permanent crops: 2%
permanent pastures: 25%
forests and woodland: 39%
other: mo {m3 est.)
Irrigated land: 830 sq km (1993 est.)
Natural hazards: high seismic risks
Environment - current issues: air pollution from
metallurgical plants
Environment - international agreements:
party to; Air Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; major transportation
corridor from Western and Central Europe to Aegean
Sea and Southern Europe to Western Europe
Location: Western Europe, bordering the North Sea,
between Belgium and Germany
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area:
total: 41 ,526 sq km
land: 33,883 sq km
water: 7,643 sq km
Area - comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1 ,027 km
border countries: Belgium 450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
exclusive fishing zone: 200 NM
territoriai sea: 12 NM
Climate: temperate; marine; cool summers and mild
winters
Terrain: mostly coastal lowland and reclaimed land
(polders); some hills in southeast
Elevation extremes:
lowest point: Prins Alexanderpolder -7 m
highest point: Maalserberg 321 m
Natural resources: natural gas, petroleum, arable
land
Land use:
arable land: 25%
permanent crops: 3%
permanent pastures: 25%
forests and woodland: 8%
other: 39% (1996 est.)
Irrigated land: 6,000 sq km (1996 est.)
Natural hazards: flooding
Environment - current Issues: water pollution in
the form of heavy metals, organic compounds, and
nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Environment - international agreements:
party fo.'' Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Biodiversity, Climate
Change-Kyoto Protocol
Geography - note: located at mouths of three major
European rivers (Rhine, Maas or Meuse, and
Schelde)','dd1b65f94979e0286afdaa532da977751938b35818798dc9c287f1dd83b34d1f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('421d7860a97a7a5327ad1610dabe24a0be2c3a0d9915540d72a9698c5e141fd7',2001,'GH','Ghana','geography',493,'Location: Western Africa, bordering the Gulf of
Guinea, between Cote d''Ivoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area:
total: 238,540 sq km
land: 230,020 sq km
water: 8,520 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,093 km
border countries: Burkina Faso 548 km, Cote d''Ivoire
668 km, Togo 877 km
Coastline: 539 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; warm and comparatively dry along
southeast coast; hot and humid in southwest; hot and
dry in north
Terrain: mostly low plains with dissected plateau in
south-central area
Elevation extremes:
tewesfpotef.* Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish, rubber,
hydropower
Land use:
arable land: 12%
permanent crops: 7%
permanent pastures: 22%
forests and woodland: 35%
of/7er;24%(1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: dry, dusty, harmattan winds occur
from January to March; droughts
Environment - current issues: recent drought in
north severely affecting agricultural activities;
deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations;
water pollution; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Marine Life Conservation
Geography ■ note: Lake Volta is the world''s largest
artificial lake; northeasterly harmattan wind (January
to March)','19d5abab7c048b5b2fcac821d7f98bf22e87358c5c68a336372c9f4ebca85a09','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55292929fa3a7976e08eb95c4385152d4e150c3408063ba2967e2af7145842b9',2001,'GI','Gibraltar','geography',501,'Location: Southwestern Europe, bordering the Strait
of Gibraltar, which links the Mediterranean Sea and the
North Atlantic Ocean, on the southern coast of Spain
Geographic coordinates: 36 1 1 N, 5 22 W
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area - comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries:
total: 1 .2 km
border countries: Spain 1 .2 km
Coastline: 12 km
Maritime claims:
temtorte/ sea; 3 NM
Climate: Mediterranean with mild winters and warm
summers
Terrain: a narrow coastal lowland borders the Rock
of Gibraltar
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
194
Gibraltar (continued)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: limited natural
freshwater resources; large concrete or natural rock
water catchments collect rainwater
Geography - note: strategic location on Strait of
Gibraltar that links the North Atlantic Ocean and
Mediterranean Sea
Location: Southern Africa, group of islands in the
Indian Ocean, northwest of Madagascar
Geographic coordinates: 11 30 S, 47 20 E
Map references: Africa
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes He Glorieuse, He du Lys, Verte Rocks,
Wreck Rock, and South Rock
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical
Terrain: low and fiat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Natural resources: guano, coconuts
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all lush vegetation and coconut palms)
Irrigated land: 0 sq km (1 993)
Natural hazards: periodic cyclones
Environment - current issues: NA','c591f83e202344139a7a6d985b00f9bbc5aa7c9f3f5431b4c3f0d0eeafbf360c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308f81c82d48f971399eeef94c7a0680625e2526e5b54d75a5619a22ea08d17e',2001,'GR','Greece','geography',510,'Location: Southern Europe, bordering the Aegean
Sea, Ionian Sea, and the Mediterranean Sea,
between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
/ofa/; 131 ,940 sq km
/a/7Qf;130,800 sq km
wafer; 1,1 40 sq km
Area - comparative: slightly smaller than Alabama
Land boundaries:
fofa/; 1,210 km
border countries: Albania 282 km, Bulgaria 494 km,
Turkey 206 km, The Former Yugoslav Republic of
Macedonia 228 km
Coastline: 13,676 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
ferr/for/a/ sea; 6 NM
Climate: temperate; mild, wet winters; hot, dry
summers
Terrain: mostly mountains with ranges extending
into the sea as peninsulas or chains of islands
Elevation extremes;
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,91 7 m
Natural resources: bauxite, lignite, magnesite,
petroleum, marble, hydropower potential
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 41 %
forests and woodland: 20%
ote; 12% (1993 est.)
Irrigated land: 13,140 sq km (1993 est.)
Natural hazards: severe earthquakes
Environment - current issues: air pollution; water
pollution
Environment - International agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Climate Change-Kyoto
Protocol
Geography ■ note: strategic location dominating the
Aegean Sea and southern approach to Turkish
Straits; a peninsular country, possessing an
archipelago of about 2,000 islands','7028b7e013e766f4d30a1a2deb3d879844d0f1b9ef3dd254f7503e112bc448ff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b3f71412485d5d7fc5f6a910264e6c132a8af1df81269169b239e13eca5b868',2001,'GL','Greenland','geography',518,'Location: Northern North America, island between
the Arctic Ocean and the North Atlantic Ocean,
northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: Arctic Region
Area:
/o/a/; 2,175,600 sq km
land: 2,175,600 sq km (341 ,700 sq km ice-free,
1 ,833,900 sq km ice-covered) (est.)
Area - comparative: slightly more than three times
the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
continental shelf: 200 NM or agreed boundaries or
median line
exclusive fishing zone: 200 NM or agreed boundaries
or median line
territorial sea; 3 NM
Climate: arctic to subarctic; coo! summers, cold
winters
Terrain: flat to gradually sloping icecap covers all but
a narrow, mountainous, barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
Natural resources: zinc, lead, iron ore, coal,
molybdenum, gold, platinum, uranium, fish, seals,
whales, hydropower, possible oil and gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 %
forests and woodland: 0%
o/her;99%(1998 est.)
Irrigated land: NAsqkm
Natural hazards: continuous permafrost over
northern two-thirds of the island
Environment - current issues: protection of the
arctic environment; preservation of the Inuit traditional
way of life, including whaling and sea! hunting
Geography - note: dominates North Atlantic Ocean
between North America and Europe; sparse
population confined to small settlements along coast,
but close to one-quarter of the population lives in the
capital, Nuuk; world''s second largest ice cap','4fc2d3052f871936241ff60c23dfeeaa4aaeac9e20f2019a0938f524ed9c9943','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6ecfeb4919cabccc1a4b4b5d8c19a35a7b21f4c99b92e8637df3601206796a4',2001,'GD','Grenada','geography',525,'Location: Caribbean, island between the Caribbean
Sea and Atlantic Ocean , north of T rinidad and T obago
Geographic coordinates: 12 07 N, 61 40 W
Map references: Central America and the
Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area ■ comparative: twice the size of Washington,
DC
Land boundaries; 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwater
harbors
Land use:
arable land: i5%
permanent crops: ^S%
permanent pastures: 3%
forests and woodland: 9%
other: 55% (^993 est.)
Irrigated land: NAsqkm
Natural hazards: lies on edge of hurricane belt;
hurricane season lasts from June to November
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada
Location; Caribbean, islands in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates: 13 15 N, 61 12 W
Map references: Central America and the
Caribbean
Area:
total: 389 sq km (Saint Vincent 344 sq km)
land: 389 sq km
water: 0 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastiine: 84 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Ciimate: tropical; little seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1 ,234 m
Natural resources: hydropower, cropland
Land use:
arab/e /anof; 10%
permanent crops: 1 8%
permanent pastures: 5%
forests and woodland: 36%
ofber; 31% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes; Soufriere volcano on
the island of Saint Vincent is a constant threat
Environment - current issues; pollution of coastal
waters and shorelines from discharges by pleasure
yachts and other effluents; in some areas, pollution is
severe enough to make swimming prohibitive
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: C\\\\ma\\e Change-Kyoto
Protocol
Geography - note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada','de52ad54cc52150eecad0b84480b2427fb3941e0d4bcd59a528f5f219bb0e323','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1735af7b46546c59a5b74168917dabecaa19620e888829a7e52a6d23b9941f07',2001,'GU','Guam','geography',536,'Location: Oceania, island in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 13 28 N, 144 47 E
Map references: Oceania
Area:
total: 549 sq km
land: 549 sq km
water: Osq km
Area - comparative: three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; generally warm and humid,
moderated by northeast trade winds; dry season from
January to June, rainy season from July to December;
little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs;
relatively flat coralline limestone plateau (source of
most fresh water), with steep coastal cliffs and narrow
coastal plains in north, low-rising hills in center,
mountains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: fishing (largely undeveloped),
tourism (especially from Japan)
Land use:
arable land: 1 1%
permanent crops: 1 1 %
permanent pastures: 1 5%
forests and woodland: 1 8%
other 45% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: frequent squalls during rainy
season; relatively rare, but potentially very destructive
typhoons (especially in August)
Environment - current issues: extirpation of native
bird population by the rapid proliferation of the brown
tree snake, an exotic species
Geography - note: largest and southernmost island
in the Mariana Islands archipelago; strategic location
in western North Pacific Ocean','712817b68424aea9b5d29be7c246a55428fe67d2d04e8d1450a8f71baab0cb42','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('809f57faca786dd3f630ee29496922de56f8f79402e090dd08dae76d88ff3430',2001,'GT','Guatemala','geography',543,'Location: Middle America, bordering the Caribbean
Sea, between Honduras and Belize and bordering the
North Pacific Ocean, between El Salvador and Mexico
Geographic coordinates: 15 30 N, 90 15 W
Map references: Central America and the
Caribbean
Area:
fofa/; 108,890 sq km
/and; 108,430 sq km
water: 460 sq km
Area - comparative: slightly smaller than
Tennessee
Land boundaries:
total: 1 ,687 km
border countries: Belize 266 km, El Salvador 203 km,
Honduras 256 km, Mexico 962 km
Coastline: 400 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; hot, humid in lowlands; cooler in
highlands
Terrain: mostly mountains with narrow coastal plains
and rolling limestone plateau (Peten)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,21 1 m
Natural resources: petroleum, nickel, rare woods,
fish, chicle, hydropower
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 24%
forests and woodland: 54%
ofder; 5% (1993 est.)
Irrigated land: 1 ,250 sq km (1993 est.)
Natural hazards: numerous volcanoes in
mountains, with occasional violent earthquakes;
Caribbean coast subject to hurricanes and other
tropical storms
Environment - current Issues: deforestation; soil
erosion; water pollution; Hurricane Mitch damage
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol
Geography - note: no natural harbors on west coast','a8562a0ea82b47c073f8a27e2a35e7f15bf3599690b03bcc8cbeccd33d47acfa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6d6f33d025b1488b92bfc1dde62a882d17450fb2efd9192ad09283f050aa7ed',2001,'GG','Guernsey','geography',551,'Location: Western Europe, islands in the English
Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area:
total: 1 94 sq km
land: 1 94 sq km
water: Osq km
note: includes Alderney, Guernsey, Herm, Sark, and
some other smaller islands
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 1 2 NM
territorial sea: 8 NM
Climate: temperate with mild winters and cool
summers; about 50% of days are overcast
Terrain: mostly level with low hills in southwest
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 1 14 m
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: N A%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: NA
209
Guernsey (continued)
Environment - current issues: NA
Geography - note: large, deepwater harbor at Saint
Peter Port','4e7fb2be16b5713ee99aabb1dea8fb3720977532280c657fb1cbfeafe4397c12','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2123f349640aef8344251034728d392c82bf5c6e8f35c799ce00aaabb5b4b594',2001,'GW','Guinea-Bissau','geography',560,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Senegal
Geographic coordinates: 12 00 N, 15 00 W
Map references: Africa
Area:
total: 33,120 sq km
land: 28,000 sq km
wafer 8,120 sq km
Area - comparative: slightly less than three times
the size of Connecticut
Land boundaries:
total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; generally hot and humid;
monsoonal-type rainy season (June to November)
with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain: mostly low coastal plain rising to savanna in
east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
213
Guinea-Bissau (continued)
highest point: unnamed location in the northeast
corner of the country 300 m
Natural resources: fish, timber, phosphates,
bauxite, unexploited deposits of petroleum
Land use:
arable land: M%
permanent crops: ^%
permanent pastures: 38%
forests and woodland: 38%
other: 12% (1993 est.)
Irrigated land: 17 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season; brush fires
Environment - current issues: deforestation; soil
erosion; overgrazing; overfishing
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements','c516b49733b8fd91aaca85f442f83ae5f3de7cee0c6240958a62dbf67ad72bcb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('001d1f0e00c9596f135e80b21d06154ec9fd931811caf6c323077515815f50fa',2001,'HM','Heard Island and McDonald Islands','geography',569,'(continued)
Natural hazards: Heard Island is dominated by a
dormant volcano called Big Ben
Environment - current Issues: NA
Geography - note: primarily used for research
stations','853475b29b15a1f9b73d41cec889bca46b929b70cdfaf16d382acd145017f5f8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a72de9db69937b16d0cb5c368429bfcfac9a2798a987cc1533499d02b97f2de7',2001,'HK','Hong Kong','geography',572,'Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 15 N, 114 10 E
Map references: Southeast Asia
Area:
total: 1 ,092 sq km
land: 1 ,042 sq km
wafer; 50 sq km
Area - comparative: six times the size of
Washington, DC
Land boundaries:
total: 30 km
border countries: China 30 km
Coastline: 733 km
Maritime claims:
ferr/tor/a/ sea; 3 NM
Climate: tropica! monsoon; cool and humid in winter,
hot and rainy from spring through summer, warm and
sunny in fall
Terrain: hilly to mountainous with steep slopes;
lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater harbor,
feldspar
Land use:
arable land: 6%
permanent crops: ^%
permanent pastures: 1 %
forests and woodland: 20%
ofher; 72% (1997 est.)
Irrigated land: 20 sq km (1997 est.)
Natural hazards: occasional typhoons
Environment - current issues: air and water
pollution from rapid urbanization
Geography - note: more than 200 islands','8852a3212f695bb15e9c60f8cd28f464599e0f254bba72bd98d27fcbb5743874','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1186482a5f6a96df6dd4fd855a90a622b8c7292de68732f2ff362a2a3faaf437',2001,'HU','Hungary','geography',580,'Location: Central Europe, northwest of Romania
Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
Area:
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries;
total: 2,009 km
border countries: Austria 366 km, Croatia 329 km,
Romania 443 km, Yugoslavia 151 km, Slovakia 515
km, Slovenia 102 km, Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cold, cloudy, humid winters;
warm summers
Terrain: mostly flat to rolling plains; hills and low
mountains on the Slovakian border
Elevation extremes:
lowest point: Tisza River 78 m
highest point: Kekes 1,014m
Natural resources: bauxite, coal, natural gas, fertile
soils, arable land
Land use;
arable land: b^%
permanent crops: 3.6%
permanent pastures: 12.4%
forests and woodland: 1 9%
oto;14%(1999)
Irrigated land: 2,060 sq km (1993 est.)
Environment - current issues: the approximation
of Hungary''s standards in waste management, energy
efficiency, and air, soil, and water pollution with
environmental requirements for EU accession will
require large investments
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94,
Antarctic-Environmental Protocol, Law of the Sea
Geography - note: landlocked; strategic location
astride main land routes between Western Europe
and Balkan Peninsula as well as between Ukraine and
Mediterranean basin
Location: Southern Europe, a peninsula extending
into the central Mediterranean Sea, northeast of
Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area:
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
Area ■ comparative: about twice the size of New
Hampshire
Land boundaries:
total: 1 ,355 km
border coun/r/es: Austria 91 km, Czech Republic 215
km, Hungary 51 5 km, Poland 444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: rugged mountains in the central and
northern part and lowlands in the south
Elevation extremes:
lowest point: Bodrok River 94 m
highest point: Gerlachovsky Stit 2,655 m
Natural resources: brown coal and lignite; small
amounts of iron ore, copper and manganese ore; salt;
arable land
Land use:
arable land: 3^%
permanent crops: 3%
permanent pastures: 1 7%
forests and woodland: 41 %
other: 3% {m3 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: NA
Environment - current Issues: air pollution from
metallurgical plants presents human health risks; acid
rain damaging forests
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked','c70b792488510186f60cfacec50231488c8e6290cbc7e3c92ff28d59b72469ca','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4559d1359cc2b619b3ea25705bfcca0d764e0713816b86484aaa7bcdaac3caf3',2001,'AT','Austria','geography',583,'Location: Northern Europe, island between the
Greenland Sea and the North Atlantic Ocean,
northwest of the UK
Geographic coordinates: 65 00 N, 18 00 W
Map references: Arctic Region
Area:
total: 103,000 sq km
/and; 100,250 sq km
water: 2,750 sq km
Area - comparative: slightly smaller than Kentucky
Land boundaries: 0 km
Coastline: 4,988 km
Maritime ciaims:
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: temperate; moderated by North Atlantic
Current; mild, windy winters; damp, cool summers
Terrain: mostly plateau interspersed with mountain
peaks, Icefields; coast deeply indented by bays and
fiords
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,1 19 m
Natural resources: fish, hydropower, geothermal
power, diatomite
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 1 %
of/ier;76%(1993 est.)
irrigated land: NAsqkm
Natural hazards: earthquakes and volcanic activity
Environment ■ current issues: water pollution from
fertilizer runoff; inadequate wastewater treatment
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Marine Life Conservation
Geography - note: strategic location between
Greenland and Europe; westernmost European
country; Reykjavik is the northernmost national capital
in the world; more land covered by glaciers than in all
of continental Europe
P 9 0 g t e
Population: 277,906 (July 2001 est.)
Age structure:
0‘14 years: 23.18% (male 33,238; female 31,191)
15-64 years: 65.01 % (male 91 ,095; female 89,583)
65 years and over: 1 1 .81 % (male 1 4,681 ; female
18,118) (2001 est.)
Population growth rate: 0.54% (2001 est.)
Birth rate: 14.62 births/1,000 population (2001 est.)
Death rate: 6.89 deaths/1 ,000 population
(2001 est.)
Net migration rate: -2.28 migrant(s)/1 ,000
population (2001 est.)
Sex ratio:
af birth: 1 .08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (2001 est.)
Infant mortality rate: 3.56 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 79.52 years
male: 77.31 years
female: 81 .92 years (2001 est.)
Total fertility rate: 2.01 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.14%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: lcelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of
descendants of Norse and Celts
Religions: Evangelical Lutheran 93%, other
Protestant and Roman Catholic, none (1997)
Languages: Icelandic
Literacy:
definition: age 15 and over can read and write
total population: 99.9% (1997 est.)
male: NA%
female: NA%
Location: Southern Asia, bordering the Arabian Sea
and the Bay of Bengal, between Burma and Pakistan
Geographic coordinates: 20 00 N, 77 00 E
Map references: Asia
Area:
total: 3,287,590 sq km
/and; 2,973,1 90 sq km
water; 314,400 sq km
Area - comparative: slightly more than one-third the
size of the US
Land boundaries:
tote/; 14,103 km
border countries: Bangladesh 4,053 km, Bhutan 605
km, Burma 1,463 km, China 3,380 km, Nepal 1,690
km, Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: varies from tropical monsoon in south to
temperate in north
Terrain: upland plain (Deccan Plateau) in south, flat
to rolling plain along the Ganges, deserts in west,
Himalayas in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest reserves in
the world), iron ore, manganese, mica, bauxite,
titanium ore, chromite, natural gas, diamonds,
petroleum, limestone, arable land
Land use:
arable land: 56%
permanent crops: ]%
permanent pastures: 4%
forests and woodland: 23%
otoer; 16% (1993 est.)
Irrigated land: 535,100 sq km (1995/96 est.)
Natural hazards: droughts, flash floods, severe
thunderstorms common; earthquakes
Environment - current issues: deforestation; soil
erosion: overgrazing; desertification; air pollution from
industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural
pesticides: tap water is not potable throughout the
country: huge and growing population is overstraining
natural resources
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: dominates South Asian
subcontinent: near important Indian Ocean trade
routes
Location: body of water between Africa, the
Southern Ocean, Asia, and Australia
Geographic coordinates: 20 00 S, 80 00 E
Map references: World
Area:
total: 68.556 million sq km
note: includes Andaman Sea, Arabian Sea, Bay of
Bengal, Great Australian Bight, Gulf of Aden, Gulf of
Oman, Mozambique Channel, Persian Gulf, Red Sea,
Strait of Malacca, and other tributary water bodies
Area - comparative: about 5.5 times the size of the
US
Coastline: 66,526 km
Climate: northeast monsoon (December to April),
southwest monsoon (June to October); tropical
cyclones occur during May/June and October/
November in the northern Indian Ocean and January/
February in the southern Indian Ocean
Terrain: surface dominated by counterclockwise
gyre (broad, circular system of currents) in the
southern Indian Ocean; unique reversal of surface
currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot,
rising, summer air results in the southwest monsoon
and southwest-to-northeast winds and currents, while
high pressure over northern Asia from cold, falling,
winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean
floor is dominated by the Mid-Indian Ocean Ridge and
subdivided by the Southeast Indian Ocean Ridge,
Southwest Indian Ocean Ridge, and Ninetyeast Ridge
Elevation extremes:
lowest point: Trench -7,258 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, shrimp,
sand and gravel aggregates, placer deposits,
polymetallic nodules
Natural hazards: occasional icebergs pose
navigational hazard in southern reaches
Environment - current Issues: endangered marine
species include the dugong, seals, turtles, and
whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
Geography - note: major chokepoints include Bab
el Mandeb, Strait of Hormuz, Strait of Malacca,
southern access to the Suez Canal, and the Lombok
Strait
Location: Southeastern Asia, archipelago between
the Indian Ocean and the Pacific Ocean
Geographic coordinates: 5 00 S, 120 00 E
Map references: Southeast Asia
Area:
tofa/; 1,919,440 sq km
land: 1 ,826,440 sq km
wafer; 93,000 sq km
Area - comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 2,602 km
border countries: Malaysia 1 ,782 km, Papua New
Guinea 820 km
Coastline: 54,716 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: mostly coastal lowlands; larger Islands have
interior mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Puncak Jaya 5,030 m
Natural resources: petroleum, tin, natural gas, nickel,
timber, bauxite, copper, fertile soils, coal, gold, silver
Land use:
arable land: W/o
permanent crops: 7%
permanent pastures: 7%
forests and woodland: 62%
other 14% (1993 est.)
Irrigated land: 45,970 sq km (1993 est.)
Natural hazards: occasional floods, severe
droughts, tsunamis, earthquakes, volcanoes
Environment - current issues: deforestation; water
pollution from industrial wastes, sewage; air pollution
in urban areas; smoke and haze from forest fires
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: archipelago of 17,000 Islands
(6,000 inhabited); straddles Equator; strategic
location astride or along major sea lanes from Indian
Ocean to Pacific Ocean
Location; Middle East, bordering the Gulf of Oman,
the Persian Gulf, and the Caspian Sea, between Iraq
and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area:
total: 1.648 million sq km
/and; 1.636 million sq km
water: 12,000 sq km
Area - comparative: slightly larger than Alaska
Land boundaries:
total: 5,440 km
border countries: Afghanistan 936 km, Armenia 35
km, Azerbaijan-proper 432 km, Azerbaijan-Naxcivan
exclave 179 km, Iraq 1 ,458 km, Pakistan 909 km,
Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km; note - Iran also borders the
Caspian Sea (740 km)
Maritime claims:
contiguous zone: 24 NM
continental shelf: natural prolongation
exclusive economic zone: bilateral agreements or
median lines in the Persian Gulf
territorial sea: 12 NM
Climate: mostly arid or semiarid, subtropical along
Caspian coast
239
Iran (continued)
Terrain: rugged, mountainous rim; high, central
basin with deserts, mountains; small, discontinuous
plains along both coasts
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: OoWeh-ye Damavand 5,671 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, iron ore, lead, manganese, zinc,
sulfur
Land use:
arable land: 10%
permanent crops: ^%
permanent pastures: 27%
forests and woodland: 7%
other: 55% {ms est.)
Irrigated land: 94,000 sq km (1993 est.)
Natural hazards: periodic droughts, floods; dust
storms, sandstorms; earthquakes along western
border and in the northeast
Environment - current issues: air pollution,
especially in urban areas, from vehicle emissions,
refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution
in the Persian Gulf; inadequate supplies of potable
water
Environment ■ International agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea, Marine Life Conservation
Location: Middle East, bordering the Persian Gulf,
between Iran and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area:
total: 437,072 sq km
/and; 432,1 62 sq km
wafer; 4,91 Osq km
Area - comparative: slightly more than twice the
size of Idaho
Land boundaries:
total: 3,631 km
border countries: Iran 1,458 km, Jordan 181 km,
Kuwait 242 km, Saudi Arabia 814 km, Syria 605 km,
Turkey 331 km
Coastline: 58 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 NM
Climate: mostly desert; mild to cool winters with dry,
hot, cloudless summers; northern mountainous
regions along Iranian and Turkish borders experience
cold winters with occasionally heavy snows that melt
in early spring, sometimes causing extensive flooding
in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along
Iranian border in south with large flooded areas;
mountains along borders with Iran and Turkey
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Haji Ibrahim 3,600 m
Natural resources: petroleum, natural gas,
phosphates, sulfur
Land use:
arable land: ^2%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 0%
other: 79% (m3 est.)
Irrigated land: 25,500 sq km (1993 est.)
Natural hazards: dust storms, sandstorms, floods
Environment - current Issues: government water
control projects have drained most of the inhabited
marsh areas east of An Nasiriyah by drying up or
diverting the feeder streams and rivers; a once sizable
population of Shi''a Muslims, who have inhabited these
areas for thousands of years, has been displaced;
furthermore, the destruction of the natural habitat
poses serious threats to the area''s wildlife
populations; inadequate supplies of potable water;
development of Tigris-Euphrates Rivers system
contingent upon agreements with upstream riparian
Turkey; air and water pollution; soil degradation
(salination) and erosion; desertification
Environment - international agreements:
party to: Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ship Pollution
signed, but not ratified: Environmental Modification','49660b5f7459b72460d31f850247c443e39e7d31154f5dd2172620cd39afb006','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e565c3a106c11ed276064f913550358d2cdf835f8b684fd1b0903f20f37d31c',2001,'IE','Ireland','geography',592,'Location: Western Europe, occupying five-sixths of
the island of Ireland in the North Atlantic Ocean, west
of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area:
total: 70,280 sq km
land: 68,890 sq km
wafer; 1,390 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime claims:
continental shelf: not specified
exclusive fishing zone: 200 NM
territorial sea: 12 NM
Climate: temperate maritime; modified by North
Atlantic Current; mild winters, cool summers;
consistently humid; overcast about half the time
Terrain: mostly level to rolling interior plain
surrounded by rugged hills and low mountains; sea
cliffs on west coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: CarmntoohW 1,041 m
Natural resources: zinc, lead, natural gas, barite,
copper, gypsum, limestone, dolomite, peat, silver
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 68%
forests and woodland: 5%
other: 14% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current Issues: water pollution,
especially of lakes, from agricultural runoff
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Biodiversity, Climate
Change, Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Endangered Species, Marine Life Conservation
Geography - note: strategic location on major air
and sea routes between North America and northern
Europe; over 40% of the population resides within 97
km of Dublin','e48939fbe94955d6622853387263031e7d7bd0048bb1f765bcc8878ea7fb36d4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('439c59fe3d80c6124fe9db79c6e9094807566f765ae2a1155e1c8a00bcb8b852',2001,'IL','Israel','geography',600,'Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area - comparative: slightly smaller than New Jersey
Land boundaries:
total: 1 ,006 km
border countries: Egypt 255 km, Gaza Strip 51 km,
Jordan 238 km, Lebanon 79 km, Syria 76 km, West
Bank 307 km
Coastiine: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 NM
Climate: temperate; hot and dry in southern and
eastern desert areas
Terrain: Negev desert in the south; low coastal plain;
central mountains; Jordan Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1 ,208 m
Natural resources: timber, potash, copper ore,
natural gas, phosphate rock, magnesium bromide,
clays, sand, oil
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 7%
forests and woodland: 6%
other: 88% (1993 est.)
Irrigated land: 1 ,800 sq km (1993 est.)
Natural hazards: sandstorms may occur during
spring and summer; droughts
Environment - current issues: limited arable land
and natural fresh water resources pose serious
constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from
industrial and domestic waste, chemical fertilizers,
and pesticides
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: there are 231 Israeli settlements
and civilian land use sites in the West Bank, 42 in the
Israeli-occupied Golan Heights, 25 in the Gaza Strip,
and 29 in East Jerusalem (August 2000 est.)','a15ff10cb2df0e6349074ca91af09b06ebde1ba8dba2ce8ec3d840a157f15e89','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52f9bc9be98ad80496925e94c5b9dde2359871a764150d4983884ce2a79d6492',2001,'TN','Tunisia','geography',608,'Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area:
tofa/.* 301,230 sq km
land: 294,020 sq km
water: 7,21 0 sq km
note: includes Sardinia and Sicily
Area - comparative: slightly larger than Arizona
Land boundaries:
total: 9322 km
border cot/nfr/es.'' Austria 430 km, France 488 km,
Holy See (Vatican City) 3.2 km, San Marino 39 km,
Slovenia 232 km, Switzerland 740 km
Coastline: 7,600 km
Maritime ciaims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 NM
Climate: predominantly Mediterranean; Alpine In far
north; hot, dry in south
Terrain: mostly rugged and mountainous; some
plains, coastal lowlands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc (Monte Bianco) 4,807 m
Natural resources: mercury, potash, marble, sulfur,
natural gas and crude oil reserves, fish, coal, arable
land
Land use:
arable land: 31%
permanent crops: 1 0%
permanent pastures: 1 5%
forests and woodland: 23%
ote21%(1993 est.)
Irrigated land: 27,100 sq km (1993 est.)
Natural hazards: regional risks include landslides,
mudflows, avalanches, earthquakes, volcanic
eruptions, flooding; land subsidence in Venice
Environment - current issues: air pollution from
industrial emissions such as sulfur dioxide; coastal and
inland rivers polluted from industrial and agricultural
effluents; acid rain damaging lakes; inadequate
industrial waste treatment and disposal facilities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location dominating
central Mediterranean as well as southern sea and air
approaches to Western Europe
Location: Northern Africa, bordering the
Mediterranean Sea, between Algeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
fofa/.- 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Area ■ comparative: slightly larger than Georgia
Land boundaries:
total: 1 ,424 km
border countries: Algeria 965 km, Libya 459 km
507
Tunisia (continued)
Coastline: 1,148 km
Maritime claims:
contiguous zone: 24 NM
territorial sea: 12 NM
Climate: temperate in north with mild, rainy winters
and hot, dry summers; desert in south
Terrain: mountains in north; hot, dry central plain;
semiarid south merges into the Sahara
Elevation extremes:
lowest point: Shatt al Gharsah -17 m
highest point: Jebel ech Chambi 1 ,544 m
Natural resources: petroleum, phosphates, iron
ore, lead, zinc, salt
Land use:
arable land: 19%
permanent crops: 13%
permanent pastures: 20%
forests and woodland: 4%
other: 44% (1 993 est.)
Irrigated land: 3,850 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: toxic and
hazardous waste disposal is ineffective and presents
human health risks; water pollution from raw sewage;
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Environment - International agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography ■ note: strategic location in central
Mediterranean; Malta and Tunisia are discussing the
commercial exploitation of the continental shelf
between their countries, particularly for oil exploration
Location: southeastern Europe and southwestern
Asia (that portion of Turkey west of the Bosporus is
geographically part of Europe), bordering the Black
Sea, between Bulgaria and Georgia, and bordering
the Aegean Sea and the Mediterranean Sea, between
Greece and Syria
Geographic coordinates: 39 00 N, 35 00 E
Map references: Middle East
Area:
total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
Area - comparative: slightly larger than Texas
Land boundaries;
total: 2,627 km
border countries: Armenia 268 km, Azerbaijan 9 km,
Bulgaria 240 km, Georgia 252 km, Greece 206 km,
Iran 499 km, Iraq 331 km, Syria 822 km
Coastline: 7,200 km
Maritime claims:
exclusive economic zone: in Black Sea only: to the
maritime boundary agreed upon with the former
USSR
territorial sea: 6 NM in the Aegean Sea; 12 NM in
Black Sea and in Mediterranean Sea
Climate: temperate; hot, dry summers with mild, wet
winters; harsher in interior
Terrain: mostly mountains; narrow coastal plain;
high central plateau (Anatolia)
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5, 1 66 m
Natural resources: antimony, coal, chromium,
mercury, copper, borate, sulfur. Iron ore, arable land,
hydropower
Land use;
arable land: 32%
permanent crops: 4%
permanent pastures: 1 6%
forests and woodland: 26%
of/?er; 22% (1993 est.)
Irrigated land: 36,740 sq km (1993 est.)
Natural hazards: very severe earthquakes,
especially in northern Turkey, along an arc extending
from the Sea of Marmara to Lake Van
Environment ■ current issues: water pollution from
dumping of chemicals and detergents; air pollution,
particularly in urban areas; deforestation; concern for
oil spills from increasing Bosporus shjp traffic
Environment ■ international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Environmental Modification
Geography - note: strategic location controlling the
Turkish Straits (Bosporus, Sea of Marmara,
Dardanelles) that link Black and Aegean Seas
Location: Central Asia, bordering the Caspian Sea,
between Iran and Kazakhstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Commonwealth of Independent
States
Area:
tofa/;488,100 sq km
/and; 488, 100 sq km
water: 0 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 3,736 km
border countries: Afghanistan 744 km, Iran 992 km,
Kazakhstan 379 km, Uzbekistan 1,621 km
Coastline: 0 km; note - Turkmenistan borders the
Caspian Sea (1,768 km)
Maritime claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes rising
to mountains in the south; low mountains along border
with Iran; borders Caspian Sea in west
Elevation extremes:
lowest point: Vpadina Akchanaya -81.00 m; note -
Sarygamysh Koli is a lake in northern Turkmenistan
with a water level that fluctuates above and below the
elevation of Vpadina Akchanaya (the lake has
dropped as low as -110 m)
highest point: Gora Ayribaba 3,139 m
soil and groundwater with agricultural chemicals,
pesticides; salination, water-logging of soil due to poor
irrigation methods; Caspian Sea pollution; diversion of
a large share of the flow of the Amu Darya into
irrigation contributes to that river''s inability to replenish
the Aral Sea; desertification
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
Location: Caribbean, two island groups in the North
Atlantic Ocean, southeast of The Bahamas
Geographic coordinates: 21 45 N, 71 35 W
Map references: Central America and the
Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 12 NM
Climate: tropical; marine; moderated by trade winds;
sunny and relatively dry
Terrain; low, flat limestone; extensive marshes and
mangrove swamps
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 98% (1998 est.)
Irrigated land: NA sq km
Natural hazards: frequent hurricanes
Environment - current issues: limited natural fresh
water resources, private cisterns collect rainwater
Geography - note; 30 islands (eight inhabited)','37302f893593e1f823df822537e7ab37057f2205e9f56494ff44fefcae428773','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3364bba61b9b8e79a4ca4aaa767cb2c1a8621a9c01af06c7a66a75432ef724f5',2001,'JM','Jamaica','geography',617,'Location: Caribbean, island in the Caribbean Sea,
south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the Caribbean
Area:
tofa/; 10,990 sq km
/and.'' 10,830 sq km
loafer 160 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1 ,022 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains, with narrow,
discontinuous coastal plain
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, limestone
Land use:
arable land: 14%
permanent crops: 6%
permanent pastures: 24%
forests and woodland: 1 7%
of/?er; 39% (1993 est.)
Irrigated land: 350 sq km (1993 est.)
Natural hazards: hurricanes (especially July to
November)
Environment - current issues: heavy rates of
deforestation; coastal waters polluted by industrial
waste, sewage, and oil spills; damage to coral reefs;
air pollution in Kingston results from vehicle emissions
Environment - International agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Law of the Sea, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography ■ note: strategic location between
Cayman Trench and Jamaica Channel, the main sea
lanes for Panama Canal','4bf1a711882971b7a49235b92b639af636335191fbd8bf0fe11e62630368f9ed','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74a3b9abfa359fd905bb48e3c23a49d0843e53b3bd8567abd3eb9743d7645098',2001,'NO','Norway','geography',629,'Elevation extremes:
lowest point: Hachiro-gata -4 m
highest point: Fujiyama 3,776 m
Natural resources: negligible mineral resources,
fish
Land use:
arable land: ^^%
permanent crops: ]%
permanent pastures: 2%
forests and woodiand: 67%
other: 19% (1993 est.)
Irrigated land: 27,820 sq km (1993 est.)
Natural hazards: many dormant and some active
volcanoes; about 1 ,500 seismic occurrences (mostly
tremors) every year; tsunamis; typhoons
Environment - current issues: air pollution from
power plant emissions results in acid rain; acidification
of lakes and reservoirs degrading water quality and
threatening aquatic life; Japan is one of the largest
consumers of fish and tropical timber, contributing to
the depletion of these resources in Asia and
elsewhere
Environment ■ international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: strategic location in northeast
Asia
Location: Eastern Asia, island chain between the
North Pacific Ocean and the Sea of Japan, east of the
Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references: Asia
Area:
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto),
Daito-shoto, Minami-jima, Okino-tori-shima, Ryukyu
Islands (Nansei-shoto), and Volcano Islands
(Kazan-retto)
Area - comparative: slightly smaller than California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 1 2 NM; between 3 NM and 1 2 NM in the
international straits - La Perouse or Soya, Tsugaru,
Osumi, and Eastern and Western Channels of the
Korea or Tsushima Strait
Climate: varies from tropica! in south to cool
temperate in north
Terrain: mostly rugged and mountainous
Location: Oceania, island in the South Pacific
Ocean, about one-half of the way from Hawaii to the
Location: Northern Europe, bordering the North Sea
and the North Atlantic Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area:
total: 324,220 sq km
land: 307,860 sq km
wafer 16,360 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
fofa/; 2,515 km
border countries: Finland 729 km, Sweden 1,619 km,
Russia 167 km
Coastline: 21,925 km (includes mainland 3,419 km,
large islands 2,413 km, long fjords, numerous small
islands, and minor indentations 16,093 km)
Maritime claims:
contiguous zone: 10 HU
continental shelf: 200 NM
exclusive economic zone: 200 NM
territorial sea.- 4 NM
Climate: temperate along coast, modified by North
Atlantic Current; colder interior with increased
precipitation and colder summers causing glaciers to
grow; rainy year-round on west coast
Terrain: glaciated; mostiy high plateaus and rugged
mountains broken by fertile valleys; small, scattered
381
Norway (continued)
plains; coastline deeply indented by fjords; arctic
tundra in north
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: GMhoplqqen 2,469 m
Natural resources: petroleum, copper, natural gas,
pyrites, nickel, iron ore, zinc, lead, fish, timber,
hydropower
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 27%
other: 70% {m3 est.)
Irrigated land: 970 sq km (1993 est.)
Natural hazards: rockslides, avalanches
Environment ■ current issues: water pollution; acid
rain damaging forests and adversely affecting lakes,
threatening fish stocks; air pollution from vehicle
emissions
Environment - International agreements:
party fo; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol
Geography - note: about two-thirds mountains;
some 50,000 islands off its much indented coastline;
strategic location adjacent to sea lanes and air routes
in North Atlantic; one of most rugged and longest
coastlines in world; Norway is the only NATO member
having a land boundary with Russia
Location: Middle East, bordering the Arabian Sea,
Gulf of Oman, and Persian Gulf, between Yemen and
UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area:
total: 212,460 sq km
land: 212,460 sq km
water: 0 sq km
Area - comparative: slightly smaller than Kansas
Land boundaries:
total: 1,374 km
border countries: Saudi Arabia 676 km, UAE 41 0 km,
Yemen 288 km
Coastline: 2,092 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: dry desert; hot, humid along coast; hot, dry
interior; strong southwest summer monsoon (May to
September) in far south
Terrain: central desert plain, rugged mountains in
north and south
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal Shams 2,980 m
Natural resources: petroleum, copper, asbestos,
some marble, limestone, chromium, gypsum, natural
gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 0%
other: %% {m3 est.)
Irrigated land: 580 sq km (1993 est.)
Natural hazards: summer winds often raise large
sandstorms and dust storms in interior; periodic
droughts
Environment - current issues: rising soil salinity;
beach pollution from oil spills; very limited natural
fresh water resources
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on Musandam
Peninsula adjacent to Strait of Hormuz, a vital transit
point for world crude oil
Location: body of water between the Southern
Ocean, Asia, Australia, and the Western Hemisphere
Geographic coordinates: 0 00 N, 160 00 W
Map references: World
Area:
tofa/; 155.557 million sq km
note: includes Bali Sea, Bering Sea, Bering Strait,
Coral Sea, East China Sea, Flores Sea, Gulf of
Alaska, Gulf of Tonkin, Java Sea, Philippine Sea,
Savu Sea, Sea of Japan, Sea of Okhotsk, South
China Sea, Tasman Sea, Timor Sea, and other
tributary water bodies
Area - comparative: about 1 5 times the size of the
US; covers about 28% of the global surface; larger
than the total land area of the world
Coastline: 135,663 km
Climate: planetary air pressure systems and
resultant wind patterns exhibit remarkable uniformity
in the south and east; trade winds and westerly winds
are well-developed patterns, modified by seasonal
fluctuations; tropical cyclones (hurricanes) may form
south of Mexico from June to October and affect
Mexico and Central America; continental influences
cause climatic uniformity to be much less pronounced
in the eastern and western regions at the same
latitude in the North Pacific Ocean; the western Pacific
is monsoonal - a rainy season occurs during the
summer months, when moisture-laden winds blow
from the ocean over the land, and a dry season during
the winter months, when dry winds blow from the
Asian landmass back to the ocean; tropical cyclones
(typhoons) may strike southeast and east Asia from
May to December
Terrain: surface currents in the northern Pacific are
dominated by a clockwise, warm-water gyre (broad
circular system of currents) and in the southern Pacific
by a counterclockwise, cool-water gyre; in the
northern Pacific, sea ice forms in the Bering Sea and
Sea of Okhotsk in winter; in the southern Pacific, sea
ice from Antarctica reaches its northernmost extent in
October; the ocean floor in the eastern Pacific is
dominated by the East Pacific Rise, while the western
Pacific is dissected by deep trenches, including the
Mariana Trench, which is the world''s deepest
Elevation extremes:
lowest point: Challenger Deep in the Mariana
Trench -10,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields, polymetallic
nodules, sand and gravel aggregates, placer
deposits, fish
Natural hazards: surrounded by a zone of violent
volcanic and earthquake activity sometimes referred
to as the "Pacific Ring of Fire"; subject to tropical
cyclones (typhoons) in southeast and east Asia from
May to December (most frequent from July to
October); tropical cyclones (hurricanes) may form
south of Mexico and strike Central America and
Mexico from June to October (most common in
August and September); cyclical El Nino/La Nina
phenomenon occurs in the equatorial Pacific,
influencing weather in the Western Hemisphere and
the western Pacific; ships subject to superstructure
icing in extreme north from October to May; persistent
fog in the northern Pacific can be a maritime hazard
from June to December
Environment - current issues: endangered marine
species include the dugong, sea lion, sea otter, seals,
turtles, and whales; oil pollution in Philippine Sea and
South China Sea
Geography - note: the major chokepoints are the
Bering Strait, Panama Canal, Luzon Strait, and the
Singapore Strait; the Equator divides the Pacific
Ocean into the North Pacific Ocean and the South
Pacific Ocean; dotted with low coral islands and
rugged volcanic islands in the southwestern Pacific
Ocean
Location: Southern Asia, bordering the Arabian Sea,
between India on the east and Iran and Afghanistan
on the west and China in the north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area:
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area - comparative: slightly less than twice the size
of California
Land boundaries:
total: 6,774 km
border counfr/es; Afghanistan 2,430 km, China 523
km, India 2,912 km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea; 12 NM
Climate: mostly hot, dry desert; temperate in
northwest; arctic in north
Terrain: flat Indus plain in east; mountains in north
and northwest; Balochistan plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen) 8,611 m
Natural resources: land, extensive natural gas
reserves, limited petroleum, poor quality coal, iron
ore, copper, salt, limestone
Land use:
arable land: 27%
permanent crops: ^%
permanent pastures: 6%
forests and woodland: 5%
ofber61%(1993 est.)
Irrigated land: 171 ,100 sq km (1993 est.)
Natural hazards: frequent earthquakes,
occasionally severe especially in north and west;
flooding along the Indus after heavy rains (July and
August)
Environment - current Issues: water pollution from
raw sewage, industrial wastes, and agricultural runoff;
limited natural fresh water resources; a majority of the
population does not have access to potable water;
deforestation; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation,
Nuclear Test Ban
Geography - note: controls Khyber Pass and Bolan
Pass, traditional invasion routes between Central Asia
and the Indian Subcontinent
Location: Oceania, group of islands in the North
Pacific Ocean, southeast of the Philippines
Geographic coordinates: 7 30 N, 134 30 E
Map references: Oceania
Area:
total: 458 sq km
land: 458 sq km
water: 0 sq km
Area - comparative: slightly more than 2.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 12 NM
extended fishing zone: 200 NM
territorial sea.-3NM
Climate: wet season May to November; hot and
humid
Terrain: varying geologically from the high,
mountainous main island of Babelthuap to low, coral
islands usually fringed by large barrier reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Ngerchelchauus 242 m
Natural resources: forests, minerals (especially
gold), marine products, deep-seabed minerals
389
Palau (continued)
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (June to December)
Environment - current issues: inadequate facilities
for disposal of solid waste; threats to the marine
ecosystem from sand and coral dredging, illegal
fishing practices, and overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the
Sea, Marine Dumping, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: includes World War II
battleground of Beliliou (Peleliu) and world-famous
rock islands; archipelago of six island groups totaling
over 200 Islands in the Caroline chain
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to American','9d629f7d9caa94e93c81aa09a58965b850175b3d98519af3d27081a0404fb60d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d5a05a513f11ab92cc444c018476ffe5161d94e2f11dc26a36ed52587b11666',2001,'JO','Jordan','geography',638,'Location: Middle East, northwest of Saudi Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area:
total: 92,300 sq km
/and; 91 ,971 sq km
water: 329 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
total: ^fi^9 km
border countries: Iraq 181 km, Israel 238 km, Saudi
Arabia 728 km, Syria 375 km. West Bank 97 km
Coastline: 26 km
Maritime claims:
territorial sea: 3 NM
Climate: mostly arid desert; rainy season in west
(November to April)
Terrain: mostly desert plateau in east, highland area
in west; Great Rift Valley separates East and West
Banks of the Jordan River
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Ma\\ Ram 1,734 m
Population: 5,153,378 (July 2001 est.)
Age structure:
0-14 years: 37.23% (male 980,345; female 938,081)
15-64 years: 59.44% (male 1 ,633,579; female
1,429,631)
65 years and over: 3.33% (male 84,81 5; female
86,927) (2001 est.)
Population growth rate: 3% (2001 est.)
Birth rate: 25.44 births/1 ,000 population (2001 est.)
Death rate: 2.62 deaths/1 ,000 population
(2001 est.)
Net migration rate: 7.18 migrant(s)/1,000
population (2001 est.)
Sex ratio:
at birth:]. 03 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: ]A4 male(s)/female
65 years and over: 0.98 male(s)/female
total population: ] .1 male(s)/female (2001 est.)
Infant mortality rate: 20.36 deaths/1,000 live births
(2001 est.)
Life expectancy at birth:
total population: 77.53 years
male: 75 A years
female: 80.12 years (2001 est.)
Total fertility rate: 3.29 children born/woman
(2001 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun; Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1 %, Armenian
1%
Religions: Sunni Muslim 92%, Christian 6%
(majority Greek Orthodox, but some Greek Catholics,
Roman Catholics, Syrian Orthodox, Coptic Orthodox,
Armenian Orthodox, and Protestant denominations).
other 2% (several small Shi''a Muslim and Druze
populations) (2000 est.)
Languages: Arabic (official), English widely
understood among upper and middle classes
Literacy:
definition: age 15 and over can read and write
total population: 86.6%
male: 93.4%
fema/e; 79.4% (1995 est.)','1229beef15794265369ed2d31403dee7a09407a510248cf11fe4d643a05c7167','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73bbf9994d035715538130ba49461a87e8e8c989116254e91b6c63e783b959f3',2001,'KZ','Kazakhstan','geography',646,'Location: Central Asia, northwest of China
Geographic coordinates: 48 00 N, 68 00 E
Map references; Commonwealth of Independent
States
Area:
tofa/; 2,71 7,300 sq km
/and.'' 2,669,800 sq km
water: 47,500 sq km
Area - comparative: slightly less than four times the
size of Texas
Land boundaries:
total: 12,012 km
border countries: Ohm ^ ,533 km, Kyrgyzstan 1,051
km, Russia 6,846 km, Turkmenistan 379 km,
Uzbekistan 2,203 km
Coastline: 0 km (landlocked); note - Kazakhstan
borders the Aral Sea, now split into two bodies of
water (1,070 km), and the Caspian Sea (1,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot summers,
arid and semiarid
Terrain: extends from the Volga to the Altai
Mountains and from the plains in western Siberia to
oases and desert in Central Asia
Elevation extremes:
lowest point: Vpadina Kaundy -132 m
highest point: Khan Tangiri Shyngy (Pik Khan-Tengri)
6,995 m
Natural resources: major deposits of petroleum,
natural gas, coal, iron ore, manganese, chrome ore,
nickel, cobalt, copper, molybdenum, lead, zinc,
bauxite, gold, uranium
Land use:
arable land: ^2%
permanent crops: ^^%
permanent pastures: 57%
forests and woodland: 4%
of/?er;16%(1996 est.)
Irrigated land: 22,000 sq km (1996 est.)
Natural hazards: earthquakes in the south,
mudslides around Almaty
Environment - current issues: radioactive or toxic
chemical sites associated with its former defense
industries and test ranges are found throughout the
country and pose health risks for humans and
animals; industrial pollution is severe in some cities;
because the two main rivers which flowed into the Aral
Sea have been diverted for irrigation, it is drying up
and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are
then picked up by the wind and blown into noxious
dust storms; pollution in the Caspian Sea; soil
pollution from overuse of agricultural chemicals and
salination from poor infrastructure and wasteful
irrigation practices
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: landlocked; Russia leases
approximately 6,000 sq km of territory enclosing the
Baykonur Cosmodrome','03f5006e45bd63ee4a7bce6dc649492e9b48a6653a183708728961ce94899aa4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bad198b9712ff0b9abd0bc1f9346b25f483c2d6f529e5146673058c4d80abc7b',2001,'KE','Kenya','geography',655,'Location: Eastern Africa, bordering the Indian
Ocean, between Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total: 582,650 sq km
land: 569,250 sq km
water; 13,400 sq km
Area ■ comparative: slightly more than twice the
size of Nevada
Land boundaries:
total: 3,446 km
border countries: Ethiopia 830 km, Somalia 682 km,
Sudan 232 km, Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: varies from tropical along coast to arid in
interior
Terrain: low plains rise to central highlands bisected
by Great Rift Valley; fertile plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources; gold, limestone, soda ash, salt
barites, rubies, fluorspar, garnets, wildlife, hydropower
Land use:
arable land: 7%
permanent crops: ^%
permanent pastures: 37%
forests and woodland: 30%
oteer; 25% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring drought in northern and
eastern regions; flooding during rainy seasons
Environment - current issues: water pollution from
urban and industrial wastes; degradation of water
quality from increased use of pesticides and fertilizers;
water hyacinth infestation in Lake Victoria;
deforestation; soil erosion; desertification; poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the Kenyan Highlands comprise
one of the most successful agricultural production
regions in Africa; glaciers on Mt. Kenya; unique
physiography supports abundant and varied wildlife of
scientific and economic value
Location: Oceania, reef in the North Pacific Ocean,
about one-half of the way from Hawaii to American','faa518d342833b548474e210c2fc7f421760ebc4e59dfce0ae46d14164e0369f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c4cca2e78df3d8d50c341d3185f661a714cc7df3fd034d6f52277c968c133dd',2001,'WS','Samoa','geography',663,'Geographic coordinates: 6 24 N, 162 24 W
Map references: Oceania
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area - comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical, but moderated by prevailing winds
Terrain: low and nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 1 m
Natural resources: terrestrial and aquatic wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1996)
270
Kingman Reef (continued)
Natural hazards: wet or awash most of the time,
maximum elevation of about 1 meter makes Kingman
Reef a maritime hazard
Environment - current issues: none
Geography - note: barren coral atoll with deep
interior lagoon; closed to the public
Geographic coordinates: 5 52 N, 162 06 W
Map references: Oceania
Area:
tofa/;11.9sq km
land: 1 1 .9 sq km
water: 0 sq km
Area - comparative: about 20 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 14.5 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: equatorial, hot, and very rainy
Terrain: very low
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Natural resources: terrestrial and aquatic wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
391
Palmyra Atoll (continued)
forests and woodland: 1 00%
other: 0%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current Issues: NA
Geography - note: about 50 islets covered with
dense vegetation, coconut trees, and balsa-like trees
up to 30 meters tall
Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 13 35 S, 172 20 W
Map references: Oceania
Area:
total: 2,860 sq km
/and; 2,850 sq km
water: ^0s(\\ km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea; 12 NM
Climate: tropical; rainy season (October to March),
dry season (May to October)
Terrain: narrow coastal plain with volcanic, rocky,
rugged mountains in interior
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili 1 ,857 m
Natural resources: hardwood forests, fish,
hydropower
Land use:
arad/e /and; 19%
permanent crops: 24%
permanent pastures: 0%
South Pacific Ocean
forests and woodland: 47%
other: 10%
Irrigated land: NAsqkm
Natural hazards: occasional typhoons; active
volcanism
Environment ■ current issues: soil erosion
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements','c7cb172d293d8b7dcd938f1e05252c2cbd26c0055f7b5e04cdd1a7f666f10757','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f052be8c2c6c58d7d72fad8298979614852c04596bf35d607464cfb19b29d19',2001,'KG','Kyrgyzstan','geography',671,'Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Commonwealth of Independent
States
Area:
fofa/; 198,500 sq km
/anof;191,300 sq km
water: 7,200 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries:
tofa/.'' 3,878 km
border coanfr/es.'' China 858 km, Kazakhstan 1,051
km, Tajikistan 870 km, Uzbekistan 1 ,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan;
subtropical in southwest (Fergana Valley); temperate
in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys
and basins encompass entire nation
Elevation extremes:
lowest point: Kara-Darya 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydropower;
significant deposits of gold and rare earth metals;
locally exploitable coal, oil, and natural gas; other
deposits of nepheline, mercury, bismuth, lead, and
zinc
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 44%
forests and woodland: 4%
other 45% (1993 est.)
note: Kyrgyzstan has the world''s largest natural
growth walnut forest
Irrigated land: 9,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: water pollution;
many people get their water directly from
contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil
salinity from faulty irrigation practices
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
Location: Southeastern Asia, northeast of Thailand,
west of Vietnam
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
Area - comparative: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km,
China 423 km, Thailand 1 ,754 km, Vietnam 2,130 km
Coastline: 0 km (landlocked)
Maritime ciaims: none (landlocked)
Climate: tropical monsoon; rainy season (May to
November); dry season (December to April)
Terrain: mostly rugged mountains; some plains and
plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower, gypsum,
tin, gold, gemstones
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
of/ier; 40% (1993 est.)
Laos (continued)
Irrigated land: 1 ,250 sq km (1993 est.)
note: rainy season irrigation - 2,169 sq km; dry
season irrigation - 750 sq km (1998 est.)
Natural hazards: floods, droughts, and blight
Environment - current issues: unexploded
ordnance; deforestation; soil erosion; a majority of the
population does not have access to potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Marine Dumping, Nuclear Test Ban. Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked','0f1c04d36e1a3ed280eb69d6e0a251c11ed673c1042e02adfb30d4b4bed1debe','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e29cb698067b0013cdc35bb130a0b4fd6268506905aeff14c415f6d715620179',2001,'LV','Latvia','geography',680,'Location: Eastern Europe, bordering the Baltic Sea,
between Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area:
total: 64,589 sq km
land: 64,589 sq km
water: 0 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: km
border counfr/es; Belarus 141 km, Estonia 339 km,
Lithuania 453 km, Russia 217 km
Coastline: 531 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Gaizinkalns 31 2 m
Natural resources: minimal; amber, peat,
limestone, dolomite, hydropower, arable land
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 1 3%
forests and woodland: 46%
ofber; 14% (1993 est.)
Irrigated land: 160 sq km (1993 est.)
Natural hazards; NA
Environment - current issues: air and water
pollution because of a lack of waste conversion
equipment; Gulf of Riga and Daugava River heavily
polluted; contamination of soil and groundwater with
chemicals and petroleum products at military bases
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: A\\r Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol','1d3204c81a7f92feb007b43e49e145be38014df82cf3b66623b34e335e0b8d18','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d79434d167845a9b3d6cedb8d65c593a8e2e592297e2a320c0b4341526fcd984',2001,'LB','Lebanon','geography',689,'Location: Middle East, bordering the Mediterranean
Sea, between Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
Area - comparative: about 0,7 times the size of
Connecticut
Land boundaries;
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 NM
Climate: Mediterranean; mild to cool, wet winters
with hot, dry summers; Lebanon mountains
experience heavy winter snows
Terrain: narrow coastal plain; Al BIqa'' (Bekaa Valley)
separates Lebanon and Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Qurnat as Sawda'' 3,088 m
Natural resources: limestone, iron ore, salt,
water-surplus state in a water-deficit region, arable land
Land use;
arable land: 13%
permanent crops: 9%
permanent pastures: 1 %
forests and woodland: 8%
ote64%(1996 est.)
Irrigated land: 860 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment - current issues: deforestation; soil
erosion; desertification; air pollution in Beirut from
vehicular traffic and the burning of industrial wastes;
pollution of coastal waters from raw sewage and oil
spills
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Marine Dumping, Marine Life Conservation
Geography - note: Nahr al Litani only major river in
Near East not crossing an international boundary;
rugged terrain historically helped isolate, protect, and
develop numerous factional groups based on religion,
clan, and ethnicity
Location: Southern Africa, an enclave of South
Africa
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot,
wet summers
Terrain: mostly highland with plateaus, hills, and
mountains
Elevation extremes:
lowest point: \\mc\\^\\on of the Orange and Makhaleng
Rivers 1 ,400 m
highest point: Jhabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing
land, some diamonds and other minerals
Land use:
arable land: ^^%
permanent crops: 0%
permanent pastures: 66%
forests and woodland: 0%
ofher; 23% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current issues: population pressure
forcing settlement in marginal areas results in
overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls,
stores, and redirects water to South Africa
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Endangered Species, Law of
the Sea, Marine Dumping
Geography - note: landlocked; surrounded by','e7ddfb36b80e91dad43de19e3bce567730db19c4c31ff6d0eac293bfd36b5fd6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14a18810ba3fa79cde311ae553dac8971e483f10118233596e609e58fa153fbd',2001,'LR','Liberia','geography',705,'Location: Western Africa, bordering the North
Atlantic Ocean, between Cote d''Ivoire and Sierra
Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 1 1 1 ,370 sq km
land: 96,320 sq km
wafer.'' 15,050 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716
km, Sierra Leone 306 km
Coastline; 579 km
Maritime claims:
territorial sea: 200 NM
Climate: tropical; hot, humid; dry winters with hot
days and cool to cold nights; wet, cloudy summers
with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to
rolling plateau and low mountains in northeast
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1 ,380 m
Natural resources: iron ore, timber, diamonds, gold,
hydropower
Land use:
arable land: 1%
permanent crops: 3%
permanent pastures: 59%
forests and woodland: 18%
of/?er 19% (1993 est.)
Irrigated land: 20 sq km (1 993 est.)
Natural hazards: dust-laden harmattan winds blow
from the Sahara (December to March)
Environment - current issues: tropical rain forest
subject to deforestation; soil erosion; loss of
biodiversity; pollution of coastal waters from oil
residue and raw sewage
Environment - international agreements:
party to; Biodiversity, Desertification, Endangered
Species, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Climate Change,
Environmental Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation','b3b9b217c2dec8a790111f288e140bd498ed5543e8a4d7570a3bd1dc744a49ba','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bede86c3e7b1bfe7fe4580c45bc02c6f726f6b0bdd489b0edf41692b5feee556',2001,'LY','Libya','geography',713,'Location: Northern Africa, bordering the
Mediterranean Sea, between Egypt and Tunisia
Geographic coordinates; 25 00 N, 17 00 E
Map references: Africa
Area;
tote/; 1,759,540 sq km
/and; 1,759,540 sq km
water: 0 sq km
Area ■ comparative: slightly larger than Alaska
Land boundaries:
tote/; 4,383 km
border countoes; Algeria 982 km, Chad 1,055 km,
Egypt 1,150 km, Niger 354 km, Sudan 383 km,
Tunisia 459 km
Coastline: 1,770 km
Maritime claims:
territorial sea: 12 NM
note: Gulf of Sidra closing line - 32 degrees, 30
minutes north
Climate: Mediterranean along coast; dry, extreme
desert interior
Terrain: mostly barren, flat to undulating plains,
plateaus, depressions
294
Libya (continued)
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use:
arable land: ^%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
oto;91%(1993 est.)
Irrigated land: 4,700 sq km (1993 est.)
Natural hazards: hot, dry, dust-laden ghibli is a
southern wind lasting one to four days in spring and
fall; dust storms, sandstorms
Environment - current issues: desertification; very
limited natural fresh water resources; the Great
Manmade River Project, the largest water
development scheme in the world, is being built to
bring water from large aquifers under the Sahara to
coastal cities
Environment - Internationai agreements:
party to: Climate Change, Desertification, Marine
Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Biodiversity, Law of the Sea,
Nuclear Test Ban
Location: Central Europe, between Austria and','efd2ea5bf5cc400ac92720b6a1f126bc520aac42ff6b98ca4ca2c52ea4d922ac','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4984981d122139f2a783aa9dab471a7b1564f74bdf01154fdc3ca1e2f17ca9f2',2001,'CH','Switzerland','geography',721,'Geographic coordinates: 47 10 N, 9 32 E
Map references: Europe
Area:
toto/:160 sq km
/anc/;160 sq km
water: 0 sq km
Area - comparative: about 0.9 times the size of
Washington, DC
Land boundaries:
total: 76 km
border countries: Austria 35 km, Switzerland 41 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: continental; cold, cloudy winters with
frequent snow or rain; cool to moderately warm,
cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine
Valley in western third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Grauspitz 2,599 m
Natural resources; hydroelectric potential, arable
land
Location: Eastern Europe, bordering the Baltic Sea,
between Latvia and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area:
total: 65,200 sq km
/and; 65,200 sq km
water: 0 sq km
Area - comparative: slightly largerthan West Virginia
Land boundaries:
total: 1,273 km
border countries: Belarus 502 km, Latvia 453 km,
Poland 91 km, Russia (Kaliningrad) 227 km
Coastline: 99 km
Maritime claims:
territorial sea: 12 HU\\
Climate: transitional, between maritime and
continental; wet, moderate winters and summers
Terrain: lowland, many scattered small lakes, fertile
soil
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Juozapines/Kalnas 292 m
Natural resources: peat, arable land
Land use:
arable land: 39%
permanent crops: 9%
permanent pastures: 6%
forests and woodland: 31 %
other: 15% [2001 est.)
Irrigated land: 430 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: contamination of
soil and groundwater with petroleum products and
chemicals at military bases
Environment - international agreements:
party to: Biodiversity, Climate Change, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Location: Central Europe, east of France, north of','ece479b17005fb3f228a2011022ee8d198de3fa7e7e6f276c6ffea18d6bcaea7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99273f96c8cf99995fec4ad00d24925440b03c648d6c89b07de8892082a52aad',2001,'MG','Madagascar','geography',736,'Location: Southern Africa, island in the Indian
Ocean, east of Mozambique
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area:
total: 587,040 sq km
/anof; 581,540 sq km
water: 5,500 sq km
Area - comparative: slightly less than twice the size
of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or 100 NM from the
2,500-m deep isobath
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical along coast, temperate inland, arid
in south
Terrain: narrow coastal plain, high plateau and
mountains in center
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal,
bauxite, salt, quartz, tar sands, semiprecious stones,
mica, fish, hydropower
Land use:
arable land: 4%
permanent crops: ''\\%
permanent pastures: 41 %
forests and woodland: 40%
other: 14% (1993 est.)
Irrigated land: 1 0,870 sq km (1 993 est.)
Natural hazards: periodic cyclones
Environment - current issues: soil erosion results
from deforestation and overgrazing; desertification;
surface water contaminated with raw sewage and
other organic wastes; several species of flora and
fauna unique to the island are endangered
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: world''s fourth-largest island;
strategic location along Mozambique Channel','7f45e808e725746a49ed10d5952bfdb1080fb5cf34ce7a600c78d8b5016b2e05','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a933c8112fe138d09bdb70b53deedb7caee5dfd1064645f9b6f804241c9f869',2001,'MW','Malawi','geography',744,'Location: Southern Africa, east of Zambia
Geographic coordinates: 13 30 S, 34 00 E
Map references: Africa
Area:
fofa/.- 11 8,480 sq km
land: 94,080 sq km
water: 24,400 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 2,881 km
border countries: Mozambique 1 ,569 km, Tanzania
475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: sub-tropical; rainy season (November to
May); dry season (May to November)
Terrain: narrow elongated plateau with rolling plains,
rounded hills, some mountains
Elevation extremes:
lowest point: junction of the Shire River and
international boundary with Mozambique 37 m
highest point: Sapitwa 3,002 m
Natural resources: limestone, arable land,
hydropower, unexploited deposits of uranium, coal,
and bauxite
Land use:
arable land: 34%
permanent crops: 0%
permanent pastures: 20%
forests and woodland: 39%
other: 7% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation; land
degradation; water pollution from agricultural runoff,
sewage, industrial wastes; siltation of spawning
grounds endangers fish populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: landlocked','dd5d8a05725396c0ba6f4595d2da61e98065d444de2c0e67c150c9221fb6c2b3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d9192ee857b6f456c2b40bd5c9a0365e420a402d46f4416e5616f977294378',2001,'PH','Philippines','geography',754,'Location: Southeastern Asia, peninsula and
northern one-third of the island of Borneo, bordering
Indonesia and the South China Sea, south of Vietnam
Geographic coordinates: 2 30 N, 1 12 30 E
Map references: Southeast Asia
Area:
total: 329,750 sq km
land: 328,550 sq km
water: 1 ,200 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 2,669 km
border countries: Brunei 381 km, Indonesia 1 ,782 km,
Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068 km,
East Malaysia 2,607 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation; specified boundary in the South China
Sea
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; annual southwest (April to
October) and northeast (October to February)
monsoons
Terrain: coastal plains rising to hills and mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Gumng Kinabalu 4,100 m
arable land: 3%
permanent crops: 12%
permanent pastures: 0%
forests and woodland: 68%
other: 17% (1993 est.)
Irrigated land: 2,941 sq km (1998 est.)
Natural hazards: flooding, landslides
Environment - current issues: air pollution from
industrial and vehicular emissions; water pollution
from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
Environment - International agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: CWmaie Change-Kyoto
Protocol
Geography - note: strategic location along Strait of
Malacca and southern South China Sea
Geographic coordinates: 16 30 N, 1 12 00 E
Map references: Southeast Asia
Area:
total: NA sq km
land: NA sq km
water: 0 sq km
Area - comparative: NA
Land boundaries: 0 km
Coastiine: 518 km
Maritime ciaims: NA
Climate: tropical
Terrain: mostly low and flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: ur\\r\\ame6 location on Rocky Island 14
m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
Natural hazards: typhoons
Environment - current issues: NA
Location: Central South America, northeast of
Location: Southeastern Asia, archipelago between
the Philippine Sea and the South China Sea, east of
Vietnam
Geographic coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area:
total: 300,000 sq km
/and; 298,170 sq km
wafer; 1,830 sq km
Area - comparative: slightly larger than Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims:
continental shelf: to depth of exploitation
exclusive economic zone: 200 NM
territorial sea: irregular polygon extending up to 100
NM from coastline as defined by 1898 treaty; since
late 1 970s has also claimed polygonal-shaped area in
South China Sea up to 285 NM in breadth
Climate: tropical marine; northeast monsoon
(November to April); southwest monsoon (May to
October)
Terrain: mostly mountains with narrow to extensive
coastal lowlands
Elevation extremes:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel,
cobalt, silver, gold, salt, copper
Land use:
arable land: 19%
permanent crops: 12%
permanent pastures: 4%
forests and woodland: 46%
other; 19% (1993 est.)
Irrigated land: 15,800 sq km (1993 est.)
Natural hazards: astride typhoon belt, usually
affected by 1 5 and struck by five to six cyclonic storms
per year; landslides; active volcanoes; destructive
earthquakes; tsunamis
Environment - current issues: uncontrolled
deforestation in watershed areas; soil erosion; air and
water pollution in Manila; increasing pollution of
coastal mangrove swamps which are important fish
breeding grounds
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
Geographic coordinates: 8 38 N, 1 1 1 55 E
Map references: Southeast Asia
Area:
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so Islets, coral reefs, and sea
mounts scattered over an area of nearly 410,000 sq
km of the central South China Sea
Area ■ comparative: NA
Land boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
Climate: tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay 4 m
Natural resources: fish, guano, undetermined oil
and natural gas potential
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
Natural hazards: typhoons; serious maritime hazard
because of numerous reefs and shoals
Environment - current issues: NA
Geography - note: strategically located near several
primary shipping lanes in the central South China Sea;
includes numerous small islands, atolls, shoals, and
coral reefs
P e 0 p i e
Population: no indigenous inhabitants
note; there are scattered garrisons occupied by
personnel of several claimant states (July 2001 est.)','c5d75f452893e512056582b4fc00f53ed4d5850580e66f741e724f1159aa574b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28364fbe03a339b8dbff8638035425da51c5ce0b85e9f652ec20d40011ca38be',2001,'MV','Maldives','geography',759,'Location: Southern Asia, group of atolls in the Indian
Ocean, south-southwest of India
Geographic coordinates: 3 15 N, 73 00 E
Map references: Asia
Area:
total: 300 sq km
land: 300 sq km
water: 0 sq km
Area - comparative: about 1 .7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; hot, humid; dry, northeast
monsoon (November to March); rainy, southwest
monsoon (June to August)
Terrain: flat, with white sandy beaches
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Wilingili island in
the Addu Atoll 2.4 m
Natural resources; fish
Land use:
arable land: ^0%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 3%
other: S^%(^993 est.)
Irrigated land: NAsqkm
Natural hazards: low level of islands makes them
very sensitive to sea level rise
Environment - current issues: depletion of
freshwater aquifers threatens water supplies; global
warming and sea level rise; coral reef bleaching
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: 1 ,1 90 coral islands grouped into
26 atolls (200 inhabited islands, plus 80 islands with
tourist resorts); archipelago of strategic location
astride and along major sea lanes in Indian Ocean','4cd14a6fc82463cce6040c484e6ec217689a90e1bb35b955a44b285c1721a31d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa2a5d73fb09c6fefa15ccc2b4947f7ba5ba596f80104054b601630d3f17abea',2001,'ML','Mali','geography',767,'Location: Western Africa, southwest of Algeria
Geographic coordinates: 17 00 N, 4 00 W
Map references: Africa
Area:
total: 1 .24 million sq km
land: 1 .22 million sq km
water: 20,000 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 7,243 km
border counf/''/es; Algeria 1,376 km, Burkina Faso
1 ,000 km, Guinea 858 km, Cote d''Ivoire 532 km,
Mauritania 2,237 km, Niger 821 km, Senega! 419 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to arid; hot and dry February to
June; rainy, humid, and mild June to November; cool
and dry November to February
Terrain: mostly flat to rolling northern plains covered
by sand; savanna in south, rugged hills in northeast
Elevation extremes:
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1 ,1 55 m
Natural resources: gold, phosphates, kaolin, salt,
limestone, uranium, hydropower
note: bauxite, iron ore, manganese, tin, and copper
deposits are known but not exploited
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 6%
other: 07% (^m est.)
Irrigated land: 780 sq km (1993 est.)
Natural hazards: hot, dust-laden harmattan haze
common during dry seasons; recurring droughts
Environment - current Issues: deforestation; soil
erosion; desertification; inadequate supplies of
potable water; poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Geography - note: landlocked','751eb16ef7ee66a2f1ebe397dbf28591e9df4af7a1a34d05c0fbb41d7ef79333','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2da60e54106d769bfde5bdee2e38b46b93b3c9714c0cbb88ad382aef90c83d6c',2001,'MT','Malta','geography',775,'Location: Southern Europe, islands in the
Mediterranean Sea, south of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area:
total: 318 sq km
land: 318 sq km
water: 0 sq km
Area ■ comparative: slightly less than twice the size
of Washington, DC
Land boundaries: 0 km
Coastline: 196.8 km (does not include 56.01 km for
the island of Gozo)
Maritime claims:
contiguous zone: 24 NM
continental shelf : 200‘m depth or to the depth of
exploitation
exclusive fishing zone: 25 NM
territorial sea: 12 NM
Climate: Mediterranean with mild, rainy winters and
hot, dry summers
Terrain: mostly low, rocky, flat to dissected plains;
many coastal cliffs
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Ta''Dmejrek 253 m (near Dingli)
Natural resources: limestone, salt, arable land
319
Malta (continued)
Land use:
arable land: 32%
permanent crops: 3%
permanent pastures: 0%
forests and woodland: 4%
of/?er; 61% (2000 est.)
Irrigated land: 1 1 .45 sq km (2000 est.)
Natural hazards: NA
Environment - current issues: very limited natural
fresh water resources; increasing reliance on
desalination
Environment - International agreements:
party to: Mr Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: C\\\\rr\\a\\e Change-Kyoto
Protocol
Geography - note: the country comprises an
archipelago, with only the three largest islands (Malta,
Ghawdex or Gozo, and Kemmuna or Comino) being
inhabited: numerous bays provide good harbors;
Malta and Tunisia are discussing the commercial
exploitation of the continental shelf between their
countries, particularly for oil exploration
Location: Western Europe, island in the Irish Sea,
between Great Britain and Ireland
Geographic coordinates: 54 15 N, 4 30 W
Map references: Europe
Area:
total: 572 sq km
land: 572 sq km
water: 0 sq km
Area ■ comparative: slightly more than three times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims;
exclusive fishing zone: 12 NM
fomfor/a/ sea; 12 NM
Climate: cool summers and mild winters; temperate;
overcast about one-third of the time
Terrain: hills in north and south bisected by central
valley
Elevation extremes;
lowest point: Irish Sea 0 m
highest point: SnaeieW 621 m
Natural resources: none
Land use:
arable land: 9%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 6%
other: 39% (includes 25% mountain and heathland)
Irrigated land: Osqkm
Natural hazards: NA
321
Man, Isle of (continued)
Environment - current Issues: waste disposal
(both household and industrial); transboundary air
pollution
Geography - note: one small islet, the Calf of Man,
lies to the southwest, and is a bird sanctuary','93ce57aaa758886b2d8d1cf2210c6176a01fe24dec7c2fe67f01774527aa1202','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e96514f0668d4c69428c920db63d70e6ce75504eaeacb6542e2667fd4671cf4f',2001,'MH','Marshall Islands','geography',783,'Location: Oceania, group of atolls and reefs in the
North Pacific Ocean, about one-half of the way from
Hawaii to Papua New Guinea
Geographic coordinates; 9 00 N, 168 00 E
Map references; Oceania
Area:
fofa/; 181 .3 sq km
/ancf; 181 .3 sq km
water: 0 sq km
note: includes the atolls of Bikini, Enewetak, and
Kwajalein
Area - comparative: about the size of Washington,
DC
Land boundaries: 0 km
Coastline: 370.4 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: wet season from May to November; hot and
humid; islands border typhoon belt
Terrain: low coral limestone and sand islands
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Natural resources: phosphate deposits, marine
products, deep seabed minerals
Land use;
arable land: 0%
permanent crops: 60%
permanent pastures: 0%
forests and woodland: 0%
other: 40%
Irrigated land: NAsqkm
Natural hazards: occasional typhoons
Environment - current issues: inadequate
supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: two archipelagic island chains of
30 atolls and 1,152 islands; Bikini and Enewetak are
former US nuclear test sites; Kwajalein, the famous
World War II battleground, is now used as a US
missile test range','9ff59de6cdb0dcaf28e27e15f8f4a6cb55895874cb70566c46b5c118ba8752f2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4187f9f772f825b802fba805be705982ccadee209859124f3ffc40631318d3d2',2001,'MQ','Martinique','geography',791,'Location: Caribbean, island in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates: 14 40 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 1,100 sq km
land: 1 ,060 sq km
water: 40 sq km
Area - comparative; slightly more than six times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea.'' 12 NM
Climate: tropical; moderated by trade winds; rainy
season (June to October); vulnerable to devastating
cyclones (hurricanes) every eight years on average;
average temperature 17.3 degrees C; humid
Terrain: mountainous with indented coastline;
dormant volcano
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1 ,397 m
Natural resources; coastal scenery and beaches,
cultivable land
Land use:
arable land: 8%
permanent crops: Q%
permanent pastures: 17%
forests and woodland: 44%
other: 23% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: hurricanes, flooding, and volcanic
activity (an average of one major natural disaster
every five years)
Environment - current issues; NA
Location: Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland
(Canada)
Geographic coordinates: 46 50 N, 56 20 W
Map references: North America
Area:
total: 2A2 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the Saint Pierre
and the Miquelon groups
Area - comparative; 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: cold and wet, with much mist and fog;
spring and autumn are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 4%
of/7er;83% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: persistent fog throughout the year
can be a maritime hazard
Environment - current issues: NA
Geography - note: vegetation scanty','6f1191fdd8ce9d349d10784717908b76b08b7579fbfd103bca59fb33e6f01957','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f816e2fc3bb3be70a4ab3caad991701855fbc6c1064828564a7403d5a99a6bb4',2001,'MR','Mauritania','geography',795,'Location: Northern Africa, bordering the North
Atlantic Ocean, between Senegal and Western
Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area:
total: 1 ,030,700 sq km
/and.'' 1,030,400 sq km
water: 300 sq km
Area - comparative; slightly larger than three times
the size of New Mexico
Land boundaries;
total: 5,074 km
border counfr/es; Algeria 463 km, Mali 2,237 km,
Senegal 813 km, Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
contiguous zone: 24 NM
continental shelf : 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara;
some central hills
Elevation extremes:
lowest point: Sebkha de Ndrhamcha -3 m
highest point: Kediet Ijill 910 m
Natural resources: iron ore, gypsum, fish, copper,
phosphate, diamonds, gold
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 38%
forests and woodland: 4%
of/?er;58%(1993 est.)
Irrigated land: 490 sq km (1993 est.)
Natural hazards: hot, dry, dust/sand-laden sirocco
wind blows primarily in March and April; periodic
droughts
Environment - current issues: overgrazing,
deforestation, and soil erosion aggravated by drought
are contributing to desertification; very limited natural
fresh water resources away from the Senegal which is
the only perennial river
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: most of the population
concentrated in the cities of Nouakchott and
Nouadhibou and along the Senegal River in the
southern part of the country','0fdb06f33fe38d18816c3eec02ffd6fe49806f0afb0f23bd5714d60fe71e2d0a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b863147e0d163c38030bf28fd39ddc059cd299fd0cd591fecf9cbaef40f4741d',2001,'MU','Mauritius','geography',804,'Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 20 17 S, 57 33 E
Map references: World
Area:
total: 1 ,860 sq km
land: 1 ,850 sq km
water lOsq km
note: includes Agalega Islands, Cargados Carajos
Shoals (Saint Brandon), and Rodrigues
Area - comparative: almost 1 1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 177 km
Maritime claims:
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate; tropical, modified by southeast trade winds;
warm, dry winter (May to November); hot, wet, humid
summer (November to May)
Terrain: small coastal plain rising to discontinuous
mountains encircling central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Piton 828 m
329
Mauritius (continued)
Natural resources: arable land, fish
Land use:
arable land: 49%
permanent crops: 3%
permanent pastures: 3%
forests and woodland: 22%
other: 23% (^993 esl)
Irrigated land: 170 sq km (1993 est.)
Natural hazards: cyclones (November to April);
almost completely surrounded by reefs that may pose
maritime hazards
Environment - current issues: water pollution,
degradation of coral reefs
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements','b7d988cdae8fb83ad04cd74c36131f926a88ba2a7981506529a5acb82b33908c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e8cb70780a9945010b1137ff216a2c8947e3a97edce22ef00997447b5d3693e',2001,'YT','Mayotte','geography',813,'Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from northern
Madagascar to northern Mozambique
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area:
total: 374 sq km
land: 374 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; marine; hot, humid, rainy season
during northeastern monsoon (November to May); dry
season is cooler (May to November)
Terrain: generally undulating, with deep ravines and
ancient volcanic peaks
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: cyclones during rainy season
331
Mayotte (continued)
Environment - current issues: NA
Geography - note: part of Comoro Archipelago; 18
islands','24091263f34207ad048ceec75be2cdf6a243912c0821ae78d0d36b623d76f97d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609b63f3be569e98a1dd2fa872816f8781c5e8bf4bb7d9c2802a60f3f19373b3',2001,'US','United States','geography',823,'Location: Middle America, bordering the Caribbean
Sea and the Gulf of Mexico, between Belize and the
US and bordering the North Pacific Ocean, between
Guatemala and the US
Geographic coordinates: 23 00 N, 102 00 W
Map references: North America
Area:
total: 1,972,550 sq km
land: 1 ,923,040 sq km
water: 49,510 sq km
Area - comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 4,538 km
border countries: Belize 250 km, Guatemala 962 km,
US 3,326 km
Coastline: 9,330 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low coastal plains;
high plateaus; desert
Elevation extremes:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper, gold,
lead, zinc, natural gas, timber
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 39%
forests and woodland: 26%
other: 22% est.)
Irrigated land: 61 ,000 sq km (1993 est.)
Natural hazards; tsunamis along the Pacific coast,
volcanoes and destructive earthquakes in the center
and south, and hurricanes on the Gulf of Mexico and
Caribbean coasts
Environment ■ current issues: natural fresh water
resources scarce and polluted in north, inaccessible
and poor quality in center and extreme southeast; raw
sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion;
desertification; serious air pollution in the national
capital and urban centers along US-Mexico border
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on southern
border of US
Location: Oceania, island group in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
Location: North America, bordering both the North
Atlantic Ocean and the North Pacific Ocean, between
Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total: 9,629,091 sq km
/anc/.‘ 9,158,960 sq km
water 470,1 31 sq km
note: includes only the 50 states and District of
Columbia
Area - comparative: about one-half the size of
Russia; about three-tenths the size of Africa; about
one-half the size of South America (or slightly larger
than Brazil); slightly larger than China; about two and
one-half times the size of Western Europe
Land boundaries:
total: 12,248 km
border countries: Canada 8,893 km (including 2,477
km with Alaska), Cuba 29 km (US Naval Base at
Guantanamo Bay), Mexico 3,326 km
note: Guantanamo Naval Base is leased by the US
and thus remains part of Cuba
Coastline: 19,924 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: not specified
exclusive economic zone: 200 NM
territorial sea: 12 NM
Ciimate: mostly temperate, but tropical in Flawaii and
Florida, arctic in Alaska, semiarid in the great plains
west of the Mississippi River, and arid in the Great
Basin of the southwest; low winter temperatures in the
northwest are ameliorated occasionally in January
and February by warm Chinook winds from the eastern
slopes of the Rocky Mountains
Terrain: vast central plain, mountains in west, hills
and low mountains in east; rugged mountains and
broad river valleys in Alaska; rugged, volcanic
topography in Hawaii
Elevation extremes:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,1 94 m
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, bauxite, gold,
iron, mercury, nickel, potash, silver, tungsten, zinc,
petroleum, natural gas, timber
Land use:
arable land: 19%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 30%
other: 20% {1993 est.)
Irrigated land: 207,000 sq km (1993 est.)
Natural hazards: tsunamis, volcanoes, and
earthquake activity around Pacific Basin; hurricanes
along the Atlantic and Gulf of Mexico coasts; tornadoes
in the midwest and southeast; mud slides in California;
forest fires in the west; flooding; permafrost in northern
Alaska, a major impediment to development
Environment - current issues: air pollution
resulting in acid rain In both the US and Canada; the
US is the largest single emitter of carbon dioxide from
the burning of fossil fuels; water pollution from runoff
530
United States (continued)
of pesticides and fertilizers; very limited natural fresh
water resources in much of the western part of the
country require careful management; desertification
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Climate Change, Desertification, Endangered
Species, Environmental Modification, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change-Kyoto
Protocol, Hazardous Wastes
Geography - note: world''s third-largest country
(after Russia and Canada)','61f983f7f072526186da5afe482bb2a9c80987209f43e19cf15485d9e4362eca','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bff71a7e7dfd0d13ad9fade68356f219cdb4253d5027ac09177dc876d43f054',2001,'MC','Monaco','geography',831,'Location: Western Europe, bordering the
Mediterranean Sea on the southern coast of France,
near the border with Italy
Geographic coordinates: 43 44 N, 7 24 E
Map references: Europe
Area:
total: 1.95 sq km
land: 1.95 sq km
water: 0 sq km
Area ■ comparative: about three times the size of
The Mall in Washington, DC
Land boundaries:
total: 4.4 km
border countries: France 4.4 km
Coastline: 4.1 km
Maritime claims:
territorial sea: 12 NM
Climate: Mediterranean with mild, wet winters and
hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (urban area)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current Issues: NA
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: second smallest independent
state in the world (after Holy See); almost entirely urban','b1d0e6b774678664b7786510bcf63bbcc141bbf2725033f3f5a07e04a148240f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8ec69c99e8b152c140f49bbf4b4c0c7616e441ab17c26fcfadb686095bb40a4',2001,'MS','Montserrat','geography',838,'Location: Caribbean, island in the Caribbean Sea,
southeast of Puerto Rico
Geographic coordinates: 16 45 N, 62 12 W
Map references: Central America and the
Caribbean
Area:
total: 100 sq km
land: 100 sq km
wafer; Osq km
Area - comparative: about 0.6 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 3 HU
Climate: tropical; little daily or seasonal temperature
variation
Terrain: volcanic islands, mostly mountainous, with
small coastal lowland
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chances Peak (in the Soufriere Hills)
914 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 0%
permanent pastures: 1 0%
forests and woodland: 40%
off?er; 30% (1993 est.)
Irrigated land: NAsqkm
345
Montserrat (continued)
Natural hazards: severe hurricanes (June to
November): volcanic eruptions (full-scale eruptions of
the Soufriere Hills volcano occurred during 1996-97)
Environment ■ current issues: land erosion occurs
on slopes that have been cleared for cultivation','59b2fde0cc167516d7ccb8b466d9d0062f6ae7dd0bba17e7d961171e4df99d23','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3fb67db0a046a8cfedf7eaa2fdaced98dbe7365e197d71e0567fd538e37a768',2001,'MA','Morocco','geography',846,'Location: Northern Africa, bordering the North
Atlantic Ocean and the Mediterranean Sea, between
Algeria and Western Sahara
Geographic coordinates: 32 00 N, 5 00 W
Map references: Africa
Area:
tofa/.'' 446,550 sq km
/and.'' 446,300 sq km
water: 250 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 2, OM. 9 km
border countries: Algeria 1 ,559 km. Western Sahara
443 km, Spain (Ceuta) 6.3 km, Spain (Melilfa) 9.6 km
Coastline: 1 ,835 km
Maritime claims:
contiguous zone: 24
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: Mediterranean, becoming more extreme in
the interior
Terrain: northern coast and interior are mountainous
with large areas of bordering plateaus, intermontane
valleys, and rich coastal plains
Elevation extremes:
lowest point: Sebkha Tah -55 m
highest point: Jbel Toubkal 4,1 65 m
Natural resources: phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use:
arable land: 21%
permanent crops: 1%
permanent pastures: 47%
forests and woodland: 20%
ofher; 11% (1993 est.)
Irrigated land: 12,580 sq km (1993 est.)
Natural hazards: northern mountains geologically
unstable and subject to earthquakes; periodic
droughts
Environment - current issues: land degradation/
desertification (soil erosion resulting from farming of
marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollution of coastal
waters
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Environmental Modification,
Law of the Sea
Geography - note: strategic location along Strait of','017c323a5946e2fde096fe08c93f9cf89b4bc5417026a94a98336e5ab6372eab','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d26937cd282d5a6503efd029683521f3c93f137a56381667b7f6bc825cdbd17f',2001,'NA','Namibia','geography',848,'Location: Southern Africa, bordering the South
Atlantic Ocean, between Angola and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area:
total: 825,41 8 sq km
land: 825,41 8 sq km
water: 0 sq km
Area ■ comparative: slightly more than half the size
of Alaska
Land boundaries:
total: 3,824 km
border countries: Angola 1 ,376 km, Botswana 1,360
km, South Africa 855 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along
coast; Kalahari Desert in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium,
gold, lead, tin, lithium, cadmium, zinc, salt, vanadium,
natural gas, hydropower, fish
note: suspected deposits of oil, coal, and iron ore
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 22%
of/]er;31%(1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: prolonged periods of drought
Environment - current Issues: very limited natural
fresh water resources; desertification
Environment - international agreements:
party to; Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements','516fc7313105a4cbb0ac065a0ac737aebd569ee17a2ec3ec44c1ea0b8c7804cb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e05a0c22f47b02f4b7c8c356bd2d61e798045fa4087f5f02d97187126d5e753',2001,'NR','Nauru','geography',856,'Location: Oceania, island in the South Pacific
Ocean, south of the Marshall Islands
Geographic coordinates: 0 32 S, 166 55 E
Map references: Oceania
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area - comparative: about 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; monsoonal; rainy season
(November to February)
Terrain: sandy beach rises to fertile ring around
raised coral reefs with phosphate plateau in center
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location along plateau rim 61 m
Natural resources: phosphates
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
of/?er; 100% (1993 est.)
354
Nauru (continued)
Irrigated land: NAsqkm
Natural hazards: periodic droughts
Environment - current Issues: limited natural fresh
water resources, roof storage tanks collect rainwater,
but mostly dependent on a single, aging desalination
plant; intensive phosphate mining during the past 90
years - mainly by a UK, Australia, and NZ consortium -
has left the central 90% of Nauru a wasteland and
threatens limited remaining land resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: Nauru is one of the three great
phosphate rock islands in the Pacific Ocean - the
others are Banaba (Ocean Island) in Kiribati and
Makatea in French Polynesia; only 53 km south of
Equator
Location: Caribbean, island in the Caribbean Sea,
about one-fourth of the way from Haiti to Jamaica
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the
Caribbean
Area:
total: 5.2 sq km
land: 5.2 sq km
water: 0 sq km
Area - comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: marine, tropical
Terrain: raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m
high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side
77 m
Natural resources: guano
Land use:
arable land: 0%
permanent crops: 0%
356
Navassa Island (continued)
permanent pastures: 1 0%
forests and woodland: 0%
other: 90%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment - current issues: NA
Geography - note: strategic location 160 km south
of the US Naval Base at Guantanamo Bay, Cuba;
mostly exposed rock, but enough grassland to support
goat herds; dense stands of fig-like trees, scattered
cactus','fa28407fa938c5827f9fc6d33c36df914f8594af5c5a0ce6aec02c60dadcc22b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33bf9387ba8a6a160403a55c2bcf2c5cc6cfcdb28d2128b777c3d0c52864fb00',2001,'NP','Nepal','geography',864,'Location: Southern Asia, between China and India
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area:
total: 140,800 sq km
/and.- 136,800 sq km
water: 4,000 sq km
Area - comparative: slightly larger than Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1,236 km, India 1,690 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from cool summers and severe
winters in north to subtropical summers and mild
winters in south
Terrain: Terai or flat river plain of the Ganges in
south, central hill region, rugged Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,850 m (1999 est.)
Natural resources: quartz, water, timber,
hydropower, scenic beauty, small deposits of lignite,
copper, cobalt, iron ore
Land use:
arable land: 17%
permanent crops: 0%
k
permanent pastures: 15%
forests and woodland: 42%
other: 26% (m3 est.)
Irrigated land: 8,500 sq km (1993 est.)
Natural hazards: severe thunderstorms, flooding,
landslides, drought, and famine depending on the
timing, intensity, and duration of the summer
monsoons
Environment - current issues: deforestation
(overuse of wood for fuel and lack of alternatives);
contaminated water (with human and animal wastes,
agricultural runoff, and industrial effluents); wildlife
conservation; vehicular emissions
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life
Conservation
Geography ■ note: landlocked; strategic location
between China and India; contains eight of world’s 1 0
highest peaks','f13a89fcb2757992752c03d138551367684a030663d45a9f0e59b71fc213597c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f75e9cf01219fdacb5bdf857da5bd382450dc08b4e8f8b0c2ff827eee30d1248',2001,'NL','Netherlands','geography',873,'Location: Caribbean, two island groups in the
Caribbean Sea - one includes Curacao and Bonaire
north of Venezuela; the other is east of the Virgin
Islands
Geographic coordinates: 1 2 1 5 N, 68 45 W
Map references: Central America and the
Caribbean
Area:
total: 960 sq km
land: 960 sq km
water: 0 sq km
note: includes Bonaire, Curacao, Saba, Sint
Eustatius, and Sint Maarten (Dutch part of the island
of Saint Martin)
Area - comparative: more than five times the size of
Washington, DC
Land boundaries:
total: 10.2 km
border countries: Guadeloupe (Saint Martin) 10.2 km
Coastline: 364 km
Maritime claims:
exclusive fishing zone: 1 2 NM
territorial sea: 12 NM
Climate: tropical; ameliorated by northeast trade
winds
Terrain: generally hilly, volcanic interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources; phosphates (Curacao only), salt
(Bonaire only)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 90% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: Curacao and Bonaire are south of
Caribbean hurricane belt and are rarely threatened;
Sint Maarten, Saba, and Sint Eustatius are subject to
hurricanes from July to October
Environment - current issues: NA','edc62b2dd1095dd1110250c4da986f3998293012644a16cdb6dc7399c97c56bc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1f58902c49474b3570a2d340298a538bbec17a3f67998377827f169be0ef31b',2001,'NC','New Caledonia','geography',881,'Location: Oceania, islands in the South Pacific
Ocean, east of Australia
Geographic coordinates: 21 30 S, 165 30 E
Map references: Oceania
Area:
total: 1 9,060 sq km
land: 16,575 sq km
water: 485 sq km
Area - comparative: slightly smaller than New','04d04e47866a4b98cc23e10d07c85c7b91aeb8071ee61d69731940e19bbf951f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11e02bdb7da2a53dc8f1e373106dae4c03f9f0c3e68087bdd0fa2ca526c273f4',2001,'NE','Niger','geography',894,'Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total: 1267 million sq km
/and; 1,266,700 sq km
water: 300 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,697 km
border countries: Algeria 956 km, Benin 266 km,
Burkina Faso 628 km, Chad 1 ,175 km, Libya 354 km,
Mali 821 km, Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty; tropical in
extreme south
Terrain: predominately desert plains and sand
dunes; fiat to rolling plains in south; hills in north
Elevation extremes:
lowest point: Niger River 200 m
highest point: Mont Greboun 1,944 m
Natural resources: uranium, coal, iron ore, tin,
phosphates, gold, petroleum
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 2%
of/ier; 88% (1993 est.)
371
Niger (continued)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring droughts
Environment - current issues: overgrazing; soil
erosion; deforestation; desertification; wildlife
populations (such as elephant, hippopotamus, giraffe,
and lion) threatened because of poaching and habitat
destruction
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Law of the Sea
Geography - note: landlocked
Location: Western Africa, bordering the Gulf of
Guinea, between Benin and Cameroon
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area:
total: 923,768 sq km
/and; 91 0,768 sq km
water: ]3, 000 sq km
Area - comparative: slightly more than twice the
size of California
Land boundaries:
total: 4,047 km
border countries: Benin 773 km, Cameroon 1 ,690 km,
Chad 87 km, Niger 1,497 km
Coastline: 853 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: varies; equatorial in south, tropical in
center, arid in north
Terrain: southern lowlands merge into central hills
and plateaus; mountains in southeast, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,41 9 m
Natural resources: natural gas, petroleum, tin,
columbite, iron ore, coal, limestone, lead, zinc, arable
land
Land use:
arable land: 33%
permanent crops: 3%
permanent pastures: 44%
forests and woodland: 12%
ote''8% (1993 est.)
Irrigated land: 9,570 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current Issues: soil degradation;
rapid deforestation; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements','1b327f88b159469b4892bcfea5117863e0791ecf47784ab6540684ac20e5aea1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a4613fc330bb7f89b051e8495d10418a4309ecd189b23363aec7a42310f74b3',2001,'NU','Niue','geography',903,'Location: Oceania, island in the South Pacific
Ocean, east of Tonga
Geographic coordinates: 19 02 S, 169 52 W
Map references: Oceania
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; modified by southeast trade winds
Terrain: steep limestone cliffs along coast, central
plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau
settlement 68 m
Natural resources: fish, arable land
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 4%
forests and woodland: 1 9%
other: 50% {1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons
Environment - current issues: increasing attention
to conservationist practices to counter loss of soil
fertility from traditional slash and burn agriculture
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification
signed, but not ratified: Law of the Sea
Geography - note: one of world''s largest coral
islands','2d1ba9a5745fed07e2c5cb3a7a5b2387a42b1074d72715e0ee276491d10422c7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbaa139a1564d002f0c120f92f3a8cc08b1b07c827cda9a058e29b73b05133d4',2001,'PA','Panama','geography',914,'Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 78,200 sq km
land: 75,990 sq km
wafer 2,210 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa Rica
330 km
Coastline: 2,490 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Terrain: interior mostly steep, rugged mountains and
dissected, upland plains; coastal areas largely plains
and rolling hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Natural resources: copper, mahogany forests,
shrimp, hydropower
Land use:
arable land: 7%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 44%
of/ier; 27% (1993 est.)
Irrigated land: 320 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: water pollution from
agricultural runoff threatens fishery resources;
deforestation of tropica! rain forest; land degradation
and soil erosion threatens siltation of Panama Canal
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography ■ note: strategic location on eastern end
of isthmus forming land bridge connecting North and
South America; controls Panama Canal that links
North Atlantic Ocean via Caribbean Sea with North
Pacific Ocean','7ee09afe57622044205e41c9eb002cb9e182ec5e9baa6fca0004a696f4f0ca24','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98a311626500c79d4ba565312a8eb2706ff7437575fc9af494384902c721207d',2001,'PN','Pitcairn','geography',927,'Location: Oceania, islands In the South Pacific
Ocean, about one-half of the way from Peru to New
Zealand
Geographic coordinates: 25 04 S, 130 06 W
Map references: Oceania
Area:
total: 47 sq km
land: 47 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 3NM
Climate: tropical, hot, humid; modified by southeast
trade winds; rainy season (November to March)
Terrain: rugged volcanic formation; rocky coastline
with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for
handicrafts), fish
note: manganese, iron, copper, gold, silver, and zinc
have been discovered offshore
Land use:
arable land: NA%
permanent crops: NA%
405
Pitcairn Islands (continued)
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: typhoons (especially November to
March)
Environment - current issues: deforestation (only
a small portion of the original forest remains because
of burning and clearing for settlement)','26119f657f49198de9d57b8e84d1c9832c6d033ae0e1b9d750a889a831c9a775','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a59ef26b78dba1508701f9e5bd3fcdc64dbada8758c25cb5b33253a7a3d4330',2001,'PL','Poland','geography',934,'Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area:
total: 312,685 sq km
land: 304,465 sq km
water: 8,220 sq km
Area - comparative: slightly smaller than New','6f87d071903e3acc3334f671c447aae1dc440e119d4a900a3566c8c2fba3ced7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ece0a09fdeac56b13e1e76d290d6e8c7627ec7059acc4b254de12f304e953cc',2001,'MX','Mexico','geography',935,'Land boundaries:
total: 2,888 km
border countries: Belarus 605 km, Czech Republic
658 km, Germany 456 km, Lithuania 91 km, Russia
(Kaliningrad Oblast) 206 km, Slovakia 444 km,
Ukraine 428 km
Coastline: 491 km
Maritime claims:
exclusive economic zone: defined by international
treaties
territorial sea: 12 NM
Climate: temperate with cold, cloudy, moderately
severe winters with frequent precipitation; mild
summers with frequent showers and thundershowers
Terrain: mostly flat plain; mountains along southern
border
Elevation extremes:
lowest point: Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural gas,
silver, lead, salt, arable land
Land use:
arable land: 47%
permanent crops: 1%
permanent pastures: 1 3%
forests and woodland: 29%
of/?er; 10% (1993 est.)
Irrigated land: 1 ,000 sq km (1 993 est.)
Natural hazards: NA
Environment - current issues: situation has
improved since 1989 due to decline in heavy industry
and increased environmental concern by
postcommunist governments; air pollution
nonetheless remains serious because of sulfur
dioxide emissions from coal-fired power plants, and
the resulting acid rain has caused forest damage;
water pollution from industrial and municipal sources
is also a problem, as is disposal of hazardous wastes
Environment - international agreements:
party to: Air Pollution, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Climate Change-Kyoto Protocol
Geography - note: historically, an area of conflict
because of flat terrain and the lack of natural barriers
on the North European Plain','bf2632587f6d0c5febf2a55b38520ea783c22121e6ccc8e71578f3c21b75de44','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('896b9cdc2e1e22cc27b20af0be6a3ad60d5162cd1a4d539a2fac916e5ca3d17a',2001,'PT','Portugal','geography',942,'Location: Southwestern Europe, bordering the
North Atlantic Ocean, west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references: Europe
Area:
total: 92,391 sq km
land: 91,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
Area - comparative: slightly smaller than Indiana
Land boundaries:
fofa/; 1,214 km
border countries: Spam 1,214 km
Coastline: 1,793 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: maritime temperate; cool and rainy in north,
warmer and drier in south
Terrain: mountainous north of the Tagus River,
rolling plains in south
Eievation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico (Pico or Pico Alto) on llha
do Pico in the Azores 2,351 m
Natural resources: fish, forests (cork), tungsten,
iron ore, uranium ore, marble, arable land, hydro
power
Land use:
arable land: 26%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 36%
other: 20% (1993 est.)
Irrigated land: 6,300 sq km (1993 est.)
Natural hazards: Azores subject to severe
earthquakes
Environment - current issues: soil erosion; air
pollution caused by industrial and vehicle emissions;
water pollution, especially in coastal areas
Environment - international agreements:
party to; Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol,
Environmental Modification, Nuclear Test Ban
Geography - note: Azores and Madeira Islands
occupy strategic locations along western sea
approaches to Strait of Gibraltar','9ca3444b9d4628415e1f051ddb6f0f8ea3716d06f4c9747ed388e253e0816543','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba2c573923d812a6548f97ace7531bc5c39bd74624d452bdaadc4be255decdaa',2001,'PR','Puerto Rico','geography',946,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, east of the
Geographic coordinates: 18 20 N, 64 50 W
Map references: Central America and the
Caribbean
Area:
total: 352 sq km
land: 349 sq km
water: 3 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: subtropical, tempered by easterly trade
winds, relatively low humidity, little seasonal
temperature variation; rainy season May to November
Terrain: mostly hilly to rugged and mountainous with
little level land
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use:
arable land: 15%
permanent crops: 6%
545
Virgin Islands (continued)
permanent pastures: 26%
forests and woodland: 6%
oto;47%(1993 est.)
Irrigated land: NAsqkm
Natural hazards: several hurricanes in recent years;
frequent and severe droughts and floods; occasional
earthquakes
Environment - current issues: lack of natural
freshwater resources
Geography - note: important location along the
Anegada Passage - a key shipping lane for the
Panama Canal; Saint Thomas has one of the best
natural, deepwater harbors in the Caribbean
Location: Oceania, atoll in the North Pacific Ocean,
about two-thirds of the way from Hawaii to the','8f9af1ef5b22e63a2c0994285b0258746ed43cabee130a6e1a6fe7b097c1d8d7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eef181e6144d767ad8154eec47e6e541db800ef5b00e2ebd8e7007f2340fbd8f',2001,'QA','Qatar','geography',948,'Location: Middle East, peninsula bordering the
Persian Gulf and Saudi Arabia
Geographic coordinates: 25 30 N, 51 15 E
Map references: Middle East
414
Qatar (continued)
Area:
total: 1 1 ,437 sq km
land: 1 1 ,437 sq km
water: Osq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries:
total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: as determined by bilateral
agreements or the median line
territorial sea; 12 NM
Climate: desert; hot, dry; humid and sultry in summer
Terrain: mostly flat and barren desert covered with
loose sand and gravel
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Qurayn Abu al Bawl 1 03 m
Natural resources: petroleum, natural gas, fish
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 0%
of/ier; 94% (1993 est.)
Irrigated land: 80 sq km (1993 est.)
Natural hazards: haze, dust storms, sandstorms
common
Environment ■ current issues: limited natural fresh
water resources are increasing dependence on
large-scale desalination facilities
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Law of the Sea
Geography ■ note: strategic location in central
Persian Gulf near major petroleum deposits
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 21 06 S, 55 36 E
Map references: World
Area:
tofa/;2,512sq km
land: 2,502 sq km
water; 10 sq km
Area - comparative: slightly smaller than Rhode
island
Land boundaries: 0 km
Coastline: 207 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea; 12 NM
Climate: tropical, but temperature moderates with
elevation; cool and dry from May to November, hot
and rainy from November to April
Terrain: mostly rugged and mountainous; fertile
lowlands along coast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Natural resources: fish, arable land, hydropower
Land use:
arable land: 17%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 35%
oteer; 41% (1993 est.)
Irrigated land: 60 sq km (1 993 est.)
Natural hazards: periodic, devastating cyclones
(December to April); Piton de la Fournaise on the
southeastern coast is an active volcano
Environment - current issues: NA','beb5016a117044f3eeeb62eacfe4d660cd83bbaf11d62b36a8d71375c06a7b3f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c78cc77c694bca09a0841cbf80b85e978d76ba114e1d526cbf2823008b85848',2001,'RO','Romania','geography',957,'Location: Southeastern Europe, bordering the Black
Sea, between Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area:
total: 237,500 sq km
land: 230,340 sq km
wafer 7,1 60 sq km
Area ■ comparative: slightly smaller than Oregon
Land boundaries:
total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443 km,
Moldova 450 km, Yugoslavia 476 km, Ukraine (north)
362 km, Ukraine (east) 169 km
Coastline: 225 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: temperate; cold, cloudy winters with
frequent snow and fog; sunny summers with frequent
showers and thunderstorms
Terrain: central Transylvanian Basin is separated
from the Plain of Moldavia on the east by the
Carpathian Mountains and separated from the
Walachian Plain on the south by the T ransylvanian Alps
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declining),
timber, natural gas, coal, iron ore, salt, arable land,
hydropower
Land use:
arable land: A^%
permanent crops: 3%
permanent pastures: 21 %
forests and woodland: 29%
other 6% (1993 est.)
irrigated land: 31,020 sq km (1993 est.)
Natural hazards: earthquakes most severe in south
and southwest: geologic structure and climate
promote landslides
Environment - current issues: soil erosion and
degradation; water pollution; air pollution in south from
industrial effluents; contamination of Danube delta
wetlands
Environment ■ Internationa! agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography ■ note: controls most easily traversable
land route between the Balkans, Moldova, and','69ac661d9dbb83b18f2541b9a1e09013e15e12066eeb40cb62abb3c216850a47','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3b079f2ad3d57eb15ee2a0d06b07045fa17115bc60dd307887396cd873d0aed',2001,'UA','Ukraine','geography',966,'Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: ranges from steppes in the south through
humid continental in much of European Russia;
subarctic in Siberia to tundra climate in the polar north;
winters vary from cool along Black Sea coast to frigid
in Siberia; summers vary from warm in the steppes to
cool along Arctic coast
Terrain: broad plain with low hills west of Urals; vast
coniferous forest and tundra in Siberia; uplands and
mountains along southern border regions
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Gora El''brus 5,633 m
Natural resources: wide natural resource base
including major deposits of oil, natural gas, coal, and
many strategic minerals, timber
note: formidable obstacles of climate, terrain, and
Location: Northern Asia (that part west of the Urals is
sometimes included with Europe), bordering the Arctic
Ocean, between Europe and the North Pacific Ocean
Geographic coordinates: 60 00 N, 100 00 E
Map references: Asia
Area:
fofa/.- 17,075,200 sq km
/ancf; 16,995,800 sq km
wafer; 79,400 sq km
Area - comparative: slightly less than 1 .8 times the
size of the US
Land boundaries:
total: 19,961 km
border countries: Azerbaijan 284 km, Belarus 959 km,
China (southeast) 3,605 km, China (south) 40 km,
Estonia 294 km, Finland 1,313 km, Georgia 723 km,
Kazakhstan 6,846 km, North Korea 19 km, Latvia 217
km, Lithuania (Kaliningrad Oblast) 227 km, Mongolia
3,485 km, Norway 167 km, Poland (Kaliningrad
Oblast) 206 km, Ukraine 1,576 km
Coastline: 37,653 km
distance hinder exploitation of natural resources
Land use:
arable land: 8%
permanent crops: 0%
permanent pastures: 4%
forests and woodland: 46%
other: 42% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: permafrost over much of Siberia is
a major impediment to development; volcanic activity
in the Kuril Islands; volcanoes and earthquakes on the
Kamchatka Peninsula
Environment - current Issues: air pollution from
heavy industry, emissions of coal-fired electric plants,
and transportation in major cities; industrial,
municipal, and agricultural pollution of inland
waterways and sea coasts; deforestation; soil erosion;
soil contamination from improper application of
agricultural chemicals; scattered areas of sometimes
intense radioactive contamination; ground water
contamination from toxic waste
Russia (continued)
Environment - International agreements:
party to; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94,
Climate Change-Kyoto Protocol
Geography - note: largest country in the world in
terms of area but unfavorably located in relation to
major sea lanes of the world; despite its size, much of
the country lacks proper soils and climates (either too
cold or too dry) for agriculture
Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,338 sq km
land: 24,948 sq km
water: 1 ,390 sq km
Area ■ comparative: slightly smaller than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km. Democratic
Republic of the Congo 217 km, Tanzania 217 km,
Uganda 169 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February to
April, November to January); mild in mountains with
frost and snow possible
Terrain: mostly grassy uplands and hills; relief is
mountainous with altitude declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: yolcau Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore),
wolframite (tungsten ore), methane, hydropower,
arable land
Land use:
arable land: 35%
permanent crops: 1 3%
permanent pastures: 18%
forests and woodland: 22%
other: 12% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: periodic droughts; the volcanic
Virunga mountains are in the northwest along the
border with Democratic Republic of the Congo
Environment - current issues: deforestation
results from uncontrolled cutting of trees for fuel;
overgrazing; soil exhaustion; soil erosion; widespread
poaching
Environment - International agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Nuclear Test Ban, Ship Pollution
signed, but not ratified: Law of the Sea
Geography - note: landlocked; predominantly rural
population
Location: islands in the South Atlantic Ocean, about
mid-way between South America and Africa
Geographic coordinates: 15 56 S, 5 42 W
Map references: Africa
Area:
tofa/.''410sq km
land: 410 sg km
water: 0 sq km
note: includes St. Helena Island, Ascension, and the
island group of Tristan da Cunha, which consists of
Tristan da Cunha Island, Gough Island, Inaccessible
Island, and the three Nightingale Islands
Area - comparative: slightly more than two times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 60 km
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 12 NM
Climate: Saint Helena - tropical; marine; mild,
tempered by trade winds; Tristan da Cunha -
temperate; marine, mild, tempered by trade winds
(tends to be cooler than Saint Helena)
Terrain: Saint Heiena - rugged, volcanic; small
scattered plateaus and plains
note: the other islands of the group have a volcanic
origin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak on Tristan da
Cunha 2,060 m
Natural resources; fish
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 6%
other; 82% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: active volcanism on Tristan da
Cunha
Environment - current issues: NA
Geography - note: harbors at least 40 species of
plants unknown anywhere else in the world;
Ascension is a breeding ground for sea turtles and
sooty terns
Location: Caribbean, islands in the Caribbean Sea,
about one-third of the way from Puerto Rico to','dcb05d420ede40525c3c3f7a4c2f2d34f7373abe4e4be967e3b4b9e40ce17ecc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0add043cc2595667d90b06b3a4b57352fead5dbe31e162ef716edfce5c94f17c',2001,'TT','Trinidad and Tobago','geography',967,'Geographic coordinates: 17 20 N, 62 45 W
Map references: Central America and the
Caribbean
Area:
to/a/; 261 sq km (Saint Kitts 168 sq km; Nevis
93 sq km)
/and; 261 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
/er/''//ona/sea;12NM
exclusive economic zone: 200 NM
Climate: tropical tempered by constant sea breezes;
little seasonal temperature variation; rainy season
(May to November)
Terrain: volcanic with mountainous interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1 ,1 56 m
Natural resources: arable land
Land use:
arable land: 22%
permanent crops: 17%
permanent pastures: 3%
forests and woodland: ^7%
other: A^%{^993 est.)
Irrigated land: NAsqkm
Natural hazards; hurricanes (July to October)
Environment - current issues: NA
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements','a86f983fe4063bd3aa3462420f6cbecfddbdf3c9fa2db94472ee382eab203d8e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('417ed6b296b2cb17b2dcef7c4f4385d940c34d110a5cc1d64c4ade7a8ff5b286',2001,'LC','Saint Lucia','geography',975,'Location: Caribbean, island between the Caribbean
Sea and North Atlantic Ocean, north of Trinidad and
Tobago
Geographic coordinates: 1 3 53 N, 60 68 W
Map references: Central America and the
Caribbean
Area:
total: 620 sq km
/and;610sq km
wafer lOsq km
Area - comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical, moderated by northeast trade
winds; dry season from January to April, rainy season
from May to August
Terrain: volcanic and mountainous with some broad,
fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs, geothermal
potential
Land use:
arable land: 8%
permanent crops: 2^%
permanent pastures: 5%
forests and woodland: 1 3%
of/?er53% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards; hurricanes and volcanic activity
Environment - current issues: deforestation; soil
erosion, particularly in the northern region
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: CWmle Change-Kyoto
Protocol','ae13f46fdbb59eb41170d4dc5ccb6cbffd2f630f293754c77fe90b0d7197f680','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72d6d4c8a0f0b4d70e0a32dac5ab7ffb92220acdadaed6c00952e6c89521dd0c',2001,'IT','Italy','geography',985,'Geographic coordinates: 43 46 N, 12 25 E
Map references: Europe
Area:
total: 2 sq km
/and,'' 61 .2 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries:
total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Mediterranean; mild to cool winters; warm,
sunny summers
Terrain: rugged mountains
Elevation extremes:
lowest point: Torrente Ausa 55 m
highest point: Monte Titano 755 m
Natural resources: building stone
Land use:
arable land: M%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 83% est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: NA
Environment • international agreements:
party to: Biodiversity, Climate Change,
Desertification, Marine Dumping, Nuclear Test Ban,
Ship Pollution
signed, but not ratified: Air Pollution
Geography - note: landlocked; smallest
independent state in Europe after the Holy See and
Monaco; dominated by the Apennines
Location: Western Africa, islands in the Gulf of
Guinea, straddling the Equator, west of Gabon
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area:
total: sq km
land: 1 ,001 sq km
water: 0 sq km
Area - comparative: more than five times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 209 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: tropical; hot, humid; one rainy season
(October to May)
Terrain; volcanic, mountainous
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish, hydropower
Land use:
arable land: 2%
permanent crops: 36%
permanent pastures: 1 %
forests and woodland: 0%
ofher; 61% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation; soil
erosion and exhaustion
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Marine Dumping, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area:
total: 41 ,290 sq km
land: 39,770 sq km
water: 1 ,520 sq km
Area - comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1 ,852 km
border countries: Austria 164 km, France 573 km,
Italy 740 km, Liechtenstein 41 km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime ciaims: none (landlocked)
Climate: temperate, but varies with altitude; cold,
cloudy, rainy/snowy winters; cool to warm, cloudy,
humid summers with occasional showers
Terrain: mostly mountains (Alps in south. Jura in
northwest) with a central plateau of rolling hills, plains,
and large lakes
Elevation extremes:
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential, timber,
salt
Land use:
arabie land: ^0%
permanent crops: 2%
permanent pastures: 28%
forests and woodland: 32%
ofrter; 28% (1993 est.)
Irrigated land: 250 sq km (1993 est.)
Natural hazards: avalanches, landslides, flash floods
Environment - current issues: air pollution from
vehicle emissions and open-air burning; acid rain;
water pollution from increased use of agricultural
fertilizers; loss of biodiversity
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol, Law of the
Sea
Geography - note: landlocked; crossroads of
northern and southern Europe; along with
southeastern France and northern Italy, contains the
highest elevations in Europe
Location: Middle East, bordering the Mediterranean
Sea, between Lebanon and Turkey
Geographic coordinates: 35 00 N, 38 00 E
Map references: Middle East
Area:
tofa/;185,180 sq km
land: 134,050 sq km
water; 1,130 sq km
note: includes 1 ,295 sq km of Israeli-occupied territory
Area ■ comparative: slightly larger than North
Dakota
Land boundaries:
total: 2,253 km
border countries: Iraq 605 km, Israel 76 km, Jordan
375 km, Lebanon 375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
contiguous zone: 41 NM
territorial sea: 35 NM
Climate: mostly desert: hot, dry, sunny summers
(June to August) and mild, rainy winters (December to
February) along coast: cold weather with snow or
sleet periodically hitting Damascus
Terrain: primarily semiarid and desert plateau;
narrow coastal plain; mountains in west
Elevation extremes:
lowest point: unnamed location near Lake
Tiberias -200 m
highest point: Mount Hermon 2,814 m
488
Syria (continued)
Natural resources: petroleum, phosphates, chrome
and manganese ores, asphalt, iron ore, rock salt,
marble, gypsum, hydropower
Land use:
arable land: 28%
permanent crops: 4%
permanent pastures: 43%
forests and woodland: 3%
ofher; 22% (1993 est)
Irrigated land: 9,060 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment ■ current issues: deforestation;
overgrazing; soil erosion; desertification; water
pollution from dumping of raw sewage and wastes
from petroleum refining; inadequate supplies of
potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: there are 42 Israeli settlements
and civilian land use sites in the Israeli-occupied
Golan Heights (August 1999 est.)','3c4d72cebeb8ad2a257aad3fb454d096677d688fc93004832407095e266019e7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b072da84ff9275b0b473cc990788fd73566b62092372814861fc7378cc10046b',2001,'SC','Seychelles','geography',990,'Location: Eastern Africa, group of islands in the
Indian Ocean, northeast of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total: 455 sq km
land: 455 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims;
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical marine; humid; cooler season
during southeast monsoon (late May to September);
warmer season during northwest monsoon (March to
May)
Terrain: Mahe Group is granitic, narrow coastal strip,
rocky, hilly; others are coral, flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cinnamon trees
Land use:
arable land: 2%
permanent crops: 13%
447
Seychelles (continued)
permanent pastures: 0%
forests and woodland: 1 1 %
other: 74% {m3 est.)
Irrigated land: NA sq km
Natural hazards: lies outside the cyclone belt, so
severe storms are rare; short droughts possible
Environment - current issues: water supply
depends on catchments to collect rainwater
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: 40 granitic and about 50
coralline islands','b578d6a3ec0ac425d83c1baca16dc1d0c2baeadc433c363d7e35672887628afb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0fef800ad2eb7540e2adfbd24ff81d77c75c389e632251f97a3451fc2715d07',2001,'SL','Sierra Leone','geography',998,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Liberia
Geographic coordinates: 8 30 N, 1 1 30 W
Map references: Africa
Area:
total: 71 ,740 sq km
land: 7 1,020 sq km
water: 120 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea: 200 NM
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical; hot, humid; summer rainy season
(May to December); winter dry season (December to
April)
449
Sierra Leone (continued)
Terrain: coastal belt of mangrove swamps, wooded
hill country, upland plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Natural resources: diamonds, titanium ore, bauxite,
iron ore, gold, chromite
Land use:
arable land: 7%
permanent crops: 1 %
permanent pastures: 31 %
forests and woodland: 28%
other: 33% est.)
Irrigated land: 290 sq km (1993 est.)
Natural hazards: dry, sand-laden harmattan winds
blow from the Sahara (December to February);
sandstorms, dust storms
Environment - current issues: rapid population
growth pressuring the environment; overharvesting of
timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in
deforestation and soil exhaustion; civil war depleting
natural resources; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements','22d2f156d96717095b69a0d176c459021dd6f78506961c214a8764177818e13b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7da9265f07a36fc4b52b39e3363893d9d809521cf6c452275f99b9b1a36622a2',2001,'SG','Singapore','geography',1006,'Location: Southeastern Asia, islands between
Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area:
total: 647.5 sq km
land: 637.5 sq km
water: 10 sq km
Area ■ comparative: slightly more than 3.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
exclusive fishing zone: within and beyond territorial
sea, as defined in treaties and practice
territorial sea: 3 NM
Climate: tropical; hot, humid, rainy; two distinct
monsoon seasons - Northeastern monsoon from
December to March and Southwestern monsoon from
June to September; inter-monsoon - frequent
afternoon and early evening thunderstorms
Terrain: lowland; gently undulating central plateau
contains water catchment area and nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 166 m
Natural resources: fish, deepwater ports
Land use:
arable land: 2%
permanent crops: 6%
permanent pastures: 0%
forests and woodland: 5%
other: 37% {m3 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: industrial pollution;
limited natural fresh water resources; limited land
availability presents waste disposal problems;
seasonal smoke/haze resulting from forest fires in','7d3db75135f3666365413fd1a9be3b99f43f9296ce0b8639c1d8af68075fd9fb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d5b1312b7d187a01d5f1d915adf044e09f9493037be2d6926fbff58b3e7bbb5',2001,'SO','Somalia','geography',1023,'Location: Eastern Africa, bordering the Gulf of Aden
and the Indian Ocean, east of Ethiopia
Geographic coordinates: 10 00 N, 49 00 E
Map references: Africa
Area:
total: 637,657 sq km
land: 627,337 sq km
water.'' 10,320 sq km
461
Somalia (continued)
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 2,366 km
border countries: Djibouti 58 km, Ethiopia 1,626 km,
Kenya 682 km
Coastline: 3,025 km
Maritime ciaims:
territorial sea: 200 NM
Ciimate: principally desert; December to February -
northeast monsoon, moderate temperatures in north
and very hot in south; May to October - southwest
monsoon, torrid in the north and hot in the south,
irregular rainfall, hot and humid periods (tangambili)
between monsoons
Terrain: mostly flat to undulating plateau rising to
hills in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2,416 m
Natural resources: uranium and largely unexploited
reserves of iron ore, tin, gypsum, bauxite, copper, salt
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 69%
forests and woodland: 26%
other; 3% (1993 est.)
Irrigated land: 1,800 sq km (1993 est.)
Natural hazards: recurring droughts; frequent dust
storms over eastern plains in summer; floods during
rainy season
Environment - current issues: famine; use of
contaminated water contributes to human health
problems; deforestation; overgrazing; soil erosion;
desertification
Environment - international agreements:
party to: Endangered Species, Law of the Sea,
Marine Dumping, Ship Pollution
signed, but not ratified: Marine Dumping, Nuclear
Test Ban
Geography - note: strategic location on Horn of
Africa along southern approaches to Bab el Mandeb
and route through Red Sea and Suez Canal','07705fc8e86a8f4ca38cbcd9d094ec713295082bc3187a900ae86112e11f3a5c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37a35f893a6b91638c3a46fbcb77eef841d708d0262f1ce0d5b01e78917acde2',2001,'ZA','South Africa','geography',1030,'Location: Southern Africa, at the southern tip of the
continent of Africa
Geographic coordinates: 29 00 S, 24 00 E
Map references: Africa
Area:
/ofa/.'' 1,219,912 sq km
/and.'' 1,219,912 sq km
water: Osq km
note: includes Prince Edward Islands (Marion Island
and Prince Edward Island)
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 4,750 km
border countries: Botswana 1,840 km, Lesotho 909
km, Mozambique 491 km, Namibia 855 km,
Swaziland 430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: mostly semiarid; subtropical along east
coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by rugged hills
and narrow coastal plain
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony, coal,
iron ore, manganese, nickel, phosphates, tin,
uranium, gem diamonds, platinum, copper, vanadium,
salt, natural gas
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 67%
forests and woodland: 7%
other: 15% (1993 est.)
Irrigated land: 12,700 sq km (1993 est.)
Natural hazards: prolonged droughts
Environment - current Issues: lack of important
arterial rivers or lakes requires extensive water
conservation and control measures: growth in water
usage threatens to outpace supply; pollution of rivers
from agricultural runoff and urban discharge; air
pollution resulting in acid rain; soil erosion;
desertification
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: South Africa completely
surrounds Lesotho and almost completely surrounds
Swaziland
Location: Southern South America, islands in the
South Atlantic Ocean, east of the tip of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area:
total: 3,903 sq km
land: 3,903 sq km
water: 0 sq km
note: includes Shag Rocks, Black Rock, Clerke
Rocks, South Georgia Island, Bird Island, and the
South Sandwich Islands, which consist of some nine
islands
Area - comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: NAkm
Maritime claims:
exclusive fishing zone: 200 NM
territorial sea: 12 NM
466
South Georgia and the South Sandwich Islands (continued)
Climate: variable, with mostly westerly winds
throughout the year interspersed with periods of calm;
nearly all precipitation falls as snow
Terrain: most of the islands, rising steeply from the
sea, are rugged and mountainous; South Georgia is
largely barren and has steep, glacier-covered
mountains; the South Sandwich Islands are of
volcanic origin with some active volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget (South Georgia) 2,934 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (largely covered by permanent ice and
snow with some sparse vegetation consisting of
grass, moss, and lichen)
Irrigated land: 0 sq km (1993)
Natural hazards: the South Sandwich Islands have
prevailing weather conditions that generally make
them difficult to approach by ship; they are also
subject to active volcanism
Environment - current Issues: NA
Geography - note: the north coast of South Georgia
has several large bays, which provide good
anchorage; reindeer, introduced early in this century,
live on South Georgia
Location: body of water between 60 degrees south
latitude and Antarctica
Geographic coordinates. 65 00 S, 0 00 E
(nominally), but the Southern Ocean has the unique
distinction of being a large circumpolar body of water
totally encircling the continent of Antarctica; this ring of
water lies between 60 degrees south latitude and the
coast of Antarctica, and encompasses 360 degrees of
longitude
Map references. Antarctic Region
Area.
total. 20.327 million sq km
note, includes Amundsen Sea, Bellingshausen Sea,
part of the Drake Passage, Ross Sea, a small part of
the Scotia Sea, Weddell Sea, and other tributary water
bodies
Area - comparative, slightly more than twice the size
of the US
Coastline. 17,968 km
Climate, sea temperatures vary from about 10
degrees Celsius to -2 degrees Celsius; cyclonic
storms travel eastward around the continent and
frequently are intense because of the temperature
contrast between ice and open ocean; the ocean area
from about latitude 40 south to the Antarctic Circle has
the strongest average winds found anywhere on
Earth; in winter the ocean freezes outward to
467
Southern Ocean (continued)
65 degrees south latitude in the Pacific sector and 55
degrees south latitude in the Atlantic sector, lowering
surface temperatures well below 0 degrees Celsius; at
some coastal points intense persistent drainage winds
from the interior keep the shoreline ice-free
throughout the winter
Terrain, the Southern Ocean is deep, 4,000 to 5,000
meters over most of its extent with only limited areas
of shallow water; the Antarctic continental shelf is
generally narrow and unusually deep - its edge lying
at depths of 400 to 800 meters (the global mean is 1 33
meters); the Antarctic icepack grows from an average
minimum of 2.6 million square kilometers in March to
about 18.8 million square kilometers in September,
better than a sixfold increase in area; the Antarctic
Circumpolar Current (21,000 km in length) moves
perpetually eastward; it is the world''s largest ocean
current, transporting 1 30 million cubic meters of water
per second - 1 00 times the flow of all the world''s rivers
Elevation extremes.
lowest point -7,235 m at the southern end of the
South Sandwich Trench
highest point sea level 0 m
Natural resources, probable large and possible giant
oil and gas fields on the continental margin,
manganese nodules, possible placer deposits, sand
and gravel, fresh water as icebergs, squid, whales,
and seals - none exploited; krill, fishes
Natural hazards, huge icebergs with drafts up to
several hundred meters; smaller bergs and iceberg
fragments; sea ice (generally 0.5 to 1 meter thick) with
sometimes dynamic short-term variations and with
large annual and interannual variations; deep
continental shelf floored by glacial deposits varying
widely over short distances; high winds and large
waves much of the year; ship icing, especialiy
May-October; most of region is remote from sources
of search and rescue
Environment - current issues, increased solar
ultraviolet radiation resulting from the Antarctic ozone
hole in recent years, reducing marine primary
productivity (phytoplankton) by as much as 15% and
damaging the DNA of some fish; illegal, unreported,
and unregulated fishing in recent years, especially the
landing of an estimated five to six times more
Patagonian toothfish than the regulated fishery, which
is likely to affect the sustainability of the stock; large
amount of incidental mortality of seabirds resulting
from long-line fishing for toothfish
note, the now-protected fur seal population is making
a strong comeback after severe overexploitation in the
18th and 19th centuries
Environment - international agreements, the
Southern Ocean is subject to all international
agreements regarding the world''s oceans; in addition,
it is subject to these agreements specific to the
Antarctic region: International Whaling Commission
(prohibits commercial whaling south of 40 degrees
south [south of 60 degrees south between 50 degrees
and 130 degrees west]); Convention on the
Conservation of Antarctic Seals (limits sealing);
Convention on the Conservation of Antarctic Marine
Living Resources (regulates fishing)
note: many nations (including the US) prohibit mineral
resource exploration and exploitation south of the
fluctuating Polar Front (Antarctic Convergence) which
is in the middle of the Antarctic Circumpolar Current
and serves as the dividing line between the very cold
polar surface waters to the south and the warmer
waters to the north
Geography - note: the major chokepoint is the
Drake Passage between South America and
Antarctica; the Polar Front (Antarctic Convergence) is
the best natural definition of the northern extent of the
Southern Ocean; it is a distinct region at the middle of
the Antarctic Circumpolar Current that separates the
very cold polar surface waters to the south from the
warmer waters to the north; the Front and the Current
extend entirely around Antarctica, reaching south of
60 degrees south near New Zealand and near 48
degrees south in the far South Atlantic coinciding with
the path of the maximum westerly winds','e01ab51ffe53fc2750177a7313574e9819b37605bf71e0009d001cede27f07a8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8786d7695869bb4ee5c75678084318dcbb80a7bcfa9d52062357e77ae34e6ebf',2001,'ES','Spain','geography',1034,'Location: Southwestern Europe, bordering the Bay
of Biscay, Mediterranean Sea, North Atlantic Ocean,
and Pyrenees Mountains, southwest of France
Geographic coordinates: 40 00 N, 4 00 W
Map references: Europe
Area:
total: 504,782 sq km
/and.'' 499,542 sq km
water: 5,240 sq km
note: includes Balearic Islands, Canary Islands, and
five places of sovereignty (plazas de soberania) on
and off the coast of Morocco - Ceuta, Melilla, Islas
Chafarinas, Penon de AIhucemas, and Penon de
Velez de la Gomera
Area - comparative: slightly more than twice the
size of Oregon
Land boundaries:
to/a/; 1,917.8 km
border coun/r/es; Andorra 63.7 km, France 623 km,
Gibraltar 1 .2 km, Portugal 1 ,214 km, Morocco (Ceuta)
6.3 km, Morocco (Melilla) 9.6 km
Coastline: 4,964 km
Maritime claims:
contiguous zone: 24 NM
468
Spain (continued)
exclusive economic zone: 200 NM (applies only to the
Atlantic Ocean)
territorial sea: 12 NM
Climate: temperate; clear, hot summers in interior,
more moderate and cloudy along coast; cloudy, cold
winters in interior, partly cloudy and cool along coast
Terrain: large, flat to dissected plateau surrounded
by rugged hills; Pyrenees in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on Canary
Islands 3,718 m
Natural resources: coal, lignite, iron ore, uranium,
mercury, pyrites, fluorspar, gypsum, zinc, lead,
tungsten, copper, kaolin, potash, hydropower, arable
land
Land use:
arable land: 30%
permanent crops: 9%
permanent pastures: 21 %
forests and woodland: 32%
other: 3% (m3 est.)
Irrigated land; 34,530 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current Issues: pollution of the
Mediterranean Sea from raw sewage and effluents
from the offshore production of oil and gas; water
quality and quantity nationwide; air pollution;
deforestation; desertification
Environment - International agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Desertification
Geography - note: strategic location along
approaches to Strait of Gibraltar','6da28c42f86013079b7ffc718c62b2b9cc20b0bfbdd3f41cc9fd99071c7bbfb0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('816cf34bf25b723e8549259d115b1a500309a17d02b5e3af5d8d291f57ccc7f3',2001,'LK','Sri Lanka','geography',1042,'Location: Southern Asia, island in the Indian Ocean,
south of India
Geographic coordinates; 7 00 N, 81 00 E
Map references; Asia
Area;
tofa/.- 65,61 Osq km
land: 64,740 sq km
water: 870 sq km
Area ■ comparative: slightly larger than West
Virginia
Land boundaries: 0 km
Coastline; 1,340 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: ^2 HU
Climate: tropical monsoon; northeast monsoon
(December to March); southwest monsoon (June to
October)
Terrain: mostly low, flat to rolling plain; mountains in
south-centra! interior
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite, mineral
sands, gems, phosphates, clay, hydropower
Land use:
arable land: 14%
permanent crops: 1 5%
permanent pastures: 7%
forests and woodland: 32%
other: 32% {ms est.)
Irrigated land: 5,500 sq km (1993 est.)
Natural hazards: occasional cyclones and tornadoes
Environment - current issues: deforestation; soil
erosion; wildlife populations threatened by poaching
and urbanization; coastal degradation from mining
activities and increased pollution; freshwater resources
being polluted by industrial wastes and sewage runoff;
waste disposal; air pollution in Colombo
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: strategic location near major
Indian Ocean sea lanes','251e76c756c3d2f7a32ffd054b76ab9cc9bc8ffc0a0c72c0e63f25d8a63c2637','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e60f53e0541f784fff4da1df74915544339cb8904a27cb630ac6d6a6b2ab8d4b',2001,'SD','Sudan','geography',1051,'Location: Northern Africa, bordering the Red Sea,
between Egypt and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area:
tofa/; 2,505,810 sq km
land: 2.376 million sq km
wafer 129,810 sq km
Area - comparative: slightly more than one-quarter
the size of the US
Land boundaries:
total: 7,687 km
border countries: Central African Republic 1 ,165 km,
Chad 1 ,360 km. Democratic Republic of the Congo 628
km, Egypt 1,273 km, Eritrea 605 km, Ethiopia 1 ,606
km, Kenya 232 km, Libya 383 km, Uganda 435 km
Coastline: 853 km
Maritime claims:
contiguous zone: 18 HWi
continental shelf: 200- m depth or to the depth of
exploitation
territorial sea: 12 NM
Climate: tropical in south; arid desert in north; rainy
season (April to October)
Terrain: generally flat, featureless plain; mountains
in east and west
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small reserves of
iron ore, copper, chromium ore, zinc, tungsten, mica,
silver, gold, hydropower
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 1 9%
other: 30% {1993 est.)
irrigated land: 19,460 sq km (1993 est.)
Natural hazards: dust storms
Environment ■ current issues: inadequate
supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: largest country in Africa;
dominated by the Nile and its tributaries','7e5f5e717cdad3b6fc6aa3027f38f06b9456c11f08f52d8a9adf8f8b0688cad1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea8499e1bf5006e646d10aa39a1eb6eac938be689626391b76d8a3ca9489e702',2001,'SR','Suriname','geography',1059,'Location: Northern South America, bordering the
North Atlantic Ocean, between French Guiana and','c0a0885b01b1a745b37f8ab18e10fdb72d8d2d07eb19f2951d3d194c03e6aa71','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e83ec71e15636c8dfe11d075e4022ac6b1a616f20e06464f350007bf80b37df',2001,'GY','Guyana','geography',1060,'Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
tofa/: 163,270 sq km
/and; 161 ,470 sq km
water; 1,800 sq km
Area - comparative: slightly larger than Georgia
Land boundaries:
tote/; 1,707 km
border countries: Brazil 597 km, French Guiana 510
km, Guyana 600 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain with
swamps
Elevation extremes:
lowest point: unnamed location in the coastal plain -2 m
highest point: Juliana Top 1 ,230 m
Natural resources: timber, hydropower, fish, kaolin,
shrimp, bauxite, gold, and small amounts of nickel,
copper, platinum, iron ore
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 96%
otoer; 4% (1993 est.)
note: there are 94,927 hectares of arable land, 7,195
hectares of permanent crops, and 15,000 hectares of
permanent pastures
Irrigated land: 600 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation as
timber is cut for export; pollution of inland waterways
by small-scale mining activities
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: mostly tropical rain forest; great
diversity of flora and fauna that, for the most part, is
increasingly threatened by new development;
relatively small population, most of which lives along
the coast
Location: Northern Europe, islands between the
Arctic Ocean, Barents Sea, Greenland Sea, and
Norwegian Sea, north of Norway
Geographic coordinates: 78 00 N, 20 00 E
Map references: Arctic Region
Area:
total: 62,049 sq km
land: 62,049 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear
Island)
Area ■ comparative: slightly smaller than West
Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
exclusive fishing zone: 200 NM unilaterally claimed
by Norway but not recognized by Russia
territorial sea: 4
Climate: arctic, tempered by warm North Atlantic
Current; cool summers, cold winters; North Atlantic
Current flows along west and north coasts of
Spitsbergen, keeping water open and navigable most
of the year
Terrain: wild, rugged mountains; much of high land
Ice covered; west coast clear of ice about one-half of
the year; fjords along west and north coasts
Elevation extremes:
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources: coal, copper, iron ore,
phosphate, zinc, wiidlife, fish
479
Svalbard (continued)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (no trees, and the only bushes are
crowberry and cloudberry)
Irrigated land: NAsqkm
Natural hazards: ice floes often block up the
entrance to Bellsund (a transit point for coal export) on
the west coast and occasionally make parts of the
northeastern coast inaccessible to maritime traffic
Environment - current issues: NA
Geography - note: northernmost part of the
Kingdom of Norway; consists of nine main islands;
glaciers and snowfields cover 60% of the total area
Location: Southern Africa, between Mozambique
and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area:
total: 17,363 sq km
land: 17,203 sq km
water: 1 60 sq km
Area - comparative: slightly smaller than New','2719e918fe9def05fc54873be36fdcad0c8e06768500f8b2d65101ec9a66e705','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe9fddabba35c87df836311b7b2b5cd13e5b9518683af20b96c8d2c2948196f4',2001,'PK','Pakistan','geography',1066,'Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references; Commonwealth of Independent
States
Area:
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries;
fofa/; 3,651 km
border counfr/es; Afghanistan 1,206 km, China 414
km, Kyrgyzstan 870 km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild
winters; semiarid to polar in Pamir Mountains
Terrain: Pamir and Alay mountains dominate
landscape; western Fergana Valley in north,
Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes;
lowest point: Syrdariya 300 m
highest point: Pik Imeni Ismail Samani 7,495 m
Natural resources: hydropower, some petroleum,
uranium, mercury, brown coal, lead, zinc, antimony,
tungsten, silver, gold
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 4%
other: 65% (1 993 est.)
Irrigated land: 6,390 sq km (1993 est.)
Natural hazards: NA
Environment - current issues; inadequate
sanitation facilities; increasing levels of soil salinity;
Industrial pollution; excessive pesticides; part of the
basin of the shrinking Aral Sea suffers from severe
overutilization of available water for irrigation and
associated pollution
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Marine
Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
Location: Eastern Africa, bordering the Indian
Ocean, between Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,087 sq km
land: 886,037 sq km
water; 59,050 sq km
note: includes the islands of Mafia, Pemba, and
Zanzibar
Area - comparative: slightly larger than twice the
size of California
Land boundaries:
total: 3,402 km
border countries: Burundi 451 km, Kenya 769 km,
Malawi 475 km, Mozambique 756 km, Rwanda 217
km, Uganda 396 km, Zambia 338 km
Coastline; 1,424 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast; central plateau;
highlands in north, south
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
493
Tanzania (continued)
Natural resources: hydropower, tin, phosphates,
iron ore, coal, diamonds, gemstones, gold, natural
gas, nickel
Land use:
arable land: 3%
permanent crops: ^%
permanent pastures: 40%
forests and woodland: 38%
ote18%(1993 est.)
Irrigated land: 1 ,500 sq km (1 993 est.)
Natural hazards: flooding on the central plateau
during the rainy season; drought
Environment - current issues: soil degradation;
deforestation; desertification; destruction of coral
reefs threatens marine habitats; recent droughts
affected marginal agriculture
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: Nuclear Test Ban
Geography - note: Kilimanjaro is highest point in
Africa','39ed14c7e105c54dd28a71cf616dbdbd684fcf068ac682db43a2648c8539a2fe','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('908ba1e4b65c62ea76d07e622f2cdcb0f672caa184db2560c6c23c8dd151b2cc',2001,'TO','Tonga','geography',1076,'Location: Oceania, archipelago in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','dba2c3f5cc9763816183b4cbb380a2ba67479dfface76994e5a899d532e5e760','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fedd961ba7341118947951bdd4ff1b30aba2eb9bdeda6f716e4cc75bbc554596',2001,'TV','Tuvalu','geography',1080,'Location: Oceania, island group consisting of nine
coral atolls in the South Pacific Ocean, about one-half
of the way from Hawaii to Australia
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total: 26 sq km
land: 26 sq km
water: 0 sq km
Area - comparative: 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastiine: 24 km
Maritime claims:
contiguous zone: 24 NM
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; moderated by easterly trade winds
(March to November); westerly gales and heavy rain
(November to March)
Terrain: very low-lying and narrow coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
ote 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: severe tropical storms are usually
rare, but, in 1 997, there were three cyclones; low level
of islands make them very sensitive to changes in sea
level
Environment - current issues: since there are no
streams or rivers and groundwater is not potable,
most water needs must be met by catchment systems
with storage facilities (the Japanese Government has
built one desalination plant and plans to build one
other); beachhead erosion because of the use of sand
for building materials; excessive clearance of forest
undergrowth for use as fuel; damage to coral reefs
from the spread of the Crown of Thorns starfish;
Tuvalu is very concerned about global increases in
greenhouse gas emissions and their effect on rising
sea levels, which threaten the country''s underground
water table
Environment - international agreements:
party to: Climate Change, Climate Change-Kyoto
Protocol, Desertification, Marine Dumping, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: Biodiversity, Law of the Sea
Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00 E
Map references: Africa
Area:
total: 236,040 sq km
/and; 1 99,71 Osq km
water: 36,330 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,698 km
border countries: Democratic Republic of the Congo
765 km, Kenya 933 km, Rwanda 169 km, Sudan 435
km, Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; generally rainy with two dry
seasons (December to February, June to August);
semiarid in northeast
Terrain: mostly plateau with rim of mountains
Elevation extremes:
lowest point: Lake Albert 621 m
highest point: Margherita Peak on Mount Stanley
5,110 m
Natural resources: copper, cobalt, hydropower,
limestone, salt, arable land
Land use:
arable land: 25%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 28%
other 29% (1993 est.)
Irrigated land: 90 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: draining of wetlands
for agricultural use; deforestation; overgrazing; soil
erosion; water hyacinth infestation in Lake Victoria;
poaching is widespread
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: landlocked
Location: Eastern Europe, bordering the Black Sea,
between Poland and Russia
Geographic coordinates: 49 00 N, 32 00 E
Map references: Commonwealth of Independent
States
Area:
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 4,558 km
border countries: Belarus 891 km, Hungary 103 km,
Moldova 939 km, Poland 428 km, Romania (south)
169 km, Romania (west) 362 km, Russia 1,576 km,
Slovakia 90 km
Coastline: 2,782 km
Maritime claims:
continental shelf: 200-m or to the depth of exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: temperate continental; Mediterranean only
on the southern Crimean coast; precipitation
disproportionately distributed, highest in west and
north, lesser in east and southeast; winters vary from
cool along the Black Sea to cold farther inland;
summers are warm across the greater part of the
country, hot in the south
Terrain: most of Ukraine consists of fertile plains
(steppes) and plateaus, mountains being found only in
the west (the Carpathians), and in the Crimean
Peninsula in the extreme south
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese,
natural gas, oil, salt, sulfur, graphite, titanium,
magnesium, kaolin, nickel, mercury, timber, arable
land
Land use:
arable land: 58%
permanent crops: 2%
permanent pastures: 1 3%
forests and woodland: 1 8%
of/}en9%(1993 est.)
Irrigated land: 26,050 sq km (1993 est.)
Natural hazards: NA
Environment - current Issues: inadequate
supplies of potable water; air and water pollution;
deforestation; radiation contamination in the northeast
from 1 986 accident at Chornobyl'' Nuclear Power Plant
Environment - International agreements;
party to; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol
521
Ukraine (continued)
Geography - note: strategic position at the
crossroads between Europe and Asia; second-largest
country in Europe','d5e0705795124c3525c5a834f481e0567d54d412f9d7e72b65dc28545cecc356','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3ea4fdad256228287acb0b2514b90008781ef6944c7bc9ba2f17d64a8ee8a19',2001,'OM','Oman','geography',1089,'Location: Middle East, bordering the Gulf of Oman
and the Persian Gulf, between Oman and Saudi
Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area:
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
Area ■ comparative: slightly smaller than Maine
Land boundaries:
total: 867 km
border countries: Oman 410 km, Saudi Arabia
457 km
Coastline: 1,318 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: ^2 NM
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging Into
rolling sand dunes of vast desert wasteland;
mountains in east
1 or to the edge of the
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: ^aba\\ Yibir 1,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 2%
forests and woodland: 0%
other 98% (1993 est.)
Irrigated land: 50 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment - current issues: lack of natural
freshwater resources being overcome by desalination
plants; desertification; beach pollution from oil spills
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Law of the Sea
Geography - note: strategic location along southern
approaches to Strait of Hormuz, a vital transit point for
world crude oil','479a2062aa16d7bc42d946a9163563994a19f879cecb2b4f2ebf1036b6d15952','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11573237dc9b3065065e1077ee1dbe9255eeaf3c09f26d6495a0cc5a31919234',2001,'GB','United Kingdom','geography',1099,'Location: Western Europe, islands including the
northern one-sixth of the island of Ireland between the
North Atlantic Ocean and the North Sea, northwest of','c787d283c2e22a1f57631ee037062bbb59858683c4c126a28ad13dd81380700a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96977e62379a43ae519fb5f10642d90817369ff6d8d5c53619686a1196f2afb2',2001,'UY','Uruguay','geography',1101,'Location: Southern South America, bordering the
South Atlantic Ocean, between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Area:
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area ■ comparative: slightly smaller than the state
of Washington
Land boundaries:
total: 1 ,564 km
border counfr/es; Argentina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: warm temperate; freezing temperatures
almost unknown
Terrain: mostly rolling plains and low hills; fertile
coastal lowland
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
533
Uruguay (continued)
Natural resources: arable land, hydropower, minor
minerals, fisheries
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 77%
forests and woodland: 6%
other: ^0%{^997 est.)
Irrigated land: 7,700 sq km (1997 est.)
Natural hazards: seasonally high winds (the
pampero is a chilly and occasional violent wind
which blows north from the Argentine pampas),
droughts, floods; because of the absence of
mountains, which act as weather barriers, all
locations are particularly vulnerable to rapid changes
in weather fronts
Environment ■ current issues: water pollution from
meat packing/tannery industry; inadequate solid/
hazardous waste disposal
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Nuclear
Test Ban','3eff7e35bf4f1b309c16b5150dd738b382768ef1a19a549a7d690de41a14b68c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc1b34f00c5469c5e2d19be898a7f40546e96fcda22f20822caa7adc635b4e71',2001,'UZ','Uzbekistan','geography',1108,'Location: Central Asia, north of Afghanistan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Commonwealth of Independent
States
Area:
total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: e,22^ km
border countries: Afghanistan 137 km, Kazakhstan
2,203 km, Kyrgyzstan 1 ,099 km, Tajikistan 1,161 km,
Turkmenistan 1,621 km
Coastline: 0 km; note - Uzbekistan includes the
southern portion of the Aral Sea with a 420 km
shoreline
Maritime claims: none (doubly landlocked)
Climate: mostly midlatitude desert, long, hot
summers, mild winters; semiarid grassland in
east
along course of Amu Darya, Sirdaryo (Syr Darya), and
Zarafshon; Fergana Valley in east surrounded by
mountainous Tajikistan and Kyrgyzstan; shrinking
Aral Sea in west
Elevation extremes:
lowest point: Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal,
gold, uranium, silver, copper, lead and zinc, tungsten,
molybdenum
Land use:
arable land: 9%
permanent crops: ^%
permanent pastures: 46%
forests and woodland: 3%
of/?er41%(1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: drying up of the Aral
Sea is resulting in growing concentrations of chemical
pesticides and natural salts; these substances are
then blown from the increasingly exposed lake bed
and contribute to desertification; water pollution from
industrial wastes and the heavy use of fertilizers and
pesticides is the cause of many human health
disorders; increasing soil salination; soil
contamination from agricultural chemicals, including
DDT
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: along with Liechtenstein, one of
the only two doubly landlocked countries in the world','150b69e04df30aa8c660ae96567d097a6023d318d0afa0afb0a6c0d98956904c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a14ac6ac7a2e5c0c2905b5f894092d720fb68f58e1ce39fadd5b2579a55988ee',2001,'AF','Afghanistan','geography',1116,'Location: Oceania, group of islands in the South
Pacific Ocean, about three-quarters of the way from
Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area:
total: 12,200 sq km
land: 12,200 sq km
water: 0 sq km
note: includes more than 80 islands
Area - comparative: slightly larger than Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 NM
538
Vanuatu (continued)
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical; moderated by southeast trade
winds
Terrain: mostly mountains of volcanic origin; narrow
coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: JabmmdiSanSi1,B77 m
Natural resources: manganese, hardwood forests,
fish
Land use:
arable land: 2%
permanent crops: 1 0%
permanent pastures: 2%
forests and woodland: 75%
other; 11% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: tropical cyclones or typhoons
(January to April); volcanism causes minor
earthquakes
Environment - current issues: a majority of the
population does not have access to a potable and
reliable supply of water; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Location: Northern South America, bordering the
Caribbean Sea and the North Atlantic Ocean,
between Colombia and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America, Central America
and the Caribbean
Area:
total: 912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Area - comparative: slightly more than twice the
size of California
Land boundaries:
total: 4,993 km
border countries: Brazil 2,200 km, Colombia 2,050
km, Guyana 743 km
Coastline: 2,800 km
Maritime claims:
contiguous zone: 1 5 NM
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Venezuela (continued)
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: Andes Mountains and Maracaibo Lowlands
in northwest; central plains (llanos); Guiana Highlands
in southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna) 5,007 m
Natural resources: petroleum, natural gas, iron ore,
gold, bauxite, other minerals, hydropower, diamonds
Land use:
arable land: 4%
permanent crops: ^%
permanent pastures: 20%
forests and woodland: 34%
other: 4i% (1993 est.)
Irrigated land: 1,900 sq km (1993 est.)
Natural hazards: subject to floods, rockslides,
mudslides; periodic droughts
Environment - current issues: sewage pollution of
Lago de Valencia; oil and urban pollution of Lago de
Maracaibo; deforestation; soil degradation; urban and
industrial pollution, especially along the Caribbean
coast; threat to the rainforest ecosystem from
irresponsible mining operations
Environment - international agreements:
party to; Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping
Geography - note: on major sea and air routes
jinking North and South America
Location: Southeastern Asia, bordering the Gulf of
Thailand, Gulf of Tonkin, and South China Sea,
alongside China, Laos, and Cambodia
Geographic coordinates: 16 00 N, 106 00 E
Map references: Southeast Asia
Area:
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
tofa/; 4,639 km
border counf/ves.'' Cambodia 1,228 km, China 1,281
km, Laos 2,130 km
Coastiine: 3,444 km (excludes islands)
Maritime ciaims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical in south; monsoonal in north with
hot, rainy season (mid-May to mid-September) and
warm, dry season (mid-October to mid-March)
Terrain: low, flat delta in south and north; central
highlands; hilly, mountainous in far north and
northwest
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Ngoc Linh 3,143 m
Natural resources: phosphates, coal, manganese,
bauxite, chromate, offshore oil and gas deposits,
forests, hydropower
Land use:
arable land: M%
permanent crops: 4%
permanent pastures: 1 %
forests and woodland: 30%
ofber.''48% (1993 est.)
Irrigated land: 18,600 sq km (1993 est.)
Natural hazards: occasional typhoons (May to
January) with extensive flooding
Environment - current Issues: logging and
slash-and-burn agricultural practices contribute to
deforestation and soil degradation; water pollution
and overfishing threaten marine life populations;
groundwater contamination limits potable water
supply; growing urban industrialization and population
migration are rapidly degrading environment in Hanoi
and Ho Chi Minh City
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: C\\\\r(]a\\e Change-Kyoto
Protocol, Nuclear Test Ban
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean, east of','b45f33736ab34c62b02ae589a82dc9df134764de4478ac7ed08118c482e3de47','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12fad07653daad99590489f1ff1127db0479102cfff90836f4ae5bde7189b6d1',2001,'MP','Northern Mariana Islands','geography',1128,'Geographic coordinates: 19 17 N, 166 36 E
Map references; Oceania
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area - comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims:
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate; tropical
Terrain: atoll of three coral islands built up on an
underwater volcano; central lagoon is former crater,
islands are part of the rim
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land; 0 sq km (1998)
Natural hazards; occasional typhoons
Environment - current issues: NA
Geography - note: strategic location in the North
Pacific Ocean; emergency landing location for
transpacific flights','5e589efd1545096408dc9305bca5211e74ee8e24b41fc79026ea7970512232b8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('631c6c878b2f9572a1dda3e0fdebbd6620b23106bb5aaf5a30072a171ceb1008',2001,'WF','Wallis and Futuna','geography',1131,'Location: Oceania, islands in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','e0b14fbea7a6600686b865ca0f5eac39b8c110a5a9fda69667701ce167afead3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5437a0f8427ccfb8a493296984fc1c39a9329cafab4275cad0f91bef136d5003',2001,'YE','Yemen','geography',1134,'Location: Middle East, bordering the Arabian Sea,
Gulf of Aden, and Red Sea, between Oman and Saudi
Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area;
total: 527,970 $q km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen
Arab Republic (YAR or North Yemen), and the former
People''s Democratic Republic of Yemen (PDRY or
South Yemen)
Area - comparative: slightly larger than twice the
size of Wyoming
Land boundaries:
total: 1 ,746 km
border countries: Oman 288 km, Saudi Arabia 1,458
km
Coastline: 1,906 km
Maritime claims:
contiguous zone: 24 NM
continental shelf: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: mostly desert; hot and humid along west
coast; temperate in western mountains affected by
seasonal monsoon; extraordinarily hot, dry, harsh
desert in east
Terrain: narrow coastal plain backed by flat-topped
hills and rugged mountains; dissected upland desert
plains in center slope into the desert interior of the
Arabian Peninsula
Elevation extremes:
/owesfpo/nf; Arabian Sea 0 m
highest point: 33ba.\\ an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt,
marble, small deposits of coal, gold, lead, nickel, and
copper, fertile soil in west
Land use:
arable land: 3%
permanent crops: ^3%
permanent pastures: 33.5%
forests and woodland: 4%
ofte 46.5% (1999)
Irrigated land: 5,674 sq km (1999)
Natural hazards: sandstorms and dust storms in
summer
Environment - current issues: very limited natural
fresh water resources; inadequate supplies of potable
water; overgrazing; soil erosion; desertification
Environment - International agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Nuclear Test Ban
Geography - note: strategic location on Bab el
Mandeb, the strait linking the Red Sea and the Gulf of
Aden, one of world''s most active shipping lanes
Location: Southeastern Europe, bordering the
Adriatic Sea, between Albania and Bosnia and
Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
tofa/; 102,350 sq km
557
Yugoslavia (continued)
/anof; 102,136 sq km
loafer; 214 sq km
Area - comparative: slightly smaller than Kentucky
Land boundaries;
total: 2,246 km
border countries: Albania 287 km, Bosnia and
Herzegovina 527 km, Bulgaria 31 8 km, Croatia (north)
241 km, Croatia (south) 25 km, Hungary 151 km, The
Former Yugoslav Republic of Macedonia 221 km,
Romania 476 km
Coastline: 199 km
Maritime claims: NA
Climate: in the north, continental climate (cold
winters and hot, humid summers with well distributed
rainfall): central portion, continental and
Mediterranean climate; to the south, Adriatic climate
along the coast, hot, dry summers and autumns and
relatively cold winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile
plains; to the east, limestone ranges and basins; to the
southeast, ancient mountains and hills; to the
southwest, extremely high shoreline with no islands
off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper,
lead, zinc, nickel, gold, pyrite, chrome, hydropower,
arable land
Land use:
arable land: 40%
permanent crops: 0%
permanent pastures: 20.7%
forests and woodland: 1 7.3%
ofher: 22% (1998 est.)
Irrigated land: NAsqkm
Natural hazards: destructive earthquakes
Environment - current issues: pollution of coastal
waters from sewage outlets, especially in
tourist-related areas such as Kotor; air pollution
around Belgrade and other industrial cities; water
pollution from Industrial wastes dumped into the Sava
which flows into the Danube
Environment - international agreements:
party to: Air Pollution, Climate Change, Hazardous
Wastes, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Biodiversity
Geography - note: controls one of the major land
routes from Western Europe to Turkey and the Near
East; strategic location along the Adriatic coast','de42e36498864751987c5d749520ff5bf41e52117a77b149d2036da05e69434e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('512503f1631fa723d5dee786f4885e62bf39f400dd4a764d79453f9c2882f1df',2001,'ZM','Zambia','geography',1143,'Location: Southern Africa, east of Angola
Geographic coordinates: 15 00 S, 30 00 E
Map references: Africa
Area:
fo/a/.'' 752,614 sq km
land: 740,724 sq km
wafer; 11,890 sq km
Area - comparative: slightly larger than Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1 ,1 10 km, Democratic
Republic of the Congo 1 ,930 km, Malawi 837 km,
Mozambique 41 9 km, Namibia 233 km, Tanzania 338
km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; modified by altitude; rainy season
(October to April)
Terrain: mostly high plateau with some hills and
mountains
Elevation extremes:
lowest point: Zambezi river 329 m
highest point: unnamed location in Mafinga Hills
2,301 m
Natural resources; copper, cobalt, zinc, lead, coal,
emeralds, gold, silver, uranium, hydropower
560
Zambia (continued)
Land use;
arable land: 7%
permanent crops: 0%
permanent pastures: 40%
forests and woodland: 39%
of/?er; 14% (1993 est.)
Irrigated land: 460 sq km (1993 est.)
Natural hazards: tropical storms (November to
April)
Environment - current issues: air pollution and
resulting acid rain in the mineral extraction and
refining region; chemical runoff into watersheds:
poaching seriously threatens rhinoceros, elephant,
antelope, and large cat populations: deforestation: soil
erosion; desertification; lack of adequate water
treatment presents human health risks
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: landlocked
Location: Southern Africa, between South Africa
and Zambia
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
tofa/; 390,580 sq km
land: 386,670 sq km
wafer 3,91 Osq km
Area - comparative: slightly larger than Montana
Land boundaries:
total: 3,066 km
border countries: Botswana 813 km, Mozambique
1 ,231 km. South Africa 225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; moderated by altitude; rainy
season (November to March)
Terrain: mostly high plateau with higher central
plateau (high veld); mountains in east
Elevation extremes:
/owesfpo/nf.'' junction of the Runde and Save rivers
162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos,
gold, nickel, copper, iron ore, vanadium, lithium, tin,
platinum group metals
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 23%
off?er.- 57% (1993 est.)
Irrigated land: 1 ,930 sq km (1993 est.)
Natural hazards: recurring droughts; floods and
severe storms are rare
Environment - current issues: deforestation; soil
erosion; land degradation; air and water pollution; the
black rhinoceros herd - once the largest concentration
of the species in the world - has been significantly
reduced by poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked','71d0eda8297c25d4783581f88c52a52365c6d185a82177f521bc7c24887dba8a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f76764567fc7de5c831fbaaa2addd8b7d2219a927ff3212a1368e1216e5c8198',2001,'WF','Wallis and Futuna','geography',10,'This category includes the entries dealing with the natural environment
and the effects of human activity.
Geography - note
This entry includes miscellaneous geographic information of
significance not included elsewhere.
GNP
Gross national product (GNP) is the value of all final goods and
services produced within a nation in a given year, plus income earned
by its citizens abroad, minus income earned by foreigners from domestic
production. The Factbook, following current practice, uses GDP rather
than GNP to measure national production. However, the user must realize
that in certain countries net remittances from citizens working abroad
may be important to national well-being.','05f6c34bbbde789b97a2a560dac5b9aaf21d3441cef6cde35db0b8b18b61e46d','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

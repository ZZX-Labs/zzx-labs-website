SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3b0b95d4f33eaecdffd12354cfdb56bae45935aaae0b406da7878e9389a4b84',2001,'EH','Western Sahara','transnational-issues',15,'Disputes - international
Illicit drugs
XXIX
Afghanistan [ i
Background: Afghanistan was invaded and
occupied by the Soviet Union in 1 979. The USSR was
forced to withdraw 10 years later by anti-communist
mujahidin forces supplied and trained by the US,
Saudi Arabia, Pakistan, and others. Fighting
subsequently continued among the various mujahidin
factions, but the fundamentalist Islamic Taliban
movement has been able to seize most of the country.
In addition to the continuing civil strife, the country
suffers from enormous poverty, a crumbling
infrastructure, and widespread land mines.
Disputes - international: support to Islamic
militants worldwide by some factions; question over
which group should hold Afghanistan''s seat at the UN
Illicit drugs: world''s largest illicit opium producer,
surpassing Burma (potential production in 1999 -
1 ,670 metric tons; cultivation in 1999 - 51 ,500
hectares, a 23% increase over 1998); a major source
of hashish; increasing number of heroin-processing
laboratories being set up in the country; major political
factions in the country profit from drug trade
Background: Morocco virtually annexed the
northern two-thirds of Western Sahara (formerly
Spanish Sahara) in 1976, and the rest of the territory
in 1979, following Mauritania''s withdrawal. A guerrilla
war with the Polisario Front contesting Rabat''s
sovereignty ended in a 1991 cease-fire; a referendum
on final status has been repeatedly postponed and is
not expected to occur until at least 2002.
Disputes - international: claimed and administered
by Morocco, but sovereignty is unresolved and the UN
is attempting to hold a referendum on the issue; the
UN-administered cease-fire has been in effect since
September 1991
World
Wl
EH
ESH
732
.eh
Western Samoa
—
—
—
—
.ws
see Samoa
World
the Factbook uses the W data code
from DIAM 65-18 Geopolitical Dei\\a
Elements and Related Features, Data
Standard No. 3, December 1994,
published by the Defense Intelligence
Agency
23 45 N
15 45W
Rio Muni (mainland region)
24 30 N
13 00W
Sahel (region)
Burkina Faso, Chad, The Gambia, Guinea- Bissau,
Mali, Mauritania, Niger, Senegai
15 00N
800W
Saigon (city; former name for Ho Chi Minh City)
Vietnam
10 45N
106 40 E
Saint Barthelemy (Saint Bart’s) (island)
24 30 N
13 00W
Spanish West Africa (former name for Ifni and Spanish
Sahara)
Morocco, Western Sahara
25 00 N
13 00W
Spice Islands (Moluccas)','d686c87766e9ab81928fca1ec1b8b4cd47c3d77508f1ab24abb46aba52052436','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54dd839f5ffdbd97beb8b2fa199ba35826cc66e516dec3e82fc5bfef643ebd47',2001,'AL','Albania','transnational-issues',17,'Background: In 1 990 Albania ended 44 years of
xenophobic communist rule and established a
multiparty democracy. The transition has proven
difficult as corrupt governments have tried to deal with
high unemployment, a dilapidated infrastructure,
widespread gangsterism, and disruptive political
opponents. International observers judged local
elections in 2000 to be acceptable and a step toward
democratic development, but serious deficiencies
remain to be corrected before the the 2001
parliamentary elections.
Disputes - international; the Albanian Government
supports protection of the rights of ethnic Albanians
outside of its borders but has downplayed them to
further its primary foreign policy goal of regional
cooperation; Albanian majority in Kosovo seeks
independence from Yugoslavia; Albanians in The
Former Yugoslav Republic of Macedonia claim
discrimination in education, access to public-sector
jobs, and representation in government
Illicit drugs: increasingly active transshipment point
for Southwest Asian opiates, hashish, and cannabis
transiting the Balkan route and - to a far lesser extent -
cocaine from South America destined for Western
Europe; limited opium and cannabis production;
ethnic Albanian narcotrafficking organizations active
and rapidly expanding in Europe
Disputes - international: part of southeastern
region claimed by Libya; Algeria supports exiled West
Saharan Polisario Front and rejects Moroccan
administration of Western Sahara
AL
AL
ALB
008
.al
41 00 N
20 00 E
Siam (former name for Thailand)
41 20 N
19 50E
Tirane (see Tirana)
41 20 N
19 50 E
Tirol (region)
Austria, Italy
47 00 N
1100E
Tobago (island)','7c6ca74780493ecfe88c49b490d448e99f52a5c182115285159b5d6eb40ed227','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b174bb4e184a6b86c932504269ca00691015721f1a28df6d7d720a818614e11b',2001,'AS','American Samoa','transnational-issues',26,'(territory of the US)
Disputes - international: none
AQ
AS
ASM
016
.as
14 20S
170 00 W
Eesti (local name for Estonia)
1413S
169 35 W
Maputo (capital)
1416S
170 42 W
Palawan (island)
11 03 S
171 15W
Swan Islands
1418S
170 42 W
Tyrol, South (region)','3501761724016692ab67e69baf36bafd88f0d12c0bcc61825b663d2cc8b91627','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9e8a3fe89cbd0e920e4558554acd44598c262f500a93a22fc9038b39e82a424',2001,'AD','Andorra','transnational-issues',34,'Background: Long isolated and impoverished,
mountainous Andorra has achieved considerable
prosperity since World War II through its tourist
industry. Many immigrants (legal and illegal) are
attracted to the thriving economy with its lack of
income taxes.
Disputes - International: none
AN
AD
AND
020
.ad
42 30N
130E
Andros (island)','14cd67bd68114ed1a44c2a64674a68120e44fba1428f28c5c963d0e92401da7e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b1e22ad9eaba93b41925eb503226f4bbf9c3894348eed9cfd252f804648efb9',2001,'AO','Angola','transnational-issues',41,'Background: Civil war has been the norm in Angola
since independence from Portugal in 1975. A 1994
peace accord between the government and the
National Union for the Total Independence of Angola
(UNITA) provided for the integration of former UNITA
Insurgents into the government and armed forces. A
national unity government was installed in April of
1997, but serious fighting resumed in late 1998,
rendering hundreds of thousands of people homeless.
Up to 1 .5 million lives may have been lost in fighting
over the past quarter century.
Terrain: narrow coastal plain rises abruptly to vast
interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, Iron ore,
phosphates, copper, feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
ofher; 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes
periodic flooding on the plateau
Environment - current issues: overuse of pastures
and subsequent soil erosion attributable to population
pressures; desertification; deforestation of tropical
rain forest, in response to both international demand
for tropical timber and to domestic use as fuel,
resulting in loss of biodiversity; soil erosion
contributing to water pollution and siltation of rivers
and dams; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: Cabinda is separated from rest
of country by the Democratic Republic of the Congo
Disputes - international: none
Illicit drugs: increasingly used as a transshipment
point for cocaine and heroin destined for Western
Europe and other African states
AO
AO
AGO
024
.ao
5 33S
1212E
Cabo Verde (local name for Cape Verde)
Cape Verde
16 00N
24 00 W
Cabot Strait
Atlantic Ocean
4720N
59 30 W
Caicos Islands
8 48S
1314E
Lubnan (local name for Lebanon)
,< Lubumbashi ; LN.V*-''?
malaW(^
Kltwe*\\J Ulongwdll ■■ ■
ZAMBIA:;
Lusaka^,-^
''(Mv Cldadef j (adinln. by France,
de Nacala I claimed by Comoro!!
Ul,„,yrc
^yA a''RAnCE) /
Tropic ol Capricorn
\\ Windhoek J BOTSWAPiA
VVaivisBay\\ ★ KALAHARI
- Y mWlBIA - e-e^ft^ ^
: MO^BICfUE
■ ^»^f(dra Mcygnibujnc ^ ''^lA^^tananarivo j
■ \\ firanncl ^7/ sTDctHsT #—20^
U do tndlo “Lorop./ MADAGASCAR Ktfunlon j
I M Island Y'' ; (PRAMCE) /
- 0-E^R^ -j^ - — -V - ^ _
Gabor^e^ Pretoria ]
) ^ Xo''^Maputo
“’“‘’•"""“’“''SMbebeJeW
SOUTH SWAZILAND
Scale 1:51,400,000
Azimuthal Equal-Area Projection
Boundary representation is
not necessarily authoritative.
AmicA---eSop
1 n d i a n O c e a t
802793AI (R02109) 4-01
ANTARCTIC REGION
802800AI (R02207) 4-01
ARCTIC REGION
802799AI {R02112) 4-01
ASIA','ce7d4defe7cdc1cb18b88834cdba92c63f5d7a3c7e0ad511accbe805da8a46ad','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9147aafc730173a7d536e6102af0b637fd3d7e9c3e54b3cb42e607f7e42c562',2001,'AI','Anguilla','transnational-issues',48,'(overseas territory
0 20 40 km
North
Sombrero North
Atlantic
Caribbean Ocean
Sea
Atlantic
Ocean
0 5 10 km
Anguilla^^J^
St. Martin^^^j^”
0 5 lo''ml
Scrub
Island
Prickfey
V — ! Pear - Seal
Dog Cays Island
Island
\\ THE VALEEV
Fiond Bay- _ ^
Caribbean
^ ^^-^nguilla
Sea
Blowing Point
St. Martin _ _ ^ ^
(FRANCE and NETH.)
Disputes - international: none
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe
AV
Al
AIA
660
.ai
1813N
63 04W
Van Diemen Strait (Osumi Strait)
Pacific Ocean
31 00 N
131 00 E
Vancouver Island','436dbe27e3f5b8658559c75f6f72ec4841171da07997b45985b710553ae478e4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f92a60875a1cc97d5e4fa3d942e7fa512d116103228dc62eb777660f4b749061',2001,'AQ','Antarctica','transnational-issues',56,'Background: Speculation over the existence of a
"southern land" was not confirmed until the early
1820s when British and American commercial
operators and British and Russian national
expeditions began exploring the Peninsula region and
areas south of the Antarctic Circle. Not until 1 838 was
it established that Antarctica was indeed a continent
and not just a group of islands. Various "firsts" were
achieved in the early 20th century, including: 1902,
first balloon flight (by British explorer Robert Falcon
SCOTT); 1 91 2, first to the South Pole (five Norwegian
explorers under Roald AMUNDSEN); 1928, first
fixed-wing aircraft flight (by Australian adventurer/
explorer Sir Hubert WILKINS); 1929, first flight over
the South Pole (by Americans Richard BYRD and
Bernt BALCHEN); and 1935, first transantarctic flight
(American Lincoln ELLSWORTH). Following World
War II, there was an upsurge in scientific research on
the continent. A number of countries have set up
year-round research stations on Antarctica. Seven
have made territorial claims, but no other country
recognizes these claims. In order to form a legal
framework for the activities of nations on the continent,
an Antarctic T reaty was negotiated that neither denies
nor gives recognition to existing territorial claims;
signed in 1959, it entered into force in 1961.
Disputes - international: Antarctic Treaty freezes
claims (see Antarctic Treaty Summary in Government
type entry); sections (some overlapping) claimed by
Argentina, Australia, Chile, France, New Zealand,
Norway, and UK; the US and most other nations do
not recognize the territorial claims of other nations and
have made no claims themselves (the US and Russia
reserve the right to do so); no claims have been made
in the sector between 90 degrees west and 150
degrees west
Disputes - international: claims UK-administered
Falkland Islands (Islas Malvinas); claims
UK-administered South Georgia and the South
Sandwich Islands; territorial claim in Antarctica
partially overlaps British and Chilean claims
illicit drugs; use as a transshipment country for
cocaine headed for Europe and the US; increasing
use as a money-laundering center; domestic
consumption of drugs in urban centers is increasing
23
Disputes - international: Armenia supports ethnic
Armenians in the Nagorno-Karabakh region of
Azerbaijan in the longstanding, separatist conflict
against the Azerbaijani Government; traditional
demands regarding former Armenian lands in Turkey
have subsided
Illicit drugs: illicit cultivator of cannabis mostly for
domestic consumption; increasingly used as a
transshipment point for illicit drugs - mostly opium and
hashish - to Western Europe and the US via Iran,
Central Asia, and Russia
Disputes - International: none
Illicit drugs: drug-money-laundering center and
transit point for narcotics bound for the US and Europe
27
Ashmore and
Cartier Islands
(territory of Australia)
Disputes ■ international: none
Atlantic Ocean
Disputes - international: some maritime disputes
(see littoral states)
AY
AQ
ATA
010
.aq
ISO defines as the territory south of
60 degrees south latitude
66 30S
139 00 E
Aden (city)
71 00 S
70 00 W
Alexandretta (region; former name for Iskenderun)
Turkey
36 34 N
36 08 E
Alexandria (city)
6700S
163 00 E
Balochistan (region)
79 30S
49 30 W
Berlin (capital)
62 56S
60 34 W
Denmark Strait
Atlantic Ocean
67 DON
24 00 W
D''Entrecasteaux Islands
75 00S
92 00 W
Elobey, Islas de (island group)
6500S
64 00 W
Gran Chaco (region)
Argentina, Paraguay
2400S
60 00 W
Grand Bahama (island)
The Bahamas
26 40 N
78 35 W
Grand Banks (fishing ground)
Atlantic Ocean
47 06 N
55 48 W
Grand Cayman (island)
77 00S
130 00 W
Marion Island
68 48 S
90 35 W
Philip Island
7330S
12 00E
Quemoy (island)
Taiwan
24 27 N
118 23 E
Quito (capital)
79 30S
162 00 W
Roseau (capital)
8000S
180 00 E
Ross Island
8130S
175 00 W
Ross Sea
Antarctica, Southern Ocean
76 00S
175 00 W
Rossiya (local name for Russia)
Russia
60 00 N
100 00 E
Rota (island)
6724S
179 55 W
Senegambia (region; former name of confederation
of Senegal and The Gambia)
The Gambia, Senegal
13 SON
15 25W
Senyavin Islands
Federated States of Micronesia
655 N
158 00E
Seoul (capital)
South Korea
37 34N
127 00 E
Serbia and Montenegro
Yugoslavia
43 00 N
21 00 E
Serendib (former name for Sri Lanka)
KUim
45 00 W
South Ossetia (region)
62 00S
59 00 W
South Tyrol (region)
66 30S
139 00 E
Terres Australes et Antarctiques Francaises (local name
for the French Southern and Antarctic Lands)
French Southern and Antarctic Lands
43 DOS
67 00 E
Thailand, Gulf of
Pacific Ocean
10 00N
101 00 E
Thimphu (capital)
7220S
99 00 W
Tiberias, Lake
72 00S
155 00 E
Vienna (capital)
71 00 S
120 00 E
Willemstad (capital)
Netherlands Antilles
12 06N
68 56 W
Windhoek (capital)','cd34462ace627a3e0336142845ca89c6077e22187111d44a8e6195e8574cf86b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19aa719dcd32601e50c44dad911d07e00787c21dd74febafd9da90f36ceadf94',2001,'AG','Antigua and Barbuda','transnational-issues',64,'Background: The islands of Antigua and Barbuda
became an independent state within the British
Commonwealth of Nations in 1981 . Some 3,000
refugees fleeing a volcanic eruption on nearby
Montserrat have settled in Antigua and Barbuda since
1995.
AC
AG
ATG
028
.ag
14 34N
90 44W
Antipodes Islands
17 38N
61 48 W
Barents Sea
Arctic Ocean
74 00 N
36 00E
Barranquilla (city)
16 55N
6219W
Republica Dominicana (local name for Dominican
Republic)
17 06N
61 51 W
Saint Lawrence Island','c7836255887172e95c0fc79d6f989395fc2d9467869a3570d3abae6027d1b4c9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b44fd8b335b2d17dc6b8086caf606012fc6e68320f72115f384ed165141fcc89',2001,'GP','Guadeloupe','transnational-issues',73,'Disputes - International: none
Illicit drugs: considered a minor transshipment point
for narcotics bound for the US and Europe; more
significant as a drug-money-laundering center
Arctic Ocean
Disputes - international: some maritime disputes
(see littoral states)
(overseas department
of France)
GP
GP
GLP
312
•gp
16 00N
61 44 W
Basseterre (capital)
1755N
62 52 W
Saint Brandon (Cargados Carajos Shoals)
18 04N
63 04 W
Saint-Pierre (capital)','032befe8f9ca6384922369b2e6f1fac9d3a9a4a0ea046bff1f00a0d80a625bf9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55dca2ca33c1263332efef17ad52d390d3e1cd1ad4407b79cd61567adf6e29ba',2001,'AR','Argentina','transnational-issues',77,'Background: Following independence from Spain in
1816, Argentina experienced periods of internal
political conflict between conservatives and liberals
and between civilian and military factions. After World
War II, a long period of Peronist dictatorship was
followed by a military junta that took power in 1976.
Democracy returned in 1983, and numerous elections
since then have underscored Argentina''s progress in
democratic consolidation.
Illicit drugs: illicit producer of cannabis, most or all of
which is consumed in South America; transshipment
country for Andean cocaine headed for Southern
Cone markets and Europe
AR
AR
ARG
032
.ar
34 36S
58 27 W
Bujumbura (capital)
35 00 N
63 00 W
647
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry In The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Panama (capital)
48 00S
61 00 W
Peking (see Beijing)','705a7a154238b6018514b0fb8fb99938d746400f970a6859f76d1587fee240af','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea3e0345abbe2e84783ef3ae1aeb167768dcb8251a3bbcfa9830860174c0b7d5',2001,'AU','Australia','transnational-issues',90,'Disputes - international: territorial claim in
Antarctica (Australian Antarctic Territory)
Illicit drugs: Tasmania is one of the world''s major
suppliers of licit opiate products; government
maintains strict controls over areas of opium poppy
cultivation and output of poppy straw concentrate
31
Disputes - international: minor disputes with Czech
Republic and Slovenia over nuclear power plants and
post-World War II treatment of German-speaking
minorities
Illicit drugs: transshipment point for Southwest
Asian heroin and South American cocaine destined
for Western Europe
Disputes -international: none
Clipperton Island
(possession of France)
Background: This isolated island was named for
John CLIPPERTON, a pirate who made it his hideout
early in the 18th century. Annexed by France in 1855,
it was seized by Mexico in 1 897. Arbitration eventually
awarded the island to France, which took possession
in 1935.
Disputes -international: none
Disputes - international: none
Disputes -international: none
Disputes - international: none
Disputes • international: none
377
Norfolk Island /
(territory of Australia) i , '' /
0 2 4 km
0 2 4 ml
\\pascade
, Burnt Pine j
Norfolk Island ^
\\
- ,3
'' ^KINGSTON
^ ^ Nepean
Philip Island
n"
Disputes - international: none
Northern Mariana
Islands
(commonwealth in political
union with the US)
Farallon de
Pajaros.
0 100 200 km
0 100 200 mi
Maug Islands
''Asuncion Island
Pi!!ii;-f ):nc''
^Agrihan
Pagan
0
Noifn
Pci; ci lie
Guguan° Occen
^^Sarigan
''^Anatahan
''''Farallon de
Medinilla
Saipan
SAIPAN
'' Tinian
^Rota
AS
AU
AUS
036
.au
ISO includes Ashmore and Cartier
Islands, Coral Sea Islands
1012S
142 16 E
Banks Island
27 28S
153 02 E
Bristol Bay
Pacific Ocean
57 00 N
160 00 W
Bristol Channel
Atlantic Ocean
51 18 N
330W
Britain (see Great Britain)
3517S
149 08 E
Cancun (city)
2315S
155 32 E
Caucasus (region)
Russia
42 00 N
45 00 E
Cayenne (capital)
1025S
105 39 E
Christmas Island (Kiritimati) (Pacific Ocean)
3130S
159 00 E
Lorraine (region)
30 07S
147 24 E
Madagasikara (local name for Madagascar)
43 00S
147 00 E
Tatar Strait
Pacific Ocean
50 00 N
141 00 E
Taymyr Peninsula (Poluostrov Taymyr)
Russia
76 00N
104 00 E
Tbilisi (capital)
802795AI {R02105) 4-01
CENTRAL AFRICA
CENTRAL AMERICA AND THE CARIBBEAN
1 I i’ '' ? Pderto Lempira
■''■-HONDURAS'' .
.
^ A Puerto
.5 / Cabezas
‘ ''‘''"if ''
Salvad(
ficraldton
O
Pert hi
Bonlniry''
Q
GREAT VICTORIA
DESERT
^Kalgoorlie
^Kingston','0302641e0916bc1fb17b46d8ff1c353943ad6f0f435dbe384b5d262382775084','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a30bc6c2242f0509211fa7e21a3baee6fad7363226907e020578ff87e59c559',2001,'AZ','Azerbaijan','transnational-issues',91,'Background: Azerbaijan - a nation of Turkic
Muslims - has been an independent republic since the
collapse of the Soviet Union in 1991 . Despite a
cease-fire, in place since 1994, Azerbaijan has yet to
resolve its conflict with Armenia over the Azerbaijani
Nagorno-Karabakh enclave (largely Armenian
populated). Azerbaijan has lost almost 20% of its
territory and must support some 750,000 refugees
and internally displaced persons (IDPs) as a result of
the conflict. Corruption is ubiquitous and the promise
of widespread wealth from Azerbaijan''s undeveloped
petroleum resources remains largely unfulfilled.
Disputes - international: Armenia supports ethnic
Armenians in the Nagorno-Karabakh region of
Azerbaijan in the longstanding, separatist conflict
against the Azerbaijani Government; Caspian Sea
boundaries are not yet determined among Azerbaijan,
Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivation of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; transshipment point
for opiates via Iran, Central Asia, and Russia to
Western Europe
36
Background; Since attaining independence from the
UK in 1973, The Bahamas have prospered through
tourism and international banking and investment
management. Because of its geography, the country
is a major transshipment point for illegal drugs,
particularly shipments to the US, and its territory is
used for smuggling illegal migrants into the US.
AJ
AZ
AZE
031
.az
Bahamas, The
BF
BS
BHS
044
.bs
40 30N
47 30 E
Azerbaidzhan (local name for Azerbaijan)
40 30 N
47 30 E
Azores (islands)
40 23 N
49 51 E
Baku (capital)
40 23 N
49 51 E
Baky (see Baku)
40 23 N
49 51 E
Balabac Strait
Pacific Ocean
735 N
117 00 E
Balearic Islands
40 00N
46 40E
Nairobi (capital)
39 20 N
45 20 E
Naxos (island)','a53e47cdb00da41b863cc2e8f19e5daca779e33987e4f607546c0fcf2dc06c0e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('583826b4b1a77d269f7254a383960c7deca1ac2409e2c9b105be7285bda09ece',2001,'BS','Bahamas','transnational-issues',103,'Disputes ■ international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for US and Europe; banking industry
vulnerable to money laundering
38','aaa8d0bac256fa39430c314e3404261dfc373625fb7b5ea699d6ae6531cc1a4c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86ed5af316cdd7e43a31a369e33d5be540bb1fc1d7db5619f20bab62a8a35562',2001,'BH','Bahrain','transnational-issues',104,'Background: Bahrain''s small size and central
location among Persian Gulf countries require it to
play a delicate balancing act in foreign affairs among
its larger neighbors. Possessing minimal oil reserves,
Bahrain has turned to petroleum processing and
refining, and has transformed itself into an
international banking center. The new amir is pushing
economic and political reforms, and has worked to
improve relations with the Shi''a community. In 2001 ,
the International Court of Justice awarded the Hawar
Islands, long disputed with Qatar, to Bahrain.
Disputes - international: in March of 2001 , the
International Court of Justice (ICJ) awarded the
Hawar Islands to Bahrain and also adjusted Bahrain''s
maritime boundary with Qatar
40
Baker Island
(territory of the US)
0 0.25 0.5 km
0 0.25 0,5 mi
North Pacific Ocean
Disputes - international: none
BA
BH
BHR
048
.bh
Baker Island
FQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
26 00 N
50 33 E
Ai Imarat al Arabiyah al Muttahidah (local name for
the United Arab Emirates)
700 N
81 00 E
Diomede Islands
Russia (Big Diomede), United States (Little
Diomede)
65 47 N
169 00 W
Diu (region)
25 40 N
50 47E
Hayastan (local name for Armenia)
2613N
5035E
Manchukuo (former state)','09dd04ff6dcde450f30c24b009c69bfa42af8cd1e43ca63c937bae5ff8f5a26a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1924815fb40e5afd29dd03e72f72a28754cb4baaf35b490c266bbb14528578b1',2001,'BD','Bangladesh','transnational-issues',113,'Background: Bangladesh came into existence in
1971 when Bengali East Pakistan seceded from its
union with West Pakistan. About a third of this
extremely poor country annually floods during the
monsoon rainy season, hampering economic
development.
Disputes - international: a portion of the boundary
with India is indefinite; exchange of 151 enclaves
along border with India subject to ratification by Indian
parliament; dispute with India over South Talpatty/
New Moore Island
Illicit drugs: transit country for illegal drugs
produced in neighboring countries
43
BG
BD
BGD
050
.bd
23 43 N
90 25 E
Dhivehi Raajje (local name for Maldives)
24 00N
90 00 E
East Siberian Sea
Arctic Ocean
74 00 N
166 00 E
East Timor (Portuguese Timor)','2d9b079bec0e4b0bdb6acf53b971a169ced7472b20b01ac333775b7e936cfbc8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('221108afd40fb6492c0155301232d39f345507e7b7fcb06c9298252a0734a1ed',2001,'BB','Barbados','transnational-issues',121,'Background: The island was uninhabited when first
settled by the British in 1627. Its economy remained
heavily dependent on sugar, rum, and molasses
production through most of the 20th century. In the
1990s, tourism and manufacturing surpassed the
sugar industry in economic importance.
BB
BB
BRB
052
.bb
Bassas da India
BS
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
13 06N
59 37 W
Brisbane (city)
Bridgetown
Barquisimeto^ Valencia" "M^^acay;
Port-of-Spain ._^ TRINIDAD AND
. - - - ^ * <* ( TOBAGO
c===C — ^ '' V.
y i jrS fJ TTrim''bfid
Cum an A _ ^
Barcelona ^
Maturin* ,/ x
olon y ''“"J! —
'' Balboa *■-
-\\MA ■
Ui Paima , \\,\\
Bucnavoniura
■- :.T CucutJl ^
;. , f ;''■/ ) / 1 c^jian'' Cristobal
'' :v/:. '' { ■. V''tu
■/.''-'' X ^''y Bdcaramanga:r-" Arauca
Ollin; .fp ''a'' /^c''
-r- ^ri y '' 0^.
/(10 JU.O M B I A
“• # . s*
i#. / 0 :i
Ciudad Bolivar ^ ^ Ciudad Guayana
vbiCezuela
-;1.
Q Ayacucho
Georgetown','94266e7f314da9e5d649fa6e5ec185243e9415cb6330b0dbbd0722ea0a430584','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d66c8f2f5cc0e846737a21cd7a2efecc30325e3e67d51eab239bd46fec2e1deb',2001,'LC','Saint Lucia','transnational-issues',130,'Disputes - international: none
Illicit drugs: one of many Caribbean transshipment
points for narcotics bound for Europe and the US
45
Bassas da India
(possession of France)
0 2 4 ml Moyambiquc
Channel
ST
LC
LCA
662
.Ic
1401 N
61 00 W
Catalonia (region)','1b6a44a87e6e6e162aba54d10cb405874d2899f980e2586c41fe7e96bab324bd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('440de9cb578055c50e24e84fd979faefe66dc1c409b6f4ea38e065c54da22324',2001,'FR','France','transnational-issues',136,'Disputes - international: claimed by Madagascar
Background: After seven decades as a constituent
republic of the USSR, Belarus attained its
independence in 1991 . It has retained closer political
and economic ties to Russia than any of the other
former Soviet republics. Belarus and Russia signed a
treaty on a two-state union on 8 December 1999
envisioning greater political and economic integration
but, to date, neither side has actively sought to
implement the accord.
Disputes - international: none
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for the domestic market;
transshipment point for illicit drugs to and via Russia,
and to the Baltics and Western Europe
48
0 20 40 km
0 20 40 mi
Disputes - international: none
Illicit drugs: growing producer of synthetic drugs;
transit point for US-bound ecstasy; source of
precursor chemicals for South American cocaine
processors; transshipment point for cocaine, heroin,
hashish, and marijuana entering Western Europe
Disputes - international: none
108
Cocos (Keeling)
Islands
(territory of Australia)
0 4 8 km
North Keeling
0 4 8 mi
Island
Indian
Ocean
Horsburgh
Island
Direction Island
foc/iT "’krori''s
%^Home Island
South
A \\
Keeling
)\\ West \\
Islands
lUlsIand \\
South Island
rods
Disputes - international: none
Illicit drugs; illicit producer of cannabis, mostly for
local consumption; transshipment point for Southwest
and Southeast Asian heroin to Europe and
occasionally to the US, and for Latin American
cocaine destined for Europe
Disputes - international: claimed by Madagascar
Disputes - international: claimed by Argentina
Background: Although ultimately a victor in World
Wars I and II, France suffered extensive losses in its
empire, wealth, manpower, and rank as a dominant
nation-state. Nevertheless, France today is one of the
most modern countries in the world and is a leader
among European nations. Since 1958, it has
constructed a presidential democracy resistant to the
instabilities experienced in earlier parliamentary
democracies. In recent years, its reconciliation and
cooperation with Germany have proved central to the
economic integration of Europe, including the advent
of the euro in January 1999. Presently, France is at
the forefront of European states seeking to exploit the
momentum of monetary union to advance the creation
of a more unified and capable European defense and
security apparatus.
Disputes - international: Suriname claims area
between Riviere Litani and Riviere Marouini (both
headwaters of the Lawa)
Illicit drugs: small amount of marijuana grown for
local consumption; minor transshipment point to
Europe
177
Disputes -international: none
179
French Southern
and Antarctic Lands
(overseas territory of France)
fndhvi Oconn
lie Amsterdam ^
0
he Saint-Paul
lies Crozet
lies Kerguelen
0 400 800 ktii
0 400 800 ml
Disputes - international: "Adelie Land" claim in
Antarctica is not recognized by the US
180
Gabon L ; ;
Background: Ruled by autocratic presidents since
independence from France in 1960, Gabon
introduced a multiparty system and a new constitution
in the early 1 990s that allowed for a more transparent
electoral process and for reforms of governmental
institutions. A small population, abundant natural
resources, and foreign private investment have
helped make Gabon one of the more prosperous
black African countries.
Disputes - international: maritime boundary
dispute with Equatorial Guinea because of disputed
sovereignty over islands in Corisco Bay
Gambia, The
from the UK in 1 965; it formed a short-lived federation
of Senegambia with Senegal between 1 982 and 1 989.
In 1991 the two nations signed a friendship and
cooperation treaty. A military coup in 1994 overthrew
the president and banned political activity, but a new
1996 constitution and presidential elections, followed
by parliamentary balloting in 1997, have completed a
nominal return to civilian rule.
Disputes -international: none
Gaza Strip
Background: The Israel-PLO Declaration of
Principles on Interim Self-Government Arrangements
(the DOP), signed in Washington on 13 September
1993, provided for a transitional period not exceeding
five years of Palestinian interim self-government in the
Gaza Strip and the West Bank. Under the DOP, Israel
agreed to transfer certain powers and responsibilities
to the Palestinian Authority, which includes the
Palestinian Legislative Council elected in January
1996, as part of the interim self-governing
arrangements in the West Bank and Gaza Strip. A
transfer of powers and responsibilities for the Gaza
Strip and Jericho took place pursuant to the
Israel-PLO 4 May 1 994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of
the West Bank pursuant to the Israel-PLO
28 September 1995 Interim Agreement, the
Israel-PLO 15 January 1997 Protocol Concerning
Redeployment in Hebron, the Israel-PLO 23 October
1998 Wye River Memorandum, and the 4 September
1 999 Sharm el-Sheikh Agreement. The DOP provides
that Israel will retain responsibility during the
transitional period for external security and for interna!
security and public order of settlements and Israeli
citizens. Permanent status is to be determined
through direct negotiations, which resumed in
September 1999 after a three-year hiatus. An
intifadah broke out in September 2000; the resulting
widespread violence in the West Bank and Gaza Strip,
Israel''s military response, and instability in the
Palestinian Authority are undermining progress
toward a permanent settlement.
Disputes - international: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation
186
Disputes ■ international; none
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for domestic consumption; used
as transshipment point for opiates via Central Asia to
Western Europe and Russia
Disputes ■ international: claimed by Madagascar
196
Disputes - international: none
Disputes - international: claimed by Madagascar
264
Disputes -international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for the US and Europe
Disputes - international: none
342
Introduction Elevation extremes:
lowest point: Hoh Nuur 518 m
Background: Long a province of China, Mongolia highest point: Nayramadlin Orgil (Huyten Orgil)
won its independence in 1921 with Soviet backing. A 4^374 m
communist regime was installed in 1 924. During the Natural resources: oil, coal, copper, molybdenum,
early 1 990s, the ex-communist Mongolian People''s tungsten, phosphates, tin, nickel, zinc, wolfram.
Revolutionary Party (MPRP) gradually yielded its fluorspar, gold, silver, iron, phosphate
monopoly on power. In 1 996, the Democratic Union Land use:
Coalition (DUG) defeated the MPRP in a national arable land: 5.7%
election. Over the next four years the Coalition permanent crops: 0%
implemented a number of key reforms to modernize permanent pastures: 81 %
the economy and institutionalize democratic reforms. forests and woodland: 1 1 .4%
However, the former communists were a strong other: 1 .9% (2000 est.)
opposition that stalled additional reforms and made irrigated land: 800 sq km (1 993 est.)
implementation difficult. In 2000, the MPRP won 72 of Natural hazards: dust and snow storms, grassland
the 76 seats in Parliament and completely reshuffled and forest fires, drought and "zud", which is a
the government. While it continues many of the reform combination of drought followed by harsh winter
policies, the MPRP is focusing on social welfare and conditions
public order priorities. Environment - current Issues: limited natural fresh
water resources in some areas; policies of the former
Geography communist regime promoting rapid urbanization and
Location: Northern Asia, between China and Russia
Geographic coordinates: 46 00 N, 105 00 E
Map references: Asia
Area:
fota/.* 1.565 million sq km
/and.'' 1.565 million sq km
water: 0 sq km
Area - comparative: slightly smaller than Alaska
Land boundaries:
tofa/.'' 8,161.9 km
border countries: China 4,676.9 km, Russia 3,485 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; continental (large daily and
seasonal temperature ranges)
Terrain: vast semidesert and desert plains, grassy
steppe, mountains in west and southwest; Gobi
Desert in south-central
industrial growth have raised concerns about their
negative effects on the environment; the burning of
soft coal in power plants and the lack of enforcement
of environmental laws have severely polluted the air in
Ulaanbaatar; deforestation, overgrazing, the
converting of virgin land to agricultural production
have increased soil erosion from wind and rain;
desertification and mining activities have also had a
deleterious effect on the environment
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; strategic location
between China and Russia
Disputes - international: none
Disputes - international: Matthew and Hunter
Islands east of New Caledonia claimed by France and
Disputes -international: none
418
Disputes - international: none
434
Saint Vincent and
the Grenadines
Souhi^f^
jChateaiJbelaii
belair
Saint J ^Georgetown
Vincentl /
KINGSTOWN
Caribbean
Sea
Bequia^
Co
Q)
^ Mustique^^''
^Baiiceaux Island
Savan Island ■
■=> Petit Mustique Island
<\\ • Petit Canouan
e.
\\ ‘icS Canouan
Mayreaup .Tobago Cays
Union Island
Palm Island
^PetitSt. Vincent Is.
Disputes - international: Northern Ireland issue
with Ireland (historic peace agreement signed 1 0 April
1998): Gibraltar issue with Spain; Argentina claims
Falkland Islands (Islas Malvinas); Argentina claims
South Georgia and the South Sandwich Islands;
Mauritius and the Seychelles claim Chagos
Archipelago (UK-administered British Indian Ocean
Territory): Rockall continental shelf dispute involving
Denmark and Iceland; territorial claim in Antarctica
(British Antarctic Territory) overlaps Argentine claim
and partially overlaps Chilean claim; disputes with
Iceland, Denmark, and Ireland over the Faroe Islands
continental shelf boundary outside 200 NM
Illicit drugs: gateway country for Latin American
cocaine entering the European market; major
consumer of synthetic drugs, producer of limited
amounts of synthetic drugs and synthetic precursor
chemicals; major consumer of Southwest Asian
heroin; money-laundering center
Disputes ■ international: none
549
West Bank
Background: The Israel-PLO Declaration of
Principles on Interim Self-Government Arrangements
(the DOP), signed in Washington on 13 September
1 993, provided for a transitional period not exceeding
five years of Palestinian interim self-government in the
Gaza Strip and the West Bank. Under the DOP, Israel
agreed to transfer certain powers and responsibilities
to the Palestinian Authority, which includes the
Palestinian Legislative Council elected in January
1996, as part of interim self-governing arrangements
in the West Bank and Gaza Strip. A transfer of powers
and responsibilities for the Gaza Strip and Jericho
took place pursuant to the Israel-PLO 4 May 1994
Cairo Agreement on the Gaza Strip and the Jericho
Area and In additional areas of the West Bank
pursuant to the Israel-PLO 28 September 1995
Interim Agreement, the Israel-PL0 15 January 1997
Protocol Concerning Redeployment in Hebron, the
Israel-PLO 23 October 1998 Wye River
Memorandum, and the 4 September 1999 Sharm
el-Sheikh Agreement. The DOP provides that Israel
will retain responsibility during the transitional period
for external security and for internal security and
public order of settlements and Israeli citizens.
Permanent status is to be determined through direct
negotiations, which resumed in September 1999 after
a three-year hiatus. An intifadah broke out in
September 2000; the resulting widespread violence in
the West Bank and Gaza Strip, Israel''s military
response, and instability in the Palestinian Authority
are undermining progress toward a permanent
settlement.
Disputes - International: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation
551
FR
FR
FRA
250
.fr
France, Metropolitan
FX
FXX
249
.fx
ISO limits to the European part of
France, excluding French Guiana,
French Polynesia, French Southern
and Antarctic Lands, Guadeloupe,
Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon,
48 30 N
720 E
Amami Strait
Pacific Ocean
2840N
129 30 E
Amindivi Islands (former name for Laccadive Islands)
44 50 N
034W
Borneo (island)
Brunei, Indonesia, Malaysia
0 30N
114 00 E
Bornholm (island)
42 00 N
9 00E
Cosmoledo Group (Atoll de Cosmoledo) (island group)
48 42N
611 E
Louisiade Archipelago
48 52 N
2 20E
Pascua, Isla de (Easter Island)
46 00 N
200E
Republique Gabonaise (local name for Gabon)','6f917adc4aa7169304802d0259e21aba917e92d9eee34755647b4cad288e1c20','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5263ad46ab4e7fc4d584a064bdf8a080617e8941395d2083b82b50d34b7719c1',2001,'BZ','Belize','transnational-issues',149,'Background: Territorial disputes between the UK
and Guatemala delayed the independence of Belize
(formerly British Honduras) until 1981. Guatemala
refused to recognize the new nation until 1992.
Tourism has become the mainstay of the economy.
The country remains plagued by high unemployment,
growing involvement in the South American drug
trade, and increased urban crime.
Disputes - international: Guatemala periodically
asserts claims to territory in southern Belize; to deter
cross-border squatting, both states in 2000 agreed to
a "line of adjacency" based on the de facto boundary,
which is not recognized by Guatemala
Illicit drugs: minor transshipment point for cocaine;
small-scale illicit producer of cannabis for the
international drug trade; minor money-laundering
center
0 50 100 mi
Disputes - International: none
Illicit drugs: transshipment point for narcotics
associated with Nigerian trafficking organizations and
most commonly destined for Western Europe and the
US
55
BH
BZ
BLZ
084
.bz
618
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
17 30 N
8812W
Belle Isle, Strait of
Atlantic Ocean
51 35 N
56 30 W
Bellingshausen Sea
Southern Ocean
71 00 S
85 00 W
Belmopan (capital)
1715N
88 46 W
Belorussia (former name for Belarus)
1715N
88 45W
British Solomon Islands (former name for
Solomon Islands)','92623dba61fa2db879b6093b5bd49babb4895a0b8a629d2f62890607ff6c6062','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34652ee431bbf3a455cae0b94021f608226dd0e2fa415950ab7bff9194597241',2001,'BM','Bermuda','transnational-issues',158,'(overseas territory of
the UK)
Background: Bermuda was first settled in 1609 by
shipwrecked English colonists headed for Virginia.
Tourism to the island to escape North American
winters first developed in Victorian times. Bermuda
has developed into a highly successful offshore
financial center. A referendum on independence was
soundly defeated in 1995.
Disputes - international: none
57
Disputes - International: approximately 98,700
Bhutanese refugees in Nepal
59
Bolivia
Background: Bolivia, named after independence
fighter Simon BOLIVAR, broke away from Spanish
rule in 1825; much of its subsequent history has
consisted of a series of nearly 200 coups and
counter-coups. Comparatively democratic civilian rule
was established in the 1980s, but leaders have faced
difficult problems of deep-seated poverty, social
unrest, and drug production. Current goals include
attracting foreign investment, strengthening the
educational system, continuing the privatization
program, and waging an anti-corruption campaign.
Disputes - international: has wanted a sovereign
corridor to the South Pacific Ocean since the Atacama
area was lost to Chile in 1 884; dispute with Chile over
Rio Lauca water rights
Illicit drugs: world''s third-largest cultivator of coca
(after Colombia and Peru, a distant second) with an
estimated 14,600 hectares under cultivation in 2000,
a 33% decrease in overall cultivation of coca from
1999 levels; intermediate coca products and cocaine
exported to or through Colombia, Brazil, Argentina,
and Chile to the US and other international drug
markets; eradication and alternative crop programs
have slashed illicit coca cultivation during the
BANZER administration beginning in 1997
Bosnia and
Herzegovina
Background: Bosnia and Herzegovina''s declaration
of sovereignty in October 1991 , was followed by a
referendum for independence from the former
Yugoslavia in February 1992. The Bosnian Serbs -
supported by neighboring Serbia - responded with
armed resistance aimed at partitioning the republic
along ethnic lines and joining Serb-held areas to form
a "greater Serbia." In March 1994, Bosniaks and
Croats reduced the number of warring factions from
three to two by signing an agreement creating a joint
Bosniak/Croat Federation of Bosnia and Herzegovina.
On 21 November 1995, in Dayton, Ohio, the warring
parties signed a peace agreement that brought to a
halt the three years of interethnic civil strife (the final
agreement was signed in Paris on 14 December
1995). The Dayton Agreement retained Bosnia and
Herzegovina''s international boundaries and created a
joint multi-ethnic and democratic government. This
national government is charged with conducting
foreign, economic, and fiscal policy. Also recognized
was a second tier of government comprised of two
entities roughly equal in size: the Bosniak/Croat
Federation of Bosnia and Herzegovina and the
Bosnian Serb-led Republika Srpska (RS). The
Federation and RS governments are charged with
overseeing internal functions. In 1 995-96, a NATO-led
international peacekeeping force (IFOR) of 60,000
troops served in Bosnia to implement and monitor the
military aspects of the agreement. IFOR was
succeeded by a smaller, NATO-led Stabilization
Force (SFOR) whose mission is to deter renewed
hostilities. SFOR remains in place at a level of
approximately 21 ,000 troops.
BD
BM
BMU
060
.bm
3217N
6446W
Han-guk (local name for South Korea)
South Korea
37 00N
127 30 E
Hanoi (capital)
Vietnam
21 02 N
105 51 E
Harare (capital)
32 20 N
64 45W
Songkhia (city)
(U.K.)
Jacksonville,
Cruir or/vtux''ito
« THE BAHAMAS
M kklfX
h
300 600 Kilometers
Boundary rcprcscnteition is
not necessarily eimhoritjtivc.
ISLAS
RUVn.LACiCEOO
(MEXICO)
^Tampico
\\ I''.tli
MexiciO''^ ^ i,ycracruz
N Puebla '' ~^X
Acapulco]
''^^un
Kingston
Porl^^uF
Prince','72f09d180e4e5685c582b58343777470ff0db84c1cc4fecabf6d5dbf33655157','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eca9953901ac83c0d7e333c3163637d990c36625cd0badaeb9131e6f8037a6ed',2001,'IT','Italy','transnational-issues',172,'Disputes -international: none
Illicit drugs: minor transit point for marijuana and
opiate trafficking routes to Western Europe
Disputes - international: none
440
Disputes - international: none
Illicit drugs: because of more stringent government
regulations, used significantly less as a
money-laundering center: transit country for and
consumer of South American cocaine and Southwest
Asian heroin
Syria
Background: Following the breakup of the Ottoman
Empire during World War I, Syria was administered by
the French until independence in 1946. In the 1967
Arab-lsraeli War, Syria lost the Golan Heights to
Israel. Since 1976, Syrian troops have been stationed
in Lebanon, ostensibly In a peacekeeping capacity. In
recent years, Syria and Israel have held occasional
peace talks over the return of the Golan Heights.
Disputes ■ international: Golan Fleights is Israeli
occupied; dispute with upstream riparian Turkey over
Turkish water development plans for the Tigris and
Euphrates rivers; Syrian troops in northern, central,
and eastern Lebanon since October 1976
illicit drugs: a transit point for opiates and hashish
bound for regional and Western markets
490
Taiwan
IT
IT
ITA
380
.it
42 46N
1017E
Elemi Triangle (region)
Ethiopia (claimed), Kenya (de facto), Sudan
(claimed)
5 DON
35 30E
Ellada (local name for Greece)
38 30 N
15 00E
Epirus, Northern (region)
Albania, Greece
40 00 N
20 30 E
Ertra (local name for Eritrea)
44 25N
8 57E
George Town (capital)
42 50 N
12 50E
Italian East Africa (former name for Italian possessions
in eastern Africa)
Eritrea, Ethiopia, Somalia
SOON
36 00 E
Italian Somaliland (former name for southern Somalia)
41 13 N
09 24 E
Madeira Islands
38 07 N
1321 E
Palestine (region)
Israel, West Bank
32 00 N
35 15 E
Palikir (capital)
Federated States of Micronesia
655 N
158 08 "e
Palk Strait
Indian Ocean
10 00N
79 45 E
Pamirs (mountains)
China, Tajikistan
38 00 N
73 00 E
Pampas (region)
36 47N
12 00E
Papeete (capital)
35 40 N
12 40 E
Peleliu (Beliliou) (island)
41 54 N
12 29E
Roncador Cay (island)
40 00 N
900 E
Sargasso Sea (region)
Atlantic Ocean
30 00 N
55 00 W
Sark (island)
37 30 N
14 00E
Sicily, Strait of
Atlantic Ocean
37 20 N
11 20 E
Sidra, Gulf of
Atlantic Ocean
18 00E
Sikkim (state)
46 30 N
10 30E
South Vietnam (former name for the southern portion
of Vietnam)
Vietnam
12 00N
108 00 E
South Yemen (People''s Democratic Republic of Yemen)
45 04 N
7 40 E
Turkish Straits
Atlantic Ocean
40 40 N
28 00 E
Turkiye (local name for Turkey)
Turkey
39 00 N
35 00E
Turkmenia (former name for Turkmenistan)
4325N
1100E
Tutuila (island)
4630N
10 30 E
Tyrrhenian Sea
Atlantic Ocean
4000N
12 00 E
u
Ubangi-Shari (former name for the Central African
Republic','2d471d0eec75e3a579f17528f3c62552027fc3d961f55f73272a9203a1a43046','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ae4368653e8f56ebf5566619037fce622ce7d924dc144e3e64d0e19c0044252',2001,'BW','Botswana','transnational-issues',173,'Background: Formerly the British protectorate of
Bechuanaland, Botswana adopted its new name upon
independence in 1966. The economy, one of the most
robust on the continent, is dominated by diamond
mining.
Disputes - international: none
BC
BW
BWA
072
.bw
22 00 S
24 00 E
Beijing (capital)
24 45S
25 55 E
Galapagos Islands (Archipielago de Colon)','eef2426e516553ecc1d8325d19d4ab58d7ff9805f0e8268486da4a31153bcf33','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed1f52c452c489d6c761d666088729ac44c309dc6efc22a93eef83e9934037d6',2001,'BV','Bouvet Island','transnational-issues',181,'(territory of Norway)
Background: This uninhabited volcanic island is
almost entirely covered by glaciers and is difficult to
approach. It was discovered in 1739 by a French
naval officer after whom the island was named. No
claim was made until 1825 when the British flag was
raised. In 1928, the UK waived its claim in favor of
Norway, which had occupied the island the previous
year. In 1971 , Bouvet Island and the adjacent
territorial waters were designated a nature reserve.
Since 1977, Norway has run an automated
meteorological station on the island.
BV
BV
BVT
074
.bv','2fb434f938d6505ea6d4204095556e3c2baa37b20e880ddfe28ac6373e0beac6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea9f12c32491a06a27e27352ee43cfab4e5f91d71bf088abb40d3f13012e61a4',2001,'NO','Norway','transnational-issues',185,'Disputes - international: none
67
Disputes - international: none
255
Disputes ■ international: islands of Etorofu,
Kunashiri, and Shikotan, and the Habomai group
occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Liancourt
Rocks (Takeshima/Tokdo) disputed with South Korea;
Senkaku-shoto (Senkaku Islands) claimed by China
and Taiwan
Jarvis Island
(territory of the US)
Background: First discovered by the British in 1 821 ,
the uninhabited island was annexed by the US in
1 858, but abandoned in 1 879 after tons of guano had
been removed. The UK annexed the island in 1889,
but never carried out plans for further exploitation. The
US occupied and reclaimed the Island In 1935.
Abandoned after World War II, the island is currently
a National Wildlife Refuge administered by the US
Department of the Interior; a day beacon is situated
near the middle of the west coast.
Background: Despite its neutrality, Norway was not
able to avoid occupation by Germany in World War II.
In 1949, neutrality was abandoned and Norway
became a member of NATO. Discovery of oil and gas
in adjacent waters in the late 1 960s boosted Norway''s
economic fortunes. The current focus is on containing
spending on the extensive weifare system and
planning for the time when petroleum reserves are
depleted. In referenda held in 1 972 and 1 994, Norway
rejected joining the EU.
Disputes - international: territorial claim in
Antarctica (Queen Maud Land); Svalbard is the focus
of a maritime boundary dispute between Norway and
Russia
383
Background; In 1970, QABOOS bin Said Al Said
ousted his father and has ruled as sultan ever since.
His extensive modernization program has opened the
country to the outside world and has preserved a
long-standing political and military relationship with
the UK. Oman''s moderate, independent foreign policy
has sought to maintain good relations with all Middle
Eastern countries.
Disputes ■ international: boundary with the UAE
has not been bilaterally defined; northern section in
the Musandam Peninsula is an administrative
boundary
385
Pacific Ocean
Disputes ■ international: some maritime disputes
(see littoral states)
386
Disputes - international: status of Kashmir with
India; water-sharing problems with India over the
Indus River (Wular Barrage)
Illicit drugs: key transit area for Southwest Asian
heroin moving to Western markets; narcotics still
move from Afghanistan into Balochistan Province
Kayangel
0 50 100 km
Islands'''' .
6 50 100 mi
"u- Palau
Babelthuap.^: ‘stands
^''rkOROR
. ^Beliliou
Philippine
Sea
North
.^Sonsorol Islands
Pacific
Ocean
. Pulo Anna
'' Merit
Helen Reef
''''''
Disputes - international: none
Palmyra Atoll
(territory of the US)
Background: The Kingdom of Hawaii claimed the
atoll in 1862, and the US included it among the
Hawaiian Islands when it annexed the archipelago in
1898. The Hawaii Statehood Act of 1959 did not
include Palmyra Atoll, which is now privately owned by
the Nature Conservancy. This organization is
managing the atoll as a nature preserve. The lagoons
and surrounding waters within the 12 nautical mile US
territorial seas were transferred to the US Fish and
Wildlife service and designated a National Wildlife
Refuge in January 2001 .
NO
NO
NOR
578
.no
62 00 N
10 00 E
Norman Isles (Channel Islands)
Guernsey, Jersey
49 20 N
2 20W
North Atlantic Ocean
Atlantic Ocean
30 00 N
45 00 W
North Channel
Atlantic Ocean
5510N
5 40W
North Frisian Islands
Denmark, Germany
54 50 N
812E
North Greenland Sea
Arctic Ocean
78 00 N
500W
North Island
59 55N
1045 E
OsumI Strait (Van Diemen Strait)
Pacific Ocean
31 00 N
131 00 E
Otranto, Strait of
Atlantic Ocean
40 00 N
19 00E
Ottawa (capital)','9df7d3b0c7ab276e6d2da0de6df592ed59e35a191e4b12c2aa2ae3d70a488db2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c408087d9837ebdb6d5757c750539ea92951bb7d26b4e311ae76824ff0649ab2',2001,'BR','Brazil','transnational-issues',186,'SURINAME ,
AyA./-„ North
French At In nl ic
\\ Guiana Oconn
^ (FRANCE)
■/'' " /Belem
■^-T Luis
Fortaleza^v.
:ife^
Recife,
Salvador/
^BRASfLIA I
Belo /
^Horiz^te
^Vitdria
* ''^*Rio de
Janeiro
Sooth At Inn tic
Occnn
0 300 600 km
Disputes - international: none
Illicit drugs: limited illicit producer of cannabis,
minor coca cultivation in the Amazon region, mostly
used for domestic consumption; government has a
large-scale eradication program to control cannabis;
important transshipment country for Bolivian,
Colombian, and Peruvian cocaine headed for the US
and Europe; also used by traffickers as a way station
for narcotics air transshipments between Peru and
Colombia; upsurge in drug-related violence and
weapons smuggling; important market for Bolivian,
Peruvian, and Colombian cocaine
British Indian
Ocean Territory
(overseas territory
of the UK)
Peros r
Banhos . .
,0 Salomon Islands
, Nelsons
Island
Chagos
Archipelago
^ Three Brothers
Danger ‘
Island
'' Eagle Islands
Indian
Egmont Islands
Ocean
0 25 50 km
. ^ Diego
’I ? Garcia
6 25
50 ml
BR
BR
BRA
076
.br
15 47S
47 55W
Bratislava (capital)
3 51 S
32 25 W
Fernando Po (island) (see Bioko)
2030S
28 51 W
Mas a Tierra (Robinson Crusoe Island)
351 S
3349W
Rockall (island)
0 23N
29 23 W
Pedro e Sao Paulo)
Saint Peter Port (capital)
0 23N
29 23W
Sao Tiago (island)
Cape Verde
15 05N
23 40 W
Sao Tome (island)
2031 S
29 20 W
Trinidad (island)
802787AI (R02068) 4-01
CENTRAL BALKAN REGION
802790A! (R02592) 4-01
COMMONWEALTH OF INDEPENDENT STATES
I
802796Ai (R0211 0)4-01
EUROPE
802789AI {R01083) 4-01
KOSOVO
MIDDLE EAST
802792AI (R02107) 4-01
NORTH AMERICA
1
\\ ?o
RUSSIA ''-*acvck
V 3^^
i^nadyrtfi) V"'''''' i
N ) cImU-l.i
) Vi 5(M
^jsn / -N''y
Prov\\dcmya}^, ^A^^ j.^
\\
Pun''n^i;
5tM
/
I c Ocean,
/ — r-
160 1‘-;0 120 100 80 GO
/ ■ '' ■ ''
r''C ^Q^fsjafd/o Crret''iilanii >(.\\i
V,pBarrow
tv Alert/ V
/ QaanVaq
'' ''m
Jan Mayen
^ (nOKWAY)
ItscqqoVfoo^t^ t
(Scorcsby^u^l^ \\ ''t^ICElAmD
Greenland / „/ “
(DEMMA^K) Reykjavik
\\_^Priidhoe iHMufint
tV-V
\\
£ HiXkW ''
'' ^ W'' ''s «ssz7
„ _NITCQ STATES //\\
;f*Bctficl Wf,Afc/f/n/03r""''V //
\\/ (highest point in Fairbanks// J . KA r~.
^ North America.6194 m)m ^ y/ i|^lnUVik
h "\\.
c)ui(\\>r X. // ''/
Ta^il,
(Amma^saHl
Ocnnuirk
.SIlMll
KanQ<5rluss^;^q
fjiCr (Sf^arc Stroml^n
Nuuki
Jeaih Valley + •*
(iijw^l point in
North -56 m)
Los
San Die''go''^
/rijuanat
/ Mexfcal
^is^r^""''KX E s''"
y Oklahoma City^
Phoenix /Albuquerque
FJ Paso
Ciudad
Juarez
t j •Hermosillo
*Chihuahua
03lumbus-"^T^ &iishington, DX.
■ptiTs .vviiV y ^ North
y Norfoli^V
\\
A t ( a n 1 1 c
Memphis
^Auania rleston
Ocean
New OrlC^fe
San Houston j. - 7
Antonio •oV"
V/>4;
^/Ocr..,
Scale: 1:38,700,000
Lambert Conformn! Conic Projection,
stnncinrfi parallels 3 7"N and 65 ‘N
UMBX-KEO/--
f','9fe5c44183bd2994bdd96c447acd81c6c29f9c347b5d5adf6efd4f5b95216faa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48cdfaa5dcdff5db6f81e4edda0676131093634612c47a8e170ebd19f74ccf65',2001,'ID','Indonesia','transnational-issues',201,'Disputes - international: the Chagos Archipelago is
claimed by Mauritius and Seychelles
British Virgin
islands
(overseas territory
of the UK)
Background: First settled by the Dutch in 1648, the
isiands were soon after (1672) annexed by the
English. The economy is closely tied to the larger and
more populous US Virgin Islands to the west; the US
doilar is the iegal currency.
Disputes - International: none
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe
Brunei
Background: The Sultanate of Brunei''s heyday
occurred between the 15th and 17th centuries, when
Its control extended over coastal areas of northwest
Borneo and the southern Philippines. Brunei
subsequently entered a period of decline brought on
by internal strife over royal succession, colonial
expansion of European powers, and piracy. In 1888,
Brunei became a British protectorate; independence
was achieved in 1984. Brunei benefits from extensive
petroleum and natural gas fields, the source of one of
the highest per capita GDPs in the less developed
countries. The same family has now ruled in Brunei for
over six centuries.
Disputes ■ international: none
337
Midway Islands
(territory of the US)
Background; The US took formal possession of the
islands in 1867. The laying of the trans-Pacific cable,
which passed through the islands, brought the first
residents in 1903. Between 1935 and 1947, Midway
was used as a refueling stop for trans-Pacific flights.
The US naval victory over a Japanese fleet off Midway
in 1942 was one of the turning points of World War II.
The islands continued to serve as a naval station until
closed in 1993. Today the islands are a wildlife refuge
open to the public.
Disputes - international: none
338
Moldova
Background: Formerly ruled by Romania, Moldova
became part of the Soviet Union at the close of World
War II. Although Independent from the USSR since
1991, Russian forces have remained on Moldovan
territory east of the Nistru (Dnister) River supporting
the Slavic majority population, mostly Ukrainians and
Russians, who have proclaimed a "Transnistria"
republic. One of the poorest nations in Europe and
plagued by a moribund economy, in 2001 Moldova
became the first former Soviet state to elect a
communist as its president.
Disputes - International: separatist Transnistria
region, comprising the area between the Nistru
(Dniester) River and Ukraine, has its own de facto
government, dominated by Moldovan Slavs
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for CIS consumption; transshipment
point for illicit drugs from Southwest Asia via Central
Asia to Russia, Western Europe, and possibly the US
Disputes ■ international: Pedra Branca Island
(Pulau Batu Putih) disputed with Malaysia
Illicit drugs: as a transportation and financial
services hub, Singapore is vulnerable, despite strict
laws and enforcement, to use as a transit point for
Golden Triangle heroin and as a venue for money
laundering
ID
ID
IDN
360
.id
Iran
IR
IR
IRN
364
.ir
820S
11500 E
Bali Sea
Indian Ocean
745S
115 30 E
Balintang Channel
Pacific Ocean
19 49N
121 40 E
Balintang Islands
2 30S
106 00 E
Bangkok (capital)
2 00S
121 00 E
Celebes Sea
Pacific Ocean
300N
122 00 E
Celtic Sea
Atlantic Ocean
51 00 N
6 30W
Central African Empire (former name for Central
African Republic)
500S
120 00 E
Dutch Guiana (former name for Suriname)
9 00S
126 00 E
Easter Island (Isla de Pascua)
845S
121 00 E
Flores Sea
Pacific Ocean
740S
11945 E
Florida, Straits of
Atlantic Ocean
25 00 N
79 45 W
Former Soviet Union (FSU)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,
1 00 N
128 00 E
638
Appendix F: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
Halmahera Sea Pacific Ocean 0 30 S 1 29 00 E
Hamilton (capital)
500S
138 00 E
Irish Sea
Atlantic Ocean
53 30N
520W
Iron Gate (river gorge)
Romania, Yugoslavia
44 41 N
22 31 E
639
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry In The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Iskenderun (Alexandretta) (region)
Turkey
36 34 N
36 OSE
Islamabad (capital)
610S
106 48 E
James Bay
Arctic Ocean
54 00N
80 00W
Jamestown (capital)
Saint Helena
15 56S
5 44W
Jammu (city)
730S
11000E
Java Sea
Pacific Ocean
5 00S
11000E
Jerusalem (capital, proclaimed)
Israel, West Bank
31 47 N
3514E
Jiddah (Jeddah) (city)
OOON
115 00 E
Kaliningrad (region; formerly part of East Prussia)
Russia
54 SON
21 00 E
Kamaran (island)
6 07S
105 24 E
Kuala Lumpur (capital)
9 00S
120 00 E
Lesvos (island)
828S
11640E
Lombok Strait
Indian Ocean
8 30S
115 50 E
Lome (capital)
2 00S
28 00 E
Mombasa (city)
3 SON
102 30 E
Natuna Sea
Pacific Ocean
330N
108 00 E
645
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Naxcivan (region)
500S
120 00 E
Netherlands Guiana (former name for Suriname)
9 00S
126 00 E
Port-Vila (capital)
200S
Spitsbergen (island)
Svalbard
78 00 N
Srbija-Crna Gora (local name for Serbia and Montenegro)
Yugoslavia
44 00 N
21 00 E
St. John’s (city)
Canada (Newfoundland)
47 34N
52 43 W
Stanley (capita!)
Falkland Islands (Islas Malvinas)
51 42 8
5741 W
Stockholm (capital)
2008
121 00 E
Sulawesi Sea
Pacific Ocean
SOON
122 00 E
653
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Sulu Archipelago (island group)
OOON
102 00 E
Sumba (island)
1000S
120 00 E
Sumba Strait
Pacific Ocean
910S
120 00 E
Sumbawa (island)
8 30S
11800E
Sunda Islands (Soenda Isles)
Indonesia, Malaysia
2 00S
11000E
Sunda Strait
Indian Ocean
6 00S
105 45 E
Suomi (local name for Finland)
900S
125 00 E
Timor Leste (former name for East Timor)
East Timor
900N
126 00 E
Timor Sea
Pacific Ocean
1100S
128 00 E
Tinian (island)','fc430d70b4a94f7549a5f83e2bdfb64da0738cb5b11d711dcd53dc87260e845e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26b32b06ab174a8b00f12cb1935ee467b3a253d449e67f2289030947e3906606',2001,'BG','Bulgaria','transnational-issues',210,'Illicit drugs: major European transshipment point for
Southwest Asian heroin and, to a lesser degree,
South American cocaine for the European market;
limited producer of precursor chemicals
BU
BG
BGR
100
•bg
42 41 N
2319E
Solomon Islands, northern','298640e382d089927496b9203d512391cea995621322f04b31491da8c01edd81','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a3ae3be675f7ef17a53a98b2ce14b2daa272a0399c7850817d3eecf6bf08349',2001,'BF','Burkina Faso','transnational-issues',211,'Background: Independence from France came to
Burkina Faso (formerly Upper Volta) in 1960.
Governmental instability during the 1970s and 1980s
was followed by multiparty elections in the early
1990s. Several hundred thousand farm workers
migrate south every year to Cote d''Ivoire and Ghana.
UV
BF
BFA
854
.bf
Burma
BM
MM
MMR
104
.mm
ISO uses the name Myanmar
12 22N
1 31 W
Outer Hebrides (islands)
13 00N
2 00W
Ural Mountains
Kazakhstan, Russia
60 00 N
60 00E
Urdunn (local name for Jordan)','92b4fc55d4dbce5add7c266c6d4f35cba648199c54582444cf5cc4d18b16f068','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1edd0671e8a57cd418343d9d73f165f1e774cbae6afa3cebc09d391feff7851',2001,'ET','Ethiopia','transnational-issues',219,'Disputes - international: none
Burma
Background: Unique among African countries, the
ancient Ethiopian monarchy maintained its freedom
from colonial rule, one exception being the Italian
occupation of 1936-41. In 1974 a military junta, the
Derg, deposed Emperor Haile SELASSIE (who had
ruled since 1930) and established a socialist state.
Torn by bloody coups, uprisings, wide-scale drought,
and massive refugee problems, the regime was finally
toppled by a coalition of rebel forces, the Ethiopian
People''s Revolutionary Democratic Front (EPRDF), in
1991 . A constitution was adopted in 1994 and
Ethiopia''s first multiparty elections were held in 1995.
A two and a half year border war with Eritrea that
ended with a peace treaty on 1 2 December 2000 has
strengthened the ruling coalition, but has hurt the
nation''s economy.
Disputes - international: most of the southern half
of the boundary with Somalia is a Provisional
Administrative Line; as a result of the 12 December
2000 peace agreement ending a two year war with
Eritrea, the UN will administer a 25-km wide
temporary security zone within Eritrea until a joint
boundary commission delimits and demarcates a final
boundary; dispute over alignment of boundary with
Eritrea led to armed conflict in 1998; a peace accord
signed in December 2000 provides for UN-assisted
arbitration and demarcation of the border
Illicit drugs; transit hub for heroin originating in
Southwest and Southeast Asia and destined for
Europe and North America as well as cocaine
destined for markets in southern Africa; cultivates qat
(khat) for local use and regional export, principally to
Djibouti and Somalia
Europa Island |H llll
(possession of France)
Disputes -international: none
215
Disputes - international: none
442
Disputes - International: a final border resolution
was agreed to with Qatar in March of 2001; location
and status of boundary with UAE is not final, de facto
boundary reflects a 1974 agreement; a June 2000
treaty delimited the boundary with Yemen, but final
demarcation requires adjustments based on tribal
considerations
Illicit drugs: death penalty for traffickers; increasing
consumption of heroin and cocaine
Disputes - International; none
Illicit drugs: transshipment point for Southwest and
Southeast Asian heroin moving to Europe and North
America; illicit cultivator of cannabis
ET
ET
ETH
231
.et
Europa Island
EU
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Falkland Islands (Islas Malvinas)
FA
FK
FLK
238
.fk
SOON
38 00 E
Acapulco (city)
9 02N
38 42 E
Adelie Land (Terre Adelie) (claimed by France)
SOON
36 00E
Ivory Coast (former name for Cote d’Ivoire)
Cote d''Ivoire
8 00N
5 00W
Iwo Jima (island)
8 00N
38 00 E
Yalu River
China, North Korea
39 55 N
124 20 E
Yamoussoukro (capital)
Cote d''Ivoire
649 N
517W
Yangon (see Rangoon)
Burma
16 47 N
9610E
Yaounde (capital)
LAKSHADWEEP
(IMDIA)
fOjlQtnbo
''/Phnom tonhf
^r. uuir.T^
TiiailjiiJ I
/ UGAMDA
KEfiYA
/SOiyiALIA
Mogadishu
;.^Male
MALDIVES \\t
o
RWAHD/C Nairobi /
fj^jumbura '' J
''IGOWbURITOI N^Mombasa
L TAnZAniA :^^''''®® Salaam','4df823274e778520c641cc260a64c502d28bcabacd0789523be904c93c01ec69','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9406a80f62c667b375e2ec38347c813c4274f4a58fff2985b9be6b8bfeada45',2001,'TH','Thailand','transnational-issues',228,'Disputes - international: sporadic border hostilities
with Thailand over border alignment and ethnic Shan
rebels operating in cross-border region
Illicit drugs: world''s second largest producer of illicit
opium, after Afghanistan (potential production in
1999 - 1,090 metric tons, down 38% due to drought;
cultivation in 1999 - 89,500 hectares, a 31% decline
from 1998); surrender of drug warlord KHUN SA''s
Mong Tai Army in January 1996 was hailed by
Rangoon as a major counternarcotics success, but
lack of government will and ability to take on major
narcotrafficking groups and lack of serious
commitment against money laundering continues to
hinder the overall antidrug effort; becoming a major
source of methamphetamine for regional consumption
Disputes - international; none
Background: A unified Thai kingdom was
established in the mid-14th century; it was known as
Siam until 1939. Thailand is the only southeast Asian
country never to have been taken over by a European
power. A bloodless revolution in 1932 led to a
constitutional monarchy. In alliance with Japan during
World War II, Thailand became a US ally following the
conflict.
Disputes - international: parts of the border with
Laos are indefinite; parts of border with Cambodia are
indefinite; sporadic border hostilities with Burma over
border alignment and ethnic Shan rebels operating in
cross-border region
Illicit drugs: a minor producer of opium, heroin, and
marijuana; illicit transit point for heroin en route to the
international drug market from Burma and Laos;
eradication efforts have reduced the area of cannabis
cultivation and shifted some production to neighboring
countries; opium poppy cultivation has been reduced
by eradication efforts; also a drug money-laundering
center; minor role in amphetamine production for
regional consumption; increasing indigenous abuse of
methamphetamine
498
Disputes ■ international: none
Illicit drugs: transit hub for Nigerian heroin and
cocaine traffickers
South Pacific Ocean
V \\
Nukunonu
Fakaofo
Disputes - international: none
502
TH
TH
THA
764
.th
13 45N
100 31 E
Bangui (capital)
15 00N
100 00 E
Pretoria (capital)
1500N
100 00 E
Siberia (region)
Russia
100 00 E
Sibutu Passage
Pacific Ocean
450 N
11935E
Sicily (island)
712N
100 36 E
Sound, The (Oresund) (strait)
Atlantic Ocean
55 50 N
12 40 E
South Atlantic Ocean
Atlantic Ocean
30 00S
15 00W
South China Sea
Pacific Ocean
10 00N
11300E
South Georgia (island)','2f7b6911b9b423ca6fa00bb1af77148bbc0a22a4cfa9075cbf5ca05fc3098be3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f8dc801e8ec82a269b8fb9c53a62cc72676e9b3d73002e6dd37f4726240872f',2001,'KH','Cambodia','transnational-issues',233,'Background: Following a five-year struggle,
communist Khmer Rouge forces captured Phnom
Penh in 1975 and ordered the evacuation of all cities
and towns; over 1 million displaced people died from
execution or enforced hardships. A 1978 Vietnamese
invasion drove the Khmer Rouge into the countryside
and touched off 13 years of fighting. UN-sponsored
elections in 1993 helped restore some semblance of
normalcy, as did the rapid diminishment of the Khmer
Rouge in the mid-1990s. A coalition government,
formed after national elections in 1998, brought
renewed political stability and the surrender of
remaining Khmer Rouge forces.
Disputes - international: portions of boundary with
Vietnam are disputed; parts of border with Thailand
are indefinite
Illicit drugs: possible money laundering;
narcotics-related corruption reportedly involving some
in the government, military, and police; possible
small-scale opium, heroin, and amphetamine
production; large producer of cannabis for the
international market
87
CB
KH
KHM
116
.kh
13 26N
103 50 E
Anglo-Egyptian Sudan (former name for Sudan)
13 00N
105 00 E
Kane Basin (portion of channel)
Arctic Ocean
79 SON
68 00 W
Kanton island
13 00N
105 00 E
Khuriya Muriya Islands (Kuria Muria Islands)
1133N
104 55 E
Phoenix Islands','6a787e07c892b7c8f2e00a1504da01f7ab61240c2afe95b2308044ab27feacf1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdac372581fdbc40eeeedc16763c588451a991e585affd9dd41eee06da41737d',2001,'CM','Cameroon','transnational-issues',249,'Disputes - international: delimitation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past, is
complete and awaits ratification by Cameroon, Chad,
Niger, and Nigeria; tripartite maritime boundary and
economic zone dispute with Equatorial Guinea and
Nigeria is currently before the ICJ
CM
CM
CMR
120
.cm
6 00N
12 00E
Campbell Island
4 03N
942 E
Douglas (capital)
Man, Isle of
54 09 N
428W
Dover, Strait of
Atlantic Ocean
51 00 N
1 30 E
Drake Passage
Atlantic Ocean, Southern Ocean
60 00 S
60 00 W
Druk Yul (local name for Bhutan)
6 00N
12 00E
French Guinea (former name for Guinea)
352 N
11 31 E
Yap Islands
Federated States of Micronesia
930 N
138 00 E
Yaren (governmental center)','72edcd8c569404b88d3466add62f98da1b2611ebac2bb80c91e82429ba372f93','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f6af39eca3c25f64b8c87403c004cc34e6c11d624442b09f85ca7c39c7197bd',2001,'CA','Canada','transnational-issues',250,'Background: A land of vast distances and rich
natural resources, Canada became a self-governing
dominion in 1867 while retaining ties to the British
crown. Economically and technologically the nation
has developed in parallel with the US, its neighbor to
the south across an unfortified border. Its paramount
political problem continues to be the relationship of the
province of Quebec, with its French-speaking
residents and unique culture, to the remainder of the
country.
Disputes - International: maritime boundary
disputes with the US (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island)
Illicit drugs: Illicit producer of cannabis for the
domestic drug market; use of hydroponics technology
permits growers to plant large quantities of
high-quality marijuana indoors; transit point for heroin
and cocaine entering the US market
92
Cape Verde
Santo
Antao
Mindelo
Q.Santa Luzia
Sao
Vicente ^ _
Sao Nicolau
<?.o w C5,
...
Santa
Maria
North Atlantic
Ocoan
9^ Boa
Vista
Brava^
Sotavento
^ T arraf alf ^ Ma/o
Qfopo
Tiago
CA
CA
CAN
124
.ca
Cape Verde
cv
CV
CPV
132
.cv
79 30N
90 00W
Azad Kashmir (region)
68 00 N
70 00W
Baghdad (capital)
7515N
121 30 W
Banks Islands (lies Banks)
76 00 N
87 00 W
Dhaka (capital)
78 00 N
103 00 W
Ellesmere Island
81 00 N
80 00 W
Ellice Islands
54 00 N
62 00 W
Labrador Sea
Atlantic Ocean
60 00 N
55 00W
Laccadive Islands
45 31 N
73 34W
Moravia (region)
Czech Republic
49 SON
17 00E
Moravian Gate (pass)
Czech Republic
49 35N
17 50E
Moroni (capital)
52 00 N
56 00 W
Niamey (capital)
6405N
117 low
Norwegian Sea
Atlantic Ocean
6600N
600E
Nouakchott (capital)
72 00N
90 00 W
Nuuk (Godthab) (capital)
45 20 N
73 58 W
Ouagadougou (capital)
46 20 N
63 20 W
Prince Edward Islands
76 30N
11900W
Principe (island)
52 00N
72 00 W
Queen Charlotte Islands
53 00 N
132 00 W
Queen Elizabeth Islands
78 00N
95 00W
Queen Maud Land (claimed by Norway)
43 55 N
59 50 W
Safety Islands (lies du Salut)
4712N
60 09 W
Saint Paul Island
49 45N
126 00 W
Vatican City (capital)
Holy See
41 54 N
12 27 E
Velez de la Gomera, Penon de (island)
71 00 N
11000W
Victoria Land (region)','e25ae7d4a29c6db647a9873d5394eebdbfb48b5ff07ad2313231beef3edc46d6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc9f23c4e725c62f82f7240df4dd56f5dc87b50b54dd3bad85703eaf61c5a4df',2001,'PT','Portugal','transnational-issues',264,'Disputes - International: none
Illicit drugs: used as a transshipment point for illicit
drugs moving from Latin America and Africa destined
for Western Europe
94
Background: Following its heyday as a world power
during the 1 5th and 1 6th centuries, Portugal lost much
of its wealth and status with the destruction of Lisbon
in a 1755 earthquake, occupation during the
Napoleonic Wars, and the independence in 1822 of
Brazil as a colony. A 1910 revolution deposed the
monarchy; for most of the next six decades repressive
governments ran the country. In 1974, a left-wing
military coup Installed broad democratic reforms. The
following year Portugal granted independence to all of
its African colonies. Portugal entered the EC in 1985.
Illicit drugs: important gateway country for Latin
American cocaine and Southwest Asian heroin
entering the European market; transshipment point for
hashish from North Africa to Europe; consumer of
Southwest Asian heroin
PO
PT
PRT
620
•Pt
3830N
28 00W
Azov, Sea of
Atlantic Ocean
49 00 N
36 00 E
B Bab el Mandeb (strait)
Indian Ocean
12 40N
43 20 E
Babuyan Channel
Pacific Ocean
18 44 N
121 40 E
Babuyan Islands
38 43N
908W
Little Belt (Lille Baelt) (strait)
Atlantic Ocean
55 05 N
9 55E
Ljubljana (capital)
32 40N
1645W
Madras (see Chennai) (city)
Lisbon/ K
ANDORRA^^
Madrid iarcelona','728073eb7cb35793143ddc4b4e550f51ccdf3e3c624c3a3dea717d2549ac8200','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcaf8252b9ac91cf466e8f2d8e4b6303ca8728028145cf354454ec4f537f5126',2001,'KY','Cayman Islands','transnational-issues',265,'(overseas territory
of the UK)
C a r i b h c a n
Sea
Utf/e
Cayman
Cayman
Brae
Grand
„ Cayman
GEORGE TOWN
0 20
40 km
0 20
40 mi
CJ
KY
CYM
136
.ky
19 20N
81 23 W
George Town (city)
19 20N
81 20 W
Grand Turk (Cockburn Town) (capital)','59f8ddba4411052491e7ef32a71d7a1132ff1536d5d52ebeb377abd571dbc9af','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e68c64719d7bdca183f0473fd3089ff9d87a0a26b42c27ceffd1aad12e059bd',2001,'HN','Honduras','transnational-issues',275,'Disputes - international: none
Illicit drugs: vulnerable to drug money laundering
and drug transshipment to the US and Europe
Disputes - International: none
98
Disputes - international: with respect to the
maritime boundary in the Golfo de Fonseca, the ICJ
referred to the line determined by the 1900
Honduras-Nicaragua Mixed Boundary Commission
and advised that some tripartite resolution among El
Salvador, Honduras, and Nicaragua likely would be
required; the maritime boundary dispute with
Nicaragua in the Caribbean Sea is before the ICJ
Illicit drugs: transshipment point for drugs and
narcotics; illicit producer of cannabis, cultivated on
small plots and used principally for local consumption;
corruption is a major problem; vulnerable to money
laundering
224
HO
HN
HND
340
.hn
17 25S
83 56 W
T Tadzhikistan (former name for Tadjikistan)
Tadjikistan
39 00 N
71 00 E
Tahiti (island)
14 06N
8713W
Tehran (capital)
Iran
35 40 N
51 26 E
Tel Aviv (capital, de facto)','b78ab90bfbe459505f0f8e49c889555e8524931323e188beae6b741b3802b351','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3c7b37ac2cb7f488a8f884583e7641b82180afd7c36a47934f40432888c701f',2001,'TD','Chad','transnational-issues',285,'Disputes - International: delimitation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past,
has been completed and awaits ratification by
Cameroon, Chad, Niger, and Nigeria
Background: A three-year-old Marxist government
was overthrown in 1 973 by a dictatorial military regime
led by Augusto PINOCHET, which ruled until a freely
elected president was installed in 1990. Sound
economic policies, first implemented by the
PINOCHET dictatorship, led to unprecedented growth
in 1991-97 and have helped secure the country''s
commitment to democratic and representative
government. Growth slowed in 1998-99, but
recovered strongly in 2000.
Disputes - international: Bolivia has wanted a
sovereign corridor to the South Pacific Ocean since
the Atacama area was lost to Chile in 1884; dispute
with Bolivia over Rio Lauca water rights; territorial
claim in Antarctica (Chilean Antarctic Territory)
partially overlaps Argentine and British claims
Illicit drugs: a growing transshipment country for
cocaine destined for the US and Europe; economic
prosperity has made Chile more attractive to
traffickers seeking to launder drug profits; imported
precursors passed on to Bolivia; domestic cocaine
consumption is rising
103
CD
TD
TCD
148
.td
22 00 N
18 00E
Apia (capital)
12 07N
15 03 E
Nederland (local name for the Netherlands)
1500N
19 00E
Tegucigalpa (capital)','63ac88d8aa879688a2afa3bd66d94733e610df859a2adcb73f973b2317f22f5f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cafc3ef19bcf30fc48dd187e9b951a6e008de2b07dee95d67728bc984e484503',2001,'CN','China','transnational-issues',286,'(also see separate Hong Kong, Macau, and Taiwan entries)
Disputes - international: most of boundary with
India in dispute; dispute over at least two small
sections of the boundary with Russia remains to be
settled, despite 1 997 boundary agreement; portions of
the boundary with Tajikistan are indefinite; 33-km
section of boundary with North Korea in the
Paektu-san (mountain) area is indefinite; involved in a
complex dispute over the Spratly Islands with
Malaysia, Philippines, Taiwan, Vietnam, and possibly
Brunei: maritime boundary agreement with Vietnam in
the Gulf of Tonkin awaits ratification; Paracel Islands
occupied by China, but claimed by Vietnam and
Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as
does Taiwan
Illicit drugs: major transshipment point for heroin
produced in the Golden Triangle; growing domestic
drug abuse problem; source country for chemical
precursors and methamphetamine
106
Disputes -international: none
Illicit drugs: a hub for Southeast Asian heroin and
regional stimulants trade; transshipment and
money-laundering center; increasing indigenous
amphetamine abuse
Howland Island
(territory of the US)
Background: Discovered by the US early in the 1 9th
century, the island was officially claimed by the US in
1 857. Both US and British companies mined for guano
until about 1890. Earhart Light is a day beacon near
the middle of the west coast that was partially
destroyed during World War II, but has since been
rebuilt; it is named in memory of famed aviatrix Amelia
EARHART. The island is administered by the US
Department of the Interior as a National Wildlife
Refuge.
Sea
Fiery Cross
Reefi’
‘ Spratly
Island
Amboy 03“
Cay
Loaita Nan^.^
West York
, » Jsland
"Thitu Island ^lat
A Jsland
— Lankiam Cay *
Sand Cay^Loaita Island ■■
Itu Aba Island- ’ ^-^Eldad Reef ''fjgpshan
. — -Namyit island
f Island
Sin Cowe-^"’ * Mischief
Island ''
Alison
Reef
Reef
a
„ Pigeon Reef t-lalf-^
^ Moon ^
TURKM.
J J ^ Kulob. y
u 1
1 J ’Ourghonteppa j
/ p a m i r s (
f.Khorugh
CH
CN
CHN
156
.cn
see also Taiwan
39 56 N
11624E
Beirut (capital)
23 06 N
11316E
Canton Island (Kanton Island)
35 00N
105 00 E
China, Republic of
Taiwan
2330N
105 00 E
Chisinau (capital)
Moldova
47 00 N
28 50E
ChoiseuI (island)
19 00N
109 30 E
Haiphong (city)
Vietnam
20 52N
106 41 E
Halaib Triangle (region)
Egypt (claimed), Sudan (de facto)
22 30 N
35 00 E
Halmahera (island)
42 00 N
11300 E
Ionian Islands
36 00 N
84 00 E
Kuril Islands
Russia (de facto)
4610N
152 00 E
Kuwait (capital)
44 00N
124 00 E
Manchuria (region)
44 00 N
124 00 E
Manila (capital)
39 56N
11624E
Pelagian Islands (Isole Pelagie)
86 00 E
Sint Eustatius (island)
Netherlands Antilles
62 58 W
Sint Maarten (Saint-Martin) (island)
Netherlands Antilles
18 04N
63 04 W
Sjaelland (island)
32 00 N
90 00 E
Tibilisi (see Tbilisi)
35 00 N
105 00 E
Zhonghua (locai name for China)
35 00 N
105 00 E
Zion, Mount (locale in Jerusalem)
Israel, West Bank
31 46 N
3514E
Zurich (city)','990a4c1bd1f2eccde8c6ba9fb0ad650cc2e639822264d0cf3633b6d3dc999bb7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a62245acb2d4a5dbcc84db2d57398fea43f296c579ef1b96bca9042eaa4c9abb',2001,'CX','Christmas Island','transnational-issues',295,'(territory of Australia)
Background: Named in 1643 for the day of its
discovery, the island was annexed and settlement
was begun by the UK in 1888. Phosphate mining
began in the 1 890s. The UK transferred sovereignty to
Australia in 1958. The phosphate mine, closed in
1 987, was reopened four years later, but the need for
an alternative industry has spurred investment in
tourism. Old mining areas are being restored, and
almost two-thirds of the island has been declared a
national park.
KT
cx
CXR
162
.cx
Clipperton Island
IP
—
—
—
ISO includes with French Polynesia
18 44N
6419W
Severnaya Zemlya (Northland) (island group)
Russia
98 00 E
Shaba (region)
Democratic Republic of the Congo
8 00S
27 00 E
Shag Island','17a3570e7a11099c29302d346b8708e61b445d4597036de35a0131445c801e2d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88f6aa3b21c5ba3be75a7aecc50e48b4a165f365d70b70228bfbce98eee8f910',2001,'CO','Colombia','transnational-issues',302,'Background: Colombia was one of the three
countries that emerged from the collapse of Gran
Colombia in 1830 (the others being Ecuador and
Venezuela). A 40-year insurgent campaign to
overthrow the Colombian Government escalated
during the 1990s, undergirded in part by funds from
the drug trade. Although the violence is deadly and
large swaths of the countryside are under guerrilla
influence, the movement lacks the military strength or
popular support necessary to overthrow the
government. While Bogota continues to try to
negotiate a settlement, neighboring countries worry
about the violence spilling over their borders.
Disputes ■ international: maritime boundary
dispute with Venezuela in the Gulf of Venezuela;
territorial disputes with Nicaragua over Archipelago de
San Andres y Providencia and Quita Sueno Bank
Illicit drugs: illicit producer of coca, opium poppies,
and cannabis; world''s leading coca cultivator
(cultivation of coca in 1999 - 122,500 hectares, a
20.3% increase over 1998); cultivation of opium in
1 999 increased to 7,500 hectares from 6,1 00 hectares
in 1998; potential production of opium in 1999 - 75
metric tons, a 25% increase over 1998; potential
production of heroin in 1 999 - nearly 8 metric tons, as
compared with 6 tons in 1998; the world''s largest
processor of coca derivatives into cocaine; supplier of
about 90% of the cocaine to the US and the great
majority of cocaine to other international drug
markets, and an important supplier of heroin to the US
market; active aerial eradication program
112
a/m— to provide a forum for largest debtor
nations in Latin America
members— (11) Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador, Mexico, Peru, Uruguay,
Venezuela
Group of 15 (G-15)
note— byproduct of the Nonaligned Movement
established— NA September 1989
a/m— to promote economic cooperation among
developing nations; to act as the main political
organ for the Nonaligned Movement
members— (15) Algeria, Argentina, Brazil, Egypt, India, Indonesia, Jamaica, Malaysia, Mexico, Nigeria, Peru,
Senegal, Venezuela, Yugoslavia, Zimbabwe
Group of 24 (G-24)
members— (24) Algeria, Argentina, Brazil, Colombia, Democratic Republic of the Congo, Cote d''Ivoire, Egypt,
Ethiopia, Gabon, Ghana, Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, Sri Lanka,
established— ^ August 1989
a/m— to promote the interests of developing
countries in Africa, Asia, and Latin America
within the IMF
Syria, Trinidad and Tobago, Venezuela, Yugoslavia
585
Appendix B: International Organizations and Groups (continued)
Group of 77 (G-77)
established— June 1964 was set up; NA
October 1967 first ministerial meeting
aim—[o promote economic cooperation among
developing countries; name persists in spite of
increased membership
members— (^3^ plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda,
Argentina, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, South Korea, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Federated States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Phiiippines, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation
Organization
Gulf Cooperation Council (GCC)
members— {5) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
nofe— also known as the Cooperation Council
for the Arab States of the Gulf
established— 25 May 1981
a/m— to promote regional cooperation in
economic, social, political, and military affairs
high-income countries
another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC)
members— (5) Comoros, France (for Reunion), Madagascar, Mauritius, Seychelles
established— 2^ December 1982
a/m— to organize and promote regional
cooperation in all sectors, especially economic
Industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank (lADB)
note— also known as Banco Interamericano de
Desarrollo (BID)
establishedS April 1959
effective— 30 December 1959
aim—{o promote economic and social
development in Latin America
members— (46) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany,
Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica, Japan, Mexico, Netherlands, Nicaragua, Norway,
Panama, Paraguay, Peru, Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US,
Uruguay, Venezuela
Inter-Governmental Authority on
Development (IGAD)
members— (6) Djibouti, Eritrea, Ethiopia, Kenya, Sudan, Uganda
note— formerly known as Inter-Governmental
Authority on Drought and Development (IGADD)
esteW/s/?ecf— 15-16 January 1986 as the
Inter-Governmental Authority on Drought and
Development
revitalized— 2^ March 1996 as the
Inter-Governmental Authority on Development
a/m— to promote a social, economic, and
scientific community among its members
586
Appendix B: International Organizations and Groups (continued)
International Atomic Energy Agency (IAEA) members— {^30) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Bangladesh,
Belarus, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina Faso, Burma, Cambodia,
established— 23 October 1956 Cameroon, Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
effective— 29 July 1957 Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia,
a/m— to promote peaceful uses of atomic energy Finland, France, Gabon, Georgia, Germany, Ghana, Greece, Guatemala, Haiti, Holy See, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Latvia,
Lebanon, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malaysia, Mali, Malta, Marshall Islands, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco,
Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, Tunisia, Turkey, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
International Bank for Reconstruction and members-{^82) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Development (IBRD) Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
note— also known as the World Bank Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
established— 22 July 1944 Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
effective— 27 December 1945 Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
a/m— to provide economic development loans; Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
a UN specialized agency Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, SaoTome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
International Chamber of Commerce (ICC) members— (78 national councils) Algeria, Argentina, Australia, Austria, Bahrain, Bangladesh, Belgium, Brazil,
Burkina Faso, Cameroon, Canada, Caribbean, Chile, China, Colombia, Cote d''Ivoire, Cuba, Cyprus, Czech
established— 1919 Republic, Denmark, Ecuador, Egypt, Finland, France, Germany, Ghana, Greece, Greenland, Hong Kong, Hungary,
a/m— to promote free trade and private Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait, Lebanon, Lithuania,
enterprise and to represent business interests at Luxembourg, Madagascar, Mexico, Morocco, Netherlands, NZ, Nigeria, Norway, Pakistan, Peru, Philippines,
national and international levels Poland, Portugal, Russia, Saudi Arabia, Senegal, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sweden,
Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo, Tunisia, Turkey, UK, US, Uruguay, Venezuela, Yugoslavia
International Civil Aviation Organization members— (187) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
(ICAO) Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
established— 7 December 1944 Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
effective-4 April 1 947 Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
a/m— to promote international cooperation in Cyprus, Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
civil aviation; a UN specialized agency Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Palau, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
587
Appendix B: International Organizations and Groups (continued)
International Committee of the Red Cross
(ICRC)
established— M February 1863
a/m— to provide humanitarian aid in wartime
International Confederation of Free Trade
Unions (ICFTU)
established— HA December 1949
a/m— to promote the trade union movement
International Court of Justice (iCJ)
note— also known as the World Court
established— 3 February 1946 superseded
Permanent Court of International Justice
a/m— primary judicial organ of the UN
International Criminal Police Organization
(Interpol)
e$tablished-^A September 1 923 set up as the
International Criminal Police Commission;
13 June 1956 constitution modified and present
name adopted
a/m— to promote International cooperation
among police authorities in fighting crime
members— {25 individuals) all Swiss nationals
members— {221 affiliated organizations in the following 148 countries) Algeria, Angola, Antigua and Barbuda,
Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados, Basque Country, Belgium, Belize,
Benin, Bermuda, Botswana, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, El Salvador, Eritrea, Estonia, Falkland Islands, Fiji, Finland, France, French Polynesia, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Holy
See, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, Kiribati, South Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montserrat, Morocco, Mozambique, Nepal, Netherlands,
New Caledonia, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Puerto Rico, Romania, Russia, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US, Vanuatu, Venezuela, Yugoslavia, Zambia,
CO
CO
COL
170
.CO
10 59N
74 48 W
Bashi Channel
Pacific Ocean
22 00 N
121 00 E
Basilan Strait
Pacific Ocean
6 49N
122 05 E
Basque Provinces
4 36N
74 05 W
Bohemia (region)
Czech Republic
5000N
14 30E
Bombay (see Mumbai)
4 00N
90 30W
Malta Channel
Atlantic Ocean
56 44 N
26 53E
Malvinas, Islas (island group)
Falkland Islands (Islas Malvinas)
5145S
59 00W
Mamoutzou (capital)
13 32N
80 03 W
Roosevelt Island
13 00N
81 30 W
San Bernardino Strait
Pacific Ocean
124 10 E
San Felix, Isla (island)
14 25N
8016W
Serranilla Bank (shoal)
15 51 N
79 46 W
Settlement, The (capital)','23c78027a65d5f75501b7122b7eebf6e93dc9eefba2ce38bdb5e4d2b44efaf51','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5237b0e9552003c60db4f1c8a35f1902c8da82a19626c7c25cf4b06787b6ec56',2001,'MZ','Mozambique','transnational-issues',318,'Disputes - international: claims
French-administered Mayotte; the island of Anjouan
(Nzwani) has moved to secede from Comoros
114
Congo, Democratic
Republic of the
Background: Since 1994 the Democratic Republic
of the Congo (DROC; formerly called Zaire) has been
rent by ethnic strife and civil war, touched off by a
massive inflow of refugees from the fighting in
Rwanda and Burundi. The government of former
president MOBUTU Sese Seko was toppled by a
rebellion led by Laurent KABILA in May 1997; his
regime was subsequently challenged by a Rwanda-
and Uganda-backed rebellion in August 1998. Troops
from Zimbabwe, Angola, Namibia, Chad, and Sudan
intervened to support the Kinshasa regime. A
cease-fire was signed on 10 July 1999, but sporadic
fighting continued. KABILA was assassinated in
January 2001 and his son Joseph KABILA was named
head of state. The new president quickly began
overtures to end the war.
Disputes - international: none
Location: Southern Africa, island in the Mozambique
Channel, about one-third of the way between
Madagascar and Mozambique
Geographic coordinates: 17 03 S, 42 45 E
Map references: Africa
Area:
total: 4.4 sq km
land: 4.4 sq km
water: 0 sq km
Area - comparative: about seven times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 NM
territorial sea: 12 NM
Climate: tropical
Terrain: low and flat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Natural resources: guano deposits and other
fertilizers
Land use:
arabie land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 90%
other: 10%
Irrigated land: 0sqkm(1993)
Natural hazards: periodic cyclones
Environment - current issues: NA
Geography - note; wildlife sanctuary
Background: Almost five centuries as a Portuguese
colony came to a close with independence in 1 975.
Large-scale emigration by whites, economic
dependence on South Africa, a severe drought, and a
prolonged civil war hindered the country''s
development. The ruling party formally abandoned
Marxism in 1 989, and a new constitution the following
year provided for multiparty elections and a free
market economy. A UN-negotiated peace agreement
with rebel forces ended the fighting in 1992.
Disputes - international: none
illicit drugs: Southern African transit point for South
Asian hashish, South Asian heroin, and South
American cocaine probably destined for the European
and South African markets; producer of cannabis (for
local consumption) and methaqualone (for export to
South Africa)
Illicit drugs: significant transit point for African
cannabis and South Asian heroin, mandrax, and
methamphetamines destined for the South African
and European markets
Taiwan
Background: In 1895, military defeat forced China
to cede Taiwan to Japan, however it reverted to
Chinese control after World War 11. Following the
communist victory on the mainland in 1949, 2 million
Nationalists fled to Taiwan and established a
government using the 1947 constitution drawn up for
all of China. Over the next five decades, the ruling
authorities gradually democratized and incorporated
the native population within its governing structure.
Throughout this period, the island has prospered to
become one of East Asia''s economic "Tigers." The
dominant political issue continues to be the
relationship between Taiwan and China and the
question of eventual reunification.
Disputes - international: involved in complex
dispute over the Spratly Islands with China, Malaysia,
Philippines, Vietnam, and possibly Brunei; Paracel
Islands occupied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as
does China
Illicit drugs: transit point for heroin and
methamphetamine; major problem with domestic
consumption of methamphetamine and heroin
567
Appendix A:
Abbreviations
A
ABEDA
Arab Bank for Economic Development in Africa
ACC
Arab Cooperation Council
ACCT
Agency for the French-Speaking Community
AGP Group
African, Caribbean, and Pacific Group of States
AfDB
African Development Bank
AFESD
Arab Fund for Economic and Social Development
Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen
Oxides
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Nitrogen Oxides or Control of Emissions
of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent
Organic Poilutants
Protocol to the 1979 Convention on Long-Range Transboundary Air Poliution on
Persistent Organic Pollutants
Air Pollution-Sulphur 85
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
the Reduction of Sulphur Emissions or Their Transboundary Fluxes by at Least
30%
Air Pollution-Sulphur 94
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
Air Pollution-Volatile
Organic Compounds
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AL
Arab League
AMF
Arab Monetary Fund
AMU
Arab Maghreb Union
Antarctic-Environmental
Protocol
Protocol on Environmental Protection to the Antarctic Treaty
ANZUS
Australia-New Zealand-United States Security Treaty
APEC
Asia-Pacific Economic Cooperation
Arabsat
Arab Satellite Communications Organization
ARF
ASEAN Regional Forum
AsDB
Asian Development Bank
ASEAN
Association of Southeast Asian Nations
Autodin
Automatic Digital Network
B
Benelux
Benelux Economic Union
Biodiversity
Convention on Biological Diversity
BIS
Bank for International Settlements
BSEC
Black Sea Economic Cooperation Zone
C
c
Commonwealth
CACM
Central American Common Market
CAEU
Council of Arab Economic Unity
CAN
Andean Community of Nations
Caricom
Caribbean Community and Common Market
CB
citizen’s band mobile radio communications
CBSS
Council of the Baltic Sea States
568
Appendix A: Abbreviations (continued)
ccc
Customs Cooperation Council
CDB
Caribbean Development Bank
CE
Council of Europe
CEI
Central European Initiative
CEMA
Council for Mutual Economic Assistance; also known as CMEA or Comecon
CEMAC
Monetary and Economic Community of Central Africa
CEPGL
Economic Community of the Great Lakes Countries
CERN
European Organization for Nuclear Research
c.i.f. cost, insurance, and freight
CIS
Commonwealth of Independent States
CITES
see Endangered Species
Climate Change
United Nations Framework Convention on Climate Change
Climate Change-Kyoto
Protocol
Kyoto Protocol to the United Nations Framework Convention on Climate Change
COCOM
Coordinating Committee on Export Controls
Comsat
Communications Satellite Corporation
CP
Colombo Plan
CY
calendar year
D
DC
developed country
Desertification
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in Africa
DSN
Defense Switched Network
DWT
deadweight ton
E
EADB
East African Development Bank
EAPC
Euro-Atlantic Partnership Council
EBRD
European Bank for Reconstruction and Development
EC
European Community
ECA
Economic Commission for Africa
ECE
Economic Commission for Europe
ECLAC
Economic Commission for Latin America and the Caribbean
ECO
Economic Cooperation Organization
ECOSOC
Economic and Social Council
ECOWAS
Economic Community of West African States
ECS
European Coal and Steel Community
EEC
European Economic Community
EFTA
European Free Trade Association
ElB
European Investment Bank
EMU
European Monetary Union
Endangered Species
Convention on the International Trade in Endangered Species of Wild Flora and
Fauna (CITES)
Entente
Council of the Entente
Environmental
Convention on the Prohibition of Military or Any Other Hostile Use of
Modification
Environmental Modification Techniques
ESA
European Space Agency
569
Appendix A: Abbreviations (continued)
ESCAP
Economic and Social Commission for Asia and the Pacific
ESCWA
Economic and Social Commission for Western Asia
est.
estimate
EU
European Union
Euratom
European Atomic Energy Community
Eutelsat
European Telecommunications Satellite Organization
Ex“lm
Export-Import Bank of the United States
F
FAO
Food and Agriculture Organization
FAX
facsimile
f.o.b.
free on board
FLS
Front Line States
FRG
Federal Republic of Germany (West Germany): used for information dated
before 3 October 1 990 or CY91
FSU
former Soviet Union
FY
fiscal year
FYROM
The Former Yugoslav Republic of Macedonia
FZ
Franc Zone
G
G-2
Group of 2
G-3
Group of 3
G-5
Group of 5
G-6
Group of 6
G-7
Group of 7
G-8
Group of 8
G-9
Group of 9
G-10
Group of 10
G-11
Group of 1 1
G-15
Group of 15
G-19
Group of 19
G-24
Group of 24
G-30
Group of 30
G-33
Group of 33
G-77
Group of 77
GATT
General Agreement on Tariffs and Trade; now WTrO
GCC
Gulf Cooperation Council
GDP
gross domestic product
GDR
German Democratic Republic (East Germany); used for information dated before
3 October 1990 or CY91
GNP
gross national product
GRT
gross register ton
GWP
gross world product
H
Habitat
United Nations Center for Human Settlements
Hazardous Wastes
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
HF
high-frequency
570
Appendix A: Abbreviations (continued)
I
lADB
Inter-American Development Bank
IAEA
International Atomic Energy Agency
IBEC
International Bank for Economic Cooperation
IBRD
International Bank for Reconstruction and Development (World Bank)
ICAO
International Civil Aviation Organization
ICC
International Chamber of Commerce
ICJ
International Court of Justice (World Court)
ICRC
International Committee of the Red Cross
ICRM
International Red Cross and Red Crescent Movement
ICTR
International Criminal Tribunal for Rwanda
ICTY
International Criminal Tribunal for the former Yugoslavia
IDA
International Development Association
IDB
Islamic Development Bank
lEA
International Energy Agency
IFAD
International Fund for Agricultural Development
IFC
International Finance Corporation
IFCTU
International Federation of Christian Trade Unions
IFRCS
International Federation of Red Cross and Red Crescent Societies
IGAD
Inter-Governmental Authority on Development
IGADD
Inter-Governmental Authority on Drought and Development
!HO
International Hydrographic Organization
IIB
International Investment Bank
ILO
International Labor Organization
IMF
International Monetary Fund
IMO
International Maritime Organization
Inmarsat
International Mobile Satellite Organization
InOC
Indian Ocean Commission
INSTRAW
International Research and Training Institute for the Advancement of Women
Intelsat
International Telecommunications Satellite Organization
Interpol
International Criminal Police Organization
Intersputnik
International Organization of Space Communications
IOC
International Olympic Committee
lOM
International Organization for Migration
ISO
International Organization for Standardization
ITU
International Telecommunication Union
K
kHz
kilohertz
km
kilometer
kW
kilowatt
kWh
kilowatt-hour
L
LAES
Latin American Economic System
LAIA
Latin American Integration Association
Law of the Sea
United Nations Convention on the Law of the Sea (LOS)
LDC
less developed country
571
Appendix A: Abbreviations (continued)
LLDC
least developed country
London Convention
see Marine Dumping
LOS
see Law of the Sea
M
m
meter
Marecs
Maritime European Communications Satellite
Marine Dumping
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other
Matter
Marine Life Conservation
Convention on Fishing and Conservation of Living Resources of the High Seas
MARPOL
see Ship Pollution
Medarabtel
Middle East Telecommunications Project of the International
Telecommunications Union
Mercosur
Southern Cone Common Market
MHz
megahertz
MINURSO
United Nations Mission for the Referendum in Western Sahara
MONUC
United Nations Organization Mission in the Democratic Republic of the Congo
N
NA
not available
NAM
Nonaligned Movement
NATO
North Atlantic Treaty Organization
NC
Nordic Council
NEA
Nuclear Energy Agency
NEGL
negligible
NIB
Nordic Investment Bank
NIC
newly industrializing country
NIE
newly industrializing economy
NIS
new independent states
NM
nautical mile
NMT
Nordic Mobile Telephone
NSG
Nuclear Suppliers Group
Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and
Under Water
NZ
MZ
MZ
MOZ
508
.mz
22 30 8
34 30 E
Inini (former name for French Guiana)
2556S
32 34 E
Loyalty Islands (lies Loyaute)
25 58S
32 35 E
Marcus Island (Minami-tori-shima)
1815S
35 00 E
Mogadishu (capital)
13 SOS
37 00E
0 Oahu (Island)
United States (Hawaii)
21 30 N
158 00 W
Ocean Island (Banaba)
1815S
35 00 E
Portuguese Guinea (former name for Guinea-Bissau)
1600S
37 00E
Zanzibar (island)
Tanzania
610S
3911 E
Zhong Guo (local name for China)','e028369b4ef3be9f2f9c8742db3422eb41cf420cb4ce29e494a1aba5fde0222e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9815453edc99f21b2411643df6cb4ac98a6cc8102ab63c1bc58921f8ee5cb0a4',2001,'CG','Congo','transnational-issues',321,'Disputes - International: the Democratic Repubiic
of the Congo is in the grip of a civil war that has drawn
in military forces from neighboring states, with
Uganda and Rwanda supporting the rebel movements
that occupy much of the eastern portion of the state;
most of the Congo river boundary with the Repubiic of
the Congo is indefinite (no agreement has been
reached on the division of the river or its isiands,
except in the Pool Malebo/Staniey Pool area)
Illicit drugs: illicit producer of cannabis, mostly for
domestic consumption
Congo, Republic of the
Disputes ■ international: most of the Congo river
boundary with the Democratic Republic of the Congo
is indefinite (no agreement has been reached on the
division of the river or its islands, except in the Stanley
Pool/Pool Malebo area)
119','b415eb02e18e77661718e1512ebc5dfaa1b33b5991150defc5f81d7069d95ff8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b60ee6836e51195e66057d0e65f56ebfb53bd1155559f8508d1e9a9f8375ad6',2001,'CK','Cook Islands','transnational-issues',328,'(self-governing in free
association with
New Zealand)
„ , ^ ^Penrhyn
Rakahanga .
Pukapuka
Manihiki
■ Nassau
Island
Suwarrow
Soulh
^aciiic Ocann
Palmerston
Aitutaki ,
Manuae
Takutea , .Miiiaro
Atiu Mauke
— * AVARUA
0 150 300 km
Rarotonga
0 150 300 mi
’''Mangaia
Disputes “ international: none
Coral Sea Islands
(territory of Australia)
Disputes -international: none
Disputes -international: none
Disputes - international: none
260
Disputes - international: none
261
CW
CK
COK
184
.ck
Coral Sea Islands
CR
—
—
—
—
ISO includes with Australia
21 12 S
159 46 W
Axel Heiberg Island
1053S
165 49 W
634
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Danish Straits
Atlantic Ocean
58 00N
1100E
Danish West Indies (former name for the Virgin Islands)
Virgin Islands
18 20N
64 50 W
Danmark (local name)
21 14 S
159 46 W
Hatay (province)
Turkey
36 30 N
3615E
Havana (capital)
1053S
165 49 W
Punjab (region)
India, Pakistan
30 SON
73 30E
Puntland (region)','4abe0a28e0021f90050f9a742ee8e57374d4dab49842c4e78b389b9a842ef8e5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('212c8d99dde791a4d0fa04ece485508b78695e09f7c0ce6a9639d27c6f3be578',2001,'CR','Costa Rica','transnational-issues',337,'&
Background: Costa Rica is a Central American
success story: since the late 19th century, only two
brief periods of violence have marred its democratic
development. Although still a largely agricultural
country, it has achieved a relatively high standard of
living. Land ownership is widespread. Tourism is a
rapidly expanding industry.
Disputes - international: legal dispute over
navigational rights of Rio San Juan on border with
cs
CR
CRI
188
.cr
Cote d''Ivoire
IV
Cl
CIV
384
.ci
5 32N
87 04W
Cocos Islands
956N
84 05 W
San Juan (capital)','dc763f81ff5f934862b25dc8da02de75a394fd518665ab62f5fca9ffe6c6e5d0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee455405b8ccc73c6eec6d7b1474a260eadc3e99bb990be7ef4373c5266e9325',2001,'NI','Nicaragua','transnational-issues',345,'Illicit drugs: transshipment country for cocaine and
heroin from South America; illicit production of
cannabis on small, scattered plots; domestic cocaine
consumption is rising, particularly crack cocaine;
those who previously only trafficked are now
becoming users
0 75 150 km Gulf Of GuinB3
0 75 150 mi
Background: Settled as a colony of Spain in the
1520s, Nicaragua gained its independence in 1821.
Violent opposition to governmental manipulation and
corruption spread to all classes by 1978 and resulted
in a short-lived civil war that brought the Marxist
Sandinista guerrillas to power in 1 979. Nicaraguan aid
to leftist rebels in El Salvador caused the US to
sponsor anti-Sandinista contra guerrillas through
much of the 1980s. Free elections in 1990 and again
In 1996 saw the Sandinistas defeated. The country
has slowly rebuilt its economy during the 1990s, but
was hard hit by Hurricane Mitch in 1998.
Disputes ■ international: territorial disputes with
Colombia over the Archipelago de San Andres y
Providencia and Quita Sueno Bank; with respect to
the maritime boundary question in the Golfo de
Fonseca, the ICJ referred to the line determined by
the 1900 Honduras-Nicaragua Mixed Boundary
Commission and advised that some tripartite
resolution among El Salvador, Honduras, and
Nicaragua likely would be required; maritime
boundary dispute with Honduras in the Caribbean Sea
is before the ICJ; legal dispute over navigational rights
of San Juan River on border with Costa Rica
Illicit drugs: transshipment point for cocaine
destined for the US and transshipment point for
arms-for-drugs dealing
NU
Nl
NIC
558
.ni
622
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
1215N
83 00 W
Corocoro Island
Guyana, Venezuela
3 38N
66 50 W
Corsica (Corse) (island)
1215N
83 00W
Majorca Island (Isla de Mallorca)
12 09N
8617W
Manama (capital)','c9b190ac7629340d05a5b2d7eefae8d3b93d25af5c391969da2c76e63b8c3196','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7cfaa5053e90643b9973fc39a1d68b61912d8a53776b21b6ca863d8fea8abc7',2001,'HR','Croatia','transnational-issues',350,'Background: In 1918, the Croats, Serbs, and
Slovenes formed a kingdom known after 1929 as
Yugoslavia. Following World War II, Yugoslavia
became an independent communist state under the
strong hand of Marshal TITO. Although Croatia
declared its independence from Yugoslavia in 1 991 , it
took four years of sporadic, but often bitter, fighting
before occupying Serb armies were mostly cleared
from Croatian lands. Under UN supervision the last
Serb-held enclave in eastern Slavonia was returned to
Croatia in 1998.
Terrain: geographically diverse; flat plains along
Flungarian border, low mountains and highlands near
Adriatic coastline and islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1 ,830 m
Natural resources: oil, some coal, bauxite,
low-grade iron ore, calcium, natural asphalt, silica,
mica, clays, salt, hydropower
Land use:
arable land: 21%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 38%
other: 19% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: destructive earthquakes
Environment - current issues: air pollution (from
metallurgical plants) and resulting acid rain is
damaging the forests; coastal pollution from industrial
and domestic waste; landmine removal and
reconstruction of infrastructure consequent to
1992-95 civil strife
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Desertification,
Endangered Species, Flazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: controls most land routes from
Western Europe to Aegean Sea and Turkish Straits
HR
HR
HRV
191
.hr
43 00 N
17 00E
Daman (Damao) (city)
45 ION
15 30 E
Hudson Bay
Arctic Ocean
60 00 N
86 00 W
Hudson Strait
Arctic Ocean
62 00 N
71 00 W
Hunter Island
New Caledonia, Vanuatu
22 24 S
172 06 E
Iberian Peninsula
Portugal, Spain
40 00 N
500W
Iceland Sea
Arctic Ocean
68 00 N
20 00 W
Ifni (region; former name of part of Spanish West Africa)
42 24 N
18 31 E
Pribilof Islands
18 00E
Slovenija (local name for Slovenia)
4548N
15 58E
Zaire (former name for the Democratic Republic of
the Congo)
Democratic Republic of the Congo
1500S
30 00 E
Zakhalinskiy Zaiiv (bay)
Pacific Ocean
54 DON
142 00 E
Zaliv Shelikhova (bay)
Pacific Ocean
60 00 N
157 30 E
Zambezia (region)','de2b9e684a337a05aff8475aaaf5acbf741176b2a9f57f3c7bcb2f2657b68ddd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('995dc37a8fed38024d06faf3972bd6613681b8e4d93e3a89819a581dd07b7644',2001,'SI','Slovenia','transnational-issues',359,'Disputes - international: Croatia and Italy made
progress toward resolving a bilateral issue dating from
World War II over property and ethnic minority rights;
progress with Slovenia on discussions of adjustments
to land boundary, but problems remain in defining
maritime boundary in Gulf of Piran; Croatia and
Yugoslavia are negotiating the status of the
strategically important Prevlaka Peninsula, which is
currently under a UN military observer mission
(UNMOP)
Illicit drugs: transit point along the Balkan route for
Southwest Asian heroin to Western Europe; a minor
transit point for maritime shipments of South
American cocaine bound for Western Europe
129
SI
SI
SVN
705
.si
4603N
14 31 E
Llanos (region)
Venezuela
8 00N
68 00 W
Lobamba (city)
Swaziland
26 27S
31 12 E
Lombok (island)
46 00 N
15 00E
Slovensko (local name for Slovakia)','8940fcf0731d1e3790fa35d86e2fc9f2aefb2a801c6c791d7b7f11b2b3ef3979','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f25ae2e9ba7f9565d0788bd167e80573343655f660ae2365aa0e644d4fd77bac',2001,'CU','Cuba','transnational-issues',368,'Disputes ■ international: US Naval Base at
Guantanamo Bay is leased to US and only mutual
agreement or US abandonment of the area can
terminate the lease
Illicit drugs: territorial waters and air space serve as
transshipment zone for cocaine bound for the US and
Europe; established the death penalty for certain
drug-related crimes in 1999
132
P<iii?nnc
North Atlantic
lie de la Tortue q ^
Port-de''Pai)c^;
Cap-H anil''ll
''''N,^^Gonaives
lie de la Gonive c''
cr ''
Jeremie
MiragoSne
Hispaniola
PORT-AU-PRINCE^
Jacmel
Ca ribbon n Son
DOMINICAN'' )
REPUBLIC ^
0 30 60 km ^
Disputes ■ international: claims US-administered
Navassa Island
Illicit drugs: major Caribbean transshipment point
for cocaine en route to the US and Europe; vulnerable
to money laundering
Heard Island
and McDonald
Islands
(territory of Australia)
Background: These uninhabited, barren islands
were transferred from the UK to Australia in 1947.
Populated by large numbers of seal and bird species,
the islands have been designated a nature preserve.
CU
CU
CUB
192
.CU
20 00 N
75 08W
Guatemala (capital)
23 08 N
82 22 W
Hawaii (island)
21 40 N
82 50W
K
Kabardino-Balkaria (region)
Russia
4330N
43 30E
Kabul (capital)
21 40 N
82 50 W
Pleasant Island
21 40 N
82 50W
Yucatan Channel
Atlantic Ocean
21 45 N
85 45 W
Yucatan Peninsula','8d355d7a154378a3a98e78653067ecf08ff3b0d709eb0034e7ea3f719698c382','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9a9e4a54eaf1bdc87f1eede6138b8719026d4b723597ebe52510b45aee6f6c0',2001,'CY','Cyprus','transnational-issues',377,'Disputes - international: 1974 hostilities divided the
island into two de facto autonomous areas, a Greek
Cypriot area controlled by the internationally
recognized Cypriot Government (59% of the island''s
land area) and a Turkish-Cypriot area (37% of the
island), that are separated by a UN buffer zone (4% of
the island): there are two UK sovereign base areas
mostly within the Greek Cypriot portion of the island
Illicit drugs: minor transit point for heroin and
hashish via air routes and container traffic to Europe,
especially from Lebanon and Turkey; some cocaine
transits as well
135
Czech Republic ||||^U|^
Background: After World War 1 1 , Czechoslovakia fell
within the Soviet sphere of influence. In 1968, an
invasion by Warsaw Pact troops ended the efforts of
the country''s leaders to liberalize party rule and create
"socialism with a human face." Anti-Soviet
demonstrations the following year ushered in a period
of harsh repression. With the collapse of Soviet
authority in 1989, Czechoslovakia regained its
freedom through a peaceful "Velvet Revolution." On
1 January 1993, the country underwent a "velvet
divorce" into its two national components, the Czech
Republic and Slovakia. Now a member of NATO, the
Czech Republic has moved toward integration in
world markets, a development that poses both
opportunities and risks.
Disputes - International: Liechtenstein''s royal
family claims restitution for 1 ,600 sq km of land in the
Czech Republic confiscated in 1918; individual
Sudeten German claims for restitution of property
confiscated in connection with their expulsion after
World War 11; Austria has minor dispute with Czech
Republic over nuclear power plants and post-World
War II treatment of German-speaking minorities
Illicit drugs: major transshipment point for
Southwest Asian heroin and minor transit point for
Latin American cocaine to Western Europe; domestic
consumption - especially of locally produced synthetic
drugs - on the rise
Disputes - international: Rockall continental shelf
dispute involving Iceland and the UK (Ireland and the
UK have signed a boundary agreement in the Rockall
area); dispute with Iceland over the Faroe Islands
fisheries median line boundary within 200 NM;
disputes with Iceland, the UK, and Ireland over the
Faroe Islands continental shelf boundary outside
200 NM
140
CY
CY
CYP
196
■cy
Czech Republic
EZ
cz
CZE
203
.CZ
35 00 N
33 00 E
Kiel Canal (Nord-Ostsee Kanal)
Atlantic Ocean
5S5SN
908 E
Kiev (capital)
35 00 N
33 00 E
Kirghiziya (former name for Kyrgyzstan)
35 ION
33 22 E
Lemnos (island)
35 ION
33 22 E
Nightingale Island
Saint Helena
3725S
12 30W
Nihon (local name for Japan)
3515N
33 44 E
Northern Epirus (region)
Albania, Greece
40 00 N
20 30 E
Northern Grenadines (political region)','9d288f9622733d061f897494e17e11a99e0cd2b14b4494fabdff93ca37544f27','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('395f6207aef221800a48758aaceb312f055c8d737a032b7456dc3a9645e26bcd',2001,'DJ','Djibouti','transnational-issues',378,'Background; The French Territory of the Afars and
the Issas became Djibouti in 1977. A peace accord in
1994 ended a three-year uprising by Afars rebels.
Disputes - international: none
142
Disputes - international: none
Illicit drugs: transshipment point for narcotics bound
for the US and Europe; minor cannabis producer;
banking industry is vulnerable to money laundering
144
DJ
DJ
DJI
262
.dj
619
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
11 30 N
43 00 E
Afghanestan (local name for Afghanistan)
11 30 N
4315E
Dnieper (river)
Beiarus, Russia, Ukraine (Dnyapro, Dnepr, Dnipro)
46 30 N
3218E
Dniester (river)
Moldova, Ukraine (Nistru, Dnister)
4618N
3017E
Dobruja (region)
Bulgaria, Romania
43 30 N
2800E
Dodecanese (island group)
11 SON
43 00 W
French Sudan (former name for Mali)
1130N
43 00E
French Togoland (former name for Togo)','8d263ba9554dfb8ed88819353c9aba4ff0bccc702b6540480c9cb082a7ecf228','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214459b3f2f6a1d44a5627a6075e71b73afb4de72879904793df3cd179a6b9e1',2001,'DO','Dominican Republic','transnational-issues',386,'H^jd
Background; A legacy of unsettled, mostly
non-representative, rule for much of the 20th century
was brought to an end In 1996 when free and open
elections ushered in a new government.
Disputes - international: none
Illicit drugs: transshipment pointfor South American
drugs destined for the US and Europe; has become a
transshipment point for ecstasy from the Netherlands
and Belgium destined for US and Canada
Disputes - international: none
DR
DO
DOM
214
.do
East Timor
—
TP
TMP
626
•tp
FIPS Includes with Indonesia
19 00N
70 40 W
Republique Centrafricain (local name for Central
African Republic)
18 28N
69 54 W
Sao Pedro e Sao Paulo, Penedos de (rocks)','a8c821dd3398da29e8cd40cc3c77f83a4d10d35abd119b2173fbc455ab9df219','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1185008b3f9f20f1046fce6a621d2c72b4db331cb749d46d2227be9120d1192',2001,'EC','Ecuador','transnational-issues',394,'Background: The "Republic of the Equator" was one
of three countries that emerged from the collapse of
Gran Colombia in 1830 (the others being Colombia
and Venezuela). Between 1904 and 1942, Ecuador
lost territories in a series of conflicts with its neighbors.
A border war with Peru that flared in 1 995 was
resolved in 1999.
EC
EC
ECU
218
.ec
OOON
90 SOW
Commander Islands (Komandorskiye Ostrova)
Russia
55 00N
167 00 E
Comores (local name for Comoros)
039 S
78 26 W
Courantyne River
Guyana, Suriname
5 57N
57 06W
Cozumel (island)
OOON
90 SOW
Galicia (region)
Poland, Ukraine
49 SON
23 00E
Galicia (region)
013S
78 30 W
R
Rabat (capital)','2ae5c191dcef32948e08a8b52d0c3025a74629d141f7e99c66350ab6451e9857','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e26457b40279556f36add90d30ff064cc8f7170b7d9294ea3fb6a51a96e34998',2001,'PE','Peru','transnational-issues',403,'Disputes • international: none
Illicit drugs: significant transit country for cocaine
and derivatives of coca originating in Colombia and
Peru; importer of precursor chemicals used in
production of illicit narcotics; important
money-laundering hub; increased activity on the
northern frontier by trafficking groups and Colombian
insurgents
Background: After a dozen years of military rule,
Peru returned to democratic leadership in 1980. In
recent years, bold reform programs and significant
progress in curtailing guerrilla activity and drug
trafficking have resulted in solid economic growth.
Disputes -international: none
Illicit drugs: until 1 996 the world''s largest coca leaf
producer, Peru reduced the area of coca under
cultivation by 64% to 34,200 hectares between 1996
and the end of 2000; much of the cocaine base is
shipped to neighboring Colombia for processing into
cocaine for the international drug market; increasing
amounts of finished cocaine, however, are being
shipped to Europe or to Brazil and Bolivia for use in
the Southern Cone or transshipped to world markets
402
PE
PE
PER
604
•pe
12 03S
77 03W
Lincoln Sea
Arctic Ocean
83 00 N
56 00 W
Line Islands
Jarvis Island, Kingman Reef, Kiribati,
Palmyra Atoll
0 05N
157 00W
Lion, Gulf of
Atlantic Ocean
4320N
400E
Lisbon (capital)','357c72f4c19ac76e0602e0110c7324da09cd6ddb0846681aa7daa35dd1174f6f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2163fe3182049e030174570a3ae0a0b10dc05dc3865bee86a9d54a3aa2e2b5c',2001,'EG','Egypt','transnational-issues',412,'Disputes - international: Egypt asserts its claim to
the "Hala''ib Triangle," a barren area of 20,580 sq km
under partial Sudanese administration that is defined
by an administrative boundary which supersedes the
treaty boundary of 1899
Illicit drugs: a transit point for Southwest Asian and
Southeast Asian heroin and opium moving to Europe,
Africa, and the US; popular transit stop for Nigerian
couriers
EG
EG
EGY
818
•eg
31 12 N
29 54 E
Algiers (capital)
30 03N
31 15 E
California, Gulf of
Pacific Ocean
28 00N
11200W
Cameroon (local name for Cameroon)
3013N
33 09E
Gilbert Islands
3020N
32 23 E
Great Britain (island)
2700N
30 00 E
Mitia Pass
30 02N
32 54 E
Mocambique (local name for Mozambique)
34 00 E
Singapore (capital)
29 55 N
32 33 E
Suez, Gulf of
Indian Ocean
28 ION
33 27 E
Suisse (local French name for Switzerland)','e9db4277943b6e7f2f62ff916cf5fbb239d0a5ebad2aebdfb5381f05c3c6aa90','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80752706a063ec2a3ade63c03624e656255f900494296020ceaede6ab926e4b1',2001,'SV','El Salvador','transnational-issues',421,'Disputes - international: with respect to the
maritime boundary in the Golfo de Fonseca, the ICJ
referred to the line determined by the 1900
Honduras-Nicaragua Mixed Boundary Commission
and advised that some tripartite resolution among El
Salvador, Honduras and Nicaragua likely would be
required
Illicit drugs: transshipment point for cocaine;
marijuana produced for local consumption; domestic
drug abuse on the rise
ES
SV
SLV
222
.SV
8912W
Sanaa (capital)
/San « ?
“ ■_A‘''S • -■
> _ ^Matagalpa ^ j
’u.6n HICAI^QUA i
''^-QpManagua 7^
Gr''jnadaO-, ''/SMS
. r \\ 1 DELMA/Z
■■
V J’uil^r^as Ltab?
CmTA RIGaVk
''X >-'' I''r
isla dc San Andres
• (COLOMBIA)
Santa
Marta
Barranqiiilla^--,-)
Cartagena^ {
Bocas
del Toro
,GoJfUo,^
'' ; , David
Colon /''
j Balboa''*^, ''
IpaJma .% ■ ^
/
PATIAW/^
) •'' \\
Scale 1:12,500,000
Lambert Conformal Conk Projection,
standard parallels 9‘N and 1 7*N
Is/a det Coco
(COSTA RICA)
McdcIHn^
100
200
300 Kilometers
0
I - ^ - l-t - ,
0 100 200 300 Miles
Boundary represcmallon is not necessarily authoritative.
Buenaventura
Cali;''
9'';vy:
.‘Y''rt^Sati''Crlstob
Biicaramanga:^"
'', j'' ‘
mr;
■ • ■ ''
■ ''fGs''i''G U,:0''^''''M I
■
ibagutv'' Bogota^ ./
jf c#^
Bnhima ^ f
Tree port
ISLANDS Nciv
\\Proi^idencc
Great
Abaco
THE BAHAMAS
Cuinc/ios Cay
(THE BAHAMAS) <■
Amiros^A - ^cai wana
Isinticl \\icx \\ ''
Cnv''Srt/''- \\d^ - i''p’ f;i
HE BAHAMAS, :> , . Exumo^ \\Long Istond s„^„„cay
(THE BAHAMAS) o- ^ ^ /■ M ,^X^okeC( iSlOfld '' ^
:lara '' \\ RAGGED »- Mayaeuana -
• •Cnv''Lobos ^ \\ ISLAND OtL
Cienfuceos ^xJT^.miEBAftAMAs, \\ RANGE pMcMm5 l^irks^d-''???
''X,'' - rriRA^. miEBAHA«.s, fctod 5/x Caicos isimds
^^^cvltas '' ^ / (U.K.)i»’,-%-
, \\ Camagucy Cre«MMg™f -x
''1 l(C V -''''''3^
mim^^m
Camagiiey
.angan"l„; SanOago ''
yman Islands
•oU:si-Maval Base /
Quantanamo Bay
Montego Bay
ManaguaT
802785AI (R02067) 4-01
Samiirinda^
Jcckbcs
Makassar] *•''" ] .<•
I n il''a-n''''E:§.i''^ --
Dcnpasar ,.■. ^ . ^<^i^lemporarlly administered Ar.irutM >C.l
S<,mf,rt 0> T-inirr bytheUM)
riinar.HM ,v . -V-.-
Ashmore and
Cartier Islands
(AUSTKAUAI
A
c ’
feygpura''^l''^''^^re^vak
. i PAPL..
\\\\’av!Guinca
^ Darwin ■
%,
lf>of/(j(T(fn''i7/i’ ■
_ SOLOMOK
S r> ^ ISLAMDS
!'' i''^i
Funafuti
''Cuailnlcniinl''^ ^ ?anH\\ CRW;''
\\r
''h''''-\\
•','d323b7247cd0fd55dc69064fbe31a9f57e50cac2b3e263b93bc461e6526119b5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f06836a5837a9ded3cd80c74f1b8b2089ab3056790ddece29a553c2284aaac11',2001,'GQ','Equatorial Guinea','transnational-issues',422,'Background: Composed of a mainland portion and
five inhabited islands, Equatorial Guinea has been
ruled by ruthless leaders who have badly
mismanaged the economy since independence from
1 90 years of Spanish rule in 1 968. Although nominally
a constitutional democracy since 1991 , the 1996
presidential and 1 999 legislative elections were widely
seen as being flawed.
EK
GQ
GNQ
226
•gq
125S
5 36E
Antananarivo (capital)
330 N
842E
Biscay, Bay of
Atlantic Ocean
44 00N
4 00W
Bishkek (capital)
0 55N
919E
Corn Islands (Islas del Maiz)
059 N
9 33 E
Enderbury Island
3 30N
842 E
Pilipinas (local name for the Philippines)
2 00N
10 00E
Guinea, Gulf of
Atlantic Ocean
300 N
230 E
Guine-Bissau (local name for Guinea-Bissau)
3 45N
8 47E
Malacca, Strait of
Indian Ocean
2 30N
101 20 E
Malagasy Republic
1 30 N
10 00E
Riyadh (capital)
2 00N
10 00 E
Spanish Morocco (former name for northern Morocco)','b0d4cf9bebf5cff52a1b594c9776be67025ac51368740f45e2966fec81eaf0d9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db9e380850474b88093c8e5cbde54c8e3c376702eec7024eeb3d5408e4b72df1',2001,'GN','Guinea','transnational-issues',430,'Disputes - international: tripartite maritime
boundary and economic zone dispute with Cameroon
and Nigeria is currently before the ICJ; maritime
boundary dispute with Gabon because of disputed
sovereignty over islands in Corisco Bay
Disputes - international: as a result of the
12 December 2000 peace agreement ending a
two-year war with Ethiopia, the UN will administer a
25-km wide temporary security zone within Eritrea
until a joint boundary commission delimits and
demarcates a final boundary
158
.III
Background: Independent from France since 1958,
Guinea did not hold democratic elections until 1993
when Gen. Lansana CONTE (head of the military
government) was elected president of the civilian
government. He was reelected in 1 998. Unrest in
Sierra Leone has spilled over into Guinea, threatening
stability and creating a humanitarian emergency.
Disputes - international: border incursions by
Revolutionary United Front combatants from Sierra
Leone; civil war in that country has engendered a
massive flow of refugees to southern Guinea and
Daru^ f ,,
Tun‘..r V
AgSTRAUjA
South
New rV;i?''T/r
'' .-^.Ireland Oo:cyin
BljVHk ■-4...
Rabaur.K ^
NewBritainS y''^J
""--v _ \\\\ K i eta
_} '' BougainvilleX^j v^-,.
Lae^ c'' -I-
\\ PORT ^ Sar SOLOMON
\\ MbRESBY '' , ISLANDS ^
‘ . .
Coiv\\'' Sc''O
Disputes - international: none
Paracel Islands
South China Sea
North Rcof^^ Amphitrite
West SandooTree Island Group
Pa We .
Island
Woody °
Island
Rocky Island
^Drummond Island
Robert Island^
Money Island Duncan ^
Reef
Discovnry Reef W''
''^Lincoln
Island
Crescent Passu ^
Group Keah
Triton''’
Island
0
30 60 km
0
30 60 mi
GV
GN
GIN
324
.gn
931 N
13 43W
Confederatio Helvetica (local name for Switzerland)
11 00 N
10 00W
French Indochina (former name for French possessions
in southeast Asia)
Cambodia, Laos, Vietnam
15 00N
107 00 E
French Morocco (former name for Morocco)
11 00 N
10 00W
Guyane Francaise (local name for French Guiana)','8a242ac3d4ef532146d72f34509711c0cb973bf729ffc35094fff1224a3f2d73','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbdc93ad68184007a1fd0feb442b52c1fa9ec48ec55965bf717efd11695a5b58',2001,'EE','Estonia','transnational-issues',434,'Background: After centuries of Swedish and
Russian rule, Estonia attained independence in 1918.
Forcibly incorporated into the USSR in 1940, it
regained its freedom in 1991 with the collapse of the
Soviet Union. Since the last Russian troops left in
1 994, Estonia has been free to promote economic and
political ties with Western Europe.
Disputes - International: Estonian and Russian
negotiators reached a technical border agreement in
December 1996 which has not been signed nor
ratified by Russia as of February 2001
Illicit drugs: transshipment point for opiates and
cannabis from Southwest Asia and the Caucasus via
Russia, cocaine from Latin America to Western
Europe and Scandinavia, and synthetic drugs from
Western Europe to Scandinavia; possible precursor
manufacturing and/or trafficking; synthetic drug
production growing, trafficked to Russia, Baltics,
EN
EE
EST
233
.ee
5900N
26 00E
Eire (local name for Ireland)
58 50 N
22 30 E
Hispaniola (island)
Dominican Republic, Haiti
18 45N
71 00 W
Ho Chi Minh City (Saigon)
Vietnam
10 45N
106 40 E
Hokkaido (island)
58 25 N
22 30 E
Saba (island)
Netherlands Antilles
1738N
63 low
Sabah (state)
59 25 N
24 45 E
Tanganyika (former name for the mainland portion of
Tanzania)
Tanzania
600S
35 00 E
Tangier (city)','0aaf35081d15d2d39c934650fc452dab6fc85f06d67d310dceaaaf329f859068','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64b645a6233d660e342e3e89f24d4158a3fe98dd6e9da3b3f731df4afec82134',2001,'FO','Faroe Islands','transnational-issues',442,'(part of the Kingdom
of Denmark)
Background: The population of the Faroe Islands is
largely descended from Viking settlers who arrived in
the 9th century. The islands have been connected
politically to Denmark since the 14th century. A high
degree of self-government was attained in 1948.
FO
FO
FRO
234
.fo
62 00 N
7 00W
Fort-de-France (capital)
62 01 N
646W
Toshkent (see Tashkent)','7270808da146a96ba65e916ee7efd2ed72f4f8d5582356eb1c5c8db2344ba325','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5b4b80b3267010730ce6ffd00447be507f0bbdec5ccc7181d6e0860c7eed614',2001,'DK','Denmark','transnational-issues',450,'Disputes - international: Faroese are considering
proposals for full independence
p, Rotuma
South Pacific Ocean
Vanua Lev^u^basa ‘
LautoKa^-^ ,Levuka
Kadavu
. Ceva-i-Ra o loo 200 km
** 0 100 200 ml
Disputes ■ international: none
DA
DK
DNK
208
.dk
55 ION
15 00 E
Bosna i Hercegovina (local name for Bosnia and
Herzegovina)
55 40 N
12 35E
Coral Sea
Pacific Ocean
15 00S
150 00 E
Corfu (island)
56 00N
1000E
Danzig (city; former name for Gdansk)
55 20N
1025E
G Gaborone (capital)
56 00 N
915E
Juventud, Isla de la (Isle of Youth)
55 30 N
12 00E
Skagerrak (strait)
Atlantic Ocean
5745N
9 00E
Skopje (capital)
The Former Yugoslav Republic of Macedonia
21 26 E
Slavonia (region)','7642488f41d13a36de7bba223bc84d72ee514ff3459f2e4cd0303890174c0218','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5912fe66c95e40610e746e8bd5a81ba1e999bae4bf4ce1fdb952d5d15af6552f',2001,'JE','Jersey','transnational-issues',461,'Disputes - international: none
Disputes ■ international: none
172
Disputes - international: in November 1994, Iraq
formally accepted the UN-demarcated border with
Kuwait which had been spelled out in Security Council
Resolutions 687 (1991), 773 (1993), and 883 (1993);
this formally ends earlier claims to Kuwait and to
Bubiyan and Warbah islands
279
Disputes - international: progress with Croatia on
discussions of adjustments to land boundary, but
problems remain in defining maritime boundary in Gulf
of Piran; Austria has minor dispute with Slovenia over
nuclear power plants and post- World War II treatment
of German-speaking minorities
Illicit drugs: minor transit point for cocaine and
Southwest Asian heroin bound for Western Europe,
and for precursor chemicals
Disputes ■ international: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
Disputes - international: none
485
JE
—
—
.je
ISO includes with the United Kingdom
Johnston Atoll
JQ
—
—
—
—
ISO includes with the US Minor
Outiying islands
4912N
2 37W
Saint John (city)
Canada (New Brunswick)
4516N
66 04 W
Saint John''s (capital)','0e9e04d35533f970e5074483106119b8d3a38cf2b0cdc98d01c637d3100e4bce','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b52525e2d574c400911da3c4966c0e6169df84ea06c909a28896d3990efc97a',2001,'WF','Wallis and Futuna','transnational-issues',469,'Disputes ■ international: Madagascar claims
Bassas da India, Europa Island, Glorioso Islands,
Juan de Nova Island, and Tromelin Island; Comoros
claims Mayotte; Mauritius claims Tromelin Island;
territorial dispute between Suriname and French
Guiana; territorial claim in Antarctica (Adelie Land);
Matthew and Hunter Islands east of New Caledonia
claimed by France and Vanuatu
Illicit drugs: transshipment point for and consumer
of South American cocaine. Southwest Asian heroin,
and European synthetics
175
(overseas territory of France)
0 25 50 km
0 25 50 mi
lies
Wallis
MATA-UT(^
lie Uv4a
South Pacific Ocean
lies de Horne
he Futuna
^igave (Leava)
^lle Alofi
WF
WF
WLF
876
.wf
West Bank
WE
—
—
—
—
1419S
178 05 W
Fyn (island)
1419S
178 05 W
Hrvatska (local name for Croatia)
13 57S
171 56 W
Matsu (island)
Taiwan
2613N
11956E
Matthew Island
New Caledonia, Vanuatu
22 20S
171 20 E
Mauritania (local name for Mauritania)
1317S
176 low
Walvis Bay (former exclave) (city)','1c6ab369aa2247790ba46a5997488bf508878feebce1c3b013f59a63329dbe62','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45af972ce956689ad28144e6d181e155ce92a45a3a6d44d8770d51a2bb3a9f8e',2001,'GF','French Guiana','transnational-issues',470,'(overseas department
of France)
Background: First settled by the French in 1604,
French Guiana was the site of notorious penal
settlements until 1951. The European Space Agency
launches its communication satellites from Kourou.
FG
GF
GUF
254
•gf
456N
52 20 W
Celebes (island)
517N
52 35 W
Devon Island
4 00N
53 00 W
H Ha''apai Group (island group)
4 00N
53 00 W
Inland Sea
5 20N
52 37W
Sahara Occidental (former name for Western Sahara)','269e1455d24f605c338daf79289b89be22928e24d5d4648f45c0bfe0e396c55c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7100b6c5d18f1ddb8942994f9d06da9f3c8e7aeee8311804fefaff9a87650a2b',2001,'PF','French Polynesia','transnational-issues',474,'(overseas territory
of France)
FP
PF
PYF
258
■pf
ISO includes Clipperton Island
French Southern and Antarctic
Lands
FS
TF
ATF
260
.tf
FIPS 10-4 does not include the
French-claimed portion of Antarctica
(Terre Adelie)
23 20S
151 00 W
Avarua (capital)
16 30 8
151 45 W
Bordeaux (city)
2309S
134 58 W
Gaspar Strait
Pacific Ocean
300S
107 00 E
Gdansk (Danzig) (city)
900S
139 30 W
Martin Vaz, llhas (island group)
1732S
149 34 W
Paramaribo (capital)
15 00S
140 00 W
Pomerania (region)
Germany, Poland
53 40 N
15 35E
Ponape (Pohnpei) (island)
Federated States of Micronesia
6 55N
158 15 E
Port Louis (capital)
1700S
652
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Socotra (island)
17 37S
149 27 W
Taipei (capital)
Taiwan
25 03 N
121 30 E
Taiwan Strait
Pacific Ocean
24 00 N
11900E
Tallinn (capital)
19 00S
142 00 W
Tubuai Islands (lies Tubuai)
23 00S
150 00 W
Tunb al Kubra (island)
Iran
2614N
5519E
Tunb as Sughra (island)
Iran
2614N
55 09 E
Tunis (capital)','2d1abc380cc90db185658a191e353966df612c43666a9f49c5a8cc66c5bc48da','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('529772ff5c162ea7467c6690a96e3396b600f5b9ba1bfb10defc981089c4d496',2001,'KI','Kiribati','transnational-issues',475,'ILES
SOUTH PACIFIC OCEAN
Makatea ... ,
Clturoa* PAPEETE
''Oy Tahiti
^^I-ands
ARCHIPEL
DES TUAMOTU
■ Mataura
Mururoa'' ''
Rikitea.
.Rapa
g 200 4Q0 km
0 200 400 mi ’
MARSHALL
. JSLANDS
UNITED STATES ^
(Hawaii)
” Johnston Atoll
(U.S.)
North Pad fin Ocean
Kingman Reef pa,^y,a Atoll
(U.S.)
''TARAWA Howland I. (u.s.) o
''P, Baker I. (U.S.) _ Wrrt/ma/(
• % .o * '' jarvls i: ''(Chnstnias i:j
Banaba ’"..IGilbert _ .. (U.S.)
fsiands) ^ :(Phoer)ix TK
TUVALU’^" Islartds) .* »
SOLOMON
ISLANDS
.VANUATU
Tokelau Sooth Pacific Ocean
Cook Is. «
» . (N.Z.) ®
. SAMOA
American
French ,
Polynesia*
Samoa (U.S.) '' (pR.)
. . " Cook Islands *
nONGA
Disputes -international; none
Korea, North
Background: Following World War II, Korea was
split into a northern, communist half and a southern,
Western-oriented half. KIM Chong-i! has ruled North
Korea since his father and the country''s founder,
president KIM ll-song, died in 1994. After decades of
mismanagement, the North relies heavily on
international food aid to feed its population, while
continuing to expend resources to maintain an army of
about 1 million. North Korea''s long-range missile
development and research into nuclear and chemical
weapons are of major concern to the international
community.
Disputes - international; 33-km section of
boundary with China in the Paektu-san (mountain)
area is indefinite; Demarcation Line with South Korea
Background: After World War II, a republic was set
up in the southern half of the Korean Peninsula while
a communist-style government was installed in the
north. The Korean War (1950-53) had US and other
UN forces intervene to defend South Korea from North
Korean attacks supported by the Chinese. An
armistice was signed In 1 953 splitting the peninsula at
the 38th parallel known as the DMZ. Thereafter, South
Korea achieved rapid economic growth, with per
capita income rising to 13 times the level of North
Korea. In 1997, the nation suffered a severe financial
crisis from which it continues to make a solid recovery.
South Korea has also maintained its commitment to
democratize its political processes. In June 2000, a
historic first south-north summit took place between
the south''s President KIM Dae-jung and the north''s
leader KIM Chong-il. In December 2000, President
KIM Dae-jung won the Noble Peace Prize for his
lifeling committment to democracy and human rights
in Asia. He is the first Korean to win a Nobel Prize.
Disputes - international: Demarcation Line with
North Korea; Liancourt Rocks (Takeshima/Tokdo)
disputed with Japan
277
KR
Kl
KIR
296
,ki
Korea, North
KN
KP
PRK
408
.kp
Korea, South
KS
KR
KOR
410
.kr
052 S
169 35 E
Banat (region)
Hungary, Romania, Yugoslavia
45 30 N
21 00 E
Banda Sea
Pacific Ocean
5 00S
128 00 E
Bandar Seri Begawan (capital)
Brunei
4 52S
11455E
Bangka (island)
2 49S
171 40 W
Cape Juby (region; former name for
Southern Morocco)
1 52 N
157 20 W
Chukchi Sea
Arctic Ocean
69 00 N
171 00 W
Chuuk Islands (Truk Islands)
Federated States of Micronesia
725N
151 47 W
633
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Cilicia (region)
Turkey
36 SON
34 30E
Ciskei (enclave)
308S
171 05 W
Enewetak Atoll (Eniwetok Atoll)
1 25 N
173 00 E
Goa (state)
249 S
171 40 W
Kara Sea
Arctic Ocean
76 00 N
80 00 E
Karachevo-Cherkessia (region)
Russia
43 40 N
41 50 E
Karafuto (island; former name for southern Sakhalin Island)
Russia
50 00 N
143 00 E
Karakoram Pass
China, India
35 30 N
77 50 E
Karelia (region)
Finland, Russia
6315N
30 48 E
Karelian Isthmus
Russia
60 25 N
30 00E
Karimata Strait
Pacific Ocean
2 05S
108 40 E
Kashmir (region)
India, Pakistan
34 00N
76 00 E
Katanga (region)
Democratic Republic of the Congo
1000S
26 00E
Kathmandu (capital)
1 52 N
157 20 W
Kishinev (see Chisinau)
Moldova
47 00 N
2850E
Kithira Strait
Atlantic Ocean
36 00 N
23 00E
Kobe (city)
0 52S
169 35 E
Ocean Island (Kure Island)
330S
172 00 W
Pilipinas (local name for the Philippines)
1 25 N
173 00 E
Tartary, Gulf of
Pacific Ocean
5000N
141 00 E
Tashkent (capital)
10 06 8
152 23 W
Vrangelya, Ostrov (Wrangel Island)
Russia
71 14 N
179 36 W
656
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
w
Wake Atoll
Wake Island
1917N
166 36 E
Wakhan Corridor (see Vakhan)','c1ff5d11ee7e4866bb8df4a771eb898cbbdfdc8bf44f7fe486f651f1d6e494f6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5a4d32171a064d5eb7d82f9a96252104287652ca44f15f23bcbca9d7b3b9232',2001,'DE','Germany','transnational-issues',491,'Disputes -international: none
Illicit drugs: source of precursor chemicals for
South American cocaine processors; transshipment
point for and consumer of Southwest Asian heroin,
Latin American cocaine, and European-produced
synthetic drugs
Disputes ■ international: none
Macau
(special administrative
region of China)
Background: Colonized by the Portuguese in the
16th century, Macau was the first European
settlement In the Far East. Pursuant to an agreement
signed by China and Portugal on 13 April 1987,
Macau became the Macau Special Administrative
Region (SAR) of China on 20 December 1999. China
has promised that, under its "one country, two
systems" formula, China''s socialist economic system
will not be practiced in Macau and that Macau will
enjoy a high degree of autonomy in all matters except
foreign and defense affairs.
Disputes ‘international; none
Macedonia, The
Former Yugoslav
Republic of
Background: International recognition of The
Former Yugoslav Republic of Macedonia''s (FYROM)
independence from Yugoslavia in 1991 was delayed
by Greece''s objection to the new state''s use of what it
considered a Hellenic name and symbols. Greece
finally lifted its trade blockade in 1995, and the two
countries agreed to normalize relations, despite
continued disagreement over FYROM''s use of
"Macedonia." FYROM''s large Albanian minority and
the de facto independence of neighboring Kosovo
continue to be sources of ethnic tension.
Disputes - international: dispute with Greece over
its name; February 2001 agreement with Yugoslavia
settled alignment of boundary, stipulating
implementation within two years
Illicit drugs: increasing transshipment point for
Southwest Asian heroin and hashish; minor transit
point for South American cocaine destined for Europe
307
Disputes - international: none
Illicit drugs: major European producer of illicit
amphetamine and other synthetic drugs; important
gateway for cocaine, heroin, and hashish entering
Europe; major source of US-bound ecstasy
606
Appendix B: International Organizations and Groups (continued)
West African Economic and Monetary Union
(WAEMU)
members— {3) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
note—eAso known as Union Economique et
Monetaire Quest Africaine (UEMOA)
established— ^ August 1994
aim—{o increase competitiveness of members''
economic markets; to create a common market
Western European Union (WEU)
established— 23 October 1954
effective-^ May 1955
a/m—to provide mutual defense and to move
toward political unification
members— {^0) Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members— (6) Czech Republic, Hungary, Iceland, Norway, Poland, Turkey
associate partners— {7) Bulgaria, Estonia, Latvia, Lithuania, Romania, Slovakia, Slovenia
observers— (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International Development Association
(IDA), and International Finance Corporation (IFC)
World Confederation of Labor (WCL)
established— June 1920 as the International
Federation of Christian Trade Unions (IFCTU),
renamed 4 October 1968
a/m— to promote the trade union movement
members— (101 national organizations) Antigua and Barbuda, Argentina, Aruba, Austria, Bangladesh, Belgium,
Belize, Benin, Bolivia, Bonaire island, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic,
Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba,
Cyprus, Czech Republic, Dominica, Dominican Republic, Ecuador, El Salvador, France, French Guiana, Gabon, The
Gambia, Ghana, Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, India,
Indonesia, Iran, Italy, Japan, Kazakhstan, South Korea, Liberia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malaysia, Malta, Martinique, Mauritania, Mauritius, Mexico,
Montserrat, Morocco, Namibia, Netherlands, Netherlands Antilles, Nicaragua, Niger, Pakistan, Panama, Paraguay,
Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Lucia, Saint Vincent and the Grenadines,
SaoTome and Principe, Senegal, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Switzerland,
Taiwan, Thailand, Togo, Trinidad and Tobago, Ukraine, US, Uruguay, Venezuela, Vietnam, Windward Islands,
Zambia, Zimbabwe
World Federation of Trade Unions (WFTU)
established— 3 October 1945
a/m— to promote the trade union movement
members— (125 and the Palestine Liberation Organization) Afghanistan, Albania, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada, Chile, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia,
Iran, Iraq, Jamaica, Japan, Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia,
NZ, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Puerto Rico,
Reunion, Romania, Russia, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Saudi
Arabia, Senegal, Sierra Leone, Slovakia, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Program (WFP)
members— {36) selected on a rotating basis from all regions
established— 2A November 1 961
a/m— to provide food aid in support of economic
development or disaster relief; an ECOSOC
organization
607
Appendix B: International Organizations and Groups (continued)
World Health Organization (WHO) members— (191 ) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
established— 22 July 1 946 Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
effective— 7 April 1948 Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
a/m— to deal with health matters worldwide; Democratic Republic of fhe Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
a UN specialized agency Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niue, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
associate members— (2) Puerto Rico, Tokelau
observers— {2} Holy See, Liechtenstein _ _
members— (177) Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea. Guinea-Bissau,
Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
members— (185) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, British Caribbean Territories, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea. Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe _ _ _ _
World Intellectual Property Organization
(WIPO)
esfab/ished— 14 July 1 967
effective— 26 April 1970
a/m— to furnish protection for literary, artistic,
and scientific works; a UN specialized agency
World Meteorological Organization (WMO)
established— 11 October 1947
e/fecf/Ve-4 April 1951
a/m— to sponsor meteorological cooperation;
a UN specialized agency
608
Appendix B: International Organizations and Groups (continued)
World Tourism Organization (WToO)
established— 2 January 1975
a/m— to promote tourism as a means of
contributing to economic development,
international understanding, and peace
World Trade Organization (WTrO)
note— succeeded General Agreement on Tariff
and Trade (GATT)
established— AprW 1994
effective— 1 January 1995
a/m— to provide a means to resolve trade
conflicts between members and to carry on
negotiations with the goal of further lowering
and/or eliminating tariffs and other trade barriers
Zangger Committee (ZC)
established— ear\\y 1970s
a/m— to establish guidelines for the export
control provisions of the Nonproliferation of
Nuclear Weapons Treaty (NPT)
members— (135) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Austria, Bangladesh, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Hungary, India, Indonesia, Iran, Iraq,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Lebanon, Lesotho, Libya, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, Nicaragua, Niger, Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania,
Russia, Rwanda, San Marino, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Switzerland, Syria, Tanzania, Thailand, Togo, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members— (6) Aruba, Flanders, Hong Kong, Macau, Madeira islands, Netherlands Antilles
observers— (2) Holy See, Palestine Liberation Organization
members— (140) Albania, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cameroon, Canada, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait,
Kyrgyzstan, Latvia, Lesotho, Liechtenstein, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Mongolia, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Suriname,
Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE,
UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
observers— (34) Algeria, Andorra, Armenia, Azerbaijan, The Bahamas, Belarus, Bhutan, Bosnia and Herzegovina,
Cambodia, Cape Verde, China, Ethiopia, The Former Yugoslav Republic of Macedonia, Holy See, Kazakhstan,
Laos, Lebanon, Lithuania, Moldova, Nepal, Russia, Samoa, Sao Tome and Principe, Saudi Arabia, Seychelles,
Sudan, Taiwan, Tonga, Ukraine, Uzbekistan, Vanuatu, Vietnam, Yemen, Yugoslavia; note— must start accession
negotiations within five years of becoming observers
members— (33) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, China, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, Norway,
Poland, Portugal, Romania, Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Ukraine, UK, US
609
Appendix C:
Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air Poiiution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur
Emissions or Their Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur
Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Volatile Organic Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature— ^ December 1959
entered into force— 23 June 1961
objective— {0 ensure that Antarctica is used for
peaceful purposes only (such as international
cooperation in scientific research): to defer the
question of territorial claims asserted by some
nations and not recognized by others; to provide
an international forum for management of the
region; applies to land and ice shelves south of
60 degrees South latitude
parties— (44) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech
Republic, Denmark, Ecuador, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy, Japan, North
Korea, South Korea, Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia,
South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay, Venezuela
Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
nofe—abbreviated as Hazardous Wastes
opened for signature— 22 March 1989
entered into force— 5 May 1 992
objective— to reduce transboundary movements
of wastes subject to the Convention to a
minimum consistent with the environmentally
sound and efficient management of such
wastes; to minimize the amount and toxicity of
wastes generated and ensure their
environmentally sound management as closely
as possible to the source of generation; and to
assist LDCs in environmentally sound
management of the hazardous and other wastes
they generate
part;es-(143) Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria,
Burkina Faso, Burundi, Cameroon, Canada, Cape Verde, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, EU, Finland, France, The Gambia, Georgia, Germany,
Greece, Guatemala, Guinea, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan,
Jordan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia,
GM
DE
DEU
276
.de
48 30 N
11 30 E
Beagle Channel
Atlantic Ocean
54 53S
68 low
Bear Island (see Bjornoya)
Svalbard
74 26N
19 05 E
Beaufort Sea
Arctic Ocean
73 00 N
140 00 W
Bechuanaland (former name for Botswana)
52 31 N
1324 E
Berlin, East (former name for eastern sector of Berlin}
52 30N
13 33E
Berlin, West (former name for western sector of Berlin)
52 30 N
12 20E
Bern (capital)
48 00 N
815E
Black Rock (island)
5044N
705 E
Bophuthatswana (enclave region)
900 E
Devils Island (lie du Diable)
53 44 N
7 25 E
East Germany (German Democratic Republic)
(former name for eastern portion of Germany)
52 00 N
13 00 E
East Korea Strait (Eastern Channel or Tsushima Strait)
Pacific Ocean
34 00 N
129 00 E
East Pakistan (former name for Bangladesh)
52 00 N
13 00 E
German Southwest Africa (former name for Namibia)
51 00 N
900 E
Gibraltar (city, peninsula)
49 25 N
7 00E
Saaremaa (island)
51 00 N
13 00E
Schleswig-Holstein (region)
54 31 N
9 33E
Schweiz (local German name for Switzerland)
48 46 N
911 E
Sucre (city)
Bolivia
19 02 8
6517W
Suez Canal
51 00 N
11 00 E
654
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Thurston Island
5322N
5 20E
West Island (capital)','28b01e38312145a38543be2b095acee9a9ad320af603d8e6fd0de7d82a3634c6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('575074dec9bcfadb627fc15e81fc35a35f4ba4d33f9eef674159d10b8254d61f',2001,'GH','Ghana','transnational-issues',492,'Background: Formed from the merger of the British
colony of the Gold Coast and the Togoland trust
territory, Ghana in 1957 became the first country in
colonial Africa to gain its independence. A long series
of coups resulted in the suspension of the constitution
in 1981 and the banning of political parties. A new
constitution, restoring multiparty politics, was
approved in 1992. Lt. Jerry RAWLINGS, head of state
since 1981, won presidential elections in 1992 and
1 996, but was constitutionally prevented from running
for a third term in 2000. He was succeeded by John
KUFUOR.
Disputes -international: none
Illicit drugs: illicit producer of cannabis for the
International drug trade; transit hub for Southwest and
Southeast Asian heroin and South American cocaine
destined for Europe and the US
GH
GH
GHA
288
.gh
5 33N
013W
Adamstown (capital)
Pitcairn Islands
2504S
130 05 W
Addis Ababa (capital)
8 00N
2 00W
Golfo San Jorge (gulf)
Atlantic Ocean
46 00 S
66 00 W
Golfo San Matias (gulf)
Atlantic Ocean
41 30 S
64 00 W
Good Hope, Cape of','fd421ffc2e3332b1b34462dc8e72c622907387b660c734a9d43ccb1936ba3345','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0059f03234e6816d46000a96aecb1ca67cd1c9e40513355f545117c8985daa5c',2001,'GI','Gibraltar','transnational-issues',500,'(overseas territory
of the UK)
Background: Strategically important, Gibraltar was
ceded to Great Britain by Spain in the 1713 Treaty of
Utrecht; the British garrison was formally declared a
colony in 1830. In a 1967 referendum, Gibraltarians
Ignored Spanish pressure and voted overwhelmingly
to remain a British dependency.
Disputes - International: source of friction between
Spain and the UK
Glorioso Islands
(possession of France)
Wreck
flocfr ,
He du Lys
reef / f /
,/ weather ^ \\
Zixstation
He I Vene
I ''i^ahsinp^lorieuse nocks
rod^^south"''
Rock
/
Indian Ocean
Disputes ■ international: claims and administers
Western Sahara, but sovereignty is unresolved and
the UN is attempting to hold a referendum on the
issue; the UN-administered cease-fire has been in
effect since September 1 991 ; Spain controls five
places of sovereignty (plazas de soberania) on and off
the coast of Morocco - the coastal enclaves of Ceuta
and Melilla which Morocco contests, as well as the
islands of Penon de AIhucemas, Penon de Velez de la
Gomera, and Islas Chafarinas
Illicit drugs; illicit producer of hashish; trafficking on
the increase for both domestic and international drug
markets; shipments of hashish mostly directed to
Western Europe; transit point for cocaine from South
America destined for Western Europe
349
Gl
Gl
GIB
292
•gi
Glorioso Islands
GO
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
3611 N
5 22W
Gibraltar, Strait of
Atlantic Ocean
35 57 N
5 36W
Gidi Pass','11a502326405f76cf130968f58f6dd64c47f18f8c9b24cb404fc46240cccd2b7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e992dc22081931a90448e458c1366f64948ccf3cd06fe8aab07064412bbb8d9',2001,'GR','Greece','transnational-issues',509,'Background: Greece achieved its independence
from the Ottoman Empire in 1829. During the second
half of the 1 9th century and the first half of the 20th
century, it gradually added neighboring islands and
territories with Greek-speaking populations. Following
the defeat of communist rebels in 1 949, Greece joined
NATO in 1952. A military dictatorship, which in 1967
suspended many political liberties and forced the king
to flee the country, lasted seven years. Democratic
elections in 1974 and a referendum created a
parliamentary republic and abolished the monarchy:
Greece joined the European Community or EC in
1981 (which became the EU in 1992).
Disputes - international: complex maritime, air, and
territorial disputes with Turkey in Aegean Sea; Cyprus
question with Turkey; dispute with The Former
Yugoslav Republic of Macedonia over its name
Illicit drugs: a gateway to Europe for traffickers
smuggling cannabis and heroin from the Middle East
and Southwest Asia to the West and precursor
chemicals to the East; some South American cocaine
transits or is consumed in Greece
GR
GR
GRC
300
•gr
38 00 N
25 00E
Aegean Sea
Atlantic Ocean
38 30N
25 00 E
Afars and Issas, French Territory of the (FTAI)
(former name for Djibouti)
37 45 N
24 42E
Andros Island
The Bahamas
24 26 N
77 57W
Anegada Passage
Atlantic Ocean
18 30N
63 40 W
Angkor Wat (ruins)
37 59N
23 44 E
Attu Island
3940N
19 45 E
Corinth (region)
37 56N
22 56 E
Corisco (island)
3515N
24 45 E
Crimea (region)
37 00 N
2510E
Cyrenaica (region)
36 00N
27 05 E
Dodoma (city)
Tanzania
611 S
35 45 E
Doha (capital)
39 00 N
22 00 E
Ellas (local name for Greece)
39 00 N
22 00 E
Ellef Ringnes Island
38 SON
20 30 E
Ionian Sea
Atlantic Ocean
38 SON
18 00 E
Irian Jaya (province)
38 22 N
26 04E
Khmer Republic (former name for Cambodia)
39 54N
25 21 E
Leningrad (see Saint Petersburg)
Russia
59 55N
3015E
Lesser Sunda Islands
3915N
2615E
Leyte (island)
37 05 N
25 30 E
N''Djamena (capital)
37 30 N
22 25 E
Pemba Island
Tanzania
7 31 S
39 25 E
Penang Island
36 ION
28 00 E
Rhodesia (region)
37 48N
26 44 E
San Ambrosio, Isla (island)','da0ee2f6b819db5cab177d44875fd4f43a81fe98b51f48cb561b919f0de91c32','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3148c1403e429bbd724f8cddcd0f3d38ccdf6c51c1383968884453fc5504d65f',2001,'GL','Greenland','transnational-issues',517,'(part of the Kingdom of Denmark)
Background: The world''s largest island, about 84%
ice-capped, Greenland was granted self-government
in 1978 by the Danish parliament. The law went into
effect the following year. Denmark continues to
exercise control of Greenland''s foreign affairs.
GL
GL
GRL
304
•gl
6411N
51 44 W
Golan Heights (region)
Syria
33 00 N
35 45 E
Gold Coast (former name for Ghana)
72 00 N
40 00 W
Kalahari (desert)
Botswana, Namibia
24 30S
21 00 E
Kalimantan (region)
6411 N
51 44 W
Nyasaland (former name for Malawi)
(DEMMARK)
ARCTIC /OCEAN
Longyearb
Q-reenlaad 5ea
^Svalbard
(MORWAY)
y Da\\''i5
/ 5trait
Labrador
Sea
Island of
wfoundland
^uuk (GodthSbl;^^
NORTH
ATLANTIC
OCEAN
S^ELAMP ,
Reykjavik
Jan Mayen I Norwe(^Un
(NORWAY)
I 5ea
I
I TORWAVi
Murmansk
Faroe
Islands
Torshavn*^ (dem.)
> SWEDEI^
l^fStockholm^
jniTED North
Celtic
\\ St. Petersburg
\\ Yarosla
mi
* : C -f: ''Vi SLOi
TTOrt
.uxeml ''■’'''''''''' U K R*A 1 n E ‘ki
iyl^na*TOj^tf<^1av»vw
"T^AUSnu^ * Budapest
|ubliaM#^uriQAwy
sS;;Jdii§inau','c90a7dc72da8dec5fb5c6ee421a857acf6ed434325a7869905cac40645715ac5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b3cc5a9765fef310da8fbdcf6b5319fa9d3d135e6d2dd02f7946595b885735d',2001,'GD','Grenada','transnational-issues',524,'Background: One of the smallest independent
countries in the western hemisphere, Grenada was
seized by a Marxist military council on 19 October
1983. Six days later the island was invaded by US
forces and those of six other Caribbean nations, which
quickly captured the ringleaders and their hundreds of
Cuban advisers. Free elections were reinstituted the
following year.
Disputes - international: none
Illicit drugs: small-scale cannabis cultivation; lesser
transshipment point for marijuana and cocaine to US
Disputes - international: none
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe
436
GJ
GD
GRD
308
•gd
12 07N
61 40 W
Grytviken (South Georgia) (town)
12 03N
61 45 W
Saint George''s Channel
Atlantic Ocean
52 00 N
6 00W
Saint Helens, Mount (volcano)
12 20N
61 SOW
Southern Rhodesia (former name for Zimbabwe)','f443203baa760dc86a928ef3105f745896c6d79b2c09ebde9c9f92c95d54bd8c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cc2a882f9b462cb8ea0842149f9709a6a3a998d2d26aa39f3069212e379d463',2001,'GU','Guam','transnational-issues',534,'(territory of the US)
Disputes - international: none
GQ
GU
GUM
316
.gu
13 28N
144 45 E
Ajaccio (city)
France (Corsica)
41 55 N
8 44E
Ajaria (region)
13 28N
144 45 E
Hague, The (seat of government)','ef9b741ed67d8af116714b67cba6cbe4cb4133635663f10ff147aec37fcf740a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f965eabfea7620d83f6f07a6d40ff4088e4502a8c9223c3a9e4ab0cfea02b319',2001,'GT','Guatemala','transnational-issues',542,'Background: Guatemala was freed of Spanish
colonial rule in 1821 . During the second half of the
20th century, it experienced a variety of military and
civilian governments as well as a 36‘year guerrilla
war. In 1996, the government signed a peace
agreement formally ending the conflict, which had led
to the death of more than 100,000 people and had
created some 1 million refugees.
Disputes " international: Guatemala periodically
asserts claims to territory in southern Belize; to deter
cross-border squatting, both states in 2000 agreed to
a "line of adjacency" based on the de facto boundary,
which is not recognized by Guatemala
Illicit drugs: transit country for cocaine and heroin;
minor producer of illicit opium poppy and cannabis for
the international drug trade; proximity to Mexico
makes Guatemala a major staging area for drugs
(cocaine and heroin shipments); money laundering is
probably increasing
GT
GT
GTM
320
•gt
14 38N
90 31 W
Guinea Ecuatorial (local name for Equatorial Guinea)','de1414552f7572522958deb357ff6ff4886f2dd8e4d65953be1ee76f1c3a2d73','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9021210513feed9f62fcef78056b68f7613e3cad96f8b856493a39079d6202c',2001,'GG','Guernsey','transnational-issues',550,'(British crown dependency)
Background: The island of Guernsey and the other
Channel Islands represent the last remnants of the
medieval Dukedom of Normandy, which held sway in
both France and England. The islands were the only
British soil occupied by German troops in World War II.
Disputes - International: none
GK
—
—
—
•gg
ISO includes with the United Kingdom
620
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
49 43 N
212W
Aleutian Islands
United States (Alaska)
52 00 N
176 00 W
Alexander Archipelago (island group)
United States (Alaska)
57 DON
134 00 W
Alexander Island
49 27N
232W
Saint Petersburg (city; former capital)
Russia
59 55 N
3015E
Saint Thomas (island)
Virgin Islands
18 21 N
64 55 W
Saint Vincent Passage
Atlantic Ocean
13 30N
61 00 W
Saint-Denis (capital)
Reunion
2052S
5528E
Saint-Martin (Sint Maarten) (island)
49 26 N
2 21 W
651
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Savage Island (former name for Niue)','542b2a8e4279690109d3619dae7fa349895aa597c073c23bf63bad08bbdf8f16','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5198944a806437205329c8b8b0037ecb16a2a59aa70e8e2af22f920a2bf45e34',2001,'GW','Guinea-Bissau','transnational-issues',557,'I
Economic aid ■ recipient: $359.2 million (1998)
Currency: Guinean franc (GNF)
Currency code: GNF
Exchange rates: Guinean francs per US dollar -
1 ,855.0 (October 2000), 1 ,572.0 (2000), 1 ,387.4
(1999), 1,236.8 (1998), 1,095.3 (1997), 1,004.0
(1996)
Fiscal year: calendar year
PU
GW
GNB
624
.gw
11 25N
16 20W
Bikini Atoll
11 51 N
15 35W
Bjornoya (Bear Island)
Svalbard
74 26 N
1905E
Black Forest (region)
12 00N
15 00W
Guinee (local name for Guinea)
12 00N
15 00W
Portuguese Timor (former name for East Timor)','7e92831e5ae38c9dae50f09cb1abf964dabf9d341fd78644fc8d898cbf549ee9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdffc0c7fb009efc0711690077dd6c81aa070a417a9dd62f1691e4b1ad3221da',2001,'GY','Guyana','transnational-issues',568,'Disputes - international: all of the area west of the
Essequibo (river) claimed by Venezuela; Suriname
claims area between New (Upper Courantyne) and
Courantyne/Kutari [Koetari] rivers (all headwaters of
the Courantyne)
Illicit drugs: transshipment point for narcotics from
South America - primariiy Venezuela - to Europe and
the US; producer of cannabis
Disputes - international: area disputed by French
Guiana between Riviere Litani and Riviere Marouini
(both headwaters of the Lawa); area disputed by
Guyana between New (Upper Courantyne) and
Courantyne/Koetari [Kutari] rivers (all headwaters of
the Courantyne)
Illicit drugs: transshipment point for South American
drugs destined for Europe and Brazil; transshipment
point for arm s-for-d rugs dealing
Svalbard
(territory of Norway)
Background: First discovered by the Norwegians in
the 12th century, the islands served as an
international whaling base during the 17th and 18th
centuries. Norway''s sovereignty was recognized in
1 920; five years later it officially took over the territory.
Disputes - international: focus of a maritime
boundary dispute between Norway and Russia
480
Swaziland
Background: Autonomy for the Swazis of southern
Africa was guaranteed by the British in the late 19th
century; independence was granted 1968. Student
and labor unrest during the 1 990s have pressured the
monarchy (one of the oldest on the continent) to
grudgingly allow political reform and greater
democracy.
GY
GY
GUY
328
•gy
500N
59 00W
British Honduras (former name for Belize)
659 N
58 23 W
Etorofu (Iturup) (island)
Russia (de facto)
44 55 N
147 40 E
F
Farquhar Group (Atoll de Farquhar) (island group)
648N
58 low
Georgetown (city)
The Gambia
13 SON
1447W
German Democratic Republic (East Germany)
(former name for eastern portion of Germany)
GUIANA H I G TA/ U j^)','177431f2bfc6ec2f0cc85bcc718d4f92cd26da5e8d8ae5ce5b6a9c5d2a9c49ff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60ab7d469b5cb7ad0656bf54b06afd1c0ce60eb6a4b7f59543a7b8978ef9442d',2001,'HK','Hong Kong','transnational-issues',571,'(special administrative
region of China)
Background: Occupied by the UK in 1 841 , Hong
Kong was formally ceded by China the following year;
various adjacent lands were added later in the 19th
century. Pursuant to an agreement signed by China
and the UK on 19 December 1984, Hong Kong
became the Hong Kong Special Administrative
Region (SAR) of China on 1 July 1997. In this
agreement, China has promised that, under its "one
country, two systems" formula, China''s socialist
economic system will not be practiced in Hong Kong
and that Hong Kong will enjoy a high degree of
autonomy in all matters except foreign and defense
affairs for the next 50 years.
HK
HK
HKG
344
.hk
Howland Island
HQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
2215N
11410E
Honiara (capital)
2218N
114 10E
Kra, Isthmus of
Burma, Thailand
1020 N
99 00 E
Krakatoa (volcano)
2215N
11355E
Lao (local name for Laos)
Laos
18 00N
105 00 E
Laptev Sea
Arctic Ocean
76 00N
126 00 E
Las Palmas (city)
Spain (Canary Islands)
28 06N
15 24W
Latakia (region)
Syria
36 DON
35 50 E
Latvija (local name for Latvia)
22 24 N
11410E
Newfoundland (island, with mainland area, and a province)
2217N
11409 E
Victoria (island)
2215N
11410E
Y
Y’israel (local name for Israel)','f9eff593083852f45c1fd8824e954138cab0537d366b543badc919417508ea1e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8582558e97a80b89d7059f80d206c577b421f3a18272e84c4a061c75691b1b02',2001,'AT','Austria','transnational-issues',588,'Disputes - international: Rockall continental shelf
dispute involving Denmark and the UK (Ireland and
the UK have signed a boundary agreement in the
Rockall area); dispute with Denmark over the Faroe
Islands fisheries median line boundary within 200 NM;
disputes with Denmark, the UK, and Ireland over the
Faroe Islands continental shelf boundary outside
200 NM
Arphinn
Marmagao’
\\ r-% I jChsnnsi Bor^^nl And^msn
\\ Bangalore i(Madras) " (
Vcalicut Pondicherry
^ Cochin^ .Mailurai
Juticorin sni
7, .Alanka
Port Biair^^
Nicobar •
Islands
Disputes - international: boundary with China in
dispute; status of Kashmir with Pakistan;
water-sharing problems with Pakistan over the Indus
River (Wular Barrage): a portion of the boundary with
Bangladesh is indefinite; exchange of 151 enclaves
along border with Bangladesh subject to ratification by
Indian parliament; dispute with Bangladesh over New
Moore/South Talpatty Island
Illicit drugs: world''s largest producer of licit opium
for the pharmaceutical trade, but an undetermined
quantity of opium is diverted to illicit international drug
markets; transit country for illicit narcotics produced in
neighboring countries; illicit producer of hashish and
methaqualone
Indian Ocean
Disputes - international: some maritime disputes
(see littoral states)
236
Background: The world''s largest archipelago,
Indonesia achieved independence from the
Netherlands in 1949. Current issues include:
implementing IMF-mandated reforms of the banking
sector, effecting a transition to a popularly elected
government after four decades of authoritarianism,
addressing charges of cronyism and corruption,
holding the military accountable for human rights
violations, and resolving growing separatist pressures
in Aceh and Irian Jaya. On 30 August 1999 a
provincial referendum for independence was
overwhelmingly approved by the people of Timor
Timur. Concurrence followed by Indonesia''s national
legislature, and the name East Timor was
provisionally adopted. The independent status of East
Timor • now under UN administration - has yet to be
formally established.
Disputes - international: Sipadan and Ligitan
Islands in dispute with Malaysia
Illicit drugs: illicit producer of cannabis largely for
domestic use; possible growing role as transshipment
point for Golden Triangle heroin
’ Mashhad
TEHRAN. ^Oolleh-ye Damavand
,Qom
’Kermanshah
SAUDI
\\ G''.il-
w "
I 0 100 200 km U
Dezful ,Esfahan
Yazd
^Ahvaz •
Bandar-e Emam KhomeynT
iBadan Shiraz *Kerman
^ o- Zahedatf"
V ■. «Bushehr
V.....
Disputes - international: Iran and Iraq restored
diplomatic relations in 1 990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab
waterway; Iran occupies two islands in the Persian
Gulf claimed by the UAE: Lesser Tunb (called Tunb as
Sughra in Arabic by UAE and Jazireh-ye Tonb-e
Kuchek in Persian by Iran) and Greater Tunb (called
Tunb al Kubra in Arabic by UAE and Jazireh-ye
Tonb-e Bozorg in Persian by Iran); Iran jointly
administers with the UAE an island in the Persian Gulf
claimed by the UAE (called Abu Musa in Arabic by
UAE and Jazireh-ye Abu Musa in Persian by Iran) -
over which Iran has taken steps to exert unilateral
control since 1992, including access restrictions and a
military build-up on the island; the UAE has garnered
significant diplomatic support in the region in
protesting these Iranian actions; Caspian Sea
boundaries are not yet determined among Azerbaijan,
Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: despite substantial interdiction efforts,
Iran remains a key transshipment point for Southwest
Asian heroin to Europe; domestic consumption of
narcotics remains a persistent problem and Iranian
press reports estimate that there are at least 1 .2
million drug users in the country
Iraq MiMBiB
Background: Formerly part of the Ottoman Empire,
Iraq became an independent kingdom in 1932. A
"republic" was proclaimed in 1958, but in actuality a
series of military strongmen have ruled the country
since then, the latest being SADDAM Husayn.
Territorial disputes with Iran led to an inconclusive
and costly eight-year war (1980-1988). In August
1 990 Iraq seized Kuwait, but was expelled by US-led,
UN coalition forces during January-February 1 991 .
The victors did not occupy Iraq, however, thus
allowing the regime to stay in control. Following
Kuwait''s liberation, the UN Security Council (UNSC)
required Iraq to scrap all weapons of mass
destruction and long-range missiles and to allow UN
verification inspections. UN trade sanctions remain in
effect due to incomplete Iraqi compliance with
relevant UNSC resolutions.
Disputes - international: Iran and Iraq restored
diplomatic relations in 1990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab
waterway; in November 1994, Iraq formally accepted
the UN-demarcated border with Kuwait which had
been spelled out in Security Council Resolutions 687
(1 991 ), 773 (1 993), and 883 (1 993); this formally ends
earlier claims to Kuwait and to Bubiyan and Warbah
islands although the government continues periodic
rhetorical challenges; dispute over water development
plans by Turkey for the Tigris and Euphrates rivers
244
AU
AT
AUT
040
.at
47 20 N
1320E
Ogaden (region)
Ethiopia, Somalia
7 00N
46 00 E
Oil Islands (Chagos Archipelago)
47 48 N
13 02 E
Samar (island)
4812N
16 22E
Vientiane (capital)
Laos
17 58N
102 36 E
Vilnius (capital)','d32a2e0bc18a9b62cedd0ba6726cb02ed4b99fc739dbaa754ce931609ab6cf58','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bad11449d3be9bf7e5f451e2ef34ac9e215b1f57c43f1d7b14f5eabdcb8003f',2001,'IE','Ireland','transnational-issues',591,'Background: A failed 1916 Easter Monday
Rebellion touched off several years of guerrilla
warfare that in 1921 resulted in independence from
the UK for the 26 southern counties; the six northern
counties (Ulster) remained part of Great Britain. In
1948 Ireland withdrew from the British
Commonwealth; it joined the European Community in
1973. Irish governments have sought the peaceful
unification of Ireland and have cooperated with Britain
against terrorist groups. A peace settlement for
Northern Ireland, approved in 1998, was implemented
the following year.
Disputes - international: Northern Ireland issue
with the UK (historic peace agreement signed 1 0 April
1998); disputes with Iceland, Denmark, and the UK
over the Faroe Islands continental shelf boundary
outside 200 NM
Illicit drugs: transshipment point for and consumer
of hashish from North Africa to the UK and
Netherlands and of European-produced synthetic
drugs; minor transshipment point for heroin and
cocaine destined for Western Europe
El
IE
IRL
372
.ie
53 20 N
615W
Dushanbe (capital)
53 00 N
8 00W
Elba (island)','c8ef542b5fe77d138ff1ec615a9947ffb8aa13810cae48ef91c1c671f88a4b56','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8704cff7f15fd62f28997fd360122e2c6a95d1680b13305a0b0e75549447645d',2001,'IL','Israel','transnational-issues',599,'(also see separate Gaza Strip
and West Bank entries)
I ^
Background: Following World War II, the British
withdrew from their mandate of Palestine, and the
UN partitioned the area into Arab and Jewish states,
an arrangement rejected by the Arabs.
Subsequently, the Israelis defeated the Arabs in a
series of wars without ending the deep tensions
between the two sides. The territories occupied by
Israel since the 1967 war are not included in the
Israel country profile, unless otherwise noted. In
keeping with the framework established at the
Madrid Conference in October 1991, bilateral
negotiations are being conducted between Israel and
Palestinian representatives (from the
Israeli-occupied West Bank and Gaza Strip) and
Israel and Syria, to achieve a permanent settlement.
On 25 April 1982, Israel withdrew from the Sinai
pursuant to the 1979 Israel-Egypt Peace Treaty.
Outstanding territorial and other disputes with Jordan
were resolved in the 26 October 1994 Israel-Jordan
Treaty of Peace. On 25 May 2000, Israel withdrew
unilaterally from southern Lebanon, which it had
occupied since 1982.
Disputes - International: West Bankand Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation;
Golan Heights is Israeli-occupied (Lebanon claims the
Shab''a Farms area of Golan Heights)
Illicit drugs: increasingly concerned about cocaine
and heroin abuse; drugs arrive in country from
Lebanon and increasingly Jordan
249
* iWITZERLAND^
IS
IL
ISR
376
.il
32 54N
35 20E
Galleons Passage
Atlantic Ocean
11 00 N
60 55W
Gambler Islands (lies Gambler)
32 50 N
35 00 E
Hainan Dao (island)
30 30 N
34 55 E
Negros (island)
32 05 N
34 48 E
Teluk Bone (gulf)
Pacific Ocean
400S
120 45 E
Teluk Tomini (gulf)
Pacific Ocean
0 30S
121 00 E
Terre Adelie (Adelie Land) (claimed by France)
32 48 N
35 35 E
Tibet (Xizang) (province)
31 SON
34 45 E
Yaitopya (local name for Ethiopia)','e03e28778d47102b6eb3ccb28ede5f86041787a5df4b0b0e2c54077ff6ea2827','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f506ca1dca8cfc2879e118fb3fb5264a25ead02d652ac1e3aca322b58bedb75',2001,'HU','Hungary','transnational-issues',607,'J-hii)ubc-A
V TriesteX
CROATIA V
.Turin Ravenna Wenio^''^.
?Genoa BolognaX r V BOSNIA |
^ Hsan V K and
Wspeza^ .r i
/ \\ Livorno\\ Florence v ^ A
"^’''MONACO . iPiombino \\ r
Corsica f'' ■ ^'' \\ rom^
(FRANCE)/, / VAriCAN.® ^ ^
Porto i ''^v-.Gaeta ^\\,Bari ALte.
Jorre fy \\ •• , \\,Naples '' f
\\sarLa " I
Oristandf 1 ^ , . \\ C c
/ I Tyrrhrninn V
i.^Cagliari «''''■'' . \\ J
Sicily di Calabria
V. -'''' ''-t. ..- \\ Augusta^ 0 100 km
ALG. ef Tunisia'' y _ 0 '' ‘ ‘ loomi
Disputes - international: Gabcikovo/Nagymaros
Dam dispute with Hungary is before the ICJ
Illicit drugs: transshipment point for Southwest
Asian heroin bound for Western Europe
456
HU
HU
HUN
348
.hu
47 30N
19 05 E
Buenos Aires (capital)
47 00N
20 00 E
Mahe Island','103d9de811bd042d312c0b9d9f170697f137a85f31ff1146d2225ac5f9256fbc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01674c0982acb2a57438af5fb2e7aa64695629b84bd07668a52392450f221ffd',2001,'TN','Tunisia','transnational-issues',615,'Disputes - international: Croatia and Italy made
progress toward resolving a bilateral issue dating from
World War II over property and ethnic minority rights
Illicit drugs: important gateway for and consumer of
Latin American cocaine and Southwest Asian heroin
entering the European market
252
Disputes - Internationai: claimed by Madagascar
and Mauritius
Background: Following independence from France
in 1956, President Habib BOURGIUBA established a
strict one-party state. He dominated the country for 31
years, repressing Islamic fundamentalism and
establishing rights for women unmatched by any other
Arab nation. In recent years, Tunisia has taken a
moderate, non-aligned stance in its foreign relations.
Domestically, it has sought to diffuse rising pressure
for a more open political society.
Disputes - international; none
509
o
Turkey
Disputes - international: complex maritime, air, and
territorial disputes with Greece in Aegean Sea;
Cyprus question with Greece; dispute with
downstream riparian states (Syria and Iraq) over
water development plans for the Tigris and Euphrates
rivers; traditional demands regarding former
Armenian lands in Turkey have subsided
Illicit drugs: key transit route for Southwest Asian
heroin to Western Europe and - to a far lesser extent
the US - via air, land, and sea routes; major Turkish,
Iranian, and other international trafficking
organizations operate out of Istanbul; laboratories to
convert imported morphine base into heroin are in
remote regions of Turkey as well as near Istanbul;
government maintains strict controls over areas of
legal opium poppy cultivation and output of poppy
straw concentrate
512
Introduction Natural resources: petroleum, natural gas, coal,
sulfur, salt
Background: Annexed by Russia between 1 865 and [.and use:
1 885, T urkmenistan became a Soviet republic in Qrable land: 3%
1 925. It achieved its independence upon the permanent crops: 0%
dissolution of the USSR in 1 991 . President NIYAZOV permanent pastures: 63%
retains absolute control over the country and forests and woodland: 8%
opposition is not tolerated. Extensive hydrocarbon/ Qfper: 26% (1 993 est.)
natural gas reserves could prove a boon to this Irrigated land: 1 3,000 sq km (1 993 est.)
underdeveloped country if extraction and delivery Natural hazards: NA
projects can be worked out. Environment - current issues: contamination of
Disputes - international: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivator of opium poppy,
mostly for domestic consumption; limited government
eradication program; increasingly used as
transshipment point for illicit drugs from Southwest Asia
to Russia and Western Europe; also a transshipment
point for acetic anhydride destined for Afghanistan
Turks and
Caicos Islands
{overseas territory
of the UK)
Background: The islands were part of the UK''s
Jamaican colony until 1 962, when they assumed the
status of a separate crown colony upon Jamaica''s
independence. The governor of The Bahamas
oversaw affairs from 1965 to 1973. With Bahamian
independence, the islands received a separate
governor in 1973. Although independence was
agreed upon for 1 982, the policy was reversed and the
islands are presently a British overseas territory.
Disputes - international: none
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe
516
Convention on Long-Range Transboundary
Air Pollution
note— abbreviated as Air Pollution
opened for signature— ^3 November 1979
entered into force— 16 March 1983
objective— {0 protect the human environment
against air pollution and to gradually reduce and
prevent air pollution, including long-range
transboundary air pollution
parties— (48) Armenia, Austria, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Yugoslavia
countries that have signed, but not yet ratified— (2) Holy See, San Marino
Convention on the Conservation of Antarctic
Marine Living Resources
nofe-^bbreviated as Antarctic-Marine Living
Resources
opened for signature—
entered into force— NA
objective— HA
parties— (30) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, EU, Finland, France, Germany, Greece,
India, Italy, Japan, South Korea, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain,
Sweden, Ukraine, UK, US, Uruguay
611
Appendix C: Selected International Environmental Agreements (continued)
Convention on the Internationa! Trade In
Endangered Species of Wild Flora and Fauna
(CITES)
nofe-abbreviated as Endangered Species
openei^ for signature— 3 March 1973
entere(j into force— 1 July 1975
objective— io protect certain endangered
species from overexploitation by means of a
system of import/export permits
parties-{^52) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemaia, Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Latvia, Liberia, Liechtenstein,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (3) Ireland, Kuwait, Lesotho
Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other
Matter (London Convention)
/lote^bbreviated as Marine Dumping
opene(j for signature— 29 December 1972
entered into force— 30 August 1975
objective— {0 control pollution of the sea by
dumping and to encourage regional agreements
supplementary to the Convention
parties— {78) Afghanistan, Antigua and Barbuda, Argentina, Australia, Azerbaijan, Barbados, Belarus, Belgium,
Brazil, Canada, Cape Verde, Chile, China, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Denmark, Dominican Republic, Egypt, Finland, France, Gabon, Germany, Greece, Guatemala, Haiti,
Honduras, Hong Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kenya,
Kiribati, South Korea, Libya, Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Philippines, Poland, Portugal, Russia, Saint Lucia,
Seychelles, Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tonga, Tunisia,
Ukraine, UAE, UK, US, Vanuatu, Yugoslavia
Convention on the Prohibition of Military or
Any Other Hostile Use of Environmental
Modification Techniques
nofe— abbreviated as Environmental
Modification
opened for signature— 10 December 1976
entered into force— 6 October 1978
objective— prohibit the military or other hostile
use of environmental modification techniques in
order to further world peace and trust among
nations
parties— {88) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Bangladesh, Belarus,
Belgium, Benin, Brazil, Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark,
Dominica, Egypt, Finland, Germany, Ghana, Greece, Guatemala, Hungary, Iceland, India, Ireland, Italy, Japan,
North Korea, South Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway, Pakistan,
Papua New Guinea, Poland, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Sierra Leone, Slovakia, Solomon Islands, Spain, Sri Lanka, Sweden, Switzerland, Tajikistan, Tunisia,
Ukraine, UK, US, Uruguay, Uzbekistan, Vietnam, Yemen
countries that have signed, but not yet ratified— {t 5) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy See,
Iran, Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Syria, Turkey, Uganda
Convention on Wetlands of International
Importance Especially as Waterfowl Habitat
(Ramsar)
note— abbreviated as Wetlands
opened for signature— 2 February 1971
entered into force— 21 December 1975
objective— (0 stem the progressive
encroachment on and loss of wetlands now and
in the future, recognizing the fundamental
ecological functions of wetlands and their
economic, cultural, scientific, and recreational
value
parties— (123) Albania, Algeria, Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Canada, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire,
Croatia, Czech Republic, Denmark, Ecuador, Egypt, El Salvador, Estonia, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Latvia, Lebanon, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mexico, Moldova, Monaco, Mongolia, Morocco, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Russia, Senegal, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname,
Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK,
US, Uruguay, Venezuela, Vietnam, Yugoslavia, Zambia
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and/or
Desertification, Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
612
Appendix C: Selected International Environmental Agreements (continued)
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposai
International Convention for the Regulation
of Whaling
nofe-^abbreviated as Whaling
opened for signature— 2 December 1946
entered Into force— 10 November 1948
objective— {0 protect all species of whales from
overhunting; to establish a system of
international regulation for the whale fisheries to
ensure proper conservation and development of
whale stocks; and to safeguard for future
generations the great natural resources
represented by whale stocks
part/es— (41) Antigua and Barbuda, Argentina, Australia, Austria, Brazil, Chile, China, Costa Rica, Denmark,
Dominica, Finland, France, Germany, Grenada, Guinea, India, Ireland, Italy, Japan, Kenya, South Korea, Mexico,
Monaco, Morocco, Netherlands, NZ, Norway, Oman, Peru, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Senegal, Solomon Islands, South Africa, Spain, Sweden, Switzerland, UK, US
Internationa! Tropical Timber Agreement,
1983
nofe— abbreviated as Tropical Timber 83
opened for signature— IS November 1983
entered into force— 1 April 1985; this agreement
expired when the International Tropical Timber
Agreement, 1994, went into force
objective— provide an effective framework for
cooperation between tropical timber producers
and consumers and to encourage the
development of national policies aimed at
sustainable utilization and conservation of
tropical forests and their genetic resources
parties— (5A) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cameroon, Canada, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland, France,
Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Russia, Spain, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
International Tropical Timber Agreement,
1994
note— abbreviated as Tropical Timber 94
opened for signature— 26 January 1 994
entered into force— 1 January 1997
objective— {0 ensure that by the year 2000
exports of tropical timber originate from
sustainably managed sources; to establish a
fund to assist tropical timber producers in
obtaining the resources necessary to reach this
objective
parties-{5B) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African
Republic, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark,
Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia,
Ireland, Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua
New Guinea, Peru, Philippines, Portugal, Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and
Tobago, UK, US, Uruguay, Vanuatu, Venezuela
countries that have signed, but not yet ratified— {t ) 1 reland
Kyoto Protocol to the United Nations
Framework Convention on Climate Change
note— abbreviated as Climate Change-Kyoto
Protocol
opened for signature— 16 March 1998, but not
yet in force
objective— io further reduce greenhouse gas
emissions by enhancing the national programs
of developed countries aimed at this goal and by
establishing percentage reduction targets for the
developed countries
parties— (32) Antigua and Barbuda, Azerbaijan, The Bahamas, Barbados, Bolivia, Cyprus, Ecuador, El Salvador,
Equatorial Guinea, Fiji, Georgia, Guatemala, Guinea, Honduras, Jamaica, Kiribati, Lesotho, Maldives, Mexico,
Federated States of Micronesia, Mongolia, Nicaragua, Niue, Palau, Panama, Paraguay, Samoa, Trinidad and
Tobago, Turkmenistan, Tuvalu, Uruguay, Uzbekistan
countries that have signed, but not yet ratified— (64) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada,
Chile, China, Cook Islands, Costa Rica, Croatia, Cuba, Czech Republic, Denmark, Egypt, Estonia, EU, Finland,
France, Germany, Greece, Indonesia, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia, Liechtenstein,
Lithuania, Luxembourg, Malaysia, Mali, Malta, Marshall Islands, Monaco, Netherlands, NZ, Niger, Norway, Papua
New Guinea, Peru, Philippines, Poland, Portugal, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines,
Seychelles, Slovakia, Slovenia, Solomon Islands, Spain, Sweden, Switzerland, Thailand, Ukraine, UK, US, Vietnam,
TS
TN
TUN
788
.tn
Turkey
TU
TR
TUR
792
.tr
36 48 N
1011 E
Turin (city)','f189792cc0b29911fdd4776e1f52481f374981df97963be9874bd730c7f94418','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08fb1b3b41e37b108a99c7f1d13d4d2976780e3fa390f83098cc7bc33c481ca8',2001,'JM','Jamaica','transnational-issues',624,'Disputes - international: none
Illicit drugs: major transshipment point for cocaine
from South America to North America and Europe;
illicit cultivation of cannabis; government has an active
manual cannabis eradication program; corruption is a
major concern
Jan Mayen
(territory of Norway)
Background: This desolate, mountainous island was
named after a Dutch whaling captain who indisputably
discovered it in 1614 (earlier claims are inconclusive).
Visited only occasionally by seal hunters and trappers
over the following centuries, the island came under
Norwegian sovereignty in 1929. The long dormant
Beerenberg volcano resumed activity in 1970; it is the
northernmost active volcano on earth.
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: dominated by the volcano Haakon
VII Toppen/Beerenberg; volcanic activity resumed in
1970
Environment - current issues: NA
Geography - note: barren volcanic island with some
moss and grass
JM
JM
JAM
388
.jm
Jan Mayen
JN
—
—
—
_
ISO includes with Svalbard
18 00 N
76 48 W
Kingston (capital)
"ta>^a^J SannagoV-^
HAITI:) DOMmiCAI<
Rort-au-^^^I^^fes L/^ '' A
AI<F:1^ “n''l’s- • . .
1C X Mona- _ (U.K.)^^ AnguitftTlOJfe)^ • ''
"r"
Domingo isia ^ ^ ^riEThl ^ ''^ '' ”
Mona Puerto Rico St. Croix ArfTIdUAANp&fil^i ,
• . ru^ > ^ ''■ . ^ '' Basseterre*w ^St. lohn^s • -''
?■ •„ ...= ,.''-^ -. ST KITTS AWn MF.VIS^ ^ ... " ''I ‘ '' t
ST. KITTS AMD MEVIS''^ ''
Plymouth ^
Montserrat(tJ.K.)
IslaAvcs
(VEMEZUELA) -
Evis^^ ^ ,..^c , ‘
''mouth ^
itserrat(tJ.K.) A QuadelOUp«. ,1.4''-. .-,
(rRAItCIW llo/r
Basse-Terre T ^Marle-Galante
DOMIMICANJ
Roseau^ !>;
^ Martinique
Fort-dc-France^
Barranquillarv..^ /> J V''c
^ W . ,ifr'' /y V
•tagena^^'' / y .'' A''Maracaibq^
,^J,!:J: , Mctherlands Antilles
(riETtl.) (hETH.)
Oranjestad CnriKao
^c c:. Bonaire
\\ r"- ^ ^ ■>
y ( \\ Willemstad
/s/a dc
Isla la Margarita
Torfugn ^
Caracas
ngstown ^
ST. VIMCENT AND
THE GRENADINES,*
y iyt0Mi5ij^>;
''''''‘'' ''caatemala^ / Tc^clgat^a
QUATE^U/_V-/V
Caribbejji
5ca
San SalvadbV','2efd179a33ff466510e59720c1fa2831a93949dfd23b2aea6429716541cb69d2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26141c49a06236eaaf31e5df2336a964f49337b58f36391b9764639124573dae',2001,'KZ','Kazakhstan','transnational-issues',653,'Disputes - International: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan
Illicit drugs: significant illicit cultivation of cannabis
and limited cultivation of opium poppy and ephedra
(for the drug ephedrone); limited government
eradication program; cannabis consumed largely in
the CIS; used as transshipment point for illicit drugs to
Russia, North America, and Western Europe from
Southwest Asia; developing heroin addiction problem
267
^^^^j^lsfara Valley
j Khujand
KZ
KZ
KAZ
398
.kz
51 ION
71 30 E
Aksai Chin (region)
China (de facto), India (claimed)
35 00N
79 00 E
A1 Arabiyah as Suudiyah (local name for Saudi Arabia)
4315N
76 57 E
Almaty (former capital)
4315N
76 57E
Alofi (capital)
51 ION
71 30 E
Asuncion (capital)
48 00 N
68 00 E
Keeling Islands
48 00 N
68 00 E
Qita Ghazzah (local name Gaza Strip)
Gaza Strip
31 25 N
3420E
Quebec (province)','8ee88d154ac9a2efb487079d270e1e98394b61dc191ed0247fedbd493dada684','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('157022c68de1ae201abe1df03623da222dd28360e140f98db32856b8942c5a2b',2001,'KE','Kenya','transnational-issues',662,'Disputes - international: administrative boundary
with Sudan does not coincide with international
boundary
Illicit drugs: widespread harvesting of small plots of
marijuana; transit country for South Asian heroin
destined for Europe and North America; Indian
methaqualone also transits on way to South Africa
KE
KE
KEN
404
.ke
Kingman Reef
KQ
—
—
—
—
ISO Includes with the US Minor
Outlying Islands
4 03S
3940E
Mona Passage
Atlantic Ocean
18 SON
6745W
Monaco (capital)
1 17S
36 49 E
Namib (desert)','c49566c1d6df981969a0479ee20b02a5a44fa25586c8382d78f03a46f2d3c2bd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e5470ce9cd13bce7bd46034348c345c18e283da8c80431dd51e4de522ab3f31',2001,'WS','Samoa','transnational-issues',669,'Disputes - international: none
Disputes - International: none
South Pacific Ocean
Disputes -international: none
438
ws
ws
WSM
882
.ws
1350S
171 44 N
Aqaba, Gulf of
Indian Ocean
29 00 N
34 30 E
Arab, Shaft al (river)
Iran, Iraq
29 57 N
48 34 E
Arabian Sea
Indian Ocean
15 00 N
65 00 E
Arafura Sea
Pacific Ocean
900 S
133 00 E
628
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Aral Sea
Kazakhstan, Uzbekistan
45 00 N
60 00E
Argun River
China, Russia
5320N
121 28 E
Aru Sea
Pacific Ocean
615S
135 00E
Ascension Island
Saint Helena
7 57S
14 22W
Ashgabat (capital)
1335S
172 20 W
Wetar Strait
Pacific Ocean
8 20S
126 30 E
White Sea
Arctic Ocean
65 SON
38 00 E
Wilkes Land (region)
. Walllsjand *2^ -A''
Putuna r.-^-
K I R I B AT I ''>
Cook
Islands
new ^ “
iedonia
•RAnCE)','eac5dd41b35428dab9c21ccd82d721b122c1dbf1a6449e50cd1e8166ef7142ff','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f6c3c771b16f7178ec0a9522d7845bc62e0d53dbfcfa2582d9b4687935892c9',2001,'KG','Kyrgyzstan','transnational-issues',678,'Disputes - International: territorial dispute with
Tajikistan on southwestern boundary in Isfara Valley
area; periodic target of Islamic insurgents from
Uzbekistan, Tajikistan, and Afghanistan
Illicit drugs: limited illicit cultivator of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; increasingly used
as transshipment point for illicit drugs to Russia and
Western Europe from Southwest Asia
Laos
Disputes - international: parts of the border with
Thailand are indefinite
Illicit drugs: world''s third-largest illicit opium
producer (estimated cultivation in 1999 - 21 ,800
hectares, a 16% decrease over 1998; estimated
potential production in 1999 - 140 metric tons, about
the same as in 1998); potential heroin producer;
transshipment point for heroin and methamphetamine
produced in Burma; illicit producer of cannabis
284
Murghob,
KG
KG
KGZ
417
.kg
Laos
LA
LA
LAO
418
.la
42 54 N
74 36E
Bishop Rock
42 54 N
74 36E
Funafuti (capital)
41 00 N
75 00 E
Kirgizia (former name for Kyrgyzstan)
41 00 N
7500E
Kirguizstan (local name for Kyrgyzstan)
41 00 N
75 00E
Kiritimati (Christmas Island)','592252a5ce3725d27f0d5245fce114d7c9e37a9d5068e8cf548b9473812df8a8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e1149a969af2c7767e8b1e8a21b01ad2a3cf0a491531bb74d57148a1b1901f0',2001,'LV','Latvia','transnational-issues',687,'Disputes - international: draft treaty delimiting the
boundary with Russia has not been signed; has not
ratified 1998 maritime boundary agreement with
Lithuania (primary concern is oil exploration rights)
Illicit drugs: transshipment point for opiates and
cannabis from Central and Southwest Asia to Western
Europe and Scandinavia and Latin American cocaine
and some synthetics from Western Europe to CIS;
limited production of illicit amphetamine, ephedrine,
and ecstasy for export
LG
LV
LVA
428
.Iv
57 00 N
25 00 E
Lau Group (island group)
56 57N
24 06 E
Riga, Gulf of
Atlantic Ocean
57 30 N
23 30 E
Rio de la Plata (gulf)
Atlantic Ocean
35 00S
59 00 W
649
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Rio de Oro (region)','56bd140f9f29900a1b5ddd2c7b0ce77efdca1abd47ff34b6dcfee2529795a4f3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d516bccfbca26d4e76de1b217f7a3d03e0299daaab5d80115631acc9b72a7c3',2001,'LB','Lebanon','transnational-issues',688,'Background: Lebanon has made progress toward
rebuilding its political institutions and regaining its
national sovereignty since 1991 and the end of the
devastating 16-year civil war. Under the Ta''if Accord -
the blueprint for national reconciliation - the Lebanese
have established a more equitable political system,
particularly by giving Muslims a greater say in the
political process while Institutionalizing sectarian
divisions in the government. Since the end of the war,
the Lebanese have conducted several successful
elections, most of the militias have been weakened or
disbanded, and the Lebanese Armed Forces (LAF)
have extended central government authority over
about two-thirds of the country. Hizballah, the radical
Shi''a party, retains its weapons. Syria maintains about
25,000 troops in Lebanon based mainly in Beirut,
North Lebanon, and the Bekaa Valley. Syria''s troop
deployment was legitimized by the Arab League
during Lebanon''s civil war and in the Ta''if Accord.
Damascus justifies its continued military presence in
Lebanon by citing the continued weakness of the LAF,
Beirut''s requests, and the failure of the Lebanese
Government to implement all of the constitutional
reforms in the Ta''if Accord. Israel''s withdrawal from its
security zone In southern Lebanon in May of 2000,
however, has emboldened some Lebanese Christians
and Druze to demand that Syria withdraw its forces as
well.
Disputes - international: Syrian troops in northern,
central, and eastern Lebanon since October 1976;
Lebanese government claims Shab’a Farms area of
Israeli-occupied Golan Heights as a part of Lebanon
from which Hizballah conducts cross-border attacks
Illicit drugs: inconsequential producer of hashish; a
Lebanese/Syrian eradication campaign started in the
early 1990s has practically eliminated the opium and
cannabis crops
289
LE
LB
LBN
422
.lb
33 53 N
35 30 E
Bekaa Valley
34 00 N
36 05 E
Belau (Palau Islands)
33 50N
36 50 E
Libreville (capital)
33 50N
36 50E
Lubumbashi (city)
Democratic Republic of the Congo
11 40 S
27 28 E
Lusaka (capital)
34 26 N
35 51 E
Tripolitania (region)','627456779e21ced5538f4dd7eb30e69df9b54724a91a2c9628856c0f1b0f6c2c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4000c57101f40138b4ec89f5e734b98f051f64016f93af37dc3656cac97f383f',2001,'ZA','South Africa','transnational-issues',703,'Disputes - international: none
Background: After the British seized the Cape of
Good Hope area in 1806, many of the Dutch settlers
(the Boers) trekked north to found their own republics.
The discovery of diamonds (1867) and gold (1886)
spurred wealth and immigration and intensified the
subjugation of the native inhabitants. The Boers
resisted British encroachments, but were defeated in
the Boer War (1899-1902). The resulting Union of
South Africa operated under a policy of apartheid - the
separate development of the races. The 1990s
brought an end to apartheid politically and ushered in
black majority rule.
Disputes - International: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
Illicit drugs: transshipment center for heroin,
hashish, marijuana, and possibly cocaine; cocaine
consumption on the rise; world''s largest market for
illicit methaqualone, usually imported illegally from
India through various east African countries; illicit
cultivation of marijuana
South Georgia
and the South
Sandwich Isiands
(overseas territory of the UK,
also claimed by Argentina)
Shag Rocks
are not shown.
0 100 200 km
0 100 200 ml
^ South Georgia
rytviken
Bird \\
Island
South
Atlantic Ocean
Clerke''"
Rocks
Traversay o
islands \\
Sootin Sea
South
Sandwich Saunders IP
Montagu 1.0
Bristol 1.^
Administered by U.K.,
claimed by ARGENTINA.
Southern"
Thule
Disputes - international: claimed by Argentina
Southern Ocean
Disputes - international: Antarctic Treaty defers
claims (see Antarctic Treaty Summary in the
Antarctica entry); sections (some overlapping)
claimed by Argentina, Australia, Chile, France, New
Zealand, Norway, and UK; the US and most other
nations do not recognize the maritime claims of other
nations and have made no claims themselves (the US
and Russia have reserved the right to do so); no
formal claims have been made in the sector between
90 degrees west and 150 degrees west
SF
ZA
ZAF
710
.za
South Georgia and the Islands
sx
GS
SGS
239
•gs
2912S
26 07E
Bo Hai (gulf)
Pacific Ocean
38 00 N
120 00 E
Boa Vista (island)
Cape Verde
16 05N
22 50W
Bogota (capital)
26 30 8
25 30 E
Bora-Bora (island)
27 30S
2330E
British Central African Protectorate (former name
of Nyasaland)
3415S
18 25E
632
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Cape Province (region; former name for Northern,
Western, and Eastern Cape Provinces of South Africa)
3f 30 S
22 30E
Cape Town (legislative capital)
33 57S
1828W
Caracas (capital)
Venezuela
10 30 N
66 56 W
Cargados Carajos Shoals
33 00S
27 00 E
Citta del Vaticano (local name for Vatican City)
Holy See
41 54 N
1227 E
Cochin China (region)
Vietnam
11 00 N
107 00 E
Coco, Isla del (island)
34 24S
18 30 E
Goteborg (city)
2615S
26 00 E
Joseph Bonaparte Gulf
Pacific Ocean
1400S
126 45 E
Juan de Fuca, Strait of
Pacific Ocean
4S1SN
124 00 W
Juan Fernandez, Islas de (island group)
46 51 S
37 52E
Marmara, Sea of
Atlantic Ocean
40 40 N
2815E
Marquesas Islands (lies Marquises)
2900S
30 25 E
Natuna Besar Islands
2820S
2640E
Oranjestad (capital)
2545S
2810E
Prevlaka peninsula
4635S
38 00 E
Prince Patrick Island
3215S
2815E
Transvaal (region; former name for northeastern
South Africa)
25 IDS
29 25 E
Transylvania (region)
23 00 S
31 00 E
Verde Island Passage
Pacific Ocean
13 34N
120 51 E
Victoria (capital)','5595d03f01778064c252954a5b2ad4c045ec93a4e7664e885a2d68e2139fb207','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bc685ad94f6b80cc0bf289b40141d3e21c12bfa9afb2594cf6f888eab8c9b2a',2001,'LR','Liberia','transnational-issues',704,'Background: Seven years of civil strife were brought
to a close in 1996 when free and open presidential
and legislative elections were held. President
TAYLOR now holds strong executive power with no
real political opposition. The years of fighting coupled
with the flight of most businesses have disrupted
formal economic activity. A still unsettled domestic
security situation has slowed the process of rebuilding
the social and economic structure of this war-torn
country.
Disputes - international: large refugee population
from civil war in Sierra Leone
Illicit drugs: increasingly a transshipment point for
Southeast and Southwest Asian heroin and South
American cocaine for the European and US markets
LI
LR
LBR
430
Jr
618N
10 47W
Montenegro (political region)
Yugoslavia
42 30N
19 00E
Monterrey (city)','72c9e14f8e7d77fbb92c9605648629ee641c0486fb0dc7d19cb54175c0941766','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaaeee9a22c5bca94d01770f5fe23c26ce2e191b7403ae2041072d3a3a9ad87d',2001,'LY','Libya','transnational-issues',712,'Background; Since he took power in a 1969 military
coup. Col. Muammar Abu Minyaral-QADHAFI has
espoused his own political system - a combination of
socialism and Islam - which he calls the Third
International Theory. Viewing himself as a
revolutionary leader, he used oil funds during the 1 970s
and 1 980s to promote his ideology outside Libya, even
supporting subversives and terrorists abroad to hasten
the end of Marxism and capitalism. Libyan military
adventures failed, e.g., the prolonged foray of Libyan
troops into the Aozou Strip in northern Chad was finally
repulsed in 1987. Libyan support for terrorism
decreased after UN sanctions were imposed in 1992.
Those sanctions were suspended in April 1999.
LY
LY
LBY
434
•ly
31 00 N
22 00 E
Czechoslovakia (former name for the entity that
subsequently split into the Czech Republic and Slovakia)
Czech Republic, Slovakia
49 00 N
18 00E
D Dagestan (region)
Russia
43 00 N
47 00 E
Dahomey (former name for Benin)
32 54N
1311 E
Tripoli (city)
31 00 N
14 00 E
Tristan da Cunha Group (island group)
Saint Helena
3704S
1219W
Trobriand Islands
A\\
KuwiiH Barfdar \\ ,
: ''V" '' ‘Abbas \\
Manan^r,.i!t A Vl;'' \\oi-<-
BAHR^A Doha /Ah^
I Riyadh, \\7 TjfDhafbi ,mVsc.u
K ''^ ★ QATarV^ -
*S-AU01 " - S OMAri7\\
liiff ARABIA
T t Mecca
* ■fc'' Dakat^ \\
/ ■^SENEOADv
iBanJul jf__5;v J
THE QAMBIA^^!!!?,^
I DIssatAfe -J
QUINEA-BISS’AiA nr
BU|^NA\\^iamcy
Omdurman
Khartoum -4
S U D AY
^ jrA ^ COTE
%/ Uy D’IVOIRE /
ivlaSk. J'' ^ ,( A
\\ YamoussoukroV Accra Ky
LIBCR^ f
Abidian'''''''' 1
V ( nJQERlA
Pji&Ww > / V,. ★Abuja
^/^Qv.^OQO I • Ogbomoso
I jL!-'' ] 1 *
Accr^ti^Ukagos ;
Noto'' W
Forto- f CAMEROON ] r,„o„i
Oouala Bangui
Malabo ★ \\ _ j
EQUATORiAi, QuiriEA ^ ^ Yaound^N/ /
CrnK’jf Cruin ca — 1~^^7 — (
CENTPWL AFRICAN ^
REPUBLIC
, r AfacB. -r^m; . /^Djibouti
Ababa
ETHIOPIA : /,
V ■ ^ , ''. ■ I-Ine / £
Prov. •, /
''^"c"v SOMALIA
SAO TOME
_ AHD PRinCIPE -A-
Sao Tom6
Annohofi
rCQUA. QUI.)
OjOANDAY: ^
Kisangani ^
^Mogadishu
GABON ^ONGO
kM.REF.er^fc
Bra^aville
Poi n te- No i
anqola\\Jjc1.
/ OFTHECOHC^
Kinshasa ICananpa 1
■TBujunibura" '' "'' . x. ^ ''
^Burundi , '' <^omhasz
;\\\\ l.ike .. Dodoma/ ®,, „
^ '' '' TAMZAMiA. 7 Dar cs
. , V Salaam
Mi . Immanjaro Indian
Rpfiest point in
Africa, 5895 m) ^ ^ ^ Victoria
Y ^lombasa O C C 3 n
5 o u t h
A t i cl n t i c','b46ba47290fb23567efc13ffc61f3e7a01cc4968f05b1dde60649ddce06898da','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b26a4fbcb2b043103f0c11f59ae8db05d2fa16bb6d1c0aa4664dc44392a4cc3',2001,'CH','Switzerland','transnational-issues',728,'Disputes - international: Liechtenstein''s royal
family claims restitution for 1 ,600 sq km of land in the
Czech Republic confiscated in 1918
Illicit drugs: multilateral organizations engaged in
issuing international guidelines for financial sector
oversight have found gaps In Liechtenstein''s financial
services controls that make it vulnerable to money
laundering
298
Disputes - international; Latvia has not ratified a
1998 maritime boundary agreement with Lithuania
(primary concern is oil exploration rights); 1 997 border
agreement with Russia not yet ratified by Russia
Illicit drugs: transshipment point for opiates and
other illicit drugs from Southwest Asia, Latin America,
and Western Europe to Western Europe and
Scandinavia; limited production of methamphetamine
and ecstasy
sz
CH
CHE
756
.ch
Syria
SY
SY
SYR
760
•sy
Taiwan
TW
TW
TWN
158
.tw
4657N
7 26 E
Bessarabia (region)
Moldova, Romania, Ukraine
47 00 N
28 30 E
Bharat (local name for India)
4700N
8 00E
Congo (Brazzaville) (former name for Republic of
the Congo)
Republic of the Congo
100S
15 00E
Congo (Leopoldville) (former name for the Democratic
Republic of the Congo)
Democratic Republic of the Congo
OOON
25 00 E
Constantinople (city; former name for Istanbul)
Turkey
41 01 N
28 58E
Cook Strait
Pacific Ocean
41 15 S
174 30 E
Copenhagen (capital)
4612N
610E
Genoa (city)
4700N
800E
Scopus, Mount
Israel, West Bank
31 48 N
3514E
Scotia Sea
Atlantic Ocean, Southern Ocean
5600S
40 00 W
Scotland (region)
47 00 N
800 E
Sulawesi (Celebes) (island)
4700N
8 00E
Swains Island
47 23N
8 32 E
658
AFRICA
QERMArfvJi POlkm \\
bel^LOX. iPrague*
A t i .111 t 1 c
/
/ SWllz.-^Beri
/FRAriCEn-V^
-- — / Marseilles ^
? Barccrona^ cars/
Ankara
-TORKMENISTAn^
. A''ishgabal
MADEIRA ISLANDS '' , '' ''/\\_^
ylF''OKTUQAL) Rabat/
/ ^ CasaWanca^;^ • j
/ Funchal f
/ / MOROCGO^
/ CAiVAfiV ;SM\\''DS /Marrakech ("‘''^
/ . (SPAIMt / ■ _X''''^
/ . r
I Las Palmas /=-- _ f A |
Al-aayoun^ /» 1-
(El Aaiun)/ X
Webern I n.
H^AURilAIllAl
TmlSIA McHil err, mean So,
• K gYRiM ] IRAQ?
CYPRUS^E^0,„A4 JV ESfahan^
an SOri Beirut?^ T .^Vv
) iLCairbS.} JORDAN \\ J*Kuw,','759cf759bc86375b116a5dd9b172c827a6e5e8c72c10c2131dc6e2c006e6f1cc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f077cf84a125345ea1bcc7c257453c2223f1922da2808a6910e41a50e6619d52',2001,'LU','Luxembourg','transnational-issues',734,'Background: Founded in 963, Luxembourg became
a grand duchy in 1815 and an independent state
under the Netherlands. It lost more than half of its
territory to Belgium in 1839, but gained a larger
measure of autonomy. Full independence was
attained in 1867. Overrun by Germany in both World
Wars, it ended its neutrality in 1948 when it entered
into the Benelux Customs Union and when it joined
NATO the following year. In 1957, Luxembourg
became one of the six founding countries of the
European Economic Community (later the European
Union) and in 1999 it joined the euro currency area.
established— 3 February 1958
effective— 1 November 1960
a/m— to develop closer economic cooperation
and integration
Big Seven
members— {7} Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
note— membership is the same as the
Group of 7
established— HA 1975
a/m— to discuss and coordinate major economic
policies
577
Appendix B: International Organizations and Groups (continued)
Big Six
members— (6) Canada, France, Germany, Italy, Japan, UK
note— not to be confused with the Group of 6
esteW/shecf— NA 1967
a/m— to foster economic cooperation
Black Sea Economic Cooperation Zone
(BSEC)
established— 25 June 1992
a/m— to enhance regional stability through
economic cooperation
members— (11) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Turkey,
LU
LU
LUX
442
Ju
Macau
MC
MO
MAC
446
.mo
Macedonia, The Republic of
MK
MK
MKD
807
.mk
49 45 N
610E
Luzon (island)','d8a69fceadd984542a2bf92f572cbf78899089ca752b9119f68c67c59016794b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('447a96c23ca5d257ed4a04181912781a87d3da4f17fb5585f03eea3ffee0d210',2001,'MG','Madagascar','transnational-issues',735,'Background: Formerly an Independent kingdom,
Madagascar became a French colony In 1886, but
regained its independence in 1960. During 1992-93,
free presidential and National Assembly elections
were held, ending 17 years of single-party rule. In
1997 in the second presidential race, Didier
RATSIRAKA, the leader during the 1 970s and 1 980s,
was returned to the presidency.
Disputes - international: claims Bassas da India,
Europa Island, Glorioso Islands, Juan de Nova Island,
and Tromelin Island (all administered by France)
Illicit drugs: illicit producer of cannabis (cultivated
and wild varieties) used mostly for domestic
consumption; transshipment point for heroin
MA
MG
MDG
450
.mg
1852S
47 30 E
Antigua (island)
20 00S
47 00 E
Maddalena, Isoia
20 00 S
47 00E
Malay Archipelago
Brunei, Indonesia, Malaysia, Papua New Guinea,','725ce296c77f2a70a1f225783cb608f804d952b80eeb5a01aac9b473abeaf0b3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee02aef96b90f4ff81ac66ab21be859f0b5d639f39ecfc0155810570287ee4f1',2001,'MW','Malawi','transnational-issues',743,'Background: Established in 1891, the British
protectorate of Nyasaland became the independent
nation of Malawi in 1964. After three decades of
one-party rule, the country held multiparty elections in
1994 under a provisional constitution, which took full
effect the following year. National multiparty elections
were held again in 1999.
Ml
MW
MWI
454
.mw
13 30S
34 00E
British East Africa (former name for British
possessions in eastern Africa)
Kenya, Tanzania, Uganda
1 00 N
38 00E
British Guiana (former name for Guyana)
1359S
3344E
Lima (capital)
13 SOS
34 00 E
Nyassa (region)','df37b17fd2242e2501f3e3f4a1c49a1411d4740f664977fb716ed5c9b91cfd11','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('808211d9a8c00e4e3fd1ecb7b34e8536df8ea09b540fb33148deb80a4a64bf5a',2001,'PH','Philippines','transnational-issues',753,'Disputes - international: dispute with Tanzania
over the boundary in Lake Nyasa (Lake Malawi)
the merging of Malaya (independent in 1957) and the
former British Singapore, both of which formed West
Malaysia, and Sabah and Sarawak in north Borneo,
which composed East Malaysia. The first three years
of independence were marred by hostilities with
Indonesia. Singapore separated from the union in
1965.
Disputes - international: involved in a complex
dispute over the Spratly Islands with China,
Philippines, Taiwan, Vietnam, and possibly Brunei;
Philippines have not fully revoked claim to Sabah
State; Pulau Batu Putih (Pedra Branca Island)
disputed with Singapore; Sipadan and Ligitan Islands
in dispute with Indonesia
Illicit drugs: transit point for some illicit drugs; drug
trafficking prosecuted vigorously and carries severe
penalties
Disputes - international: occupied by China, but
claimed by Taiwan and Vietnam
397
Background: The Philippines were ceded by Spain
to the US in 1898 following the Spanish-American
War. They attained their independence in 1946 after
being occupied by the Japanese in World War II. The
21 -year rule of Ferdinand MARCOS ended in 1986
when a widespread popular rebellion forced him into
exile. In 1992, the US closed down its last military
bases on the islands. The Philippines has had two
electoral presidential transitions since Marcos''
removal by "people power." In January 2001, the
Supreme Court declared Joseph ESTRADA unable to
rule in view of mass resignations from his government
and administered the oath of office to Vice President
Gloria MACAPAGAL-ARROYO as his constitutional
successor. The government continues to struggle with
ongoing Muslim insurgencies in the south.
Disputes - international: involved in a complex
dispute over the Spratly Islands with China, Malaysia,
Taiwan, Vietnam, and possibly Brunei; claim to
Malaysia''s Sabah State has not been fully revoked
Illicit drugs: exports locally produced marijuana and
hashish to East Asia, the US, and other Western
markets; serves as a transit point for heroin and
crystal methamphetamine
Pitcairn islands
(overseas territory
of the UK)
0 50 100 km
6 50 100 mi
^Sandy
Oeno
0 Henderson
ADAM^TOWN
Ducie<^
V^Bounty
Disputes - International: all of the Spratly Islands
are claimed by China, Taiwan, and Vietnam; parts of
them are claimed by Malaysia and the Philippines; in
1984, Brunei established an exclusive fishing zone
that encompasses Louisa Reef in the southern Spratly
Islands, but has not publicly claimed the island; in
2000, China joined ASEAN discussions towards
creating a South China Sea "code of conduct" - a
non-legally binding confidence building measure
471
RP
PH
PHL
608
.ph
Pitcairn Islands
PC
PN
PCN
612
.pn
1910N
121 40 "E
Baffin Bay
Arctic Ocean
73 00 N
66 00 W
Baffin Island
19 55N
122 10 E
Balkan Peninsula
Albania, Bosnia and Herzegovina, Bulgaria,
Croatia, Greece, The Former Yugoslav
Republic of Macedonia, Romania, Slovenia,
Turkey (European part), Yugoslavia
42 00 N
23 00 E
Balleny Islands
20 30 N
121 50 E
Bavaria (Bayern) (region)
1300 N
122 00 E
Finland, Gulf of
Atlantic Ocean
60 00N
27 00 E
Flores (island)
10 50N
124 50 E
Liancourt Rocks (claimed by Japan)
South Korea
3715N
131 50 E
Liaodong Wan (gulf)
Pacific Ocean
40 30 N
121 20 E
Liban (local name for Lebanon)
16 00N
121 00 E
Luzon Strait
Pacific Ocean
20 30N
121 00 E
Lyakhov Islands
Russia
73 45N
138 00 E
M Macao
Macau
22 ION
113 33 E
Macedonia
The Former Yugoslav Republic of Macedonia
41 50 N
22 00 E
Macquarie Island
2 30N
120 00 E
Malay Peninsula
Malaysia, Thailand
710N
100 35 E
Male (capital)
14 35N
121 00 E
Manipa Strait
Pacific Ocean
3 20S
127 23 E
Mannar, Gulf of
Indian Ocean
8 30N
79 00 E
Manua Islands
SOON
125 00 E
Mindanao Sea
Pacific Ocean
915N
124 30 E
Mindoro (island)
12 50N
121 05 E
Mindoro Strait
Pacific Ocean
12 20N
120 40 E
Mingrelia (region)
15 08N
120 21 E
Mozambique Channel
Indian Ocean
19 00S
41 00 E
Muritaniyah (local name for Mauritania)
10 00N
123 00 E
Nejd (region)
930 N
11830 E
Palermo (city)
11 15N
122 30 E
Pantelleria, Isola di (island)
13 00N
122 00 E
Pinatubo, Mount (volcano)
15 08N
120 21 E
Pines, Isle of (former name for Isla de la Juventud) (island)
12 00N
125 00 E
Samaria (region)
West Bank
3215N
3510E
Samoa Islands
American Samoa, Samoa
14 00S
171 00 W
Samos (island)
6 00N
121 00 E
Sulu Sea
Pacific Ocean
SOON
120 00 E
Sumatra (island)','be46145945683ad839cd4cc7a1b75a897448b4d8495c509a2fb68980922872ae','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15fa186bd500d53411101dbb07cfdbcf063a02a151b5132da5bef36b75dfa586',2001,'MV','Maldives','transnational-issues',757,'0 75 150 km
i-''
0 75 150 mi
■■■'''' ^MaleAtol!
Arabian ■
& ;-^MALE
Sea ir \\
u
Laccadive
<0
Sea
Addu Atoll,
Disputes ■ international: none
MV
MV
MDV
462
.mv
315N
7300E
Dhofar (region)
410N
73 31 E
Mallorca (Majorca) (island)','7cdd4743dcfd89ec576e82738a06616a9565063c12d72d434d0edf467cc46a29','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2033925023984fbfe97dd4731ae37a56385d745e25f8dd2f3af2aefc068bbb17',2001,'ML','Mali','transnational-issues',766,'Background: The Sudanese Republic and Senegal
became independent of France in 1960 as the Mali
Federation. When Senegal withdrew after only a few
months, the Sudanese Republic was renamed Mali.
Rule by dictatorship was brought to a close in 1991
with a transitional government, and in 1992 when
Mali''s first democratic presidential election was held.
Since his reelection in 1997, President KONARE has
continued to push through political and economic
reforms and to fight corruption. In 1999 he indicated
he would not run for a third term.
Disputes - International: none
ML
ML
MU
466
.ml
12 39N
8 00W
Banaba (Ocean Island)
17 00N
4 00W
French Territory of the Afars and Issas (FTAI)
(former name for Djibouti)','ceae9323cada536a077e6b0dc7464b2ce410a13d9565c8b8957faf9bd14bf41d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9e6eb7c8c061933cd4fbaa7c3095a7efee90361943e02be09716e172496a94f',2001,'MT','Malta','transnational-issues',773,'Background: Great Britain formally acquired
possession of Malta in 1814. The island staunchly
supported the UK through both World Wars and
remained in the Commonwealth when it became
independent in 1964. A decade later Malta became a
republic. Over the last 15 years, the Island has
become a major freight transshipment point, financial
center, and tourist destination. It is an official
candidate for EU membership.
Railways:
total: 729 km (linked to Senegal''s rail system through
Kayes)
narrow gauge: 729 km 1 .000-m gauge
Highways:
total: ^b,^00 km
paved: 1,827 km
unpaved: 13,273 km (1 996)
Waterways: 1,815 km
Ports and harbors: Koulikoro
Airports: 27 (2000 est.)
Airports - with paved runways:
total: 7
2,438 to 3,047 m: 4
1,524 to 2,437 m:1
914 to 1,523 m: 2 {2000 est.)
Airports - with unpaved runways:
total: 20
1,524 to 2,437 m: 4
914 to 1,523 m: 7
under 91 4 m: 9 (2000 est.)
Disputes - international; none
Illicit drugs; minor transshipment point for hashish
from North Africa to Western Europe
Man, Isle of
(British crown dependency)
Background: Part of the Norwegian Kingdom of the
Hebrides until the 13th century when it was ceded to
Scotland, the isle came under the British crown in
1765. Current concerns include reviving the almost
extinct Manx Celtic language.
Disputes -international: none
MT
MT
MLT
470
.mt
Man, Isle of
IM
—
—
—
.im
ISO includes with the United Kingdom
35 54N
1431 E
Valley, The (capital)','f7d6f40fc4619668f972032a1491c66ccf6e58fe38e9fc89026b92e3558224e2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39653f6184088e87ee0d198af246898cc7890846b35e9c752f0d61995a741a47',2001,'MH','Marshall Islands','transnational-issues',781,'150 300 km
150 300 mi
North F^acific Ocean
^Taongi
Ujelang
Bikini
C"5
Q, ^Rongerik ^Utirik
‘^''Rongelap ral7a
^ Wotho
Cjae\\
^ .Mejit
^--S^Ebeye *5'' Maloelap
Kwajalein
>>. * ^i^Namu
-5 P
Majuro Arno
Ailinglapalap S?
MAJURO® Mill
h
Namonkr, ^Jaluit Knox
Disputes - International: claims US territory of
Wake Island
RM
MH
MHL
584
.mh
11 35 N
165 23 E
Bilbao (city)
11 30 N
162 15 E
England (region)
11 30 N
162 15 E
Eolie, Isole (island group)
9 05N
167 20 E
Kyushu (island)
7 05N
171 08 E
Makassar Strait
Pacific Ocean
200S
11730 E
Makedonija (local name for Macedonia)
The Former Yugoslav Republic of Macedonia
41 SON
22 00 E
643
Appendix F; Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Malabo (capital)
8 00N
167 00 E
Rangoon (Yangon) (capital)
Burma
16 47N
9610E
Rapa Nui (Easter Island)','f31f58d5815a2e37263cd3497a779a09ffe8a26e8caff99f9e2d9a018b6c7779','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b75ab5aebeaf88a094d64edfe41c341f9f26f60bfccb1fd02fb33bd5b307c326',2001,'MQ','Martinique','transnational-issues',790,'(overseas department
of France)
Background: Colonized by France in 1635, the
island has subsequently remained a French
possession except for three brief periods of foreign
occupation.
Disputes ■ international: none
Illicit drugs: transit point for South American drugs
destined for the US and Europe
432
Saint Pierre
and Miquelon
(territorial collectivity
of France)
MB
MQ
MTQ
474
.mq
14 36N
61 05 W
Franz Josef Land (island group)
Russia
81 00 N
5500E
Freetown (capital)','75358d1d9449fb383beb5a5c2a1f60f9da1be2108d91de326a2b6a0db8d9a65b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('164debfb21748864d6af5d48c2b80062f4a5cf69c1bd5e1dd9d27e791543d5f2',2001,'MR','Mauritania','transnational-issues',802,'Disputes -international: none
MR
MR
MRT
478
.mr
20 00 N
12 00W
Mazatlan (city)
20 00 N
12 00W
Musandam Peninsula
Oman, United Arab Emirates
2618N
56 24E
Muscat (capital)
1806 N
15 57W
Noumea (capital)','938204e59c66034be018d8d860bfb91bfe66b48ce47879cf333c58a3bef493cc','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('455445bc5e4ad2631e46dab117b2ff1371b4003f3baaa87e36940732251fc14c',2001,'MU','Mauritius','transnational-issues',811,'Disputes - international: claims the Chagos
Archipelago (UK-administered British Indian Ocean
Territory); claims French-administered Tromelin
Island
Illicit drugs: minor consumer and transshipment
point for heroin from South Asia; small amounts of
cannabis produced and consumed locally
MP
MU
MUS
480
.mu
10 25S
56 40 E
Agana (city; former name for Hagatna)
1625S
59 38 E
Caribbean Sea
Atlantic Ocean
15 00N
73 00W
Caroline Islands
Federated States of Micronesia, Palau
730 N
148 00 E
Carpatho-Ukraine (region; former name for
Zakarpats’ka oblast’)
2010S
57 30 E
Port Moresby (capital)
1942S
63 25 E
Rome (capital)
1625S
59 38 E
Saint Christopher (island)','53b80cc98fc083429a40f1a95513ccc55bd11a41bbaf928558fd57da0353c824','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c70affd46874c4db84171aaee30fc65dd6898e51e2d838b813e8a2d903e06891',2001,'YT','Mayotte','transnational-issues',812,'(territorial collectivity
of France)
Background: Mayotte was ceded to France along
with the other Comoros in 1 843. It was the only island
in the archipelago that voted in 1974 to retain its link
with France and forgo independence.
Disputes - international: claimed by Comoros
MF
YT
MYT
175
•yt
1247S
4514E
Managua (capita!)','ec6d0b7ba31a4885e0ad322ed68988320011daad550ae1f37a17aa03ba5c13e1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b28d3918ec567872636a4990c3f3de75ecc085b93365d81bc4cd2692d57077',2001,'MX','Mexico','transnational-issues',820,'Tijuana^
Ensenada \\
Disputes - international: none
Illicit drugs: major illicit producer of amphetamine
for the international market; minor transshipment point
for Asian and Latin American illicit drugs to Western
Europe
409
MX
MX
MEX
484
.mx
16 51 N
99 55 W
Accra (capital)
21 ION
86 50 W
Canton (Guangzhou) (city)
20 SON
86 55 W
Crete (island)
2911 N
11817W
Guantanamo Bay (US Naval Base)
2313N
106 25 W
Mbabane (capita!)
Swaziland
2618S
31 06 E
McDonald Islands
19 24N
99 09 W
Mexico, Gulf of
Atlantic Ocean
25 00 N
90 00 W
644
Appendix F: Cross-Reference List of Geographic Names (continued)
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
Middle Congo (former name for Republic of the Congo)
Republic of the Congo
1 DOS
15 00E
Milwaukee Deep (Puerto Rico Trench)
Atlantic Ocean
19 55 N
65 27 W
Minami-tori-shima (Marcus Island)
25 40 N
100 19 W
Montevideo (capital)
19 00N
11245W
Reykjavik (capital)
19 30 N
89 00 W
Yugoslavia, Socialist Federal Republic
Bosnia and Herzegovina, Croatia, The Former
Yugoslav Republic of Macedonia, Serbia and
Montenegro (now Yugoslavia), Slovenia
43 00 N
19 00E
Z Zagreb (capital)','d93b01412062595dea57531662d5b4f506c567c133315eccd07b09c44982ffc3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79007b3b2bacc032f912dad0993bb8a41d61cb3b6d540526ccabbe551f8b9c27',2001,'US','United States','transnational-issues',821,'\\Guaymas
North Pacific
Ocean
(JTopolobampo
Mazatl^rfs.
Puerto Valtarta-
Manzanillo \\
Lazaro Carden^''
Nuevo Laredo"^
Monterrey,
Guadalajara
MEXICO®
*1
Coatzacoalcos
Oaxaca
Caribbean
Sea
Disputes -international: none
Illicit drugs: illicit cultivation of opium poppy
(cultivation in 2000 - 1,900 hectares; potential heroin
production - 2.4 metric tons) and cannabis cultivation
in 2000 - 3,900 hectares; government eradication
efforts have been key in keeping illicit crop levels low;
major supplier of heroin and marijuana to the US
market; continues as the primary transshipment
country for US-bound cocaine from South America;
two major drug syndicates control majority of drug
trafficking throughout the country; primary supplier of
methamphetamine to the US market; growing
producer and distributor of ecstasy
Micronesia,
Federated
States of
Northern
Philippine *. Mariana
Sea '' Islands
(U.S.)
350 700 km
Guam(V.S.)/
Yap
Islands
/ . .
North Pacific
Ocean
MARSHALL
ISLANDS
Hall
Islands
.t .
PALIKIR
I -\\Pohnpei
Kosrae''
C a T o I i n G '' Islands
Truk^" ..
Islands
(Chuuk)
- Kapingamarangi
Rcniaior _ _ _ _ _ _
South Pacific
Ocean
Disputes - international: maritime boundary
disputes with Canada (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island); US
Naval Base at Guantanamo Bay is leased from Cuba
and only mutual agreement or US abandonment of the
area can terminate the lease; Haiti claims Navassa
Island; US has made no territorial claim in Antarctica
(but has reserved the right to do so) and does not
recognize the claims of any other nation; Marshall
Islands claims Wake Island
Illicit drugs: consumer of cocaine shipped from
Colombia through Mexico and the Caribbean;
consumer of heroin, marijuana, and increasingly
methamphetamine from Mexico; consumer of
high-quality Southeast Asian heroin; illicit producer of
cannabis, marijuana, depressants, stimulants,
hallucinogens, and methamphetamine;
money-laundering center
USSR
Union of Soviet Socialist Republics (Soviet Union); used for information dated
before 25 December 1991
USSR/EE
Union of Soviet Socialist Republics/Eastern Europe
V
VHP
very-high-frequency
VSAT
very small aperture terminal
W
WADB
West African Development Bank
WAEMU
West African Economic and Monetary Union
WCL
World Confederation of Labor
Wetlands
Convention on Wetlands of International Importance Especially As Waterfovi/I
Habitat
WEU
Western European Union
WFC
World Food Council
WFP
World Food Program
WFTU
World Federation of Trade Unions
Whaling
International Convention for the Regulation of Whaling
WHO
World Health Organization
WlPO
World Intellectual Property Organization
WMO
World Meteorological Organization
WP
Warsaw Pact
WTO
see WToO for World Tourism Organization or WTrO for World Trade
Organization
WToO
World Tourism Organization
WTrO
World Trade Organization
Y
YAR
Yemen Arab Republic [Yemen (Sanaa) or North Yemen); used for information
dated before 22 May 1990 or CY91
Z
ZC
Zangger Committee
574
Appendix B:
International Organizations and Groups
advanced developing countries
another term for those less developed countries (LDCs) with particularly rapid industrial development; see newly
industrializing economies (NlEs)
advanced economies
a term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced economies,
countries in transition, and developing countries; it includes the following 28 advanced economies: Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland, Ireland, Israel, Italy, Japan,
South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan,
UK, US; note— this group would presumably also cover the following seven smaller countries of Andorra, Bermuda,
Faroe Islands, Holy See, Liechtenstein, Monaco, and San Marino which are included in the more comprehensive
group of "developed countries"
African, Caribbean, and Pacific Group of
States (ACP Group)
established—^ June 1975
aim—{o manage their preferential economic and
aid relationship with the EU
members— (77) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Cote d''Ivoire, Djibouti, Dominica, Dominican Republic, Equatorial Guinea,
Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica,
Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi, Mali, Marshall Islands, Mauritania, Mauritius, Federated
States of Micronesia, Mozambique, Namibia, Nauru, Niger, Nigeria, Niue, Palau, Papua New Guinea, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sudan, Suriname, Swaziland, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
African Development Bank (AfDB)
note— also known as Banque Africaine de
Developpement (BAD)
established^ August 1963
a/m— to promote economic and social
development
regional members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central
African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti,
Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho,
Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria,
Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland,
Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members— (24) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France,
Germany, India, Italy, Japan, South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden,
Switzerland, UK, US
Agency for the French-Speaking Community
(ACCT)
note— formerly Agency for Cultural and
Technical Cooperation
established— 20 March 1970; name changed
1996
a/m— to promote cultural and technical
cooperation among French-speaking countries
members— (4^) Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Dominica, Equatorial Guinea, France, Gabon, Guinea, Haiti, Laos, Lebanon, Luxembourg, Madagascar,
Mali, Mauritius, Moldova, Monaco, Niger, Romania, Rwanda, Sao Tome and Principe, Senegal, Seychelles,
Switzerland, Togo, Tunisia, Vanuatu, Vietnam
associate members— (7) Albania, Egypt, Guinea-Bissau, The Former Yugoslav Republic of Macedonia, Mauritania,
Morocco, Saint Lucia
observers— (4) Czech Republic, Lithuania, Poland, Slovenia
participating governments— (2) New Brunswick (Canada), Quebec (Canada)
Agency for the Prohibition of Nuclear
Weapons in Latin America and the Caribbean
(OPANAL)
note— acronym from Organismo para la
Proscripcion de las Armas Nucleares en la
America Latina y el Caribe (OPANAL)
established— U February 1 967 under the Treaty
of TIatelolco
effective— 25 April 1969 on the 1 1th ratification
of the treaty
a/m— to encourage the peaceful uses of atomic
energy and prohibit nuclear weapons
members— (32) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia,
Costa Rica, Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras,
Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Suriname, Trinidad and Tobago, Uruguay, Venezuela; note— Cuba signed the treaty but did not ratify it
575
Appendix B: International Organizations and Groups (continued)
Andean Community of Nations (CAN)
members— {5) Bolivia, Colombia, Ecuador, Peru, Venezuela
note— formerly known as the Andean Group
(AG), the Andean Parliament, and most recently
as the Andean Common Market (Ancom)
established— 26 May 1969; present name
adopted 1 October 1992
e/feof/Ve— 16 October 1969
a/m— to promote harmonious development
through economic integration
Arab Bank for Economic Development in
Africa (ABEDA)
note— also known as Banque Arabs de
Developpement Economique en Afrique
(BADEA)
established— IB February 1974
effective— 1 6 September 1 974
a/m— to promote economic development
members— (17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, DAE, Palestine Liberation
Organization; note— these are all the members of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
Arab Cooperation Council (ACC)
members— {A) Egypt, Iraq, Jordan, Yemen
established— ^6 February 1989
aim-Ao promote economic cooperation and
integration, possibly leading to an Arab Common
Market
Arab Fund for Economic and Social
Development (AFESD)
established— ^6 May 1968
a/m— to promote economic and social
development
members— (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq (suspended 1993),
Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia (suspended 1993),
Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Arab League (AL)
note— also known as League of Arab States
(LAS)
estabH$hed—22 March 1945
a/m— to promote economic, social, political, and
military cooperation
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE,
Yemen, Palestine Liberation Organization
Arab Maghreb Union (AMU)
members— (5) Algeria, Libya, Mauritania, Morocco, Tunisia
established— M February 1989
a/m— to promote cooperation and integration
among the Arab states of northern Africa
Arab Monetary Fund (AMF)
estdbHshed—27 April 1976
effective— 2 February 1977
a/m— to promote Arab cooperation,
development, and integration in monetary and
economic affairs
members— (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen,
Palestine Liberation Organization
Asia-Pacific Economic Cooperation (APEC)
established— 7 November 1 989
a/m— to promote trade and investment in the
Pacific basin
members— (21) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia,
Mexico, NZ, Papua New Guinea, Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers— (3) Association of Southeast Asian Nations, Pacific Economic Cooperation Conference, South Pacific
Forum
576
Appendix B: International Organizations and Groups (continued)
Asian Development Bank (AsDB)
established— ^9 December 1966
aim—{o promote regional economic cooperation
regional members— {43} Afghanistan, Australia, Azerbaijan, Bangladesh, Bhutan, Burma, Cambodia, China, Cook
Islands, Fiji, Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos, Malaysia,
Maldives, Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New
Guinea, Philippines, Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan, Thailand, Tonga,
Turkmenistan, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members— {16} Austria, Belgium, Canada, Denmark, Finland, France, Germany, Italy, Netherlands,
Norway, Spain, Sweden, Switzerland, Turkey, UK, US
Association of Southeast Asian Nations
(ASEAN)
established— S August 1967
a/m— to encourage regional economic, social,
and cultural cooperation among the
non-Communist countries of Southeast Asia
members— {10} Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
observers— (1) Papua New Guinea
dialogue partners-^11} Australia, Canada, China, EU, India, Japan, South Korea, NZ, Russia, US, UNDP
ASEAN Regional Forum (ARF)
established-^A 1994
aim—(o foster constructive dialogue and
consultation on political and security issues of
common interest and concern
members— (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
dialogue partners— {13} Australia, Canada, China, EU, India, Japan, North Korea, South Korea, Mongolia, NZ,
Papua New Guinea, Russia, US
Australia Group
established— 1 984
a/m— to consult on and coordinate export
controls related to chemical and biological
weapons
members— (33) Argentina, Australia, Austria, Belgium, Canada, Cyprus, Czech Republic, Denmark, European
Commission, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
observers— {1} Singapore
Australia-New Zealand-United States
Security Treaty (ANZUS)
members— (3) Australia, NZ, US
established— September 1951
effective— 29 April 1952
aim—{o implement a trilateral mutual security
agreement, although the US suspended security
obligations to NZ on 1 1 August 1986; Australia
and the US continue to hold annual meetings
Bank for international Settlements (BIS)
established— 20 January 1930
effective— M March 1930
a/m— to promote cooperation among central
banks in international financial settlements
members— (49) Argentina, Australia, Austria, Belgium, Bosnia and Herzegovina, Brazil, Bulgaria, Canada, China,
Croatia, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hong Kong, Hungary, Iceland,
India, Ireland, Italy, Japan, South Korea, Latvia, Lithuania, The Former Yugoslav Republic of Macedonia, Malaysia,
Mexico, Netherlands, Norway, Poland, Portugal, Romania, Russia, Saudi Arabia, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sweden, Switzerland, Thailand, Turkey, UK, US, Yugoslavia
Benelux Economic Union (Benelux)
members— {3} Belgium, Luxembourg, Netherlands
note— acronym from Belgium, Netherlands, and
US
US
USA
840
.us
United States Minor Outlying
Islands
UM
UMI
581
.urn
ISO includes Baker Island, Howland
island, Jarvis Island, Johnston Atoll,
Kingman Reef, Midway Islands,
Palmyra Atoll, Wake Island
65 00 N
153 00 W
Alaska, Gulf of
Pacific Ocean
58 00 N
145 00 W
Alboran Sea
Atlantic Ocean
36 00 N
230W
627
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry In The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Aldabra Islands (Groupe d’Aldabra)
5255N
172 57 E
Auckland Islands
19 45N
155 45 W
Hawaiian Islands
21 00 N
157 45 W
Hawar (island)
57 49N
152 23 W
Kola Peninsula (Kol’skiy Poluostrov)
Russia
67 20 N
37 00 E
Kolonia (town; former capital) (see Palikir)
Federated States of Micronesia
6 58N
158 13 E
Korea Bay
Pacific Ocean
39 00 N
124 00 E
Korea Strait
Pacific Ocean
34 00 N
129 00 E
641
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
28 25 N
178 20 W
Oesterreich (local name for Austria)
57 00N
170 00 W
Prince Edward Island
4615N
122 12 W
Saint Helier (capital)
49 30 N
67 00W
Saint Lawrence Seaway
Atlantic Ocean
4915N
67 00 W
Saint Lawrence, Gulf of
Atlantic Ocean
48 00 N
62 00 W
650
Appendix F: Cross-Reference List of Geographic Names (continued)
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
Saint Paul Island
5711 N
170 16 W
Saint Paul Island (He Saint-Paul)
French Southern and Antarctic Lands
3843S
7729E
Saint Peter and Saint Paul Rocks (Penedos de Sao
38 53 N
77 02 W
Weddell Sea
Southern Ocean
72 00S
45 00 W
Wellington (capital)
STANDARD TIME ZONES OF THE WORLD
ARCTIC ! Cl C E A N''
S''.'''' F''.''T." ■
I
» I
^nchor.,8C
reenland
(DEPiMARK)
3
^iuk (CodthAb^
.‘■.■''■■■''c A''n.A \\3)A
\\ I rpf ^ klatid of
-v-^^ — /f- t^ciifouniUand
rf''AY^ >*
I NORTH
P A Cl F I C
OC E A N
. . ViniJNTqTK^i.r -
NORTH i
A T L A N T i C
HAWAIIAN 0
/SMWDS ,
■ the
''''i ''(BAHAMAS
Carih^tJZA -
C<>ok Islands
-15-;--- . —
EL SAIJVAQSl?^^Ce^
COSTaSiT
RICA A
s
SOUTH
1
1
j
PACIFIC ''
CAIAPAOO.S
istA.vns
(ECIJA[50R‘
% tk%e^ \\
« French Pojy n^e % i a \\
(FRANCE) ^ mcy _
\\ _ ^ ^ yb Pilcaim Islands j
ARCHIPI^lAGO \\
fUAN FERN^DEZ I
. iCrilLti )
\\ Scale 1:85,000,000 310“
Miller Cylindrical Projection
0 SOin 1000 Kilometers
j - ^ j
0 500 1000 Miles
‘F.Y.R.O.M.- The Former Yugoslav Republic of Macedonia
Boundary representation is not necessarily authoritative.
EalKland Islands I
(IslaS Malvinas) j
(administered by U.K.;
claimed by ARQCHTIFiA)
I
I South Qcotpia and the
: South Sandwich Islands
(administered by U.K.
^-Claimed by ARQbrtTiMAi
Add time zone number to local time to ohla
Subtract time zone number from UTC to ob:
Add time zone number to local time to obtain UTC,
Subtract time zone number from UTC to obtain local time.
WEST
EAST
Subtract time zone number from local time to obtain UTC.
Add time zone number to UTC to obtain local time.
802801 Al (R02183) 4-01
UTC.
Political Map of the World, April 2001
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily/ AZORES Island / island group
★ Capital
Scale 1:35,000,000
Robinson Projection
standard parallels 38^N and 38 "S
Arctic C
^ u. ^
Anchorage/^
/ Cruif t>r Alailu \\
.Whitehorse ''
NORTH
PACIFIC
OCE AN
San Francisco?
uniT
^Los Angeles
'' • / 1 '']
San Diego
•
^El Paso
_ / _ M
Ciudad |u4rez^^\\
/ / •
\\\\h
x/
Tropic of Cancer (23''27'')
. Mazatl^n _ _
) MEXIC
\\ .Le6n
r *Guadalaj;
^ Mexico''
* (^Honolulu
HAWAIIAN
ISLANDS jP
Johnston Atoll
<U.S.)
ISLAS
REViiLACtGEDO
(MEXICO)
Clipperton Island
(FRAhCE)
1 2001
tCEDO
O)
Clipperton Island
(nwiCE)
3','e09ba61aafc17c44488f474fc7c9eb9413b2327999460d76a82c82d265229bd9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e18434e420d6eed5b56f14a3a868863ce6adb4837a3e24b37acb5b810f2b6ae0',2001,'MC','Monaco','transnational-issues',830,'Background: Economic development was spurred
in the late 19th century with a railroad linkup to France
and the opening of a casino. Since then, the
principality''s mild climate, splendid scenery, and
gambling facilities have made Monaco world famous
as a tourist and recreation center.
MN
MC
MCO
492
.me
4344N
7 25E
Mongol Uls (local name for Mongolia)','b6c1d9d19670fc7a65764234d32b189db20352b9de70ec5519cf0f694b673335','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2fff30b1bcbc0203e214b4b9291dc29a885fb3d199987518cc4fd73ec404f33',2001,'MS','Montserrat','transnational-issues',837,'(overseas territory
of the UK)
Background: Much of this island has been
devastated and two-thirds of the population has fled
abroad due to the eruption of the Soufriere Hills
volcano that began on 18 July 1995.
Disputes ■ international: none
illicit drugs: transshipment pointfor South American
narcotics destined for the US and Europe
MH
MS
MSR
500
.ms
16 44N
6214W
Polska (local name)','da95bdf0bc347c196799dd0983d9d3ce4ff00d8dc551ed086ab6c5f030b8f218','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a142743f9660c87bc577bac1e36f7d10a36c03e0a3677c66038f029789d3c347',2001,'NA','Namibia','transnational-issues',847,'Background: South Africa occupied the German
colony of Sud-West Afrika during World War I and
administered it as a mandate until after World War II
when it annexed the territory. In 1966 the Marxist
South-West Africa People''s Organization (SWAPO)
guerrilla group launched a war of independence for
the area that was soon named Namibia, but it was not
until 1988 that South Africa agreed to end its
administration in accordance with a UN peace plan for
the entire region. Independence came in 1990.
Disputes - international: none
WA
NA
NAM
516
.na
22 00 S
17 00 E
Germany, Federal Republic of
2400S
15 00E
Nampo-shoto (island group)
22 00 8
17 00E
Soviet Union (former name of a large Eurasian empire,
roughly coequal with the former Russian Empire)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Spanish Guinea (former name for Equatorial Guinea)
22 59S
14 31 E
Warsaw (capital)
22 34 S
17 06E
Windward Passage
Atlantic Ocean
20 00N
73 50W
Wrangel Island (Ostrov Vrangelya)
Russia
71 14 N
179 36 W
X
Xianggang (local name for Hong Kong)','7e2824f6838a58af04f8cb8a98ba1415e0227825d79a80b10a4f4af4ef386efe','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30914d26f5b31f33b21a2dcf72e71fc06026ea0c666b4b803bde9f6bbdfbf5b4',2001,'NR','Nauru','transnational-issues',855,'Background: Nauru''s phosphate deposits began to
be mined early in the 20th century by a
German-British consortium; the Island was occupied
by Australian forces in World War I. Upon achieving
Independence in 1968, Nauru became the smallest
independent republic in the world; it joined the UN in
1999.
Disputes > International: none
Navassa Island
(territory of the US)
Background: This uninhabited island was claimed
by the US in 1 857 for its guano, and mining took place
between 1 865 and 1 898. The lighthouse, built in 1 91 7,
was shut down in 1 996 and administration of Navassa
Island transferred from the Coast Guard to the
Department of the Interior. A 1998 scientific
expedition to the island described it as a unique
preserve of Caribbean biodiversity; the following year
it became a National Wildlife Refuge.
Disputes - international: claimed by Haiti
NR
NR
NRU
520
.nr
Navassa Island
BQ
—
—
—
—
0 32S
166 55 E
Plymouth (capital)
0 32S
166 55 E
Yekaterinburg (city; former name for Sverdlovsk)
Russia
56 50 N
60 39 E
Yellow Sea
Pacific Ocean
36 00 N
123 00 E
Yemen (Aden) (People''s Democratic Republic of Yemen)
(former name for southern portion of Yemen)','fef9efa2a1892bebc06d69a411d545cc4305498764ca74a35a7d0d66548c1e2a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e4926ebfbb50395b11437c1e1819c44e73d27cff59e6c337b741326b11afc03',2001,'NP','Nepal','transnational-issues',871,'Disputes - international: approximately 98,700
Bhutanese refugees in Nepal
Illicit drugs: illicit producer of cannabis for the
domestic and international drug markets; transit point
for opiates from Southeast Asia to the West
359
NP
NP
NPL
524
.np
27 43 N
8519E
Kattegat (strait)
Atlantic Ocean
57 00N
1100E
Kauai Channel
Pacific Ocean
21 45 N
158 50 W
Kazakstan (former name for Kazakhstan)','27ee2235a8c1966d2be04234bfb561d2289d6e6afccdf7dacc8764b3392ca090','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('020c975b26d788815554b05733959a7f556fde1259e3461d058c1bdeadb9684c',2001,'NL','Netherlands','transnational-issues',872,'Antilles
(part of the Kingdom of
the Netherlands)
Background; Once the center of the Caribbean
slave trade, the island of Curacao was hard hit by the
abolition of slavery in 1 863. Its prosperity (and that of
neighboring Aruba) was restored In the early 20th
century with the construction of oil refineries to service
the newly discovered Venezuelan oil fields. The island
of Sint Maarten is shared with France; its northern
portion is named Saint Martin and is part of
Guadeloupe.
Disputes - international: none
Illicit drugs: money-laundering center;
transshipment point for South American drugs bound
for the US and Europe
NL
NL
NLD
528
.nl
Netherlands Antilles
NT
AN
ANT
530
.an
52 23 N
4 54E
Amsterdam Island (He Amsterdam)
French Southern and Antarctic Lands
3752S
77 32E
Amundsen Sea
Southern Ocean
72 30S
11200W
Amur River
China, Russia
52 56 N
141 10 E
Amurskiy Liman (strait)
Pacific Ocean
53 00 N
141 30 E
Anadyrskiy Zaliv (gulf)
Pacific Ocean
64 00 N
177 00 E
Anatolia (region)
Turkey
39 00 N
35 00 E
Andaman Islands
52 05N
418E
Haifa (city)
52 30 N
545 E
Hong Kong (special administrative region)
52 30 N
5 45E
Nederlandse Antillen (local name for the Netherlands
Antilles)
Netherlands Antilles
1215N
68 45 W
Negev (region)
53 26 N
5 30E
West Germany (Federal Republic of Germany)
(former name for western portion of Germany)','1540a57e7f07d58e187f54257effa79f325d6c4147540d6080d006b9c0e2e353','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e189a8f79400b07bf39cda538e68227d19dd0896f30074e2e5b4a62ecb28233',2001,'NC','New Caledonia','transnational-issues',880,'(overseas territory
of France)
Background: Settled by both Britain and France
during the first half of the 1 9th century, the island was
made a French possession in 1853. It served as a
penal colony for four decades after 1 864. Agitation for
independence during the 1980s and early 1990s
seems to have dissipated.
NC
NC
NCL
540
.nc
19 45S
163 40 E
Belgian Congo (former name for Democratic
Republic of the Congo)
Democratic Republic of the Congo
OOON
25 00 E
Belgie (local name for Belgium)
19 52S
158 15 E
Chihli, Gulf of (see Bo Hai)
Pacific Ocean
38 30N
120 00 E
Chiloe (island)
21 00 S
167 00 E
Luanda (capital)
2216S
166 27 E
Nouvelle-Caledonie (local name for New Caledonia)
21 SOS
165 30 E
Nouvelles Hebrides (former name for Vanuatu)','dbf3e3a75fc6e7c408a30f6422b9ee46f7bb6dd1b7953dbd222d5421ee247a38','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64efde7300e019da3dde9347499026ef6541d82ca5e997f10c237079b5b37450',2001,'NZ','New Zealand','transnational-issues',882,'Background: The British colony of New Zealand
became an independent dominion in 1907 and
supported the UK militarily in both World Wars. New
Zealand withdrew from a number of defense alliances
during the 1 970s and 1 980s. In recent years the
government has sought to address longstanding
native Maori grievances.
Disputes - international: territorial claim in
Antarctica (Ross Dependency)
Disputes - international: none
504
Trinidad and
Tobago
Background: The islands came under British control
in the 19th century; independence was granted in
1 962. The country is one of the most prosperous in the
Caribbean thanks largely to petroleum and natural
gas production and processing. Tourism, mostly in
Tobago, is targeted for expansion and is growing.
Disputes - international: none
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe; producer of
cannabis
506
Tromelin Island
(possession of France)
Background: First explored by the French in 1776,
the island came under the jurisdiction of Reunion in
1814. At present, it serves as a sea turtle sanctuary
and is the site of an important meteorological station.
0
OAPEC
Organization of Arab Petroleum Exporting Countries
OAS
Organization of American States
OAU
Organization of African Unity
ODA
official development assistance
OECD
Organization for Economic Cooperation and Development
OECS
Organization of Eastern Caribbean States
OIC
Organization of the Islamic Conference
OOF
other official flows
OPCW
Organization for the Prohibition of Chemical Weapons
OPEC
Organization of Petroleum Exporting Countries
OSCE
Organization for Security and Cooperation in Europe
Ozone Layer Protection
Montreal Protocol on Substances That Deplete the Ozone Layer
572
Appendix A: Abbreviations (continued)
PCA
Permanent Court of Arbitration
PDRY
People''s Democratic Republic of Yemen [Yemen (Aden) or South Yemen]; used
for information dated before 22 May 1990 or CY91
PFP
Partnership for Peace
Ramsar
see Wetlands
RG
Rio Group
SAARC
South Asian Association for Regional Cooperation
SACU
Southern African Customs Union
SADC
Southern African Development Community
SPRY
Socialist Federal Republic of Yugoslavia
SHF
super-high-frequency
Ship Pollution
Protocol of 1 978 Relating to the International Convention for the Prevention of
Pollution From Ships, 1973 (MARPOL)
Sparteca
South Pacific Regional Trade and Economic Cooperation Agreement
SPC
South Pacific Commission
SPF
South Pacific Forum
sq km
square kilometer
sq mi
square mile
TAT
Trans-Atlantic Telephone
Tropical Timber 83
International Tropical Timber Agreement, 1983
Tropical Timber 94
International Tropical Timber Agreement, 1994
UAE
NZ
NZ
NZL
554
.nz
49 41 S
178 43 E
Antwerp (city)
5100S
166 30 E
Australes, lies (lies Tubuai) (island group)
47 43 8
174 00 E
631
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Bourbon Island (former name of Reunion)
Reunion
21 06 S
55 36 E
Brasilia (capital)
52 33S
169 09 E
Campeche, Bay of
Atlantic Ocean
20 00 N
94 00 W
Canal Zone (former name for US possessions
in Panama)
44 00 S
176 30 W
Chechnya (Chechnia) (region)
Russia
4315N
45 40 E
Cheju Strait
Pacific Ocean
34 00 N
126 30 E
Cheju-do (island)
Korea, South
33 20 N
126 30 E
Chennai (Madras) (city)
29 50 8
178 15 W
Kerulen River
China, Mongolia
48 48 N
11700 E
Khabarovsk (city)
Russia
48 27 N
135 06 E
Khanka, Lake
China, Russia
45 00 N
132 24 E
Khartoum (capital)
39 00 S
176 00 E
North Korea
North Korea
40 00 N
127 00 E
North Ossetia (region)
Russia
43 00 N
4410E
North Pacific Ocean
Pacific Ocean
30 00 N
165 00 W
North Sea
Atlantic Ocean
56 00 N
400 E
North Vietnam (former name for northern portion of
Vietnam)
Vietnam
23 00 N
106 00 E
North Yemen (Yemen Arab Republic)
43 00S
171 00 E
South Korea
South Korea
127 30 E
South Orkney Islands
41 28 S
174 51 E
West Frisian Islands','900c24e9ebf8ee9d1be4fa18e09470a0aca015f574cfad36d013a38083db279a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f17176f7bc3b568bafe1a8c729ee11b255aa46ce3eef21fd5dd70db5c7805836',2001,'NE','Niger','transnational-issues',893,'Background: Not until 1993, 33 years after
independence from France, did Niger hold its first free
and open elections. A 1995 peace accord ended a
five-year Tuareg insurgency in the north. Coups in
1996 and 1999 were followed by the creation of a
National Reconciliation Council that effected a
transition to civilian rule in December 1999.
Disputes - international: Libya claims about 1 9,400
sq km in northern Niger; delimitation of international
boundaries in the vicinity of Lake Chad, the lack of
which led to border incidents in the past, has been
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria
373
Background: Following nearly 16 years of military
rule, a new constitution was adopted in 1999 and a
peaceful transition to civilian government completed.
The new president faces the daunting task of
rebuilding a petroleum-based economy, whose
revenues have been squandered through corruption
and mismanagement, and institutionalizing
democracy. In addition, the OBASAIMJO
administration must defuse longstanding ethnic and
religious tensions, if it is to build a sound foundation
for economic growth and political stability.
Disputes - international: delimitation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past,
has been completed and awaits ratification by
Cameroon, Chad, Niger, and Nigeria; dispute with
Cameroon over land and maritime boundaries around
the Bakasi Peninsula is currently before the ICJ;
tripartite maritime boundary and economic zone
dispute with Equatorial Guinea and Cameroon is
currently before the ICJ
Illicit drugs: facilitates movement of heroin en route
from Southeast and Southwest Asia to Western
Europe and North America; increasingly a transit
route for cocaine from South America intended for
European, East Asian, and North American markets
NG
NE
NER
562
.ne
1331 N
2 07E
Nicobar Islands','0f1b1ab3d1c1145d77255fe7c6786450d418c7b172d2ecbe77cce3800e8d5322','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa3b1b7790d9c9130bcff0447351fb0c0e56486ac32cd8a60a2d7c8518608e6',2001,'NU','Niue','transnational-issues',901,'(self-governing in free
association with
New Zealand)
0 3 6 km
6 3 6 mi Mutalau,
Hikutavake
Lakepa,
'')■
. \\
\\ • ■
\\
\\ ■:
Liku, \\
*ALOFI
/■■''
/ ■
y :
.Avatele
NE
NU
NIU
570
.nu
1901 S
169 55 E
Alphonse Island
19 02S
169 52 W
Savu Sea
Pacific Ocean
9 30S
122 00 E
Saxony (region)','33ae849ba2ac9fd915573dda83abf479f872a5d3b8bb5acf88c4f60702cd80db','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f03b3a3171afddf527c7d0ba05c97f1da2b24c5510906804294e70e8f00bb7a',2001,'MP','Northern Mariana Islands','transnational-issues',912,'Disputes - international: none
Railways: 0 km
Highways:
total: 362 km
paved: NA km
unpaved: HA km (1991)
Waterways: none
Ports and harbors: Saipan, Tinian
Merchant marine: none (2000 est.)
Airports: 6 (2000 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:1
1,524 to 2,437 m: 2 {2000 est.)
Disputes - international: claimed by Marshall
Islands
CQ
MP
MNP
580
.mp
19 40N
145 24 E
Atacama (desert)
18 08N
145 47 E
Pago Pago (capital)
1410N
145 12 E
Rotuma (island)
15 DON
145 38 E
Tiran, Strait of
Indian Ocean
28 00 N
34 27 E
Tirana (capital)','5544e432eca9dee52821a81cdc4b68b018dc567eb4a1643ca71129084658def1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b4f32d2cd54be7e7608a1d6b8bf3bbc0266d36cb13359fe86630daa5912cc01',2001,'PA','Panama','transnational-issues',913,'from Colombia in 1903 and promptly signed a treaty
with the US allowing for the construction of a canal
and US sovereignty over a strip of land on either side
of the structure (the Panama Canal Zone). The
Panama Canal was built by the US Army Corps of
Engineers between 1904 and 1914. On 7 September
1977, an agreement was signed for the complete
transfer of the Canal from the US to Panama by the
end of 1999. Certain portions of the Zone and
Increasing responsibility over the Canal were turned
over in the intervening years. With US help, dictator
Manuel NORIEGA was deposed in 1989. The entire
Panama Canal, the area supporting the Canal, and
remaining US military bases were turned over to
Panama by or on 31 December 1 999.
Disputes - international: none
Illicit drugs: major cocaine transshipment point and
major drug money-laundering center; no recent signs
of coca cultivation; monitoring of financial transactions
is improving; official corruption remains a major
problem; Panama was cited by the Financial Action
Task Force (FATF) an international organization that
includes the US Government, for its lack of
cooperation in the fight against international money
laundering
394
PM
PA
PAN
591
.pa
9 00N
79 45W
Canarias Sea
Atlantic Ocean
28 00 N
16 00W
Canary Islands
8 58N
79 32 W
Panama Canal
9 00N
79 45 W
Panama, Gulf of
Pacific Ocean
8 00N
79 30 W
Panay (island)','5730ca6f0f8fce8cab7d53933b39133d739ecacfec0604c2664981770e0ea30c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37e600154e56626c2c77e4574defdb0714ddb588b3eaf2abd3eb9efc512f3cc1',2001,'PG','Papua New Guinea','transnational-issues',921,'Nor[! ''
r^icifk: Oconn
0 150 300 km
0 150 300 mi
New
PP
PG
PNG
598
•pg
Paracel Islands
PF
—
—
—
—
210S
147 00 E
Adriatic Sea
Atlantic Ocean
42 30N
16 00E
Adygey (region)
Russia
'' 4430 N
4010E
Aegean Islands
5 00S
150 00 E
Bismarck Sea
Pacific Ocean
400 S
148 00 E
Bissau (capital)
6 00 8
155 00 E
Bougainville Strait
Pacific Ocean
6 40 8
156 10 E
Bounty Islands
9 30S
150 40 E
Desolation Islands (Isles Kerguelen)
French Southern and Antarctic Lands
49 30S
69 30 E
Deutschland (local name for Germany)
4 30S
154 10 E
Greenland Sea
Arctic Ocean
79 00 N
5 00W
Grenadines, Northern (island group)
1100S
153 00 E
Lourenco Marques (city) (former name for Maputo)
6 DOS
150 00 E
New Delhi (capital)
3 20N
152 00 E
New Siberian Islands
Russia
75 00 N
142 00 E
New Territories (mainland region)
930S
147 10 E
Port-au-Prince (capital)
6 00S
155 00 E
Solomon Islands, southern
8 38S
151 04 E
Trucial Coast (former name for the United Arab Emirates)','6e38e031b56bb5767beadea8247e0cc4e6d51f380122150e4e12ce3954065d6e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('543b69441ccce47a82d7992053ff23575213d52c19c0ec7e0ea0f9d091245d6d',2001,'PR','Puerto Rico','transnational-issues',944,'(commonwealth associated with the US)
Disputes - international: none
Wake Island
(territory of the US)
Background: The US annexed Wake island in 1899
for a cable station. An important air and naval base
was constructed in 1940-41. In December 1941 the
island was captured by the Japanese and held until
the end of World War II. In subsequent years, Wake
was developed as a stopover and refueling site for
military and commercial aircraft transiting the Pacific.
Since 1974, the island''s airstrip has been used by the
US military and some commercial cargo planes, as
well as for emergency landings. There are over 700
landings a year on the island.
RQ
PR
PRI
630
■pr
18 28N
66 07W
San Marino (capital)','d5cc8015fa6f011bcae72eb61785a4daeeac0db320adfeb423cf6e512c705979','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6094a4edefc8f6b2e637ab1e29500b6fca6ef6a07f2c518e726bc79cc3293a54',2001,'QA','Qatar','transnational-issues',947,'Background: Ruled by the Al Thani family since the
mid-1 800s, Qatar transformed Itself from a poor
British protectorate noted mainly for pearling into an
independent state with significant oil and natural gas
revenues. During the late 1980s and early 1990s, the
Qatari economy was crippled by a continuous
siphoning off of petroleum revenues by the amir who
had ruled the country since 1972. He was overthrown
by his son, the current Amir HAMAD bin Khalifa Al
Thani, in a bloodless coup in 1995. In 2001, Qatar
resolved its longstanding border disputes with both
Bahrain and Saudi Arabia. Qil and natural gas
revenues enable Qatar to have a per capita income
not far below the leading industrial countries of
Western Europe.
Disputes - international: in March of 2001 , the
International Court of Justice (ICJ) awarded the
Hawar Islands to Bahrain and adjusted Its maritime
boundary with Qatar; a final border resolution was
agreed to with Saudi Arabia in March of 2001
416
Reunion
(overseas department
of France)
QA
QA
OAT
634
.qa
Reunion
RE
RE
REU
638
.re
2517N
51 32 E
Donets Basin
Russia, Ukraine
4815N
38 30 E
Douala (city)','c72df890050c9c2e57298983615df9dc54748290475432f7cd89b3b02da4bc2d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02ce6e7af1235ec9d971d9ded2f6ca784b0468565c6aafeeb0c90bc801d17e4f',2001,'RO','Romania','transnational-issues',956,'Background: Soviet occupation following World War
II led to the formation of a communist "peoples
republic" in 1947 and the abdication of the king. The
decades-long rule of President Nicolae CEAUSESCU
became increasingly draconian through the 1 980s. He
was overthrown and executed in late 1989. Former
communists dominated the government until 1996
when they were swept from power. Much economic
restructuring remains to be carried out before
Romania can achieve its hope of joining the EU.
RO
RO
ROM
642
.ro
Russia
RS
RU
RUS
643
.ru
44 26 N
26 06 E
Budapest (capital)
46 30 N
24 00 E
Trindade, llha de (island)
44 45 N
26 05 E
Wales (region)','2bbbc02d65af40d67e60cd7dd0f81dddafa0f00368b7021925c9a7c7bff1d8ab','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29dd2a7357fff50269b47258267860be459f38aac2dbc04ce7873c9fe6530e6f',2001,'UA','Ukraine','transnational-issues',964,'Disputes -international; none
Illicit drugs: important transshipment point for
Southwest Asian heroin transiting the Balkan route
and small amounts of Latin American cocaine bound
for Western Europe
Russia
Providei^V? ^
ARCTIC OCEAN /
’aVocrsk.''x
Arkhangel''ste^
★Moscow
^ ^izhni^h^ovgorod (
^Kazan'' \\
rNovo^siyst; v
.(Tuapse
f I j*Krasnoyarsk;
NovosibfiiSk V
(Petropavlovsk-
^Kamchatskiy
''NeyeliJk ''.k
^ Nakhodka X
Vr«Vos»ochnyy\\
J) Vladivostok
Disputes - international: dispute over at least two
small sections of the boundary with China remains to
be settled, despite 1997 boundary agreement; islands
of Etorofu, Kunashiri, and Shikotan and the Habomai
group occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Caspian
Sea boundaries are not yet determined among
Azerbaijan, Iran, Kazakhstan, Russia, and
Turkmenistan: Estonian and Russian negotiators
reached a technical border agreement in December
1996, which has not been signed or ratified by Russia
as of February 2001 ; draft treaty delimiting the
boundary with Latvia has not been signed; 1997
border agreement with Lithuania not yet ratified; has
made no territorial claim in Antarctica (but has
reserved the right to do so) and does not recognize
the claims of any other nation; Svalbard is the focus of
a maritime boundary dispute between Norway and
Russia
Illicit drugs: limited cultivation of illicit cannabis and
opium poppy and producer of amphetamine, mostly
for domestic consumption; government has active
eradication program; increasingly used as
transshipment point for Southwest and Southeast
Asian opiates and cannabis and Latin American
cocaine to Western Europe, possibly to the US, and
growing domestic market; major source of heroin
precursor chemicals; corruption and organized crime
are major concerns; heroin an increasing threat in
domestic drug market
424
Disputes - international: Rwandan military forces
are supporting the rebel forces in the civil war in the
Democratic Republic of the Congo
Saint Helena
(overseas territory
of the UK)
0 400 km
0 400 mi
Ascension
St. Helena
JAMESTOWN
South Atlantic Ocean
TRISTAN DA CUNHA
Inaccessible
Island ''\\^^^^Tristan da Cunha
Nightingale
Islands
Gough Island
Disputes - international: none
428
observers— (7) Austria, Egypt, Israel, Italy, Poland, Slovakia, Tunisia
Caribbean Community and Common Market
(Caricom)
established^ July 1973
effective— 1 August 1973
a/m— to promote economic integration and
development, especially among the less
developed countries
members— (14) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Jamaica,
Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members— (3) Anguilla, British Virgin Islands, Turks and Caicos Islands
observers— (10) Aruba, Bermuda, Cayman Islands, Colombia, Dominican Republic, Haiti, Mexico, Netherlands
Antilles, Puerto Rico, Venezuela; note— w/hen Haiti has deposited an appropriate instrument of accession with the
Secretary General, it will become a full member of the Community
Caribbean Development Bank (CDB)
established— October 1969
effective— 26 January 1970
a/m— to promote economic development and
cooperation
reg/ona/ members— (20) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands,
Cayman Islands, Colombia, Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
nonregional members— (5) Canada, China, Germany, Italy, UK
Central African Customs and Economic
Union (UDEAC)
see Monetary and Economic Community of Central Africa (CEMAC)
Central African States Development Bank
(BDEAC)
members— (9) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, France,
Gabon, Germany, Kuwait
/lote— acronym from Banque de Developpement
des Etats de I''Afrique Centrale
established— 3 December 1 975
a/m— to provide loans for economic
development
Central American Bank for Economic
Integration (BCIE)
members— (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members — (4) Argentina, Colombia, Mexico, Taiwan
note— acronym from Banco Centroamericano
de Integracion Economico
established— December 1960 signature of
Articles of Agreement; 31 May 1961 began
operations
a/m— to promote economic integration and
development
Central American Common Market (CACM)
esteW/s/?ecf— 13 December 1960, collapsed in
1969, reinstated in 1991
a/m— to promote establishment of a Central
American Common Market
members— (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua; note— Panama, although not a member,
pursues full regional cooperation
578
Appendix B: International Organizations and Groups (continued)
Central European Initiative (CEI)
nofe— evolved from the Quadrilateral Initiative
and the Hexagonal Initiative
estabHshed~^ 1 November 1989 as the
Quadrilateral Initiative, 27 July 1 991 became the
Hexagonal Initiative, NA July 1992 present name
adopted
a/m— to form an economic and political
cooperation group for the region between the
Adriatic and the Baltic Seas
members— (17) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary,
Italy, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Slovakia, Slovenia, Ukraine,
Yugoslavia
centrally planned economies
a term applied mainly to the traditionally communist states that looked to the former USSR for leadership; most are
now evolving toward more democratic and market-oriented systems; also known formerly as the Second World or
as the communist countries; through the 1980s, this group included Albania, Bulgaria, Cambodia, China, Cuba,
Czechoslovakia, GDR, Hungary, North Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam, Yugoslavia
Colombo Plan (CP)
established-^^ May 1950 proposal was
adopted; 1 July 1951 commenced full operations
a/m— to promote economic and social
development in Asia and the Pacific
members— (24) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, Fiji, India, Indonesia, Iran, Japan,
South Korea, Laos, Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines, Singapore, Sri Lanka,
Thailand, US
Commonwealth (C)
note— also known as Commonwealth of Nations
established— December 1931
a/m— to foster multinational cooperation and
assistance, as a voluntary association that
evolved from the British Empire
members— {54) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei,
Cameroon, Canada, Cyprus, Dominica, Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan
(suspended), Papua New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Seychelles, Sierra Leone, Singapore, Solomon Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga,
Trinidad and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia, Zimbabwe
Commonwealth of Independent States (CIS)
established— S December 1991
effective— 2^ December 1991
a/m— to coordinate intercommonwealth
relations and to provide a mechanism for the
orderly dissolution of the USSR
members— {^2) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
communist countries
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the
Soviet model; most of the original and the successor states are no longer communist; see centrally planned
economies
Coordinating Committee on Export Controls
(COCOWl)
established in 1949 to control the export of strategic products and technical data from member countries to
proscribed destinations; members were Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy,
Japan, Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US; abolished 31 March 1994; COCOM
members established a new organization, the Wassenaar Arrangement, with expanded membership on 12 July
1996 which focuses on nonproliferation export controls as opposed to East-West control of advanced technology
Council for Mutual Economic Assistance
(CEMA)
note— also known as CMEA or Comecon
established 25 January 1 949 to promote the development of socialist economies and abolished 1 January 1 991 ;
members included Afghanistan (observer), Albania (had not participated since 1961 break with USSR), Angola
(observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia (observer), GDR, Hungary, Laos (observer), Mongolia,
Mozambique (observer), Nicaragua (observer), Poland, Romania, USSR, Vietnam, Yemen (observer), Yugoslavia
(associate)
Council of Arab Economic Unity (CAEU)
estabiished—3 June 1957
effective— 30 May 1964
a/m— to promote economic integration among
Arab nations
members— 1 plus the Palestine Liberation Organization) Egypt, Iraq, Jordan, Kuwait, Libya, Mauritania, Somalia,
Sudan, Syria, UAE, Yemen, Palestine Liberation Organization
579
Appendix B: International Organizations and Groups (continued)
Council of Europe (CE)
established— 6 May 1949
effective— 3 August 1949
aim-Ao promote increased unity and quality of
life in Europe
members— {43) Albania, Andorra, Armenia, Austria, Azerbaijan, Beigium, Bulgaria, Croatia, Cyprus, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Netherlands,
Norway, Poland, Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK
guests— {2) Bosnia and Herzegovina, Yugoslavia
observers— (5) Canada, Israel, Japan, Mexico, US
Council of the Baltic Sea States (CBSS)
estabiished—6 March 1 992
aim—{o promote cooperation among the Baltic
Sea states in the areas of aid to new democratic
institutions, economic development,
humanitarian aid, energy and the environment,
cultural programs and education, and
transportation and communication
members— {\\2) Denmark, Estonia, EU, Finland, Germany, Iceland, Latvia, Lithuania, Norway, Poland, Russia,
parties— (23) Austria, Belgium, Canada, Croatia, Czech Republic, Denmark, EU, Finland, France, Germany,
Greece, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified— (5) Bulgaria, Hungary, Poland, Russia, Ukraine
parties— (6) Canada, Luxembourg, Netherlands, Norway, Sweden, Switzerland
countries that have signed, but not yet ratified— (30) Armenia, Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech
Republic, Denmark, EU, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Liechtenstein,
Lithuania, Moldova, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Ukraine, UK, US
parties— (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Estonia, Finland, France, Germany, Hungary,
Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— (7) Canada, EU, Greece, Norway, Portugal, Ukraine, US
615
Appendix C: Selected International Environmental Agreements (continued)
Treaty Banning Nuclear Weapon Tests in the
Atmosphere, in Outer Space, and Under
Water
note-abbreviated as Nuclear Test Ban
opened for signature— 6 August 1 963
entered into force— ^0 October 1963
objective— to obtain an agreement on general
and complete disarmament under strict
international control in accordance with the
objectives of the United Nations; to put an end to
the armaments race and eliminate incentives for
the production and testing of all kinds of
weapons, including nuclear weapons
parties— {^^3) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Austraiia, Austria, The Bahamas,
Bangladesh, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma,
Canada, Central African Republic, Chad, China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Fiji, Finland,
Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon, Liberia,
Luxembourg, Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Poland, Romania, Russia,
Rwanda, Samoa, San Marino, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Uganda, UK, US, Venezuela, Yugoslavia, Zambia
countries that have signed, but not yet ratified— (''\\7) Mgefia, Burkina Faso, Burundi, Cameroon, Chile, Ethiopia,
Haiti, Libya, Mali, Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam, Yemen
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the
Sea (LOS)
note-abbreviated as Law of the Sea
opened for signature— 1 0 December 1 982
entered into force— 1 6 November 1 994
objective-Ao set up a comprehensive new legal
regime for the sea and oceans; to include rules
concerning environmental standards as well as
enforcement provisions dealing with pollution of
the marine environment
parties-{\\35) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Bahrain,
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burma,
Cameroon, Cape Verde, Chile, China, Comoros, Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominica, Egypt, Equatorial Guinea, EU, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, Luxembourg, The Former Yugoslav Republic of Macedonia, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Nigeria, Nonvay, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Philippines, Poland, Portugal, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Samoa, SaoTome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden,
Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda, Ukraine, UK, Uruguay, Vanuatu, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (35) Afghanistan, Bangladesh, Belarus, Bhutan, Burkina Faso,
Burundi, Cambodia, Canada, Central African Republic, Chad, Colombia, Republic of the Congo, Denmark,
Dominican Republic, El Salvador, Ethiopia, Hungary, Iran, North Korea, Lesotho, Liberia, Libya, Liechtenstein,
Madagascar, Malawi, Morocco, Niger, Niue, Qatar, Rwanda, Swaziland, Switzerland, Thailand, Tuvalu, UAE
United Nations Convention to Combat
Desertification in Those Countries
Experiencing Serious Drought and/or
Desertification, Particularly in Africa
note— abbreviated as Desertification
opened for signature— 14 October 1994
entered into force— 26 December 1996
objective-Ao combat desertification and
mitigate the effects of drought through national
action programs that incorporate long-term
strategies supported by international
cooperation and partnership arrangements
parties-{\\72) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South
Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg, Madagascar,
Malawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Portugal,
Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
616
Appendix C; Selected International Environmental Agreements (continued)
United Nations Framework Convention on
Ciimate Change
note— abbreviated as Climate Change
opened for signature— 9 May 1992
entered into force— 2t March 1994
objective— to achieve stabilization of
greenhouse gas concentrations in the
atmosphere at a low enough level to prevent
dangerous anthropogenic interference with the
climate system
Wetlands
parf/es— (186) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Samoa, San Marino, SaoTome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (2) Afghanistan, Liberia _
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
617
Appendix D:
Cross-Reference List of Country Data Codes
FIPS 10-4; Countries, Dependencies, Areas of Speciai Sovereignty, and Their Principal Administrative Divisions (FIPS PUB 10-4) is
maintained by the Office of the Geographer and Globai Issues (Department of State) and published by the National Institute
of Standards and Technology (Department of Commerce). FIPS 10-4 codes are intended for general use throughout the US
Government, especially in activities associated with the mission of the Department of State and national defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO 31 66) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character alphabetic codes and three-digit numeric codes that may be
needed for activities involving exchange of data with international organizations that have adopted that standard. Except for
the numeric codes, ISO 31 66 codes have been adopted in the US as FIPS 1 04-1 : American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of Special Sovereignty for Information Interchange.
Internet:
The Internet country code is the two-letter digraph maintained by the International Organization for Standardization (ISO) in
the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers Authority (lANA) to establish country-coded top-level
domains (ccTLDs).
Entity
FIPS 104
ISO 3166
Internet
Comment
UP
UA
UKR
804
.ua
4822N
23 32 E
Carpentaria, Gulf of
Pacific Ocean
14 00S
139 00 E
Castries (capita!)
45 00N
34 00 E
Crimean Peninsula
45 00 N
34 00 E
Crooked Island Passage
Atlantic Ocean
22 55N
74 35W
Crozet Islands (lies Crozet)
French Southern and Antarctic Lands
46 SOS
51 00 E
Cyclades (island group)
50 26 N
30 31 E
Kigali (capital)
50 26 N
30 31 E
L La Paz (capital)
Bolivia
16 30S
68 09 W
La Perouse Strait
Pacific Ocean
45 45 N
142 00 E
Labrador (peninsula, region)
48 22 N
23 32E
Ryukyu Islands
48 22 N
23 32 E
Transjordan (former name for Jordan)
49 00N
32 00 E
Ulaanbaatar (capital)','aeadcaaa9b05d83dd68e3d5469396505a841f09f5afd183689b2da8e30794e26','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16462e01da9b69ab6e0738b36630d587e682e2f692368329f4c4dad41a63da6a',2001,'TT','Trinidad and Tobago','transnational-issues',973,'Disputes - international: none
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe
430
TD
TT
TTO
780
.tt
Tromelin Island
TE
—
—
—
—
ISO includes with the Miscellaneous
Islands
10 39N
61 31 W
Porto-Novo (capital)
11 15N
60 40W
Tokyo (capital)
10 22N
61 15 W
Tripoli (capital)','43abcc6a1a28fe71e3d3cb3e4a1cf4dbf5b0db0bc6bfb87d1245fe818e4c5a05','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48e186b758fa297e14c02f73492169c71a7fe332593def9b2695a170b6061e4a',2001,'SM','San Marino','transnational-issues',984,'Background: The third smallest state in Europe
(after The Holy See and Monaco) also claims to be the
world''s oldest republic. According to tradition, it was
founded by a Christian stonemason named Marinus in
301 A.D. San Marino''s foreign policy is aligned with
that of Italy. Social and political trends in the republic
also track closely with those of its larger neighbor.
SM
SM
SMR
674
.sm
43 56 N
12 25 E
San Salvador (capital)','249f3c32452cd69129428eef3cae14a898112ce1a1859e105cabbd21f366952a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf774886522c3dd6dc737cbc1e9c82114fe9dbc7dc78cc5adc73aabd30b1223c',2001,'SC','Seychelles','transnational-issues',988,'0 100 200 km
0 100 200 mi
VICTORIA Y"
Les
Amirantes. ’
Mah6
Indian Ocean
Coetivy^
Groupe
d’Aldabra
Atoll de
Cosmoledo
’’^Atoll de
Farquhar
Disputes - International: claims the Chagos
Archipelago (UK-administered British Indian Ocean
Territory)
SE
SC
SYC
690
.sc
925S
46 22 E
Alderney (island)
7 01 S
52 45 E
Alsace (region)
600S
5310E
Amman (capital)
9 46S
46 34E
Astana (Akmola) (capital)
943S
47 35 E
Cotonou (seat of government)
1010S
51 10 E
Fergana Valley
Kyrgyzstan, Tajikistan, Uzbekistan
41 00 N
72 00 E
Fernando de Noronha (island group)
441 S
55 30E
Maiz, Islas del (Corn Islands)
4388
5527E
Victoria (city; former name of seaport city in
Hong Kong colony)
British Indian
Ocean Territory
(u.K.)
Valembang
Moroni
\\ *
eOMOROS
Mayotte* ^
(administered by FRAnCE. N''
> claimed by COMOROS) P
/Juan de Mova
'' Island (FR.) r
Qlorioso Islands
I MOZ^BIQUE
T Bassa!"''"
( Europa island
I _ (FRAHCD _
1 Antananarivo
1ADAQASCAR
Tromelin Island
. (rRAhCE)
_ . , Port!
Saint- Louii
^MAURITIUS
Reunion i
(rRAMCE) I
INDIAN
OCEAN
Cocos :
(Keeling) Islands
(AUSTL.)
Tropic of Capricorn (23
i: ♦
|rg* ^^bane
lie Amsterdam
. (Fr. 5. and Ant. Lands)
lie Saint- Paul
(Fr. S. and Ant. Lands)
FrencM Southern and Antarctic Lands
/ (FRAnCC)
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
hES CROZET
(Fr. S. and Ant. Lands)
ILES KERGUELEN
(Fr. S. and Ant. Lands)
Amerv Ice
^ Sheir
Heard Island and
** McDonald Islands
SOUTH [
\\0
O JL 1 i
li*Cl
ArRI€A:;;
Pori Elizabeth
fie Amsterdam
. (Fr. S. and Ant. Lands)
lie Salnt-Paul
(Fr. S. and Ant. Lands)
French Southern and Antarctic Lands
(FRAMCE)
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
ILES CROZET
(Fr. S. and Ant. Lands)
ILES KERGUELEN
i (Fr. S. and Ant. Lands)
Heard Island and
McDonald Islands
(AUSTL.)
Ilo
Ross Sea
Boundary representation is not necessarily authoritative.
802784AI (R00349) 4-01
w
\\
Physical Map of the World, April 2001
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily/ AZORES Island / island group
?ril 2001
3
4
z
6
\\1
feiMirt-''v [^^^UmaOMKati^aiSa '' ,/<i^^>,’''/4S^&^v; fe
/ ^D ''lyc''jlt'' ''■ ZEALAND
i''^'' "''-r r Z^^V^ngton
Auckland
J1
fl^.*; ,''V, .-■■ <=>-''■''-■. -''t-
*^? ./^.<'' '' '''' y''^''
-VA ■ v.; ■vj:
?# :;!lPiiii;^«-
^^--yy^^^^Chnstchurch gs^
;-yp^%y CHATHAM ISIAND^'':^
■/X - ‘.. , ... >
;;v UMil . fW-
■ 3- ■’■
mCKhhUD
ISLANDS ^
ymji.)
‘ SNARES ISLANDS
y^-- (n.z.)
• BouiSffv.is:t4^£*^/:
■ 1'' ;>X-S“i#&^''>:r /■■ ''r^''X
-.. w^AiivVM''. >ef<^ T ■
.^xx . •:-''
^ry^ysm:yy^-''^-''yy
.. ■'' ■■ 1 -X^
April 2001
’Twcntv of 27 Antarctic consultative nations
have made no claims to Antarctic territory
(although Russia and the United States have
reserved the right to do so) and they do not
recognize the claims of the other nations.
Boundary representation is not necessarily authoritative
802802AI (R00349) 4-01','89014379808e494ac9546cfba172c05e8175368fad9952a90327ba37cf717739','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1f699862b02d91f4e93cf2c4d46e5fa97129f06da53f333d0f6f080ea111699',2001,'SL','Sierra Leone','transnational-issues',997,'Background: Since 1991, civil war between the
government and the Revolutionary United Front
(RUF) has resulted in tens of thousands of deaths and
the displacement of more than 2 million people (well
over one-third of the population) many of whom are
now refugees in neighboring countries. A peace
agreement, signed in July 1999, collapsed in May
2000 after the RUF took over 500 UN peacekeepers
hostage. The RUF stepped up attacks on Guinea in
December 2000, despite a cease-fire that it signed
with the Freetown government one month earlier. As
of late 2000, up to 13,000 UN peacekeepers were
protecting the capital and key towns In the south. AUK
force of 750 was helping to reinforce security and train
the Sierra Leone army.
Disputes - international: civil war has engendered
massive refugee movements into neighboring Guinea
and Liberia
451
SL
SL
SLE
694
.si
8 SON
1315W
French Cameroon (former name for Cameroon)','4b7655e1a6dc73beffae25d22a70dea44f63076af2937b8f2636d146e68f6ff7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3208c67f871505f4c0aa214bf8ee7bda57fdc94e7963506955241a5a1fb40605',2001,'SK','Slovakia','transnational-issues',1007,'CZECH
REPUBLIC
.BRATISLAVA
u
LO
SK
SVK
703
.sk
48 09 N
17 07E
Brazzaville (capital)
Republic of the Congo
416S
1517E
Bridgetown (capital)
48 40 N
Smyrna (region; former name for Izmir)
Turkey
Society Islands (lies de la Societe)','0ac5988ef8e425940ba85fdcf7455ef58297e42f2ce88a74e7af53b66e1999ce','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f82fa0593a0e8f8cd0f405a6537792318ff523290999841e2dd10586eae7bb1',2001,'SB','Solomon Islands','transnational-issues',1021,'Disputes - international: none
BP
SB
SLB
090
.sb
623
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
8 00S
159 00 E
British Somaliland (former name for northern Somalia)
705S
121 00 E
Choson (local name for North Korea)
North Korea
40 00N
127 00 E
Christmas Island (Indian Ocean)
9 32S
160 12 E
Guadalupe, Isla de (island)
9 26S
159 57 E
Honshu (island)
1100S
166 15 E
Santa Sede (local name for the Holy See)
Holy See
41 54 N
12 27E
Santiago (capital)
8 00S
159 00 E
Solomon Sea
Pacific Ocean
8 00S
153 00 E
Somaliland (region)','5fd2f5b59e8a5bdaf2b6bc30aafe3da4333437f5511bc2ecd170d66eb0f953b4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38dfc739465d634cee1af2671057927fe8fa766896d09a86a5f393b4b488211c',2001,'SO','Somalia','transnational-issues',1022,'Background: A SIAD BARRE regime was ousted in
January 1991 ; turmoil, factional fighting, and anarchy
followed for nine years. In May of 1 991 , northern clans
declared an independent Republic of Somaliland
which now includes the administrative regions of
Awdal, Woqooyi Galbeed, Togdheer, Sanaag, and
Sool. Although not recognized by any government,
this entity has maintained a stable existence, aided by
the ovenwhelming dominance of the ruling clan and
economic infrastructure left behind by British,
Russian, and American military assistance programs.
The regions of Bari and Nugaal comprise a
neighboring self-declared Republic of Puntland, which
has also made strides towards reconstructing
legitimate, representative government. Beginning in
1993, a two-year UN humanitarian effort (primarily in
the south) was able to alleviate famine conditions, but
when the UN withdrew in 1995, having suffered
significant casualties, order still had not been
restored. A Transitional National Government (TNG)
was created in October 2000 in Arta, Djibouti which
was attended by a broad representation of Somali
clans. The TNG has a three-year mandate to create a
permanent national Somali government. The TNG
does not recognize Somaliland or Puntland as
independent republics but so far has been unable to
reunite them with the unstable regions In the south;
numerous warlords and factions are still fighting for
control of Mogadishu and the other southern regions.
Disputes - international: most of the southern half
of the boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute with Ethiopia
over the Ogaden
463
SO
so
SOM
706
.so
4 00N
46 00 E
Bengal, Bay of
Indian Ocean
15 00 N
90 00 E
Berau, Gulf of
Pacific Ocean
2 30S
132 30 E
Bering Island
Russia
55 00 N
166 30 E
Bering Sea
Pacific Ocean
60 00 N
175 00 W
630
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Bering Strait
Pacific Ocean
65 30 N
169 00 W
Berkner Island
10 00N
49 00 E
Brussels (capital)
10 00N
49 00E
Ittihad al-lmarat al-Arablyah (local name for the
United Arab Emirates)
204N
45 22E
Moldavia (region)
Moldova, Romania
47 00N
29 00 E
Molucca Sea
Pacific Ocean
2 00N
127 00 E
Moluccas (Spice Islands)
8 21 N
49 08 E
Pyongyang (capital)
North Korea
39 01 N
125 45 E
Q
Qazaqsfan (local name for Kazakhstan)
930N
46 00 E
Somers Islands (former name for Bermuda)','6625244a25d1582c44b718a279eb05dfb3ccade71a33fbc38d2be22fddbec2d0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('820083f3377dd312230a96e2ad5a0a4abeea2b3207689c38b2552014801ac069',2001,'ES','Spain','transnational-issues',1032,'La Coruna /^ORRA
Wgo ''Lean
.Valladolid .Zaragoza
.Salamanca Tarrannna*^^Barcelona
Tarragoi
Castolldn do
MADRID® la p|ana
Balaaric
Soa
Valencia^
O Balearic
*• Islands
Cbrdoba. ^Mioante
Huelva ,, Cartager^
Sevilla X
GibraltapJ!^ S/m/Y of Gitnoltur
(U.K.j^Ceuta Mellila
AliaZ 7 ALGERIA
Ocean / MOROCCO > Canary islands are not shown.
Disputes - International: Gibraltar issue with UK;
Spain controls five places of sovereignty (plazas de
soberania) on and off the coast of Morocco - the
coastal enclaves of Ceuta and Melilla, which Morocco
contests, as well as the islands of Penon de
AIhucemas, Penon de Velez de la Gomera, and Islas
Chafarinas
Illicit drugs: key European gateway country for Latin
American cocaine and North African hashish entering
the European market; transshipment point for and
consumer of Southwest Asian heroin
Spratly Islands
Northeast Cay
Southwest CayJV
South
SP
ES
ESP
724
.es
Spratly Islands
PG
—
—
—
—
3513N
353W
Alma-Ata (city; former name for Almaty)
39 30 N
3 00E
Balearic Sea (Iberian Sea)
Atlantic Ocean
40 30N
2 00E
Bali (island)
43 00 N
2 30W
Bass Strait
Pacific Ocean
3920S
145 30 E
Basse-Terre (capital)
4315N
258W
Bioko (island)
28 00 N
15 30W
Canberra (capital)
42 00 N
200 E
Cato Island
3553N
519W
Ceylon (former name for Sri Lanka)
3512N
2 26W
Chagos Archipelago (Oil Islands)
40 00 N
400W
Essequibo (region) (claimed by Venezuela)
42 45N
810E
Galilee (region)
40 24 N
341 W
Magellan, Strait of
Atlantic Ocean
54 00S
71 00 W
Maghreb (region)
Algeria, Libya, Mauritania, Morocco, Tunisia
30 00 N
500 E
Magreb (local name for Morocco)
39 30 N
300E
Majuro (capital)
39 30 N
3 00E
Malmady (region)
3519N
258W
Memel (region)
40 00 N
4 00E
Minsk (capital)
3511 N
418W
Venda (enclave)
^Sevilla
V^encia^, <a
^ BALEARIC
.\\|TAL\\=
VATlfeACli. \\
NRcmi
i Naple^
fSprrf/nfn
(rr.)
Palermi
ROMAniA (T^
Bucharest
S^^braitanu.K.) Algiers
Ceuta Iran
DMIA
^izmlr T U R
Konya*
,i ^ Nicosia^
''^Valletta TnIco^
Mediterranean Sea Sr.) Cyprus
CANARY ISLANDS
o <SP.) /
AliQ ERI A
Nouakchott^
MAURITATHA
CAPE VERDE*
.• V Dakar
Praia o,„},
1 M AL
I
\\ *Tombou:i
;ou
/ . n 1 Q
THE GAMBIA
B''ssaucf^jl^H
QUlHEA-BiS^U^^
FrectoAvn 5
Bamako^
★ i
Niamey^
Khartoum','b16d70bd7153fe4cf080512c71c95a954a147b84ee702797a3e07f981a780933','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e4c23939004dea5102ad8b0d03bd8a26d68ad570f694b8796f47ba88eae30d1',2001,'LK','Sri Lanka','transnational-issues',1049,'Disputes - international: none
CE
LK
LKA
144
.Ik
700N
81 00 E
Chafarinas, Islas (island)
6 56N
79 51 E
Colon, Archipielago de (Galapagos Islands)
7 00N
81 00 E
Serrana Bank (shoal)','696089f854aabc5366a4c5da6e5c650c9ad9d57c00cd24886d6e49233d59245e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aab79381539519c17eff18e7ab9838a41d51d391e17cb840766dae43adf6dc0',2001,'SD','Sudan','transnational-issues',1050,'Background: Military dictatorships promulgating an
Islamic government have mostly run the country since
independence from the UK in 1 956. Over the past two
decades, a civil war pitting black Christians and
animists in the south against the Arab-Muslims of the
north has cost at least 1 .5 million lives in war- and
famine-related deaths, as well as the displacement of
millions of others.
Disputes ■ international: administrative boundary
with Kenya does not coincide with international
boundary; Egypt asserts its claim to the "Hala''ib
T riangle," a barren area of 20,580 sq km under partial
Sudanese administration that is defined by an
administrative boundary which supersedes the treaty
boundary of 1899
476
SU
SD
SDN
736
.sd
1500N
30 00 E
Anjouan (island)
15 00 N
30 00 E
Assumption Island
15 36N
32 32E
Khios (island)
4
ARCTk
s
erian i>ea
Petropavlovsk-Kamchatskiy
XtEUr/AN ISLAMDS
\\ ^
D)^ KOREA
S^''y^gyang japan
jAPAri
occupied by the SOVIET UMIOM in 1945,
administered by RUSSIA, claimed by JAPAPI
NORTH
PACIFIC
OCEAN
Marcus Island
(JAFAI^)
Tropic of Cancer (23°27'')
Philippine
northern
Mariana
Islands
(U.S.)
Wake Island
(U.S.)
PHILlPPiriES
Hag^tha
FEDERATED STATES OF MICRONESIA
MARSHALL
ISLANDS
''ORElhADA
Pcfrtpof-Spain
''J^TRiniDAD AMD
jrOBAQO
O l->
J U L)i A h
pjmouTi '' •
^Djibouti','542ddd3e6a64bff87215b0a15fb5fcaea6c216726c88609499e5ee74ad20e822','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2d14e5e427bf4958b2d316762fec2aa935c1d19babd4a2b1c3e28234043388b',2001,'SR','Suriname','transnational-issues',1058,'Background: Independence from the Netherlands
was granted in 1975. Five years later the civilian
government was replaced by a military regime that
soon declared a socialist republic. It continued to rule
through a succession of nominally civilian
administrations until 1987, when international
pressure finally brought about a democratic election.
In 1989, the military overthrew the civilian
government, but a democratically elected government
returned to power in 1991.
NS
SR
SUR
740
.sr
Svalbard
sv
SJ
SJM
744
■Sj
ISO includes Jan Mayen
Swaziland
wz
SZ
swz
748
.sz
4 00N
56 00 W
Dutch West Indies (former name for the Netherlands
Antilles)
Netherlands Antilles
52 05N
418E
Dzungarian Gate (valley)
China, Kazakhstan
4525N
82 25 E
635
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
E
East China Sea
Pacific Ocean
30 00 N
126 00 E
East Frisian Islands
4 00N
56 00 W
Nevis (island)
550N
5510W
Parece Vela (island)
400N
56 00 W
Suriyah (local name for Syria)
Syria
35 00 N
38 00E
Surtsey (volcanic island)','ba94ff0dc793d43979d4efb56ca24de7c045bd6be04f6f67e592b3f846d47c4d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('847d23d7984992f385c8db0607a59474305bb315c3d66f473199138cd0883253',2001,'TJ','Tajikistan','transnational-issues',1062,'Entry
follows
Tl
TJ
TJK
762
•tj
Tanzania
TZ
TZ
TZA
834
.tz
3835N
68 48 E
Dutch Antilles (former name for the Netherlands Antilles)
Netherlands Antilles
52 05 N
418E
Dutch East indies (former name for Indonesia)','52e8c030b3fa46e67fd9f0149841b331be58fbc97c995db21e0032cefcf62a14','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0109d917388dcdb2b743f8a3a0fcd2621e68b70efc9093b8c9f96de36e2ae30e',2001,'UZ','Uzbekistan','transnational-issues',1063,'*Panjakent
A''
aV<
*Garm
^DUSHANBE
Background: Russia conquered Uzbekistan in the
late 19th century. Stiff resistance to the Red Army
after World War I was eventually suppressed and a
socialist republic set up in 1 925. During the Soviet era,
intensive production of "white gold" (cotton) and grain
led to overuse of agrochemicals and the depletion of
water supplies, which have left the land poisoned and
the Aral Sea and certain rivers half dry. Independent
since 1991, the country seeks to gradually lessen its
dependence on agriculture while developing its
mineral and petroleum reserves. Current concerns
include insurgency by Islamic militants based in
Tajikistan and Afghanistan, a non-convertible
currency, and the curtailment of human rights and
democratization.
Disputes - international: occasional target of
Islamic insurgents based in Tajikistan and
associate member— (1) "Turkish Republic of Northern Cyprus"
Euro-Atlantic Partnership Council (EAPC)
note— began as the North Atlantic Cooperation
Council (NACC); an extension of NATO
established— Q November 1991
effective— 20 December 1991
a/m— to discuss cooperation on mutual political
and security issues
members— (46) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bulgaria, Canada, Croatia, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Moldova,
Netherlands, NonA/ay, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and
Deveiopment (EBRD)
established— 8-9 January 1990 (proposals
made); 15 April 1991 (bank inaugurated)
a/m-Mo facilitate the transition of seven centrally
planned economies in Europe (Bulgaria, former
Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market
economies by committing 60% of its loans to
privatization
members— (61) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank (EIB),
Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy, Japan, Kazakhstan,
South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Mexico, Moldova, Mongolia, Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania,
Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US,
Uzbekistan; note— includes all 25 members of the OECD; also includes the EU as a single entity
European Community (or European
Communities, EC)
was established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal
and Steel Community (ESC), the European Economic Community (EEC or Common Market), and to establish a
completely integrated common market and an eventual federation of Europe; merged into the European Union (EU)
on 7 February 1992; member states at the time of merger were Belgium, Denmark, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA)
members— {4) Iceland, Liechtenstein, Norway, Switzerland
establlshed-4 January 1960
effectives May 1960
a/m— to promote expansion of free trade
European Investment Bank (EIB)
established— 25 March 1957
effectives January 1 958
a/m— to promote economic development of the
EU and its predecessors, the EEC and the EC
members— (^5) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, Sweden, UK
582
Appendix B: International Organizations and Groups (continued)
European Monetary Union (EMU)
note—^n integral part of the European Union;
also known as the European Economic and
Monetary Union
proposed— ^ -2 December 1969 at summit
conference of heads of government
signed— 7 February 1992 (Maastricht Treaty)
aim— io promote a single market by creating a
single currency, the euro; time table— 2 May
1998: European exchange rates fixed for
1 January 1999; 1 January 1999: all banks and
stock exchanges begin using euros; 1 January
2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
members— (^2) Austria, Belgium, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands,
Portugal, Spain; note— Denmark, Sweden, and UK decided not to join
European Organization for Nuclear Research
(CERN)
note— acronym retained from the predecessor
organization Conseil Europeenne pour la
Recherche Nucleaire
established— 1 July 1953
effective— 29 September 1954
a/m— to foster nuclear research for peaceful
purposes only
members— {20) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Greece,
Hungary, Italy, Netherlands, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers— (7) European Commission, Israel, Japan, Russia, Turkey, United Nations Educational, Scientific, and
Cultural Organization (UNESCO), US
European Space Agency (ESA)
estabiished—3^ May 1975
a/m— to promote peaceful cooperation in space
research and technology
members— (15) Austria, Belgium, Denmark, Finland, France, Germany, Ireland, Italy, Netherlands, Norway,
Portugal, Spain, Sweden, Switzerland, UK
cooperating state— {^) Canada
European Union (EU)
note— evolved from the European Community
(EC)
established— 7 February 1992
effective— ^ November 1993
a/m— to coordinate policy among the 15
members in three fields: economics, building on
the European Economic Community''s (EEC)
efforts to establish a common market and
eventually a common currency to be called the
''euro'', which superseded the EU''s accounting
unit, the ECU; defense, within the concept of a
Common Foreign and Security Policy (CFSP);
and justice and home affairs, including
immigration, drugs, terrorism, and improved
living and working conditions
members— (15) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, Sweden, UK
membership appiicants—(^3) Bulgaria, Cyprus, Czech Republic, Estonia, Hungary, Latvia, Lithuania, Malta, Poland,
Romania, Slovakia, Slovenia, Turkey
First World
another term for countries with advanced, industrialized economies; this term is fading from use; see developed
countries (DCs)
583
Appendix B: International Organizations and Groups (continued)
Food and Agriculture Organization (FAO)
established— October 1945
a/m— to raise living standards and increase
availability of agricultural products, as a UN
specialized agency
members— (180) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia
and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, UAE, UK, US,
Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
applicant member— (t ) Yugoslavia
former Soviet Union (FSU)
former term often used to identify as a group the successor nations to the Soviet Union or USSR; this group of 15
countries consists of Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe
(former USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); these countries are in political and economic transition and may well be
grouped differently in the near future; this group of 27 countries consists of Albania, Armenia, Azerbaijan, Belarus,
Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Russia, Slovakia,
Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan, Yugoslavia: this group is identical to the IMF group
"countries in transition" except for the IMF''s inclusion of Mongolia
Four Dragons
the four small Aslan less developed countries (LDCs) that have experienced unusually rapid economic growth; also
known as the Four Tigers; this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are
included in the IMF''s "advanced economies" group
Franc Zone (FZ)
note— also known as Conference des Ministres
des Finances des Pays de la Zone Franc
established— 1964
a/m— to form a monetary union among countries
whose currencies are linked to the French franc
members— (^6) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo,
Cote d''Ivoire, Equatorial Guinea, France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo; note— France includes
metropolitan France, the four overseas departments of France (French Guiana, Guadeloupe, Martinique, Reunion),
the two territorial collectivities of France (Mayotte, Saint Pierre and Miquelon), and the three overseas territories of
France (French Polynesia, New Caledonia, Wallis and Futuna)
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence; members inciuded
Angola, Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade
(GATT)
see the World Trade Organization (WTrO)
Group of 2 (G-2)
informal term that came into use about 1986; to facilitate bilateral economic cooperation between the two most
powerful economic giants
Japan, US
Group of 3 (G-3)
members— (3) Colombia, Mexico, Venezuela
established— HA September 1990
a/m— mechanism for policy coordination
Group of 5 (G-5)
members— {5) France, Germany, Japan, UK, US
established— 22 September 1985
a/m— to coordinate the economic policies of five
major noncommunist economic powers
584
Appendix B: International Organizations and Groups (continued)
Group of 6 (G-6)
note--e\\so known as Groupe des Six Sur le
Desarmement; not to be confused with the
Big Six
established— 22 May 1984
a/m— to achieve nuclear disarmament
members— (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7)
note— membership is the same as the Big Seven
established— 22 September 1985
a/m— to facilitate economic cooperation among
the seven major noncommunist economic
powers
members— (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
Group of 8 (G-8)
established— NA October 1975
a/m— to facilitate economic cooperation among
the developed countries (DCs) that participated
in the Conference on International Economic
Cooperation (CIEC), held in several sessions
between NA December 1975 and 3 June 1977
members— (9) Canada, EU (as one member), France, Germany, Italy, Japan, Russia, UK, US
Group of 9 (G-9)
established— NA
a/m— to discuss matters of mutual interest on an
informal basis
members— (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary, Romania, Sweden, Yugoslavia
Groupof 10(G-10)
note— also known as the Paris Club; Includes
the wealthiest members of the IMF who provide
most of the money to be loaned and act as the
Informal steering committee; name persists in
spite of the addition of Switzerland on NA April
1984
established— NA October 1962
aim—{o coordinate credit policy
members— (11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden, Switzerland, UK, US
noristate participants— (4) BIS, EU, IMF, OECD
Group of 11 (G-11)
note— also known as the Cartagena Group
established— 21 ’22 June 1984, in Cartagena,
new independent states (NIS)
a term referring to all those countries of the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies (NIEs)
newly Industrializing economies (NIEs)
that subgroup of the less developed countries (LDCs) that has experienced particularly rapid industrialization of their
economies: formerly known as the newly industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea, Singapore, Taiwan), and Brazil
595
Appendix B: International Organizations and Groups (continued)
Nonaligned Movement (NAM)
establisheci~^''6 September 1961
a/m— to establish political and military
cooperation apart from the traditional East or
West blocs
members— (1 13 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Ecuador, Egypt, Equatorial
Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Qatar, Rwanda, Saint Lucia, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization
observers— (16) Antigua and Barbuda, Armenia, Azerbaijan, Brazil, China, Costa Rica, Croatia, Dominica,
Dominican Republic, El Salvador, Kazakhstan, Kyrgyzstan, Mexico, Paraguay, Ukraine, Uruguay
guests— (28) Australia, Austria, Bosnia and Herzegovina, Bulgaria, Canada, Finland, France, Germany, Greece,
Holy See, Hungary, Ireland, Italy, Japan, South Korea, Netherlands, NZ, Norway, Poland, Portugal, Romania,
Russia, Slovakia, Slovenia, Sweden, Switzerland, UK, US
Nordic Council (NC)
established— March 1952
effective— ''\\2 February 1953
aim— to promote regional economic, cultural,
and environmental cooperation
members— [5) Denmark (including Faroe Islands and Greenland), Finland, Iceland, Norway, Sweden
observers— (3) the Sami (Lapp) local parliaments of Finland, Nonvay, and Sweden
Nordic Investment Bank (NIB)
members— (5) Denmark (including Faroe Islands and Greenland), Finland, Iceland, Norway, Sweden
established— 4 December 1975
effective— "i June 1976
aim— to promote economic cooperation and
development
North
a popular term for the rich industrialized countries generally located in the northern portion of the Northern
Hemisphere; the counterpart of the South; see developed countries (DCs)
North Atlantic Treaty Organization (NATO)
established— ^ A\\)r\\\\ 1949
a/m— to promote mutual defense and
cooperation
members— {\\d) Belgium, Canada, Czech Republic, Denmark, France, Germany, Greece, Hungary, Iceland, Italy,
Luxembourg, Netherlands, Norway, Poland, Portugal, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA)
note— also known as OECD Nuclear Energy
Agency
established— ^ February 1958
a/m— to promote the peaceful uses of nuclear
energy; associated with OECD
members— (27) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Portugal,
Spain, Sweden, Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG)
note— also known as the London Suppliers
Group or the London Group
established— HA 1974
effective— HA 1975
aim— to establish guidelines for exports of
nuclear materials, processing equipment for
uranium enrichment, and technical information
to countries of proliferation concern and regions
of conflict and instability
members— (39) Argentina, Australia, Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, Cyprus, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Latvia, Luxembourg,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK, US
observers— (1) European Commission
596
Appendix B: International Organizations and Groups (continued)
Organization for Economic Cooperation and
Development (OECD)
established— U December 1960
effective— 30 September 1961
a/m— to promote economic cooperation and
development
Organization for Security and Cooperation in
Europe (OSCE)
r/ofe— formerly the Conference on Security and
Cooperation in Europe (CSCE) established
3 July 1975
established—] January 1995
aim—io foster the implementation of human
rights, fundamental freedoms, democracy, and
the rule of law; to act as an instrument of early
warning, conflict prevention, and crisis
management; and to serve as a framework for
conventional arms control and confidence
building measures
Organization for the Prohibition of Chemical
Weapons (OPCW)
established— 29 April 1997
a/m— to enforce the Convention on the
Prohibition of the Development, Production,
Stockpiling and Use of Chemical Weapons and
on Their Destruction; to provide a forum for
consultation and cooperation among the
signatories of the Convention
Organization of African Unity (OAU)
estabiished—25 May 1963
a/m— to promote unity and cooperation among
African states
Organization of American States (OAS)
established— 14 April 1890 as the International
Union of American Republics; 30 April 1948
adopted present charter
effective— 13 December 1951
a/m— to promote regional peace and security as
well as economic and social development
members— (30) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
special member— (1) EU
members— (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia
partners for cooperation— {9) Algeria, Egypt, Israel, Japan, Jordan, South Korea, Morocco, Thailand, Tunisia
members— (174) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, El Salvador, Eritrea, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US. Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe _ _
members— {53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi
Arab Democratic Republic, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe _
members— {35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Cuba (excluded from formal participation since 1962), Dominica, Dominican Republic,
Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama,
Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago, US, Uruguay, Venezuela
observers-i50) Algeria, Angola, Austria, Azerbaijan, Belgium, Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus,
Czech Republic, Denmark, Egypt, Equatorial Guinea, EU, Finland, France, Germany, Ghana, Greece, Holy See,
Hungary, India, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia, Lebanon, Morocco, Netherlands,
Norway, Pakistan, Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia, Spain, Sri Lanka, Sweden,
Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, Yemen _
597
Appendix B: International Organizations and Groups (continued)
Organization of A','159cb85dd76354ba8aaf877035cbd468f792edb8693dcd6616e47f36270020fb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95ce0527f2361796b719d63d2645097454512453fe60e4aa1ee97df434ca45be',2001,'UZ','Uzbekistan','transnational-issues',1064,'rab Petroleum Exporting
Countries (OAPEC)
members— {W) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, UAE
estab!ished—Q January 1968
a/m— to promote cooperation in the petroleum
industry
Organization of Eastern Caribbean States
(OECS)
esfaMs/?ecf— 18 June 1981
e/fecf/Ve— 4 July 1981
a/m— to promote political, economic, and
defense cooperation
members— (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines
associate members— (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting
Countries (OPEC)
members— (M) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
establishe(d—''\\4 September 1960
aim—{o coordinate petroleum policies
Organization of the Islamic Conference (OIC)
established— 22-25 September 1969
aim—{o promote Islamic solidarity in economic,
social, cultural, and political affairs
members— (55 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Guyana, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya,
Malaysia, Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia,
Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda,
UAE, Uzbekistan, Yemen, Palestine Liberation Organization
observers— (12) Bosnia and Herzegovina, Central African Republic, Cote d''Ivoire, ECO, LAS, NAM, Moro National
Liberation Front of the Philippines, OAU, Thailand, Turkish Muslim Community of Kirbris, "Turkish Republic of
Northern Cyprus", UN
Pacific Community
/?ofe— formerly known as the South Pacific
Commission (SPC)
established— 6 February 1947
effective— 29 My 1948
aim—{o promote regional cooperation in
economic and social matters
members— (27) American Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands, Palau, Papua
New Guinea, Pitcairn Islands, Samoa, Solomon Islands, Tokelau, Tonga, Tuvalu, UK, US, Vanuatu, Wallis and
Futuna
Partnership for Peace (PFP)
established— January 1994
aim-Ao expand and intensify political and
military cooperation throughout Europe,
increase stability, diminish threats to peace, and
build relationships by promoting the spirit of
practical cooperation and commitment to
democratic principles that underpin NATO;
program under the auspices of NATO
members— (29) Albania, Armenia, Austria, Azerbaijan, Belarus, Bulgaria, Croatia, Czech Republic, Estonia,
Finland, Georgia, Hungary, Ireland, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Moldova, Poland, Romania, Russia, Slovakia, Slovenia, Sweden, Switzerland, Turkmenistan, Ukraine,
Permanent Court of Arbitration (PCA)
established— 29 July 1899
aim—{o facilitate the settlement of international
disputes
members— (78) Argentina, Australia, Austria, Belarus, Belgium, Bolivia, Brazil, Bulgaria, Canada, Chile, China,
Colombia, Democratic Republic of the Congo, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Finland, France, Germany, Greece, Guatemala, Guyana, Haiti, Honduras,
Hungary, India, Iran, Iraq, Israel, Italy, Japan, Jordan, South Korea, Laos, Lebanon, Luxembourg, Malta, Mexico,
Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Poland, Portugal, Romania,
Russia, Senegal, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Thailand, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
598
Appendix B: International Organizations and Groups (continued)
Rio Group (RG)
note— formerly known as Grupo de los Ocho,
established in December 1986; composed of the
Contadora Group and the Lima Group
established— 1988
a/m— to consult on regional Latin American
issues
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Panama, Paraguay, Peru, Uruguay,
Venezuela
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian
governments and command economies based on the Soviet model; the term is fading from use; see centrally
planned economies
socialist countries
in general, countries in which the government owns and plans the use of the major factors of production; note— the
term is sometimes used incorrectly as a synonym for communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the developed countries; the
counterpart of the North; see less developed countries (LDCs)
South Asian Association for Regional
Cooperation (SAARC)
members— {7} Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
established— B December 1985
a/m— to promote economic, social, and cultural
cooperation
South Pacific Forum (SPF)
established— 5 August 1971
aim—{o promote regional cooperation in political
matters
members— (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
South Pacific Regional Trade and Economic
Cooperation Agreement (Sparteca)
members— (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
established— Hk 1981
aim-Ao redress unequal trade relationships of
Australia and New Zealand with small island
economies in the Pacific region
Southern African Customs Union (SACU)
members— (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
established— December 1969
a/m— to promote free trade and cooperation in
customs matters
Southern African Development Community
(SADC)
members— (^ 4) Angola, Botswana, Democratic Republic of the Congo, Lesotho, Malawi, Mauritius, Mozambique,
Namibia, Seychelles, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe
note— evolved from the Southern African
Development Coordination Conference
(SADCC)
established— M August 1992
a/m— to promote regional economic
development and integration
599
Appendix B: International Organizations and Groups (continued)
Southern Cone Common Market (Mercosur)
or Southern Common Market
members— (4) Argentina, Brazil, Paraguay, Uruguay
associate member— (2) Bolivia, Chiie
note— also known as Mercado Comun del Cono
Sur (Mercosur)
established— 2B March 1991
a/m— to increase regional economic cooperation
Third World
another term for the less developed countries; the term is obsolescent; see less developed countries (LDCs)
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth; see less developed
countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see ieast
developed countries (LLDCs)
United Nations (UN)
constituent organizations—the UN is composed of six principal organs and numerous subordinate agencies and
bodies as foliows;
established— 26 June 1 945 1 ) Secretariat
effective-2A October 1945 2) General Assembly: International Research and Training Institute for the Advancement of Women (INSTRAW),
a/m— to maintain international peace and United Nations Center for Human Settlements (Habitat), United Nations Children''s Fund (UNICEF), United Nations
security and to promote cooperation involving Conference on Trade and Development (UNCTAD), United Nations Development Program (UNDP), United Nations
economic, social, cultural, and humanitarian Drug Control Program (UNDCP), United Nations Environment Program (UNEP), United Nations High Commissioner
problems for Human Rights (UNHCHR), United Nations High Commissioner for Refugees (UNHCR), United Nations Institute
for Disarmament Research (UNIDIR), United Nations Institute for Training and Research (UNITAR), United Nations
Interregional Crime and Justice Research Institute (UNICRI), United Nations Population Fund (UNFPA), United
Nations Relief and Works Agency for Palestine Refugees in the Near East (UNRWA), United Nations Research
Institute for Social Development (UNRISD), and United Nations University (UNU), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former Yugoslavia (ICTY), International Criminal Tribunal
for Rwanda (ICTR), United Nations Compensation Commission, United Nations Disengagement Observer Force
(UNDOF), United Nations Interim Administration Mission in Kosovo (UNMIK), United Nations Interim Force in
Lebanon (UNIFIL), United Nations Iraq/Kuwait Boundary Demarcation Commission, United Nations Iraq-Kuwait
Observation Mission (UNIKOM), United Nations Military Observer Group in India and Pakistan (UNMOGiP), United
Nations Mission for the Referendum in Western Sahara (MINURSO), United Nations Mission in Bosnia and
Herzegovina (UNMIBH), United Nations Mission in Ethiopia and Eritrea (UNMEE), United Nations Mission in Sierra
Leone (UNAMSIL), United Nations Mission of Observers in Prevlaka (UNMOP), United Nations Monitoring and
Verification Commission (UNMOVIC), United Nations Observer Mission in Georgia (UNOMIG), United Nations
Organization Mission in the Democratic Republic of the Congo (MONUC), United Nations Peace-Keeping Force in
Cyprus (UNFICYP), United Nations Transitional Administration in East Timor (UNTAET), and United Nations Truce
Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social Development, Commission on Crime
Prevention and Criminal Justice, Commission on Human Rights, Commission on Narcotics Drugs, Commission on
Population and Development, Commission on Science and Technology for Development, Commission on
Sustainable Development, Commission on the Status of Women, Economic and Sociai Commission for Asia and
the Pacific (ESCAP), Economic and Sociai Commission for Western Asia (ESCWA), Economic Commission for
Africa (ECA), Economic Commission for Europe (ECE), Economic Commission for Latin America and the Caribbean
(ECLAC), Food and Agriculture Organization of the United Nations (FAO), International Atomic Energy Agency
(IAEA), International Bank for Reconstruction and Development (IBRD), International Civil Aviation Organization
(ICAO), International Development Association (IDA), International Finance Corporation (IFC), International Fund
for Agricultural Development (IFAD), International Labor Organization (ILO), International Maritime Organization
(IMO), International Monetary Fund (IMF), International Telecommunication Union (ITU), Statistical Commission,
United Nations Educational, Scientific, and Cultural Organization (UNESCO), United Nations Industrial
Development Organization (UNIDO), Universal Postal Union (UPU), World Health Organization (WHO), World
Intellectual Property Organization (WlPO), World Meteorological Organization (WMO), World Tourism Organization
(WToO), and World Trade Organization (WTrO)
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ) _
600
Appendix B: International Organizations and Groups (continued)
United Nations (UN) (continued)
UN members— (189) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, SaoTome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe; note— all UN members are represented in
the General Assembly
observers— {2 plus the Palestine Liberation Organization) Holy See, Switzerland, Palestine Liberation Organization
United Nations Children''s Fund (UNICEF)
note— acronym retained from the predecessor
organization, UN International Children''s
Emergency Fund
established— U December 1946
aim— to help establish child health and welfare
services
members— {36} selected on a rotating basis from all regions
United Nations Civilian Police Mission in
established 28 November 1 997; to support the professionalization of the Haitian National Police; established by UN
Haiti (MIPONUH)
Security Council; members were Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo, Tunisia, US;
mission ended March 2000
United Nations Conference on Trade and
Development (UNCTAD)
established— 30 December 1964
aim— to promote international trade
members— (191) all UN members plus Holy See, Switzerland
United Nations Development Program
(UNDP)
established— 22 November 1965
aim— to provide technical assistance to
stimulate economic and social development
members (executive board)— (36) selected on a rotating basis from all regions
United Nations Disengagement Observer
Force (UNDOF)
established— 31 May 1974
aim— to observe the 1973 Arab-lsraeli
cease-fire; established by the UN Security
Council
members— (5) Austria, Canada, Japan, Poland, Slovakia
601
Appendix B: International Organizations and Groups (continued)
United Nations Educational, Scientific, and
Cultural Organization (UNESCO)
establishe(^—^Q November 1945
effective^ November 1946
a/m— to promote cooperation in education,
science, and culture
members— {^88) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
associate members— (8) Aruba, British Virgin Islands, Cayman Islands, Macau, Netherlands Antilles
United Nations Environment Program
(UNEP)
members— (5S) selected on a rotating basis from all regions
esiab!ished—^5 December 1972
a/m— to promote international cooperation on all
environmental matters
United Nations General Assembly
members— (189) all UN members are represented in the General Assembly
established— 26 June 1945
effective— 24 October 1 945
a/m— to function as the primary deliberative
organ of the UN
United Nations High Commissioner for
Refugees (UNHCR)
established— 3 December 1949
effective— ^ January 1951
a/m-4o ensure the humanitarian treatment of
refugees and find permanent solutions to
refugee problems
members (executive committee)— (57) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Canada,
Chile, China, Colombia, Democratic Republic of the Congo, Cote d''Ivoire, Denmark, Ethiopia, Finland, France,
Germany, Greece, Holy See, Hungary, Iceland, India, Iran, Ireland, Israel, Italy, Japan, South Korea, Lebanon,
Lesotho, Madagascar, Morocco, Mozambique, Namibia, Netherlands, Nicaragua, Nigeria, Norway, Pakistan,
Philippines, Poland, Russia, Somalia, South Africa, Spain, Sudan, Sweden, Switzerland, Tanzania, Thailand,
Tunisia, Turkey, Uganda, UK, US, Venezuela
United Nations Industrial Development
Organization (UNIDO)
established— M November 1966
effective— ^ January 1967
a/m— UN specialized agency that promotes
industrial development especially among the
members
members— (169) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
602
Appendix B: International Organizations and Groups (continued)
United Nations Institute for Training and
Research (UNITAR)
established—] 1 December 1963 adoption of
the resolution establishing the Institute
effective— 2A March 1965
a/m— to help the UN become more effective
through training and research
members (Board of Trustees)— (20) Austria, Brazil, Cameroon, Chile, China, Egypt, France, Ghana, Ireland, Japan,
Kuwait, Mexico, Netherlands, Nigeria, Russia, South Africa, Sweden, Switzerland, Thailand, US; no/e— the UN
Secretary General can appoint up to 30 members
United Nations Interim Administration
Mission in Kosovo (UNMIK)
established— W .}me 1999
a/m— to promote the establishment of
substantial autonomy and self-government in
Kosovo; to perform basic civilian administrative
functions: to support the reconstruction of key
infrastructure and humanitarian and disaster
relief
members— (49) Argentina, Austria, Bangladesh, Belgium, Bolivia, Bulgaria, Canada, Czech Republic, Denmark,
Egypt, Estonia, Fiji, Finland, France, Germany, Ghana, Hungary, Iceland, India, Ireland, Italy, Jordan, Kenya,
Kyrgyzstan, Lithuania, Malawi, Malaysia, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Philippines, Poland,
Portugal, Romania, Russia, Senegal, Spain, Sweden, Switzerland, Tunisia, Turkey, Ukraine UK, US, Zambia,
uz
uz
UZB
860
.uz
Formosa (island)
Taiwan
23 30 N
121 00 E
Formosa Strait (see Taiwan Strait)
Pacific Ocean
24 00 N
119 00 E
636
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Foroyar (local name for Faroe Islands)
41 20 N
6918E
Tasman Sea
Pacific Ocean
430S
168 00 E
Tasmania (island)
41 20 N
6918E
Transcarpathia (region; alternate name for
Carpatho-Ukraine)
United Arab Republic (UAR) (former name for a
federation between Egypt and Syria)
Egypt, Syria
Upper Volta (former name for Burkina Faso)','6b53b18db795cabf8f74ae4ca4c8d3fad8b576cd3cbbc51157305cc89b207d84','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c52099f63630bd595302ee4e7db29e65f48d815260c6e3fefa43ce0b273be5c8',2001,'PK','Pakistan','transnational-issues',1073,'Disputes - international: portions of Tajikistan''s
northern and western border with Uzbekistan and Its
eastern border with China have not been officially
demarcated; territorial dispute with Kyrgyzstan on
northern boundary in Isfara Valley area
Illicit drugs: major transshipment zone for heroin
and opiates from Afghanistan going to Russia and
Western Europe; limited illicit cultivation of cannabis,
mostly for domestic consumption
Background: Shortly after independence,
Tanganyika and Zanzibar merged to form the nation of
Tanzania in 1964. One-party rule came to an end in
1995 with the first democratic elections held in the
country since the 1970s. Zanzibar''s
semi-autonomous status and popular opposition have
led to two contentious elections since 1 995, which the
ruling party won despite international observers''
claims of voting irregularities.
Disputes ■ international: dispute with Malawi over
the boundary in Lake Nyasa (Lake Malawi); a
resurvey of the latitudinal boundary with Uganda in
2000 revealed a 300-meter discrepancy that both
sides are currently adjudicating
Illicit drugs: growing role in transshipment of
Southwest and Southeast Asian heroin and South
American cocaine destined for South African,
European, and US markets and of South Asian
methaqualone bound for Southern Africa
PK
PK
PAK
586
•pk
34 30 N
74 00E
Azarbaycan (local name for Azerbaijan)
28 00N
6300E
Baltic Sea Atlantic Ocean 5700N 1900E
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Bamako (capital)
33 42 N
7310E
Island (local name for Iceland)
30 00 N
70 00 E
West Siberian Plain
Russia
60 00N
75 00 E
Western Channel (West Korea Strait)
Pacific Ocean
34 40N
129 00 E
Western Samoa (former name for Samoa)','0c459fd0726516623f7e3779ae2c1990540b97422d688caafed239b458906340','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aa0717cb8ae2eb7467216cd7b0defa034b826f8c7cf74f3f799e74155a5d9d0',2001,'TO','Tonga','transnational-issues',1074,'0 50 100 km
0 50 100 mi
. Niuafo’ou
, Tafahi
Niuatoputapu"
South Pacific Ocean
Vava’u
Group
Vavau
Neiafu
Kao Island
o ^.l-Pangai
Ha''apai Group
NUKU''ALOFA
Tongatapu
Group ^
Minerva Reef not sfiown
TN
TO
TON
776
.to
20 00 S
175 00 W
Frisian Islands
Denmark, Germany, Netherlands
53 35N
640 E
Frunze (city; former name for Bishkek)
19 42S
174 29 W
Habomai Islands
Russia (de facto)
43 30 N
146 10 E
Hadhramaut (region)
21 OSS
175 12 W
Nunavut (region)','32db4f761dcdf7bef201ece65edd954c4a163181a2c744c3b5715cc8ea54d3ad','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95a43c945a527dbf5e2386697b5bdbb4a7671a0ae9a542f0d05e5b53eca7f935',2001,'TV','Tuvalu','transnational-issues',1078,'yNanumea
^ Kuliav.
Tonga''
Niutao
''‘Nanumanga
Tanrake^
Vaitupu''-
South
Pacific
Ocean
75 150 km
Savave
Nukufetau
Funafuti^
.^FUNAFUTI
Fangaua
Nukulaelae''
. Niulakita
Disputes - international: none
518
Disputes - international: the Ugandan military is
deployed to the Democratic Republic of Congo in
support of rebel forces in that country''s civil war; a
resurvey of the latitudinal boundary with Tanzania in
2000 revealed a 300-meter discrepancy that both
sides are currently adjudicating
Disputes ■ international: has made no territorial
claim in Antarctica (but has reserved the right to do so)
and does not recognize the claims of any other nation
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for CIS consumption; some
synthetic drug production for export to West; limited
government eradication program; used as
transshipment point for opiates and other illicit drugs
from Africa, Latin America, and Turkey, and to Europe
and Russia; drug-related money laundering a minor,
but growing, problem
TV
TV
TUV
798
.tv
800S
178 00 E
Ellsworth Land (region)
830S
179 12 E
Fundy, Bay of
Atlantic Ocean
45 00 N
66 00 W
Futuna Islands (Hoorn Islands/lles de Horne)','8fdd12989e220c96e74226df32aac381eb2df6a6f6de8ec5407f8374732d3db2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d184b1fdff40582d68a205ffd2bb22c12fe83b21f64d610826828a086847d1c',2001,'AE','United Arab Emirates','transnational-issues',1087,'b^Iain
Persian Gulf
,Das
0 ^Tunbal . \\ - \\
Tunb af Kubra / ^ /
"Sughra r*! ? V
^ Ra’s al / I / Hormuz \\
AbuMusi^ Khaym^/ j / U
Umm al Qaywayn^^ t "N
‘Ajmay^ eSL jKhawr FakkSn
, Dubar *]aI Fujayrah
I’Jabal ''Air./ 1 Gulf of
Mina’Jabal ''Ali
/
Ar Ruways
IDI ARABIA \\
UHF
ultra-high-frequency
UK
TC
AE
ARE
784
.ae
24 28 N
54 22 E
Abu Musa (island)
Iran
25 52N
55 03 E
Abuja (capita!)
2400N
54 00E
Ai iraq (local name for Iraq)
2518N
5518E
Dubayy (see Dubai)
2518N
5518E
Dublin (capital)
24 00 N
54 00 E
Iturup (see Etorofu) (island)
Russia (de facto)
44 55 N
147 40 E
Ityop’iya (local name for Ethiopia)
24 00 N
54 00 E
Trucial Oman (former name for the United Arab Emirates)
24 00 N
54 00 E
Trucial States (former name for the United Arab Emirates)
24 00 N
54 00 E
Truk Islands (former name for the Chuuk Islands)
Federated States of Micronesia
725 N
151 47 E
Tsugaru Strait
Pacific Ocean
41 35 N
141 00 E
Tuamotu Islands (lies Tuamotu)','3a39cc0dd9a6d2a916fda65e47ad7a8e658dac83ce416634a685d38bed837fec','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a651559c1e8df67a373d43498bf03fabd65218d7543549ad21c2fb44d0f0e7',2001,'OM','Oman','transnational-issues',1096,'Disputes - international: location and status of
boundary with Saudi Arabia is not final, de facto
boundary reflects 1974 agreement; boundary with
Oman has not been bilaterally defined; northern
section in the Musandam Peninsula is an
administrative boundary; claims two islands in the
Persian Gulf occupied by Iran: Lesser Tunb (called
Tunb as Sughra in Arabic by UAE and Jazireh-ye
Tonb-e Kuchek in Persian by Iran) and Greater Tunb
(called Tunb al Kubra in Arabic by UAE and Jazireh-ye
Tonb-e Bozorg in Persian by Iran); claims island in the
Persian Gulf jointly administered with Iran (called Abu
Musa in Arabic by UAE and Jazireh-ye Abu Musa in
Persian by Iran) - over which Iran has taken steps to
exert unilateral control since 1992, including access
restrictions and a military build-up on the island; the
UAE has garnered significant diplomatic support in
the region in protesting these Iranian actions
Illicit drugs: growing role as heroin transshipment
and money-laundering center due to its proximity to
southwest Asian producing countries and the
bustling free trade zone in Dubai
526
MU
OM
OMN
512
.om
17 00N
5410E
Diego Garcia (island)
17 30N
5600E
Khyber Pass
Afghanistan, Pakistan
S4 05N
71 10 E
Kibris (Turkish local name for Cyprus)
23 37 N
58 35 E
Muscat and Oman (former name for Oman)
21 00 N
57 00E
Myanma, Myanmar
Burma
22 00 N
98 00E
N Nagorno-Karabakh (region)
21 00 N
57 00E
Unimak Pass (strait)
Pacific Ocean
5420N
164 50W
Union of Soviet Socialist Republics (USSR) (former
name of a large Eurasian empire, roughly coequal with
the former Russian Empire)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,','420fbc8cbc4909c46fb9cc5b9a910e5fe886f248682966d9172c183c9f400131','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('badcd9911a0701d184d96f7740341e8fd20d1eb419a606fa4638273379a5f1be',2001,'GB','United Kingdom','transnational-issues',1097,'0 50 100 150 km
North
Atlantic
Ocean
The island of Roc kali
not shown.
(^Shetland
i Islands
Hebrides
Scotland
Ql^Orkney
Islands
./Aberdeen
Scotland 7
Dunde^
^{y||^sgow ‘Edinb''brah
h-vv O / Newcastle!
^ondc^derw ^on Tyne.V
Northerns
7^ Ireland •^Has\\ (
^ Man V
Irish (U.K.) C
North
Sea
Middlesbrough
Kingston
upon Hull
/ ^Manchester
-"■Liverpool
Celiic
Sen
England
Wales
LONDON
^ .Brisioi Dover J
./Southhampton port^outtr^'']
y - .
English Channel
Guernsey (U.K.)^ ''
Jersey (U.K.) ^ \\
" I FRANCE
V^-V _
UN
United Nations
UNAMIR
United Nations Assistance Mission for Rwanda
UNAMSIL
United Nations Mission in Sierra Leone
UNAVEM 111
United Nations Angola Verification Mission 111
UNCRO
United Nations Confidence Restoration Operation in Croatia
UNCTAD
United Nations Conference on Trade and Development
UNDCP
United Nations Drug Control Program
UNDOF
United Nations Disengagement Observer Force
UNDP
United Nations Development Program
UNEP
United Nations Environment Program
UNESCO
United Nations Educational, Scientific, and Cultural Organization
UNFICYP
United Nations Peace-keeping Force in Cyprus
UNHCR
United Nations High Commissioner for Refugees
UNHCRHR
United Nations High Commissioner for Human Rights
UNICEF
United Nations Children''s Fund
UNICRI
United Nations Interregional Crime and Justice Research Institute
UNIDIR
United Nations Disarmament Research
UNIDO
United Nations Industrial Development Organization
UNIFIL
United Nations Interim Force in Lebanon
UNIKOM
United Nations Iraq-Kuwait Observation Mission
573
Appendix A: Abbreviations (continued)
UNITAR
United Nations Institute for Training and Research
UNMEE
United Nations Mission in Ethiopia and Eritrea
UNMIBH
United Nations Mission in Bosnia and Herzegovina
UNMIK
United Nations Interim Administration Mission in Kosovo
UNMOGIP
United Nations Military Observer Group in India and Pakistan
UNMOP
United Nations Mission of Observers in Prevlaka
UNMOT
United Nations Mission of Observers in Tajikistan
UNMOVIC
United Nations Monitoring and Verification Commission
UNOMIG
United Nations Observer Mission in Georgia
UNOMSIL
United Nations Mission of Observers in Sierra Leone
UNRISD
United Nations Research Institute for Social Development
UNRWA
United Nations Relief and Works Agency for Palestine Refugees in the Near East
UNSMIH
United Nations Support Mission in Haiti
UNTAET
United Nations Transitional Administration in East Timor
UNTSO
United Nations Truce Supervision Organization
UNU
United Nations University
UPU
Universal Postal Union
US
UK
GB
GBR
826
.uk
ISO includes Guernsey, Isle of Man,
49 52N
6 27W
Bismarck Archipelago (island group)
54 00 N
2 00W
British Bechuanaland (region; former name for
northwest South Africa)
52 30N
1 30W
English Channel
Atlantic Ocean
1 OOW
Eniwetok Atoll (see Enewetak Atoll)
54 00 N
2 00W
Great Channel
Indian Ocean
6 25 N
94 20 E
Great Inagua (island)
The Bahamas
21 00 N
73 20 W
Great Rift Valley
Ethiopia, Kenya
0 30N
36 00 E
Greater Sunda Islands
Brunei, Indonesia, Malaysia
2 00S
11000E
Green Islands
56 30 N
6 20W
Inner Mongolia (Nei Mongol) (region)
51 30 N
010W
Longyearbyen (town)
Svalbard
7813N
15 33E
Lord Howe Island
54 40 N
6 45W
Northern Rhodesia (former name for Zambia)
59 00 N
300W
Oslo (capital)
5745N
7 00W
Outer Mongolia (region)
57 35N
13 48W
Rodrigues (island)
57 00 N
4 00W
Scott Island
1 30 W
Shikoku (island)
52 SON
330W
Wallis Islands','913732f4fae62996542df9d8d7793a3a92ea337dbad58007d30ad6c99a486045','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e7dfbbca93a8e7b7dd31d96ce4c6e2b58d13b4788c29e6b66b5dc797bba5068',2001,'UY','Uruguay','transnational-issues',1100,'Background: A violent Marxist urban guerrilla
movement, the Tupamaros, launched in the late
1960s, led Uruguay''s president to agree to military
control of his administration in 1973. By the end of the
year the rebels had been crushed, but the military
continued to expand its hold throughout the
government. Civilian rule was not restored until 1985.
Uruguay''s political and labor conditions are among the
freest on the continent.
Disputes - international: none
535
United Nations Organization Mission in the
Democratic Republic of the Congo (MONUC)
esfaW/s/ied— 30 November 1999
aim—io establish contacts with the signatories
to the cease-fire agreement and to plan for the
observation of the cease-fire and
disengagement of forces
members— {35) Algeria, Bangladesh, Belgium, Benin, Bolivia, Burkina Faso, Canada, Czech Republic, Denmark,
Egypt, France, Ghana, India, Jordan, Kenya, Libya, Malaysia, Mali, Morocco, Nepal, Niger, Nigeria, Pakistan, Peru,
Poland, Romania, Russia, Senegal, South Africa, Switzerland, Tunisia, Ukraine, UK, Tanzania, Uruguay, Zambia
604
Appendix B: International Organizations and Groups (continued)
United Nations Peace-keeping Force in
Cyprus (UNFICYP)
members— (10) Argentina, Austria, Canada, Finland, Hungary, Ireland, Nepal, Netherlands, Slovenia, UK
established— 4 March 1964
a/m— to serve as a peacekeeping force between
Greek Cypriots and Turkish Cypriots in Cyprus;
estabiished by the UN Security Councii
United Nations Population Fund (UNFPA)
members (executive board )-{3&) selected on a rotating basis from all regions
note— acronym retained from predecessor
organization UN Fund for Population Activities
established— July 1967
a/m— to assist both developed and developing
countries to deal with their population problems
United Nations Preventive Deployment Force
(UNPREDEP)
established 31 March 1995; to monitor border activity in the Former Yugoslav Republic of Macedonia; members
were Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Finland, Ghana,
Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Sweden,
Switzerland, Turkey, Ukraine, US; mandate ended 25 March 1999
United Nations Relief and Works Agency
for Palestine Refugees in the Near East
(UNRWA)
members (advisory commission) — (10) Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria, Turkey, UK, US
established— 8 December 1949
aim-Ao provide assistance to Palestinian
refugees
United Nations Research institute for Social
Development (UNRISD)
members-Hio country members, but a Board of Directors consisting of a chairman appointed by the UN secretary
general and 1 1 individual members
established— 1963
a/m— to conduct research into the problems of
economic development during different phases
of economic growth
United Nations Secretariat
members— the UN Secretary General and staff
established— 28 June 1945
effective— 24 October 1945
a/m— to serve as the primary administrative
organ of the UN; a Secretary General is
appointed for a five-year term by the General
Assembly on the recommendation of the
Security Council
United Nations Security Council
established— 28 June 1945
effective— 24 October 1945
a/m— to maintain international peace and
security
permanent members— (5) China, France, Russia, UK, US
nonpermanent members— (^ 0) elected for two-year terms by the UN General Assembly; Bangladesh (2000-01 ),
Colombia (2001 -02), Ireland (2001 -02), Jamaica (2000-01 ), Mali (2000-01 ), Mauritius (2001 -02), Norway (2001 -02),
Singapore (2001-02), Tunisia (2000-01), Ukraine (2000-01)
United Nations Transitional Administration
in East Timor (UNTAET)
established— 28 October 1999
a/m— to provide security throughout the territory
of East Timor; to establish an effective
administration; to ensure the coordination and
delivery of humanitarian assistance; to support
capacity-building for self-government
members-(47) Australia, Austria, Bangladesh, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Canada, Cape
Verde, Chile, China, Denmark, Egypt, Fiji, France, Ghana, Ireland, Jordan, Kenya, South Korea, Malaysia,
Mozambique, Namibia, Nepal, NZ, Nigeria, Norway, Pakistan, Peru, Philippines, Portugal, Russia, Senegal,
Singapore, Slovenia, Spain, Sri Lanka, Sweden, Thailand, Turkey, Ukraine, UK, US, Uruguay, Vanuatu, Zambia,
UY
UY
URY
858
.uy
34 53S
5611 W
Montreal (city)','30799fbbb075efe1a128625d0bba0ae87ba346694fb00c2d604691f4af639de5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d133c0e0a761d543679142f2f2c90d245e84244ce0f15b4bfe4fd8160694d43b',2001,'AF','Afghanistan','transnational-issues',1115,'Illicit drugs: limited illicit cultivation of cannabis and
very small amounts of opium poppy, mostly for
domestic consumption, almost entirely eradicated by
an effective government eradication program;
increasingly used as transshipment point for illicit
drugs from Afghanistan to Russia and Western
Europe and for acetic anhydride destined for
Background: The British and French who settled the
New Hebrides in the 19th century, agreed in 1906 to
an Anglo-French Condominium, which administered
the islands until independence in 1980.
Disputes - international: claims all of Guyana west
of the Essequibo (river); maritime boundary dispute
with Colombia in the Gulf of Venezuela
Illicit drugs: illicit producer of opium for the
international drug trade on a small scale; however,
large quantities of cocaine, heroin, and marijuana
transit the country from Colombia bound for US and
Europe; important money-laundering center; active
eradication program primarily targeting opium;
increasing signs of drug-related activities by
Colombian insurgents on border
542
IIIIIQI
Background: France occupied all of Vietnam by
1 884. Independence was declared after World War II,
but the French continued to rule until 1954 when they
were defeated by communist forces under Ho Chi
MINH, who took control of the north. US economic and
military aid to South Vietnam grew through the 1 960s
in an attempt to bolster the government, but US armed
forces were withdrawn following a cease-fire
agreement in 1 973. Two years later North Vietnamese
forces overran the south. Economic reconstruction of
the reunited country has proven difficult as aging
Communist Party leaders have only grudgingly
initiated reforms necessary for a free market.
Disputes - international: maritime boundary with
Cambodia not defined; involved in a complex dispute
over the Spratly Islands with China, Malaysia,
Philippines, Taiwan, and possibly Brunei; maritime
boundary agreement with China in the Gulf of Tonkin
awaits ratification; Paracel Islands occupied by China
but claimed by Vietnam and Taiwan; portions of
boundary with Cambodia are in dispute; agreement
on land border with China was signed in December
1 999, but details of alignment have not yet been made
public
Illicit drugs: minor producer of opium poppy with
2,100 hectares cultivated in 1999, capable of
producing 1 1 metric tons of opium; probable minor
transit point for Southeast Asian heroin; opium/heroin/
methamphetamine addiction problems
Virgin Islands
(territory of the US)
Background: During the 17th century, the
archipelago was divided into two territorial units, one
English and the other Danish. Sugarcane, produced
by slave labor, drove the islands'' economy during the
18th and early 19th centuries. In 1917, the US
purchased the Danish portion, which had been in
economic decline since the abolition of slavery in
1848.
AF
C
AFG
004
.af
33 00 N
65 00 E
Agalega Islands
34 31 N
6912E
Kaduna (city)
37 00N
73 00E
Valletta (capital)
37 DON
73 00 E
Walachia (region)','e07cd59507b76bab297195ec8d2b7df402998830f3ca84dfeadcdabcd65f29c9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e21a280c9643ceaede1aac77eb0653992cbe8c9863069c082f3c538798e98ef8',2001,'YE','Yemen','transnational-issues',1140,'Disputes ■ international: a June 2000 treaty
delimited the boundary with Saudi Arabia, but final
demarcation requires adjustments based on tribal
considerations
Disputes - international: Albanian majority in
Kosovo seeks independence from Yugoslavia;
Croatia and Yugoslavia are negotiating the status of
the strategically important Prevlaka Peninsula, which
is currently under a UN military observer mission
(UNMOP); the February 2001 agreement with the
Former Yugoslav Republic of Macedonia settled
alignment of boundary, stipulating implementation
within two years
Illicit drugs: transshipment point for Southwest
Asian heroin moving to Western Europe on the Balkan
route
YM
YE
YEM
887
■ye
Yugoslavia
—
YU
YUG
891
.yu
Zaire
—
—
—
—
—
see Democratic Republic of the Congo
1246N
45 01 E
Aden, Gulf of
Indian Ocean
12 30N
48 00E
Admiralty Island
United States (Alaska)
5744N
134 20 W
Admiralty Islands
15 00N
48 00E
Aland Islands
15 00N
50 00 E
Hagatna (Agana) (capital)
1521 N
42 34 E
Kamchatka Peninsula (Poluostrov Kamchatka)
Russia
56 00N
160 00 E
Kampala (capital)
15 00N
44 00 E
Northeast Providence Channel
Atlantic Ocean
25 40 N
77 09W
Northern Cyprus (region)
12 39N
43 25 E
Perouse Strait, La
Pacific Ocean
44 45 N
142 00 E
Persia (former name for Iran)
Iran
32 00 N
53 00 E
Persian Gulf
Indian Ocean
27 00 N
51 00 E
Pescadores (islands)
Taiwan
23 30 N
11930 E
Peter 1 Island
HIHSEHI
4412E
Sandzak (region)
Yugoslavia
19 45E
Santa Cruz (city)
Bolivia
63 low
Santa Cruz Islands
12 30N
54 00 E
Sofia (capital)
14 00N
48 00 E
Southern Grenadines (island group)
14 00N
46 00 E
Yemen (Sanaa) (Yemen Arab Republic) (former name for
northern portion of Yemen)
15 00N
44 00 E
Yemen Arab Republic (former name for northern portion
of Yemen)
15 00N
44 00 E
Yemen, North (Yemen Arab Republic) (former name for
northern portion of Yemen)
15 00N
44 00 E
Yemen, People''s Democratic Republic of (former name
for southern portion of Yemen)
14 00N
46 00 E
Yemen, South (People''s Democratic Republic of Yemen)
(former name for southern portion of Yemen)
MOON
46 00 E
657
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Yerevan (capital)','272729ad9cf1f2a6bd63f6bbb89f75864206de1b6d96d0c0b04ff6d9d7357a08','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf9013c305e062b0ac17428b29421fe319b8bd38fece493ff2c6d301e4c4343',2001,'ZM','Zambia','transnational-issues',1150,'Illicit drugs; transshipment point for moderate
amounts of methaqualone, small amounts of heroin,
and cocaine bound for Southern Africa and possibly
Europe; regional money-laundering center
562
Zimbabwe i
h
Background: The UK annexed Southern Rhodesia
from the South Africa Company in 1923. A 1961
constitution was formulated to keep whites in power.
In 1965 the government unilaterally declared its
independence, but the UK did not recognize the act
and demanded voting rights for the black African
majority in the country (then called Rhodesia). UN
sanctions and a guerrilla uprising finally led to free
elections in 1 979 and independence (as Zimbabwe) in
1980. Robert MUGABE, the nation''s first prime
minister, has been the country''s only ruler (as
president since 1987) and has dominated the
country''s political system since independence.
countries that have signed, but not yet ratified— (3) Afghanistan, Haiti, US
Biodiversity
see Convention on Biological Diversity
Convention for the Conservation of Antarctic
Seals
nofe— abbreviated as Antarctic Seals
opened for signature— N A
entered into force— HA
objective— HA
parties— {^3) Argentina, Australia, Belgium, Brazil, Canada, Chile, France, Germany, Italy, Japan, Norway, Poland,
Russia, South Africa, UK, US
countries that have signed, but not yet ratified— {1 ) NZ
610
Appendix C: Selected International Environmental Agreements (continued)
Convention on Biological Diversity
nofe— abbreviated as Biodiversity
opened for signature— 6 June 1 992
entered into force— 29 December 1993
objective— {0 develop national strategies for the
conservation and sustainable use of biological
diversity
parties— (180) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (7) Afghanistan, Kuwait, Libya, Thailand, Tuvalu, US, Yugoslavia
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
Convention on Fishing and Conservation of
Living Resources of the High Seas
note— abbreviated as Marine Life Conservation
opened for signature— 29 April 1958
entered into force— 20 March 1966
objective~Ao solve through international
cooperation the problems involved in the
conservation of living resources of the high seas,
considering that because of the development of
modern technology some of these resources are
in danger of being overexploited
parties— (38) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark,
Dominican Republic, Fiji, Finland, France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra Leone, Solomon Islands, South Africa, Spain,
Switzerland, Thailand, Tonga, Trinidad and Tobago, Uganda, UK, US, Uruguay, Venezuela, Yugoslavia
countries that have signed, but not yet ratified— (21) Afghanistan, Argentina, Bolivia, Canada, China, Costa Rica,
Cuba, Ghana, Iceland, Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka,
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
613
Appendix C; Selected International Environmental Agreements (continued)
Montreal Protocol on Substances That
Deplete the Ozone Layer
note—abbreviated as Ozone Layer Protection
opened for signature— September 1987
entered into force— ^ January 1989
objective-io protect the ozone layer by
controlling emissions of substances that
deplete it
parties— (175) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution
From Ships, 1973 (MARPOL)
no/e— abbreviated as Ship Pollution
opened for signature— 17 February 1978
entered into force— 2 October 1983
objective— (0 preserve the marine environment
through the complete elimination of pollution by
oil and other harmful substances and the
minimization of accidental discharge of such
substances
parties— (115) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Barbados, Belarus,
Belgium, Belize, Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile, China, Colombia,
Comoros, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, Equatorial Guinea, Estonia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Guatemala, Guyana, Hong Kong (associate member), Hungary, Iceland, India, Indonesia, Ireland, Israel,
Italy, Jamaica, Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia, Lithuania,
Luxembourg, Malaysia, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Monaco, Morocco, Netherlands, NZ,
Nicaragua, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru, Poland, Portugal, Romania, Russia, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Senegal, Seychelles,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yugoslavia
Protocol on Environmental Protection to the
Antarctic Treaty
no/e— abbreviated as Antarctic-Environmental
Protocol
opened for signature— ^ October 1991
entered into force— U January 1998
objective— \\o provide for comprehensive
protection of the Antarctic environment and
dependent and associated ecosystems; applies
to the area covered by the Antarctic Treaty
parties— (27) Argentina, Australia, Belgium, Brazil, Bulgaria, Chile, China, Ecuador, Finland, France, Germany,
India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain, Sweden, UK,
US, Uruguay
countries that have signed, but not yet ratified— (15) Austria, Canada, Colombia, Cuba, Czech Republic, Denmark,
Greece, Guatemala, Hungary, North Korea, Papua New Guinea, Romania, Slovakia, Switzerland, Turkey, Ukraine
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of
Nitrogen Oxides or Their Transboundary
Fluxes
parties— (23) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, EU, Finland,
France, Germany, Greece, Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia,
Slovakia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified— (1 ) Poland
/70/e— abbreviated as Air Pollution-Nitrogen
Oxides
opened for signature— 31 October 1988
entered into force— 14 February 1991
objective— {0 provide for the control or reduction
of nitrogen oxides and their transboundary
fluxes
614
Appendix C: Selected International Environmental Agreements (continued)
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of
Volatile Organic Compounds or Their
Transboundary Fluxes
note^bbreviated as Air Pollution-Volatile
Organic Compounds
opened for signature— November 1991
entered into force— 29 September 1 997
objective~Ao provide for the control and
reduction of emissions of volatile organic
compounds in order to reduce their
transboundary fluxes so as to protect human
health and the environment from adverse effects
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
note— abbreviated as Air Pollution-Sulphur 94
opened for signature— ^ 4 ^\\une 1994
entered into force— 5 August 1 998
objective— {0 provide for a further reduction In
sulfur emissions or transboundary fluxes
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
Persistent Organic Pollutants
note— abbreviated as Air Pollution-Persistent
Organic Pollutants
opened for signature— 24 June 1 998, but not yet
in force
objective— \\o provide for the control and
reduction of emissions of persistent organic
pollutants in order to reduce their transboundary
fluxes so as to protect human health and the
environment from adverse effects
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30%
note— abbreviated as Air Pollution-Sulphur 85
opened for signature— 8 July 1985
entered into force— 2 September 1 987
objective— to provide for a 30% reduction in
sulfur emissions or transboundary fluxes by
1993
Ship Pollution see Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973
(MARPOL)
parties— (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, Finland, France,
Germany, Hungary, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden, Switzerland,
ZA
ZM
ZWB
894
.zm
15 25S
2817E
Luxembourg (capital)
15 00S
30 00 E
Northwest Passages
Arctic Ocean
74 40 N
100 00 W
646
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Northwest Territories (region)
1500S
30 00 E
Rhodesia, Southern (former name for Zimbabwe)','19c29980063109a694681540c2daa55f124e66fa54ec6327713068a180058e7d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('245835e974b2022ee7bf08befa5bb618b6070660890bf64931815566a68a0510',2001,'SE','Sweden','transnational-issues',1151,'Council of the Entente (Entente)
members— {5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
established— 29 May 1959
a/m— to promote economic, social, and political
coordination
countries in transition
a term used by the International Monetary FUND (IMF) for the middle group in its hierarchy of advanced economies,
countries in transition, and developing countries; recently published IMF statistics include the following 28 countries
in transition: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic,
Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Moldova, Mongolia, Poland, Romania, Russia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan, Yugoslavia; note— this group is identical to the group traditionally referred to as the "former USSR/
Eastern Europe" except for the addition of Mongolia
Customs Cooperation Council (CCC)
note— also known as World Customs
Organization (WCO)
established— 15 December 1950
a/m— to promote international cooperation in
customs matters
members— {153) Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bangladesh, Barbados, Belarus, Belgium, Benin, Bermuda, Bolivia, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cameroon, Canada, Cape Verde, Central African Republic, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Ecuador, Egypt, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Haiti, Hong Kong, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia,
sw
SE
SWE
752
.se
57 43N
11 58 E
Gotland (island)
57 30N
18 33 E
Gough Island
Saint Helena
4010S
9 45W
Graham Land (region)
5645N
16 40E
Oman, Gulf of
Indian Ocean
24 SON
58 30E
Ombai Strait
Pacific Ocean
8 30S
125 00 E
Oran (city)
5920N
18 03E
Stuttgart (city)
62 00 N
15 00E
Svizzera (local Italian name for Switzerland)','20e308393d866756cd50bb145aa213140e394f916b69c7b90e0a56c5e219343c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e608b9924a757c6de1e502feea193d675d1c629cb77bc8a2bcd4987893f744b3',2001,'ZW','Zimbabwe','transnational-issues',1152,'developed countries (DCs)
the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and
less developed countries (LDCs); includes the market-oriented economies of the mainly democratic nations in the
Organization for Economic Cooperation and Development (OECD), Bermuda, Israel, South Africa, and the
European ministates; also known as the First World, high-income countries, the North, industrial countries; generally
have a per capita GDP in excess of $1 0,000 although four OECD countries and South Africa have figures well under
$10,000 and two of the excluded OPEC countries have figures of more than $10,000; the 35 DCs are: Andorra,
Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy
See, Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Mexico, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US; note— similar to the new
Internationa! Monetary Fund (IMF) term "advanced economies" which adds Hong Kong, South Korea, Singapore,
and Taiwan but drops Malta, Mexico, South Africa, and Turkey
580
Appendix B: International Organizations and Groups (continued)
developing countries a term used by the International Monetary Fund (IMF) for the bottom group in its hierarchy of advanced economies,
countries in transition, and developing countries; recently published IMF statistics include the following 126
developing countries: Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya,
Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique, Namibia,
Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa,
Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
DAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; nofe^his category would
presumably also cover the following 46 other countries that are traditionally included in the more comprehensive
group of "less developed countries": American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands,
Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia,
Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of
Man, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands,
Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and
Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara _
East African Development Bank (EADB) members— (3) Kenya, Tanzania, Uganda
established— 6 June 1967
effective— ^ December 1967
a/m— to promote economic development
Economic and Social Council (ECOSOC) members— (54) selected on a rotating basis from all regions
established— 25 June 1945
effective— 24 October 1 945
a/m— to coordinate the economic and social
work of the UN; includes five regional
commissions (Economic Commission for Africa,
Economic Commission for Europe, Economic
Commission for Latin America and the
Caribbean, Economic and Social Commission
for Asia and the Pacific, Economic and Social
Commission for Western Asia) and 9 functional
commissions (Commission for Social
Development, Commission on Human Rights,
Commission on Narcotic Drugs, Commission on
the Status of Women, Commission on
Population and Development, Statistical
Commission, Commission on Science and
Technology for Development, Commission on
Sustainable Development, and Commission on
Crime Prevention and Criminal Justice) _ _
Economic Community of the Great Lakes members— (3) Burundi, Democratic Republic of the Congo, Rwanda
Countries (CEPGL)
note— acronym from Communaute Economique
des Pays des Grands Lacs
established— 20 September 1976
a/m— to promote regional economic cooperation
and integration
581
Appendix B: International Organizations and Groups (continued)
Economic Community of West African States
(ECOWAS)
members— (16) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The Gambia, Ghana, Guinea, Guinea-Bissau,
Liberia, Mali, Mauritania, Niger, Nigeria, Senegal, Sierra Leone, Togo
established— 28 May 1 975
aim—{o promote regional economic cooperation
Economic Cooperation Organization (ECO)
established— 27-29 January 1 985
a/m— to promote regional cooperation in trade,
transportation, communications, tourism,
cultural affairs, and economic development
members— (^0) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan, Turkey, Turkmenistan,
members— (15 judges) elected by the UN General Assembly and Security Council to represent all principal legal
systems
members— (178) Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
subbureaus— {1^) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Gibraltar, Guam,
Hong Kong, Macau, Montserrat, Northern Mariana Islands, Puerto Rico, Turks and Caicos Islands, Virgin Islands
588
Appendix B: International Organizations and Groups (continued)
members— (W)
Part /— (27 developed countries) Australia, Austria, Belgium, Canada, Denmark, EU, Finland, France, Germany,
Iceland, Ireland, Italy, Japan, Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South Africa, Spain,
Sweden, Switzerland, UAE, UK, US
Part //-{134 less developed countries) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Azerbaijan,
Bangladesh, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech
Republic, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan, Kazakhstan, Kenya, Kiribati, South
Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone,
Slovakia, Slovenia, Solomon Islands, Somalia, Sri Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia,
International Energy Agency (lEA) members— {25) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden,
established— ^ 5 November 1 974 Switzerland, Turkey, UK, US
a/m— to promote cooperation on energy observers— (^5) Commission of the European Communities, Iceland, South Korea, Mexico, Poland
matters, especially emergency oil sharing and
relations between oil consumers and oil
producers; established by the OECD
International Federation of Red Cross and
Red Crescent Societies (IFRCS)
note— formerly known as League of Red Cross
and Red Crescent Societies (LORCS)
established— 5 May 1919
a/m— to organize, coordinate, and direct
international relief actions; to promote
humanitarian activities; to represent and
encourage the development of National
Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to
reduce the vulnerability of people through
development programs
members— (176) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
associate members— {A) Comoros, Cyprus, Gabon, Tuvalu
Internationa! Development Association (IDA)
established— 26 January 1960
effective— 24 September 1960
a/m— UN specialized agency and IBRD affiliate
that provides economic loans for low-income
countries
589
Appendix B: International Organizations and Groups (continued)
International Finance Corporation (IFC)
established— 25 May 1 955
effective— 2A July 1956
a/m— to support private enterprise in
international economic development; a UN
specialized agency and IBRD affiliate
International Fund for Agricultural
Development (IFAD)
established— November 1974
a/m— to promote agricultural development; a UN
specialized agency
International Hydrographic Organization
(IHO)
note-^iame changed from International
Hydrographic Bureau on 22 September 1970
established-^A June 1 91 9
effective— HA June 1921
a/m— to train hydrographic surveyors and
nautical cartographers to achieve
standardization in nautical charts and electronic
chart displays; to provide advice on nautical
cartography and hydrography; to develop the
sciences in the field of hydrography and
techniques used for descriptive oceanography
members— (174) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Samoa, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
members— (161)
Category 1-^22 industrialized aid contributors) Australia, Austria, Belgium, Canada, Denmark, Finland, France,
Germany, Greece, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden,
Switzerland, UK, US
Category //—(1 2 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Category ///— (127 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia,
Azerbaijan, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Nicaragua, Niger, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Uruguay, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
members— {SB) Algeria, Argentina, Australia, Bahrain, Belgium, Brazil, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Ecuador, Egypt, Estonia,
Fiji, Finland, France, Germany, Greece, Guatemala, Iceland, India, Indonesia, Iran, Italy, Japan, North Korea, South
Korea, Malaysia, Monaco, Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Papua New
Guinea, Peru, Philippines, Poland, Portugal, Russia, Singapore, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Syria, Thailand, Tonga, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela,
Yugoslavia
membership pending— (5) Bangladesh, Bulgaria, Jamaica, Mauritania, Qatar
590
Appendix B: International Organizations and Groups (continued)
International Labor Organization (ILO)
estabHshed~2S June 1919 set up as part of
Treaty of Versailles; 1 1 April 1919 became
operative: 14 December 1946 affiliated with the
UN
a/m— to deal with world labor issues; a UN
specialized agency
International Maritime Organization (IMO)
note— name changed from Intergovernmental
Maritime Consultative Organization (IMCO) on
22 May 1982
established^ March 1948 set up as the
Inter-Governmental Maritime Consultative
Organization
e/fecf/Ve— 17 March 1958
a/m— to deal with international maritime affairs;
a UN specialized agency
International Mobile Satellite Organization
(Inmarsat)
note— formerly International Maritime Satellite
Organization
established— 3 September 1976
e/fecf/Ve— 16 July 1979
a/m— to provide worldwide communications for
commercial, distress, and safety applications, at
sea, in the air, and on land
members— (MS) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe
members— (158) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Brunei,
Bulgaria, Burma, Cambodia, Cameroon, Canada, Cape Verde, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, Ei Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Ukraine, UAE, UK, US, Uruguay,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia
associate members— (2) Hong Kong, Macau
members— (SS) Algeria, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Bosnia and
Herzegovina, Brazil, Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Costa Rica, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Egypt, Finland, France, Gabon, Georgia, Germany, Ghana, Greece, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Israel, Italy, Japan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia,
Malaysia, Malta, Marshall Islands, Mauritius, Mexico, Monaco, Mozambique, Netherlands, NZ, Nigeria, Norway,
Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal,
Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Tanzania, Thailand, Tunisia, Turkey,
Ukraine, UAE, UK, US, Vietnam, Yugoslavia
591
Appendix B: International Organizations and Groups (continued)
International Monetary Fund (IMF)
established— 22 July 1944
effective— 27 December 1945
a/m— to promote world monetary stability and
economic development; a UN specialized
agency
International Olympic Committee (IOC)
established— 23 June 1894
a/m— to promote the Olympic ideals and
administer the Olympic games: 2002 Winter
Olympics in Salt Lake City, United States; 2004
Summer Olympics in Athens, Greece; 2006
W','c9a488f01026a0ffe44f30810056f1dc0173085eba6d3c2c3766506aec21ac38','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ed3ddbf6d133074378f5b58e755b017f3deaf8db3f68284f0edbe4a05cd40f8',2001,'ZW','Zimbabwe','transnational-issues',1153,'inter Olympics in Turin, Italy
International Organization for Migration
(lOM)
nofe— established as Provisional
Intergovernmental Committee for the Movement
of Migrants from Europe; renamed
Intergovernmental Committee for European
Migration (ICEM) on 15 November 1952;
renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current
name adopted 14 November 1989
established— 6 December 1951
a/m— to facilitate orderly international emigration
and immigration
members— (m) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, SaoTome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
National Olympic Committees— (^39 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria,
American Samoa, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Virgin Islands, Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization _
members— (79) Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Bangladesh, Belgium, Belize,
Benin, Bolivia, Bulgaria, Burkina Faso, Canada, Chile, Colombia, Costa Rica, Cote d''Ivoire Croatia, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Finland, France, Germany, Greece,
Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Israel, Italy, Japan, Jordan, Kenya, South Korea,
Kyrgyzstan, Latvia, Liberia, Lithuania, Luxembourg, Mali, Morocco, Netherlands, Nicaragua, Norway, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Senegal, Slovakia, Slovenia, South Africa, Sri
Lanka, Sudan, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Tunisia, Uganda, US, Uruguay, Venezuela,
Yemen, Zambia
observers-(A3) Afghanistan, Belarus, Bhutan, Bosnia and Herzegovina, Brazil, Cambodia, Cape Verde,
Democratic Republic of the Congo, Republic of the Congo, Cuba, Estonia, Ethiopia, Georgia, Ghana, Holy See,
India, Indonesia, Iran, Ireland, Jamaica, Kazakhstan, The Former Yugoslav Republic of Macedonia, Madagascar,
Malta, Mexico, Moldova, Mozambique, Namibia, NZ, Papua New Guinea, Russia, Rwanda, San Marino, Sao Tome
and Principe, Somalia, Spain, Turkey, Turkmenistan, Ukraine, UK, Vietnam, Yugoslavia, Zimbabwe
Appendix B: International Organizations and Groups (continued)
members— {9^ national standards organizations) Algeria, Argentina, Armenia, Australia, Austria, Bangladesh,
Barbados, Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Canada, Chile, China, Colombia,
Costa Rica, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, Ethiopia, Finland, France, Germany,
Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya,
North Korea, South Korea, Kuwait, Libya, Luxembourg, The Former Yugoslav Republic of Macedonia, Malaysia,
Malta, Mauritius, Mexico, Mongolia, Morocco, Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Philippines,
Poland, Portugal, Romania, Russia, Saudi Arabia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yugoslavia, Zimbabwe
corresponderit members— (34) Albania, Azerbaijan, Bahrain, Bolivia, Brunei, Cameroon, Democratic Republic of
the Congo, Cote d''Ivoire, El Salvador, Estonia, Guatemala, Honduras, Hong Kong, Jordan, Kyrgyzstan, Latvia,
Lebanon, Lithuania, Madagascar, Malawi, Moldova, Mozambique, Namibia, Nepal, Nicaragua, Oman, Papua New
Guinea, Paraguay, Peru, Qatar, Rwanda, Sudan, Turkmenistan, Uganda
subscriber members— (^^) Benin, Burkina Faso, Cambodia, Comoros, Dominican Republic, Fiji, Grenada, Guyana,
Lesotho, Mali, Saint Lucia
International Red Cross and Red Crescent National Societies— (M3 countries); note— same as membership for International Federation of Red Cross and Red
Movement (ICRM) Crescent Societies (IFRCS)
established— NA 1928
aim-Ao promote worldwide humanitarian aid
through the International Committee of the Red
Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent
Societies (IFRCS; formerly League of Red
Cross and Red Crescent Societies or LORCS) in
peacetime
International Telecommunication Union (ITU)
established— M May 1865 set up as the
International Telegraph Union; 9 December
1932 adopted present name
effective— ^ January 1934; affiliated with the
UN— 15 November 1947
a/m— to deal with world telecommunications
issues; a UN specialized agency
members— (189) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
International Organization for
Standardization (ISO)
established-^k February 1947
aim— to promote the development of
international standards with a view to facilitating
international exchange of goods and services
and to developing cooperation in the sphere of
intellectual, scientific, technological and
economic activity
593
Appendix B: International Organizations and Groups (continued)
International Telecommunications Satellite
Organization (Intelsat)
established--20 August 1964 set up as the
Telecommunications Satellite Consortium;
12 February 1973 adopted present name
a/m— to develop and operate a global
commercial telecommunications satellite system
Islamic Development Bank (IDB)
esfab//s/?ed— 15 December 1973 by declaration
of intent
effective— 1 2 August 1 974
aim—{o promote Islamic economic aid and
social development
Latin American Economic System (LAES)
note— also known as Sistema Economico
Latinoamericana (SELA)
established— M October 1975
a/m— to promote economic and social
development through regional cooperation
Latin American Integration Association
(LAIA)
note— also known as Asociacion
Latinoamericana de Integracion (ALADI)
established— ^2 August 1980
effective— March 1981
a/m— to promote freer regional trade
least developed countries (LLDCs)
members— (143) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia,
Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guatemala, Guinea, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
Kuwait, Kyrgyzstan, Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal,
Singapore, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
nonsignatory users— {42) Albania, Antigua and Barbuda, Belarus, Belize, Burma, Burundi, Cambodia, Cook
Islands, Cuba, Djibouti, Eritrea, The Gambia, Guinea-Bissau, Guyana, Kiribati, North Korea, Laos, Latvia, Lesotho,
Liberia, Lithuania, The Former Yugoslav Republic of Macedonia, Maldives, Marshall Islands, Moldova, Nauru, Niue,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Seychelles, Sierra Leone, Slovakia,
Slovenia, Solomon Islands, Suriname, Tonga, Turkmenistan, Tuvalu, Ukraine, Vanuatu _
members— (52 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra
Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen,
Palestine Liberation Organization
members — (28) Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba,
Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico,
Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and Tobago, Uruguay, Venezuela
observers— (21) Andean Promotion Corporation, China, Costa Rica, Dominican Republic, El Salvador, EEC,
Guatemala, Honduras, lADB, Inter-American Institute for Agricultural Cooperation, Italy, Nicaragua, OAS, Panama,
Portugal, Romania, Russia, Spain, Switzerland, UN Development Program, UN Economic Commission for Latin
America and the Caribbean _ _
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador, Mexico, Paraguay, Peru, Uruguay,
Venezuela
observers— {22} China, Commission of the European Communities, Corporacion Andina de Fomento, Costa Rica,
Dominican Republic, El Salvador, Guatemala, Honduras, Inter-American Development Bank, Inter-American
Institute for Cooperation on Agriculture, Italy, Latin America Economic System, Nicaragua, Organization of American
States, Panama, Portugal, Romania, Russia, Spain, Switzerland, United Nations Development Program, United
Nations Economic Commission for Latin America and the Caribbean
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as
having no significant economic growth, per capita GDPs normally less than $1 ,000, and low literacy rates; also
known as the undeveloped countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Botswana,
Burkina Faso, Burma, Burundi, Cape Verde, Central African Republic, Chad, Comoros, Djibouti, Equatorial Guinea,
Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho, Malawi, Maldives, Mali,
Mauritania, Mozambique, Nepal, Niger, Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
Appendix B: International Organizations and Groups (continued)
less developed countries (LDCs)
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent areas with low levels of output, living
standards, and technology; per capita GDPs are generally below $5,000 and often less than $1 ,500; however, the
group also includes a number of countries with high per capita incomes, areas of advanced technology, and rapid
rates of grovrth; includes the advanced developing countries, developing countries. Four Dragons (Four Tigers),
least developed countries (LLDCs), low-income countries, middle-income countries, newly industrializing
economies (NIEs), the South, Third World, underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands, Brunei,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Cayman Islands, Central African Republic,
Chad, Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana,
French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam,
Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran, Iraq,
Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya,
Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Isle of Man, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn islands, Puerto
Rico, Qatar, Reunion, Rwanda, Saint Heiena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegai, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname, Swaziiand, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE, Uganda, Uruguay,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen, Zambia,
Zimbabwe; rrofe— similar to the new International Monetary Fund (IMF) term “developing countries" which adds
Malta, Mexico, South Africa, and Turkey but omits in its recentiy published statistics American Samoa, Anguiiia,
British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea,
Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man, Martinique, Mayotte, Montserrat, Nauru, New
Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint
Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and
Futuna, West Bank, Western Sahara
low-income countries
another term for those less developed countries with below-average per capita GDPs; see less developed countries
(LDCs)
middle-income countries
another term for those less developed countries with above-average per capita GDPs; see less developed countries
(LDCs)
Monetary and Economic Community of
Central Africa (CEMAC)
note— ^as formerly the Central African Customs
and Economic Union (UDEAC)
established— 8 December 1964
effective— 1 January 1966
a/m— to promote the establishment of a Central
African Common Market
members-i6) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, Gabon
Near Abroad
Russian term for the 14 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in
which Moscow has expressed a strong national security interest; the 14 countries are Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,
United Nations Interim Force in Lebanon
(UNIFIL)
members— (10) Fiji, Finland, France, Ghana, India, Ireland, Italy, Nepal, Poland, Ukraine
established— ]9 March 1978
aim—{o confirm the withdrawal of Israeli forces,
and assist in reestablishing Lebanese authority
in southern Lebanon; established by the UN
Security Council
United Nations Iraq-Kuwait Observation
Mission (UNIKOM)
established— Q April 1991
a/m— to observe and monitor the demilitarized
zone established between Iraq and Kuwait;
established by the UN Security Council
members— (33) Argentina, Austria, Bangladesh, Canada, China, Denmark, Fiji, Finland, France, Germany, Ghana,
Greece, Hungary, India, Indonesia, Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan, Poland, Romania, Russia,
Senegal, Singapore, Sweden, Thailand, Turkey, UK, US, Uruguay, Venezuela
United Nations Military Observer Group in
India and Pakistan (UNMOGIP)
members— (9) Belgium, Chile, Denmark, Finland, Hungary, Italy, South Korea, Sweden, Uruguay
established— 24 January 1949
a/m— to observe the 1949 India-Pakistan
cease-fire; established by the UN Security
Council
United Nations Mission for the Referendum
in Western Sahara (MINURSO)
established— 29 April 1991
a/m— to supervise the cease-fire and conduct a
referendum in Western Sahara; established by
the UN Security Council
members— (30) Argentina, Austria, Bangladesh, Belgium, China, Egypt, El Salvador, France, Ghana, Greece,
Guinea, Honduras, Hungary, India, Ireland, Italy, Jordan, Kenya, South Korea, Malaysia, Nigeria, Norway, Pakistan,
Poland, Portugal, Russia, Senegal, Sweden, US, Uruguay
United Nations Mission in Bosnia and
Herzegovina (UNMIBH)
established— 2] December 1995
a/m— to establish an International Police Task
Force (IPTF) to implement the Dayton Peace
Agreement in Bosnia and Herzegovina
members— (45) Argentina, Austria, Bangladesh, Bulgaria, Canada, Chile, Czech Republic, Denmark, Egypt,
Estonia, Fiji, Finland, France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland, Italy, Jordan,
Kenya, Malaysia, Nepal, Netherlands, Nigeria, Norway, Pakistan, Poland, Portugal, Romania, Russia, Senegal,
Spain, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, US, Vanuatu
603
Appendix B; International Organizations and Groups (continued)
United Nations Mission in Sierra Leone
(UNAMSIL)
established— 22 October 1999
aim—io cooperate with the Government of
Sierra Leone and the other parties to the Peace
Agreement in the implementation of the
agreement; to monitor the military and security
situation In Sierra Leone; to monitor the
disarmament and demobilization of combatants
and members of the Civil Defense Forces (CFD);
to assist in monitoring respect for international
humanitarian law
members— (30) Bangladesh, Bolivia, Canada, Croatia, Czech Republic, Denmark, Egypt, France, The Gambia,
Ghana, Guinea, Indonesia, Jordan, Kenya, Kyrgyzstan, Malaysia, Mali, Nepal, NZ, Nigeria, Norway, Pakistan,
Russia, Slovakia, Sweden, Thailand, Ukraine, UK, Uruguay, Zambia
United Nations Mission of Observers in
Previaka (UNMOP)
established— ^ February 1996
a/m—to monitor the demilitarization of the
Previaka peninsula in southern Croatia
members— {25) Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Eg','4915aa4a768e6766bfc307398946eaacd9b2806be5d2e87b33307f8b64c94dac','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ec8e3ff97b21b36c071e62bba5389e4dfad2f25fe78d56b8a13326c7144beb6',2001,'ZW','Zimbabwe','transnational-issues',1154,'ypt, Finland,
Ghana, Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia,
Sweden, Switzerland, Ukraine
United Nations Mission of Observers in
Tajikistan (UNMOT)
established 16 December 1994; to monitor and investigate violations of the cease-fire of 17 September 1994
between Tajikistan and the Tajik opposition and to assist In the political negotiation process; established by the UN
Security Council; members were Austria, Bangladesh, Bulgaria, Czech Republic, Denmark, Ghana, Indonesia,
Jordan, Nepal, Nigeria, Poland, Ukraine, Uruguay; mission ended May 2000
United Nations Monitoring and Verification
Commission (UNMOVIC)
members— {22) Australia, Austria, Belgium, Canada, China, Czech Republic, Finland, France, Germany, Indonesia,
Italy, Japan, Netherlands, Nigeria, Norway, Poland, Russia, Sri Lanka, Sweden, UK, US, Venezuela
nofe-— formerly known as United Nations Special
Commission for the Elimination of Iraq''s
Weapons of Mass Destruction (UNSCOM)
established— December 1999
aim-Ao identify, account for, and eliminate Iraq''s
weapons of mass destruction and the capacity
to produce them
United Nations Observer Mission in Georgia
(UNOMIG)
established— 24 August 1993
a/m— to verify compliance with the cease-fire
agreement, to monitor weapons exclusion zone,
and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security
Council
members— {22) Albania, Austria, Bangladesh, Czech Republic, Denmark, Egypt, France, Germany, Greece,
Hungary, Indonesia, Jordan, South Korea, Pakistan, Poland, Russia, Sweden, Switzerland, Turkey, UK, US,
605
Appendix B: International Organizations and Groups (continued)
United Nations Truce Supervision
Organization (UNTSO)
members— (22) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark, Estonia, Finland, France,
Ireland, Italy, Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
established— HA June 1948
aim—io supervise the 1948 Arab-lsraeli
cease-fire; currently supports timely deployment
of reinforcements to other peacekeeping
operations In the region as needed; initially
established by the UN Security Council
United Nations Trusteeship Council
established on 26 June 1945, effective on 24 October 1945, to supervise the administration of the 1 1 UN trust
territories; members were China, France, Russia, UK, US; it formally suspended operations 1 November 1995 after
the Trust Territory of the Pacific Islands (Palau) became the Republic of Palau, a constitutional government in free
association with the US; the Trusteeship Council was not dissolved
United Nations University (UNU)
established— 3 December 1973
aim—\\o conduct research in development,
welfare, and human survival and to train
scholars
members— (24 members of UNU Council and the Rector are appointed by the Secretary General of the United
Nations and the Director General of UNESCO)
Universal Postal Union (UPU)
established— 9 October 1874, affiliated with the
UN 15 November 1947
effective— 1 July 1948
aim—{o promote international postal
cooperation; a UN specialized agency
members— (189) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands
Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Overseas Territories of the UK, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member
states at the time of dissolution were Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier
members included GDR and Albania
West African Development Bank (WADB)
note— also known as Banque Ouest-Africaine
de Developpement (BOAD); is a financial
institution of WAEMU
established— ^ A November 1973
a/m— to promote regional economic
development and integration
regional members— (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
international/nonregional members— (5) African Development Bank, Belgium, European Investment Bank, France,
Zl
ZW
ZWE
716
.ZW
625
Appendix E:
Cross-Reference List of Hydrographic Data Codes
IH0 23-4th:
Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1986, published by the International Hydrographic Bureau
of the International Hydrographic Organization
IH0 23-3rd:
Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1 953, published by the International Hydrographic Organization
ACICM49-1:
Chart of Limits of Seas and Oceans, revised January 1958, published by the Aeronautical Chart and Information Center
(ACIC), United States Air Force; note - ACIC is now part of the National Imagery and Mapping Agency (NIMA)
DIAM 65-18:
Geopoliticat Data Elements and Related Features, Data Standard No. 4, Defense Intelligence Agency Manual 65-18,
December 1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar to the Federal Information Processing
Standards (FIPS) 10-4 country codes. The names and limits of the following oceans and seas are not always directly
comparable because of differences in the customers, needs, and requirements of the individual organizations. Everi the
number of principal water bodies varies from organization to organization, Factbook users, for example, find the Atlantic Ocean
and Pacific Ocean entries useful, but none of the following standards include those oceans In their entirety. Nor is there any
provision for combining codes or overcodes to aggregate water bodies. The recently delimited Southern Ocean is not included.
Principal Oceans and Seas of the World With
Hydrographic Codes by Institution
IHO
23-4th
IHO
23-3rd*
ACIC
M49-1
DIAM
65-18
Arctic Ocean
9
17
A
5A
Atlantic Ocean
—
—
—
—
North Atlantic Ocean
1
23
B
1A
South Atlantic Ocean
4
32
C
2A
Baltic Sea
2
1
B26
7B
Indian Ocean
5
45
F
6A
Mediterranean Sea
3.1
28
B11
Eastern Mediterranean
3.1.2
28 B
—
8E
Western Mediterranean
3.1.1
28 A
—
8W
Pacific Ocean
—
—
—
North Pacific Ocean
7
57
D
3A
South Pacific Ocean
8
61
E
4A
South China and Eastern Archipelagic Seas
6
49, 48
D18plus others
3U plus others
* The letters after the numbers are subdivisions, not footnotes.
626
Appendix F:
Cross-Reference List of Geographic Names
This appendix cross-references a wide variety of geographic names to the appropriate
facfboo/r ‘country’ entry. Additionai information is included in parentheses.
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Abidjan (capital)
Cote d''Ivoire
519N
402W
Abkhazia (region)
17 50S
31 03 E
Harvey Islands (former name for Cook Islands)
2000S
30 00E
Rhodesia, Northern (former name for Zambia)
20 00S
30 00 E
Riga (capital)
17 50 8
105 00 W
Salzburg (city)
20 00S
30 00 E
South-West Africa (former name for Namibia)','8569f5ef803c4da7fe9496392973a1f4f6f1c433e444450dee592db4fc596932','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eb1e0d252123caf7da589b66a5f000a7f4a34878a3d0dfab936fe022b206d35',2001,'DZ','Algeria','transnational-issues',1155,'AG
DZ
DZA
012
.dz
28 00 N
3 00 E
Al Kuwayt (local name for Kuwait)
36 47 N
2 03E
AIhucemas, Penon de (island group)
35 43N
043W
Orange River Colony (region; former name of
Free State Province of South Africa)','d7bffb275065198aa4dfa3c1d7404e9f0bf63d6a74008cbcd0467d341c8dd4da','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48543285f3a80de8f69ef61f8b355f12bd0038dbfa7fe45fe3497e6657264163',2001,'AM','Armenia','transnational-issues',1156,'AM
AM
ARM
051
.am
40 00 N
45 00 E
Heard Island
4011 N
44 30 E
Youth, Isle of (Isla de la Juventud)','4e06331ad8b871da5f43a80d4c5acc8793fa78408d0b3937affd3f91658e14f6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a328aeaa875c26992d9a21044b3e701d9a740027afdcefadebcf6b95faaa6186',2001,'AW','Aruba','transnational-issues',1157,'AA
AW
ABW
533
.aw
Ashmore and Cartier Islands
AT
—
—
—
—
ISO includes with Australia
12 33N
70 06 W
Oresund (The Sound) (strait)
Atlantic Ocean
55 SON
12 40E
Orkney Islands','ef2d6aeb6849a742d2763563dc206482d894349f62fc70f559490dc81a7750ca','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06e3b699fbee2978e1972963083ade836b1e1b3ebaa73167c78f6237fc74838b',2001,'BY','Belarus','transnational-issues',1158,'BO
BY
BLR
112
•by
53 00 N
28 00 E
Benadir (region; former name of Italian Somaliland)
53 00N
28 00E
Byelorussia (former name for Belarus)
53 00 N
2800E
C Cabinda (province)
5354N
27 34E
Misr (local name for Egypt)','713a6546a837ea9b4cafdf3f5f35fa20ea50b57d481aecf6a89d6416181b4d70','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3cc6f954b548988f76477d67e30e182ec41ea1b71b868646071a483c943bf83',2001,'BE','Belgium','transnational-issues',1159,'BE
BE
BEL
056
.be
51 13 N
425 E
Aomen (local Chinese short-form name for Macau)
Macau
22 ION
11333E
Aozou Strip (region)
50 50 N
4 00E
Belgique (local name for Belgium)
5050N
4 00E
Belgrade (capital)
Yugoslavia
44 50 N
20 30 E
Belize City (capital)
50 SON
420 E
Bubiyan (island)
50 26 N
602 E
Malpelo, Isla de (island)','5c83a5b62258d3d72e32a4034f19ebc0ea1eed56d1d7716eae8527e313e08f34','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5b334317a1bb88f044b1dae089f918429bc468b439f0d953265d80edd3d328c',2001,'BJ','Benin','transnational-issues',1160,'BN
BJ
BEN
204
•bj
6 21 N
2 26E
Cotopaxi (volcano)
9 SON
215E
Daito Islands
629N
2 37E
Portuguese East Africa (former name for Mozambique)','11a8b3a801323468297d74048d022b3f5ae934ebb16c86ac74098d43908a9309','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83a64b123942cd3c57537877633860f15481f816172ad0d190b58fa37b485f39',2001,'BT','Bhutan','transnational-issues',1161,'BT
BT
BTN
064
.bt
Bolivia
BL
BO
BOL
068
.bo
2730N
90 30 E
Dubai (city)
2728N
89 39 E
Thuringia (region)','d01a3686e533db0d6d315ed3320a3b63c11b53bcd44c45d49227dde0fac9cade','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73c05286733eb43e4936102fb2776dff5b2ec90470cc599323aa6ab206f0771d',2001,'BA','Bosnia and Herzegovina','transnational-issues',1162,'BK
BA
BIH
070
.ba
44 00N
1800E
Bosnia (political region)
44 00 N
18 00E
Bosporus (strait)
Atlantic Ocean
41 00 N
2900E
Bothnia, Gulf of
Atlantic Ocean
63 00N
20 00E
Bougainville (island)
44 00 N
18 00 E
Hiiumaa (island)
43 52 N
18 25 E
Sarawak (state)','6f1ee61b1a4864d473b71d38e309e64e11f57d8749c42ef9818b028b1efeff89','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a43a477c7404782a4b01d2955ed3d5939d2e4262f84bb4ed947b303799266419',2001,'IO','British Indian Ocean Territory','transnational-issues',1163,'10
10
lOT
086
.io
British Virgin Islands
VI
VG
VGB
092
•vg
Brunei
BX
BN
BRN
096
.bn
6 00S
71 30 E
Challenger Deep (Mariana Trench)
Pacific Ocean
11 22 N
142 36 E
Channel Islands
Guernsey, Jersey
4920N
220W
Charlotte Amalie (capital)
Virgin Islands
18 21 N
64 56 W
Chatham Islands
7 20S
72 25 E
Diego Ramirez (islands)
6 00S
71 30 E
Okhotsk, Sea of
Pacific Ocean
53 00N
150 00 E
Okinawa (island group)','fba40cac3fffb805664f911fa8c4e055b45ff2d6bc3f26c72cc44721716cdf23','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b626122bd7727a3d80a4c73705ec7e4fc46a0eed025dc48fad9c27569cefca5',2001,'BI','Burundi','transnational-issues',1164,'BY
Bl
BDI
108
.bi
323S
29 22 E
Bukovina (region)
Romania, Ukraine
48 00 N
26 00 E
Byelarus (local name for Belarus)
3 30S
30 00 E
Ussuri River
China, Russia
48 28 N
135 02 E
V
Vaduz (capital)','c3d7015218f400fceaccbba1962ece1d1ce531cff7467e806988a9813fd3d30a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70435545d430d91eb82e35e33ac2545fa5d5250901921939e8e7b4c5cbd2edae',2001,'CF','Central African Republic','transnational-issues',1165,'CT
CF
CAF
140
.cf
4 22N
18 35E
Banjul (capita!)
The Gambia
13 28N
16 39W
Banks Island
7 00N
21 00 E
Ceram (Seram) Sea
Pacific Ocean
2 30S
129 30 E
Ceska Republika (local name for Czech Republic)
Czech Republic
4945N
15 30E
Ceskoslovensko (former local name for
Czechoslovakia)
Czech Republic, Slovakia
49 00 N
17 30E
Ceuta (city)
7 00N
21 00 E
Republique Francaise (local name for France)
6 38N
20 33E
Ukrayina (local name for Ukraine)','43f35d384f7d35df274474651cb852a76df1a601073e56f36874acdf2dff1534','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f57e28eef1f2a81184c74538c40ac728141c3c6c5f8725da65bc30bc98b40a7',2001,'CL','Chile','transnational-issues',1166,'Cl
CL
CHL
152
.cl
2300S
70 tow
Atacama (region)
24 30S
6915W
Athens (capital)
42 SOS
74 00 W
China, People''s Republic of
56 30S
68 43 W
Dilmun (former name for Bahrain)
2707S
109 22 W
Eastern Channel (East Korea Strait or Tsushima Strait)
Pacific Ocean
34 00N
129 00 E
Eastern Samoa (former name for American Samoa)
55 59S
6716W
Horne, lies de (island group)
3300S
SO 00 W
Jubal, Strait of
Indian Ocean
2740N
33 55 E
Judaea (region)
Israel, West Bank
31 35 N
35 00 E
Jugoslavia, Jugoslavia (local names for Yugoslavia)
Yugoslavia
43 00 N
21 00 E
Jutland (region)
33 38S
78 52 W
Mascarene Islands
Mauritius, Reunion
21 00 S
57 00E
Maseru (capital)
2707S
109 22 W
Pashtunistan (region)
Afghanistan, Pakistan
32 00 N
69 00 E
Passion, lie de la (island)
Clipperton Island
1017N
109 13W
Patagonia (region)
27 07S
109 22 W
Ratak Chain (island group)
Marshaii islands
900N
171 00 E
Red Sea
Indian Ocean
20 00 N
38 00 E
Redonda (island)
33 38S
78 52W
Rocas, Atol das (island)
26 28S
105 00 W
Salisbury (city; former name for Harare)
26 21 S
79 52W
San Andres y Providencia, Archipielago (island group)
80 05W
San Jose (capital)
33 27 8
70 40 W
Santo Antao (island)
Cape Verde
17 05N
25 low
Santo Domingo (capital)','40d243ef38435f6f0ead291b15fc1e00b630cd428e71d307a47994f007e9374f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cda1d2c620e10d044947a4709ee8c0f83872601d3cc5536e71ff28eb0363cc29',2001,'CC','Cocos (Keeling) Islands','transnational-issues',1167,'CK
cc
CCK
166
.cc
12 SOS
96 50E
Colombo (capital)
12 30S
96 50 E
Kerguelen, lies (island group)
French Southern and Antarctic Lands
49 SOS
69 30E
Kermadec Islands
1210S
96 55 E
West Korea Strait (Western Channel)
Pacific Ocean
34 40 N
129 00 E
West Pakistan (former name for western portion
of Pakistan)','b957e8fb8076416ae383860914067a7f15b97f835e2784ad79f8ca278c6c57fa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0af08199f7c214a208cff280bf7f26d88f5d21b8005acd383fbad1e1cc7dbbba',2001,'KM','Comoros','transnational-issues',1168,'CN
KM
COM
174
.km
Congo, Democratic Republic of the
CG
ZR
ZAR
180
.cd
formerly Zaire
Congo, Republic of the
CF
CG
COG
178
•eg
1215S
44 25 E
Ankara (capital)
Turkey
39 56 N
32 52 E
Annobon (island)
1210S
4415E
Con Son (islands)
Vietnam
8 43N
106 36 E
Conakry (capital)
11 41 S
4316E
Mortlock Islands (Nomoi Islands)
Federated States of Micronesia
5 30N
15340 E
Moscow (capital)
Russia
55 45N
37 35E
Mount Pinatubo (volcano)','697571be6927da760f1ca282bcc663a3ac325a1a75eaae665865db32cf96f567','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd4cb376f9fdf0df2f746f869f224210ea70625b5cc12f658e391b4ab4b44a9e',2001,'ER','Eritrea','transnational-issues',1169,'ER
ER
ERI
232
.er
15 20N
38 53 E
Asmara (see Asmara)
15 20N
38 53 E
As-Sudan (local name for Sudan)
15 00N
39 00 E
Espana','caabb0887d3394a19bb9d2693c89aa7145710fe5ec3deb5376fdc680a6a2104d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('784b2e47e967f46809d0db0b59876067ad68d3d98c2f2be3e3fefecc61aa86cc',2001,'FJ','Fiji','transnational-issues',1170,'FJ
FJ
FJI
242
•fj
1820S
178 30 E
Lefkosa (see Nicosia)
12 30S
177 30 E
Ruanda (former name for Rwanda)
18 08S
178 25 E
Sverdlovsk (Yekaterinburg) (city)
Russia
56 50 N
60 39E
Sverige (local name for Sweden)
1800S
178 00 E
Vladivostok (city)
Russia
43 ION
131 56 E
Vojvodina (region)
Yugoslavia
45 35N
20 00 E
Volcano Islands
„ Qsuvii’ TOIiQA ,,
Nuku''alo^
iSLAsns _ Tahiti
^apeete ''
ARCHIPEL DES TUAMOTLI
Trench Polynesia
. ■ . (rRAMCE)
n .
^ Pitcairn Islands
(U.R.)','e793fd6417be0f9ec575542d764bad966ee26f2a03d745dadf0f6b2c1aa9df7e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8e25d7f7c1efcce68023623007e6c34a168496abce4c1594e10f924eadc079d',2001,'FI','Finland','transnational-issues',1171,'FI
FI
FIN
246
.fi
6015N
20 00 E
Alaska (state)
60 ION
24 58 E
Herzegovina (political region)
64 00 N
26 00 E
Surigao Strait
Pacific Ocean
1015N
125 23 E
Surinam (former name for Suriname)','688ccccf921772915c56a3c04dab59605645c763edb8425145ed4e61b084808a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22b5464eb39c2e746ea91d9a7932ff7403c2fb50b1e0d1e1b56b3c0d1cdc27cc',2001,'GA','Gabon','transnational-issues',1172,'GB
GA
GAB
266
.ga
Gambia, The
GA
GM
GMB
270
.gm
Gaza Strip
GZ
—
—
—
—
0 23N
9 27E
Lietuva (local name for Lithuania)
1 00 S
11 45 E
Republique Rwandaise (local name for Rwanda)','88deecac484ff487bdd476b6ffdf7525ce92ea2c7a6e164c6ee9a1131b0b1faf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11e2fefeca4b068e6886a81963810dc5a8a21f6b66c76440016144b0f773df85',2001,'GE','Georgia','transnational-issues',1173,'GG
GE
GEO
268
•ge
4300N
41 00 E
Abu Dhabi (capital)
41 45 N
4210E
Akmola (city; former name for Astana)
42 30N
41 52 E
Minicoy Island
42 00 N
43 30E
Sakhalin Island (Ostrov Sakhalin)
Russia
5100N
143 00 E
Sakishima Islands
42 20 N
44 00E
South Pacific Ocean
Pacific Ocean
130 00 W
South Sandwich Islands
41 43 N
44 49 E
Tchad (local name for Chad)
41 43 N
44 49 E
Tien Shan (mountains)
China, Kyrgyzstan
42 00 N
80 00 E
Tierra del Fuego (island, Island group)
Argentina, Chile
5400S
69 00W
Timor (island)','c26a688a3bc85abca7a14f4ae68ae6d0dc5e7e61aa56a2c3bbb1c9c3c8ccc7a5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0213e8b0c96c0c2d18058ed71ecfb57c053c67532df66e943e42390ca920840',2001,'HM','Heard Island and McDonald Islands','transnational-issues',1174,'HM
HM
HMD
334
.hm
Holy See (Vatican City)
VT
VA
VAT
336
.va
5306S
73 30 E
Hejaz (region)
5306S
73 30 E
Mecca (city)
53 00 S
72 30 E
Shag Rocks','a3fcee3a48567993374dea26cea3b558125039896878a20dafb05523818d020d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('387c6e99ab4d21f7ddc7a7f62618dafaaf6d4baa759d665198d2f7b154ffbb98',2001,'IS','Iceland','transnational-issues',1175,'IC
IS
ISL
352
.is
65 00 N
18 00W
Islas Malvinas (island group)
Falkland Islands (Islas Malvinas)
51 45 S
59 00 W
Istanbul (city)
Turkey
41 01 N
28 58E
Istrian Peninsula
Croatia, Slovenia
45 00N
14 00E
Italia (local name for Italy)
19 00N
111 30W
Rhodes (island)
6317N
20 40 W
Suva (capital)','c800f6c8914a903837c31579ebefc8e8b28ef1e624ce1bb50c255f5a6f39644a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88d21af9562ee6caf0d0ce2e4c68874dae9e9804102ab9de90752e3b957bd27e',2001,'IN','India','transnational-issues',1176,'IN
IN
IND
356
.In
11 30 N
72 30 E
Amiranfe Isles (Les Amirantes) (island group)
12 00N
92 45E
Andaman Sea
Indian Ocean
10 00N
95 00 E
Andorra la Vella (capital)
20 00 N
77 00 E
Bhopal (city)
2316N
77 24 E
Biafra (region)
18 58 N
7250E
Bonaire (island)
Netherlands Antilles
1210N
6815W
Bonifacio, Strait of
Atlantic Ocean
41 01 N
14 00E
Bonin Islands
13 04N
8016E
Chesterfield Islands (lies Chesterfield)
20 ION
73 00 E
Damascus (capital)
Syria
33 SON
3618E
Danger Islands (see Pukapuka Atoll)
20 42 N
70 59E
Djibouti (capital)
14 20N
74 00E
637
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Gobi (desert)
China, Mongolia
42 30N
107 00 E
Godthab (Nuuk) (capital)
32 42N
74 52E
Jammu and Kashmir (region)
India, Pakistan
34 00N
76 00E
Japan, Sea of
Pacific Ocean
40 00 N
135 00 E
Jars, Plain of
Laos
1927N
103 10 E
Java (island)
10 00N
73 00 E
Laccadive Sea
Indian Ocean
7 00N
76 00 E
Lagos (capital)
10 00N
73 00 E
Lantau Island
13 04N
8016E
Madrid (capital)
817N
73 02E
Minorca Island (Isla de Menorca)
28 36 N
7712E
New Guinea (island)
Indonesia, Papua New Guinea
5 00S
140 00 E
New Hebrides (island group)
8 00N
93 30E
Nicosia (capital)
88 30E
Silesia (region)
Czech Republic, Germany, Poland
17 00E
Sinai Peninsula','51549d16a679af97da597ac57b29223cb8b0a6ea4db3f7b1303458cced534423','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('491b53cffb322b6e6c4eed7fae37e3b66db4777a8e0c8399964ba9aaf0c8e4a4',2001,'IQ','Iraq','transnational-issues',1177,'IZ
IQ
IRQ
368
•iq
33 00N
44 00 E
Al Jaza’ir (local name for Algeria)
33 21 N
44 25E
Baki (see Baku)
33 00 N
44 00 E
Messina, Strait of
Atlantic Ocean
3815N
15 35E
Mexico (capital)','1eb6c970bf2f2f436dbc7cb5e233629a919eefb7a4ed4c05a75454639230401d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06b03498aec3bf4a7e76502bf633d03c11985aba0a2de765e817aac940974fca',2001,'JP','Japan','transnational-issues',1178,'JA
JP
JPN
392
■ip
Jarvis Island
DQ
—
—
—
ISQ includes with the US Minor
Outiying islands
27 00N
140 10 E
Bonn (capital)
43 00 N
17 00E
Dakar (capital)
44 00 N
143 00 E
Holland (region)
36 00 N
138 00 E
Hormuz, Strait of
Indian Ocean
26 34 N
5615E
Horn of Africa (region)
Djibouti, Eritrea, Ethiopia, Somalia
SOON
48 00 E
Horn, Cape (Cabo de Hornos)
34 20 N
133 30 E
Inner Hebrides (islands)
2447N
141 20 E
Izmir (region)
Turkey
38 25N
2710E
J
Jakarta (capital)
34 41 N
135 10 E
Kodiak Island
3300N
131 00 E
Kyyiv (see Kiev)
2416N
154 00 E
Margarita, Isla (island)
Venezuela
10 00N
64 00 W
Mariana Islands
Guam, Northern Mariana Islands
16 00N
145 30 E
Marie Byrd Land (region)
2416N
154 00 E
Mindanao (island)
30 00N
140 00 E
Nassau (capital)
The Bahamas
25 05N
77 21 W
Natal (region)
36 00 N
138 00 E
Nippon (local name for Japan)
36 00 N
138 00 E
Nomoi Islands (Mortlock Islands)
Federated States of Micronesia
5 30N
153 40 E
Norge (local name for Norway)
26 SON
128 00 E
Oland (island)
20 20 N
136 00 E
Paris (capital)
26 30 N
128 00 E
S Saar (region)
24 30 N
124 00 E
Sala y Gomez, Isla (island)
H^9!HI
133 30 E
Shikotan (island)
Russia (de facto)
146 45 E
Shqiperia (local name for Albania)
35 42 N
13946 E
Tonkin, Gulf of
Pacific Ocean
20 00 N
108 00 E
Torres Strait
Pacific Ocean
10 25S
142 10 E
Torshavn (capital)
25 00N
141 00 E
Vostok Island','961d2f3b8c7f10975bfa5f01a8ca52c4f28a0c3c121d3711cf24187aaf97e629','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b381a6ebc62ef918f7bec4238c33ef44c55aa6dee5fab863fd3465f75e59ff75',2001,'JO','Jordan','transnational-issues',1179,'JO
JO
JOR
400
.jo
Juan de Nova Island
JU
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
31 00 N
36 00 E
Al Yaman (local name for Yemen)
31 57 N
35 56 E
Amsterdam (capital)
31 00 N
36 00 E
Transkei (enclave)
31 00 N
36 00 E
Urundi (former name for Burundi)','0448e883bd6069cd6be7f14b5401ca3ad6c65ef1e6f66f13682d6fa89b0c1dac','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a987b1d22c9446eca9f574bbf11d28a8e38f81e787b6845ee454c6a8164073f',2001,'KW','Kuwait','transnational-issues',1180,'KU
KW
KWT
414
.kw
29 30 N
45 45 E
Al Maghrib (local name for Morocco)
29 47 N
4810E
Bucharest (capital)
29 20 N
47 59 E
Kuznetsk Basin
Russia
54 00 N
86 00 E
Kwajalein Atoll','d3761d902ea68b6fb58e04ccf0cc8d6c02258a6cfe82e8125b54ac162994de38','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e139817676aedb015d5a513bf2c65c2c1952ff08d58175343b94624cff490478',2001,'LS','Lesotho','transnational-issues',1181,'LT
LS
LSO
426
,1s
621
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
2930S
28 30E
Batan Islands
29 28S
27 30E
Mata-Utu (capital)','cf275958cce9d770a99ea1d791cc284d4ce9d2ae1c071df2715f260db9b4469e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45083185265d2ae614e8ab50d7c2d600a6d090bdc23d2a61e9aea971bae0b269',2001,'LT','Lithuania','transnational-issues',1182,'LH
LT
LTU
440
Jt
56 00 N
24 00 E
642
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Ligurian Sea
Atlantic Ocean
4330N
900E
Lilongwe (capital)
55 43N
21 30 E
Mesopotamia (region)
54 41 N
2519E
Viti Levu (island)','c4a67cf55d920a2146a33fc76a5ac368332f3cd6ae1a98daf5d1f6c2593973c0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3942caa758b47968a386fd9d27155aa78d8750becea3d039204f7f84c134eeb3',2001,'MY','Malaysia','transnational-issues',1183,'MY
MY
MYS
458
.my
526N
100 16 E
George Town (city)
The Bahamas
23 SON
75 46 W
Georgetown (capital)
310N
101 42 E
Kunashiri (Kunashir) (island)
Russia (de facto)
44 20 N
146 00 E
Kunlun Mountains
5 23N
100 15 E
Pentland Firth (channel)
Atlantic Ocean
58 44 N
313W
Perim (island)
5 20N
117 10E
Sable Island
2 30N
11330E
Sardinia (Island)','f8387565af82d7e98cd8005320950256f1b42095cd698314284bab831b80c387','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56806b9bf9381035062974021c2f37da02ad9f08292e5cb4dbdc534bfd265631',2001,'FM','Micronesia, Federated States of','transnational-issues',1184,'FM
FM
FSM
583
.fm
Midway Islands
MQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
Miscellaneous (French) Indian
Ocean Islands
ISO includes Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova
Island, Tromelin Island
Moldova
MD
MD
MDA
498
.md','e1c1fae922bff89c6cf062014d7abd976d2739bb9bc74f4788e5f795c8065840','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3b275efd95ce1a9490c888157fad255722b00d25cbfda0f621369d50c4ee1cc',2001,'MN','Mongolia','transnational-issues',1185,'MG
MN
MNG
496
.mn
46 00 N
105 00 E
Monrovia (capital)
46 00 N
105 00 E
P Pacific Islands, Trust Territory of the
Marshall Islands, Federated States of Micronesia,
Northern Mariana Islands, Palau
10 00N
155 00 E
Pagan (island)
47 55N
106 53 E
Ullung-do (island)
South Korea
37 29 N
130 52 E
Ulster (region)
Ireland, United Kingdom
54 35 N
7 00W
Uman (local name for Oman)','e2f0ac6864ff2ace6ff5899e8f942d14d2d6ba857095d6a371cc5d246b02eb8f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0067582a179bc30a7ad82cb79f776f35a3f40dee7f1c27c05ed7dd8bbcfb55b7',2001,'MA','Morocco','transnational-issues',1186,'MO
MA
MAR
504
.ma
32 00N
5 00W
Al Urdun (local name for Jordan)
27 53N
12 58W
Cape of Good Hope (cape; also alternate name for
Cape Province of South Africa)
32 00 N
500W
French Somaliland (former name for Djibouti)
29 22 N
10 09W
Inaccessible Island
Saint Helena
3717S
12 40W
Indochina (region)
Cambodia, Laos, Vietnam
15 00N
107 00 E
Ingushetia (region)
Russia
4315N
45 00 E
Inhambane (region)
32 00 N
5 00W
Magyarorszag (local name for Hungary)
3402N
6 51 W
Ralik Chain (island group)
32 00 N
7 00W
Spanish North Africa (exclaves)
Spain (Ceuta, Islas Chafarinas, Melilia, Penon
de AIhucemas, Penon de Velez de la Gomera)
3515N
400W
Spanish Sahara (former name)
35 48 N
5 45W
Tannu-Tuva (region)
Russia
51 25 N
94 45 E
Tarawa (island)','21c465144c5953aac2345357efb605b5462bdcb9b0e2257f04d121818219353f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26bd947c977583562fe80716e49eb17f7daa1e6875447df27b77c657d480598d',2001,'NG','Nigeria','transnational-issues',1187,'Nl
NG
NGA
566
■ng
912N
711 E
Abyssinia (former name for Ethiopia)
530 N
7 30E
Big Diomede Island
Russia
65 46 N
169 06 W
Bijagos, Arquipelago dos (island group)
10 33N
7 27E
Kailas Range
China, India
3000N
62 00 E
Kalaallit Nunaat (local name for Greenland)
6 27N
324 E
Lake Erie
Atlantic Ocean
42 30N
81 00 W
Lake Huron
Atlantic Ocean
45 00N
83 00W
Lake Michigan
Atlantic Ocean
43 30 N
87 30 W
Lake Ontario
Atlantic Ocean
43 30 N
78 00W
Lake Superior
Atlantic Ocean
48 00 N
88 00 W
Lakshadweep (Laccadive Islands)','5905fab0816d5b06430e370d47e1779b6f94042167bcc323a8f01f38b97b557c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f52e783a6a53d89d1cd79866b33bb51d64761b3a05ac437c951f0aa83a145d4d',2001,'NF','Norfolk Island','transnational-issues',1188,'NF
NF
NFK
574
.nf
29 OSS
167 58 E
Kingstown (capital)
29 08S
167 57 E
Philippine Sea
Pacific Ocean
20 00 N
134 00 E
Phnom Penh (capital)
(AUSTRALIA)
KERMADEC
ISLANDS
(M.Z.)
. , Adelaide V^-v ''.-.^
- .dJ t c
O''^
y Bendigo^
''._ Geelong V
Newcastle
^Sydney
I on/ //oivc Js/iim/
lAUSTKAl.lAt
...''Wollongong
Mount Koscluszko
) point in Australia.
North
Island
Hamilton* .
''w\\ ''
Auckland!^''
MEW
^ ''^Hastings ’
Tasmania
ZEALAND
) Wellington
^hrlslchurch
South Island
Dunedin
f Invcrcarg
Slaviut Ishiml
.?Mid way Islands''
Wake Island
A/ ''''■ '' C^Honolulu, V
'' I ■ '' ■''(.i/ /-S''/
■ i :■" ‘ • , •Jjorinston Atoir V, ll
. ’ .
MARSHALL
ISLAFiDS ,
• Kingman Reef
. , (U.SO- 1.;,
Palmyra Atoll
/''•''(U.S.)
Tarawa KIRIHATI
. (CUmiT fSI.AWS)
HiATl Howland Island
T iSl.AWS) ,'', ,
• Baker Island , > ''
. ■ - /(U.S.)'' •'' •:■: ''
: .;■ ;■■ ■ ■■ . ... ; , ''■
K I K \\ B^A T I \\ ‘ . y''^RAvvAkf .
- ^ Jv i y( PHOENIX
, ^ "* ''■ Lsz/anos;
Jarvis Island
^'' ‘ {U.S.)
Kind iv lit I
<L''iri^-‘''i!in hhvuii
''■ (KIRIBATI)
TUVALU ’
^ . *\\^FunafuU
•.iHX X ■ \\
■SANTA CKWZ
£}'' ISiiANDS ,
KERMADEC ,
I SI/AN PS
(M.Z.) ■ j
North
Auckland;. /s/lTtirf
ZEALAHD
Wellington
Scale; I ;36,000,000 at 30*»S
Mercator Projection
■ / South fslnnti
802798AI (R02111) 4-01
SOUTHEAST ASIA
802797A1 (R02106) 4-01','dccba295330a4375a4b76d37f7b506aec98fc26f086354e6ac9c407dbfff1e7b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f46f27d9b31ab235c343a3a26962439e34e47525e052f6a4c3104beed0407f8',2001,'PW','Palau','transnational-issues',1189,'PS
PW
PLW
585
.pw
Palmyra Atoll
LQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
7 30N
134 30 E
Belep Islands (lies Belep)
720N
134 29 E
Kosovo (region)
Yugoslavia
42 30N
21 00 E
Kosrae (island)
Federated States of Micronesia
520 N
163 00 E
Kowloon (city)
701 N
134 15 E
Peloponnese (peninsula)','9d9e0d90aee72adad2e4690d5261f1f7d82a5c8fb173608d994fbf469cc5c3c0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('614872aceda3eacb3330ee28d775588d675ea8321ea6a88b73c95706018b7d01',2001,'PL','Poland','transnational-issues',1190,'PL
PL
POL
616
■pi
54 23 N
18 40E
Dao Bach Long Vi (island)
Vietnam
20 08 N
107 44 E
Dar es Salaam (capital)
Tanzania
648 S
3917E
Dardanelles (strait)
Atlantic Ocean
4015N
26 25 E
Davis Strait
Atlantic Ocean
6700N
5700W
Dead Sea
Israel, Jordan, West Bank
32 30 N
35 30 E
Deception Island
54 23N
18 40 E
Geneva (city)
52 00 N
20 00 E
Polynesie Francaise (local name for French Polynesia)
5225N
16 55E
Prague (capital)
Czech Republic
40 55N
21 00 E
Praia (capital)
Cape Verde
14 55N
23 31 W
Prathet Thai (local name for Thailand)
5215N
21 00 E
Washington, DC (capital)','ee2528fa745f46ef2ec467c7e12a8268606cc3c8d50fd8c39b9395cc0fea9300','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4feadf4bbd76cf8a542ef1edcc3d15883cb85d5eba336f437514ef779ed61a2',2001,'RW','Rwanda','transnational-issues',1191,'RW
RW
RWA
646
.rw
Saint Helena
SH
SH
SHN
654
.sh
1 57 S
30 04 E
Kingston (capital)
200S
30 00 E
Republique Togolaise (local name for Togo)
2 00S
30 00 E
Rub al Khali (desert)','96b110d4d7a87456745b43b31e3c808d3f6fd70e641912df61c910d9d4f62a78','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd42cb973c2b482609a90b26ede8f6e4b52c8f0586f2e76c89f3d262964df3c4',2001,'KN','Saint Kitts and Nevis','transnational-issues',1192,'sc
KN
KNA
659
.kn
1718N
62 43 W
Bastia (city)
France (Corsica)
42 42 N
927E
Basutoland (former name for Lesotho)
17 09N
62 35W
New Britain (island)
1720N
62 45 W
Saint Christopher and Nevis
17 20N
62 45 W
Saint Eustatius (island)
Netherlands Antilles
1730N
63 00 W
Saint George''s (capital)','315ffc7d1b3200f6b04bd2d85f974bca874adaac1f2024861732a4f465a02edf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a87d45b17123290d08c02437e49bfab87738ea25b4b5e7765178f582af4fb95',2001,'PM','Saint Pierre and Miquelon','transnational-issues',1193,'SB
PM
SPM
666
.pm
46 46 N
5611 W
Saipan (island)
Northern Manana Islands
1512N
145 45 E
Sak’artVelo (local name for Georgia)','f46e095acfc3c2e84d473df36c8517d034c76004da06ccd19bc1e92b310b3e9e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ce752bdb793691eaf70509193f5e193bf601f8106abda7a89d627c033a5464',2001,'VC','Saint Vincent and the Grenadines','transnational-issues',1194,'VC
VC
VCT
670
.VC
1315N
61 12 W
Grenadines, Southern (island group)
13 09N
61 14W
Kinshasa (capital)
Democratic Republic of the Congo
418S
1518E
Kipros (Greek local name for Cyprus)
12 45N
61 15W
Northern Ireland','2ef35ddbc88d7918fbe81f717b3bce4a73c48f194008692fd575d7cbdc4e560f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8172e5561c52a46dd189267d5229c5454cdf9228f0b624208078633d18ff127',2001,'ST','Sao Tome and Principe','transnational-issues',1195,'TP
ST
STP
678
.St
1 38 N
7 25E
Prussia (region)
Germany, Poland, Russia
5300N
14 00E
Pukapuka Atoll
012N
639 E
Sapudi Strait
Pacific Ocean
7058
11410E
Sarajevo (capital)','15db84318f5151ac0b1c48b7b15a0ec10a25c8f8e9306654e8568d22e39d29bf','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16aeea686da37b4772cb0e533184770f2cecab6f373e5bb25c0120cd0bafbbc8',2001,'SA','Saudi Arabia','transnational-issues',1196,'SA
SA
SAU
682
.sa
2500N
45 00 E
Ai Bahrayn (iocal name for Bahrain)
24 30 N
38 30 E
Helsinki (capital)
21 SON
3912E
Johannesburg (city)
21 27 N
39 49E
Mediterranean Sea
Atlantic Ocean
36 00 N
15 00E
Melilla (exclave)
24 05 N
4515E
Netherlands East Indies (former name for Indonesia)
24 38 N
46 43E
Road Town (capital)
British Virgin Islands
18 27N
64 37 W
Robinson Crusoe Island (Mas a Tierra)
19 30N
49 00 E
Rumelia (region)
Albania, Bulgaria, The Former Yugoslav Republic
of Macedonia
42 00 N
22 30 E
Ruthenia (region; former name for Carpatho-Ukraine)','c70bca23906bcc7b60caac4dd21e805b372a278aacbed42fe128ffa766f3bc67','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fe9e66f5542ecc6b8f17d1367104cb68eadd5196c18c2de6c9df2ebe5e0fd13',2001,'SG','Singapore','transnational-issues',1197,'SN
SG
SGP
702
.sg
IHIBiHI
103 51 E
Singapore Strait
Pacific Ocean
1 15N
104 00 E
Sinkiang (Xinjiang) (city)','4c7092a9f64dc94f8b447d3f6268e73cf708bf1f0410ff34250f1149146b6377','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1b31da3a78d95816eed311878bf470732b868924135bb939509968045585120',2001,'TG','Togo','transnational-issues',1198,'TO
TG
TGO
768
•tg
SOON
1 10 E
French West Indies (former name for French
possessions
in the West Indies)
Guadeloupe, Martinique
16 SON
62 00 W
Friendly Islands
608 N
1 13 E
London (capital)
SOON
1 10E
Revillagigedo Island
United States (Alaska)
55 35 N
131 06 W
Revillagigedo Islands','28384e547e0aa898b7332e11287dcc674c0f0f257f3a2607a3f6f91aae8ae42b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31a0c87dd3b0770225b7d23d85616d81b414d69848da28f70bd3b04c5e109b0a',2001,'TM','Turkmenistan','transnational-issues',1199,'TX
TM
TKM
795
.tm
37 57N
58 23 E
Ashkhabad (see Ashgabat)
37 57N
58 23E
Asmara (capital)
40 00 N
60 00 E
655
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Turkmeniya (former name for Turkmenistan)
40 00N
60 00 E
Turks Island Passage
Atlantic Ocean
21 40 N
71 00 W
Tuscany (region)','559d4b4efb865ef5dade850917098a439c8a6b1bfae4a27c949478979e7106b4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3feb69c53971ae2559a43cc6144837d0126042f2863d40951661d565b2090378',2001,'TC','Turks and Caicos Islands','transnational-issues',1200,'TK
TC
TCA
796
.tc
21 56 N
71 58 W
Cairo (capital)
21 28 N
71 08 W
Great Australian Bight
Indian Ocean
35 00S
130 00E
Great Belt (Store Baelt) (strait)
Atlantic Ocean
55 30N
11 00 E
Great Bitter Lake','c6e3626f63c781dd4f3a5d0fa912633b583e6869a1fdad20b8ed77f61ac72519','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c3d2db4448130f17b605922da41bef66d47a166526feca4ba4b41bf81cb9f23',2001,'UG','Uganda','transnational-issues',1201,'UG
UG
UGA
800
•ug
019N
32 25 E
640
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry In The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Kampuchea (former name for Cambodia)','3722c8674b6398c9811c43176e2d181280c84d8bc6d28ab2d8c3b2fb9f5eb55a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d132f7d0f9b1ce3a5b31de90986b759bbc32d5b343a338471421da02b59224',2001,'VU','Vanuatu','transnational-issues',1202,'NH
vu
VUT
548
.vu
Venezuela
VE
VE
VEN
862
.ve
Vietnam
VM
VN
VNM
704
.vn
624
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
Virgin Islands
VQ
VI
VIR
850
.vi
Virgin Islands (UK)
—
—
—
—
•vg
see British Virgin Islands
Virgin Islands (US)
—
—
—
.vi
see Virgin Islands
Wake Island
WQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
14 00S
167 30 E
Barbuda (island)
16 00S
167 00 E
New Ireland (island)
16 00S
167 00 E
Novaya Zemlya (islands)
Russia
7400N
57 00 E
Nubia (region)
Egypt, Sudan
20 30 N
33 00 E
Nuku''alofa (capital)
17 44S
168 19 E
648
Appendix F: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook _ (deg min) (deg min)
Poznan (city)
I’ori Hcdland
HAMMERSLEY
RANGE
GREAT SANDY
DESERT
tvv Mount Isa
Cairn^;;,t " ^
o )•> >
■35 ■^ • .
_ Townsville'' y."= .
tt\\ •^, • ••
Mackay''d
riJi
V''''(»i(fii
/.cm
. Mata-Ut
•'' ■''i
. Wall
Fu
(FR
'' new
Caledonia <i
(FRAMCEl <i
''A \\ ■
''^''^N Noftimea
Port“VHa
l^''Suva TOn
Nuku''ai
GIBSON
DESERT
Alice Springs','f41e92fbd8523c943db597d41efcc146b0aa9f63bf6393e410aa786a0d7f2a16','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d226dc53b4d77d2ac8519a6fb9e3b3f394308b1b31c1e5e47f602d81149d422b',2001,'GS','South Georgia and the South Sandwich Islands','transnational-issues',1203,'53 39 S
41 48 W
Black Sea
Atlantic Ocean
43 00N
35 00E
Bloemfontein (city, judicial center)
5415S
36 45 W
Guadalcanal (island)
53 33 S
42 02 W
Shetland Islands
5415 3
36 45 W
South Island
26 SOW
South Shetland Islands','280d1f1eacb4b6e5c502ee415fb6e80c21f571a6290a92a4b0fc6ca6f5e45f86','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac6bb62bab2617ab5287d6f1a49bd3251f7df0f650987ae1730fff3d2ffb4ef9',2001,'WF','Wallis and Futuna','transnational-issues',16,'This category includes only two entries at the present time - Disputes
- international and Illicit drugs - that deal with current issues going
beyond national boundaries.','44d3a215e32ebc4e1e55482237ac4509d27accb0eb62b9edc54a23990d9ea1da','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

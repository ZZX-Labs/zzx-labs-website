SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7865c645d91bd0f74f4c4ec088c0d912e84dadb63b6a7a7ad2ddfa17573af494',2001,'EH','Western Sahara','military-and-security',14,'Military branches
Military manpower - military age
Military manpower - availability
males age 15-49
females age 15-49
Military manpower - fit for military service
males age 15-49
females age 15-49
Military manpower - reaching military age
annually
males
females
Military expenditures - dollar figure
Military expenditures - percent of GDP
Military - note
Military branches: NA; note - the military does not
exist on a national basis; some elements of the former
Army, Air and Air Defense Forces, National Guard,
Border Guard Forces, National Police Force
(Sarandoi), and tribal militias still exist but are
factionalized among the various groups
Military manpower - military age: 22 years of age
Military manpower - availability:
males age 15-49: 6.645,023 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 3, 501, %7 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 252,869 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military expenditures - dollar figure: aggregate
real expenditure on arms worldwide in 1 999 remained
at approximately the 1998 level, about three-quarters
of a trillion dollars (1999 est.)
Military expenditures - percent of GDP: roughly
2% of gross world product (1999 est.)','2e4c6fdf8fe88105957d7c652eda865aeaec459bea4dd6499d0991f836f67ae9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d98bf25ffadd00efeb88c6f5fc5e1151fbbb497456943f6b4253f6f253e29f9',2001,'AL','Albania','military-and-security',24,'Military branches: Army, Navy, Air and Air Defense
Forces, Interior Ministry Troops, Border Guards
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15^49: 870,768 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1^2,103 (2001 est.)
Military manpower - reaching military age
annually;
ma/es; 35,792 (2001 est.)
Military expenditures - dollar figure: $42 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
Military branches: National Popular Army, Navy, Air
Force, Territorial Air Defense, National Gendarmerie
Military manpower ■ military age: 19 years of age
Military manpower - availability;
males age f 5-49; 8,794,622 (2001 est.)
Military manpower - fit for military service:
males age /5-49; 5,383,770 (2001 est.)
Military manpower - reaching military age
annually:
males: 388,939 (2001 est.)
Military expenditures - dollar figure: $1 .87 billion
(FY99)
Military expenditures - percent of GDP: 4.1 %
(FY99)','16412bde26f24ded442e981415b69a11d36143c28a60c31edb0f0184e7b09029','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f506016bb2632387925556be8c90697d1b072610b660bcbef0f5f5fa3c2557af',2001,'AO','Angola','military-and-security',47,'Military branches: Army, Navy, Air and Air Defense
Forces, National Police Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,480,016 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,246,224 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 103,807 (2001 est.)
Military expenditures - dollar figure: $1 .2 billion
(FY97)
Military expenditures - percent of GDP: 22%
(1999)','75acc3606ce0926d6b9e1d6942a0df7bc2a543e2eeb0cf18b9b1d4107f58ed72','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3658718402e7ac60516a7ede861994f18fdf7a5125d217b8af30ced8e0b82609',2001,'AQ','Antarctica','military-and-security',63,'Military - note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes
Military branches: Argentine Army, Navy of the
Argentine Republic (includes Naval Aviation, Marines,
and Coast Guard), Argentine Air Force, National
Gendarmerie, National Aeronautical Police Force
Military manpower « military age: 20 years of age
Military manpower - availability:
males age 15-49:9,404, ASA (2001 est.)
Military manpower ■ fit for military service:
males age 15-49:7,025,425 (2001 est.)
Military manpower - reaching military age
annually:
mates; 335,085 (2001 est.)
Military expenditures - dollar figure: $4.3 billion
(FY99)
Military expenditures ■ percent of GDP; 1 .3%
(FY99)
Military branches: Army, Air Force and Air Defense
Aviation, Air Defense Force, Security Forces (internal
and border troops)
Military manpower •• military age: 18 years of age
Military manpower - availability:
males age 15-49:905,154 (2001 est.)
Military manpower - fit for military service:
males age 15-49:715,734 (2001 est.)
Military manpower - reaching military age
annually:
males: 34,998 (2001 est.)
Military expenditures - dollar figure: $75 million
(FY99)
Military expenditures - percent of GDP: 4%
(FY99)
Military branches: Royal Dutch Navy and Marines,
Coast Guard
Military - note: defense is the responsibility of the
Kingdom of the Netherlands
Military - note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force','d67935534d8eee431434ae0a7194ee9c812fee526799778f241a5d77918964b5','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ee83cec195a43414b540c6596cdac7d9aab1466c0a36cad1cc6f669b0269138',2001,'GP','Guadeloupe','military-and-security',72,'Military branches: Royal Antigua and Barbuda
Defense Force, Royal Antigua and Barbuda Police
Force (includes Coast Guard)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','f6bfb0f99eb1fb7d37a73430cdc0f049fa841ed8268e8423c8da78f8f01dbf00','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c8af2583ca3bcaea97febfb6b8f1d679910f98c267dd7c37e8fcaf1e01271bf',2001,'AU','Australia','military-and-security',89,'Military branches: Australian Army, Royal
Australian Navy, Royal Australian Air Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49:4,990,107 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 4,303,966 (2001 est.)
Military manpower - reaching military age
annually:
mates; 138,971 (2001 est.)
Military expenditures - dollar figure: $6.9 billion
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)
Military branches: Army (includes Flying Division)
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 2,091 ,263 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1,731,383 (2001 est.)
Military manpower ■ reaching military age
annually:
mates; 50,580 (2001 est.)
Military expenditures - dollar figure: $1 .7 billion
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of Italy;
Swiss Papal Guards are posted at entrances to the
Vatican City to provide security and protect the Pope
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
Military branches: Police Force
Military - note: defense is the responsibility of New
Zealand
Military - note: defense is the responsibility of','77800adb8f9a954883203014ac5f983957914086d8098350acc27688473277c6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03b0d9d3e6c144182405f4bc503f0c0914bf439150f26250037cafcf38f4b995',2001,'AZ','Azerbaijan','military-and-security',98,'Military branches: Army, Navy, Air and Air Defense
Forces, Border Guards
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age /5-4P; 2,1 02,780 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,684,673 (2001 est.)
Miiitary manpower - reaching military age
annually:
males: 77,099 (2001 est.)
Military expenditures - doilar figure: $1 21 million
(FY99)
Military expenditures - percent of GDP: 2.6%
(FY99)','0d6b3a53d2750af4de6cd0b5dc9c2741e90e21b2a3aa6d0cf6189b7c35cb7427','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd6f4f5cc03732e66f35c1c94e9edd12d4cea00a1ba65a1d7f5aa6ca1cc3d43b',2001,'BH','Bahrain','military-and-security',111,'Military branches: Ground Force, Navy, Air Force,
Coast Guard, Police Force
Military manpower - military age: 1 5 years of age
Military manpower - availability:
males age 75-49; 222,141 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 121,833 (2001 est.)
Military manpower ■ reaching military age
annually:
males: 5,926 (2001 est.)
Military expenditures - dollar figure: $318 million
(FY99)
Military expenditures - percent of GDP: 5.2%
(FY99)
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard','151f4ea8c2a4918d3cb41455e0fcd17dba33648cf42426635697cb0e3bceebd6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae31fff73d61605d996ee59abceed104c45a7d294bcd4a2cb1ab79ba4d7ed9be',2001,'BD','Bangladesh','military-and-security',120,'Military branches: Army, Navy, Coast Guard, Air
Force, paramilitary forces (includes Bangladesh
Rifles, Bangladesh Ansars, Village Defense Parties,
National Cadet Corps), Armed Police battalions
Military manpower - availability:
males age 15-49: 36,005,553 (2001 est.)
Military manpower - fit for military service:
males age 15-49:21,362,279 (2001 est.)
Military expenditures - dollar figure: $559 million
(FY96/97)
Military expenditures ■ percent of GDP: 1 .8%
(FY96/97)','f377fdb83a0c24d55171aa6a4e72137acf08fdb88dbe7e04246d53edb51ad315','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('391e95c446bf6116d4eef7fadf095a98cea944dc26854ff0f45c17486061e17b',2001,'LC','Saint Lucia','military-and-security',129,'Military branches: Royal Barbados Defense Force
(includes Ground Forces and Coast Guard), Royal
Barbados Police Force
Military manpower ■ availability:
males age 15-49: 78,069 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 53,576 (2001 est.)
Military expenditures ■ dollar figure: $NA
Military expenditures - percent of GDP: NA%','047d2fce458558305c63db28bb1e9c00dc8cc22d570d48bf7e5f28c9bde56460','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66dbf173bf48cbe887aadcdf2284240e7ed37e9879fe30d760668fac40c0becc',2001,'FR','France','military-and-security',147,'Military branches: Army, Air Force, Air Defense
Force, Interior Ministry Troops, Border Guards
Military manpower - military age: 1 8 years of age
Military manpower ■ availability:
males age ^5-49: 2,729,956 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,133,743 (2001 est.)
Military manpower - reaching military age
annually:
males: 86,396 (2001 est.)
Military expenditures ■ dollar figure: $156 million
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)
Military branches: Army, Navy, Air Force, National
Gendarmerie, Medical Service
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49:2,517,593 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,079,324 (2001 est.)
Military manpower - reaching military age
annually:
mates; 63,247 (2001 est.)
Military expenditures - dollar figure: $2.5 billion
(FY01)
Military expenditures - percent of GDP: 1 .2%
(FY99)
Military - note: defense is the responsibility of
Military branches: Army, Navy, Air Force,
paramilitary Gendarmerie, Republican Guard
(includes Presidential Guard), Sapeur-Pompier
(Military Fire Group)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 75-49; 3,851,432 (2001 est.)
Military manpower - fit for military service:
males age 75-49; 2,01 0,862 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 188,411 (2001 est.)
Military expenditures - dollar figure: $94 million
(FY96)
126
Cote d''Ivoire (continued)
Military expenditures - percent of GDP: 1%
(FY96)
Military branches: British Forces Falkland Islands
(includes Army, Royal Air Force, Royal Navy, and
Royal Marines), Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
UK
Military branches: French Forces, Gendarmerie
Military manpower - availability:
males age 15-49: 49,495 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 32,052 (2001 est.)
Military expenditures ■ dollar figure: $NA
Military expenditures ■ percent of GDP: NA%
Military - note: defense is the responsibility of
Military ■ note: defense is the responsibility of
Military branches: Army, Navy, Air Force,
Republican Guard (charged with protecting the
president and other senior officials). National
Gendarmerie, National Police
Military manpower « military age: 20 years of age
Military manpower - availability:
males age 15-49: 231, 2^S (2001 est.)
Military manpower - fit for military service:
males age 15-49: 145,062 (2001 est.)
Military manpower - reaching military age
annually:
mates; 11,304 (2001 est.)
Military expenditures - dollar figure: $91 million
(FY96)
Military expenditures - percent of GDP: 1 .6%
(FY96)
Military branches: Army (includes marine unit).
National Police, Presidential Guard
Military manpower - availability:
males age t5-49; 316,873 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 159,764 (2001 est.)
Military expenditures ■ dollar figure: $2.6 million
(2001 est.)
Military expenditures - percent of GDP: 2%
(FY96/97)
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Ground Forces, Navy, Air Force
and Air Defense Forces, National Guard, Security
Forces (internal and border troops)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age ^5-49; 1,296,199 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,024,574 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 41,561 (2001 est.)
Military expenditures - dollar figure: $23 million
(FYOO)
Military expenditures - percent of GDP: 0.59%
(FYOO)
Military - note; a CIS peacekeeping force consisting
of Russian troops is deployed in the Abkhazia region
of Georgia together with a UN military observer group;
a Russian peacekeeping battalion is deployed in
South Ossetia
Miiitary branches: French Forces, Gendarmerie
Military - note: defense is the responsibility of
Military branches: French forces (Army, Navy, Air
Force), Gendarmerie
Military - note: defense is the responsibility of
Military branches: Mongolian Armed Forces
(includes General Purpose Forces, Air and Air
Defense Forces, Civil Defense Troops); note - Border
T roops are under Ministry of Justice and Home Affairs
in peacetime
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:748,779 (2001 est.)
Military manpower - fit for military service:
males age 15-49:486,491 (2001 est.)
Military manpower > reaching military age
annually:
males: 30,230 (2001 est.)
Military expenditures - dollar figure: $25.5 million
(FY01)
Military expenditures - percent of GDP: 2.3%
(FY01)
Military branches: French forces (Army, Navy, Air
Force, and Gendarmerie)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 190,846 (2001 est.)
Military manpower - fit for military service:
males age 15-49:97,497 (2001 est.)
Military manpower - reaching military age
annually:
males: 6,243 (2001 est.)
Military - note: defense is the responsibility of
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','4e85b3726a443bd088c7970faebe57a20a81cd4f368b3208a2d81ed378845763','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78bf32220224f6cbbfe5aa2dd21670505708090746e4f32dc6527d2a05e4ddb1',2001,'BZ','Belize','military-and-security',156,'Military branches: Belize Defense Force (includes
Army, Maritime Wing, Air Wing, and Volunteer Guard)
Military manpower ■ military age: 18 years of age
Military manpower - availability:
males age 15-49: 62,698 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 37,174 (2001 est.)
Military manpower - reaching military age
annually:
males: 2,847 (2001 est.)
Military expenditures - dollar figure: $17 million
(FY98/99)
Military expenditures - percent of GDP: 2.4%
(FY98/99)
Military branches: Armed Forces (includes Army,
Navy, Air Force), National Gendarmerie
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 75-49; 1,455,433
females age 15-49: 1 ,489,947
note: both sexes are liable for military service
(2001 est.)
Military manpower - fit for military service:
males age 15-49: 743,980
females age 75-49; 755,149 (2001 est.)
Military manpower - reaching military age
annually:
males: 70,088
females: 73,618 (2001 est.)
Military expenditures - dollar figure: $27 million
(FY96)
Military expenditures - percent of GDP: 1 .2%
(FY96)','fedecd2243e870f420eabaf652edc318a95c4c5eae7e5bdc688a3b1794241bf1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a829b88f16b3f98997826f0bb2826573b98bf2dfcaa69dc185430d8a343953fa',2001,'BM','Bermuda','military-and-security',165,'Military branches: Bermuda Regiment, Bermuda
Police Force, Bermuda Reserve Constabulary
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
UK
Military branches: Royal Bhutan Army, National
Militia, Royal Bhutan Police, Royal Body Guards,
Forest Guards (paramilitary)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 504,342 (2001 est.)
Military manpower - fit for military service:
males age 15-49.- 269,251 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 21,167 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army (Ejercito Boliviano), Navy
(Fuerza Naval Boliviana, includes Marines), Air Force
(Fuerza Aerea Boliviana), National Police Force
(Policia Nacional de Bolivia)
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 1549:2,005,660 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,306,452 (2001 est.)
Military manpower - reaching miiitary age
annually:
males: 90,120 (2001 est.)
Military expenditures - dollar figure: $147 million
(FY99)
Military expenditures - percent of GDP: 1 .8%
(FY99)','947c4d5edcf99bab6ef369b3d8d2d10965e7cdd4bc6af18403851683a73387d0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfbf815814fc707417f3d6eab7350beff4f4f58115cfe3624490b516b2d6ee2b',2001,'IT','Italy','military-and-security',171,'Military branches: Federation Army or VF
(composed of both Croatian and Bosniak elements),
Republika Srpska Army or VRS (composed of
Bosnian Serb elements); note - within both of these
forces air and air defense are subordinate commands
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age /5-49; 1,127,146 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 895,780 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 29,757 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Voluntary Military Force, Police
Force
Military expenditures - dollar figure: $700,000
(FYOO)
Military expenditures - percent of GDP: NA%
Military branches: Army, Air Force, Frontier
Guards, Fortification Guards
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49:1,349,034 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,570,913 (2001 est.)
Military manpower - reaching military age
annually:
males: 42,597 (2001 est.)
Military expenditures - dollar figure: $3.1 billion
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)
Military branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air Force, Syrian Arab Air Defense
Forces, Police and Security Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49:4,334,526 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,443,630 (2001 est.)
Military manpower ■ reaching military age
annually:
ma/es.'' 200,859 (2001 est.)
Military expenditures - dollar figure: $921 million
(FYOO est.); note - based on official budget data that
may understate actual spending
Military expenditures - percent of GDP: 5.9%
(FY98)','2c68bcbea39ae646650cbbab6181aa91072d6d344c3c0f30e41382daf801e6b1','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('155e00cdac303d6fda531beeb8c6e55b2ffd09b35538e0a8e110f369affea876',2001,'BW','Botswana','military-and-security',180,'Military branches: Botswana Defense Force
(includes Army and Air Wing), Botswana National
Police
Military manpower - military age: 18 years of age
Military manpower - availability;
males age ^5-49; 380,152 (2001 est.)
Military manpower - fit for military service:
males age 15-49.* 199,995 (2001 est.)
Military manpower - reaching military age
annually:
mates; 19,479 (2001 est.)
Military expenditures - dollar figure: $61 million
(FY99)
Military expenditures - percent of GDP: 1 .2%
(FY99)','757af87d30e6b67ecda0025f1071fadef7dae1218ce26ea216bef429c048323b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fc1c1957a9158c9a1e98bf6ecf740b56a71622bf867d2342a33a65895eecf76',2001,'BR','Brazil','military-and-security',194,'Military branches: Brazilian Army, Brazilian Navy
(includes naval air and marines), Brazilian Air Force,
Federal Police (paramilitary)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49:48,298,488 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49:32,388,788 (2001 est.)
Military manpower ■ reaching military age
annually:
™/es; 1,762,740 (2001 est.)
Military expenditures - dollar figure: $13,408
billion (FY99)
Military expenditures - percent of GDP: 1 .9%
(FY99)','c3cca09cc9d880c546bcacf4bb4e3556dc4e3f9cdef8001d160b9f72c7d6f0c7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c4c31d537feb59e903d8220e49081a7102247e77f70db3687578d0570c0996e',2001,'ID','Indonesia','military-and-security',202,'Military - note: defense is the responsibility of the
UK
Military - note: Federated States of Micronesia
(FSM) is a sovereign, self-governing state in free
association with the US; FSM is totally dependent on
the US for its defense
Military - note: defense is the responsibility of the
US
Military branches: Ground Forces, Air and Air
Defense Forces, Republic Security Forces (internal
and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age t5-49: 1,164,018 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 921 ,21 0 (2001 est.)
Military manpower - reaching military age
annually:
males: 42,233 (2001 est.)
Military expenditures - dollar figure: $6 million
(FY99)
Military expenditures - percent of GDP: 1 %
(FY99)
Military branches: Army, Navy, Air Force, People''s
Defense Force, Police Force
Military manpower - availability:
males age /5-49; 1,316,815 (2001 est)
Military manpower - fit for military service:
males age 15-49: 959,636 (2001 est.)
Military expenditures - dollar figure: $5 billion
(FYOO/01 est.)
Military expenditures - percent of GDP: 4.5%
(FYOO/01 est.)','d380d99841bd542c34e9d66da5613477036d93686b795184f6368c80ebe5890b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65af7047c2bb9a6c2ce7fbcae35ac7e4bdca2aadcd7651f909e4ed79545ac728',2001,'BG','Bulgaria','military-and-security',205,'Military branches: Land Forces, Navy, Air Force,
Royal Brunei Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 1549: 106,725 (2001 est.)
Military manpower - fit for military service:
males age 1549: 61,640 (2001 est.)
Military manpower - reaching military age
annually:
males: 3,005 (2001 est.)
Background: Bulgaria earned its independence
from the Ottoman Empire in 1878, but having fought
on the losing side in both World Wars, it fell within the
Soviet sphere of influence and became a People''s
Republic in 1946. Communist domination ended in
1990, when Bulgaria held its first multi-party election
since World War II and began the contentious process
of moving toward political democracy and a market
economy while combating inflation, unemployment,
corruption, and crime. Today, reforms and
democratization keep Bulgaria on a path toward
eventual integration into NATO and the EU ■ with
which it began accession negotiations in 2000.
Military branches: Army, Navy, Air and Air Defense
Forces, Civil Defense Forces, Internal Troops
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 1549: 1 ,891 ,498 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,531 ,697 (2001 est.)
Military manpower - reaching military age
annually:
males: 55,104 (2001 est.)
Military expenditures - dollar figure: $344 million
(FYOO)
77
Bulgaria (continued)
Military expenditures ■ percent of GDP: 2.4%
(FYOO)','bcd7d83930e5ee47c93fe650c72dbb0a7c191c611a2e9376e0d66d3c92797c9d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcfe8bf38e722cadbfef8245028ffb0bfdec0d0b6c44d4dce6eb7588b1cd37d4',2001,'ET','Ethiopia','military-and-security',218,'Military branches: Army, Air Force, National
Gendarmerie, National Police, People''s Militia
Military manpower ■ availability:
males age 15-49:2,592,974 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,329,995 (2001 est.)
Military expenditures - dollar figure: $66 million
(FY96)
Military expenditures - percent of GDP: 2%
(FY96)
Military branches: Ground Forces, Air Force,
Police, Militia
note: Ethiopia is landlocked and has no navy;
following the independence of Eritrea, Ethiopian naval
facilities remained in Eritrean possession and ships
which belonged to the former Ethiopian Navy and
based at Djibouti have been sold
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 14,537,884 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49:7,581,815 (2001 est.)
Military manpower - reaching military age
annually;
mates; 703,625 (2001 est.)
Military expenditures - dollar figure: $1 38 million
(FY98/99)
Military expenditures - percent of GDP: 2.5%
(FY98/99)
Military - note: defense is the responsibility of
Military branches: People''s Revolutionary Armed
Force (FARP; includes Army, Navy, and Air Force),
paramilitary force
Military manpower - availability:
males age 15-49: 305,071 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 173,703 (2001 est.)
Military expenditures - dollar figure: $8 million
(FY96)
Military expenditures - percent of GDP: 2.8%
(FY96)
Military branches: Army, Navy, Security Police
Military manpower - availability:
males age 15-49: 34,205 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 18,043 (2001 est.)
Military expenditures -dollar figure: $1 million
(FY94)
Military expenditures - percent of GDP: 1 .5%
(FY94)
Military branches: Land Force (Army), Navy, Air
Force, Air Defense Force, National Guard, Ministry of
Interior Forces (paramilitary)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 75-49; 5,894,691 (2001 est.)
Military manpower - fit for military service:
males age 75-49:3,291,185 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 233,402 (2001 est.)
Military expenditures - dollar figure: $1 8.3 billion
(FYOO)
Military expenditures - percent of GDP: 13%
(FYOO)
Military branches: Army, Navy, Air Force, National
Gendarmerie, National Police (Surete Nationals)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age /5-49; 2, 31 1,063 (2001 est.)
Military manpower - fit for military service;
males age 15-49: 1 ,207,360 (2001 est.)
Military manpower - reaching military age
annually:
ma/es.'' 114,189 (2001 est.)
Military expenditures - dollar figure; $68 million
(FY97)
Military expenditures - percent of GDP: 1 ,4%
(FY97)','48e0d1d60fe0adb8a386c0e777bc2df544a168107fc99ca5fd3f5985b027f200','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e6cf9ef735b710dbe0a5c298489f96379f9272e66e4a001ac38979be20766f3',2001,'TH','Thailand','military-and-security',227,'Military branches: Army, Navy, Air Force
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 12,050,964
females age 15-49: 12,070,017
note: both sexes liable for military service (2001 est.)
Military manpower - fit for military service:
males age 15-49; 6,425,514
females age 15-49: 6,41 9,677 (2001 est.)
Military manpower ■ reaching military age
annually:
males: 470,667
fema/es; 479,691 (2001 est.)
Military expenditures - dollar figure: $39 million
(FY97/98)
Military expenditures - percent of GDP: 2.1%
(FY97/98)
82
Burma (continued)
Military branches: Army (includes naval and air
units), paramilitary Gendarmerie
Military manpower - military age: 16 years of age
Military manpower - availability:
males age 15^49: 1 ,394,273 (2001 est.)
Military manpower - fit for military service:
males age 15-49:728,320 (2001 est.)
Military manpower ■ reaching military age
annually:
mates.- 79,360 (2001 est.)
Military expenditures - dollar figure: $57 million
(FY97)
Military expenditures - percent of GDP: 6.1%
(FY97)
Military branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps), Royal Thai
Air Force, Paramilitary Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 17,717,268 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 10,646,818 (2001 est.)
Military manpower - reaching military age
annually:
mates; 567,659 (2001 est.)
Military expenditures - dollar figure: $1 .775 billion
(FYOO)
Military expenditures ■ percent of GDP: 1 .4%
(FYOO)
Military branches: Army, Navy, Air Force,
Gendarmerie
Military manpower ■ availability:
males age 15-49: ^,^75, 528 (2001 est.)
Military manpower - fit for military service:
males age 15-49:616,622 (2001 est.)
Military expenditures - dollar figure: $27 million
(FY96)
Military expenditures - percent of GDP: 2%
(FY96)
Military - note: defense is the responsibility of New
Zealand','e4787b77bb8a34200971721d70c47d1a91108abb6e7fe7f104f81bdbbced2095','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f81576484f08668a8acc24d08bddde0d17853a779b25ade62fa827d61fe821e',2001,'KH','Cambodia','military-and-security',240,'Military branches: Royal Cambodian Armed Forces
(RCAF), including Army, Navy, and Air Force ■
created in 1993 by the merger of the Cambodian
People''s Armed Forces and the two noncommunist
resistance armies
note: Khmer Rouge and royalist insurgent forces were
integrated Into the RCAF in 1999
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:2,877,137 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,610,761 (2001 est.)
Military manpower - reaching military age
annually:
males: 162,643 (2001 est.)
Military expenditures ■ dollar figure: $1 1 2 million
(FY01 est.)
Military expenditures - percent of GDP: 3%
(FY01 est.)','a651f5df102378aa61980c37a0212df38249fb6dd7bc4413eeacfea8fd72bd09','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d698d3b04cfb0bf2427881f0b2ea6efe7b3a963b46c6cb8f6c011decfab0716c',2001,'CM','Cameroon','military-and-security',248,'Miiitary branches: Army, Navy (includes Naval
Infantry), Air Force, National Gendarmerie,
Presidential Guard
Military manpower - military age: 18 years of age
Miiitary manpower - availability:
males age 15-49: 3,762,369 (2001 est.)
Miiitary manpower ■ fit for military service:
males age 15-49: 1 ,903,149 (2001 est.)
Miiitary manpower - reaching military age
annually:
mates.'' 174,308 (2001 est.)
Military expenditures - dollar figure: $1 1 8.6
million (FYOO/01)
Military expenditures - percent of GDP: 1 .4%
(FY98/99)','f290f8b0d1e09a6b3f05cab9e4bd52a95c52a74bb07c8a5bce5d6092d0efefbd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f336ab613353d9f754ccad443959215c3970e5f45303eabb66e8d8a992055b49',2001,'CA','Canada','military-and-security',257,'Military branches: Canadian Forces (includes Land
Forces Command or LC, Maritime Command or MC,
Air Command or AC, Communications Command or
CC, Training Command or TC), Royal Canadian
Mounted Police (RCMP)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age f5-49.* 8,325,084 (2001 est.)
Military manpower - fit for military service:
males age 15-49:7,114,851 (2001 est.)
Military manpower ■ reaching miiltary age
annually:
mates.* 21 5,627 (2001 est.)
Military expenditures - dollar figure: $7.5 billion
(FYOO/01)
Military expenditures - percent of GDP; 1 .3%
(FYOO/01)','5af15155adc3e04e2495091b49298361097082345f0939644fa79ad2a9540628','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c89dd56e7437cbfce1dc29fbca6d075d33718d51d6c3059cc6348b190dfa13e9',2001,'PT','Portugal','military-and-security',263,'Military branches: Army, Coast Guard/Marines
Military manpower - availability:
males age 15-49: 89,543 (2001 est.)
Military manpower - fit for military service:
males age 15-49:50,615(2001 est.)
Military expenditures - dollar figure: $4 million
(FY96)
Military expenditures - percent of GDP: 1 .8%
(FY96)
Military branches; Army, Navy (includes Marines),
Air Force, National Republican Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age f5-49; 2,530,466 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 2,030,759 (2001 est.)
Military manpower - reaching military age
annually:
males: 71, 404 (2001 est.)
Military expenditures - dollar figure: $2,458 billion
(FY97)
Military expenditures - percent of GDP: 2.6%
(FY97)','cbcdd0db3786dcc9c8941a6669ed162c514d7be6496225989e36e098e18dfea4','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb455d277690a26daba809f75fc6b71796be532cb42d782264dfd142c816647e',2001,'HN','Honduras','military-and-security',274,'Military branches: Royal Cayman Islands Police
Force (RCIPF)
Military ■ note: defense is the responsibility of the
UK
Military branches: Central African Armed Forces
(includes Army, Air Force, Presidential Guard,
National Gendarmerie, Police Force)
Military manpower - availability:
males age 15-49:824,139 (2001 est.)
Military manpower « fit for military service:
males age 15-49: 430,922 (2001 est.)
Military expenditures - dollar figure: $29 million
(FY96)
Military expenditures - percent of GDP: 2.2%
(FY96)
Military branches: Army, Navy (includes Marines),
Air Force
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 75-49.- 1,515,101 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 902,220 (2001 est.)
Military manpower - reaching military age
annually:
males: 72,335 (2001 est.)
Military expenditures - dollar figure: $35 million
(FY99)
Military expenditures - percent of GDP: 0.6%
(FY99)','ec8923af3f393caee62f29b41ae97001e91b420516e9c19414d7efd716a0f5d6','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef086b21e987f005db27ab0f9e04b76b33eb3b12b83dd71e98e2cb9a39efc8c7',2001,'TD','Chad','military-and-security',284,'Military branches: Armed Forces (includes Ground
Force, Air Force, and Gendarmerie), Republican
Guard, Rapid Intervention Force, Police, Rural and
Nomadic Guard (GNNT)
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1 ,814,578 (2001 est.)
Military manpower - fit for military service:
males age 15-49:949,997 (2001 est.)
Military manpower - reaching military age
annually:
males: 82,003 (2001 est.)
Military expenditures - dollar figure: $39 million
(FY96)
Military expenditures - percent of GDP: 3.5%
(FY96)
Military branches: Army, Navy (includes Naval Air,
Coast Guard, and Marines), Air Force, Carabineros of
Chile (National Police), Investigations Police
note: Carabineros and Investigations Police are
normally administered by the Ministry of Interior, but in
times of national emergency, they are considered part
of the military
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49:4,067,466 (2001 est.)
Military manpower - fit for military service:
males age 15-49:3,003,134 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 136,830 (2001 est.)
Military expenditures - dollar figure: $2.5 billion
(FY99)
Military expenditures - percent of GDP: 3.1%
(FY99)','4e74a9d44acf918425f54e78c6e15712b9ad79fcd7963d0498f13ae0b9afe2fd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00fa4ede560b3327cb704629871a55377a966dfab10f4f2e9d4fdfba6b70fc06',2001,'CN','China','military-and-security',294,'Military branches: People''s Liberation Army (PLA) -
which includes Ground Forces, Navy (includes
Marines and Naval Aviation), Air Force, Second
Artillery Corps (the strategic missile force), People''s
Armed Police (internal security troops, nominally
subordinate to Ministry of Public Security, but included
by the Chinese as part of the "armed forces" and
considered to be an adjunct to the PLA in wartime)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 366,306,353 (2001 est.)
Military manpower - fit for military service:
males age 15-49:200,666,946 (2001 est.)
Military manpower - reaching military age
annually:
males: 10,089,458 (2001 est.)
Military expenditures - dollar figure: $1 2.608
billion (FY99); note - China''s real defense spending
may be several times higher than the official figure
because a number of significant items are funded
elsewhere
Military expenditures - percent of GDP: 1 .2%
(FY99)
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of China','49b0e7483c5afcbbbed80634d033d0f72d9dd0a7c6b7d1a881847e4ea50233ad','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf1e24f2f2084618f84ecc5a129e7d527683c94623538e745cad53c70acaea68',2001,'CO','Colombia','military-and-security',309,'Military branches: Army (Ejercito Nacional), Navy
(Armada Nacional, includes Marines and Coast
Guard), Air Force (Fuerza Aerea Colombiana),
National Police (Policia Nacional)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age f 5-49; 10,779,148 (2001 est.)
Military manpower - fit for military service:
males age f 5-49; 7,205,21 1 (2001 est.)
Military manpower ■ reaching military age
annually:
mates; 379,295 (2001 est.)
Military expenditures - dollar figure: $3 billion
(FYOO)
Military expenditures - percent of GDP: 3.4%
(FYOO)','a86d9b28bb8392d256f3cd75fd7fcf6febc867608133738b10d8c2d6b54ebecd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aa84fc0af2122d7331e116cef2587d506db35943ffaa0d6a69ee0df1e97c2f4',2001,'MZ','Mozambique','military-and-security',317,'Military branches: Comoran Security Force
Military manpower - availability:
males age 15-49: 141,120 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 83,920 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Channel
\\
weather''
station
''i
) ''^^airstrip
■v^
V /
X, rcof
Military - note: defense is the responsibility of
Military branches: Army, Naval Command, Air and
Air Defense Forces, Militia
Military manpower - availability:
males age 15-49: 4,627,052 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,670,933 (2001 est.)
Military expenditures - dollar figure: $35.1 million
(2000 est.)
Military expenditures - percent of GDP: 1%
(2000 est.)
Military branches: Zimbabwe National Army, Air
Force of Zimbabwe, Zimbabwe Republic Police
(includes Police Support Unit, Paramilitary Police)
Military manpower - availability;
males age ^5-49; 2,996,631 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,860,167 (2001 est.)
Military expenditures - dollar figure: $127 million
(FY99/00)
Military expenditures • percent of GDP: 3.1 %
(FY99/00)
Military branches: Army, Navy (includes Marines),
Air Force, Coastal Patrol and Defense Command,
Armed Forces Reserve Command, Combined Service
Forces
Military manpower ■ military age: 19 years of age
Military manpower - availability:
males age 15-49: 6,575,689 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 5,025,856 (2001 est.)
Military manpower - reaching military age
annually:
mates.'' 198,766 (2001 est.)
Military expenditures - dollar figure: $8,042 billion
(FY98/99)
Military expenditures - percent of GDP: 2.8%
(FY98/99)','a09714fb093c2283429d0c582614cc0b889f67c37043c9d09e1c11d065b20df8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37a8e62ae63375ea8b8e39c7a17b361483c08c0cbfca7936d39e98a0decd0fa4',2001,'CG','Congo','military-and-security',324,'Military branches: Army, Navy, Air Force, Special
Presidential Security Group
Military manpower - availability:
males age 15-49: 1 1 ,615,554 (2001 est.)
Military manpower - fit for military service:
males age 15-49:5,915,251 (2001 est.)
Military branches: Army, Air Force, Navy,
Gendarmerie
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 684,922 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 347,946 (2001 est.)
Military manpower ■ reaching military age
annually;
mates; 32,350 (2001 est.)
Military expenditures - dollar figure: $110 million
(FY93)
Military expenditures - percent of GDP: 3.8%
(FY93)','642a2fcda9cb6b37165db820100b8ed3243657bc1371c0a1fd16a07e8369cd2e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f08ebc440c0acb61aeb41c4c6af6009dc4dd267195707ad7fe051c824b2ed87d',2001,'CK','Cook Islands','military-and-security',336,'Military - note; defense is the responsibility of New
Zealand, in consultation with the Cook Islands and at
its request
Military - note; defense is the responsibility of
Australia; visited regularly by the Royal Australian
Navy; Australia has control over the activities of
visitors
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
Military - note: defense is the responsibility of the
UK
Military - note: defense is the responsibility of the
US','d7cf55da34088dc65cc449c8b4d6610fe516771bdf88ae6b7e31bcd7950f045b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca61d7bef68686c26678fc58ad94bba53c890eaaa5374f48218b518cf25cc884',2001,'CR','Costa Rica','military-and-security',344,'Military branches: Coast Guard, Air Section,
Ministry of Public Security Force (Fuerza Publica)
note: Costa Rica has no military, only domestic police
forces, including the Coast Guard and Air Section
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:1,035,090 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 692,973 (2001 est.)
Military manpower - reaching military age
annually:
males: 39,41 1 (2001 est.)
Military expenditures - dollar figure: $69 million
(FY99)
Military expenditures - percent of GDP: 1 .6%
(FY99)','b4b1ccd8d49e2bf6ebd00970e9ad051edc47e81866a560ea9e945f8de1f1abfa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76efff1a4cf687a24c1f215a70c736bd2946b8a4ac60b1273d8566ac344c447d',2001,'SI','Slovenia','military-and-security',358,'Military branches: Ground Forces, Naval Forces,
Air and Air Defense Forces
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 1 ,085,877 (2001 est.)
Military manpower - fit for military service:
males age 15-49:859,621 (2001 est.)
Military manpower - reaching military age
annually;
mates; 30,037 (2001 est.)
Military expenditures - dollar figure; $575 million
(2000)
Military expenditures - percent of GDP: 3.8%
(2000)','1ab47fc0a0c0ad07ea639db12ee1e85b532e72fefb2ab5f64c74a8af479faeed','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5d10d9a981ef2b506922788ea584af8b88a7f3d753359956cba7164a34b6048',2001,'CU','Cuba','military-and-security',367,'Military branches: Revolutionary Armed Forces
(FAR) includes ground forces. Revolutionary Navy
(MGR), Air and Air Defense Force (DAAFAR),
Territorial Troops Militia (MTT), and Youth Labor Army
(EJT); the Border Guard (TGF) is controlled by the
Interior Ministry
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 3,090,633
females age t5-49.- 3,029,274 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49: 1 ,91 1 ,1 60
females age /5-49: 1,867,958 (2001 est.)
Military manpower - reaching military age
annually:
males: 79,562
females: 85,650 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: roughly
4% (FY95 est.)
Military - note: Moscow, for decades the key military
supporter and supplier of Cuba, cut off almost all
military aid by 1993
Military branches: Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force
have been demobilized but still exist on paper until
constitutionally abolished
Military manpower - military age: 18 years of age
Military manpower - availability;
males age r5-49; 1,635,253 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 888,305 (2001 est.)
Military manpower - reaching military age
annually:
mates; 87,049 (2001 est.)
Military expenditures - dollar figure: $NA; note ■
mainly for police and security activities
Military expenditures - percent of GDP: NA%','14ff655cbc2bee38520e6e16ed726a5478c0e287642a9b4048c3ed371c3c005f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ae20d987bd1e64a0c499cfb39c7e44da0322f7db71bd2f08c87ebb0037e08e0',2001,'CY','Cyprus','military-and-security',376,'Military branches: Greek Cypriot area: Greek
Cypriot National Guard (GCNG; includes air and naval
elements), Hellenic Forces Contingent on Cyprus
(ELDYK), Greek Cypriot Police; Turkish Cypriot area:
Turkish Cypriot Security Force (TCSF), Turkish
mainland army units
Military manpower ■ military age: 18 years of age
Military manpower - availability:
males age 15-49: 198,275 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 136,147 (2001 est.)
Military manpower - reaching military age
annually:
ma/es,'' 6,616 (2001 est.)
Military expenditures - dollar figure: $370 million
(FYOO)
Military expenditures - percent of GDP: 4.2%
(FYOO)
Military branches: Army, Air and Air Defense
Forces, Territorial Defense, Railroad Units
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age f 5-49.* 2,653,456 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,024,070 (2001 est.)
Military manpower - reaching military age
annually:
males: 69,393 (2001 est.)
Military expenditures - dollar figure: $1 .2 billion
(FY01)
Military expenditures - percent of GDP: 2.2%
(FY01)
Military branches: Royal Danish Army, Royal
Danish Navy, Royal Danish Air Force, Home Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 292, 819 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,106,094 (2001 est.)
Military manpower - reaching military age
annually:
mates.'' 29,21 2 (2001 est.)
Military expenditures - dollar figure: $2.47 billion
(FY99)
Military expenditures - percent of GDP: 1 .4%
(FY99)','790544743351e227ff5350d55abba32c67201b45b461b9782fd0d40db49ef6a3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24e6dfc3d63d16bcabf127f37874533edd9a088780a9606193f9c95fa9268aae',2001,'DJ','Djibouti','military-and-security',385,'Military branches: Djibouti National Army (includes
Navy and Air Force)
Military manpower - availability:
males age 15-49: 108,038 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 63,589 (2001 est.)
Military expenditures - dollar figure: $23 million
(FY97)
Military expenditures - percent of GDP: 4.5%
(FY97)
Military branches: Commonwealth of Dominica
Police Force (includes Special Service Unit, Coast
Guard)
Military expenditures - dollar figure: $NA
Military expenditures ■ percent of GDP: NA%','34892f58e1312deb2aec0e705aa2751b81c040101e4070d361ab6e76e567f526','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06c25589758574d6d4c0835ae75dfaf411ae6d3303bf69d2bd970d2cd393ff4b',2001,'DO','Dominican Republic','military-and-security',393,'Military branches: Army, Navy, Air Force, National
Police
Military manpower ■ military age: 18 years of age
Military manpower - availability:
males age 75-49; 2,281 ,035 (2001 est.)
Military manpower - fit for military service:
males age 75-49; 1 ,430,776 (2001 est.)
146
Dominican Repubiic (continued)
Military manpower ■ reaching military age
annually:
males: 87, m (2001 est.)
Military expenditures - dollar figure: $1 80 million
(FY98)
Military expenditures - percent of GDP: 1,1%
(FY98)
Military branches: paramilitary National Guard,
Police Force
Military - note; defense is the responsibility of the
US','213c1d18d434c0a2fbd73138bf50076185f163889655f201ca7b375331a84679','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('027a481fda25525ee9825b14fb0dbda36d5b9717cd353a8fec675dab6828edc9',2001,'PE','Peru','military-and-security',402,'Military branches: Army (Ejercito Ecuatoriano),
Navy (Armada Ecuatoriana, includes Marines), Air
Force (Fuerza Aerea Ecuatoriana), National Police
(Policia Nacional)
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 3,382,567 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 2,280,899 (2001 est.)
Military manpower - reaching military age
annually:
males: 132,978 (2001 est.)
Military expenditures - dollar figure: $720 million
(FY98)
Military expenditures - percent of GDP: 3.4%
(FY98)
Military branches: Army (Ejercito Peruano), Navy
(Marina de Guerra del Peru; includes Naval Air,
Marines, and Coast Guard), Air Force (Fuerza Aerea
del Peru), National Police (Policia Nacional)
Military manpower ■ military age: 20 years of age
Military manpower - availability:
males age 15-49:7,205,675 (2001 est.)
Military manpower - fit for military service:
males age 15-49:4,647,250 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 276,458 (2001 est.)
Military expenditures ■ dollar figure: $1 billion
(FYOO)
Military expenditures - percent of GDP: 1 .9%
(FYOO)','c6706146de442867928116aeb4d3cc1b2280060862fbd971e6ba879aea534181','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b0b1930f64e90ada0db3e12b96c9c46ffe6765a31806bb2add6807c5e4a57c2',2001,'EG','Egypt','military-and-security',411,'Military branches: Army, Navy, Air Force, Air
Defense Command
Military manpower - military age: 20 years of age
Military manpower » availability:
males age 15-49: 18,562,994 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 12,020,059 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 712,983 (2001 est.)
Military expenditures - dollar figure: $4.04 billion
(FY99/00)
Military expenditures ■ percent of GDP: 4.1%
(FY99/00)','f8fdbcd9c04f597f7f6a6c597252d575ae7ff1f7dc325b32564d3dd5f1079966','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c32e37d5c78eaeaa849b8efd9712604d04aeebeec75602dab5d616fe56407b6',2001,'SV','El Salvador','military-and-security',420,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 75-49; 1,464,898 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 929,263 (2001 est.)
Military manpower - reaching military age
annually:
males: 68, m (2001 est.)
Military expenditures - dollar figure: $112 million
(FY99)
Military expenditures - percent of GDP: 0.7%
(FY99)','a9a6d84e983aae257e8fae3675c674cb024e735518cd8882a8caa0782e8c4000','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82199bbb4cd59a410f6238364a5b7fb279bff90d64ecfdad151b2f16ade52dc3',2001,'GN','Guinea','military-and-security',429,'Military branches: Army, Navy, Air Force, Rapid
Intervention Force, National Police
Military manpower - availability:
males age 15-49: 108,973 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 55,347 (2001 est.)
Military expenditures ■ dollar figure: $3 million
(FY97/98)
Military expenditures ■ percent of GDP: 0.6%
(FY97/98)
Military branches: Army, Navy, Air Force
Military expenditures - dollar figure: $1 60 million
(2000 est.)
Military expenditures - percent of GDP: 29.4%
(2000 est.)
Military branches: Army, Navy, Air Force,
Republican Guard, Presidential Guard, paramilitary
National Gendarmerie, National Police Force (Surete
National)
Military manpower - availability:
males age /5-45; 1,764,912 (2001 est.)
Miiitary manpower - fit for military service:
males age 15-49: 891 ,166 (2001 est.)
Military expenditures - dollar figure: $56 million
(FY96)
Military expenditures - percent of GDP: 1 .4%
(FY96)
Military branches: Papua New Guinea Defense
Force (includes Ground, Naval, and Air Forces, and
Special Forces Unit)
Military manpower - availability:
males age )5-49; 1,306,159 (2001 est.)
Military manpower - fit for military service:
males age 15-49:723,012 (2001 est.)
Military expenditures - dollar figure: $42 million
(FY98)
Military expenditures - percent of GDP: 1%
(FY98)','89979a941585c0e62163e6483383a0fbfb42d294b82cdab06496425366454cd7','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('101f6afbb48150fe0231fc02311c6240a50df082ba8d993690c2593519c02b2a',2001,'EE','Estonia','military-and-security',441,'Military branches: Ground Forces, Navy/Coast
Guard, Air and Air Defense Force (not officially
sanctioned). Maritime Border Guard, Volunteer
Defense League (Kaitseliit), Security Forces (internal
and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 359,677 (2001 est.)
Military manpower - fit for military service:
males age 15-49:282,418 (2001 est.)
Military manpower - reaching military age
annually:
mates; 11,164 (2001 est.)
Military expenditures - dollar figure: $70 million
(FY99)
Military expenditures ■ percent of GDP: 1 .2%
(FY99)','c226d1bdba2d8eb6fa4a782ec4ab347c67348b64b81447a23226c74252b0fa8b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d76bef9369f332241c292933518b0d973b1c9848f0db09904c549e1bfcf11cf0',2001,'FO','Faroe Islands','military-and-security',449,'Military branches: defense is the responsibility of
Denmark: no organized native military forces; only a
small Police Force and Coast Guard are maintained
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of','6aa7edbdc31c5f0be381877f728b797f9aed3d1f7cf89684791a789dd2b439cd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37227f2b67d6538abfa834d2bac26fe9bab133d0a49462be9e92ac7b19f49ba7',2001,'JE','Jersey','military-and-security',463,'Military branches: Army, Navy, Air Force, Frontier
Guard (includes Sea Guard)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 1 ,251 ,700 (2001 est.)
Military manpower - fit for military service:
males age 75-49; 1,033,188 (2001 est.)
Military manpower - reaching military age
annually:
males: 33,883 (2001 est.)
Military expenditures ■ dollar figure: $1 .8 billion
(FY98)
Military expenditures - percent of GDP: 2% (FY98)
Military branches: Army, Navy, Air Force, National
Police Force, National Guard, Coast Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 780,559 (2001 est.)
Military manpower - fit for military service:
males age 75-49; 466,521 (2001 est.)
Military manpower - reaching military age
annually:
mates; 18,309 (2001 est.)
Military expenditures - dollar figure: $1 .9 billion
(FYOO/01)
Military expenditures - percent of GDP: 8.7%
(FYOO/01)
Military branches: French Armed Forces (Army,
Navy, Air Force, Gendarmerie); Police Force
Military expenditures ■ dollar figure: $1 92.3
million (1996)
Military expenditures • percent of GDP: 5.3%
(1996)
Military - note: defense is the responsibility of
Military branches: Slovenian Army (includes Air
and Naval Forces)
Military manpower - military age; 1 9 years of age
Military manpower - availability:
males age 15-49: 523,336 (2001 est.)
Military manpower - fit for military service:
males age 15-49:416,237 (2001 est.)
Military manpower - reaching military age
annually:
ma/es.- 14,513 (2001 est.)
Military expenditures - dollar figure: $370 million
(FYOO)
Military expenditures - percent of GDP: 1 .7%
(FYOO)
Military branches: Umbutfo Swaziland Defense
Force (Army), Royal Swaziland Police Force
Military manpower - availability:
males age 15-49:246,064 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49:143,618(2001 est.)
Military expenditures ■ dollar figure: $19,198
million (FYOO/01)
Military expenditures - percent of GDP; 4.75%
(FYOO/01)
482
Swaziland (continued)
Military branches: Swedish Army, Royal Swedish
Navy, Swedish Air Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49:2,062,566 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,803,995 (2001 est.)
Military manpower - reaching military age
annually:
mates; 51 ,506 (2001 est.)
Military expenditures ■ dollar figure: $5 billion
(FY98)
Telephones ■ main lines in use: 6.017 million
(December 1998)
Telephones - mobile cellular: 3.835 million
(October 1998)
Telephone system:
general assessment: excellent domestic and
international facilities; automatic system
domestic: coaxial and multiconductor cables carry
most of the voice traffic; parallel microwave radio relay
systems carry some additional telephone channels
international: 5 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean), 1 Eutelsat,
and 1 Inmarsat (Atlantic and Indian Ocean regions);
note - Sweden shares the Inmarsat earth station with
the other Nordic countries (Denmark, Finland,
Iceland, and Norway)
Radio broadcast stations; AM 1 , FM 265,
shortwave 1 (1998)
Radios: 8.25 million (1997)
Military expenditures ■ percent of GDP: 2.1%
(FY98)','ee03a46ac03c1071663126d4c8dfcbf6b6616bb0b618346cad4903b4d5d0bfb3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca85199527b7b59a18827286269e768e02e4975a8478fff22d18558f0e97850a',2001,'WF','Wallis and Futuna','military-and-security',468,'Military branches: Army (includes Marines), Navy
(includes Naval Air), Air Force (includes Air Defense),
National Gendarmerie
Military manpower ■ military age: 18 years of age
Military manpower - availability:
males age 15-49: 14,573,199 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 12,127,793 (2001 est.)
Military manpower - reaching military age
annually:
mates; 390,064 (2001 est.)
Military expenditures - dollar figure: $39,831
billion (FY97)
Military expenditures - percent of GDP: 2.5%
(FY97)','615ac9f7a7806bf376c2b9a6c397329d761a9fc18c4fa247b782f616962e9f1f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('958dd919a0ce7e7b6de29ed63a63ebf7a9063b8415a712b36d655fb167823c94',2001,'KI','Kiribati','military-and-security',483,'Military branches: French Forces (includes Army,
Navy, Air Force), Gendarmerie
Military - note: defense is the responsibility of
Military branches: no regular military forces; Police
Force (carries out law enforcement functions and
paramilitary duties; small police posts are on all
islands)
Military expenditures - dollar figure: $NA
Military expenditures ■ percent of GDP: NA%
Military - note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
Military branches: Korean People''s Army (includes
Army, Navy, Air Force), Civil Security Forces
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:5,943,735 (2001 est.)
Military manpower - fit for military service;
males age 15-49:3,574,050 (2001 est.)
Military manpower - reaching military age
annually:
males: 179,136 (2001 est.)
Military expenditures - dollar figure: $3.7 billion to
$4.9 billion (FY98 est.)
Military expenditures - percent of GDP: 25% to
33% (FY98 est.)
Military branches: Army, Navy, Air Force, Marine
Corps, National Maritime Police (Coast Guard)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 14,148,552 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 8,979,778 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 394,397 (2001 est.)
Military expenditures - dollar figure: $12 billion
(2000)
Military expenditures - percent of GDP: 3.2%
(FY98/99)','5118fef3a2e0d404e67a14b528a9f63fdf91580605b571895c51b33431f7c269','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdac14d3b5b1af4fa019941c99f627d34fa753934fe63f704ddd72a6738acff4',2001,'DE','Germany','military-and-security',490,'Military branches: Army, Navy (includes Naval Air
Arm), Air Force, Medical Corps, Border Police, Coast
Guard
Military manpower ■ military age: 18 years of age
Military manpower ■ availability:
males age 15^49:20,851,022 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 17,760,412 (2001 est.)
Military manpower - reaching military age
annually:
mates.'' 482,31 8 (2001 est.)
Military expenditures - dollar figure: $32.8 billion
(FY98)
Military expenditures - percent of GDP: 1 .5%
(FY98)
Military branches: Army; note - the government
abolished the Gendarmerie
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 1 12,714 (2001 est.)
Military manpower - fit for military service:
males age 15-49:92,817 (2001 est.)
Military manpower - reaching military age
annually:
males: 2,565 (2001 est.)
Military expenditures - dollar figure: $131 million
(FY98/99)
Military expenditures - percent of GDP: 1%
(FY98/99)
Military branches: Macau garrison of China''s
People''s Liberation Army (PLA) includes about 500
troops
Military manpower - availability:
males age 1549: 125,737 (2001 est.)
Military manpower - fit for military service:
males age 15-49:69,191 (2001 est.)
Military - note: responsibility for defense reverted to
China on 20 December 1999
Military branches: Army (includes Air and Air
Defense Forces), Police Force
Military manpower ■ military age: 1 9 years of age
Military manpower - availability:
males age 75-49; 548,183 (2001 est.)
Military manpower - fit for military service:
males age 75-49; 442,053 (2001 est.)
Military manpower - reaching military age
annually:
males: 17,905 (2001 est.)
Military expenditures - dollar figure: $76.3 million
(FYOO/01)
Military expenditures - percent of GDP: 2.17%
(FYOO/01)
Military branches: Royal Netherlands Army, Royal
Netherlands Navy (includes Naval Air Service and
Marine Corps), Royal Netherlands Air Force, Royal
Constabulary
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 4,083,349 (2001 est.)
Military manpower - fit for military service:
males age 15-49:3,555,501 (2001 est.)
Military manpower ■ reaching military age
annually:
mates.- 96,082 (2001 est.)
Military expenditures - dollar figure: $6.5 billion
(FYOO/01 est.)
Military expenditures ■ percent of GDP: 1 .5%
(FYOO/01 est.)','c504b9c2e932cb152f9137fc808829ee11bf16f55e3ef56da3bd79726df614b3','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63e53cbb089f8c38a0f4b6fa77cd50c740991ce611d296ca177b6375f52ef66b',2001,'GH','Ghana','military-and-security',499,'Military branches: Army, Navy, Air Force, National
Police Force, Palace Guard, Civil Defense
Military manpower ■ military age: 18 years of age
Military manpower - availability:
males age 15-49: 4,890,483 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,713,584 (2001 est.)
Military manpower - reaching military age
annually:
mates; 21 3,237 (2001 est.)
Military expenditures - dollar figure: $53 million
(FY99)
Military expenditures - percent of GDP: 0.7%
(FY99)','39df5877945252c2493e1fe24b8065e82c71828abe36c08015ae3e3e0b2d4fb2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32433b01b646c979e10a9ef21e34f7e0b266867ba47f4a708f00dd90a9514bca',2001,'GI','Gibraltar','military-and-security',507,'Military branches: British Army, Royal Navy, Royal
Air Force
Military - note: defense is the responsibility of the
UK
Military - note: defense is the responsibility of
Military branches: Royal Armed Forces (includes
Army, Navy, Air Force), Gendarmerie, Auxiliary
Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49.* 8,182,073 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 5,160,374 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 348,380 (2001 est.)
Military expenditures - dollar figure: $1 .4 billion
(FY99/00)
Military expenditures ■ percent of GDP: 4%
(FY99/00)','64e8a18ae96f1a2b9a66ed3c42e77129bbed16eb240156a466e663e63a2921ea','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cec6538394aa9dd946534c2db8c6d961ac93655e3c1b652cc6617506454bbb8f',2001,'GR','Greece','military-and-security',516,'Military branches: Hellenic Army, Hellenic Navy,
Hellenic Air Force, National Guard, Police
Military manpower - military age: 21 years of age
Military manpower ■ availability:
males age 1&49: 2,673,539 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,040,227 (2001 est.)
Military manpower - reaching military age
annually:
males: 77,976 (2001 est.)
Military expenditures - dollar figure: $6.12 billion
(FY99/00 est.)
Military expenditures ■ percent of GDP: 4.91%
(FY99/00 est.)','1024c8f7da7c0a4b294ad21421d84fa437603ce6f2de26e5ad0f3e100c426056','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a56af15783b794a5365099a3f8eb966e83c8b4bd2d3487cb7607c7a7ad71d19d',2001,'GD','Grenada','military-and-security',531,'Military branches: Royal Grenada Police Force
(includes Special Service Unit), Coast Guard
Military expenditures ■ dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Royal Saint Vincent and the
Grenadines Police Force (includes Special Service
Unit), Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','2ab3010ee405f7e5007f1dde3fc59c42639d9331e7bc9cc1afd12554e79b999b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c5e96a38f648b58e725dfb5d62ff056f0069623321cb22093d2e1966e68dbc3',2001,'GT','Guatemala','military-and-security',549,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 3,092,050 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49:2,018,888 (2001 est.)
Military manpower - reaching military age
annually:
males: 140,358 (2001 est.)
Military expenditures - dollar figure: $120 million
(FY99)
Military expenditures - percent of GDP: 0.6%
(FY99)','724aeecb68b110f0d6ea1012aafeb9747c123898cd49c37d0f591bac70c57615','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9e4c22ae6dd81d45ff51b61be5a022c057c1c7f95b476e3d1734a54913e0ffa',2001,'GY','Guyana','military-and-security',567,'Military branches: Guyana Defense Force (GDF;
includes Ground Forces, Coast Guard, and Air
Corps), Guyana People''s Militia (GPM), Guyana
National Service (GNS), Guyana Police Force
Military manpower ■ availability:
males age 1549: 204,938 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 154,259 (2001 est.)
Military expenditures ■ dollar figure: $7 miliion
(FY94)
Military expenditures - percent of GDP: 1 .7%
(FY94)
Military branches: National Army (includes small
Navy and Air Force elements), Civil Police
Military manpower - availability:
males age 15-49: 121,656 (2001 est.)
Military manpower - fit for military service:
males age 15-49:71,344 (2001 est.)
Military expenditures - dollar figure: $8.5 million
(FY97 est.)
Military expenditures ■ percent of GDP: 1 .6%
(FY97 est.)
Military - note: demilitarized by treaty (9 February
1920)','dda620b58cfe8dc1f2d3d5bc9252d646c570d5426c141ac36911821a673b35fb','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49b77593aaa049dec28567cbb6ac73439e7b5e1c1f3950178f66f3c18d59d040',2001,'HK','Hong Kong','military-and-security',578,'Military branches: Hong Kong garrison of China’s
People''s Liberation Army (PLA) including elements of
the PLA Ground Forces, PLA Navy, and PLA Air
Force; these forces are under the direct leadership of
the Central Military Commission in Beijing and under
administrative control of the adjacent Guangzhou
Military Region
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49; 2,020,937 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,520,531 (2001 est.)
Military manpower - reaching military age
annually:
mates; 47,139 (2001 est.)
Military expenditures - dollar figure: $NA; note -
separate budget for Hong Kong not established by','aec20240db4166a4619dc88240643dc47a25e406b8881ef2191b24f761b79af2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68050c55079ffca6381fdfb991d9a6f52daae81e59d307d898111814c64d0afd',2001,'AT','Austria','military-and-security',590,'Military branches: Army, Navy (including naval air
arm). Air Force, various security or paramilitary forces
(includes Border Security Force, Assam Rifles,
Rashtriya Rifles, and National Security Guards)
Military manpower - military age: 1 7 years of age
Military manpower - availability:
males age f5-49; 280,204,502 (2001 est.)
235
India (continued)
Military manpower - fit for military service;
males age 164,41 0,461 (2001 est.)
Military manpower - reaching military age
annually:
ma/es: 10,879,384 (2001 est.)
Military expenditures - dollar figure: $13.02 billion
(FY01)
Military expenditures - percent of GDP: 2.5%
(FYOO)
Military branches: Army, Navy, Air Force, Marines
note: as of 1 July 2000, the National Police became an
independent organization that reports directly to the
president
Military manpower - military age: 1 8 years of age
Military manpower ■ availability:
males age 15-49: 64,046,049 (2001 est.)
Military manpower - fit for military service:
males age 15-49:37,418,755 (2001 est.)
Military manpower - reaching military age
annually:
males: 2,263,706 (2001 est.)
Military expenditures - dollar figure: $1 billion
(FY98/99)
Military expenditures - percent of GDP: 1 .3%
(FY98/99)
Miiitary branches: Islamic Republic of Iran regular
forces (includes Ground Forces, Navy, Air and Air
Defense Forces), Revolutionary Guards (includes
Ground, Air, Navy, Qods, and
Basij-mobilization-forces), Law Enforcement Forces
Military manpower - military age: 21 years of age
Military manpower - availability:
males age 15-49: 18,319,328 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 10,872,407 (2001 est.)
Military manpower - reaching military age
annually:
ma/es.* 823,040 (2001 est.)
Military expenditures - dollar figure: $5,787 billion
(FY98/99)
Military expenditures - percent of GDP: 2.9%
(FY98/99)
Military branches: Army, Republican Guard, Navy,
Air Force, Air Defense Force, Border Guard Force,
Fedayeen Saddam
Military manpower - military age: 1 8 years of age
Military manpower ■ availability:
males age 15-49: 5,902,215 (2001 est.)
Military manpower - fit for military service;
males age 15-49: 3,301 ,880 (2001 est.)
Military manpower - reaching military age
annually:
mates.- 274,035 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','1434c306a5478f242faec2f7d8290e5aaf5a66ee7840c839e6b57054c4a4fdf8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc2b1cc01ec6304094c3be0a68490dce1e79205952495152df0e807ad9a4541c',2001,'IE','Ireland','military-and-security',598,'Military branches: Army (includes Naval Service
and Air Corps), National Police (Garda Siochana)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 1 ,004,469 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49: 809,808 (2001 est.)
Military manpower - reaching military age
annually:
males: 32,287 (2001 est.)
Military expenditures - dollar figure: $738 million
(2001 est.)
Military expenditures - percent of GDP: 0.75%
(2001 est.)','ca9059fe9ef110fd83fd1b3a6ff8efa48e4b355ac3f8efb9704a828cddea6e78','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d002a4e52749ccfceabb85e2eee4c853a341a615094b86553de6735867e09a6',2001,'IL','Israel','military-and-security',606,'Military branches: Israel Defense Forces (includes
ground, naval, and air components). Pioneer Fighting
Youth (Nahal), Frontier Guard, Chen (women); note -
historically there have been no separate Israeli
military services
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,522,003
females age /5-49; 1,482,027 (2001 est.)
Military manpower - fit for military service:
males age 15-49:), 245, 757
females age 15-49:), 203,973 (2001 est.)
Military manpower - reaching military age
annually:
males: 49,206
females: 53,379 (2001 est.)
Military expenditures - dollar figure: $8.7 billion
(FY99)
Military expenditures - percent of GDP: 9.4%
(FY99)','d624830bf9ac96acb72a99eb5904491a7b30ca167df431ffd7400904d4987d53','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b42727ba6331c3de4fb1c542c0a60fbd986f03f213369042a9777a15d884b98',2001,'TN','Tunisia','military-and-security',614,'Military branches: Army, Navy, Air Force,
Carabinieri
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 14,248,674 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 12,244,166 (2001 est.)
Military manpower ■ reaching military age
annually:
mates.'' 304,369 (2001 est.)
Military expenditures - dollar figure: $20.7 billion
(FYOO/01)
Military expenditures >• percent of GDP: 1 .7%
(FYOO/01)
Military branches: Army, Navy, Air Force,
paramilitary forces. National Guard
Military manpower ■ military age: 20 years of age
Military manpower - availability:
males age 75-49:2,739,566 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,561 ,484 (2001 est.)
Military manpower - reaching military age
annually:
ma/es: 105,146 (2001 est.)
Military expenditures - dollar figure: $356 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
Military branches: Land Force, Navy (includes
Naval Air and Naval Infantry), Air Force, Coast Guard,
Gendarmerie
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 18,882,272 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49:11,432,438 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 674,805 (2001 est.)
Military expenditures - dollar figure: $10.6 billion
(FY99)
Military expenditures - percent of GDP: 5.6%
(FY99)
Military branches: Ministry of Defense (Army, Air
and Air Defense, Navy, Border Troops, and Internal
Troops), National Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,173,500 (2001 est.)
Military manpower - fit for military service:
males age 15-49:982,218 (2001 est.)
Military manpower - reaching military age
annually:
males: A8, 292 (2001 est.)
Military expenditures - dollar figure: $90 million
(FY99)
Military expenditures - percent of GDP: 3,4%
(FY99)
Military - note: defense is the responsibility of the
UK','222ba305b6d31d531c5ade9985f6af0fb32fc6bf34b9f9fecc6c79020745b3f9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28b1b9232c17ea628feb163560e7583c2d6453a19065c2636d4b02a622d43b7a',2001,'JM','Jamaica','military-and-security',623,'Military branches: Jamaica Defense Force
(includes Ground Forces, Coast Guard, and Air
Wing), Jamaica Constabulary Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49:736,627 (2001 est.)
Military manpower - fit for military service:
males age 1549: 517,077 (2001 est.)
Military manpower - reaching military age
annually:
males: 27,729 (2001 est.)
Military expenditures - dollar figure: $30 million
(FY95/96 est.)
Military expenditures - percent of GDP: NA%','f1f824ad4df9d0f102d64914a1c998e891c0ba3f0060b33ab2ac00d79ee77244','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3c54414d04d4f9102059cab1822b16f86b23d354dd2652b9101cac312ae8d47',2001,'NO','Norway','military-and-security',635,'Military branches: Japan Ground Self-Defense
Force (Army), Japan Maritime Self-Defense Force
(Navy), Japan Air Self-Defense Force (Air Force)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age /5-49.’ 29,926,614 (2001 est.)
Military manpower - fit for military service;
males age 15-49: 25,876,484 (2001 est.)
Military manpower - reaching military age
annually;
ma/es.'' 765,817 (2001 est.)
Military expenditures - dollar figure: $43 billion
(FY01)
Military expenditures - percent of GDP: 0.96%
(FY01)
Military branches: Norwegian Army, Royal
Norwegian Navy (includes Coast Artillery and Coast
Guard), Royal Norwegian Air Force, Flome Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49; 1,101,384 (2001 est.)
Military manpower - fit for military service:
males age 15-49; 913,534 (2001 est.)
Military manpower - reaching miiitary age
annually:
males: 27,341 (2001 est.)
Military expenditures - dollar figure: $3.1 13 billion
(FY98)
Miiitary expenditures - percent of GDP: 2.1%
(FY98)
Military branches: Army, Navy, Air Force,
paramilitary (includes Royal Oman Police)
Military manpower - military age; 14 years of age
Military manpower - availability:
males age 15-49: 771 ,91 9 (2001 est.)
Military manpower - fit for military service:
males age 75-49; 429,811 (2001 est.)
Military manpower ■ reaching military age
annually:
males: 26,469 (2001 est.)
Military expenditures - dollar figure: $2.4 billion
(FYOO)
Military expenditures - percent of GDP: 1 3%
(FYOO)
Military branches: Army, Navy, Air Force, Civil
Armed Forces, National Guard
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49:35,770,928 (2001 est.)
Military manpower - fit for military service:
males age 15-49:21,897,366 (2001 est.)
Military manpower - reaching military age
annually:
ma/es.'' 1,657,723 (2001 est.)
Military expenditures - dollar figure: $2,435 billion
(FY99/00)
Military expenditures - percent of GDP: 3.9%
(FY99/00)
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
US; under a Compact of Free Association between
Palau and the US, the US military is granted access to
the islands for 50 years','375b191832a6251de841442e18ec3208be319589ade7a6a45630474c124ca053','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abe21e3a281533ea6f261ddec958bc9506ac896191c6eca143894dd06ae5f85e',2001,'JO','Jordan','military-and-security',643,'Military branches: Jordanian Armed Forces (JAF;
includes Royal Jordanian Land Force, Royal Naval
Force, and Royal Jordanian Air Force); Ministry of the
Interior''s Public Security Force (falls under JAF only in
wartime or crisis situations)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 1 ,458,571 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,034,109 (2001 est.)
Military manpower - reaching military age
annually:
males: 57,131 (2001 est.)
Military expenditures - dollar figure: $608.9
million (FY98/99)
Military expenditures - percent of GDP: 7.8%
(FY98/99)
Juan de Nova
Island
(possession of France)','38295549872b19487cac2187d9aaccf4d9af93471afae70dbcb91b4c8e7a1684','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0484e5a37e2094afcfdc72cfa02c2cef317d05b525d764d439ea492b12b232f',2001,'KZ','Kazakhstan','military-and-security',652,'Military branches; General Purpose Forces (Army),
Air Force, Border Guards, Navy, Republican Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:4,509,179 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 3,598,859 (2001 est.)
Military manpower - reaching military age
annually:
males: 163,628 (2001 est.)
Military expenditures ■ dollar figure: $322 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)','172af638409f5d11bde6b89658f647a5f66ff025fadce5c78722a7b5221b592d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9892d570c7f1b2ff5a0e8bc262e62ac84578f049a5f6feed69ec60ed419325c5',2001,'KE','Kenya','military-and-security',661,'Military branches: Army, Navy, Air Force,
paramilitary General Service Unit of the Police
Military manpower ■ availability:
males age 1549:7,712,402 (2001 est.)
Military manpower - fit for military service:
males age 15-49:4,774,889 (2001 est.)
Military expenditures - dollar figure: $197 million
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)','45c66233154985ff1ed83443c44d67f678d3780902ef888dec6d6d48a4127b0b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c59c71bed98deb084086b917a66bc5d97131072adf82007ca21d7638aed52afd',2001,'WS','Samoa','military-and-security',668,'Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of the
US
Military branches: no regular armed services;
Samoa Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZ, which Is required to consider any
Samoan request for assistance under the 1962 Treaty
of Friendship','70c33c57d05100937653f0876f191e16fe223addd0dc86d8951160c41d8b573c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e5b855d35257447e91bbd7c4001af5cf5c390c1c05456fc601882bab43f7ac4',2001,'KG','Kyrgyzstan','military-and-security',677,'Military branches: Army, Air and Air Defense,
Security Forces, Border Troops
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 203, 00^ (2001 est.)
Military manpower - fit for military service:
males age 15-49:975,744 (2001 est.)
Military manpower - reaching military age
annually:
males: 50,590 (2001 est.)
Military expenditures - dollar figure: $1 2 million
(FY99)
Military expenditures - percent of GDP: 1 %
(FY99)
Military branches: Lao People''s Army (LPA;
includes riverine element). Air Force, National Police
Department
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age /5-49; 1,319,537 (2001 est.)
Military manpower - fit for military service:
males age 15-49:7:0,627 (2001 est.)
Military manpower - reaching military age
annually:
mates; 64,437 (2001 est.)
Military expenditures - dollar figure: $55 million
(FY98)
Military expenditures - percent of GDP: 4.2%
(FY96/97)','4f8e199d82685eb78aa9f62e3154be32bb0a6ff7bb643779111050018b35a273','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('321ff6843cb8e5d3d42b35bbd515cc3c6c8a76d2197aa877f87a7c3e4b2d1c5e',2001,'LV','Latvia','military-and-security',686,'Military branches: Ground Forces, Navy, Air and Air
Defense Forces, Security Forces, Border Guard,
Home Guard (Zemessardze)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 590,784 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 463,944 (2001 est.)
Military manpower - reaching mliitary age
annually:
males: 19,114(2001 est.)
Military expenditures > dollar figure: $60 million
(FY99)
Military expenditures - percent of GDP: 0.9%
(FY99)','eabf886432ed7f46dd8249f7a86a676cac9a4b82dab46fafbcefe71256d3d3ed','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c982431fe98b7464f6c992b9ef30dfd5833d1f6b058c8158a4a316f1a6a6011',2001,'LB','Lebanon','military-and-security',695,'Military branches: Lebanese Armed Forces (LAF;
includes Army, Navy, and Air Force)
Military manpower - availability:
males age 15-49: 980,412 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 605,332 (2001 est.)
Military expenditures - dollar figure: $343 million
(FY99/00)
Military expenditures ■ percent of GDP: 4.8%
(FY99/00)','5838ccb150850f968596709ef4e484998d2876d776065113d6d4bcdb03d3ade2','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3f8583f8e2c51ed771ffdaed718ef3e73f2c540012a9e0df5cbad6880e5b1eb',2001,'ZA','South Africa','military-and-security',702,'Military branches: Lesotho Defense Force (LDF;
includes Army and Air Wing), Royal Lesotho Mounted
Police (RLMP)
Military manpower - availability:
males age f5-45; 51 5,464 (2001 est.)
Military manpower - fit for military service:
males age 15-49:277,369 (2001 est.)
Military expenditures - dollar figure: $34 million
(1999)
Military expenditures - percent of GDP: NA%
Military - note: The Lesotho Government in 1999
began an open debate on the future structure, size,
and role of the armed forces, especially considering
the Lesotho Defense Force''s (LDF) history of
intervening in political affairs.
Military branches: South African National Defense
Force or SANDF (includes Army, Navy, Air Force, and
Medical Services), South African Police Service or
SAPS
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age f5-49; 11,469,812 (2001 est.)
Military manpower - fit for military service;
males age 15-49: 6,977,328 (2001 est.)
Military manpower - reaching military age
annually:
mates.’ 466,399 (2001 est.)
Military expenditures - dollar figure: $2 billion
(FYOO/01)
Military expenditures - percent of GDP: 1 .5%
(FY99/00)
Military - note: the National Defense Force
continues to integrate former military, black
homelands forces, and ex-opposition forces
Military - note: defense is the responsibility of the
UK','fb14211577d0b61018326342eba412c17532dc5a840dc9d2e8eade757620264e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10c934deb5f6b9b01a72c2678df45c2f82bca4edecd32c1bb48fd9b2cf50825d',2001,'LR','Liberia','military-and-security',711,'Military branches: Army, Air Force, Navy
Military manpower - availability;
males age 15-49:715,753 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 385,460 (2001 est.)
Military expenditures - dollar figure: $1 million
(FY98)
Military expenditures - percent of GDP: 2%
(FY98)','eb255e3dbbff475310e31b434f38857aa298000d13c6b0ff606d9425cb4d8c84','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b19d18e5eda14b0a285ece58af235efc16a6c0c580bb49230073c3742d8c400a',2001,'LY','Libya','military-and-security',719,'Military branches: Army, Navy, Air and Air Defense
Command
Military manpower - military age: 1 7 years of age
Military manpower - avaiiabiiity:
males age f 5-49; 1,459,400 (2001 est.)
Military manpower - fit for miiitary service:
males age f5-49; 866,01 2 (2001 est.)
Military manpower - reaching military age
annuaily:
males: 61 m (2001 est.)
Military expenditures - doilar figure: $1 .3 billion
(FY99/00)
Military expenditures - percent of GDP: 3.9%
(FY99/00)
Transnationai Issues
Disputes - international: Libya claims about 1 9,400
sq km in northern Niger and also a part of
southeastern Algeria
296','53c7cf54fa3448544d5ea04ed1f2c69376dd5e46a430110319765c8fbca25147','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b35f70bbfe0f87ddc864c2347660113fa0ffee7ccafaacc5a0f3812d8cfd000',2001,'CH','Switzerland','military-and-security',733,'Military branches: Ground Forces, Navy, Air and Air
Defense Force, Security Forces (internal and border
troops). National Guard (Skat)
Military manpower - miiitary age: 18 years of age
Military manpower - avaliabiiity:
males age 15-49: 929,389 (2001 est.)
Miiitary manpower - fit for miiitary service:
males age 15-49: 730,363 (2001 est.)
Miiitary manpower - reaching military age
annually:
ma/es.‘ 28,506 (2001 est.)
Military expenditures - dollar figure: $181 million
(FY99)
Military expenditures - percent of GDP: 1 .66%
(FYOO)','bdb77a84af78614fae7498f4ed96a32d7349b053c5b9155447e22e4b67abc919','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('339b28e904c35d0f03fdc8b34257d3e7e9a8a6a6a402ab65c778ef251a20eee1',2001,'MG','Madagascar','military-and-security',742,'Military branches: Popular Armed Forces (includes
Intervention Forces, Development Forces, Aeronaval
Forces - includes Navy and Air Force), Gendarmerie,
Presidential Security Regiment
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 3,640,554 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,159,767 (2001 est.)
Military manpower - reaching military age
annually:
males: 153,856 (2001 est.)
Military expenditures - dollar figure: $29 million
(FY94)
Military expenditures - percent of GDP: 1 %
(FY94)','56af3d3352c693266354a237eb52e22d8bcebb68d99023480b57fec23ac0bc0b','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6aeae73849353caf4ce11b149d5a98097e26482351feb3e1194d07c3e0a9193',2001,'PH','Philippines','military-and-security',752,'Military branches: Army (includes Air Wing and
Naval Detachment), Police (includes paramilitary
Mobile Force Unit)
Military manpower - availability:
males age 75-49:2,466,708 (2001 est.)
Military manpower - fit for military service:
males age 75-49; 1,265,893 (2001 est.)
Military expenditures - dollar figure: $9.5 million
(FYOO/01)
Military expenditures - percent of GDP: 0.76%
(FYOO/01)
Military branches: Malaysian Army, Royal
Malaysian Navy, Royal Malaysian Air Force, Royal
Malaysian Police Force, Marine Police, Sarawak
Border Scouts
Military manpower - military age: 21 years of age
Military manpower ■ availability:
males age 15-49: 5,800,456 (2001 est.)
Military manpower - fit for military service:
males age 75-49.'' 3,51 4,023 (2001 est.)
Military manpower - reaching military age
annually:
males: 196,042 (2001 est.)
Military expenditures - dollar figure: $1 .69 billion
(FYOO est.)
314
Malaysia (continued)
Military expenditures - percent of GDP: 2.03%
(FYOO)
Military - note: occupied by China
Military branches: Army, Navy (includes Coast
Guard and Marine Corps), Air Force
Military manpower ■ military age: 20 years of age
Military manpower - availability:
males age 15^49:21,220,191 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 14,942,363 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 848, 181 (2001 est.)
Military expenditures - dollar figure: $995 million
(FY98)
Military expenditures - percent of GDP: 1 .5%
(FY98)
Military - note: Spratly Islands consist of more than
100 small islands or reefs, of which about 45 are
claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','2a1ea590d5b3c20fa9686b429ba3b7ec69c974e1645478e437cc067e5a90a711','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62d3804d22f0e94679695a0f76afc5b8c1aecd23b16dd23030d0f141b4e4506e',2001,'MV','Maldives','military-and-security',765,'Military branches: National Security Service
Military manpower - availability:
males age 15-49: 71 ,856 (2001 est.)
Military manpower - fit for military service:
males age 15-49:40,000 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','b7bcb7d6b1269b6f46c6caf1aeb16dc8a657babbbbff8f88c47e5045c819969d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac2f39604a49ff5dc560370bb0d27baa423112a5b395fa9b1b4c433277eeace0',2001,'MT','Malta','military-and-security',774,'Military branches: Army, Air Force, Gendarmerie,
Republican Guard, National Guard, National Police
(Surete Nationale)
Military manpower - availability:
males age f5-49; 2,284,632 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,309,812 (2001 est.)
Military branches; Armed Forces (including land
forces, an air squadron, a maritime squadron, and the
Revenue Security Corps), Maltese Police Force
Military manpower - availability:
males age 15-49: 98,953 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 78,783 (2001 est.)
Military expenditures - dollar figure: $201 million
(FY98)
Military expenditures - percent of GDP: 5.5%
(FY98)
Military ■ note: defense is the responsibility of the
UK','988eacfbc1600a0e705596c72c44bcfe7ced274b12741fc56842d1b9119d1856','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66310f77a0913e7ade38e55a4c1e3f95bf59b15d27296bcc792c51fc53146752',2001,'MH','Marshall Islands','military-and-security',789,'Military branches: no regular military forces (a
coast guard may be established); Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
US','8af9e5a6a7fd348f93449f2272615979d0db870c9e096cea8a4b0ab8949a1f88','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('540f2423fba21f7d3dd6084fc69bebde7a5d3320e3220900bc9e231942a47fe3',2001,'MR','Mauritania','military-and-security',801,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Guard, National Police,
Presidential Guard
Military manpower - availability:
males age ^5-49.* 624,375 (2001 est.)
Miiitary manpower - fit for military service:
males age 15-49: 302,699 (2001 est.)
Military expenditures -dollar figure: $41 million
(FY97/98)
Military expenditures - percent of GDP: 2.7%
(FY97/98)','f5d7af9ea773d3f14f87898f3fec2e9d7d70dc76645ac4b59e3593810ab8d550','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86baafd2000daee6e136cc37399324838d7f1abc5596db5d659659ae7e7b4ca3',2001,'MU','Mauritius','military-and-security',810,'Military branches: National Police Force (includes
the paramilitary Special Mobile Force or SMF and
National Coast Guard)
Military manpower - availability:
males age 15-49: 339,473 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49: 171,206 (2001 est.)
Military expenditures - dollar figure: $1 1 million
(FY97/98)
Military expenditures - percent of GDP: 0.3%
(FY97/98)','fc6b1fb1616f93d31c210daef34ac530a5deb9b18b73dd2653782b9ccabf6f52','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa96da963cd50bcdf47d78cdb8213f8a3da033f321443a2fc51504674cc90b5b',2001,'YT','Mayotte','military-and-security',819,'Military - note: defense is the responsibility of
France; small contingent of French forces stationed
on the island','c14c91599d57a098f46b075425b91068423931b2fb1849e349c137de62d62892','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67b8b44ba466ab10694325c2f2167a90a65b60005d53fe7a239601a9b75919b0',2001,'US','United States','military-and-security',829,'Military branches: National Defense Secretariat
(includes Army and Air Force), Navy Secretariat
(includes Naval Air and Naval Infantry)
Military manpower - military age; 18 years of age
note: starting in 2000, females will be allowed to
volunteer for military service
Military manpower - availability:
males age f 5-49; 26,703,300 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 19,394,184 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 1,077,536 (2001 est.)
Military expenditures - dollar figure: $4 billion
(FY99)
Military expenditures - percent of GDP: 1%
(FY99)
Military branches: Department of the Army,
Department of the Navy (includes Marine Corps),
Department of the Air Force
note: the Coast Guard is normally subordinate to the
Department of Transportation, but in wartime reports
to the Department of the Navy
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:70,819,436 (2001 est.)
Military manpower - fit for military service: NA
(2001 est.)
Military manpower - reaching military age
annually:
ma/es: 2,039,41 4 (2001 est.)
Military expenditures - dollar figure: $276.7 billion
(FY99 est.)
Military expenditures - percent of GDP: 3.2%
(FY99 est.)','43506428a310c25db56e0451c8a534918a78f304e106828c234322a914b806e8','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbb805200c8669ea1e8cea0f6b709c55d106975a12643b380231eb59cfbedb5d',2001,'MS','Montserrat','military-and-security',844,'Military branches: Police Force
Military - note: defense is the responsibility of the
UK','69819b9c210f94a556583001a0fae7b3b02769888c4aefe36d53828a9456d0ac','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c40e10ff333f529090d39a1cb2d466e4fa2c250c4192b7c41a4506d9f690cf19',2001,'NA','Namibia','military-and-security',854,'Military branches: National Defense Force (Army),
Police
Military manpower - availability:
males age 15-49: 427,087 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 255,016 (2001 est.)
Military expenditures - dollar figure: $1 04.4
million (2001)
Military expenditures - percent of GDP; 2.6%
(FY97/98)','205daaab6c3b57f06345c4137d7fcdc86acd13f6e059f390c1e85f91e31782f9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a05b105bf93bafbe5352c15c4ac00ae90d1f294e95a6b4ead9d894331fa59e1a',2001,'NR','Nauru','military-and-security',862,'Military branches: no regular armed forces;
Directorate of the Nauru Police Force
Military manpower - availability:
males age 15-49: 3, 0^9 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,001 (2001 est.)
Military expenditures ■ dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: Nauru maintains no defense forces;
under an informal agreement, defense is the
responsibility of Australia
Military - note: defense is the responsibility of the
US','86d287f4b338b9b40e95e712278158d0d34a1edf120108af33bec418a417e2f0','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969ac26c845abdada9c5b2ca50c796b86fe6203364eeeae9a2cc365444f06907',2001,'NP','Nepal','military-and-security',870,'Military branches: Royal Nepalese Army (includes
Royal Nepalese Army Air Service), Nepalese Police
Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 6,295,990 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 3,272,077 (2001 est.)
Military manpower - reaching military age
annually:
males: 292,589 (2001 est.)
Military expenditures - dollar figure: $44 million
(FY96/97)
Military expenditures - percent of GDP: 0.9%
(FY96/97)','6765776afdd517e8ee7a335239884c742169bea3d88225c98798f483ea183ba9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79c103bc93bce9a5b788fcf631211241cc838025a1e9efc5775cc21b5f7f250e',2001,'NL','Netherlands','military-and-security',879,'Military branches: Royal Netherlands Navy, Marine
Corps, Coast Guard, National Guard, Police Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 54,284 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 30,405 (2001 est.)
Military manpower - reaching military age
annually:
males: 610 (2001 est.)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands','6417a67dddacff6246f134abfde9e391e61b150730100ca74abab48826515278','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd8c0777e9160339a402b9e6b6d16f8f1fdb141da6dcdf753254aa60d1c546fc',2001,'NZ','New Zealand','military-and-security',888,'Military branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age /5-49; 1,000,102 (2001 est.)
Military manpower - fit for military service:
males age 75’45: 841 ,91 5 (2001 est.)
Military manpower - reaching military age
annually:
males: 26,480 (2001 est.)
Military expenditures - dollar figure: $883 million
(FY97/98)
Military expenditures - percent of GDP: 1.1%
(FY97/98)
Military branches: Tonga Defense Services
(includes Royal Tongan Marines, Tongan Royal
Guards, Maritime Force, Police); note - a new Air
Wing which will be subordinate to the Defense
Ministry is being developed
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Trinidad and Tobago Defense
Force (includes Ground Forces, Coast Guard, and Air
Wing), Trinidad and Tobago Police Service
Military manpower - availability:
males age 15-49: 346,043 (2001 est.)
Military manpower - fit for military service:
males age 15-49; 247,297 (2001 est.)
Military expenditures - dollar figure: $83 million
(FY94)
Military expenditures - percent of GDP: NA%
Military - note: defense Is the responsibility of
Military - note: defense is the responsibility of','f5453e4fbc4538974dc7f864b67901266cf10ba852930013af67d4b47ef35ce9','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1f7fb010c8e3fbfe5afc6c86214f9cbcbccf84e9b5b9e1eb1093a0b90a29171',2001,'NI','Nicaragua','military-and-security',892,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 1549: 1 ,269,322 (2001 est.)
Military manpower > fit for military service:
males age 1549: 779.267 (2001 est.)
Military manpower - reaching military age
annually:
males: 58,232 (2001 est.)
Military expenditures - dollar figure: $26 million
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)','e40fffeb8004d24979dddca901ba84b9d66fbf4520b3f67ffe40ced92ad23820','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1ffd2709848e6c50a2c1e162f2ec7e3397ceaf36aa760f455ad1535a76264f4',2001,'NE','Niger','military-and-security',900,'Military branches: Army, Air Force, National
Gendarmerie, Republican Guard, National Police
Military manpower ■ military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,202,608 (2001 est.)
Military manpower - fit for military service:
males age 15-49:1,100,737 (2001 est.)
Military manpower - reaching military age
annually:
ma/es.- 108,993 (2001 est.)
Military expenditures - dollar figure: $20 million
(FY96)
Military expenditures - percent of GDP: 1 .1%
(FY96)
Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49/29,940,922 (2001 est.)
Military manpower - fit for military service:
males age 15-49:17,201,367 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 1,375,1 12 (2001 est.)
Military expenditures - dollar figure: $360 million
(FYOO)
Military expenditures - percent of GDP: 10%
(FYOO)','2ce78abc7bbf02bbf5ebb06d3982d6cd7cc60373bfe00a395368ad3ea6ba103e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08e103eed8de501161ca67310f58719892a3302dc8cea773dfeae5320fbe0cb6',2001,'MP','Northern Mariana Islands','military-and-security',911,'Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of the
US','6f75d34e097b117b9add09a066dae95e2d2a46a6e85ab39c03b02681b0c6af76','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('018a05c9e037d03b9747bbc659eb07e534c948826127eddb85a4bf53831abdc8',2001,'PA','Panama','military-and-security',920,'Military branches: an amendment to the
Constitution abolished the armed forces, but there are
security forces (Panamanian Public Forces or PPF
includes the Panamanian National Police, National
Maritime Service, and National Air Service)
Military manpower - availability:
males age 1&49: 775,966 (2001 est.)
Military manpower - fit for military service:
males age f5-49; 530,916 (2001 est.)
Military expenditures - dollar figure: $128 million
(FY99)
Military expenditures - percent of GDP: 1 .3%
(FY99)
Military - note: on 10 February 1990, the
government of then President ENDARA abolished
Panama''s military and reformed the security
apparatus by creating the Panamanian Public Forces;
in October 1994, Panama''s Legislative Assembly
approved a constitutional amendment prohibiting the
creation of a standing military force, but allowing the
temporary establishment of special police units to
counter acts of “external aggression"','b504c498fd66a8d507a7bfc14f1b3bb610d0b630588ea180186ac42f445ca68e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10697d46be40a8720b5cd93c3a850f93c969d4c6390b875964181712b96292cd',2001,'AR','Argentina','military-and-security',925,'Military branches: Army, Navy (includes Naval Air
and Marines), Air Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 1 ,388,436 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,001 ,516 (2001 est.)
Military manpower - reaching military age
annually:
males: 58,359 (2001 est.)
Military expenditures - dollar figure: $125 million
(FY98)
Military expenditures - percent of GDP: 1 .4%
(FY98)','ea91d02f149e5c8d1236dc8112b9e52ef1fab33ce076fae7bf9a2e3ee1d0aa1f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ada061044e1309de37e38897202907f1415413a9ef0989c5124cf6dfa6857ae',2001,'MX','Mexico','military-and-security',941,'Military branches: Army, Navy, Air and Air Defense
Force
Military manpower - military age: 1 9 years of age
Military manpower - availability;
males age f 5-49; 10,447,931 (2001 est.)
Military manpower - fit for military service:
males age 15-49:3,139,245 (2001 est.)
Military manpower ■ reaching military age
annually:
ma/es: 344,781 (2001 est.)
Military expenditures - dollar figure: $3.17 billion
(FYOO)
Military expenditures - percent of GDP: 1 .95%
(FYOO)','dc462af4232f700a30b4db7b1f796d003d0fcd891b8832b67b80f7384c29f770','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16e5d7acc4df8f98c9ab3784f171fd2dbfb2218d5f7c2b63fb950be44bf055cc',2001,'QA','Qatar','military-and-security',954,'Military branches: Army, Navy, Air Force, Public
Security
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:312,110
note: includes non-nationals (2001 est.)
Military manpower - fit for military service:
males age 15-49: 163,642 (2001 est.)
Military manpower - reaching military age
annually:
males: 6,797 (2001 est.)
Military expenditures - dollar figure: $723 million
(FYOO/01)
Military expenditures - percent of GDP: 10%
(FYOO/01)','f0a945f5a84480af534034377827347eb5438906947d210d330db1ccfe6e0199','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17a4d515ab9f4b5e1c7c4db3979623258d793fb9e08719d38cec84ccc1a8c508',2001,'UA','Ukraine','military-and-security',963,'Military branches: Army, Navy, Air and Air Defense
Forces, Paramilitary Forces, Civil Defense
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 5,899,536 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 4,962,807 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 179,951 (2001 est.)
Military expenditures - dollar figure: $720 million
(FYOO)
Military expenditures - percent of GDP: 2.2%
(FYOO)
Military branches: Ground Forces, Navy, Air Force,
Strategic Rocket Forces
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age ^5-49; 38,866,147 (2001 est.)
Military manpower - fit for military service:
males age 15-49; 30,337,743 (2001 est.)
Military manpower - reaching military age
annually:
mates; 1,242,778 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force
Military manpower - availability:
males age 15^49: 1 ,815,633 (2001 est.)
Military manpower ■ fit for military service:
males age 15-49: 924,544 (2001 est.)
Military expenditures - dollar figure: $58 million
(FY01)
Military expenditures - percent of GDP: 3.2%
(FY01)
Military - note: defense is the responsibility of the UK','98b9203943120f39cdd843cab1fcea4b4d93a91853b56deaee1f65e19c5fa7da','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24bbe241f2e4e75e6fd702fc6f2e9e8af712cc7314406ce5745cf0608b4b4d12',2001,'TT','Trinidad and Tobago','military-and-security',972,'Military branches: Royal Saint Kitts and Nevis
Police Force, Coast Guard, Royal Saint Kitts and
Nevis Defense Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','98b3ea410ef0845a9838237f1258208cc7711a948e8aa7c8a9506688a988ad50','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('199c886e86dfb4472cac55aca575bfb0986c9e5188e5cd10e20841b1ebaf23b6',2001,'MQ','Martinique','military-and-security',978,'Military branches: Royal Saint Lucia Police Force
(includes Special Service Unit), Coast Guard
Military expenditures - dollar figure: $5 million
(FY91/92)
Military expenditures ■ percent of GDP; 2%
(FY91/92)
Military - note: defense is the responsibility of','2dd7d7624ff7d6d4feb994e25bdf6af942aa61356388be3e19fbf2fd3765105e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a50fbdde79ad903ac0f69f800467c5bd481bb6d650b4df2b843c343778844444',2001,'SC','Seychelles','military-and-security',996,'Military branches: Army, Coast Guard, air wing,
National Guard, Presidential Protection Unit, Police
Force
Military manpower - availability:
males age 15-49:22,951 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,452 (2001 est.)
Military expenditures - dollar figure: $1 3 million
(FY93)
Military expenditures - percent of GDP: 2.8%
(FY93)','38249aa4f23454bfc0f3edeccd5279768358a841a6d666c5e0262ba2fab6d6be','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2f118e6684c619e1146aae81712409fe9d03386071fc01304fb1c21e3534f43',2001,'SL','Sierra Leone','military-and-security',1004,'Military branches: Army
Military manpower • availability:
males age /5-49; 1,161 ,790 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 563,631 (2001 est.)
Miiitary expenditures » dollar figure: $46 million
(FY96/97)
Military expenditures ■ percent of GDP: 2%
(FY96/97)','6ae9efbad3652048b86ec6bb9dee9d6c39ffa7b63fae6b055f59dd18796c396d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62848447344cd5ac4c89ab2c51d0b9f7605eeef840c4db183fdc1c94fdbc6fa8',2001,'HU','Hungary','military-and-security',1012,'Military branches: Ground Forces, Air and Air
Defense Forces, Territorial Defense Forces, Civil
Defense Force
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 437, 093 (2001 est.)
Military manpower - fit for military service:
males age f 5-49.'' 1,136,811 (2001 est.)
Military manpower - reaching military age
annually:
males: 45,502 (2001 est.)
Military expenditures ■ dollar figure: $380 million
(FYOO)
Military expenditures - percent of GDP: 1 .71%
(FYOO)','10853f49d369332176d6a7fe4422d2b6cfd2d0f708f828fe5b6f03838306dc58','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c65a878d80af9feb4804e10b2bf2a37aeaaba839db41234a472c310e137bc84b',2001,'SB','Solomon Islands','military-and-security',1020,'Military branches: no regular military forces;
Solomon Islands National Reconnaissance and
Surveillance Force; Royal Solomon Islands Police
(RSIP)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','997a0316d3ec8cddc0d6681e98e9a91d7c5be93a9ba99ebd9a2afcaddf5b859c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8e37f0b9bb3ca55694448dfea40496d67c6dc4643e7aa5b02d5293fa9a0653a',2001,'SO','Somalia','military-and-security',1029,'Military branches: A Somali National Army is being
reformed under the interim government; numerous
factions and clans maintain independent militias, and
the Somaliland and Puntland regional governments
maintain their own security and police forces
Military manpower - availability;
males age f 5-49.- 1 ,825,302 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,01 1 ,400 (2001 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','97f11cebde36d2fce33d0426c276824d78cdfd1d88de6645e4b198feba119e1d','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5eeffb96ce452f1f8a305adeeb645f4b66bca1d95b582429e90b60c25f4f225',2001,'ES','Spain','military-and-security',1040,'Military branches: Army, Navy, Air Force, Marines,
Civil Guard, National Police, Coastal Civil Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 1549: 10,551,945 (2001 est.)
Military manpower - fit for military service:
males age f5-49; 8,448,150 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 281, 043 (2001 est.)
Military expenditures - dollar figure: $6 billion
(FY97)
Military expenditures - percent of GDP: 1.1%
(FY97)','d07b47124d5b56ce02eb684306ef1f5402c3db36175e1537015a0f496587924f','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3f3c33b87bb5e7eb3287259f076aaf3a6561c6919d706fc1ef1ebac1477123d',2001,'LK','Sri Lanka','military-and-security',1048,'Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 5,304,323 (2001 est.)
Military manpower - fit for military service:
males age f5-49; 4,1 19,511 (2001 est.)
Military manpower - reaching military age
annualiy:
males: 193,522 (2001 est.)
Miiitary expenditures ■ dollar figure: $719 million
(FY98)
Military expenditures - percent of GDP: 4.2%
(FY98)','fe9933b545381b09f5587e2472b3bb21cc6f44868e9f124b6cd12f9fdb3b05ba','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a926381f6520efab0280d43c477c39128c4c4b68be45a126193124a5402cefbb',2001,'SD','Sudan','military-and-security',1057,'Military branches: Army, Navy, Air Force, Popular
Defense Force Militia
Military manpower ■ military age; 18 years of age
Military manpower - availability:
males age 15-49: 8,436,732 (2001 est.)
Military manpower - fit for military service:
males age /5-49; 5,194,862 (2001 est.)
Military manpower - reaching military age
annually:
mates; 398,294 (2001 est.)
Military expenditures - dollar figure: $550 million
(FY98)
Military expenditures - percent of GDP: NA%','accaad3280bbb794de095834cf823529022584726641d90d402fde1c8261352a','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b033cdd33cc0436ae0b212b5c80119e98835470de72ae71d8a5a260fe185f9d',2001,'PK','Pakistan','military-and-security',1072,'Military branches; Army, Air Force, Air Defense
Forces, Presidential National Guard, Security Forces
(internal and border troops)
Military manpower - military age; 18 years of age
Military manpower - availability:
males age 1,586,700 (2001 est.)
Military manpower - fit for military service:
males age f 5-49; 1,300,252 (2001 est.)
Military manpower - reaching military age
annually;
mates; 72,056 (2001 est.)
Military expenditures - dollar figure: $17 million
(FY97)
Military expenditures - percent of GDP: 1 .8%
(FY97)
Military branches: Tanzanian People''s Defense
Force or TPDF (includes Army, Navy, and Air Force),
paramilitary Police Field Force Unit, Militia
Military manpower - availability:
males age 15-49:8,365,337 (2001 est.)
Military manpower - fit for military service:
males age 15-49:4,841,095 (2001 est.)
Military expenditures - dollar figure: $21 million
(FY98/99)
Military expenditures ■ percent of GDP: 0.2%
(FY98/99)','2e7f4a9b36ca4d651bcb52a25bff40e6d14930b9eb3d1c1cc9a9759dcfa72c03','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bddfd15d22b92bb5f969edda7741826e4de6153601b3e41809e584181be1caf',2001,'TV','Tuvalu','military-and-security',1086,'Military branches: no regular military forces; Police
Force includes Maritime Surveillance Unit for search
and rescue missions and surveillance operations
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Air Wing, Marine Unit
Military manpower - availability:
males age 15-49:5,113,755 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,778,457 (2001 est.)
Military expenditures - dollar figure: $95 million
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)
Military branches: Army, Navy, Air Force, Air
Defense Force, Internal Troops, Border Troops
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 12,285,623 (2001 est.)
Military manpower - fit for military service:
males age 15-49:9,530^84 (2001 est.)
Military manpower - reaching military age
annually:
ma/es.* 390,823 (2001 est.)
Military expenditures ■ dollar figure: $500 million
(FY99)
Military expenditures ■ percent of GDP: 1 .4%
(FY99)','54d2daea3e4406ddf2b1c3b59e8c77fe7ebc2768087ba12e8a1eae2951a0ce1e','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4da93632499be6e4a7056be58ccc95b37089e8fe81842822dbf9a5f5bee128e',2001,'OM','Oman','military-and-security',1095,'Military branches: Army, Navy, Air Force, Air
Defense, paramilitary (includes Federal Police Force)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 778,842
note: includes non-nationals (2001 est.)
Military manpower - fit for military service:
males age 15-49:420,484 (2001 est.)
Military manpower - reaching military age
annually:
males: 25,482 (2001 est.)
Military expenditures - dollar figure: $1.6 billion
(FYOO)
Military expenditures - percent of GDP: 3.1%
(FYOO)','ec646aa16be3068688d1f17ef8f90287868ff9abc2eced821a7c00aaf17c5b1c','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('689782abdb7dd2b6d42541dd5ce9ee6af0db4083472f63f59333e55b9efb7c8b',2001,'UY','Uruguay','military-and-security',1107,'Military branches: Army, Navy (includes Naval Air
Arm, Coast Guard, Marines), Air Force, Police
(Coracero Guard, Grenadier Guard)
Military manpower - availability:
males age 15-49: 817,535 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 661 ,777 (2001 est.)
Military expenditures - dollar figure: $172 million
(FY98)
Military expenditures - percent of GDP: 0.9%
(FY98)','d99f601547edeb3ab03d062535f8ac20bec17cc53b37050293f45e46faf5a932','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b29620273cf08d146aeb8de2a1797bd8931aabd398a321692c17031dc195de6',2001,'UZ','Uzbekistan','military-and-security',1114,'Military branches: Army, Air and Air Defense
Forces, Security Forces (internal and border troops).
National Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 75-49.'' 6,550,587 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 5,318,418 (2001 est.)
Military manpower - reaching military age
annually:
ma/es.'' 274,602 (2001 est.)
Military expenditures - dollar figure: $200 million
(FY97)
Military expenditures - percent of GDP: 2%
(FY97)','afb99164cc48be3f26288c635ffd688fa5103c769a872a9670397a02c364afec','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eae526be2353b7da28500cb93b941a7a4ee8f5c3574b38d12d046e496fa4e336',2001,'AF','Afghanistan','military-and-security',1122,'Miiitary branches: no regular military forces;
Vanuatu Police Force (VPF; includes the paramilitary
Vanuatu Mobile Force or VMF)
Military expenditures - doliar figure: $NA
Military expenditures - percent of GDP: NA%
Transnationai issues
Disputes “ internationai: claims Matthew and
Hunter Islands east of New Caledonia
Background: Venezuela was one of the three
countries that emerged from the collapse of Gran
Colombia in 1830 (the others being Colombia and
Ecuador). For most of the first half of the 20th century,
Venezuela was ruled by generally benevolent military
strongmen, who promoted the oil industry and allowed
for some social reforms. Democratically elected
governments have held sway since 1959. Current
concerns include: drug-related conflicts along the
Colombian border, increasing internal drug
consumption, overdependence on the petroleum
industry with its price fluctuations, and irresponsible
mining operations that are endangering the rain forest
and indigenous peoples.
Military branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN) includes Ground Forces
or Army (Fuerzas Terrestres or Ejercito), Naval
Forces (Fuerzas Navales or Armada), Air Force
(Fuerzas Aereas or Aviacion), Armed Forces of
Cooperation or National Guard (Fuerzas Armadas de
Cooperacion or Guardia Nacional)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 6,524,809 (2001 est.)
Military manpower - fit for military service:
males age 15-49.- 4,701 ,062 (2001 est.)
Military manpower - reaching military age
annually:
mates.- 246,185 (2001 est.)
Military expenditures - dollar figure: $934 million
(FY99)
Military expenditures - percent of GDP: 0.9%
(FY99)
Military branches: People''s Army of Vietnam
(PAVN) (includes Ground Forces, Navy, and Air
Force), Coast Guard
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49:21,704,588 (2001 est.)
Military manpower - fit for military service:
males age 1549: 13,673,438 (2001 est.)
Military manpower - reaching military age
annually:
mates: 961,124 (2001 est.)
Military expenditures - dollar figure: $650 million
(FY98)
Military expenditures - percent of GDP: 2.5%
(FY98)','420019f944baf5f4ada397f943d29f7dfe144fafa07aad724be6da0360f53fbd','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd759b114cbca64dfbc408f1199ea2c04850fbccc6b672f24568335ea9e9bddc',2001,'YE','Yemen','military-and-security',1133,'Background: North Yemen became independent of
the Ottoman Empire in 1918. The British, who had set
up a protectorate area around the southern port of
Aden in the 19th century, withdrew in 1967 from what
became South Yemen. Three years later, the
southern government adopted a Marxist orientation.
The massive exodus of hundreds of thousands of
Yemenis from the south to the north contributed to two
decades of hostility between the states. The two
countries were formally unified as the Republic of
Yemen in 1 990. A southern secessionist movement in
1 994 was quickly subdued. In 2000, Saudi Arabia and
Yemen agreed to a delimitation of their border.
Military branches: Army, Navy, Coast Guard, Air
Force, Air Defense Forces, Presidential Guards,
paramilitary (includes Police)
Military manpower - military age: 14 years of age
Military manpower - availability:
males age 15-49: 4,103,093 (2001 est.)
Military manpower - fit for military service:
males age 15-49: 2,303,257 (2001 est.)
Military manpower - reaching military age
annually:
ma/es; 238,690 (2001 est.)
Military expenditures - dollar figure: $414 million
(FY99)
Military expenditures - percent of GDP: 7.6%
(FY99)
Military branches: Army (including ground forces
with border troops, naval forces, air and air defense
forces)
Military manpower - military age: 19 years of age
Military manpower - availability:
males ages 15-49:2,600,362 (2001 est.)
Military manpower - fit for military service:
males age 15-49:2,088,595 (2001 est.)
Military manpower - reaching military age
annually:
males: 82,542 (2001 est.)
Military expenditures - dollar figure: $760 million
(FYOO)
Military expenditures - percent of GDP: NA%','63d16a0a27c54059bb573defa4aa43d04374f8c1d6361a51b2e1ffb2d6169194','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b95b778524951956329331d2a6b4fc57c637afddf08fa6700f159d3c3952699f',2001,'ZM','Zambia','military-and-security',1149,'Military branches: Army, Air Force, National
Service, police
Miiitary manpower - availability:
males age f 5-49; 2,246,640 (2001 est.)
Military manpower - fit for military service:
males age f 5-49; 1,193.047 (2001 est.)
Military expenditures - dollar figure: $76 million
(FY97)
Military expenditures - percent of GDP: 1 .8%
(FY97)','7ed3c196a5d7b1793a860ce5738328c2b775f4cf693f8f47def7cfa3f66bd0fa','internet-archive','DTIC_ADA399075','txt','462549b1871763caafe8dc1a8bdc195616458eabd841a41df0e3d1fce890116d','https://archive.org/download/DTIC_ADA399075/DTIC_ADA399075_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffce84663b6b885eba721546c4684fe6e421ddb1aa7277712e2b455d99ac92fe',2001,'WF','Wallis and Futuna','military-and-security',14,'This category includes the entries dealing with a country''s military
structure, manpower, and expenditures.
Military branches
This entry lists the names of the ground, naval, air, marine, and other
defense or security forces.
Military expenditures - dollar figure
This entry gives current military expenditures in US dollars; the
figure is calculated by multiplying the estimated defense spending in
percentage terms by the gross domestic product (GDP) calculated on an
exchange rate basis not purchasing power parity (PPP) terms. However,
in the case of Russia, estimates of military expenditures have been
made using PPP. Dollar figures for military expenditures should be
treated with caution because of different price patterns and accounting
methods among nations, as well as wide variations in the strength of
their currencies.
Military expenditures - percent of GDP
This entry gives current military expenditures as an estimated percent
of gross domestic product (GDP).
Military manpower - availability
This entry gives the total numbers of males and females age 15-49 and
assumes that every individual is fit to serve.
Military manpower - fit for military service
This entry gives the number of males and females age 15-49 fit for
military service. This is a more refined measure of potential military
manpower availability which tries to correct for the health situation
in the country and reduces the maximum potential number to a more
realistic estimate of the actual number fit to serve.
Military manpower - military age
This entry gives the minimum age at which an individual may volunteer
for military service or be subject to conscription.
Military manpower - reaching military age annually
This entry gives the number of draft-age males and females entering the
military manpower pool in any given year and is a measure of the
availability of draft-age young adults.
Military - note
This entry includes miscellaneous military information of significance
not included elsewhere.
Money figures
All money figures are expressed in contemporaneous US dollars unless
otherwise indicated.
National holiday
This entry gives the primary national day of celebration - usually
independence day.
Nationality
This entry provides the identifying terms for citizens - noun and
adjective.
Natural hazards
This entry lists potential natural disasters.
Natural resources
This entry lists a country''s mineral, petroleum, hydropower, and other
resources of commercial importance.
Net migration rate
This entry includes the figure for the difference between the number of
persons entering and leaving a country during the year per 1,000
persons (based on midyear population). An excess of persons entering
the country is referred to as net immigration (e.g., 3.56
migrants/1,000 population); an excess of persons leaving the country as
net emigration (e.g., -9.26 migrants/1,000 population). The net
migration rate indicates the contribution of migration to the overall
level of population change. High levels of migration can cause problems
such as increasing unemployment and potential ethnic strife (if people
are coming in) or a reduction in the labor force, perhaps in certain
key sectors (if people are leaving).','112a8b2f1c14312ad88216f9e4c3511061ebd5b2ebb7bb50ab289a768f1830c1','internet-archive','theciaworldfactb27638gut','txt','e086fb4751fd7e1a1088856d19caccfdb09edd4afd3779c2b6482086976a47c0','https://archive.org/download/theciaworldfactb27638gut/27638.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

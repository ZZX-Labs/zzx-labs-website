SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6350e61191910be1b7165c6ed186e9106200516eb5d6f8ebd4c351008183d61e',1982,'AF','Afghanistan','people-and-society',4,'Population: 15,328,000 (July 1982), average annual
growth rate 1.4%; this estimate includes an adjustment for
net emigration to Pakistan during recent years, but it does
not take into account other demographic consequences of
the Soviet intervention in Afghanistan
Nationality: noun — Afghan(s); adjective — Afghan
Ethnic divisions: 50% Pashtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Baluchi, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pashtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai); much
bilingualism
Literacy: 10%
Labor force: 4.98 million (1980 est.); 67.8% agriculture
and animal husbandry, 10.2% industry, 6.3% construction,
5.0% commerce, 7.7% services and other
Organized labor: government-controlled unions are being
established','5b754b4440b6c616fcd0c7cc43ed0547aa050c16147af04a845275c8bfca03d3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87d6720d6422409a1ca8ba9be832bed2b8fa568e6a4f6fb5d201cd780af41052',1982,'AL','Albania','people-and-society',9,'Population: 2,792,000 (July 1982), average annual growth
rate 2.1%
Nationality: noun — Albanian(s); adjective — Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic; observances prohibited; Albania claims to
be the world''s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural','8be3710e3ede36f030544f3f62cd8adfdf675dd51fc02103da43a61627ed599f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2ad133b3782c507cd27319182cf94853a0ee13b312ae91ae584355ec6f1278',1982,'DZ','Algeria','people-and-society',13,'Population: 20,030,000 (July 1982), average annual
growth rate 3.1%
Nationality: noun — Algerian(s); adjective — Algerian
Ethnic divisions: 99% Arab- Berbers, less than 1%
Europeans
Religion: 99% Muslim; 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 4.0 million; 19% agriculture, 17% industry,
64% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
19% of urban labor unemployed
Organized labor: 25% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor organi-
zation and is subordinate to the National Liberation Front
Population: 1,561,000 (July 1982), average annual growth
rate 1.9%
Nationality: noun — Mauritanian(s); adjective — Mauri-
tanian
Ethnic divisions: 30% Moor, 30% Black, 40% mixed
Moor/Black
Religion: nearly 100% Muslim
Language: Arabic is the national language, French is the
working language for government and commerce
Literacy: about 17%
Labor force: about 95,000 wage earners (1979); remainder
of population in farming and herding; considerable
unemployment
Organized labor: 30,000 union members claimed by
single union, Mauritanian Workers'' Union','2764676208192c7c6ab837c8363657014fd895a37e3ab5b3b6f797ba71c7b533','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('505fd90af7a06aafcb46d12e4d06f9db3d3daaef2497af424f3d056aae97a743',1982,'AD','Andorra','people-and-society',17,'Population: 36,000 (July 1982), average annual growth
rate 4.1%
Nationality: noun — Andorran(s); adjective — Andorran
Ethnic divisions: Catalan stock; 61% Spanish, 30% Andor-
rans, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan; many also speak some French and
Castilian
Labor force: unorganized; largety shepherds and farmers','d3c5480291d68d6f9a3c141805f92d36c8681811dc548be4530aa8010414be48','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1005fc7d89c55320fad84561c6f5940b2c4624f7a486ad4f80d9f3a30cd3d70',1982,'AO','Angola','people-and-society',22,'Population: 7,000,000, including Cabinda (July 1982),
average annual growth rate 2.5%; Cabinda, 117,000 (July
1982), average annual growth rate 3.3%
Nationality: noun — Angolan(s); adjective — Angolan
Ethnic divisions: 93% African, 5% European, 1% mestizo
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official); many native dialects
Literacy: 10-15%
Labor force: 2.6 million economically active (1964);
531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','893d365576dc0e9c138279b758bfa9d9f930d640b53778fe7fe519a82ae3c5be','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('706865f3356aa017dbfb029f0c4d4c3c7f763532417abb499f152c2f58f3968e',1982,'AG','Antigua and Barbuda','people-and-society',24,'Population: 77,000 (July 1982), average annual growth
rate 1.3%
Nationality; noun — Antiguan(s); adjective — Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other Protes-
tant sects, and some Roman Catholic
Language: English
Literacy: about 88%
Organized labor: 18,000, 18% unemployment (est.)','5e336454932d066a88b5127dc12ed377df071a8c96befd75b0818f4b2ce22f51','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e6e7425b0ed309be22db2321c13c8afa93058b6adf7076ca7e5bde7f7be92d7',1982,'AR','Argentina','people-and-society',28,'Population: 28,593,000 (July 1982), average annual
growth rate 1.6%
Nationality: noun — Argentines); adjective — Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 10.8 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 2.2% estimated unemployment
(1978 est.)
Organized labor: 25% of labor force (est.)
Population: 2,000 (July 1982), average annual growth rate
-0.7%
Nationality: noun — Falkland Islander(s); adjective — Falk-
land Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agriculture,
mostly sheepherding','92921aa8b08c07b528f23d9ae91acbcab39a79334036d217346d6b581f7f7974','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d5e1fc8e9a6f400b872558ef86ccb64ce94adb0c721b276ccfd2fb756c85160',1982,'AU','Australia','people-and-society',33,'Population: 15,011,000 (July 1982), average annual
growth rate 1.3%
Nationality: noun — Australian(s); adjective — Australian
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 6.5 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 6.2% unem-
ployment
Organized labor: 44% of labor force
Population: 654,000 (July 1982), average annual growth
rate 1.8%
Nationality: noun — Fijian(s); adjective — Fijian
Ethnic divisions: 50% Indian, 44% Fijian, 6% European,
Chinese, and others
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani spo-
ken among Indians
Literacy: over 80%
Labor force: 176,000 (1979); 43.8% agriculture, 15.6%
industry
Organized labor: about 50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation','1577afef00bc7c325bc3164cea767701abd94111ccfb5ec0fb4db91d22d18130','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60a28a661464760efaedbe7c9dd91bca17be62026e6491a62f38e54bf4efc725',1982,'AT','Austria','people-and-society',36,'Population: 7,510,000 (July 1982), average annual growth
rate 0.0%
Nationality: noun — Austrian(s); adjective — Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,875,000 (September 1980); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and
communications, 7% professions, 6% public service, 2%
other; 1.2% unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number 184,100 (September 1980)
Organized labor: 60% of wage and salary workers (1979)
Population: 237,000 (July 1982), average annual growth
rate 2.8%
Nationality: noun — Bahamian(s); adjective — Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
Language: English
Labor force: 101,000 (1979), 25% organized; 19% unem-
ployment (1979)','42094c907192986584bd4d09a9cac38368a503828c17a8f29888fb49c310c1a9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b612cd2496162d2ca9076e32cf8734066e78245c0897a149f4b64ec86014fd11',1982,'BH','Bahrain','people-and-society',42,'Population: 380,000 (July 1982), average annual growth
rate 4.7%
Nationality: noun — Bahraini(s); adjective — Bahraini
Ethnic divisions: 63% Bahraini, 10% other Arab, 13%
Asian, 8% Iranian, 6% other
Religion: Muslim, slightly more Shias than Sunnis
Language: Arabic, English also widely spoken
Literacy: about 40%
Labor force: 130,000 (1980 est.); 43% of labor force is
Bahraini','9131e472318b03f06c27dfaf5f23369937c98ac21e0a1e50b903a0e24de4a405','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59900790d5056bc3b98783b335eeca61e4eca531329c1b755f23219c157a3c33',1982,'CN','China','people-and-society',47,'Population: 93,040,000 (July 1982), average annual
growth rate 2.6%
Nationality: noun — Bangladeshi(s); adjective — Bangla-
desh
Ethnic divisions: predominantly Bengali; fewer than one
million "Biharis" and fewer than one million tribals
Religion: 85% Muslim, about 12% Hindu, less than 1%
Buddhist, Christian, or other
Language: Bengali
Literacy: 24.3% (1979-80)
Labor force: 30.7 million; extensive export of labor to
Saudi Arabia, UAE, Oman, and Kuwait; 80% of labor force
is in agriculture, 15% services, 11% industry (FY79)
Population: 1,055,304,000 (July 1982), average annual
growth rate 1.3%
Nationality: noun — Chinese (sing., pi.); adjective —
Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism, Bud-
dhism, ancestor worship; about 2%-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: est. 400 million (mid-1979); 75% agriculture,
25% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor
Population: 289,000 (July 1982), average annual growth
rate 1.7%
Nationality: noun — Macanese (sing, and pi); adjective —
Macau
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-
half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese;
no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)
Population: 56,430,000 (July 1982), average annual
growth rate 2.5%
Nationality; noun — Vietnamese (sing, and pi.); adjec-
tive— Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Cham, and mountain tribesmen
Religion: Buddhist, Confucian, Taoist, Catholic, Animist,
Islamic, and Protestant
Language: Vietnamese, French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','a82432b1089c2713da3d39282c62539d2e11386901a0a6fb206240983c402d60','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23c4a1d300896c5def99f17e6673efe944212bf349ac459c674b3f2bb4cda403',1982,'BB','Barbados','people-and-society',51,'Population: 252,000 (July 1982), average annual growth
rate 0.5%
Nationality: noun — Barbadian(s); adjective — Barbadian
Ethnic divisions: 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 106,000 (1979 est.) wage and salary earners;
unemployment 11% (1979)
Organized labor: 32%','5564769852977f81704b189cb501f6f89047bffd5003cba3f81e293041e2ddf1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c9c98bc63771adb604d83a3b91e5441f0b137cf3a1f2fdb5a2f202342c3e7dc',1982,'BE','Belgium','people-and-society',55,'Population: 9,881,000 (July 1982), average annual growth
rate 0.1%
Nationality: noun — Belgian(s); adjective — Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
Literacy: 97%
Labor force: 4.09 million (July 1978); in June 1976, 46.7%
in services, 28.0% in mining and manufacturing, 7,4% in
construction, 6.6% in transportation, 3.2% in agriculture,
1.0% commuting foreign workers, 0.4% in public works;
10.2% unemployed (January 1982)
Organized labor: 70% of labor force','7d92e7ed4a5433dbd965cac06b9b2c34f15d1d4a4fefd86c2c856c3505be2c83','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056a443041f0c449f5d1926fbfd573659f64931ddd92fb56956c9c6b42b46604',1982,'BZ','Belize','people-and-society',59,'Population: 150,000 (July 1982), average annual growth
rate 1.8%
Nationality: noun — Belizean(s); adjective — Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amer-
indian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-Day
Adventist, Methodist, Baptist, Jehovah''s Witnesses, Men-
nonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 40,000; 39% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force','27c2e207d33172b43f27b245829b39cd2151f576af9c980f5f0e2fdc89f78ee6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9329fb4accd6db18cc02751e517340c64958b7fe38fdfbc4da6462e226d4228a',1982,'BJ','Benin','people-and-society',63,'Population: 3,636,000 (July 1982), average annual growth
rate 2.6%
Nationality: noun — Beninese (sing., pi.); adjective —
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most com-
mon vernaculars in south; at least six major tribal languages
in north
Literacy: about 20%
Labor force: 70% of labor force employed in agriculture;
less than 2% of the labor force work in the industrial sector
and the remainder are employed in transport, commerce,
and public services
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions','eec5adaa50659ac370ac8d7ed7b7076ab855a84f49ac6e3ffd0cf32785ef8370','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('664fb0d63ebc1da9ad184d8054c807e61dd974159fc95f30bcd3fd0eb232debe',1982,'BM','Bermuda','people-and-society',67,'Population: 72,000 (July 1982), average annual growth
rate 2.6%
Nationality; noun — Bermudian(s); adjective — Bermudian
Ethnic divisions: approximately 61% black, 39% white
Religion: 37% Church of England, 19% other Protestant,
14% Catholic, 30% other
Language: English
Literacy: 98%
Labor force: 29,669 employed (1980)','3b30dbd89d6d1f92cae051d2c13e97cc68990ddc43988009c0a35e8e67a3c1a1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e91e0c73e6ae67f9e0ab37d8da4bb6d4da0593f3620de02532e2a30d6634bd3b',1982,'IN','India','people-and-society',73,'Population: 1,364,000 (July 1982), average annual growth
rate 2.3%
Nationality: noun — Bhutanese (sing., pi.); adjective —
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Buddhist-
influenced Hinduism
Language: Bhotias speak various Tibetan dialects — most
widely spoken dialect is Dzongkha, the official language;
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 5,633,000 (July 1982), average annual growth
rate 2.6%
Nationality: noun — Bolivian(s); adjective — Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.8 million (1977); 70% agriculture, 3%
mining, 10% services and utilities, 7% manufacturing, 10%
other
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation
Population: 723,762,000, including Sikkim and the
Indian-held part of disputed Jammu-Kashmir (July 1982),
average annual growth rate 2.2%
Nationality: noun — Indian(s); adjective — Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
enjoys "associate" status but is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force
Population: 93,106,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area of Jammu-Kashmir,
(July 1982); average annual growth rate 2.9%
Nationality: noun — Pakistani(s); adjective — Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages — 7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: 24% (1980)
Labor force: 24.45 million (1981 est.); 52% agriculture,
21% industry, 27% services.
Organized labor: 5% of labor force','dbc42447c6e06821ce83fb86bd77034a9fb6e0620dde9d2ec2fecba8c25e2dfe','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31a78709f2ab9ade67c9aafffddb1113e6c0daec28b481fd29593105cc25244b',1982,'BW','Botswana','people-and-society',77,'Population: 975,000 (July 1982), average annual growth
rate 4.6%
Nationality: noun — Motswana (sing.), Batswana (pi.); ad-
jective— Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean
Religion: 85% animist, 15% Christian
Language: Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less
than 1% secondary school graduates
Labor force: 78,000 formal sector employees; most others
are engaged in cattle raising and subsistence agriculture;
40,000 or over one-half of formal sector employees spend at
least six to nine months per year as wage earners in South
Africa (1978)
Organized labor: eight trade unions organized with a total
membership of approximately 9,000 (1972 est.)','d39aaf4274569a83a5dd01d7b3e8ae9f3065d14445698c7b4bf218737df3f91a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fef83d1ce08493f9cacdc15b50536c8cec9c5b57212bce36868a86da2b8c07f3',1982,'BR','Brazil','people-and-society',82,'Population: 127,734,000 (July 1982), average annual
growth rate 2.3%
Nationality: noun — Brazilian(s); adjective — Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 83% of the population 15 years or older (1978)
Labor force: about 40 million in 1976 — 36.3% agriculture,
livestock, forestry, and fishing; 23.2% industry; 18.9% serv-
ices, transportation, and communication; 9.2% commerce;
6.1% social activities; 3.5% public administration; 2.8% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 252,000 (July 1982), average annual growth
rate 5.6%
Nationality: noun — Bruneian(s); adjective — Bruneian
Ethnic divisions: 65% Malays, 24% Chinese, 11% other
Religion: 60% Muslim (Islam official religion); 8% Chris-
tian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction; 33.8% trade, transport,
services; 2.9% other
Organized labor: 8.4% of labor force','db5448e5cef0e7f48fb18f2bf28e0200bddd3eec857503a125244191ec05cd23','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8219599d7e5960dfd35f8c04c53e90690677ceeb24d3d0be182f0ad2ba960742',1982,'BG','Bulgaria','people-and-society',85,'Population: 8,940,000 (July 1982), average annual growth
rate 0.4%
Nationality: noun — Bulgarian(s); adjective — Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 13% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.0 million (1981); 23% agriculture, 35%
industry, 42% other
Population: 36,166,000 (July 1982), average annual
growth rate 2.5%
Nationality: noun — Burman(s); adjective — Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 3%
Indian, 2% Kachin, 2% Chin, 2% Chinese, 6% other
Religion: 85% Buddhist, 15% animist, and other
Language: Burmese; minority ethnic groups have their
own languages
Literacy: 70% (official claim)
Labor force: 12.2 million (1976); 67% agriculture, 9%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor organiza-
tions have been disbanded, and government is forming one
central labor organization','b756e2400d225ae21ee4d812797344eb840437c817796748800ba8322876a4b7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a63826ef7c019ea8a6743b1e79df5dae4865e3e0d2891f989d1939074b02b06',1982,'BI','Burundi','people-and-society',89,'Population: 4,438,000 (July 1982), average annual growth
rate 2.7%
Nationality: noun — Burundian(s); adjective — Burundi
Ethnic divisions: Africans — 85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include around
70,000 refugees, mostly Rwandans and Zairians; non-
Africans include about 3,000 Europeans and 2,000 South
Asians
Religion: about 60% Christian (53% Catholic, 7% Protes-
tant); rest mostly animist plus perhaps 2% Muslim
Language: Kirundi and French (official); Swahili (along
Lake Tanganyika and in the Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no service-
able estimate for Kiswahili
Labor force: about 2 million (1976 est.); most engaged in
subsistence agriculture
Organized labor: sole group is the Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally); figures denoting "active mem-
bership" have been unobtainable','76c6aec11c576e5ba96b4cb4d04e5661c61948cffc927578df2140409d13bdf1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb6b00478439af725540164fdadf1c09a205840b9872027e451a6ff17cc06da1',1982,'CM','Cameroon','people-and-society',94,'Population: 9,049,000 (July 1982), average annual growth
rate 2.9%; this estimate does not take into account migration
between Cameroon and Chad during recent years
Nationality: noun — Cameroonian(s); adjective — Came-
roon ian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 11% Kirdi, 10% Fulani, 8% Northwestern Bantu, 7%
Eastern Nigritic, 13% other African, less than 1%
non- African
Religion: about one-half animist, one-third Christian, one-
sixth Muslim
Language: English and French official, 24 major African
language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
including 22,000 government employees, 63,000 paid agri-
cultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force','939a8cb6bd7bc1db1289fd7a75ca8c25f99a9203e4269469cc5a463795049d03','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0343a4637083bb600d42eca51ea983183a32193d408a914fd587b766302b59c7',1982,'CA','Canada','people-and-society',97,'Population: 24,469,000 (July 1982), average annual
growth rate 1.1%
Nationality: noun — Canadian(s); adjective — Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other
Religion: 48% Protestant, 47% Catholic, 5% other
Language: English and French official
Literacy: almost complete
Labor force: 11.9 million (December 1981); 41% service,
19% manufacturing, 17% trade, 8% transportation and utili-
ties, 6% construction, 4% agriculture, 5% other; 7.6% unem-
ployment (1981 average); 8.6% unemployment (December
1981)
Organized labor: 30% of labor force','1a8b34660349efc7552fa61cc3b9b16ba1a6c5246d44c98f664270483e53336c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('931493d21eae4d53347a4f000d8ba68768f6b60c3b1c78a799352c00d61a36bc',1982,'MR','Mauritania','people-and-society',101,'Population: 293,000 (July 1982), average annual growth
rate 0.6%
Nationality: noun — Cape Verdean(s); adjective — Cape
Verdean''
Ethnic divisions: about 71% mulatto; 28% African; 1%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and Crioulo, a blend of Portuguese
and West African words
Literacy: 37%
Labor force: bulk of population engaged in subsistence
agriculture','3cd76955a7206cfeabbad8ab6ac59bbe339ef4ba31e42775346bb4efa435695e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23b9ad01955b3af99a326714023353858589f0d2dc11aac269b7c434bb38a987',1982,'CF','Central African Republic','people-and-society',106,'Population: 2,471,000 (July 1982), average annual growth
rate 2.6%
Nationality: noun — Central African(s); adjective — Central
African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic charac-
teristics; Banda (32%) and Baya-Mandjia (29%) are largest
single groups; 6,500 Europeans, of whom 6,000 are French
and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 24% animist, 8%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
Language: French official; Sangho, lingua franca and
national language
Literacy: estimated at 20%
Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force','cc3a7387959d97b9fbe57cfd9ea942402a16cd7f9937938ca633916ac79c398e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f58f622e050aa3eed2d300c418d9dbf2b8ee4cbfb0248ee883f1247c08b2f758',1982,'TD','Chad','people-and-society',108,'Population: 4,852,000 (July 1982), average annual growth
rate 2.3%; this estimate does not take into account migration
between Cameroon and from Chad during recent years
Nationality: noun — Chadian(s); adjective — Chadian
Ethnic divisions: some 200 distinct ethnic groups, includ-
ing Muslims (Arabs, Toubou, Fulani, Kotoko, Hausa, Kanem-
bou, Baguirmi, Boulala, and Maba) in the north and center
and non-Muslims (Sara, Mayo-Kebbi, and Chari) in the
south; some 150,000 nonindigenous, 3,000 of them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid subsis-
tence farming, herding, and fishing; 50,000 wage earners in
industry and civil service
Organized labor: about 20% of wage labor force','001ca2f893191980136e62a4396cf9859d8b63fef9c7e1d7c2bc3584fcec6a6b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8610c3141cceafb009d39f7933fdd2fcd293365321f439095d9069815af10199',1982,'CL','Chile','people-and-society',113,'Population: 11,323,000 (July 1982), average annual
growth rate 1.4%
Nationality: noun — Chilean(s); adjective — Chilean
Ethnic divisions: 95% European stock and mixed Europe-
an with some Indian admixture, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 90% (1977)
Labor force: 3.0 million total employment (1979); 20%
agricultural, 22% industry and construction, 22% services,
15% commerce, 3% mining, 6% transportation, 12% other
(1979)
Organized labor: 25% of labor force (1973)','b40f8e3196f0bda455d100e110a7cf2f65d776411da55bd3b16ba69a52041371','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('555023afb60d3b3bfbc999f30053cbe562e2ae38b359e2bb39b171a47c3b1f55',1982,'CO','Colombia','people-and-society',117,'Population: 26,631,000 (July 1982), average annual
growth rate 1.6%
Nationality: noun — Colombian(s); adjective — Colombian
Ethnic divisions: 58% mestizo, 20% Caucasian, 14%
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 72-75% of population over 15 years old
Labor force: 5.9 million (1973); 30% agriculture, 15%
industry, 19% services, 13% commerce/hotels, 18% other
(1973); 18.5% unemployment (1979)
Organized labor: 13% of labor force (1968)','c321af0cdc57e1efbb248df04132a81390c67a1eb1dc6ef0c0def00b5814084d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c92fd2eb162de9bb97fbf6b9cded55b60682e6268aaa937906f5b20ef7d8d41',1982,'KM','Comoros','people-and-society',120,'Population: 442,000 (July 1982), average annual growth
rate 3.5%
Nationality: noun — Comoran(s); adjective — Comoran
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: low; probably around ^fiftr
Labor force: mainly agricultural','935f4e72f4f7af2464cfe3ae889a01c1edba9ed145ac885ff401d77cd1b967e7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e98a565a1287ac8036c00cbe46267b19e9763966399a8ccccffba5f8d77bb7f',1982,'CG','Congo','people-and-society',124,'Population: 1,641,000 (July 1982), average annual growth
rate 2.8%
Nationality: noun — Congolese (sing., pi.); adjective — Con-
golese or Congo
Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
Sangha (20%) and M''Bochi (12%) in north; about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economically ac-
tive, most engaged in subsistence agriculture; 79,100 wage
earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','ca2849065445efc12461625a8e7d670e515fd41309d011399012185841088820','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b90fba82c709f5616b6ccfc651bf2772c88311ab8eccc107413b30abe35b85dc',1982,'CK','Cook Islands','people-and-society',128,'Population: 17,000 (July 1982), average annual growth
rate 0.0%
Nationality: noun — Cook Islanders); adjective — Cook
Islander
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church','04fdb18651f57018c8a380a08e06ac1ea653a563d2961c4648ca14cafd5d6a4d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e831c683f5e183b870902ae689f6304a262d31b6a6de4a4fea246e1d071df7d',1982,'CR','Costa Rica','people-and-society',133,'Population: 2,396,000 (July 1982), average annual growth
rate 2.9%
Nationality: noun — Costa Rican(s); adjective — Costa
Rican
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 90%
Labor force: 770,000 (1980 est.); 26.9% agriculture; 16.2%
manufacturing; 18.1% commerce; 7.9% construction; 6.4%
transportation, utilities; 22.9% service (government, educa-
tion, social); 0.2% other; 15% unemployment (1981 est.)
Organized labor: about 13.8% of labor force','8cabd5c67a4d72a2a918bbbdcef9b113e0daef7fd5cbc866c952a5d0eff97fd8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5d140ac9606096d23492ec8e8d08c553f1a15eefb9497b3aac850679e7db76b',1982,'CU','Cuba','people-and-society',135,'Population: 9,771,000 (July 1982), average annual growth
rate 0.8%
Nationality: noun — Cuban(s); adjective — Cuban
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.9 million in 1978; 33% agriculture, 17%
industry, 9% construction, 7% transportation, 32% services,
2% unemployed','931a6f968d8f5d5577761b22723683f76a548615c04a4afabbc2669a501209cf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4180cbfd2c76b69124173aaf1e312db1446eb8c4dcbcde41d1bfd35ddfda503e',1982,'CY','Cyprus','people-and-society',140,'Population: 642,000 (July 1982), average annual growth
rate 1.0%
Nationality: noun — Cypriot(s); adjective — Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Maro-
nite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 89% of population 15 years or older, 99%
of population aged 15-39
Greek Sector labor force: 180,700 (1980), 42% services;
33% industry; 25% agriculture; 2.1% unemployed','81633c33844b9471de15a21bb8a32df649bc839d63285d86f126c712497b0f41','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('344b4f8ce5af3d1931bbfc93b77f427935f69b4255e159574922ddd32f19d464',1982,'DE','Germany','people-and-society',144,'Population: 15,369,000 (July 1982), average annual
growth rate 0.4%
Nationality: noun — Czechoslovak(s); adjective — Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.6 million; 14% agriculture, 38.6% industry,
11% services, 36.4% construction, communications and
others
Population: 5,278,000 (July 1982), average annual growth
rate 2.6%
Nationality: noun — Guinean(s); adjective — Guinean
Ethnic divisions: 99% African (3 major tribes — Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than
1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language
Labor forcer 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force
loosely affiliated with the National Confederation of Guin-
ean Workers, which is closely tied to the PDG','77b4dd3995c3280cf22996ce37058cc715fa0f46f4422c227c077744a8be0673','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6926ad762498d1f28a9840583d807138edb42993dc65cd2b3c7432a2e83652ff',1982,'DK','Denmark','people-and-society',147,'Population: 5,125,000 (July 1982), average annual growth
rate 0.1%
Nationality: noun — Dane(s); adjective — Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2,529,000 (1979 average); 8.2% agriculture,
forestry, fishing, 21.0% manufacturing, 7.9% construction,
13.3% commerce, 6.8% transportation, 7.0% banking and
business services, 34.1% social services; 6.9% average unem-
ployment rate
Organized labor: 65% of labor force','99145de73683ec91d9fe3878604a10a5e4a275eebd4f9e176c25c940daef3de5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('549eadad74c9d8cd4a7be5ac4ee7542050d2c8e6b0d4c080b67fedd6498ef9f7',1982,'DJ','Djibouti','people-and-society',151,'Population: 306,000 (July 1982) average annual growth
rate 4.1%
Nationality: noun — Afar(s), Issa(s); adjective — Afar, Issa
Ethnic divisions: Somalis (lssas) and Afars
Religion: 94% Muslim, 6% Christian
Language: French (official), Somali, Afar, Arabic, all
widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
Organized labor: some 3,000 railway workers organized','6a09e4d82c20242ea25b5b49b944c79799b7e1877a235a53a9d03e291f24a5e2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b27918b0bd3a3ca788a0d2cc0c823f03ea9880cdb46a5ec8b15db03d77a52bb',1982,'DM','Dominica','people-and-society',156,'Population: 80,000 (July 1982), average annual growth
rate 0.6%
Nationality: noun — Dominican(s); adjective — Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture; 24%
unemployment
Organized labor: 25% of the labor force','7a9138105ff5828dd11d1d3e26f96500807f3650a0ec62a302a9e6883b8e29f8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b5190ac381130e109bab5a5706f6a1cfdca8738fc066ef768d1c5465cfe938',1982,'DO','Dominican Republic','people-and-society',160,'Population: 6,013,000 (July 1982), average annual growth
rate 2.7%
Nationality: noun — Dominican(s); adjective — Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services, and other
Organized labor: 12% of labor force','52c0d8dae34a4550b9d0ccd9050bee5a2287c3ae6aacea1d94d67e1e17e7f0a8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaad252e5fc290440a09519666bff5f37da20854550ee7c079eddc1934bdf666',1982,'EC','Ecuador','people-and-society',162,'Population: 8,537,000 (July 1982), average annual growth
rate 3.1%
Nationality: noun — Ecuadorean(s); adjective — Ecuador-
ean
Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Negro, 5% Oriental, and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other services and activities
Organized labor: less than 15% of labor force','bd537631f94d7d4930654dbca3693fa0480411cd3c13e75f3f5b22cde9b3bd3c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d6d644ad798e8f53ac5d9401095c538525971f707b2d84167095803cbe13c34',1982,'SD','Sudan','people-and-society',169,'Population: 44,740,000 (July 1982), average annual
growth rate 3.0%
Nationality: noun — Egyptian(s); adjective — Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 44%
Labor force: 13.4 million; 45-50% agriculture, 13% indus-
try, 11% trade and finance, 26% services and other; shortage
of skilled labor
Organized labor: 1 to 3 million
Population: 19,868,000 (July 1982), average annual
growth rate 2.8%
Nationality: noun — Sudanese (sing, and pi.); adjective —
Sudanese
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 20%
Labor force: 8.6 million (1979); roughly 78% agriculture,
10% industry, 12% services; labor shortages for almost all
categories of employment coexist with urban unemployment','126e05bd3e3d583f2d099947ee760128bd979b021527b0ecc2a68377293c0b37','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('702ffcf40e2c12eb56fa8fa18bb7eb7beabc6f138330693320fbfd091342d0d4',1982,'HN','Honduras','people-and-society',173,'Population: 4,617,000 (July 1982), average annual growth
rate -2.4%
Nationality: noun — Salvadoran(s); adjective — Salvadoran
Ethnic divisions: 92% mestizo; Indian and white minor-
ities, 4% each at most
Religion: predominantly Roman Catholic, probably
97%-98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
Labor force: 1,7 million (est. 1982); 50% agriculture, 14%
manufacturing and construction, 7% commerce, 29% public
and private services; shortage of skilled labor and large pool
of unskilled labor, but manpower training programs improv-
ing situation
Organized labor: 8% total labor force; 10% agricultural
labor force; 7% urban labor force (1982)
Population: 4,103,000 (July 1982), average annual growth
rate 4.1%
Nationality: noun — Honduran(s); adjective — Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 1 million (1980); 59.3% agriculture,
12.7% services, 12.5% manufacturing, 8.3% commerce, 3.0%
transportation, 2.7% construction, 1.1% financial sector, 0.4%
mining; 10.8% unemployed; 3% unspecified
Organized labor: 40% of urban labor force, 20% of rural
work force (1981)','0faa7b33c720d124dd97725f7d190bf99cfb77f5387dfee620f9d5187fdbb9e3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('537a766afa47f8101b5774346a19c9bf9357843534b6167d02c50c3b31df91a7',1982,'NG','Nigeria','people-and-society',179,'Population: 260,000 (July 1982), average annual growth
rate 2.1%
Nationality: noun — Equatorial Guinean(s); adjective —
Equatorial Guinean
Ethnic divisions: indigenous population of Province
Bioko, primarily Bubi, some Fernandinos; of Rio Muni
primarily Fang; less than 1,000 Europeans, primarily
Spanish
Religion: natives all nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: school enrollment reportedly 90% for school age
children, but overall literacy rate is only 38%
Labor force: most Equatorial Guineans involved in subsis-
tence agriculture; labor shortages on plantations
Population: 82,396,000 (July 1982), average annual
growth rate 3.3%
Nationality: noun — Nigerian(s); adjective — Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Hausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27,000 non-Africans
Religion: no exact figures on religious breakdown, but last
census (1963) showed Nigeria to be 47% Muslim, 34%
Christian, and 18% animist
Language: English official; Hausa, Yoruba, and Ibo also
widely used
Literacy: est. 25%
Labor force: approx. 28-32 million (1979)
Organized labor: between 800,000 and 1 million wage
earners, approx. 2.4% of total labor force, belong to some 70
unions
Population: 2,783,000 (July 1982), average annual growth
rate 3.0%
Nationality: noun — Togolese (sing, and pi.); adjective —
Togolese
Ethnic divisions: 37 tribes; largest and most important are
Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in subsis-
tence agriculture; about 30,000 wage earners, evenly divided
between public and private sectors
Organized labor: 1 national union, the CNTT organized
in 1972','077d0666a077e2306e8e612707f289e5cb8084a9e0cdc07bc82dd97552259e32','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2112733f8a335e31a447a20847e99c73c2fe5eacd3da40b472d7d6fc794d9a83',1982,'ET','Ethiopia','people-and-society',183,'Population: 30,569,000 (July 1982), average annual
growth rate 1.9%
Nationality: noun — Ethiopian(s); adjective — Ethiopian
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lim, 15%-20% animist, 5% other
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and Quasi-government
Organized labor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','839b3e3c6271ecf40bd9c790b47a579650138d01400534fab317e9f91b81fdc4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b77ece92bb78e0ca40cca8c73101e5d83908868eb2fd367ccfe34365f43f7739',1982,'FO','Faroe Islands','people-and-society',189,'Population: 45,000 (July 1982), average annual growth
rate 1.2% (current)
Nationality: noun — Faroese (sing., pi.); adjective —
Faroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce','9a6d02faf83525e06acc1030da9fff9188cab29a13aa657d99a2aebd556f7924','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c720cac22f3b157afcce95816fe2167239a9081290b34677f702d05b492f4e17',1982,'FI','Finland','people-and-society',194,'Population: 4,816,000 (July 1982), average annual growth
rate 0.4%
Nationality: noun — Finn(s); adjective — Finnish
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and
Russian-speaking minorities
Literacy: 99%
Labor force: 2.1 million; 11.7% agriculture, forestry, and
fishing, 26.1% mining and manufacturing, 7.0% construc-
tion, 14.3% commerce, 7.8% transportation and communica-
tions, 5.6% banking and finance, 25.5% services; 4.6% unem-
ployed (1979 average)
Organized labor: 60% of labor force','451525aca3b5c1b7c0c64f210c8c0a3de8281787d2464df2cea4efcf38ae50e6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e890a134e63418e52a94d065670389273b721a8241fed09881555c2947b13f34',1982,'FR','France','people-and-society',199,'Population: 54,174,000 (July 1982), average annual
growth rate 0.4%
Nationality: noun — Frenchman (men); adjective —
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly declining
regional patois — Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 20.5 million (September 1979); 47% services,
35% industry, 9% agriculture, 9% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force
Population: 37,940,000 (July 1982), including the Balearic
and Canary Islands and Ceuta and Melilla (two towns on the
Moroccan coast); average annual growth rate 0.7%
Nationality: noun — Spaniard(s); adjective — Spanish
Ethnic divisions: homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97%
Labor force (1979): 13.2 million; 19% agriculture, 27%
industry, 10% construction, 41% services; unemployment
now estimated at nearly 12% of labor force
Organized labor: labor unions legalized April 1977 expe-
riencing surge in membership; probably represent 30-35% of
the labor force (1979)','bf9ca70023b400321fd46c71dd77f544584a5056b80bde504acc589b51430b3e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('059a8411973cbfe65b1aed52aef7779e00ea93f706ea3aba4c8ce0eac7d45c29',1982,'GF','French Guiana','people-and-society',202,'Population: 69,000 (July 1982), annual growth rate 2.5%
Nationality: noun — French Guianese (sing., pi.); adjec-
tive— French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% Caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force','ac319c6beb8453558df398a99b25f69b172c799f600758f04feb1a9be5d72cdc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e88bca16107852b7878592c7dd352d81fd8084f439d45892bb3628c3aa71dbf6',1982,'KI','Kiribati','people-and-society',206,'Population: 155,000 (July 1982), annual growth rate 2.2%
Nationality: noun — French Polynesian(s); adjective —
French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic
Population: 59,000 (July 1982), average annual growth
rate 1.1%
Nationality: noun — Kiribatian(s); adjective — Kiribati
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: adult literacy ratio 90%
Labor force: 15,921 (1973); general unemployment rate
4.9%
Population: 20,586,000 (July 1982), average annual
growth rate 3.2%
Nationality: noun — Korean(s); adjective — Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52% non-
agricultural; shortage of skilled and unskilled labor
Population: 41,092,000 (July 1982), average annual
growth rate 1.6%
Nationality: noun — Korean(s); adjective — Korean
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk reli-
gion (Shamanism); vigorous Christian minority (16.6% Chris-
tian population); Buddhism (including estimated 20,000
members of Soka Gakkai); Chondokyo (religion of the
heavenly way), eclectic religion with nationalist overtones
founded in 19th century, claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: 14.2 million (1979); 36% agriculture, fishing,
forestry; 24% mining and manufacturing; 40% services and
other; average unemployment 3.8% (1979)
Organized labor: about 13% of nonagricultural labor
force','6d54a7a9cc0e340802e683959bac630102031ca281137029bcbf1abd38d7cab3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8d803e404c308cdb07618ef1ada961bc3df6369b0fd54a814b1e48b943e5561',1982,'GA','Gabon','people-and-society',210,'Population: 662,000 (July 1982), average annual growth
rate 1.3%
Nationality: noun — Gabonese (sing., pi.); adjective —
Gabonese
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including 20,000
French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: government claims more than 80% of school age
children in school, but literacy rate is substantially below this
figure— 20%
Labor force: about 280,000 of whom 98,000 are wage
earners in the modern sector (late 1979)
Organized labor: there are 38,000 members of the nation-
al trade union, the Gabonese Trade Union Confederation
(COSYGA)
Population: 635,000 (July 1982), average annual growth
rate 2.8%
Nationality: noun — Gambian(s); adjective — Gambian
Ethnic divisions: over 99% Africans (Mandinka 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Mandinka and Wolof most
widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsist-
ence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,738,000, including East Berlin (July 1982),
average annual growth rate 0.0%
Nationality: noun — German(s); adjective — German
Ethnic divisions: 99.7% German, 0.3% Slavic and other
Religion: 53% Protestant, 8% Roman Catholic, 39% unaf-
filiated or other; less than 5% of Protestants and about 25%
of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.7 million; 38.0% industry; 3.2% handi-
crafts; 7.1% construction; 8.6% agriculture; 7.4% transport
and communications; 10.3% commerce; 20.1% services; 3.2%
other
Organized labor: 87.7% of total labor force
Population: 61,697,000, including West Berlin (July 1982),
average annual growth rate 0.0%
Nationality: noun — German(s); adjective — German
Ethnic divisions: 99% Germanic, 1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 6.4%
other (as of 1975)
Language: German
Literacy: 99%
Labor force: 27.199 million (1979); 36.4% in manufactur-
ing, 6.6% construction, 37.4% services, 9.7% government,
5.6% agriculture, 0.5% other; 3.8% unemployed July 1980
Organized labor: 33.7% of total labor force; 40.1% of
wage and salary earners','abb0166353d424e1b90f3d1b53572365d63772b7ca168c88a941780735ec3d70','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d789fd6d808cc8337846265d37aae0a95aec84dbb5eb1d2fc232d2fe9187dbc6',1982,'GH','Ghana','people-and-society',214,'Population: 12,943,000 (July 1982), average annual
growth rate 3.2%
Nationality: noun — Ghanaian(s); adjective — Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing,
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation, and communications, 2.9% professional;
400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor
force','6e48b58718a8d189f67f8163f8b8d92390a7f0e5dba665252605032bbce03368','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb125ddc37ded267dff7c0554b1596a4520decd6366334dfbb4aef54b135f2ad',1982,'GI','Gibraltar','people-and-society',218,'Population: 30,000 (July 1982), average annual growth
rate 0.8%
Nationality: noun — Gibraltarian; adjective — Gibraltar
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese, and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltar
laborers
Organized labor: over 6,000','2c1945d93a94e7e38716d2fff39ab5c9edc399a905249c6db7c214e29a18f8dd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a802f57befc0615eb61ef9a069ea138a32d9f5421616cf1f41d9536e0b6e7999',1982,'GR','Greece','people-and-society',222,'Population: 9,743,000 (July 1982), average annual growth
rate 0.7%
Nationality: noun — Greek(s); adjective — Greek
Ethnic divisions: 98.8% Greek, 0.2% Turkish, 1.0% other
Religion: 99% Greek Orthodox, 0.3% Muslim, 0.7% other
Language: Greek; English and French widely understood
Literacy: males about 94%; females about 79%; total
about 86%
Labor force: 3.3 million (1979 est.); approximately 31%
agriculture, 30% industry, 39% services; urban unemploy-
ment is under 3%, but substantial unreported unemployment
exists in agriculture
Organized labor: 10-15% of total labor force, 20-25% of
urban labor force','bb62a6ff0894796eb6f7f9b5a91fba93f52a98093afee31ec31fdf6b84f5a33d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd473a1337ba6630e2f6a631a434d607ce053fd5c245270ca20f09ac5ccdd7dd',1982,'GL','Greenland','people-and-society',227,'Population: 51,000 (July 1982) - ^ annual growth
rate 0.6%
Nationality: noun — Greenlander(s); adjective — Green-
landic
Ethnic divisions: 86% Greenlander (Eskimos and
Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep
breeding','edd6d0cc09c5d65f497afa44e25f62021bfb0aef3bda2559e17eea3d18b8efa7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a70c2ba8edf526f511b2e0f676f745bb3726fcefd464d4989d1246a7aedcd2d9',1982,'GD','Grenada','people-and-society',232,'Population: 109,000 (July 1982), average annual growth
rate 1.0%
Nationality: noun — Grenadian(s); adjective — Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 36,000 (1978, est.); 40% agriculture
Organized labor: 33% of labor force','9ee80f03d1c65b03bfbc671c7cd761f8724bcbeef3b52aeddc2afe1ce41106de','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf9a1a3794403def7a7e962d92f905efad156a58e2f412f5ed286278ee780c3f',1982,'GP','Guadeloupe','people-and-society',236,'Population: 305,000 (July 1982), average annual growth
rate -0.7%
Nationality: noun — Guadeloupian(s); adjective — Guade-
loupe
Ethnic divisions: 90% Negro or mulatto, 5% Caucasian,
less than 5% East Indian, Lebanese, Chinese
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','aed62426cae812eb1c51e27fd5286acadf55eecc4ef7efceb4837d29c1b31124','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('990aa117dcac41fa61231dc3537c6b3e296f5f613dcc670d4a4e552cd63e09f9',1982,'GT','Guatemala','people-and-society',238,'Population: 7,537,000 (July 1982), average annual growth
rate 3.1%
Nationality: noun — Guatemalan(s); adjective — Guatema-
lan
Ethnic divisions: 58.6% Ladino (mestizo and westernized
Indian), 41.4% Indian
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 30%
Labor force (1974): 1.8 million; 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 3.9% con-
struction, 2.1% transport, 0.7% mining, 1.2% electrical, 0.8%
other; unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)','cdee29a94e9a8d1048d43794fa61c1569412b8124b897aa874f056b9a8ac8452','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64bf42852ac4a07a3c0ff15a620d09d8235d4b61d2e4cd9a6245b1321792dc73',1982,'GW','Guinea-Bissau','people-and-society',245,'Population: 823,000 (July 1982), average annual growth
rate 1.9%
Nationality: noun — Guinean(s); adjective — Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese and numerous African languages
Literacy: 3% to 5%
Labor force: 90% of economically active population
engaged in subsistence agriculture','84de95a4b7f723bce3fb068f531ef3c8e3c36fd929fcd8ee070958cfb9193d02','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7574687c1824295d1b367d5997987723e8274d428053073130b1ca4d4520b37',1982,'GY','Guyana','people-and-society',249,'Population: 870,000 (July 1982), average annual growth
rate 1.5%
Nationality: noun — Guyanese (sing., pi.); adjective —
Guyanese
Ethnic divisions: 51% East Indians, 43% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other
Language: English
Literacy: 86%
Labor force: 242,000 (1975); 29% agriculture, 31%
manufacturing/mining, 40% services; 21% unemployed
Organized labor: 34% of labor force','21a466a601850f5e1c5eeccafb21a4c6fd700335eb5259c0d2cc1e0b7468bd62','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5086caa4ee37e5970896d0d040f197e43d4ffbd232eeb064b8150c0b20751168',1982,'HT','Haiti','people-and-society',254,'Population: 6,054,000 (July 1982), average annual growth
rate 2.2%
Nationality: noun — Haitian(s); adjective — Haitian
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of popu-
lation; all speak Creole
Literacy: 10% to 12%
Labor force: 2.3 million (est. 1975); 79% agriculture, 14%
services, 7% industry, 5% unemployed; shortage of skilled
labor; unskilled labor abundant
Organized labor: less than 1% of labor force','88ad5df6c57c436227450579b9ed6fddd7a7c8dcaff983ecdc226559407ff6ac','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2adffdb9fa490f278f4e2880bc1810fc6eb10fcd7396c57884c882a29edeba1',1982,'PH','Philippines','people-and-society',260,'Population: 5,272,000 (July 1982), average annual growth
rate 2.3%
Nationality: adjective — Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
religions
Language: Chinese, English
Literacy: 75%
Labor force (1976 Census): 1.87 million; 45.3% manufac-
turing, 18.6% services, 6.0% construction, mining, quarrying
and utilities, 19.4% commerce, 2.6% agriculture, forestry,
fisheries, and hunting, 7.3% communications, 0.8% other;
est. unemployment 3.0%, underemployment is a serious
problem
Organized labor: 21% of 1976 labor force
Population: 51,574,000 (July 1982), average annual
growth rate 2.5%
Nationality: noun — Filipino(s); adjective — Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Mus-
lim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
Literacy: about 83%
Labor force: 18.5 million (1981); 47.3% agriculture, 12.2%
manufacturing, 12.2% commerce, 17.6% services, 3.5%
transportation, 4.6% construction
Population: 18,456,000, excluding the population of Que-
moy and Matsu Islands and foreigners (July 1982), average
annual growth rate 1.8%
Nationality: noun — Chinese (sing., pi.); adjective —
Chinese
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
Religion: 93% mixture of Buddhist, Confucian, and Tao-
ist; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language); Taiwan-
ese and Hakka dialect also used
Literacy: about 90%
Labor force: 6.51 million (1979); 21.5% primary industry
(agriculture), 41.8% secondary industry (including manufac-
turing, mining, construction), 36.7% tertiary industry (in-
cluding commerce and services), 1979; 1.3% unemployment
(1979)
Organized labor: about 15% of 1978 labor force (govern-
ment controlled)','775e2053bc7cb45c69846a52332391c4064665d2dde3833410fec08ed606dec6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('960107394ce253daf4d74c41d231930972f25a72f482ff62726667edc6e2f072',1982,'HU','Hungary','people-and-society',264,'Population: 10,714,000 (July 1982), average annual
growth rate 0.0%
Nationality: noun — Hungarian(s); adjective — Hungarian
Ethnic divisions: 92.4% Magyar, 3.3% Gypsy, 2.5% Ger-
man, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.6% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,230,000 (1979); 20% agriculture, 33%
industry and building, 47% other nonagriculture','71504b5f5e3bcc6c2ef2982cc0f63271b0fbb38a4e8224000cfff0106f86d525','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0194a3188487f7bdadb4f10509c804dc465adaecd53f4423aa81f24c9ccac355',1982,'IS','Iceland','people-and-society',268,'Population: 233,000 (July 1982), average annual growth
rate 1.0%
Nationality: noun — Icelander(s); adjective — Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 102,000; 9.0% agriculture; 5.4% fishing; 8.0%
fish processing; 16.8% other manufacturing; 12.2% construc-
tion; 18.6% commerce, finance, and services; 6.3% transpor-
tation and communications; 23.7% other; unemployment
1979 est., 0.4%
Organized labor: 60% of labor force','51be6c531339fb29102a5d7625e46964abc2038ee0d27103d8050de71ed34170','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a643fed15d615fa6bfe7569b2d498a0351f2d897f66fa059359ccb26e0bc27b',1982,'ID','Indonesia','people-and-society',273,'Population: 157,595,000, including East Timor and West
Irian Jaya (July 1982), average annual growth rate 2.1%
Nationality: noun — Indonesian(s); adjective — Indonesian
Ethnic divisions: majority of Malay stock comprising 45%
Javanese, 14% Sundanese, 7.5% Madurese, 7.5% coastal
Malays, 26% other
Religion: 90% Muslim, 5% Christian, 3% Hindu, 2% other
Language: Indonesian (modified form of Malay) official;
English and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 60 million; 64% agriculture, 12% trade, 7%
industry, 17% other (1980 est.)
Organized labor: 10% of labor force
Population: 41,203,000 (July 1982), average annual
growth rate 3.1%
Nationality: noun — Iranian(s); adjective — Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 13%
other Iranian, 18% Turkic, 3% Arab and other Semitic, 1%
other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2% Zoroas-
trians, Jews, Christians and Baha''is
Language: Persian, Turkish dialects, Kurdish, Arabic
Literacy: about 37% of those seven years of age and older
(1976 est.)
Labor force: 12.0 million, est. (1979); 33% agriculture,
21% manufacturing; shortage of skilled labor substantial','fe3db75d84d78297f651e31eb197075268ab0dcd8bb39f0f003000b9aa218800','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('659aa441479e2acf815a84012334acb6b963042461cbd6891633387e1a7da23a',1982,'IQ','Iraq','people-and-society',277,'Population: 14,034,000 (July 1982), average annual
growth rate 3.3%
Nationality: noun — lraqi(s); adjective — Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 2.4% Turko-
mans, 0.7% Assyrians, 7.7% other
Religion: 90% Muslim (50% Shia Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 3.1 million (1977); 30% agriculture, 27%
industry, 21% government, 22% other; rural underemploy-
ment high, but not serious because low subsistence levels
make it easy to care for unemployed; severe shortage of
technically trained personnel
Organized labor: 11% of labor force','6c77cb1ec73238847dfede2779912fd7f0e908e214351798745322c159483a64','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63728ecc0a0e181b4ce39954d604ea534baed2df986aced2a0fa6c9225b81606',1982,'IE','Ireland','people-and-society',280,'Population: 3,533,000 (July 1982), average annual growth
rate 1.5%
Nationality: noun — Irishman(men), Irish (collective pi.);
adjective — Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%~99%
Labor force: about 1,133,000 (1978); 26% agriculture,
forestry, fishing; 19% manufacturing; 15% commerce; 7%
construction; 5% transportation; 4% government; 24% other;
7.8% unemployment (August 1979)
Organized labor: 36% of labor force','cb6528834b1869431e175911b3cec3b9c3a8ec90b3ae3d4481833684b2663874','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37f37487b04470ba9eaf10ff91c66369b1b53142e23bd61c70fe0d701e3bc16a',1982,'IL','Israel','people-and-society',285,'Population: 3,916,000, excluding East Jerusalem (July
1982), average annual growth rate 1.9%
Nationality: noun — Israeli(s); adjective — Israeli
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other
Language: Hebrew official; Arabic used officially for
Arab minority; English most commonly used foreign
language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,318,000; 6.3% agriculture, forestry and
fishing; 23.5% industry, mining, and manufacturing; 1.0%
electricity and water; 6.3% construction and public works;
11.6% commerce; 6.9% transport, storage, and communica-
tions; 8.2% finance and business; 29.3% public services; 6.1%
personal and other services (1980)
112
ISRAEL (Continued)
Organized labor: 90% of labor force','8bf29db5c4a719db7a8606b1f25dcff87e3848037188afd1ab5b0c29be2d3959','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3809c4d07b954fbd292c90ffb20184ee44231e267cdcb155f3ec9282dccbb1f',1982,'IT','Italy','people-and-society',288,'Population: 57,353,000 (July 1982), average annual
growth rate 0.3%
Nationality: noun — Italian(s); adjective — Italian
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French-, and Slovene-
Italians in the north and of Albanian-Italians in the south
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige region
(for example, Bolzano) are predominantly German speaking;
significant French-speaking minority in Valle d''Aosta re-
gion; Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 596-7% of population illiterate (1972); illiteracy
varies widely by region
Labor force: 22,372,000 (1980); 14.1% agriculture, 37.6%
industry, 48.3% other (1980); 7.6% unemployment (1980); 1.5
million Italians employed in other West European countries
Organized labor: 50-55% (est.) of labor force
Population: 8,569,000 (July 1982), average annual growth
rate 3.3%
Nationality: noun — Ivorian(s); adjective — Ivorian
Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately
2 million foreign Africans, mostly Upper Voltans; about
75,000 to 90,000 non-Africans (50,000 to 60,000 French and
25,000 to 30,000 Lebanese)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula
most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of population engaged in agricul-
ture, forestry, livestock raising; about 11% of labor force are
wage earners, nearly half in agriculture, remainder in
government, industry, commerce, and professions
Organized labor: 20% of wage labor force
Population: 302,000 (July 1982), average annual growth
rate -0.8%
Nationality: noun — Martiniquais (sing, and pi.); adjec-
tive— Martiniquais
Ethnic divisions: 90% African and African-Caucasian-
Indian mixture, less than 5% East Indian, Lebanese, and
Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public serv-
ices, 11% construction and public works, 10% commerce and
banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','5b212c2d16c3d657f11f3eae2e90adb9dae605870d0b8fd03e8b47cc17762224','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe7597abb9b73931a9af30a8da4bdd6c9ab8107817e0eee98a8f50ddc0705398',1982,'JM','Jamaica','people-and-society',292,'Population: 2,295,000 (July 1982), average annual growth
rate- 1.2%
Nationality: noun — Jamaican(s); adjective — Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
East Indian and Afro-East Indian 3.4%, white 3.2%, Chinese
and Afro-Chinese 1.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist cults
Language: English
Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 1,006,900, including 269,000 unemployed
(1980); 30% in agriculture, forestry, fishing and mining, 10%
manufacturing/mining, 14% public administration, 4% con-
struction, 11% commerce, 4% transportation and utilities,
16% services; 26% unemployed; shortage of technical and
managerial personnel
Organized labor: about 33% of labor force (1980)','b40cfa37590853ba0c8305d54798924ca394e6408be1ce18ef8498e554b62442','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4e487d23191f9aec3ee353b48caaa7396cc40235d55d5292dc7ed77f9b89671',1982,'JP','Japan','people-and-society',297,'Population: 118,519,000, (July 1982), average annual
growth rate 0.7%
Nationality: noun — Japanese (sing., pi.); adjective —
Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 99%
Labor force (1980): 56.5 million; 10% agriculture, forest-
ry, and fishing; 35% manufacturing, mining, and construc-
tion; 51% trade and services; 4% government; 2%
unemployed
Organized labor: 22% of labor force','f9f81f2ec52c18d43a3bf925a569cf93a3d7f44fa870500c3b945cb8f35dd2c1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c2d7912aa487e49355d3212c6d25f51c9479b59d9c4d63966d6a4d95dcaf000',1982,'JO','Jordan','people-and-society',300,'Population: 3,246,000— East and West Banks, including
East Jerusalem (July 1982), average annual growth rate 3.2%;
East Bank, 2,415,000, average annual growth rate 3.9%;
West Bank, including East Jerusalem, 831,000, average
annual growth rate 1.2%
Nationality: noun — Jordanian(s); adjective — Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official; English widely understood
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 638,000; less than 2% unemployed
Organized labor: 9.8% of labor force
Population: 5,882,000 (July 1982), average annual growth
rate 1.9%
Nationality: noun — Kampuchean(s); adjective — Kam-
puchean
Ethnic divisions: 90% Khmer (Kampuchean), 5% Chinese,
5% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian','c1a2a6b80479bd2f28b9c4860700fa0024dd5086704889a9b4206b862609c9de','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80c719ce3ba7c53e68120638b116b60daa3c4fa0f05fde7fad578df56f61793a',1982,'KE','Kenya','people-and-society',304,'Population: 17,832,000 (July 1982), average annual
growth rate 4.1%
Nationality: noun — Kenyan(s); adjective — Kenyan
Ethnic divisions: 97% native African (including Bantu.
Nilotic, Hamitic and Nilo-Hamitic); 2% Asian; 1% Europe
Arab, and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language
Literacy: 27%
Labor force: 5.4 million; about 900,000, in monetary
Population: 52,000 (July 1982), average annual growth
rate 0.8%
Ethnic divisions: mainly of African Negro descent
Nationality: noun — Kittsian(s), Nevisian(s); adjective —
Kittsian, Nevisian
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 88-90%
Labor force: 30,000 (1979 est.)
Organized labor: 6,700
Population: 119,000 (July 1982), average annual growth
rate 1.4%
Nationality: noun — St. Lucian(s); adjective — St. Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 45,000 (1979); 40% agriculture; 13% unem-
ployment (1979)
Organized labor: 20% of labor force
Population: 121,000 (July 1982), average annual growth
rate 2.9%
Nationality: noun — St. Vincentian(s) or Vincentian(s); ad-
jectives— St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent; re-
mainder mixed with some white and East Indian and Carib
Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 61,000 (1979 est.); about 20% unemployed
(1978)
Organized labor: 10% of labor force','f91ea61ea92d40520cbc0036370e6f45785b311eab304b2253fa52f0878330e1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe693dfdbfb1a5dc45ccd167e7ea7e58b8c947dd1c364190529f1ce92f3b705f',1982,'KW','Kuwait','people-and-society',310,'Population: 1,553,000 (July 1982), average annual growth
rate 6.2%
Nationality: noun — Kuwaiti(s); adjective — Kuwaiti
Ethnic divisions: 42% Kuwaitis, 41% other Arabs, 7%
South Asians, 4% Iranians, 6% other
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 60%
Labor force: 360,000 (1978 est.); 74% services, 11% indus-
try, 11% construction; 70% of labor force is non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
Population: 3,577,000 (July 1982), average annual growth
rate 1.7%
Nationality: noun — Lao or Laotian (sing.); Laotians (pi.);
adjective — Lao or Laotian
Ethnic divisions: 48% Lao; 25% Phoutheung (Kha); 14%
Tribal Tai; 13% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
language
Literacy: about 15%
Labor force: about 1-1.5 million; 80%-90% agriculture
Organized labor: only labor organization is subordinate to
the Communist Party','9cd266717bf8dc95f7176bcdda2a3fafe5066fea1d6643c2eaad3fbd8d83dba3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f620074c3d18e012a12670b5f5871fda1e4efe2887d33896ddee4d17f303f098',1982,'LB','Lebanon','people-and-society',314,'Population: 3,177,000 (July 1982), average annual growth
rate 2.6%; this estimate does not take into account any
demographic consequences of the 1975-76 civil war
Nationality: noun — Lebanese (sing., pi.); adjective —
Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49%
agriculture, 11% industry, 14% commerce, 26% other; mod-
erate unemployment
Organized labor: about 65,000','a2dfd30dcd1a6f8413a1e2c8e2bf549c20c8693209eba34c209f94a2a400d955','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55d04e9609cfab73700e9a41b1a55a56dcac5e86220e9913d9e0827bbe2bc96d',1982,'LS','Lesotho','people-and-society',319,'Population: 1,395,000 (July 1982), average annual growth
rate 2.2%
Nationality: noun — Mosotho (sing.), Basotho (pi.); adjec-
tive— Basotho
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend from six
months to many years as wage earners in South Africa
Organized labor: negligible','56f92f43d4196b3cf3d11d262b4c4c904083d99f9ed2b4cee2441e9b33fd20fe','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c9fe3842c4e68c4aab90973d878a371b0580c1b8ebb597baa2b3acd4ed40577',1982,'LR','Liberia','people-and-society',321,'Population: 2,024,000 (July 1982), average annual growth
rate 3.2%
Nationality: noun — Liberian(s); adjective — Liberian
Ethnic divisions: 97% indigenous Negroid African tribes,
including Kpelle, Bassa, Kru, Grebo, Gola, Kissi, Krahn, and
Mandingo; 3% descendants of repatriated slaves known as
Americo-Liberians
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 510,000, of which 160,000 are in monetary
economy; non-African foreigners hold about 95% of the top-
level management and engineering jobs
Organized labor: 2% of labor force','2c494cb20a427131749ec71aea6ef3de1629f1c7b9fc45716a8efa9158ab9ba2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97aaea78d867173c1d413d9d641f9c9229070267e03aee3304e100ef524b5677',1982,'LY','Libya','people-and-society',324,'Population: 3,425,000 (July 1982), average annual growth
rate 5.4%
Nationality: noun — Libyan(s); adjective — Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians, Paki-
stanis, Turks, Indians, and Tunisians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
Labor force: 900,000, of which about 350,000 are resident
foreigners','6e1dee7d589c203e833c7812267c6cd932c349e30f17925ce89434bac5d50854','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('766a23f47707ce75334862dda7a7580340874c26f9ca69b2b9332fa2867b4da4',1982,'LI','Liechtenstein','people-and-society',328,'Population: 26,000 (July 1982), average annual growth
rate 1.7%
Nationality: noun — Liechtensteiner(s); adjective — Liech-
tenstein
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 82.7% Roman Catholic, 7.1% Protestant, 10.2%
other
Language: German, Alemannic dialect
Literacy: 100%
Labor force: 11,368, 5,078 foreign workers (mostly from
Switzerland and Austria); 54.5% industry, trade, building
trade; 41.6% services; 4.0% agriculture, forestry, and hunting','07c92b9aa34c6a6d45e145fe9d81102f83253b1efd6d2b2c2a9ab07bc31fe972','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b51189c1ac618fc61c13a0c9b6c407546395468e0b88a15e36b82bfb32980317',1982,'LU','Luxembourg','people-and-society',333,'Population: 366,000 (July 1982), average annual growth
rate 0.3%
Nationality: noun — Luxembourger(s); adjective — Luxem-
bourg
Ethnic divisions: 83% Luxembourger, including an esti-
mated 5% of Italian descent; remainder French, German,
Belgian, and other
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1977) 147,300; one-third of labor force is
foreign, comprised mostly of workers from Portugal, Italy,
France, Belgium, and West Germany (1977); unemployment
0.9% (1981)','330037604a9d3fd33de569c693ef31faf9fe86fe226358c9e842c9c4c9132c62','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d94ddbb3c66b6ea5188b0c5e1496db952e691fbd876fba5d9825d7bdb897d1a2',1982,'MG','Madagascar','people-and-society',336,'Population: 8,992,000 (July 1982), average annual growth
rate 2.5%
Nationality: noun — Malagasy (sing, and pi.); adjective —
Malagasy
Ethnic divisions: basic split between highlanders of pre-
dominantly Malayo-Indonesian origin, consisting of Merina
(1,643,000) and related Betsileo (760,000) on the one hand
and coastal tribes — collectively termed the Cotiers — with
mixed Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka 941,000,
Tsimihety 442,000, Antaisaka 415,000, Sakalava 375,000;
there are also 10-12,000 European French, 5,000 Indians of
French nationality, and 5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are non-
salaried family workers engaged in subsistence agriculture;
of 175,000 wage and salary earners, 26% agriculture, 17%
domestic service, 15% industry, 14% commerce, 11% con-
struction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force','0b51cf71d4c234c10dc4816401865173ed1c6c259ecdecebf8b8e1e25d87511d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('034ed4190ea9a201af1d9b26826fee6ebf1297bc486dba7bb556d69b9bcb565f',1982,'MW','Malawi','people-and-society',340,'Population: 6,410,000 (July 1982), average annual growth
rate 3.0%
Nationality: noun — Malawian(s); adjective — Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Tombuka is
second African language
Literacy: 15% of population
Labor force: 331,536 wage earners employed in Malawi
(1978); 48% agriculture, 10% construction, 10% commerce,
11% manufacturing, 15% personal services, 5% miscella-
neous services; 6,000 Europeans permanently employed
Organized labor: small minority of wage earners are
unionized
Population: 49,823,000 (July 1982), average annual
growth rate 2.1%
Nationality: noun — Thai (sing, and pi.); adjective — Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 82%
Labor force: 78% agriculture, 15% services, 7% industry','8219e8d0eaa969b3ffcdf80a9e7a392dbbfc0ec5a4250cc661595311d2075248','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0e4bbdb9f9b44a5fd7949598ca40b4f43ad1e1d35badcd98b91005fb27b9127',1982,'MY','Malaysia','people-and-society',345,'Population: 14,661,000 (July 1982), average annual
growth rate 2.3%
Peninsular Malaysia: 12,105,000 (July 1982), average
annual growth rate 2.1%
Sabah: 1,135,000 (July 1982), average annual growth
rate 4.1%
Sarawak: 1,421,000 (July 1982), average annual growth
rate 2.6%
Nationality: noun — Malaysian(s); adjective — Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 53% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sabah: 69% indigenous tribes, 21% Chinese, 10% other
145
MALAYSIA (Continued)
Sarawak: 50% indigenous tribes, 30% Chinese, 19%
Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim, Chi-
nese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language;
Peninsular Malaysia: Malay (official); English, Chinese
dialects, Tamil
Sabah: English, Malay, numerous tribal dialects, Man-
darin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.95 million (1980)
Peninsular Malaysia: 4.1 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1980)
Sabah: 366,000 (1980); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade and
transportation, 1% other
Sarawak: 455,000 (1980); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade,
transportation, and services, 1% other
Organized labor: 562,000 (May 1980), about 11% of total
labor force; unemployment about 6.1% of total labor force
(1979), but higher in urban areas','90228f1f057aa1c0a96b9552b7d800f0861d7e38ae71cda0d2b4a4fd531bd492','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a734b4ed3dbe988f5ca830bab78741071cf18e19dddda20cb4be1cac9a9fff9',1982,'MV','Maldives','people-and-society',348,'Population: 163,000 (July 1982), average annual growth
rate 3.0%
Nationality: noun — Maldivian(s); adjective — Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
Arab, and Negro
Religion: Sunni Islam
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs 80% of the labor
force','27487cc2acded6fa7d126476f596b0c80a09945eef1ec5fb1f2ca5e4854d9c6e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30f17106a77832b30019e4692c6e0f48a3c8a8d39827e729bd5c10f620a631d5',1982,'ML','Mali','people-and-society',353,'Population: 7,015,000 (July 1982), average annual growth
rate 2.7%
Nationality: noun — Malian(s); adjective — Malian
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
Literacy: under 5%
Labor force: 2.8 million
Organized labor: National Union of Malian Workers
(UNTM) is umbrella organization over 13 national unions','eba44e0090161bc3d18b3e18e91da6d1de04ce56a569b439b7dcaa72f50f0e70','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('008273020e88d102e19953f945a0cd5b68cdcfd812605cea3ec1703fc01515ca',1982,'MT','Malta','people-and-society',355,'Population: 376,000 (July 1982), average annual growth
rate 1.6%
Nationality: noun — Maltese (sing, and pi.); adjective —
Maltese
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in
1946
Labor force: 125,000 (November 1977); 32% services
(except government), 18% government (except job corps), 5%
k>b corps, 26% manufacturing, 6% agriculture, 3% construc-
tion, 5% utilities and drydocks; 3.3% registered unemployed
Organized labor: approximately 40% of labor force','a5867890c50b4d7822b4d4bc06deda5035a6cc732155f742466c46dae5963d5e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0d59a57d19bdc96e9e4e15ee468e72de1234ed7adbcaacac8b5bb612efec187',1982,'MU','Mauritius','people-and-society',360,'Population: 990,000 (July 1982), average annual growth
rate 1.7%
Nationality: noun — Mauritian(s); adjective — Mauritian
Ethnic divisions: 67% Indians, 29% Creoles, 3.5% Chi-
nese, 0.5% English and French
Religion: 51% Hindu, 30% Christian (mostly Catholic
with a few Anglican Protestants), 17% Muslim
Language: English official language; Hindi, Chinese,
French, Creole
Literacy: estimated 60% for those over 21 and 90% for
those of school age
Labor force: 335,000; 30% agriculture, 24% industry; 20%
government services; 14% are unemployed, 12% other
Organized labor: about 35% of labor force, forming over
270 unions','12dd88f90bfe0e29dbdc0cdb4df89c552741d0bc022aa0b56daf68be91af7aeb','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('712cc75ac2fb1470173b79339ce3723d2bdf669fdb91d69698f4fe1548534399',1982,'MX','Mexico','people-and-society',364,'Population: 71,330,000 (July 1982), average annual
growth rate 2.4%
Nationality: noun — Mexican(s); adjective — Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force: 18.0 million (1978) (defined as those 12 years
of age and older); 33.0% agriculture, 16.0% manufacturing,
16.6% services, 16.8% construction, utilities, commerce, and
transport, 3% government, 5.4% unspecified activities; 10%
unemployed, 40% underemployed
Organized labor: 20% of total labor force','f52f66bd175692ad6e68c53999f37cb1477c4fc65d09c90cc7f88621f9c05bd6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e1ef4bc61dc1e9b68a2484341730dc3dc39b859b87c9749efd6f1dbd8854716',1982,'MC','Monaco','people-and-society',369,'Population: 26,000 (July 1982), average annual growth
rate 0.8%
Nationality: noun — Monacan(s) or Monegasque(s); adjec-
tive— Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete','4e8376b26edad0b6af08e0f23073f04ba0439fe140a87309bc3315ac0daed385','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bccc1c36bd01a4345fb6cc9918acaeb274289b825132496086d73303f32d6ee',1982,'MN','Mongolia','people-and-society',374,'Population: 1,759,000 (July 1982), average annual growth
rate 2.8%
Nationality: noun — Mongolian(s); adjective — Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime
Languages: Khalkha Mongol used by over 90% of popula-
tion; minor languages include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the popula-
tion is in the labor force, including a large percentage of
Mongolian women; shortage of skilled labor (no reliable
information available)','bf189bfccbaea7299ab1d40fb05c1a3ba45505c7116f95704b67be9c6a9acf8c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d956e786a6d461daa7248a83fde1e438b1ca4f59348b99aade4065941bb6812',1982,'MA','Morocco','people-and-society',378,'Population: 22,230,000 (July 1982), average annual
growth rate 2.9%
Nationality: noun — Moroccan(s); adjective — Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government, diplo-
macy, and postprimary education
Literacy: 28%
Labor force: 5.4 million (1980 est.); 50% agriculture, 15%
industry, 26% services, 9% other; at least 20% of urban labor
unemployed
Organized labor: about 5% of the labor force, mainly in
two unions — the Union of Moroccan Workers (UMT) and the
Democratic Confederation of Labor (CDT)','2d22077595d28159ed423ac5a901bb78878e574b9491d728d66c4f8bb583b8ff','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('419bf0ba80fa729f27ea5eeb2312064159bf7cfed63a15b87e8d8785cf1e8f39',1982,'MZ','Mozambique','people-and-society',380,'Population: 12,695,000 (July 1982), average annual
growth rate 2.7%
Nationality: noun — Mozambican(s); adjective — Mozam-
bican
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 15% (1974 est.)','9056d3a830aa580916a35864685d478f99473976e2eab0befcd7d7b778984f4d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25af13cb2a31bdfceee1d527c490269e9f2ae8389dcca3e86b60565f2b2c3eaf',1982,'NA','Namibia','people-and-society',384,'Population: 1,086,000 (July 1982), average annual growth
rate 3.0%
Nationality: noun — Namibian(s); adjective — Namibian
Ethnic divisions: 83% African, 11% white, 6% mulatto;
approximately half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites ei-
ther animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white
wage earners belong to South African unions','a1f0fa9e06829f52cc5c5204863c1090505320a60c359751efa73838bcd570b7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76d24de64a2ad8465990375688b0b6aecf79311bb4f54beb9811c923be4227cc',1982,'NR','Nauru','people-and-society',389,'Population: 9,000 (July 1982), average annual growth rate
1.7%
Nationality: noun — Nauruan(s); adjective — Nauruan
Ethnic divisions: 58% Nauruans, 26% other Pacific Is-
landers, 8% Chinese, 8% Europeans
Religion: Christian (two-thirds Protestant, one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Literacy: nearly universal','fd9f10dffaec8b64dcf6e3232d7365ad7fe33c2e2b340a8fca72a0166bec3329','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7528adb4e97c7df922f7a0af9950f33a9b70170739a5d03cee2b51db8610c1e',1982,'NP','Nepal','people-and-society',394,'Population: 15,715,000 (July 1982), average annual
growth rate 2.4%
Nationality: noun — Nepalese (sing, and pi.); adjective —
Nepalese
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto- Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu kingdom in world, although
no sharp distinction between many Hindu (about 88%) and
Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry;
great lack of skilled labor','448dd816c7e29aba6492283ad39b843b1771c3cfc8186e7e70be84cfe86d25a3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf7960573e066e631197b8be24f9790ba349f083cabe49b372d131447adde761',1982,'NL','Netherlands','people-and-society',396,'Population: 14,349,000 (July 1982), average annual
growth rate 0.7%
Nationality: noun — Netherlander(s); adjective — Nether-
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 31% Protestant, 40% Roman Catholic, 24%
unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.8 million (1978); 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 10%
unemployment, November 1981
Organized labor: 33% of labor force
Population: 247,000 (July 1982), average annual growth
rate 1.0%
Nationality: noun — Netherlands Antillean(s); adjective —
Netherlands Antillean
Ethnic divisions: racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; Negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish minorities
Language: Dutch official; Papiamento, a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 83,000 (1977); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other;
unemployment 20% (1977)
Organized labor: 60%-70% of labor force','f9adbb0b6710be40bb82cca871066d73feaefee4de40a7b3caa965415922b7e5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3185ab9767e783ec6f3c4006591a3d43d67c004d90cea2b20ed0ce1194b21e26',1982,'NC','New Caledonia','people-and-society',401,'Population: 138,000 (July 1982), average annual growth
rate 0.5%
Nationality: noun — New Caledonian(s); adjective — New
Caledonian
Ethnic divisions: Melanesian 42%; French 40%; remain-
der Vietnamese, Indonesian, Chinese, Polynesian
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War II period; immigrant labor now coming
from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: labor not organized','736aa37d12079c29bd77aef9d40f2c2963596bba352ff631d6ca3ee67cd712de','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da6b4d1a4ab36b2a35b1a9cbcb99bb095e9a74d2722e209fb083088e455c5756',1982,'NZ','New Zealand','people-and-society',406,'Population: 3,120,000 (July 1982), average annual growth
rate 0.1%
Nationality: noun — New Zealander(s); adjective — New
Zealand
Ethnic divisions: 87% European, 9% Maori, 2% Pacific
Islanders, 2% other
Religion: 81% Christian, 1% Hindu, Confucian, and
other, 18% none or unspecified
Literacy: 98%
Labor force: 1,316,000 (1979); 13% agriculture, 33%
manufacturing, mining, and construction, 9% transportation
and communications, 24% commerce and finance, 21%
administrative and professional; unemployment 4.3% (De-
cember 1978)
Organized labor: 46% of labor force','5e6adf87d860e955ffcdad3ef5935fbfe0a6d4589247cfd75d5ff6b049894af7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9d6d926da7fc08b52d8239070f91d95137c48c7cfa36eb0e62d5a17231e5de1',1982,'NI','Nicaragua','people-and-society',409,'Population: 2,643,000 (July 1982), average annual growth
rate 3.2%
Nationality: noun — Nicaraguan(s); adjective — Nicaraguan
Ethnic divisions: 69% mestizo, 17% white, 9% Negro, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English and Indian-speaking
minorities on Atlantic coast
Literacy: 87% of population 10 years of age and over
Labor force: 850,000 (1981 est.); 42% agriculture, 13%
industry, 23% service industries, 3% construction, 14% com-
merce, 5% other; 25% unemployment
Organized labor: almost 39% of Nicaragua''s 850,000
economically active citizens are organized; of the seven
confederations, five are Sandinista or Marxist oriented; they
are — the government-sponsored Sandinista Workers* Central
(CST), with over 125,000 members, including state and
municipal employees; the Association of Campesino Work-
ers (ATC), which also has 125,000 members; the General
Confederation of Independent Workers (CGI-I), with ap-
proximately 15,000 members; the Workers Front, with a
small membership of about 100; and the Central for Labor
Action and Unity (CAUS), with about 3,000 members; the
other two unions are the Nicaraguan Workers* Central
(CTN), with 25,000 members, and the Confederation of
Labor Unification (CUS), with 12,000 members','407c4df109f9b863bd7bae1ee61e80869abea52e6083a4b6ccc7d0572d375fdc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ca8da502668757b60ed6776caf513810bad829cd1494e01f7c55e002f1fbc95',1982,'NE','Niger','people-and-society',414,'Population: 5,833,000 (July 1982), average annual growth
rate 2.9%
Nationality: noun — Nigerien(s) (sing, and pi.); adjective —
Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official; many African languages; Hau-
sa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible','a3ffffdff69df2f547ee883b88a57ccd121f69e998d6356ddcf868adb542f71d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e39625fe76370fc739b952f2d860793822331f321090299319d70935ee12ab2',1982,'NO','Norway','people-and-society',418,'Population: 4,113,000 (July 1982), average annual growth
rate 0.3%
Nationality: noun — Norwegian(s); adjective — Norwegian
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 95% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-speaking
minorities
Literacy: 100%
Labor force: 1.9 million; 8.6% agriculture, forestry, fish-
ing, 21.2% mining and manufacturing, 5.8% banking and
financial services, 8.1% construction, 16.9% commerce, 9.2%
transportation and communication, 29.3% services; 1.4%
unemployed (1979 average)
Organized labor: 60% of labor force
Population: 56,095,000 (July 1982), average annual
growth rate 0.1%
Nationality: noun — Briton(s), British (collective pi.); adjec-
tive— British
Ethnic divisions: 81.5% English, 9.6% Scottish, 2.4% Irish,
1.9% Welsh, 1.8% Ulster, 0.8% other; West Indian, Indian,
Pakistani over 2%
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterian, 760,000 Method-
ist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1978) 26 million, 12.4% unemployed (Octo-
ber 1980)
Organized labor: 40% of labor force','3fb2a5079488237c52b6b7c69a6e3049e48add644e5c6cd724cc9000abb5245a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef98f004c08f42f200759c77cf51cd9b3e907281d684093677ec96db41f12e7d',1982,'OM','Oman','people-and-society',422,'Population: 948,000 (July 1982), average annual growth
rate 3.1%
Nationality: noun — Omani(s); adjective — Omani
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim (Ibadhi and Sunni sects, few Shias)
Language: Arabic
Literacy: 10%
Labor force: 300,000; 49% are non-Omani','874f520116b31ff063e0b19715f5c76e2e284d8a442f6bd99242da585e1d09bd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13190755555feaaee7ae1649f1f6db0ef4565ec12898907f45c1e6505987002f',1982,'PA','Panama','people-and-society',428,'Population: 2,011,000 (July 1982), average annual growth
rate 2.3%
Nationality: noun — Panamanian(s); adjective — Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
Labor force: est. 625,000 0anuary 1982); 45% commerce,
finance and services; 29% agriculture, hunting and fishing;
10% manufacturing and mining; 5% construction; 4% Canal
Zone; 5% transportation and communications; 1.2% utilities;
2% other; unemployed estimated at 10-15% (January 1982);
shortage of skilled labor but an oversupply of unskilled labor
Organized labor: 10-15% of labor force (1978 est.)','3e662e90b5bf2d4641140d1d72b3250a3e81acfb23acf213f783e2a77f33f4f6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2db24e0b7f5efcb6e65c5c5e50f1fa743fc26922fab1ff856309a85c4154eb43',1982,'PG','Papua New Guinea','people-and-society',432,'Population: 3,126,000 (July 1982), average annual growth
rate 2.2%
Nationality: noun — Papua New Guinean(s); adjective —
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan;
some Negrito, Micronesian, and Polynesian
Religion: over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 715 indigenous languages; pidgin English in
much of the country and Motu in Papua region are linguae
francae; English spoken by 1% to 2% of population
Literacy: 15%; in English, 0.1%
Labor force: 1.44 million (1979); agriculture, forestry,
fishing employ 85% of labor force; 200,000 (1979 est.) in
salaried employment','cd6d629abbd5004335c23232788e70ca815eb9c1bc7df4a3b53f3c8f8ce59a93','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0307bc5c93d244250c6cf18e1df6254e9416c8017033a0371a00ba3de945db5',1982,'PY','Paraguay','people-and-society',436,'Population: 3,347,000 (July 1982), average annual growth
rate 2.4%
Nationality: noun — Paraguayan(s); adjective — Paraguayan
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 1,003,000 (1980); 52.6% agriculture, forestry,
fishing; 28.2% services; 19.2% manufacturing and mining
(1970); unemployment rate 3.3% (1980)
Organized labor: about 5% of labor force','79118351577899897777e4556dee0cf8982fb7e438f7447fe9dd509243b19f2d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01a9861a436f46ef6b801ab7ad811395f216cc29d9069dabfeed7a411c321308',1982,'PE','Peru','people-and-society',440,'Population: 18,631,000 (July 1982), average annual
growth rate 2.8%
Nationality: noun — Peruvian(s); adjective — Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.3 million (1978); 42% agriculture, 20%
services, 13% industry, 14% trade, 4% construction, 4%
transportation, 1% mining, 2% other
Organized labor: 25% of labor force (1978)','8500773c3418e0095ee8f7f63858b44502a29f206efca1445f7294ba91c6d5fa','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06fbffd67e54d9964270d0974365d174714822047379c24bcfe4e304f0bded09',1982,'PL','Poland','people-and-society',444,'Population: 36,229,000 (July 1982), average annual
growth rate 0.9%
Nationality: noun — Pole(s); adjective — Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing), 5%
Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 19.3 million; 27% agriculture, 32% industry,
41% other nonagricultural (1980)
Organized labor: Solidarity Union — new independent
trade union formed as result of labor disturbances in Gdansk
(fall 1980)— claims 10 million members, suspended in De-
cember 1981','0fbe2aec8274ab48a87d8c5dda376cdee0aa7ff9bcd5a326a1aeae1f2b983f2a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5ed9f842062bbf1b042f59a66f9c9ef69c551f6771eb973aec015a1ba3617f1',1982,'PT','Portugal','people-and-society',449,'Population: 10,056,000 (July 1982), including the Azores
and Madeira Islands, average annual growth rate 0.6%
Nationality: noun — Portuguese (sing, and pi.); adjective —
Portuguese
Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
number less than 100,000
Religion: 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 70%
Labor force: (1979) 4.1 million; 31% agriculture, 35%
industry, 34% services; unemployment is now more than
13%
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers — National Intersindi-
cal (CGTP-IN) claims to represent 77% of the unionized
labor force; their main competition comes from the General
Workers Union (UGT) organized by the Socialists and Social
Democrats','61b9ef9429eebc31e2aab11498a843ec82f5360a56f94b29bbd95e6a10dd6780','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a4c3c5d03f460443f9d42966aee0c3449af1eb6d480528c70ff088049f73e3b',1982,'SA','Saudi Arabia','people-and-society',453,'Population: 258,000 (July 1982), average annual growth
rate 4.0%
Nationality: noun— Qatari(s); adjective— Qatari
Ethnic divisions: 25% Qatari, 20% other Arab, 34% South
Asian, 16% Iranian, 5% others
Religion: Muslim
Language: Arabic, English is commonly used as second
language
Literacy: 25%
Labor force: 100,000 (1980 est.); 90% non-Qatari
Population: 521,000 (July 1982), average annual growth
rate 1.4%
Nationality: noun — Reunionese (sing, and pi.); adjective —
Reunionese
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment
Population: 19,795,000 (July 1982), average annual
growth rate 2.8%
Nationality: noun — Saudi(s); adjective — Saudi Arabian or
Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15-25% (est.)
Labor force: about 33% (one-half foreign) of population;
44% commerce, services, and government; 28% agriculture,
21% construction, 4% industry, 3% oil and mining','a06502d50046c6eb2f8e283a98cae7723eb103e15cfd2e6f95f6b88ecf4b94b9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fed7910d2d89fbb7228414f63ac74c736bac19c098d15356cfb774907a661d7',1982,'RO','Romania','people-and-society',457,'Population: 22,510,000 (July .1982), average annual
growth rate 0.7%
Nationality: noun — Romanian(s); adjective — Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million Ro-
man Catholic, 1 million Protestants, 60,000 Jews, 30,000
Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 12.1 million (1979); 36% agriculture, 26%
industry, 38% other nonagricultural','497e71287035b1c72ee0763cc8b52afda85bd3247a1d66cdf79f5d129b3b9f44','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9474c2d8e6e7153a013558807dba674e95c59434506fc4caf4b8731231a34965',1982,'RW','Rwanda','people-and-society',462,'Population: 5,451,000 (July 1982), average annual growth
rate 3.2%
Nationality: noun — Rwandan(s); adjective — Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
Literacy: 25% in French and Kinyarwanda
Labor force: approximately 5% in cash economy','f776fea717e421ccb5858b40b5af3edef617b947f3f6ab902ed99de20ce8f507','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d2969653a0b60049e24a14cfcf100a65c119fe98fd8ca4df6346189279db3f7',1982,'SM','San Marino','people-and-society',465,'Population: 22,000 (July 1982), average annual growth
rate 1.6%
Nationality: noun — Sanmarinese (sing, and pi.); adjec-
tive— Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: 97%
Labor force: approx. 4,300
Organized labor: General Democratic Federation of San-
marinese Workers (affiliated with ICFTU) has about 1,800
members; Communist-dominated Camera del Lavoro, about
1,000 members','5d1e6e2cf585a738ad10ed7acf3ccdd4aed49ecd01dad01b2e701274032f5b66','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a3b86a13ea9a7802388f1a35f9a98c968e737672548b25b2b06d9ed6dcf4487',1982,'ST','Sao Tome and Principe','people-and-society',470,'Population: 85,000 (July 1982), average annual growth
rate 1.1%
Nationality: noun — Sao Tomean(s): adjective — Sao
Tomean
Ethnic divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese
Religion: Roman Catholic, Evangelical Protestant, Sev-
enth Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-\\0%
Labor force: most of population engaged in subsistence
agriculture and fishing; some unemployment, but labor
shortages on plantations and for skilled work','4b65a70176c2427d88e9a9b53fefccec25ce7b7c33c8f284fa86ec86c0c573cf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fac5a7ac9c50974101a7a580a807d73f442c8c399915bd7eb8184bc6762bec83',1982,'SN','Senegal','people-and-society',473,'Population: 5,991,000 (July 1982), average annual growth
rate 2.7%
Nationality: noun — Senegalese (sing, and pi.); adjective —
Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5% Serer,
9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African,
1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal language;
use of Wolof vernacular spreading — now spoken to some
degree by nearly half the population
Literacy: 10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul-
tural workers; about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central unions, major central is CNTS,
an affiliate of governing party','5fdbdfb420e6479c88a6285369dd3bf9f7fafbb9f1ce5f5db2f55b7b6bb33ff7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f14350c387941521fc9ca3513477d6e08e99ad3451569143a87dcedc54bfc83d',1982,'SC','Seychelles','people-and-society',478,'Population: 66,000 (July 1982), average annual growth
rate 1.9%
Nationality: noun — Seychellois (sing, and pi.); adjective —
Ethnic divisions: Seychellois (admixture of Asians, Afri-
cans, Europeans)
Religion: 90% Roman Catholic
Language: Creole official and most widely spoken;
English, French
Literacy: 60% adult; 75% school-age children
Labor force: 15,000 in monetized sector (excluding self-
employed, domestic servants, and workers on small farms);
33% public sector employment, 20% private sector employ-
ment in agriculture, 20% private sector employment in
construction and catering services
Organized labor: 3 major trade unions','a066458bcc5a56956347cfdc906d11ef6c3e3906462a721aced166da51c49344','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c98c9d742ba90fce962639d63a50b891fc1be4091cfcd94e322d88b569e840',1982,'SL','Sierra Leone','people-and-society',480,'Population: 3,535,000 (July 1982), average annual growth
rate 2.2%
Nationality: noun — Sierra Leonean(s); adjective — Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; "Krio," the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million; most of population en-
gages in subsistence agriculture; only small minority, some
65,000, earn wages
Organized labor: 35% of wage earners','0b5cc0264207c55be9b4dc629677a3ee178cf8f7fe58cebb0a7e315cd4f6430a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be93648cfd93a0835f822e2a2df001764410d20933ff274aff2ee1cd75d97cf7',1982,'SG','Singapore','people-and-society',485,'Population: 2,472,000 (July 1982), average annual growth
rate 1.2%
Nationality: noun — Singaporean(s), adjective — Singapore
Ethnic divisions: 76.1% Chinese, 15.0% Malay, 6.9%
Indians and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages
Literacy: 84% (1980)
Labor force: 1,093,000; 2.2% agriculture, forestry, and
fishing, 0.2% mining and quarrying, 27.2% manufacturing,
30.5% services, 4.6% construction, 23.5% commerce, 11.7%
transport, storage, and communications
Organized labor: 23.1% of labor force','1a863389727d73b798b6ed42b620cfa255a6dd958e9c903d51a6c8d0c1357e0d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2041935d1a39f1229ef1475f8026c2ce7b0ddc3476ea4f260cb531d51708923',1982,'SB','Solomon Islands','people-and-society',488,'Population: 245,000 (July 1982), average annual growth
rate 3.4%
Nationality: noun — Solomon Islander(s); adjective — Solo-
mon Islander
Ethnic divisions: 93.0% Melanesians, 4.0% Polynesians,
1.5% Micronesians, 0.8% Europeans, 0.3% Chinese, 0.4%
others
Religion: almost all at least nominally Christian; Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60%','99dfc4675f9017c449561697da10ebbabcef248db447ed86b80168002c8feac6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a42d486913242b336536ee0815c9a4f453edd02f65d8d72a8fc26cd0d63d88d',1982,'SO','Somalia','people-and-society',492,'Population: 6,124,000 (July 1982), average annual growth
rate 3.5%
Nationality: noun — Somali(s); adjective — Somali
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1972); Arabic, Italian, English
Literacy: 5-10%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
Organized labor: General Federation of Somali Trade
Unions, a government-controlled organization, established in
1977','d21b00b535bef836f71104d5d3eae63e671cd23bab2e053db41ccfd3c80903a4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b97c5e12247ff507b324544e952572724542bf83eefdb47eff8c4b65d61f7027',1982,'ZA','South Africa','people-and-society',496,'Population: 30,021,000 (July 1982), including Bophuthats-
wana, Transkei, and Venda, average annual growth rate
2.4%; Bophuthatswana 1,347,000 (July 1982), average annual
growth rate 2.4%; Transkei 2,390,000 (July 1982), average
annual growth rate 2.2%; Venda 374,000 (July 82), average
annual growth rate 2.4%
Nationality: noun — South African(s); adjective — South
African
Ethnic divisions: 69.9% African, 17.8% white, 9.4% Col-
ored, 2.9% Asian
Religion: most whites and coloreds and roughly 60% of
Africans are Christian; roughly 60% of Asians are Hindu,
20% are Muslim
Language: Afrikaans and English official, Africans have
many vernacular languages
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 53% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is union-
ized (mostly white workers); relatively small African unions,
representing about 1% of black labor force, have recently
gained official recognition
Population: 269,876,000 (July 1982), average annual
growth rate 0.8%
Nationality: noun — Soviet(s); adjective — Soviet
Ethnic divisions: 72% Slavic, 28% among some 170 ethnic
groups
Religion: Russian Orthodox, Armenian Orthodox, Protes-
tant, Roman Catholic, Moslem, and Jews
Language: more than 200 languages and dialects (at least
18 with more than 1 million speakers); 76% Slavic group, 8%
other Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 144 million (midyear 1981), 22%
agriculture, 78% industry and other nonagricultural fields,
unemployed not reported, shortage of skilled labor reported','4bd84178922c71066393fc440de0453307607eddcdb3afad5fee12009cfd1b10','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eb0c43b0ef1988c2594c912b4b328923d24983db17c042741a12f9a2d867346',1982,'LK','Sri Lanka','people-and-society',500,'Population: 15,398,000 (July 1982), average annual
growth rate 1.8%
Nationality: noun — Sri Lankan(s); adjective — Sri Lankan
Ethnic divisions: 74% Sinhalese, 18% Tamil, 7% Moor,
1% other
Religion: 69% Buddhist, 15% Hindu, 8% Christian, 8%
Muslim, 0.1% other
Language: Sinhala official, Sinhala and Tamil listed as
national languages, Sinhala spoken by about 74% of popula-
tion; Tamil spoken by about 18%; English commonly used in
government and spoken by about 10% of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
persons — 53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates','6d013265ab8d7a38851b66413c222247d0b649b6c49ad6876c7f398a5a873ef7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85b398c0a092fe57916157b5e0528fbd330db2c4ee89ad1f1cf3f7f7c4268acb',1982,'SR','Suriname','people-and-society',503,'Population: 356,000 (July 1982), average annual growth
rate -1.5%
Nationality: noun — Surinamer(s); adjective — Surinamese
Ethnic divisions: 37% Hindustani (East Indian), 31%
Creole (Negro and mixed), 15.3% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown
Religion: Hindu, Muslim, Roman Catholic, Moravian, other
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
and is lingua franca among others; Hindi; Javanese
Literacy: 80%
Labor force: 129,000; unemployment 2.6% (1978)
Organized labor: approx. 33% of labor force
Population: 589,000 (July 1982), average annual growth
rate 2.8%
Nationality: noun — Swazi(s); adjective — Swazi
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence
agriculture; 55,000-60,000 wage earners, many only inter-
mittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 35% other (1968
est.); 18,114 employed in South African mines (1978)
Organized labor: about 15% of wage earners are
unionized','4ab64436ec27a4943769e94daade261f826e40bee98b86da6376709917e63480','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81a0b41648477bfd19668da511af833bebfee5eccd030a4f42719dc9e6bdf22b',1982,'SE','Sweden','people-and-society',509,'Population: 8,331,000 (July 1982), average annual growth
rate 0.1%
Nationality: noun — Swede(s); adjective — Swedish
Ethnic cfivisions: homogeneous white population; small
Lappish minority; est. 12% foreign born or first generation
immigrants (Finns, Yugoslavs, Danes, Norwegians, Greeks)
Religion: 93.5% Evangelical Lutheran, 1.0% Roman
Catholic, 5.5% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities; immigrants speak native languages
Literacy: 99%
Labor force: 4.2 million; 5.8% agriculture, forestry, fish-
ing; 24.9% mining and manufacturing; 6.8% construction;
13.8% commerce; 6.9% communications; 34.5% services
including government; 6.4% banking and business services;
1.9% unemployed (average 1980)
Organized labor: 80% of labor force','b664918c07b1f774e363c79ba062fb5c7f468aac2331696d5ff55fd6fc8eb2ce','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8867e9ccce5d78728205c8d6d0f604238e65b97acdf5f25b4c86002b7b53658',1982,'CH','Switzerland','people-and-society',511,'Population: 6,407,000 (July 1982), average annual growth
rate -0.3%
Nationality: noun — Swiss (sing. & pi.); adjective — Swiss
Ethnic divisions: total population — 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss nation-
als—74% German, 20% French, 4% Italian, 1% Romansch,
1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals — 74% German, 20% French,
4% Italian, 1% Romansch, 1% other; total population— 69%
German, 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 2.6 million, about one-tenth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.2% unemployed in September 1980
Organized labor: 20% of labor force
Population: 9,423,000 (July 1982), average annual growth
rate 3.4%
Nationality: noun — Syrian(s); adjective — Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion; 74% Sunni Muslim, 16% Alawites, Druze, and
other Muslim sects, 10% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and Eng-
lish widely understood
Literacy: about 40%
Labor force: 2.2 million; 32% agriculture, 29% industry
(including construction), 39% miscellaneous services; major-
ity unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 19,868,000 (July 1982), average annual
growth rate 3.2%
Nationality: noun — Tanzanian(s); adjective — Tanzanian
Ethnic divisions: 99% native Africans consisting of well
over 100 tribes; 1% Asian, European, and Arab
Religion: Mainland— 40% Animist, 30% Christian, 30%
Muslim; Zanzibar — almost all Muslim
Language: Swahili official, English primary language of
commerce, administration and higher education; Swahili
widely understood and generally used for communication
between ethnic groups; first language of most people is one
of the local languages
Literacy: 61%
Labor force: 456,000 in paid employment, over 90% in
agriculture
Organized labor: 15% of labor force','5a98b0b57e4ed2d75a9ad59d01384e182af3d37342be41b7a25ad9b1949ddd15','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e627eb31f4dd3078ee64f7b579f96488c0fa69367aaa57054c4a431ff004cf57',1982,'TO','Tonga','people-and-society',518,'Population: 102,000 (July 1982), average annual growth
rate 2.1%
Nationality: noun — Tongan(s); adjective — Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','db725621c0e2fe24a2ecfbb4f7952dc257d41153570b544b15fbd96dfd8337dd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('524624ddcd1a0bf4e7d858c45acdeeb5cb592c51c78153f35a376be6cf6b786e',1982,'TT','Trinidad and Tobago','people-and-society',523,'Population: 1,203,000 (July 1982), average annual growth
rate 1.5%
Nationality: noun — Trinidadian(s), Tobagan(s); adjec-
tive— Trinidadian, Tobagan
Ethnic divisions: 43% Negro, 40% East Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
Labor force: 393,800 (July 1975), 13.5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications; 23.0% services, 2.9% other
Organized labor: 30% of labor force','41fa0db8f5122db460b8aad2fcf41e235f974f556a32caacf2be9cc23f148cf6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98e6794c8d4be7f1b5a94572ce7dc53c72fcd582ec04fde8ef3d746e8bf820e1',1982,'TN','Tunisia','people-and-society',525,'Population: 6,842,000 (July 1982), average annual growth
rate 2,7%
Nationality: noun — Tunisians); adjective — Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 98% Muslim, 1% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 50%
Labor force: 4 million, 40% agriculture; 15%-25% unem-
ployed; shortage of skilled labor
Organized labor: 25% of labor force; General Union of
Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party
Population: 48,105,000 (July 1982), average annual
growth rate 2.2%
Nationality: noun — Turk(s); adjective — Turkish
Ethnic divisions: 85% Turkish, 12% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 62%
Labor force: 17.14 million; 58% agriculture, 13% indus-
try, 29% service; surplus of unskilled labor (1980)
Organized labor: 10-15% of labor force','cf840069511ddecd8805c02cf7d00d9bcfa3f057c40a25d027d932ff74a550a0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e82594f86d4eedd66e213f66ed39c0dd5410bcbbffc3fb1714bb53b87cb69ee',1982,'WS','Samoa','people-and-society',530,'Population: 9,000 (July 1982), average annual growth rate
1.4%
Nationality; noun — Tuvaluans(s); adjective — Tuvaluan
Ethnic divisions: 96% Polynesian
Religion: Protestant
Literacy: less than 50%','d5c493c5b880d0ecb7bdad3192516790874c23042a58a054dbee1d5f99947bac','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb00a54cc054a88370fd9da83ade3b86189e694babab51a0e40f6444a99f7ceb',1982,'UG','Uganda','people-and-society',533,'Population: 13,651,000 (July 1982), average annual
growth rate 3.2%
Nationality: noun — Ugandan(s); adjective — Ugandan
Ethnic divisions: 99% African, 1% European, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist
Language: English official; Luganda and Swahili widely
used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members','02e551f2901314ba47874edfbcea141b0bb2ed32597bd54ec1587acde36ebe95','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c96ef174cd87d18394edeb972dfe493ec4b4f36cbe2e88506be3ae432db772',1982,'AE','United Arab Emirates','people-and-society',536,'Population: 1,240,000 (July 1982), average annual growth
rate 11.3%
Nationality: Noun — Emirian(s), adjective — Emirian
Ethnic divisions: Emirians 19%, other Arabs 23%, South
Asians 50% (fluctuating), other expatriates (includes West-
erners and East Asians) 8%
Religion: Muslim 96%, Christian, Hindu, and other 4%
Language: Arabic; English widely spoken in major cities
Literacy: 25% est. (1975)
Labor force: 541,000 (1980 est.); 56% services; 80% of
labor force is foreign','30542059ece74151e8b85dcc4af597f28daaf5424e1c0d803d6078e508cc5779','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f98650aac6924836b743f4755bdba75b7a61ec28ac81ad948cf308fed845dbd',1982,'US','United States','people-and-society',540,'Population: 232,195,000 (July 1982), average annual
growth rate 1.0%
Ethnic divisions: 79.7% white, 11.7% black, 6.5% Spanish
origin, 1.5% Asian and Pacific Islander, 0.6% American
Indian, Eskimo, and Aleut (1980)
Religion: total membership in religious bodies,
133,749,000; Protestant 73,704,000, Roman Catholic
49,602,000, Jewish 5,781,000, other religions 4,662,000
(1978)
Language: English, predominantly
Literacy: 99.0% of total population 14 years or older
(1977)
Labor force: 102.9 million (civilian), unemployment 7.6%
(1981)
Organized labor: 20.2% of civilian labor force (1978)
Population: 6,208,000 (July 1982), average annual growth
rate 2.4%
Nationality: noun — Upper Voltan(s); adjective — Upper
-Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are Gur-
unsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active popu-
lation engaged in animal husbandry, subsistence farming,
and related agricultural pursuits; about 30,000 are wage
earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 4 principal trade union groups, repre-
sent less than 1% of population','e9a8a86e191399395892156530655267a8aabaebdc412ad48590bbc441db99c6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b96ad896634f68903b47505a52693c40a9709d397d6d379192a672d8b0c24e3e',1982,'UY','Uruguay','people-and-society',544,'Population: 2,961,000 (July 1982), average annual growth
rate 0.6%
Nationality: noun — Uruguayan(s); adjective — Uruguayan
Ethnic divisions: 85-95% white, 5% Negro, 5-10% mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1.07 million (1975); 19.8% agriculture, 29.0%
industry, 51.2% service
Organized labor: government authorized non-Communist
union activities in 1981 for the first time since 1973 military
takeover','195bda3892dce96b3a8660da4462d4d1a35a6739f94de7d176c85eceb94524e0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bdeb99c1bddf7565441fb427f1dfe1bb7006b153efd27aa6fa97ce4d668e406',1982,'VU','Vanuatu','people-and-society',548,'Population: 123,000 (July 1982), average annual growth
rate 2.7%
Nationality: noun — Vanuatuan(s); adjective — Vanuatuan
Ethnic divisions: 90% indigenous Melanesian, 8% French,
remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%
Population: 1,000 (July 1980), average annual growth rate
0.0%
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divid-
ed into three categories — executives, off ice workers, and
salaried employees
Organized labor: none
Population: 18,427,000 (July 1982), average annual
growth rate 2.8%
Nationality; noun — Venezuelan(s); adjective — Vene-
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 96% nominally Roman Catholic, 2% Protestant
Language: Spanish (official); "Indian" dialects spoken by
about 200,000 aborigines in the interior
Literacy: 74% (claimed, 1970 est.)
Labor force: 4.4 million (1980); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroleum, utilities, and other
Organized labor: 27% of labor force','2b6b2acefb1f44889022525e96b190960854761db05743a732c2ba8e08434987','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ada1765c8dbcc13144f685c0135d32e4cbb8ef232409934dad16e3bb0c0d04bc',1982,'WF','Wallis and Futuna','people-and-society',552,'Population: 11,000 (July 1982) average annual growth rate
3.0%
Nationality: noun — Wallisian(s), Futunan(s), or Wallis and
Futuna Islanders; adjective — Wallisian, Futunan, or Wallis
and Futuna Islander
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','5f0476080e5b0b1de3c33d11c4fa2c48e32ea4499840d58a39fac5af85432166','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72c3037d861e18cd84a903a48f548394c4aa627b4f111b385b6ff794674f9c2d',1982,'EH','Western Sahara','people-and-society',556,'Population: 86,000 (July 1982), average annual growth
rate 1.8%
Nationality: noun — Saharan(s), Moroccan(s); adjective —
Saharan, Moroccan
Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy: among Moroccans, probably nearly 20%; among
Saharans, perhaps 5%
Labor force: 12,000; 50% animal husbandry and subsist-
ence farming, 50% other
Organized labor: none
Population; 158,000 (July 1982), average annual growth
rate 0.7%
Nationality: noun — Western Samoan(s); adjective — West-
ern Samoa
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population associ-
ated with the London Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children
from 7-15 years)
Labor force: 38,200 (1976), 90% in agriculture
Organized labor: unorganized
Population: 2,022,000, excluding the islands of Perim and
Kamaran for which no data are available (July 1982),
average annual growth rate 2.8%
Nationality: noun — Yemeni(s); adjective — Yemeni
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,490,000 (July 1982), average annual growth
rate 2.3%
Nationality: noun — Yemeni(s); adjective — Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 22,689,000 (July 1982), average annual
growth rate 0.8%
Nationality: noun — Yugoslav(s); adjective — Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 6.4% Albanian, 5.8% Macedonian, 2.5% Mon-
tenegrin, 2.3% Hungarian, 4.6% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 9.3 million (1980); 29% agriculture, 27%
mining and manufacturing, 20% noneconomic activities;
estimated unemployment averaged at least 10% of domestic
labor force in 1981
Population: 30,289,000 (July 1982), average annual
growth rate 2.8%
Nationality: noun — Zairian(s); adjective — Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes — Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 60% Christian, 35% animist, 5% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 13% in wage
structure','f933867b087e5816cca8aa784237520fab752105602a17bfa194df0a2841ce8b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e2c7ae07c6eb7a13effdde5b16a0a70eb8a179776fd76c8cf6d71e2ec5f548',1982,'ZM','Zambia','people-and-society',560,'Population: 6,222,000 (July 1982), average annual growth
rate 3.2%
Nationality: noun — Zambian(s); adjective — Zambian
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9% do-
mestic service, 19% construction, 9% commerce, 10% manu-
facturing, 23% government and miscellaneous services, 6%
transport
Organized labor: approximately 238,000 wage earners
are unionized','f9ee33d8ffea724fecc7ed4ef3f399474a37c3edab41488545af6ec931c39df7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c2edad89eb542d600e8f35b9c111b8ee8f2e53f6cc6ae989a6e6f8b5524da06',1982,'ZW','Zimbabwe','people-and-society',565,'Population: 8,090,000 (July 1982), average annual growth
rate 3.5%
Nationality: noun — Zimbabwean(s); adjective — Zim-
babwean
Ethnic divisions: about 97% African (over 70% of which
are members of Shona-speaking subtribes, 20 to 25% speak
Ndebele); about 3% European, less than 0.5% coloreds
(people of mixed heritage) and Asians
Religion: 51% syncretic (part Christian, part animist), 24%
Christian, 24% animist, a few Muslim
Language: English official; Shona and Ndebele also wide-
ly used
Literacy: 25-30% of blacks; nearly 100% of whites
Labor force: (1981) 1,048,000 total; 35% agriculture, 25%
mining, manufacturing, construction, 40% transport and
services
Organized labor: about one-third of European wage
earners are unionized, but only a small minority of Africans','b97007fac0e76f738791dc920e7be372f51826c0940852c7340e9bf5c4d738a4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

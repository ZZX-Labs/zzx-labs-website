SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae2ea31028e4d38a3c79d6bbe52ba0d14b882040a83d6cb90c132307a9a062ce',1982,'AF','Afghanistan','communications',7,'Railroads: 9.6 km (single track) 1.524-meter gauge, gov-
ernment-owned spur of Soviet line
1','9fff67601dece8d7b6cdd65bf6a9cf4e8ddb2d1a104f271f6acd09812b620d80','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e84557cc64e7b4d4bf411c67bc7fe99af75ad1f8ab4093399d7da1868d8c5b2d',1982,'AL','Albania','communications',8,'AFGHANISTAN (Continued)
Highways: 21,000 km total (1981); 3,000 km paved, 2,100
km gravel, 8,900 km improved earth, and 7,000 km unim-
proved earth
Inland waterways: total navigability 1,070 km; steamers
up to about 500 metric tons use sections of Amu Darya
Ports: 3 minor river ports; largest Sher Khan
Civil air: 6 major transport aircraft
Airfields: 37 total, 36 usable; 10 with permanent-surface
runways; 8 with runways 2,440-3,659 m, 12 with runways
1,220-2,439 m
Telecommunications: limited telephone, telegraph, and
radiobroadcast services; television introduced in 1980; tele-
phones (0.2 per 100 popl.); 5 AM and no FM stations, 1 TV
station, 1 earth satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 3,602,000;
1,998,000 fit for military service; about 146,000 reach
military age (22) annually
Supply: dependent on foreign sources, almost exclusively
the USSR
Military budget: estimated expenditures for fiscal year
ending 31 March 1979, about $63.8 million; approximately
12% of central government budget
(See reference map V)
LAND
28,749 km2; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 716 km
WATER
Limits of territorial waters (claimed): 15 nm
Coastline: 418 km (including Sazan Island)
Railroads: 277 km standard gauge (1.435 m), single track,
government owned (1975)
Highways: 4,989 km total; 1,287 km paved, 1,609 km
crushed stone and /or gravel, 2,093 km improved or unim-
proved earth (1975)
Inland waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1979)
Freight carried: rail — 2.8 million metric tons, 180 million
metric ton/km (1971); highways — 39 million metric tons,
900 million metric ton/km (1971)
Ports: 1 major (Durres), 3 minor (1979)
Pipelines: crude oil, 117 km; refined products, 65 km;
natural gas, 64 km
Civil air: no civil airline
DEFENSE FORCES
Military manpower: males 15-49, 721,000; 597,000 fit for
military service; 31,000 reach military age (19) annually
Ships: 4 submarine, 2 mine warfare ships, 54 coastal
patrol-river/roadstead craft, 6 mine warfare craft, 2 under-
way replenishment ships, 1 other auxiliary
Military budget announced: for fiscal year ending 31
December 1981, 940 million leks; 11.5% of total budget
3','8b17c043f11a3db0cc608a1a1b3d0f97600e21073424586eaaa5e2cecbb5b937','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1fe42686ec1b6a9ba294621543ea0dd6a797ec8fb4671c1dd6c761c82d6ee0f',1982,'DZ','Algeria','communications',12,'(See reference map VII)
LAND
2,460,500 km2; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 6,260 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,183 km
WESTERN 1
SAHARA j
Atiatttlt
I MAURITANIA I
Ocean
INouikchott t
MAU
N^msAtY
(See reference map VII)
LAND
1,085,210 km2; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 5,118 km
WATER
Limits of territorial waters (claimed): 70 nm (fishing, 200
nm; exclusive economic zone 200 nm)
Coastline: 754 km
Railroads: 650 km standard gauge (1.435 m), single track,
privately owned
154','1b0d42f1925c35c9a0868442e0b001f4c3b48a198b8d689dfd5b905f63370c4c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3045342c9467549045678e583989b141b3ebe7dc33b627ce6652ec385d3fb18c',1982,'AD','Andorra','communications',16,'Railroads: 3,950 km total; 2,690 km standard gauge (L435
m), 1,140 km 1.055-meter gauge, 120 km meter gauge (1.000
m); 302 km electrified; 193 km double track
Highways: 78,410 km total; 45,070 km concrete or bitu-
minous, 33,340 km gravel, crushed stone, unimproved earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 6,612 km; refined products, 298 km;
natural gas, 2,398 km
Civil air: 35 major transport aircraft, including 4 leased in
Airfields: 185 total, 172 usable; 52 with permanent-
surface runways; 27 with runways 2,440-3,659 m; 85 with
runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 4,159,000; 2,568,000 fit
for military service; 218,000 reach military age (19) annually
Military budget: for fiscal year ending 31 December
1981, $1,779 million; 11% of central government budget
At/antic
Ocean
Y FRANCE ]
/ 4°
J Mttfiteaanedit
f Sea
■■■■■■ .j*"^
(See reference map V)
LAND
466 km*
Land boundaries: 105 km','fc6bdc0ab2e8dba865edeb3cc9ab6c3d332416c380c4666918800b806b9e4914','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('307fc3cb64c830c0a6c136d899ece9262b68463263beaaf6637bcaf6856c1ab9',1982,'AO','Angola','communications',21,'Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international landline circuits to
Spain and France; 2 AM stations, 1 FM station, and 1 TV
station; about 11,720 telephones (39.0 per 100 popl.)
DEFENSE FORCES
Andorra has no defense forces; Spain and France are
responsible for protection as needed
n i" — -py — t~ —
ZAIRE
Cibiodatp-Lv
Luanda)*
) ANGOLA ^Jh^4i /(H"
/ /
j MM8IA£*4S
\\namibia} \\ / \\
Atlantic
Ocean
(See reference mep Vtl)
LAND
1,245,790 km1; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 5,070 km
WATER
Limits of territorial waters (claimed): 20 nm (fishing 200
nm)
Coastline: 1,600 km
Railroads: 3,189 km total; 2,879 km 1.067-meter gauge,
310 km 0.600-meter gauge
Highways: 73,828 km total; 8,577 km bituminous-surface
treatment, 28,723 km crushed stone, gravel, or improved
earth, remainder unimproved earth
Inland waterways: 1,165 km navigable
Ports: 3 major (Luanda, Lobito, Mocamedes), 5 minor
Pipelines: crude oil, 179 km
Civil air: 26 major transport aircraft
Airfields: 389 total, 367 usable; 27 with permanent-
surface runways; 1 with runways over 3,660 m, 9 with
runways 2,440-3,659 m, 100 with runways 1,220-2,439 m
Telecommunications: fair system of wire and radio relay;
troposcatter/radio-relay system under construction; HF used
extensively for military/Cuban links; 1 Atlantic Ocean
satellite station; 29,100 telephones (0.5 per 100 popl); 15 AM
and 5 FM stations; 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,536,000; 773,000 fit
for military service; 62,000 reach military age (20) annually
7','a67fee55848fc8ada97a12ae809bdc7a3978858b17cc3d4e1a1a87e553d2b399','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d550d5764d17f3a4b3fd04b51690a35f031c122d86fa4a3f39e0215bb06858b',1982,'AG','Antigua and Barbuda','communications',23,'OOMINICAN At/antic
— ^REPUBLIC PUERT0 Ocean
ANO * #
BARBUDA %
Caribbean Sea
«
> Q vs
>
VENEZUELA
CSae reference map III)
LAND
280 km2; 54% arable, 5% pasture, 14% forested, 9% unused
but potentially productive, 18% wasteland and built on; the
islands of Redonda (less than 2.6 km2 and uninhabited) and
Barbuda (161 km*) are dependencies
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 153 km
Railroads: 78 km narrow gauge (0.760 m), employed
almost exclusively for handling cane
Highways: 380 km total; 240 km main, 140 km secondary
Ports: 1 major (St. Johns), 1 minor
Civil air: 10 major transport aircraft, including 2 leased in
Airfields: 3 total, 2 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m
Telecommunications: automatic telephone system; 4,000
telephones (5.4 per 100 popl); tropospheric scatter links with
Tortola and St. Lucia; 3 AM, 2 FM, and 2 TV stations; 1
coaxial submarine cable','98e76aeeb0387e5f7559a7d244a4a0bc6910bc58635d74b6e087c624d3a2a288','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('899f189221d58adf2b81b109eafaaf02f57ea3c5b6e4b0a097df451a16a024ef',1982,'AR','Argentina','communications',27,'\\ BOUVIA f^~S ''
Pacific l
Ocean $*■
ARGENTINA X. //
milt
r Bu nos Aires *^s^/
M
* f
Atlantic Ocean
1 f ^ FALKLAND ISLANDS
(See reference mep IV)
2,771,300 km1; 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25% forested,
18% mountain, urban, or waste
Land boundaries: 9,414 km
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf, including sovereignty over superjacent waters)
Coastline: 4,989 km
CHilH
Atlantic
Ocean
FALKLAND
^PlSLANDS
(See reference map IV)
LAND
Colony — 12,168 km2; area consists of some 200 small
islands and two principal islands, East Falkland (6,680 km2)
and West Falkland (5,276 km2); dependencies — South Sand-
wich Islands, South Georgia, and the Shag and Clerke Rocks
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 1,288 km','edd1a4ee0d31c1b726cc74681848c1d22a0a70157f138beb48e2ce37c3dd1b7c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('104d3bc1c20c2f075a926b3019774b48f39024e4d3ce66b1ce34edf081a8a359',1982,'AU','Australia','communications',32,'Railroads: 39,738 km total; 3,086 km standard gauge
(1.435 m), 22,788 km broad gauge (1.676 m), 13,461 km
meter gauge (1.000 m), 403 km 0.750-meter gauge; of total in
country, 260 km are electrified
Highways: 208,100 km total, of which 47,550 km paved,
39,500 km gravel, 101,000 km improved earth, 20,300 km
unimproved earth
Inland waterways: 11,000 km navigable
Ports: 7 major, 21 minor
Pipelines: 4,090 km crude oil; 2,200 km refined products;
8,172 km natural gas
Civil air: 67 major transport aircraft including 2 leased in
Airfields: 2,446 total, 2,147 usable; 108 with permanent-
surface runways; 24 with runways 2,440-3,659 m, 311 with
runways 1,220-2,439 m
Telecommunications: extensive modern system; tele-
phone network has 2.76 million sets (10.3 per 100 popl.),
radio relay widely used; 1 satellite station with 2 Atlantic
Ocean antennas; 160 AM, 12 FM, and 74 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 7,040,000; 5,715,000 fit
for military service; 236,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31
December 1981, $3,426,600; about 16.6% of total central
government budget
(See reference map X)
LAND
7,692,300 km*; 6% arable, 58% pasture, 2% forested, 34%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing
200 nm; prawn and crayfish on continental shelf)
Coastline: about 25,760 km
Railroads: 42,855 km total (1980); 9,689 km 1.60-meter
gauge, 15,783 km standard gauge (1.435 m), 17,383 km
1.067-meter gauge; 800 km electrified (June 1962); govern-
ment owned (except for few hundred kilometers of privately
owned track)
Highways: 837,872 km total (1980); 207,650 km paved,
205,454 km gravel, crushed stone, or stabilized soil surface,
424,768 km unimproved earth
Inland waterways: 8,368 km; mainly by small, shallow-
draft craft
Ports: 12 major, numerous minor
Pipelines: crude oil, 740 km; refined products, 340 km;
natural gas, 6,947 km
Civil air: around 150 major transport aircraft
Airfields: 1,584 total, 1,526 usable; 207 with permanent-
surface runways, 2 with runways over 3,660 m; 16 with
runways 2,440-3,659 m, 570 with runways 1,220-2,439 m
Telecommunications: very good international and do-
mestic service; 7.4 million telephones (52 per 100 popl.); 223
AM, 5 FM, and 111 TV stations; 3 earth satellite stations;
submarine cables to New Zealand, New Guinea, Singapore,
Malaysia, Hong Kong, and Guam
DEFENSE FORCES
Military manpower: males 15-49, 3,907,000; 3,334,000 fit
for military service; 131,000 reach military age (17) annually
Military budget: for fiscal year ending 30 June 1982, $4.7
billion; about 10.1% of total central government budget
11
(See reference m»p X)
LAND
18,272 km1; consists of more than 300 islands and many
more coral atolls and cays; the larger islands, Viti Levu,
Taveuni, and Kadavu are all mountainous and volcanic in
origin, with peaks rising over 1,210 meters; landownership—
83.6% Fijians, 1.7% Indians, 6.4% government, 7.2% Europe-
an, 1.1% other; about 30% of land area is suitable for
farming
WATER
Limits of territorial waters (claimed): (economic zone
200 nm)
Coastline: 1,129 km
Railroads: 644 km narrow gauge (0.610 m); owned by Fiji
Sugar Corp., Ltd.
Highways: 2,960 km total (1981); 390 km paved, 2,150
km gravel, crushed stone, or stabilized soil surface; 420
unimproved earth
Inland waterways: 203 km; 122 km navigable by motor-
ized craft and 200-metric ton barges
Ports: 1 major, 6 minor
Civil air: 1 DC-3 and 1 light aircraft
Airfields: 15 total, 15 usable; 2 with permanent-surface
runways, 1 with runways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: modern local, interisland, and in-
ternational (wire/radio integrated) public and special-
purpose telephone, telegraph, and teleprinter facilities; re-
gional radio center; important COMPAC cable link between
US/Canada and New Zealand/Australia, et al; 37,515 tele-
phones (6.0 per 100 popl.); 7 AM and 2 FM stations; no TV
stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 169,000; 95,000 fit for
military service; 7,000 reach military age (18) annually
Military budget: the defense of the Fiji Islands was the
responsibility of the UK until 10 October 1970; military
budget for 1979, $11.1 million; 4% of central government
budget
71','1d6bc563a1c4dd6de537d823295b92d5b7f1b25536b7fce1e4f03869c0714dc5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e687fdd58268e64c731ec9263ed45c444172d46f08eb93c341e93d389df4a8d',1982,'AT','Austria','communications',35,'(See reference map V)
LAND
83,916 km*; 20% cultivated, 26% meadows and pastures,
15% waste or urban, 38% forested, 1% inland water
Land boundaries: 2,582 km
Railroads: 6,517 km total; 5.877 km government owned;
5,397 km standard gauge (1.435 m) of which 2,730 km
electrified and 1,333 km double tracked; 480 km narrow
gauge (0.760 m) of which 91 km electrified; 640 km
privately owned (1.435- and 1.000-meter gauge)
Highways: approximately 33,600 km total national classi-
fied network, including 10,400 km federal and 23,200 km
provincial roads; about 20,800 km paved (bituminous, con-
crete, stone block) and 12,800 km unpaved (gravel, crushed
stone, stabilized soil); additional 60,800 km communal roads
(mostly gravel, crushed stone, earth) and 1,012 km autobahn
Inland waterways: 427 km
Ports: 2 major river (Vienna, Linz)
Pipelines: 554 km crude oil; 2,611 km natural gas; 171 km
refined products
Civil air: 25 major transport aircraft, including 1 leased in
Airfields: 55 total, 53 usable; 16 with permanent-surface
runways; 5 with runways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: highly developed and efficient;
extensive TV and radiobroadcast systems with 160 AM, 450
FM, and 780 TV stations; 1 Atlantic Ocean INTELSAT
station; 2.81 million telephones (37.5 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 1,878,000; 1,590,000 fit
for military service; 65,000 reach military age (19) annually
Military budget: for fiscal year ending 31 December
1982, $782 million; about 3.6% of the proposed federal
budget
1
Caribbean Sea REPUBLIC
(See reference map III)
LAND
11,396 km2; 1% cultivated, 29% forested, 70% built on,
wasteland, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 3,542 km (New Providence Island, 76 km)','48442f61c8f4985a99d8d152d21fb3c9b6ed17247fd27bd235e49d1b3f265ff2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3292a044acf153af6bd265b30977ad4530deae3ebb2e934846adcf32bba28d3',1982,'BH','Bahrain','communications',41,'Railroads: none
Highways: 3,350 km total; 1,350 km paved, 2,000 km
gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 8 major transport aircraft, including 1 leased in
Airfields: 55 total, 51 usable; 27 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 22 with runways
1,220-2,439 m
Telecommunications: telecom facilities highly developed,
including 62,000 telephones (28 per 100 popl.) in totally
automatic system; tropospheric scatter link with Florida; 3
AM stations, 2 FM stations and 1 TV station; 3 coaxial
submarine cables
(See reference mep VI)
LAND
596 km1 plus group of 32 smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste, or urban
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km','6a8ec1cb445d6fa4ad493c681af8e4c448eb164cbbe83769b6df323b80f62cc4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('835a83d578e17ea15f181b1c2c7d8b9e28f68fdf7db92c0c2c246111ba9fb2e8',1982,'BD','Bangladesh','communications',45,'Highways: 93 km bituminous surfaced; undetermined
mileage of natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 56 km; refined products, 16 km;
natural gas, 32 km
Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runways over 3,660 m; 1 with runways
1,220-2,439 m
Telecommunications: excellent international telecom-
munications; limited domestic services; 38,300 telephones
(14.2 per 100 popl.); 2 AM stations, 1 FM station, and 1 TV
station; 1 Indian Ocean satellite station; tropospheric scatter
and microwave to Qatar and United Arab Emirates
DEFENSE FORCES
Military manpower: males 15-49, 106,000; 61,000 fit for
military service
Supply: from several West European countries, especially
France and UK
Military budget: for fiscal year ending 31 December
1979, $87.8 million; 11% of central government budget','2af7077d96a6b97ec9478c8924a4f51fb2aa09146f1568b4b97a38eca72c50ad','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67eb7dbfdc79cf70a12a1b4c2c1ac1d23b5e2dd722566dcc607291459b002206',1982,'CN','China','communications',46,'(See reference map VIII)
LAND
142,500 km2; 66% arable (including cultivated and fallow),
18% not available for cultivation, 16% forested
Land boundaries: 2,535 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 580 km
Railroads: 4,085 km total (1980); 2,198 km meter gauge
(1.000 m),l,852 km broad gauge (1.676 m), 35 km narrow
gauge (0.762 m), 300 km double track; government owned
Highways: 45,633 km total; 4,076 km paved, 2,693 km
gravel, 38,864 km earth
Inland waterways: 7,000 km; river steamers navigate
main waterways
Ports: 1 major (Chittagong), 2 minor
Pipelines: 854 km natural gas
Civil air: 9 major transport aircraft
Airfields: 23 total, 15 usable; 17 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 7 with runways
1,220-2,439 m
Telecommunications: adequate international radio-
communications and landline service; fair domestic wire and
microwave service; fair broadcast service; 100,000 (est.)
telephones (0.1 per 100 popl.); 9 AM, 6 FM, 7 TV stations,
and 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 21,456,000; 11,190,000
fit for military service
Military budget: for fiscal year ending 30 June 1982, $1.7
billion; about 10.8% of central government budget
16
(See reference map VIII)
LAND
9.6 million km*; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of this area
consists largely of denuded wasteland, plains, rolling hills,
and basins from which about 3% could be reclaimed), 8%
forested; 2%-3% inland water
Land boundaries: 24,000 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 14,500 km
MACAU/
HONG
KONG
South
Sea
( See reference mep VIII)
LAND
15.5 km2; 10% agricultural, 90% urban
Land boundaries: 201 m
WATER
Limits of territorial waters (claimed): 6 nm; fishing, 12
nm
Coastline: 40 km
Highways: 42 km paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern communication fa-
cilities maintained for domestic and international services;
13,000 telephones; 4 AM and 3 FM radio broadcast transmit-
ters; est. 75,000 radio receivers; international HF radio
communication facility; access to international communica-
tions carriers provided via Hong Kong and China
DEFENSE FORCES
Military manpower: males 15-49, 76,000; 45,000 fit for
military service
Defense is responsibility of Portugal
Personnel: there are no Portuguese military personnel in
Macau
141
^AFGHANISTAN f £
IRAN J f lsl*
"bo
i
\\. V^PAKISTAN/
f J IA0S /
r?
| \\ THAILAND L S
V A*
VIETNAM
ih y ^ mH^^
fSee reference map IX)
LAND
329,707 km2; 14% cultivated, 50% forested, 36% urban
inland water, and other
Land boundaries: 4,562 km
WATER
Limits of territorial waters (claimed): 12 nm plus 12 nm
contiguous customs and security zone (fishing 200 nm,
economic 200 nm)
Coastline: 3,444 km (excluding islands)
Railroads: 2,587 km total; 2,227 meter gauge, 130 km
standard gauge, 230 km dual gauge
252
0-
Taip«t
TAIWAN
South China
Sea','85047eae67c0efc301bf1c57fb647b28be774986b5fa74d672a8b480faf50a0d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00f1f456776ac5a993f7c81ae2605b0067efbea764e98038453cfbecbb41d5cb',1982,'BB','Barbados','communications',50,'DOMINICAN
h \\>^REPUBUC Atfo t''
v PUERTO* N *
RICO
Caribbean Sea \\
(See reference map III)
LAND
430 km8; 60% cropped, 10% permanent meadows, 30%
unused, built on, or wasteland
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 97 km
Railroads: none
Highways: 1,546 km total; 1,450 km paved, and 96 km
gravel, and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 3 major transport aircraft (including 1 leased in)
Airfields: 1 with permanent-surface runways 2,440-3,659 m
Telecommunications: islandwide automatic telephone
system with 47,000 telephones (17.2 per 100 popl.); tropo-
spheric scatter link to Trinidad; UHF/VHF links to St.
Vincent and St. Lucia; 2 AM stations, 1 FM station, and 1
TV station; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 64,000; 45,000 fit for
military service; no conscription
17','e2cf53f3fa0378b98b32e126600c388a5fd9d0f92d9512bbb706d8fe9249e365','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d781aecde71711ab3bf340c5740ef6ebc7bdf09908918f72338168aae7ffc0ef',1982,'BE','Belgium','communications',54,'(See reference mep V)
LAND
30,562 km2; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 1,377 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 64 km
Railroads: 4,171 km total; 3,971 km standard gauge
(L435 m) and government-owned, 2,536 km double track,
1,413 km electrified; 200 km government-owned, electrified
meter gauge (1.000 m)
Highways: 104,663 km total; 1,102 km paved, limited
access, divided autoroute; 51,780 km other paved; 51,781 km
unpaved
Inland waterways: 2,043 km, of which 1,528 km are in
regular use by commercial transport
Ports: 5 major, 1 minor
Pipelines: refined products, 1,115 km; crude, 161 km;
natural gas, 3,218 km
Civil air: 49 major transport aircraft, including 4 leased in
and 5 leased out
Airfields: 47 total, 46 usable; 25 with permanent-surface
runways; 14 with runways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: excellent domestic and interna-
tional telephone and telegraph facilities; 3.45 million tele-
phones (35.0 per 100 popl.); 6 AM, 31 FM, and 31 TV
stations; 5 coaxial submarine cables; 1 Atlantic Ocean IN-
TELSAT station
DEFENSE FORCES
Military manpower: males 15-49, 2,478,000; 2,096,000 fit
for military service; 79,000 reach military age (19) annually','e5d3523b74d19192e794c8bc244a55f690742e2d954390b74a5e10fcc83c1a10','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc735a2b298a810a62c4d93868585586268b33b8632228c41468dc2af4f2986c',1982,'BZ','Belize','communications',58,'(formerly British Honduras)
Guff of ^
Mexico |
. f Caribbean
Sea
MEXIC0
Pacific
Ocean
(See reference mep HI)
LAND
22,973 km2; 38% agricultural (5% cultivated), 46% exploit-
able forest, 16% urban, waste, water, offshore islands or
other
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 386 km
Railroads: none
Highways: 2,575 km total; 340 km paved, 1,190 km
gravel, 735 km improved earth and 310 km unimproved
earth
Inland waterways: 800 km river network used by
shallow-draft craft
Ports: 1 major (Belize), 4 minor
Civil air: 1 major transport aircraft, leased in
Airfields: 37 total, 28 usable; 4 with permanent-surface
runways; 1 with runways 1,220-2,439 m
Telecommunications: 5,800 telephones in automatic and
manual network (2.7 per 100 pop!.); radio-relay system; 6
AM stations and 1 FM station; 1 Atlantic Ocean INTELSAT
station
DEFENSE FORCES
Military manpower: males 15-49, 35,000; 21,000 fit for
military service; 1,600 reach military age (18) annually
20','3bb84ef23b7135051077030ff3cc5ca7b931a794a5a7b48774dc7e7ee736ad38','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17a491cf934b45bab3efcc58b6200d5ded1a71bd99ff6a96ccfe49deb9fe4125',1982,'BJ','Benin','communications',62,'(formerly Dahomey)
^. tsbfn f
f mhm I ] 1
\\ Porto
Bulf of Guinea
(See reference map VII)
LAND
115,773 km2; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and game
preserves 19%, nonarable 1%
Land boundaries: 1,963 km
WATER
Limits of territorial waters (claimed): 200 nm (100 nm
mineral exploitation limit)
Coastline: 121 km
Railroads: 579 km, all meter gauge (1.00 m)
21
BENIN (Continued)
Highways: 3,303 km total; 705 km paved, 2,598 km
improved earth
Inland waterways: small sections, only important locally
Ports: 1 major (Cotonou), 1 minor
Civil air: 3 major transport aircraft
Airfields: 9 total, 9 usable; 1 with permanent-surface
runways; 4 with runways 1,220-2,439 m
Telecommunications: fair system of open wire and radio
relay; 16,200 telephones (0.5 per 100 pop].); 2 AM stations, 1
FM station, and 1 TV station
DEFENSE FORCES
Military manpower: eligible 15-49, 1,579,000; of the
778,000 males 15-49, 393,000 are fit for military service;
about 37,000 males and 38,000 females reach military age
(18) annually; both sexes are liable for military service','6e7610a834469d27cd62b47180ffe6c1f4f7f6e47da2e3ca2aa6837053e71eaf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6c1638fcea6432a1f9724eebbe3ef86559b7dffedb1650b126a527440c2ba93',1982,'BM','Bermuda','communications',66,'1 unmu W
STATES i
Atlantic
OCBSfl
•
1 A i
(See reference map II)
LAND
54.4 km*; 8% arable, 60% forested, 21% built on, waste-
land, and other, 11% leased for air and naval bases
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 103 km','3752df085e99dc1087c13c96cf7e006e449d6f3a2f5162d0c3d72bd869116572','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e89e631f4e9c7f810d0915e897e0d50db806de66a2048c63bca48b2220bbf996',1982,'BT','Bhutan','communications',71,'Railroads: none
Highways: 190 km, all paved
Ports: 3 major (Hamilton, St. George Freeport, Ireland
Island)
Civil air: 4 major transport aircraft
Airfields: 1 with permanent-surface runways 2,440-3,659
m
Telecommunications: modern telecom system, includes
fully automatic telephone system with 39,500 sets (63.7 per
100 pop].); 3 AM, 1 FM, and 2 TV stations; 3 coaxial
submarine cables; 1 Atlantic Ocean satellite station
CHIIS3
A','331c3ae9ba9121a37d7a6bc88b54186282dab53371e4eb1167b955f2dafa559b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bfbf04980240a8360ccdd061566f0a66394dc84d5462ce31f40ed06a53f2b80',1982,'IN','India','communications',72,'| BANStfff
Bay of
Bengal
BURMA
r
(See reference map VIII)
LAND
46,600 km2; 15% agricultural, 15% desert, waste, urban,
70% forested
Land boundaries: about 870 km
Highways: 1,304 km total; 418 km surfaced, 515 km
improved, 371 km unimproved earth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
Airfields: 2 total; 2 usable; 1 with runways 1,220-2,439 m
Telecommunications: facilities inadequate; 1,300 tele-
phones (0.1 per 100 popl.); 6,000 est. radio sets; no TV sets; 1
AM station and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 332,000; 178,000 fit for
military service; about 16,000 reach military age (18)
annually
Supply: dependent on India
8RAZ&
La Paz I
*bolivia\\
[Sucre
Pacific
Ocean J
(See reference map fV)
LAND
1,098,160 km1; 2% cultivated and fallow, 11% pasture and
meadow, 45% urban, desert, waste, or other, 40% forest, 2%
inland water
Land boundaries: 6,083 km
Railroads: 3,651 km total; 3,514 km meter gauge (1.000
m) and 32 km 0.760-meter gauge, all government owned,
single track; 105 km meter gauge (1.000 m) privately owned
Highways: 39,650 km total; 1,400 km paved, 7,880 km
gravel, 6,800 km improved earth, 23,650 km unimproved
earth
Inland waterways: officially estimated to be 10,000 km
of commercially navigable waterways
Pipelines: crude oil, 1,670 km; refined products, 1,495
km; natural gas, 580 km
Ports: none (Bolivian cargo moved through Arica and
Antofagasta, Chile, and Matarani, Peru)
Civil air: 57 major transport aircraft
Airfields: 583 total, 535 usable; 6 with permanent-surface
runways; 1 with runways over 3,659 m, 7 with runways
2,440-3,659 m, 127 with runways 1,220-2,439 m
Telecommunications: radio-relay system from La Paz to
Santa Cruz; improved international services; 125,300 tele-
phones (2.0 per 100 popl.); 135 AM, 19 FM, and 32 TV
stations; 1 Atlantic Ocean INTELSAT station
DEFENSE FORCES
Military manpower: males 15-49, 1,241,000; 812,000 fit
for military service; 56,000 reach military age (19) annually
Military budget: proposed for fiscal year ending 31
December 1981, $177.7 million; 15.9% of central govern-
ment budget
25
(See reference map VIII)
LAND
3,136,500 km2 (includes Indian part of Jammu-Kashmir,
Sikkim, Goa, Damao and Diu); 50% arable, 5% permanent
meadows and pastures, 20% desert, waste, or urban, 22%
forested, 3% inland water
Land boundaries: 12,700 km*
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; additional 100 nm is fisheries conservation zone, De-
cember 1968; archipelago concept baselines); 200 nm exclu-
sive economic zone
Coastline: 7,000 km (includes offshore islands)
> jT Arabian Sea
; s
(See reference map VIII)
LAND
803,000 km2 (includes Pakistani part of Jammu-Kashmir);
40% arable, including 24% cultivated; 23% unsuitable for
cultivation; 34% unreported, probably mostly waste; 3%
forested
Land boundaries: 5,900 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 1,046 km
Railroads: 8,815 km total (1981); 535 km meter gauge
(1.000 m), 7,670 km broad gauge (1.676 m), 610 km narrow
gauge (0.762 m); 1,022 km double track; 286 km electrified;
government owned
Highways: 80,500 km total (1981); 23,500 km paved,
23,000 km gravel, 3,100 km improved earth, 30,900 km
unimproved earth
Inland waterways: negligible
Pipelines: 230 km crude oil; 1,600 km natural gas
Ports: 2 major, 4 minor
Civil air: 27 major transport aircraft
Airfields: 111 total, 92 usable; 69 with permanent-surface
runways; 1 with runways over 3,659 m, 27 with runways
2,440-3,659 m, 41 with runways 1,200-2,439 m
Telecommunications: good international radiocommuni-
cation service over microwave and INTELSAT satellite;
domestic radiocommunications poor; broadcast service good;
314,000 telephones (0.3 per 100 popl.); 27 AM, no FM, 16
TV stations; 1 ground satellite station
DEFENSE
Military manpower: males 15-49, 21,754,000; 14,795,000
fit for military service; 1,108,000 reach military age (17)
annually
Military budget: for fiscal year ending 30 June 1982,
$1.77 billion; about 27% of central government budget
181','3db7e05a462b97053fef0bd0443ef5813320bb04448610bf12f2ff7bf0c61b49','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f9d9294fd4460d8d4e4fe0f86d529eba357099c2e5d20c4f0f60c9336813e4f',1982,'BW','Botswana','communications',76,'(See reference mep VII)
LAND
569,800 km2; about 6% arable, less than 1% under cultiva-
tion, mostly desert
Land boundaries: 3,774 km','efd946131dd8c4de0639bd4b8fdbb02ca5c6640fc0ee3de7d7fa0dd461bc34d1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d294fd0502ef2b1181d093bfc52ec66dc926a61a451acbc93e86ad75d56f856',1982,'BR','Brazil','communications',81,'Railroads: 726 km 1.067-meter gauge
Highways: 10,784 km total; 1,105 km paved; 1,465 km
crushed stone or gravel; 5,177 km improved earth and 3,037
km unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 5 major transport aircraft, including 1 leased in
Airfields: 78 total, 67 usable; 3 with permanent-surface
runways; 13 with runways 1,220-2,439 m
Telecommunications: the small system is a combination
of open-wire lines, radio-relay links, and a few radiocom-
munication stations; 11,700 telephones (1.5 per 100 popl.); 5
AM, 1 FM, and 2 TV stations; INTELSAT satellite ground
station
DEFENSE FORCES
Military manpower: males 15-49, 177,000; 94,000 fit for
military service; 9,000 reach military age (18) annually
Military budget: for fiscal year ending 31 March 1982,
$28.7 million; 4.6% of central government budget
At/antic
Ocean
BRAZIL J
Brasilia f
soiiviaS
/) m4
(See reference map IV)
LAND
8,521,100 km*; 4% cultivated, 13% pasture, 23% built-on
area, waste, and other, 60% forested
Land boundaries: 13,076 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 7,491 km
Railroads: 24,600 km total; 22,450 km meter gauge (1.000
m), 1,750 km 1.60-meter gauge, 200 km standard gauge
(1.435 m), 200 km 0.76-meter gauge; 1,050 km electrified
Highways: 1,385,600 km total; 83,700 km paved,
1,301,900 km gravel or earth
Inland waterways: 50,000 km navigable
Ports: 8 major, 23 significant minor
Pipelines: crude oil, 2,000 km; refined products, 465 km;
natural gas, 257 km
Civil air: 169 major transport aircraft, including 9 leased
in
Airfields: 4,464 total, 3,633 usable; 220 with permanent-
surface runways; 1 with runways over 3,659 m; 17 with
runways 2,440-3,659 m, 412 with runways 1,220-2,439 m
Telecommunications: fair telecom system; good radio
relay facilities; 1 Atlantic Ocean INTELSAT station with 2
antennas; 10 domestic satellite stations; 6.49 million tele-
phones (5.1 per 100 popl.); 1,100 AM, 150 FM, and 170 TV
stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 31,263,000; 21,155,000
fit for military service; 1,393,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1981, $1,757.5 million; 7.8% of central government budget
28
BRUNEI
VIETNAM
PHILIPPINES^)*/
South China Sea
(See reference map IX)
LAND
5,776 km*; 3% cultivated; 22% industry, waste, urban or
other; 75% forested
Land boundaries: 381 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Railroads: 13 km narrow gauge (0.610 m) private line
Highways: 1,090 km total; 370 km paved (bituminous
treated), with another 52 km under construction, 720 km
gravel or unimproved
Inland waterways: 209 km; navigable by craft drawing
less than 1.2 meters
Ports: 1 major (Muara), 4 minor
Pipelines: crude oil, 135 km; refined products, 56 km;
natural gas, 56 km; crude oil and natural gas, 241 km under
construction
Civil air: 4 major transport aircraft
Airfields: 3 total, 2 usable; 1 with permanent-surface
runways; 1 with runways over 3,659 m; 1 with runways
1,220-2,439 m
Telecommunications: service throughout country is ade-
quate for present needs; international service good to adja-
cent Sabah and Sarawak; radiobroadcast coverage good;
15,672 telephones (8.8 per 100 popl.); Radio Brunei broad-
casts from 6 AM/FM stations and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 62,000; 36,000 fit for
military service; about 2,600 reach military age (18) annually
29','269d8288fbd42d9ed42db3c756c2239a80ea8221d43aa722a0f911a1faddf428','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f50aeb920cebe3e961f2349d72aae42719f65a2c1913e529df2073763773409',1982,'BG','Bulgaria','communications',84,'(See reference map V)
LAND
111,852 km*; 41% arable, 11% other agricultural, 33%
forested, 15% other
Land boundaries: 1,883 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 354 km
Railroads: 4,341 km total; about 4,096 km standard gauge
(1.435 m), 245 km narrow gauge; 437 km double track; 1,449
km electrified; government owned (1979)
Highways: 32,236 km total; 2,360 km trunk roads, 4,291
km class I concrete, asphalt, stone block; 6,062 km class II
asphalt treated, gravel, crushed stone; 19,523 km class 111
earth (1979)
Inland waterways: 471 km (1979)
Freight carried: rail — 77.6 million metric tons, 17.6 bil-
lion metric ton/km (1979); highway — 836 million metric
tons, 15.6 billion metric ton/km (1979); waterway — 4.9
million metric tons, 2.6 billion metric ton/km (excluding
international transit traffic; 1979)
Ports: 3 major (Varna, Varna West, Burgas), 6 minor
(1981); principal river ports are Ruse and Lorn (1981)
DEFENSE FORCES
Military manpower: males 15-49, 2,173,000; 1,818,000 fit
for military service; 63,000 reach military age (19) annually
Military budget: for fiscal year ending 31 December
1981, est. 900 million leva; 5.9% of total budget
(See reference maps Vlll and IX)
LAND
678,600 km2; 28% arable, of which 12% is cultivated, 62%
forest, 10% urban and other (1969)
Land boundaries: 5,850 km
WATER
Limits of territorial waters (claimed): 200 nm (200 nm
exclusive economic zone)
Coastline: 3,060 km
Railroads: 3,243 km total; 3,130 km meter gauge (1.00 m),
113 km narrow-gauge industrial lines; 328 km double track;
government owned
Highways: 27,000 km total; 3,200 km bituminous, 17,700
km improved earth, gravel, 6,100 km unimproved earth
Inland waterways: 12,800 km; 3,200 km navigable by
large commercial vessels
Ports: 4 major, 6 minor
Civil air: about 20 major transport aircraft
Airfields: 81 total, 80 usable; 21 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 40 with runways
1,220-2,439 m
Telecommunications: provide minimum requirements
for local and intercity service; international service is good;
radiobroadcast coverage is limited to the most populous
areas; 33,000 telephones (0.1 per 100 popl); 1 AM station, 1
FM station, and 1 TV station; 1 ground satellite station
DEFENSE FORCES
Military manpower: eligible 15-49, 16,523,000; of the
8,203,000 males 15-49, 4,535,000 are fit for military service;
about 374,000 males and 365,000 females reach military age
(18) annually; both sexes are liable for military service
12','55daa804472ce3a0185174daa8505b6b138f17642410fca6f826b16ba06fc5a9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fe4f980f1cdbed88ab42f32c07e4df4c85c7df2c7c1b71ca2e03cf66dde45b9',1982,'BI','Burundi','communications',88,'ZAIRE
If /t
\\S> TANZANIA K
(See reference map VII)
LAND
28,490 km2; about 37% arable (about 66% cultivated), 23%
pasture, 10% scrub and forest, 30% other
Land boundaries: 974 km','c7621866a5f3de02b146cd34e1293175faad4e67d603d48769bc5553dce0b887','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cda22f6a4c6cdaa45da21438ff162053c2649c283ada250ca00db399faa291c1',1982,'CM','Cameroon','communications',93,'Railroads: none
Highways: 7,800 km total; 300 km bituminous, 2,500 km
crushed stone, gravel, or laterite, and 3,000 km improved
earth, and 2,000 km unimproved earth
Inland waterways: Lake Tanganyika navigable for lake
steamers and barges; 1 lake port
Civil air: 4 major transport aircraft
Airfields: 8 total, 7 usable; 1 with permanent-surface
runways; 1 with runways 2,440-3,659 m
Telecommunications: sparse system of wire and low-
capacity radio- relay links; about 6,000 telephones (0.1 per
100 popl.); 2 AM and 2 FM stations; no TV stations;
INTELSAT satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 1,003,000; 521,000 fit
for military service; 50,000 reach military age (16) annually
Military budget: for fiscal year ending 31 December
1980, $35.5 million; about 21.8% of central government
budget
(See reference map VII)
LAND
475,400 km2; 4% cultivated, 18% grazing, 13% fallow, 50%
forest, 15% other
Land boundaries: 4,554 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 402 km
Railroads: 1,173 km total; 858 km meter gauge (1.00 m),
145 km 0.600-meter gauge
Highways: approximately 32,226 km total; including
2,682 km bituminous, 3,670 km gravel and earth, 11,004 km
improved earth, 14,870 km unimproved
Inland waterways: 2,090 km; of decreasing importance
Ports: 1 major (Douala), 3 minor
Civil air: 4 major transport aircraft
Airfields: 60 total, 54 usable; 7 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: good system of open wire and
radio relay; 26,000 telephones (0.3 per 100 popl.); 10 AM, 1
FM, and no TV stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,990,000; 1,001,000 fit
for military service; about 85,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 June 1982,
$78.9 million; 7.4% of central government budget
35','c8a095cf711c37d05dff6df527c7dfbbe0202b2582dc5994347b6faae5bf075e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e8b79ccb3985f305b8625a15fd0375c44fc8ca226fade39dbd907a1c00688bc',1982,'CA','Canada','communications',96,'(See reference map M)
LAND
9,971,500 km*; 4% cultivated, 2% meadows and pastures,
44% forested, 42% waste or urban, 8% inland water
Land boundaries: 9,010 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 90,908 km
Railroads: 68,978 km total; 67,616 km standard gauge
(1.435 m), 43 km electrified; 1,183 km 1.067-meter gauge (in
Newfoundland); 179 km 0.914-meter gauge
Highways: 829,325 km total; 640,850 km surfaced
(189,800 km paved), 188,475 km earth
Inland waterways: 3,000 km
Pipelines: oil, 23,564 km total crude and refined; natural
gas, 74,980 km
Ports: 19 major, 300 minor
Civil air: 599 major transport aircraft
Airfields: 1,863 total, 1,510 usable; 358 with permanent-
surface runways; 4 with runways over 3,659 m, 30 with
runways 2,440-3,659 m, 316 with runways 1,220-2,439 m
Telecommunications: excellent service provided by mod-
ern telecom media; 15.9 million telephones (66.6 per 100
popl.); countrywide AM, FM, and TV coverage including
630 AM, 80 FM, and 500 TV stations; 8 coaxial submarine
cables; 2 satellite stations with total of 5 antennas and 70
domestic satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 6,694,000; 5,744,000 fit
for military service; 202,000 reach military age (17) annually','4dd61e532c4f834843d0f631a317f33415d195221eb4f0aabb15d518c1dbeca3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4cfde343d70d7b0179c8521858b3d8cf1aa6b45ca29e578b278fe457c77b1fd',1982,'MR','Mauritania','communications',100,'CAPE VEBDE
o
y SENEGAL
Atlantic Ocean
BISSAU^ Vf
(See reference mep VII)
LAND
4,040 km1, divided among 10 islands and several islets
WATER
Limits of territorial waters: 12 nm (fishing 200 nm,
economic 200 nm)
Coastline: 965 km
/','ada2270a97a566a6b046b3ae023d23ab6165b306de1b0a5b779f84c1f68f2d41','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a2eb909e1fe504923a2655bd68f61f391d5c5898340b94bbb4888208070cfd2',1982,'CF','Central African Republic','communications',105,'Ports: 1 major (Mindelo), 3 minor
Civil air: 2 major transport aircraft
Airfields: 6 total, 6 usable; 4 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: interisland radio-relay system, HF
radio to mainland Portugal and Guinea-Bissau, about 1,700
telephones (0.5 per 100 popl.); 1 FM station and 1 AM
station; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 79,000; 45,000 fit for
military service
Military budget: for fiscal year including 31 December
1980, $15 million; about 5% of central government budget
(See reference map VII)
LAND
626,780 km*; 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban, waste
Land boundaries: 4,981 km
Railroads: none
Highways: 21,950 km total; 454 km bituminous, 10,196
km improved earth, 11,300 unimproved earth
Inland waterways: 7,080 km; traditional trade carried on
by means of shallow-draft dugouts on the extensive system of
rivers and streams
Ports: Bangui (river port)
Civil air: 3 major transport aircraft
Airfields: 55 total, 47 usable; 3 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: facilities are meager; network is
composed of low-capacity, low-powered radio-communication
stations and radio-relay links; 6,000 telephones (0.2 per 100
popl.); 3 AM stations, 1 FM station, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 541,000; 281,000 fit for
military service
Supply: mainly dependent on France, but has received
equipment from Israel, Italy, USSR, FRG, South Korea, and
PRC
Military budget: for fiscal year ending 31 December
1980; $13.5 million; about 10.8% of central government
budget
39','3afe3079598e95b00d6576f3cdbaf9ec12863d88ddd2d0ea625e317fe34c8a2c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9288fc93fe283df4073d27be02bd7dc33a2eaaeed49e7d98019ce772b56ab686',1982,'TD','Chad','communications',107,'J LIBYA
EGYPT \\\\
SUDAN /
(See reference map VI f)
LAND
1,284,640 km*; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 5,987 km','111ee6d51027c71fe628188c3a2e5ce8d023aa2f556e888b029b35d8b4b46508','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9900159b91cf8867ecf372cda3a4a20114aba052b2b1cd0ed5efe958dabe5c0c',1982,'CL','Chile','communications',112,'Railroads: none
Highways: 27,505 km total; 242 km bituminous, 4,385 km
gravel and laterite, and remainder unimproved
Inland waterways: approximately 2,000 km navigable
Civil air: 4 major transport aircraft
Airfields: 65 total, 61 usable; 6 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 27 with runways
1,220-2,439 m
Telecommunications: fair system of radiocommunication
stations for intercity links; satellite ground station; 5,000
telephones (0.1 per 100 popl.); 1 AM and no FM stations;
most facilities inoperative
'' DEFENSE FORCES
Military manpower: males 15-49, 1,093,000; 565,000 fit
for military service; about 46,000 reach military age (20)
annually
Supply: primarily dependent on France
Military budget: for fiscal year ending 31 December
1977, $22.2 million; about 33% of total budget
A BOLIVIA <^
v i
CHILE/
f ARGENTINA L^T
Pacific ) f
Ocean tt
At/antic
f Ocean
(See reference mep IV)
756,626 km2; 2% cultivated, 7% other arable, 15% perma-
nent pasture, grazing, 29% forest, 47% barren mountains,
deserts, and cities
Land boundaries: 6,325 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 6,435 km
Railroads: 8,293 km total; 3,979 km 1.676-meter gauge,
135 km standard gauge (1.435 m), 3,903 km meter gauge
(1.00 m), 95 km 0.600-meter gauge, 68 km 0.762-meter
gauge, 113 km combined 1.435- and 1.00-meter gauge
Highways: 79,870 km total; 9,840 km paved, 37,930 km
gravel, 32,100 km improved and unimproved earth
Inland waterways: 725 km
Pipelines: crude oil, 755 km; refined products, 785 km;
natural gas, 320 km
Ports: 10 major, 20 minor
Civil air: 27 major transport aircraft, including 2 leased in
Airfields: 397 total, 343 usable; 44 with permanent-
surface runways; 10 with runways 2,440-3,659 m, 48 with
runways 1,220-2,439 m
Telecommunications: modern telephone system based on
extensive radio-relay facilities; 553,800 telephones -(4.9 per
100 popl.); I Atlantic Ocean satellite station; 2 domestic
satellite stations; 180 AM, 30 FM, and 88 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,947,000; 2,219,000 fit
for military service; about 118,000 reach military age (19)
annually
42','19b385ac06b17a2d5654f3436adc1095d050478d39e7306374dcebbe437e458b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60d3d3be4500250e5769e8f3ed7d452d6188a9a371199e75f96f5ed5be451446',1982,'CO','Colombia','communications',116,'Railroads: networks total about 52,500 route km
common-carrier lines; about 600 km meter gauge (1.00 m);
rest standard gauge (1.435 m); all single track except 9,345
km double track on standard gauge lines; approximately
1,520 km electrified; about 10,000 km industrial lines
(gauges range from 0.762 to 1.435 m)
Highways: about 890,000 km all types roads; almost half
(about 350,000 km) unimproved natural earth roads and
tracks; about 280,000 km improved earth roads about 2- to
5-meters wide and in poor to fair condition; remainder
(about 260,000 km) includes majority of principal roads
Inland waterways: 169,000 km; 40,200 km navigable by
modern motorized craft
Ports: 21 major, approximately 180 minor
Airfields: 372 total; 270 with permanent-surface runways;
10 with runways 3,500 m and over; 66 with runways 2,500 to
3,499 m; 230 with runways 1,200 to 2,499 m; 62 with
runways less than 1,200 m; 2 seaplane stations; 4 airfields
under construction
DEFENSE FORCES
Military manpower: males 15-49, 274,548,000;
153,482,000 fit for military service; 11,372,000 reach mili-
tary age (18) annually
Caribbean Sea \\
j * Bogota / ^S^\\
J COLOMBW) Tf~^ ?
Pacific
Ocean
XJ f BRAZIL
(See reference map IV)
LAND
1,139,600 km*; settled area 28% consisting of cropland and
fallow 5%, pastures 14%, woodland, swamps, and water 6%,
urban and other 3%; unsettled area 72% — mostly forest and
savannah
Land boundaries: 6,035 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 2,414 km
Railroads: 3,436 km, all 0.914-meter gauge, single track
Highways: 65,125 km total; 8,655 km paved, 48,510 km
gravel, 7,960 earth
Inland waterways: 14,300 km, navigable by river boats
Pipelines: crude oil, 3,585 km; refined products, 1,350
km; natural gas, 830 km; natural gas liquids, 125 km
Ports: 5 major, 5 minor
Civil air: 118 major transport aircraft, including 6 leased
in
Airfields: 634 total, 633 usable; 50 with permanent-
surface runways; 1 with runways over 3,660 m; 6 with
runways 2,440-3,659 m, 89 with runways 1,220-2,439 m
Telecommunications: nationwide radio-relay system; 1
Atlantic Ocean satellite station and 3 domestic satellite
stations; 1.52 million telephones (5.3 per 100 popl.); 325 AM,
130 FM, and 86 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 6,442,000; 4,570,000 fit
for military service; about 326,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1981, $312.7 million; about 7.6% of central
government budget
45','d34dc8b4d91e47865223d10fdf6706118284b3853d9951000fcfbac642c23771','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f716ac4cd78410986ee3fd33c693f136b85585b30a088609d5f71a8828fe615c',1982,'KM','Comoros','communications',119,'—J .
TMUHIA S
Indian Ocean
) Monmi^ COMOROS
) MOZAMBIQUE
;
/ MADAGASCAR
0
(See reference map VII)
LAND
2,170 km1; 4 main islands; forests 16%, pasture 7%,
cultivable area 48%, noncultivable area 29%
WATER
Limits of territorial waters (claimed); 12 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 340 km
Railroads: none
Highways: 1,000 km total; approximately 295 km bitumi-
nous, remainder crushed stone or gravel
Ports: 1 minor (Moroni on Grande Comore); Majunga,
Madagascar, is used for major trade
Civil air: 4 major transports, 1 leased
Airfields: 5 total, 5 usable; 5 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: sparse system of HF radiocom-
munication stations for interisland, island, and external
communications to Malagasy and Reunion; 1,200 telephones
(0.3 per 100 popl.); 2 AM stations and 1 FM station; no TV
station
DEFENSE FORCES
Military manpower: males 15-49, 94,000; 57,000 fit for
military service
Military budget: for fiscal year ending 31 December
1981, $2.9 million; about 16% of the central government
budget
46','589950234a25a33766ed2473f96db1172fb349542a7edcd2fe9cd8d33de8f5a7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02c3665fd6b994005a720a61de1394887e370f6f3bb2b4591ac9b35e675f857e',1982,'CG','Congo','communications',123,'(See reference map VII)
LAND
349,650 km*; 63% dense forest or woodland, 33% cultiva-
ble or grazing (2% cultivated est.), 4% urban or waste
Land boundaries: 4,514 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 169 km
Railroads: 800 km, 1.067-meter gauge, single track
47','cdd09bf0c8004dac475444cc7b52fa2b2ef9b7a0cfe4570477d5ba490d81368f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('198a3ae1fdd651bba9612a3ae8f0a0f26fc152a03241bb16ee294efa1dd758ea',1982,'CK','Cook Islands','communications',127,'CONGO (Continued)
Highways: 8,246 km total; 555 km bituminous surface
treated; 848 km gravel, laterite, 1,623 km improved earth,
and 5,220 km unimproved roads
Inland waterways: 6,485 km navigable
Pipelines: crude oil 25 km
Ports: 1 major (Pointe-Noire)
Civil air: 4 major transport aircraft
Airfields: 63 total, 47 usable; 3 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 19 with runways
1,220-2,439 m
Telecommunications: services adequate for government
use; primary network is comprised of radio-relay routes and
coaxial cables; key centers are Brazzaville, Pointe-Noire, and
Loubomo; 13,900 telephones (1.1 per 100 popl.); 3 AM
stations, 1 FM station, and 4 TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 360,000; 180,000 fit for
military service; about 16,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1981, $59.8 million; about 10.8% of central government
budget
(See reference map X)
LAND
About 240 km2
WATER
Limits of territorial waters: 3 nm
Coastline: about 120 km','3a4a5ef8be4ef110376fb93d94f4718f27e31bff3c1b30f9cdfac94171ad5872','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9ff41c70f4b27a1cdf911733696e1db2dc65eb48eb032480700c42ebb1f0852',1982,'CR','Costa Rica','communications',132,'Railroads: none
Highways: 187 km total (1980); 35 km paved, 35 km
gravel, 84 km improved earth, 33 km unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 6 total, 5 usable; 1 with permanent-surface
runways; 2 with runways 1,220-2,439 m
Telecommunications: 6 AM, no FM, and no TV stations;
7,000 radio receivers, and 1,186 telephones (1.3 per 100
popl.)
(See reference mep III)
LAND
51,000 km2; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban, and
other
Land boundaries: 670 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; specialized competence over living resources to 200 nm)
Coastline: 1,290 km
Railroads: 790 km total; 740 km 1.067-meter gauge, 50
km 0.914-meter gauge, all single track, 160 km electrified
Highways: 28,235 km total; 2,425 km paved, 9,360 km
gravel, 16,450 km unimproved earth
Inland waterways: about 730 km perennially navigable
Pipelines: refined products, 318 km
Ports: 3 major (Lim6n, Golfito, Puntarenas), 4 minor
Civil air: 14 major transport aircraft, including 2 leased in
Airfields: 217 total, 216 usable; 27 with permanent-
surface runways; 1 with runways 2,440-3,659 m; 9 with
runways 1,220-2,439 m
Telecommunications: good domestic telephone service;
145,000 telephones (6.7 per 100 pop!.); connection into
Central American microwave net; 55 AM, 10 FM, and 15
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 619,000; 422,000 fit for
military service; about 28,000 reach military age (18)
annually
Supply: dependent on imports from US
Military budget: for fiscal year ending 31 December
1981, $13.9 million for Ministry of Public Security, including
the Civil Guard; about 2.6% of total central government
budget','58418c2c28836a8563ff237887cf111c508d81c7c12e609910ce2b53375d8a41','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d15d9826074c4261ad0c34b27cf5d3f5e81c802a1036b34ebf17fd4835bd016',1982,'CU','Cuba','communications',134,'(See reference map lit)
LAND
114,478 km2; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 3,735 km','fa480f640bef1a62a430c327e0d6662e7f78b9709bda2ad99248aa1d0bc431b5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ded36f9a56e3ecf08db99a95d97b7d3c825770c016f016893bc8ca1bb5e9a00',1982,'CY','Cyprus','communications',139,'Railroads: 14,725 km total, government owned; 5,070 km
common-carrier lines of which 4,990 km standard gauge
(1.435 m), 80 km 0.914-meter gauge; about 9,655 km
plantation/industrial lines, 6,455 km standard gauge (1.435
m), 3,200 km narrow gauge
Highways: 21,000 km total; 9,000 km paved, 12,000 km
gravel and earth surfaced
Inland waterways: 240 km
Pipelines: natural gas, 80 km
Ports: 8 major (including US Naval Base at Guantanamo),
44 minor
Civil air: 48 major transport aircraft, including 2 leased in
Airfields: 202 total, 195 usable; 58 with permanent-
surface runways; 2 with runways over 3,659 m, 8 with
runways 2,440-3,659 m, 23 with runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: eligible 15-49, 5,079,000; of the
2,575,000 males 15-49, 1,621,000 are fit for military service;
120,000 males and 114,000 females reach military age (17)
annually
Military budget: for fiscal year ending 31 December
1981, $1,112 billion; about 7,5% of total budget
TURKEY
CYPRUa^
UBAN0«
Mediterranean
Se* ISRAEi/r
SYRIA J
L \\ * r
EGYPT A V
(See reference map VI)
LAND
9,251 km*; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste, urban
areas, and other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: approximately 648 km','46c6c60cf99d460d18f43008dbefcd50ce0a8cf0079bb0a3caa9207c7dbb2807','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3c4a75bcb767b6c83083ac099748f5505415acab18482d7e845bb726f5214c0',1982,'DE','Germany','communications',143,'Railroads: none
Highways: 9,710 km total; 4,580 km bituminous surface
treated; 5,130 km gravel, crushed stone, and earth
Ports: 3 major (Famagusta, Larnaca, Limassol), 6 minor;
Famagusta under Turkish Cypriot control
Civil air: 7 major transport aircraft
Airfields: 12 total, 11 usable; 8 with permanent-surface
runways; 3 with runways 1,220-2,439 m; 4 with runways
2,440-3,656 m
Telecommunications: moderately good telecommunica-
tion system in both Greek and Turkish sectors; 92,580
telephones (15.0 per 100 popl.); 10 AM, 4 FM, and 25 TV
stations; tropospheric scatter circuits to Greece and Turkey;
2 submarine coaxial cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 174,000; 123,000 fit for
military service; about 5,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1981, $57.7 million; about 14.8% of central government
budget
(See reference map V)
LAND
127,946 km1; 42% arable, 14% other agricultural, 35%
forested, 9% other
Land boundaries: 3,540 km
Railroads: 13,131 km total; 12,872 km standard gauge
(1.435 m), 102 km broad gauge (1.524 m), 157 km narrow
gauge (0.750 m and 0.760 m); 2,891 km double track; 3,034
km electrified; government owned (1980)
Highways: 73,793 km total; 60,300 km concrete, asphalt,
stone block; 13,493 km gravel, crushed stone (1979)
Inland waterways: 475 km (1980)
Pipelines: crude oil, 1,448 km; refined products, 861 km;
natural gas, 6,000 km
Freight carried: rail — 286.2 million metric tons, 72.6
billion metric ton/km (1980); highway — 1,235.3 million
metric tons, 21.3 billion metric ton/km (1980); waterway —
10.5 million metric tons, 3.6 billion metric ton/km (exclud-
ing international transit traffic) (1980)
Ports: no maritime ports; outlets are Gdynia, Gdansk, and
Szczecin in Poland; Rijeka and Koper in Yugoslavia; Ham-
burg, FRG; Rostock, GDR; principal river ports are Prague,
Decln, Komarno, Bratislava (1979)
DEFENSE FORCES
Military manpower: males 15-49, 3,737,000; 2,888,000 fit
for military service; 112,000 reach military age annually
Military budget: announced for fiscal year ending 31
December 1980, 23 billion crowns, 7.8% of total budget
55
Railroads: 909 km, 0.914-meter gauge, single tracked; 819
km government owned, 90 km privately owned
Highways: 26,429 km total; 2,851 km paved, 11,438 km
gravel, and 12,140 unimproved
Inland waterways: 260 km navigable year round; addi-
tional 730 km navigable during high-water season
Pipelines: crude oil, 48 km
Ports: 2 major (San Jose, and Santo Tomas de Castilla), 3
minor
Civil air: 14 major transport aircraft, including 1 leased in
Airfields: 532 total, 527 usable; 10 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 17 with
runways 1,220-2,439 m
Telecommunications: modern telecom facilities limited
to Guatemala City; 70,600 telephones (1.4 per 100 popl.); 97
AM, 20 FM, and 25 TV stations; connection into Central
American microwave net; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,750,000; 1,189,000 fit
for military service; about 82,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1981, $79.0 million; 5.4% of central government
budget
•V" SENEGAL if
i
1
/
MALI f^
Bissau tsl guinea n
mm f
£0A$T f
Atlantic Ocean
(See reference map VII)
LAND
246,050 km2; 3% cropland, 10% forest
Land boundaries: 3,476 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; economic zone 200 nm)
Coastline: 346 km','c42138f66f06015be6a9de61e42f02947f117a5b7ed11e6c3a3d056d927cedef','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bab739d75102d69c00cbdb926ee6d13fd00d25a2f0ef39f6285b75b43a2e6887',1982,'DK','Denmark','communications',146,'(See reference map V)
LAND
42,994 km* (exclusive of Greenland and Faroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 68 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 3,379 km''
Railroads: 2,770 km standard gauge (1.435 m); Danish
State Railways (DSB) operate 2,120 km (1,999 km rail line
and 121 km rail ferry services); 97 km electrified, 730 km
double tracked; 650 km of standard gauge lines are privately
owned and operated
Highways: approximately 66,482 km total; 64,551 km
concrete, bitumen, or stone block; 1,931 km gravel, crushed
stone, improved earth
Inland waterways: 417 km
Pipelines: refined products, 418 km
Ports: 16 major, 44 minor
Civil air: 55 major transport aircraft, including 5 leased
out
Airfields: 178 total, 121 usable; 24 with permanent-
surface runways; 9 with runways 2,440-3,659 m, 6 with
runways 1,220-2,439 m
Telecommunications: excellent telephone, telegraph, and
broadcast services; 3.11 million telephones (60.8 per 100
popl.); 1 AM, 37 FM, and 30 TV stations; 16 submarine
coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 1,294,000; 1,094,000 fit
for military service; 41,000 reach military age (20) annually','bd93a6530eb9ae3e49004cc13bfac92eea19f173fc70fab4bc23e924b268986a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd0c9bfb9b11fb3167e310422d2cf27df69a0bcd2927edbf9b576b9309a56577',1982,'DJ','Djibouti','communications',150,'(formerly French Territory of the Afars
and Issas)
(See reference map VII)
LAND
23,310 km2; 89% desert wasteland, 10% permanent pas-
ture, and less than 1% cultivated
Land boundaries: 517 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; economic zone 200 nm)
Coastline: 314 km (includes offshore islands)','cb285405be3ae2075bc99fcbb8f6497a9a3225ef6516176756cb81a4d83c8946','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2de2f63f55a51842ca8b5496a4918bc79258172dc00a1a365b7a4b21b75ace33',1982,'DM','Dominica','communications',155,'Railroads: the Franco-Ethiopian railroad extends for 97
km through Djibouti
Highways: 1,387 km total; 279 km bituminous surface,
112 km improved earth; 996 km unimproved earth
Ports: 1 major (Djibouti)
Airfields: 11 total, 11 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m
Civil air: 2 major transport aircraft, including 1 leased in
Telecommunications: fair system of urban facilities in
Djibouti and radiocommunication stations at outlying places;
4,350 telephones (1.2 per 100 popl.); 1 AM station and no FM
stations; 1 TV station; 1 INTELSAT satellite station at
Ambouli, working with Indian Ocean satellite
DEFENSE FORCES
Military manpower: males 15-49, about 64,000; about
38,000 fit for military service
Defense is responsibility of France
Military budget: for fiscal year ending 31 December 1981,
$2.9 million; about 3.4% of central government budget
oominican At ant e
^T^SIPU8UC Ocean
-fc i V PUERTO ucean
**\\ J PUERTO
(See reference map HI)
LAND
790 km1; 24% arable, 2% pasture, 67% forests, 7% other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline; 148 km','9df7a9bb79aefe1ac486473f41933e607268fed99eb37415ac45a73c354fd9e8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97fe5d842ac73e1b88f6eb18d09ca6d1711a325b687e4ff8eef7a5cb5476c9cb',1982,'DO','Dominican Republic','communications',159,'Railroads: none
Highways: 630 km total; 360 km paved, 270 km gravel
and earth
Ports: 2 minor (Roseau, Portsmouth)
Civil air: no major transport aircraft
Airfields: 1 with permanent-surface runways 1,220-2,439
m
Telecommunications: 4,000 telephones in fully automatic
network (5.1 per 100 popl.); VHF and UHF link to St. Lucia;
2 AM stations and 1 TV station
(See reference mep III)
LAND
48,692 km2; 14% cultivated, 4% fallow, 17% meadows and
pastures, 45% forested, 20% built on or waste
Land boundaries: 361 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 1,288 km
Railroads: 1,600 km total; 104 km government owned
common-carrier 1. 065-meter gauge; 1,496 km privately
owned plantation lines of four different gauges ranging from
0.60 m to 1.43 m, 0.760-meter gauge predominating
Highways: 11,400 km total; 5,800 km paved, 5,600 km
gravel and improved earth
Pipelines: refined products, 69 km
Ports: 4 major (Santo Domingo, Barahona, Haina, San
Pedro de Macon''s), 17 minor
Civil air: 16 major transport aircraft, including 1 leased in
Airfields: 47 total, 37 usable; 13 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,439 m
Telecommunications: relatively efficient domestic system
based on islandwide radio-relay network; 139,000 telephones
(2.5 per 100 popl.); 135 AM, 31 FM, and 22 TV stations; 1 co-
axial submarine cable; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,423,000; 939,000 fit
for military service; 75,000 reach military age (18) annually
60','d9a3a80e30173a2f028c23326c755c07d477c2e3e5dfc63732f3198befff996c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c985a2511ebb3e8715549a4c85925c04c44e442ef9b044ad58ee9f962a8b0af',1982,'EC','Ecuador','communications',161,'? C0LOM&& \\ *
Galapagos f"
lalands j^*S
ECUADOR "V /
BftAZIL )
(See reference mep IV)
LAND
274,540 km2 (including Galapagos Islands); 11% culti-
vated, 8% meadows and pastures, 55% forested, 26% waste,
urban, or other (excludes the Oriente and the Galapagos
Islands, for which information is not available)
Land boundaries: 1,931 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,237 km (includes Galapagos Islands)','8202f00d537d59cd8bd45be61d762a285833119ba12bdef8606fd4a475a143fd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a967f73aac156d2846ea8ccd8662d6974c9ae0c0d44442fa77ad862456c085ea',1982,'EG','Egypt','communications',166,'Railroads: 1,121 km total; 966 km 1.067-meter gauge, 155
km 0.750-meter gauge; all single track
Highways: 69,280 km total; 11,925 km paved, 24,400 km
gravel, 32,955 km earth roads
Inland waterways: 1,500 km
Pipelines: crude oil, 623 km; refined products, 1,358 km
Ports: 3 major (Guayaquil, Manta, Puerto Bolivar), 11
minor
Civil air: 46 major transport aircraft, including 1 leased in
Airfields: 174 total, 174 usable; 17 with permanent-
surface runways; 1 with runways over 3,659 m, 4 with
runways 2,440-3,659 m, 26 with runways 1,220-2,439 m
Telecommunications: facilities adequate only in largest
cities; 1 Atlantic Ocean satellite station; 260,000 telephones
(2.9 per ''100 popl.); 250 AM, 38 FM, and 17 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,908,000; 1,295,000 fit
for military service; 87,000 reach military age (20) annually
t V_ f ISRAEtT"
\\ Cairo* i |~>','99db27ae0c2a90e23b42538a42d56e4972ac4c2e7446fc7624ca89c7780db72b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a5ea29173c272b9947c08172416acfc3a5e0a7f285eb81d9dd94d7bde909422',1982,'LY','Libya','communications',167,'EGYPT VN
\\ SAU0I
\\ ARABIA
CHAD J
LIBERIA (Continued)
Highways: 8,524 km total; 804 km bituminous treated,
2,055 km gravel, 4,731 km improved earth, and remainder
unimproved earth
Inland waterways: 370 km, for shallow-draft craft
Ports: 1 major (Monrovia), 4 minor
Civil air: 2 major transport aircraft
Airfields: 82 total, 81 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: telephone and telegraph service via
radio-relay network; main center is Monrovia; 7,700 tele-
phones (0.5 per 100 popl.); 4 AM, 3 FM, and 3 TV stations; 1
Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 430,000; 233,000 fit for
military service; no conscription
Military budget: for fiscal year ending 30 June 1982,
$60.1 million; 13.9% of central government budget
r-4 U V
J TUNISIA e^a. '' k
EGYPT \\\\
^ ^ ^ ^ * i
1 NIGER / CHAD J
(See reference map Vff)
LAND
1,758,610 km1; 6% agricultural, 1% forested, 93% desert,
waste, or urban
Land boundaries: 4,345 km
WATER
Limits of territorial waters (claimed): 12 nm (except for
Gulf of Sidra where sovereignty is claimed and northern
limit of jurisdiction fixed at 32°30''N and the unilaterally
proclaimed 100 nm zone around Tripoli)
Coastline: 1,770 km
Railroads: none
Highways: 16,250 km total; 7,750 km bituminous and
bituminous treated, 8,500 km gravel, crushed stone and
earth
Pipelines: crude oil 3,686 km; natural gas 938 km; refined
products 443 km (includes 217 km liquid petroleum gas)
Ports: 3 major (Tobruk, Tripoli, Benghazi), 4 minor, and 5
petroleum terminals
Civil air: 43 major transport aircraft, including 2 leased in
Airfields: 98 total, 86 usable; 25 with permanent-surface
runways, 6 with runways over 3,659 m, 14 with runways
2,440-3,659 m, 33 with runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 813,000; 479,000 fit for
military service; about 35,000 reach military age (17) annual-
ly; conscription now being implemented
Military budget: for fiscal year ending 31 December
1979, $502 million; 6% of central government budget
137','ea3007611f5024bf0584eb6903da3765913d843b07bc79e5471ab85726008933','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc96fccde62b6419afa3e2c3953c24f681aba1d5408ddcd9e1e17eadb6314527',1982,'SD','Sudan','communications',168,'(See reference maps VI and VII)
LAND
1,000,258 km1 (including 19,237 km* in Sinai); 2.8%
cultivated (of which about 70% multiple cropped); 96.5%
desert, waste, or urban; 0.7% inland water
Land boundaries: approximately 2,580 km (including
border of Sinai area)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
"necessary supervision zone")
Coastline: 2,450 km (1967); includes approximately 500
km within Sinai area
Railroads: 4,857 km total; 951 km double track; 25 km
electrified; 4,510 km standard gauge (1.435 m), 347 km
0.750-meter gauge
Highways: 47,025 km total; 12,300 km paved, 2,500 km
gravel and crushed stone, 14,200 km improved earth, 18,025
km unimproved earth
Inland waterways: 3,360 km; Suez Canal, 160 km long,
used by oceangoing vessels drawing up to 11.5 meters of
water; Alexandria-Cairo waterway navigable by barges of
metric ton capacity; Nile and large canals by barges of
420-metric ton capacity; Ismailia Canal by barges of 200- to
300-metric ton capacity; secondary canals by sailing craft of
10- to 70-metric ton capacity
Freight carried: Suez Canal (1966) — 242 million metric
tons of which 175.6 million metric tons were POL
Pipelines: crude oil, 675 km; refined products, 240 km;
natural gas, 365 km
Ports: 3 major (Alexandria, Port Said, Suez), 8 minor
Civil air: 37 major transport aircraft, including 3 leased in
and 2 leased out
Airfields: 109 total, 77 usable; 68 with permanent-surface
runways; 45 with runways 2,440-3,659 m, 2 with runways
over 3,659 m, 21 with runways 1,220-2,439 m
Telecommunications: system is large but still inadequate
for needs; principal centers Alexandria and Cairo, secondary
centers Al Mansurah, Ismailia, and Tanta; intercity connec-
tions by coaxial cable and microwave; extensive upgrading
in progress; est. 600,000 telephones (1.3 per 100 popl.); 23
AM, 3 FM, and 35 TV stations; 1 Atlantic Ocean satellite
station; Symphonie satellite station; 2 submarine coaxial
cables
DEFENSE FORCES
Military manpower: males 15-49, 10,912,000; 7,120,000
fit for military service; about 458,000 reach military age (20)
annually
63
Railroads: 1,496 km total (1980); all broad gauge (1.435m);
102 km double track; no electrification; government owned
Highways: 66,176 km total (1979>, 24,300 km paved
(mostly bituminous treated), 28,916 km crushed stone or
gravel, 12,960 km improved earth or unimproved earth; in
addition several thousand km of tracks, mostly unmotorable
Inland waterways: 430 km; navigable by shallow-draft
craft
Ports: 3 major, 9 minor
Civil air: 8 major transport (including 1 leased)
Airfields: 14 total, 11 usable; 11 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 7 with runways
1,220-2,439 m
Telecommunications: good international service; 75,000
(est.) telephones (0.5 per 100 popl.); 16 AM stations, 2 FM
stations, and 1 TV station; submarine cables extend to India;
1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,997,000; 3,138,000 fit
for military service; 178,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1982, $38.5 million, 2% of central government current
budget
\\ LIBYA
EGYPT \\\\ \\
| 4A \\ ARABIA
\\^Ji CHAD f
Khartoum * f\\*Y
SUDAN /
\\ X / /
5uOAM3A f
j^J f ZAIRE
(See reference map Vlf)
LAND
2,504,530 km2; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 7,805 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
"necessary supervision zone")
Coastline: 853 km
Railroads: 5,516 km total; 4,800 km 1.067-meter gauge,
716 km 1.6096-meter gauge plantation line
Highways: 20,000 km total; 1,576 km bituminous treated,
3,652 km gravel, 2,304 km improved earth; remainder
unimproved earth and track
Inland waterways: 5,310 km navigable
Pipelines: refined products, 815 km
Ports: 1 major (Port Sudan)
Civil air: 17 major transport aircraft, including 1 leased in
Airfields: 80 total, 79 usable; 9 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 33 with runways
1,220-2,439 m
Telecommunications: large system by African standards,
but barely adequate; consists of radio relay, cables, radio-
communications, and troposcatter; domestic satellite system
with 14 stations; 63,400 telephones (0.3 per 100 popl.); 5 AM,
no FM, and 2 TV stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 4,544,000; 2,778,000 fit
for military service; 209,000 reach military age (18) annually
221','6a0a4e1fa19e15b75252df592830320a6ba0295b72ca40cb90617b5c27b09aaa','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de7b9006a31fc0c63df109db93021e1e80f231c69d756fbf3233e977f3109fc4',1982,'HN','Honduras','communications',172,'ti SALVAD
Pacific Ocean
(See reference mep III)
LAND
21,400 km2; 32% cropland (9% corn, 5% cotton, 7% coffee,
11% other), 26% meadows and pastures, 31% nonagricul-
tural, 11% forested
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 307 km
(See reference map HI)
LAND
112,150 km2; 27% forested, 30% pasture, 36% waste and
built up, 7% cropland
Land boundaries: 1,530 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 820 km','465d0c8db85beac5f1b34c8cab93c45dd98eb0fb15f52d9a7a45a884a6c67d12','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a400df9dbfb76d75e79b255f625b2222ecb5a6e595d09928c9a09245efe4b44',1982,'GQ','Equatorial Guinea','communications',177,'Railroads: 602 km 0.914-meter gauge, single tracked
Highways: 10,000 km total; 1,500 km paved, 4,100 km
gravel, 4,400 km improved and unimproved earth
Inland waterways: Lempa River partially navigable
Pipelines: crude oil 1,051 km; refined products 431 km;
natural gas 365 km
Ports: 2 major (Acajutla, La Union), 1 minor
Civil air: 5 major transport aircraft
Airfields: 158 total, 146 usable; 5 with permanent-
surfaced runways; 1 with runways 2,440-3,659 m; 8 with
runways 1,220-2,439 m
Telecommunications: nationwide trunk radio-relay sys-
tem; connection into Central American microwave net;
70,000 telephones (1.5 per 100 pop!.); 60 AM, 9 FM, and 5
TV stations; 1 Atlantic Ocean Satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,057,000; 673,000 fit
for military service; 55,000 reach military age (18) annually
Military budget: proposed for fiscal year ending 31 Decem-
ber 1982, $133.9 million; central government budget unknown','1ba0bc9b7c3ad8bbe1e1f532ecf664ca3a9f1c5176949aef4fd33af23b75e464','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98f2c5f819ec7f6c3cb73305dfe84b74a15ec84aef57eca304b0e5534e5cff39',1982,'NG','Nigeria','communications',178,'EQUATOftlAl
GUINEA f
SA0 TOME *r^L
AND PRINCIPE^ / £
GABON \\ J
Atlantic
Ocean
\\ ''."v....
(See reference map VII)
LAND
28,051 km2; Rio Muni, about 25,900 km2, largely forested;
Fernando Po, about 2,072 km2
Land boundaries: 539 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 296 km
Railroads: none
Highways: Rio Muni — 2,460 km, including approx. 185
km bituminous, remainder gravel and earth; Fernando Po—
300 km, including 146 km bituminous, remainder gravel and
earth
Inland waterways: Rio Muni has approximately 167 km
of year-round navigable waterway, used mostly by pirogues
Ports: 1 major (Malabo), 3 minor
Civil air; 1 major transport aircraft
Airfields; 3 total, 3 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: poor system with adequate govern-
ment services; international communications from Bat a and
Malabo to African and European countries; 2.000 telephones
(0.6 per 100 popl ); 2 AM and no FM stations; no TV station
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 30,000 fit for
military service
Military budget: for fiscal year ending 31 December
1981, $6.2 million; 21% of central government budget
Railroads: none
Highways: 8,220 km total; 2,674 km paved bituminous,
2,658 km gravel, 2,888 km unimproved earth
Inland waterways: Niger River navigable 300 km from
Niamey to Gaya on the Benin frontier from mid-December
through March
Civil air: 4 major transport aircraft
Airfields: 66 total, 62 usable; 6 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: small system of wire and radio-
relay links concentrated in southwestern area; 8,500 tele-
phones (0.2 per 100 popl.); 12 AM stations, no FM, and 2 TV
stations; 1 Atlantic Ocean satellite station, 4 domestic anten-
nas under construction
DEFENSE FORCES
Military manpower: males 15-49, 1,255,000; 676,000 fit
for military service; about 60,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1981, $15.4 million; about 3.9% of central government
budget
(See reference map Vtt)
LAND
924,630 km2; 24% arable (13% of total land area under
cultivation), 35% forested, 41% desert, waste, urban, or other
Land boundaries: 4,034 km
WATER
Limits of territorial waters (claimed): 30 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 853 km
Railroads: 3,505 km 1.067-meter gauge
Highways: 107,990 km total 30,019 km paved (mostly
bituminous surface treatment); 25,411 km laterite, gravel,
crushed stone, improved earth; 52,560 km unimproved
Inland waterways: 8,575 km consisting of Niger and
Benue rivers and smaller rivers and creeks; additionally,
Kainji Lake has several hundred miles of navigable lake
routes
Pipelines: 1,918 km crude oil; 102 km natural gas; 3,000
km refined products
Ports: 5 major (Lagos, Port Harcourt, Calabar, Warri,
Sapele), 10 minor
Civil air: 40 major transport aircraft
Airfields: 79 total, 75 usable; 25 with permanent-surface
runways; 10 with runways 2,440-3,659 m, 19 with runways
1,220-2,439 m
Telecommunications: above average system with major
expansion in progress; radio relay and cable routes; 154,200
telephones (0.2 per 100 popl.); 25 AM, 6 FM, and 26 TV
stations; satellite station with Atlantic and Indian Ocean
antennas, domestic satellite system with 18 stations; 1 coaxial
submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 17,450,000; 10,030,000
fit for military service; 860,000 reach military age (18)
annually
177
/r / 6 NANA I I f
Guff of Guinea
0\\.
(See reference map VII)
LAND
56,980 km1; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,646 km
WATER
Limits of territorial waters (claimed): 30 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 56 km','6b4ff836943831bf0c684e190d75c4f2efd61c4247f0c1dd3e10f66e3d60a0cd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b77c3fbbd64408404819ff207a3140a5a29b9cd02140cda25eaf2a3af3c23c80',1982,'ET','Ethiopia','communications',182,'(See reference map VII)
LAND
1,178,450 km2; 10% cropland and orchards, 55% meadows
and natural pastures, 6% forests and woodlands, 29% waste-
land, built-on areas, and other
Land boundaries: 5,198 km
WATER
Limits of territorial waters (claimed): 12 nm; for seden-
tary fisheries, territorial sea extends to limit of fisheries
Coastline: 1,094 km (includes offshore islands)
Railroads: 1,089 km total; 782 km meter gauge (1.00 m),
of which 97 km are in Djibouti; 307 km 0.95-meter gauge
Highways: 44,300 km total; 3,650 km bituminous, 9,650
km gravel, 3,000 km improved earth, 28,000 km unim-
proved earth
Ports: 2 major (Assab, Massawa)
Civil air: 16 major transport aircraft
Airfields: 187 total, 167 usable; 7 with permanent-surface
runways; 1 with runways over 3,659 m, 8 with runways
2,440-3,659 m, 47 with runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 6,871,000; 3,690,000 fit
for military service; 346,000 reach military age (18) annually','0e83e0db673ca238815958101f8364247e62ed788c816618499ad1e68b93cc3d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8baba120b2a8b5cf558e5703b4ec40b9f1840d791a4d7b3f3a90c4a0d95165ad',1982,'FO','Faroe Islands','communications',188,'Railroads: none
Highways: 510 km total; 30 km paved, 80 km gravel, and
400 km unimproved earth
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable, 1 with permanent surface
runways; 1 with runways 1,200-2,439 m
Telecommunications: government-operated radiotele-
phone networks providing effective service to almost all
points on both islands; approximately 530 telephones (est.
29.2 per 100 popl.); 1 AM station
Norwegian
Sea
FAROE m
ISLANDS 7
Atlantic
Ocaan
(See reference map V)
LAND
1,340 km2; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited islands and
a few uninhabited islets
WATER
Limits of territorial waters (claimed): 3 nm; fishing
200 nm
Coastline: 764 km','201040d9528e29e8f06071dfb86f3ca549a9f7d656baeaff534478b120580931','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65ab58418d4caff8244d7ee2cfcc58edcde946245b77f0b280c5a104be2c9ce9',1982,'FJ','Fiji','communications',192,'Railroads: none
Highways: 200 km
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 1 with permanent-surface runways 1,220-2,439
m
Telecommunications: good international communica-
tions; fair domestic facilities; 15,000 telephones (35 per 100
popl); 1 AM and 3 FM stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with Denmark
!
1 PAPU^
1 j^ew cui Sea
Pacific Ocean
A
\\i VANUATU g,.-
\\ Coral Sea
\\ *
Fiji ;'':
^NEW CALEDONIA','d53aed02116d5c1d6d18efe5effb389d923aed9cffb802710a65ad09cfe98843','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35f8c8ea38d4043b940fa8baa19ea61f226e844dbb3707d246e693a814fcf3f7',1982,'FI','Finland','communications',193,'(See reference map V)
LAND
336,700 km*; 8% arable, 58% forested, 34% other
Land boundaries: 2,534 km
WATER
Limits of territorial waters (claimed): 4 nm; fishing 12
nm; Aland Islands, 3 nm
Coastline: 1,126 km (approx.) excludes islands and coastal
indentations','2db0835448e4cbb90acf5e8b3bb434e5e53c6bbbf2b881cf6c726600d04ea616','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa5e083143f4fc6668ce6ae40335b92aec8a720ccdd88c7aea930fcd74801d5e',1982,'FR','France','communications',198,'Railroads: 6,038 km total; Finnish State Railways (VR)
operate a total 6,010 km 1.524-meter gauge, 477 km multi-
ple track, and 608 km electrified; 22 km 0.750-meter gauge
and 6 km 1.524-meter gauge are privately owned
Highways: about 73,552 km total in national classified
network, including 31,000 km paved (bituminous, concrete,
bituminous-treated surface) and 42,552 km unpaved (stabi-
lized gravel, gravel, earth); additional 29,440 km of private
(state subsidized) roads
Inland waterways: 6,597 km total (including Saimaa
Canal); 3,700 km suitable for steamers
Pipelines: natural gas, 161 km
Ports: 11 major, 14 minor
Civil air: 40 major transport
Airfields: 173 total, 173 usable; 43 with permanent-
surface runways; 20 with runways 2,440-3,659 m, 23 with
runways 1,220-2,439 m
Telecommunications: good telecom service from cable
and radio-relay network; 2.24 million telephones (47.0 per
100 popl.); 15 AM, 87 FM, and 143 TV stations; 3 submarine
cables
DEFENSE FORCES
Military manpower: males 15-49, 1,289,000; 1,092,000 fit
for military service; 36,000 reach military age (17) annually
Military budget: proposed for fiscal year ending 31
December 1982, $750 million; about 5.3% of proposed
central government budget
(See reference mep V)
LAND
551,670 km2; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 2,888 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 3,427 km (includes Corsica, 644 km)
Railroads: 36,775 km total; French National Railways
(SNCF) operates 34,520 km standard gauge (1.435 m); 10,079
km electrified, 15,630 km double or multiple track; 2,255
km of various gauges (1.000 m to 1.440 m), privately owned
and operated
Highways: 1,542,400 km total; 27,500 km national high-
way; 340,000 km departmental highway; 420,000 km com-
munity roads; 750,000 km rural roads; 4,900 km of
controlled-access divided "autoroutes"; approx. 861,000 km
have bituminous-treated surface or better
Inland waterways: 14,912 km; 6,969 km heavily traveled
Pipelines: crude oil, 2,253 km; refined products, 4,344
km; natural gas, 22,532 km
74
Atlantic
Qceatt <
jV MadriiTr ¥j
PORTOG
«f SPAIN ( *
"MOROCCO^ \\ /
CANARY fi
ISLANDS /
ALGERIA \\ ■
(See reference map V and VII)
LAND
505,050 km*, including Canary (7,511 km2) and Balearic
Islands (5,025 km2); 41% arable and land under permanent
crops, 27% meadow and pasture, 22% forest, 10% urban or
other
Land boundaries: 1,899 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 4,964 km (includes Balearic Islands, 677 km,
and Canary Islands, 1,158 km)
Railroads: 16,272 km total; Spanish National Railways
(RENFE) operates 13,533 km 1.668-meter gauge, 4,921 km
electrified, and 2,140 km double track; FEVE (government-
owned narrow-gauge railways) operates 1,821 km, of pre-
dominantly meter gauge (1.000 m), and 441 km electrified;
privately owned railways operate 918 km, of predominantly
meter gauge (1.000 m), 512 km electrified and 56 km double
track
Highways: 149,352 km total; 82,070 km national— 2,433
km limited-access divided highway, 63,042 km bituminous
treated, 17,038 km intermediate bituminous, concrete, or
stone block; the remaining 67,282 km are provincial or local
roads (bituminous treated, intermediate bituminous, or stone
block)
Inland waterways: 1,045 km; of minor importance as
transport arteries and contribute little to economy
Pipelines: 265 km crude oil; 1,293 km refined products;
1,000 km natural gas
Ports: 23 major, 150 minor
Civil air: 166 major transport aircraft, including 2 leased
in and 3 leased out
Airfields (including Balearic and Canary Islands): 120
total, 114 usable; 59 with permanent-surface runways; 4
with runways over 3,659 m, 22 with runways 2,440-3,659 m,
32 with runways 1,220-2,439 m
Telecommunications: generally adequate, modern facili-
ties; 11.1 million telephones (29.4 per 100 popl.); 180 AM,
290 FM, and 890 TV stations; 20 coaxial submarine cables; 2
satellite stations with total of 5 antennas
DEFENSE FORCES
Military manpower: males 15-49, 9,068,000; 7,351,000 fit
for military service; 336,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31
December 1982, $4,271.8 million; 11.6% of the proposed
central government budget
218','9b8a778128320f91694a60171e237a53abae0d40f5e34fd0320434c6d9562641','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35e1c52cc7ccc1a614338bd08731af91ba505d2030fa0c9e9d74edc4db009d25',1982,'GF','French Guiana','communications',201,'FRANCE (Continued)
Ports: 24 major, 20 secondary, 24 minor
Civil air: 313 major transport aircraft, including 18 leased
in and 4 leased out
Airfields: 465 total, 448 usable; 237 with permanent-
surface runways; 3 with runways over 3,659 m, 34 with
runways 2,440-3,659 m, 123 with runways 1,220-2,439 m
Telecommunications: highly developed system provides
satisfactory telephone, telegraph, and radio and TV broad-
cast services; 22.2 million telephones (41.5 per 100 popl); 55
AM, 423 FM, and 5,676 TV stations; 25 submarine coaxial
cables; 2 communication satellite ground stations with total
of 6 antennas
DEFENSE FORCES
Military manpower: males 15-49, 13,620,000; fit for
military service 11,549,000; 428,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1982, $22.4 billion; about 18.3% of proposed
central government budget
*
Atlantic Ocean
SRAZtt
(See reference map IV)
LAND
90,909 km2; 90% forested, 10% wasteland, built on, inland
water and other, of which .05% is cultivated and pasture
Land boundaries: 1,183 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; economic zone 200 nm)
Coastline: 378 km
Railroads: 32 km private plantation line, 0.600-meter
gauge
Highways: 820 km total; 570 km paved, 250 km im-
proved and unimproved earth
Inland waterways: 460 km, navigable by small ocean-
going vessels and river and coastal steamers; 3,300 km
possibly navigable by native craft
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 10 total, 10 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m
Telecommunications: limited open-wire and radio-relay
system with about 13,700 telephones (22.1 per 100 popl.); 2
AM, 2 FM, and 2 TV stations; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 9,000 fit for
military service
76','3754054bf8b5aa673989d172a7bc9b40961f12ae2a3a0f45ac292fa936ac1659','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0878aeceeb9ac5f027c94a04fd7cf70b5a591efe84b720ed4047a36bcdd47d9',1982,'KI','Kiribati','communications',205,'FRENCH
• POLYNESIA
(See reference map X)
LAND
About 4,000 km2
WATER
Limits of territorial waters: 12 nm (fishing 200 nm;
exclusive economic zone 200 nm)
Coastline: about 2,525 km
Highways: 3,700 km, all types
Ports: 1 major, 6 minor
Airfields: 38 total, 38 usable; 16 with permanent-surface
runways, 2 with runways 2,440-3,659 m, 14 with runways
1,220-2,439 m
Civil air: about 3 major transport aircraft
Telecommunications: 17,302 telephones (12.9 per 100
popl.); 72,000 radio and 14,000 TV sets; 5 AM, 2 FM, and 6
TV stations; 1 ground satellite station
DEFENSE FORCES
Defense is responsibility of France
77
(formerly Gilbert Islands)
Pacific Ocean
UNfTED''*^
»™.
^^w.mpEA
Gilbert k.\\
KIRIBATI * • .
Ctinstmas I
''* TUVALU
*■ WESTERN
tffw SAM0A
J\\
(See reference map X)
LAND
About 690 km2
WATER
Limits of territorial waters: 3 nm (fishing 200 nm)
Coastline: about 1,143 km
Railroads: none
Highways: 483 km of motorable roads
Inland waterways: small network of canals, totaling 5
km, in Northern Line Islands
Ports: 3 minor
Civil air: 2 Trislanders, however, no major transport
aircraft
Telecommunications: 1 AM broadcast station; 866 tele-
phones (4.3 per 100 popl.)
(See reference map VIII)
LAND
121,730 km2; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,675 km
WATER
Limits of territorial waters (claimed): 12 nm (economic,
including fishing, 200 nm; military 50 nm)
Coastline: 2,495 km
Railroads: 4,535 km total operating in 1980; 3,870 km
standard gauge (1.435 m), 665 km narrow gauge (0.762 m);
159 km double tracked; about 2,940 km electrified; govern-
ment owned
Highways: about 20,280 km (1980); 98.5% gravel, crushed
stone, or earth surface; 1.5% concrete or bituminous
Inland waterways: 2,253 km; mostly navigable by small
craft only
Ports: 6 major, 26 minor
. DEFENSE FORCES
Military manpower: males 15-49, 4,658,000; 2,852,000 fit
for military service; 231,000 reach military age (18) annually
(See reference mep Vttt)
LAND
98,913 km*; 23% arable (22% cultivated), 10% urban and
other, 67% forested
Land boundaries: 241 km
WATER
Limits of territorial waters: 12 nm (fishing 200 nm)
Coastline: 2,413 km
Highways: 46,800 km total (1980); 9,290 km national
highway, 37,510 km provincial and local roads
Freight carried: rail (1980) 49 million metric tons; high-
way 145 million metric tons; air (1979) 14 billion metric tons
(domestic)
Pipelines: 515 km refined products
Ports: 10 major, 18 minor
Civil air: 41 major transport aircraft
Airfields: 127 total, 118 usable; 63 with permanent-
surface runways; 21 with runways 2,440-3,659 m, 12 with
runways 1,220-2,439 m
Telecommunications: adequate domestic and interna-
tional services; 2.0 million telephones (5.2 per 100 popl.); 95
AM, 19 FM, and 25 TV stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 11,201,000; 7,560,000
fit for military service; 455,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1982, $4.6 billion; about 34% of central govern-
ment budget
128','8872e9168bb54c772583d5ca0e60705f0f8bb55a2dfc13c2f1767d3f09629412','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d65ac8a9624f163a6f1db0c25ac2a2eaac44359b3b047647f5a43710564ed9cd',1982,'GA','Gabon','communications',209,'(See reference map VII)
LAND
264,180 km2; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 2,422 km
WATER
Limits of territorial waters (claimed): 100 nm; fishing,
150 nm
Coastline: 885 km
Railroads: 970 km standard gauge (1.437 m) under con-
struction; 180 km are completed
Highways: 6,947 km total; 459 km paved, 5,517 km
gravel and improved and 971 km unimproved
Inland waterways: approximately 1,600 km perennially
navigable
Pipelines: crude oil, 270 km
Ports: 2 major (Owendo and Port-Gentil), 3 minor
Civil air: 20 major transport aircraft
Airfields: 121 total, 98 usable; 6 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 22 with runways
1,220-2,439 m
Telecommunications: adequate system of open-wire,
radio-relay, tropospheric scatter links and radiocommunica-
tion stations; 1 Atlantic Ocean satellite station; 7 AM, 2 FM,
and 8 TV stations; 11,600 telephones (1.2 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 158,000; 81,000 fit for
military service; 5,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1981, $49.5 million; 3.1% of central government budget
— —
J $enegaN/^/"~
THE BanjulWss* V &AU
GAMBIA r^^—^l
BISSAU* S*T 6WNEA
Atlantic Ocean ^
(See reference map VI t)
LAND
10,360 km2; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up areas, and
other
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 80 km
Railroads: none
Highways: 3,083 km total; 431 km paved, 501 km
gravel/laterite, and 2,151 km unimproved earth
Inland waterways: 400 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent-surface runways
2,440-3,659 m
Telecommunications: adequate network of radio relay
and wire; 3,500 telephones (0.5 per 100 popl.); 2 AM and no
FM stations; no TV stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 141,000; 71,000 fit for
military service
Military budget: for fiscal year ending 30 June 1981, $2.4
million; 6.2% of central government budget; includes fire
and police expenditures
SO
GERMAN DEMOCRATIC REPUBLIC
(See reference mep V)
LAND
108,262 km2; 43% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 2,309 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 901 km (including islands)
Railroads: 14,164 km total; 13,874 km standard gauge
(1.435 m), 290 km meter (1.00 m) or other narrow gauge,
3,360 km double track standard gauge (1.435 m); 1,621 km
overhead electrified (1979)
Highways: 117,500 km total; 47,500 km concrete, asphalt,
stone block, of which 1,744 km are autobahn and limited
access roads; over 70,000 km asphalt treated, gravel, crushed
stone, and earth (1979)
Inland waterways: 2,302 km (1979)
Freight carried: rail — 302.5 million metric tons, 54.4
billion metric ton/km (1979); highway — 730.2 million metric
tons, 21.6 billion metric ton/km (1979); waterway — 14.8
million metric tons, 1.9 billion metric ton/km (excluding
international transit traffic) (1979)
Pipelines: crude oil, 1,200 km; refined products, 500 km;
natural gas 650 km
Ports: 4 major (Rostock, Wismar, Stralsund, Sassnitz), 13
minor; principal inland waterway ports are E. Berlin, Riesa,
Magdeburg, and Eisenhuttenstadt (1979)
DEFENSE FORCES
Military manpower: males 15-49, 4,319,000; 3,470,000 fit
for military service; 138,000 reach military age (18) annually
Personnel: paramilitary field force was integrated into the
Confederal Armed Forces with the Senegalese military
troops
Military budget: (announced) for fiscal year ending 31
December 1981, 10.2 billion marks; 6.2% of total budget
7 *tyH
J NonhSea /% \\
I si
r
Biltic $pt
r Ng$r J OEM \\
FED. REp\\
/OF GER.
CZECJC~
FRANCE ^^^p^^
(See reference mep V)
LAND
248,640 km* (including West Berlin); 33% cultivated, 23%
meadows and pastures, 13% waste or urban, 29% forested,
2% inland water
Land boundaries: 4,232 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,488 km (approx.)
Railroads: 32,555 km total; 28,533 km government
owned, standard gauge (1.435 m), 12,491 km double track;
11,140 km electrified; 4,022 km nongovernment owned;
3,598 km standard gauge (1.435 m); 214 km electrified; 424
km meter gauge (1.00 m); 186 km electrified
Highways: 479,600 km total; 171,600 km classified, in-
cludes 153,160 km cement-concrete, bituminous, or stone
block (includes 7,400 km of autobahnen); 8,240 km gravel,
crushed stone, improved earth; in addition, 308,000 km of
unclassified roads of various surface types (community roads)
Inland waterways: 5,222 km of which almost 70% usable
by craft of 990 metric ton capacity or larger
Pipelines: crude oil, 2,071 km; refined products, 3,240
km; natural gas, 95,414 km
Ports: 10 major, 11 minor
Civil air: 208 major transport aircraft, including 1 leased
in and 2 leased out
Airfields: 466 total, 432 usable; 221 with permanent-
surface runways; 3 with runways over 3,659 m, 32 with
runways 2,440-3,659 m, 41 with runways 1,220-2,439 m
Telecommunications: highly developed, modern tele-
communication service to all parts of the country; fully
adequate in all respects; 26.6 million telephones (43.4 per
100 popl.); 90 AM, 370 FM, and 5,510 TV stations; 6
submarine coaxial cables; 2 satellite stations with total of 6
antennas
DEFENSE FORCES
Military manpower: males 15-49, 16,350,000; 13,670,000
fit for military service; 528,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1982, $19.12 billion; about 18% of the proposed central
government budget
83','96d6c9a1e90d0d62f38c8d9ce8a82f6503f1599e8e3ce0bf50b9ab836b27401b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7de5f8c1271d5dbbca7c00c7129e7f83a308ff520db985de099a09796e24d608',1982,'GH','Ghana','communications',213,'(See reference mep VII)
LAND
238,280 km2; 19% agricultural, 60% forest and brush, 21%
other
Land boundaries: 2,285 km
WATER
Coastline: 539 km
Limits of territorial waters (claimed): 200 nm
Railroads: 953 km, all 1.067-meter gauge; 32 km double
track; diesel locomotives gradually replacing steam engines
Highways: 32,200 km total; 6,084 km concrete or bitumi-
nous surface, 26,166 km gravel or laterite
84','e06aa1ea20bc471f1ea4054a5a8bc733ddab8fdc396571a0da6a000e55c913b8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7dc0bd79c00e2f2e548a13416db9ae0d7944887c294c7e215b5ebd039fea95f',1982,'GI','Gibraltar','communications',217,'GHANA (Continued) .
Inland waterways: Volta, Ankobra, and Tano rivers
provide 235 km of perennial navigation for launches and
lighters; additional routes navigable seasonally by small
craft; Lake Volta reservoir provides 1,125 km of arterial and
feeder waterways
Pipelines: refined products, 3 km
Ports: 2 major (Tema, Takoradi), 1 naval base (Sekondi)
Civil air: 7 major transport aircraft
Airfields: 14 total, 12 usable; 5 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 7 with runways
1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 2,752,000; 1,532,000 fit
for military service; 134,000 reach military age (18) annually
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 12 km
Railroads: none
Highways: 56 km. mostly paved
Ports: 1 major (Gibraltar)
Civil air: 1 major transport aircraft
Airfields: 1 with permanent -surface runways 1,220-2,439
m
Telecommunications: adequate international radiocom-
munication facilities; automatic telephone system serving
9,000 telephones (30.3 per 100 popl.); 1 AM, I FM, and 3 TV
stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower; males 15-49, about 8,000; about
4,000 fit for military service
Defense is responsibility of United kingdom
86','f0e08075ceb7275e7818504d824441eea609040624e64901f2a242d6293497de','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c9b6a9f955a324c801af78b582a22988005bfd69b58580ec75fc4e1bad693b3',1982,'GR','Greece','communications',221,'y V
A. ( mum
" ITJttV? T f * *****
\\ j , ■ GREECf X?
>f town \\ <Sr £ 1
Sea <S**^sj&i
Mediterranean Sea
CYPRUS^"
Jem . . ;V
(See
reference map V)
LAND
132,608 km2; 29% arable and land under permanent
crops, 40% meadows and pastures, 20% forested, 11% waste-
land, urban, other
Land boundaries: 1,191 km
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 13,676 km','4a417277aeca07970f716126b63cbe271493ed8967a7b87afd71f92439d0cf9d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ca9a96fe2e1b0f3a807740ce2384e7fa3055b69bd1b3e6cf1bb2a796b7a7ecb',1982,'GL','Greenland','communications',226,'Railroads: 2,476 km total; 1,565 km standard gauge (1.435
m) of which 36 km electrified and 100 km double track, 889
km meter gauge (1.000 m), 22 km narrow gauge (0.750 m);
all government owned
Highways: 38,938 km total; 16,090 km paved, 13,676 km
crushed stone and gravel, 5,632 km improved earth, 3,540
km unimproved earth
Inland waterways: system consists of three coastal canals
and three unconnected rivers which provide navigable
length of just less than 80 km
Pipelines: crude oil, 26 km, refined products, 547 km
Ports: 17 major, 37 minor
Civil air: 43 major transport aircraft
Airfields: 74 total, 70 unable; 52 with permanent-surface
runways; 1 with runways over 3,659 m, 20 with runways
2,440-3,659 m, 19 with runways 1,220-2,439
Telecommunications: adequate, modern networks reach
all areas on mainland and islands; 2.66 million telephones
(28.1 per 100 popl); 31 AM, 37 FM, and 149 TV stations; 5
coaxial submarine cables; 1 satellite station with 1 Atlantic
Ocean antenna and 1 Indian Ocean antenna
DEFENSE FORCES
Military manpower: males 15-49, 2,298,000; 1,851,000 fit
for military service; about 75,000 reach military age (21)
annually
Military budget: proposed for fiscal year ending 31
December 1981, $1.7 billion; about 18% of central govern-
ment budget
(See reference map II)
LAND
2,175,600 km*; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow, 15% other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: approx. 44,087 km, (includes minor islands)','2ed4722176d40cf567851eec3a6d63f03c237c93a112ef928433c1f6808f9c40','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('729e8ef9239f53ea5b8bff19b300dd28586b41f19daff4b95530eb7125cc59fe',1982,'GD','Grenada','communications',231,'Railroads: none
Highways: 80 km
Ports: 7 major, 16 minor
Civil air: 2 major transport aircraft
Airfields: 12 total, 7 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: adequate domestic and interna-
tional service provided by cables and radio relay; 9,000
telephones (18.4 per 100 popl.); 9 AM, 11 FM, and 2 TV
stations; 2 coaxial submarine cables; 1 Atlantic Ocean satel-
lite station
DEFENSE FORCES
Military manpower: included with Denmark
(See reference map III)
LAND
344 km2 (Grenada and southern Grenadines); 44% culti-
vated, 4% pastures, 12% forests, 17% unused but potentially
productive, 23% built on, wasteland, other
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 121 km','c8023dd697f81ceb22a33edd35ec069e0431d9bcfc5acd9d7c1181ab4b09c6c4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('991af8665ba1aad26a3b5f22c115d2344b2e8ee002eafc5645158d7630e64053',1982,'GP','Guadeloupe','communications',235,'Railroads: none
Highways: 1,000 km total; 600 km paved, 300 km
otherwise improved; 100 km unimproved
Ports: 1 major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable; 1 with permanent-surface
runways, 1 with runways 1,220-2,439 m
Telecommunications: automatic, islandwide telephone
system with 5,200 telephones (4.9 per 100 pop].); VHF and
UHF links to Trinidad and Carriacou; 3 AM stations
5""
00MINICAN
EPUBUC
Caribbean Sea
PUERTO
» RICO
GUADELOUPE G>
*
(See reference map III)
LAND
1,779 km1; 24% cropland, 9% pasture, 4% potential crop-
land, 16% forest, 47% wasteland, built on; area consists of
two islands
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 306 km
Railroads: privately owned, narrow-gauge plantation lines
Highways: 1,110 km total; 770 km paved, 340 km gravel
and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 3 major transport aircraft
Airfields: 8 total, 8 usable, 8 with permanent-surface
runways; 1 with runways 2,440-3,659 m
Telecommunications: domestic facilities inadequate;
39,100 telephones (12.4 per 100 popl.); interisland radio-
relay links; 2 AM, 2 FM, and 3 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 80,000; 50,000 fit for
military service
91','eecd02b5506f88cf99fbc0f399484691f939fd96c009e6c4f048469426f234b5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3792532ac8ac4870e9934d2543ef259d37b0e47f460a75dd1ab3f3c0151a97e',1982,'GT','Guatemala','communications',237,'(See reference map HI)
LAND
108,880 km2; 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,625 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 400 km','14fdf5f77f48262042097521e08247012c3dafa20c99f96a669402fb85c627e0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e20dd79ba58127be74c20d1af01a3ec01b5c389f509156b4501a2573585a3861',1982,'GN','Guinea','communications',243,'Railroads: 805 km; 662 km meter gauge (1.000 m), 143
km standard gauge (1.435 m)
Highways: 7,604 km total; 4,949 km paved, remainder
unimproved earth
Inland waterways: 1,295 km navigable by shallow-draft
native craft
Ports: 1 major (Conakry), 2 minor
Civil air: 13 major transport aircraft
Airfields: 18 total, 18 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 9 with runways
1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 1,173,000; 590,000 fit
for military service
94','6d1712e054e9a371656cfc997d6ff0abe5c5fb90b246b753355b783b6eaf9a59','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d92b5ae7d5560d91b31b029441fc3f01bb608a73df5c69bde0dd8e6c051c8e14',1982,'GW','Guinea-Bissau','communications',244,'(formerly Portuguese Guinea)
■ ■■■ I
'' 7 5
BISSAU GumsA
Atlantic Ocean
(See reference map VII)
LAND
36,260 km2 (includes Bijagos archipelago)
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 274 km
Railroads: none
Highways: approx. 3,218 km (418 km bituminous, re-
mainder earth)
Inland waterways: scattered stretches
Ports: 1 major (Bissau)
Civil air: 3 major transport aircraft
Airfields: 59 total, 56 usable; 5 with permanent-surface
runways; 8 with runways 1,220-2,439 m
Telecommunications: limited system of open-wire lines,
radio-relay links, and radiocommunication stations; 3,000
telephones (0.5 per 100 popl.); 1 AM station and 1 FM
station; no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 190,000; 110,000 fit for
military service
Ships: no combat ships
95','898c7581a6349f6e143f6f9eabfa71ae13b045fbbd5d61f862445b19dfaf1bff','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66ac7ca898c3f8a36de870a0c81a792c1b3a004fd037ff33c2023ece730b535a',1982,'GY','Guyana','communications',248,'Caribbean
Set
•
\\
i
Atlantic
Ocean
} ^fieoTBitowii
YANaV-^w FRENCH
\\ SURNAME jK
BBAZii
(See reference map /Ifl
LAND
214,970 km*; 1% cropland, 3% pasture, 8% savanna, 66%
forested, 22% water, urban, and waste
Land boundaries: 2,575 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; economic zone 200 nm)
Coastline: 459 km','139e87a74e5a0d4c2837af123522a4e5c9bec0c0db201bb50ce4da24b06e9ab7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5107fbfb6ef113360a62dfa13f6d8a13a0f99d38326eac2dc7a5d1a76a4826d6',1982,'HT','Haiti','communications',253,'Railroads: 110 km total, all single track; 80 km 0.914-
meter gauge, 30 km 1.067-meter gage
Highways: 7,665 km total; 550 km paved, 5,000 km
gravel, 1,525 km earth, and 590 km unimproved
Inland waterways: 5,900 km; Demerara River navigable
to Mackenzie by ocean steamers, others by ferryboats, small
craft only
Ports: 1 major (Georgetown), 3 minor
Civi] air: 6 major transport aircraft, including 2 leased in
Airfields: 88 total, 88 usable; 4 with permanent-surface
runways; 13 with runways 1,220-2,439 m
Telecommunications: highly developed telecom system
with radio-relay network and over 27,000 telephones (3.3 per
100 popl.); tropospheric scatter link to Trinidad; 6 AM, 2 FM
and no TV stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 215,000; 172,000 fit for
military service
Military budget: for fiscal year ending 31 December
1981, $22.7 million; 9.0% of central government budget
4 ^ * Atlantic Ocean
(See refe/ence map III)
LAND
27,713 km2; 31% cultivated, 18% rough pastures, 7%
forested, 44% unproductive
Land boundary: 361 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 1,771 km
Railroads: 80 km narrow gauge (0.760 m), single-track,
privately owned industrial line; 8 km dual-gauge 0.760- to
1.065-meter gauge, government line, dismantled
Highways: 3,200 km total; 600 km paved, 950 km
otherwise improved, 1,650 km unimproved
Inland waterways: negligible; about 100 km navigable
Ports: 2 major (Port-au-Prince, Cap Haitien), 12 minor
Civil air: 7 major transport aircraft, including 2 leased in
Airfields: 15 total, 13 usable; 3 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: all domestic facilities inadequate,
international facilities slightly better; telephone expansion
program underway; 18,000 telephones (0.3 per 100 popl.); 40
AM and 5 FM stations; 1 TV station; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,334,000; 774,000 fit
for military service; about 65,000 reach military age (18)
annually
98','65fca56a077f5884df1611beec90742adba85a7a18d2500aa4cc5ad2a8139fe9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5777394e9d531ce4d52f266a91bb06ed0e8ab623a51daa37619400ecda2c5615',1982,'HK','Hong Kong','communications',258,'Railroads: 751 km total; 293 km 1.067-meter gauge, 458
km 0.914-meter gauge
Highways: 8,950 km total; 1,700 km paved, 5,000 km
otherwise improved, 2,250 km unimproved earth
Inland waterways: 1,200 km navigable by small craft
Ports: 5 major (Puerto Cortes, La Ceiba, Tela, San Lor-
enzo, Puerto Castilla), 3 minor
Civil air: 14 major transport aircraft, including 1 leased in
Airfields: 217 total, 213 usable; 5 with permanent-surface
runways; 2 with runways 2,440-3,659 m; 6 with runways
1,220-2,439 m
Telecommunications: improved, but still inadequate;
connection into Central American microwave net; 20,000
telephones (0.5 per 100 pop!.); 104 AM, 12 FM, and 7 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 874,000; 521,000 fit for
military service; about 44,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1981, $45.2 million; about 6.7% of central govern-
ment budget (includes the armed forces and other military)','644d7275afffa1f4803609673a901f6e845c8a24645b6b380a47e9dbd58da248','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db83ebeaebcda731daf3db3c79517a9ffb3c36c07322727a199690b462805842',1982,'PH','Philippines','communications',259,'(See reference map VIII)
LAND
1,036 km2; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 24 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km
Railroads: 35 km standard gauge (1.435 m); government
owned
Highways: 966 km total; 660 km paved, 306 km gravel
and crushed stone, or earth
Ports: 1 major
Civil air: 16 major transport aircraft
Airfields: 2 total; 2 usable; 2 permanent-surface runways;
1 with runways 2,440-3,659 m
Telecommunications: modern facilities provide excellent
domestic and international services; 62 telephone exchanges,
1.5 million telephones; 5 AM and 2 FM radiobroadcast
stations with 11 transmitters; 5 TV stations; 2.5 million radio
and 1.1 million TV receivers; 10,100 Telex subscriber lines
with direct connections to 47 countries; 2 INTELSAT
ground stations with access to Pacific and Indian Ocean
satellites; coaxial cable to Guangzhou (Canton), China; 3
international submarine cables; troposcatter to Taiwan avail-
able but inactive
DEFENSE FORCES
Military manpower: males 15-49, 1,550,000; 1,220,000 fit
for military service; about 52,000 reach military age (18)
annually
Defense is the responsibility of UK
101
Railroads: 2,192 km total; 1,775 km standard gauge (1.435
m), 46 km 0.60-meter gauge, 371 km 0.914-meter gauge
Highways: 56,645 km total; 6,030 km paved, 11,865 km
gravel, 14,610 km improved earth, 24,140 km unimproved
earth
Inland waterways: 8,600 km of navigable tributaries of
Amazon River system and 208 km Lake Titicaca
Pipelines: crude oil, 800 km; natural gas and natural gas
liquids, 64 km
Ports: 7 major, 20 minor
Civil air: 26 major transport aircraft
Airfields: 301 total, 291 usable; 27 with permanent-
surface runways; 2 with runways over 3,659 m, 21 with
runways 2,440-3,659 m, 47 with runways 1,220-2,439 m
Telecommunications: fairly adequate for most require-
ments; new nationwide radio-relay system; 1 Atlantic Ocean
satellite station, 7 domestic antennas; 457,000 telephones (2.7
per 100 popl.); 200 AM, 7 FM, and 63 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 4,363,000; 2,955,000 fit
for military service; 173,000 reach military age (20) annually
(See reference map IX)
LAND
300,440 km2; 53% forested, 30% arable land, 5% perma-
nent pasture, 12% other
WATER
Limits of territorial waters (claimed): 0-300 nm (under
an archipelago theory, waters within straight lines joining
appropriate points of outermost islands are considered inter-
nal waters; waters between these baselines and the limits
described in the Treaty of Paris, 10 December 1898, the
US-Spain Treaty of 7 November 1900, and the US-UK
Treaty of 2 January 1930 are considered to be the territorial
sea); fishing 200 nm; exclusive economic zone 200 nm
Coastline: about 22,540 km
Railroads: 3,510 km total (1980); 2 common-carrier sys-
tems 1.067-meter gauge totaling about 1,177 km (360 km
inoperable); 19 industrial systems with 4 different gauges
totaling 2,333 km; 34% government owned
Highways: 152,800 km total (1980); 20,000 km paved;
80,700 km gravel, crushed stone, or stabilized soil surface;
52,000 km unimproved earth
Inland waterways: 3,219 km; limited to shallow-draft
(less than 1.5 m) vessels
Pipelines: refined products, 357 km
Ports: 18 major, numerous minor
Civil air: approximately 80 major transport aircraft
Airfields: 346 total, 316 usable; 62 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 42 with
runways 1,220-2,439 m
Telecommunications: good international radio and sub-
marine cable services; domestic and interisland service
adequate; 519,642 telephones (1.2 per 100 popl.); 273 AM
stations, including 6 US; and 6 FM stations; 24 TV stations,
including 4 US; submarine cables extended to Hong Kong,
Guam, Singapore, and Japan; tropospheric-scatter link to
Taiwan; 1 ground satellite station; domestic satellite network
under construction
DEFENSE FORCES
Military manpower: males 15-49, 12,619,000; 8,948,000
fit for military service; about 555,000 reach military age (20)
annually
Supply: limited small arms and small arms ammunition,
small patrol craft production; licensed assembly of transport
aircraft; most other materiel obtained from US; naval ships
and equipment from Australia, Japan, Italy, Singapore, US,
and Italy; aircraft and helicopters from West Germany and
US
189
(See reference map Vlll)
LAND
32,260 km2 (Taiwan and Pescadores); 24% ctiltivated, 6%
pasture, 55% forested, 15% other (urban, industrial, de-
nuded, water area)
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 990 km Taiwan, 459 km offshore islands
Railroads: about 1,050 km common -carrier and 3,500 km
industrial lines, all on Taiwan, common-carrier lines consist
of West System— 825 km meter gauge (1.067 m) with 325
km double track (complete line under construction for
electrification) — and East Line — 225 km meter gauge (1,067
m); common-carrier lines owned by government and operat-
ed by Railway Administration (TRA) under Ministry of
Communications; industrial lines owned and operated by
government enterprises
Highways: network totals 17,224 km (construction of
North-South Freeway approximately §&% complete), plus
483 km on Penghu and offshore islands; 11,455 km paved,
4,424 km gravel and crushed stone, 1 ,345 km earth
Pipelines: 615 km refined products, 97 km natural gas
Ports: 5 major. 5 minor
Airfields: 43 total, 41 usable; 31 with permanent -surface
runways; 3 with runways over 3,659 m, 16 with runways
2,440-3,659 m, 10 with runways 1,220-2,439 m
Telecommunications: very good international and do-
mestic service; 2.6 million telephones; about 100 radio
broadcast stations with 240 AM and 6 FM transmitters; 12
TV stations and 3 repeaters; 8 million radio receivers and 3.6
million TV receivers; 2 INTELSAT ground stations; tropo-
spheric scatter links to Hong Kong and the Philippines
available but inactive; submarine cables to Okinawa (Japan),
the Philippines, and Guam
DEFENSE FORCES
Military manpower: males 15-49. 4,875,000; 3,835,000 fit
for military service; about 205,000 currently reach military
age (19) annually
266
f
NOV 95
INDI
■BSSBn','6d014c5486bbc276fcc76554e0af99b3676014b4d535b380fd1d502fb526ef2c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d857d58ab99a92ef92a48561faebe9435660cd0db810f1968366bfe9e26450d7',1982,'HU','Hungary','communications',263,'— "7 ~y
\\
V SOVIET
) UNION
BQMAMA V.
^ \\ \\ YUGOSLAVIA
(See reference map V)
LAND
92,981 km''; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries; 2,245 km
Railroads: 7,864 km total; 7,615 km standard gauge
(1.435 m), 214 km narrow gauge (mostly 0.760 m), 35 km
broad gauge (1.524 m), 1,179 km double track, 1,613 km
electrified; government owned (1978)
102','f50e5634ded60e62dfc3505c3d9bac359a4cd3e04b34a59b508923213dc904e1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('284890117333b658ff4294bc88b49ff6e67d9fcbf7b3593dbbe6bae000cb8292',1982,'IS','Iceland','communications',267,'HUNGARY (Continued)
Highways: 29,759 km total; 25,000 km concrete, asphalt,
stone block; 4,101 km asphalt treated, gravel, crushed stone;
658 km earth (1980)
Inland waterways: 1,688 km (1980)
Pipelines: crude oil, 1,500 km; refined products, 500 km;
natural gas, 2,896 km
Freight carried: rail — 135.2 million metric tons, 24,6
billion metric ton/km (1980); highway — 237.8 million metric
tons, 6.2 billion metric ton/km (1980); waterway — est. 4.1
million metric tons, 6.8 billion metric ton/km (excluding
international transit traffic)
River ports: 2 principal (Budapest, Dunaujvaros); no
maritime ports; outlets are Rostock, GDR; Gdansk, Gdynia,
and Szczecin in Poland; and Galati and Braila in Romania
(1978)
DEFENSE FORCES
Military manpower: males 15-49, 2,594,000; 2,085,000 fit
for military service; about 67,000 reach military age (18)
annually
Military budget: announced for fiscal year ending 31
December 1981, 18 billion forints; 3.7% of total budget
(See reference map V)
LAND
102,952 km2; arable negligible, 22% meadows and pas-
tures, forested negligible, 78% other
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 4,988 km
Railroads: none
Highways: 12,343 km total; 166 km bitumen and con-
crete; 1,284 km bituminous treated and gravel; 10,893 km
earth
Ports: 4 major (Akureyri, Hafnarfjordhur, Reykjavik,
Seydhisfjordhur), and about 50 minor
Civil air: 14 major transport aircraft, including 2 leased
out
Airfields: 119 total, 100 usable; 3 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 10 with runways
1,220-2,439 m
Telecommunications: adequate domestic service, wire
and radio communication system; 103,800 telephones (45.9
per 100 popl.); 17 AM, 19 FM, and 96 TV stations; 2 coaxial
submarine cables; 1 satellite station with Atlantic Ocean
antenna
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 52,000 fit for
military service (Iceland has no conscription or compulsory
military service)
104','2975086882b8babb54e6ca9a550cde6b0afaae4eae0c8027455313eb6095ecea','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a530c9188f698b54b1b6fbb1b9c5b1fa613a9baf5c863d5b24190e02867eb31b',1982,'ID','Indonesia','communications',272,'Railroads: 60,693 km total (1981); 30,909 km broad gauge
(1.676 m), 25,503 km meter gauge (1.00 m), 4,281 km narrow
gauge (0.762 m and 0.610 m), government owned; 46 km
meter gauge (1.00 m), 855 km broad gauge (1.676 m), 345
km narrow gauge (0.762 m and 0.610 m), privately owned;
12,617 km double track; 4,820 km electrified
Highways: 1,327,450 km total (1979); 514,250 km hard
surfaced, 190,600 km gravel or crushed stone, 495,500 km
improved earth, 416,700 km unimproved earth
Inland waterways: 16,000 km; 2,575 km navigable by
river steamers
Pipelines: crude oil, 1,980 km; refined products, 1,056
km; natural gas, 854 km; slurry 992 km
Ports: 9 major, 79 minor
Civil air: 93 major transport aircraft
Airfields: 355 total, 321 usable; 186 with permanent-
surface runways; 2 with runways over 3,659 m, 55 with
runways 2,440-3,659 m, 107 with runways 1,220-2,439 m
Telecommunications: fair domestic telephone service
where available, good internal microwave links; telegraph
facilities widespread; AM broadcast adequate; international
radio communications adequate; 2.6 million telephones (0.4
per 100 popl.); about 174 AM stations at 80 locations, 17 TV
stations, 13 earth satellite stations; submarine cables extend
to Sri Lanka; 7 satellite stations under construction
DEFENSE FORCES
Military manpower: males 15-49, 183,001,000;
111,614,000 fit for military service; about 8,343,000 reach
military age (17) annually
Military budget: for fiscal year ending 31 March 1982,
$5.7 billion; 17.0% of central government budget
(See reference map IX)
LAND
1,906,240 km*; 12% small holdings and estates, 64%
forests, 24% inland water, waste, urban, and other
Land boundaries: 2,736 km
WATER
Limits of territorial waters (claimed): under an archi-
pelago theory, claim is 12 nm, measured seaward from
straight baselines connecting the outermost islands (fishing
200 nm, economic zone 200 nm)
Coastline: 54,716 km
Railroads: 6,964 km total; 6,389 km 1.067-meter gauge,
497 km 0.750-meter gauge, 78 km 0.600-meter gauge; 211
km double track; 101 km electrified; government owned
Highways: 93,063 km total; 26,583 km paved, 41,521 km
gravel or crushed stone, 24,959 km improved or unimproved
earth
Inland waterways: 21,579 km; Sumatra 5,471 km, Java
and Madura 820 km, Borneo 10,460 km, Celebes 241 km,
and Irian Jaya 4,587 km
Ports: 15 ocean ports
Civil air: approximately 120 major transport aircraft
Airfields: 403 total, 392 usable; 86 with permanent-
surface runways; 12 with runways 2,440-3,659 m, 70 with
runways 1,220-2,439 m
Telecommunications: interisland microwave system and
HF police net; domestic service fair, international service
good; radiobroadcast coverage good; 392,563 telephones (0.2
per 100 popl.); 251 AM, 1 FM, and 14 TV stations; 1
international ground satellite station (1 Indian Ocean anten-
na and 1 Pacific Ocean antenna), and a domestic satellite
communications system
DEFENSE FORCES
Military manpower: males 15-49, 38,679,000; 22,868,000
fit for military service; about 1,798,000 reach military age
(18) annually
Military budget: for fiscal year ending 31 March 1982,
$2.76 billion; about 12.4% of central government budget
107
IRAN
y kj^w
SOVIET
UNION
i
TURKEY V
*Tthran
\\ IRAN *
SAUDI
TO—A
Arabian
Sea
fSee reference map VI)
LAND
1,647,240 km1; 14% agricultural, 11% forested, 16% culti-
vable with adequate irrigation, 51% desert, waste, or urban,
8% migratory grazing and other
Land boundaries: 5,318 km (including areas belonging to
Iran and now occupied by Iraq during continuing border
war)
WATER
Limits of territorial waters (claimed): 12 nm (fishing 50
nm)
Coastline: 3,180 km, including islands, with 676 km','4e292dee1d61449a9a3310c8d316cf1f62773ba32c6807c51f2c23172be627d9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1e46f6b27bcf30e2fa694e298f76726cf87c4f38e99ea28b6b0e419b52600db',1982,'IQ','Iraq','communications',276,'Railroads: 4,601 km total; 4,509 km standard gauge (1.435
m), 92 km 1.676-meter gauge
Highways: 81,800 km total; 36,000 km gravel and crushed
stone, 15,000 km improved earth
Inland waterways: 904 km, excluding the Caspian Sea,
104 km on the Shatt al Arab
Pipelines: crude oil, 5,900 km; refined products, 3,500
km; natural gas, 3,282 km
Ports: 7 major, 6 minor
Civil air: approx. 50 major transport aircraft
Airfields: 178 total, 143 usable; 78 with permanent-
surface runways; 17 with runways over 3,659 m, 17 with
runways 2,440-3,659 m, 69 with runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 9,310,000; 5,722,000 fit
for military service; about 409,000 reach military age (21)
annually
Military budget: for fiscal year ending 20 March 1981,
$4.2 billion; 10% of central government budget
(See reference map VI)
LAND
445,480 km2; 18% cultivated, 68% desert, waste, or urban,
10% seasonal and other grazing land, 4% forest and
woodland
Land boundaries: 3,668 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 58 km
Railroads: 1,700 km total; 1,123 km standard gauge (1.435 m),
577 km meter gauge (1.00 m); 16 km meter gauge double track
Highways: 20,791 km total; 6,490 km paved, 4,645 km
improved earth, 9,656 km unimproved earth
Inland waterways: 1,015 km; Shatt al Arab navigable by
maritime traffic for about 104 km; Tigris and Euphrates
navigable by shallow-draft steamers
Ports: 3 major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 3,821 km; 585 km refined products;
1,360 km natural gas
Civil air: 30 major transport aircraft
Airfields: 87 total, 73 usable; 29 with permanent-surface
runways; 39 with runways 2,440-3,659 m, 13 with runways
1,220-2,439 m
Telecommunications: good network consists of coaxial
cables, radio-relay links, and radiocommunication stations;
320,000 telephones (2.5 per 100 popl.); 9 AM, no FM and 13
TV stations; 1 satellite station with Atlantic Ocean and
Indian Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 3,146,000; 1,809,000 fit
for military service; about 156,000 reach military age (18)
annually
Military budget: est. for fiscal year ending 31 December
1980, $2.9 billion; 24% of central government budget
110','54bb5591b9de76d150228fef08af3c9de230b5f5e3b0643eb02f99f22057f065','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22f7a3554d355deb8bd8d14c7c30c5774f73cfce70e7b0fe708bd57a7f72b473',1982,'IE','Ireland','communications',279,'(See reference map V)
LAND
68,894 km2; 17% arable, 51% meadows and pastures, 3%
forested, 2% inland water, 27% waste and urban
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed); 3 nm (fishing 200
nm)
Coastline: 1,448 km','e751718ee0c8eab637d3a2b6d7f78f6068e37436f57b613959b1e0e83748b87f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51f89f399cc167f3cec0b84665d363e22688297b5461288667f940135e88a6d9',1982,'IL','Israel','communications',284,'Railroads: 2,190 km 1.600-meter gauge, government
owned
Highways: 92,294 km total; 87,422 km surfaced, 4,872
km gravel or crushed stone
Inland waterways: approximately 1,000 km
Ports: 6 major, 38 minor
Civil air: 36 major transport aircraft, including 2 leased in
and 4 out
Airfields: 38 total, 37 usable; 9 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: small, modern system using cable
and radio-relay circuits; 586,000 telephones (17.2 per 100
popl.); 15 AM, 14 FM, and 59 TV stations; 2 coaxial
submarine cables; planned satellite station
DEFENSE FORCES
Military manpower: males 15-49, 807,000; 662,000 fit for
military service; about 33,000 reach military age (17)
annually
Military budget: for fiscal year ending 31 December
1981, $222 million; about 4.0% of the central government
budget
(See reference mep VI)
NOTE: the Arab territories occupied by Israel since the
1967 war are not included in the data below unless indicat-
ed; the occupied Gaza Strip (360 km2) was administered
from 1948 to June 1967 by Egypt but not claimed as
sovereign territory; Israel relinquished control of the Sinai to
Egypt on 25 April 1982
LAND
20,720 km2 (excluding about 26,331 km2 of occupied
territory in Jordan, Egypt, Syria, and Gaza as of January
1982); 20% cultivated, 40% pastureland and meadows, 4%
forested, 4% desert, waste, or urban, 3% inland water, 29%
unsurveyed (mostly desert)
Land boundaries: 1,036 km (before 1967 war); including
occupied areas, approximately 1,050 km (as of January 1982)
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 273 km (before 1967 war); including occupied
areas, approximately 400 km (January 1982)
Railroads: 767 km standard gauge (1.435 m)
Highways: 4,459 km paved, 7 km gravel/crushed stone,
remainder unknown
113','a34e581fec08b596268c03406aa8f893a2d6448c6a0cdfb6109fa84d1af2d9a8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f5cc5d48363a3229280915c34bd26018928eb554dbf5999e503549604752035',1982,'IT','Italy','communications',287,'ISRAEL (Continued)
Pipelines: crude oil, 708 km; refined products, 290 km;
natural gas, 89 km
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Civil air: 22 major transport aircraft, including 3 leased in
Airfields: 66 total, 55 usable; 23 with permanent-surface
runways; 5 with runways 2,440-3,659 m, 10 with runways
1,220-2,439 m
Telecommunications: most highly developed in the Mid-
dle East though not the largest; good system of coaxial cable
and radio relay; 930,000 telephones (25.4 per 100 popl.); 14
AM, 10 FM stations, 15 TV stations, and 25 repeater stations;
2 submarine cables; 1 Atlantic Ocean satellite station, second
antenna planned
DEFENSE FORCES
Military manpower: eligible 15-49, 1,838,000; of 921,000
males 15-49, 580,000 fit for military service; of 909,000
females 15-49, 571,000 fit for military service; 35,000 males
and 33,000 females reach military age (18) annually; both
sexes liable for military service
(See reference mep V)
LAND
301,217 km*; 50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive, 9% waste
or urban
Land boundaries: 1,702 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,996 km
Railroads: 20,085 km total; 16,140 km government owned
standard gauge (1.435 m), 8,585 km electrified; 3,945 km
nongovernment owned — 2,100 km standard gauge (1.435 m),
1,155 km electrified, and 1,845 km narrow gauge (0.950 m),
380 km electrified
Highways: 294,410 km total; autostrade 5,900 km, state
highways 45,170 km, provincial highways 101,680 km,
communal highways 141,660 km; 260,500 km concrete,
bituminous, or stone block, 26,900 km gravel and crushed
stone, 7,010 km earth
Inland waterways: 2,500 km navigable routes
Pipelines: crude oil, 1,703 km; refined products, 2,148
km; natural gas, 13,749 km
115
IVORY COAST
ITALY (Continued)
Ports: 16 major, 22 significant minor
Civil air: 146 major transport aircraft, including 6 leased
in
Airfields: 147 total, 142 usable; 84 with permanent-
surface runways; 2 with runways over 3,659 m, 32 with
runways 2,440-3,659 m, 43 with runways 1,220-2,439 m
Telecommunications: well engineered, well constructed,
and efficiently operated; 18.1 million telephones (31.7 per
100 popl.); 135 AM, 1,830 FM, and 1,350 TV stations; 20
coaxial submarine cables; 2 communication satellite ground
stations with a total of 5 antennas
DEFENSE FORCES
Military manpower: males 15-49, 14,075,000; 11,862,000
fit for military service; 466,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1982, $8.8 billion; about 4.4% of central govern-
ment budget
(See reference map VII)
LAND
323,750 km*; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste; 322 km of lagoons and
connecting canals extend east-west along eastern part of the
coast
Land boundaries: 3,227 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 515 km
Railroads: 657 km of the 1,173 km Abidjan to Ouagadou-
gou, Upper Volta line, all single track meter gauge (1.00 m);
only diesel locomotives in use
Highways: 45,600 km total; 2,461 km bituminous and
bituminous-treated surface; 31,939 km gravel, crushed stone,
laterite, and improved earth; 11,200 km unimproved
Inland waterways: 740 km navigable rivers and numer-
ous coastal lagoons
Ports: 2 major (Abidjan, San Pedro), 3 minor
Civil air: 23 major transport aircraft
Airfields: 50 total, 47 usable; 3 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 9 with runways
1,220-2,439 m
Telecommunications: system above African average; con-
sists of open-wire lines and radio-relay links; 78,400 tele-
phones (1.2 per 100 popl.); 3 AM, 8 FM, and 6 TV stations; 2
Atlantic Ocean satellite stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 2,081,000; 1,068,000 fit
for military service; 84,000 males reach military age (18)
annually
117
Military budget: for fiscal year ending 31 December
1982, $13.5 million; about 2.4% of central government
budget
(See reference mep HI)
LAND
1,100 km2; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 290 km
Railroads: none
Highways: 1,680 km total; 1,300 km paved, 380 km
gravel and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: 2 major transport aircraft
Airfields: 3 total; 3 usable; 1 with permanent-surface
runways; 1 with runways 2,440-3,659 m
Telecommunications: domestic facilities inadequate;
38,500 telephones (12.2 per 100 popl.); interisland VHF and
UHF radio links; 1 Atlantic Ocean satellite station; 1 AM, 1
FM, and 7 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 77,000; 40,000 fit for
military service
153','77cba8aba17d99985ebc00661c20469fecc58b3ffad93435ecafc5b8123bc0b1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f294db83065a0b53fdc3ca9c4cbd5d0fc66c0ce020b5aa1e1d770b35273b658',1982,'JM','Jamaica','communications',291,'(See reference mep til)
LAND
11,422 km2; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,022 km','b68baad91443bf0aeff743826d4a9b66aebe90502e3dcbf333d99720ff6a264f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10c96400b473edf112586f97a2f216fe5ce0ca17444837998efc84916eb7487d',1982,'JP','Japan','communications',296,'Railroads: 370 km, all standard gauge (1.435 m), single
track
Highways: 18,200 km total; 12,600 km paved, 3,200 km
gravel, 2,400 km improved earth
Pipelines: refined products, 10 km
Ports: 2 major (Kingston, Montego Bay, 10 minor
Civil air: 12 major transport aircraft, including 1 leased in
and 1 leased out
Airfields: 42 total, 22 usable; 13 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: fully automatic domestic telephone
network with 111,000 telephones (5.0 per 100 popl); 1
Atlantic Ocean INTELSAT station; 8 AM, 11 FM, and 9 TV
stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 511,000; 378,000 fit for
military service; no conscription; 31,000 reach minimum
volunteer age (18) annually
Supply: dependent on UK and US
Military budget: for fiscal year ending 31 March 1982,
$33.2 million; about 2.3% of central government budget
SOVIET
* V
cumk\\
SOUTH?
i KOREAN
''KOREA
Ajapan
''''Tokyo
Pacific
Philippine
Ocean
*
(See reference map VIII)
LAND
370,370 km2; 16% arable and cultivated, 3% grassland,
12% urban and waste, 69% forested
WATER
Limits of territorial waters (claimed): 12 nm except 3
nm in five international straits (fishing 200 nm)
Coastline: 13,685 km
Railroads: 29,711 km total (1979); 1,077 km standard
gauge (1.435 m), 28,634 km predominantly narrow gauge
(1.067 m), 7,539 km double track, 8,279 km or 28% of total
route length electrified; 82% government owned
Highways: 1,106,138 km total (1976); 474,434 km paved,
631,704 km gravel, crushed stone, or unpaved
Inland waterways: approx. 1,770 km; seagoing craft ply
all coastal "inland seas"
Pipelines: crude oil, 50 km; natural gas, 1,728 km
Ports: 53 major, over 2,000 minor
Civil air: 265 major transport aircraft
Airfields: 195 total, 170 usable; 125 with permanent-
surface runways; 2 with runways over 3,659 m; 24 with
runways 2,440-3,659 m, 46 with runways 1,220-2,439 m
Telecommunications: excellent domestic and interna-
tional service; 55.4 million telephones (47.6 per 100 popl.);
167 AM stations, 48 FM stations plus 429 relay stations; 5,525
TV stations (192 major— 1 kw or greater), and 2 ground
satellite stations; submarine cables to US (via Guam), Philip-
pines, China, and USSR
DEFENSE FORCES
Military manpower: males 15-49, 31,204,000; 26,059,000
fit for military service; about 884,000 reach military age (18)
annually
Supply: defense industry potential is large, with capability
of producing the most sophisticated equipment; manufac-
tured equipment includes small arms artillery, armored
vehicles, and other types of ground forces materiel, aircraft
(jet and prop), naval vessels (submarines, guided missile and
other destroyers, patrol craft, mine warfare ships, and other
minor craft including amphibious, auxiliaries, service craft,
and small support ships), small amounts of all types of army
materiel; several missile systems are produced under US
license and a vigorous domestic missile development pro-
gram exists
Military budget: proposed for fiscal year ending 31
March 1983, $11.8 billion; about 5.2% of total budget
120','76d77215fa2d69b70f9770a2d5b5fc9ad8b214b78663ab782595e1cc8566ef26','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('101482a2acb31d5a03b1f4aaa908162c88cff45e7b868f34d016983b86ad8f9f',1982,'JO','Jordan','communications',299,'j. SYfUA
£7 LEBANON* ^
mm
A. \\ * y*-/
EGYPT V8* \\
A
SAW
ABASIA
\\ Sea\\
fSea reference map VI)
NOTE: The war between Israel and the Arab states in
June 1967 ended with Israel in control of West Jordan.
Although approximately 930,000 persons resided in this area
before the start of the war, fewer than 750,000 of them
remain there under the Israeli occupation, the remainder
having fled to East Jordan. Over 14,000 of those who fled
were repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the 1967 Arab-Israeli war are not
included in the data below.
LAND
96,089 km2 (including about 5,439 km2 occupied by
Israel); 11% agricultural, 88% desert, waste, or urban, 1%
forested
Land boundaries: 1,770 km (1967, 1,668 km excluding
occupied areas)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 26 km
Railroads: 817 km 1.050-meter gauge, single track
Highways: 6,332 total; 4,837 paved, 1,495 gravel and
crushed stone
Pipelines: crude oil, 209 km
Ports: 1 major (Aqaba)
Civil air: 17 major transport aircraft, including 2 leased in
Airfields: 27 total, 18 usable; 16 with permanent-surface
runways; 2 with runways over 3,659 m, 13 with runways
2,440-3,659 m, 2 with runways 1,220-2,439 m
Telecommunications: adequate system of radio-relay,
wire, and radio; 53,000 telephones (1.6 per 100 popl.); 5 AM,
no FM, and 11 TV stations; 1 Atlantic Ocean satellite station,
1 Indian Ocean station
DEFENSE FORCES
Military manpower: males 15-49, 722,000; 511,000 fit for
military service; 36,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1981, $874 million; 44% of central government budget
(See reference map IX)
LAND
181,300 km1; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 2,438 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: about 443 km
Railroads: 612 km meter gauge (1.00 m); government
owned
Highways: 13,351 km total; 2,622 km bituminous, 7,105
km crushed stone, gravel, or improved earth; and 3,624 km
unimproved earth; some roads in disrepair
Inland waterways: 3,700 km navigable all year to craft
drawing 0.6 meters; 282 km navigable to craft drawing 1.8
meters
Ports: 2 major, 5 minor
Airfields: 52 total, 23 usable; 9 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 8 with runways
1,220-2,439 m
Telecommunications: service barely adequate for govern-
ment requirements and virtually nonexistent for general
public; international service limited to Vietnam and other
adjacent countries; radiobroadcasts limited to 1 station
DEFENSE
Military manpower: males 15-49, 1,571,000; 843,000 fit
for military service; 99,000 reach military age (18) annually
123','594fe765f7ab11f54b03b28cdcb49a00488614e7a05548bd53059f31f6e6af7a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d2304560db145fb433949005ee10e42c6d2fe0b8fe3cf76c05cc76d91bf195',1982,'KE','Kenya','communications',303,'* SUOAfti f
ff ETHIOPIA /
^ /
* J
Tsomauax
/ KENYA
JJXiy^*^ * Nairobi
Indian
Ocean
\\ TANZANIA S
(Sae reference map Vll)
LAND
582,750 km2; about 21% forest and woodland, 13% suit-
able for agriculture, 66% mainly grassland adequate for
grazing (1971)
Land boundaries: 3,368 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zones 200 nm)
Coastline: 536 km
Railroads: none
Highways: 9,020 km total; 460 km paved, 2,700 km
gravel and/or improved earth, remainder unimproved
Inland waterways: Lake Kivu navigable by barges and
native craft
Civil air: 3 major transport aircraft
Airfields: 8 total, 8 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: fair system with low-capacity
radio-relay system centered on Kigali; 4,600 telephones (0.1
per 100 popl.); 2 AM, 1 FM, no TV stations; SYMPHON1E
satellite station, INTELSAT terminal under construction
DEFENSE FORCES
Military manpower: males 15-49, 1,151,000; 583,000 fit
for military service; no conscription
Military budget: for fiscal year ending 31 December
1981, $22.1 million; 14% of central government budget
198
ST. CHRISTOPHER-NEVIS
— 1
Atlantic Ocean
ST. CHRISTOPHER*. I
MCVIO *
Caribbean Sea «
4 « *
(Sea reference map HO
LAND
261 km*; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 135 km
Railroads: 57 km, narrow gauge (0.760 m) on St. Christo-
pher for sugarcane
Highways: 300 km total; 125 km paved, 125 km otherwise
improved, 50 km unimproved earth
Ports: 2 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; 1 with runways 1,220-2,439 m
Telecommunications: good interisland VHF/UHF/SHF
radio connections and international link via Antigua and St.
Martin; about 2,400 telephones (5.0 per 100 popl.); 2 AM and
5 TV stations
199
ST. LUCIA
(See reference map III)
LAND
616 km2; 50% arable, 3% pasture, 19% forest, 5% unused
but potentially productive, 23% wasteland and built on
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 158 km
Railroads: none
Highways: 760 km total; 500 km paved; 260 km otherwise
improved
Ports: 1 major (Castries), 1 minor
Civil air: 1 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways, 1 with runways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: fully automatic telephone system
with 7,200 telephones (6.2 per 100 popl.); direct radio-relay
link with Martinique; interisland troposcatter links to Barba-
dos and Antigua; 3 AM stations, 1 TV station
ST. VINCENT AND THE GRENADINES
~V>-n \\* DOM.
Caribbean Sea
Atlantic Ocean
VINCENT AND
« THE GRENADINES
(See reference mep HI)
LAND
389 km2 (including northern Grenadines); 50% arable, 3%
pasture, 44% forest, 3% wasteland and built on
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 84 km
Railroads: none
Highways: 600 km total; 300 km paved; 150 km otherwise
improved; 150 km unimproved earth
Ports: 1 major (Kingstown), 1 minor
Civil air: no major transport aircraft
Airfields: 5 total, 5 usable; 3 with permanent-surface
runways, 1 with runways 1,220-2,439 m
Telecommunications: island wide fully automatic tele-
phone system with 5,300 sets (5.3 per 100 popl.); VHF/UHF
interisland links to Barbados and the Grenadines; 2 AM
stations
201','b42c9d0b1a27a3ae92fff1cb61ebf053fc0d09403907658dc8b870f7b226dbe4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82823abf2ae939d5b6027797816732c66919f5ae641566d8f85359fec8944cbb',1982,'UG','Uganda','communications',308,'Railroads: 2,040 km meter gauge (1.00 m)
Highways: 52,250 km total; 5,542 km paved, 16,500 km
gravel, 29,550 km improved earth, remainder unimproved
earth
Inland waterways: part of Lake Victoria and Lake
Rudolph systems are within boundaries of Kenya
Pipelines: refined products, 483 km
Ports: 1 major (Mombasa)
Civil air: 13 major transport aircraft, including 2 leased in
Airfields: 216 total, 194 usable; 12 with permanent-
surface runways; 2 with runways over 3,659 m, 4 with
runways 2,440-3,659 m, 43 with runways 1,220-2,439 m
Telecommunications: in top group of African systems;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; 168,200 telephones (1.1 per 100 popl.); 9
AM, 2 FM, and 4 TV stations; Atlantic and Indian Ocean
satellite service from 1 station
DEFENSE FORCES
Military manpower: males 15-49, 3,463,000; 2,130,000 fit
for military service; no conscription
Military budget: for fiscal year ending 30 June 1980,
$168.6 million; about 8% of central government budget
(See reference mep VII)
LAND
235,690 km''; 21% inland water and swamp, including
territorial waters of Lake Victoria; about 21% cultivated,
13% national parks, forest, and game reserves; 45% forest,
woodland, and grassland
Land boundaries: 2,680 km
Railroads: 1,216 km, meter gauge (1.00 m), single track
Highways: 6,763 km total; 1,934 km paved; 4,829 km
crushed stone, gravel, and laterite; remainder earth roads
and tracks (est.)
Inland waterways: Lake Victoria, Lake Albert, Lake
Kyoga, Lake George, and Lake Edward; Kagera River and
Victoria Nile
Civil air: 4 major transport aircraft
Airfields: 40 total, 36 usable; 5 with permanent-surface
runways; 1 with runways over 3,659 m, 4 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: fair system being rebuilt after war;
radio-relay, wire radio communications stations in use;
46,400 telephones (0.3 per 100 popl.); 9 AM, no FM, 9 TV
stations; 1 Atlantic Ocean INTELSAT station
DEFENSE FORCES
Military manpower: males 15-49, about 2,949,000; about
1,586,000 fit for military service
240','f6e707a2512a99f2de46b2796495ba79f2c35c72028806c6e6aa44f294f26e5a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de8e3b30696aeadf06c53debbd65926e0c1da1cfe4b64270a57c657e4a81dee3',1982,'KW','Kuwait','communications',309,'b , ... V VI
(See reference map VI)
LAND
16,058 km2 (excluding neutral zone but including islands);
insignificant amount forested; nearly all desert, waste, or
urban
Land boundaries: 459 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 499 km
Railroads: none
129
KUWAIT (Continued)
LAOS
Highways: 2,545 km total; 2,255 km bituminous; 290 km
earth, sand, light gravel
Pipelines: crude oil, 877 km; refined products, 40 km;
natural gas, 121 km
Ports: 3 major (Ash Shuwaikh, Ash Shuaybah, Mina al
Ahmadi), 4 minor
Civil air: 19 major transport aircraft, including 2 leased in
Airfields: 10 total, 6 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: excellent international and ade-
quate domestic telecommunication facilities; 153,000 tele-
phones (12.0 per 100 popl); 3 AM, 1 FM, and 3 TV stations;
1 satellite station with Indian and Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, about 383,000; about
232,000 fit for military service
Military budget: for fiscal year ending 30 June 1981,
$1,104 million; 6% of central government budget
(See reference mep IX)
LAND
236,804 km1; 8% agricultural, 60% forests, 32% urban,
waste, and other; except in very limited areas, soil is very
poor; most of forested area is not exploitable
Land boundaries: 5,053 km
Highways: about 21,300 km total; 1,300 km bituminous
or bituminous treated; 5,900 km gravel, crushed stone, or
improved earth; 14,100 km unimproved earth and often
impassable during rainy season mid-May to mid-September
Inland waterways: about 4,587 km, primarily Mekong
and tributaries; 2,897 additional kilometers are sectionally
navigable by craft drawing less than 0.5 m
Ports (river): 5 major, 4 minor
Airfields: 88 total, 76 usable; 12 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 13 with runways
1,220-2,439 m
Telecommunications: service to general public consid-
ered poor; radio network provides generally erratic service
to government users; approx. 10 AM stations; over 2,000 est.
telephones; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 845,000; 453,000 fit for
military service; 40,000 reach military age (18) annually; no
conscription age specified
Lao Peopled Liberation Army (LPLA): the LPLA con-
sists of an army with naval, aviation, and militia elements
131','e10ada32dd53f9599bb5623e0a3309e3857712dad598fc2b9dfaa12fb33d6fc2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38ffca7cea31d5491f3e65ce81f07fbf7c4bc9bcc89a159ae7dbb969ea67a886',1982,'LB','Lebanon','communications',313,'(See reference map VI)
LAND
10,360 km2; 27% agricultural land, 64% desert, waste, or
urban, 9% forested
Land boundaries: 531 km
WATER
Limits of territorial walers (claimed): no specific claims
(fishing, 6 nm)
Coastline: 225 km','a867d3c2fca7a4e829ec5008cf410ff85e7f25e01ff1b17b8f90741ad8ffce61','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c05258a0f013634e99dfbca0ee5f798a6a93ee1e3c2b3ada5d822f90bdf7f35d',1982,'LS','Lesotho','communications',318,'Railroads: 378 km total; 296 km standard gauge (1.435
m), 82 km 1.050-meter gauge; all single track
Highways: 7,370 km total; 6,270 km paved, 450 km
gravel and crushed stone, 650 km improved earth
Pipelines: crude oil, 72 km
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 36 major transport aircraft, including 2 leased
out and 4 leased in
Airfields: 8 total, 6 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 2 with runways
1,220-2,439 m; major military airfields are Riyaq and Kleiat
Telecommunications: rebuilding program disrupted; in-
ternational facilities restored, domestic being rebuilt; fair
system of radio relay, cable; approx 125,000 telephones (5.0
per 100 popl.); 2 FM, 4 AM, and 7 TV stations; 1 Indian
Ocean satellite station; 3 submarine cables; planned second
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 719,000; 443,000 fit for
military service; average of about 40,000 reach military age
(18) annually
Military budget: for fiscal year ending 31 December
1982, $272 million; 26% of central government budget
Indian Ocean
(See reference map VII)
LAND
30,303 km2; 15% cultivable; largely mountainous
Land boundaries: 805 km
Railroads: L6 km; owned, operated, and included in the
statistics of the Republic of South Africa
Highways: appro*, 4,033 km total; 320 km paved; 1,585
km crushed stone, gravel, or stabilized soil; 946 km im-
proved, 2,128 km unimproved earth
Civil air: no major transport aircraft
Airfields: 27 total, 27 usable; 1 with permanent surface
runways; 3 with runways 1,220-2,439 m
Telecommunications: system a modest one consisting of a
few land lines, a small radio- re lay system, and minor radio-
communication stations; 4,500 telephones (0,3 per 100 popL);
2 AM stations and 1 FM station, 1 TV station planned
DEFENSE FORCES
Military manpower: males 15-49, 313,000; 167,000 fit for
military service
134','0644bc3ff0455a861d2943c4925493d905b71fd28f16245d49a3b32f82f1bbbb','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8959257e7b8f36d441c8793eb5ac1a043da5cf736c049a371cb7c9d73a27a4ed',1982,'LR','Liberia','communications',320,'iVOfiV /
COAST J
Atlantic Ocean
(Se
b reference map VII)
LAND
111,370 km2; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 1,336 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 579 km
Railroads: 499 km total; 354 km standard gauge (1.435
m), 145 km narrow gauge (1.067 m); all lines single track; rail
systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
135','5b4c3669ea3e336e85bee32d3e590da54111d011d33cbd63658f0622b1c6bc5b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c1b8ff8bbb0551c2596e8df54d51b0dab96333f793af34402ae2b8a1b775336',1982,'LI','Liechtenstein','communications',327,'\\ n —
3 i\\ I ^
i S
Li FEDERAL REPUBUcV
^^Of GERMANY ^x^/^
[ J AUSTRIA
FRANCE f
/ ITAtY C \\J\\
(See reference map V)
LAND
168 km2
Land boundaries: 76 km','68f8a8a4ac579925e9d39c838584219d324141963db4229fa6c2d65aabd34018','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f60c6a9ac2ee64b6ea8699b25e36c2372fa58e169966519f7f0b37c525b7eba1',1982,'LU','Luxembourg','communications',332,'Railroads: 18.5 km, standard gauge (1.435 m), electrified;
owned, operated, and included in statistics of Austrian
Federal Railways
Highways: 130.66 km main roads, 192.27 km byroads
Civil air: no transport aircraft
Airfields: none
Telecommunications: automatic telephone system serv-
ing about 18,000 telephones (72.0 per 100 popl.); no broad-
cast facilities
DEFENSE FORCES
Defense is responsibility of Switzerland
)
/
?
J
} OF GERMANY
/
t
litxemtxn
fmmt
(See reference map V)
LAND
2,590 km2; 25% arable, 27% meadows and pasture, 15%
waste or urban, 33% forested, negligible amount of inland
water
Land boundaries: 356 km
Railroads: 270 km standard gauge (1.435 m); 160 km
double track; 136 km electrified
Highways: 5,094 km total; 4,981 km paved, 57 km gravel,
56 km earth; about 80 km limited access divided highway
completed or under construction
Inland waterways: 37 km; Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 15 major transport aircraft, including 1 leased in
and 4 leased out
Airfields: 2 total, 2 usable; 1 with permanent-surface
runways; 1 with runways 2,440-3,659 m
Telecommunications: adequate and efficient system,
mainly buried cables; 199,000 telephones (54.8 per 100
popl.); 2 AM, 3 FM, 3 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 96,000; 80,000 fit for
military service; about 3,000 reach military age (19) annually
140
MACAU','8dae8c21c9a5158d5c14b057b5bb3c29f6eafa8d1ae0635f0519096c06f31429','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebbf57d70cf1a0db588c3a408839fe8a92f0f4e9dfae3fef9ee659ff15fa5905',1982,'MG','Madagascar','communications',335,'(See reference map VII)
LAND
595,700 km2; 5% cultivated, 58% pastureland, 21% forest-
ed, 8% wasteland, 2% rivers and lakes, 6% other
WATER
Limits of territorial waters (claimed): 50 nm (fishing 150
nm; exclusive economic zone 150 nm)
Coastline: 4,828 km
Railroads: 884 km of meter gauge (1.00 m)
Highways: 27,500 km total; 4,694 km paved, 811 km
crushed stone, gravel, or stabilized soil; remainder improved
and unimproved earth (est.)
Inland waterways: of local importance only, Lake Alao-
tra, isolated streams and small portions of Canal des
Pangalanes
Ports: 4 major (Tamatave, Diego Suarez, Majunga, Tulear)
Civil air: 7 major transport aircraft, including 1 leased out
Airfields: 172 total, 131 usable; 29 with permanent-
surface runways; 3 with runways 2,440-3,659 m, 45 with
runways 1,220-2,439 m
Telecommunications: fair system, above African average;
includes open-wire lines, coaxial cables, and radio-relay
links; 1 Indian Ocean satellite station; 37,100 telephones (0.4
per 100 popl.); 11 AM, no FM, and 4 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,972,000; 1,206,000 fit
for military service; 84,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1981, $114.4 million; about 10.3% of central government
budget
143','73640edc3ebe7d95e52391c9f1cac806150ca50e5ec15f66417ee85cb12b07c2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59c47a02bc57452451213178e19c43987b34a1aa58fab2cc1e94b94cfff50159',1982,'MW','Malawi','communications',339,'(See reference mep VII)
95,053 km2; about 31% of land area arable (of which less
than half is cultivated), nearly 25% forested, 6% meadow
and pasture, 38% other
Land boundaries: 2,881 km
Ports: 3 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 11 major transport aircraft
Airfields: 95 total, 88 usable; 10 with permanent-surface
runways; 2 with runway 2,440-3,659 m, 45 with runways
1,220-2,439 m
Telecommunications: fair system of open wire, radio
relay, and troposcatter; 88,700 telephones (0.5 per 100 popl.);
5 AM and no FM stations, 1 TV station; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 4,220,000; 2,421,000 fit
for military service
Military budget: for fiscal year ending 30 June 1981, $179
million; 9% of central government budget
(See reference map IX)
LAND
514,820 km*; 24% in farms, 56% forested, 20% other
Land boundaries: 4,868 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 3,219 km
Railroads: 3,830 km meter gauge (1.000 m), 97 km double
track
Highways: 27,498 km total; 21,742 km paved, 5,756 km
crushed stone and soil aggregate
Inland waterways: 3,999 km principal waterways; 3,701
km with navigable depths of 0.9 m or more throughout the
year; numerous minor waterways navigable by shallow-
draft native craft
Ports: 2 major, 16 minor
Civil air: 25 major transport aircraft
Airfields: 162 total, 120 usable; 56 with permanent-
surface runways; 13 with runways 2,440-3,659 m, 27 with
runways 1,220-2,439 m
Telecommunications: service to general public adequate;
bulk of service to government activities provided by multi-
channel cable and radio-relay network; satellite ground
station; domestic satellite system being developed; 451,409
telephones (1.0 per 100 popL); approx. 150 AM, 15 FM, and
10 TV transmitters in government-controlled networks
DEFENSE FORCES
Military manpower: males 15-49, 12,323,000; 7,570,000
fit for military service; about 589,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1982, $1,427 million; 19.5.% of central government budget
231','440563134c062a73630206b8482bd38be686b702c5e36e33fbb0ae84fbda4408','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0178fbb367f600de3415cf9cddd8d39e79c8577a1583fa5d4f7228a355a562da',1982,'MY','Malaysia','communications',344,'Railroads: 754 km 1. 067-meter gauge
Highways: 11,311 km total; 2,361 km paved; 381 km
crushed stone, gravel, or stabilized soil; 8,569 km improved
earth
Inland waterways: Lake Malawi, 1,290 km and Shire
River, 144 km, 3 lake ports
Civil air: 4 major transport aircraft, including 1 leased in
Airfields: 50 total, 47 usable; 3 with permanent-surface
runways; 1 with runways 2,440-3,659 m; 9 with runways
1,220-2,439 m
Telecommunications: fair system of open-wire lines,
radio-relay links, and radiocommunications stations; 28,800
telephones (0.5 per 100 popl.); 8 AM, 4 FM, and no TV
stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,348,000; about
683,000 fit for military service
(See reference map IX)
NOTE: established on 16 September 1963, Malaysia con-
sists of Peninsular Malaysia, which includes 11 states of the
former Federation of Malaya, plus East Malaysia, which
includes the 2 former colonies of North Borneo (renamed
Sabah) and Sarawak
LAND
Peninsular Malaysia: 131,313 km2; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 76,146 km2; 13% cultivated, 34% forest reserves,
53% other
Sarawak: 125,097 km2; 21% cultivated, 24% forest re-
serves, 55% other
Land boundaries: 509 km Peninsular Malaysia, 1,786 km
East Malaysia
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm, exclusive economic zone 200 nm)
Coastline: 2,068 km Peninsular Malaysia, 2,607 km East
Railroads:
Peninsular Malaysia: 1,665 km 1.04-meter gauge; 13
km double track; government owned
East Malaysia: 136 km meter gauge (LOO m) in Sabah
Highways:
Peninsular Malaysia: 19,753 km total; 15,900 km hard
surfaced (mostly bituminous surface treatment), 3,000 km
crushed stone/gravel, 883 km improved or unimproved
earth
East Malaysia: about 5,426 km total (1,644 km in
Sarawak, 3,782 km in Sabah); 819 km hard surfaced (mostly
bituminous surface treatment), 2,936 km gravel or crushed
stone, 1,671 km earth
Inland waterways:
Peninsular Malaysia: 3,209 km
East Malaysia: 4,200 km (1,569 km in Sabah, 2,518 km
in Sarawak)
Ports:
Peninsular Malaysia: 3 major, 14 minor
East Malaysia: 3 major, 12 minor (2 major, 3 minor in
Sabah; 1 major, 9 minor in Sarawak)
Civil air: approximately 30 major transport aircraft
Pipelines: crude oil, 69 km; refined products, 56 km
Airfields:
Peninsular Malaysia: 61 total, 61 usable; 17 with
permanent-surface runways; 3 with runways 2,440-3,659 m,
11 with runways 1,220-2,439 m
Sabah: 35 total, 35 usable; 6 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 4 with runways
1,220-2,439 m
Sarawak: 47 total, 47 usable; 5 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications:
Peninsular Malaysia: good intercity service provided
mainly by microwave relay; international service good; good
coverage by radio and television broadcasts; 305,000 tele-
phones (2.9 per 100 pop].); 26 AM, 1 FM, and 16 TV stations;
submarine cables extend to Singapore; connected to SEA-
COM submarine cable terminal at Singapore by microwave
relay; 2 ground satellite stations
147','251f252b2e1c8ed746f6549f2f00db614cf0168f3c5e19cee5ede9230bec7e18','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78ddcfbf1fc542162e9ce23b947acdf7ee0983b9b37e27fca3cc95e6821bf515',1982,'MV','Maldives','communications',347,'MALAYSIA (Continued)
Sabah: adequate intercity radio-relay network extends
to Sarawak via Brunei; 36,000 telephones (2.8 per 100 popl.);
14 AM, 1 FM, 5 TV stations; SEACOM submarine cable
links to Hong Kong and Singapore; 1 ground satellite station
Sarawak: adequate intercity radio-relay network ex-
tends to Sabah via Brunei; 40,000 telephones (2.5 per 100
popl.); 5 AM stations, no FM, and 6 TV stations
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males 15-49, 2,993,000;
1,901,000 fit for military service; 135,000 reach military age
(21) annually
Sabah: males 15-49, 278,000; 165,000 fit for military
service; 13,000 reach military age (21) annually
Sarawak: males 15-49, 351,000; 209,000 fit for military
service; 15,000 reach military age (21) annually
External defense dependent on loose Five Power Defense
Agreement (FPDA) which replaced Anglo-Malayan Defense
Agreement of 1957 as amended in 1963
Military budget: for fiscal year ending 31 December
1982, $2,928.3 million; about 21.1% of central government
budget
Indian Ocean
(See reference map VUl)
LAND
298 km2; 2,000 islands grouped into 12 atolls; about 220
islands inhabited
WATER
Limits of territorial waters (claimed): the land and sea
between latitudes 7°9''N and 0°45''S and between longitudes
72°30''E and 73°48''E; these coordinates form a rectangle of
approximately 37,000 nm2; territorial sea ranges from 2.75 to
55 nm; fishing, approximately 100 nm; economic, approxi-
mately 200 nm
Coastline: 644 km (approx.)','a06b787321b3ad4813b8a3a26c86ef29ce7727f02c39cab1994ce3f56744ffec','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd9893f44a93a780e3672790f4f5f894bd47edff4acd5a50bf6d912020516bba',1982,'ML','Mali','communications',352,'Railroads: none
Highways: none
Ports: 2 minor (Male, Gan)
Civil air: 1 major transport aircraft, leased in
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: minimal domestic and international
telecommunication facilities; 550 telephones (0.4 per 100
popl.); 2 AM stations, 1 TV station; 1 Indian Ocean INTEL-
SAT station
^ ALGERIA \\
i MAURITANIA
Wi J m™
\\7\\i IV0RV / || f
Atlantic
Ocean
(See reference map Vlt)
LAND
1,204,350 km2; only about a fourth of area arable, forests
negligible, rest sparse pasture or desert
Land boundaries: 7,459 km
Railroads: 642 km meter gauge (LOO m)
Highways: approximately 15,700 km total; 1,670 km
bituminous, 3,670 km gravel and improved earth, 10,360 km
unimproved earth
Inland waterways; lT8!5 km navigable
Civil air: % major transport aircraft
Airfields: 44 total, 39 usable; 8 with permanent-surface
runways; 5 with runways 2,440-3,659 m. 10 with runways
1,220-2,439 m
Telecommunications: domestic system poor and provides
only minimal service; radio- relay, wire, and radiocommuni-
cations stations in use; expansion of radio relay in progress;
8,000 telephones; 2 AM, no FM, and no TV stations; 2
antennas for Atlantic and Indian Ocean INTELSAT
satellites
DEFENSE FORCES
Military manpower: males 15-49, 1,521.000; 767,000 fit
for military service; no conscription
150','365da5e0f1b02a185c309b8c7d1968ab8124b9a68d2dd1993eae5de9f9c737c1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1577079ed4eb384bf28a1540f4c50b7cac1ccf04f27910bf34af1e8e51a0f405',1982,'MT','Malta','communications',354,'» MAtTA
#
Mediterranean Sae
mm
(See reference map V)
LAND
313 km2; 45% agricultural, negligible amount forested,
remainder urban, waste, or other (1965)
WATER
Limits of territorial waters (claimed): 12 nm (fishing 25
nm)
Coastline: 140 km','da435d67dd08f097f0a09580a391f48805b8bf1eb9e56b6a0335aa345abb9b77','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('506f803a6360e0d1d2ceee0ec801546e7e2a3452e079db4a923ccbe339a2d568',1982,'MQ','Martinique','communications',358,'Highways: 1,285 km total; 1,173 km paved (asphalt), 77
km crushed stone or gravel, 35 km improved and unim-
proved earth
Ports: 1 major (Valletta), 2 minor
Civil air: 8 major transport aircraft, including 3 leased in
Airfields: 1 with permanent-surface runways, 2,440-3,659 m
Telecommunications: modern automatic telecom system
centered in Valletta; 78,900 telephones (25.3 per 100 popl.);
2 TV, 2 AM, and 5 FM stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 80,000; 66,000 fit for
military service
Supply: various facilities and equipment turned over by
the UK in 1965; has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment from','ba83f5b6e4900aa8a5f14571749e752aba63fe049b004c72a7943f8d37040c7e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bd8c7969eaf576065a6a633b2fe3dd5a9a10480d50d5479044445f63b50380f',1982,'MU','Mauritius','communications',359,'MAURITANIA (Continued)
Highways: 7,540 km total; 1,350 km paved; 710 km
gravel, crushed stone, or otherwise improved; 5,480 km
unimproved
Inland waterways: 800 km
Ports: 2 major (Nouadhibouand and Nouakchott), 2 minor
Civil air: 5 major transport aircraft
Airfields: 31 total, 31 usable; 9 with permanent-surface
runways; 4 with runways 2,440-3,659 m; 14 with runways
1,220-2,439 m
Telecommunications: poor system of cable and open-
wire lines, a minor radio-relay link, and radiocommunica-
tions stations; 3,000 telephones (0.2 per 100 popl.); 2 AM, no
FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 337,000; 164,000 fit for
military service; conscription law not implemented
Supply: primarily dependent on France; has also received
material from Algeria, Morocco, UK, Spain, and Romania
Military budget: for fiscal year ending 31 December
1981, $60.0 million; 26.0% of central government budget
f / MADAGASt
AH f MAURITIUS
W REUNION
Indian Ocean
(See reference map Vll)
LAND
1,856 km2 (excluding dependencies); 50% agricultural,
intensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5% water
bodies, 2% roads and tracks, 1% permanent wastelands
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 177 km
Highways: 1,786 km total; 1,636 km paved, 150 km earth
Ports: 1 major (Port Louis)
Civil air: 1 major transport aircraft, leased in
Airfields: 5 total, 4 usable; 1 with permanent surface
runways; 1 with runways 2,440-3,659 m
Telecommunications: small system with good service; HF
radio links to several countries; 1 AM, no FM, and 4 TV
stations; 36,400 telephones (4.0 per 100 popl.); 1 Indian
Ocean INTELSAT station
DEFENSE FORCES
Military manpower: males 15-49, 259,000; 135,000 fit for
military service
Military budget: for fiscal year ending 30 June 1981, $4.5
million
156','5a53663105fa7ec552b65eeb0ece951aac6a9e230c372d9e89d2641382074c10','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('747accb6d083b1d9adabe26d4ba47969ae1efa114585334c9abddd114a14dedc',1982,'MX','Mexico','communications',363,'UNITED STATES . : ; : jT
V A
^ \\ MEXICO,
\\ Gulf of
Me/ice
? ^
EUZE
Pacific Ocean
SaATEMAU^
(See reference map II)
LAND
1,978,800 km2; 12% cropland, 40% pasture, 22% forested,
26% other (including waste, urban areas and public lands)
Land boundaries: 4,220 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: 9,330 km','8b419368c53da22b7a88fee0093bf9459fded623bfbc0420eebb23f7fd11894b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7a8d768178599f9e7b39ced0bddf0581b840ededc47cb8884a9236c462b1ff0',1982,'MC','Monaco','communications',368,'Railroads: 20,270 km total; 19,380 km standard gauge
(1.435 m); 890 km narrow gauge (0.914 m); 20 km electrified;
20,160 km government owned, 110 km privately owned
Highways: 213,190 km total; 66,375 km paved, 119,050
km otherwise improved, 27,765 km unimproved
Inland waterways: 2,900 km navigable rivers and coastal
canals
Pipelines: crude oil, 3,910 km; refined products, 3,490
km; natural gas, 5,710 km
Ports: 12 major, 19 minor
Civil air: 134 major transport aircraft, including 6 leased in
Airfields: 2,196 total, 2,060 usable; 164 with permanent-
surface runways; 2 with runways over 3,659 m, 21 with
runways 2,440-3,659 m, 291 with runways 1,220-2,439 m
Telecommunications: highly developed telecom system
with extensive radio-relay links; connection into Central
American microwave net; 1 Atlantic Ocean satellite ground
station; 3.71 million telephones (5.6 per 100 popl.); 574 AM,
109 FM, and 83 TV stations; and about 100 low-power relay
stations; second satellite station planned
DEFENSE FORCES
Military manpower: males 15-49, 16,358,000; 12,971,000
fit for military service; reach military age (18) annually,
810,000
Military budget: for year ending 31 December 1981,
$1,656.0 million; 2.3% of central government budget
(See reference map V)
LAND
1.5 km2
Land boundaries: 3.7 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4.1 km','d1e20a1074f57c7f9d36ab5839b85a2d60531c366c704c117aa4c02eea40f472','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('585cc3ba1a5cdc51893d8dfb27fd86ff17820c1035816c72b271256005836e36',1982,'MN','Mongolia','communications',373,'Railroads: 1.6 km of 1.435 m gauge
Highways: none; city streets
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: none
Telecommunications: served by the French communica-
tions system; automatic telephone system with about 28,800
telephones (115.2 per 100 popl.); 2 AM, 4 FM, and 4 TV
stations
DEFENSE FORCES
France responsible for defense
(See reference map VIII)
LAND
1,564,619 km2; almost 90% of land area is pasture or desert
wasteland, varying in usefulness, less than 1% arable, 10%
forested
Land boundaries: 8,000 km','e21fe2948d8bf7587df5e7cb47c1d4ec527248920de8c807b3cf5cdff884ad7c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b905a8f344b52123defc5835a7a0c1c86ae0c83b3e9003dc954079bf2bac696f',1982,'MA','Morocco','communications',377,'Railroads: 1,585 km (1979); all broad gauge (1.524 m)
Highways: 83,280 km total; 400 km concrete, asphalt;
9,920 km crushed stone, gravel; 72,960 km earth (1975)
Inland waterways: 397 km of principal routes (1979)
Freight carried: rail — 9.0 million metric tons, 3,126 mil-
lion metric ton/km (1979); highway— 20.3 million metric
tons, 1,342 million metric ton/km (1979); waterway — 0.04
million metric tons, 5.4 million metric ton/km (1979)
DEFENSE FORCES
Military manpower: males 15-49, 396,000; 259,000 fit for
military service; about 18,000 reach military age (18)
annually
Supply: military equipment supplied by USSR
Military budget: for fiscal year ending 31 December
1977, 405 million tugriks, 12% of total budget
portugaI? SpA)N
f *
At /antic \\1 j
Ocean s
MOROCCO^
*° * r^.Jj
AlGSfUA j
SAHARA J f^v
< MAURtTANfA j
(See reference map VII)
LAND
409,200 km1; about 32% arable and grazing land, 17%
forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,996 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 1,835 km
Railroads: 1,756 km standard gauge (1.435 m), 161 km
double track; 708 km electrified
Highways: 55,970 km total; 24,700 km bituminous treat-
ed, 4,000 km gravel, crushed stone, and improved earth,
27,270 km unimproved earth
Pipelines: 362 km crude oil; 491 km (abandoned) refined
products; 241 km natural gas
Ports: 8 major (including Spanish-controlled Ceuta and
Melilla), 10 minor
Civil air: 20 major transport aircraft, including 1 leased in
Airfields: 81 total, 76 usable; 25 with permanent-surface
runways; 2 with runways over 3,659 m, 14 with runways
2,440-3,659 m, 29 with runways 1,220-2,439 m
Telecommunications: good system composed of wire
lines, cables, and radio-relay links; principal centers Casa-
blanca and Rabat, secondary centers Fes, Marrakech, Oujda,
Tangier and Tetouan; 210,000 telephones (1.1 per 100 popl.);
25 AM, 7 FM, and 27 TV stations; 5 submarine cables; 1
Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 4,780,000; 2,950,000 fit
for military service; about 248,000 reach military age (18)
annually; limited conscription
161','2739d61c58992c9b592b53f0517c40aa5c01863d6a0aad1de7bd01923e6fa1bb','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a467dc79f166dba43756fa6828c98bdc755ad4b732e261f9691fabb32972a2d1',1982,'MZ','Mozambique','communications',379,'(See reference mep VII)
Land
786 ,762 km2; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries: 4,627 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 2,470 km
Railroads: 3,436 km total; 3,288 km 1.067-meter gauge;
148 km narrow gauge (0.750 m)
Highways: 26,498 km total; 4,593 km paved; 829 km
gravel, crushed stone, stabilized soil; 21,076 km unimproved
earth
Inland waterways: approx. 3,750 km of navigable routes
Pipelines: crude oil, 306 km (not operating); refined
products, 280 km
Ports: 3 major (Maputo, Beira, Nacala), 2 significant
minor
Civil air: 16 major transport aircraft, including 2 leased in
Airfields: 292 total, 247 usable; 29 with permanent-
surface runways; 5 with runways 2,440-3,659 m; 37 with
runways 1,220-2,439 m
Telecommunications: fair system of troposcatter, open-
wire lines, and radio relay; 51,600 telephones (0.5 per 100
popl.); 10 AM, 2 FM, no TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,763,000; 1,633,000 fit
for military service
Supply: mostly from the USSR and PRC, and to a lesser
extent from other Communist countries and Portugal
Military budget: for fiscal year ending 31 December
1980, $157.8 million; 27.8% of central government budget
162','8ca8ca4c5dc334aacfa75f68c8df37c2c27b3f5b179f7ba502a84dc4a5313cbe','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0a9028a8cdb4d930df1b1d4d7be7019388d109dad749ee429d0cf6ad73e0a65',1982,'NA','Namibia','communications',383,'(South-West Africa)
(See reference map VH)
LAND
823,620 km*; mostly desert except for interior plateau and
area along northern border
Land boundaries: 3,798 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,489 km','50887c43e5626cfa9cd52e5b9a36219e5998731aaea959dd263380576465fbb8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d0c7902d2879b44f3556807ba755a58992605d4942b191cdae9087a16b8bca3',1982,'NR','Nauru','communications',388,'Railroads: 2,340 km 1.067-meter gauge, single track
Highways: 54,500 km; 4,079 km paved, 2,540 gravel,
remainder earth roads and tracks
Ports: 2 major (Walvis Bay and Luderitz)
Civil air: 4 major transport aircraft
Airfields: 128 total, 102 usable; 17 with permanent-
surface runways; 1 with runways over 3,659 m; 3 with
runways 2,440-3,659 m, 42 with runways 1,220-2,439 m
Telecommunications: good urban, fair rural services;
radio relay connects major towns, wires extend to other
population centers; 50,300 telephones (5.2 per 100 popl.); 11
FM, no TV stations; AM and TV stations under construction
DEFENSE FORCES
Military manpower: males 15-49, about 239,000; about
141,000 fit for military service
Defense is responsibility of Republic of South Africa;
however, a Southwest African Territory Force was estab-
lished 1 August 1980
Military budget: for fiscal year ending 31 March 1982,
$63.1; 6.7% of central government budget
NAURU*
(See reference map X)
LAND
21.2 km1; insignificant arable land, no urban areas, exten-
sive phosphate mines
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 24 km','1f700837692586af672ca4d5b5c825c00860e054003741a86498c7a30d0dee0d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('371b588c3818a0da418df3e75f9a5fcc034addaa2ece9f0832646e11e25b7411',1982,'NP','Nepal','communications',393,'Railroads: none
Highways: about 27 km total; 21 km paved, 6 km
improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 3 major transport aircraft, one on order
Airfields: 1 with runways over 1,220-2,439 m
Telecommunications: adequate intraisland and interna-
tional radiocommunications provided via Australian facili-
ties; 1,500 telephones (20.8 per 100 popl.); 3,600 radio
receivers, 1 AM, no FM or TV stations; 1 ground satellite
station
DEFENSE FORCES
Military manpower: males 15-49, about 1,800; fit for
military service, about 1,000; less than 100 reach military
age (18) annually, 1978-82,
No formal defense structure and no regular armed forces
(See reference map VIII)
LAND
141,400 km2; 16% agricultural area, 14% permanent
meadows and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested
Land boundaries: 2,800 km
Railroads: 63 km (1977), all narrow gauge (0.762 m); all in
Terai close to Indian border; 10 km from Raxaul to Biranj is
government owned
Highways: 4,136 km total; 1,751 km paved, 556 km
gravel or crushed stone, 1,829 km improved and unim-
proved earth; additionally 322 km of seasonally motorable
tracks
Civil air: 5 major transport aircraft
Airfields: 47 total, 46 usable; 5 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 7 with runways
1,220-2,439 m
Telecommunications: poor telephone and telegraph serv-
ice; fair radiocommunication and broadcast service; interna-
tional radiocommunication service is poor; 10,000 telephones
(less than 0.1 per 100 popl.); 3 AM, no FM, and no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 3,704,000; 1,919,000 fit
for military service; 176,000 reach military age (17) annually
Military budget: for fiscal year ending 14 July 1981,
$22.1 million; 5.4% of central government budget
166','4e418a86118e7dfd69e5e14c4307abeafd48411938b0f0ee56fccbaec6f55e54','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eda50e3630e1935a4b60e510b77499651213db8f9a5e61e2b9fe03cd6fb42d4',1982,'NL','Netherlands','communications',395,'(See reference map V)
LAND
33,929 km2; 70% cultivated, 5% waste, 8% forested, 8%
inland water, 9% other
Land boundaries: 1,022 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 451 km
Railroads: 3,046 km standard gauge (1.435 m); 2,880 km
government owned (NS), 1,759 km electrified, 1,588 km
double track; 166 km privately owned
Highways: 107,300 km total; 90,600 km paved (including
2,106 km of limited access, divided highways); 16,700 km
gravel, crushed stone
Inland waterways: 6,340 km, of which 35% is usable by
craft of 900 metric ton capacity or larger
Pipelines: 418 km crude oil; 965 km refined products;
9,886 km natural gas
Ports: 8 major, 6 minor
Civil air: 95 major transport aircraft, including 4 leased in
and 11 leased out
Airfields: 29 total, 28 usable; 17 with permanent-surface
runways; 13 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: highly developed, well maintained,
and integrated; extensive system of multiconductor cables,
supplemented by radio-relay links; 6.80 million telephones
(48.3 per 100 popl.); 6 AM, 33 FM, and 29 TV stations; 9
coaxial submarine cables; 1 satellite station with 1 Atlantic
Ocean and 1 Indian Ocean antenna
DEFENSE FORCES
Military manpower: males 15-49, 3,853,000; 3,275,000 fit
for military service; 128,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1982, $4.5 billion; about 9.5% of central government budget
168
NETHERLANDS ANTILLES
,00m. Atlantic Ocean
NETHERLANDS *
Caribbean
ANTILLES V
Sea
V__^ VENC2UEU ?\\
L COtDMBlA I S f
(See reference map III)
LAND
1,020 km2; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 nm, fishing 200
nm
Coastline: 364 km','c99e199625ccc3be1ba1a32ab8aad72324aa2089634cc7508d9ad5fc5df4ed88','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dde3dc991e3663d06780a5803d87f0c3d5ca15b80ea1c8819307eca5ccc60680',1982,'NC','New Caledonia','communications',400,'Railroads: none
Highways: 950 km total; 300 km paved, 650 km gravel
and earth
Ports: 4 major (Willemstad, Oranjestad, Caracasbaai, Bul-
lennbaai); 6 minor
Civil air: 10 major transport aircraft, including 3 leased in
Airfields: 7 total, all usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: generally adequate telecom facili-
ties; extensive interisland radio-relay links; 53,000 telephones
(21.1 per 100 popl.); 11 AM, 2 FM and 5 TV stations; 2
submarine cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000 fit for
military service; about 2,600 reach military age (20) annually
Defense is responsibility of the Netherlands
(See reference map X)
LAND
22,015 km*; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 2,254 km','3357b08afd5bf0b3b29f02facd500e8f7777894aeab031312b6d2544a61f8b37','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa0c7937d081b99cd7c0a4601afd23988b62093ec8f1521c112ac53f057d2806',1982,'NZ','New Zealand','communications',405,'Railroads: none
Highways: 5,448 km total (1977); 558 km paved, 2,251
km improved earth, 2,639 km unimproved earth
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air: no major transport aircraft
Airfields: 31 total, 30 usable; 4 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: 23,000 telephones (17.0 per 100
popl.); 5 AM, no FM, and 7 TV stations; 1 earth satellite
station
HU>> i nHUn
Coral Sea
V
7 Tasman
/ Sea
m
Pacific
Qt.pan
NEW
ZEALAND
<J
y Wellinflton
(See
reference map X)
LAND
268,276 km1; 3% cultivated, 50% pasture, 10% parks and
reserves, 1% urban, 16% forested, and 20% waste, water, or
other; 4 principal islands, 2 minor inhabited islands, several
minor uninhabited islands
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: about 15,134 km
Railroads: 4,716 km total (1980); all 1.067-meter gauge;
274 km double track; 113 km electrified; over 99% govern-
ment owned
Highways: 92,617 km total (1977); 46,716 km paved,
45,901 km gravel or crushed stone
Inland waterways: 1,609 km; of little importance to','2111ea6de0343869b51966966d37361bf0bfa2875b1138b717cbd01b06dbe603','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3307a68c2beabbbc716523014155fbb64434f98615c835de5bb0c806276b5334',1982,'NI','Nicaragua','communications',412,'Railroads: 344 km 1.067-meter gauge, government owned
Highways: 24.126 km total; 1,654 km paved, 2,711 km
gravel or crushed stone, 5,427 km earth or graded earth,
14,334 km unimproved
Inland waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil, 56 km
Ports: 1 major (Corinto), 7 minor
Civil air: 7 major transport aircraft
Airfields: 349 total, 326 usable; 9 with permanent -surface
runways; 11 with runways 1.220-2.439 m
Telecommunication*: low-capacity radio- relay and wire
system being replaced after war damage; connection into
Central American microwave net; Atlantic Ocean INTEL-
SAT station. .55,800 telephones (2.2 per 100 popl ); 85 AM, 30
FM, and 6 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 573,000; 353,000 fit for
military service; 30,000 reach military age (18) annually
174','fa27eeb722cb4901631ae1a8a606f6780c9f1c53bce4042ffab4eb5bcacef3cb','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('127799bf5b8f179e873dbe6ddfd404b76a7068e7a41b16d46dad023cba75ac2a',1982,'NE','Niger','communications',413,'(See reference map VII)
LAND
1,266,510 km1; about 3% cultivated, perhaps 20% some-
what arable, remainder desert
Land boundaries: 5,745 km','6eeeb5520f3818bdffdb9689a6400b11d0cc4aeb1c3df5a08232b9542f5b3d35','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feaed1cdf836f1a494ef3e019ec48f742b7697e21c25b50d3d507bb1b6e03cc3',1982,'NO','Norway','communications',417,'(See referenca map V)
LAND
Continental Norway, 323,750 km2; Svalbard, 62,160 km2;
Jan Mayen, 373 km2; 3% arable, 2% meadows and pastures,
21% forested, 74% other
Land boundaries: 2,579 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm; 200 nm exclusive economic zone)
Coastline: mainland 3,419 km; islands 2,413 km (excludes
long fjords and numerous small islands and minor indenta-
tions which total as much as 16,093 km overall)
Railroads: 4,257 km standard gauge (1.435 m); Norwegian
State Railways (NSB) operates 4,241 km (2,440 km electrified
and 91 km double track); 16 km privately owned and
electrified
Highways: 78,116 km total; 17,699 km concrete and
bitumen; 19,277 km bituminous treated; 41,140 km gravel,
crushed stone, and earth
Inland waterways: 1,577 km; 1.5-2.4 m draft vessels
maximum
Pipelines: refined products, 53 km
Ports: 9 major, 69 minor
Civil air: 51 major transport aircraft
Airfields: 103 total, 102 usable; 52 with permanent-
surface runways; 12 with runways 2,440-3,659 m, 15 with
runways 1,220-2,439 m
Telecommunications: high-quality domestic and interna-
tional telephone, telegraph, and telex services; 1.73 million
telephones (42.3 per 100 popl-); 40 AM, 685 FM, and 1,320
TV stations; 5 coaxial submarine cables; 6 domestic satellite
stations
DEFENSE FORCES
Military manpower: males 15-49, 1,002,000; 815,000 fit
for military service; 33,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31
December 1982, $1.3 billion; about 8.8% of proposed central
government budget
„ Nortli ? /
i I UcNMAH
A\\ J
IRELAf?
UNITED
Ip IjKINGDOM, ^
7 \\
> V
Atlantic
Ocean
\\, F RANCH ^
(See reference map V)
LAND
243,978 km*; 30% arable, 50% meadow and pasture, 12%
waste or urban, 7% forested, 1% inland water
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 12,429 km
Railroads: Great Britain— 17,754 km total; British Rail-
ways (BR) operates 17,735 km standard gauge (1.435 m)
(3,718 km electrified, 12,708 km double or multiple track),
and 19 km 0.597-meter gauge; several additional small
standard gauge and narrow gauge lines are privately owned;
Northern Ireland Railways (N1R) operates 357 km 1.600-
meter gauge, 190 km double track
Highways: United Kingdom, 361,491 km total; Great
Britain, 337,992 km paved (including 2,485 km limited-
access divided highway); Northern Ireland, 23,499 km
(22,907 paved, 592 km gravel)
Inland waterways: 3,219 km publicly owned; 605 km
major commercial routes
Pipelines: 933 km crude oil, almost all insignificant; 2,907
km refined products; 1,770 km natural gas
Ports: 23 major, 350 minor
Civil air: 570 major transport aircraft, including 5 leased
in and 16 leased out
Airfields: 630 total, 390 usable; 253 with permanent-
surface runways; 1 with runways over 3,659 m, 38 with
runways 2,440-3,659 m, 145 with runways 1,220-2,439 m
Telecommunications: modern, efficient domestic and
international system; 26.8 million telephones (48.0 per 100
popl.); excellent countrywide broadcast; 97 AM, 330 FM,
and 1,680 TV stations; 31 coaxial submarine cables; 2 earth
satellite stations with a total of 5 antennas
DEFENSE FORCES
Military manpower: males 15-49, 13,767,000; 11,680,000
fit for military service; no conscription; 476,000 reach
military age (18) annually
Military budget: proposed for fiscal year ending 31
March 1982, $24.1 billion; about 15% of central government
budget
243','1ceaf4617324d52db42a537083d49b4d95bfbfc70002f81f1666e89396a60b65','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43f9fd6e42ef59add2b80b64596dc4eed3b85312afe0808458d48d3faae2909a',1982,'OM','Oman','communications',421,'(See reference map VI)
About 212,380 km2; negligible amount forested, remain-
der desert, waste, or urban
Land boundaries: 1,384 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; exclusive economic zone 200 nm)
Coastline: 2,092 km','c57765b365c40498aaca44d0d5c1695d008f5c1663f1f4c29cc7c323c7792792','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('420e20fbb8a6fa046a5f22c59517d0dcab8a88f1e1c7ccd7c7fe83e271650922',1982,'PK','Pakistan','communications',426,'Highways: 2,816 km total; 5 km bituminous surface,
2,811 km motorable track
Pipelines: crude oil 960 km; natural gas 390 km
Ports: 1 major (Qaboos), 3 minor
Civil air: 23 major transport aircraft, including 7 leased in
and 1 leased out
Airfields: 195 total, 143 usable; 5 with permanent-surface
runways; 1 with runways over 3,659 m, 4 with runways
2,440-3,659 m, 56 with runways 1,220-2,439 m
Telecommunications: fair system of open-wire, radio-
relay, and radiocommunications stations; 13,000 telephones
(0.9 per 100 popl.); 3 AM, no FM, 11 TV stations; 1 Indian
Ocean satellite station, 6 domestic antennas
DEFENSE FORCES
Military manpower: males 15-49, 213,000; 123,000 fit for
military service
Military budget: for fiscal year ending 31 December
1981, $1.7 billion; 41% of central government budget
Y p SOVIET UNION','e422e20d5658c952a7b94a3b4b604f764af205fdd5dbc076575a99ff881e6211','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c9fbf911494096e2a749f01e249101bba025404a9b00071cc7615509f96d1de',1982,'PA','Panama','communications',427,'I
Caribbean Sea
(CGsTav
Pacific Ocean
V COLOMBIA i
(See reference mep III)
LAND
75,650 km* (excluding Canal Zone, 1,430 km1); 24%
agricultural land (9% fallow, 4% cropland, 11% pasture), 20%
exploitable forest, 56% other forests, urban, and waste
Land boundaries: 630 km
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf including sovereignty over superjacent waters)
Coastline: 2,490 km
Railroads: 192 km total; 78 km 1.524-meter gauge, 114
km 0.9 14- meter gauge
Highways: 8,400 km total; 2,715 km paved, 3,170 km
gravel or crushed stone, 2,515 km improved and unim-
proved earth
Inland waterways: 800 km navigable by shallow draft
vessels; 82 km Panama Canal
Pipelines: refined products, 96 km
Ports: 2 major (Cristobal/ Colon /Coco Solo, Balboa/
Panama City), 10 minor
Civil air: 16 major transport aircraft, including 1 leased in
Airfields: 151 total, 150 usable; 39 with permanent-
surface runways; 2 with runways 2,440-3,659 m; 16 with
runways 1,220-2,439 m
Telecommunications: domestic and international telecom
facilities well developed; connection into Central American
microwave net; Atlantic Ocean satellite ground station;
157,000 telephones (8 4 per 100 popl); 90 AM, 30 FM, and
13 TV stations; 1 coaxial submarine cable
'' DEFENSE FORCES
Military manpower: males 15-49, 499,000; 344,000 fit for
military service; no conscription
IH3','72f83747b2f3e96a03b2e09b4f5dd8d7de5c176e1fecd4dc06136c1573f4c66f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32affb8c866bca4db4b1bd5405f7f678be84d8b6ab0e93013b55eff627115f2b',1982,'PG','Papua New Guinea','communications',431,'(See reference map X)
LAND
475,369 km2
Land boundaries: 966 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: about 5,152 km
Railroads: none
Highways: 19,200 km total; 640 km paved, 10,960 km
gravel, crushed stone, or stabilized soil surface, 7,600 km
unimproved earth
Inland waterways: 10,940 km
Ports: 5 principal, 9 minor
184','c8b964c8fa94dc1c2ce2a2cc51fe7c6e5f6c5b135ded32421b5a0e0546d1aab0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fa920d2bd676bf37bc68a6cc2d14a0d8e6c51119cbf4c9f7a234fa57b138a24',1982,'PY','Paraguay','communications',435,'PAPUA NEW GUINEA (Continued)
Civil air: about 15 major transport aircraft
Airfields: 535 total, 433 usable; 18 with permanent-
surface runways; 2 with runways 2,440-3,659 m; 41 with
runways 1,220-2,439 m
Telecommunications: Papua New Guinea telecom serv-
ices are adequate and are being improved; facilities provide
radiobroadcast, radiotelephone and telegraph, coastal radio,
aeronautical radio and international radiocommunication
services; submarine cables extend from Madang to Australia
and Guam; 45,274 telephones (1.5 per 100 popl.); 31 AM, no
FM and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 748,000; about 413,000
fit for military service
Supply: dependent on Australia
Military budget: for fiscal year ending 30 June 1982,
$33.6 million; 3.0% of central government budget
BOLIVIA
BfiAZiL
Lf^^^W R A G UAV\\
AliSSNTtKA j(
'' Atlantic Ocean
(See reference map IV)
LAND
406,630 km2; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 3,444 km
Railroads: 970 km total; 440 km standard gauge (1.435
m), 60 km meter gauge (1.00 m), 470 km various narrow
gauge (privately owned)
Highways: 13,460 km total; 1,370 km paved, 12,090 km
gravel or earth
Inland waterways: 3,100 km
Ports: 1 major (Asuncion), 9 minor (all river)
Civil air: 14 major transport aircraft
Airfields: 955 total, 818 usable; 5 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 21 with runways
1,220-2,439 m
Telecommunications: principal center in Asuncion, fair
intercity microwave net; 51,600 telephones (1.5 per 100
popl.); 33 AM, 14 FM, and 3 TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 775,000; 615,000 fit for
military service; 40,000 reach military age (17) annually
Military budget: for fiscal year ending 31 December
1981, $87.6 million; 16.2% of central government budget
186','02d766daf3e27de0065fc15081621076bb50acaebcc4b93bf68c40ac57a45193','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf359b4542711dae0dc3a9042f837e40eb96bf610b84f5c8d8df88e823759970',1982,'PE','Peru','communications',439,'} COLOMBIA >
B8AZJI
\\PERU (
Pacific
VLimi V
Ocean
BOLIVIA W !
(See reference map IV)
LAND
1,284,640 km2 (other estimates range as low as 1,248,380
km2); 2% cropland, 14% meadows and pastures, 55% forest-
ed, 29% urban, waste, other
Land boundaries: 6,131 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,414 km','bd51b6025e5599a864dc598581e107362a065d22cd70a19e701021e217eb36b8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9857c7efabd1230ee2ede8b2d93e1f499833d8bbf8b38ae33d832452d80f42e',1982,'PL','Poland','communications',443,'I"/ Q j\\.
1 j
L/QO^ Baltic Set \\
} 6£R 1 Warsaw.
> _S POLAND
SOVIET
\\ UNION
J V_~**< HUNGARY / \\ <
(See
reference map V)
LAND
312,354 km2; 49% arable, 14% other agricultural, 27%
forested, 10% other
Land boundaries: 3,090 km
WATER
Limits of territorial waters (claimed): 12 nm (6 nm
contiguous zone claimed in addition to the territorial sea;
fishing 12 nm, lateral limits based on geographical
coordinates)
Coastline: 491 km','83e85f459eacf2c9a3ed56ac41876968925ce3767f89455d2999297565f29265','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('058e1a1514dd4e425ac0162e3fdfed223f223c385f282baf8281785bd4c4fbd7',1982,'PT','Portugal','communications',448,'Railroads: 27,236 km total; 24,380 km standard gauge
(1.435 m), 2,856 km other gauge; 7,474 km double track;
6,868 km electrified; government owned (1980)
Highways: 305,863 km total; 65,000 km concrete, asphalt,
stone block; 98,000 km crushed stone, gravel; 142,863 km
earth (1977)
Inland waterways: 4,035 km navigable rivers and canals
(1979)
Pipelines: 3,540 km for natural gas; 1,515 km for crude
oil; 322 km for refined products
Freight carried: rail — 481.8 million metric tons (1980),
135.3 billion metric ton/km (1979); highway— 2,146 million
metric tons, 43.9 billion metric ton/km (1979); waterway —
23.2 million metric tons, 2.0 billion metric ton/km (1979)
Ports: 4 major (Gdafisk, Gdynia, Szczecin, Swinoujscie),
12minor (1979); principal inland waterway ports are
Gliwice, WrocHaw, and Warsaw (1979)
DEFENSE FORCES
Military manpower: males 15-49, 9,242,000; 7,388,000 fit
for military service; 256,000 reach military age (19) annually
Military budget: announced for fiscal year ending 31
December 1981, 75.2 billion zHotys; 4.9% of total budget
LAND
Metropolitan Portugal: 94,276 km2, including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and other
Land boundaries: 1,207 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 860 km; excludes Azores (708 km) and Madeira
(225 km)
Railroads: 3,602 km total: state-owned Portuguese Rail-
road Co. (CP) operates 2,830 km 1.665-meter gauge (432 km
electrified and 426 km double track), 760 km meter gauge
(1. 000 m); 12 km (1.435-meter gauge) electrified, double,
nongovernment owned
Highways: 57,499 km total; 49,537 km paved (bitumi-
nous, gravel, and crushed stone), including 140 km of
limited-access divided highway; 7,962 km improved earth;
plus an additional 4,100 km of unimproved earth roads
(motorable tracks)
192','db6054ba1bcd86dd2748d02add31d4777cab0fe2a3cc508fcf80b89c6531b05b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa982abc51668d1172d1d5fb171f1e81fa032967242858148f4c9d7de6185bec',1982,'QA','Qatar','communications',451,'PORTUGAL (Continued)
Inland waterways: 820 km navigable; relatively unimpor-
tant to national economy, used by shallow-draft craft limited
to 297 metric ton cargo capacity
Pipelines: crude oil, 11 km
Ports: 7 major, 34 minor
Civil air: 36 major transport aircraft, including 5 leased in
and 2 leased out
Airfields (including Azores and Madeira Islands): 61
total, 60 usable; 31 with permanent-surface runways; 1 with
runways over 3,659 m, 10 with runways 2,440-3,659 m, 11
with runways 1,220-2,439 m
Telecommunications: facilities are generally adequate;
1.31 million telephones (13.2 per 100 popl.); 39 AM, 52 FM,
and 42 TV stations; 4 submarine coaxial cables; 2 Atlantic
Ocean satellite stations (on mainland and Azores)
DEFENSE FORCES
Military manpower: males 15-49, 2,372,000; 1,941,000 fit
for military service; 91,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31
December 1982, $761.5 million; about 11% of proposed
central government budget
IRAN
V \\- V
K ^BAHRAIN
OMJLfhrf V
■\\j (QATAR','6efdb5136371f558fa8148231da1234f23f6840c1b0e85a4d7b2903f91bd0655','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d64b4beb7248069de93c7834727b27486da3ecd55ff4bd0ee18e753c1deab51a',1982,'SA','Saudi Arabia','communications',452,'(See reference map VI)
LAND
About 10,360 km2; negligible amount forested; mostly
desert, waste, or urban
Land boundaries: 56 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 563 km
Railroads: none
Highways: 805 km total; 442 km bituminous; 362 km
gravel; undetermined mileage of earth tracks
Pipelines: crude oil, 169 km; natural gas, 97 km
Ports: 1 major (Ad Dawhah), 1 minor
Airfields: 4 total, 3 usable; 2 with permanent-surface
runways, 1 with runways over 3,659 m, 1 with runways,
1,220-2,439 m
Civil air: 3 major transport aircraft, including 1 leased in
Telecommunications: good urban facilities; 29,000 tele-
phones (15.4 per 100 popl.); international service through an
Indian Ocean satellite station and a troposcatter link to
Bahrain; 2 AM, 1 FM, and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 115,000; about
62,000 fit for military service
Military budget: for fiscal year ending 31 December
1978, $157 million; 7.3% of central government budget
(See reference map VII)
LAND
2,512 km*; two-thirds of island extremely rugged, consist-
ing of volcanic mountains; 48,600 hectares (less than one-
fifth of the land) under cultivation
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 201 km
Railroads: none
Highways: 1,983 km total; 1,683 km paved, 300 km
gravel, crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: 1 major transport aircraft, leased in
Airfields: 6 total, 6 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications; adequate system for needs; fairly
modern open-wire lines and radiocommunication stations;
principal center Saint-Denis; radiocommunication to Co-
moros Islands, France, Madagascar, and Mauritius; 36,000
telephones (7.2 per 100 popl.); 2 AM and 8 FM stations; 1 TV
station with 13 relay transmitters; 1 Indian Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 144,000; 77,000 fit for
military service; 7,000 reach military age (18) annually
195
Ports: 1 major (Sao Tome), 1 minor
Civil air: 1 major transport aircraft
Airfields: 3 total, 3 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m
Telecommunications: minimal system; 900 telephones
(1.0 per 100 popl.); 1 AM, 1 FM, and no TV stations; 1
Atlantic Ocean satellite ground station
(See reference map VI)
LAND
Estimated at about 2,331,000 km2 (boundaries undefined
and disputed); 1% agricultural, 1% forested, 98% desert,
waste, or urban
Land boundaries: 4,537 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
"necessary supervision zone")
Coastline: 2,510 km
Railroads: 575 km standard gauge (1.435 m)
Highways: 30,100 km total; 16,500 km paved, 13,600 km
improved earth
Pipelines: 5,850 km crude oil; 386 km refined products;
1,570 km natural gas, includes 1,370 km of natural gas
liquids
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6 minor
Civil air: 112 major transport aircraft, including 22 leased
in
Airfields: 157 total, 122 usable; 52 with permanent-
surface runways; 7 with runways over 3,659 m, 21 with
runways 2,440-3,659 m, 62 with runways 1,220-2,439 m, 4
with runways over 3,660 m
Telecommunications: good system exists, major expan-
sion program nearly complete with microwave, coaxial
cable, satellite systems; 200,000 telephones (2.5 per 100
popl); 6 AM, 1 FM, 27 TV stations, 1 submarine cable; 1
Atlantic and 1 Indian Ocean satellite station; 13 domestic
satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 2,562,000; 1,464,000 fit
for military service; about 93,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 April 1982,
$24,640 million; about 28% of central government budget
205','a8b4ace1ff8693a34bef088d6f0aa546bcfaed0eb75ca2bdf33eb77733535574','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0efa6899ba3192939f82be42f9ec6d7ca23189e33293964bd5aebbe545d2618e',1982,'RO','Romania','communications',456,'(See reference mep V)
LAND
237,503 km2; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 2,969 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 225 km','99d37fe3a624c209b8a550353f6d6e321adfacd86be6b609143fad9f271ad350','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a4e878009a35744f80975f4cdb3d4e5887d1b3d2fb55945655e2b127806abb3',1982,'RW','Rwanda','communications',461,'Railroads: 11,113 km total; 10,509 km standard gauge
(1.435 m), 559 km narrow gauge, 45 km broad gauge; 2,202
km electrified, 2,280 km double track; government owned
(1979)
Highways: 73,361 km total; 28,738 km concrete, asphalt,
stone block; 36,790 km asphalt treated, gravel, crushed stone
and 7,833 km other (1979)
Inland waterways: 1,660 km (1979)
Pipelines: 2,735 km crude oil; 1,429 km refined products;
5,149 km natural gas
Freight carried: rail — 273.0 million metric tons, 76.0
billion metric ton/km (1979); highway — 414.7 million metric
tons, 11.5 billion metric ton/km (1979); waterway — 9.6
million metric tons, 2.1 billion metric ton/km
Ports: 4 major (Constanta, Galati, Braila, Mangalia), 7
minor; principal inland waterway ports are Giurgiu, Turnu
Severin, and Orsova (1981)
DEFENSE FORCES
Military manpower: males 15-49, 5,378,000; 4,500,000 fit
for military service; 141,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1981, 10.4 billion lei; about 3.3% of total budget
ZAIRE I&KiH \\
■: ^^^^ sL TAN2AWIA
(See reference mep VII)
LAND
25,900 km2; almost all the arable land, about one-third
under cultivation, about one-third pastureland
Land boundaries: 877 km','8d750039cc402390703d84ca11f815463d7d7489eb2d09fe5494108cb8899f0d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51502f3ddf2a36b0558c4540d3f8cc513a049723a930693a6d1e757372e18952',1982,'SM','San Marino','communications',464,'(See reference mep V)
LAND
62 km2; 74% cultivated, 22% meadows and pastures, 4%
built on
Land boundaries: 34 km','79569b6a2567f12b9e049264855708bb5d758222b084fa45e13015c1065a2a00','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd41ba5e8ed8adb2e541cdd0c5e93dbfeb18ea85c54245061b545ee20e4ac4a4',1982,'ST','Sao Tome and Principe','communications',469,'Railroads: none
Highways: about 104 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serv-
ing 6,800 telephones (32.3 per 100 popl.); no radiobroadcast-
ing or television facilities
(See reference map Vll)
LAND
964 km2 (Sao Tome, 855 km2 and Principe, 109 km2;
including small islets of Pedras Tinhosas)
WATER
Limits of territorial waters: 12 nm (economic, including
fishing, 200 nm)
Coastline: estimated 209 km','7f640aff17b748d33b673ff4d70b2e6f03462e8ffd7cca0c8706c8dbe4271ffc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4ff4a62c021a87f06b5349346c88f8cb2a45c07bcbf7c79a8fb2cc4765c9bb8',1982,'SN','Senegal','communications',472,'Ocean
(See reference map VU)
LAND
196,840 km2; 13% forested, 40% agricultural (12% cultivat-
ed), 47% built-up areas, waste, or other
Land boundaries: 2,680 km
WATER
Limits of territorial waters (claimed): 150 nm
Coastline: 531 km','eb3cdb6093f9c636c0c79e26b729da4017de66f27ea46189dbd22891965fb357','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cbba4ead3c518dd63f0d2e2114a47ba37988632f08ae24c2fb95411d42b0a98',1982,'SC','Seychelles','communications',477,'Railroads: 1,033 km meter gauge (1.00 m); 64 km double
track
Highways: 13,898 km total; 3,461 km paved, 10,437 km
other
Inland waterways: 1,505 km
Ports: 1 major (Dakar), 3 minor
Civil air: 5 major transport aircraft
Airfields: 28 total, 28 usable; 11 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 20 with runways
1,220-2,439 m
Telecommunications: above average urban system;
40,200 telephones (0.8 per 100 pop!.); 8 AM stations, no FM,
and 1 TV station; 2 submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,324,000; 668,000 fit
for military service; 61,000 reach military age (18) annually
Military budget: for fiscal year ending 30 June 1981,
$70.7 million; about 7.4% of central government budget
J itmm^^y
* J
■^r Indian Ocean
tZk X£N¥A
:-#
Victor**
I TANZANIA |
COMPftOS J\\
*\\ V ,J
f^f.., ^MADAGASCAR
(See reference mep VII)
LAND
404 km1; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other (mainly
reefs and other surfaces unsuited for agriculture); 40 granitic
and 50 or more coralline islands
WATER
Limits of territorial waters (claimed): 12 nm (economic,
including fishing, 200 nm)
Coastline: 491 km (Mahe Island 93 km)
Railroads: none
Highways: 215 km total; 145 km bituminous, 70 km
crushed stone or earth
Ports: 1 small port (Victoria)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable (on Praslin Island, Astove
Island, Bird Island, Mahe Island); 1 with permanent-surface
runways 2,440-3,659 m
Telecommunications: direct radiocommunications with
adjacent island and African coastal countries; 5,970 tele-
phones (9.6 per 100 popl.); 2 AM, no FM, and no TV stations;
Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 13,000; 7,000 fit for
military service
Supply: infantry-type weapons and ammunition from
Tanzania, USSR, and the PRC
208','45e874e5872eb5798212a32a4ee234992753df4d422665d299d1355b8178300f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('122e6dfaa0d0a954ebe9983a68db0e37ea2a7ee89b4189e7d53d1264eed943c3',1982,'SL','Sierra Leone','communications',479,'Jk . 1
Bissau mm
f 1
COAST f
Atlantic
Ocean
(See reference map VII)
LAND
72,261 km2; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 933 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 402 km','9c9bb94f88e727d710ea13c4e6747b7fcde76cb7769a74698ff649992078366f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f3bf6ea60c60a03997adc32f74e13d2a153d58ab7fa232065f976aded441434',1982,'SG','Singapore','communications',484,'Railroads: about 84 km narrow gauge (1.067 m) privately
owned mineral line operated by the Sierra Leone Develop-
ment Company
Highways: 7,460 km total; 1,225 km bituminous, 490 km
laterite (some gravel), and remainder improved earth
Inland waterways: 800 km; 600 km navigable year round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft
Airfields: 16 total, 16 usable; 6 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: telephone and telegraph are ade-
quate; 16,000 telephones (0.5 per 100 popl.); INTELSAT
Atlantic Ocean satellite ground station; 2 AM stations, 1 FM,
and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 771,000; 373,000 fit for
military service; no conscription
Military budget: for fiscal year ending 30 June 1981,
$20.2 million; about 7.4% of the central government budget
1 V
f \\>
V X J South
China Sea J
Indian
Ocean
\\JA A L A Y S 1 Ay^
nJ| INDONESIA
<
(See reference map IX)
i*; 31% built-up area, roads, railroads, and
LAND
618 k
22% agricultural, 47% other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 193 km
Railroads: 38 km of meter gauge
Highways: 2,314 km total (1980); 2,006 km paved, 308
km crushed stone or improved earth
Ports: 3 major, 2 minor
Civil air: approx. 30 major transport aircraft
Airfields: 6 total, 6 usable; 6 with permanent-surface
runways; 2 with runways over 3,659 m, 2 with runways
2,440-3,659 m, 1 with runways 1,220-2,439 m
Telecommunications: good domestic facilities; good in-
ternational service; good radio and television broadcast
coverage; 625,130 telephones (26.5 per 100 popl.); 13 AM, 4
FM, and 2 TV stations; submarine cables extend to Hong
Kong via Sabah, Philippines; 1 ground station to Hong Kong
via Sabah, Malaysia; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 730,000; 574,000 fit for
military service
Ships: 13 coastal patrol, 6 amphibious ships (1 in reserve),
2 coastal minesweepers, 6 amphibious craft, 2 service craft;
delivery of 12 new 23-meter patrol craft (swift Warrior class)
began 1981
Military budget: for fiscal year ending 31 March 1982,
$716.5 million; about 15.6% of central government budget
211','9431d260e9cd053438bddabba9c0656f79dca29cc6c85be65598d4c88e18d894','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('050518106bb3f44da63e2ad4a151a2bebf0475334fc4704ab6e404ee4c3a99f1',1982,'SB','Solomon Islands','communications',487,'PAfUA
(See reference mep X)
NOTE: This archipelagic nation, independent since 7 July
1978, includes southern Solomon Islands, primarily Guadal-
canal, Malaita, San Cristobal, Santa Isabel, Choiseul. North-
ern Solomon Islands constitute part of Papua New Guinea.
LAND
About 29,785 km2
WATER
Limits of territorial waters: 12 nm (fishing 200 nm)
Coastline: about 5,313 km
Railroad: none
Highways: 834 km total; 241 km sealed or all-weather
Inland waterways: none
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 25 total, 23 usable; 1 with permanent-surface
runways; 5 with runways 1,220-2,430 m
Telecommunications: 4 AM broadcast, no FM, and no
TV stations; 1,726 telephones, no TV sets; one ground
satellite station
212','530bfe31e92d50de135adbb804b024e8648f57c9802e56599476852a47718242','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f461dc3edfd02d2f6f808666fcc0787c169e9145d8bec5c74afa887d7c07a7f2',1982,'SO','Somalia','communications',491,'(See reference map VII)
LAND
637,140 km2; 13% arable (0.3% cultivated), 32% grazing,
14% scrub and forest, 41% mainly desert, urban, or other
Land boundaries: 2,263 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 3,025 km
Railroads: none
Highways: 15,215 km total; 2,335 km bituminous surface,
2880 km gravel, and 10,000 km unimproved earth, crushed
stone, gravel, or stabilized soil, remainder improved or
unimproved earth (est.)
Pipelines: 15 km crude oil
Ports: 3 major (Mogadishu, Berbera, Chisimaio)
Civil air: 8 major transport aircraft
Airfields: 50 total, 41 usable; 6 with permanent-surface
runways; 2 with runways over 3,659 m; 6 with runways
2,440-3,659 m; 16 with runways 1,220-2,439 m
Telecommunications: fair telephone and telegraph serv-
ice; radio-relay system centered on Mogadishu connects a
few towns; 6,000 telephones (0.2 per 100 popl.); 1 INTEL-
SAT ground station; 2 AM stations, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,176,000; 634,000 fit
for military service; no conscription
213','c4bf493c1dc6663317afe01662b998024535e7bda8a6ec9bb341d0bcbc8d3a38','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('724ef1c07a8d17a053f509bbd73dffd7f348160c15de6e61749ff2e69c035fee',1982,'ZA','South Africa','communications',495,'(See reference mep VII)
LAND
1,222,480 km2 (includes enclave of Walvis Bay, 1,124 km1;
Transkei, 44,000 km2, and Bophuthatswana, 38,000 km2);
12% cultivable, 2% forested, 86% desert, waste, or urban
Land boundaries: 2,044 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 2,881 km, including Transkei
Railroads: 35,434 km total (includes Namibia); 34,728 km
1.067-meter gauge of which 6,143 km are multiple track;
13,949 km electrified; 706 km 0.610-meter gauge single
track
Highways: 229,090 km total; 80,296 km paved, 148,794
km crushed stone, gravel, or improved earth
Pipelines: 836 km crude oil; 1,748 km refined products;
322 km natural gas
Ports: 7 major (Durban, Cape Town, Port Elizabeth,
Richards Bay, Saldanha Bay, East London, and Mossel Bay)
Civil air: 79 major transport aircraft, including 1 leased
in, 3 leased out
Airfields: 761 total, 613 usable; 83 with permanent-
surface runways; 3 with runways over 3,659 m, 7 with
runways 2,440-3,659 m, 155 with runways 1,220-2,439 m
Telecommunications: the system is the best developed,
most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay
links, and radiocommunication stations; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg, Port
Elizabeth, and Pretoria; 2.66 million telephones (10.8 per
100 popl.); 13 AM, 100 FM, and 40 main TV stations with
450 relay transmitters; 1 submarine cable; 1 satellite station
with 1 Indian Ocean and 2 Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 5,809,000; 3,669,000 fit
for military service; 295,000 reach military age (18) annual-
ly; obligation for service in Citizen Force or Commandos
begins at 18; volunteers for service in permanent force must
be 17; national service obligation is two years
Military budget: for year ending 31 March 1981, $2.9
billion; 18.4% of central government budget
(See reference map VIII)
LAND
22,402,200 km2; 10.2% cultivated, 35.5% forest, 16.8%
pasture and hay land, 37.5% other
Land boundaries: 20,619 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 46,670 km (incl. Sakhalin)
Railroads: 141,800 km total; 139,917 km broad gauge
(1.524 m); 1,833 km narrow gauge (mostly 0.750 m); 110,815
km broad gauge single track; 43,700 km electrified; does not
include industrial lines (1980)
Highways: 1,346,500 km total; 373,000 km asphalt, con-
crete, stone block; 554,000 km asphalt treated, gravel,
crushed stone; 419,500 km earth (1980)
Inland waterways: 142,000 km navigable, exclusive of
Caspian Sea (1980)
Freight carried: rail— 3,728.0 million metric tons, 3,439.9
billion metric ton/km (1980); highways— 24.1 billion metric
tons, 432.3 billion metric ton/km j(1980); waterway— 568. 1
million metric tons, 244.9 billion metric ton/km, excluding
Caspian Sea (1980)
Pipelines: 70,000 km crude oil; 20,000 km refined prod-
ucts; 135,000 km natural gas
Ports: 53 major (most important: Leningrad, Riga, Tallinn,
Kaliningrad, Liepaja, Ventspils, Murmansk, Arkhangelsk,
Odessa, Novorossiysk, Ilichevsk, Nikolayev, Sevastopol,
Vladivostok, Nakhodka); over 180 selected minor; 58 major
inland ports (some of the more important: Astrakhan, Baku,
Gorkiy, Kazan, Khabarovsk, Krasnoyarsk, Kubyshev, Mos-
cow, Rostov, Volgograd, and Kiev (1982)
DEFENSE FORCES
Military manpower: males 15-49, 68,359,000; 54,009,000
fit for military service; 2,101,000 reach military age (17)
annually
216','8ec6bab4ec23488c33845ec3d013138010af9c039b8405e54e501c7c0b2f07b2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34a2ce6cd182609bc0d433a5c7b3aa0009237703be5fca0dd7e753a33d775a18',1982,'LK','Sri Lanka','communications',499,'(formerly Ceylon)
(See reference map VIII)
LAND
65,500 km2; 25% cultivated; 44% forested; 31% waste,
urban, and other
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm, plus pearling in the Gulf of Mannar; 200 nm exclusive
economic zone) ,
Coastline: 1,340 km','538ccc2aa792e46af8541b855f157e39ab86d8c4b1a98b2923f60fff381314b1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88c03d124442aa8b77ceb3865d7bf31be2480b27e3f37ae35e3cac401bd0163a',1982,'SR','Suriname','communications',502,'(See reference mep IV)
LAND
142,709 km2; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially produc-
tive, 16% built-on area, wasteland, and other
Land boundaries: 1,561 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 386 km
Railroads: 166 km total; 86 km meter gauge (1.00 m)
(government owned) and 80 km narrow gauge (industrial
lines); all single track
Highways: 8,780 km total; 2,210 km paved, 1,990 km
gravel, 2,400 km improved earth, 2,180 km unimproved
earth
Inland waterways: 4,500 km; most important means of
transport; oceangoing vessels with drafts ranging from 4.2 m
to 7 m can navigate many of the principal waterways while
native canoes navigate upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 2 major transport aircraft, leased in
Airfields: 29 total, 28 usable; 2 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: international facilities good; do-
mestic radio-relay system; 21,300 telephones (6.1 per 100
popl.); 6 AM, 2 FM, and 6 TV stations; 2 Atlantic satellite
stations
DEFENSE FORCES
Military manpower: males 15-49, 63,000; 40,000 fit for
military service
(See reference map VII)
LAND
17,364 km2; most of area suitable for crops or pastureland
Land boundaries: 435 km','637dbf9e02c1a80b5599d36f9d4425c1e78cd455d421ba9848043d46b984b9a5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fe4f8683dce7a5fe47c2fbf4b2734513e24e6056c05cebf396966fbe6c878a8',1982,'SE','Sweden','communications',508,'Railroads: 292 km 1.067-meter gauge, single track
Highways: 2,853 km total; 510 km paved, 1,230 km
crushed stone, gravel, or stabilized soil, and 1,113 km
improved earth
Civil air: 4 major transport aircraft, including 1 leased in
Airfields: 28 total, 26 usable; 1 with runways 1,220-
2,439 m
Telecommunications: system consists of carrier-equipped
open-wire lines and low capacity radio-relay links; 10,700
telephones (2.0 per 100 popL); 3 AM, 2 FM, and 3 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 125,000; 73,000 fit for
military service
(Sea reference map V)
LAND
448,070 km2; 7% arable, 2% meadows and pastures, 55%
forested, 36% other
Land boundaries: 2,196 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 3,218 km
Railroads: 12,518 km total; Swedish State Railways (SJ) —
11,179 km standard gauge (1.435 m), 6,959 km electrified
and 1,152 km double track; 182 km 0.891-meter gauge; 117
km rail ferry service; privately owned railways — 511 km
standard gauge (1.435 m), 332 km electrified; 371 km
0.891-meter gauge electrified
Highways: classified network, 97,400 km, of which
51,899 km paved; 20,659 km gravel; 24,842 km unimproved
earth
Inland waterways: 2,052 km navigable for small steamers
and barges
Ports: 17 major, and 30 minor
Civil air: 57 major transports, including 2 leased in and 2
leased out
Airfields: 254 total, 249 usable; 133 with permanent-
surface runways; 9 with runways 2,440-3,659 m, 87 with
runways 1,220-2,439 m
Telecommunications: excellent domestic and internation-
al facilities; 6.4 million telephones (77.2 per 100 popl.); 3
AM, 330 FM, and 700 TV stations; 9 submarine coaxial
cables, 1 Atlantic Ocean satellite station, another planned
DEFENSE FORCES
Military manpower: males 15-49, 2,034,000; 1,806,000 fit
for military service; 62,000 reach military age (19) annually
Military budget: for fiscal year ending 30 June 1982, $4.1
billion; about 8% of central government budget
225','6a7de631da4b0ab9f481eb046a5c34bb2045a07c7d35ca72fe1938ce25fb8789','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0a88652b2352f11a8148edab99916e3e673305b22a11746abbbc1178c60d239',1982,'CH','Switzerland','communications',510,'(See reference mep V)
LAND
41,440 km1; 10% arable, 43% meadows and pastures, 20%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,884 km
Railroads: 5,098 km total; 2,895 km government owned
(SBB), 2,822 km standard gauge (1.435 m); 73 km narrow
gauge (LOO m); 1,339 km double track, 99% electrified;
2,203 km nongovernment owned, 710 km standard gauge
(1.435 m), 1,418 km meter-gauge (1.00 m), 75 km 0.790-
meter gauge, 100% electrified
Highways: £2,145 km total (all paved), of which 18,620
km aie canton and 1,057 km are national highways (740 km
autobahn)
Pipelines: 314 km crude oil; 1,046 km natural gas
Inland waterways: 65 km; Rhine River-Basel to Rhein-
felden, Schaffhausen to Constanz; in addition, there are 12
navigable lakes ranging in size from Lake Geneva to
Hallwilersee
Ports: 1 major (Basel), 2 minor (all inland)
Civil air: 83 major transport aircraft, including 1 leased
out
Airfields: 80 total, 71 usable; 41 with permanent-surface
runways; 2 with runways over 3,660 m, 7 with runways
2,440-3,659 m, 14 with runways 1,220-2,439 m
Telecommunications: excellent domestic, international,
and broadcast services; 4.45 million telephones (70.0 per 100
popl); 6 AM, 200 FM, and 1,125 TV stations; 1 satellite
station with 2 Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 1,656,000; 1,435,000 fit
for military service; 50,000 reach military age (20) annually
Major ground units: no active combat units
Military budget: proposed for fiscal year ending 31
December 1982, $2,018 million; 20.1% of proposed central
government budget
(See reference map VI)
LAND
186,480 km2 (including 1,295 km2 of Israeli-occupied
territory); 48% arable, 29% grazing, 2% forest, 21% desert
Land boundaries: 2,196 km (1967) (excluding occupied
area 2,156 km)
WATER
Limits of territorial waters (claimed): 35 nm
Coastline: 193 km
Railroads: 1,543 km total; 1,281 km standard gauge, 262
km narrow gauge (1.050 m)
Highways: 16,939 km total; 12,051 km paved, 2,625 km
gravel or crushed stone, 2,263 km improved earth
Inland waterways: 672 km; of little importance
Pipelines: 1,304 km crude oil; 515 km refined products
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
Civil air: 14 major transport aircraft
Airfields: 53 total, 49 usable; 23 with permanent-surface
runways; 21 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: good international and fair domes-
tic service; 193,000 telephones (2.3 per 100 popl.); 9 AM, no
FM, and 21 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,040,000; 1,145,000 fit
for military service; about 102,000 reach military age (19)
annually
Military budget: for fiscal year ending 31 December
1981, $2,389 million; 31% of central government budget
228
TANZANIA
(See reference map VII)
LAND
939,652 km2 (including islands of Zanzibar and Pemba,
2,642 km2); 6% inland water, 15% cultivated, 31% grassland,
48% bush forest, woodland; on mainland, 60% arable, of
which 40% cultivated on islands of Zanzibar and Pemba
Land boundaries: 3,883 km
WATER
Limits of territorial waters ^claimed): 50 nm
Coastline: 1,424 km (this includes 113 km Mafia Island;
177 km Pemba Island; and 212 km Zanzibar)','7049a61d2ef4ae20ebdbff4d00a8e3c7ee60d7686406eed0d7b4d9405571e4bf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80c032c18609a0bdeba977295667edb9e18c17d20eda75e38cca282526df795b',1982,'TH','Thailand','communications',515,'Railroads: 3,555 km total; 960 km 1.067-meter gauge;
2,595 km meter gauge (1.00 m), 6.4 km double track; 962 km
Tan-Zam Railroad 1.067-meter gauge in Tanzania
Highways: total 34,227 km, 3,588 km paved; 5,529 km
gravel or crushed stone; remainder improved and unim-
proved earth
Pipelines: 982 km crude oil
Inland waterways: 1,168 km of navigable streams; several
thousand km navigable on Lakes Tanganyika, Victoria, and','4aede9f95058492730017695daae7912987b30896fb0dda49e264a0855e35a62','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b0b222c6468c55e297c305af731fad41b45183bd7fbaa823c85351146175286',1982,'TO','Tonga','communications',517,'Railroads: 442 km meter gauge (1.00 m), single track
Highways: 7,000 km total; 1,320 km paved, 1,280 km
improved earth, remainder unimproved earth
Inland waterways: section of Mono River and about 50
km of coastal lagoons and tidal creeks
Ports: 1 major (Lome), 1 minor
Civil air: 1 major transport aircraft
Airfields: 11 total, 11 usable; 2 with permanent-surface
runways 2,440-3,659 m
Telecommunications: fair system based on skeletal net-
work of open-wire lines supplemented by a radio-relay route
and radiocommunication stations; only center is Lome; 7,500
telephones (0.4 per 100 popl.); 2 AM, no FM, and 3 TV
stations; 1 Atlantic Ocean satellite station and 1 SYM-
PHONIE station
DEFENSE FORCES
Military manpower: males 15-49, 600,000; 313,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1981, $20.8 million; 8.5% of central government budget
(See reference map X)
LAND
997 km2 (169 islands, only 36 inhabited); 77% arable, 3%
pasture, 13% forest, 3% inland water, 4% other
WATER
Limits of territorial waters (claimed): rectangular/poly-
gonal claim (12 nm for Minerva Reef)
Coastline: 419 km (est.)','a4fd5cf2be409dcbca1f43b79820be3fc4a4fadcd74d657f7d7ece121b2441cd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23ec9e9115659c190a3c38b245131f7b1ea3ac9cb86267adfc1b9b4e30953682',1982,'TT','Trinidad and Tobago','communications',522,'Railroads: none
Highways: 249 km total (1974); 177 km rolled stone; 72
km coral base
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 1 with permanent-surface
runways 1,220-2,439 m
Telecommunications: 1,285 telephones (1.4 per 100
popl.); 11,000 radio sets; no TV sets; 1 AM station; 1 ground
satellite station
ft
CaribbiBft Sea \\
i
At /antic Ocean
^\\ o Spam
TRINIDAD
AND TOBAGO
GUYANA W-r-^
r\\ J />R£NCH
1ST ^ ■ X ,„;-?
( See reference map III)
LAND
5,128 km2; 41.9% in farms (25.7% cropped or fallow, 1.5%
pasture, 10.6% forests, and 4.1% unused or built on), 58.1%
outside of farms, including grassland, forest, built-up area,
and wasteland
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 362 km
Railroads: none
Highways: 7,900 km total; 3,600 km paved, 1,100 km
improved earth, 3,200 km unimproved earth
Pipelines: 1,032 km crude oil and refined products; 832
km natural gas
Ports: 3 major (Port of Spain, Chaguaramas Bay, Point
Tembladora), 6 minor
Civil air: 19 major transport aircraft
Airfields: 8 total, 6 usable; 3 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: excellent international service via
tropospheric scatter links to Barbados and Guyana; good
local service; 1 Atlantic Ocean satellite station; 75,000
telephones (7.0 per 100 popl.); 2 AM, 2 FM, and 3 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 331,000; 235,000 fit for
military service
Supply: mostly from UK
Military budget: proposed for fiscal year ending 31
December 1979, $105.0 million; 4.8% of central government
budget
235','26f159b7e7ea456229c1d04de2d318174e21eb99e2f6873871cee742687ce579','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ffee5660a03131e0300323c0c098b4bfc934187a4b821c876053097e8ede610',1982,'TN','Tunisia','communications',524,'(See reference map VII)
LAND
164,206 km2; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste, or urban
Land boundaries: 1,408 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 12
nm exclusive fisheries zone follows the 50-meter isobath for
part of the coast, maximum 65 nm)
Coastline: 1,143 km (includes offshore islands)
Railroads: 2,089 km total; 503 km standard gauge (1.435
m), 1,586 km meter gauge (1.000 m)
Highways: 17,140 km total; 7,940 km bituminous, 660 km
gravel; 2,000 km improved earth; 6,540 km unimproved
earth
Pipelines: 797 km crude oil; 10 km refined products; 372
km natural gas „
Ports: 4 major, 8 minor
Civil air: 15 major transport aircraft, including 3 leased in
Airfields: 29 total, 26 usable; 12 with permanent-surface
runways; 5 with runways 2,440-3,659 m; 10 with runways
1,220-2,439 m
Telecommunications: the system is above the African
average; facilities consist of open-wire lines, multiconductor
cable, or radio relay; key centers are Safaqis, Susah, Bizerte,
and Tunis; 145,000 telephones (2.3 per 100 popl.); 4 AM, 3
FM, and 11 TV stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,590,000; 887,000 fit
for military service; about 77,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1981, $261 million; 9% of central government budget
..ei
\\ : SOVIET
mwf Stack Sm^x \\ An
^Tjj^^ * Ankara <S*/\\C
K\\ TURKEY \\> \\w
f EGYPT Y\\ ^
(See reference map VI)
LAND
766,640 km2; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km
Railroads: 8,138 km standard gauge (1.435 m); 204 km
double track; 104 km electrified
Highways: 59,615 km total; 26,915 km bituminous;
23,000 km gravel or crushed stone; 2,200 km improved
earth; 7,500 km unimproved earth
Inland waterways: approx. 1,600 km
Pipelines: 1,288 km crude oil; 2,145 km refined products
Ports: 10 major, 35 minor
Civil air: 23 major transport aircraft, including 3 leased in
and 1 leased out
Airfields: 121 total, 99 usable; 60 with permanent-surface
runways; 3 with runways over 3,660 m, 26 with runways
2,440-3,659 m, 23 with runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 11,717,000; 6,932,000
fit for military service; about 494,000 reach military age (20)
annually
238','b736725df93b08a0f6af420af78982a9c83a1a260f0f4c67630a59122cc71c4b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80786330b3ff0abc59dc10bf445fe6459188b60d3f8d99d3f5362a8871332cf6',1982,'TV','Tuvalu','communications',528,'(formerly Ellice Islands)
Pacific Ocean
UNITED*''
STATES
*\\ KIRIBATI
^ >^ V *S§? " ■ TUVALU
t VANUATU
^WESTERN','fe9ce8ba04d47ee14572dde3538c0b4e73f71276d0ce0a55cac3265894a972cb','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bee421fe84158d20590532255723620ba41ea5be78634f417ca1ba98e3caf51',1982,'WS','Samoa','communications',529,'» FIJI
AUSTRAtlA
(See reference map X)
NOTE: On 1 October 1975, by Constitutional Order, the
Ellice Islands were formally, separated from the British
colony of Gilbert and Ellice Islands, thus forming the colony
of Tuvalu. The remaining islands in trie former Gilbert and
Ellice Islands Colony are now named Kiribati. Tuvalu
includes the islands of Nanumanga, Nanumea, Nui, Niutao,
Vaitupu, and the four islands of the Tuvalu group formerly
claimed by the United States: Funafuti, Nukufetau, Nuku-
lailai (Nukulaelae), and Nurakita (Niulakita).
LAND
26 km1
WATER
Limits of territorial waters: 3 nm (fishing 200 nm,
economic 200 nm)
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 1 with runways 1,220-2,439 m
Telecommunications: 1 AM station; about 300 radio
telephones (0.5 per 100 popl.); 4,000 radio sets
239','ce4e8288f82172eebfa9daefa890adeb61f8d1eea028f5f483742619c0f555fd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b99474a18053488bf9c67696164d641d9692944af36a994ac12d09a1bd0a9b0b',1982,'AE','United Arab Emirates','communications',535,'k x> v.-
IHAM
k Qmnn
1. UNITED ARAB
EMIRATES
■
OMAN >
SAUDI
ABASIA
(See reference map VI)
LAND
82,880 km2; almost all desert, waste or urban
Land boundaries: 1,094 km tdoes not include boundaries
between adjacent UAE states)
WATER
Limits of territorial waters (claimed): 3 nm for all states
except Sharjah (12 nm); fishing 200 nm; exclusive economic
zone 200 nm
Coastline: 1,448 km
Railroads: none
Highways: 780 km bituminous, undetermined mileage of
earth tracks
Pipelines: 540 km crude oil; 190 km natural gas
Ports: 3 major, 1 minor
Civil air: 10 major transport aircraft, including 1 leased in
Airfields: 58 total, 37 usable; 18 with permanent-surface
runways; 5 with runways over 3,659 m, 2 with runways
2,440-3,659 m, 10 with runways 1,220-2,439 m
Telecommunications: adequate system of radio relay and
coaxial cable; key centers are Abu Dhabi and Dubai; 96,000
telephones (16.0 per 100 popl.); 4 AM, 2 FM, and 9 TV
stations; 3 INTELSAT stations with 1 Atlantic and 2 Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 445,000; 309,000 fit for
military service
Military budget: for fiscal year ending 31 December
1979, $670 million; 36% of central government budget
241','fcff68f5dbda36afdb95e85a66aadefde63bf5307cff9ce26d8815acf6f5fce6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a79beff9ab66a8972d91fe13fb3dd38611c3d37a9726564ac6481e84b6537a6b',1982,'US','United States','communications',539,'This "Factsheet" on the US is provided solely as a service
to those wishing to make rough comparisons of foreign
country data with a US "yardstick." Information is from US
open sources and publications and in no sense represents
estimates by the US Intelligence Community.
LAND
9,371,829 km* (contiguous US plus Alaska and Hawaii);
19% cultivated, 27% grazing and pasture, 32% forested, 22%
waste, urbap, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 19,924 km
Railroads: 286,885 km (1978)
Highways: 6,251,769.5 km (1978)
Inland waterways: 40,416 km of navigable inland chan-
nels, exclusive of the Great Lakes (1970)
Freight carried: rail — 1,645.0 million metric tons, 1,360.0
billion metric ton/km (1980); highways — 936.84 billion met-
ric ton/km (1980); inland water freight (excluding Great
Lakes traffic) — 569.79 million metric tons, 319.01 billion
metric tons/km (1979)
Pipelines: petroleum, 271,921 km* (1979); natural gas,
408,203 km (1978)
Ports: 53 handling 9.07% million metric tons or more per
year
Civil air: 3,208 multiengine transport aircraft^some
2,500 jet planes, remainder turboprop (December 1980)
Airfields: 14,746 in operation (1979)
Telecommunications: 162 million telephones (74 tele-
phones per 100 popl); 4,550 AM, 4,100 FM, and 990 TV
broadcast stations; 436 million radio and 133 million TV
receivers (1979)
DEFENSE FORCES
Personnel: army 1,108,000, air force 790,000, navy and
marines 1,013,000 (1979)
Military budget: $146.2 billion (1981 est. in current
dollars)
t MAi i
\\ MAli
NIGEfi J
coast ( JJJL*
Atlantic
Ocean
(Se
3 reference map VII)
LAND
274,540 km2; 50% pastureland, 21% fallow, 10% culti-
vated, 9% forest and scrub, 10% waste and other uses
Land boundaries: 3,307 km
Railroads: 1,173 km Ouagadougou to Abidjan (Ivory
Coast line); 516 km meter gauge (1.00 m), single track in
Upper Volta
Highways: 8,316 km total; 967 km paved, 5,639 km
improved, 1,710 km unimproved
Civil air: no major transport aircraft
Airfields: 55 total, 54 usable; 2 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: all services only fair; radio relay,
wire, radiocommunication stations in use; 8,600 telephones
(under 0.14 per 100 popl.); 2 AM stations, 1 FM station, and
1 TV station; i Atlantic Ocean INTELSAT station
DEFENSE FORCES
Military manpower: males 15-49, 1,373,000; 691,000 fit
for military service; no conscription
Supply: mainly dependent on France, FRG, and UK
246','f6bba608923a1e9c6dc5f499426b076f36269b5bf0b62174cdc5f45995b00d25','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc9592599860fea493c760fa95d23e72c094f5bc1d176c5072cab3b4c217c626',1982,'UY','Uruguay','communications',543,'• BRAZIL
''^^\\SP ARAGli AY \\
|uguayS/
Atlantic
1} Montevideo
Ocean
(Sea reference map IV)
LAND
186,998 km2; 84% agricultural land (73% pasture, 11%
cropland), 16% forest, urban, waste, and .other
Land boundaries: 1,352 km
WATER
Limits of territorial waters (claimed): 200 nm (fishing
200 nm)
Coastline: 660 km
Railroads: 2,795 km, all standard gauge (1.435 m) and
government owned
Highways: 49,900 km total; 6,700 km paved, 3,000 km
gravel, 40,200 km earth
Inland waterways: 1,600 km; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail
15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos, Pay-
sandu), 6 minor
Civil air: 22 major transport aircraft, including 1 leased in
Airfields: 129 total, 85 usable; 12 with permanent-surface
runways; 1 with runways 2,440-3,659 m, 16 with runways
1,220-2,439 m
Telecommunications: most modern facilities concen-
trated in Montevideo; 279,000 telephones (9,9 per 100 popl.);
85 AM, 4 FM, and 20 TV stations; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 686,000; 557,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1979, $211.7 million; 18.6% of central government budget','f6ba7df5ffd99e5ca09b94b51dcb06fa6173bfbd55d088334c646aa7a3c1119e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0f8ae2d0e434532179ee242a4743fff7fc6126c573011146f6e90c19eef351d',1982,'VU','Vanuatu','communications',547,'(formerly New Hebrides)
( See reference map X)
LAND
About 14,763 km2
WATER
Limits of territorial waters: 12 nm (fishing 200 nm;
exclusive economic zone 200 nm)
Coastline: about 2,528 km
m
Railroads: none
Highways: at least 240 km sealed or all-weather roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft''
Airfields: 31 total, 29 usable; 2 with ''permanent-surface
runways, 2 runways 1,220-2,439 m
Telecommunications: 2 AM broadcast stations; 2,400
telephones (2.4 per 100 popl.); 1 ground satellite station
under construction
DEFENSE FORCES
Personnel: no military forces maintained; however, the
French and British maintain constabularies of about 100
men each
(See reference map V)
LAND
0.438 km2
Land boundaries: 3 km
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 2 AM stations and 2 FM stations;
2,000-line automatic telephone exchange
DEFENSE FORCES
Defense is responsibility of Italy
(See reference map IV)
LAND
911,680 km2; 4% cropland, 18% pasture, 21% forest, 57%
urban, waste, and other
Land boundaries: 4,181 km
WATER
Limits of territorial waters (claimed): 12 nm plus 3 nm
contiguous zone for customs and sanitation (economic, in-
cluding fishing, 200 nm)
Coastline: 2,800 km
Railroads: 403 km standard gauge (1.435 m) all single
track; 173 km government owned, 230 km privately owned
Highways: 77,785 km total; 22,780 km paved, 24,720 km
gravel, 14,450 km earth roads, and 15,835 km unimproved
earth
Inland waterways: 7,100 km; Orinoco River and Lake
Maracaibo accept oceangoing vessels
Pipelines: 6,110 km crude oil; 400 km refined products;
2,495 km natural gas
Ports: 6 major, 17 minor
Civil air: 68 major transport aircraft, including 4 leased in
and 1 leased out
Airfields: 268 total, 267 usable; 115 with permanent-
surface runways; 7 with runways 2,440-3,659 m, 82 with
runways 1,220-2,439 m
Telecommunications: modern expanding telecom system;
satellite ground station; 1,165,000 telephones (8.5 per 100
popl.); 215 AM, 50 FM, and 48 TV stations; 3 submarine
coaxial cables; 1 Atlantic Ocean satellite station with 2
antennas
DEFENSE FORCES
Military manpower: males 15-49, 4,373,000; 3,322,000 fit
for military service; 185,000 reach military age (18) annually
Military budget: proposed for fiscal year ending 31
December 1980, $861.2 million; about 6.5% of central
government budget
251
VIETNAM','e8257ebddde17200127fbc66b438dd6273db8b9e1fcfeeda01c5a65d86dcfe48','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45ce85bb0852578f20102b2c856c0fef31a49845e4c574791ba23424466218e0',1982,'WF','Wallis and Futuna','communications',551,'VIETNAM (Continued)
Highways: 41,190 km total; 5,471 km bituminous, 27,030
km gravel or improved earth, 8,690 km unimproved earth ''
Inland waterways: about 17,702 km navigable; more than
5,149 km navigable at all times by vessels up to 1.8-m draft
Ports: 9 major, 23 minor
Civil air: military controlled
Airfields: 242 total, 128 usable; 55 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 17 with
runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 13,266,000; 8,085,000
fit for military service; 661,000 reach military age (17)
annually
Supply: dependent on the USSR and Eastern European
Communist countries for virtually all new, equipment; pro-
duces negligible quantities of infantry weapons, ammunition
and explosive devices (Vietnam possesses a huge inventory of
US-manufactured weapons and equipment captured from
the RVN)
Military budget: no expenditure estimates are available;
military aid from the USSR has been so extensive that actual
allocation of Vietnam''s domestic resources to defense has not
been indicative of total military effort
ZEALAN0
(See reference map X)
LAND
About 207 km2
WATER
Limits of territorial waters: 12 nm (fishing 200 nm;
exclusive economic zone 200 nm)
Coastline: about 129 km
Highways: 100 km of improved road on Uvea Island
(1977)
Ports: 2 minor
Airfields: 2 total, 2 usable; 1 with permanent-surface
runways, 1 with runways 1,220-2,439 m
Telecommunications: 148 telephones (1.6 per 100 popl.)
DEFENSE FORCES
No formal defense structure; no regular armed forces','831cbe54fe40524a646bd367bc5065c469bf324053bbfb6ba9057458c229ac60','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54d8f7c6c117f7753cc550b50548a536c2840551fac2b8e13565a6437cee8e42',1982,'EH','Western Sahara','communications',555,'(formerly Spanish Sahara)
(See reference map VII)
LAND
266,770 km2, nearly all desert
Land boundaries: 2,086 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,110 km
Railroads: none
Highways: 6,100 km total; 500 km bituminous treated,
5,600 km unimproved earth roads and tracks
Ports: 2 major (El Aaiun, Dakhla)
Civil air: no major transport aircraft
Airfields: 15 total, 14 usable; 3 with permanent-surface
runways; 1 with runways over 3,659; 1 with runways 2,440-
3,659 m; 8 with runways 1,220-2,439 m
Telecommunications: sparse and fragmentary system
with facilities concentrated in northwest area; some radio
relay, wire, and radiocommunications stations in use; 1,000
telephones (0.7 per 100 popl.); 2 AM and no FM stations; 1
TV station
WESTERN
''• SAMOA
(See reference map X)
LAND
2,849 km2; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono and
Apolima; 65% forested, 24% cultivated, 11% industry, waste,
or urban
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 403 km
Railroads: none
Highways: 784 km total; 375 km bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, 4 usable; 1 with permanent-surface
runways, 1 with runways 1,220-2,439 m
Telecommunications: 3,800 telephones (2.5 per 100
popl.); 20,000 radio receivers; 1 AM station
DEFENSE FORCES
Military manpower: males 15-49, 35,000; 18,000 fit for
military service
(See reference mep VI)
LAND
287,490 km2; (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,802 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
"necessary supervision zone"); fishing 200 nm, economic 200
nm
Coastline: 1,383 km
Railroads: none
Highways: 5,311 km total; 322 km bituminous treated,
290 km crushed stone and gravel, 4,699 km motorable track
Pipelines: refined products, 32 km
Ports: 1 major (Aden)
Civil air: 14 major transport aircraft, 1 leased in
Airfields: 98 total, 52 usable; 5 with permanent-surface
runways; 10 with runways 2,440-3,659 m, 25 with runways
1,220-2,439 m
Telecommunications: small system of open-wire, tropo-
scatter multiconductor cable, and radiocommunications sta-
tions; only center Aden; estimated 10,000 telephones (0.6 per
100 popl); 1 AM, no FM, and 5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 428,000; 238,000 fit for
military service
Military budget: for fiscal year ending 31 December
1977, $56 million; about 22.4% of central government
budget
257
YEMEN (SANAA)
\\ \\ SAUOi \\A
\\ S ARABIA ^
J ^l^y^fi Ad""
; / OJ1B0U7D W"**^
Arabian
Sea
f ETHIOPIA V4^ALy
rr/
Ocean
(See reference map VI)
LAND
194,250 km2 (parts of border with Saudi Arabia and
Southern Yemen undefined); 20% agricultural, 1% forested,
79% desert, waste, or urban
Land boundaries: 1,528 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
"necessary supervision zone")
Coastline: 523 km
Railroads: none
Highways: 3,477 km total; 467 km bituminous; 435 km
crushed stone and gravel; 2,575 km earth, sand, and light
gravel
Ports: 1 major (Al Hudaydah), 2 minor
Civil air: 10 major transport aircraft
Airfields: 26 total, 15 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 8 with runways
1,220-2,439 m
Telecommunications: system inadequate; consists of mea-
ger open-wire lines and low-power radiocommunication
stations; 5,000 telephones (0.1 per 100 popl.); 2 AM stations,
no FM, 2 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,008,000; 560,000 fit
for military service; about 59,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 June 1979, $156
million; 22% of central government budget
258
YUGOSLAVIA
(See reference map V)
LAND
255,892 km2; 32% arable, 25% meadows and pastures, 34%
forested, 9% other
Land boundaries: 3,001 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,521 km (mainland), plus 2,414 km (offshore
islands)
Railroads: 9,465 km total; 9,465 km standard gauge
(1.435 m); 891 km double track; 3,167 km electrified (1980),
Highways: 155,842 km total; 56,655 km asphalt, concrete,
stone block; 38,642 km asphalt treated, gravel, crushed stone;
20,545 km earth (1980)
Inland waterways: 2,600 km (1978)
Freight carried: rail — 84.9 million metric tons, 25.0 bil-
lion metric ton/km (1980); highway — 201.7 million metric
tons, 19.0 billion metric ton/km (1980); waterway— 26.0
million metric tons, 5.0 billion metric ton/km (excluding
international transit traffic)
Pipelines: 1,373 km crude oil; 2,760 km natural gas; 150
km refined products
Ports: 9 major (most important: Rijeka, Split, Koper, Bar,
and Ploce), 24 minor; principal inland water port is Belgrade
(1979)
Airfields: 124 total, 109 usable; 41 with permanent-
surface runways, 20 with runways 2,440-3,659 m, 22 with
runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 5,968,000; 4,814,000 fit
for military service; 188,000 reach military age (19) annually
Military budget: announced for fiscal year ending 31
December 1981, 102 billion dinars; about 5.8% of national
income
(See reference map VII)
2,343,950 km2; 22% agricultural land (1% cultivated), 45%
forested, 33% other
Land boundaries: 9,902 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 37 km
Railroads: 5,254 km total; 3,968 km L067-meter gauge
(851 km electrified), 125 km 1,000-meter gauge; 136 km
0.615-meter gauge, 1,025 km 0.600-meter gauge
Highways: 168,979 km total; 2,654 km bituminous,
58,129 km improved earth; 108,196 km unimproved earth
Inland waterways: comprising the Zaire, its tributaries,
and unconnected lakes, the waterway system affords over
15,000 km of navigable routes
Pipelines: refined products, 390 km
Ports: 2 major (Matadi, Boma), 1 minor
Civil air: 56 major transport aircraft
Airfields: 324 total, 287 usable; 26 with permanent-
surface runways; 1 with runways over 3,659 m, 5 with
runways 2,440-3,659 m, 68 with runways 1,220-2,439 m
Telecommunications: barely adequate wire and radio-
relay service, 30,300 telephones (0.1 per 100 popl.); 12 AM, 1
FM, and 17 TV stations; 1 Atlantic Ocean satellite station
and 13 domestic satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 6,702,000; 3,386,000 fit
for military service
261','913762bbe8f5639c4138393d984377551ec2ef8d4a35b714a2665b9f68a7a1c4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38c45f6a89eec475deb577656f7b055a69d6e56de2e2a739e32852d508ddb3f2',1982,'ZM','Zambia','communications',559,'(See reference map VII)
LAND
745,920 km*; 5% under cultivation, 5% arable, 10% graz-
ing, 13% dense forest, 6% marsh, 61% scattered trees and
grassland
Land boundaries: 6,003 km','c3c50be559bda9989fc39b7a9e35eaabae989417cc001b942368fb8bd3ebc126','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa7b2c1b2eb2f02d29c75c62a892076a5bfa46682168510339ec106bee57a882',1982,'ZW','Zimbabwe','communications',564,'Railroads: 2,014 km, all narrow gauge (1.067 m); 13 km
double track
Highways: 36,809 km total; 5,565 km paved, 8,374 km
crushed stone, gravel, or stabilized soil; 22,870 km improved
and unimproved earth
Inland waterways: 2,250 km including Zambezi River,
Luapula River, Lake Kariba, Lake Bangweulu, Lake Tan-
ganyika; Mpulungu is small port on Lake Tanganyika
Pipelines: 724 km crude oil
Civil air: 7 major transport aircraft
Airfields: 136 total, 129 usable; 12 with permanent-
surface runways; 1 with runways over 3,659 m, 4 with
runways 2,440-3,659 m, 20 with runways 1,220-2,439 m
Telecommunications: facilities are among the best in
Sub-SaharanAfrica; high-capacity radio relay connects most
larger towns and cities; 60,500 telephones; (1.1 per 100
popl.); 7 AM, 1 FM, and 5 TV stations; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,327,000; 691,000 fit
for military service
(See reference map Vll)
LAND
391,090 km2; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; 39% owned by Europe-
ans (farmed by modern methods); 48% worked communally
by Africans; 7% national land, 6% not alienated
Land boundaries: 3,017 km
Railroads: 2,743 km narrow gauge (1.067 m); 42 km
double track
Highways: 85,237 km total; 12,243 km paved, 28,090 km
crushed stone, gravel, stabilized soil: 23,097 km improved
earth; 21,807 km unimproved earth
Pipelines: 8 km refined products (nonoperating)
Civil air: 19 major transport aircraft, including 3 leased in
Airfields: 447 total, 431 usable; 19 with permanent-
surface runways; 2 with runways over 3,659 m, 3 with
runways 2,440-3,659 m, 31 with runways 1,220-2,439 m
Telecommunications: system is one of the best in Africa;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; principal center Salisbury, secondary
center Bulawayo; 214,400 telephones (2.8 per 100 popl.); 8
AM, 15 FM, and 6 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,708,000; 1,048,000 fit
for military service
Military budget: for fiscal year ending 30 June 1982,
$464.8 million; 17.2% of central government budget
264
TAIWAN','499158d61bcbcc3eecf0fbc255e276f10c6e87b98e6f05a6da3960035076acfc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

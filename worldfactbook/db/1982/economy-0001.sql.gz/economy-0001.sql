SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('578e0bd481d1bd1c00a7f8d82689ed4788b04e33121ea2698956438256013a8e',1982,'AF','Afghanistan','economy',6,'GNP: $2.8 billion (FY79), $225 per capita; real growth
rate 2.5% (1975-79)
Agriculture: subsistence farming and animal husbandry;
main crops — wheat, cotton, fruits
Major industries: carpets and textiles
Electric power: 360,000 kW capacity (1980); 756 million
kWh produced (1980), 50 kWh per capita
Exports: $670.2 million (f.o.b., 1980); mostly fruits and
nuts, natural gas, and carpets
Imports: $438.4 million (commercial, c.i.f., 1980); mostly
food supplies and petroleum products
Major trade partners: exports — mostly USSR and other
Eastern bloc countries; imports — mostly USSR and other
Eastern bloc countries
Budget: current expenditure Afl6.7 billion, capital ex-
penditure Afll.7 billion for FY79 (est.)
Monetary conversion rate: 44.85 Afghanis=US$l (offi-
cial, end 1980)
Fiscal year: 21 March-20 March','47d9d58a1df683af5b33bf5df2e9eca578a0eadcc989e86f3fe2425d0b12db0e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('361fcca1975db45c21e2e06b109c9fd0319ad1830fc0af15098a51f9e02185cd',1982,'AL','Albania','economy',11,'GNP: $1.2 billion in 1972 (at 1970 prices), $520 per capita
Agriculture: food deficit area; main crops — corn, wheat,
tobacco, sugar beets, cotton; food shortages — wheat; caloric
intake, 2,503 calories per day per capita (1972/74)
Major industries: agricultural processing, textiles and
clothing, lumber, and extractive industries
Shortages: spare parts, machinery and eauipment, wheat
Electric power: 1,390,000 kW capacity (1981); 4.350
billion kWh produced (1981), 1,575 kWh per capita
Exports: $150.5 million (1978 est.); 1964 trade— 55%
minerals, metals, fuels; 23% foodstuffs (including cigarettes);
17% agricultural materials (except foods); 5% consumer
goods
Imports: $173.4 million (1978); 1964 trade— 50% machin-
ery, eauipment, and spare parts; 16% minerals, metals, fuels,
construction materials; 16% foodstuffs; 7% consumer goods;
7% fertilizers, other chemicals, rubber; 4% agricultural
materials (except foodstuffs)
Monetary conversion rate: 4.14 leks=US$l (1980)
Fiscal year: same as calendar year; economic data report-
ed for calendar years except for caloric intake, which is
reported for consumption year 1 July-30 June','f12f0e6df7841d092dc12c856d59070161dd7a6e9400ff8486599597364b02c0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ae81a9450366fc8bb01388f6546e13f8d8498649f6e8197881764bb26cdd086',1982,'DZ','Algeria','economy',15,'GDP: $41.0 billion (1981 est.), $1,720 per capita; 6.2% real
growth in 1981
Agriculture: main crops — wheat, barley, grapes, citrus
fruits
Major industries: petroleum, light industries, natural gas,
mining, petrochemical, electrical, and automotive plants
under construction
Electric power: 1,780,000 kW capacity (1980); 6,400
million kWh produced (1980), 336 kWh per capita
Exports: $14.0 billion (f.o.b., 1981 est.); major items —
petroleum and gas 98.0%; US 52.0%, France 23.0%
Imports: $11.0 billion (f.o.b., 1981 est.); major items —
capital goods 32.0%, semifinished goods 25.0%, foodstuffs
19.0%; France 23.0%, US 7.4%
Major trade partners: US, West Germany, France, Italy
Monetary conversion rate: 1 Algerian dinar (DA)=
US$0.23
Fiscal year: calendar year
4
GDP: about $689 million (1980 est.), $400 per capita,
average annual increase in current prices about 1 1 %
(1974-80)
Agriculture: most Mauritanians are nomads or subsistence
farmers; main products — livestock, cereals, vegetables, dates;
cash crops — gum arabic
Fishing: local catch, 34,170 metric tons (1980 est.); ex-
ports, 42,000 metric tons (1980 est.)
Major industries: mining of iron ore and gypsum, fishing
Electric power: 70,000 kW capacity (1980); 105 million
kWh produced (1980), 69 kWh per capita
Exports: $194 million (f.o.b., 1980 prelim.); iron ore, fish
Imports: $307 million (f.o.b., 1980); foodstuffs, petroleum,
capital goods
Major trade partners: (trade figures not complete because
Mauritania has a form of customs union with Senegal and
much local trade unreported) France and other EC mem-
bers, UK, and US are main overseas partners
Budget: $204 million (budgeted) current expenditures,
$10.5 million capital expenditures, $114.9 million extra
budgetary expenditure, $140.4 million revenue (1980)
Monetary conversion rate: 48.66 Ouguiyas=US$l as of
November 1981
Fiscal year: calendar year','85cb815b8421a71a24bdf347a8410d66f2c491bf3b057aecc52823662a427c98','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98b1d427c59c5dea889847c39570fd05c2e6270d78a4440c2c804fde0087f9f4',1982,'AO','Angola','economy',20,'Agriculture: sheep raising; small quantities of tobacco,
rye, wheat, barley, oats, and some vegetables (less than 4% of
land is arable)
Major industries: tourism, sheep, timber, tobacco, and
smuggling
Electric power: 25,000 kW capacity (1981); 100 million
kWh produced (1981), 3,450 kWh per capita; power is
mainly exported to Spain and France
Major trade partners: Spain, France
GDP: $3.9 billion (1980 est.), $591 per capita, 0.0% real
growth (1980)
Agriculture: cash crops — coffee, sisal, corn, cotton, sugar,
manioc, and tobacco; food crops — cassava, corn, vegetables,
plantains, bananas, and other local foodstuffs; largely self-
sufficient in food
Fishing: catch 106,073 metric tons (1979)
Major industries: mining (oil, diamonds), fish processing,
brewing, tobacco, sugar processing, textiles, cement, food
processing plants, building construction
Electric power: 600,000 kW capacity (1980); 1.4 billion
kWh produced (1980), 206 kWh per capita
Exports: est. $1,900 million (f.o.b., 1980); oil, coffee,
diamonds, sisal, fish and fish products, iron ore, timber, corn,
and cotton; exports down sharply 1975-77
Imports: est. $1,350 million (f.o.b., 1980); capital equip-
ment (machinery and electrical equipment), wines, bulk iron
and ironwork, steel and metals, vehicles and spare parts,
textiles and clothing, medicines; military deliveries partially
offset drop in imports in 1975-77
Major trade partners: Cuba, USSR, Portugal, and US
Budget: (1975) balanced at about $740 million by former
Portuguese administration; budget not yet published by new','6d63c41abf5ceb4507218251867cf975411633a91225da83cce7cb4efa70e975','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcea4df35474d99f57e0b0ecf3361ffce789b0752ef16398fab30a7afd852f2b',1982,'AG','Antigua and Barbuda','economy',26,'GDP: $73 million (1978 est.), $1,000 per capita; 3% real
growth in 1980
Agriculture: main crop, cotton
Major industry: tourism
Electric power: 28,000 kW capacity (1981); 55 million
kWh produced (1981), 714 kWh per capita
Exports: $21 million (f.o.b., 1980 est.); clothing, rum,
lobsters
Imports: $76 million (c.i.f., 1980 est.); fuel, food,
machinery
Major trade partners: 30% UK, 25% US, 18% Common-
wealth Caribbean countries (1975)
Aid: economic — bilateral commitments, ODA and OOF
(1970-79) from Western (non-US) countries, $20 million; no
military aid
Budget: (current) revenues, $24 million (1980 prelim.);
current expenditures, $33 million (1980 prelim.)
Monetary conversion rate: 2.70 East Caribbean (EC)
dollar=US$l (1980)
Fiscal yean 1 April-30 March','3bbfa828e56d6767f341cf13d66b58e85325042f4811c8327ab70888deb7feae','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a878b2c12164419f6854fa7b86215f3a37789b5d2a853925aec0c4d757e8649',1982,'AR','Argentina','economy',30,'GNP: $143 billion (1980), $5,257 per capita; 69% con-
sumption, 26% investment, 6% net foreign demand (1979);
real GDP growth rate 1980, -0.3%
Agriculture: main products— cereals, oilseed, livestock
products; Argentina is a major world exporter of temperate
zone foodstuffs
9','235e400e9d79b13f21f7cde58e9a6f8d22b944a52d2ea8ba454e44e5769abac6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd693622dbad3fb559dd81f8149167f845e78ca1b755f162ddcd0e71e9728a5b',1982,'AU','Australia','economy',31,'ARGENTINA (Continued)
Fishing: catch 537,323 metric tons (1978); exports $42
million (1976 est.)
Major industries: food processing (especially meatpack-
ing), motor vehicles, consumer durables, textiles, chemicals,
printing, and metallurgy
Crude steel: 3.2 million metric tons produced (1979), 120
kg per capita
Electric power: 10,500,000 kW capacity (1981); 40.0
billion kWh produced (1981), 1,454 kWh per capita
Exports: $8.0 billion (f.o.b., 1980); meat, corn, wheat,
wool, hides, oilseed
Imports: $9.4 billion (f.o.b., 1980); machinery, fuel and
lubricating oils, iron and steel, intermediate industrial
products
Major trade partners (1980): exports— 9% Brazil, 9%
Netherlands, 8% Italy, 9% US, 6% FRG, 5% USSR, Japan,
and Spain; imports— 26% US, 10% Brazil, 11% FRG, 4%
Italy, 11% Japan, 3% Chile
Budget: (1980) approximately $20 billion at exchange rate
of first quarter 1980
Monetary conversion rate: 1,930 pesos=US$l (mid-
September 1980)
Fiscal year: calendar year
GNP: $120.4 billion (1979), $8,360 per capita; 60% private
consumption, 16% government current expenditure, 24%
investment (1975); 2.8% real average annual growth (1979)
Agriculture: large areas devoted to livestock grazing; 60%
of area used for crops is planted in wheat; major products —
wool, livestock, wheat, fruits, sugarcane; self-sufficient in
food; caloric intake, 3,300 calories per day per capita
Fishing: catch 122,947 metric tons (1978); exports $94.5
million (FY75), imports $86.2 million (FY75)
Major industries: mining, industrial and transportation
equipment, food processing, chemicals
Crude steel: 7.8 million metric tons produced (FY76), 560
kg per capita
Electric power: 26,358,140 kW capacity (1980); 98.843
billion kWh produced (1980), 6,728 kWh per capita
Exports: $18.7 billion (f.o.b., 1979); principal products
(1979) — 44% agricultural products, 14% metalliferous ores,
10% wool, 10% coal
Imports: $18.3 billion (c.i.f., 1979); principal products
(1977) — 41% manufactured raw materials, 28% capital
equipment, 25% consumer goods
Major trade partners: (1979) exports— 28% Japan, 12%
US, 5% New Zealand, 4% UK; imports— 23% US, 11% UK,
18% Japan
Aid: economic — Australian aid abroad in Australian dol-
lars, $662 million (FY81-82); for Papua New Guinea in US
dollars, $290 million per year 1981-86
Budget: expenditures, A$40.86 billion; receipts A$40.72
billion (FY81-82)
Monetary conversion rate: 1.0 Australian dollar=US$1.08
(February 1982)
Fiscal year: 1 July-30 June
GNP: $811 million (1979), $1,300 per capita; 6% real
growth rate (1979)
Agriculture: main crops — sugar, coconut products, ba-
nanas, ginger, rice; major deficiency, grains
Major industries: sugar processing, tourism
Electric power: 117,000 kW capacity (1981); 351 million
kWh produced (1981), 550 kWh per capita
Exports: $258.0 million (f.o.b., 1979, including reexports
totaling $56.9 million); 57.8% sugar, 5.4% coconut oil
Imports: $471.4 million (c.i.f., 1979); 23.0% machinery,
fuels, chemicals, 19.0% manufactured goods, 18.4% petrole-
um, 17.0% food
Major trade partners: UK, New Zealand, US, Canada,
Australia, Japan
Aid: disbursed 1978— UK, Australia, and New Zealand,
$42.3 million
Budget: (FY80) outlays $280 million (current prices)
Monetary conversion rate: Fijian dollar=US$1.2 (1979)
Fiscal year: calendar year','54c8f6b3d7b4dd6d27fe335bd44f01139f8d56745c31066c079975b5270912e2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99df7002d153107c8e25899fd12ad82a3f7bc1a51e2d21d1c4f10863733a2f94',1982,'AT','Austria','economy',38,'GNP: $62.16 billion (1980), $8,280 per capita; 56% private
consumption, 18% public consumption, 26% investment;
1980 real GNP growth rate, 0.3%
Agriculture: livestock, forest products, cereals, potatoes,
sugar beets; 84% self-sufficient; caloric intake 3,230 calories
per day per capita (1969-70)
Major industries: foods, iron and steel, machinery, tex-
tiles, chemicals, electrical, paper and pulp
Crude steel: 4.9 million metric tons produced (1979), 650
kg per capita (1979)
Electric power: 13,200,000 kW capacity (1980); 40.815
billion kWh produced (1980), 6,728 kWh per capita
Exports: $17.2 billion (f.o.b., 1980); iron and steel prod-
ucts, machinery and equipment, lumber, textiles, paper
products, chemicals
Imports: $23.4 billion (c.i.f., 1980); machinery and equip-
ment, chemicals, textiles and clothing, petroleum, foodstuffs
12
THE BAHAMAS
AUSTRIA (Continued)
Major trade partners: (1980) 37.1% West Germany, 9.5%
Italy, 6.2% Switzerland, 3.5% UK, 2.8% US; 59.8% EC;
10.1% Eastern Europe
Aid: (1970-79) bilateral economic aid authorized (ODA
and OOF), $670 million
Budget: expenditures, $23.18 billion; revenues, $19.45
billion; deficit, $3.73 billion (1982)
Monetary conversion rate: 15.89 shillings=US$l, 1981
average
Fiscal year: calendar year','064c9289da9e1c7d3c7f86238db636a72e2a1ee7480c0e242c841cf6e2d47adc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('469db41881bdd49619bd51e193dfe43f91f11190f21bb2f6d205e226f953f2f9',1982,'BH','Bahrain','economy',40,'GNP: $1,083 million (1979), $4,650 per capita; real growth
rate 3-4% (1980)
Agriculture: food importer, main crops — fish, fruits,
vegetables
Major industries: tourism, cement, oil refining, lumber,
salt production, rum, aragonite, pharmaceuticals, spiral
weld, and steel pipe
Electric power: 320,000 kW capacity (1981); 650 million
kWh produced (1981), 3,307 kWh per capita
Exports (nonoil): $194 million (f.o.b., 1979); pharmaceuti-
cals, cement, rum
Imports (nonoil): $364 million (f.o.b., 1979); foodstuffs,
manufactured goods
Major trade partners: nonoil exports — US 41%, UK 12%,
Canada 3%; nonoil imports— US 73%, UK 13%, Canada 2%
(1973)
Aid: economic — bilateral commitments including Ex-Im
(1970-80) from US, $34.3 million; from other Western
countries (1970-79), $137.7 million; no military aid
Budget: (1979 actual) revenues, $208 million; expend-
itures, $216 million
Monetary conversion rate: 1 Bahamian dollar=US$l
Fiscal year: calendar year','f28bf7d7983e51cebdbd75b4abd062a9ebe6a9d09ccfa0e7a4aa629e29f4c0af','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('117a6909b417bc35fbfa8e41cf818bcc54349d62e37134b12f3cff7de988e414',1982,'BD','Bangladesh','economy',44,'GDP: $1.8 billion (1980 est.), $4,600 per capita; annual
real growth rate (1973-77) 11%, dominated by oil industry;
1980 average daily crude oil production, 48,000 b/d (oil
expected to last 15 years if no new discoveries are made);
1980 natural gas production, 177 billion ft3; government oil
revenues for 1978 are estimated at $845 million
Agriculture: produces dates, alfalfa, vegetables; dairy and
poultry farming; fishing; not self-sufficient in food
Major industries: petroleum refining, aluminum smelt-
ing, ship repairing, shrimp fishing, pearls and sailmaking on
a small scale; major development projects include flourmill,
and ISA town; OAPEC dry dock opened in 1977
Electric power: 900,000 kW capacity (1980); 4.0 billion
kWh produced (1980), 10,204 kWh per capita
Exports: $3.8 billion (f.o.b., 1980); nonoil exports (includ-
ing reexports), $550.8 million (1980); oil exports, $3.3 billion
(1980)
Imports: $3.6 billion (c.i.f., 1980); nonoil imports $1.6
billion (1980); oil imports $2.0 billion (1980)
Major trade partners: Saudi Arabia, UK, US, Japan, EC
Budget: (1980) $488 million current expenditure, $302
million capital
Monetary conversion rate: 1 Bahrain dinar=US$2.65
(1980)
Fiscal year: calendar year','c475a695bbb5ca1c15af88036ce0edf559d068534d54c8e11ef8e2fb627a8999','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d83709a92f428597c4fa2c9dbc6c49389d3e908abe71664052b770a8bbd4e9b5',1982,'CN','China','economy',49,'GNP: $9.1 billion est. (FY79, current prices), $100 per
capita; real growth, 4.4% (FY79)
Agriculture: large subsistence farming, heavily dependent
on monsoon rainfall; main crops are jute and rice; short-
ages— grain, cotton, and oilseed
Fishing: catch 835,000 metric tons (FY78)
Major industries: jute manufactures, food processing and
cotton textiles
Electric power: 1,302,000 kW capacity (1980); 1.750
billion kWh produced (1980), 20 kWh per capita
Exports: $759 million (f.o.b. 1980); raw and manufactured
jute, leather, tea
Imports: $2,348 million (f.o.b. 1980); foodgrains, fuels,
raw cotton, fertilizer, manufactured products
Major trade partners: exports— US 14%, USSR 8%; im-
ports—US 19%, Japan 12% (FY79)
Budget: (FY81) domestic revenue, $2,379 million; expend-
itures, $2,203 million
Monetary conversion rate: 16 taka=US$l (June 1981)
Fiscal year: 1 July-30 June
GNP: $552 billion (1980), $538 per capita
Agriculture: main crops — rice, corn, wheat, miscellaneous
grains, oilseed, cotton; agriculture mainly subsistence; grain
imports 13.7 million metric tons in 1980
43
Agriculture: main crops — rice, vegetables; food short-
ages— rice, vegetables, meat; depends mostly on imports for
food requirements
Major industries: textiles, fireworks
Electric power: 116,856 kW capacity (1981); 234 million
kWh produced (1981), 805 kWh per capita
Exports: $404.5 million (f.o.b., 1979), plus reexports $55.7
million; textiles and clothing, foodstuffs
Imports: $365.0 million (c.i.f., 1979)
Major trade partners: exports — 16.6% West Germany,
15.7% France, 23.2% US; imports— 51.0% Hong Kong, 30.0%
China (1979)
Monetary conversion rate: 5.0/4.9 patacas=US$l (August
1979); pataca has been pegged to Hong Kong dollar since
1977
Fiscal year: calendar year
GNP: $4.9 billion (calculated by UNO method), less than
$91 per capita (1980); no growth in recent years
Agriculture: main crops — rice, rubber, fruits and vegeta-
bles; sonfe corn, manioc, and sugarcane; major food im-
ports— wheat, corn, dairy products
Fishing: catch 515,000 metric tons (1980)
Major industries: food processing, textiles, machine
building, mining, cement, chemical fertilizer, glass, tires
Shortages: foodgrains, petroleum, capital goods and ma-
chinery, fertilizer
Electric power: 1,610,300 kW capacity (1980); 3.781
billion kWh produced (1980), 69 kWh per capita
Exports: $300 million (1978); agricultural and handicraft
products, coal, minerals, ores
Imports: $900 million (1978); petroleum, steel products,
railroad equipment, chemicals, medicines, raw cotton, fertil-
izer, grain
Major trade partners: exports — USSR, East European
countries, Japan, other Asian markets; imports — USSR, East
Europe, Japan
Aid: accurate data on aid since April 1975 unification
unavailable; estimated annual economic aid on annual basis
is — USSR, $500 million or more; East European countries,
$150 million; non-Communist countries, $230 million; inter-
national institutions, $75 million; value of military aid
deliveries since 1975 are not available
Monetary conversion rate (official): 9.0 dong=US$l (late
1981)
Fiscal year: calendar year','9adabe678fb8399b5ad9c730ccb5b6998c0702b3639203d70b803c5b0d4fd969','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b4da06f870dfecb4cab416d9bf818333bf58918ffdfd2552952314907d3bc40',1982,'BB','Barbados','economy',53,'GDP: $811 million (1980), $3,257 per capita; real growth
rate 1980, 5%
Agriculture: main products — sugarcane, subsistence foods
Major industries: tourism, sugar milling, light manu-
facturing
Electric power: 110,000 kW capacity (1981); 325 million
kWh produced (1980), 1,265 kWh per capita
Exports: $207 million (f.o.b., 1980); sugar and sugarcane
byproducts, electrical parts, clothing
Imports: $424 million (c.i.f., 1979); foodstuffs, consumer
durables, machinery, fuels
Major trade partners: exports— 36% US, 27% CAR1COM,
UK; imports— 34% US, 18% CAR1COM, UK, Canada (1980)
Aid: economic — bilateral commitments including Ex-Im
(FY70-80) from US, $9.3 million; (1970-79) ODA and OOF
commitments from other Western countries, $52.1 million;
no military aid
Budget: (1980) revenues, $223 million; expenditures, $270
million
Monetary conversion rate: 2.01 Barbados dollars=US$l
Fiscal year: 1 April-31 March','5beafd2ab28087a759d9c5c46a2ec04ee3a9f6f2d84ac5d73414ae1ff997aa3b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91207ce750e65d74b18f141a13c10b24429347f50e3441ebe6608fac7a19d86d',1982,'BE','Belgium','economy',57,'GNP: $118.5 billion (1980), $12,017 per capita; 64.3%
consumption, 21.1% investment, 18.7% government con-
sumption, 0.08% stock building, —0.91% net foreign balance
(1978); 2% real growth rate in 1980
1H
BELGIUM (Continued)
Fishing: catch 33,178 metric tons (1978); exports $60
million (1978), imports $327 million (1978)
Major industries: engineering and metal products, proc-
essed food and beverages, chemicals, basic metals, textiles,
and petroleum
Crude steel: 18.0 million metric tons capacity (December
1981); 13.4 million metric tons produced, 1,360 kg per capita
(1978)
Electric power: 12,500,000 kW capacity (1980); 53,643
million kWh produced (1980), 5,440 kWh per capita
Exports: (Belgium-Luxembourg Economic Union) $88.9
billion (f.o.b., 1980); iron and steel products, finished or
semifinished precious stones, textile products
Imports: (Belgium-Luxembourg Economic Union) $93.5
billion (c.i.f., 1980); nonelectrical machinery, motor vehicles,
textiles, chemicals, fuels
Major trade partners: (Belgium-Luxembourg Economic
Union, 1979) 70% EC (22% West Germany, 17% France,
16% Netherlands, 8% UK, 5% Italy), 5% US
Aid: (1970-79) bilateral economic aid authorized (ODA
and OOF), $3,018 million
Budget: (1982 proj.) revenues, Belgian francs (BF) 1,153.5
billion; expenditures, BF 1,507.7 billion; deficit, BF $354.2
billion
Monetary conversion rate: (1980 average) 29.243 Belgian
Francs=US$l
Fiscal year: calendar year','e4ce1a6002bac50e3e8def1a20270bb99bcb167eb33fb9c903abf4cf3786a0cb','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c499122b5caf5880eefb276b68871870745413ec404086a3507c89d587eac00c',1982,'BZ','Belize','economy',61,'GDP: $140 million (1979), $960 per capita (1979 est.); real
growth rate 1980, 4% (est.)
Agriculture: main products — sugarcane, citrus fruits,
corn, molasses, rice, beans, bananas, livestock products; net
importer of food; caloric intake, 2,500 calories per day per
capita
Major industries: sugar refining, garments, timber and
forest products, furniture, rum, soap
Electric power: 16,000 kW capacity (1980); 42 million
kWh produced (1980), 288 kWh per capita
Exports: $130 million (f.o.b., 1980 est.); sugar, garments,
fish, molasses, citrus fruits
Imports: $141 million (c.i.f., 1980 est.); machinery and
transportation equipment, food, manufactured goods, fuels
Major trade partners: exports — US 43%, UK 37%, Trini-
dad and Tobago 6%, Mexico 2%; imports— US 52%, UK 17%,
Netherlands Antilles 5% (1979 est.)
Aid: economic — authorized from US, including Ex-lm
(FY70-80), 5.3 million; bilateral ODA and OOF commit-
ments from Western (non-US) countries (1970-79), $93.4
million
Budget: revenues, $88 million; expenditures, $88 million
(projected budget for April 1981 through March 1982)
Monetary conversion rate: 2 Belize dol!ars=US$l
Fiscal year: calendar year','9b319e62d0d09f0306c1b9f805f52b384b25ba177c9331a77b90b03d313b696d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01b2b236ea37bdb5bddaaaf17866e67a9aa840cb6cf8cdc73ceff3e6576bf1db',1982,'BJ','Benin','economy',65,'GNP: $1,139.5 million (1980), $286 per capita; 5.7% real
growth during 1980
Agriculture: major cash crop is oil palms; peanuts, cotton,
coffee, sheanuts, and tobacco also produced commercially;
main food crops — corn, cassava, yams, rice, sorghum and
millet; livestock, fish
Fishing: catch 25,452 metric tons (1979 est.); exports 600
metric tons, imports 7,365 metric tons (1979)
Major industries: palm oil and palm kernel oil processing,
textiles, beverages
Electric power: 19,500 kW capacity (1980); 8 million
kWh produced (1980), 80 million kWh imported from
Ghana, 2 kWh per capita
Exports: $170 million (f.o.b., 1980); palm products (34%);
other agricultural products
Imports: $410 million (c.i.f., 1980); clothing and other
consumer goods, cement, lumber, fuels, foodstuffs, machin-
ery, and transport equipment
Major trade partners: France, EC, franc zone; preferen-
tial tariffs to EC and franc zone countries
Budget: (1980) revenues $156.2 million, current expendi-
tures $127.1 million, development expenditures $139.0
million
Monetary conversion rate: 281.23 Communaute Finan-
cier Africaine (CFA) francs=US$l (1981)
Fiscal year: calendar year','32c72d5d87b0102de57ee441572dc53f99adbc2d441773470506f97d70ff05cf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83d51f0d55016f3d78c20d5ae94b8860411696bf72c3b56bf5feab86734c3c4b',1982,'BT','Bhutan','economy',70,'GDP: $598 million (FY79/80), $10,894 per capita; real
growth rate FY79/80, est. 3%
Agriculture: main products — bananas, vegetables, Easter
lilies, dairy products, citrus fruits
Major industries: tourism, finance
Electric power: 110,000 kW capacity (1981); 355 million
kWh produced (1981), 5,460 kWh per capita
Exports: $31 million (f.o.b., 1979); mostly reexports of
drugs and bunker fuel
Imports: $234 million (f.o.b., 1979); fuel, foodstuffs,
machinery
Major trade partners: imports, 50% US; tourists, 90% US
Aid: economic — bilateral commitments, including Ex-Im
(1970-80), from US $34 million; from" Western (non-US)
countries, ODA and OOF (FY70-79), $109 million; no
military aid
Budget: revenues, $132 million; expenditures $132 mil-
lion; (FY81/82)
Monetary conversion rate: 1 Bermuda dollar=US$l
Fiscal year: 1 April-31 March','3d759e8c19e8a83bd1a2975f223807af4a3bb44478112bf3b20ae13d6a9a8870','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cbe873e935637a6076a6ffd372b618bb23195f9498be3aebbcc2fd1038ec9d4',1982,'IN','India','economy',75,'GNP: $116 million (FY81), $97 per capita; 3.6% growth in
FY81
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 3,000 kW capacity (1981); 8 million kWh
produced (1981), 6 kWh per capita
Exports: $12 million (FY81); fruit and vegetables, timber,
coal, and cardamom
Imports: about $19 million (FY81); textiles, cereals,
vehicles
Major trade partner: India
Aid: economic— India (FY61-72), $180 million
Budget: domestic revenue $12.9 million, expenditures
$39.3 million (FY81 est.)
Monetary conversion rate: both ngultrums and Indian
rupees are legal tender; 9.16 ngultrums=9.16 Indian
rupees=US$l as of October 1981
Fiscal year: 1 April-31 March
GNP: $6 billion (1980), $1,050 per capita; 75% private
consumption, 15% public consumption, 12% gross domestic
investment, —2.0% net foreign balance (1980); 1980 growth,
1%
Agriculture: main crops — potatoes, corn, rice, sugarcane,
yucca, bananas; imports significant quantities of wheat;
caloric intake, 83% of requirements (1978)
Major industries: mining, smelting, petroleum refining,
food processing, textiles, and clothing
Electric power: 460,000 kW capacity (1981); 1.6 billion
kWh produced (1981), 273 kWh per capita
Exports: $1.1 billion (f.o.b., 1980 est.); tin, petroleum,
lead, zinc, silver, tungsten, antimony, bismuth, gold, coffee,
sugar, cotton, natural gas
Imports: $1.2 billion (f.o.b., 1980 est.); foodstuffs, chemi-
cals, capital goods, pharmaceuticals, transportation
Major trade partners: exports — Western Europe, 19% (of
which UK is largest market); Latin America, 38%; US, 30%;
Japan, 3.9%; imports— US, 24%; Western Europe, 15.4% (of
which West Germany is largest supplier); Japan, 15.7%;
Latin America, 33.6% (1975)
Budget: $470 million revenues, $780 million expenditures
(1980 est.)
Monetary conversion rate: 24.75 pesos=US$l (October
1981)
Fiscal year: calendar year
GNP: $150.6 billion (FY8I est. at current prices), $217 per
capita; real growth 7% in FY8I
Agriculture: main crops — rice, other cereals, pulses, oil-
seed, cotton, jute, sugarcane, tobacco, tea, and coffee
105
GNP: $27.8 billion (FY81 est.), $332 per capita; average
annual real growth, 5.7% (FY79-81)
Agriculture: extensive irrigation; main crops — wheat, rice,
sugarcane, and cotton
Fishing: catch 304,500 metric tons (FY81 est.)
Major industries: cotton textiles, food processing, tobacco,
engineering, chemicals, natural gas
Electric power: 3,920,000 kW capacity (1980); 17.64
billion kWh produced (1980), 207 kWh per capita
Exports: $2,958 million (f.o.b., FY81); primarily rice,
cotton (raw and manufactured), carpets, rugs and mats,
petroleum products, leather
Imports: $5,486 million (f.o.b., FY81; petroleum crude
and products, sugar, machinery, tea, medicaments, chemi-
cals, iron and steel
Major trade partners: US, UK, West Germany, Saudi
Arabia, Japan, China
Budget: FY81 — current expenditure, $3,213.7 million;
capital expenditures, $2,669.8 million
Monetary conversion rate: 9.9 rupees=US$l (February
1973 through January 1982)
Fiscal year: 1 July-30 June','995f84ceea9bbd86ae9fbd54db124c0f3976fc6c2a368ef0b48d039ac6f009d1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65dd0c9af07442b47a9e2fd444c808cc4360d5e2f5b0bb65cc84072fe2c9ecaf',1982,'BW','Botswana','economy',79,'GDP: $856.3 million; growth in constant prices, 11.0% in
FY79/80, 5% in 1977
Agriculture: principal crops are corn and sorghum; live-
stock raised and exported
Major industries: livestock processing, mining of dia-
monds, copper, nickel, and coal
Electric power: 75,000 kW capacity (1977); 85 million
k Wh produced (1977), 120 k Wh per capita
Exports: $478.4 million (f.o.b., 1980); diamonds, cattle,
animal products, copper, nickel
Imports: $643.9 million (c.i.f., 1980); foodstuffs, vehicles,
textiles, petroleum products
Major trade partners: South Africa and UK
Budget: (1981) revenues $252.4 million, current expendi-
tures $247.4 million, development expenditures $150.0
million 4
Monetary conversion rate: I pula=about US$1.23 (1981)
Fiscal year: 1 April-31 March
26','289d44719ecfea3f1a6319e697c53aae1c442f644490db7cb4e7d6aa31c316b0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71be7ea4ef8a82b0d2a937279975a85014e1252901bbfd05ff1900a61746c907',1982,'BR','Brazil','economy',80,'BOTSWANA (Continued)
GNP: $250 billion (1981 est.), $2,000 per capita; 20% gross
investment, 84% consumption, —4% net foreign balance
(1981 est.); real growth rate 1% (1981 est.)
Agriculture: main products— coffee, rice, beans, corn,
sugarcane, soybeans, cotton, manioc, oranges; nearly self-
sufficient; caloric intake, 2,400 calories per day per capita
(1975)
Fishing: catch 857,971 metric tons (1978); exports, $140
million (f.o.b., 1981 est.); imports, $90 million (f.o.b., 1981
est.)
Major industries: textiles and other consumer goods,
chemicals, cement, lumber, steel, motor vehicles, other
metalworking industries, capital goods
Crude steel: 12.5 million metric tons capacity (1978); 12.5
million metric tons produced (1981 est.)
Electric power: 32,271,000 kW capacity (1981); 126.0
billion kWh produced (1981), 1,033 kWh per capita
Exports: $23 billion (f.o.b., 1981 est); coffee, manufac-
tures, iron ore, cotton, soybeans, sugar, wood, cocoa, beef,
shoes
Imports: $22 billion (f.o,b., 1981 est.); machinery, chemi-
cals, pharmaceuticals, petroleum, wheat, copper, aluminum
Major trade partners: exports — 17% US, 5% West Ger-
many, 6% Netherlands, 5% Japan, 4% Italy, 4% Argentina,
4% France (1981 est); imports— 40% oil exporters, 17% US,
5% West Germany, 5% Japan, 3% Argentina (1981 est.)
Budget: (1981 est.) revenues $21.0 billion, expenditures
$20.4 billion (Treasury budget only)
Monetary conversion rate: 125 cruzeiros=US$l (Decem-
ber 1981, changes frequently)
Fiscal year: calendar year
GNP: $460 million (1975 est.), $2,970 per capita
Agriculture: main crops — rubber, rice, pepper, must im-
port most food
Major industry: crude petroleum, liquefied natural gas
Electric power: 147,000 kW capacity (1981); 404 million
kWh produced (1981), 1,740 kWh per capita
Exports: $1,900 million (f.o.b., 1978); 95% crude petro-
leum and liquefied natural gas
Imports; $261 million (c.i.f., 1978); 25% machinery and
transport equipment, 46% manufactured goods, 16% food
Major trade partners: exports of crude petroleum and
liquefied natural gas to Japan; imports from Japan 30%, US
24%, UK 15%, Singapore 9%
Budget: (1979) revenues $1 billion, expenditures $507
million, surplus $493 million; 70% defense
Monetary conversion rate: 2.2 Brunei dollars=US$l
Fiscal year: calendar year','32d7e071e37800ccfb86a983337c28d14d17c376374c4fd71ede9d4fc94379a8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e38f3882a24022e049a756ca4709450df6ec872c3c36e6b656315f2b0b51624',1982,'BG','Bulgaria','economy',87,'GNP: $39.8 billion, 1980 (1980 dollars), $4,489 per capita;
1980 real growth rate, -0.2%
Agriculture: mainly self-sufficient; main crops — grain,
vegetables; caloric intake, 3,461 calories per day per capita
(1972/74)
Fishing: catch 89,000 metric tons (1979)
Major industries: agricultural processing, machinery, tex-
tiles and clothing, mining, ore processing, timber
Shortages: some raw materials, metal products, meat and
dairy products, fodder
Crude steel: 2.6 million metric tons produced (1980), 293
kg per capita
Electric power: 9,333,000 kW capacity (1981); 32,700
million kWh produced (1981), 3,665 kWh per capita
Exports: $10.5 billion (f.o.b., 1980); 45% machinery,
equipment, and transportation equipment; 21% fuels, miner-
als, raw materials, metals, and other industrial material; 2%
agricultural raw materials; 23% foodstuffs, raw materials for
food industry, and animals; 9% industrial consumer goods
(1980)
Imports: $9.7 billion (f.o.b., 1980); 35% machinery, equip-
ment, and transportation equipment; 50% fuels, minerals,
raw materials, metals, other materials; 5% agricultural raw
materials; 5% foodstuffs, raw materials for food industry,
and animals; 5% industrial consumer goods (1979)
30
BURMA
BULGARIA (Continued)
Major trade partners: $20,217 million in 1980; 25% with
non-Communist countries, 53% with USSR, 22% with other
Communist countries
Monetary conversion rate: 0.95 leva=US$l (August 1981)
Fiscal year: calendar year; economic data reported for
calendar years except for caloric intake, which is reported
for consumption year 1 July-30 June
NOTE: Foreign trade figures were converted at the 1980
rate of 0.85 leva=US$l
GDP: $5.0 billion (1979/80, in current prices), $170 per
capita; real growth rate 5.9% (1979/80)
Agriculture: accounts for nearly 70% of total employment
and about 27% of GDP; main crops — paddy, sugarcane,
corn, peanuts; almost 100% self-sufficient; most rice grown
in deltaic land
Fishing: catch 518,700 metric tons (1977)
Major industries: agricultural processing; textiles and
footwear; wood and wood products; petroleum refining
Electric power: 719,000 kW capacity (1980); 1.438 billion
kWh produced (1980), 42 kWh per capita
Exports: $480 million (1980/81); rice, teak
Imports: $650 million (c.i.f., 1979); machinery and trans-
portation equipment, textiles, other manufactured goods
Major trade partners: exports — Singapore, Western Eu-
rope, China, UK, Japan; imports— Japan, Western Europe,
Singapore, UK
Budget: (1979/80) $3.4 billion est. revenues, $4.0 billion
expenditures, $600 million deficit
Monetary conversion rate: 7.0 kyat=US$l (1981)
Fiscal year: 1 April-31 March','eb8e1471bb2377d09e5dbfb0bf9d6102109a60e78cc3c605d65d1c4dc6c64f86','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e848d32fc621b180cdd3f5c216f7777018ffc602e27030600916e8c4306caeb',1982,'BI','Burundi','economy',91,'GNP: about $614.0 million (1978), $140 per capita; 2.0%
real growth (1970-74); real GDP growth in 1976, 7.8%
Agriculture: major cash crops — coffee, cotton, tea; main
food crops — manioc, yams, corn, sorghum, bananas, haricot
beans; marginally self-sufficient
Industries: light consumer goods such as beverages, blan-
kets, shoes, soap, assembly of imports
Electric power: 17,000 kW capacity (diesel generator
1980); 2 million kWh produced (1980), 35 million kWh
imported from Zaire, .05 kWh per capita
Exports: $90 million (f.o.b., 1979); coffee (90%), tea,
cotton, hides, skins
Imports: $102 million (c.i.f., 1979); textiles, foodstuffs,
transport equipment, petroleum products
Major trade partners: US, EEC countries
Budget: (1979) revenue $113.3 million, current expendi-
ture $38.0 million, development expenditure $38.0 million
Monetary conversion rate: 90 Burundi francs=US$l
(official)
Fiscal year: calendar year','604d17c94077891542ea16b8f07f52b6b1d09c67098f12c8a71741690d146a13','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6e5b65115c52664fb46b91a5e5f08346627bf0df90b718fec3959a87cc53003',1982,'CM','Cameroon','economy',92,'BURUNDI (Continued)
GDP: $5.6 billion (1980), about $675 per capita; real
annual growth rate, 4.1% (1971-81)
Agriculture: commercial and food crops — cocoa, coffee,
timber, cotton, rubber, bananas, peanuts, palm oil and palm
kernels; root starches, livestock, millet, sorghum, and rice
Fishing: imports 7,024 metric tons, $2.2 million; exports
909 metric tons (largely shrimp), $3.5 million (1975)
Major industries: small aluminum plant, food processing
and light consumer goods industries, sawmills
Electric power: 381,000 kW capacity (1980); 1.388 billion
kWh produced (1980), 160 kWh per capita
Exports: $1,620 million (f.o.b., 1980); cocoa and coffee
about 60%; other exports include timber, aluminum, cotton,
natural rubber, bananas, peanuts, tobacco, and tea
Imports: $1,550 million (f.o.b., 1980); consumer goods,
machinery, transport equipment, alumina for refining, pe-
troleum products, food and beverages
Major trade partners: most trade with France, other EC
countries, and the US
Budget: (1980) revenues $877.3 million, current expendi-
tures $608.6 million, development expenditures $268.7
million
Monetary conversion rate: 225.8 Communaute Finan-
ciere Africaine francs=US$l (1980)
Fiscal year: 1 JuIy-30 June','e2055bc484ba150046138a23bd5a462449061c2040330746c2967c9df23811b5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('074db2f19eeafdcb25c235ead94de8e0374d753b624a60d383fe1c5345e86912',1982,'CA','Canada','economy',99,'GNP: $252.2 billion (1980 in 1980 prices), $10,832 per
capita (1980); 63% consumption, 20% government, 20%
investment, —3% net foreign trade; real growth rate 5.3%
(1970-74), 2.8% (1975-80)
Agriculture: main products — livestock, grains (principally
wheat), dairy products; food shortages — fresh fruits and
vegetables; caloric intake, 3,180 calories per day per capita
(1966-67)
Fishing: catch 892 million metric tons; exports 784.7
million metric tons (1978)
Major industries: mining, metals, food products, wood
and paper products, transportation equipment, chemicals
Shortages: rubber, rolled steel, fruits, precision instru-
ments
Crude steel: 15.9 million metric tons produced (1980)
Electric power: 78,000,000 kW capacity (1980); 366.677
billion kWh produced (1980), 15,260 kWh per capita
Exports: $66,289 million (f.o.b., 1980; principal items-
transportation equipment, wood and wood products includ-
ing paper, ferrous and nonferrous ores, crude petroleum,
wheat; Canada is a major food exporter
36
CAPE VERDE
CANADA (Continued)
Imports: $59,473 million (f.o.b., 1980); principal items —
transportation equipment, machinery, crude petroleum,
communication equipment, textiles, steel, fabricated metals,
office machines, fruits and vegetables
Major trade partners: 67% US, 11% EC, 4.4% Japan
(1980)
Aid: economic — (received US, $412.8 million Ex-lm Bank,
FY70-79); Canada commitments to LDCs (1970-79), bilateral
ODA and OOF, $12.0 billion
Budget: total revenues $42,250 million; current expendi-
tures $51,213 million; gross capital expenditure $1,014 mil-
lion; budget deficit $9,167 million (1980; National Accounts
Basis)
Monetary conversion rate: there is no designated par
value for the Canadian dollar, which was allowed to float
freely on the exchanges beginning 1 June 1970; since then
the Canadian dollar has moved between US$0.81-1.04 in
value, C$1.00=US$0.8572 (official rate, 1980 average)
Fiscal year: 1 April-31 March','2864b58a4f2fa451d251864b8587ba38d0d9cac56eaa12b671f9e6285cefe100','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfdf9b44ee080490c5e69478879e60822688367459b4c1a7eaa6aa7b9204b8f7',1982,'CF','Central African Republic','economy',104,'GDP: $40.7 million (1978 est.); $136 per capita income;
0.0% growth rate
Agriculture: main crops — corn, beans, manioc, sweet po-
tatoes; barely self-sufficient in food
Fishing: catch 8,331 metric tons (1979 est.); largely
undeveloped but provides major source of export earnings
Major industries: salt mining
Electric power: 6,000 kW capacity (1980); 9 million kWh
produced (1980); 27 kWh per capita
Exports: $4.1 million (f.o.b., 1979); fish, bananas, salt,
flour
Imports: $71.1 million (c.i.f., 1979); petroleum products,
corn, rice, machinery, textiles
Major trade partners: Portugal, UK, Japan, African
neighbors
Budget: $17.1 million public revenue, $22.1 million cur-
rent expenditures (1980 est.)
Monetary conversion rate: 47 escudos=US$l (1981)
Fiscal year: calendar year
GDP: $535,5 million (1980 est.), $200 per capita, 1% real
growth
Agriculture: commercial — cotton, coffee, peanuts, ses-
ame, wood; main food crops — manioc, corn, peanuts, rice,
potatoes, beef; requires wheat, flour, rice, beef, and sugar
imports
Major industries: sawmills, cotton textile mills, brewery,
diamond mining and splitting
Electric power: 44,000 kW capacity (1980); 66 million
kWh produced (1980), 28 kWh per capita
Exports: $129.7 million (f.o.b., 1979 est.); cotton, coffee,
diamonds, timber
Imports: $101.6 million (f.o.b., 1979 est.); textiles, petro-
leum products, machinery and electrical equipment, motor
vehicles and equipment, chemicals and pharmaceuticals
Major trade partners: France, Yugoslavia, Japan, US
Budget: (1980) revenues $95.1 million (est.), current ex-
penditures $131.1 million (est.), development expenditures
$4.4 million (est.)
Monetary conversion rate: 225.8 Communaute Finan-
cier Africaine (CFA) francs=US$l (1980)
Fiscal year: calendar year','1fca72d9984536e53d18ec28e2027f6a721c1575d959f33237130a29097ff07b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9109312fbb53db6e1593fb446cb326bd1bd8552a3ba3ea58d9cfb629748ee1ea',1982,'TD','Chad','economy',110,'GDP: $500 million (1980), $109 per capita; estimated real
annual growth rate 0.6% (1971-81)
Agriculture: commercial — cotton, gum arabic, livestock,
fish; food crops — peanuts, millet, sorghum, rice, sweet pota-
toes, yams, cassava, dates; imports food
Fishing: catch 70,000 metric tons (1978 est.)
Major industries: agricultural and livestock processing
plants (cotton textile mill, slaughterhouses, brewery), natron
Electric power: 38,000 kW capacity (1980); 63 million
kWh produced (1980), 13 kWh per capita
Exports: $90.5 million (f.o.b., 1978 est.); cotton 80%,
livestock and animal products
Imports: $179.6 million (f.o.b., 1978 est); cement, petrole-
um, foodstuffs, machinery, textiles, and motor vehicles
Major trade partners: France (about 40% in 1973) and
UDEAC countries; preferential tariffs to EC and franc zone
countries
Budget: (1978 est.) public revenue $67.4 million, current
revenue $89.0 million
Monetary conversion rate: 212.72 Communaute Finan-
ciere Africaine (CFA) francs=US$l (1979)
Fiscal year: calendar year
40','a935ce5213cc0b609359d79638912fd7acf9916b7c66afd43b353724ded335c1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ea48fac4420fc94f5661e1db528cf44d5e15d70e09ee4edde2b362dfd40784e',1982,'CL','Chile','economy',111,'CHAD (Continued)
GDP: $20.0 billion (1980), $1,800 per capita; 72% private
consumption, 11% government consumption; 18% gross in-
vestment, —4% change in inventory, —5% net foreign
balance; real growth rate (1980), 6.5%
Agriculture: main crops — wheat, potatoes, corn, sugar
beets, onions, beans, fruits; net agricultural importer; 2,279
calories per day per capita (1978 est.)
Fishing: catch 2.8 million metric tons (1980); exports $339
million (1979)
Major industries: copper, other minerals, foodstuffs, fish
processing, iron and steel, pulp, paper, and forestry products
Crude steel: 765,000 million metric tons capacity (1980);
715,600 metric tons produced (1980)
Electric power: 3,100,000 kW capacity (1981); 12.0 billion
kWh produced (1981), 1,050 kWh per capita
Exports: $4.7 billion (f.o.b., 1980); copper, molybdenum,
iron ore, paper products, fishmeal, fruits, wood products
Imports: $5.8 billion (c.i.f., 1980); petroleum, sugar,
wheat, capita] goods, vehicles
Major trade partners: exports— 12% US, 12% FRG, 10%
Japan; 9% Brazil, 6% UK (1980); imports— 27% US, 10%
Japan, 8% Brazil, 5% FRG, 5% Venezuela (1980)
Budget: $7.3 billion revenues, $6.9 billion expenditures
(1980)
Monetary conversion rate: 39 pesos=US$l, fixed since 30
June 1979
Fiscal year: calendar year','a0b6f13384569150d8a4b46cbb1166fc138089460c1b074cb835ceb86e258646','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f3243bc028df50c2cacbc3e7df8335d3eb2da33d40c1b51f5838a5a49557e9f',1982,'CO','Colombia','economy',115,'CHINA (Continued)
Major industries: iron and steel, coal, machine building,
armaments, textiles, petroleum
Shortages: complex machinery and equipment, highly
skilled scientists and technicians, electricity
Crude steel: 34.48 million metric tons produced, 30 kg
per capita (1979)
Electric power: 66,000,000 kW capacity (1980); 301.0
billion kWh produced (1980), 290 kWh per capita
Exports: $13.8 billion (f.o.b., 1979); agricultural products,
oil, minerals and metals, manufactured goods
Imports: $14.5 billion (c.i.f., 1979); grain, chemical fertil-
izer, steel, industrial raw materials, machinery and
equipment
Major trade partners: Japan, Hong Kong, US, West
Germany, Romania, Australia, Canada, UK, France, USSR
(1979)
Monetary conversion rate: as of 9 September 1980, about
1.46 yuan=US$l (arbitrarily established)
Fiscal year: calendar year
GNP: $30.58 million (1980 est.; in current dollars), $1,112
per capita (1980; in current dollars); 73% private consump-
tion, 8% public consumption, 20% gross investment
Agriculture: main crops — coffee, rice, corn, sugarcane,
plantains, bananas, cotton, tobacco; caloric intake, 2,140
calories per day per capita (1970)
Fishing: catch 63,965 metric tons 1977; exports $10.6
million (1973), imports $10.3 million (1973)
Major industries: textiles, food processing, clothing and
footwear, beverages, chemicals, and metal products
Crude steel: 356,000 metric tons produced (1976), 14 kg
per capita
Electric power: 5,000,000 kW capacity (1981); 22.0 billion
kWh produced (1981), 808 kWh per capita
Exports: $4,113 million (f.o.b., 1980); coffee, fuel oil,
cotton, tobacco, sugar, textiles, cattle and hides, bananas
Imports: $3,851 million (f.o.b., 1980); transportation
equipment, machinery, industrial metals and raw materials,
chemicals and pharmaceuticals, fuels, fertilizers, paper and
paper products, foodstuffs and beverages
Major trade partners: exports — 4% Japan, 29% US, 20%
Germany, 9% Venezuela, 5% Netherlands; imports — 35%
US, 8% Germany, 10% Japan, 3% Ecuador, 4% UK, 5%
Venezuela, 4% France (1977)
Budget: (1980) revenues $2.9 billion; expenditures $2.8
billion
Monetary conversion rate: 56.39 pesos=US$l (September
1981, changes frequently)
Fiscal year: calendar year','941922208528860665fa6fd0b9ef56714788b95180704112d1f25bd77d0c9be3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ba2339574177351e67204d04b7f7b25ae6dc166183a517327826369dd36bf64',1982,'KM','Comoros','economy',122,'GNP: $78.8 million (1980), about $210 per capita
Agriculture: food crops — rice, manioc, maize, fruits, vege-
tables; export crops — essential oils for perfumes (mainly
ylang-ylang), vanilla, copra, cloves
Electric power: 2,400 kW capacity (1980); 4 million kWh
produced (1980); 11 kWh per capita
Exports: $11 million (f.o.b., 1980); perfume oils, vanilla,
copra, cloves
Imports: $33 million (f.o.b., 1980); foodstuffs, cement,
fuels, chemicals, textiles
Major trade partners: France, Madagascar, Kenya, Italy,
FRG, Tanzania, and US
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $110 million; OPEC, ODA
(1974-80), $33 million
Budget: (1980) revenues $24.5 million, current expendi-
tures, $38 million
Monetary conversion rate: 212.7 Communaute Finan-
ciere Africaine (CFA) francs=US$l in 1979, floating','8d9460fbf7d9f5d6f6455d81fec186296b221f578b2094f3436864780f8657f7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('275a102a3c6803b58540f50f7054dbe08a7eaa9fc22f35eec33be6b658dee95c',1982,'CG','Congo','economy',126,'GDP: about $1.0 billion (1980 est.), $667 per capita; real
growth rate 3.5% per year (1971-81)
Agriculture: cash crops — sugarcane, wood, coffee, cocoa,
palm kernels, peanuts, tobacco; food crops — root crops, rice,
corn, bananas, manioc, fish
Fishing: catch 19,447 metric tons (1978 est.)
Major industries: crude oil, sawmills, brewery, cigarettes,
sugar mill, soap
Electric power: 116,000 kW capacity (1980); 130 million
kWh produced (1980), 83 kWh per capita
Exports: $910.6 million (f.o.b., 1980); oil, lumber, tobacco,
veneer, and plywood
Imports: $545 million (f.o.b., 1980); machinery, transport
equipment, manufactured consumer goods, iron and steel,
foodstuffs, petroleum products, sugar
Major trade partners: France and other EC countries
Budget: (1980) revenues $345.6 million, current expendi-
tures $345.6 million, development expenditures $81.2
million
Monetary conversion rate: 202 Communaute Financiere
Africaine (CFA) francs=US$l (1980)
Fiscal year: calendar year','c5a5c291e0d9286fbc310704f258accc183a68a0bd0e9cb568f6a6e4ba5149b2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('402dccceb62f0f01ef127fde3a1c5a07013ec69a21338af8edb7f7459a5ed4ef',1982,'CR','Costa Rica','economy',131,'GDP: $15.4 million (1977), $860 per capita (1978)
Agriculture: export crops include copra, citrus fruits,
pineapples, tomatoes, and bananas, with subsistence crops of
yams and taro
Industry: fruit processing
Electric power: 4,000 kW capacity (1981); 13 million
kWh produced (1981), 733 kWh per capita
Exports: $3.0 million (1977); copra, fresh and canned fruit
Imports: $16.8 million (1977); foodstuffs, textiles, fuels
Major trade partners: (1970) exports — 98% New Zealand,
imports — 76% New Zealand, 7% Japan
Aid: Australia (1980-83), $2.0 million; Australia and New
Zealand (1977), $6.5 million
Government budget: $121 million (1977)
Monetary conversion rate: 1 New Zealand$=US$1.01
(1978/79)
GDP: $4.8 billion (1980, in current prices), $2,109 per
capita; 67.5% private consumption, 19.0% public consump-
tion, 24.2% gross domestic investment, —10.7% net foreign
balance (1980); 1.2% real growth rate (1980)
Agriculture: main products — bananas, coffee, sugarcane,
rice, corn, cocoa, livestock products; caloric intake, 2,550
calories per day per capita (1977); protein intake 58 grams
per day per capita (1974)
Fishing: catch 14,491 metric tons (1978); exports, $5.1
million (1976), imports, $0.3 million (1976)
Major industries: food processing, textiles and clothing,
construction materials, fertilizer
Electric power: 510,000 kW capacity (1980); 1.95 billion
kWh produced (1980), 860 kWh per capita
Exports: $1,017 million (f.o.b., 1980); coffee, bananas,
beef, sugar, cacao
Imports: $1,529 million (c.i.f., 1980); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels,
foodstuffs, fertilizer
Major trade partners: exports— 35% US, 27% CACM,
10% West Germany; imports— 36% US, 17% CACM, 4%
West Germany, 12% Japan (1980)
Aid: economic bilateral commitments — US authorized
(FY70-80) including Ex-Im $142 million, other Western
countries ODA and OOF (1970-79) $127 million, Commu-
nist (1971-74) $17 million; military commitments negligible
Budget: (1981) $825 million total revenues, $1,209 million
total expenditures including debt amortization
Monetary conversion rate: 2.0 colones=US$l
Fiscal year: calendar year','60e693fa5f11c8e8ea35d2aedd26dc109bffb56b73c132b092a07878fdc6495e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bdd1fdf39c5ad2d6028a5dffea626e046596cde235f4933790c1b4cdb7a02f4',1982,'CU','Cuba','economy',137,'GDP: $13.3 billion (1978 est., in 1978 prices), $1,360 per
capita; real growth rate 1978, 4.0%
Agriculture: main crops — sugar, tobacco, rice, potatoes,
tubers, citrus fruits, coffee
Fishing: catch 186,000 metric tons (1980); exports
$127million (1980)
Major industries: sugar milling, petroleum refining, food
and tobacco processing, textiles, chemicals, paper and wood
products, metals
Shortages: spare parts for transportation and industrial
machinery, consumer goods
Crude steel: 313,500 metric tons produced (1979); 30 kg
per capita
Electric power: 2,870,000 kW capacity (1981); 10.1 billion
kWh produced (1981), 1,029 kWh per capita
Exports: $5.6 billion (f.o.b., 1980); sugar, nickel, shellfish,
tobacco
Imports: $6.4 billion (c.i.f., 1980); capital goods, industrial
raw materials, food, petroleum
Major trade partners: exports — 57% USSR, 13% other
Communist countries; imports — 62% USSR, 16% other Com-
munist countries (1980 prelim.)
Aid: from US (FY46-61), $41.5 million (loans $37.5 mil-
lion, grants $4.0 million); economic aid (1960-78) from USSR,
$5.7 billion in economic credit and $11.0 billion in subsidies;
military assistance from the USSR (1959-78), $1.6 billion
51','e6a54be76d99e451cab9589ba138929c3fb8aa5e8a67a0ca48f0303a0e018e70','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a674870c9c34cbff24851c4ee4badfdebeeb768fd52335b4eeec88cb86bb3ec3',1982,'CY','Cyprus','economy',138,'CUBA (Continued)
Budget: $13.4 billion (1980)
Monetary conversion rate: 1 peso=US$1.41 (nominal;
1980)
Fiscal year: calendar year
GNP: $2,165 million (1980, est.), $4,223 per capita; 1980
est. real growth rate 4.2%
Turkish Sector GNP: $200.7 million (1978), $1,580 per
capita
Agriculture: main crops — potatoes, grapes, citrus fruit,
grains
Major industries: mining (iron pyrites, gypsum, asbestos),
manufactures principally for local consumption — beverages,
footwear, clothing, cement
Electric power: 500,000 kW capacity (1981); 1,042 billion
kWh produced (1981), 1,654 kWh per capita
Exports: $532.8 million (f.o.b., 1980); principal items —
food and beverages including citrus, raisins, potatoes and
wine, also cement and clothing
Turkish Sector exports: $40.2 million (f.o.b., 1979); princi-
pal items — citrus fruits, potatoes, metal pipes and pyrites
Imports: $1,214 million (c.i.f., 1980); principal items —
manufactured goods, machinery and transport equipment,
fuels, food
Turkish Sector imports: $107.5 million (c.i.f., 1979);
principal items are foodstuffs, raw materials, fuels,
machinery
Major trade partners: imports (1980)— 15.4% UK, 0.8%
Italy, 10.1% Iraq, 7.6% West Germany, 7.0% Greece; exports
(1980)— 20.7% UK, 7.7% Saudi Arabia, 6.8% Syria, 9.9%
Lebanon, 8.2% Libya
Turkish Sector major trade partners: imports (1979) —
43% Turkey, 21.2% UK, 7% Italy, 6.6% West Germany, 2.7%
France; exports (1979)— 66.4% UK, 21% Turkey, 3.7% West','e47223442ceb787acee125f6f0e502f94fab8b92dc06d011f47de5f1609e9611','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24f8af559151ca0eb50febf9242fa71d5f607710c27720f6ea3b7474b56b6485',1982,'DE','Germany','economy',142,'Budget: (1980 est.) revenues $489.7 million, expenditures
$582.7 million, deficit $93.0 million
Turkish Sector budget: (1980 prelim.) revenues $33.1
million, expenditures $62.0 million, deficit $28.9 million
Monetary conversion rate: 1 Cyprus pound=US$2.834
(1980 average)
Turkish Sector monetary conversion rate: 76.04 Turkish
Iira=US$l (1980 average)
Fiscal year: calendar year
53
CZECHOSLOVAKIA
CYPRUS (Continued)
GNP: $117.6 billion in 1980 (in 1980 dollars), $7,645 per
capita; 1980 real growth rate 1.9%
Agriculture: diversified agriculture; main crops — wheat,
rye, potatoes, sugar beets; net food importer— meat, wheat,
vegetable oils, fresh fruits and vegetables; caloric intake,
3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metal-
lurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 14.8 million metric tons produced (1979),
1,000 kg per capita
Electric power: 18,292,000 kW capacity (1981); 78.9
billion kWh produced (1981), 5,196 kWh per capita
Exports: $13,890 million (f.o.b., 1979); 53% machinery,
equipment; 26% fuels, raw materials; 4% foods, food
products, and live animals; 17% consumer goods, excluding
foods (1978)
Imports: $14,371 million (f.o.b., 1979); 40% machinery,
equipment; 45% fuels, raw materials; 8% foods, food
products, and live animals; 6% consumer goods, excluding
foods (1978)
Major trade partners: USSR, GDR, Poland, Hungary,
FRG, Romania, Bulgaria, Austria, UK; $28,261 million
(1979); 71% with Communist countries, 29% with non-
Communist countries
Monetary conversion rate: noncommercial 9.54 crowns=
US$1, commercial 5.35 crowns=US$l
Fiscal year: calendar year
NOTE: foreign trade figures were converted at the rate of
5.35 crowns=US$l
Aid: economic commitments — US, including Ex-lm
(FY70-80), $241 million; from other Western (non-US) coun-
tries, ODA and OOF, $99 million; military — assistance from
US (FY70-79), $22 million
Central government budget (1981 est.): expenditures,
$1,280 million; revenues, $815 million
Monetary conversion rate: 1 quetzal=US$l (official)
Fiscal year: calendar year','ea6fa0985a3fd26bc85556e712b2894a2267530aa2b7a2297087471c9fc9304b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee00a47b72bf5920833f109b0a52f1598e3f0fc3be355bf6e92144ae2430225',1982,'DK','Denmark','economy',149,'GNP: $64.6 billion (1980), $12,623 per capita; 51.6%
private consumption, 18.8% investment, 27.5% government,
3.5% net foreign sector and stock building; 1980 growth rate
—0.2%, constant prices
Agriculture: highly intensive, specializes in dairying and
animal husbandry; main crops — cereals, root crops; food
imports— oilseed, grain, feedstuffs; caloric intake, 3,180
calories per day per capita (1968-69)
Fishing: catch 1.7 million metric tons (1979), exports $707
million 1979 (est.)
Major industries: food processing, machinery and equip-
ment, textiles and clothing, chemical products, electronics,
transport equipment, metal products, bricks and mortar,
furniture and other wood products
Crude steel: 863,000 metric tons produced (1978), 170 kg
per capita
Electric power: 7,000,000 kW capacity (1980); 25.438
billion kWh produced (1980), 4,960 kWh per capita
Exports: $16.5 billion (f.o.b., 1980); principal items —
meat, dairy products, industrial machinery and equipment,
56
DENMARK (Continued)
textiles and clothing, chemical products, transport equip-
ment, fish, furs, and furniture
Imports: $19.2 billion (c.i.f., 1980); principal items —
industrial machinery, transport equipment, petroleum, tex-
tile fibers and yarns, iron and steel products, chemicals,
grain and feedstuffs, wood and paper
Major trade partners: 49.5% EC-nine (18.8% West Ger-
many, 13.2% UK); 13.0% Sweden; 5.0% US (1979)
Aid: donor — economic aid authorized (ODA and OOF)
$1.7 billion (1970-79)
Budget: (1981) expenditures $24.2 billion, revenues $21.36
billion
Monetary conversion rate: 5.6359 Kroner=US$l (1980)
Fiscal year: calendar year, beginning 1 January','01fe2342966dd0d708b18641448291ff6108508bb487813e84de0ab044287c55','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfaec6e1404dee344898525f00f337853c6f136e9918a61dc6973f0791b897f5',1982,'DM','Dominica','economy',154,'GNP: $264.7 million (1978)
Agriculture: livestock; desert conditions limit commercial
crops to about 6 hectares, including fruits and vegetables
Industry: ship repairs and services of port and railroad
drastically reduced with war of 1977-78 in Ethiopia s Oga-
den that cut the railroad line; it has since been reopened
Electric power: 55,000 kW capacity (1980); 220 million
kWh produced (1980), 770 kWh per capita
Imports: $92 million (1978); almost all domestically need-
ed goods — foods, machinery, transport equipment
Exports: $86 million (1978); hides and skins, and transit of
coffee; values plummeted after railroad line was cut
Monetary conversion rate: 178 Djibouti francs=US$l
Fiscal year: probably same as that for France (calendar
year)','0b03c3959fe62b5e416060ad40f59b52265dbda8ab8187551dca7a80db875476','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('408a45d8a7d70ff86b5180699c9410ce4499f36261aa6ebcecb4e5ad3c5e02f5',1982,'DO','Dominican Republic','economy',158,'GNP: $35 million (1980 est. in 1977 prices), $430 per
capita; 1980 real growth rate, —1.4% (est.)
Agricultural products: bananas, citrus, coconuts, cocoa,
dasheen
Major industries: agricultural processing, tourism
Electric power: 7,000 kW capacity (1981); 15 million
kWh produced (1981), 189 kWh per capita
Exports: $8.9 million (f.o.b., 1980 proj.); bananas, lime
juice and oil, cocoa, reexports
Imports: $49 million (c.i.f., 1980 proj.); machinery and
equipment, foodstuffs, manufactured articles, cement
Major trade partners: exports — 56% UK, 14% East Com-
mon Market, 17% rest of CARICOM, 6% other Caribbean,
4% US (1979); imports— 25% UK, 12% ECC, 16% rest of
Caribbean, 14% US
Aid: economic— bilateral ODA and OOF (1970-79), from
Western (non-US) countries, $22.6 million; no military aid
Budget: revenues, $28 million (including grants); expendi-
tures, $30 million (excluding grants) (1980/81)
Monetary conversion rate: 2.70 East Caribbean
dollars=US$l
Fiscal year: 1 July-30 June
GNP: $6.8 billion (1980 prelim.), $1,256 per capita; real
growth rate 1980, 5.4%
Agriculture: main crops — sugarcane, coffee, cocoa, to-
bacco, rice, corn
Major industries: tourism, sugar processing, nickel min-
ing, bauxite mining, gold mining, textiles, cement
Electric power: 890,000 kW capacity (1981); 3.0 billion
kWh produced (1981), 519 kWh per capita
Exports: $962 million (f.o.b., 1980); sugar, nickel, coffee,
tobacco, cocoa, bauxite
Imports: $1,515 million (f.o.b,, 1980); foodstuffs, petrole-
um, industrial raw materials, capital equipment
Major trade partners: exports — 46% US including Puerto
Rico (1980); imports — 45% US including Puerto Rico (1980)
Aid: economic — bilateral commitments, including Ex-Im
(FY70-80), from US, $414 million; (1970-79) ODA and OOF
from other Western countries, $103 million; military-
authorized from US (1970-80), $18 million
Budget: revenues, $891 million; expenditures, $1,094.1
million (1980 est.)
Monetary conversion rate: 1 peso=US$l
Fiscal year: calendar year','26211ffd268ffbf6d31fee486ad49741d6a906119b34cc37c0bc8fff46d78f3c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c44116d880f183bdac542667e3e18dcad5b5aabb543b4c909ecaf99ecd973fb0',1982,'EC','Ecuador','economy',164,'GNP: $11.0 billion (1980), $1,320 per capita; 63% private
consumption, 14% public consumption, 25% gross invest-
ment, — 2% foreign; average annual real growth rate
1975-80, 6.3%
Agriculture: main crops — bananas, coffee, cocoa, sugar-
cane, fruits, corn, potatoes, rice; caloric intake, 2,104 calories
per day per capita (1977)
Fishing: catch 475,000 metric tons (1977); exports $165.6
million (1980), imports negligible
Major industries: food processing, textiles, chemicals,
fishing, petroleum
Electric power: 1,200,000 kW capacity (1981); 3.0 billion
kWh produced (1981), 340 kWh per capita
Exports: $2.5 billion (f.o.b., 1980); petroleum, bananas,
coffee, cocoa, fish products
Imports: $2.2 billion (c.i.f., 1980); agricultural and indus-
trial machinery, industrial raw materials, building supplies,
chemical products, transportation and communication
equipment
Major trade partners: exports (1980)— 31% US, 19%
LAIA, 8% EC, 13% Japan; imports (1980)— 38% US, 18%
EC, 14% Japan, 13% LAIA
61','edeb5010d25a2383d179496ed08e60ff4ed540c76a692d4981d59e9704143577','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('051e8f8ce87ee581ff4ee3aebd7a6fabd52ab461ffd3d31845c95662d7b62fd8',1982,'EG','Egypt','economy',165,'ECUADOR (Continued)
Aid: economic — bilateral commitments of ODA and OOF
(FY70-80), US, $177.3 million; other Western countries
(1970-79), $243.0 million; Communist countries (1970-75),
$9.4 million; military— {FY70-79) US, $40.0 million
Budget: (1980) revenues, $1,504 million; expenditures,
$1,680 million
Monetary conversion rate: 35 sucres=US$l
Fiscal year: calendar year','dbdfa9b8e47901b3c52c34555d88b441dc3e32c57f4075a2f5b6469dd8faadd6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe4d7379f67ce3eb0eee384ca26725c038f1e0905d3a38f557122875387536b9',1982,'SD','Sudan','economy',171,'GNP: $23.4 billion (1980), $550 per capita; real growth of
8% in 1980
Agriculture: main cash crop — cotton; other crops — rice,
onions, beans, citrus fruit, wheat, corn, barley; not self-
sufficient in food
Major industries: textiles, food processing, chemicals,
petroleum, construction, cement
Electric power: 5,480,600 kW capacity (1980); 18.5 billion
kWh produced (1980), 434 kWh per capita
Exports: $3.9 billion (f.o.b., 1980); crude petroleum, raw
cotton, cotton yarn and fabric, rice, onions, potatoes, chemi-
cals, cement
Imports: $7.6 billion (c.i.f., 1980); foodstuffs, machinery
and equipment, fertilizers, woods
Major trade partners: US, EC countries
Monetary conversion rate: official rate — 1 Egyptian
pound=US$L43 (selling rate), 0.70 Egyptian pound=US$l
(selling rate)
Fiscal year: July through June, beginning in 1980
GNP: $3.7 billion (1980 current prices), $254 per capita;
real growth rate 5.5% (1980)
Agriculture: agriculture accounts for about 23% of GNP;
main crops — rice, rubber, tea, coconuts; food shortages —
wheat and sugar
Fishing: catch 157,000 metric tons (1978)
Major industries: processing of rubber, tea, and other
agricultural commodities; consumer goods manufacture
Electric power: 310,000 kW capacity (1980); 1.2 billion
kWh produced (1980), 65 kWh per capita
Exports: $1.1 billion (f.o.b., 1980); tea, rubber, petroleum
products
Imports: $2.0 billion (c.i.f., 1980); petroleum, machinery,
transport equipment, sugar
Major trade partners: (1977) exports— 8% Pakistan, 8%
UK; imports— 12.4% Saudi Arabia, 9.8% Iran
Budget: (1980 revised estimate) revenue $782 million,
expenditure $1.65 billion
Monetary conversion rate: 20.95 rupees=US$l (Novem-
ber 1981)
Fiscal year: 1 January-31 December (starting 1973)
GDP: $5.6 billion at current prices (1979), $270 per capita
at current prices
Agriculture: main crops — sorghum, millet, wheat, sesame,
peanuts, beans, barley; not self-sufficient in food production;
main cash crops — cotton, gum arabic, peanuts, sesame
Major industries: cotton ginning, textiles, brewery, ce-
ment, edible oils, soap, distilling, shoes, pharmaceuticals
Electric power: 310,000 kW capacity (1980); 1.2 billion
kWh produced (1980), 65 kWh per capita
Exports: $594.0 million (f.o.b., FY80); cotton (56%), gum
arabic, peanuts, sesame; $187.3 million exports to Commu-
nist countries (FY79)
Imports: $1.3 billion (c.i.f., FY80); textiles, petroleum
products, vehicles, tea, wheat
Major trade partners: UK, West Germany, Italy, India,
China, France, Japan
Budget: (FY80) public revenue $2.0 billion, total expendi-
tures $2.7 billion, including development expenditure of
$660.0 million
Monetary conversion rate: 1 Sudanese pound~US$2.00
(official); 0.5 Sudanese pound=US$l
Fiscal year: 1 July-30 June','62c74c2d9ab02977ae2a6ed102dc89deb0cd91ec1fb7756d2b57389b1613dbe9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb8ba072e2514c5bf98f46a4a5987c92365f4a38070e8b579ca77f7a0c730c52',1982,'GQ','Equatorial Guinea','economy',176,'GDP: $3.5 billion (1980), $667 per capita; 83% private
consumption, 17% government consumption, 24% gross do-
mestic investment; —24% net foreign balance; real growth
rate, -10.0% (1980)
Agriculture: main crops — coffee, cotton, corn, sugar, rice,
beans; caloric intake, 2,051 calories per day per capita
(1977); protein intake 51 grams per day per capita (1974)
Fishing: catch 5,487 metric tons (1978)
Major industries: food processing, textiles, clothing, pe-
troleum products
Electric power: 480,000 kW capacity (1981); 1.3 billion
kWh produced (1981), 266 kWh per capita
Exports: $969 million (f.o.b., 1980); coffee, cotton, sugar
Imports: $907 million (c.i.f., 1980); machinery, auto-
motive vehicles, petroleum, foodstuffs, fertilizer
Major trade partners: exports— 32% US, 22% CACM,
33% EC, 13% other (1977); imports— 28% US, 24% CACM,
14% EC, 8% Japan, 26% other (1979)
Aid: economic — authorized from US, including Ex-Im
(FY70-80), $149 million; ODA and OOF committed by other
Western countries (1970-79), $71 million; military— from US
(FY70-80), $16 million
Budget: (1980) $412 million current revenues, $569 mil-
lion expenditures
Monetary conversion rate: 2.5 colones=US$l (official)
Fiscal year: calendar year','33cdf8abacf172fb82a755f2f9a4dbec40fefa90f3757f65f9438dd972700db9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4223159d4b57993c7eb55d8486efe7ef68ddbc3374dd7587e6ee4da05eb60015',1982,'NG','Nigeria','economy',181,'GNP: $100 million (1980); $417 per capita {Note; economy
destroyed by former President Masie Nguema)
Agriculture: major cash crops — Rio Muni, timber, coffee:
Fernando Po, cocoa; main food products — rice, yams, cas-
sava, bananas, oil palm nuts, manioc, and livestock
Major industries: fishing, sawmilling
Electric power: 7,000 kW capacity (1980); 25 million
kWh produced (1980), 99 kWh per capita
Exports: $13,3 million (1980 est.); cocoa, coffee, and wood
Imports: $37.1 million (1980 est,); foodstuffs, chemicals
and chemical products, textiles
Major trade partner: Spain
Budget; (1976) receipts S2 H million
Monetary conversion rate: 172 J Ekuele=US$l (March
1981)
Fiscal year; calendar year
'' NIGER (Continued)
GDP: $92.6 billion (1980 est., current prices), $1,087 per
capita; 7.8% growth rate (1980 est.)
Agriculture: main crops — peanuts, cotton, cocoa, rubber,
yams, cassava, sorghum, palm kernels, millet, corn, rice;
livestock; almost self-sufficient
Fishing: catch 535,435 metric tons (1979); imports $14.5
million (1974)
Major industries: mining — crude oil, natural gas, coal,
tin, columbite; processing industries — oil palm, peanut, cot-
ton, rubber, petroleum, wood, hides, skins; manufacturing
industries — textiles, cement, building materials, food pro-
ducts, footwear, chemical, printing, ceramics
Electric power: 1,823,000 kW capacity (1980); 5.2 billion
kWh produced (1980), 66 kWh per capita
Exports: $23.4 billion (f.o.b., 1980); oil (95%), cocoa, palm
products, rubber, timber, tin
Imports: $15.9 billion (f.o.b., 1980); machinery and trans-
port equipment, manufactured goods, chemicals
Major trade partners: UK, EC, US
Budget: (1980) revenues $22.1 billion, current expendi-
tures $8.6 billion, development expenditures $16.7 billion
Monetary conversion rate: 1 Naira=US$1.8297 (1980)
GNP: $1,200 million (1980), about $462 per capita; -2 0%
real growth in 1980
Agriculture: main cash crops — coffee, cocoa, cotton; ma-
jor food crops — yams, cassava, corn, beans, rice, millet,
sorghum, fish; must import some foodstuffs
Fishing: catch 2,000 metric tons (1979)
Major industries: phosphate mining, agricultural process-
ing, handicrafts, textiles, beverages
Electric power: 75,000 kW capacity (1980); 188 million
kWh produced (1980), 71 kWh per capita
Exports: $384.3 million (c.i.f., 1980); phosphates, cocoa,
coffee, and palm kernels
Imports: $536.2 million (c.i.f., 1980); consumer goods,
fuels, machinery, tobacco, foodstuffs
Major trade partners: mostly with France and other EC
countries
Budget: (1980), revenues, $294.41 million; current expen-
ditures, $277.77 million, development expenditures $16.63
232','7d74bf19e7a5c5345ac4aeb9f26d96ba6405ca43ffa416d27524ecf3d6dc3d2d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faca619281474c781e3a6a9e5956b034f354196b9cd3c9b6f33998a72b14a730',1982,'ET','Ethiopia','economy',185,'GDP: $4.4 billion (1981), $138 per capita; growth rate 2.0-
3.0% (1981)
Agriculture: main crop — coffee
Major industries: cement, sugar refining, cotton textiles,
food processing, oil refinery
Electric power: 330,000 kW capacity (1980); 720 million
kWh produced (1980), 25 kWh per capita
Exports: $408 million (f.o.b., 1981 est.); 70% coffee, 5%
hides and skins
Imports: $779 million (c.i.f., 1981 est.) 18% petroleum
Major trade partners: imports — Saudi Arabia, Japan,
Italy, West Germany, Iran, UK, France, and US; exports —
US, Djibouti, Saudi Arabia, Japan, Italy, West Germany
External debt: $740 million, 1981; external debt ratio
6.6%
67
ETHIOPIA (Continued)
FALKLAND ISLANDS
(Islas Malvinas) 1
Monetary conversion rate: 2.07 Ethiopian Birr=US$l
Fiscal year: 8 July-7 July','92b678d2dfada1cfd21183651350965325546c8e96d798fa241dab8709bd8667','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('664c5f53381398e31829f3b6e3bf895b870590faf71f135846e21770cf100765',1982,'FO','Faroe Islands','economy',187,'Government budget: Colony — revenues, $5.1 million
(FY68); expenditures, $5.3 million (1980-81)
Agriculture: Colony — predominantly sheep farming
Major industries: Colony — wool processing
Electric power: 1,250 kW capacity (1980); 2.5 million
kWh produced (1980), 1,150 kWh per capita
Exports: Colony — $5.8 million (1978); wool, hides and
skins, and other; dependencies — no exports in 1968 or 1969
Imports: Colony— $3.4 million (1978); food, clothing,
fuels, and machinery; dependencies — $8,368 (1969); mineral
fuels and lubricants, food, and machinery
Major trade partners: nearly all exports to the UK, also
some to the Netherlands and to Japan; imports from Cura-
cao, Japan, and the UK
Aid: economic — (1970-79) Western (non-US) countries,
ODA and OOF, $24 million
Monetary conversion rate: 1 Falkland Island pound=
US$2.3263','ab21ca31cab068fd3698e706217c641c6e0ba216620742fd47bb32515168e6f9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1864b16d27d14f0044e3580416998f931e4f411e71336314a6ec86ae6a9b33',1982,'FJ','Fiji','economy',191,'GDP: $420.8 million (1979), about $8,280 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 261,800 metric tons (1979); exports, $131.6
million (1979 est.)
Major industry: fishing
Electric power: 48,000 kW capacity (1980); 90 million
kWh produced (1980), 2,140 kWh per capita
Exports: $150.7 million (f.o.b., 1979); mostly fish and fish
products
Imports: $2058 million (c.i.f., 1979); machinery and
transport equipment, petroleum and petroleum products,
food products
Major trade partners: 48.1% Denmark, 8.9% US, 8.6%
Norway, 8.1% UK (1978)
Budget: (FY78) expenditures $73.3 million, revenues
$73.3 million
Monetary conversion rate: 5.261 Danish Kroner=US$l
Fiscal year: calendar year beginning 1 January 1979','01ff987a1e9f52bd594d7ffd677e5350583f64cd49dbcc501a5aeb3ef748aa12','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de1e6e738027ee6d2b71851d8fd7675cdb39573c3e2505f378dd5b5bfae56241',1982,'FI','Finland','economy',196,'GNP: $40.3 billion (1980), $8,476 per capita; 57% con-
sumption, 24% investment, 19% government; 3% net exports
of goods and services; 1978 growth rate 7.2% (constant
prices)
Agriculture: animal husbandry, especially dairying, pre-
dominates; forestry important secondary occupation for
rural population; main crops — cereals, sugar beets, potatoes;
85% self-sufficient; shortages — food and fodder grains; calo-
ric intake 2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing and ship-
building, forestry and wood processing (pulp, paper), copper
refining
72','edb1427a2a17756e69e9e8c2005e342a38f9dd5326bf5be8a39bb9ef7481c7de','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46a5d424a6e211123cb099767eb06374d0750022e94d82acabe526a4ce0ae6d2',1982,'FR','France','economy',197,'FINLAND (Continued)
Shortages: fossil fuels; industrial raw materials, except
wood, and iron ore
Crude steel: 2.3 million metric tons produced (1978), 480
kg per capita
Electric power: 11,100,000 kW capacity (1980); 38.5
billion kWh produced (1980), 8,050 kWh per capita
Exports: $14.1 billion (f.o.b., 1980); timber, paper and
pulp, ships, machinery, iron and steel, clothing and footwear
Imports: $15.6 billion (c.i.f., 1980); foodstuffs, petroleum
and petroleum products, chemicals, transport equipment,
iron and steel, machinery, textile yarn and fabrics
Major trade partners: (1979) 38% EC-nine (12% West
Germany, 11% UK); 17% USSR, 15% Sweden; 5% US
Aid: donor — bilateral economic aid commitments (ODA),
$290 million (1970-79)
Budget: (1979) expenditures $10.88 billion, revenues $9.61
billion
Monetary conversion rate: Finnmark (Fim) 3.7301=
US$1 (1980 average, IMF)
Fiscal year: calendar year
GNP: $535 billion (1979), $10,010 per capita; 63.5%
private consumption, 21.2% investment (including govern-
ment), 13.0% government consumption; 1979 real growth
rate, 3.2%; average annual growth rate (1970-79), 3.7%
Agriculture: Western Europe''s foremost producer; main
products — beef, cereals, sugar beets, potatoes, wine grapes;
self-sufficient for most temperate zone foodstuffs; food
shortages — fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 713,620 metric tons (1979); exports (in-
cludes shellfish, etc.) $243 million, imports $968 million
(1979)
Major industries: steel, machinery and equipment, tex-
tiles and clothing, chemicals, food processing, metallurgy,
aircraft, motor vehicles
Shortages: crude oil, textile fibers, most nonferrous ores,
coking coal, fats and oils
Crude steel: 23.4 million metric tons produced (1979), 440
kg per capita
Electric power: 74,913,000 kW capacity (1981); 300.150
billion kWh produced (1981), 5,589 kWh per capita
Exports: $98 billion (f.o.b., 1979); principal items — ma-
chinery and transportation equipment, foodstuffs, agricul-
tural products, iron and steel products, textiles and clothing,
chemicals
Imports: $107 billion (c.i.f., 1979); principal items— crude
petroleum, machinery and equipment, chemicals, iron and
steel products, foodstuffs, agricultural products
Major trade partners: 18% West Germany; 11% Italy; 9%
Belgium-Luxembourg; 6% US; 7% Franc Zone; 7% UK; 6%
Netherlands; 2% Eastern Europe; 2% USSR (1979)
Aid: donor — (1970-79) bilateral economic aid commit-
ments (ODA and OOF), $24.5 billion
Budget: (1979) expenditures 478 billion francs, revenues
443 billion francs, deficit 35 billion francs
Monetary conversion rate: 1 franc=US$0.2352 (1979
average)
Fiscal year: calendar year
GNP: $191.0 billion (1980); 70% private consumption, 11%
government consumption, 21% gross fixed capital invest-
ment; —3% net exports; real growth rate 1.2% (1980)
Agriculture: main crops — grains, vegetables, fruits; virtu-
ally self-sufficient in good crop years
Fishing: landed 769,487 million metric tons (1980)
Major industries: textiles and apparel (including foot-
wear), food and beverages, metals and metal manufactures,
chemicals, shipbuilding, automobiles
Crude steel: 12.6 million metric tons produced (1980), 310
kg per capita
Electric power: 35,503,400 kW capacity (1981); 142.723
billionkWh produced (1981), 3,780 kWh per capita
Exports: $20.7 billion (f.o.b., 1980); principal items — iron
and steel products, machinery, automobiles, fruits and vege-
tables, textiles, footwear
Imports: $34.1 billion (c.i.f., 1980); principal items — fuels
(25-30%), machinery, chemicals, iron and steel, vegetables,
automobiles
Major trade partners: (1980) 38% EC, 10% US, 10% other
developed, 3% Communist, 39% LDCs
Aid: economic commitments — US, $1.7 billion including
Ex-Im (FY70-80); other Western bilateral (ODA and OOF),
$545.0 million (1970-79); military authorizations— US,
$939.0 million (FY70-80)
Budget: (1980 central government) revenues $25 billion,
expenditures $29 billion, deficit $4 billion
Monetary conversion rate: 79.25 pesetas=US$l (1980
average)
Fiscal year: calendar year','e1a50c6bb67f47ef42b5f8f8f45d403eeea4b0e62f44a55855afeeed4da14fbc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2d127611d996d504e16c87bba10d856ab2a09947c55e49496ffee1e8d8e6ea9',1982,'GF','French Guiana','economy',204,'GNP: $100 million (at market prices, 1975), $800 per
capita
Agriculture: main crops — rice, corn, manioc, cocoa, ba-
nanas, sugarcane
Fishing: catch 1,142 metric tons (1977)
Major industries: timber, rum, gold mining, production
of rosewood essence, and space center
Electric power: 31,000 kW capacity (1981); 136 million
kWh produced (1981), 1,705 kWh per capita
Exports: $7.2 million (1977); shrimp, timber, rum,
rosewood essence
Imports: $143.4 million (1977); food (grains, processed
meat), other consumer goods, producer goods, and petroleum
Major trade partners: exports — 78% US, 11% France, 5%
Martinique; imports— 49% France, 10% US, 3% Trinidad
and Tobago (1969)
Aid: economic — bilateral commitments, ODA and OOF
(FY70-79), from Western (non-US) countries, $700 million,
no military aid
Monetary conversion rate: 4.21 French francs=US$l
1980
Fiscal year: calendar year','870ad74d441d57d01689d298c22183b394ac8d15c26656d7cd327b46f811212e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c87447ec74eb585a44d4d2dafec35fcc5994c74dc5faad37add33fa9c03a2b7',1982,'KI','Kiribati','economy',208,'GDP: $636.8 million (1976), $4,550 per capita
Agriculture: coconut main crop
Major industries: maintenance of French nuclear test
base, tourism
Electric power: 67,000 kW capacity (1981); 160 million
kWh produced (1979), 1,074 kWh per capita
Exports: $21 million (1977); principal products — coconut
products (79%), mother-of-pearl (14%), vanilla (1971)
Imports: $419 million (1977); principal items — fuels, food-
stuffs, equipment
Major trade partners: imports — 59% France, 14% US;
exports — 86% France
Aid: France $91 million (1978)
Budget: $180 million in 1979; ODA and OOF commit-
ments from Western (non-US countries)
Monetary conversion rate: 100 CFP=1NZ$ (1971)
GDP: $36.0 million (1979 est.), $630 per capita
Agriculture: copra, subsistence crops of vegetables, sup-
plemented by domestic fishing
Industry: phosphate production, which as of May 1979
was expected to cease in mid-1979
Electric power: 2,000 kW capacity (1981); 6 million kWh
produced (1981), 104 kWh per capita
125
KOREA, NORTH
KIRIBATI (Continued)
Exports: $21.2 million (1978); 88% phosphate, 11.6%
copra
Imports: $18.4 million (1978); foodstuffs, fuel, transporta-
tion equipment
Aid: Western (non-US) commitments (ODA; 1979), $46.0
million; Australia (1980-83), $8.1 million committed
Budget: $15.2 million (1979)
Monetary conversion rate: 0.90 Australian$=US$l
GNP: $14.1 billion (1979), $750 per capita
Agriculture: main crops — corn, rice, vegetables; food
shortages — meat, cooking oils; production of foodstuffs ade-
quate for domestic needs at low levels of consumption
Major industries: machine building, electric power,
chemicals, mining, metallurgy, textiles, food processing
Shortages: complex machinery and equipment, coking
coal, petroleum
Crude steel: 3.5 million metric tons produced (1979), 187
kg per capita
Electric power: 5,428,000 kW capacity (1980); 35.915
billion kWh produced (1980), 1,829 kWh per capita
Exports: $1,320 million (1979); minerals, chemical and
metallurgical products
Imports: $1,300 million (1979); machinery and equip-
ment, petroleum, foodstuffs, coking coal
Major trade partners: total trade turnover $2.6 billion
(1979); 43% with non-Communist countries, 57% with Com-
munist countries
Aid: economic and military aid from the USSR and China
Monetary conversion rate: 1.79 won=US$l
Fiscal year: calendar year
GNP: $56.6 billion (1980, in 1980 prices), $1,481 per
capita; real growth -6.2% (1980); real growth 7.2% (1976-80
average)
Agriculture: 29% of the population live on the land, but
agriculture, forestry, and fishery constitute 16% of GNP;
main crops — rice, barley; food shortages — wheat, dairy
products, corn
Fishing: catch 2,410,346 metric tons (1980)
Major industries: textiles and clothing, food processing,
chemicals, steel, electronics, shipbuilding
Shortages: base metals, petroleum, lumber, and certain
food grains
Electric power: 9,000,000 kW capacity (1980); 37.611
billion kWh produced (1979), 886 kWh per capita
Exports: $17.2 billion (f.o.b., 1980); textiles and clothing,
electrical machinery, footwear, steel, ships, fish
Imports: $22.3 billion (c.i.f., 1980); machinery, oil, steel,
transport equipment, textiles, organic chemicals, grains
Major trade partners: exports — 26% US, 17% Japan;
imports— 26% Japan, 22% US (1979)
Aid: economic— US (FY46-80), $6.0 billion committed;
Japan (1965-75), $1.8 billion extended; military— US (FY46-
80) $7.6 billion committed
Budget: $11.8 billion (1981)
Monetary conversion rate: controlled float, 700.5
won = US$1 (31 December 1981)
Fiscal year: calendar year','d1cb0acfa04f060d1b6c15b07375983462799b94f8f5a1f0e9d449958a1e17c4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('807fc1c7e70810fe3304f1d4221274463405862558b65fdb30593528db8076d6',1982,'GA','Gabon','economy',212,'GDP: $3.8 billion (1980), $6,333 per capita; 7.1% annual
growth rate (1971-81)
Agriculture: commercial— cocoa, coffee, wood, palm oil,
rice; main food crops — bananas, manioc, peanuts, root crops;
imports food
Fishing: catch 10,000 metric tons (excluding shellfish)
(1978)
Major industries: petroleum production, sawmills, petro-
leum refinery; mining of increasing importance; major
minerals — manganese, uranium, iron (not produced)
Electric power: 175,400 kW capacity (1980); 564 million
kWh produced (1980), 869 kWh per capita
Exports: $1,770 million (f.o.b., 1979); crude petroleum,
wood and wood products, minerals (manganese, uranium
concentrates, gold), coffee
Imports: $615 million (f.o.b., 1979); excluding UDEAC
trade; mining, roadbuilding machinery, electrical equip-
ment, transport vehicles, foodstuffs, textiles
Major trade partners: France, US, West Germany, and
Curacao
7S
THE GAMBIA
GABON (Continued)
Budget: (1979) revenues $1.1 billion, current expenditures
$605 million, development expenditures $344 million
Monetary conversion rate: 212.7 Communaute Finan-
ciere Africaine francs=US$l (1979)
Fiscal year: calendar year
GNP: $200 million (1980), about $333 per capita; real
growth rate 2.8% (1980)
Agriculture: main crops — peanuts, millet, sorghum, rice,
palm kernels
Fishing: catch 17,446 metric tons (1979); exports $956,000
(1974)
Major industry: peanut processing
Electric power: 10,000 kW capacity (1980); 35 million
kWh produced (1980), 57 kWh per capita
Exports: $27.4 million (1980); peanuts and peanut pro-
ducts, fish, and palm kernels
Imports: $141.2 million (1980); textiles, foodstuffs, tobac-
co, machinery, petroleum products
Major trade partners: exports — mainly EEC; imports —
EEC
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $91.0 million; Communist
countries (1974-79), $17 million; OPEC, ODA (1974-79),
$36.0 million; US (FY70-79), $18.2 million
Budget: (1980-81) revenues $51.5 million, current expen-
ditures $49.4 million, development expenditures $35.8
million
Monetary conversion rate: 1 Dalasi=US$0.716 (1981)
Fiscal year: 1 July-30 June
GNP: $135.4 billion (1980, 1980 dollars), $8,089 per
capita; 1980 growth rate 2.6%
Agriculture: food deficit area; main crops — potatoes, rye,
wheat, barley, oats, industrial crops; shortages in grain,
vegetables, vegetable oil, beef; caloric intake, 3,000 calories
per day per capita (1971)
Fish catch: 244,237 metric tons (1980)
Major industries: metal fabrication, chemicals, light in-
dustry, brown coal, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
81
GERMANY, FEDERAL REPUBLIC OF
GERMAN DEMOCRATIC REPUBLIC (Continued)
Crude steel: 7.308 million metric tons produced (1980),
approx. 436 kg per capita
Electric power: 20,965,000 kW capacity (1981); 101.8
billion kWh produced (1981), 6,080 kWh per capita
Exports: $17.3 billion, est. (f.o.b., 1979)
Imports: $19.2 billion, est. (f.o.b., 1979)
Major trade partners: $36,500 million (1979); 68% Com-
munist countries, 32% non-Communist countries
Monetary conversion rate: 3.11 DME=US$1 for trade
data (1980 rate)
Fiscal year: same as calendar year; economic data report-
ed for calendar years except for caloric intake, which is
reported for the consumption year 1 July-30 June
* GNP: $821 billion (1980), $3,330 per capita (1980); 55%
private consumption, 22% investment, 20% government
consumption; net foreign balance 0%, inventory change 1%
(distribution based on current price series)
Agriculture: main crops — grains, potatoes, sugar beets;
75% self-sufficient; food shortages — fats and oils, pulses,
tropical products; caloric intake, 2,980 calories per day per
capita (1975-76)
Fishing: catch 287,000 metric tons, $167 million (1980);
exports $256 million, imports $802 million (1980)
Major industries: among world''s largest producers of
iron, steel, coal, cement, chemicals, machinery, ships, vehi-
cles, machine tools
Shortages: fats and oils, sugar, cotton, wool, rubber,
petroleum, iron ore, bauxite, nonferrous metals, sulfur
Crude steel: 50 to 60 million metric tons capacity; 43.8
million metric tons produced (1980), 710 kg per capita
Electric power: 89,000,000 kW capacity (1980); 368.731
million kWh produced (1980), 6,010 kWh per capita
Exports: $193 billion (f.o.b., 1980); manufactures 90.0%
(machines and machine tools, chemicals, motor vehicles, iron
and steel products), agricultural products 5.3%, fuels 3.4%,
raw materials 1.3%
Imports: $188 billion (c.i.f., 1980); manufactures 61.2%,
fuels 21.9%, agricultural products 12.9%, raw materials 4.0%
Major trade partners: (1980) EC 47.1% (France 12.0%,
Netherlands 10.5%, Belgium-Luxembourg 7.5%, Italy 8.2%,
UK 6.6%); other Europe 18.4%; OPEC 8.7%; Communist
5.9%; US 6.8%
Aid: donor — (1970-79) bilateral economic aid commit-
ments (ODA and OOF), $21 billion
Budget: (1980) expenditures $118.7 billion, revenues
$103.5 billion, deficit $15.2 billion
Monetary conversion rate: DM 1.82 (West German
marks)=US$I (1980 average)
Fiscal year: calendar year','5f0b42b37390464d812b68b5eb7bd857d850abf2ce28123bd99126f37027deb9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65668c7093da0e0d193a403b3db594e4343ee031cb406e1deafdb030ddb3240f',1982,'GH','Ghana','economy',216,'GNP: $10.1 billion (1979 est.) at current prices, about $849
per capita; real growth rate less than 1% (1970-77)
Agriculture: main crop — cocoa; other crops include root
crops, corn, sorghum and millet, peanuts; not self-sufficient,
but can become so
Fishing: catch 229,904 metric tons (1979)
Major industries: mining, lumbering, light manufactur-
ing, fishing, aluminum
Electric power: 1,157,000 kW capacity (1980); 4.5 billion
kWh produced (1980), 365 kWh per capita
Exports: $1.2 billion (f.o.b., 1980); cocoa (about 70%),
wood, gold, diamonds, manganese, bauxite, and aluminum
(aluminum regularly excluded from balance-of-payments
data)
Imports: $1.1 billion (f.o.b., 1980); textiles and other
manufactured goods, food, fuels, transport equipment
Major trade partners: UK, EC, and US
Budget: (1980) revenue $1.4 billion est., current expendi-
ture $1.4 billion est., capital expenditure $327 million est.
Monetary conversion rate: 1 Cedi=US$0.3636 (1979 and
1980)
Fiscal year: 1 July-30 June','601af6d2af6a3877611b555cbce4ff1d8539d6d3f473803f0b3c73b0488e939b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e077f23c07a739548b3d36baf5bd815ba625412e0abbe0172dc00d62bd76ed8',1982,'GI','Gibraltar','economy',220,'Economic activity in Gibraltar centers on commerce and
large British naval and air bases; nearly all trade in the
well -developed port is transit trade and port serves also as
important supply depot for fuel, water, and ships'' wares;
recently built dockyards and machine shops provide mainte-
nance and repair services to 3,500-4,000 vessels that call at
Gibraltar each year; UK military establishments and civil
government employ nearly half the insured labor force and
a recently announced decision to close the Royal Navy
dockyard will significantly ad^ to unemployment; local
industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, beer, and canned fish;
some factories for manufacture of clothing are being devel-
oped; a small segment of local population makes its liveli-
hood by fishing; in recent years tourism has increased in
importance
Electric power: 40.000 kW capacity (1981); 80 million
kWh produced (1981), 2J60 kWh per capita
Exports: $4L3 million (1979); principally reexports of
tobacco, petroleum, and wine
Imports: $1 1.7 million (1979); principally manufactured
goods, fuels, and foodstuffs; 69% from UK
Major trade partners: UKt Morocco, Portugal Nether-
lands
Budget: (1978-79) revenue $56 million, expenditure $64.7
million
Monetary conversion rate: 1 Gibraltar pound =1 pound
sterling^US$2,3263 (1980)','bc38feb7d37c86a2c9df0369c3c9a3599772185aa381b960b5bba0f29c2e3689','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11a4315ae9303b30a0c9e5b4409e192bb24174760cf4b7c3e6c5f7c06b627972',1982,'GR','Greece','economy',224,'GNP: $41.8 billion (1980), $4,370 per capita; 62% con-
sumption, 24% investment, 16% government; 4% change in
stocks; net foreign balance 6%; real growth rate 1.6% (1980)
Agriculture: main crops — wheat, olives, tobacco, cotton;
nearly self-sufficient; food shortages — livestock products
Major industries: food and tobacco processing, textiles,
chemicals, metal products
Crude steel: 936,000 million metric tons produced (1978),
100 kg per capita
Electric power: 5,700,000 kW capacity (1981); 29.0 billion
kWh produced (1981), 2,900 kWh per capita
Exports: 4,078 million (f.o.b., 1980); principal items —
tobacco, minerals, fruits, textiles
87','5d24280581c8042e8ba142c89d3e951feb4d70119eb5a267ff812544ea958311','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('413898b2f6f7c8a9ba04ddabd5955b6d7df1903e0ff8a794efc8bc1e4de4d2c4',1982,'GL','Greenland','economy',225,'GREECE (Continued)
Imports: $10,769 million (c.i.f., 1980); principal items —
machinery and automotive equipment, petroleum and pe-
troleum products, manufactured consumer goods, chemicals,
meat and live animals
Major trade partners: (1980 est.) imports — 15.2% West
Germany, 9.3% Italy, 6.1% France, 8.8% Saudi Arabia, 5.9%
Egypt; exports— 7.9% West Germany, 9.7% Italy, 5.7%
Netherlands, 7.4% France, 5.6% US, 5.5% Saudi Arabia,
4.1% UK
Aid: economic commitments — US, $436 million
(FY70-80); other Western bilateral (ODA and OOF), $869
million (1970-79); military— US, $1,357 million (FY70-80)
Budget: (1980 est.) central government revenues $8.03
billion, expenditures $10.10 billion, $2.07 million deficit
Monetary conversion rate: US$1=42.6 Greek drachmas
(1980 average)
Fiscal year: calendar year','c1e24bdfe119acd3e3e37eea3c3be390a1bc1fa646e91bd26c4eeab7055fdb45','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3113392b49e96746e6d974faac42da616727c7a1ec15b7bd7712937559cc2718',1982,'GD','Grenada','economy',230,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing;
garden produce
Fishing: catch 82,000 tons (1979); exports $53.7 million
(1978)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 77,000 kW capacity (1980); 125 million
k Wh produced (1980), 2,500 k Wh per capita
Exports: $101.4 million (f.o.b., 1978); fish and fish
products, metallic ores and concentrates
Imports: $177.8 million (c.i.f., 1978); petroleum and pe-
troleum products, machinery and transport equipment, food
products
Major trade partners: (1978) Denmark 67.2%, US 7.9%,
Finland 5.3%, West Germany 5.3%, UK 5.3%
Monetary conversion rate: 5.6359 Danish Kroner=US$l
(1980)
Fiscal year: calendar year beginning 1 January 1979','906dc732eb7ea40b21a99503a548e4b1291aea7f9e71bab66a58868f0390bbf9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f47532a209f54b793eb19fb3cdc1f7828374682655c8da8fddce127b9196948',1982,'GP','Guadeloupe','economy',234,'GDP: $88 million (1980 est.), $800 per capita; real growth
rate 1980 est., -1%
Agriculture: main crops — spices, cocoa, bananas
Electric power: 7,000 kW capacity (1981); 25 million
kWh produced (1981), 231 kWh per capita
Exports: $16 million (f.o.b., 1980 prelim.); cocoa beans,
nutmeg, bananas, mace
Imports: $55 million (c.i.f., 1980 prelim.); food, machin-
ery, building materials
Major trade partners: exports— 39% UK, 17% West Ger-
many, 12% Netherlands (1979); imports— 27% West Indies,
27% UK, 9% US (1976)
Budget: (prelim. 1980) revenues, $39 million; expendi-
tures, $40 million
Monetary conversion rate: 2.70 East Caribbean dollars=
US$1
Fiscal year: calendar year
GNP: $864 million (1977), $2,630 per capita; real growth
rate (1977) 8%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar milling,
rum distillation, and tourism
Electric power: 80,000 kW capacity (1981); 260 million
kWh produced (1981), 817 kWh per capita
Exports: $119 million (f.o.b., 1978); sugar, fruits and
vegetables, bananas
Imports: $455 million (c.i.f., 1978); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum products
Major trade partners: exports — 95% metropolitan France
and rest of franc zone; imports — 75% metropolitan France
and rest of franc zone (1977)
Aid: economic — bilateral ODA and OOF commitments
(1970-79) from Western (non-US) countries, $2.4 billion; no
military aid
Monetary conversion rate: 4.21 French francs=US$l
(1980)
Fiscal year: calendar year','f6ca283cd9f3a7b7a89b2dcd7a74ae0b886d03baf06f49096e450c7410f8944b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37b566975293e200eee6ddd13d1808ba8b14e6d0ab0540254111f49e63842e7a',1982,'GT','Guatemala','economy',240,'GNP: $7.8 billion (1980 est.), $1,080 per capita; 76%
private consumption, 7% government consumption, 22%
domestic investment (1978), —5% net foreign balance (1978);
average annual real growth rate (1974-80), 4.3%
Agriculture: main products— coffee, cotton, corn, beans,
sugarcane, bananas, livestock; caloric intake, 2,156 calories
per day per capita (1977)
92','e70dd1e7a0b06c766226b021b4ba9cd300bf585ef0bba24d63d1f78ff258e207','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a91b7f5e279d5ce811dc23614143525c3af879f6a5e4b5276e506a9aa8e7e5d',1982,'GN','Guinea','economy',241,'GUATEMALA (Continued)
Major industries: food processing, textiles and clothing,
furniture, chemicals, nonmetallic minerals, metals
Electric power: 420,000 kW capacity (1980); 1.43 billion
kWh produced (1980), 200 kWh per capita
Exports: $1,757 million (f.o.b., 1980); coffee, cotton, sugar,
bananas, meat
Imports: $1,971 million (c.i.f., 1980); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels
Major trade partners: exports (1979)— 31% US, 26%
CACM, 10% West Germany, 9% Japan; imports (1979)—
33% US, 15% CACM, 10% Venezuela, 10% Japan, 6% West
GNP: $1.5 billion (1980), $270 per capita
Agriculture: cash crops — coffee, bananas, palm products,
peanuts, and pineapples; staple food crops — cassava, rice,
millet, corn, sweet potatoes; livestock raised in some areas
Major industries: bauxite mining, alumina, light manu-
facturing and processing industries
Electric power: 75,000 kW capacity (1980); 500 million
kWh produced (1980), 90 kWh per capita
Exports: $410 million (f.o.b., 1980); bauxite, alumina,
coffee, pineapples, bananas, palm kernels
Imports: $380 million (f.o.b., 1980); petroleum products,
metals, machinery and transport equipment, foodstuffs,
textiles
Major trade partners: Communist countries, Western
Europe (including France), US
Budget: (1979) public revenue $479.6 million, current
expenditures $271.2 million, development expenditures
$435.6 million
Monetary conversion rate: 18.928 syli=US$l floating
(Februaryl981)
Fiscal year: calendar year','baa79031c735ceb9d3ab020375d41314aca1696f9eb1c15bb197df2a9f46daed','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e0a63292a0a502f4aa1483fef5dccb5b5e00c7a020de9b8db6fd1565173ee6b',1982,'GW','Guinea-Bissau','economy',247,'GDP: $200 million (1980), $333 per capita, real growth
rate 1.5% (1980)
Agriculture: main crops — palm products, root crops, rice,
coconuts, peanuts
Fishing: catch 3,724 metric tons (1979 est.)
Electric power: 11,000 kW capacity (1980); 13 million
kWh produced (1980), 16 kWh per capita
Exports: $9.6 million (1980); principally peanuts, palm-
kernals, shrimp, fish, lumber
Imports: $48.3 million (1980); foodstuffs, manufactured
goods, fuels, transport equipment
Major trade partners: mostly Portugal, and other Europe-
an countries
Budget: (1979 est.) revenue $27.4 million, current expen-
ditures $45.4 million, investment expenditures $107.7 mil-
lion
Monetary conversion rate: 37.6 Guinean pesos=US$l
(1981)
Fiscal year: calendar year','4fe2cd78720fa266f87c907ed427d401bca0dca5ce22bc67856ad4222d5473bc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c3202b81fc4de526c084d83188849261ea4f66a35c338fcf23bbf386baf73e4',1982,'GY','Guyana','economy',251,'GNP: $555 million (1980), $700 per capita; real growth
1981, -6% proj.
Agriculture: main crops — sugarcane, rice, other food
crops; food shortages — wheat flour, cooking oil, processed
meat, dairy products
Major industries: bauxite mining, alumina production,
sugar and rice milling, timber
Electric power: 200,000 kW capacity (1981); 520 million
kWh produced (1981), 530 kWh per capita
Exports: $389 million (f.o.b., 1980); bauxite, sugar, rice,
alumina, shrimp, molasses, timber, rum
Imports: $425 million (c.i.f., 1980); manufactures, ma-
chinery, food, petroleum
Major trade partners: exports— 28% UK, 21% US, 14%
CARICOM, 6% Canada; imports— 22% US, 23% UK, 35%
CARICOM, 4% Canada (1980)
Budget: revenue $183 million, expenditure $373 million
(1980)
Monetary conversion rate: managed according to basket
of currencies; G$3=US$1 (June 1981)
Fiscal year: calendar year
96','118b426bcb02556aeaa47f7ea85fc686f198fec4badda4c56aa8ab75a9bceffb','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6004ccc4c3bd2f7b191908ed79009a353f0756fa9e1eff41ff991d046be1d2c',1982,'HT','Haiti','economy',252,'GUYANA (Continued)
GNP: $1.3 billion (1979), $258 per capita; real growth rate
1980, 7%
Agriculture: main crops — coffee, sugarcane, rice, corn,
sorghum, pulses; caloric intake, 1,850 calories per day per
capita
Major industries: sugar refining, textiles, flour milling,
cement manufacturing, bauxite mining, tourism, light as-
sembly industries
Electric power: 150,000 kW capacity (1981); 300 million
kWh produced (1981), 51 kWh per capita
Exports: $138 million (f.o.b., 1979); coffee, light industrial
products, bauxite, sugar, essential oils, sisal
Imports: $227 million (f.o.b., 1979); consumer durables,
foodstuffs, industrial equipment, petroleum products, con-
struction materials
Major trade partners: exports — 77% US; imports — 51%
US (1977)
Aid: economic — bilateral commitments including Ex-Im
(FY70-80) from US, $200.0 million; (1970-79) ODA and
OOF from other Western countries, $130.8 million; mili-
tary—US (FY70-80), $1.9 million
Budget: (1979/80 est.) revenue, $142 million; expenditure,
$274 million
Monetary conversion rate: 5 gourdes=US$l
Fiscal year: 1 October-30 September','b82022396e6ef8fa2c1ed65d709b08762ea3c15e6ef444a2b5532156d11c712b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('771ab87cc4b98bedde4a2233ad75e12f755cc6c28bd8e8b8f03b2ebe74672dde',1982,'HN','Honduras','economy',256,'GDP: $2.5 billion (1980), $660 per capita; 62% private
consumption, 13% government consumption, 30% domestic
investment; —5% net foreign balance (1978); real growth
rate, average 1975-79, 6.9%; real growth rate 1980, 2.5%
Agriculture: main crops — bananas, coffee, corn, beans,
cotton, sugarcane, tobacco; caloric intake, 2,015 calories per
day per capita (1977)
Fishing: catch 6,405 metric tons (1978); exports est. $0.8
million (1976); imports $0.8 million (1974)
Major industries: agricultural processing, textiles, cloth-
ing, wood products
Electric power: 178,000 kW capacity (1980); 970 million
kWh produced (1980), 253 kWh per capita','2cf77e25b856fd4ad283560affb1b30d1126c3b9bf8b3f39f90768546e256753','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74d87fcc2192ed7959399be8783b9cb11e3b7f20d2e65a7104640c59f7fb72c9',1982,'HK','Hong Kong','economy',257,'HONDURAS (Continued)
Exports: $835 million (f.o.b., 1980); bananas, coffee, lum-
ber, meat, petroleum products
Imports: $1,019 million (c.i.f., 1980); manufactured prod-
ucts, machinery, transportation equipment, chemicals,
petroleum
Major trade partners: exports— 50% US, 9% CACM, 18%
West Germany (1977); imports— 43% US, 6% Venezuela,
12% CACM, 11% Japan, 4% West Germany (1977)
Aid: economic commitments — US, including Ex-Im,
(FY70-80), $260 million loans; other Western (non-US) coun-
tries, ODA and ODF, (1970-79), $90.0 million; military-
assistance from US (FY79-80), $23 million
Budget: (1980) expenditures $448 million, revenues $379
million
Monetary conversion rate: 2 lempiras=US$l (official)
Fiscal year: calendar year','b3f0dd76cf7da546d451fba1f0db78b9f0ee692b43b8f3f635be6831ac24ef44','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('289f00a6747b06778070983966e40f7deefd4d4c53b8420525c93d0094a7909f',1982,'PH','Philippines','economy',262,'GDP: $17.4 billion (1979, in 1979 prices), $3,600 per
capita; average real growth 1979, 11.5%
Agriculture: agriculture occupies a minor position in the
economy; main products — rice, vegetables, dairy products;
less than 20% self-sufficient; food shortages — rice, wheat
Major industries: textiles and clothing, tourism, plastics,
electronics, light metal products, food processing
Shortages: industrial raw materials, water, food
Electric power: 3,491,000 kW capacity (1980); 11.320
billion kWh produced (1980), 2,195 kWh per capita
Exports: $15.2 billion (f.o.b., 1979), including $4.0 billion
reexports; principal products — clothing, plastic articles, tex-
tiles, electrical goods, wigs, footwear, light metal
manufactures
Imports: $17.26 billion (c.i.f., 1979)
Major trade partners: (1979) exports— 33.6% US, 11.4%
West Germany, 10.7% UK; imports— 22.5% Japan, 17.6%
China, 12.0% US
Budget: (1979/80) $2.8 billion
Monetary conversion rate: 4.9 Hong Kong dollars=US$l
(December 1979)
Fiscal year: 1 April-31 March
PERU (Continued)
Monetary conversion rate: 88.65 soles=US$l (1980);
floats against US dollar
Fiscal year: calendar year
GNP: $35.1 billion (1980), $720 per capita; 5.4% real
growth, 1980
Agriculture: main crops — rice, corn, coconut, sugarcane,
bananas, abaca, tobacco
Fishing: catch 1.6 million metric tons (1978)
Major industries: mining, agricultural processing, textiles,
steel processing,chemical products
Electric power: 4,980,000 kW capacity (1980); 18.924
billion kWh produced (1980), 382 kWh per capita
Exports: $5.8 billion (f.o.b., 1980); coconut products,
sugar, logs and lumber, copper concentrates, bananas, gar-
ments, nickel, electrical components, gold
Imports: $7.7 billion (f.o.b., 1980); petroleum, industrial
equipment, wheat
Major trade partners: (1980) exports— 33% US, 33%
Japan; imports— 22% Japan, 26% US
Budget: (1980) revenues $5.06 billion, expenditures $6.17
billion (capital expenditures $2.21 billion), deficit $1.11
billion
Monetary conversion rate: 8.2 pesos=US$l (September
1981)
Fiscal year: calendar year
GNP: $32.2 billion (1979, in 1979 prices), $1,830 per
capita; real growth, 8% (1979)
Agriculture: most arable land intensely farmed — 60%
cultivated land under irrigation; main crops — rice, sweet
potatoes, sugarcane, bananas, pineapples, citrus fruits; food
shortages — wheat, corn, soybeans
Fishing: catch 854,784 metric tons (1977)
Major industries: textiles, clothing, chemicals, plywood,
electronics, sugar milling, food processing, cement,
shipbuilding
Electric power: 9,147,000 kW capacity (1980); 41.0 billion
kWh produced (1980), 2,280 kWh per capita
265
TAIWAN (Continued)
Exports: $16.1 billion (f.o.b., 1979); 28,0% textiles. 17 0%
electrical machinery, 6,3% plywood and wood products,
8.0% basic metals and metal products, 28% machinery,
manufactures, and transportation
Imports: $14,8 billion (c.i.f., 1979); 23.0% machinery and
transportation equipment. 11.0% electrical machinery,
11.0% basic metals, 15.0% crude oil, 12,3% chemical
products
Major trade partners: exports — 35% US, 14% Japan,
imports— 31% Japan, 23% US (1979)
Aid: economic commitments— US (FY46-80), $2.2 billion,
including Ex-Im; other Western (non-US) countries, ODA
and OOF (1970-79), $265 million; military — US (FY46-79),
$4.4 billion committed
Central government budget: $6.7 billion (FY79)
Monetary conversion rate: NT (New Taiwan) $36=US$1
Fiscal year: 1 July-30 June','584483e8f8eaf51dc8e36788c0271ac1fe5c3492151eb1dbe5b076034d797d7d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb4d62b2ef9504790a467e268797c5f9f92fc2e10c784822a24d99303ed5d24e',1982,'HU','Hungary','economy',266,'GNP: $52.8 billion in 1980 (at 1980 dollars), $4,931 per
capita; 1980 growth rate, 0.3%
Agriculture: normally self-sufficient; main crops — corn,
wheat, potatoes, sugar beets, wine grapes; caloric intake
3,185 calories per day per capita (1977)
Major industries: mining, metallurgy, engineering indus-
tries, processed foods, textiles, chemicals (especially pharma-
ceuticals)
Shortages: metallic ores (except bauxite), copper, high
grade coal, forest products, crude oil
Crude steel: 3.9 million metric tons produced (1979), 360
kg per capita
Electric power: 6,103,000 kW capacity (1981); 26.180
billion kWh produced (1981), 2,437 kWh per capita
Exports: $11,117 million (f.o.b., 1979); 28% machinery,
16% industrial consumer goods, 31% raw materials and
semimanufactures, 21% food and raw materials for the food
industry, energy sources 4% (distribution for 1979)
Imports: $11,919 million (c.i.f., 1979); 22% machinery, 8%
industrial consumer goods, 47% raw materials and semi-
manufactures, 8% food and raw materials for the food
industry, energy sources 15% (distribution for 1979)
Major trade partners: $23,036 million (1979); 68% with
Communist countries, 32% with non-Communist countries
Monetary conversion rate: 32.05 forints=US$l (commer-
cial); 22.57 forints=US$l (noncommercial)— July 1980
Fiscal year: same as calendar year; economic data report-
ed for calendar years','f09ec20384280afd01c61abeff5b5a949557ad06dd75256913636fbac7850cb4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('576956b0cf6cb79c9545d0eec51a399f19ad7b222f9a9b8db3f0c49d6fe7f8e6',1982,'IS','Iceland','economy',270,'GNP: $2,760 million (1980), $12,213 per capita; 63.2%
consumption, 27.0% investment, 12.0% government, 0.6%
change in stocks; —0.5% net foreign demand (1979); 1980
growth rate 2.8%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips;
food shortages — grains, sugar, vegetable and other fibers;
caloric intake, 2,900 calories per day per capita (1964-66)
Fishing: landed 1,640,951 metric tons; marine product
exports $589.3 million (1979)
Major industries: fish processing, aluminum smelting,
diatomite production, hydroelectricity
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 670,000 kW capacity (1980); 3.143 billion
kWh produced (1980), 13,720 kWh per capita
Exports: $932.7 million (f.o.b., 1980); fish and fish prod-
ucts, animal products, aluminum, diatomite
Imports: $1 billion (c.i.f., 1980); machinery and transpor-
tation equipment, petroleum, foodstuffs, textiles
Major trade partners: (1979) exports— EC 39%, US 28%,
USSR 4%; imports— EC 46%, USSR 11%, US 7%
Aid: economic authorizations including Ex-Im from US,
$19.1 million (FY70-80)
Budget: (1979) expenditures $674 million, revenues $699
million
Monetary conversion rate: 4.7977 kronur=US$l (1980)','03767d1cffefe800e92f5eb5620ff1427c82ca1a9ef7f2c87e749c2f722f79ce','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a0d9e9c04fa1048e7ccf4296c984def3fbf1bc0c8d969d53e9793e4d2f5bf89',1982,'ID','Indonesia','economy',271,'INDIA (Continued)
Fishing: catch 2.5 million metric tons (FY78); exports
$151 million (FY77), imports, none in 1976 and 1977
Major industries: textiles, food processing, steel, machin-
ery, transportation equipment, cement, jute manufactures
Crude steel: 9.4 million metric tons of ingots (FY81)
Electric power: 34,831,000 kW capacity (1980); 128.874
million kWh produced (1980), 188 kWh per capita
Exports: $9 billion (f.o.b., FY81 est.); engineering goods,
textiles and clothing, tea
Imports: $16 billion (f.o.b., FY81 est.); machinery and
transport equipment, petroleum, edible oils, fertilizers
Major trade partners: US, UK, USSR, Japan
Budget: (FY81 revised est.) central government revenue
and capital receipts, $26.4 billion; disbursements, $28.9
billion
Monetary conversion rate: 9.11 rupees=US$l (November
1981)
Fiscal year: fiscal year ends 31 March of stated year
GNP: $67 billion (1980), about $450 per capita; real
average annual growth, (1973-78) 6.8%, (1980) 9.6%
Agriculture: subsistence food production, and smallholder
and plantation production for export; main crops — rice,
rubber, copra, other tropical products; food shortages — rice,
wheat
Fishing: catch 1.6 million tons (1978); exports $181 mil-
lion (1980), imports $8 million (1977)
Major industries: petroleum, textiles, mining, cement,
chemical fertilizer production, timber
Electric power: 4,754,000 kW capacity (1980); 14.606
billion kWh produced (1980), 96 kWh per capita
Exports: $22.4 billion (f.o.b., FY80/81); petroleum and
LNG ($16.7 billion; 1.2 million b/d), timber, rubber, coffee,
tin, palm oil, tea, copper
Imports: $15.6 billion (FY80/81); rice, wheat, textiles,
chemicals, iron and steel products, machinery, transport
equipment, consumer durables
Major trade partners: (1980) exports — 49% Japan, 20%
US, 11% Singapore; imports— 31% Japan, 13% US, 9% Saudi
Arabia, 6% West Germany
Budget: (1980-81) expenditures, $16.8 billion; receipts,
$14.4 billion domestic, $2.4 billion foreign
Monetary conversion rate: 642 rupiah=US$l (December
1981)
Fiscal year: 1 April-31 March
GNP: $81.7 billion (1979), $2,170 per capita; 1979 real
GNP growth, -24%
Agriculture: wheat, barley, rice, sugar beets, cotton, dates,
raisins, tea, tobacco, sheep, and goats
Major industries: crude oil production (1.4 million b/d in
1981) and refining, textiles, cement and other building
materials, food processing (particularly sugar refining and
vegetable oil production), metal fabricating (steel and
copper)
Electric power: 9,614,600 kW capacity (1980); 16.843
billion kWh produced (1980), 431 kWh per capita
Exports: $11 billion (est., 1981); 97% petroleum; also
carpets, fruits, and nuts
Imports: $15 billion (est., 1981); foodstuffs, pharmaceuti-
cals, machinery, military supplies
108','3ce33aa1c1c2c863276a51fa33b315b65bc2ff5437bc3b7199d0cbea4d1d73e3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('134919a56a327fd7b0d0db1a4aa733d5a261c79fcd79a5f18fd62b1b6662e33d',1982,'IQ','Iraq','economy',275,'IRAN (Continued)
Major trade partners: exports — Japan, West Germany,
Netherlands, Italy, UK, Spain, France; imports— West Ger-
many, Japan, UK, Italy
Budget: (FY81) proposed expenditures of $39 billion,
actual expenditures likely to be below this level
Monetary conversion rate: 70.5 rials=US$l
Fiscal year: 21 March-20 March
GNP: $35.2 billion (1979 est.), $2,730 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry: crude petroleum 1.3 million b/d (1981);
petroleum revenues for 1981, $13 billion
Electric power: 3,840,000 kW capacity (1980); 10.429
billion kWh produced (1980), 767 kWh per capita
Exports: $13.2 billion (f.o.b., 1981 est.); net receipts from
oil, $13 billion; nonoil, $200 million est.
Imports: $17 billion (f.o.b., 1981 est.); 15% from Commu-
nist countries (1981)
Major trade partners: exports — France, Italy, Brazil,
Japan, Turkey, UK, USSR, other Communist countries;
imports — West Germany, Japan, France, US, UK, USSR and
other Communist countries (1980)
Budget: public revenue $20 billion, current expenditures
$8.9 billion, development expenditures $11.1 billion (1979
est.)
Monetary conversion rate: 1 Iraqi dinar=US$3.39 (1980)
Fiscal year: calendar year','b472f1541d6672e5e18c3fd0e4c0357dd981694ec80f896bd44a02bad6fb84e9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15bfda6a7b86f29f56c7ee0536660cf64ff261c0cf00c0c5c4ac7b1c1d8afefe',1982,'IE','Ireland','economy',282,'GNP: $17.1 billion (1980), $5,000 per capita; 63.8% con-
sumption, 30.1% investment, 22.2% government, —2.5%
inventories and net factor income; —14.0% net foreign
demand
Agriculture: 70% of agricultural area used for permanent
hay and pasture; main products — livestock and dairy prod-
ucts, turnips, barley, potatoes, sugar beets, wheat; 85%
self-sufficient; food shortages — grains, fruits, vegetables; ca-
loric intake 3,510 calories per day per capita (1970)
Fishing: catch 108,434 metric tons (1978); exports of fish
and fish products $66.5 million (1979), imports of fish and
fish products $26.0 million (1979)
Major industries: food products, brewing, textiles and
clothing, chemicals and pharmaceuticals, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel
and nonferrous metals, fertilizers, cereals and animal feed,
textile fibers and textiles
Crude steel: 66,000 metric tons produced in 1978
Electric power: 3,117,000 kW capacity (1980); 10.889
millionlcWh produced (1980), 3,170 kWh per capita
Exports: $8,322.0 million (f.o.b., 1980); dairy products,
live animals, textiles, chemicals, machinery, clothing
Imports: $11,153.0 million (c.i.f., 1980); petroleum and
petroleum products, machinery, chemicals, manufactured
goods, cereals
111','9fb05a240fd4f9c96ee27252b4aa3bf1009ab163c658dd44ac44a0b4b76e2c72','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8314c109302c999c407333e4f00f0c0d8e9452b0e01d4d4617d82e406a28e2eb',1982,'IL','Israel','economy',283,'IRELAND (Continued)
Major trade partners: 74.1% EC (42.7% UK); 8.0% US
and Canada
Budget: (1980 actual) 3,702 million pounds expenditures,
3,155 million pounds revenues, 547 million pounds deficit,
public sector borrowing requirement 1,316 million pounds;
(1981 est.) 4,719 million pounds expenditures, 3,932 million
pounds revenues, 787 million pounds deficit, public sector
borrowing requirement 1,637 million pounds
Monetary conversion rate: 1 Irish pound=US$2.0580
(1980 average)
Fiscal year: calendar year
GNP: $19.5 billion (1980, in 1980 prices), $4,640 per
capita; 1980 growth of real GNP 2.3%
Agriculture: main products — citrus and other fruits, vege-
tables, beef and dairy products, poultry products
Major industries: food processing, diamond cutting and
polishing, textiles and clothing, chemicals, metal products,
transport equipment, electrical equipment, miscellaneous
machinery, rubber and plastic products, potash mining
Electric power: 2,693,000 kW capacity (1980); 12.528
billion kWh produced (1980), 3,285 kWh per capita
Exports: $5.8 billion (f.o.b., 1980); major items — polished
diamonds, citrus and other fruits, textiles and clothing,
processed foods, fertilizer and chemical products; tourism is
important foreign exchange earner
Imports: $9.2 billion (f.o.b., 1980); major items — military
equipment, rough diamonds, oil, chemicals, machinery, iron
and steel, cereals, textiles, vehicles, ships, and aircraft
Major trade partners: exports — US, West Germany, UK,
Switzerland, France, Italy; imports — US, West Germany,
UK, Switzerland, Belgium, Italy
Budget: public revenue $14.5 billion, current expendi-
tures $13.7 billion, development expenditures $1.6 billion
Monetary conversion rate: the Israeli pound was allowed
to float on 31 October 1977; the shekel became the unit of
account on 1 October 1980 (1 shekel=10 Israeli pounds) and
as of October 1981 13.74 shekels=US$l
Fiscal year: 1 April-31 March','df6289b44d923c2c1e57af6567eb625a0844218d7de3928ddf18f5831f0e0d16','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7f6fec09c202223c5488dd6cb160c4629c9cb84f74d97ea754ecf3e175f34f5',1982,'IT','Italy','economy',290,'GDP: $394 billion (1980), $6,900 per capita; 63.1% private
consumption, 20.0% gross fixed investment, 16.6% govern-
ment, net foreign balance —0.5%; 1980 growth rate 4.0%
(1975 constant prices)
Agriculture: important producer of fruits and vegetables;
main crops — cereals, potatoes, olives; 95% self-sufficient;
food shortages — fats, meat, fish, and eggs; daily caloric
intake, 3,172 calories per capita (1977)
Fishing: catch 401,958 metric tons (1978); exports $90
million (1979), imports $459 million (1979)
Major industries: machinery and transportation equip-
ment, iron and steel, chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 26.5 million metric tons produced (1980), 465
kg per capita
Electric power: 48,000,000 kW capacity (1981); 186.0
billion kWh produced (1981), 3,247 kWh per capita
Exports: $77.9 billion (f.o.b., 1980); principal items-
machinery and transport equipment, textiles, foodstuffs,
chemicals, footwear
Imports: $99.7 billion (c.i.f., 1980); principal items —
machinery and transport equipment, foodstuffs, ferrous and
nonferrous metals, wool, cotton, petroleum
Major trade partners: (1980) 46% EC-nine (17% West
Germany, 14% France, 5% UK, 4% Netherlands); 2% USSR
and 3% other Communist countries of Eastern Europe
Aid: donor — bilateral economic aid committed (ODA and
OOF), $5.8 billion (1970-79)
Monetary conversion rate: Smithsonian rate as of De-
cember 1973, 650.4 lire=US$l; average rate in 1980, 856
lire=US$l
Fiscal year: calendar year
GDP: $10.3 billion (1980 est.), $1,250 per capita; real
average annual growth rate, 6.8% (1980 est.)
Agriculture: commercial — coffee, cocoa, wood, bananas,
pineapples, palm oil; food crops — corn, millet, yams, rice;
other commodities — cotton, rubber, tobacco, fish; self-
sufficient in most foodstuffs but rice, sugar, and meat
imported
Fishing: catch 92,050 metric tons (1979 est.); exports $44.7
million (1979), imports $71.9 million (1979)
Major industries: food and lumber processing, oil refin-
ery, automobile assembly plant, textiles, soap, flour mill,
matches, three small shipyards, fertilizer plant, and battery
factory
Electric power: 721,500 kW capacity (1980); 1.717 billion
kWh produced (1980), 210 kWh per capita
Exports: $3.0 billion (f.o.b., 1980 est.) ; cocoa (32%), coffee
(23%), tropical woods (19%), cotton, bananas, pineapples,
palm oil
Imports: $2.6 billion (f.o.b., 1980 est.); manufactured
goods and semifinished products (50%), consumer goods
(40%), raw materials and fuels (10%)
Aid: economic commitments — Western (non-US) ODA
and OOF (1970-79), $1,341 million; US authorizations, in-
cluding Ex-Im (FY70-80), $141 million
Major trade partners: (1979) France and other EC coun-
tries about 65%, US 10%, Communist countries about 3%
Budget: (1980), revenues $2.8 billion, current expenditures
$2.8 billion, development expenditures $1.4 billion
Monetary conversion rate: about 211.3 Communaute
Financiere Africaine francs=US$l (1980)
Fiscal year: calendar year
GNP: $1,169 million (1977 at current prices), $3,570 per
capita
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly su-
gar milling and rum distillation; cement, oil refining, and
tourism
Electric power: 65,000 kW capacity (1981); 250 million
kWh produced (1981), 796 kWh per capita
Exports: $166 million (f.o.b., 1978); bananas, refined
petroleum products, rum, sugar, pineapples
Imports: $545 million (c.i.f., 1978); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum products
Major trade partners: exports — 56% France (1978); im-
ports—62% France, 28% EEC and franc zone, 4.5% US,
5.5% other (1977)
Aid: economic — bilateral ODA and OOF commitments
(1970-79) from Western (non-US) countries, $2.6 billion; no
military aid
Monetary conversion rate: 4.21 French francs=US$l
(1980)
Fiscal year: calendar year','27587824805a3aaa5236d2e079b82083245c556816632798a40ef067ddb6d4f7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f0096e06fe9f3c6f4cd993d09aec7b2cfd210c4896353ec240079790d5c426',1982,'JM','Jamaica','economy',294,'GNP: $2.4 billion (1980), $1,089 per capita; real growth
rate 1981, 1% est.
Agriculture: main crops — sugarcane, citrus fruits, ba-
nanas, pimento, coconuts, coffee, cocoa, tobacco
Major industries: bauxite mining, textiles, food process-
ing, light manufactures, tourism
Electric power: 1,400,000 kW capacity (1981); 2.2 billion
kWh produced (1981), 974 kWh per capita
Exports: $1 billion (f.o.b., 1981 est.); alumina, bauxite,
sugar, bananas, citrus fruits and fruit products, rum, cocoa
Imports: $1.5 billion (c.i.f., 1981 prov.); fuels, machinery,
transportation and electrical equipment, food, fertilizer
Major trade partners: exports— US 37%, UK 25%, Can-
ada 8%; imports— US 37%, UK 10%, Canada 6% (1978)
Budget: revenue $0.8 billion, expenditure $1.3 billion
(1981)
Monetary conversion rate: 1 Jamaican dollar=US$0.5613
Fiscal year: 1 April-31 March
118','edac61126324478eaa115d9b1a1a9e3bd660fb1f36b5a485c1054e1d066ddb10','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9df2d3c21e53574e77f690409aed1d8c8a9b883415c7df4341e29b1009e90060',1982,'JP','Japan','economy',295,'JAMAICA (Continued)
GNP: $1,038 billion (1980, at 226.8 yen=US$l); $8,889
per capita (1980); 58% personal consumption, 32% invest-
ment, 10% government current expenditure, 1% stocks, and
— 1% foreign balance; real growth rate 4.2% (1980); average
annual growth rate (1976-80), 5.5%
Agriculture: land intensively cultivated — rice, sugar,
vegetables, fruits; 73% self-sufficient in food (1978); food
shortages — meat, wheat, feed grains, edible oil and fats;
caloric intake, 2,502 calories per day per capita (1974)
Fishing: catch 10.6 million metric tons (1979)
Major industries: metallurgical and engineering indus-
tries, electrical and electronic industries, textiles, chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 111 million metric tons produced (1980)
Electric power: 153,000,000 kW capacity (1980); 520.0
billion kWh produced (1980), 4,435 kWh per capita
Exports: $130.7 billion (f.o.b., 1980); 88% manufactures
(including 27% machinery, 23% motor vehicles, 14% iron
and steel)
Imports: $122.9 billion (f.o.b., 1980); 50% fossil fuels, 17%
manufactures, 13% foodstuffs, 8% machinery and
equipment
Major trade partners: exports — 24% US, 21% Southeast
Asia, 11% Middle East, 7% Communist countries, 17%
Western Europe; imports — 31% Middle East, 13% Southeast
Asia, 17% US, 7% Western Europe, 5% Communist countries
Aid: bilateral economic and committed (ODA and OOF),
$22 billion (1970-79)
Budget: revenues $101 billion, expenditures $168 billion,
deficit $67 billion (general account for fiscal year ending
March 1980)
Monetary conversion rate: 219 yen=US$l (mid-January
1982), floating since February 1973
Fiscal year: 1 April-31 March','3bb3697a69524a5da7b9e95a018f55acfa7fc7d09c4de3db071231c54ab65283','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e71e732b5ed043ee3474f2acd1bb8aed757e5287e4987d42158471f08b662b86',1982,'JO','Jordan','economy',302,'GNP: $3.4 billion (East Bank only, 1980), $1,250 per
capita; real growth rate (1980), 9%
Agriculture: main crops — vegetables, fruits, olive oil,
wheat; not self-sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining,
and cement production, light manufacturing
Electric power: 299,000 kW capacity (1980); 917 million
kWh produced (1980), 290 kWh per capita, East Bank only
Exports: $553 million (f.o.b., 1980); fruits and vegetables,
phosphate rock; Communist share 13% of total (1980)
121
KAMPUCHEA
JORDAN (Continued)
Exports: $553 million (f.o.b., 1980); fruits and vegetables,
phosphate rock; Communist share 13% of total (1980)
Imports: $2,414 million (c.i.f., 1980); petroleum products,
textiles, capital goods, motor vehicles, foodstuffs; Communist
share 7% of total (1980)
Aid: economic— OPEC (ODA; 1973-76), $1,143.1 million;
US, including Ex-Im, (1970-80), $1.2 billion; Western (non-
US) countries, ODA and OOF (1970-79), $391 million;
military— US (1970-76), $906.8 million
Budget: (1980)— $1,291 million public revenue, $971 mil-
lion current expenditures, $520 million capital expenditures
Monetary conversion rate: 1 Jordanian dinar= US$3.35,
freely convertible (1980 average); 1 Jordanian dinar=
US$2.99 (October 1981)
Fiscal year: calendar year
GNP: less than $500 million (1971)
Agriculture: mainly subsistence except for rubber planta-
tions; main crops — rice, rubber, corn; food shortages — rice,
meat, vegetables, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood
products
Shortages: fossil fuels
Electric power: 120,000 kW capacity (1981); 100 million
kWh produced (1981), 18 kWh per capita
Exports: probably less than $1 million est. (1978); natural
rubber, rice, pepper, wood
Imports: probably less than $20 million (1978); food, fuel,
machinery
Trade partners: (1978) exports — China; imports — China,
North Korea; (1981) Vietnam and USSR
Aid: economic commitments— US (FY70-80), $690 mil-
lion; other Western, (1970-79) $135 million; military (FY70-
80)— US, $1,260 million; Communist not available
Budget: no budget data available since Communists took
over government
Monetary conversion rate (1978): no currency in use
Fiscal year: calendar year','4b3516d306d7f92f7e7276c8c0771aca7b4d777919239beb221075ba54f614f3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a82bf449d34a3ff24a28887ea1cf537a7b9c4eeff61ad4bce0d4b0f6b875831d',1982,'KE','Kenya','economy',305,'Organized labor: about 390,000
GDP: $4.3 billion (1980), $340 per capita; real average
annual growth rate, 4.8% (1970-78)
Agriculture: main cash crops — coffee, sisal, tea, pyre-
thrum, cotton, livestock; food crops — corn, wheat, sugar-
cane, rice, cassava; largely self-sufficient in food
Major industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, agricultural processing,
cigarettes, flour), oil refining, cement, tourism
Electric power: 481,000 kW capacity (1981); 1.5 billion
kWh produced (1981), 90 kWh per capita
Exports: $1,168.8 million (f.o.b., 1980); coffee, tea, live-
stock products, pyrethrum, soda ash, wattle-bark tanning
extract
Imports: $2,233.7 million (c.i.f., 1980); machinery, trans-
port equipment, crude oil, paper and paper products, iron
and steel products, and textiles
Major trade partners: EC, Japan, Iran, US, Zambia,
External debt: $170 million (1980), external debt ratio
3.8% (1980)
Budget: (1981) revenues $146.0 million; current expendi-
tures $146.0 million, development expenditures $32.3
million
Monetary conversion rate: 92.84 Rwanda francs=US$l
(official), 1979
Fiscal year: calendar year
GDP: $33 million (1980 est.), $672 per capita; 3.3% real
growth in 1980
Agriculture: main crops — sugar on St. Christopher, cotton
on Nevis
Major industries: sugar processing, tourism
Electric power: 12,000 kW capacity (1981); 30 million
kWh produced (1981), 603 kWh per capita
Exports: $20 million (f.o.b., 1980 est.); sugar
Imports: $43 million (c.i.f., 1980 est.); foodstuffs, manu-
factures, fuel
Major trade partners: exports — 50% US, 35% UK; im-
ports—21% UK, 17% Japan, 11% US (1973)
Aid: economic — bilateral commitments including Ex-Im
(1970-79) from Western (non-US) countries, $14.6 million; no
military aid
Budget: (1980 prelim.) revenues, $20 million; expendi-
tures, $24 million
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$l
GDP: $113 million (1980 est.), $913 per capita; no real
growth (1979)
Agriculture: main crops — bananas, coconut, sugar, cocoa,
spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 7,000 kW capacity (1981); 30 million
kWh produced (1981), 240 kWh per capita
Exports: $26 million (f.o.b., 1980 est.); bananas, cocoa
Imports: $115 million (c.i.f., 1980 est.); foodstuffs, ma-
chinery and equipment, fertilizers, petroleum products
Major trade partners: 51% UK, 9% Canada, 17% US
(1970)
Aid: economic — bilateral commitments, ODA and OOF,
(1970-79), from Western (non-US) countries, $31 million; no
military aid
Budget: (1980/81 est.) revenues, $35 million; expendi-
tures, $42 million
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$l
GNP: $47 million (1980 est.), $440 per capita; 1% real
economic growth in 1980
Agriculture: main crop — bananas
Major industries: food processing
Electric power: 6,500 kW capacity (1981); 20 million
kWh produced (1981), 168 kWh per capita
Exports: $17 million (f.o.b., 1980 est.); bananas, arrowroot,
copra
Imports: $57 million (c.i.f., 1980 est.); foodstuffs, machin-
ery and equipment, chemicals and fertilizers, minerals and
fuels
Major trade partners: exports— 61% UK, 30% CARI-
COM, 9% US; imports— 29% CARICOM, 28% UK, 9%
Canada, 9% US (1972)
Aid: economic — bilateral economic commitments, ODA
and OOF (1970-79), from Western (non-US) countries, $23.0
million; no military aid
Budget: (1980/81 est.) revenues, $18 million; expendi-
tures, $29 million
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$l','d1aa3655187321f989b163efd8f315d974e17f6463b3d7f84ed55a2c8d84bb14','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25f9bfd8b626d27ea7d72ea03adc2546b10e4fa2c32a94db9fcd560d0bcf2bfe',1982,'UG','Uganda','economy',307,'Budget: (1978/79) revenues $1,582.5 million; current ex-
penditures $1,399.1 million; development expenditures
$635.9 million
External public debt: $2.2 billion, 1980 external debt
ratio 15%
Monetary conversion rate: 9.01 Kenya shillings=US$l
(1981)
Fiscal year: 1 July-30 June
124
KENYA (Continued)
GDP: $765 million in 1981
Agriculture: main cash crop — coffee (156,000 metric tons
exported in 1981); other cash crops — tobacco, tea, sugar, fish,
livestock
Major industries: agricultural processing (textiles, sugar,
coffee, plywood*, beer), cement, copper smelting, corrugated
iron sheet, shoes, fertilizer
Electric power: 228,500 kW capacity (1980); 800 million
kWh produced (1980), 61 kWh per capita
Exports: $435 million (f.o.b., 1981); coffee, cotton, tea
Imports: $265 million (f.o.b., 1981 est.); petroleum pro-
ducts, machinery, cotton piece goods, metals, transport
equipment, food
Major trade partners: UK, US, Kenya
Monetary conversion rate: 78 Uganda shillings=US$l
(1981)
Fiscal year: 1 July-30 June','c306847ec0df71a2e5caad1b96357d0204525f93ac5f3850d1879fe1fd2c5bc7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('310c9141ab98cfd8f838a8765ad1e5c243ef57e63aef471bd05989ef991d923b',1982,'KW','Kuwait','economy',312,'GDP: $27.2 billion (1980), $18,390 per capita est.
Agriculture: virtually none, dependent on imports for
food; approx. 75% of potable water must be distilled or
imported
Major industries: crude petroleum production average
for 1980, 1.7 million b/d; refinery production 123 million
bbls (1980), average b/d refinery capacity equaled 645,000
bbls at end of 1976; other major industries include processing
of fertilizers, chemicals; building materials; flour
Electric power: 2,578,000 kW capacity (1980); 9.05 billion
kWh produced (1980), 6,382 kWh per capita
Exports: $20.7 billion (f.o.b., 1980), of which petroleum
accounted for about 90%; nonpetroleum exports are mostly
reexports, $2.1 billion (1980 est.)
Imports: $6.9 billion (f.o.b., 1980 est.); major suppliers —
US, Japan, UK, West Germany
Budget: (1980) $25.5 billion revenues, expenditures $7.9
billion, capital $2.3 billion
Monetary conversion rate: 1 Kuwaiti dinar=US$3.69
(1980)
Fiscal year: 1 July-30 June
GNP: $290 million, $90 per capita (1977 est.)
Agriculture: main crops — rice (overwhelmingly domi-
nant), corn, vegetables, tobacco, coffee, cotton; formerly
self-sufficient; food shortages (due in part to distribution
deficiencies), including rice
Major industries: tin mining, timber, tobacco, textiles,
electric power
Shortages: capital equipment, petroleum, transportation
system, trained personnel
Electric power: 141,000 kW capacity (1980); 887 million
kWh produced (1980), 253 kWh per capita
Exports: $15 million (f.o.b., 1979 est.); electric power,
forest products, tin concentrates; coffee, undeclared exports
of opium and tobacco
Imports: $80 million (c.i.f., 1979 est.); rice and other
foodstuffs, petroleum products, machinery, transportation
equipment
Major trade partners: imports from Thailand, USSR,
Japan, France, China, Vietnam; exports to Thailand and
Malaysia; trade with Communist countries insignificant;
Laos was once a major transit point in world gold trade,
value of 1973 gold reexports $55 million
Aid: economic commitments — Western (non-US) coun-
tries ODA and OOF (1970-79), $235 million; US (FY70-80),
$276 million; military— US assistance $1,119.5 million (1970-
75)
Budget: (1979 est.) receipts, $54.7 million; expenditures,
$174.2 million; deficit $119.5 million
Monetary conversion rate: US$1 ==400 kip (since June
1978)
Fiscal year: 1 July-30 June','84a344cc195a1f01f9bda077b771552e975ba38dc5420722e2dc5016677f7179','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76cda5fc8fdf33c34efe2747a3dbf846e019a1de8600de6521363a79fab8ec5b',1982,'LS','Lesotho','economy',317,'Agriculture: fruits, wheat, corn, barley, potatoes, tobacco,
olives, onions; not self-sufficient in food
Major industries: service industries, food processing, tex-
tiles, cement, oil refining, chemicals, some metal fabricating,
tourism
Electric power: 604,000 kW capacity (1980); 2.325 billion
kWh produced (1980), 760 kWh per capita
Exports: $817 million (f.o.b., 1980)
Imports: $3.2 billion (f.o.b., 1980)
Budget: (1981) public revenue $942 million, current ex-
penditures $941 million, development expenditures $327
million
Monetary conversion rate: 4.61 Lebanese pounds=US$l
as of October 1981
Fiscal year: calendar year
CNP: $473.6 million (1979/80), $312 per capita; real
growth rate, 5% (1980)
Agriculture: exceedingly primitive, mostly subsistence
farming and livestock; principal crops are corn, wheat,
pulses, sorghum, barley
Major industries: none
Electric power: approximately 35 million kWh imported
from South Africa (1981)
Exports: labor to South Africa (remittances $110 million
est in 1979); $33.7 million (f o b., 1979/80), wool, mohair,
wheat, cattle, diamonds, peas, beans, corn, hides, skins
Imports; $288.0 million (cJX, 1979/80); mainly corn,
building materials, clothing, vehicles, machinery, petroleum,
oil, and lubricants
Major trade partner: South Africa
Budget: (FY80) revenues, $137,6 million; current expendi-
tures, $98.2 million; development budget, $84,2 million
Monetary'' conversion rate: Lesotho uses the South Afri-
can rand; 1 $A rand =US$ 1.15 (1981)
Fiscal yean 1 April-31 March','31a1985da5caabba35bc50a8a8e61fb218a7c7bc6507f81dd4d81080ca459585','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42bf2974740ff9ff0a1a1f2132c1b60d55f2c34a060123f4c149e17287b79c41',1982,'LR','Liberia','economy',323,'GDP: $1.04 billion (1980), $660 per capita; -3.1% real
annual growth rate (1980)
Agriculture: rubber, rice, oil palm, cassava, coffee, cocoa;
imports of rice, wheat, and live cattle and beef are necessary
for basic diet
Fishing: catch 13,484 metric tons (1979 est.)
Industry: rubber processing, food processing, construction
materials, furniture, palm oil processing, mining (iron ore,
diamonds), 15,000 b/d oil refinery
Electric power: 355,000 kW capacity (1980); 1.0 billion
kWh produced (1980), 534 kWh per capita
Exports: $600.4 million (f.o.b., 1980 est.); iron ore, rubber,
diamonds, lumber and logs, coffee, cocoa
Imports: $550.7 million (c.i.f., 1980 est.); machinery,
transportation equipment, petroleum products, manufac-
tured goods, foodstuffs
Major trade partners: US, West Germany, Netherlands,
Italy, Belgium
Aid: economic commitments — Western (non-US), ODA
and OOF (1970-79), $324.0 million; US authorizations (in-
cluding Ex-Im) (FY70-80), $182.7 million; Communist (1970-
79), $23.0 million; military— US (FY70-80), $13.1 million
Budget: (FY81) revenues $251.8 million, current expendi-
tures $204.3 million, development expenditures $126.0
million
Monetary conversion rate: Liberia uses US currency
Fiscal year: 1 July-30 June','7298b1fa543e0af1de9e6003f4220662049dc23fc303666a73d0476c8a1aa218','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d1436874976ab75d6593e14615c932078519d9b2306e5702cd0679c70a4db51',1982,'LY','Libya','economy',326,'GDP: roughly $24.5 billion (1981 est), $6,960 per capita
Agriculture: main crops — wheat, barley, olives, dates,
citrus fruits, peanuts; 85% of Libya''s food is imported
Major industries: petroleum, food processing, textiles,
handicrafts
Electric power: 1,950,000 kW capacity (1980); 1.561
billion k Wh produced (1980), 1,561 kWh per capita
Exports: $22.5 billion (f.o.b., 1980); petroleum
Imports: $9.5 billion (f.o.b., 1980); manufactures, food
Major trade partners: imports — Italy, West Germany,
US; exports — Italy, West Germany, UK, US, France
Budget: (1980 est.) revenue $15.8 billion; expenditures
$11.7 billion, including development expenditure of $8.5
billion
Monetary conversion rate: 1 Libyan pound=US$3.38
Fiscal year: calendar year since 1974','f8d40b5916a53329fd9637b9f7cf625f931f137b615d5abdab0ab707b2a00bfd','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ac45ed0ba1cece2b4113d92c511631946a977eebdf32f8930c68e843a3c285',1982,'LI','Liechtenstein','economy',330,'Liechtenstein has a prosperous economy based primarily
on small-scale light industry and some farming; metal
industry is by far the most prominent sector employing
almost 4,000 workers; high-frequency installations, boilers
for central heating, hardware, small machinery, canned
goods, furniture and upholstery, chemical and pharmaceuti-
cal goods, vacuum installations, optical and measuring in-
struments, oil tanks, artificial teeth, ceramics, and textiles
are the principal manufactures, intended almost entirely for
export; industry accounts for 98 percent of total employ-
ment; livestock raising and dairying are the main sources of
income in the small farm sector; major source of income to
the government is the sale of postage stamps to foreign
collectors, estimated at $6 million annually; low business
taxes ''and easy incorporation rules have induced between
20,000 and 30,000 holding companies, so-called letter box
companies, to establish nominal offices in the principality;
average tax paid by one of these companies is about $400 a
year; economy is tied closely to that of Switzerland in a
customs union; no national accounts data are available
GNP: approximately $14,000 per capita (1978)
138','f0a384ca0ac467ae1dd3d0a80475f09ca5aa39651b458806461fec86fcf40ca7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c15e27fffe4046439e0b2dde0aedbd0d5489747509068599dc55ddd9e752adf',1982,'LU','Luxembourg','economy',331,'LIECHTENSTEIN (Continued)
Major trade partners: exports (1979)— $466 million; 42%
EC, 32% EFTA (24% Switzerland), 26% other
Electric power: 23,000 kW capacity (1980); 57 million
kWh produced (1980), 2,110 kWh per capita; power is
exchanged with Switzerland, but net exports average 35
million k Wh yearly
Budget: (1979) revenues $113 million, expenditures $112
million, surplus $15 million
GNP: $5.8 billion, $15,950 per capita (1980); 46.6% pri-
vate consumption, 13.0% government consumption, 20.0%
investment, 1.6% stockbuilding, 17.5% foreign balance
Agriculture: mixed farming; main crops — dairy products
and wine
Major industries: iron and steel (25% of GNP), food
processing, chemicals, metal products and engineering, tires,
and banking
Crude steel: 4.6 million metric tons produced (1980), 14
metric tons per capita
Electric power: 1,500,000 kW capacity (1980); 1.115
billion kWh produced (1980), 3,050 kWh per capita
Exports, Imports, Major trade partners: Luxembourg has
a customs union with Belgium under which foreign trade is
recorded jointly for the two countries; Luxembourg''s princi-
pal exports are iron and steel products, principal imports are
coal and consumer goods; most of its foreign trade is with
Germany, Belgium, France, and other EC countries (for
totals, see Belgium)
Budget: (1980) revenues $1,545 million, expenditures
$1,566 million, deficit $20.5 million
Monetary conversion rate: LF29.24=US$1, 1980 aver-
age; under the BLEU agreement, the Luxembourg franc is
equal in value to the Belgian franc which circulates freely in
Fiscal year: calendar year','1825801528cc7d39d7568574372b872e48653528ede36eb4eea9f8f27ff149a6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbf1df49b7188d9100bead97f1e79f69b7ee1e4e5fd3c2fcec5aab45bde51270',1982,'MG','Madagascar','economy',338,'GDP: $2.3 billion (1980), about $265 per capita; real
growth 4.2% (1980)
Agriculture: cash crops — coffee, vanilla, cloves, sugar,
tobacco, sisal, rice, raphia; food crops — rice, cassava, cereals,
potatoes, corn, beans, bananas, coconuts, and peanuts; ani-
mal husbandry widespread; imports some rice, milk, and
cereal
Fishing: catch 51,380 metric tons (1978)
Major industries: agricultural processing (meat canneries,
soap factories, brewery, tanneries, sugar refining), light
consumer goods industries (textiles, glassware), cement plant,
auto assembly plant, paper mill, oil refinery
Electric power: 100,000 kW capacity (1980); 410 million
kWh produced (1980), 47 kWh per capita
Exports: $518.0 million (f.o.b., 1980); 30% coffee, 8%
vanilla, 7% sugar, 6% cloves; agricultural and livestock
products account for about 85% of export earnings
Imports: $724.1 million (f.o.b., 1980); about 19% consumer
goods, 21% foodstuffs, 41% primary products (crude oil,
fertilizers, metal products), 19% capital goods (1974)
Major trade partners: France (in 1974 accounted for 37%
of exports and 48% of imports), US, EC; trade with Commu-
nist countries remains a minute part of total trade
Budget: (1980) revenues $521 million (est.), current expen-
ditures $540 million (est.), development expenditures $255
(est.)
Monetary conversion rate: 290 Malagasy francs=US$l
Fiscal year: calendar year','8b2f62096b93258c874ccb72dbd7c95dcf86a0afd5cdc4e2a77001eb86fbd71f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb52918c45ee8792f595118d74faa763a2c67c0ec38b2c2ddb1cb3952a63579c',1982,'MW','Malawi','economy',342,'GDP: $800 million (1980), $133 per capita; current real
growth rate 6.5% (1980)
Agriculture: cash crops — tobacco, tea, sugar, peanuts,
cotton, tung, maize; subsistence crops — corn, sorghum, mil-
let, pulses, root crops, fruit, vegetables, rice
Electric power: 124,000 kW capacity (1980); 340 million
kWh produced (1980), 55 kWh per capita
Major industries: agricultural processing (tea, tobacco,
sugar), sawmilling, cement, consumer goods
Exports: $278.4 million (f.o.b., 1980); tobacco, tea, sugar,
peanuts, cotton
Imports: $335.3 billion (f.o.b., 1980); manufactured goods,
machinery and transport equipment, building and construc-
tion materials, fuel, fertilizer
Major trade partners: exports — UK, FRG, US, Nether-
lands, South Africa; imports — South Africa, UK, Japan, US,
FRG
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $683 million; US authorized
(FY70-80), $18.2 million
Budget: 1980 revenues $319.3 million, current expendi-
tures $240.5 million, development expenditures $200.5
million
Monetary conversion rate: 1 Malawi kwacha= US$0. 8258
Fiscal year: 1 April-31 March
144
GNP: $32 billion (1980), $680 per capita; 6% real growth
in 1980 (8.2% real growth, 1975-79)
Agriculture: main crops — rice, sugar, corn, rubber,
tapioca
Fishing: catch 2.1 million metric tons (1979); major
fishery export, shrimp, 18,628 metric tons, about $116
million (1979); total marine export, estimated $249 million
(1978) ,
Major industries: agricultural processing, textiles, wood
and wood products, cement, tin and tungsten ore mining;
world''s second largest tungsten producer and third largest tin
producer
Shortages: fuel sources, including coal, petroleum; scrap
iron, and fertilizer
Electric power: 3,830,820 kW capacity (1980); 14.543
million kWh produced (1980), 330 kWh per capita
Exports: $6.5 billion (f.o.b., 1980); rice, sugar, corn,
rubber, tin, tapioca, kenaf
Imports: $9.6 billion (c.i.f., 1980); machinery and trans-
port equipment, fuels and lubricants, base metals, chemicals,
and fertilizer
Major trade partners: exports — Japan, US, Singapore,
Netherlands, Hong Kong, Malaysia; imports — Japan, US,
West Germany, UK, Singapore, Saudi Arabia; about 1% or
less trade with Communist countries
Budget: (FY82) estimate of expenditures, $7.3 billion;
Defense Ministry budget, $1.4 billion
Monetary conversion rate: 20.48 baht=US$l
Fiscal year: 1 October-30 September','444bcf5b70aa1310eff7e382b441b03d0ccb477f4a0935a37f67b38fef1e46d0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99a07eedac72eca85f8ed7b87763a538dd00422de721324b2dd0b912ca0762a6',1982,'MY','Malaysia','economy',343,'MALAWI (Continued)
GNP:
Malaysia: $21.6 billion (1980), $1,520 per capita; annu-
al growth 8.2% (1980)
Agriculture:
Peninsular Malaysia: natural rubber, oil palm, rice;
10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops — rubber, tim-
ber, coconut, rice; food deficit — rice
Sarawak: main crops — rubber, timber, pepper; food
deficit — rice
Fishing: catch 685,107 metric tons (1978)
Major industries:
Peninsular Malaysia: rubber and oil palm processing
and manufacturing, light manufacturing industry, elec-
tronics, tin mining and smelting, logging and processing
timber
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum production
and refining, logging
Electric power:
Peninsular Malaysia: 1,899,973 kW capacity (1980);
8.157 billion kWh produced (1980), 725 kWh per capita
Sabah: 183,000 kW capacity (1980); 586 million kWh
produced (1980), 558 kWh per capita
Sarawak: 147,000 kW capacity (1980); 343 million kWh
produced (1980), 269 kWh per capita
Exports: $12.2 billion (f.o.b., 1980); natural rubber, palm
oil, tin, timber, petroleum, light manufactures
Imports: $10.2 billion (f.o.b., 1980)
Major trade partners: exports — 17% Singapore, 17% US,
23% Japan, 14% EEC; imports— 23% Japan, 15% US, 11%
EEC (1979)
Budget: 1982 revenue and grants, $4 billion; current
expenditure $7.7 billion, capital expenditures $6.5 billion;
deficit $2 billion; $2.2 billion military, 80% civilian
Monetary conversion rate: 2.25 ringgits=US$l (Decem-
ber 1981)
Fiscal year: calendar year','157139db0b2a020d86f697459281c5e15a49b457811315904aa3d2dd3bc5f740','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df9d4526ab127b7b3cb5615c113c92bc2ea86dfe12337227876fb30ed41cff77',1982,'ML','Mali','economy',351,'GNP: $23 million (1978), $160 per capita
Agriculture: crops— coconut and millet; shortages — rice,
sugar, flour
Fishing: catch 27,700 metric tons (1979)
Major industries: fishing; some coconut processing;
tourism
Electric power: 4,500 k W capacity (1981); 9 million kWh
produced (1981), 57 k Wh per capita
Exports: $10.7 million (1980 prov.); fish
Imports: $26.9 million (1980 prov.); rice, sugar
Major trade partners: Japan, Sri Lanka, Singapore
Budget: (1980 est.) revenue $5.6 million; expenditure $7.1
million
Monetary conversion rate: 3.93 Maldivian rupees=US$l,
official rate; 7.55 rupees=US$l, market rate (average 1980)
Fiscal year: calendar year
GDP: $1.15 billion (1980), $163 per capita; annual real
growth rate 5 1% (1980)
Agriculture; main crops — millet, sorghum, rice, corn,
peanuts; cash crops — peanuts, cotton, and livestock
Fishings catch 95,000 tons (1980)
Major industries: small local consumer goods and
processing
Electric power: 50,000 kW capacity (1980); US million
kWh produced (1980), 17 kWh per capita
Exports: $175.4 million (fo.b., 1980); livestock, peanuts,
dried fish, cotton, and skins
Imports; $300.9 million (f o.b., 1980), textiles, vehicles,
petroleum products, machinery, and sugar
Major trade partners: mostly with franc zone and West-
ern Europe; also with USSR, China
Budget: (1980) revenues $181.4 million, current expendi-
tures $187.5 million
Monetary conversion rate: 422.6 Mali francs=US$l
(1980)
Fiscal year: calendar year','6f003a19b7211f7062e6df6cf5d3acb273f15fcee5a97fca6f32c9397312969a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c52bad498622efefa4394e300311f22f8220e5221b257bf480c9abf2eefa6c36',1982,'MT','Malta','economy',357,'GNP: $945 million (1979), $2,720 per capita; 62% private
consumption, 23% gross investment; 16% government con-
sumption, — 1% net foreign sector; in 1978 real GDP growth
was 11% (1979); 12.5% (1971-76 average)
Agriculture: overall, 20% self-sufficient; generally ade-
quate supplies of vegetables, poultry, milk and pork pro-
ducts; seasonal or periodic shortages in grain, animal fodder,
fruits, and other basic foodstuffs; main products — potatoes,
cauliflowers, grapes, wheat, barley, tomatoes, citrus, cut
flowers, green peppers, hogs, poultry, eggs; 2,680 calories per
day per capita
Major industries: ship repair yard, clothing, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs (fuels and
raw materials) must be imported
Electric power: 135,000 kW capacity (1981); 1.55 billion
kWh produced (1981), 1,550 kWh per capita
Exports: $483 million (f.o.b., 1980); clothing, textiles,
ships, printed matter
Imports: $938 million (c.i.f., 1980)
Major trade partners: 70% EC-nine (21% UK, 21% West
Germany, 16% Italy); 5% US (1979)
Budget: (1982) projects $551 million in expenditures, $547
million in revenues
Monetary conversion rate: 1 Maltese pound=US$2.8963
(average 1980)
Fiscal year: 1 January-31 December
151','d0517635fee2e41596fb95a277b900be7b001e78f14350c877e20272568868f7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4ed209db51778da05907a06c2b18f3a2c65d7f758d277b1e0ee71ac7e61ca18',1982,'MU','Mauritius','economy',362,'GNP: $890 million (1980), $890 per capita; real growth
-9% in 1980
Agriculture: sugar crop is major economic asset; about
40% of land area is planted to sugar; most food imported —
rice is the staple food — and since cultivation is already
intense and expansion of cultivable areas is unlikely, heavy
reliance on food imports except sugar and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea;
some small-scale, simple manufactures; tobacco fiber; some
fishing; tourism, diamond cutting, weaving and textiles,
electronics
Electric power: 180,000 kW capacity (1980); 370 million
kWh produced (1980), 385 kWh per capita
Exports: $318 million (f.o.b., 1981); $187 million sugar, $4
million tea, $5 million molasses
Imports: $456 million (f.o.b., 1981); foodstuffs 30%, man-
ufactured goods about 25%
Major trade partners: all EC-nine countries and US have
preferential treatment, UK buys over 50% of Mauritius ''s
sugar export at heavily subsidized prices; small amount of
sugar exported to Canada, US, and Italy; imports from UK
and EC primarily, also from South Africa, Australia, and
Burma; some minor trade with China
Aid: economic commitments — Western (non-US) coun-
tries (1970-79), $137.0 million; Communist countries (1970-
79), $40.2 million; US authorizations (FY70-80), $22.2
million
Budget: (1981) revenues $235 million, current expendi-
tures $381 million, development expenditures $120 million
Monetary conversion rate: 8.88 Mauritian rupees=US$l
1981 (floating with pound sterling)
Fiscal year: 1 July-30 June','57291c91b2683d3f1083d45b48e8e4f6fba2a81237c87801139bc957b7181401','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c76cd88d6b7290277b49947466cd8722354ea64531c9780721ee8a965f51fa46',1982,'MX','Mexico','economy',366,'GDP: $170 billion (1980), $2,520 per capita; 67% private
consumption, 12% public consumption, 13% private invest-
ment, 12% public investment (1979); net foreign balance
-4%; real growth rate 1980, 8.3%
Agriculture: main crops — corn, cotton, wheat, coffee,
sugarcane, sorghum, oilseeds, pulses, and vegetables; general
self-sufficiency with minor exceptions in meat and dairy
products; caloric intake, 2,700 calories per day per capita
(1975)
Fishing: catch 1,257,129 metric tons (1980); exports val-
ued at $429 million, imports at $22.9 million (1980)
157
MEXICO (Continued)','42e101bb4bff7b6eefe739f50a40ad21765fa87881d6bbbb32d41512f77ab4ae','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83227e49246ed004cb0f8256fc8b86b90d447909287e1d591e5fba27ea858de1',1982,'MC','Monaco','economy',367,'Major industries: processing of food, beverages, and
tobacco; chemicals, basic metals and metal products, petrole-
um products, mining, textiles and clothing, and transport
equipment
Crude steel: 9.8 million metric tons capacity (1980); 7.2
million metric tons produced (1980)
Electric power: 14,320,000 kW capacity (1981); 60.0
billion kWh produced (1981), 769 kWh per capita
Exports: $15,308 million (f.o.b., 1980); cotton, coffee,
nonferrous minerals (including lead and zinc), sugar, shrimp,
petroleum, sulfur, salt, cattle and meat, fresh fruit, tomatoes,
machinery and equipment
Imports: $18,572 million (c.i.f., 1980); machinery, equip-
ment, industrial vehicles, and intermediate goods
Major trade partners: exports — 62% US, 14% EC, 4%
Japan (1980); imports— 65% US, 19% EC, 5% Japan
Aid: economic — (including Ex-Im Credits) extensions
(FY70-80) from US, $1,673.0 million; (1970-79) from Com-
munist countries, $35.0 million; from other Western (non-
US) countries, ODA and OOF (1970-79), $1,956.0 million
Budget: 1980 public sector, revenues $58.1 billion, expen-
ditures $66.9 billion
Monetary conversion rate: floating; 22.951 pesos:=US$l
(1980 average)
Fiscal year: calendar year','8feca79a1b56227aa20344659f431ed4f33c982e29401062aed2b3d0b3b1fd49','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cf737669b9932156f41b9bb24b8d079e95bccaa2cc783fc288d16481977af75',1982,'MN','Mongolia','economy',372,'GNP: 55% tourism; 25%-30% industry (small and primar-
ily tourist oriented); 10%-15% registration fees and sales of
postage stamps; about 4% traceable to the Monte Carlo
casino
Major industries: chemicals, food processing, precision
instruments, glassmaking, printing
Electric power: 8,000 kW (standby) capacity (1981); 100
million kWh supplied by France (1981)
Trade: full customs integration with France, which col-
lects and rebates Monacan trade duties
Monetary conversion rate: 1 franc=US$0.2216 (1978
average)','4852fe95f1406a10dac0a8c55e11d00f14460e55ac646e89e47ab691bd3ad5b2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04f99234a22b4071738974cd3fd90ebd8f8a650f665e24c32f95564c19cb760f',1982,'MA','Morocco','economy',376,'Agriculture: livestock raising predominates; main crops —
wheat, oats, barley
Industries: processing of animal products; building mate-
rials; mining
Electric power: 452,500 kW capacity (1981); 1.56 billion
kWh produced (1981), 905 kWh per capita
Exports: beef for slaughter, meat products, wool, fluor-
spar, other minerals
Imports: machinery and equipment, petroleum, clothing,
building materials, sugar, and tea
Major trade partners: nearly all trade with Communist
countries (approx. 85% with USSR); total turnover about $1.0
billion (1977)
Aid: heavily dependent on USSR
Monetary conversion rate: 3.11 tugriks=US$l (June
1978); arbitrarily established
Fiscal year: calendar year
GNP: $16.1 billion (1981 est.), about $740 per capita;
average annual real growth 6-7% during 1973-77, 1.5% in
1981, 3-4% during 1978-80
Agriculture: cereal farming and livestock raising predomi-
nate; main products — wheat, barley, citrus fruit, wine, vege-
tables, olives; some fishing
Fishing: catch 280,000 metric tons (1979); exports $85.5
million (1981)
Major sectors: mining and mineral processing (phos-
phates, smaller quantities of iron, manganese, lead, zinc, and
other minerals), food processing, textiles, construction and
tourism
Electric power: 1,401,000 kW capacity (1980); 5.503
billion kWh produced (1980), 259 kWh per capita
Exports: $2.50 billion (f.o.b., 1981 est.); 46% phosphates,
54% other
Imports: $4.40 billion (f.o.b., 1981 est.); 18% capital goods,
24% foodstuffs, 29% petroleum products
Major trade partners: France, West Germany, Italy
Budget: (1981 est.) revenue $5.0 billion, expenditure $5.5
billion, development expenditure $2.0 billion
Monetary conversion rate: 5.1 dirhams=US$l average
rate in 1981; 5.3 dirhams=US$l in November 1981
Fiscal year: calendar year','091ab1e1504d3350b596d4d794ce9e468771b3e4ce5b176b2073b87c4a6b7da7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db09de387b10d29736ceefd6df5d93b3e857c2a8968b2d46b8170c14857341ce',1982,'MZ','Mozambique','economy',382,'GNP: $2.8 billion (1980 est.), about $272 per capita;
average annual growth rate —1% (1971-81)
Agriculture: cash crops — raw cotton, cashew nuts, sugar,
tea, copra, sisal; other crops — corn, wheat, peanuts, potatoes,
beans, sorghum, and cassava; self-sufficient in food except
for wheat which must be imported
Major industries: food processing (chiefly sugar, tea,
wheat, flour, cashew kernels); chemicals (vegetable oil, oil-
cakes, soap, paints); petroleum products; beverages; textiles;
nonmetallic mineral products (cement, glass, asbestos, ce-
ment products); tobacco
Electric power: 2,166,000 kW capacity (1980); 11.3 billion
kWh produced (1980), 1,080 kWh per capita
Major trade partners: Portugal, South Africa, US, UK,
West Germany
Budget: (1978) expenditures, $309 million, revenues, $241
million
Monetary conversion rate: 40.643 escudos=US$l as of
November 1977
Fiscal year: calendar year','60faaf604b291c1c87476a7672ba8af9dce1ca192de571d23b9f6f8c4f43c446','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a405ee498be05933aa6c80953864d8fd5157486883df8a1c31274f874bb26be',1982,'NA','Namibia','economy',386,'Agriculture: livestock raising (cattle and sheep) predomi-
nates, subsistence crops (millet, sorghum, corn, and some
wheat) are raised but most food must be imported
163','8450af87dd6b2ed616df4be979bcc8db126a3471790a44c4a6537ded86cd9fae','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b0cb3d78807a4b6a1c6bd56e726a9fb0e43fa39a03be95d0982489b3982e465',1982,'NR','Nauru','economy',387,'NAMIBIA (Continued)
Fishing: catch fell 31% to 277,000 metric tons (1980),
processed mostly in South African enclave of Walvis Bay
Major industries: meatpacking, fish processing, copper,
lead, diamond, and uranium mining, dairy products
Electric power: 540,000 kW capacity (1980); 1.3 billion
kWh produced (1980), 1,251 kWh per capita
Aid: South Africa is only donor
Monetary conversion rate: 1 South African Rand=
US$1.15 (as of March 1978); 0.87 SA Rand=US$l
Fiscal year: 1 April-31 March','1c10661dd3599ae78fa05a0dadbaae239ba58c90ed0cd357e83dc75a3f063d9c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ffdd052aa7da0759058e5a7b56d2ce2693155a0a566a3f91ac857d6d11dfd0',1982,'NP','Nepal','economy',392,'GNP: over $155.4 million (1977), $21,400 per capita
Agriculture: negligible; almost completely dependent on
imports for food, water
Major industries: mining of phosphates, about 2 million
tons per year
Electric power: 10,000 kW capacity (1981); 29 million
kWh produced (1981), 4,144 kWh per capita
Exports: $50.4 million (f.o.b., 1977)
Imports: $32 million (c.i.f., 1977); 16% food, fuel
Major trade partners: exports — 75% Australia and New
Zealand; imports — Australia, UK, New Zealand, Japan
Monetary conversion rate: 1 Australian dollar=US$1.12
(1979)
Fiscal year: 1 July-30 June
GDP: $2.4 billion (FY81 current prices), $115 per capita;
5.5% real growth in FY81
Agriculture: over 90% of population engaged in agricul-
ture; main crops — rice, corn, wheat, sugarcane, oilseeds
Major industries: small rice, jute, sugar, and oilseed mills;
match, cigarette, and brick factories
Electric power: 86,600 kW capacity (1980); 210 million
kWh produced (1980), 14 kWh per capita
Exports: $116 million est. (FY8I est.); rice and other food
products, jute, timber
Imports: $373 million est. (FY81 est.); manufactured con-
sumer goods, fuel, construction materials, food products
Major trade partner: over 80% India
Budget: (FY81 revised est.) domestic revenue $147 mil-
lion, expenditure $253 million
Monetary conversion rate: 12 Nepalese rupees=US$I
Fiscal year: 15 July-14 July','be862c25ed855e899fa6af3f5f6af08328675457c1471ec379f3b3a5ef5e7dff','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1ec21210f39fe48d1fa84a049e47c8a91838d420ec5e1e47d1b53b6a47e0adb',1982,'NL','Netherlands','economy',398,'GNP: $144.2 billion (1981), $10,159 per capita; 59.6%
consumption, 21.6% investment, 18.8% government
Agriculture: animal husbandry predominates; main
crops — horticultural crops, grains, potatoes, sugar beets; food
shortages — grains, fats, oils; calorie intake, 3,186 calories per
day per capita (1970-71)
167
NETHERLANDS (Continued)
Fishing: catch 295,000 metric tons (1979); exports of fish
and fish products $491.6 million (1979), imports $275.4
million (1979)
Major industries: food processing, metal and engineering
products, electrical and electronic machinery and equip-
ment, chemicals, petroleum products, and natural gas
Shortages: crude petroleum, raw cotton, base metals and
ores, pulp, pulpwood, lumber, feedgrains, and oilseeds
Crude steel: 7.7 million metric ton capacity; 5.8 million
metric tons produced (1979), 410 kg per capita
Electric power: 18,500,000 kW capacity (1980); 64.809
billion kWh produced (1980), 4,570 kWh per capita
Exports: $63.6 billion (f.o.b., 1979); foodstuffs, machinery,
chemicals, petroleum products, natural gas, textiles
Imports: $67.2 billion (c.i.f., 1979); machinery, transporta-
tion equipment, crude petroleum, foodstuffs, chemicals, raw
cotton, base metals and ores, pulp
Major trade partners: (1979) 64.3% EC, 27.3% West
Germany, 13.9% Belgium-Luxembourg, 8.9% France, 8.0%
UK
Aid: donor — bilateral economic aid committed, $6,555
million (1970-78)
Budget: (1982 proj.) revenues $135.1 billion, expenditures
$151.0 billion, at exchange rate of 2.50 guilders=$l (Decem-
ber 1981)
Monetary conversion rate: 1.9881 guilders=US$l, aver-
age 1980 est.
Fiscal year: calendar year
GNP: $652 million (1976), $2,680 per capita; real growth
rate, -1% (est.)
Agriculture: little production
Major industries: petroleum refining on Curacao and
Aruba; petroleum transshipment facilities on Curacao,
169','254a9cd033a2f60f5b21c490219791ce844249314a6e18c12caec7ca66f35ec7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d46a6d88649b4a162a39e80dce23361fe884e035ee7cf2c6d649e290d99cf238',1982,'NC','New Caledonia','economy',399,'NETHERLANDS ANTILLES (Continued)
Aruba, and Bonaire; tourism on Curasao, Aruba, and St.
Martin; light manufacturing on Curacao and Aruba
Electric power: 310,000 kW capacity (1981); 1.8 billion
kWh produced (1981), 7,346 kWh per capita
Exports: $2.6 billion (f.o.b., 1977); 96% petroleum prod-
ucts, phosphate
Imports: $3.1 billion (c.i.f., 1977); 64% crude petroleum,
food, manufactures
Major trade partners: exports — 46% US, 2% Canada, 1%
Netherlands; imports— 35% Venezuela, 11% US, 4% Nether-
lands (1977)
Aid: bilateral ODA and OOF commitments (1970-79),
economic — Western (non-US) countries $353 million
Budget: (1977) public sector current revenues, $278 mil-
lion; public sector expenditures, $306 million
Monetary conversion rate; 1.8 Netherlands Antillean
florins (NAF)=US$1, official
Fiscal year: calendar year','4f29e2f72c3f4fdc305ab1b5aac5f5f81e99103127d3c51939088a3b3b832b5e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('307f0427e674206991934434c15547d4a9b38fe1bb3deaf0452a887c00c1c30e',1982,'NZ','New Zealand','economy',404,'GNP: $569 million (1977), $4,000 per capita; -1.0%
growth (1977)
Agriculture: large areas devoted to cattle grazing; major
products-— coffee and vegetables; 60% self-sufficient in beef;
must import grains and vegetables
Industry: mining of nickel
Electric power: 365,000 kW capacity (1981); 1.606 billion
kWh produced (1981), 11,723 kWh per capita
Exports: $363.3 million (f.o.b., 1977); 95% nickel, coffee
Imports: $340 million (c.i.f., 1977); 26% mineral fuel
imports, 21% machinery, transport equipment, food
Major trade partners: (1976) exports — 49% France, 29%
Japan, 16% US; imports— 39% France, 13% Australia, 11%
rest of EC
Monetary conversion rate: 75 CFP francs=US$l
(1978/79)
GNP: NZ$I3.5 billion (1978), NZ$4,350 per capita; real
average annual growth (1976-78), 1.4%
Agriculture: fodder and silage crops about one-half of
area planted in field crops; main products — wool, meat,
dairy products; New Zealand is food surplus country; caloric
intake, 3,500 calories per day per capita (1964)
Fishing: exports 26,000 metric tons valued at $50,3
million (1977); domestic 84,700 metric tons (in 1978); catch
by foreign fishing vessels operating within 200-mile exclu-
sive economic zone (established 1978), 384,000 metric tons
Major industries: food processing, textile production,
machinery, transport equipment; wood and paper products
Electric power: 6,583,000 kW capacity (1980); 28.920
billion kWh produced (1980), 9.175 kWh per capita
Exports: $4.6 billion (f.o.b., 1979); principal products
(trade year 1978/79)— 27% meat, 13% dairy products, 17%
wool
Imports: $4.5 billion (c.i.f., 1979); principal products
(trade year 1978/79)— 30% machinery, 20% manufactured
goods, 13% minerals, 12% chemicals
Major trade partners: (trade year 1978/79) exports — 14%
UK, 15% Japan, 12% Australia, 16% US; imports— 21%
Australia, 14% UK, 13% Japan, 13% US
Aid: bilateral economic aid commitments (1970-79), $400
million
Budget: (1980/81) expenditures, NZ$8,721 million; re-
ceipts, NZ$7,154 million; deficit NZ$1,567
Monetary conversion rate: NZ$1=US$0.97 (March 1980)
Fiscal year: 1 April-31 March
NOTE: trade data are for year ending 30 June; trade year
and fiscal year do not correspond','1311577e14be6581a7703f0fd98f5338086a9fd5f47c56956556a1426958f7b1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a21878c6a3c3001f9b7a27d55868da5dc1b6b2f1ce67f281ed5fd2689b9b6dd',1982,'NI','Nicaragua','economy',411,'GDP: $L8 billion (1980), $692 per capita; 71% private
consumption, 11% government consumption, 14% domestic
investment, 4% net foreign balance (1979); real growth rate
1980, -10.0%
Agriculture: main crops — cotton, coffee, sugarcane, rice,
corn, beans, cattle; caloric intake, 2,446 calories per day per
capita (1977)
Major industries: food processing, chemicals, metal pro-
ducts, textiles and clothing
Electric power: 385,000 kW capacity (1981); 1.35 billion
kWh produced (1981X 550 kWh per capita
Exports: $450 million (f o.b., 1980); cotton, coffee, chemi-
cal products, meat, sugar
Imports: $822 million (f o b., 1980); food and nonfood
agricultural products, chemicals and pharmaceuticals, trans-
portation equipment, machinery, construction materials,
clothing, petroleum
Major trade partners: exports— 21% US, 23% CACM,
28% EC, 28% other; imports— 31% US, 23% CACM, 17%
EC, 29% other (1978)
Aid and Ex-Im Credits: economic — extensions (FY7Q-80)
from US, $223-4 million; other Western countries, ODA and
OOF (1970-79), $144.6 million; military— (FY70-79) from
US, $20 million
Budget: 1980 expenditures $622 million
Monetary conversion rate: 10,0 cordobas=U$$l (official)
Fiscal year: calendar year','6560b447c666acc7cf7bd93ede983a6af1becbd819826a83ca018513a429d52a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2a93a8b052b840181f3e18cfc85e2a00bd499730c271f1d133b89b7dfe91975',1982,'NE','Niger','economy',416,'GDP: $2.7 billion (1980), $491 per capita, annual average
growth rate 1.3% (1971-81)
Agriculture: commercial — peanuts, cotton, livestock;
main food crops — millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill,
small cotton gins, oil presses, slaughterhouse, and a few other
small light industries; uranium production began in 1971
Electric power: 32,800 kW capacity (1980); 78 million
kWh produced (1980), 14 kWh per capita
Exports: $557.9 million (f.o.b., 1980); about 65% uranium,
rest peanuts and related products, livestock, hides, skins;
exports understated because much regional trade not
recorded
Imports: $801.0 million (c.i.f., 1980); fuels, machinery,
transport equipment, foodstuffs, consumer goods
Major trade partners: France (over 50%), other EC
countries, Nigeria, UDEAC countries, US; preferential tariff
to EC and franc zone countries
Budget: (1980/81) revenue $458.8 million, current expen-
diture $255.9 million, development expenditure $344.6
million
Monetary conversion rate: about 225.8 Communaute
Financiere Africaine=US$l (1980)
Fiscal year: 1 October-30 September
175','b2633e3358a169a30cd12f0cb03eabe796389230c733409cf7cc04dfbae02293','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0469942f136efe6295438fdd86fa92175bc622fba7047204fec0a9608cd074fe',1982,'NO','Norway','economy',420,'GNP: $55.4 billion in 1980, $13,549 per capita; 49%
private consumption; 26% investment; 20% government; net
foreign balance 2%; 1980 growth rate 3.6%, in constant
prices; 4.8% average (1970-76)
Agriculture: animal husbandry predominates; main
crops — feed grains, potatoes, fruits, vegetables; 40% self-
sufficient; food shortages — food grains, sugar; caloric intake,
2,940 calories per day per capita (1969-70)
Fishing: catch 2.5 million metric tons (1979); exports $707
million (1979)
Major industries: oil and gas, food processing, shipbuild-
ing, wood pulp, paper products, metals, chemicals
178
NORWAY (Continued)
Shortages: most raw materials with the exception of
timber, petroleum, iron, copper, and ilmenite ore, dairy
products and fish
Crude steel: 921,000 metric tons produced (1979), 230 kg
per capita
Electric power: 20,000,000 kW capacity (1980); 83.986
billion kWh produced (1980), 20,520 kWh per capita
Exports: $18,712 million (f.o.b., 1980); principal items-
oil, natural gas, metals, pulp and paper, fish products, ships,
chemicals, oil
Imports: $16,955 million (c.i.f., 1980); principal items —
foodstuffs, ships, fuels, motor vehicles, iron and steel, chemi-
cal compounds, textiles
Major trade partners: 55% EC (25% UK, 14% West
Germany, 6% Denmark); 15% Sweden; 6% US; 2% Eastern
Bloc countries (1979)
Aid: donor, bilateral economic aid authorized (ODA and
OOF), $1.1 billion (1970-79)
Budget: (1980) revenues $15.0 billion, expenditures $18.7
billion
Monetary conversion rate: 1 kroner= US$0,202 (1980)
Fiscal year: calendar year
GNP: $518.7 billion (1980), $9,280 per capita; 60.3%
consumption, 17.4% investment, 21.6% government; —1.5%
stockbuilding, 2.2% net foreign balance, real growth —1.4%
(1980)
242
UNITED KINGDOM (Continued)
Agriculture: mixed farming predominates; main prod-
ucts— wheat, barley, potatoes, sugar beets, livestock, dairy
products; 53.7% self-sufficient; dependent on imports for
more than half of consumption of refined sugar, butter, oils
and fats, and bacon and ham; caloric intake, 2,260 calories
per day per capita, 1978
Fishing: catch 710,500 metric tons (1980 est.); 1980
exports $359 million, imports $812 million
Major industries: machinery and transport equipment,
metals, food processing, paper and paper products, textiles,
chemicals, clothing
Crude steel: 11.3 million metric tons produced (1980), 390
kg per capita; 30.9 million metric tons capacity (1977)
Electric power: 82,000,000 kW capacity (1980); 284.862
billion kWh produced (1980), 5,090 kWh per capita
Exports: $110.1 billion (f.o.b., 1980); machinery, transport
equipment, chemicals, metals, nonmetallic mineral manu-
factures, foodstuffs, petroleum fc
Imports: $116.1 billion (c.i.f., 1980); foodstuffs, petroleum,
machinery, crude materials, chemicals, nonferrous metals
Major trade partners: 42.5% EC, 11.4% Commonwealth,
11.0% West Germany, 9.8% US, 7.8% France
Aid: donor — bilateral economic aid authorized (ODA and
OOF), $8,956 million (1970-78)
Budget (national and local government): FY82 (proj.)
revenues, 105.5 billion pounds; expenditures, 115.5 billion
pounds; deficit including nationalized industries, 9.5 billion
pounds
Monetary conversion rate: 1 pound sterling=US$2.3263
(average January-December 1980)
Fiscal year: 1 April-31 March','8a7235c92a7a11f54498b80caa91458693bf773cb086dc253a156270598d50cf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03a0dd1202318af0849dbb2dbef8b80900e1141688cb71f60d2c1d4a8974dc3f',1982,'PK','Pakistan','economy',425,'CNP: $5.2 billion (1980), $5,780 per capita est.
Agriculture: based on subsistence farming (fruits, dates;
cereals, cattle, camels), fishing, and trade
Major industries: petroleum discovery in 1964; produc-
tion began in 1967; production 1980, 282,000 b/d; pipeline
capacity, 400,000 b/d; revenue for 1980 est. at $3.2 billion
Electric power: 396,000 kW capacity (1980); 867 million
kWh produced (1980), 1,467 kWh per capita
Exports: $3.8 billion (f.o.b., 1980) mostly petroleum;
non-oil exports (mostly agricultural)
Imports: $1.9 billion (c.i.f., 1980)
Major trade partners: UK, US, other European, Gulf
states, India, Australia, China, Japan
Budget: (1980) revenues $3.5 billion, current expenditures
$1,964 billion, development expenditures $715 million
Monetary conversion rate: 1 Riyal Omani=US$2.895
(1980)
Fiscal year: calendar year','47b02f6a0c27db9e7559a268df46b729660a9d765911cb3dad90acf0eb25feea','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afec1499b1b6aa41f727625488b6d923f56ca899fdfb54fcb324fd2247005f0d',1982,'PA','Panama','economy',430,'GNPi $3,004 million (1980), 11,580 per capita; 63%
private consumption, 18% government consumption, 28%
gross fixed investment, —1% net foreign balance (1978); real
growth (1980), 4.9%
Agriculture: main crops — bananas, rice, corn, coffee,
sugarcane; self-sufficient in most basic foods; 2,341 calories
per day per capita (1977)
Fishing: catch 113,768 metric tons (1978); exports $27,7
million (1977)
Major industries; food processing, metal products, con-
struction materials, petroleum products, clothing, furniture
Electric power: 550,000 kW capacity (1980); 1.812 billion
kWh produced (1980), 935 kWh per capita
Exports: $411 million (f.o.b., 1980); bananas, petroleum
products, shrimp, sugar, coffee
Imports: $1 ,280 million (f.o.b,, 1980); manufactures, trans-
portation equipment, crude petroleum, chemicals, foodstuffs
Major trade partners: exports — 65% US, 11% Panama
Canal Zone, 11% West Germany, 3% Italy, 11% Central
America, 4% Netherlands; imports—33% US, 15% Ecuador,
6% Venezuela, 9% Colon Free Zone, 5% Japan, 3% West
Germany (1978)
Aid: economic — US, authorized, including Ex-Im (FY70-
80), $350.6 million; other Western countries, ODA and OOF
(1970-79), $383.0 million; military ^US (FY70-80), $12
million
Budget: (1980 est,) $1,015 million in revenues, $1,215
million in expenditures
Monetary conversion rate: 1 baIboa=US$l (official)
Fiscal yean calendar year','9646629ec2f5b2537c1999fdf9dd20ebdfd8fd335401172272a2d9bd7bc4ad1b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7edf0a7fade58af27a4c96f641bbc5f8e4876fd97934d02714e3598c795dfa',1982,'PG','Papua New Guinea','economy',434,'GNP: $2.05 billion (FY79 est.), $650 per capita; real
growth (1979) 3% est
Agriculture: main crops — coffee, cocoa, coconuts, timber,
tea
Major industries: sawmilling and timber processing, cop-
per mining (Bougainville)
Electric power: 425,000 k W capacity (1980); 1.275 billion
kWh produced (1980), 398 k Wh per capita
Exports: $960.0 million (f.o.b., 1979); copper, coconut
products, coffee beans, cocoa, copra, timber
Imports: $935.5 million (c.i.f., 1979)
Major trade partners: Australia, UK, Japan
Aid: economic — Australia, $1,158 million committed
(1976-81); World Bank group (1968-September 1969), $14.8
million committed; US, Ex-Im bank loans (FY70-73), $32.5
million extended
Budget: (1979) $759 million
Monetary conversion rate: Kina $1=US$1.5 (December
1980)
Fiscal year: calendar year','0361203b56804c4a19dcafe7e23416b094f9a4cb9646e3092766a2889d926c51','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eb8691c7bd2fd70fd13f16fae05fe44614febbd3670b43ae4dd625d54d21ff9',1982,'PY','Paraguay','economy',438,'GDP: $4.4 billion (1980, at current prices), $1,375 per
capita; 6% public consumption; 82% private consumption,
30% gross domestic investment, —18% net foreign balance
(1980); real growth rate 1980, 11.4%
Agriculture: main crops — oilseeds, cotton, wheat, manioc,
sweet potatoes, tobacco, corn, rice, sugarcane; self-sufficient
in most foods; caloric intake, 2,824 calories per day per
capita (1977)
Major industries: meat packing, oilseed crushing, milling,
brewing, textiles, light consumer goods, cement
Electric power: 400,000 kW capacity (1981); 825 million
kWh produced (1981), 258 kWh per capita
Exports: $310 million (f.o.b., 1980); cotton, oilseeds, meat
products, tobacco, timber, coffee, essential oils, tung oil
Imports: $517 million (f.o.b., 1980); fuels and lubricants,
machinery and motors, motor vehicles, beverages and tobac-
co, foodstuffs
Major trade partners: exports — 15% Netherlands, 6% US,
17% Argentina, 15% West Germany, 5% Japan, 7% Switzer-
land, 9% Brazil; imports— 22% Brazil, 17% Argentina, 12%
US, 7% West Germany, 8% Japan, 6% UK (1979)
Aid: economic bilateral commitments, US (FY70-80) $74
million, other Western countries, ODA and OOF (1970-79)
$176 million; military commitments (FY70-80), US $18
million
Budget: (1980 est.) $405 million in revenues, $432 million
in expenditures
Monetary conversion rate: 126 guaranies=US$l (official
rate, October 1979)','23126ce9311b3ada535c35a84ab25bf822090f07f78904dd7bbb1d5c02b0d409','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77eb53e1c37e98166755c7a915b5e3b55601ff0e5d4a595f61dbd9680cf79bb1',1982,'PE','Peru','economy',442,'GNP: $16.8 billion (1980 est.), $944 per capita; 66%
private consumption, 10% public consumption, 14% gross
investment; 10% net foreign balance (1979); real growth rate
(1981), 3%
Agriculture: main crops — wheat, potatoes, beans, rice,
barley, coffee, cotton, sugarcane; imports — wheat, meat,
lard and oils, rice, corn; caloric intake, 2,274 calories per day
per capita (1977)
Fishing: catch 3.431 million metric tons (1979 prelim.);
exports (meal, oil, other products) $331 million (1979)
Major industries: mining of metals, petroleum, fishing,
textiles and clothing, food processing, cement, auto assem-
bly, steel, shipbuilding, metal fabrication
Electric power: 3,000,000 kW capacity (1981); 13.2 billion
kWh produced (1981), 725 kWh per capita
Exports: $3.3 million (f.o.b., 1981 est.); copper, fish and
fish products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $3.8 million (f.o.b., 1981 est.); foodstuffs, ma-
chinery, transport equipment, iron and steel semimanufac-
tures, chemicals, pharmaceuticals
Major trade partners: exports — 32% US, 8% Latin Amer-
ica, 15% EC, 13% Japan (1979); imports— 37% US, 34% EC,
11% Latin America, 7% Japan (1979)
Budget: 1979— $2.8 billion in revenues, $3.0 billion in
expenditures
187','320b697e1e5b4a6e2e6497dd2df0579b0c80d1d35b6aa374dbf754403a98c8e0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7507c473a6ec9a8bbd7257d4b0f29bbbbd6ee821bfea4cf5840faacea86a28e5',1982,'PL','Poland','economy',446,'GNP: $165.0 billion in 1980 (1980 dollars), $4,638 per
capita; 1980 growth rate, -2.6%
Agriculture: self-sufficient for minimum requirements;
main crops — grain, sugar beets, oilseed, potatoes, exporter of
livestock products and sugar; importer of grains; 3,200
calories per day per capita (1970)
Fishing: catch 791,000 metric tons (1980)
Major industries: machine building, iron and steel, ex-
tractive industries, chemicals, shipbuilding, and food
processing
Crude steel: 19.5 million metric tons produced (1980),
about 546 kg. per capita
Electric power: 26,240,000 kW capacity (1981); 113.0
million kWh produced (1981), 3,129 kWh per capita
Exports: $16,975 million (f.o.b., 1980); 48% machinery
and equipment, 35% fuels, raw materials, and semimanufac-
tures, 8% agricultural and food products, 9% light industrial
products (1980)
Imports: $19,064 million (f.o.b., 1980); 35% machinery
and equipment; 46% fuels, raw materials, and semimanufac-
tures; 15% agricultural and food products; 4% light industrial
products (1980)
190','43961ad7e2a630fe3e5798e8dfa0a2e43261672b9bb2130c3962d1f60a2570f3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eac130c52e19f4eadd6bb7e56d4f0bc643f6e792131617e9e32a767b39165ad2',1982,'PT','Portugal','economy',447,'POLAND (Continued)
Major trade partners: $36,039 million (1979); 56% with
Communist countries, 44% with West
Monetary conversion rate: 80.0 zHotys=US$l (January
1982)
Fiscal year: same as calendar year; economic data are
reported for calendar years except for caloric intake which is
reported for the consumption year, 1 July-30 June
GNP: $22.2 billion (1980); 16% government consumption,
76% private consumption; 21% gross fixed capital formation;
4% change in stocks; —15% net exports; —3% net factor
income from abroad; real growth rate 5.5% (1980)
Agriculture: generally underdeveloped; main crops —
grains, potatoes, olives, grapes for wine; deficit foods — sugar,
grain, meat, fish, oilseed
Fishing: landed 211,824 metric tons (1979)
Major industries: textiles and footwear; wood pulp, pa-
per, and cork; metalworking; oil refining; chemicals; fish
canning; wine
Crude steel: 661,000 tons produced (1979), 70 kg per
capita
Electric power: 4,762,700 kW capacity (1981); 19.06
billion kWh produced (1981), 3,129 kWh per capita
Exports: $4.6 billion (f.o.b., 1980); principal items — cotton
textiles, cork and cork products, canned fish, wine, timber
and timber products, resin
Imports: $9.4 billion (c.i.f., 1980); principal items — petro-
leum, cotton, industrial machinery, iron and steel, chemicals
Major trade partners: 44% EC, 9% US, 21% other
developed, 3% Communist, 23% LDCs
Aid: economic authorizations — US including Ex-Im, $1.2
billion (FY70-80); other Western (ODA and OOF), $396
million (1977-79); military authorizations—US, $137 million
(FY70-80)
Budget: (1980) expenditures, $7.7 billion; revenues, $5.0
billion; deficit, $2.7 billion
Monetary conversion rate: 53.04 escudos=US$I (1980
average)
Fiscal year: calendar year','ea1614d3b956e0fcaf8da4e0c24afda59a38267aabd444e116782fb766210907','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e34f450f5b1659310f8da4e323f959d46f24e0e95432bb697f42b2edf2d377a',1982,'SA','Saudi Arabia','economy',455,'CNP: $5.0 billion (1979), $29,900 plus per capita
Agriculture: farming and grazing on small scale; commer-
cial fishing increasing in importance; most food imported;
rice and dates staple diet
Major industries: oil production and refining; crude oil
production from onshore and offshore averaged 473,000 b/d
(1980); 100% takeover was announced in October 1976 of the
Qatar Petroleum Company, still negotiating with Qatar Shell
about offshore fields; oil revenues accrued $4.7 billion (est.)
in 1980, representing 91% of government/royal family
income; major development projects include $7 million
harbor at Ad Dawhah, fertilizer plant, two desalting plants,
refrigerated storage for fishing, and a cement plant
Electric power: capacity 903,900 kW (1980); 2.416 billion
kWh produced (1980), 10,737 kWh per capita
Exports: crude oil dominates; exports $6.2 billion (1980) of
which petroleum is $5.8 billion
Imports: $1.4 billion (c.i.f., 1980)
Budget: (1980) revenue $5.2 billion, expenditure $3.0
billion
Monetary conversion rate: 1 Qatar riyal=US$0.27 (1980)
Fiscal year: 1 April-31 March
Agriculture: cash crops — almost entirely sugarcane, small
amounts of vanilla and perfume plants; food crops — tropical
fruit and vegetables, manioc, bananas, corn, market garden
produce, also some tea, tobacco, and coffee; food crop
inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling
plants, cigarette factory, 2 tea plants, fruit juice plant,
canning factory, a slaughterhouse, and several small shops
producing handicraft items
Electric power: 105,000 kW capacity (1980); 285 million
kWh produced (1980), 577 kWh per capita
Exports: $62 million (f.o.b., 1975); 90% sugar, 4% perfume
essences, 5% rum and molasses, 1% vanilla and tea (1974)
Imports: $410 million (c.i.f., 1975); manufactured goods,
food, beverages, and tobacco, machinery and transportation
equipment, raw materials and petroleum products
Major trade partners: France (in 1970 supplied 62% of
Reunion''s imports, purchased 76% of its exports); Mauritius
(supplied 12% of imports)
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-78), $3,257 million
Monetary conversion rate: 4.705 French francs=US$l
Fiscal year: probably calendar year
GNP: $40 million (1978); per capita income $490 (1978)
Agriculture: cash crops — cocoa, copra, coconut, coffee,
palm oil, bananas
Fishing: catch, 1,500 metric tons (1979 est.)
Major industries: food processing on small scale, timber
Electric power: 3,000 kW capacity (1980); 10 million
kWh produced (1980), 120 kWh per capita
Exports: $26.6 million (f.o.b., 1979); mainly cocoa (90%),
copra (7%), coffee, palm oil
Imports: $15.5 million (f.o.b., 1979); food products, ma-
chinery and electrical equipment, fuels
Major trade partners: main partner, Netherlands; fol-
lowed by Portugal, US, and West Germany
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $579 million; US (FY77-80),
$0.6 million
Budget: (1979 est.) revenues $15.7 million, current expen-
ditures $10.4 million, capital expenditures $9.1 million
Monetary conversion rate: 38.6 escudos=US$l (1981)
Fiscal year: calendar year
GDP: $115 billion (FY80 est.), $9,500 per capita; annual
growth in real nonoil GNP approx. 15% (1976/80 average,
nonoil)
Agriculture: dates, grains, livestock; not self-sufficient in
food
Major industries: petroleum production 10.2 million b/d
(1980); payments to Saudi Arabian Government, $54 billion
(1979); cement production and small steel-rolling mill and oil
refinery; several other light industries, including factories
producing detergents, plastic products, furniture, etc.; PE-
TROMIN, a semipublic agency associated with the Ministry
of Petroleum, has recently completed a major fertilizer plant
Electric power: 10,460,800 kW capacity (1980); 27,490
billion kWh produced (1980), 2,719 kWh per capita
Exports: $110 billion (f.o.b., 1981); 99% petroleum and
petroleum products
Imports: $34 billion (f.o.b., 1981); manufactured goods,
transportation equipment, construction materials, and proc-
essed food products
Major trade partners: exports — US, Western Europe,
Japan; imports — US, Japan, West Germany
Budget: FY82 appropriation $88.7 billion; current expen-
diture $27.5 billion, project expenditure $61.2 billion
Monetary conversion rate: 1 Saudi riyal=US$0.30 (1980;
linked to SDR, freely convertible)
Fiscal year: follows Islamic year; the 1980-81 Saudi fiscal
year covers the period 15 May 1980 through 4 May 1981','cf3254e3222bf792742aeece2a614714cf2b62dc65a92232f7236ff133c74e28','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa94b4a933571f9b3ad5110eca996f9bbf279cf8f066f60ac43a910934d7e765',1982,'RO','Romania','economy',459,'GNP: $116.5 billion in 1980 (1980 dollars), $5,244 per
capita; 1980 real growth rate, 1.0%
Agriculture: net exporter; main crops — corn, wheat, oil-
seed; livestock — cattle, hogs, sheep; caloric intake, 118% of
requirements
Fishing: catch 140,000 metric tons (1979)
Major industries: machinery, metals, fuels, chemicals,
textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical coke, cot-
ton fibers, natural rubber
Crude steel: 3.2 million metric tons produced (1980), 579
kg per capita
Electric power: 16,104,000 kW capacity (1981); 68.455
billion kWh produced (1981), 3,048 kWh per capita
Exports: $11.2 billion (f.o.b., 1980); 26% machinery and
equipment; 12% agricultural materials and foodstuffs; 16%
manufactured consumer goods; 29% fuels, minerals, and
metals; 17% other (1979)
Imports: $12.8 billion (mixture f.o.b. and c.i.f., 1980); 32%
machinery and equipment; 43% fuels, minerals, metals; 7%
agricultural raw materials and foodstuffs; 18% other (1979)
Major trade partners: $24.0 billion in 1980; 59% non-
Communist countries, 41% Communist countries (1980)
Monetary conversion rate: 4.47 lei=US$l (commercial),
11 lei=US$l (tourist)
Fiscal year: same as calendar year; economic data report-
ed for calendar years except for caloric intake, which is
reported for consumption year, 1 July-30 June
196','14878985c0326bc425660a6a98a22b169b5bd6d75cd4821d5b628e4308dbadec','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc6b1ed449253939512c4f069ff7ec0e788dae85362988fd83177cb95902f882',1982,'RW','Rwanda','economy',460,'ROMANIA (Continued)
GDP: $1,388 million (1981), $270 per capita; real average
annual growth rate (1970-77), 5.5%
Agriculture: cash crops — mainly coffee, tea, some pyre-
thrum; main food crops — bananas, cassava; stock raising;
self-sufficiency declining; country imports foodstuffs
Major industries: mining of cassiterite (tin ore), wolfram
(tungsten ore), agricultural processing, and light consumer
goods
Electric power: 38,000 kW capacity (1980); 160 million
kWh produced (1980), 31 kWh per capita
Exports: $115 million (f.o.b., 1981 est.); mainly coffee, tea,
cassiterite, wolfram, pyrethrum
Imports: $188 million (c.i.f., 1981 est.); textiles, foodstuffs,
machines, equipment 1
Major trade partners: USJ Belgium, West Germany,','7bd2ceee516b7f6f445f1c74b02c289e364d2afd84a72f3a3bbf27a8c4e2e855','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9826ed17b7b0b1fc93d25453f42df9908508b633af29e0b887701b487e9d07f5',1982,'SM','San Marino','economy',467,'Principal economic activities of San Marino are farming,
livestock raising, light manufacturing, and tourism; the
largest share of government revenue is derived from the sale
of postage stamps throughout the world and from payments
by the Italian Government in exchange for Italy''s monopoly
in retailing tobacco, gasoline, and a few other goods; main
problem is finding additional funds to finance badly needed
water and electric power systems expansions
Agriculture: principal crops are wheat (average annual
output about 4,400 metric tons/year) and grapes (average
annual output about 700 metric tons/year); other grains,
fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and
sheep; cheese and hides are most important livestock
products
202','721a4e5e742bed663d704d3a55ed3aa56c1bca814e4743574d90de3c46dec023','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b9c1aec59c3ecac20842c44fa32fc4acc8755ca247b96fa4a24cab314ebe2a7',1982,'ST','Sao Tome and Principe','economy',468,'SAN MARINO (Continued)
Electric power: all power is imported from Italy (1981)
Manufacturing: consists mainly of cotton textile produc-
tion at Serravalle, brick and tile production at Dogane,
cement production at Acquaviva, Dogane, and Fiorentino,
and pottery production at Borgo Maggiore; some tanned
hides, paper, candy, baked goods, Moscato wine, and gold
and silver souvenirs are also produced
Foreign transactions: dominated by tourism; in summer
months 20,000 to 30,000 foreigners visit San Marino every
day; several hotels and restaurants have been built in recent
years to accommodate them; remittances from Sanmarinese
abroad also represent an important net foreign inflow;
commodity trade consists primarily of exchanging building
stone, lime, wood, chestnuts, wheat, wine, baked goods,
hides, and ceramics for a wide variety of consumer
manufactures','8dbd947fd6442c1b57213f85cdd665544dcc0132882057aae80e3143ce466d87','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feb2dc546f8aef021110cb212967db45599ef8d9ead038fc4be41558aa1c3024',1982,'SC','Seychelles','economy',476,'GDP: $2.1 billion (1980), $378 per capita; real growth
-11.9% in 1980; nominal growth -3.9% in 1980
Agriculture: main crops — peanuts, millet, sorghum, man-
ioc, rice; peanuts primary cash crop; production of food
crops increasing but still insufficient for domestic re-
quirements
Fishing: catch 359,230 metric tons (1980); exports $153.8
million (1980)
Major industries: fishing, agricultural processing plants,
light manufacturing, mining
Electric power: 310,850 kW capacity (1981); 1.106 billion
kWh produced (1981), 92 kWh per capita
Exports: $570.3 million (f.o.b., 1980 est.); peanuts and
peanut products; phosphate rock; canned fish
Imports: $1,022.2 million (c.i.f., 1980 est.); food, consumer
goods, machinery, transport equipment
Major trade partners: France, EC (other than France),
and franc zone
Budget: (1981/82) public revenue $432.7 million, current
expenditures $432.7 million, development expenditures
$191.7 million
Monetary conversion rate: francs; about 211.3 Commun-
aute Financiere Africaine francs=US$l (1980)
Fiscal year: 1 July-30 June
GDP: $90 million (1978 est.); $1,330 per capita; 6%
growth rate (1980)
Agriculture: islands depend largely on coconut production
and export of copra; cinnamon, vanilla, and patchouli (used
for perfumes) are other cash crops; food crops — small quan-
tities of sweet potatoes, cassava, sugarcane, and bananas;
islands not self-sufficient in foodstuffs and the bulk of the
supply must be imported; fish is an important food source
Major industries: processing of coconut and vanilla,
fishing, small-scale manufacture of consumer goods, coir
rope factory, tea factory, tourism
Electric power: 16,000 kW capacity (1980); 45 million
kWh produced (1980), 703 kWh per capita
Exports: $5.2 million (f.o.b., 1980); cinnamon (bark and
oil) and vanilla account for almost 50% of the total, copra
accounts for about 40%, the remainder consists of patchouli,
fish, and guano
Imports: $74.0 million (c.i.f., 1980); food, tobacco, and
beverages account for about 40% of imports, manufactured
goods about 25%, the remainder consists of machinery and
transport equipment, petroleum products, textiles
Major trade partners: exports — India, US; imports — UK,
Kenya, South Africa, Burma, India, Australia
External debt: $22 million (1980); external service payment
(1980), $245,000
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $110 million; US (FY70-80),
$2.7 million; OPEC, ODA (1974-79), $1.2 million
Budget: (1979) revenue $42.0 million, current expenditure
$35.0 million, development expenditure $15.6
Monetary conversion rate: 6.39 Seychelles rupees=US$l
(1981)','8fb0c1aebd9e45f43253f8e4d16ace34f5fd6e6ed5fe963533a1c65b1601dc2c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c419f35fead6ef91ab9b70431c2b2ecdb24cc16937bc3cebf7970333074f1cc5',1982,'SL','Sierra Leone','economy',482,'GDP: $900 million (1980), $265 per capita
Agriculture: main crops — palm kernels, coffee, cocoa,
rice, yams, millet, ginger, cassava; much of cultivated land
devoted to subsistence farming; food crops insufficient for
domestic consumption
Fishing: catch 50,080 metric tons (1978); imports $2.7
million (1974)
Major industries: mining — diamonds, iron ore, bauxite,
rutile; manufacturing — beverages, textiles, cigarettes, con-
struction goods; 1 oil refinery
Electric power: 95,000 kW capacity (1980); 213 million
kWh produced (1980), 62 kWh per capita
Exports: $230.0 million (f.o.b., 1979); diamonds, iron ore,
palm kernels, cocoa, coffee
Imports: $304.2 million (f.o.b., 1979); machinery and
transportation equipment, manufactured goods, foodstuffs,
petroleum products
Major trade partners: UK, EC, US, Japan, Communist
countries
209','36d9becdb8a14d8fb93529e112f60984210104e71ddf615d0bd285b8dae98063','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba967eb56e6b4d4bbd28320eb08cadcb7a33b8afaf05d1482f607c26b90a321',1982,'SG','Singapore','economy',483,'SIERRA LEONE (Continued)
Budget: (1980/81) revenues $229.9 million, current ex-
penditures $221.9 million, development expenditures $73.0
million
Monetary conversion rate: 1 leone=US$0.90 (1980/81)
Fiscal year: 1 July-30 June
GDP: $10.5 billion (1980 est.), $4,340 per capita; 9.4%
average annual real growth (1969-79), 10.2% (1980)
Agriculture: occupies a position of minor importance in
the economy, self-sufficient in pork, poultry, and eggs, must
import much of its other food requirements; major crops —
rubber, copra, fruit and vegetables
Fishing: catch 15,532 metric tons (1980), imports— 80,440
metric tons (1980), exports— 48,704 metric tons (1980)
Major industries: petroleum refining, oil drilling equip-
ment, rubber processing and rubber products, processed
food and beverages, electronics, ship repair, entrepot trade,
financial services
Electric power: 1,650,000 kW capacity (1980); 7.26 billion
kWh produced (1980), 3,000 kWh per capita
Exports: $19.4 billion (f.o.b., 1980); 37.7% reexports;
petroleum products, rubber, manufactured goods
Imports: $24.0 billion (c.i.f., 1980); 30.5% goods reexport-
ed; major retained imports — capital equipment, manufac-
tured goods, petroleum
Major trade partners: exports — Malaysia, US, Japan,
Hong Kong, Thailand, Australia, Indonesia, West Germany;
imports — Japan, US, Malaysia, Saudi Arabia
Aid: economic commitments — Western (non-US) coun-
tries (1970-79), $216 million; US, including Ex-Im (FY70-80),
$302 million; military— US (FY70-80), $2 million
Budget: (FY80/81) revenues $3.1 billion, expenditures
$2.9 billion, surplus $145 million; 24.8% military, 75.2%
civilian
Monetary conversion rate: 2.14 Singapore dollars=US$l
(1980)
Fiscal year: 1 April-31 March','28de0417a4ed0e48ff3896f60882c61bb9f7877185e63e10435b71ded7e7753b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bdfc8d0eceffa64e74f35c94b9d3fef916db639e222755a6e93641f5f34d0df',1982,'SB','Solomon Islands','economy',490,'GDP: $71.2 million (1977), $320 per capita
Agriculture: largely dominated by coconut production
with subsistence crops of yams, taro, bananas; self-sufficient
in rice
Electric power: 12,000 kW capacity (1981); 26 million
kWh produced (1981), 113 kWh per capita
Exports: $41.0 million (1977); 39% copra, 27% timber,
23% fish
Imports: $32.5 million (1977); 12% energy fuels
Major trade partners: exports — EEC excluding UK 42%,
Japan 29%; imports— Australia 34%, UK 14%, Japan 13%
(1975)
Aid: economic commitments from Western (non-US)
countries, ODA (1979), $13.3 million
Budget: (1977) $24.2 million
Monetary conversion rate: 1 Australian dollar=
US$1.1532 (September 1978)','06b7f8d9d1c219f1323643796d14656cc05859d5939df6fb402f13666fc1de97','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('802486713468484b11a20034e745244a91b8003aabb0cac2de9ce89cd291d2db',1982,'SO','Somalia','economy',494,'GDP: $411.1 million (1978 est.), $187.0 per capita
Agriculture: mainly a pastoral country, raising livestock;
crops — bananas, sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar
refinery, tuna and beef canneries, textiles, iron rod plant,
and petroleum refining
Electric power: 90,000 kW capacity (1980); 100 million
kWh produced (1980), 20 kWh per capita
Exports: $137 million (f.o.b., 1980); livestock, hides, skins,
and bananas
Imports: $463 million (c.i.f., 1980); textiles, cereals, trans-
port equipment, machinery, construction materials and equip-
ment, petroleum products; also military materiel in 1977
Major trade partners: Arab countries and Italy; $21.4
million imports from Communist countries (1975 est.)
External debt: $700 million (1980); external debt service
payments, 5%
Budget: (1981) revenues $400 million, current expend-
itures $381 million, development expenditures $50 million
Monetary conversion rate: 6.295 Somali shillings=US$l
Fiscal year: calendar year','63ce94e09c64a438b2af2ebbc99445d917a38293df5588ce4c9843061047258f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b865777b0537247e1aa62306e50ae63c8be48eb607bd0a3b9a54857e59e9abb9',1982,'ZA','South Africa','economy',498,'GDP: $70.3 billion (1980), about $2,400 per capita; 8%
real growth in 1980
Agriculture: main crops — corn, wool, wheat, sugarcane,
tobacco, citrus fruits; dairy products; self-sufficient in
foodstuffs
Fishing: catch 658,688 metric tons (1979)
214
SOVIET UNION 2
SOUTH AFRICA (Continued)
Major industries: mining, automobile assembly, metal-
working, machinery, textiles, iron and steel, chemical, fertil-
izer, fishing
Electric power: 20,600,000 kW capacity (1980); 98.7
billion kWh produced (1980), 3,439 kWh per capita
Exports: $25.5 billion (f.o.b., 1980, including gold); wool,
diamonds, corn, uranium, sugar, fruit, hides, skins, metals,
metallic ores, asbestos, fish products; gold output $13.0
billion (1980)
Imports: $18.4 billion (f.o.b., 1980); motor vehicles, ma-
chinery, metals, petroleum products, textiles, chemicals
Major trade partners: US, West Germany, Japan, UK
Aid: no military or economic aid
Budget: FY80 — revenue $17.6 billion, current expend-
itures $16.1 billion
Monetary conversion rate: 1 SA Rand=US$1.2854 (1980)
Fiscal year: calendar year
GNP: $1,392.5 billion (1980, in 1980 US prices), $5,245
per capita; in 1980 percentage shares were — 54% consump-
tion, 33% investment, 13% government and other, including
defense (based on 1970 GNP in rubles at adjusted factor
cost); average annual growth rate of real GNP (1971-80),
3.2%, average annual growth rate (1976-80), 2.7%
Agriculture: principal food crops— grain (especially
wheat), potatoes; main industrial crops — sugar, cotton, sun-
flowers, and flax; degree of self-sufficiency depends on
fluctuations in crop yields; calorie intake, 3,300 calories per
day per capita in recent years
Fishing: catch 9.5 million metric tons (1980); exports
483,504 metric tons (1980), imports 181,938 metric tons
(1980)
Major industries: diversified, highly developed capital
goods industries; consumer goods industries comparatively
less developed
Shortages: natural rubber, bauxite and alumina, tantalum,
tin, tungsten, fluorspar, and molybdenum
Crude steel: 163 million metric ton capacity as of 1
January 1979; 149 million metric tons produced in 1981, 555
kg per capita
Electric power: 279,500,000 kW capacity (1981); 1,325.0
billion kWh produced (1981), 4,927 kWh per capita
Exports: $76,437 million (f.o.b., 1980); petroleum and
petroleum products, natural gas, metals, wood, agricultural
products, and a wide variety of manufactured goods (pri-
marily capital goods)
Imports: $68,473 million (f.o.b., 1980); grain and other
agricultural products, machinery and eauipment, steel pro-
ducts (particularly large diameter pipe), consumer manufac-
tures
Major trade partners: $144.9 billion (1979 total turnover);
trade 54% with Communist countries, 33% with industrial-
ized West, and 13% with less developed countries
Aid: economic — total extended to non-Communist LDCs
(1954-80), $21.5 billion
Official monetary conversion rate: 0.649 rubles=US$l
(average 1980)
Fiscal year: calendar year','84f3d855d19a0064a98a5997d972e131c5f4bb686a1108129c5794a1d81c5351','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a055ad06c5134978097d1c3bca1c68669612ba6e4112aaec07831e0cb5f75f44',1982,'SR','Suriname','economy',505,'GDP: $822 million (1978); $2,370 per capita (1979); real
growth rate 4% (1978)
Agriculture: main crops — rice, sugarcane, bananas; self-
sufficient in major staple (rice)
Major industries: bauxite mining, alumina and aluminum
production, lumbering, food processing
Electric power: 410,000 kW capacity (1981); 1.6 billion
kWh produced (1981), 3,500 kWh per capita
Exports: $514 million (f.o.b., 1980 est.); alumina, bauxite,
aluminum, rice, wood and wood products
Imports: $501 million (c.i.f., 1980 est.); capital equipment,
petroleum, iron and steel, cotton, flour, meat, dairy products
Major trade partners: exports— 41% US, 33% EC, 12%
other European countries; imports — 31% US, 33% EC, 16%
Caribbean countries (1977)
Aid: economic — bilateral commitments including Ex-Im
(FY70-80) from US, $1.9 million, (1970-79) from other
Western countries, $945.0 million; no military aid
Budget: revenue, $273 million; expenditure, $319 million
(1980 est.)
222
SWAZILAND
SUR1NAME (Continued)
Monetary conversion rate: 1 Suriname guilder (S.
fl.)=US$0.560
Fiscal year: calendar year','9a4655a8a88960b7ba702069e9bf072e22744f2b5dda9ff0c53b30345d4e726a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3645b3d7254ee2e80550118f7962f3265ef6623f06f030b4166e62cb6af55ac',1982,'SE','Sweden','economy',507,'GDP: approximately $364.4 million (1980), about $700
per capita; annual real growth 3.4% (1973-78)
Agriculture: main crops — maize, cotton, rice, sugar, and
citrus fruits
Major industry: mining
Electric power: 75,000 kW capacity (1980); 142 million
kWh produced (1980), 251 kWh per capita
Exports: $226.7 million (f.o.b., 1979); sugar, asbestos,
wood and forest products, citrus, meat products, cotton, iron
ore
Imports: $294.8 million (f.o.b., 1979); motor vehicles,
petroleum products, foodstuffs, and clothing
Major trade partners: South Africa, UK, US
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $165.0 million; US (FY70-
80), $42.4 million
Budget: 1980/81— revenue $190.0 million, current ex-
penditure $97.1 million, development expenditure $78.2
million
Monetary conversion rate: 1 Lilangeni=US$1.20 (1979)
Fiscal year: 1 April-31 March
GDP: $121.5 billion, $14,627 per capita (1980); 52.2%
private consumption, 20.3% investment, 29.5% government
consumption; —1.2% inventory change; —0.7% net exports
of goods and services; 1980 growth rate 1.4% in constant
prices
Agriculture: animal husbandry predominates with milk
and dairy products accounting for 37% of farm income;
main crops — grains, sugar beets, potatoes; 100% self-
sufficient in grains and potatoes, 85% self-sufficient in sugar
beets; food shortages — oils and fats, tropical products; caloric
intake, 2,820 calories per day per capita (1978)
Fishing: catch 230,300 metric tons (1980), exports $65
million, imports $213 million
Major industries: iron and steel, precision equipment
(bearings, radio and telephone parts, armaments), wood pulp
and paper products, processed foods, motor vehicles
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 4.2 million metric tons produced (1980), 505
kg per capita
Electric power: 32,000,000 kW capacity (1980); 93.6
billion kWh produced (1980), 11,250 kWh per capita
Exports: $27,538 million (f.o.b., 1979); machinery, motor
vehicles, wood pulp, paper products, iron and steel products,
metal ores and scrap, chemicals
Imports: $28,579 million (c.i.f., 1979); machinery, motor
vehicles, petroleum and petroleum products, textile yarn
and fabrics, iron and steel, chemicals, food, and live animals
Major trade partners: (1979) 50% EC, 31% other devel-
oped, 6% Communist, 13% LDCs
Aid: donor: economic aid authorized (ODA and OOF),
$3.8 billion (1970-79)
Budget: (1980/81) revenues $36.8 billion, expenditures
$49.5 billion, deficit $12.7 billion
Monetary conversion rate: 4.2296 kronor=US$l (1980)
Fiscal year: 1 July-30 June','c13386e9ea301d2df7d9d5116149a94be827cc3fbcc2f25cf66e1c64f8601148','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cfcf606a0b1f71b530d22ac2e07bc42287ba99dfe1d2fbad930cbe4155622b1',1982,'CH','Switzerland','economy',513,'GNP: $90.31 billion (1980), $14,270 per capita; 61%
consumption, 26% investment, 13% government, —0.9% net
foreign balance; real growth rate 0.4% (1980)
Agriculture: dairy farming predominates; less than 50%
self-sufficient; food shortages — fish, refined sugar, fats and
oils (other than butter), grains, eggs, fruits, vegetables, meat;
caloric intake, 3,190 calories per day per capita (1969-70)
Major industries: machinery, chemicals, watches, textiles,
precision instruments
Shortages: practically all important raw materials except
hydroelectric energy
Electric power: 15,000,000 kW capacity (1980); 48.162
billion kWh produced (1980), 7,610 kWh per capita
226
SYRIA
SWITZERLAND (Continued)
Exports: $29.27 billion (f.o.b., 1980); principal items-
machinery and equipment, chemicals, precision instruments,
metal products, textiles, foodstuffs
Imports: $35,174 billion (c.i.f., 1980); principal items-
machinery and transportation equipment, metals and metal
products, foodstuffs, chemicals, textile fibers and yarns
Major trade partners: 60% EC, 23% other developed, 4%
Communist, 12% LDCs
Aid: donor: bilateral economic aid committed (ODA and
OOF), $860 million (1970-79)
Budget: receipts $8.33 billion, expenditures $8.87 billion,
deficit $0.54 billion (1980)
Monetary conversion rate: US$1. 00= 1.96 Swiss francs
(1981 average)
Fiscal year: calendar year
GDP: $12.9 billion (1980), $960 per capita; real GDP
growth rate 9.7% (1980)
Agriculture: main crops — cotton, wheat, barley and to-
bacco; sheep and goat raising; self-sufficient in most foods in
years of good weather
Major industries: textiles, food processing, beverages,
tobacco; petroleum— 166,000 b/d production (1980),
220,000 b/d refining capacity
Electric power: 1,971,500 kW capacity (1980); 3.638
billion kWh produced (1980), 406 kWh per capita
Exports: $2.11 billion (f.o.b., 1980); petroleum, textiles
and textile products, tobacco, fruits and vegetables, cotton
Imports: $4.01 billion (f.o.b., 1980); machinery and metal
products, textiles, fuels, foodstuffs
Major trade partners: exports — Italy, Romania, US,
USSR; imports — Iraq, West Germany, Italy, France
Budget: 1981 — revenues $3.5 billion (excluding Arab aid
payments), expenditures $7.8 billion
Monetary conversion rate: 3.925 Syrian pounds=US$l
(official rate; a parallel market was established in April 1981
with the rate determined by the government guided by
supply and demand)
Fiscal year: calendar year
Mainland:
GDP: $4.6 billion (1979), $271 per capita; real growth
rate, 3.7% (1979)
Agriculture: main crops — cotton, coffee, sisal on mainland
Major industries: primarily agricultural processing (sugar,
beer, cigarettes, sisal twine), diamond mine, oil refinery,
shoes, cement, textiles, wood products
Electric power: 275,000 kW capacity (1980); 964 million
kWh produced (1980), 51 kWh per capita
Exports: $684 million (f.o.b., 1979); coffee, cotton, sisal,
cashew nuts, meat, diamonds, cloves, tobacco, tea
Imports: $1,194 million (f.o.b., 1979); manufactured
goods, machinery and transport equipment, cotton piece
goods, crude oil, foodstuffs
Major trade partners: exports — China, UK, Hong Kong,
India, US; imports — UK, China, West Germany, US, Japan
229','1f73d3bf0375d676cf8efa2c8281f75ba71952e803affbdd3a976cf2b894e7b7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('165aab392e0cff593b9041575536a318d7e2942d60df1188d15f482952d77e77',1982,'TH','Thailand','economy',514,'TANZANIA (Continued)
External public debt and ratio: $1.2 billion, 7.3% (1979)
Budget: (1979/80) revenue $890 million, current expendi-
tures $1,110 million, development expenditures $525 million
Monetary conversion rate: 8.1898 Tanzanian shil-
lings=US$l (June 1980)
Fiscal year: 1 July-30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops — cloves, coconuts
Industries: agricultural processing
Electric power: see Mainland (above)
Exports: $504 million (f.o.b., 1977); cloves and clove
products, coconut products
Imports: $723 million (c.i.f., 1977); mainly foodstuffs and
consumer goods
Major trade partners: imports — China, Japan, and main-
land Tanzania; exports — Singapore, China, Hong Kong,
Indonesia, India, Pakistan
Aid: economic aid commitments from Western (non-US)
countries (1970-79), ODA and OOF, $100 million; US,
including Ex-Im (FY70-80), $200 million
Exchange rate: 8.00 Tanzanian shillings=US$l
Fiscal year: 1 July-30 June','06fd1d55825a2bdbf0f3972a02f7c7f3eaae6b3afde4d6a857808b49a5268d78','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d292189fa2b2165f88bbc918e062ac4fec48cda8e608c1116c19b22519538755',1982,'TO','Tonga','economy',516,'TOGO (Continued)
Monetary conversion rate: Communaute Financiere
Africaine 286 francs=US$l (1981)
Fiscal year: calendar year','cbaf975c2412cd0a584d7dda9650df9c767b90360032b77a54ccb6560726c6f7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cba105e3a22a9ca4a4f4581f05883f4e399d9d14c07f83cd48dc62e39547ded5',1982,'TT','Trinidad and Tobago','economy',521,'GNP: $34.2 million (1976), $370 per capita
Agriculture: largely dominated by coconut and banana
production with subsistence crops of taro, yams, sweet
potatoes, and bread fruit
Electric power: 4,100 kW capacity (1980); 8 million kWh
produced (1980), 87 kWh per capita
Exports: $5.6 million (1978); 65% copra, 7% coconut
products, 8% bananas
Imports: $12.4 million (1978); food, machinery, and
petroleum
Major trade partners: (FY74) exports — 25% Netherlands,
22% Australia, 20% New Zealand, 11% Norway; imports —
63% New Zealand and Australia
Aid: economic aid commitments — Western (non-US)
countries, ODA and OOF (1970-79), $57 million
Budget: (FY77) $10 million
Monetary conversion rate: 1 Tonga dollar=US$l. 1 1
(1979)
Fiscal year: 1 July-30 June
GDP: $6,708 million (1980 prov.), $5,719 per capita; 42%
private consumption, 17% government consumption, 28%
investment, 13% foreign; growth rate (1980), 10%
Agriculture: main crops — sugarcane, cocoa, coffee, rice,
citrus, bananas; largely dependent upon imports of food
Fishing: catch 4,823 metric tons (1978); exports $1.1
million (1975), imports $4.5 million (1975)
Major industries: petroleum, tourism, food processing,
cement
Electric power: 555,000 kW capacity (1981); 2.0 billion
kWh produced (1981), 1,697 kWh per capita
Exports: $4.0 billion (f.o.b., 1980 prelim.); petroleum and
petroleum products, ammonia, fertilizer
Imports: $3.1 billion (c.i.f., 1980); crude petroleum (31%),
machinery, fabricated metals, transportation equipment,
manufactured goods, food, chemicals
Major trade partners: imports — US 27%, UK 10%, Japan
7%, crude oil for refineries supplied almost exclusively from
Saudi Arabia and Indonesia; exports — US 58%, CARICOM
8%
Aid: economic — bilateral commitments including Ex-lm
(FY70-80), US, $295.2 million; (1970-79) other Western
countries, ODA and OOF, $100 million
Budget: (1978) central government revenues $1.3 billion,
expenditures $1.2 billion (current $618 million, capital $560
million)
Monetary conversion rate: tied to US dollar in 1976; 2.40
Trinidad and Tobago dollars=US$l
Fiscal year: calendar year','a9a64dee829261c879a71ed5ef51570833d41f9e93a365ac9590ac7e493749ef','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e29d94134f68c97ef0152885c101faca63871c118e82250ec3a7fd994046ab0',1982,'TN','Tunisia','economy',527,'GDP: $8.5 billion (1980 prelim.), $980 per capita; 60%
private consumption, 15.3% government consumption,
27,6%- investment; average annual growth (1975-80), 7.1%
Agriculture: main crops — cereals (barley and wheat), ol-
ives, grapes, citrus fruits, and vegetables
Major sectors: agriculture; industry — mining (phosphate),
energy (petroleum, natural gas), manufacturing (food pro-
cessing and textiles), services (transport, telecommunications,
tourism, government)
Electric power: 814,900 kW capacity (1980); 2.428 billion
kWh produced (1980), 371 kWh per capita
Exports: $2.2 billion (f.o.b., 1980); 51% crude petroleum,
14% phosphates, 8% textiles
Imports: $1.1 billion (c.i.f., 1980)
236
TURKEY
TUNISIA (Continued)
Major trade partners: exports — France, Italy, West Ger-
many, Greece
Tourism and foreign worker remittances: $622 million
(1980)
Budget: (1980 prelim.) total revenue and grants $2.4
billion; current expenditures $1.7 billion; development ex-
penditures, including capital transfers and net lending, $881
million
Monetary conversion rate: 0.51 Tunisian dinar (TD)=
US$1
Fiscal year: calendar year
GNP: $58.7 billion (1980), $1,300 per capita; -1.1% real
growth 1980, 6% average annual real growth 1970-79
Agriculture: main products — cotton, tobacco, cereals, su-
gar beets, fruits, nuts, and livestock products; self-sufficient
in food in average years
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.7 million tons produced (1980), 27 kg per
capita
Electric power: 6,389,200 kW capacity (1980); 23.330
billion kWh produced (1980), 506 kWh per capita
Exports: $2,910 million (f.o.b., 1980); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $7,667 million (c.i.f., 1980); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: (1980) exports— 20.8% West Ger-
many, 7.5% Italy, 6.1% USSR, 5.6% France, 4.6% Iraq;
imports— 15.0% Iraq, 10.9% West Germany, 5.8% US, 4.8%
France, 4.5% Switzerland
Budget: (FY80) revenues $12.4 billion, expenditures $14.2
billion, deficit $1.8 billion
Monetary conversion rate: 76.04 Turkish liras=US$l
(1980)
Fiscal year: 1 March-28 February','726b449f1fa4dbc2792f49de9737c224677a9523efe2abe732ad2345fe8e4969','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19d35563e4da0ac98301f8217d3c737e95c65c0e1e0ac93db4716f6740885895',1982,'WS','Samoa','economy',532,'GNP: $1.2 million (1975), $180 per capita
Electric power: 2,600 kW capacity (1979); 3.0 million
kWh produced (1979), 433 kWh per capita
Exports: $67,000 (1977); copra
Imports: $1.44 million (1977); food and mineral fuels
Major trade partners: Australia, UK
Aid: economic commitments — Western (non-US) coun-
tries, ODA (1970-79), $22 million
Budget: (1978) $1.6 million
Monetary conversion rate: Australian (A)$1=US$1.12
(1979); A$1=US$1.14(1978)','cb3366fa9783da47f979597bd74b1d42534ef1bf778be397497d01454baf7b46','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a9e0b2f1e42ef60a79989e05d305b1b4d430be7f6d446f02d418942bd1de25a',1982,'AE','United Arab Emirates','economy',538,'GNP: $30 billion est. (1980), $32,000 per capita
Agriculture: food imported, but some dates, alfalfa, vege-
tables, fruit, tobacco raised
Electric power: 3,814,000 kW capacity (1980); 8.353
billion kWh produced (1980), 8,943 kWh per capita
Exports: $22.2 billion (f .o.b., 1980; $19.6 billion in oil, $2.6
billion nonoil); crude petroleum, pearls, fish
Imports: $7.5 billion (f.o.b., 1980); food, consumer, and
capital goods
Major trade partners: UK, US, Japan, India, EC
Budget: (1980) current expenditures $8.0 billion, capital
$2.0 billion, public revenue $12.7 billion
Monetary conversion rate: 1 UAE Dirham=US$3.671
(1980)
Fiscal year: calendar year','5e1ae20bf06d21e9d39c9030e900f34011575cf2f69482b39dcae904b9518868','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('895da80c8ee2510d6f58b811448a10af945c66694841a672b889ebc74c33ea75',1982,'US','United States','economy',542,'GNP: $2,368.8 billion (1979); 63.7% personal consumption,
16.4% private investment, 20.1% government, —0.2% net
exports; $10,745 per capita
Fishing: catch 6.482 billion metric tons (1980); imports
$3,648 million (1980); exports $1,006 million, (1980); est.
value, $2,237 million (1980)
Crude steel: 113.7 million metric tons produced (1977),
618 kg per capita consumption
Electric power: 616,486,200 kW capacity (1980);
2,286.439 billion (net) kWh produced (1980), 10,245 kWh
per capita
Exports: $181.8 billion (f.o.b., 1979); machinery, chemi-
cals, grains, and road motor vehicles
Imports: $218.9 billion (c.i.f., 1979); crude and partly
refined petroleum, machinery, and transport equipment
(mainly new automobiles)
Major trade partners: exports— 23.4% EEC (5.9% UK,
4.7% FRG), 18.2% Canada, 12.8% LAFTA, 9.7% Japan, 5.4%
Mexico; imports— 18.5% Canada, 16.1% EEC (5.3% FRG,
3.9% UK), 12.7% Japan, 10.6% LAFTA, 4.3% Mexico, 4.0%
Nigeria, 3.9% Saudi Arabia (1979)
244
UPPER VOLTA
UNITED STATES (Continued)
Aid: obligations and loan authorizations (FY78), economic
$6.51 billion, military $2.35 billion
Budget: (FY81 est.) receipts $605.64 billion, outlays
$661,237 billion
Fiscal year: 1 October-30 September
GNP: $1,100 million (1980), $177 per capita; real growth,
2.5% (1980)
Agriculture: cash crops — peanuts, shea nuts, sesame, cot-
ton; food crops — sorghum, millet, corn, rice; livestock; large-
ly self-sufficient
Fishing: catch 7,000 metric tons (1979 est.)
Major industries: agricultural processing plants, brewery,
bottling, and brick plants; a few other light industries
Electric power: 30,000 kW capacity (1980); 90 million
kWh produced (1980), 13 kWh per capita
Exports: $118.6 million (f.o.b., 1980 est.); livestock (on the
hoof), peanuts, shea nut products, cotton, sesame
Imports: $236.0 million (c.i.f., 1980 est.); textiles, food,
and other consumer goods, transport equipment, machinery,
fuels
Major trade partners: Ivory Coast and Ghana; overseas
trade mainly with France and other EC countries; preferen-
tial tariff to EC and franc zone countries
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $693.0 million; US autho-
rized including Ex-Im (FY70-80) $122.4 million
Budget: (1980) revenue $190.4 million, current expendi-
tures $166.6 million, development expenditures $27.9
million
Monetary conversion rate: about 211.3 Communaute
Financiere Africaine francs=US$l (1980)
Fiscal year: calendar year','ef3d2f2306666f40fb30a5bb2bf22fb150898a6deabace4d6733c42808e09068','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afb61e88d93740ae0cd79ab4106b0fb94364f45174fbbd8f79fb2b28bef62896',1982,'UY','Uruguay','economy',546,'GDP: $9.9 billion (1980), $3,400 per capita; 88% consump-
tion, 17% gross investment, —5.0% foreign; real growth rate
1978, 2.5%
Agriculture: large areas devoted to extensive livestock
grazing (20 million sheep, 9.5 million cattle), 1979; main
crops — wheat, rice, corn, sorghum; self-sufficient in most
basic foodstuffs; caloric intake (1977), 3,036 calories per day
per capita, with high protein content
Major industries: meat processing, wool and hides, tex-
tiles, footwear, cement, petroleum refining
Steel: rolled products 43,398 metric tons produced (1978)
Electric power: 715,000 kW capacity (1981); 3.5 billion
kWh produced (1981), 1,160 kWh per capita
Exports: $1,059 million (f.o.b., 1980); wool, hides, meat,
textiles
Imports: $1,625 million (f.o.b., 1980); crude petroleum
(26%), metals, machinery, transportation equipment, indus-
trial chemicals
Major trade partners: exports— 33% EC, 11% US, 40%
LAFTA; imports— 44% LAFTA (15% Brazil, 17% Argenti-
na), 9% US, 19% EC (1979)
Aid: economic commitments — US including Ex-Im
(FY70-80) $61 million; from other Western countries, ODA
and OOF (1970-79) $62 million; military— US (FY70-80) $39
million
247
URUGUAY (Continued)
Budget: (1979 est.) revenue, $1,063 million; expenditure,
$1,014 million
Monetary conversion rate: 9.16 pesos=US$l (1980 annu-
al average)
Fiscal year: calendar year','20410dcececcd746c9af023a0989c16c43abd1cfa9d5ea6d7858dbb446f3adbc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e4cf8b902bf279fec3cae61d0e48f8d3491df0703f2cf6654b579d5e7167b46',1982,'VU','Vanuatu','economy',550,'Agriculture: export crops of copra, cocoa, coffee, some
livestock and fish production; subsistence crops of copra,
taro, yams
248
VATICAN CITY
VANUATU (Continued)
Electric power: 10,000 kW capacity (1981); 17 million
kWh produced (1981), 162 kWh per capita
Exports: $32.2 million (1977); 24% copra, 59% frozen fish,
meat
Imports: $40.1 million (1977); 18% food
Aid: Australia (1980-83), $14.4 million
Monetary conversion rate: 1 pound=US$5.12 (official
currency, 1979), Australian $0.89=US$1, 75 Colonial Franc
Pacifique (CFP)=US$1 (1978/79)
The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter''s pence) from
Roman Catholics throughout the world; some income de-
rived from sale of Vatican postage stamps and tourist
mementos, fees for admission to Vatican museums, and sale
of publications; industrial activity consists solely of printing
and production of a small amount of mosaics and staff
uniforms; the banking and financial activities of the Vatican
are worldwide; the Institute for Religious Agencies carries
out fiscal operations and invests and transfers funds of
Roman Catholic religious communities throughout the
world; the Cardinal''s Commission controls the administra-
tion of ordinary assets of the Holy See and a Special
Administration manages the Holy See''s capital assets
Electric power: 2100 kW (standby) capacity (1981); all
power is imported from Italy
GNP: $60 billion (1980, in 1980 dollars), $4,000 per capita;
52% private consumption, 14% public consumption, 34%
gross investment (1979); real growth rate —0.1% (1980)
Agriculture: main crops — sugarcane, corn, coffee, rice;
imports wheat (US), corn (South Africa), sorghum (Argentina,
US); caloric intake 2,435 calories per day per capita (1977)
Fishing: catch 178,000 metric tons (1980); exports $1.6
million (1979), imports $19.7 million (1980)
Major industries: petroleum, iron-ore mining, construc-
tion, food processing, textiles
Crude steel: 848,000 metric tons produced (1978), 60 kg
per capita
Electric power: 10,000,000 kW capacity (1981); 43.0
billion kWh produced (1981), 2,500 kWh per capita
Exports: $19.3 billion (f.o.b., 1980); petroleum (95%), iron
ore, coffee
Imports: $11.3 billion (f.o.b., 1980); industrial machinery
and equipment, chemicals, manufactures, wheat
Major trade partners: imports — 45% US, 8% Japan, 6%
West Germany; exports— 30% US, 11% Canada (1980)
Budget: 1980— revenues $14.6 billion; expenditures, $12.0
billion, capital $2.2 billion
Monetary conversion rate: 4.2925 bolivares=US$l (Janu-
ary 1982)
Fiscal year: calendar year','59af3848c6c8a24f05fb822ffa126198916e527341fdee3da1d8f01e9af8562d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a75e0b5a6fdb2058e9afbade8c8d3bc64b1459cb4b53e1b09c71026262574024',1982,'WF','Wallis and Futuna','economy',554,'Agriculture: dominated by coconut production with sub-
sistence crops of yams, taro, bananas
Electric power: 1,000 kW capacity (1981); 1 million kWh
produced (1981), 133 kWh per capita
Exports: negligible
Imports: $3.4 million (1977); largely foodstuffs and some
equipment associated with development programs
Aid: (1978) France, European Development Fund, $2.6
million
Monetary conversion rate: 75 Colonial Franc Pacifique
(CFP)=US$1','576e6a8040a9bce26cbc6cd533778306f7851e6db63b2d71d68e61e47feb2e8c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad63c412e849401fb6bc5bc07e45a424ade1b312727fe831a6a9778b4b2a260d',1982,'EH','Western Sahara','economy',558,'Agriculture: practically none; some barley is grown in
nondrought years; fruit and vegetables in the few oases; food
imports are essential; camels, sheep, and goats are kept by
the nomadic natives; cash economy exists largely for the
garrison forces
Major industries: phosphate and iron mining, fishing, and
handicrafts
Shortages: water
Electric power: 56,000 kW capacity (1980); 78 million
kWh produced (1980), 772 kWh per capita
Exports: in 1975, up to $75 million in phosphates, all other
exports valued at under $1 million
Imports: $1,443,000 (1968); fuel for fishing fleet,
foodstuffs t
Major trade partners: monetary trade largely with Spain
and Spanish possessions, more recently with Morocco
Aid: small amounts from Spain in prior years; currently
Morocco is major source of support
Monetary conversion rate: see Moroccan and Maurita-
nian currencies
GNP: $70 million (1978), $450 per capita
Agriculture: cocoa, bananas, copra; staple foods include
coconut, bananas, taro, and yams
Major industries: timber, tourism
Electric power: 16,900 kW capacity (1981); 41 million
kWh produced (1981), 263 kWh per capita
Exports: $11.1 million (f.o.b., 1978); copra 43.3%, cocoa
32.3%, timber 2.0%, mineral fuel, bananas
Imports: $52.5 million (c.i.f., 1978); food 30%, manufac-
tured goods 25%, machinery
Major trade partners: exports — 37% New Zealand, 7%
Netherlands, 36% West Germany, 8% US; imports— 28%
New Zealand, 20% Australia, 15% Japan, 13% US
Aid: economic commitments — US (FY70-80), $8 million;
Western (non-US) countries, ODA and OOF (1970-79), $72
million
Budget: (1977) $53.3 million
Monetary conversion rate: WS Tala=US$1.22 (1979)
GNP: $792 million (1978 est.), $430 per capita
Agriculture (all outside Aden): cotton is main cash crop;
cereals, dates, kat (qat), coffee, and livestock are raised and
there is a growing fishing industry; large amount of food
must be imported (particularly for Aden); cotton, hides,
skins, dried and salted fish are exported
Major industries: petroleum refinery at Little Aden
operates on imported crude; 1981 output about one-half of
rated capacity of 170,000 b/d; oil exploration activity
Electric power: 142,100 kW capacity (1980); 349 million
kWh produced (1980), 181 kWh per capita
Exports: $44.3 million (1979), excluding petroleum prod-
ucts but including re-exports
Imports: $391.0 million (f.o.b., 1979)
Major trade partners: Yemen, East Africa, but some
cement and sugar imported from Communist countries;
crude oil imported from Persian Gulf, exports mainly to UK
and Japan
Budget: (1979) total receipts $423 million, current expend-
itures $209 million, development expenditures $214 million
Monetary conversion rate: 1 S. Yemeni dinar=US$2.90
Official foreign reserves: $800 million (December 1981)
Fiscal year: calendar year
GNP: $3.8 billion (FY79), $740 per capita
Agriculture: sorghum and millet, qat (a mild narcotic),
cotton, coffee, fruits and vegetables; largely self-sufficient in
food
Major industries: cotton textiles and leather goods pro-
duced on a small scale; handicraft and some fishing; small
aluminum products factory
Electric power: 100,500 kW capacity (1980); 220 million
kWh produced (1980), 41 kWh per capita
Exports: $12.7 million (f.o.b., 1980); qat, cotton, coffee,
hides, vegetables
Imports: $1,685.0 million (f.o.b., 1980); textiles and other
manufactured consumer goods, petroleum products, sugar,
grain, flour, other foodstuffs, and cement
Major trade partners: China, Yemen (Aden), USSR, Ja-
pan, UK, Australia, Saudi Arabia
Budget: (1978-79) total receipts $909 million, current
expenditure $409 million, development expenditure $590
million
Monetary conversion rate: I Yerneni rial=US$0.22 (1980)
Fiscal year: 1 July-30 June
GNP: $66.3 billion (1980 est., at 1980 prices), $2,900 per
capita; real growth rate 3% (1980)
Agriculture: diversified agriculture with many small pri-
vate holdings and large agricultural combines; main crops —
corn, wheat, tobacco, sugar beets, and sunflowers; occasion-
ally a net exporter of foodstuffs and live animals; imports
tropical products, cotton, wool, and vegetable meal feeds;
caloric intake, 3,539 calories per day per capita (1975)
Fishing: catch 56,000 metric tons (1979)
Major industries: metallurgy, machinery and equipment,
oil refining, chemicals, textiles, wood processing, food
processing
Shortages: electricity, fuels, steel
Crude steel: 3.6 million metric tons produced (1980), 160
kg per capita
Electric power: 15,113,000 kW capacity (1981); 63.3
billion kWh produced (1981), 2,797 kWh per capita
Exports: $8.9 billion (f.o.b., 1980); 51% raw materials and
semimanufactures, 15% equipment, 34% consumer goods
259
ZAIRE
YUGOSLAVIA (Continued)
Imports: $15.1 billion (c.i.f., 1980); 71% raw materials and
semimanufactures, 19% equipment, 10% consumer goods
Major trade partners: 62% non-Communist countries;
38% Communist countries, of which 25% USSR (1981)
Monetary conversion rate: 38.7 dinars=US$l (November
1981)
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $6.3 billion (1980 est.), $225 per capita; 1.8%
current annual growth rate
Agriculture: main cash crops — coffee, palm oil, rubber,
quinine; main food crops — manioc, bananas, root crops,
corn; some provinces self-sufficient
Fishing: catch 115,182 metric tons (1979)
Major industries: mining, mineral processing, light
industries
Electric power: 1,694,000 kW capacity (1980); 4.2 billion
kWh produced (1980), 143 kWh per capita
Exports: $2,089 million (f.o.b., 1980); copper, cobalt,
diamonds, petroleum, coffee
Imports: $1,469 million (c.i.f., 1980); consumer goods,
foodstuffs, mining and other machinery, transport equip-
ment, fuels
Major trade partners: Belgium, US, and West Germany
Budget: 1980 revenue, $1,250.2 million; current expendi-
tures, $1,242.3 million, capital expenditures $206.5 million
Monetary conversion rate: 1 zaire=US$0.182 (as of June
1981)
Fiscal year: calendar year','8e99da08c9747c00a095800a94bd190f4b7216ea9daa0ad3a7b8c3fd5ab3a0b8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8587f3dfaa4db41bf0c26733e821d1dda8f6bcd5ef5c2320407911d4e63e622',1982,'ZM','Zambia','economy',562,'GNP: $2.8 billion (1980), $483 per capita; real annual
average growth rate, 0.65% (1971-81)
Agriculture: main crops — corn, tobacco, cotton; net im-
porter of most major agricultural products
Major industries: copper and cobalt production
Electric power: 1,453,000 kW capacity (1980); 7.3 billion
kWh produced (1980), 969 kWh per capita
Exports: $1,378 million (f.o.b., 1980); copper, zinc, cobalt,
lead, tobacco
Imports: $1,383 million (c.i.f., 1980); machinery, transport
equipment, foodstuffs, fuels, manufactures
Major trade partners: EEC, Japan, China, South Africa
Budget: (1980) revenue $950 million (est.), current
expenditures $1,279 million (est.), development expenditures
$241 million (est.)
Monetary conversion rate: 1 Zambia kwacha=US$1.2446
(official)
Fiscal year: calendar year
262','a137a72bf71eec4a9d656c8afec07c9c2e44f009b7e7121e5428d13a70731c40','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7034c6faef62933e19e23c5baf6278d72f0bd8af42c5104f77e77b87ba4cd34c',1982,'ZW','Zimbabwe','economy',563,'ZAMBIA (Continued)
GDP: $4.75 billion (1980), $630 per capita; real growth 8%
Agriculture: main crops — tobacco, corn, sugar, cotton;
livestock; self-sufficient in foodstuffs
Major industries: mining, steel, textiles, chemicals, and
vehicles
Electric power: 1,453,000 kW capacity (1980); 7.5 billion
kWh produced (1980), 1,110 kWh per capita
Exports: $1,445 million (f.o.b., 1980), including net gold
sales and reexports; tobacco, asbestos, copper, tin, chrome,
gold, nickel, meat, clothing, sugar
Imports: $1,287 billion (1980); machinery, petroleum
products, wheat, transport equipment
Net merchandise trade earnings: $160 million (1980)
Major trade partner: South Africa
Aid: economic commitments — Western (non-US) coun-
tries, ODA and OOF (1970-79), $77 million
Budget: FY80 — revenues $1,422 million, expenditures
$2,200 million, deficit $778 million
Monetary conversion rate: 1 Rhodesian dollar=US$1.59
(1980)
Fiscal year: 1 July-30 June','07cd4de9b83bd4a48486a746ee5dfd4dd15603ae4fe557a57d8e26163e8fb5a7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

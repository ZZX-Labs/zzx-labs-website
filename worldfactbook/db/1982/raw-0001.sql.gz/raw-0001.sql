SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('885b567e625b440e867740028a6bfa4cf41bdaac163323881f175e32a1f79c8c',1982,'','','raw',1,'UNIVERSITY OF
ILLINOIS LIBRARY
AT URBANA CHAMPAIGN
BOOKSTACKS
BOOKSTACKS
DOCUMENTS
PcC
THE LIBflAmr of: the
AUG - 6 1982
UNIVERSITY OF ILLINOIS
AT Uff iAWA-CH A M PA (Gf(
Produced by the Central Intelligence Agency
CR 82-1 it 17
UNIVERSITY OF
ILLINOIS LIBRARY
AT URBANA-CHAMPAIGN
DOCUMENTS
This publication is prepared for the use of US Government
officials, and the format, coverage, and content arc designed to
meet their specific requirements, US Government officials may
obtain additional copies of this document directly or through
liaison channels from the Central Intelligence Agency.
Requesters outside the US Government may obtain subscriptions to
CIA publications similar to this one by addressing inquiries to:
Document Expediting (DOCEX; Project
Exchange and Gift Division
Library of Congress
WashKKton, BX . 20540
or: National Technical Information Service
5285 Port Royal Road
'' • Springfield, V A 22161
Requesters outside the US Government not interested in subscription
service may purchase specific publications either in paper copy or
microform from:
P ho todupli ca I i on Sen ice
Library of Congress
Wa^ngtoiu [>.C . 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
(To expedite service call the
NTtS Order Desk (703) 487-4650)
This publication is also for sale by the Superintendent of Documents,
US Government Printing Office. Washington. D C. 20402
(Slock No, 04 1*0 15-001 5 h5).
Central
Intelligence
Agency
The World Factbook— 1982
The World Factbook is produced annually by the Di
Central Intelligence Agency. The data are provided I
Central Intelligence Agency, the Defense Intelligenc
Census, and the US State Department. In general, ii
1 January 1982 was used in the preparation of this e
ary cutoff date are explained on page vii. Comments
may be addressed to:
snnn^u r" char£in* this material is re-
25rh ^ ltS ?tUrn to the "bnirv from
Llil * JLT" withdraw" on or before thl
Latest Date stamped below.
Theft, mutilation, and u«derMn|n(I *4 fc^
far dl«ipUnOFy octio. ond re^f In HI "7 7"°"
rhe Unlvariltr. <«*mf«oI from
T* riHw cell Telephone Center, 333*8400
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(703)351-7676
For information on how to obtain additional copies,
APR 23 1986
fed?
4, ** 1
3 0 19)6
JAN 0 2 1988
DEC 0 4 1987
MM* ! L16''-O-1096
f5«pfwrffi GS WF 81-001)
April 1982
CONTENTS
Page
Definitions, Abbreviations, and Explanatory Notes ... vii
United Nations (UN): Structure and Associated
Agencies viii
Abbreviations for Other Important International
Organizations ix
Conversion Factors xi
— A—
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN 1
\\Ajman (see UNITED ARAB EMIRATES)
ALBANIA 2
ALGERIA 4
ANDORRA 5
ANGOLA 6
ANTIGUA AND BARBUDA 8
ARGENTINA 9
AUSTRALIA 10
AUSTRIA 12
Azores (see PORTUGAL)
— B—
BAHAMAS, THE 13
BAHRAIN 14
Balearic Islands (see SPAIN)
BANGLADESH 15
BARBADOS 17
BELGIUM 18
BELIZE 19
BENIN 21
BERMUDA 22
BHUTAN 23
BOLIVIA 24
Bophuthatswana (see SOUTH AFRICA)
BOTSWANA 26
BRAZIL 27
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNEI 29
BULGARIA 30
BURMA 31
BURUNDI 33
Page
— C—
Cabinda (see ANGOLA)
Cambodia (see KAMPUCHEA)
CAMEROON 34
CANADA 36
Canary Islands (see SPAIN)
CAPE VERDE 37
CENTRAL AFRICAN REPUBLIC 38
Ceylon (see SRI LANKA)
CHAD 40
CHILE 41
CHINA (Taiwan listed at end of table) 43
COLOMBIA 44
COMOROS 46
CONGO (Brazzaville) 47
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS 48
COSTA RICA 49
CUBA 51
CYPRUS 52
CZECHOSLOVAKIA 54
— D—
Dahomey (see BENIN)
DENMARK 56
DJIBOUTI (formerly French Territory of the Afars
and Issas) 57
DOMINICA 58
DOMINICAN REPUBLIC 59
Dubai (see UNITED ARAB EMIRATES)
— E—
ECUADOR 61
EGYPT 62
Eiice Islands (see TUVALU)
EL SALVADOR 64
EQUATORIAL GUINEA 65
ETHIOPIA 67
— F—
FALKLAND ISLANDS (MALVINAS) 68
FAROE ISLANDS 69
Fernando Po (see EQUATORIAL GUINEA)
iii
Page
— F—
FIJI 70
FINLAND 72
FRANCE 73
FRENCH GUIANA 75
FRENCH POLYNESIA 77
French Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
— G—
GABON 78
GAMBIA, THE 79
GERMAN DEMOCRATIC REPUBLIC 81
GERMANY, FEDERAL REPUBLIC OF 82
GHANA 84
GIBRALTAR 85
Gilbert Islands (see KIRIBATI)
GREECE 87
GREENLAND 88
GRENADA 89
GUADELOUPE 90
GUATEMALA 92
GUINEA 93
GUINEA-BISSAU 95
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA 96
— H—
HAITI 97
HONDURAS 99
HONG KONG 100
HUNGARY 102
ICELAND 103
INDIA 105
INDONESIA 106
IRAN 108
IRAQ 109
IRELAND Ill
ISRAEL 112
ITALY 114
IVORY COAST 116
JAMAICA 118
JAPAN 119
JORDAN 121
Page
— K —
KAMPUCHEA (formerly Cambodia) 122
KENYA 124
KIRIBATI (formerly Gilbert Islands) 125
KOREA, NORTH 126
KOREA, SOUTH 127
KUWAIT 129
LAOS 130
LEBANON 132
LESOTHO 133
LIBERIA 135
LIBYA 136
LIECHTENSTEIN 138
LUXEMBOURG 139
— M—
MACAU 141
MADAGASCAR 142
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
MALAWI 144
MALAYSIA 145
MALDIVES 148
MALI 149
MALTA 151
MARTINIQUE 152
MAURITANIA 154
MAURITIUS 155
MEXICO 157
MONACO 158
MONGOLIA 159
MOROCCO 160
MOZAMBIQUE 162
— N—
NAMIBIA (South-West Africa) 163
NAURU 164
NEPAL 165
NETHERLANDS 167
NETHERLANDS ANTILLES 169
NEW CALEDONIA 170
New Hebrides (see VANUATU)
NEW ZEALAND 171
NICARAGUA 173
iv
Page
— N —
NIGER 175
NIGERIA 176
Northern Rhodesia (see ZAMBIA)
NORWAY 178
OMAN 179
— P—
PAKISTAN 180
PANAMA 182
PAPUA NEW GUINEA 184
PARAGUAY 185
Pemba (see TANZANIA)
PERU 187
PHILIPPINES 188
POLAND 190
PORTUGAL 191
Portuguese Guinea (see GUINEA-BISSAU)
Portuguese Timor (see INDONESIA)
— Q—
QATAR 193
— R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
REUNION 194
Rhodesia (see ZIMBABWE)
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA 196
RWANDA 197
— S—
ST. CHRISTOPHER-NEVIS 199
ST. LUCIA 200
ST. VINCENT AND THE GRENADINES 201
SAN MARINO 202
SAO TOME AND PRINCIPE 203
SAUDI ARABIA 204
SENEGAL 206
SEYCHELLES 207
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE 209
SINGAPORE 210
SOLOMON ISLANDS (formerly British Solomon
Islands) 212
SOMALIA 213
Page
— S—
SOUTH AFRICA 214
Southern Rhodesia (see ZIMBABWE)
South-West Africa (see NAMIBIA)
SOVIET UNION 215
SPAIN 217
Spanish Sahara (see WESTERN SAHARA)
SRI LANKA (formerly Ceylon) 219
SUDAN 220
SURINAME 222
SWAZILAND 223
SWEDEN 224
SWITZERLAND 226
SYRIA 227
— T—
Tanganyika (see TANZANIA)
TANZANIA 229
Tasmania (see AUSTRALIA)
THAILAND 230
TOGO 232
TONGA 233
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO 234
TUNISIA 236
TURKEY 237
TUVALU (formerly Ellice Islands) 239
— U—
UGANDA 240
Umm al Qaiwain (see UNITED ARAB EMIRATES)
UNITED ARAB EMIRATES: Abu Dhabi, *Ajman,
Dubai, Fujairah, Ras al Khaimah, Sharjah, Umm al
Qaiwain 241
United Arab Republic (see EGYPT)
UNITED KINGDOM 242
UNITED STATES 244
UPPER VOLTA 245
URUGUAY 247
— V—
VANUATU (formerly New Hebrides) 24B
VATICAN CITY 249
VENEZUELA 250
VIETNAM 252
— W—
WALLIS AND FUTUNA 253
Walvis Bay (see SOUTH AFRICA)
v
Page
— W—
WESTERN SAHARA - 254
(formerly Spanish Sahara)
WESTERN SAMOA 255
— Y—
YEMEN (Aden) 256
YEMEN (Sanaa) 258
YUGOSLAVIA 259
Page
— Z—
ZAIRE 260
ZAMBIA 262
Zanzibar (see TANZANIA)
ZIMBABWE 263
TAIWAN 265
Maps
(following text)
I The World (Guide to Reference Maps II— XI)
II North America
III Central America and the Caribbean
IV South America
V Europe
VI Middle East
VII Africa
VIM Soviet Union, Eost and South Asia
IX Southeast Asia
X Oceania
XI Arctic Region
XII Antarctic Region
Definitions, Abbreviations, and Explanatory Notes;
Dates of Information:
* Population figures are projected estimates for 1 July 1982; the average annual growth
rates listed are projected estimates for the period mid- 1981 to mid- 1982,
* Military manpower estimates are as of 1 January 1982, except the numbers of males
reaching military age, which are projected averages for the five-year period 1982-86.
* In addition, although research for this edition was generally completed in January
1982, major political developments through 25 April 1982 have been included.
Fiscal Year: The abbreviation FY stands for fiscal year; all years are calendar years un-
less otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and services produced within
the domestic borders of a country over a particular time period, normally a year. GNP
equals GDP plus the income accruing to domestic residents arising from investment
abroad less income earned in the domestic market accruing to foreigners abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual entries
throughout this foctbook are cLf. (cost, insurance, and freight), f.o.b. (free on board),
ODA (official development assistance), and OOF (other official flows).
Land Utilization: Most of the land utilization percentages are rough estimates. Figures
for "arable" land in some cases reflect the area under cultivation rather than the total
cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal states are included
only when they differ from territorial sea limits. Maritime claims do not necessarily rep-
resent the position of the United States Government.
Money: All money figures ore *n contemporaneous US dollars unless otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express volume of crude oil
and refined products; a barrel equals 42,00 gallons, 158.99 liters, 5-61 cubic feet, or
0,16 cubic meters.
Some of the countries and governments included in this publication are not fully
independent, and others are not officially recognized by the United States Government.
UNITED NATIONS (UN); STRUCTURE AND RELATED AGENCIES
Principal Organs:
SC Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
. , , Secretariat
Operating Bodies:
UNCTAD UN Conference on Trade and Development
TDB Trade and Development Board
UNDP UN Development Program
UNICEF UN Children''s Fund
UN I DO UN Industrial Development Organization
Regionol Economic Commissions:
EGA Economic Commission for Africa
ECE Economic Commission for Europe
EC LA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic ond Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the UN:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO UN Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the UN:
IAEA International Atomic Energy Agency
ABBREVIATIONS FOI OTHER IMPORTANT INTERNATIONAL ORGANIZATIONS
AAP30 Afro- Asian People''s Solidarity Organization
ADB Asian Development Bank
A FOB Af rican Development Bank
AIOEC Association of Iron Ore Exporting Countries
ANZUS ANZUS Council; treaty signed by Australia, New Zealand, and the','3fcb8ec706172bfa1815758d797a97fe4fcf21d7f7360135d6ae72e781285d28','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b85f1a849cdefa63c768fb04c55a1c2be8172f53d2b13387e17e2b3b7174983',1982,'US','United States','raw',2,'A PC African Peanut (Groundnut) Council
ASEAN Association of Southeast Asian Nations
ASP AC Asian and Pacific Council
ASSIMER International Mercury Producers Association
BENELUX Belgium, Netherlands, Luxembourg Economic Union
BLEU Belgium-Luxembourg Economic Union
CACM Central American Common Market
CAR I COM Caribbean Common Market
CARIfTA Caribbean Free Trade Association
CCC Customs Cooperation Council
CEAO West African Economic Community
CEMA Council for Mutual Economic Assistance
CENTO Central Treaty Organization
CI PEC Intergovernmental Council of Copper Exporting Countries
. . * Colombo Plan
, . i Council of Europe
DAC Development Assistance Committee (OECD)
EAMA African States associated with the EEC
EC European Communities (EEC, ECSC, EURATOM)
ECOWAS Economic Community of West African States
ECSC European Cool and Steel Community
EEC European Economic Community (Common Market)
EFTA European Free Trode Association
EIB European Investment Bank
ELDO European Space Vehicle Launcher Development Organization
EMA European Monetary Agreement
ENTENTE Political- Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo
ESRO European Space Research Organization
EURATOM European Atomic Energy Community
G-77 Group of 77
GCC Gulf Cooperation Council
IADB Inter-American Defense Board
I ATP International Association of Tungsten Producers
1BA International Bauxite Association
IBEC International Bank for Economic Cooperation
ICAC International Cotton Advisory Committee
ICC AT International Commission for the Conservation of Atlantic Tunas
ICCO International Cocoa Organization
IC EM Intergovernmental Committee for European Migration
ICES International Cooperation in Ocean Exploration
ICO International Coffee Organization
ABBREVIATIONS FOR OTHER IMPORTANT INTERNATIONAL ORGANIZATIONS (Cont.)
IDB
Inter -American Development Bank
IEA
International Energy Agency (associated with OECD)
IHO
International Hydrographic Organization
International Lead and Zinc Study Group
118
International Investment Bank
INRO
International Natural Rubber Organization
INTELSAT
International Telecommunications Satellite Organization
IOOC
International Olive Oil Council
1PU
Inter -Parliamentary Union
IRC
International Red Cross
ISCON
Islamic Conference
ISO
International Sugar Organization
rrc
International Tin Council
IWC
International Whaling Commission
IWC
International Wheat Council
LA FT A
Latin American Free Trade Association
LICROSS
League of Red Cross Societies
NAM
Nan-Aligned Movement
NATO
North Atlantic Treaty Organization
OAPEC
Organization of Arab Petroleum Exporting Countries
OAS
Organization of American States
OAU
Organization of African Unity
OCAM
Afro-Malagasy and Mauritian Common Organization
ODECA
Organization of Central American States
OECD
Organization for Economic Cooperation and Development
OPEC
Organization of Petroleum Exporting Countries
SELA
Latin American Economic System
SPC
South Pacific Commission
UDEAC
Economic and Customs Union of Central Africa
UEAC
Union of Central African States
UPEB
Union of B a nana Exporting Countries
WEU
W es tern E uropean Union
WFTU
World Federation of Trade Unions
WPC
World Peace Council
WSG
International Wool Study Group
WTO
World Tourism Organization
Conversion Factors
To Convert From
To
Multiply By
To Convert From
To
Multiply By
Acres
Hectares
ft 4fUAS«iA
U\\*tU40o DO
;
Meters, cubic
Tons, register
U.JDJ14/
Acres
Kilometers, square
ft nftdftd£ft^£
Miles, nautical
Kilometers
1 .ojl
Acres
Meters, square
4U40.O DO
Miles, statute
Centimeters
1 Af\\Q1A A
iouyj4.4
Centimeters
Meters
n fti
Miles, statute
Meters
1 £ftO 1AA
wenumeicrs, square
Meiers, square
ft fifim
iviues, siaiuie
Kilometers
1 ,OUy J44
n«itrMC n rAtt n At t
L/cgrtxs, rdnrcnncu
L/cgrcca, v^ClalUa
suuirdci jz dnu
\\A * 1 ac c/i n4 r a
jviiics, square
nccidrca
multiply by 5/9
Miles, square
Kilometers, square
7 CSOOOfi
pAAt
rcci
v^cniimcicra
in as
Ounces, avoirdupois
Grams
rcci
X^^t Arc
iVlClCla
ft Iftdfi
U. jUHO
uuntc!i, dvuiruupoia
K nArrr^ mc
iviiugrdms
ft ft7ft''?4Q^7,l
rcci
ixiiurncicra
ft nnmn^R
Ounces, troy
Pounds, troy
ft ftft''ll''l''l
rcci, cuDic
I it «rc
7ft 11 £847
AO. J 1 UO*f /
wunccs, iruy
Grams
■5 1 1ft"5ylS
J I . J UJ40
rcci, cuDic
Meters, cubic
ft ft7ft1 1 £R47
U.UZoj 1 Oo*t /
Pints, liquid
Milliliters
471 17A471
4 / J. 1 /04 / j
Feet, square
Centimeters, square
Q7Q ft1ft4
Pints, liquid
Liters
ft 471 1 7^471
U.4/J1 /04 / j
rcci, aqudrc
\\^Af Arc ennord
ivicicra, aqudrc
ft ftQ7Qft1ft4
Pounds, avoirdupois
Grams
4 J J, J7£.J /
Gallons, US liQuid
Liters
Pounds, avoirdupois
Kilograms
ft 4^1^0717
UalJUilS, tJo JiqUlU
Meters, cubic
ft ftft17RSA1 0
Pounds, avoirdupois
Quintals
ft ftft4S1^Q7
U.UU4 J J J7Z
Grams
wuncca, iruy
ft ft-io 1 «1
Pounds, avoirdupois
Tons, metric
ft ftftft4^1^07
U.UUU4J J J7Z
Grams
Pounds, troy
ft ftft7A7Q
Pounds, troy
Ounces, troy
1 7
Hectares
Kilometers, square
ft ftl
Pounds, troy
Grams
171 741 777
ncvidrca
\\^Af Arc c/lno r a
ivicicrs, aqudrc
1 ft ftftft
Quarts, dry
Liters
1 1 ftl 77 1
incnca
f^Aflti Try AtArc
vxnurncicra
7 $A
Quarts, dry
Dekaliters
ft 1 1 ftl 77 1
mines
\\AT AtAfC
ivieicrs
ft ft7Sd
vuans, jiquiu
11*1 * t Arc
Muiiiiicrs
inwnca,
\\^ illtlitA rc
1 (\\ 1ft7ft£4
fit I4rf c
Liters
ft 04A1S704/;
incnca, cuuiv
Liters
ft ftl AIRlftAd
U.U I O JO /UO*f
flu i n t <i 1 c
Trtric ty% At ri/*
i uns, mcinc
ft i
U. 1
IlldlGa, wUUlV
ivicicra, CUUll
ft ftftftftl A1ft7ftA4
i una, lung
tviiugidma
lftl £ fU7
uicuca, aqudic
V^CIlllIIlClCI a, aqUdlw
U.*T J 1 u
i una, lung
i una, mcinc
1 ftl fS\\Al
mwnca, aqudrc
\\^ At Arc cmtorA
vicicia, aqudrc
ft ftftftAA^I fs
i ons, meinc
vuiniais
1ft
uuncca, iruy
V> 1 Sft7S
i un-miica, lung
i un*K.iiumcicr s, m&inc
ruuiius, iruy
''J A7Q77Q
Ton-miles, short
Ton-kilometers, metric
Kilograms
Tons, metric
0.001
Tons, register
Meters, cubic
2.831685
Kilometers, square
Hectares
100
Tons, short
Kilograms
907.185
Liters
Milliliters
1000
Tons, short
Tons, metric
0.907185
Liters
Meters, cubic
0.001
Yards
Centimeters
91.44
Meters
Millimeters
1000
Yards
Meters
0.9144
Meters
Centimeters
100
Yards, cubic
Liters
764.5549
Meters
Kilometers
0.001
Yards, cubic
Meters, cubic
0.7645549
Meters, cubic
Liters
1000
Yards, square
Meters, square
0.836127
xl','36e73428f1d4d7647815ed07b7659960b78746a4cfb7b4ce98f127c2b50f3095','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('171d569a4a23daaf07b8dbb7b0efcfab3662f3dc85e3539d33baeae41cafaef1',1982,'AF','Afghanistan','raw',3,'(See reference map VIII)
LAND
647,500 km2; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','a63a85b7e62568b9ef3d35baada1d7b0d5555b2633d8f841732ab206e47ecc10','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('028245ba165548121b0f0dd80af2386d900148999cd62bcb1fc12e954846b937',1982,'AF','Afghanistan','government',5,'Official name: Democratic Republic of Afghanistan
Type: Communist regime backed by multidivisional So-
viet force
Capital: Kabul
Political subdivisions: 29 provinces with centrally ap-
pointed governors
Legal system: not established; legal education at Uni-
versity of Kabul; has not accepted compulsory ICJ
jurisdiction
Branches: Revolutionary Council acts as legislature and
final court of appeal; President of Council acts as chief of
state; Cabinet and judiciary responsible to Council; Presid-
ium chosen by Council has full authority when Council not
in session; Loya Jirga (Grand Assembly) supposed to convene
eventually and approve permanent constitution
Government leaders: President of the Revolutionary
Council and head of the People''s Democratic Party of
Afghanistan Babrak KARMAL; Prime Minister Soltan Ali
KESHTMAND
Suffrage: universal from age 18
Political parties and leaders: The People''s Democratic
Party of Afghanistan (PDPA) is the sole legal political party
Communists: the PDPA reportedly claims 50,000 mem-
bers; the Parcham faction of the PDPA was installed on 27
December 1979; members of the deposed Khalqi faction
continue to hold some important posts; the Sholaye-Jaweid is
a much smaller pro-Beijing group
Other political or pressure groups: the military and other
branches of internal security are being rebuilt by the Soviets;
insurgency continues throughout the country; widespread
opposition on religious grounds and anti-Soviet sentiment
Member of: ADB, Colombo Plan, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, ITU, NAM, UN,
UNESCO, UPU, WHO, WMO, WTO, WSG; suspended
from ISCON in January 1980','2fbf4940f0c565ce9c008cb54111170bbe527edd116a6f6eee7de8d3d10b05e2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d4c95ffe51f1750dc66b0ee3f310e01a8ca8e030d3197316296e12f01e4e009',1982,'AL','Albania','government',10,'Official name: People''s Socialist Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisions: 27 rethet (districts), including
capital
Legal system: based on constitution adopted in 1976;
judicial review of legislative acts only in the Presidium of the
People''s Assembly, which is not a true court; legal education
at State University of Tirane; has not accepted compulsory
1CJ jurisdiction
National holiday: Liberation Day, 29 November
2
ALBANIA (Continued)
Branches: People''s Assembly, Council of Ministers,
judiciary
Government leaders: Chairman, Council of Ministers
(Premier), Adil CARCAN1; Chairman, Presidium of the
People''s Assembly, Haxhi LLESHI (chief of state)
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every four
years; last elections 6 November 1978; 99.99% of electorate
voted
Political parties and leaders: Albanian Workers Party
only; First Secretary, Enver Hoxha
Communists: 101,500 party members (November 1976)
Member of: CEMA, FAO, IAEA, IPU, ITU, UN,
UNESCO, UPU, WFTU, WHO, WMO; has not participated
in CEMA since rift with USSR in 1961; officially withdrew
from Warsaw Pact 13 September 1968','8c8fbe94b70c4dc13bc685764769827e7f78320084b7ad4ed3d5c42ffb42d5a3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28e9e017339c695b884d73431def53f36dcb4e8ade253037571387152ce0f94d',1982,'DZ','Algeria','government',14,'Official name: Democratic and Popular Republic of
Type: republic
Capital: Algiers
Political subdivisions: 31 Wilayas (departments or
provinces)
Legal system: based on French and Islamic law, with
socialist principles; new constitution adopted by referendum
November 1976; judicial review of legislative acts in ad hoc
Constitutional Council composed of various public officials,
including several Supreme Court justices; Supreme Court
divided into four chambers; legal education at Universities
of Algiers, Oran, and Constantine; has not accepted compul-
sory ICJ jurisdiction
National holiday: 1 November
Branches: executive dominant; unicameral legislature;
judiciary
Government leader: President, Col. Chadli BENDJED1D,
elected 7 February 1979 as successor to deceased President
Boumediene
Suffrage: universal over age 19
Elections (latest): presidential 7 February 1979; depart-
mental assemblies 2 June 1974; local assemblies 30 March
1975; legislative elections held 25 February 1977
Political parties and leaders: National Liberation Front
(FLN), Secretary General Chadli Bendjedid
Communists: 400 (est.); Communist Party illegal (banned
1962)
Member of: AFDB, AlOEC, Arab League, ASS1MER,
FAO, G-77, GATT (de facto), IAEA, IBRD, ICAO, IDA,
IFAD, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IOOC, ISCON, ITU, NAM, OAPEC, OAU,
OPEC, UN, UNESCO, UPU, WHO, WIPO, WMO
Official name: Islamic Republic of Mauritania
Type: republic; military seized power in bloodless coup 10
July 1978
Capital: Nouakchott
Political subdivisions: 12 regions and a capital district
NOTE: Mauritania acquired administrative control of the
southern third of Western (formerly Spanish) Sahara under a
1975 agreement with Morocco and Spain. Following an
August 1979 peace agreement with Polisario insurgents
fighting for control of Western Sahara, Mauritania withdrew
from the territory and renounced all territorial claims.
Legal system: based on French and Islamic law; military
constitution April 1979
National holiday: Independence Day, 28 November
Branches: executive, Military Committee for National
Salvation rules by decree; National Assembly and judiciary
suspended pending restoration of civilian rule
Government leader: Chief of State and Head of Govern-
ment, Lt. Col. Mohamed Khouna Ould HAIDALLA
Suffrage: universal for adults
Elections: in abeyance; last presidential election August
1976
Political parties and leaders: suspended
Communists: no Communist party, but there is a scatter-
ing of Maoist sympathizers
Member of: AFDB, AlOEC, Arab League, CEAO, Cl-
PEC (associate), EAMA, E1B (associate), FAO, G-77, GATT,
IBRD, ICAO, IDA, 1FAD, 1FC, 1LO, IMCO, IMF, IPU,
1SCON, ITU, NAM, OAU, OMVS (Organization for the
Development of the Senegal River Valley), UN, UNESCO,
UPU, WHO, WIPO, WMO','5d83596e7d354ff46553f75b1ea0138e9719abb249e1b1340999580db8657596','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04f6787d0eea0146bdc42dc2e881e5e80edf57e7c6b6b4d430adb28c992f9953',1982,'AD','Andorra','government',18,'Official name: Principality of Andorra
Type: unique coprincipality under formal sovereignty of
President of France and Spanish Bishop of Seo de Urgel,
who are represented locally by officials called verguers
Capital: Andorra
Political subdivisions: 7 districts
Legal system: based on French and Spanish civil codes;
Plan of Reform adopted 1866 serves as constitution; no
judicial review of legislative acts; has not accepted compul-
sory ICJ jurisdiction
Branches: legislature (General Council) consisting of 28
members with one-half elected every two years for four-year
term; executive — syndic (manager) and a deputy subsyndic
chosen by General Council for three-year terms; judiciary
chosen by coprinces who appoint two civil judges, a judge of
appeals, and two Batles (court prosecutors); final appeal to
the Supreme Court of Andorra at Perpignan, France, or to
the Ecclesiastical Court of the Bishop of Seo de Urgel, Spain
Suffrage: males of 21 or over who are third generation
Andorrans vote for General Council members; same right
granted to women in April 1970
5','d45a012a14c5bbdf241cbf0a67c303cb243eb3fd686c6184340698b791d704d5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('460342e45840bb7b5ddcfd6aaa5939aec3995df8489a5e991a18aa471643923b',1982,'AO','Angola','government',19,'ANDORRA (Continued)
Elections: half of General Council chosen every two
years, last election December 1979
Political parties and leaders: political parties not yet
legally recognized; traditionally no political parties but only
partisans for particular independent candidates for the
General Council, on the basis of competence, personality,
and orientation toward Spain or France; various small
pressure groups developed in 1972; first formal political
party — Andorran Democratic Association — formed in No-
vember 1976; as of March 1980, newly formed Partit
Democrata Andorra, which had applied for legal status,
must await final approval of a new law covering associations
Communists: negligible
Member of: UNESCO
Official name: People''s Republic of Angola
Type: republic; achieved independence from Portugal in
November 1975; constitution promulgated 1975; govern-
ment formed after civil war which ended in early 1976
Capital: Luanda
Political subdivisions: 17 provinces including the coastal
exclave of Cabinda
Legal system: formerly based on Portuguese civil law
system and customary law; being modified along "socialist"
model
National holiday: Independence Day, 11 November
6
ANGOLA (Continued)
Branches: the official party is the supreme political
institution
Government leader: Jose Eduardo DOS SANTOS,
President
Suffrage; to be determined
Elections: none held to date
Political parties and leaders: Popular Movement for the
Liberation of Angola-Labor Party (MPLA-Labor Party), led
by dos Santos, only legal party; National Front for the
Liberation of Angola (FNLA) and National Union for the
Total Independence of Angola (UNITA), defeated in civil
war, carrying out insurgencies
Member of: FAO, G-77, GATT (de facto), ICAO, ILO,
IMCO, ITU, NAM, OAU, UN, UNESCO, UNICEF, UPU,
WHO, WMO
Monetary conversion rate: 27.6 kwanza=US$l as of
September 1981
Fiscal year: calendar year','98f2b608471b9f8eb73f9df9c0d7252273c9f78da746b4b315bb219c5aad03a5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e02dbb91b1a40fcbd047a7d0592b1e5c2a6058ab09ee5bafd226693b728b55c',1982,'AG','Antigua and Barbuda','government',25,'Official name: Antigua and Barbuda
Type: independent state since 1 November 1981; recog-
nizes Elizabeth II as Chief of State
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Bar-
buda, Redonda)
Legal system: based on English law; British Caribbean
Court of Appeal has exclusive original jurisdiction and an
appellate jurisdiction, consists of Chief Justice and five
justices
Branches: legislative, 21-member popularly elected
House of Representatives; executive, Prime Minister and
Cabinet
Government leaders: Prime Minister Vere C. BIRD, Sr.;
Deputy Prime Minister Lester BIRD; Governor Sir Wilfred
Ebenezer JACOBS
Suffrage: universal suffrage age 18 and over
Elections: every five years; last general election 24 April
1980
Political parties and leaders: Antigua Labor Party (ALP),
Vere C. Bird, Sr., Lester Bird; Progressive Labor Movement
(PLM), George Herbert Walter; Antigua People''s Party
(APP), J. Rowan Henry
Voting strength: (1980 election) House of Representatives;
ALP, 13 seats; PLM, 3 seats; independent, 1 seat
Communists: negligible
Other political or pressure groups: Antigua Caribbean
Liberation Movement (ACLM), a small leftist nationalist
group led by Timothy Hector
Member of: CARICOM, ISO','2718b56544cd34cb0e1bc93e44c496bcc3143c80f47a779dfe8e9e6690a3d852','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e77458e808ba116702e31880d12cf8c8cf07661097be2bfdca7360e275b7d296',1982,'AR','Argentina','government',29,'Official name: Argentine Republic
Type: republic; under military rule since 1976
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal
Capital), and 1 territory
Legal system: based on Spanish and French civil codes;
constitution adopted 1853 partially superseded in 1966 by
the Statute of the Revolution, which takes precedence over
the constitution when the two are in conflict; further
changes may be made by new government; judicial review
of legislative acts; legal education at University of Buenos
Aires and other public and private universities; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 25 May
Branches: presidency; national judiciary
Government leader: President, Lt. Gen. Leopoldo For-
tunato GALTIERI, chosen in December 1981 by the mili-
tary junta that took power on 24 March 1976
Government structure: the President and the junta, com-
posed of the chiefs of the three armed services, retain
supreme authority; active duty or retired officers fill three
Cabinet posts and administer all provincial and many local
governments; in addition, the military now oversees the
nation''s principal labor confederation and unions, as well as
other civilian pressure groups; Congress has been disbanded
and all political activity suspended; a five-man Legislative
Council, composed of senior officers, advises the junta on
lawmaking
Political parties: several civilian political groupings re-
main potentially influential, despite the suspension of all
partisan activity; these include Justicialist Party (Peronist
coalition that formerly governed) and the Radical Civic
Union, center-left party providing the chief civilian opposi-
tion to the Peronists; the Moscow-oriented Communist Party
remains legal, but extreme leftist splinter groups have been
outlawed
Communists: some 70,000 members in various party
organizations, including a small nucleus of activists
Other political or pressure groups: Peronist-dominated
labor movement, General Economic Confederation (Peronist-
leaning association of small businessmen), Argentine Indus-
trial Union (manufacturers* association), Argentine Rural
Society (large landowners* association), business organiza-
tions, students, and the Catholic Church
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
IFAD, ICAC, 1CAO, IDA, IDB, 1FC, 1HO, ILO, 1MCO,
IMF, IOOC, ISO, ITU, IWC— International Whaling Com-
mission, 1WC — International Wheat Council, LAFTA,
NAM, OAS, SELA, UN, UNESCO, UPU, WHO, WMO,
WTO, WSG
Official name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to
capital
Legal system: English common law
Branches: Governor, Executive Council, Legislative
Council
1 The possession of the Falkland Islands has been disputed by the
UK and Argentina (which refers to them as the Islas Malvinas) since
1833. On I April 1982 Argentine military forces invaded the islands.
The British responded by sending warships to the South Atlantic.
68','17eb3351aceed0e6e3f68e7c9abf8afe23688808ffac2c8fdb605f362b14e06b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce6b60197c52cdda3245d23543725ab8fcc53bbbb8d879500793c20cf1d82b3c',1982,'AU','Australia','government',34,'Official name: Commonwealth of Australia
Type: federal parliamentary state recognizing Elizabeth 11
as sovereign or head of state
Capital: Canberra
Political subdivisions: 6 states and 2 territories — Austra-
lian Capital Territory (Canberra) and Northern Territory
Legal system: based on English common law; constitution
adopted 1900; High Court has jurisdiction over cases involv-
ing interpretation of the constitution; accepts compulsory
ICJ jurisdiction, with reservations
National holiday: 26 January
Branches: Parliament (House of Representatives and Sen-
ate); Prime Minister and Cabinet responsible to House;
independent judiciary
If
AUSTRALIA (Continued)
Government leaders: Governor General Sir Zelman
COWEN; Prime Minister J. Malcolm FRASER
Suffrage: universal over age 18
Elections: held at three-year intervals or sooner if Parlia-
ment is dissolved by Prime Minister; last election October
1980
Political parties and leaders: government — Liberal Party
(Malcolm Fraser) and National Country Party (Douglas
Anthony); opposition — Labor Party (William J. Hayden)
Voting strength (1980 parliamentary election): lower
house — Liberal-Country coalition, 74 seats; Labor Party, 51
seats; Senate — Liberal-Country coalition, 31 seats; Labor, 27
seats; Australian Democrats, 5 seats; Independents, 1 seat
Communists: 5,000 members (est.)
Other political or pressure groups: Democratic Labor
Party (anti-Communist Labor Party splinter group)
Member of: ADB, AIOEC, ANZUS, CIPEC (associate),
Colombo Plan, Commonwealth, DAC, ELDO, ESCAP,
FAO, GATT, IAEA, IATP, IBA, IBRD, ICAC, ICAO, ICO,
IDA, IEA, IFAD, IFC, IHO, ILO, International Lead and
Zinc Study Group, 1MCO, IMF, IOOC, IPU, ISO, ITC, ITU,
IWC — International Whaling Commission, IWC — Interna-
tional Wheat Council, OECD, UN, UNESCO, UPU, WHO,
WIPO, WMO, WSG
Official name: Fiji
Type: independent parliamentary state within Common-
wealth; Elizabeth II recognized as chief of state
Capital: Suva located on the south coast of the island of
Viti Levu
70
FIJI (Continued)
Political subdivisions: 14 provinces
Legal system: based on British
National holiday: 10 October
Branches: executive — Prime Minister; legislative —
52-member House of Representatives (Alliance Party 36
seats, National Federation Party 15 seats, 1 independent);
22-member appointed Senate; judicial — Supreme Court
Government leader: Prime Minister Ratu Sir Kamisese
MARA
Suffrage: universal adult
Elections: every five years unless House dissolves earlier,
last held September 1977
Political parties: Alliance, primarily Fijian, headed by
Ratu Mara; National Federation, primarily Indian, headed
by Jai Ram Reddy
Communists: few, no figures available
Member of: ADB, Colombo Plan, Commonwealth, EEC
(associate), FAO, G-77, GATT (de facto), IBRD, 1CAO, IDA,
IFAD, IFC, ILO, IMF, ISO, ITU, UN, UPU, WHO, W1PO,
WMO','b186d3629432e2cd9de8b571fdbf2a3902514f0a1618e44107f6c20e257c2d09','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ae68d5e5c425d3d015da97bdadacdef4e3f7bccdf37c3cc9a24742657d9fdcf',1982,'AT','Austria','government',37,'Official name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the
capital
Legal system: civil law system with Roman law origin;
constitution adopted 1920, repromulgated in 1945; judicial
review of legislative acts by a Constitutional Court; separate
administrative and civil/penal supreme courts; legal educa-
tion at Universities of Vienna, Graz, Innsbruck, Salzburg,
and Linz; has not accepted compulsory ICJ jurisdiction
National holiday: 26 October
Branches: bicameral parliament, directly elected Presi-
dent whose functions are largely representational, independ-
ent federal judiciary
Government leaders: President Rudolf KIRCH-
SCH LAGER; Chancellor Bruno KREISKY leads a one-party
Socialist government
Suffrage: universal over age 19; compulsory for presiden-
tial elections
Elections: presidential, every six years (next 1986); parlia-
mentary, every four years (next 1983)
Political parties and leaders: Socialist Party of Austria
(SPOe), Bruno Kreisky, Chairman; Austrian People''s Party
(OeVP), Alois Mock, Chairman; Liberal Party (FPOe), Nor-
bert Steger, Chairman; Communist Party, Franz Muhri,
Chairman
Voting strength (1979 election): 51.0% SPOe, 41.9%
OeVP, 6.1% FPOe, 1.0% Communist
Communists: membership 25,000 est.; activists 7,000-
8,000
Other political or pressure groups: Federal Chamber of
Commerce and Industry; Austrian Trade Union Federation
(primarily Socialist); three composite leagues of the Austrian
Peoples Party (OeVP) representing business, labor, and
farmers; the OeVP-oriented League of Austrian Industrial-
ists; Roman Catholic Church, including its chief lay organi-
zation, Catholic Action
Member of: ADB, Council of Europe, DAC, ECE, EFTA,
EMA, ESRO (observer), FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFAD, IFC, ILO, International Lead and
Zinc Study Group, 1MCO, IMF, ITU, IWC— International
Wheat Council, OECD, UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO, WSG
Official name: The Commonwealth of The Bahamas
Type: independent commonwealth since July 1973, recog-
nizing Elizabeth II as Chief of State
Capital: Nassau (New Providence Island)
Legal system: based on English law
National holiday: Independence Day, 10 July
Branches: bicameral legislature (appointed Senate, elect-
ed House); executive (Prime Minister and Cabinet); judiciary
Government leaders: Prime Minister Lynden O. P1ND-
LING; Governor General Gerald C. CASH
Suffrage: universal over age 18; registered voters (July
1977) 73,309
Elections: House of Assembly (19 July 1977); next election
due constitutionally in five years
13','414abd7a5732d238992cca2c051d210f070d48e6cb37138bb0edfbbacb3b8353','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5edb07aae8210f32495588502829e8eb3022c1173abe9f9c2447b90d348a803a',1982,'BH','Bahrain','government',39,'THE BAHAMAS (Continued)
Political parties and leaders: Progressive Liberal Party
(PLP), predominantly black, Lynden O. Pindling; Bahamian
Democratic Party (BDP), Henry Bostwick; Free National
Movement (FNM), Cecil Wallace-Whitfield; Social Demo-
cratic Party (SDP), Norman Solomon
Voting strength (1977 election): PLP (55%) 30 seats, BDP
(27%) 6 seats, FNM (15%) 2 seats, others (3%) 0 seats
Communists: none known
Member of: CDB, G-77, GATT (de facto), IBRD, ICAO,
IDB, ILO, IMCO, IMF, ITU, UN, UPO, WHO, WIPO,
WMO, WTO
Official name: State of Bahrain
Type: traditional monarchy; independence declared in
1971
Capital: Manama
Legal system: based on Islamic law and English common
law; constitution went into effect December 1973
National holiday: 16 December
Branches: Amir rules with help of a Cabinet led by Prime
Minister; Amir dissolved the National Assembly in August
1975 and suspended the constitutional provision for election
of the Assembly; independent judiciary
Government leader: Amir ''Isa bin Salman Al KHALIFA
Political parties and pressure groups: political parties
prohibited; several small, clandestine leftist and Shia Funda-
mentalist groups are active
14','a1fab2e86e2cc366678302c2217889e688bdd6fd43005a3b26d8aee0863d3fdf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f9c87724c6562ba7e30cc4e08cba9b0beb9b1c4b2156533e3c579a3d646b5e6',1982,'BD','Bangladesh','government',43,'BAHRAIN (Continued)
Communists: negligible
Member of: Arab League, FAO, G-77, GATT (de facto),
GCC, IBRD, ICAO, ILO, IMCO, IMF, ISCON, ITU, NAM,
OAPEC, UN, UNESCO, UPU, WHO','407d9a7d64209fdbcb2776fa9bce23d2bcfed0a0624d460c8d139c90c85a1b91','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c34f5a33dd5ce677257151c950d8773844aa3638043be72c97d73f60b0b54d6c',1982,'CN','China','government',48,'Official name: Peopled Republic of Bangladesh
Type: independent republic since December 1971; Gov-
ernment of President Sheikh Mujibur Rahman overthrown
in August 1975; two other coups followed; after four years of
martial law rule, presidential elections were held in June
1978 and a new parliament was elected in February 1979;
President Ziaur Rahman assassinated in failed military coup
on 30 May 1981; former Vice President Justice Abdus Sattar
became President in election on 15 November 1981; martial
law imposed 24 March 1982; government dissolved
Capital: Dacca
15
BANGLADESH (Continued)
Political subdivisions: 19 districts, 413 thanas (counties),
4,365 unions (village groupings)
Legal system: based on English common law; constitution
adopted December 1972; amended January 1975 to more
authoritarian presidential system, changed by proclamation
in April 1977 to reflect Islamic character of nation; further
change, by proclamation in December 1978, to provide for
the appointments of the Prime Minister and the Deputy
Prime Minister, as well as other ministers of Cabinet rank,
and to further define the powers of the President
National holiday: Independence Day, 26 March
Branches: constitution provides for unicameral legisla-
ture, strong President; independent judiciary; President has
substantial control over the judiciary
Government leader: President Abdus Sattar replaced by
martial law administrator Lt. Gen. H. M. ERSHAD in
March 1982 coup
Suffrage: universal over age 18
Elections: Second Parliament (House of the Nation) elect-
ed in February 1979; elections every five years; most recent
presidential election November 1981
Political parties and leaders: Bangladesh Nationalist
Party (formed September 1978), Abdus Sattar; Awami
League, Sheikh Hasina Wajed; United People''s Party, Kazi
Zafar Ahmed; Democratic League, Khondakar Mushtaque
Ahmed; Muslim League, Khan A. Sabur; Jatiya Samajtantrik
Dal (National Socialist Party), M. A. Jalil; Bangladesh Com-
munist Party (pro- Soviet), Manindra Moni Singh; numerous
small parties; political activity banned following March 1982
coup
Communists: 2,500 members (est.)
Member of: ADB, Afro-Asian People''s Solidarity Organi-
zation, Colombo Plan, Commonwealth, ESCAP, FAO, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF,
IMCO, ISCON, ITU, NAM, UN, UNCTAD, UNESCO,
UPU, WHO, WMO, WTO
Official name: People''s Republic of China
Type: Communist state; real authority lies with Commu-
nist Party''s Political Bureau; the National People''s Congress,
in theory the highest organ of government, usually ratifies
the party''s programs; the State Council actually directs the
Capital: Beijing (Peking)
Political subdivisions: 21 provinces, 3 centrally governed
municipalities, and 5 autonomous regions
Legal system: before 1966, a complex amalgam of custom
and statute, largely criminal; little ostensible development of
uniform code of administrative and civil law; highest judicial
organ is Supreme People''s Court, which reviews lower court
decisions; laws and legal procedure subordinate to priorities
of party policy; whole system largely suspended during
Cultural Revolution but has been revived as part of the
current regime''s efforts to rationalize the state and to
reintroduce socialist legality; regime has attempted to write
civil and Communist codes; new legal codes in effect 1
January 1980
National holiday: National Day, 1 October
Branches: before 1966 control was exercised by Chinese
Communist Party, through State Council, which supervised
more than 60 ministries, commissions, bureaus, etc., all
technically under the Standing Committee of the National
People''s Congress; this system broke down under Cultural
Revolution pressures but has been largely restored
Government leader: Premier of State Council ZHAO
Ziyang; head of state, Chairman of NPC Standing Commit-
tee, YE Jianying; government subordinate to Central Com-
mittee of CCP
Suffrage: universal over age 18
Elections: elections held for People''s Congress representa-
tives at county level
Political parties and leaders: Chinese Communist Party
(CCP), headed by Hu Yaobang; Hu is Chairman of Central
Committee and was elected at the party''s 6th plenum in
June 1981; Central Committee was formed at the 11th Party
Congress, held in August 1977
Communists: about 39 million party members in 1981
Other political or pressure groups: the People''s Liber-
ation Army (PLA) remains a major force, although many
military officers who acquired a wide range of civil political-
administrative duties during the Cultural Revolution have
been either returned to primarily military positions or
removed; many veteran civilian officials, in eclipse since the
Cultural Revolution, have been reinstated; mass organiza-
tions, such as the trade unions and the youth league, have
been rebuilt
Member of: FAO, IAEA, IBRD, 1CAO, IDA, 1FAD, 1FC,
IHO, ILO, 1MCO, IMF, ITU, Red Cross, UN, UNESCO,
UPU, WHO, WIPO, WMO, other international bodies
Official name: Macau
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macau, and two
islands
Legal system: Portuguese civil law system
Branches: 18-member Legislative Assembly, with Gover-
nor and 5 appointed, 6 nominated, and 6 elected
representatives
Government leader: Governor Cdr. Vasco Fernando
Lecte da Almeida e COSTA
Suffrage: Portuguese, Chinese, and foreign residents over 18
Elections: conducted every four years
Political parties and leaders: Association to Defend the
Interests of Macau; Macau Democratic Center; Group to
Study the Development of Macau; Macau Independent
Group
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese
and Chinese representing local interests, wealthy pro-
Communist merchants representing China''s interests; in
January 1967 Macau Government acceded to Chinese de-
mands which gave Chinese veto power over administration
of the enclave
Official name: Socialist Republic of Vietnam
Type: Communist state
Capital: Hanoi
Political subdivisions: 39 provinces
Legal system: based on Communist legal theory and
French civil law system
National holiday: 2 September
Branches: constitution provides for a National Assembly
and highly centralized executive nominally subordinate to it
Party and government leaders: LE DUAN, Party Secre-
tary General; NGUYEN HUU THO, Chairman, National
Assembly; TRUONG CHINH, Chairman, Council of State;
PHAM VAN DONG, Chairman, Council of Ministers; Gen.
VAN TIEN DUNG, Minister of National Defense;
NGUYEN CO THACH, Minister for Foreign Affairs;
PHAM HUNG, Minister of Interior
Suffrage: over age 18
Elections: pro forma elections held for national and local
assemblies; latest election for National Assembly held on 25
April 1976
Political parties: Vietnam Communist Party, formerly
known as the Vietnam Workers Party
Communists: probably more than 1 million
Member of: ADB, CEMA, Colombo Plan, ESCAP, FAO,
G-77, IAEA, IBRD, 1CAO, IDA, IFAD, IFC, ILO, IMF,
ITU, Mekong Committee, NAM, UN, UNDP, UNESCO,
UNICEF, UPU, WHO, WIPO, WMO, WTO','c16a0dc113f614629588695978fa23187049945757dafc0afe4d7db8395bf152','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5df5dc0b9db13a1386669931c72770068ca464fd293730562783c8086cd304e2',1982,'BB','Barbados','government',52,'Official name: Barbados
Type: independent sovereign state within the Common-
wealth since November 1966, recognizing Elizabeth II as
Chief of State
Capital: Bridgetown
Political subdivisions: 11 parishes and city of Bridgetown
Legal system: English common law; constitution came
into effect upon independence in 1966; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 30 November
Branches: legislature consisting of a 2I-member ap-
pointed Senate and a 27-member elected House of Assem-
bly; Cabinet headed by Prime Minister
Government leaders: Prime Minister J. M. G. "Tom"
ADAMS; Governor General Sir Deighton H. L. WARD
Suffrage: universal over age 18
Elections: House of Assembly members have terms no
longer than five years; last general election held 18 June 1981
Political parties and leaders: Barbados Labor Party
(BLP), J. M. G. "Tom" Adams; Democratic Labor Party
(DLP), Errol Barrow
Voting strength (1981 election): Barbados Labor Party
(BLP), 52.4%; Democratic Labor Party, 46.8%; Independent,
negligible; House of Assembly seats — BLP 17, DLP 10
Communists: negligible
Other political or pressure groups: Movement for Na-
tional Liberation (MONALI), a small leftist group led by
Bobby Clarke
Member of: CAR1COM, Commonwealth, FAO, G-77,
GATT, IADB, IBRD, 1CAO, IDB, 1FAD, 1FC, ILO, 1MCO,
IMF, ISO, ITU, IWC— International Wheat Council, OAS,
SELA, UN, UNESCO, UPU, WHO, WMO','5fc76a21377786cf5f173e8e5c4d9edf9cd9837fab79ad032b1592ee7dec7377','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dda5073a5fcfd6d39ae95f920ab8966c84ec06b974d2312a43f8dc1b19369ff2',1982,'BE','Belgium','government',56,'Official name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: nine provinces; as of 1 October
1980, Wallonia and Flanders have regional "subgovern-
ments" with elected regional councils and executive officials;
those regional authorities will have limited powers over
revenues and certain areas of economic, urban, environmen-
tal, and housing policy; the authority of the regional sub-
governments will increase over a five-year period; Wallonia
also has a separate Walloon Cultural Council
Legal system: civil law system influenced by English
constitutional theory; constitution adopted 1831, since
amended; judicial review of legislative acts; legal education
at four law schools; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: National Day, 21 July
Branches: executive branch consists of King and Cabinet;
Cabinet responsible to bicameral parliament; independent
judiciary; coalition governments are usual
Government leaders: Head of State, King BAUDOUIN I;
Prime Minister Wilfried MARTENS
Suffrage: universal over age 18 (as of 1981)
Elections: held 8 November 1981 (held at least once every
4 years)
Political parties and leaders: Flemish Social Christian,
Frank Swaelen, president; Francophone Social Christian,
Gerard Desprez, president; Flemish Socialist, Karel Van
Miert, president; Francophone Socialist, Guy Spitaels, presi-
dent; Flemish Liberal, Guy Verhofstadt, president; Franco-
phone Liberals, Louis Michel, president; Francophone
Democratic Front, Antoinette Spaak, president; Volksunie
(Flemish Nationalist), Vic Anciaux, president; Communist,
Louis Van Geyt, president; Walloon Rally, Henri Mordant
Voting strength (1981 election): 61 seats Social Christian,
61 seats Socialist, 52 seats Liberal, 20 seats Volksunie, 8 seats
Francophone Democratic Front and Walloon Rally, 4 seats
Ecologist, 3 seats Anti-Tax Party (UDRT), 2 seats Commu-
nist, 1 seat Flemist Extremist
Communists: 10,000 members (est., October 1981)
Other political or pressure groups: Christian and Socialist
Trade Unions; the Federation of Belgium Industries; numer-
ous other associations representing bankers, manufacturers,
middle-class artisans, and the legal and medical professions;
various organizations represent the cultural interests of
Flanders and Wallonia, various peace groups such as Flem-
ish Action Committee Against Nuclear Weapons
Member of: ADB, Benelux, BLEU, Council of Europe,
DAC, EC, ECE, ECOSOC, ECSC, EEC, EIB, ELDO, EMA,
ESRO, EURATOM, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, ICO, ICES, IDA, IEA, IFAD, IFC, ILO, Internation-
al Lead and Zinc Study Group, IMCO, IMF, IOOC, IPU,
ITC, ITU, NATO, OAS (observer), OECD, UN, UNESCO,
UPU, WEU, WHO, WIPO, WMO, WSG','a99bccc48c4f86100445a6802f618a3efa2a5c9429b0910d358332d734944d03','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49cd7c05ca837f142a2499fab43136cdd240487d652699652b3d27fcf3460a13',1982,'BZ','Belize','government',60,'Official name: Belize
Type: became an independent state on 21 September
1981; a member of the Commonwealth
Capital: Belmopan
Legal system: English law
19
BELIZE (Continued)
Branches: 18-member elected National Assembly and
eight-member Senate (either house may choose its speaker or
president, respectively, from outside its elected member-
ship); Cabinet; judiciary
Government leaders: Prime Minister George C. PRICE;
Governor General Minita GORDON
Suffrage: universal adult (probably 21)
Elections: Parliamentary elections held November 1979
Political parties and leaders: Peoples United Party
(PUP), George Price; United Democratic Party (UDP), Theo-
dore Aranda
Voting strength (National Assembly): PUP 13 seats, UDP
5 seats
Communists: negligible
Other political or pressure groups: United Workers
Union, which is connected with PUP
Member of: CAR1COM, ISO','9a878f8a2e9eaf0239ed55503286be7a3008f4ed7aa014fd2a1036edacbfa17c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b53530b662a28fe73f292ad34281094506d4a2f3ee13ec909a5a3ad7b4997ab5',1982,'BJ','Benin','government',64,'Official name; Peoples Republic of Benin
Type: party state, under military rule since 26 October
1972; the military plans to relinquish power to a 336-
member National Assembly
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Legal system: based on French civil law and customary
law; legal education generally obtained in France; has not
accepted compulsory ICJ jurisdiction
National holiday: 30 November
Branches: National Revolutionary Assembly, National
Executive Council, Central Committee of party
Government leader: Col. Mathieu KEREKOU, President,
Chief of State, and Minister of Defense
Suffrage: universal adult
Elections: National Assembly elections were held in No-
vember 1979; Assembly then formally elected Kerekou
President in February 1980
Political parties: Peopled Revolutionary Party of Benin
(PRPB) established in 1975
Communists: sole party espouses Marxism-Leninism
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS,
Entente, FAO, G-77, GATT, IBRD, ICAO, ICO, IDA,
IFAD, ILO, IMCO, IMF, ITU, NAM, Niger River Commis-
sion, OAU, OCAM, UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO','daf75f30badf08bde65228c547ecf221541ed3e45f920b7db9d3977228a56213','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17f96130ca86598c4b195eb16a7b7398d9d070a84818eafd5d66798388d149c4',1982,'BM','Bermuda','government',68,'Official name: Bermuda
Type: British colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) appointed by gov-
ernor, led by government leader; bicameral legislature with
an appointed Legislative Council and a 40-member directly
elected House of Assembly; Supreme Court
Government leaders: Governor Sir Richard POSNETT;
Premier John William David SWAN
Suffrage: universal over age 21
Elections: at least once every five years; last general
election, December 1980
22','f9ab786e67748349f7318a57840e9512d8c1278215db19aec6524f9dc70bfb08','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e83f64347e5cae93e3542dce1608863d736a8f984e10df2ae5363e5990b742d',1982,'BT','Bhutan','government',69,'BERMUDA (Continued)
Political parties and leaders: United Bermuda Party
(UBP), J- David Gibbons; Progressive Labor Party (PLP),
Lois Browne-Evans
Voting strength (1980 elections): UBP 54%, PLP 46%; the
UBP holds 22 House of Assembly seats, the PLP holds 18
seats
Communists: negligible
Other political or pressure groups: Bermuda Industrial
Union (BIU) headed by Ottiwell Simmons','5ff42d22583e2ddaec803635e8392ed0ab769c7310d951222b8dd3a1a98b8ca9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53b1daf16c201653db7f8d75db382a67b2d87f4422df661fee29f9ed5020a789',1982,'IN','India','government',74,'Official name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west,
south), further divided into 15-18 subdivisions
Legal system: based on Indian law and English common
law; in 1964 the monarch assumed full power — no constitu-
tion existed beforehand; a Supreme Court hears appeals
from district administrators; has not accepted compulsory
1CJ jurisdiction
National holiday: 17 December
Branches: appointed Ministers and indirectly elected
Assembly consisting of village elders, monastic representa-
tives, and all district and senior government administrators
23
BOLIVIA
BHUTAN (Continued)
Government leader: King Jigme Singye WANGCHUCK
Suffrage: each family has one vote
Elections: popular elections on village level held every
three years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, G-77, IBRD, IFAD, IMF,
NAM, UPU, UN
Official name: Republic of Bolivia
Type: republic; military dictatorship since 17 July 1980
Capital: La Paz (seat of government); Sucre (legal capital
and seat of judiciary)
Political subdivisions: nine departments with limited
autonomy
Legal system: based on Spanish law and Code Napoleon;
constitution adopted 1967; constitution in force except
where contrary to dispositions dictated by governments since
1969; legal education at University of San Andres and
several others; has not accepted compulsory 1CJ jurisdiction
National holiday: Independence Day, 6 August
24
BOLIVIA (Continued)
Branches: executive; congress of two chambers — Senate
and Chamber of Deputies — has not met since the 17 July
1980 coup; judiciary
Government leaders: Maj. Gen. Celso TORRELIO Villa
(since 4 September 1981)
Suffrage: universal and compulsory at age 18 if married,
21 if single
Elections: presidential and congressional elections held on
1 July 1979; since no presidential candidate won required
simple majority, the contest was decided in the Congress
where a compromise candidate, Senate President Walter
Guevara Arce, was elected interim president; Guevara was
overthrown on 1 November 1979 by a military coup led by
Col. Alberto Natusch Busch; popular repudiation of Natusch
forced his resignation after 16 days in power and Congress
chose Chamber of Deputies President Lidia Gueiler de
Moller as interim president; Gueiler presided over new
elections on 29 June 1980, which were won by the UDP
coalition candidate, Hernan Siles Zuazo; however, before the
planned August inauguration, the government was over-
thrown when a military coup led by Gen. Luis Garcia Meza
occurred on 17 July 1980; Garcia Meza was replaced in
August 1981 by a ruling junta of service commanders, which
in turn was replaced on 4 September 1981 by Maj. Gen.
Celso Torrelio Villa
Political parties and leaders: ban on political parties was
lifted in December 1977; however, all political party activity
banned since the 17 July 1980 coup; the two traditional
political parties in Bolivia are the Nationalist Revolutionary
Movement (MNR) and the Bolivian Socialist Phalange (FSB),
both are seriously factionalized; Bolivian Socialist Falange
(Mario Gutierrez); Nationalist Revolutionary Movement of
the People (Jaime Arellano); Nationalist Revolutionary
Movement of Left (MNR1; Herndn Siles Zuazo); Movement
of the Revolutionary Left (MIR; Jaime Paz Zamora); Authen-
tic Revolutionary Party (Walter Guevara Arce); Christian
Democratic Party (Benjamin Miguel); Nationalist Revolu-
tionary Party of Left (Juan Lechin Oquendo); Paz Estenssor-
ista MNR (Leonidas Sanchez); Nationalist Democratic Action
Party (ADN; Hugo Banzer)
Voting strength (1980 elections): UDP — Democratic Pop-
ular Unity Front, a coalition of the MNR1, MIR and several
smaller groups 38.5%; MNR 20.5%; ADN 16.8%
Communists: three parties; PCB/Soviet led by Jorge Kolle
Cueto, about 300 members; PCB/Chinese led by Oscar
Zamora, 150 (including 100 in exile); POR (Trotskyist), about
50 members divided between three factions led by Hugo
Gonzalez Moscoso, Guillermo Lora Escobar, and Amadeo
Arze
Member of: FAO, G-77, 1ADB, IAEA, IATP, IBRD,
1CAO, ICO, IDA, 1DB, 1FAD, 1FC, ILO, IMF, ISO, 1TC,
ITU, IWC— International Wheat Council, LAFTA and An-
dean Sub-Regional Group (created in May 1969 within
LAFTA), NAM, OAS, SELA, UN, UNESCO, UPO, WHO,
WMO, WTO
Official name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union territories
Legal system: based on English common law; constitution
adopted 1950; limited judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: anniversary of the Proclamation of the
Republic, 26 January
Branches: parliamentary government, national and state;
relatively independent judiciary
Government leader: Prime Minister Indira GANDHI
Suffrage: universal over age 21
Elections: national and state elections ordinarily held every
five years; may be postponed in emergency and may be held
more frequently if government loses confidence vote; last
general election in January 1980; state elections staggered
Political parties and leaders: Indian National Congress,
controlled national government from independence to
March 1977, and split in January 1978; larger Congress
group is headed by Prime Minister Indira Gandhi; the
smaller Congress group is headed by Sharad Pawar; Janata
Party led by Chandra Shekhar; Lok Dal Party by Charan
Singh; Bharatiya Janata Party by A. B. Vajpayee; Commu-
nist Party of India (CPI), C. Rajeswara Rao, general secre-
tary; Communist Party of India/Marxist (CPI/M), E. M. S.
Namboodiripad, general secretary; Communist Party of
India/Marxist- Leninist (CPI/ML), Satyanarayan Singh, gen-
eral secretary; All-India Anna Dravida Munnetra Kazhagam
(ADMK), a regional party in Tamil Nadu led by M. G.
Ramachandran; Akali Dal representing Sikh religious com-
munity in the Punjab
Communists: 470,000 members claimed by CPI, 270,000
members claimed by CPI/M; Communist extremist groups,
about 15,000 members
Other political or pressure groups: various separatist
groups seeking reorganization of states; numerous "senas" or
militant/chauvinistic organizations, including Shiv Sena in
Bombay, the Anand Marg, and the Rashtriya Swayamserak
Sangh
Member of: ADB, AIOEC, Colombo Plan, Common-
wealth, FAO, G-77, GATT, IAEA, IBRD, ICAC, ICAO,
ICO, IDA, IFAD, IFC, IHO, ILO, International Lead and
Zinc Study Group, IMCO, IMF, IPU, ITC, ITU, IWC—
International Wheat Council, NAM, UN, UNESCO, UPU,
WHO, WIPO, WMO, WSG, WTO
Official name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; military seized
power 5 July 1977 and temporarily suspended some constitu-
tional provisions
Capital: Islamabad
Political subdivisions: four provinces — Punjab, Sind, Ba-
luchistan, and North- West Frontier — with the capital terri-
tory of Islamabad and certain tribal areas centrally adminis-
tered; Pakistan claims that Azad Kashmir is independent
pending a settlement of the dispute with India, but it is in
fact under Pakistani control
180
PAKISTAN (Continued)
Legal system: based on English common law; accepts
compulsory ICJ jurisdiction, with reservations; President
Zias government has established Islamic Shariat courts
paralleling the secular courts and has introduced Koranic
punishments for criminal offenses
National holiday: Pakistan Day, 23 March
Government leader: President and Chief Martial Law
Administrator Gen. Mohammad ZIA-UL-HAQ
Suffrage: universal from age 18
Elections: opposition agitation against rigging elections in
March 1977 led to military coup; military promised to hold
new national and provincial assembly elections in October
1977 but postponed them; in 1979 elections were postponed
indefinitely
Political parties and leaders: Pakistan People''s Party
(PPP), pro-Bhutto wing, Mrs. Z. A. Bhutto, moderate wing,
Ghulam Mustapha Jatoi; Tehrik-i-Istiqlal, Asghar Khan;
National Democratic Party (NDP), Sherbaz Mazari (formed
in 1975 by members of outlawed National Awami Party —
NAP— of Abdul Wali Khan, who is de facto NDP leader);
the above two are the main groups in the Movement for
Restoration of Democracy (MRD), formed in February 1981;
Pakistan National Party (PNP), Ghaus Bakhsh Bizenjo (Ba-
luch elements of the former NAP); Jamiat-ul-Ulema-i-
Pakistan (JUP), Maulana Shah Ahmed Noorani; Pakistan
National Alliance (PNA), a disintegrating coalition of six
parties including Pakistan Muslim League (PML) — Pir of
Pagaro group; Jamaat-i-Islami (Jl), Tofail Mohammed;
Jamiat-ul-Ulema-i-Islam (JUI), Fazlur Rahman
Communists: party membership very small; sympathizers
estimated at several thousand
Other political or pressure groups: military remains
strong political force
Member of: ADB, Colombo Plan, FAO, G-77, GATT,
IAEA, IBRD, ICAC, 1CAO, IDA, 1FAD, IFC, 1HO, 1LO,
IMCO, IMF, ISCON, ITU, IWC— International Wheat
Council, NAM, RCD, UN, UNESCO, UPU, WHO, W1PO,
WMO, WSG, WTO','c09197b6514c220330ed11f7d2542545ffc127843b90bb52f3680156a4c15342','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dac662cd5706a39aa71cbda0e2fd70844ef909c0f8234d990858900bf728fcd',1982,'BW','Botswana','government',78,'Official name: Republic of Botswana
Type: parliamentary republic; independent member of
Commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and local
customary law; constitution came into effect 1966; judicial
review limited to matters of interpretation; legal education
at University of Botswana and Swaziland (two and one-half
years) and University of Edinburgh (two years); has not
accepted compulsory ICJ jurisdiction
National holiday: 30 September
Branches: executive — President appoints and presides
over the Cabinet, which is responsible to Legislative Assem-
bly; legislative — Legislative Assembly with 32 popularly
elected members and four members elected by the 32
representatives, House of Chiefs with deliberative powers
only; judicial — local courts administer customary law, High
Court and subordinate courts have criminal jurisdiction over
all residents, Court of Appeal has appellate jurisdiction
Government leaders: President Dr. Qiiett K. J. MASIRE;
Vice President Lenyeletse M. SERETSE
Suffrage: universal, age 21 and over
Elections: general elections held 20 October 1979
Political parties and leaders: Botswana Democratic Party
(BDP), Quett Masire; Botswana National Front (BNF), Ken-
neth Koma; Botswana People''s Party (BPP); Botswana Inde-
pendence Party (BIP), Motsamai Mpho
Voting strength: (October 1979 election) BDP (29 seats);
BPP (1 seat); BNF (2 seats); BIP (no seats)
Communists: no known Communist organization; Koma
of BNF has long history of Communist contacts
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, ITU,
NAM, OAU, UN, UNESCO, UPU, WHO, WMO','956ceb898b4a78a7d3788689e133f5b672169d1ec130d4fc56b61432b9aa7c8d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0337fff0c3208afa8b757600a91a47b219df1689d8b5599d8052f4ad68f7a4bb',1982,'BR','Brazil','government',83,'Official name: Federative Republic of Brazil
Type: federal republic; military-backed presidential re-
gime since April 1964
Capital: Brasilia
Political subdivisions: 23 states, 3 territories, federal
district (Brasilia)
Legal system: based on Latin codes; dual system of courts,
state and federal; constitution adopted 1967 and extensively
amended in 1969; has not accepted compulsory 1CJ
jurisdiction
National holiday: Independence Day, 7 September
27
BRAZIL (Continued)
Branches: strong executive with very broad powers; bi-
cameral legislature (powers of the two bodies have been
sharply reduced); 11-man Supreme Court
Government leader; President Gen. (Ret.) Joao Baptista
de Oliveira FIGUEIREDO
Suffrage: compulsory over age 18, except illiterates; ap-
proximately 50 million eligible to register in mid-1982
Elections: Figueiredo, who took office on 15 March 1979,
was elected by an electoral college, composed of the mem-
bers of Congress and delegates selected from the state
legislatures on 15 October 1978; next presidential election
1984
Voting strength: (November 1974 congressional elections)
33.6% ARENA, 31.9% MDB, 35.5% blank and void
Political parties and leaders: Social Democratic Party
(PDS), progovemment, Jose Sarney, president; Brazilian
Democratic Movement Party (PMDB), Ulysses Guimaraes,
president; plus several smaller parties
Communists: 6,000, less than 1,000 militants
Other political or pressure groups: the Catholic Church,
over the years, has been a consistent critic of the regime;
labor unions, at least as far as wage demands, have become
highly active
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB, IFAD, IFC, IHO, ILO,
IMCO, IMF, IPU, ISO, ITU, IWC— International Wheat
Council, LAFTA, OAS, SELA, UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO
Official name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: four administrative districts
Legal system: based on Islamic law; constitution promul-
gated by the Sultan in 1959
Branches: Chief of State is Sultan (advised by appointed
Privy Council) who appoints Executive Council and Legisla-
tive Council
Government leader: Sultan Hassanal BOLKIAH
Suffrage: universal age 21 and over; three-tiered system
of indirect elections; popular vote cast for lowest level
(district councilors)
Elections: last elections — March 1965; further elections
postponed indefinitely
Political parties and leaders: antigovernment, exiled
Brunei People''s Party, Chairman A. M. N. Azahari
Communists: information not available','92caa4f7f1e57ad37588e71fab9332cd5f07ce74bb6d687e11ca5f023833fc5c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc86855debd9c5bc0dd83da9e8af59acb137d9eb59f7ddb901876377e8e70c4d',1982,'BG','Bulgaria','government',86,'Official name: People s Republic of Bulgaria
Type: Communist state
Capital: Sofia
Political subdivisions: 28 okrugs (districts), including
capital city of Sofia
Legal system: based on civil law system, with Soviet law
influence; new constitution adopted in 1971; judicial review
of legislative acts in the State Council; legal education at
University of Sofia; has accepted compulsory ICJ jurisdiction
National holiday: National Liberation Day, 9 September
Branches: legislative, National Assembly; judiciary, Su-
preme Court
Government leaders: Todor ZHIVKOV, Chairman, State
Council (President and Chief of State); Georgi Stanchev
FILIPOV, Chairman, Council of Ministers (Premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every five years for National
Assembly; last elections held on 7 June 1981; 99.96% of the
electorate voted
Political parties and leaders: Bulgarian Communist Par-
ty, Todor Zhivkov, General Secretary; Bulgarian National
Agrarian Union, a puppet party, Petur Tanchev, secretary of
Permanent Board
Communists: 820,000 party members (April 1981)
Mass organizations and front groups: Fatherland Front,
Dimitrov Communist Youth League, Central Council of
Trade Unions, National Committee for Defense of Peace,
Union of Fighters Against Fascism and Capitalism, Commit-
tee of Bulgarian Women, All-National Committee for
Bulgarian-Soviet Friendship
Member of: CEMA, FAO, IAEA, ICAO, 1LO, Interna-
tional Lead and Zinc Study Group, IMCO, IPU, ITC, ITU,
1WC— International Wheat Council, UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO; Warsaw Pact, International
Organization of Journalists, International Medical Associ-
ation, International Radio and Television Organization
Official name: Socialist Republic of the Union of Burma
Type: republic under 1974 constitution
Capital: Rangoon
Political subdivisions: seven divisions and seven constitu-
ent states; subdivided into townships, villages, and wards
Legal system: People s Justice system and People''s Courts
instituted under 1974 constitution; legal education at Uni-
versities of Rangoon and Mandalay; has not accepted com-
pulsory ICJ jurisdiction
National holiday: Independence Day, 4 January
BURMA (Continued)
Branches: State Council rules through a Council of Minis-
ters; People''s Assembly has legislative power
Government leader; Chairman of State Council and
President Gen. U SAN YU
Suffrage: universal over age 18
Elections: People''s Assembly and local People''s Councils
elected in 1978
Political parties and leaders: government-sponsored
Burma Socialist Program Party only legal party; U Ne Win,
party chairman
Communists: estimated between 12,000 and 14,000
Other political or pressure groups: Kachin Independence
Army; Karen Nationalist Union, several Shan factions
Member of: ADB, Colombo Plan, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO, IMF,
ITU, UN, UNESCO, UPU, WHO, WMO','17544f865841aecdc15b4d41baf76947aca56b7ee2c45cdf8c8ee4d4acaf5c33','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69f23e4aff0714d1b9fbf463a78ae12ca33db92264036f849459ac436119ebf0',1982,'BI','Burundi','government',90,'Official name: Republic of Burundi
Type: republic; presidential system; military leaders hold
key positions; previous military government overthrown in
military coup in 1976
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18
arrondissements and 78 communes
Legal system: based on German and French civil codes
and customary law; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 1 July
Branches: executive (President and Cabinet offices); judi-
cial; National Assembly to be convened in 1982
Government leader: Col. Jean-Baptiste BAGAZA, Presi-
dent and Head of State
Suffrage: universal
Elections: new constitution approved by national referen-
dum in November 1981; elections to National Assembly
planned for 1982
Political parties and leaders: National Party of Unity and
Progress (UPRONA), a Tutsi-led party, declared sole legiti-
mate party in 1966; Col. Jean-Baptiste Bagaza
Communists: no Communist party; resumed diplomatic
relations with the People''s Republic of China in October
1971 following a six-year suspension; USSR, North Korea,
and Romania also have diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, FAO, G-77, GATT,
IBRD, ICAO, ICO, IDA, IFAD, IFC, ILO, IMF, ITU, NAM,
OAU, UN, UNESCO, UPU, WHO, WIPO, WMO, WTO','52974d06b59065470d8b26ec697a82b76e113e410608207506c78ed8053b5806','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de3ffbba3ded5a2c6ead8018e9d9ed77c7f844e348f614ef633c433dd2b5a477',1982,'CM','Cameroon','government',95,'Official name: United Republic of Cameroon
Type: unitary republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 40 de-
partments, 153 arrondissements, 31 districts
34
CAMEROON (Continued)
Legal system: based on French civil law system, with
common law influence; new unitary constitution adopted
1972; judicial review in Supreme Court, when a question of
constitutionality is referred to it by the President of the
Republic; has not accepted compulsory ICJ jurisdiction
National holiday: National Day, 20 May
Branches: executive (President), legislative (National As-
sembly), and judicial (Supreme Court)
Government leader: President Ahmadou AHIDJO
Suffrage: universal over age 21
Elections: parliamentary elections held 28 May 1978;
presidential elections held April 1980
Political parties and leaders: single party, Cameroon
National Union (UNC), instituted in 1966, President Ahma-
dou Ahidjo
Communists: no Communist Party or significant number
of sympathizers
Other political or pressure groups: Cameroon People''s
Union (UPC), an illegal terrorist group now reduced to
scattered acts of banditry with its factional leaders in exile
Member of: AFBD, EAMA, ECA, E1B (associate), FAO,
G-77, GATT, IAEA, IBRD, ICAC, ICAO, ICO, IDA, IFAD,
IFC, ILO, IMCO, IMF, 1PU, ISCON, ISO, ITU, Lake Chad
Basin Commission, NAM, Niger River Commission, OAU,
UDEAC, UN, UNESCO, UPU, WHO, W1PO, WMO, WTO','51f2d5ae20b097f3ba6c4c44a8938500d176d1e3133a354c35bc1da8d1e80edf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a0e92f54393957c2bed43946555121b8457cff0db255918685702c3666fdb42',1982,'CA','Canada','government',98,'Official name: Canada
Type: federal state recognizing Elizabeth II as sovereign
Capital: Ottawa
Political subdivisions: 10 provinces and 2 territories
Legal system: based on English common law, except in
Quebec, where civil law system based on French law
prevails; constitution is British North America Act of 1867
and various amendments; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Canada Day, 1 July (official name:
Dominion Day)
Branches: federal executive power vested in Cabinet
collectively responsible to House of Commons, and headed
by Prime Minister; federal legislative authority resides in
Parliament (282 seats) consisting of Queen represented by
Governor General, Senate, and Commons; judges appointed
by Governor General on the advice of the government;
Supreme Court is highest tribunal
Government leaders: Prime Minister Pierre E. TRU-
DEAU; Governor General Edward R. SCHREYER
Suffrage: universal over age 18
Elections: legal limit of five years but in practice usually
held within four years, last election February 1980; voter
turnout, 72%
Political parties and leaders: Liberal, Pierre Trudeau;
Progressive-Conservative, Joe Clark; New Democratic, Ed-
ward Broadbent
Voting strength (1980 election): Liberal, 44%; Progressive
Conservative, 33%; New Democratic Party, 20%; Parliamen-
tary seats as of March 1982 — Liberal (146 seats), Progressive
Conservative (101 seats), New Democratic Party (32 seats),
Independent (1 seat), vacant (2 seats)
Communists: approx. 2,000
Member of: ADB, Colombo Plan, Commomwealth, DAC,
FAO, GATT, IAEA, IBRD, 1CAO, ICES, ICO, ICRC, IDA,
IDB, IEA, IFAD, IFC, IHO, 1LO, International Lead and
Zinc Study Group, IMCO, IMF, 1PU, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC — International
Wheat Council, NATO, OAS (observer), OECD, UN,
UNCTAD, UNESCO, UPU, WHO, WIPO, WMO, WSG','92f3222633fa70192ef50063187ad92599fe7c91b8be7db62cba26d7119818f6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4bf559cdbdf9179c672429026265c7384d5f7800bc7c0c7bb953e1e8c849064',1982,'MR','Mauritania','government',102,'Official name: Republic of Cape Verde
National holiday: 12 September
Type: republic; achieved independence from Portugal in
July 1975
Capital: Praia
Political subdivisions: 10 islands
Legal system: to be determined
National holiday: Independence Day, 5 July
Branches: National Assembly, 56 members; the official
party is the supreme political institution
Government leaders: President Aristides PEREIRA;
Prime Minister Pedro P1RES; Minister of Foreign Affairs
Silvino da LUZ
Suffrage: universal over age 15
37','c996faae1d8f8105f42946b323bc0ac9487c39d16c62690347d19766fa17264a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb1af807a211a63c0301f436a605502ecc6567db9d38eb0a1843fb023be7755d',1982,'CF','Central African Republic','government',103,'CAPE VERDE (Continued)
Elections: national elections held December 1980, the
first since independence
Political parties and leaders: only legal party, African
Party for Independence of Cape Verde (PAICV), led by
Aristides Pereira, Secretary General; PAICV established in
January 1981 to replace the former ruling party in both
Cape Verde and Guinea Bissau, the African Party for the
Independence of Guinea-Bissau and Cape Verde (PA1GC),
in protest of the November 1980 coup in Guinea-Bissau
Communists: a few Communists, some sympathizers
Member of: FAO, G-77, GATT (de facto), IBRD, ICAO,
IDA, I FAD, ILO, IMCO, IMF, ITU, NAM, OAU, UN,
UNESCO, UPU, WHO, WMO
Official name: Central African Republic
Type: republic, under military rule since September 1981
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French law; Constitution, which
was approved in February 1981 referendum, was suspended
after September 1981 military takeover; judiciary, Supreme
Court, court of appeals, criminal court, and numerous lower
courts
National holiday: 4 December
38
CENTRAL AFRICAN REPUBLIC (Continued)
Branches: Gen. Andre-Dieudonne Kolingba is Chief of
State and President of the Military Committee for National
Recovery, which replaced the Council of Ministers; no
legislature; separate judiciary
Government leader: Gen. Andre-Dieudonne KO-
LINGBA, Chief of State, President of the Military Commit-
tee for National Recovery, Minister of National Defense, and
Armed Forces Chief of Staff
Suffrage: universal over age 21
Elections: no scheduled presidential, legislative, or mu-
nicipal elections
Political parties and leaders: political parties were
banned in September 1981
Communists: no Communist party; small number of
Communist sympathizers
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, FAO, G-77, GATT, IBRD,
ICAO, ICO, IDA, IFAD, ILO, IMF, ITU, NAM, OAU,
OCAM, UDEAC, UN, UNESCO, UPU, WHO, WIPO,
WMO','c45c4b19972b2c70a9c33652d0291498755b918c211d7b895abc9200df23ddef','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bff07e2169dbaec417ea40d0c63c773d96648a485e983aad22297e985eadd16',1982,'TD','Chad','government',109,'Official name: Republic of Chad
Type: republic; transitional Government of National Unity
Capital: N''Djamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and
Chadian customary law; constitution adopted 1962; constitu-
tion suspended and National Assembly dissolved April 1975;
judicial review of legislative acts in theory a power of the
Supreme Court; has not accepted compulsory ICJ juris-
diction
National holiday: 13 April
Branches: presidency; Council of Ministers
Government leaders: President GOUKOUNI Weddeye;
Vice President Lt. Col KAMOUGUE Wadal Abdel Kader;
Minister of Defense Adoum TOGOI; Foreign Minister
ACYL Ahmat
Suffrage: universal
Elections: none planned pending OAU efforts to encour-
age reconciliation among Chad''s feuding factions
Political parties and leaders: political parties banned
Communists: no front organizations or underground par-
ty; probably a few Communists and some sympathizers
Other political or pressure groups: the development of a
stable government will be hampered by prolonged tribal and
regional antagonisms of the numerous factions now ruling
Chad and by insurgent forces of rebel leader Hissein Habre
Member of: AFDB, CEAO, Conference of East and
Central African States, EAMA, ECA, EEC (associate), FAO,
G-77, GATT, IBRD, ICAC, ICAO, IDA, IFAD, ILO, IMF,
ISCON, ITU, Lake Chad Basin Commission, NAM, OAU,
OCAM, UEAC, UN, UNESCO, UPU, WHO, WIPO, WMO','607fab74d8cb32753eb841fd6bb9be7e4f0e4b7a25a743f8b1e380685e79b61c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('160b621b1e10ffa9f9b70056a056d32c94bf9a9e6a73e4570d321a9b4aa6b88a',1982,'CL','Chile','government',114,'Official name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 12 regions plus one metropolitan
district, 41 provincial subdivisions
41
CHILE (Continued)
Legal system: based on Code 1857 derived from Spanish
law and subsequent codes influenced by French and Austri-
an law; current constitution came into effect in March 1981;
the constitution provides for continued direct rule until
1989, with a phased return to full civilian rule by 1997;
judicial review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University, and
several others; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 18 September
Branches: four-man Military-Police Junta, which exer-
cises constituent and legislative powers and has delegated
executive powers to President of Junta; the President has
announced a plan for transition from military to civilian rule
by 1989; Congress dissolved; civilian judiciary remains
Government leaders: President Gen. Augusto PINO-
CHET Ugarte; Junta members, Adm. Jose Toribio MERINO
Castro, Air Force Maj. Gen. Fernando MATTHEI Aubel,
Carabinero Gen. Cesar MENDOZA Dur£n, Army Lt. Gen.
Cesar BENAV1DES Escobar
Suffrage: none
Elections: prohibited by decree; all electoral registers
were destroyed in 1974
Political parties and leaders: Christian Democratic Party
(PDC), Andres Zaldivar; National Party (PN), Sergio Onofre
Jarpa; PDC and PN are officially recessed; Popular Unity
coalition parties (outlawed) — Communist Party (PCCh), Luis
Corvaldn (in exile); Socialist Party (PS), Clodomiro Almeyda
and Carlos Altamirano (both in exile); Radical Party (PR);
Christian Left (IC); United Popular Action Movement
(MAPU); Independent Popular Action (API)
Voting strength (1970 presidential election): 36.6% Pop-
ular Unity coalition, 35.3% conservative independent, 28.1%
Christian Democrat; (1973 congressional election) 44% Popu-
lar Unity coalition, 56% Democratic Confederation (PDC
and PN)
Communists: 248,000 when PCCh was legal in 1973;
active militants now estimated at about 20,000
Other political or pressure groups: organized labor;
business organizations; landowners'' associations (SNA — So-
ciedad Nacional de Agricultura); Catholic church; extreme
leftist Movement of Revolutionary Left (MIR) outlawed;
rightist Patria y Libertad (PyL) outlawed
Member of: CIPEC, ECOSOC, FAO, G-77, GATT,
IADB, IAEA, IBRD, ICAO, IDA, IDB, IFAD, IFC, IHO,
ILO, IMCO, IMF, IPU, ITU, LAFTA, OAS, SELA, UN,
UNESCO, UPU, WHO, W1PO, WMO, WSG, WTO','53bbf37c58b7637bd5b0b95acbe2af02ca204246c4b942043b85cbaec28fabb1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63029a41f36495c3775b408a4513a3ecb295f37c921d6377d78ca15e2d766f76',1982,'CO','Colombia','government',118,'Official name: Republic of Colombia
Type: republic; executive branch dominates government
structure
Capital: Bogota
Political subdivisions: 22 departments, 3 Intendants, 5
Commissariats, Bogota" Special District
Legal system: based on Spanish law; religious courts
regulate marriage and divorce; constitution decreed in 1886,
amendments codified in 1946 and 1968; judicial review of
legislative acts in the Supreme Court; accepts compulsory
ICJ jurisdiction, with reservations
44
COLOMBIA (Continued)
National holiday: Independence Day, 30 July
Branches: President, bicameral legislature, judiciary
Government leader: President Julio Cesar TURBAY
Ayala
Suffrage: age 18 and over
Elections: every fourth year; next presidential election
scheduled for May 1982; last congressional election March
1982; municipal and departmental elections every two years,
last held February 1980
Political parties and leaders: Liberal Party, President
Julio Cesar Turbay and former President Alfonso Lopez
Michelsen; Conservative Party, Alvaro Gomez Hurtado,
Misael Pastrana Borrero, and Belisario Betancur head two
principal factions
Voting strength: 1978 presidential election — Julio Cesar
Turbay 49%, Belisario Betancur 46%, Gen. Alvaro Valencia
1.3%; 1978 municipal election, 55% Liberal Party, 36%
Conservative Party, 9% combined far left parties; 70%
abstention of eligible voters
Communists: 10,000-12,000 members est.
Other political or pressure groups: Communist Party
(PCC), Gilberto Vieira White; PCC/ML, Chinese Line
Communist Party
Member of: FAO, G-77, GATT, 1ADB, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, 1DB, IFAD, IFC, IHO, ILO,
1MCO, IMF, ISO, ITU, LAFTA and Andean Sub-Regional
Group (created in May 1969 within LAFTA), OAS, SELA,
UN, UNESCO, UPEB, UPU, WHO, W1PO, WMO, WSG,
WTO','d85c8e22964992c8ea60cbdab14b11ada25c1c06715340e3f8f11d08dab0f666','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a64913468165792d5f79f6349d22cfb01d7f25f0b10c4a333647710db1cc8fa',1982,'KM','Comoros','government',121,'Official name: Federal Islamic Republic of the Comoros
Type: three of the four islands comprise an independent
republic, following local government''s unilateral declaration
of independence from France in July 1975; other island,
Mayotte, disallowed declaration and is now a French territo-
rial community
Capital: Moroni
Political subdivisions: the three islands are organized into
seven regions
Legal system: French and Muslim law
Branches: Mohamed Abdallah elected President of the
Comoros, 21 October 1978, having regained power May
1978 following a coup, led by French-born mercenary Bob
Denard, which toppled Ali Soilih; Soilih had come to power
in 1977 through a coup that ousted Abdallah; Soilih was
killed in the second coup
Government leader: President Ahmed ABDALLAH
Suffrage: universal adult
Elections: next presidential election scheduled to take
place in 1984
Communists: information not available
Member of: ADB, FAO, G-77, IBRD, IDA, IFAD, ILO,
IMF, ISCON, ITU, NAM, OAU, UN, UNESCO, UPU,
WHO, WMO','5699c8f0b9b50221c9d4062db3da1ef7e18faa92cde2744feea56f214e4cd936','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55eff9c59be2cdeec4349b1d91973b0b12648f4c7089828802e19028c4280234',1982,'CG','Congo','government',125,'Official name: People s Republic of the Congo
Type: republic; military regime established September
1968
Capital: Brazzaville
Political subdivisions: nine regions divided into districts
Legal system: based on French civil law system and
customary law; constitution adopted 1973
National holiday: National Day, 15 August
Branches: President, Military Committee, Council of
State; judiciary; all policy made by Congolese Labor Party
Central Committee and Politburo
Government leaders: President Col. Denis SASSOU-
NGUESSO replaced Joachim Yhombi-Opango as President
in March 1979, following an intraparty squabble; Prime
Minister Col. Louis-Sylvain GOMA is Head of Government
Suffrage: universal over age 18
Elections: elections for local and regional organs and the
National Assembly were held in July 1979 — the first elec-
tions since June 1973
Political parties and leaders: Congolese Workers Party
(PCT) is only legal party
Communists: unknown number of Communists and
sympathizers
Other political or pressure groups: Union of Congolese
Socialist Youth (UJSC), Congolese Trade Union Congress
(CSC), Revolutionary Union of Congolese Union (URFC),
General Union of Congolese Pupils and Students (UGEEC)
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, EIB (associate), FAO, G-77,
GATT, IBRD, ICAO, ICO, IDA, IFAD, IFC, ILO, IMCO,
IMF, ITU, NAM, OAU, UDEAC, UEAC, UN, UNESCO,
UPU, WHO, WIPO, WMO','586f7d9625be81004d2a9fad0045c805ac7fcd116a3e2c18701a521596a6b87b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d76bc3dbb03c6e6d6acb58885e2fe619a258266a039ec6abec28f86c8f8c489c',1982,'CK','Cook Islands','government',129,'Official name: Cook Islands
Type: self-governing in "free association" with New Zea-
land; Cook Islands Government fully responsible for internal
affairs and has right at any time to move to full independ-
ence by unilateral action; New Zealand retains responsibility
for external affairs, in consultation with Cook Islands
Capital: Rarotonga
Branches: New Zealand Governor General appoints Rep-
resentative to Cook Islands, who represents the Queen and
the New Zealand Government; Representative appoints the
Prime Minister; Parliament of 22 members, popularly elect-
ed; House of Arikis (chiefs), 15 members, appointed by
Representative, an advisory body only
Government leader: Prime Minister Dr. Thomas (Tom)
DAVIS
Suffrage: universal adult
Elections: every five years, latest in March 1978
48','570f69b85bd3c8797d48153d60ff898e3075f9767b06cf4892b5b8ba3f4c2d95','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48330d4deca891d42940acd6edbdbbdd1aa8db48b59683dfcadf4636ec292dd6',1982,'CR','Costa Rica','government',130,'COOK ISLANDS (Continued)
Political parties and leaders: Cook Islands Party, Geof-
frey Henry; Democratic Party, Dr. Thomas Davis
Voting strength (1978): Democratic Party, 16 seats, Cook
Islands Party, 6 seats
Official name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: seven provinces
Legal system: based on Spanish civil law system; constitu-
tion adopted 1949; judicial review of legislative acts in the
Supreme Court; legal education at University of Costa Rica;
has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
49
COSTA RICA (Continued)
Branches: President, unicameral legislature, Supreme
Court elected by legislature
Government leader: President Rodrigo CARAZO Odio
until the inauguration of Luis Alberto MONGE on 8 May
1982
Suffrage: universal and compulsory age 18 and over
Elections: every four years; last, February 1982
Political parties and leaders: National Liberation Party
(PLN), Luis Alberto Monge, Daniel Oduber, Jose "Pepe"
Figueres; National Salvation Movement (MSN), Mario
Echandi; Unity Coalition (UNIDAD) comprised of: Demo-
cratic Renovation Party (PRD), Rodrigo Carazo; Christian
Democratic Party (PDC), Rafael Grillo Rivera; Republican
Calderonista Party (PRC), Rafael Angel Calder6n Fournier;
Popular Union Party (PUP), Jos6 Joaquin Trejos Fernandez;
United People''s Coalition (PU) comprised of three Marxist
parties: Popular Vanguard Party (PVP), Manuel Mora Val-
verde; Popular Revolutionary Movement (MRP), Sergio
Erick Ardon; Socialist Party (PS), Alvaro Montero Mejia
Voting strength (1982 election): PLN 57.3%, 33 seats;
UNIDAD 32.7%, 18 seats; PU 3.2%, 4 seats; MSN 3.7%, 1
seat; other, 1 seat
Communists: 10,000 members and sympathizers
Other political or pressure groups: Costa Rican Confed-
eration of Democratic Workers (CCTD; Liberation Party
affiliate), General Confederation of Workers (CGT; Commu-
nist Party affiliate), Chamber of Coffee Growers, National
Association for Economic Development (ANFE); Free Costa
Rica Movement (MCRL; rightwing militants)
Member of: CACM, FAO, IADB, IAEA, IBRD, ICAO,
ICO, IDA, IDB, IFAD, IFC, 1LO, IMF, IPU, ITU, IWC—
International Wheat Council, NAMUCAR (Caribbean Mul-
tinational Shipping Line — Naviera Multinacional del Car-
ibe), OAS, ODECA, SELA, UN, UNESCO, UPEB, UPU,
WHO, WMO, WTO','f803f0aeaa021ff14d4416d79daeae048a43d24dd0cdadfb25283d39750b7bc9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5f624510a020ea2b098eef7f986642584ad955a6f1403aac237e3ebf2e609fb',1982,'CU','Cuba','government',136,'Official name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 14 provinces and 169 munici-
palities
Legal system: based on Spanish and American law, with
large elements of Communist legal theory; Fundamental
Law of 1959 replaced constitution of 1940; a new constitu-
tion was approved at the Cuban Communist Party''s First
Party Congress in December 1975 and by a popular referen-
dum which took place on 15 February 1976; portions of the
new constitution were put into effect on 24 February 1976,
by means of a Constitutional Transition Law, and the entire
constitution became effective on 2 December 1976; legal
education at Universities of Havana, Oriente, and Las Villas;
does not accept compulsory ICJ jurisdiction
National holiday: Anniversary of the Revolution, 1
January
Branches: executive; legislature (National People''s Assem-
bly); controlled judiciary
Government leader: President Fidel CASTRO Ruz
Suffrage: universal, but not compulsory, over age 16
Elections: National People''s Assembly (indirect election)
every five years; election held November 1981
Political parties and leaders: Cuban Communist Party
(PCC), First Secretary Fidel Castro Ruz, Second Secretary
Raul Castro Ruz
Communists: approx. 400,000 party members
Member of: CEMA, ECLA, FAO, G-77, GATT, 1ADB
(nonparticipant), IAEA, 1CAO, 1FAD, IHO, ILO, IMCO,
International Rice Commission, ISO, ITU, IWC — Interna-
tional Wheat Council, NAM, NAMUCAR (Caribbean Multi-
national Shipping Line — Naviera Multinacional del Caribe),
OAS (nonparticipant), PAHO, Permanent Court of Arbitra-
tion, Postal Union of the Americas and Spain, SELA, UN,
UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WSG,
WTO','b5b581f2daa9cbccb55b1081bfd570bd22a57b080b8106061523628e7fd3fe89','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ee4198870444d9e7295efedbbb51e0e83bd4d1b0d195692089a9b8b6b93e8d5',1982,'CY','Cyprus','government',141,'Official name: Republic of Cyprus
Type: republic since August 1960; a disaggregation of the
two ethnic communities inhabiting the island began after the
outbreak of communal strife in 1963; this separation was
further solidified following the Turkish invasion of the island
in July 1974, which gave the Turkish Cypriots de facto
control over the northern 37 percent of the republic; in 1975
the Turkish Cypriots declared a separate Turkish Federated
State of Cyprus, although Greek Cypriots control the only
internationally recognized government; negotiations, which
aim at finding a mutually agreeable solution to intercom-
munal differences, have focused on the creation of a federal
system of government
Capital: Nicosia
52
CYPRUS (Continued)
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law
modifications; negotiations to create the basis for a new or
revised constitution to govern the island and relations be-
tween Greek and Turkish Cypriots have been held
intermittently
National holiday: Independence Day, 1 October
Branches: currently the Government of Cyprus has effec-
tive authority over only the Greek Cypriot community,
consisting of Greek Cypriot parts of bodies provided for by
constitution; headed by President of the Republic and
comprised of Council of Ministers, House of Representatives,
and Supreme Court; Turkish Cypriots have their own
"constitution" and governing bodies within the "Turkish
Federated State of Cyprus"
Government leaders: President Spyros KYPRIANOU;
elected Interim President in September 1977 to serve out the
remainder of the term of Archbishop Makarios, who died on
3 August 1977, and elected President in his own right by
acclamation in February 1978; Turkish Sector: "President"
Rauf DENKTASH; "Prime Minister" Mustafa CAGATAY
Suffrage: universal age 21 and over
Elections: officially every five years (next presidential
elections to be held in 1983); parliamentary elections held in
May 1981; Turkish Cypriot "presidential" and "parliamen-
tary" elections held in June 1981
Political parties and leaders: Greek Sector: Progressive
Party of the Working People (AKEL; Communist Party),
Ezekias Papaioannou; Democratic Rally (DS), Glafkos Cler-
ides; Democratic Party (DK), Spyros Kyprianou; United
Democratic Union of the Center (EDEK), Vassos Lyssarides;
New Democratic Movement (NDP), Alecos Michaelides;
New Union of the Center, Tassos Papadopoulos; Pancyprian
Renewal Party (PAME), Khrysostomos Sofianos; Turkish
Sector: National Unity Party (UBP), Mustafa Cagatay; Com-
munal Liberation Party (TKP), Alpay Durduran; Republican
Turkish Party (CTP), Ozker Ozgur; Democratic People''s
Party (DHP), Nejat Konuk; Turkish Unity Party (TBP),
Ismail Tezer
Voting strength (1981 elections): in the parliamentary
elections pro-Western Democratic Rally and Communist
AKEL each received 12 of the 35 seats; Kyprianou ''s center-
right Democratic Party received eight seats; and socialist
EDEK won three seats; in "presidential" and "parliamen-
tary" elections in the Turkish Cypriot sector, Rauf Denktash
won with 52 percent of the vote; his party (UBP) received 18
of 40 seats in the "Assembly" while the center-left TKP won
13 seats; the remainder were divided among the other
parties
Communists: 12,000; sympathizers estimated to number
60,000
Other political or pressure groups: United Democratic
Youth Organization (EDON; Communist controlled); Union
of Cyprus Farmers (EKA; Communist controlled); Cyprus
Farmers Union (PEK; pro- West); Pan Cyprian Labor Feder-
ation (PEO; Communist controlled); Confederation of Cypri-
ot Workers (SEK; pro- West); Federation of Turkish Cypriot
Labor Unions (Turk-Sen); Confederation of Revolutionary
Labor Unions (Dev-Is)
Member of: Commonwealth, Council of Europe, FAO,
G-77, GATT, IAEA, IBRD, 1CAO, ICO, IDA, IFAD, 1FC,
ILO, IMCO, IMF, 1SCON, ITU, NAM, UN, UNESCO,
UPU, WHO, WMO, WTO','8e3efa363b033099b39aa0095cafde6ae1d9d718b89f2bf49495e0fd41a23d20','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e93fd773d11545cb22fc77c847d00b063fd22e7bd2cee97974d6af306347f98a',1982,'DE','Germany','government',145,'Official name: Czechoslovak Socialist Republic (CSSR)
Type: Communist state
Capital: Prague
Political subdivisions: 2 ostensibly separate and nomi-
nally autonomous republics (Czech Socialist Republic and
Slovak Socialist Republic); seven regions (kraj) in Czech
lands, three regions in Slovakia; national capitals of Prague
and Bratislava have regional status
Legal system: civil law system based on Austrian-
Hungarian codes, modified by Communist legal theory;
revised constitution adopted 1960, amended in 1968 and
1970; no judicial review of legislative acts; legal education at
Charles University School of Law; has not accepted compul-
sory ICJ jurisdiction
National holiday: Liberation Day, 9 May
54
CZECHOSLOVAKIA (Continued)
Branches: executive — President (elected by Federal As-
sembly), Cabinet (appointed by President); legislative — Fed-
eral Assembly (elected directly), Czech and Slovak National
Councils (also elected directly) legislate on limited area of
regional matters; judiciary — Supreme Court (elected by Fed-
eral Assembly); entire governmental structure dominated by
Communist Party
Government leaders: President Gustav HUSAK (elected
May 1975), Premier Lubomir STROUGAL
Suffrage: universal over age 18
Elections: governmental bodies and president every five
years (last election, June 1981)
Dominant political party and leader: Communist Party
of Czechoslovakia (KSC), Gustav Hus&k, General Secretary;
Communist Party of Slovakia (KSS) has status of "provincial
KSC organization* ''
Voting strength (1976 election): 99.7% for Communist-
sponsored single slate
Communists: 1.45 million party members and candidate
members (January 1978)
Other political groups: puppet parties — Czechoslovak
Socialist Party, Czechoslovak People''s Party, Slovak Free-
dom Party, Slovak Revival Party
Member of: CEMA, FAO, GATT, IAEA, ICAO, ICO,
IDA, IFC, ILO, International Lead and Zinc Study Group,
IMCO, 1PU, ISO, ITC, ITU, UN, UNESCO, UPU, Warsaw
Pact, WHO, W1PO, WMO, WSG, WTO
Official name: People''s Revolutionary Republic of','2434a554cc6e01fd06ecfbc854498b268747ecb98bfe26e6626b018178cca796','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('981433f93955a9480eb3a722169be60b71e1685ba3087e4f32e610d643e39971',1982,'DK','Denmark','government',148,'Official name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88
towns
Legal system: civil law system; constitution adopted 1953;
judicial review of legislative acts; legal education at Univer-
sities of Copenhagen and Arhus; accepts compulsory 1CJ
jurisdiction, with reservations
National holiday: birthday of the Queen, 16 April
Branches: legislative authority rests jointly with Crown
and parliament (Folketing); executive power vested in
Crown but exercised by Cabinet responsible to parliament;
Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen MARGRETHE II; Prime
Minister Anker J0RGENSEN
Suffrage: universal over age 21
Elections: on call of prime minister but at least every four
years (last election 8 December 1981)
Political parties and leaders: Social Democratic, Anker
Jorgensen; Liberal, Henning Christophersen; Conservative,
Poul Schliiter; Radical Liberal, Niels Helveg Petersen; So-
cialist Peopled, Gert Petersen; Communist, Joergen Jensen;
Left Socialist, Preben Wilhjelm; Center Democratic, Erhard
Jakobsen; Christian Peopled, Christian Christensen; Justice,
Poul Gerhard Kristiansen; Trade and Industry Party, Asger
J. Lindinger; Progress Party, Mogens Glistrup
Voting strength (1981 election): 32.9% Labor, 11.3%
Liberal, 14.4% Conservative, 8.9% Progress, 11.3% Socialist
Peopled, 5.1% Radical Liberal, 2.6% Left Socialist, 8.3%
Center Democrats, 2.3% Christian, 1.4% Justice
Communists: 7,500-8,000; a number of sympathizers, as
indicated by 34,625 Communist votes cast in 1981 elections
Member of: ADB, Council of Europe, DAC, EC, EEC,
ELDO (observer), EMA, ESRD, EURATOM, FAO, GATT,
IAEA, IBRD, ICAC, 1CAO, ICES, ICO, IDA, 1EA, 1FAD,
IFC, 1HO, 1LO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ISO, ITC, ITU, IWC— International
Wheat Council, NATO, Nordic Council, OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO, WSG','dc27acf74f547f47245fb80cff5cc71939ba3e23d7e4a9ce98c3bec5eb1822c2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c2021fceddd1ebeb7f58e6bc8c7601279f7d103ce04f1194d04da3b4b91ffed',1982,'DJ','Djibouti','government',152,'Official name: Republic of Djibouti
Type: republic
Capital: Djibouti
Political subdivisions: 5 Cercles (districts)
Legal system: based on French civil law system, tradition-
al practices, and Islamic law
Branches: 65-member Parliament, Cabinet, President,
Prime Minister
Government leader: President HASSAN Gouled Aptidon
Suffrage: universal
Elections: Parliament elected May 1977
57','65ec57dc5d39c154cdc180257b1ae7ea3389704301f828f6176c13f4f9a378b9','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31404a8e64cf88b8b06d36a07264629e17f576ac716c93d0a39833667677ea16',1982,'DM','Dominica','government',153,'DJIBOUTI (Continued)
Political parties and leaders: Peoples Progress Assembly
(RPP), Hassan Gouled
Communists: possibly a few sympathizers
Member of: Arab League, FAO, GATT (de facto), IBRD,
ICAU, IDA, IFAD, IFC, ILO, IMCO, IMF, ISCO, ITU,
NAM, OAU, UN
Official name: Commonwealth of Dominica
Type: independent state within Commonwealth as of 3
November 1978, recognizes Elizabeth II as Chief of State
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local
magistrate courts and the British Caribbean Court of
Appeals
Branches: legislature, 11-member popularly elected
House of Assembly; executive, Cabinet headed by Premier
Government leader: Prime Minister (Mary) Eugenia
CHARLES
Suffrage: universal adult suffrage over age 18
Elections: every five years; most recent 21 July 1980
Political parties and leaders: Dominica Labor Party
(DLP), Michael Douglas; Dominica Freedom Party (DFP),
58','ab5c0daf50927d07b06f11f713803e983da6d51d04c7b283f88cef8d8c5c7057','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('360b53875718d83e902bf5286d6080771ba4f5740a2e2fb77624ffb084c02fcf',1982,'DO','Dominican Republic','government',157,'DOMINICA (Continued)
Mary Eugenia Charles; Dominica Democratic Labor Party
(DDLP), Oliver Seraphin; Dominica Liberation Movement
Alliance (DLMA), William Riviere
Voting strength (1980 election): House of Assembly
seats — DFP 17 seats, DLP 2 seats, independent 2 seats
Communists: negligible
Member of: CARICOM, FAO, GATT (de facto), IDA,
IFAD, IFC, IMCO, IMF, OAS, UN, UNESCO, UPU, WMO
Official name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the National
District
Legal system: based on French civil codes; 1966
constitution
National holiday: Independence Day, 27 February
Branches: President popularly elected for a four-year
term; bicameral legislature consisting of Senate (27 seats) and
Chamber of Deputies (91 seats) elected for four-year terms;
Supreme Court
Government leader: President Antonio (Silvestre) GUZ-
MAN Fernandez
59
DOMINICAN REPUBLIC (Continued)
Suffrage: universal and compulsory, over age 18 or
married, except members of the armed forces and police,
who cannot vote
Elections: last national election May 1978; next election
May 1982
Political parties and leaders: Dominican Revolutionary
Party (PRD), Ivelisse Prats de Perez Reformist Party (PR),
Joaquin Balaguer; Dominican Liberation Party (PLD), Juan
Bosch; Democratic Quisqueyan Party (PQD), Elias Wessin y
Wessin; Social Christian Revolutionary Party (PRSC), Roge-
lio Delgado Bogaert; Movement for National Conciliation
(MNC), Jaime Manuel Fernandez Gonzalez; Antireelection
Movement of Democratic Integration (MIDA), Francisco
Augusto Lora; National Civic Union (UCN), Guillermo
Delmonte Urraca; National Salvation Movement (MSN),
Luis Julian Perez; Popular Democratic Party (PDP), Homero
Lajara Burgos; Fourteenth of June Revolutionary Movement
(MR-1J4), Hector Aristy Pereyra; Dominican Communist
Party (PCD), Narciso Isa Conde, central committee, legal-
ized in 1978; Dominican Popular Movement (MPD), illegal;
12th of January National Liberation Movement (ML-12E),
Plinio Matos Moquete, illegal; Communist Party of the
Dominican Republic (PACOREDO), Luis Montas Gonzalez,
illegal; Popular Socialist Party (PSP), illegal; Anti-Imperialist
Patriotic Union (UPA), Franklin Franco Pichardo; Demo-
cratic Union (UD), Ramon Antonio Flores; Revolutionary
League of Workers (LRT), Claudio Tavarez; several addi-
tional small leftist parties
Voting strength (1978 election): 51.7% PRD, 40.9% PR,
7.4% thirteen minor parties
Communists: an estimated 7,000 to 9,000 members in
severallegal and illegal factions; effectiveness limited by
ideological differences and organizational inadequacies
Member of: FAO, G-77, GATT, 1ADB, IAEA, IBA,
IBRD, ICAO, ICO, IDA, IDB, IFAD, IFC, 1HO, ILO,
IMCO, IMF, lOOC, ISO, ITU, OAS, SELA, UN, UNESCO,
UPU, WHO, WMO, WTO','ad8208de9206d6ca677c2183dd0e866dc78341a6149b594a817de93dd0faf6a3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c1721db650a2eac171e313bceb4ec66244f4213f917f20ec595e00d0fa3f480',1982,'EC','Ecuador','government',163,'Official name: Republic of Ecuador
National holiday: Independence Day, 10 August
Type: republic
Capital: Quito
Political subdivisions: 20 provinces including Galapagos
Islands
Legal system: based on civil law system; progressive new
constitution passed in January, 1978 referendum came into
effect following the installation of a new civilian government
in August 1979; legal education at four state and two private
universities; has not accepted compulsory 1CJ jurisdiction
Branches: executive; Chamber of Representatives; inde-
pendent judiciary
Government leader: President Osvaldo HURTADO Lar-
rea assumed office in May 1981 following the death of
President Jaime Roldos in an airplane crash
Suffrage: universal over age 18
Elections: presidential and parliamentary elections held
April 1979; a presidential election is scheduled for 1984
Political parties and leaders: Popular Democracy Party,
Julio Trujillo (the party of Pres. Hurtado); Concentration of
Popular Forces, party leader position vacant, populist; Radi-
cal Liberal Party, Ignacio Hidalgo, center right; Conserva-
tive Party, Jose Teran, center right; People, Change, and
Democracy, Aguiles Rigail, center left; Democratic Left,
Rodrigo Borja, center left; Democratic Party, Francisco
Huerta, progressive liberal
Voting strength: results of April 1979 presidential elec-
tion— Jaime Roldos, Concentration of Popular Forces 62%;
Sixto Duran-Ballen, center-right coalition 28%
Communists: Communist Party of Ecuador (PCE, pro-
Moscow, Rene Mauge — secretary-general), 500 members
plus an estimated 3,000 sympathizers; Communist Party of
Ecuador (PCE/ML, pro-Peking), 100 members; Revolution-
ary Socialist Party of Ecuador (PSRE), 200 members
Member of: ECOSOC, FAO, G-77, IADB, IAEA, IBRD,
ICAO, ICO, IDA, 1DB, IFAD, IFC, IHO, ILO, 1MCO, IMF,
ITU, LAFTA and Andean Sub-Regional Group (formed in
May 1969 within LAFTA), OAS, OPEC, SELA, UN,
UNESCO, UPEB, UPU, WHO, WMO, WTO','e39a6dee141c610f46bc636e7cc1581816c832b68da79eed1fc068cba2a14149','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34fb145afdedf10e36cf29a708c9d89c72b2104b9a2979e241dde4b5bb937eaa',1982,'SD','Sudan','government',170,'Official name: Arab Republic of Egypt
Type: republic; under presidential rule since June 1956
Capital: Cairo
Political subdivisions: 26 governorates
62
EGYPT (Continued)
Legal system: based on English common law, Islamic law,
and Napoleonic codes; permanent constitution written in
1971; judicial review of limited nature in Supreme Court,
also in Council of State, which oversees validity of adminis-
trative decisions; legal education at Cairo University; accepts
compulsory ICJ jurisdiction, with reservations
National holiday: National Day, 23 July
Branches: executive power vested in President, who
appoints Cabinet; People''s Assembly dominated by the
government''s National Democratic Party; independent judi-
ciary administered by Minister of Justice
Government leader: President Hosni MUBARAK
Suffrage: universal over age 18
Elections: regular elections to People''s Assembly every
five years (most recent June 1979); presidential elections
every six years (President Mubarak was elected in October
1981)
Political parties and leaders: formation of political par-
ties must be approved by government; National Democratic
Party, formed in mid-1978 by President Anwar El-Sadat, is
the major party; various small opposition parties
Communists: approximately 500, party members
Member of: AAPSO, AFDB, FAO, C-77, GATT, IAEA,
IBRD, ICAC, ICAO, IDA, IFAD, 1FC, 1HO, 1LO, IMCO,
IMF, IOOQ IPU, ITU, IWC— International Wheat Council,
NAM, OAU, UN, UNESCO, UPU, WHO, WIPO, WMO,
WPC, WSG, WTO; Egypt suspended from Arab League and
OAPEC in April 1979 and from 1SCON in May 1979
SRI LANKA (Continued)
UNESCO, UPU, WHO, WIPO, WMO, WTO; is applying
for membership to ASEAN
Official name: Democratic Republic of the Sudan
Type: republic under military control since coup in May
1969
Capital: Khartoum
Political subdivisions: 5 regions; regional governments
were recently granted additional authority
220
SUDAN (Continued)
Legal system: based on English common law and Islamic
law; some separate religious courts; permanent constitution
promulgated April 1973; legal education at University of
Khartoum and Khartoum extension of Cairo University at
Khartoum; accepts compulsory 1CJ jurisdiction, with
reservations
National holiday: Independence Day, 1 January
Branches: President and Cabinet; 151-member People''s
Assembly; five new regional assemblies inaugurated in June
1981 for northern Sudan; plans for the division of southern
Sudan are under consideration
Government leader: President Gen. Gaafar Mohamed
NIMEIRI
Suffrage: universal adult
Elections: elections for National People''s Assembly held
in December 1981-January 1982; most recent presidential
election held April 1977 with Nimeiri as sole candidate
Political parties and leaders: all parliamentary political
parties outlawed since May 1969; the ban on the Sudan
Communist Party was not enforced until after abortive coup
in July 1971; the government''s mass political organization,
the Sudan Socialist Union, was formed in January 1972
Other political or pressure groups: Muslim Brotherhood,
formerly at odds witji, the, military regime, now participates
actively in government; Ansar Muslim sect and National
Unionist Party do not participate directly in government
Member of: AFDB, APC, Arab League, FAO, G-77,
IAEA, IBRD, ICAC, ICAO, IDA, IFAD, IFC, 1LO, 1MCO,
IMF, ISCON, ITU, NAM, OAU, UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO','5b9b10909a5df81fb6e57f433699f39cc761ee98546a2f5bb645866cf14788bc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4faec0d42c1845cf5ac4d0018dba2cc58932bdad9c23d8d932086793631315c9',1982,'HN','Honduras','government',174,'Official name: Republic of El Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of
common law; constitution adopted 1962; military coup on 15
October 1979; judicial review of legislative acts in the
Supreme Court; legal education at University of El Salvador;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Independence Day, 15 September
Branches: Constituent Assembly elected on 28 March
1982 (60 seats)
Government leaders: military/civilian junta composed of
Jose Napoleon DUARTE (President), Army Col. Jaime Ab-
dul GUTIERREZ (Vice President), Jose Antonio MORALES
Ehrlich, Dr. Ram6n AVALOS Navarrete
Suffrage: universal over age 18
Elections: 28 March 1982 Constituent Assembly election;
Constituent Assembly to write new constitution and appoint
new provisional government until scheduled presidential
elections in 1983
Political parties and leaders: Christian Democratic Party
(PDC), Julio Samayoa; National Conciliation Party (PCN),
Raul Molina; Democratic Action (AD), Rene Fortin Magafia;
Salvadoran Popular Party (PPS), Francisco Quiftonez; Popu-
lar Orientation Party (POP), Gen. Jose Alberto Medrano;
National Republican Alliance (ARENA), Maj. Roberto D''Au-
buisson; Renovative Action Party (PAR), Ernesto Oyarbide
Voting strength: PDC 24 seats, ARENA 19 seats, PNC 14
seats, AD 2 seats, POP 0 seats, and PPS 1 seat; ACAN-EFE
Coalition (composed of ARENA, PCN, AD, POP, and PPS)
controls 36 of 60 seats
Leftist revolutionary movement (Farabundo Marti Na-
tional Liberation Front — FMLN): armed insurgents — Uni-
fied Revolutionary Directorate (DRU; alliance of guerrilla
groups), Farabundo Marti Popular Liberation Forces (FPL),
Armed Forces of the National Resistance (FARN), People''s
Revolutionary Army (ERP), Communist Party of El
Salvador/Liberation Armed Forces (PCES/FAL), and Cen-
tral American Workers'' Revolutionary Party (PRTC); mili-
tant front organizations — Revolutionary Coordinator of
Masses (CRM; alliance of front groups), Popular Revolution-
ary Bloc (BPR), Unified Popular Action Front (FAPU), 28
February Popular Leagues (LP-28), National Democratic
Union (UDN), and Popular Liberation Movement (MLP);
revolutionary coalition — Revolutionary Democratic Front
(FDR), coalition of CRM and Democratic Front (FD),
controlled by DRU; FD consists of moderate leftist groups —
Independent Movement of Professionals and Technicians of
El Salvador (MIPTES), National Revolutionary Movement
(MNR), and Popular Social Christian Movement (MPSC)
Extreme rightist vigilante organizations: National
Democratic Organization (ORDEN), White Warriors Union
(UGB), Death Squadron (EM), Mano Blanca (MANO), Orga-
nization for Liberation from Communism (OLC)
Labor organizations: Federation of Construction and
Transport Workers Unions (FESINCONSTRANS), independ-
ent; Salvadoran Communal Union (UCS), peasant associ-
ation; General Confederation of Trade Unions (CGS); United
Confederation of Workers (CUT), leftist; Popular Democrat-
ic Unity (UPD), moderate political pressure group headed by
FESINCONSTRANS, UCS, and other democratic labor
organizations
Business organizations: National Association of Private
Enterprise (ANEP), conservative; Productive Alliance (AP),
moderate; National Federation of Salvadoran Small Busi-
nessmen (FENAPES), moderate
64
Official name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law;
some influence of English common law; new constitution
became effective in January 1982; judicial review of legisla-
tive acts in Supreme Court; legal education at University of
Honduras in Tegucigalpa; accepts compulsory 1CJ jurisdic-
tion, with reservations
National holiday: Independence Day, 15 September
Branches: constitution provides for elected President,
unicameral legislature, and national judicial branch
Government leader: President Roberto SUAZO Cordova
took office in January 1982
Suffrage: universal and compulsory over age 21
Elections: national election 29 November 1981 for presi-
dent; members of unicameral legislature chosen by propor-
tional representation and 281 municipal councils
Political parties and leaders: the armed forces have
fulfilled their pledge to restore civilian government; they
will monitor Suazo''s administration closely, however, and
could seize power once again; major political leaders —
Liberal Party (PLH), Roberto Suazo Cordova (Rodista fac-
tion), Carlos Roberto Reina Idiaquez and Jorge Arturo Reina
Idiaquez (ALIPO faction), Ramon Villeda Bermudez and
Conrado Napky Damas (FUL faction); National Party
(PNH), Ricardo Zuniga Augustinus, Mario Rivera Lopez;
National Innovation and Unity Party (PINU), Miguel An-
donie Fernandez, Enrique Aguilar Paz; Honduran Christian
Democratic Party (PDCH), Hernan Corrales Padilla; Com-
munist Party of Honduras (PCH), Rigoberto Padilla Rush
(uninscribed)
Voting strength (1981 election with 98% vote tally): PLH
633,365; PNH 486,092, PINU 29,133, PDCH 18,785; legisla-
tive seats (with 98% vote tally)— PLH 44, PNH 34, PINU 2-
3, PDCH 1
Communists: about 1,500
Other political or pressure groups: National Association
of Honduran Campesinos (ANACH), Council of Honduran
Private Enterprise (COHEP), Confederation of Honduran
Workers (CTH), National Union of Campesinos (UNC),
General Workers Confederation (CGT), United Federation
of Honduran Workers (FUTH)
Member of: CACM, FAO, G-77, IADB, IBRD, ICAO,
ICO, IDA, 1DB, 1FAD, 1FC, 1LO, IMCO, IMF, ISO, ITU,
OAS, UN, UNESCO, UPEB, UPU, WHO, WMO','248c699597974a1ebaea7a1cffb56002c67c870d8ea95f2abef61c786bc4221f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2afe3e9c6116501ebdbbfafd70f1048e927da093d7433f72546be616a7f3a0ba',1982,'GQ','Equatorial Guinea','government',175,'EL SALVADOR (Continued)
Member of: Central American Common Market (CACM),
FAO, G-77, IADB, IAEA, IBRD, 1CAC, ICAO, ICO, IDA,
IDB, IFAD, IFC, ILO, IMF, ITU, IWC— International
Wheat Council, OAS, ODECA, SELA, UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO','c6b54bb9c76cf0aa862ab5aa5f3162661954cb493216f2d501f89691a448e989','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fa983da6ee5b76706ce3b9ccd2fa0fcc257552b47017d8b8d8785ec06ef207f',1982,'NG','Nigeria','government',180,'Official name: Republic of Equatorial Guinea
Type: republic
Capital: Malabo
Political subdivisions: 3 military regions; 7 provinces
with appointed military governors
Legal system: in transition; law by decree issued by
Supreme Military Council; in part based on Spanish civil law
and custom
National holiday: 12 October
65
EQUATORIAL GUINEA (Continued)
Branches: executive and legislative powers held by 11-
member Supreme Military Council assisted by ministries
headed by appointed military commissars; judicial process
not clearly defined since coup
Government leaden Lt Col. Teodoro OBIANG
NGUEMA MBASOGO, President, Supreme Military Coun-
cil (SMC), succeeded former President Masie Nguema after 3
August 1979 coup
Suffrage: popular suffrage has been deferred
Elections: last parliamentary elections held December
1973
Political parties and leaders: political activities suspend-
ed; before coup of 3 August 1979, National Unity Party of
Workers (PUNT) was the sole legal party
Communists: no significant number of Communists, but
some sympathizers
Member of: Conference of East and Central African
States. ECA, G-77, GATT (de facto), IBRD, ICAO, IDA,
IMCO, IMF, ITU, NAM, OAU, UN, UPU
Official name: Federal Republic of Nigeria
Type: federal republic since 1979
Capital: Lagos
Political subdivisions: 19 states, headed by elected
governors
Legal system: based on English common law, tribal law,
and Islamic law; new constitution was promulgated for
176
NIGERIA (Continued)
Fiscal year: calendar year
restoration of civilian rule in October 1979; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: Independence Day, 1 October
Branches: a strong executive president, a bicameral Na-
tional Assembly with a 95-seat Senate and a 449-seat House,
and a separate judiciary
Government leader: President Alhaji Shehu SHAGARI
Suffrage: universal over age 18
Elections: national elections held every four years (last
held in 1979) to elect a federal president, federal Senate,
federal House of Representatives, state governors, and state
legislatures
Political parties and leaders: National Party of Nigeria
(NPN), led by Shehu Shagari; Unity Party of Nigeria (UPN),
led by Obafemi Awolowo; Nigerian People''s Party (NPP),
led by Nnamdi Azikiwe; Great Nigerian People''s Party
(GNPP), led by Waziri Ibrahim; People''s Redemption Party
(PRP), led by Aminu Kano
Communists: the pro-Communist underground comprises
a fraction of the small Nigerian left; leftist leaders are
prominent in the country''s central labor organization but
have little influence on government
Member of: AFDB, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IAEA, IBRD, ICAO, ICO,
IDA, IFAD, IFC, ILO, IMCO, IMF, ISO, 1TC, ITU, IWC—
International Wheat Council, Lake Chad Basin Commission,
Niger River Commission, NAM, OAU, OPEC, UN,
UNESCO, UPU, WHO, WMO, WTO
Official name: Republic of Togo
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 21 circumscriptions
Legal system: based on French civil law and customary
practice; no constitution; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 27 April
Branches: military government, with civilian-dominated
Cabinet, took over on 14 April 1967, replacing provisional
government created after January coup; no legislature;
separate judiciary including State Security Court established
1970
Government leader: Gen. Gnassingbe EYADEMA, Presi-
dent, Minister of National Defense, and Armed Forces Chief
of Staff
Suffrage: universal adult
Elections: presidential referendum of January 1972 elect-
ed Gen. Eyadema for indefinite period
Political party: single party formed by President Eya-
dema in September 1969, Rally of the Togolese People
(RPT), structure and staffing of party closely controlled by
Communists: no Communist Party; possibly some
sympathizers
Member of: AFDB, CEAO (observer), EAMA, ECA,
ECOWAS, ENTENTE!, FAO, G-77, GATT, IBRD, ICAO,
ICO, IDA, IFAD, IFC, ILO, IMF, ITU, NAM, OAU,
OCAM, UN, UNESCO, UPU, WHO, WIPO, WMO, WTO','52c6c1f07ed37a0cf44d174ee34fa5fabeafadf3bd792220644cb35afec72838','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('826cabdf721d4569c379ee981c93d82217c56eb2c870f262b7c7769a57283329',1982,'ET','Ethiopia','government',184,'Official name: Ethiopia
Type: under military rule since mid-1974; monarchy
abolished in March 1975, but republic not yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as
regional administrations)
Legal system: complex structure with civil, Islamic, com-
mon and customary law influences; constitution suspended
September 1974; military leaders have promised a new
constitution but established no time frame for its adoption;
legal education at Addis Ababa University; has not accepted
compulsory 1CJ jurisdiction
National holiday: Popular Revolution Commemoration
Day, 12 September
Branohes: executive power exercised by the Provisional
Military Administrative Council (PMAC), dominated by its
chairman and small circle of associates; predominantly
civilian Cabinet is ineffectual and holds office at sufferance
of military; legislature dissolved September 1974; judiciary
at higher levels based on Western pattern, at lower levels on
traditional pattern, without jury system in either
Government leader: MENG1STU Haile-Mariam, Chair-
man of the Provisional Military Administrative Council
Suffrage: universal over age 21
Elections: urban dwellers'' association officials elected
June 1981
Political parties and leaders: no political party exists,
although efforts to create one have been underway for the
past few years
Communists: probably a few Communist sympathizers in
the government; government officially committed to orga-
nize a Communist party, but progress is slow
Other political or pressure groups: important dissident
groups include Eritrean Liberation Front (ELF), Eritrean
People''s Liberation Front (EPLF), and Eritrean Liberation
Front/Popular Liberation Forces in Eritrea; Tigrean Peoples
Liberation Front (TPLF) in Tigre Province; Western Somali
Liberation Front (WSLF) in the Ogaden Region
Member of: AFDB, ECA, FAO, G-77, IAEA, IBRD, ICO,
1CAO, IDA, 1FAD, 1FC, 1LO, 1MCO, IMF, 1PU, ITU,
NAM, OAU, UN, UNESCO, UPU, WHO, WMO, WTO','7c61a4a46e8043b36d0f1ba31459030812790d9923f23739553d2beb97fd24da','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9631364f8da7c84c407417ebb2ecf3b8c2a3f0ed05a35d576c3f1b8432795798',1982,'FO','Faroe Islands','government',186,'FALKLAND ISLANDS (Continued)
Government leader: Governor and Commander in Chief
J. R. W. PARKER (also High Commissioner for British
Antarctic Colony)
Suffrage: universal
Official name: Faroe Islands
Type: self-governing province within the Kingdom of
Denmark; 2 representatives in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 1 town
Legal system: based on Danish law; Home Rule Act
enacted 1948
Branches: legislative authority rests jointly with Crown,
acting through appointed High Commissioner,'' and 32-
member provincial parliament (Lagting) in matters of strict-
ly Faroese concern; executive power vested in Crown, acting
through High Commissioner, but exercised by provincial
cabinet responsible to provincial parliament
69','c9643546d1922320eb5db6006ab576e6375b8b6a94fe0f88d574af703c3c2d2d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925bcca722bbbf3adbf70956a9c3b3714318ac17e2b851b4f288da03f7e25585',1982,'FJ','Fiji','government',190,'FAROE ISLANDS (Continued)
Government leaders: Queen MARGRETHE II; Lagmand
(Chairman) Pauli ELLEFSEN; Danish Governor Leif
GROTH
Suffrage: universal, but not compulsory, over age 21
Elections: held every four years; most recent, 8 Novem-
ber 1980
Political parties and leaders: Coalition, Pauli Effefsen;
Peoples, Jogvan Sundstein; Republican, Erlendur Patursson;
Home Rule, Tobjern Poulsen; Progressive and Fishermen''s,
Adolf Hansen; Social Democratic, Atli Dam
Voting strength (1980 election): Coalition, 23.8%; Social
Democratic, 21.7%; Republican, 17.0%; Peoples, 17.9%;
Home Rule, 8.4%; Progressive and Fishermen''s, 8.2%
Communists: insignificant number
Member of: Nordic Council','8c544f584dcaefb98b2c0856b1ea4ca7002d4cdb2d6eb00b2d5d5bc849c061a6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a35ade98162f9d7797ac687d1f993a57310d15d03c52ecf3246382ad30a2b0f2',1982,'FI','Finland','government',195,'Official name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78
towns
Legal system: civil law system based on Swedish law;
constitution adopted 1919; Supreme Court may request
legislation interpreting or modifying laws; legal education at
Universities of Helsinki and Turku; accepts compulsory 1CJ
jurisdiction, with reservations
National holiday: Independence Day, 6 December
Branches: legislative authority rests jointly with President
and parliament (Eduskunta); executive power vested in
President and exercised through coalition Cabinet responsi-
ble to parliament; Supreme Court, four superior courts, 193
lower courts
Government leaders: President Mauno KOIVISTO;
Prime Minister Kalevi SORSA
Suffrage: universal, 18 years and over; not compulsory
Elections: parliamentary, every four years (last in 1979);
presidential, every six years (President Koivisto elected to
six-year term in January 1982)
Political parties and leaders: Social Democratic, Kalevi
Sorsa; Center, Paavo Vayrynen; Peoples Democratic League
(Communist front), Kalevi Kivisto; Conservative, lllka Suo-
minen; Liberal, Jaakko Itala; Swedish Peoples Party, Par
Stenback; Rural, Pekka Vennamo; Finnish People''s Unity
Party, Anssi Keski-Vahala; Finnish Communist Party, Aarne
Saarinen; Finnish Christian League, Raino Westerholm;
Constitutional Right, Georg Ehrnrooth
Voting strength (1979 parliamentary election): 23.9%
Social Democratic, 21.6% Conservative, 17.8% Peoples
Democratic League, 17.4% Center, 4.8% Christian League,
4.6% Finnish Rural Party, 4.6% Swedish Peoples, 3.7%
Liberal Peoples, 1.2% Constitutional Peoples, 0.3% Finnish
Peoples Unity Party, 0.1% Socialist Workers Party
Communists: 43,000; an additional 65,000 persons belong
to Peoples Democratic League; a further number of sympa-
thizers, as indicated by 517,198 votes cast for Peoples
Democratic League in 1979 elections
Member of: ADB, CEMA (special cooperation agree-
ment), DAC, EC (free trade agreement), EFTA (associate),
FAO, GATT, IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA,
1FAD,1FC, 1HO, 1LO, International Lead and Zinc Study
Group, IMCO, IMF, IPU, ITU, IWC— International Wheat
Council, Nordic Council, OECD, UN, UNESCO, UPU,
WHO, WIPO, WMO, WSG','5160868ef127035a79bf53c3793e0e3cfc5c6461ab1db8b170f468d045469411','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77c272ae1a30a7d9cba0e5e1d2105e1c1c8dbca3912ea8b35a7557ba938af555',1982,'FR','France','government',200,'Official name: French Republic
Type: republic, with President having wide powers
Capital: Paris
Political subdivisions: 96 metropolitan departments, 21
regional economic districts
Legal system: civil law system with indigenous concepts;
new constitution adopted 1958, amended concerning elec-
tion of President in 1962; judicial review of administrative
73
FRANCE (Continued)
but not legislative acts; legal education at over 25 schools of
law
National holiday: National Day, 14 July
Branches: presidential^ appointed Prime Minister heads
Council of Ministers, which is formally responsible to Na-
tional Assembly; bicameral legislature — National Assembly
(491 members), Senate (304 members) restricted to a delay-
ing action; judiciary independent in principle
Government leader: President Francois MITTERRAND
Suffrage: universal over age 18; not compulsory
Elections: National Assembly — every five years, last elec-
tion June 1981, direct universal suffrage, two ballots; Sen-
ate— indirect collegiate system for nine years, renewable by
one-third every three years, last election September 1980;
President, direct, universal suffrage every seven years, two
ballots, last election May 1981
Political parties and leaders: majority coalition — Social-
ist Party (PS), Lionel Jospin; Communist Party (PCF),
Georges Marchais; Left Radical Movement (MRG), Roger-
Gerard Schwartzenberg; right opposition — Rally for the
Republic (RPR, formerly UDR), Jacques Chirac; Republi-
cans (PR), Jacques Blanc; Center for Social Democrats (CDS),
Jean Lecanuet; Radical (RAD), Didier Bariani; Union for
French Democracy (federation of PR, CDS, and RAD), Jean
Lecanuet
Voting strength (first ballot, 1981 election): diverse left,
2.05%; Communist, 16.17%; Socialist, 36.12%; left Radical
1.39%; RPR, 20.8%; UDF, 19.2%; diverse right, 2.8%; other
1.47%
Communists: 600,000 claimed; Communist voters, 4 mil-
lion in 1981 elections
Other political or pressure groups: Communist-
controlled labor union (Confederation Generale du Travail)
nearly 2.4 million members (claimed); Socialist-leaning labor
union (Confederation Francaise Democratique du Travail —
CFDT) about 800,000 members est.; Independent labor
union (Force Ouvriere) about 1,000,000 members est.; Inde-
pendent white collar union (Confederation Generale des
Cadres) 340,000 members (claimed); National Council of
French Employers (Conseil National du Patronat Francais —
CNPF or Patronat)
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO, GATT,
IAEA, IATP, IBRD, ICAC, ICAO, ICES, ICO, IDA, IFAD,
1FC, IHO, ILO, International Lead and Zinc Study Group,
1MCO, IMF, IOOC, IPU, ISO, 1TC, ITU, IWC— Interna-
tional Whaling Commission, NATO (signatory), OAS (ob-
server), OECD, South Pacific Commission, UN, UNESCO,
UPU, WEU, WHO, WIPO, WMO, WSG, WTO
Official name: Spanish State
Type: parliamentary monarchy defined by new constitu-
tion of December 1978, that completed transition from
authoritarian regime of the late Generalissimo Franco and
confirmed Juan Carlos I as monarch, but without the
exceptional powers inherited from Franco on being pro-
claimed King 22 November 1975
Capital: Madrid
Political subdivisions: metropolitan Spain, including the
Canaries and Balearics, divided into 50 provinces which are
to be allowed to form autonomous regions — probably num-
bering 13 — assuming numerous powers previously exercised
by the central government; also five places of sovereignty
(presidios) on the Mediterranean coast of Morocco; trans-
ferred administration of Spanish Sahara to Morocco and
Mauritania on 26 February 1976
Legal system: civil law system, with regional applications;
new constitution provides for rule of law, established jury
system as well as independent constitutional court to rule on
unconstitutionality of laws and to serve as court of last resort
in protecting liberties and rights granted in constitution; does
not accept compulsory 1CJ jurisdiction
National holiday: 24 June
Branches: executive, with King''s acts subject to counter-
signature, Prime Minister (Presidente) and his ministers
responsible to lower house; legislative with bicameral Cortes
consisting of more powerful Congress of Deputies (350
members) and Senate (208 members) with possible addition
of one to six members from each new autonomous region;
judicial, independent
Government leaders: King JUAN CARLOS I (Chief of
State and Commander in Chief of the Armed Forces); Prime
Minister (Presidente) Leopoldo CALVO SOTELO y Bustelo
Suffrage: universal at age 18
Elections: parliamentary election 1 March 1979 for four-
year term; local elections for municipal councils on 3 April
1979
Political parties and leaders: principal national parties in
the 1979 elections from right to left — the conservative
Democratic Coalition (CD), major rightist group, led by
former ministers Manuel Fraga Iribarne and Jose Maria de
Areilza; the Union of the Democratic Center (UCD), the
center-right party of Prime Minister Calvo Sotelo; the
Spanish Socialist Workers Party (PSOE), the major party of
the democratic left, led by Secretary General Felipe Gonza-
lez; and the Spanish Communist Party (PCE), led by San-
tiago Carrillo, which espouses Eurocommunism; chief re-
gional parties — Convergence and Unity (CiU) of Jordi Pujol
in Catalonia; Basque Nationalist Party (PNV) of Carlos
Garaicoechea; Basque radical coalitions Popular Unity (HB)
and Basque Left (EE); and Andalusia Socialist Party (PSA) of
Alejandro Rojas Marcos
Voting strength: (1979 parliamentary election in lower
house) UCD 34.3%, and 168 seats (8 seats short of a majority);
PSOE 29.9%, 121 seats; PCE 10.4%, 23 seats; CD 5.8%, 9
217
SPAIN (Continued)
seats; CiU 2.6%, 8 seats; PNV 1.5%, 7 seats; PSA 1.7%, 5
seats; HB 0.9%, 3 seats; and 6 others, 1 seat each
Communists: PCE claims to have over 160,000 members,
but this figure is difficult to verify; the PCE''s greatest
strength is in labor where it dominates the country''s strong-
est trade union, the Workers Commissions, which now
claims a membership of around 1 million.
Other political or pressure groups: on the extreme left,
the Basque Fatherland and Liberty (ETA), the First of
October Antifascist Resistance Group (GRAPO), and the
Anti-Fascist and Patriotic Revolutionary Front (FRAP) use
terrorism to oppose the government; on the extreme right,
the Guerrillas of Christ the King and the Anticommunist
Apostolic Alliance (AAA) carry out vigilante attacks on ETA
members and other leftists; free labor unions (authorized in
April 1977) include the Communist-dominated Workers
Commissions (CCOO); the Socialist General Union of Work-
ers (UGT), and the independent Workers Syndical Union
(USO); the Catholic Church; business and landowning inter-
ests; Opus Dei; Catholic Action; university students
Member of: Andean Pact (observer), ASSIMER, ESRO,
FAO, GATT, IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA,
IEA, 1FAD, IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IOOC, IPU, ITC, ITU, IWC—
International Wheat Council, OAS (observer), OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO, WSG, WTO; ap-
plied for full membership in the EC 28 July 1977; joined
Council of Europe 18 October 1977','5036268e504892aa6362e5c6941f644a6cc6c11bb6771ce84f1d9fb74aa1c4d4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f6b39c57e93534af0894b5cf82628130eed01d92236a3554131df75dd92ef6e',1982,'GF','French Guiana','government',203,'Official name: Department of French Guiana
Type: overseas department and region of France; repre-
sented by one deputy in French National Assembly and one
senator in French Senate; Deputy Elie Castor, Senator
Raymond Tarcy
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes
each with a locally elected municipal council
Legal system: French legal system; highest court is Court
of Appeals based in Martinique with jurisdiction over Marti-
nique, Guadeloupe, and French Guiana
75
FRENCH GUIANA (Continued)
Branches: executive; prefect appointed by Paris; legisla-
tive: popularly elected 16-member General Council and a
Regional Council composed of members of the local General
Council and of the locally elected deputy and senator to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Commissioner of the Republic Max-
ime GONZALVO
Suffrage: universal over age 18
Elections: General Council elections normally are held
every five years; last election March 1978
Political parties and leaders: Guyanese Socialist Party
(PSG), Raymond Tarcy (senator), Leopold Helder; Union of
the Guyanese People (UPG), weak leftist party allied with,
but also reported to have been absorbed by, the PSG; Rally
for the Republic (RPR), Hector Rivierez
Communists: Communist party membership negligible','38101023a1a64461c953a781d2358cedd5363561e8e57d3d46496590f9249038','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b85489dfaae5f700e1f98da1c8d5371e2d7424d7c5a580029a7cf78c2d379c79',1982,'KI','Kiribati','government',207,'Official name: Territory of French Polynesia
Type: overseas territory of France
Capital: Papeete
Political subdivisions: five districts
Legal system: based on French; lower and higher courts
Branches: 33-member Territorial Assembly, popularly
elected; 5-member Council of Government, elected by
Assembly; popular election of two deputies to National
Assembly and one senator to Senate in Paris
Government leader: High Commissioner and President of
the Council of Government Paul NOIROT-COSSON, ap-
pointed by French Government
Suffrage: universal adult
Elections: every five years, last in May 1977
Political parties and leaders: Le Front Uni, autonomist
coalition, Francis Sanford; Tahoeraa Huiraatira, conserva-
tive Gaullist, Gaston Flosse
Voting strength (1977 election): Le Front Uni, 14 seats;
Tahoerra Huiraatira, 10 seats; independents, 9 seats
Official name: Republic of Kiribati
Type: republic; became independent 12 July 1979
Capital: Tarawa
Branches: 35-member parliament, nationally elected
President
Government leader: President leremia TABA1
Political parties and leaders: Gilbertese National Party,
Christian Democratic Party
Member of: ADB, GATT (de facto)
Official name: Democratic People''s Republic of Korea
Type: Communist state; one-man rule
Capital: PVongyang
Political subdivisions: nine provinces, three special cities
(PVongyang, Kaesong, and Chongjin)
Legal system: based on German civil law system with
Japanese influences and Communist legal theory; constitu-
tion adopted 1948 and revised 1972; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 9 September
Branches: Supreme Peoples Assembly theoretically super-
vises legislative and judicial function; State Administration
Council (cabinet) oversees ministerial operations
126
KOREA, SOUTH
NORTH KOREA (Continued)
Government and party leaders: KIM ll-song, President
DPRK and General Secretary of the Korean Workers Party;
Yl Chong-ok, Premier
Suffrage: universal at age 17
Elections: election to SPA every four years, but this
constitutional provision not necessarily followed — last elec-
tion February 1982
Political party: Korean Workers (Communist) Party;
claims membership of about 2 million, or about 11% of
population
Member of: FAO, IAEA, ICAO, 1PU, 1RCS, ITU, UN
(observer status only), UNCTAD, UNESCO, UPU, WHO,
WIPO, WMO
Official name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads
centrally appointed
Legal system: combines elements of continental European
civil law systems, Anglo-American law, and Chinese classical
127
SOUTH KOREA (Continued)
thought; constitution approved 1980; has not accepted com-
pulsory ICJ jurisdiction
National holiday: 15 August
Branches: executive, legislative (unicameral), judiciary
Government leaders: President CHUN Doo Hwan; Prime
Minister YOO Chang Soon
Suffrage: universal over age 20
Elections: under new constitution of October 1980, Presi-
dent elected every seven years indirectly by a 5,000-man
electoral college; last election February 1981; four-year
National Assembly, elected in March 1981, consists of 276
representatives, 184 directly elected and 92 chosen through
proportional representation
Political parties and leaders: major party is the govern-
ment s Democratic Justice Party (DJP), Chun Doo Hwan
(president) and Yi Chae-hyong (chairman); opposition parties
are Democratic Korea Party (DKP), Yu Chi-Song (president);
Korean National Party (KNP), Kim Chong-Chol (president);
Democratic Socialist Party (DSP), Ko Chong-hun (president);
and several smaller parties
Communists: Communist activity banned by govern-
ment; an estimated 37,000-50,000 former members and
supporters
Other political or pressure groups: Federation of Korean
Trade Unions; Korean Veterans'' Association; Korean National
Christian Council; large, potentially volatile, student popula-
tion concentrated in Seoul
Member of: AALCC (Afro-Asian League Consultative
Committee), ADB, Asian Parliamentary Union, APACL —
Asian People''s Anti-Communist League, ASPAC, Colombo
Plan, ESCAP, FAO, G-77, GATT, Geneva Conventions of
1949 for the protection of war victims, IAEA, IBRD, ICAC,
ICAO, IDA, IFAD, IFC, IHO, IMCO, IMF, INTELSAT,
INTERPOL, IPU, ITU, IWC— International Whaling Com-
mission, IWC— International Wheat Council, UNCTAD,
UNDP, UNESCO, UNICEF, UNIDO, UN Special Fund,
UPU, WACL— World Anti-Communist League, WHO,
WIPO, WMO, WTO; official observer at UN; does not hold
UN membership','257b4801c86dc5bef1262aa597e67c45291bab4f6b0cac67ecbbcc35d9e0eccc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9633bacf0923790852c2f7c8b428160ce1a5105075b583d35efc37b782484536',1982,'GA','Gabon','government',211,'Official name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: nine provinces subdivided into 36
prefectures
Legal system: based on French civil law system and
customary law; constitution adopted 1961; judicial review of
legislative acts in Constitutional Chamber of the Supreme
Court; legal education at Center of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
National holiday: 12 March, 17 August
Branches: power centralized in President, elected by
universal suffrage for seven-year term; unicameral 93-mem-
ber National Assembly (including nine members chosen by
Omar Bongo) has limited powers; constitution amended in
1979 so that Assembly deputies will serve five-year terms;
independent judiciary
Government leader: President El Hadj Omar BONGO
Suffrage: universal over age 18
Elections: Presidential election last held December 1979,
next presidential election scheduled for 1986; parliamentary
election last held February 1980, next election scheduled for
1985; constitutional change separates dates for presidential
and parliamentary elections
Political parties and leaders: Gabonese Democratic Party
(PDG) led by President Bongo is only legal party
Communists: no organized party; probably some Com-
munist sympathizers
Member of: AFDB, Conference of East and Central
African States, BDECA (Central African Development
Bank), EAMA, EIB (associate), FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICCO, ICO, IDA, IFAD, IFC, ILO, IMCO,
IMF, IPU, ISCON, ITU, NAM, OAB (African Wood Organi-
zation), OAU, OPEC, UDEAC, UN, UNESCO, UPU, WHO,
W1PO, WMO, WTO
Official name: Republic of The Gambia
Type: republic; independent since February 1965 (The
Gambia and Senegal in early 1982 formed a loose confeder-
ation named Senegambia, which calls for the integration of
their armed forces, economies and monetary systems, and
foreign policies)
Capital: Banjul
Political subdivisions: Banjul and five divisions
79
THE GAMBIA (Continued)
Legal system: based on English common law and custom-
ary law; constitution came into force upon independence in
1965, new republican constitution adopted in April 1970;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: 18 February
Branches: Cabinet of 10 members; 44-member House of
Representatives, in which four seats are reserved for chiefs,
four are appointed, 35 are filled by election for five-year
terms, a Speaker is elected by the House, and the Attorney
General is an appointed member; independent judiciary
Government leader: Sir Alhaji Dawda Kairaba JAWARA,
President
Political parties and leaders: People''s Progressive Party
(PPP), Secretary General Dawda K. Jawara; United Party
(UP), Pierre N''Jie; and National Convention Party (NCP),
Sherrif Dibba (Dibba is to be tried for treason because of his
complicity in the August 1980 coup attempt; the NCP may
be disbanded)
Suffrage: universal adult
Elections: general elections held April 1977; PPP 31 seats,
NCP 4 seats; next general elections scheduled for 1982
Communists: small underground group
Member of: AFBD, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IBRD, ICAO, IDA, 1FAD,
IMCO, IMF, ITU, NAM, OAU, UN, UNESCO, UPU,
WHO, WMD, WTO
Official name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by US, UK,
and France, which together with the USSR have special
rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts
(Bezirke), 218 counties (Kreise), 7,600 communities
(Gemeinden)
Legal system: civil law system modified by Communist
legal theory; new constitution adopted 1974; court system
parallels administrative divisions; no judicial review of legis-
lative acts; legal education at Universities of Berlin, Leipzig,
Halle, and Jena; has not accepted compulsory 1CJ jurisdic-
tion; more stringent penal code adopted 1968, amended in
1974 and 1979
National holiday: Foundation of German Democratic
Republic, 7 October
Branches: legislative — Volkskammer (elected directly);
executive — Chairman of Council of State, Chairman of
Council of Ministers, Cabinet (approved by Volkskammer);
judiciary — Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Erich
HONECKER (Head of State); Chairman, Council of Minis-
ters, Willi STOPH (Premier)
Suffrage: all citizens age 18 and over
Elections: national every five years; prepared by an
electoral commission of the National Front; ballot supposed
to be secret and voters permitted to strike names off ballot;
more candidates than offices available; parliamentary elec-
tions held 14 June 1981, and local elections held 20 May
1979
Political parties and leaders: Socialist Unity (Communist)
Party (SED), headed by General Secretary Erich Honecker,
dominates the regime; four token parties (Christian Demo-
cratic Union, National Democratic Party, Liberal Democrat-
ic Party, and Democratic Peasants Party) and an amalgam
of special interest organizations participate with the SED in
National Front
Voting strength: 1981 parliamentary elections and 1979
local elections; over 99% voted the regime slate
Communists: 2.1 million party members
Other special interest groups: Free German Youth, Free
German Trade Union Federation, Democratic Women''s
Federation of Germany, German Cultural Federation (all
Communist dominated)
Member of: CEMA, IAEA, ICES, ILO, IMCO, IPU, ITU,
UN, UNESCO, UPU, Warsaw Pact, WHO, WIPO, WMO,
WTO
Official name: Federal Republic of Germany
Type: federal republic
Capital: Bonn
Political subdivisions: 10 Laender (states); Western sec-
tors of Berlin are ultimately controlled by US, UK, and
France which, together with the USSR, have special rights
and responsibilities in Berlin
Legal system: civil law system with indigenous concepts;
constitution adopted 1949; judicial review of legislative acts
in the Supreme Federal Constitutional Court; has not accept-
ed compulsory 1CJ jurisdiction
82
GERMANY, FEDERAL REPUBLIC OF (Continued)
Branches: bicameral parliament — Bundesrat (upper
house), Bundestag (lower house); President (titular head of
state), Chancellor (executive head of government); inde-
pendent judiciary
Government leaders: President Karl CARSTENS, elected
23 May 1979 for a five-year term, took office 1 July 1979;
Chancellor Helmut SCHMIDT leads coalition of Social
Democrats and Free Democrats
Suffrage: universal over age 18
Elections: next national election scheduled for fall of 1984
Political parties and leaders: Christian Democratic
Union/Christian Social Union (CDU/CSU), Helmut Kohl,
Franz Josef Strauss, Gerhard Stoltenberg, Ernst Albrecht,
Richard von Weizsacker; Social Democratic Party (SPD),
Willy Brandt, Hans-Jtirgen Wischnewski, Herbert Wehner,
Helmut Schmidt; Free Democratic Party (FDP), Hans-
Dietrich Genscher, Otto Graf Lambsdorff, Wolfgang Misch-
nick; National Democratic Party (NPD), Martin Mussgnug;
Communist Party (DKP), Herbert Mies
Voting strength (1980 election): 42.9% SPD, 44.5%
CDU/CSU, 10.6% FDP, 2.0% splinter groups of left and
right (no parliamentary representation)
Communists: about 40,000 members and supporters
Other political or pressure groups: expellee, refugee, and
veterans groups
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EIB, ELDO, EMA, ESRO, EURATOM, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, ICO, IDA, 1FAD, 1EA, 1FC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, 1PU, 1TC, ITU, NATO, OAS (observer),
OECD, UN, UNESCO, UPU, WEU, WHO, WIPO, WMO,
WSG, WTO','68e5054d41d72be934c4b558e95e822f7489755f8a3815c934cae98c92b3be35','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb45c3ea487c2d28ba1a1eca0068618677c269f4901f125cc6d6597e64d2c7d7',1982,'GH','Ghana','government',215,'Official name: Republic of Ghana
Type: republic; independent since March 1957; 31 De-
cember 1981 coup ended two-year-old civilian government
and suspended constitution and political activity
Capital: Accra
Political subdivisions: eight administrative regions and
separate Greater Accra Area; regions subdivided into 58
districts and 267 local administrative districts
Legal system: based on English common law and custom-
ary law; legal education at University of Ghana (Legon); has
not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 6 March
Branches: executive authority vested in seven-member
Provisional National Defense Council (PNDC); on 21 Janu-
ary 1982 PNDC appointed secretaries to head most
ministries
Government leader: former Flight Lt. Jerry RAWLINGS,
Chairman of PNDC
Suffrage: universal over 21
Elections: elections held in June 1979 for parliament and
president; presidential runoff election held in July
Political parties and leaders: political parties outlawed
after 31 December 81 coup
Communists: a small number of Communists and
sympathizers
Member of: AFDB, Commonwealth, ECA, ECOWAS,
FAO, G-77, GATT, IAEA, 1BA, IBRD, 1CAO, ICO, IDA,
1FC, ILO, IMCO, IMF, ISO, ITU, NAM, OAU, UN,
UNESCO, UPU, WCL, WHO, WIPO, WMO, WTO','f227aecec14fa3b6f7a4789021f4c0e0c916f41f39ec717409a681f66ced3dde','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b31ab617f1d8685ef1a24bec3ecb4aff299353e52a8aad9f482d852f3818ef04',1982,'GI','Gibraltar','government',219,'Official name: Gibraltar
Type: British colony
Capital: none
Legal system: English law; constitutional talks in July
1968; new system effected in 1969 after electoral inquiry
Branches: parliamentary system comprised of the Gibral-
tar House of the Assembly (15 elected members and 3 ex
officio members), the Council of Ministers headed by the
Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in Chief
Gen. Sir William JACKSON; Chief Minister Sir Joshua
HASSAN
Atlantic Ocean
Al&feRtA
(See reference map V)
LAND
6.5 km2
Land boundaries: 1.6 km
85
GIBBALTAB (Continued)
Suffrage; all adult Cibraltarians, plus other UK subjects
resident six months or more
Elections: every five years; last held in February 1980
Political parties and leaders; Association for the Ad-
vancement of Civil Rights (AACRX Sir Joshua Hassan;
Democratic Party of British Gibraltar (DPBG), Peter I sola,
Socialist Labor Party, Joe Boscano
Voting strength: (February 1980) AACR, S seats; DPBG, 6
seats; Socialist Labor, 3 seats
Communists: negligible
Other political or pressure groups: the Housewives Asso-
ciation; the Chamber of Commerce; Gibraltar Representa-
tives Organization','70360b0866452cc78ebaf77140dffd743dd3086a3eec6ef7a1809a5678ff4706','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64815ae02319148abcf0609989a4c6b2003bea313cb58fdec4e8bcc0f4bc35e6',1982,'GR','Greece','government',223,'Official name: Hellenic Republic
Type: presidential parliamentary government; monarchy
rejected by referendum 8 December 1974
Capital: Athens
Political subdivisions: 52 departments (nomoi) constitute
basic administrative units for country; each nomos headed
by officials appointed by central government and policy and
programs tend to be formulated by central ministries; degree
of flexibility each nomos may have in altering or avoiding
programs imposed by Athens depends upon tradition and
influence which prominent local leaders and citizens may
exercise vis-a-vis key figures in central government; the
departments of Macedonia and Thrace exercise some degree
of autonomy from Athens since they are governed through
the Ministry of Northern Greece
Legal system: new constitution enacted in June 1975
National holiday: Independence Day, 25 March
Branches: executive consisting of a President, elected by
the Vouli (parliament), a Prime Minister, and a Cabinet;
legislative consisting of the 300-member Vouli; and an
independent judiciary
Government leaders: President Constantine KARAMAN-
LIS; Prime Minister Andreas PAPANDREOU
Suffrage: universal age 18 and over
Elections: every four years; Papandreou''s Panhellenic
Socialist Movement defeated the incumbent New Democra-
cy government of George Rallis in elections held on 18
October 1981
Political parties and leaders: Panhellenic Socialist Move-
ment, Andreas Papandreou; New Democracy, Evangelos
Averoff-Tossizza; Communist Party-Exterior, Kharilaos
Florakis; Progressive Party, Spyros Markezinis; Communist
Party-Interior, Kharalambos Drakopoulos; United Demo-
cratic Left, Ilias Iliou; Nationalist Camp, Stefanos Stefano-
poulos; Party of Democratic Socialism, Ioannis Pesmatzoglou
Voting strength: Panhellenic Socialist Movement, 170
seats; New Democracy, 112 seats; Communists (Exterior), 13
seats; independents, 5 seats
Communists: an estimated 25,000-30,000 members and
sympathizers
Member of: EC, EIB (associate), EMA, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFAD, IFC, IHO, ILO, IMCO,
IMF, IOOC, ITU, IWC— International Wheat Council,
NATO, OECD, UN, UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO','21af8a2340aed48ddcbaef87e6644ce7c3d6bdec10421fadbbd30a51367dded3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5989c880205bab1a521d7d6e4fcad041564ae6199d943878686184f2820ace7',1982,'GL','Greenland','government',228,'Official name: Greenland
Type: province of Kingdom of Denmark; two representa-
tives in Danish parliament; separate Minister for Greenland
in the Danish Cabinet
Capital: Godth&b (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to
province in 1953; limited home rule began in spring 1979
Branches: legislative authorityjests jointly with the elect-
ed 21-seat Landsting and Danish parliament; executive
power vested in Premier and four-person council; 19 lower
courts
Government leaders: Queen MARGRETHE II, Premier
Jonathan MOTZFELDT
88','2024ea4e9ea61a7a7265b41cd54f77cb042810d0cb3000ad98af3cd78cf96f2f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d17cca973bc37175d03ca2491b736ce1d2b770da5128735a834a7870508d43c',1982,'GD','Grenada','government',229,'GREENLAND (Continued)
Suffrage: universal, but not compulsory, over age 21
Elections: held every four years
Political parties: Siumut — leading party in present gov-
ernment with 13 seats (moderate socialist, advocating more
distinct Greenland identity and greater autonomy from
Denmark; the Atassut Party, which controls the remaining
eight seats, is more conservative, favors continuing close
relations with Denmark and the EC; Sulissartut Partiat, the
political wing of the Greenland labor movement; and the
Inuit Atagatigik, a Marxist-Leninist party favoring complete
independence from Denmark rather than home rule
Official name: Grenada
Type: independent state since February 1974, recognizes
Elizabeth 11 as Chief of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
National holiday: Independence Day, 7 February
Branches: following the 13 March 1979 coup, led by New
Jewel Movement leader Maurice Bishop, constitution sus-
pended on 25 March 1979 and replaced by People''s Laws;
three-man electoral commission appointed; elections
unscheduled
Government leaders: Prime Minister Maurice BISHOP;
UK Governor General Paul SCOON
89','c6eaf78550645d90f257570cdcdfebd85296ea82be56b93cb4540e98211214b0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cef76f7768cda205a920083783aaeda01ff49ccfe46f7e8522471350f28145cf',1982,'GP','Guadeloupe','government',233,'GRENADA (Continued)
Suffrage: universal adult
Elections: formerly every five years; most recent general
election 7 December 1976
Political parties and leaders: New Jewel Movement
(NJM), Maurice Bishop; United People''s Party (UPP), Win-
ston Whyte; Grenada National Party (GNP), Herbert A.
Blaize; Grenada United Labor Party (GULP)
Voting strength (1976 election): GULP 51.7%, Opposition
Coalition, 48.3%; Legislative Council seats, GULP 9, Opposi-
tion Coalition, 6 (NJM 3, UPP 1, GNP 1, unaffiliated 1)
Communists: negligible
Member of: CARICOM, G-77, GATT (de facto), IBRD,
IDA, IFAD, IFS, ILO, IMF, NAM, OAS, SELA, UN,
UNESCO, UPU, WHO
Official name: Department of Guadeloupe
Type: overseas department and region of France; repre-
sented by three deputies in the French National Assembly
and two senators in the Senate; last deputy election, 21 June
1981
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a court
of appeal based in Martinique with jurisdiction over Guade-
loupe, French Guiana, and Martinique
90
GUADELOUPE (Continued)
Branches: executive, Prefect appointed by Paris; legisla-
tive, popularly elected General Council of 36 members and
a Regional Council composed of members of the local
General Council and the locally elected deputies and sena-
tors to the French parliament; judicial, under jurisdiction of
French judicial system
Government leader: Commissioner of the Republic Rob-
ert MIGUET
Suffrage: universal over age 18
Elections: General Council elections are normally held
every five years; last General Council election took place in
June 1981
Political parties and leaders: Rassemblement pour la
Republique (RPR), Gabriel Lisette; Communist Party of
Guadeloupe (PCG), Henri Bangou; Socialist Party (MSG),
leader unknown; Progressive Party of Guadeloupe (PPG),
Henri Rodes; Independent Republicans; Federation of the
Left; Union for French Democracy (UDF); Union for a New
Majority (UNM)
Voting strength: MSG, 1 seat in French National Assem-
bly; PCG, 1 seat; UDF, 1 seat (1981 election)
Communists: 3,000 est.
Other political or pressure groups: Guadeloupe Liber-
ation Army (GLA)','b220d86133070362372a5db153228c93895d4275b3178d5ee07dd668dd5745e4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1bea018831a90bf262d1bfe3295dd881ae7cb6758f7fa1b41355e9cba3f018',1982,'GT','Guatemala','government',239,'Official name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system; civil law system; constitution came into
effect 1966; constitution suspended following March 1982
coup; judicial review of legislative acts; legal education at
University of San Carlos of Guatemala; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
Branches: traditionally dominant executive; elected uni-
cameral legislature; seven-member (minimum) Supreme
Court
Government leader: military junta under the presidency
of Gen. (Ret.) Efrain RIOS MONTT following coup of 23
March 1982, which removed President Maj. Gen. Fernando
Romeo Lucas Garcia; Gen. Angel Anibal Guevara had been
elected president in the March 1982 election and was
scheduled to take office on 1 July 1982
Suffrage: universal over age 18, compulsory for literates,
optional for illiterates
Elections: last elections (President and Congress) 7 March
1982
Political parties and leaders: Democratic Institutional
Party (PID), Donaldo Alvarez Ruiz; Revolutionary Party
(PR), Jorge Garcia-Granados Qirinonez (secretary general);
National Liberation Movement (MLN), Mario Sandoval
Alarcon; Guatemalan Christian Democratic Party (DCG),
Vinicio Cerezo Arevalo (secretary general); Rene de Leon
Schlotter (honorary president and party strongman); Nation-
alist Authentic Central (CAN), Luis Alfonso Lopez (secretary
general), Gustavo Anzueto Vielman (secretary and 1982
presidential candidate), Gen. Carlos Arana Osorio (party
strongman); National United Front (FUN), Col. Enrique
Peralta Azurdia; Nationalist Renovator Party (PNR), Alejan-
dro Maldonado Aguirre; United Revolutionay Party (FUR);
suspended political activity of all parties following March
1982 coup
Voting strength: (1978) for President— PID/PR, 269,973
(42.3%); MLN, 211,393 (33.1%); DCG, 156,730 (24.6%); for
congressional seats— PID/PR, 34 seats; MLN, 20 seats; DCG,
7 seats
Communists: Guatemalan Labor Party (PGT); main radi-
cal left guerrilla groups — Guerrilla Army of the Poor (EGP),
Revolutionary Organization of the People in Arms (ORPA),
Rebel Armed Forces (FAR), and PGT Dissidents
Other political or pressure groups: Federated Chambers
of Commerce and Industry (CACIF)
Member of: CACM, FAO, G-77, IADB, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB, IFAD, IFC, IHO, ILO, IMF,
ISO, ITU, IWC— International Wheat Council, OAS,
ODECA, SELA, UN, UNESCO, UPEB, UPU, WHO, WMO','05c6fb01462a60b4b3576614889ab398da42828f30462629c6f2e06a41aa9de4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39d3e8a8bdc5140c756cf2a6980ad563a26577f974641ac1462a4d4f7562cf43',1982,'GN','Guinea','government',242,'Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 35 administrative regions, 170
arrondissements, about 8,000 local entities at village level
Legal system: based on French civil law system, custom-
ary law, and presidential decree; constitution adopted 1958;
no constitutional provision for judicial review of legislative
acts; has not accepted compulsory ICJ jurisdiction
93
GUINEA (Continued)
National holiday: Independence Day, 2 October
Branches: executive branch dominant, with power con-
centrated in President''s hands and a small group who are
both ministers and members of the party''s politburo; uni-
cameral People''s National Assembly (210 members) and
judiciary have little independence
Government leader: President Ahmed Sekou TOURE,
who has been designated ''The Supreme Leader of the
Revolution"
Suffrage: universal over age 18
Elections: approximate schedule — five years parliamen-
tary, latest in 1980; seven years presidential, latest in 1975
Political parties and leaders: only party is Democratic
Party of Guinea (PDG), headed by Sekou Toure
Communists: no Communist party, although there are
some sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IBA,
IBRD, ICAO, ICO, IDA, IFAD, ILO, IMCO, IMF, ISCON,
ITU, Niger River Commission, NAM, OAU, UN, UNESCO,
UPU, WHO, WMO','4be250d1cb81d583ee6338220817119c20832a356ea89e0ee897a43ca34bac34','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('579b07fe26f6013731e785c90fced7807537b3219d486ae74fb7cfd4af15cb13',1982,'GW','Guinea-Bissau','government',246,'Official name: Republic of Guinea-Bissau
Type: republic; achieved independence .from Portugal in
September 1974; constitution abolished after 14 November
1980 coup; new constitution pending
Capital: Bissau
Political subdivisions: 9 municipalities, 3 circumscrip-
tions (predominantly indigenous population)
Legal system: to be determined
National holiday: 12 September
Branches: Presidency and Cabinet overseen by Revolu-
tionary Council
Government leaders: President and Revolutionary Coun-
cil Chairman Brig. Gen. Joao Bernardo V1E1RA; Vice
President of the Revolutionary Council and Foreign Affairs
Minister Victor SAUDE MARIA
Suffrage: universal over age 15
Elections: none held to date
Political parties and leaders: African Party for the
Independence of Guinea-Bissau and Cape Verde (PA1GC),
led by Pres. Vieira, secretary general, only legal party;
Guinea-Bissau recently decided to retain the binational
party title despite its formal break with Cape Verde
Communists: a few Communists, some sympathizers
Member of: FAO, G-77, GATT (de facto), IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMCO, IMF, ISCON, ITU, NAM,
OAU, UN, UNESCO, UPU, WHO, WMO','bf1fd7e8c456edc008efefb958ad1d532b18437fc74be0226ca9d4a3e496f1a2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ba09df30406a9c178038b7a1f6f3298ff0cbfbe7b092737c3c2a6290d7d709a',1982,'GY','Guyana','government',250,'Official name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 10 government districts
Legal system: based on English common law with certain
admixtures of Roman-Dutch law; has not accepted compul-
sory ICJ jurisdiction
National holiday: 23 February
Branches: Council of Ministers presided over by Prime
Minister; 65-member unicameral legislative National Assem-
bly (elected), including 12 seats elected by local councils;
Supreme Court
Government leader: Executive President L. F. S.
BURNHAM
Suffrage: universal over age 18 as of constitutional
amendment August 1973
Elections: last held in December 1980, following promul-
gation of new constitution (on 6 October) replacing British-
drafted constitution
Political parties and leaders: People''s National Congress
(PNC), L. F. S. Burnham; People''s Progressive Party (PPP),
Cheddi Jagan; Working People''s Alliance (WPA), Rupert
Roopnarine, Olive Thomas, Walter Omawale, Eusi
Kwayana; United Force (UF), Feilden Singh
Voting strength (1980 election, unofficial returns):
77.60% PNC, 19.46% PPP, 2.88% UF
Communists: est. 100 hardcore within PPP; top echelons
of PPP and PYO (Progressive Youth Organization, militant
wing of the PPP) include many Communists, but rank and
file is conservative and non-Communist; small but unknown
number of orthodox Marxist-Leninists within PNC, some of
whom are PPP turncoats
Other political or pressure groups: Trades Union Con-
gress (TUC); Working People''s Vanguard Party (WPVP);
Guyana Council of Indian Organizations (GCIO); Civil Lib-
erties Action Committee (CLAC); the latter two organiza-
tions are small and active but not well organized
Member of: CARICOM, CDB, FAO, G-77, GATT, IADB,
IBA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMCO, IMF, ISO,
ITU, NAM, OAS (observer), SELA, UN, UNESCO, UPU,
WHO, WMO','4b3677988b0231b4dd0abf1928b35ef96ee77baee053b5e6216882a6f009e048','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8382e900bba2bbdc93fbc71a4ac05fde82767c8e6ca502c7487c736b05eaddc7',1982,'HT','Haiti','government',255,'Official name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois
Duvalier who was succeeded upon his death on 21 April
1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: five departments (despite constitu-
tional provision for nine)
Legal system: based on Roman civil law system; constitu-
tion adopted 1964 and amended 1971; legal education at
State University in Port-au-Prince and private law colleges
97
HAITI (Continued)
in Cap-Haitien, Les Cayes, Gonaives, and Jeremie; accepts
compulsory ICJ jurisdiction
National holiday: Independence Day, 1 January
Branches: lifetime President, unicameral 58-member leg-
islature of very limited powers, judiciary appointed by
President
Government leader: President-for-Life Jean-Claude
DUVALIER
Suffrage: universal over age 18
Elections: constitution as amended in 1971 provides for
lifetime president to be designated by his predecessor and
ratified by electorate in plebiscite; legislative elections,
which are held every six years, last held February 1979
Political parties and leaders: National Unity Party,
inactive government party; Haitian Christian Democratic
Party, Sylvio Claude; Haitian Christian Social Party, Gre-
goire Eugene
Voting strength (1979 legislative elections): 99% regime
loyalists; 1 independent elected
Communists: United Haitian Communist Party (PUCH),
illegal and in exile; domestic strength unknown; party
leaders in exile
Other political or pressure groups: none
Member of: FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, 1CAO, ICO, IDA, IDB, IFAD, IFC, ILO, IMCO,
IMF, ITU, OAS, SELA, UN, UNESCO, UPU, WHO, WMO,
WTO','7a05cbb4211c9e0ec4fa2666898898ade36e3b7a98d933b4559fe2d78f155849','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef479bba417175bf20cef55ec7cc6df0980b7d89acb4bc16e2e66b7bc2eb3871',1982,'PH','Philippines','government',261,'Official name: Hong Kong
Type: British colony
Capital: None
Political subdivisions: Hong Kong, Kowloon, and New
Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive Coun-
cil; he legislates with advice and consent of Legislative
Council; Urban Council which alone includes elected repre-
100
HONG KONG (Continued)
sentatives, responsible for health, recreation, and resettle-
ment; independent judiciary
Government leader: Governor and Commander in Chief
Sir Edward YOUDE
Suffrage: limited to 200,000 to 300,000 professional or
skilled persons
Elections: every two years to select one-half of elected
membership of Urban Council; other Urban Council mem-
bers appointed by the Governor
Political parties: Civic Association; Reform Club; Socialist
Democratic Party; Hong Kong Labor Party
Voting strength: (elected Urban Council members) Civic
Association 4, Reform Club 3, and 1 independent
Communists: an estimated 2,000 cadres affiliated with
Communist Party of China
Other political or pressure groups: Federation of Trade
Unions (Communist controlled), Hong Kong and Kowloon
Trade Union Council (Nationalist Chinese dominated), Hong
Kong General Chamber of Commerce, Chinese General
Chamber of Commerce (Communist controlled), Federation
of Hong Kong Industries, Chinese Manufacturers'' Associ-
ation of Hong Kong
Member of: ADB
Official name: Republic of the Philippines
Type: republic
Capital: Manila
Political subdivisions: 72 provinces
Legal system: based on Spanish, Islamic, and Anglo-
American law; parliamentary constitution passed 1973;
188
PHILIPPINES (Continued)
constitution amended in 1981 to provide for French-style
mixed presidential-parliamentary system; judicial review of
legislative acts in the Supreme Court; legal education at
University of the Philippines, Ateneo de Manila University,
and 71 other law schools; accepts compulsory 1CJ jurisdic-
tion, with reservations; martial law lifted in January 1981
National holiday: Independence Day, 12 June
Branches: new constitution provides for unicameral Na-
tional Assembly, and a strong executive branch under
President and Prime Minister; judicial branch headed by
Supreme Court with descending authority in a three-tiered
system of local, regional trial, and intermediate appellate
courts
Government leader: President Ferdinand MARCOS
Suffrage: universal over age 18
Elections: Interim National Assembly serves as interim
government pending regular elections scheduled for 1984
Political parties and leaders: national parties are Mar-
cos''s New Society Party (KBL), the Liberals, Nationalistas,
and Laban; prominent regional parties include the Minda-
nao Alliance and the Pusyon Bisaya
Communists: about 5,000 armed insurgents; not recog-
nized as legal party
Member of: ADB, ASEAN, ASPAC, Colombo Plan, ES-
CAP, FAO, G-77, GATT, IAEA, IBRD, ICAO, IDA, IFAD,
IFC, IHO, ILO, IMCO, IMF, 1PU, ISO, ITU, UN,
UNESCO, UPU, WHO, WIPO, WMO, WTO
Official name: Taiwan
Type: one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 3 cities, 2 special
municipalities (Taipei and Kaosiung)
Legal system: based on civil law system; constitution
adopted 1947, amended 1960 to permit Chiang Kai-shek to
be reelected, and amended 1972 to permit President to
restructure certain government organs; accepts compulsory
ICJ jurisdiction, with reservations
National holiday: 10 October
Branches: five independent branches (executive, legisla-
tive, judicial, plus traditional Chinese functions of examina-
tion and control), dominated by executive branch; President
and Vice President elected by National Assembly
Government leaders: President CHIANG Ching-kuo;
Premier SUN Yun-hsiian
Suffrage: universal over age 20
Elections: national level — legislative yuan every three
years but no general election held since 1948 election on
mainland (partial elections for Taiwan province representa-
tives in December 1969, 1972, 1975, and 1980); local level-
provincial assembly, county and municipal executives every
four years; county and municipal assemblies every four
years
Political parties and leaders: Kuomintang, or National
Party, led by Chairman Chiang Ching-kuo, had no real
opposition; lately a loosely organized anti-Kuomintang oppo-
sition has emerged; two insignificant parties are Democratic
Socialist Party and Young China Party
Voting strength (1981 provincial assembly elections): 59
seats Kuomintang, 18 seats independents; 1981 local elec-
tions, with 72% turnout of eligible voters Kuomintang
received 59% of the popular vote, non-Kuomintang 41%
Other political or pressure groups: none
Member of: expelled from UN General Assembly and
Security Council on 25 October 1971 and withdrew on same
date from other charter-designated subsidiary organs; ex-
pelled from IMF/World Bank group April/May 1980; mem-
ber of ADB and seeking to join GATT and/or MFA;
attempting to retain membership in 1CAC, ISO, INTELSAT,
IWC-lnternational Wheat Council, PCA; suspended from
IAEA in 1972 but still allows IAEA controls over extensive
atomic development','4200b1e2845f3976e2182247d479eda5e4c76432fafb5abb7550b2076c89a993','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77b6c0c02477ae296a5bc52410ac4a4360578b9d65544af7935f5672e7ba8e4b',1982,'HU','Hungary','government',265,'Official name: Hungarian People''s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5 autono-
mous cities in county status, 97 jaras (districts)
Legal system: based on Communist legal theory, with
both civil law system (civil code of 1960) and common law
elements; constitution adopted 1949 amended 1972; Su-
preme Court renders decisions of principle that sometimes
have the effect of declaring legislative acts unconstitutional;
legal education at Lorand Eotvos Tudomanyegyetem School
of Law in Budapest and two other schools of law; has not
accepted compulsory ICJ jurisdiction
National holiday: Anniversary of the Liberation, 4 April
Branches: executive — Presidential Council (elected by
parliament); legislative — parliament (elected by direct suf-
frage); judicial — Supreme Court (elected by parliament)
Government leaders: Pal LOSONCZ1, President, Presi-
dential Council; Gyorgy LAzAR, Chairman, Council of
Ministers
Suffrage: universal over age 18
Elections: every five years (last election June 1980);
national and local elections are held separately
Political parties and leaders: Hungarian Socialist (Com-
munist) Workers* Party (MSZMP; sole party); Janos Kadar is
First Secretary of Central Committee
Voting strength (1980 election): 7,809,000 (99.3%) for
Communist-approved candidates; 97% of electorate eligible
to vote did so
Communists: about 754,000 party members (March 1975)
Member of: CEMA, Danube Commission, FAO, GATT,
IAEA, ICAC, ICAO, ILO, International Lead and Zinc
Study Group, IMCO, IPU, ISO, 1TC, ITU, UN, UNESCO,
UPU, Warsaw Pact, WHO, WIPO, WMO; has applied for
membership in IMF and the World Bank','34bdfb4f8617077e4a30a118ed5307063dde2830e714d6584d938723101a98d4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1d640d327a357234ca5d6c3a6b8d59a75a381b5418e0dc1a4e1f0f14cc837e3',1982,'IS','Iceland','government',269,'Official name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215 parishes, 14
incorporated towns
Legal system: civil law system based on Danish law;
constitution adopted 1944; legal education at University of
Iceland; does not accept compulsory 1CJ jurisdiction
National holiday: Anniversary of the Establishment of
the Republic, 17 June
103
ICELAND (Continued)
Fiscal year: calendar year
Branches: legislative authority rests jointly with President
and parliament (Althing); executive power vested in Presi-
dent but exercised by Cabinet responsible to parliament;
Supreme Court and 29 lower courts
Government leaders: President VigdTs FINNBOGADOT-
TIR, Prime Minister Gunnar THORODDSEN; government
coalition
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary every four years, last 2-3 De-
cember 1979; presidential every four years
Political parties and leaders: Independence (conserva-
tive), Geir Hallgrlmsson; Progressive, SteingrTmur Her-
mannsson; Social Democratic, Kjartan Johannsson; People''s
Alliance (Communist front), Svavar Gestsson
Voting strength (1979 election): 37.9% Independence,
24.9% Progressive, 19.7% People''s Alliance, 17.4% Social
Democratic, 1.2% other
Communists: est. 2,200, many of whom participate in the
People''s Alliance, which drew 24,390 votes in the 1979
parliamentary elections
Member of: Council of Europe, EC (free trade agreement
pending resolution of fishing limits issue), EFTA, FAO,
GATT, IAEA, IBRD, 1CAO, ICES, IDA, IFC, 1HO, ILO,
IMCO, IMF, IPU, ITU, IWC— International Whaling Com-
mission, NATO, Nordic Council, OECD, UN, UNESCO,
UPU, WHO, WMO, WSG','c3f74eca009dea62a54e2d220588c48ee3f636fa66546e06d4df4bea400c8ac6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cb5d0862332ebfde0ee3d679a1af511455c3dfbdffd26240af1cdb8e9257694',1982,'ID','Indonesia','government',274,'Official name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 27 first-level administrative subdi-
visions or provinces, which are further subdivided into 282
second-level areas
Legal system: based on Roman-Dutch law, substantially
modified by indigenous concepts and by new criminal
procedures code; constitution of 1945 is legal basis of
106
INDONESIA (Continued)
government; legal education at University of Indonesia,
Jakarta; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 17 August
Branches: executive headed by President who is chief of
state and head of Cabinet; Cabinet selected by President;
unicameral legislature (DPR, or parliament), of 460 mem-
bers (96 appointed, 364 elected); second and larger body
(MPR, or congress) of 920 members includes the legislature
and 460 other members (chosen by several processes, but not
directly elected) elects President and Vice President, and
theoretically determines national policy; judicial, Supreme
Court is highest court
Government leader: President, Gen. (Ret.) SOEHARTO
(reelected by Congress, March 1978)
Suffrage: universal over age 17 and married persons
regardless of age
Political parties and leaders: Golkar (quasi-official "par-
ty" based on functional groups), Amir Moertono; Indonesia
Democracy Party (federation of former Nationalist and
Christian Parties), Sunawar Sukowati; Unity Development
Party (federation of former Islamic parties), John Naro
Voting strength (1977 election): Golkar 232 seats, Indone-
sia Democracy 29, Unity Development 99
Communists: Communist Party (PK1) was officially
banned in March 1966; current strength est. at 1,000, with
less than 10% engaged in organized activity; pre-October
1965 hardcore membership has been estimated at 1.5 million
Member of: ADB, ANRPC, ASEAN, CIPEC, ESCAP,
FAO, G-77, GATT, IAEA, 1BA, IBRD, ICAO, ICO, IDA,
IFAD, IFC, IHO, ILO, IMCO, IMF, IPU, 1SCON, ISO, ITC,
ITU, NAM, OPEC, UN, UNESCO, UPU, WHO, W1PO,
WMO, WTO
Official name: Islamic Republic of Iran
Type: republic
Capital: Tehran
Political subdivisions: 23 provinces, subdivided into dis-
tricts, subdistricts, counties, and villages
Legal system: the new constitution codifies Islamic prin-
ciples of government
National holiday: Shia Islam religious holidays observed
nationwide
Branches: Ayatollah ol-Ozma Khomeini, the leader of the
revolution, provides general guidance for the government,
which is divided into executive, legislative, and Judicial
branches
Government leaders: Ayatollah ol-Ozma Ruhollah KHO-
MEINI, President Ali KHAMENEI (cleric), Prime Minister
Mir Hosein MUSAVI-KHAMENEI, Speaker of Islamic Con-
sultative Assembly Ali Akbar HASHEMI-RAFSANJANI
(cleric)
Suffrage: universal, age 18 and over
Elections: elections to endorse new constitution were held
in late 1979; those to select a president in January 1980 and
July and November 1981, and those to select the parliament
(two rounds) in March and May 1980; several parliamentary
byelections were held in 1980 and 1981
Political parties and leaders: Islamic Republic Party
(IRP), Ali Khamenei; Tudeh Party, Nur-ed-Din Kianuri
Voting strength: reliable figures not available; IRP and
sympathizers dominate the parliament
Communists: 1,000 to 2,000 est. hardcore; 15,000 to
20,000 est. sympathizers
Other political or pressure groups: People''s Strugglers
(Mojahedin), People''s Fedayeen, and Kurdish Democratic
Party are armed political groups; other ethnic minorities,
local leaders and Islamic Committees enforce their political
views through armed militia
Member of: Colombo Plan, FAO, G-77, IAEA, IBRD,
ICAC, 1CAO, IDA, 1FAD, IFC, IHO, ILO, IMCO, IMF,
1PU, ISCON, ITU, NAM, OPEC, RCD, UN, UNESCO,
UPU, WFTU, WHO, WMO, WSG, WTO; continued par-
ticipation in some of these organizations doubtful under the
new Islamic constitution','a26e6af1a6cb78f463ba2db84149145ecd33cb34071e33a7cbb2cb1deebe3785','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5951ba76859d80ad7f299e98e723285214656e33c61a7817b81389d93d77d396',1982,'IQ','Iraq','government',278,'Official name: Republic of Iraq
Type: republic; National Front government consisting of
Ba''th Party (BPI) and proadministration Kurds; Communists
play no role in government
Capital: Baghdad
Political subdivisions: 18 provinces under centrally ap-
pointed officials
Legal system: based on Islamic law in special religious
courts, civil law system elsewhere; provisional constitution
109
IRAQ (Continued)
adopted in 1968; judicial review was suspended; legal educa-
tion at University of Baghdad; has not accepted compulsory
ICJ jurisdiction
National holiday: 17 July
Branches: Ba''th Party of Iraq has been in power since
1968 coup
Government leaders: President Saddam HUSAYN; Depu-
ty Chairman of the Revolutionary Command Council ''Izzat
IBRAHIM
Suffrage: universal
Elections: elections — first held since overthrow of monar-
chy in 1958 — to National Assembly and to Legislative
Council for autonomous region held in June and September
1980
Communists: est. 2,000 hardcore members
Political or pressure groups: political parties banned,
possibly some opposition to regime from disaffected mem-
bers of the regime, army officers, and religious and ethnic
dissidents
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFAD, IFC, ILO, IMCO, IMF, ITU, NAM,
OAPEC, OPEC, UN, UNESCO, UPU, WFTU, WHO,
WIPO, WMO, WSG, WTO','4fdfd64857a058e9a4b64fcdf268bc35ac753eadc944b1eaa5eb6983b98072a8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3030b4bb85fa5bab6d7d6ccdd94ca2d5b6d97de7dfdce190f1f30fff914642f5',1982,'IE','Ireland','government',281,'Official name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substan-
tially modified by indigenous concepts; constitution adopted
1937; judicial review of legislative acts in Supreme Court;
has not accepted compulsory ICJ jurisdiction
National holiday: St. Patrick''s Day, 17 March
Branches: elected President; bicameral parliament re-
flecting proportional and vocational representation; judici-
ary appointed by President on advice of government
Government leaders: President Patrick HILLERY; Prime
Minister Charles HAUGHEY; Deputy Prime Minister Ray-
mond MACSHARRY
Suffrage: universal over age 18
Elections: Dail (lower house) elected every five years —
last election February 1982; President elected for seven-year
term — last election November 1976
Political parties and leaders: Fianna Fail, Charles
Haughey; Labor Party, Michael O''Leary; Fine Gael, Garret
Fitzgerald; Communist Party of Ireland, Michael O''Riordan;
Sinn Fein the Workers'' Party (SFWP), Tomas MacGiolla
Voting strength: (1982 election) Fianna Fail (81 seats),
Fine Gael (63 seats), Labor Party (15 seats), Sinn Fein the
Workers'' Party (3 seats), independents (4 seats)
Communists: approximately 600
Member of: Council of Europe, EC, EEC, ESRO (observ-
er), EURATOM, FAO, GATT, IAEA, IBRD, ICAO, ICES,
IDA, IEA, IFAD, IFC, ILO, IMCO, IMF, IPU, ISO, ITC,
ITU, IWC— International Wheat Council, OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO, WSG','71701f690ec2a6edab057e0d879700360a273fcbb4ab7640bbd863d591e070cf','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('366a4b26112ac465ab643316bb1588dfd7e743bee34aca661421f6a3840152c0',1982,'IL','Israel','government',286,'Official name: State of Israel
Type: republic
Capital: Jerusalem; not recognized by US, which main-
tains Embassy in Tel Aviv
Political subdivisions: six administrative districts
Legal system: mixture of English common law and, in
personal area, Jewish, Christian, and Muslim legal systems;
commercial matters regulated substantially by codes adopt-
ed since 1948; no formal constitution; some of the functions
of a constitution are filled by the Declaration of Establish-
ment (1948), the basic laws of the Knesset (legislature)
relating to the Knesset, Israeli lands, the president, the
government and the Israel citizenship law; no judicial review
of legislative acts; legal education at Hebrew University in
Jerusalem; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: Independence Day, 14 May
Branches: President Yitzhak Navon has largely ceremo-
nial functions, except for the authority to decide which
political leader should try to form a ruling coalition follow-
ing an election or the fall of a previous government;
executive power vested in Cabinet; unicameral parliament
(Knesset) of 120 members elected under a system of propor-
tional representation; legislation provides fundamental laws
in absence of a written constitution; two distinct court
systems (secular and religious)
Government leader: Prime Minister Menachem BEGIN
Suffrage: universal over age 18
Elections: held every four years unless required by
dissolution of Knesset; last election held in June 1981
Political parties and leaders: Herut, Prime Minister
Menachem Begin, Foreign Affairs Minister Yitzhak Shamir;
Liberal Party, Deputy Prime Minister Simcha Ehrlich;
La am, Eliezer Shostak; State List, Yitzhak Peretz (Likud is a
coalition formed in 1973 of Herut, Liberals, La am, and
State List); National Religious Party, Yosef Burg, Zevulun
Hammer; Israel''s Labor Alignment (includes MAPAM, Vic-
tor Shemtov, and Israel Labor Party, Shimon Peres, Yitzhak
Rabin); RAKAH Communist Party, Meir Wilner; TAMI,
Aharon Aba-Hatzeira; TELEM, Mordechai Ben-Porat;
Orthodox Agudat Israel, Avraham Shapira; Citizens Rights
Movement, Shulamit Aloni; Shinui Party, Amnon Rubin-
stein; Tehiya (Rebirth, formed by Likud defectors), Yuval
Ne eman
Voting strength: Likud, 48 seats; National Religious Par-
ty, 6 seats; Orthodox Agudat Israel, 4 seats; Israel''s Labor
Alignment (Labor Party-MAPAM), 47 seats; Shinui Party, 2
seats; Citizens Rights Movement, 1 seat; RAKAH, 4 seats;
Tehiya, 3 seats; TAMI, 3 seats; TELEM, 2 seats
Communists: RAKAH (predominantly Arab but with
Jews in its leadership) has some 1,500 members; the Jewish
Communist Party, MAKI, is now part of Moked, which is a
far-left Zionist party included in SHELLI
Other political or pressure groups: rightwing Kach
Movement led by Rabbi Meir Kahane; Black Panthers, a
loosely organized youth group seeking more benefits for
oriental Jews; Gush Emunim, Jewish religious zealots push-
ing for freedom for Jews to settle anywhere on the West
Bank
Member of: FAO, GATT, IAEA, IBRD, ICAC, ICAO,
IDA, IFAD, IFC, ILO, IMCO, IMF, IOOC, IPU, ITU,
IWC — International Wheat Council, OAS (observer), UN,
UNESCO, UPU, WHO, WIPO, WMO, WSG, WTO','0cdc7c498660d9f52904ca01ad5b15abbdd4e31b2a7353dc2f70e43a401510d2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8023917825b4b9b384f61d8ca73454f5517a20e14c0cf16ef40a60b1bdff2dbe',1982,'IT','Italy','government',289,'Official name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establish-
ment of 20 regions; five with special statute (Sicilia, Sar-
degna, Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
114
ITALY (Continued)
d''Aosta) have been functioning for some time and the
remaining 15 regions with regular statute were instituted on
I April 1972; 95 provinces, 8,081 communes
Legal system: based on civil law system, with ecclesiasti-
cal law influence; constitution came into effect 1 January
1948; judicial review under certain conditions in Constitu-
tional Court; has not accepted compulsory ICJ jurisdiction
National holiday: Anniversary of the Republic, 2 June
Branches: executive — President empowered to dissolve
Parliament and call national election; he is also Commander
of the Armed Forces and presides over the Supreme Defense
Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral, popu-
larly elected Parliament; Italy has an independent judicial
establishment
Government leaders: President Alessandro PERTIN1;
Premier Giovanni SPADOLINI
Suffrage: universal over age 18 (except in senatorial
elections where minimum age of voter is 25)
Elections: national elections for Parliament held every
five years (most recent, June 1979); provincial and municipal
elections held every five years with some out of phase;
regional elections every five years (held June 1980)
Political parties and leaders: Christian Democratic Party
(DC), Flaminio Piccoli (secretary general); Communist Party
(PCI), Enrico Berlinguer (secretary general); Socialist Party
(PSI), Benedetto Craxi (secretary general); Social Democratic
Party (PSDI), Pietro Longo (secretary general); Liberal Party
(PLI), Valerio Zanone (party secretary); Italian Social Move-
ment (MSI), Giorgio Almirante (party secretary); Republican
Party (PRI), Giovanni Spadolini (party secretary)
Voting strength (1979 election): 38.3% DC, 30.4% PCI,
9.8% PSI, 5.3% MSI, 3.8% PSDI, 3.0% PRI, 1.9% PLI, 3.4%
other
Communists: 1,814,740 members (February 1978)
Other political or pressure groups: the Vatican; three
major trade union confederations (CGIL — Communist
dominated, CISL — Christian Democratic, and UIL — Social
Democratic, Socialist, and Republican); Italian manufactur-
ers association (Confindustria); organized farm groups
Member of: ADB, ASSIMER, Council of Europe, DAC,
EC, ECOWAS, ECSC, EEC, EIB, ELDO, ESRO, EURA-
TOM, FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IFAD, IEA, IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IOOC, IPU, ITU, NATO, OAS
(observer), OECD, UN, UNESCO, UPU, WEU, WHO,
WIPO, WMO, WSG
Official name: Republic of the Ivory Coast
Type: republic; one-party presidential regime established
1960
Capital: Abidjan
116
IVORY COAST (Continued)
Political subdivisions: 24 departments subdivided into
127 subprefectures
Legal system: based on French civil law system and
customary law; constitution adopted I960; judicial review in
the Constitutional Chamber of the Supreme Court; legal
education at Abidjan School of Law; has not accepted
compulsory ICJ jurisdiction
National holiday: 7 December
Branches: President has sweeping powers, unicameral
legislature, separate judiciary
Government leader: President Felix HOUPHOUET-
BOIGNY
Suffrage: universal over age 21
Elections: legislative and municipal elections were held in
November 1980; Houphouet-Boigny reelected in October
1980 to his fifth consecutive five-year term
Political parties and leaders: Democratic Party of the
Ivory Coast (PDC1), only party; Houphouet-Boigny firmly
controls party
Communists: no Communist party; possibly some
sympathizers
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS, EIB
(associate), Entente, FAO, G-77, GATT, IAEA, IBRD, 1CAO,
ICO, IDA, IFAD, IFC, 1LO, 1MCO, IMF, 1PU, ITU, Niger
River Commission, NAM, OAU, OCAM, UN, UNESCO,
UPU, WHO, WIPO, WMO, WTO
Official name: Department of Martinique
Type: overseas department of France; represented by
three deputies in the French National Assembly and two
senators in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a court
of appeal based in Martinique with jurisdiction over Guade-
loupe, French Guiana, and Martinique
152
MARTINIQUE (Continued)
Branches: executive, Commissioner appointed by Paris;
legislative, popularly elected council of 36 members and a
Regional Council including all members of the local general
council and the locally elected deputies and senators to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Commissioner of the Republic Jean
CHEVANCE
Suffrage: universal over age 18
Elections: General Council elections normally are held
every five years; last General Council election took place in
June 1981
Political parties and leaders: Rally for the Republic
(RPR), Emile Maurice; Progressive Party of Martinique
(PPM), Aime Cesaire; Communist Party of Martinique
(PCM), Armand Nicolas; Democratic Union of Martinique
(UDM), Leon-Laurent Valere
Voting strength: RPR, 1 seat in French National Assem-
bly; PPM, 1 seat; UDM, 1 seat
Communists: 1,000 estimated
Other political or pressure groups: Proletarian Action
Group (GAP), Socialist Revolution Group (GRS), Martinique
Independence Movement (M1M)','9b84a0c85995e1c3661f9ad1bbf29611a1060c75742f8ed3fb7d6e36b717251b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26d326fb1a86fb8c285cce566684d666ae312aaa9a0bcc052d309096e5f6f5fd',1982,'JM','Jamaica','government',293,'Official name: Jamaica
Type: independent state within Commonwealth since
August 1962, recognizing Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St.
Andrew corporate area
Legal system: based on English common law; has not
accepted compulsory ICJ jurisdiction
National holiday: 7 August
Branches: Cabinet headed by Prime Minister; 60-member
elected House of Representatives; 21-member Senate (13
nominated by the Prime Minister, eight by opposition
leader); judiciary follows British tradition under a Chief
Justice
Government leader: Prime Minister Edward P. G.
SEAGA; Governor General Florizel GLASSPOLE
Suffrage: universal, age 18 and over
Elections: at discretion of Governor General upon advice
of Prime Minister but within five years; latest held 30
October 1980
Political parties and leaders: Jamaica Labor Party (JLP),
Edward Seaga; People''s National Party (PNP), Michael
Manley
Voting strength: (1980 general elections) approx. 58.8%
JLP (51 seats in House), 41.2% PNP (9 seats)
Communists: Communist Party of Jamaica; Worker''s
Party of Jamaica; Worker''s Party of Jamaica, Trevor
Munroe
Other political or pressure groups: New World Group
(Caribbean regionalists, nationalists, and leftist intellectual
fraternity); Rastafarians (Negro religious/racial cultists, pan-
Africanists); New Creation International Peacemakers Tab-
ernacle (leftist group); Workers Liberation League (a Marxist
coalition of students/labor)
Member of: CAR1COM, FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, 1CAO, ICO, 1DB, 1FAD, IPC, 1LO,
IMCO, IMF, ISO, ITU, NAM, Of>, Pan American Health
Organization, SELA, UN, UNESCO, UPU, WHO, W1PO,
WMO, WTO','0c96aaac94a7846269b1028bdde9b707ed071700b8f43263c76676ec27212707','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1a2afe39c4570c0c65cd04b95fff884ade5fa0d953e268b65e520143bd97096',1982,'JP','Japan','government',298,'Official name: Japan
Type: constitutional monarchy
Capital: Tokyo
Political subdivisions: 47 prefectures
Legal system: civil law system with English-American
influence; constitution promulgated in 1946; judicial review
of legislative acts in the Supreme Court; accepts compulsory
1CJ jurisdiction, with reservations
National holiday: Birthday of the Emperor, 29 April
119
JAPAN (Continued)
Branches: Emperor is merely symbol of state; executive
power is vested in Cabinet dominated by the Prime Minis-
ter, chosen by the lower house of the bicameral, elective
legislature (Diet); judiciary is independent
Government leaders: Emperor HIROHITO; Prime Min-
ister Zenko SUZUKI
Suffrage: universal over age 20
Elections: general elections held every four years or upon
dissolution of lower house, triennially for one-half of upper
house
Political parties and leaders: Liberal Democratic Party
(LDP), Z. Suzuki, president; Japan Socialist Party (JSP), 1.
Asukata, chairman; Democratic Socialist Party (DSP), R.
Sasaki, chairman; Japan Communist Party (JCP), K. Miya-
moto, Presidium chairman; Komeito (CGP), Y. Takeiri,
chairman; New Liberal Club (NLC), S. Tagawa; Social
Democratic Federation (SDF), H. Den
Voting strength (1980 elections): Lower House — 47.9%
LDP, 19.3% JSP, 9.8% JCP, 9.0% CGP, 6.6% DSP, 3.0%
NLC, 0.7% SDF, 3.6% independents and minor parties;
Upper House— 43.3% LDP, 22.4% JSP, 11.7% JCP, 5.0%
CGP, 5.1% DSP, 0.6% NLC, 0.0% SDF, 11.8% independents
and minor parties
Communists: approximately 400,000 registered Commu-
nist Party members
Member of: ADB, ASPAC, Colombo Plan, DAC, ESCAP,
FAO, GATT, IAEA, IBRD, 1CAC, ICAO, ICO, IDA, IEA,
1FAD, IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IPU, IRC, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC— International
Wheat Council, OECD, UN, UNESCO, UPU, WHO,
WIPO, WMO, WSG','53e12785859311cea29b09b412b3e657e8027c27c87ae4b97d5df39ebc7b3b3c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deaa441375017890842601b3e951c07e6996c733a98d86c1e37ccb897f979e3b',1982,'JO','Jordan','government',301,'Official name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ''Amman
Political subdivisions: eight governorates (three Israeli
occupied) under centrally appointed officials
Legal system: based on Islamic law and French codes;
constitution adopted 1952; judicial review of legislative acts
in a specially provided High Tribunal; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 25 May
Branches: King holds balance of power; Prime Minister
exercises executive authority in name of King; Cabinet
appointed by King and responsible to parliament; bicameral
parliament with House of Representatives last chosen by
national elections in April 1967, and dissolved by King in
February 1976; a National Consultative Council appointed
by the King in March 1978 as temporary substitute for
House of Representatives; Senate last appointed by King in
January 1979; present parliament subservient to executive;
secular court system based on differing legal systems of the
former Transjordan and Palestine; law Western in concept
and structure; Sharia (religious) courts for Muslims, and
religious community council courts for non-Muslim commu-
nities; desert police carry out quasi-judicial functions in
desert areas
Government leader: King HUSSEIN I
Suffrage: all citizens over age 20
Political parties and leaders: political party activity
illegal since 1957; Palestine Liberation Organization and
various smaller fedayeen groups clandestinely active on
West Bank; Muslim Brotherhood
Communists: party actively repressed, membership esti-
mated at less than 500
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFAD, IFC, ILO, IMCO, IMF, IPU, ISCON,
ITU, NAM, UN, UNESCO, UPU, WHO, WIPO, WMO,
WTO
Official name: Democratic Kampuchea (supported by
resistance forces deployed principally near the western
border); People''s Republic of Kampuchea (PRK; pro-
Vietnamese, in Phnom Penh)
Type: both are Communist states
Capital: Phnom Penh
Political subdivisions: 19 provinces
Legal system: Judicial Committee chosen by People''s
Representative Assembly in Democratic Kampuchea; no
information for PRK
National holiday: 17 April for both regimes
Branches: Cabinet, State Presidium, and some form of
People''s Representative Assembly in Democratic Kampu-
chea; Peoples Revolutionary Council, various ministries, and
a "National Congress''* held in early 1979 and a second time
in September 1979 in PRK
122
KAMPUCHEA (Continued)
Government leaders: Presidium Chairman and Prime
Minister KH1EU SAMPHAN; Deputy Prime Ministers
IENG SARY and SON SEN; Assembly Standing Committee
Chairman NUON CHEA in Democratic Kampuchea; Chair-
man, Council of State, HENG SAMRIN; Chairman, Council
of Ministers, CHAN SI; Minister of National Defense BOU
THANG; and Foreign Minister HUN SEN in PRK
Suffrage: universal over age 18
Political parties and leaders: Democratic Kampuchea
Khmer Communist Party disbanded December 1981 though
chief political figure still former party chairman Pol Pot; in
PRK Kampuchean United Front for National Construction
and Defense (KUFNCD) and separate Kampuchean Peoples
Revolutionary Party
Member of: Colombo Plan, ESCAP, FAO, G-77, GATT
(de facto), IAEA, IBRD, 1CAO, IDA, ILO, IMCO, IMF, ITU,
Mekong Committee (inactive), NAM, UN, UNESCO, UPU,
WHO, WMO, WTO for Democratic Kampuchea; none for
PRK','993752953f05b044b5868bb401962f5c501f2cd0da4ad25d7df2c9f774576d95','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fd628fa21e1219ec4f350f34f6b8447efe90e43d721b3f98452ccfa7d4ed1d4',1982,'KE','Kenya','government',306,'Official name: Republic of Kenya
Type: republic within Commonwealth since December
1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi area
Legal system: based on English common law, tribal law
and Islamic law; constitution enacted 1963; judicial review
in Supreme Court; legal education at Kenya School of Law
in Nairobi; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: 12 December
Branches: President and Cabinet responsible to unicam-
eral legislature (National Assembly) of 170 seats, 158 directly
elected by constituencies and 12 appointed by the President;
Assembly must be reelected at least every five years; High
Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any
civil or criminal proceeding; provision for systems of courts
of appeal
Government leader: President Daniel T. arap MOl
Suffrage: universal over age 21
Elections: general election (held November 1979) elected
present National Assembly and President
Political party and leaders: Kenya Africa National Union
(KANU), president, Daniel arap Moi
Voting strength: KANU holds all seats in the National
Assembly
Communists: may be a few Communists and sym-
pathizers
Other political or pressure groups: labor unions
Member of: AFDB, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICO, IDA, 1FAD, 1FC, ILO, IMCO, IMF, ISO, ITU,
IWC— International Wheat Council, NAM, OAU, UN,
UNDP, UNESCO, UPU, WHO, W1PO, WMO, WTO
Official name: State of St. Christopher-Nevis
Type: dependent territory with full internal autonomy as
a British "Associated State"; Anguilla formally seceded in
May 1967 and reverted to British crown colony status on 19
December 1980
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution
of 1960; highest judicial organ is Court of Appeal of
Leeward and Windward Islands
Branches: legislative, 10-member popularly elected
House of Assembly; executive, Cabinet headed by Premier
Government leaders: Premier Kennedy A. SIMMONDS;
Governor Clement A. ARRINDELL
Suffrage: universal adult suffrage
Elections: at least every five years; most recent 18
February 1980
Political parties and leaders: St. Christopher-Nevis La-
bor Party (SKLP), Lee Moore; People''s Action Movement
(PAM), Kennedy Simmonds; Nevis Reformation Party
(NRP), Simeon Daniel
Voting strength (February 1980 election): SKLP won 4
seats in the House of Assembly, PAM won 3, NRP won 2
Communists: none known
Member of: CAR1COM, ISO
Official name: St. Lucia
Type: independent state within Commonwealth as of 22
February 1979, recognizing Elizabeth 11 as Chief of State
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Branches: legislative, bicameral; executive, Cabinet head-
ed by Prime Minister
Government leaders: on 16 January 1982 the government
of Prime Minister Winston Cenac resigned; an Interim
Prime Minister, Michael PILGRAM, was sworn in
Suffrage: universal adult suffrage
200
Elections: every five -years; most recent 2 July 1979;
general elections will be held within 90 days of the dissolu-
tion of Parliament, which occurred on 6 February 1982
Political parties and leaders: United Worker''s Party
(UWP), John Compton; St. Lucia Labor Party (SLP), Win-
ston Cenac; Progressive Labor Party (PLP), George Odium
(Michael Pilgram s party)
Voting strength (1979 election): SLP won 12 of the 17
elected seats in House of Assembly; UWP won 5 seats
Communists: negligible
Member of: CARICOM, OAS
Official name: St. Vincent and the Grenadines
Type: independent state within Commonwealth as of 27
October 1979
Capital: Kingstown
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Government leaders: Prime Minister R. Milton CATO;
Governor General (UK) Sir Sydney GUNN-MUNRO
Suffrage: universal adult suffrage (18 years old and over)
Elections: every five years; most recent 5 December 1979
Political parties and leaders: People''s Political Party
(PPP), Ebenezer Joshua; St. Vincent Labor Party (LP), R.
Milton Cato; People''s Democratic Party, Parnell Campbell
and Kenneth John; United People s Movement (UPM), Ralph
Gonsalves and Renwick Rose; Progressive Democratic Party
(PDP), Randolph Russell; New Democratic Party (NDP),
James "Son" Mitchell
Voting strength (1979 election): LP 11 seats, NDP 2 seats
in the legislature
Member of: CARICOM','ca7810cba6cdf90b6cb236021f4ba9de265314122f3a2849dcec6d97d73fffb2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be8bd438a3f78b8c2947934cb8e5141ade84bb0c32365d2f131a4525f71996da',1982,'KW','Kuwait','government',311,'Official name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Political subdivisions: 3 governorates, 25 voting con-
stituencies
Legal system: civil law system with Islamic law significant
in personal matters; constitution took effect in 1963; popularly
elected 50-man National Assembly (the 15 Cabinet members
can also vote) reinstated in March 1981 after being suspended
in 1976; judicial review of legislative acts not yet determined;
has not accepted compulsory 1CJ jurisdiction
National holiday: 25 February
Branches: Council of Ministers
Government leader: Amir Jabir al-Ahmad al-Jabir Al
SABAH
Suffrage: native born and naturalized males age 21 or
over; law requires 20 years residency after naturalization
Elections: National Assembly elected in February 1981
Political parties and leaders: political parties prohibited,
some small clandestine groups are active
Communists: insignificant
Other political or pressure groups: large (300,000) Pales-
tinian community
Member of: Arab League, FAO, G-77, GATT, GCC,
IAEA, IBRD, ICAO, IDA, IFAD, 1FC, ILO, IMCO, IMF,
IPU, ISCON, ITU, NAM, OAPEC, OPEC, UN, UNESCO,
UPU, WHO, WMO, WTO
Official name: Lao People''s Democratic Republic
Type: Communist state
Capital: Vientiane
Political subdivisions: 13 provinces subdivided into dis-
tricts, cantons, and villages
Legal system: based on civil law system; has not accepted
compulsory ICJ jurisdiction
National holiday: 2 December
Branches: President; 40-member Supreme People''s Coun-
cil; Cabinet; Cabinet is totally Communist but Council
contains a few nominal neutralists and non-Communists;
National Congress of People''s Representatives established
the current government structure in December 1975
Government leaders: President SOUPHANOUVONG;
Prime Minister KAYSON PHOMV1HAN; Deputy Prime
130
LAOS (Continued)
Ministers NOUHAK PHOUMSAVAN, PHOUMI VONGVI-
CHIT, PHOUN SIPASEUT, KHAMTAI SIPHANDON, and
SALI VONGKHAMSAO
Suffrage: universal over age 18
Elections: elections for National Assembly, originally
scheduled for 1 April 1976, have not yet been held
Political parties and leaders: Lao People''s Revolutionary
Party (Communist), party chairman Kayson Phomvihan,
includes Lao Patriotic Front and Alliance Committee of
Patriotic Neutralist Forces; third congress of Lao People''s
Revolutionary Party scheduled for first half of 1982; other
parties are moribund
Other political or pressure groups: non-Communist po-
litical groups are moribund; most leaders have fled the
country
Member of: ADB, Colombo Plan, ESCAP, FAO, G-77,
IBRD, ICAO, IDA, IFAD, ILO, IMF, IPU, ITU, Mekong
Committee, NAM, SEAMES, UN, UNCTAD, UNESCO,
UPU, WHO, WMO, WTO','0c563220c1650d9bdcf5d96cd782337e575fbb32b35e30f10e623cec862005b4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa59ab504189deb9ecd74936458392a74b74f7a9cbb29b0b45152fc48386d49',1982,'LB','Lebanon','government',315,'NOTE: Between early 1975 and late 1976, Lebanon was
torn by civil war between its Christians — then aided by
Syrian troops — and its Muslims and their Palestinian allies.
The cease-fire established in October 1976 between the
domestic political groups has generally held, despite occa-
sional fighting, although the country is still under the
occupation of Syrian troops constituted as the Arab Deter-
rent Force by the Arab League. In March 1978 southern
Lebanon was invaded by Israeli troops. When the Israelis
withdrew in June, they turned much of the south over to a
United Nations interim force but left Christian militias in
control of zones along the border. The country''s own army is
gradually being reestablished but is still too fragile to give
the central government effective power. Syria''s move to-
ward supporting the Lebanese Muslims and the Palestinians
and Israel''s growing support for Lebanese Christians have
brought the two sides into rough equilibrium, but no
progress has been made on national reconciliation or politi-
cal reforms — the original cause of the war. The following
description is based on the present constitutional and cus-
tomary practices of the Lebanese system.
Official name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and
civil law system; constitution mandated in 1926; no judicial
review of legislative acts; legal education at Lebanese Uni-
versity; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 22 November
Branches: power lies with President elected by parlia-
ment (Chamber of Deputies); Cabinet appointed by Presi-
dent, approved by parliament; independent secular courts
on French pattern; religious courts for matters of marriage,
divorce, inheritance, etc.; by custom, President is a Maronite
Christian, Prime Minister is a Sunni Muslim, and president
of parliament is a Shia Muslim; each of nine religious
communities represented in parliament in proportion to
national numerical strength
Government leader: President Elias SARKIS
Suffrage: compulsory for all males over 21; authorized for
women over 21 with elementary education
Elections: Chamber of Deputies held every four years or
within three months of dissolution of Chamber; security
conditions have prevented parliamentary elections since
April 1972
Political parties and leaders: political party activity is
organized along largely sectarian lines; numerous political
groupings exist, consisting of individual political figures and
followers motivated by religious, clan, and economic consid-
erations; most parties have well-armed militias which are
still involved in occasional clashes
Communists: the Lebanese Communist Party was legal-
ized in 1970; members and sympathizers estimated at
2,000-3,000
Other political or pressure groups: Palestinian guerrilla
organizations
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFAD, IFC, 1LO, IMCO, IMF, 1PU, 1SCON,
ITU, 1WC— International Wheat Council, NAM, UN,
UNESCO, UPU, WHO, WMO, WSG, WTO
132','d7f388fd25601141b8f7cfa63460f90e74a7fa8f2d772e7d6346a205fd242dc6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('556782608a525edb67fbdf1cf0b79417c285eeca00975c77a27dbb95523cbef8',1982,'LS','Lesotho','government',316,'LEBANON (Continued)
Official name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II;
independent member of Commonwealth since 1966
Capital: Maseru
Political subdivisions: 10 administrative districts
Legal system: based on English common law and Roman-
Dutch law; constitution came into effect 1966; judicial
review of legislative acts in High Court and Court of Appeal;
legal education at National University of Lesotho; has not
accepted compulsory ICJ jurisdiction
National holiday: 4 October
Branches: executive, divided between a largely ceremo-
nial King and a Prime Minister who leads Cabinet of at least
seven members; Prime Minister dismissed bicameral legisla-
ture in early 1970 and subsequently ruled by decree until
1973 when he appointed Interim National Assembly to act as
133
LESOTHO (Continued)
legislative branch; judicial — 63 Lesotho courts administer
customary law for Africans, High Court and subordinate
courts have criminal jurisdiction over all residents. Court of
Appeal at Maseru has appellate jurisdiction
Government leaders; King MOSHOESHOE II; Prime
Minister Chief Leabua JONATHAN
Suffrage: universal for adults
Elections: elections held in January 1970; nullified alleg-
edly because of election irregularities; subsequent elections
promised at unspecified date
Political parties and leaders: National Party (RNP),
Chief Leabua Jonathan; Basutoland Congress Party (BCP),
Ntsu Mokhehle
Voting strength: in 1965 elections for National Assembly,
BNP won 32 seats; BCP, 22 seats; minor parties, 4 seats
Communists: negligible, Communist Party of Lesotho
banned in early 1970
Member of: Commonwealth, FAO, G-77, GATT (de
facto), IBRD* ICAO, IDA, IFAD, IFC, ILO, IMF, ITU,
NAM, OAU, UN, UNESCO, UPU, WHO, WMO','b43d3ac962c734a679ce7b66e8b32ed2c1d71ad8ffd3806e5e1322142e9b5809','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f730f626a44df7245c39c0165fdb2c6482d0b4edd3227e54e724990130a85d63',1982,'LR','Liberia','government',322,'Official name: Republic of Liberia
Type: highly centralized military rule following coup on
12 April 1980
Capital: Monrovia
Political subdivisions: country divided into 9 counties
Legal system: constitution suspended; martial law im-
posed; laws previously in force remain until repealed or
amended by decrees issued by People''s Redemption Council
National holiday: National Redemption Day, 12 April
Branches: executive and legislative powers held by mili-
tary People''s Redemption Council, assisted by military
Cabinet; judicial powers vested in People''s Supreme Tribu-
nal and lower courts
Government leader: Gen. Samuel Kanyon DOE (replaced
President William R. Tolbert)
Suffrage: universal 18 years and over
Elections: military has set 12 April 1985 as the date for
return to civilian rule
Political parties and leaders: political activities suspend-
ed; before coup True Whig Party dominated; African
Socialist-oriented Progressive People''s Party headed by B.
Gabriel Matthews had recently been legalized; unauthorized
Marxist-oriented Movement for Justice in Africa, led by
Togba Nah Tipoteh and Amos Sawyer
Communists: no Communist Party and only a few
sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IAEA,
IBRD, 1CAO, ICO, IDA, IFAD, IFC, ILO, 1MCO, IMF,
1PU, ITU, NAM, OAU, UN, UNESCO, UPU, WHO, WMO','623adf819d00ea44d118f0d6500afc0820046c812f9cefbd21fb5324c6d845f3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61c1363e1c861f8a8d9362b297fd7997da5e68f37383772b6ba91c0729f6b9e2',1982,'LY','Libya','government',325,'Official name: Socialist People''s Libyan Arab Jamahiriya
Type; republic; major overhaul of the constitution and
government structure in March 1977 established a system of
popular congresses which theoretically controls the ruling
General Secretariat
Capital: Tripoli
Political subdivisions: 10 administrative provinces closely
controlled by central government
Legal system: based on Italian civil law system and
Islamic law; separate religious courts; no constitutional provi-
sion for judicial review of legislative acts; legal education at
136
LIBYA (Continued)
Law School, at University of Libya at Benghazi; has not
accepted compulsory 1CJ jurisdiction
National holiday: Independence Day, 1 September
Branches: paramount political power and authority rests
with the Secretariat of the General People''s Congress which
theoretically functions as a parliament with a cabinet called
the General People s Committee
Government leaders: Col. Muammar al-QADHAFI
(Chief of State); General Secretary of the General People s
Congress Muhammad al-Zarruq RAJAB
Suffrage: universal
Elections: representatives to the General People s Con-
gress are drawn from popularly elected municipal
committees
Political parties: none
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nation-
alist movements and the Arab Socialist Resurrection (Ba''th)
party with small, almost negligible memberships may be
functioning clandestinely
Member of: AFDB, Arab League, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFAD, IFC, 1LO, IMCO, IMF, lOOC,
ITU, NAM, OAPEC, OAU, OPEC, UN, UNESCO, UPU,
WHO, WIPO, WMO, WSG','c67712ff1d4eeee99df4b22732a79211084497090eb4680bfc0647d20f593161','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d07323116a71196a899c8365c4a7343802345fe99d06006279ddb109221ddd4',1982,'LI','Liechtenstein','government',329,'Official name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 communes
Legal system: principality has its own civil and penal
codes; lowest court is county court (Landgericht), presided
over by one judge, which decides minor civil cases and
summary criminal offenses; criminal court (Kriminalger-
icht), with a bench of five judges, is for major crimes;
another court of mixed jurisdiction is the court of assizes
(three judges) for misdemeanors; Superior Court (Oberger-
icht) and Supreme Court (Oberster Gerichtshof) are courts of
appeal for civil and criminal cases (five judges each); an
administrative court of appeal from government actions and
the State Court determine the constitutionality of laws;
accepts compulsory 1CJ jurisdiction, with reservations
Branches: unicameral Parliament, hereditary Prince, in-
dependent judiciary
Government leaders: Head of State, H. S. H. Prince
FRANZ Josef II; Head of Government (Prime Minister),
Hans BRUNHART
Suffrage: males age 20 and over
Elections: every 4 years; last election 1982
Political parties and leaders: Fatherland Union (VU), Dr.
Otto Hasler; Progressive Citizens* Party (FBP), Dr. Peter
Marxer; Christian Social Party, Fritz Kaiser
Voting strength (1978): FBP 51%, VU 49%; in 1982
elections Brunhart received 53.6% of the vote
Communists: none
Member of: Council of Europe, EFTA, IAEA, INTEL-
SAT, ITU, UNCTAD, UNIDO, UPU, WIPO; considering
UN membership; under several post-World War I treaties
Switzerland handles Liechtenstein''s customs and postal tele-
phone and telegraph systems and represents the principality
abroad on a diplomatic and consular level whenever request-
ed to do so by the Liechtenstein Government','075f2434dfd2ef4458ad13205204c8a59215487de3393203e8bafbfb40095622','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b67093fd381ffe8b11fccee0dffdb088851b721131f8eee3068c1411f944dc0',1982,'LU','Luxembourg','government',334,'Official name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administra-
tive purposes has 3 districts (Luxembourg, Diekirch, Greven-
macher) and 12 cantons
Legal system: based on civil law system; constitution
adopted 1868; judicial review of legislative acts in the
Cassation Court only; accepts compulsory ICJ jurisdiction
National holiday: 23 June
Branches: parliamentary democracy; seven ministers
comprise Council of Government headed by President,
139
LUXEMBOURG (Continued)
which constitutes the executive; it is responsible to the
unicameral legislature, the Chamber of Deputies; the Coun-
cil of State, appointed for indefinite term, exercises some
powers of an upper house; judicial power exercised by
independent courts
Government leaders: Grand Duke JEAN, Head of State;
Pierre WERNER, Prime Minister
Suffrage: universal and compulsory over age 18
Elections: every five years for entire Chamber of Depu-
ties; latest elections June 1979
Political parties and leaders: Christian Social Party,
Pierre Werner (parliamentary president) and Jacques Santer
(party president); Socialist, Robert Krieps (party president);-
Social Democrat, Henry Cravatte (party president); Liberal,
Colette Flesch; Communist, Dominique Urbany; Independ-
ent Socialists, Jean Gremling (party president); Enroles de
Forces
Voting strength in Chamber of Deputies (1979): Chris-
tian Socialist, 24; Socialist Workers, 14; Liberals, 15; Social
Democrats, 1; Communists, 2; Independent Socialists, 1;
Enroles de Force, 1
Communists: 500 party members (1981)
Other political or pressure groups: group of steel indus-
tries representing iron and steel industry, Centrale Paysanne
representing agricultural producers; Christian and Socialist
labor unions, Federation of Industrialists; Artisans and Shop-
keepers Federation
Member of: Benelux, BLEU, Council of Europe, EC,
ECSC, EEC, EIB, EURATOM, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IEA, 1FAD, IFC, ILO, IMF, IOOC, IPU, ITU,
NATO, OECD, UN, UNESCO, UPU, WEU, WHO, W1PO,
WMO','60d40f6742aab8782c437f74a987be743972c7c7778fc806a8faec583a3c63ef','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1377840fdbd0bd1e97de9f7d92ff11efce24a85ad7d7c981498afd1f7af4b6d',1982,'MG','Madagascar','government',337,'Official name: Democratic Republic of Madagascar
Type: republic; real authority in hands of Supreme Revo-
lutionary Council dominated by President Ratsiraka''s
AREMA party
Capital: Antananarivo
Political subdivisions: 6 provinces
Legal system: based on French civil law system and
traditional Malagasy law; constitution of 1959 modified in
October 1972 by law establishing provisional government
institutions; new constitution accepted by referendum in
December 1975; legal education at National School of Law,
University of Madagascar; has not accepted compulsory 1CJ
jurisdiction
National holiday: Independence Day, 26 June
Branches: executive — a 21-member Supreme Revolution-
ary Council (made up of military and political leaders);
assisted by cabinet called Council of Ministers; People''s
National Assembly; Military Committee for Development;
regular courts are patterned after French system, and a High
Council of Institutions reviews all legislation to determine its
constitutional validity
Government leader: Cdr. Didier RATS1RAKA, President
Suffrage: universal for adults (18 and above)
Elections: referendum held in December 1975 gave
overwhelming approval to government and new constitu-
tion; elections for People''s National Assembly held in June
1977; only one political grouping allowed to take part in the
election, "The Front for the Defense of Malagasy Socialist
Revolution,*'' which presented a single list of candidates
Political parties and leaders: 6 parties are now allowed
limited political activity under the national front and are
represented on the Supreme Revolutionary Council; the 6
parties are: AREMA (President Ratsiraka''s Advance Guard
of the Malagasy Revolution); AKFM (Pastor Richard Andria-
manjato''s pro-Soviet Congress Party for Malagasy Independ-
ence); VONJY (Dr. Marojama Razanabahiny''s Movement for
National Unity); UDECMA (Norbert Andriamorasata''s Mal-
agasy Christian Democratic Union); MFM (Manandafy Ra-
kotonirina''s Militants for the Establishment of a Proletarian
Regime); MON1MA (Monja Jaona''s National Movement for
the Independence of Madagascar) party apparently split
over issue of joining national front, leader of faction support-
ing front unknown, Monja Jaona leads other faction
Voting strength: number of registered voters (1977) — 3.5
million; in 1977 local elections, President Ratsiraka''s
AREMA captured approximately 89.5% of the 73,000 avail-
able positions on 11,400 local Executive Committees; AKFM
won about 7.3% of the seats, MONIMA 1.7%, and VONJY
1.4%; UDECMA won only about 45 seats
Communists: Communist party of virtually no impor-
tance; small and vocal group of Communists has gained
142
MADAGASCAR (Continued)
strong position in leadership of AKFM, the rank and file of
which is non-Communist
Member of: EAMA, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICO, IDA, 1FAD, 1FC, 1LO, 1MCO, IMF, ISO, ITU,
NAM, OAU, OCAM, UN, UNESCO, UPU, WHO, WMO,
WTO','b0c5799a0b7da3f2e75a215f32d37115b3604fc9c856eafe88af7b457f46d412','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0472d5f51666e966aea720a178780fdd2ae2ebaa181ee32d40ffe4ff83e254c',1982,'MW','Malawi','government',341,'Official name: Republic of Malawi
Type: one-party state
Capital: Lilongwe
Political subdivisions: 3 administrative regions and 24
districts
Legal system: based on English common law and custom-
ary law; constitution adopted 1964; judicial review of legisla-
tive acts in the Supreme Court of Appeal; has not accepted
compulsory ICJ jurisdiction
National holiday: Republic Day, 6 July
Branches: strong presidential system with Cabinet ap-
pointed by President; unicameral National Assembly of 87
elected and up to 15 nominated members; High Court with
Chief Justice and at least two justices
Government leader: Life President Dr. H. Kamuzu
BANDA
Suffrage: universal adult (21 years)
Elections: parliamentary elections June 1978
Political parties and leaders: Malawi Congress Party
(MCP), Secretary General E. Bakili Muluzi
Communists: no Communist party; Malawi maintains no
foreign relations with Communist governments
Member of: AFDB, EEC (associate member), FAO, G-77,
GATT, IBRD, 1CAO, IDA, 1FAD, IFC, 1LO, IMF, 1PU, ISO,
ITU, NAM, OAU, UN, UNESCO, UPU, WHO, W1PO,
WMO, WTO
Official name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences
of common law; legal education at Thammasat University;
has not accepted compulsory ICJ jurisdiction
National holiday: National Day, 5 December
Branches: King is head of state with nominal powers;
semiparliamentary system reestablished 22 April 1979; judi-
ciary relatively independent except in important political
subversive cases
Government leaders: King BHUM1BOL ADULYADEJ,
Prime Minister Gen. PREM TINSULANONDA
Elections: last held April 1979; next scheduled for April
1983
230
THAILAND (Continued)
Political parties: Social Action Party, Thai Nation Party,
Thai People''s Party, Thai Citizen Party, Democrat Party,
Freedom and Justice Party, Nation and People Party, New
Force Party, National Democracy Party; other small parties
represented in parliament along with numerous
independents
Communists: strength of illegal Communist Party is about
1,200; Thai Communist insurgents throughout Thailand total
an estimated 9,000
Member of: ADB, ANRPC, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFAD,
1FC, IHO, ILO, IMCO, IMF, IPU, ITC, ITU, SEAMES, UN,
UNESCO, UPU, WHO, WMO, WTO; negotiations under-
way for membership in GATT','5c63da6224608a5caabfd25853164ccfb96fc94af425b2c07266d2ddcd2344fe','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76f2745de0b5812c748fd89c74ed0fcd659b369b11b5af21963538795d719833',1982,'MY','Malaysia','government',346,'Official name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed
by Paramount Ruler (King); a bicameral Parliament consist-
ing of a 58-member Senate and a 154-member House of
Representatives
Peninsular Malaysian states: hereditary rulers in all
but Penang and Malacca where Governors appointed by
Malaysian Government; powers of state governments limited
by federal constitution
Sabah: self-governing state within Malaysia in which it
holds 16 seats in House of Representatives; foreign affairs,
defense, internal security, and other powers delegated to
federal government
Sarawak: self-governing state within Malaysia in which
it holds 24 seats in House of Representatives; foreign affairs,
defense, and internal security, and other powers are delegat-
ed to federal government
Capital:
Peninsular Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and
Sarawak)
Legal system: based on English common law; constitution
came into force 1963; judicial review of legislative acts in the
Supreme Court at request of Supreme Head of the Feder-
ation; has not accepted compulsory ICJ jurisdiction
National holiday: 31 August
Branches: nine state rulers alternate as Paramount Ruler
for five-year terms; locus of executive power vested in Prime
Minister and Cabinet, who are responsible to bicameral
Parliament; following communal rioting in May 1969, gov-
ernment imposed state of emergency and suspended consti-
tutional rights of all parliamentary bodies; parliamentary
democracy resumed in February 1971
Peninsular Malaysia: executive branches of 11 states
vary in detail but are similar in design; a Chief Minister,
appointed by hereditary ruler or Governor, heads an execu-
tive council (cabinet) which is responsible to an elected,
unicameral legislature
Sarawak and Sabah: executive branch headed by
Governor appointed by central government, largely ceremo-
nial role; executive power exercised by Chief Minister who
heads parliamentary cabinet responsible to unicameral legis-
lature; judiciary part of Malaysian judicial system
Government leader: Prime Minister MAHATHIR bin
Mohamad
Suffrage: universal over age 20
Elections: minimum of every five years, last elections July
1978
Political parties and leaders:
Peninsular Malaysia: National Front, a confederation
of 11 political parties dominated by United Malay National
Organization (UMNO), Mahathir bin Mohamad; opposition
parties are Democratic Action Party (DAP) and Islamic
Party (PAS)
Sabah: Berjaya Party, Datuk Harris Salleh; United
Sabah National Organization (USNO), Tun Datuk Mustapha;
Sabah Chinese Consolidated Party (SCCP)
Sarawak: coalition Sarawak National Front composed
of the Party Pesaka Bumipatra Bersatu (PPBB), Datuk Amar
Taib; the United People''s Party (SUPP), Ong Kee Hui; and
the Sarawak National Party (SNAP), Stephen Ningkan
Voting strength:
Peninsular Malaysia: (1978 election) National Front,
131 of 154 seats in lower house of parliament; Democratic
Action Party, 16 seats; Islamic Party, 5 seats; Sarawak
People''s Organization, 1 seat; 1 independent seat
Sabah: (March 1981 Assembly Elections) Berjaya Party
controls 43 of 48 seats in State Assembly, USNO 3 seats,
SCCP 1 seat, 1 seat vacant
146
MALAYSIA (Continued)
Sarawak: (1979 elections) National Front controls 45 of
48 State Assembly seats
Communists:
Peninsular Malaysia: approximately 3,000 armed in-
surgents on Thailand side of Thai/Malaysia border; approxi-
mately 300 full-time inside Peninsular Malaysia
Sarawak: 125 armed insurgents in Sarawak
Sabah: insignificant
Member of: ADB, ANRPC, ASEAN, Colombo Plan,
Commonwealth, FAO, G-77, GATT, IAEA, IBRD, 1CAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ISCON, 1TC, ITU, NAM,
UN, UNESCO, UPU, WHO, WMO, WTO','6a6dcbb35aa77c8761749712f7e7a7303883afd8225eca797bba02ee896c0b7d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e7e14c7de4b13d26deec29c0bad44d9e65ddde228cb4a26c440f0aa84f0ca00',1982,'MV','Maldives','government',349,'Official name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts corre-
sponding to atolls
Legal system: based on Islamic law with admixtures of
English common law primarily in commercial matters; has
not accepted compulsory 1CJ jurisdiction
National holiday: 26 July, Independence Day
Branches: popularly elected unicameral national legisla-
ture (Majlis) (members elected for five-year terms); elected
148','7f3a56b24c7e2c56e1f5b1e7c9987a3ae9c88e1679f60f916fd40f91ef329c41','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff8009bf8ef7712de8fd76e9bf13f7148625595518af1617f8013f18839bec7e',1982,'ML','Mali','government',350,'MALDIVES (Continued)
President, chief executive; appointed Chief Justice responsi-
ble for administration of Islamic law
Government leader: President Maumoon Abdul
GAYOOM
Suffrage: universal over age 21
Political parties and leaders: no organized political par-
ties; country governed by the Didi clan for the past eight
centuries
Communists: negligible number
Member of: Colombo Plan, FAO, G-77, GATT (de facto),
IBRD, 1CAO, IDA, IFAD, IMCO, IMF, ITU, NAM, UN,
UPU, WHO, WMO
Official name: Republic of Mali
Type: republic; military regime in power since November
1968; fulfilled its plans in June 1979 for a phased return to
civilian rule
Capital: Bamako
Political subdivisions: 7 administrative regions; 42 ad-
ministrative districts (cercles), arrondissements, villages; all
subordinate to central government
Legal system: based on French civil law system and
customary law; constitution adopted 1974, came into full
effect in 1979; judicial review of legislative acts in Constitu-
tional Section of Court of State; has not accepted compulsory
ICJ jurisdiction
National holiday: Independence Day, 22 September
Branches: executive authority exercised by Military Com-
mittee of National Liberation (MCNL) composed of 11 army
149
MALI (Continued)
officers; under MCNL functional Cabinet composed of
civilians and army officers; judiciary
Government leaders: Brig. Gen, Moussa TRAORE, Presi-
dent of MCNL, Chief of State, and head of government
Suffrage: universal over age 21
Political parties and leaders: Democratic Union of Ma-
lian People (UDPM), is the sole political party under civilian
leadership
Elections: constitutional elections took place June 1979
Communists: a few Communists and some sympathizers
Member of; AFDB, A PC, CEAO, EGA, ECOWAS, FAO,
G-77, GATT (de facto), IAEA, IBRD, ICAO, IDA, IFAD,
IFC, ILO, IMF, ISCON, ITU, Niger River Commission,
NAM, OAU, OMVS (Organization for the Development of
the Senegal River Valley), UN, UNESCO, UPU, WHO,
WMO, WTO','403e82faf2a44a417a3f5ea1884ec42a1cd6949640e0854b4a2bc6ce83d623a1','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cdb5a589bc3f1b94ab6f58b15e2142f72d0b11bc3bfa625c537840bed241d65',1982,'MT','Malta','government',356,'Official name: Republic of Malta
Type: parliamentary democracy, independent republic
within the Commonwealth since December 1974
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta
and Gozo, divided into 13 electoral districts (divisions)
Legal system: based on English common law; constitution
adopted 1961, came into force 1964; has accepted compul-
sory ICJ jurisdiction, with reservations
Branches: executive, consisting of Prime Minister and
Cabinet; legislative, comprising 65-member House of Repre-
sentatives; independent judiciary
National holiday: Republic Day, 13 December
Government leaders: President Agatha BARBARA,
Prime Minister Dominic M1NTOFF
Suffrage: universal over age 18; registration required
Elections: at the discretion of the Prime Minister, but
must be held before the expiration of a five-year electoral
mandate; last election December 1981
Political parties and leaders: Nationalist Party, Edward
Fenech Adami; Malta Labor Party, Dominic Mintoff
Voting strength (1981 election): Labor, 34 seats (48%);
Nationalist, 31 seats (51%)
Communists: less than 100 (est.)
Member of: Commonwealth, Council of Europe, FAO,
G-77, GATT, 1CAO, 1FAD, ILO, IMCO, IMF, ITU, 1WC
(International Wheat Council), NAM, UN, UNDP,
UNESCO, UN1CEF, UPU, WHO, WIPO, WMO','042701eec3e9406b09dd9384c546ded237897510643dcdbeb81c7f23db1fa1ed','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76baa45ccf62d14756d31cf01290a66d28f505070f29ffcb5d1b545742cbb693',1982,'MU','Mauritius','government',361,'Official name: Mauritius
Type: independent state since 1968, recognizing Elizabeth
II as Chief of State
Capital: Port Louis
Political subdivisions: 5 organized municipalities and
various island dependencies
Legal system: based on French civil law system with
elements of English common law in certain areas; constitu-
tion adopted 6 March 1968
155
MAURITIUS (Continued)
National holiday: Independence Day, 12 March
Branches: executive power exercised by Prime Minister
and 21-man Council of Ministers; unicameral legislature
(National Assembly) with 62 members elected by direct
suffrage, 8 specially elected
Government leader: Prime Minister Dr. Seewoosagur
RAMGOOLAM
Suffrage: universal over age 18
Elections: legislative elections held in December 1976;
municipal elections held in 1977
Political parties and leaders: the government is presently
controlled by the Mauritian Labor Party (S. Ramgoolam) and
supported by several dissident members of the Mauritian
Social Democratic Party (G. Duval); the main opposition
parties are the Mauritian Militant Movement (P. Berenger)
and the Mauritian Socialist Party (H. Boodhoo); there are
also several minor parties
Voting strength: the Mauritian Labor Party, supported by
dissident members of the Mauritian Social Democratic Par-
ty, had a majority in the National Assembly before it was
dissolved in December 1981, in preparation for parliamen-
tary elections in 1982
Communists: may be 2,000 sympathizers; several Com-
munist organizations; Mauritius Lenin Youth Organization,
Mauritius Women''s Committee, Mauritius Communist Par-
ty, Mauritius People''s Progressive Party, Mauritius Young
Communist League, Mauritius Liberation Front, Chinese
Middle School Friendly Association, Mauritius/USSR
Friendship Society
Other political or pressure groups: various labor unions
Member of: Commonwealth, FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFAD, IFC, ILO, IMCO, IMF, ISO,
ITU, IWC— International Wheat Council, NAM, OAU,
OCAM, UN, UNESCO, UPU, WHO, WIPO, WMO, WTO','b8486dc0eb7b5094fd613d0ce562fe47d622c15211b5c895c9127fd8f7c4a52b','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f9b5256fbc850711b3c0e27c158abecafa321b205dc8e89837eb554c8659f06',1982,'MX','Mexico','government',365,'Official name: United Mexican States
Type: federal republic operating in fact under a central-
ized government
Capital: Mexico
Political subdivisions: 31 states and the Federal District
Legal system: mixture of US constitutional theory and
civil law system; constitution established in 1917; judicial
review of legislative acts; accepts compulsory 1CJ jurisdic-
tion, with reservations
National holiday: Independence Day, 16 September
Branches: dominant executive, bicameral legislature, Su-
preme Court
Government leader: President Jose LOPEZ PORT1LLO y
Pacheco
Suffrage: universal over age 18; compulsory but
unenforced
Elections: presidential election July 1982
Political parties and leaders: Institutional Revolutionary
Party (PR1), Pedro Ojeda Paullada; National Action Party
(PAN), Abel Vincencio Tovar; Popular Socialist Party (PPS),
Jorge Cruickshank Garcia; Authentic Party of the Revolution
(PARM), Jesus Guzmin Rubio; Mexican Democratic Party
(PDM), Gumersindo Magafia; Socialist Workers Party (PST),
Rafael Aguilar Talamantes; Social Democratic Party (SPD),
Ernesto Sanchez Aguilar; Revolutionary Pary of the Workers
(PRT), Rosario Ibarra de Piedra; Mexican People''s Party
(PPM), Alejandro Gascon Mercado; Socialist Revolutionary
Party (PSR), Roberto Jaramillo Gonzales; Mexican Workers
Party (PMT), Heberto Castillo; Socialist Action and Unity
Movement (MAUS), Miguel Velasco; Mexican Communist
Party (PCM), Arnoldo Martinez Verdugo; in November 1981
the PCM, MAUS, PPM, PSR, and the Popular Action
Movement (MAP) merged to form the United Socialist Party
of Mexico (PSUM)
Voting strength: 1979 congressional election: 69.8% PR1;
11% PAN; 5.1% PCM; 8.1% other opposition; 5.9% annulled
Other political or pressure groups: Roman Catholic
Church, Confederation of Mexican Workers (CTM), Confed-
eration of Industrial Chambers (CONCAM1N), Confederation
of National Chambers of Commerce (CONCANACO), Na-
tional Confederation of Campesinos (CNC), National Confed-
eration of Popular Organizations (CNOP), Revolutionary Con-
federation of Workers and Peasants (CROC)
Member of: FAO, G-77, 1ADB, IAEA, IBRD, 1CAC,
1CAO, ICO, IDA, 1DB, 1FAD, 1FC, 1LO, International Lead
and Zinc Study Group, IMCO, IMF, ISO, ITU, 1WC—
International Whaling Commission, LAFTA, NAMUCAR
(Caribbean Multinational Shipping Line — Naviera Multina-
cional del Caribe), OAS, SELA, UN, UNESCO, UPU, WHO,
WIPO, WMO, WSG, WTO','8a095594cba2b957e1754d942243d1a8dfd011c9c0fcfcecc9270f3380a523a0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41de339e4c694dd4259c375bda9cbfb7835c0db39f91ca3908dbb109323e5af',1982,'MC','Monaco','government',370,'Official name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution
adopted 1962; has not accepted compulsory ICJ jurisdiction
National holiday: 19 November
Branches: National Council (18 members); Communal
Council (15 members, headed by a mayor)
Government leader: Prince RAINIER III
Suffrage: universal
Elections: National Council every five years; most recent
1978
Political parties and leaders: National Democratic En-
tente, Democratic Union Movement, Monegasque Actionist
(1973)
Voting strength: figures for 1978: National Democratic
Entente, 18 seats
158','03857b68db6e7081e895d1f73568276ac709187ea2a1a8c3b95ac8522f9b5db7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ab2d6faba15f42e2c076453451668618f3e483118e611e564e0b1e45205d344',1982,'MN','Mongolia','government',371,'MONACO (Continued)
Member of: IAEA, IHO, IPU, ITU, UN (permanent
observer), UNESCO, UPU, WHO, WIPO
Official name: Mongolian People''s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous
municipalities (Ulaanbaatar and Darhan)
Legal system: blend of Russian, Chinese, and Turkish
systems of law; new constitution adopted 1960; no constitu-
tional provision for judicial review of legislative acts; legal
education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
National holiday: Peoples Revolution Day, 11 July
Branches: constitution provides for a People''s Great
Hural (national assembly) and a highly centralized
administration
159','fb60b22d090c31ba15c7b41e3280233313bb04ff5bace66ffbb3bbe86d5e16ba','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79798f53a5bf6377f2139f0b3ec2b43d0ea9ba13dafd0eaace48f902776e1933',1982,'MA','Morocco','government',375,'MONGOLIA (Continued)
Party and government leaders: Yumjaagiyn Tsedenbal,
First Secretary of the MPRP and Chairman of the Presidium
of the People''s Great Hural; Jambyn Batmonh, Chairman of
the Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections theoretically held
every four years; last election held June 1977
Political party; Mongolian People''s Revolutionary (Com-
munist) Party (MPRP); estimated membership, 67,000 (1976)
Member of: CEMA, ESCAP, FAO, IAEA, 1LO, IPU, ITU,
UN, UNESCO, UPU, WHO, W1PO, WMO
Official name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted 1972)
Capital: Rabat
Political subdivisions: 39 provinces (including 4 in West-
ern Sahara) and 2 prefectures (Rabat-Sale and Casablanca,
which consists of 5 divisions)
NOTE: Morocco acquired administrative control in 1976
over the northern two-thirds of the former Spanish Sahara
160
MOROCCO (Continued)
under an agreement with Mauritania, but the legal question
of sovereignty over the area has yet to be determined.
Spain''s role as coadministrator of the disputed territory
ended in February 1976. Morocco moved to occupy and
assert administrative control over the former Mauritanian-
claimed (southern) sector of Western Sahara in August 1979,
thereby establishing a fourth additional province in the
Sahara.
Legal system: based on Islamic law and French and
Spanish civil law system; judicial review of legislative acts in
Constitutional Chamber of Supreme Court; modern legal
education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 18 November
Branches: constitution provides for Prime Minister and
ministers named by and responsible to King; King has
paramount executive powers; unicameral legislature two-
thirds directly elected, one-third indirectly; judiciary inde-
pendent of other branches
Government leaders: King HASSAN II; Prime Minister
Maati BOUABID
Suffrage: universal over age 20
Elections: local elections held 12 November 1976; provin-
cial elections held 25 January 1977; elections for new
National Assembly provided for in Constitution adopted 15
March 1972 were held June 1977
Political parties and leaders: lstiqlal Party, M''Hamed
Boucetta; Socialist Union of Popular Forces (USFP), Abder-
rahim Bouabid; Popular Movement (MP), Mahjoubi Aher-
dan; Constitutional and Democratic Popular Movement
(MPCD), Dr. Abdelkrim Khatib; National Union of Popular
Forces (UNFP), Abdallah Ibrahim and Mahjoub Ben Seddik;
National Assembly of Independents (RNI) formed in Octo-
ber 1978 is progovernment grouping of previously unaffiliat-
ed deputies in parliament, Ahmed Osman; Independent
Democrats (DI), Mohamed Arsalan Jadidi, a splinter group
from the RNI formed July 1981; Democratic Constitutional
Party (PDC), Mohamed Hassan Ouazzani; Party for Progress
and Socialism (PPS), legalized in August 1974, is front for
Moroccan Communist Party (MCP), which was proscribed in
1959, Ali Yata
Voting strength: progovernment independents hold abso-
lute majority in Chamber of Representatives; with palace-
oriented Popular Movement deputies, the King controls over
two-thirds of the seats
Communists: 300 est.
Member of: AFDB, Arab League, EC (association until
1974), FAO, G-77, GATT, IAEA, IBRD, ICAO, IDA, IFAD,
IFC, ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, IPU, ISCON, ITU, NAM, OAU, UN,
UNESCO, UPU, WHO, WIPO, WMO, WTO','ff747d0c16b99613bc5811592d7a52497839f7076b206fbc86eec97c1340dba6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21bbea5c70b3b498fd78aa4b60a3c0ad105957ab48bd9714904cc692e7999105',1982,'MZ','Mozambique','government',381,'Official name: People''s Republic of Mozambique
Type: "people''s republic"; achieved independence from
Portugal in June 1975
Capital: Maputo
Political subdivisions: 10 provinces subdivided into about
94 districts; administrators are appointed by central
Legal system: based on Portuguese civil law system and
customary law
National holiday: Independence Day, 25 June
Branches: none established
Government leader: President Samora Moises MACHEL
Suffrage: not yet established
Elections: information not available on future election
schedule
Political parties and leaders: the Mozambique Liberation
Front (FRELIMO), led by Samora Machel, is only legal party
Communists: none known
Member of: FAO, G-77, GATT (de facto), ICAO, IFAD,
IFC, ILO, IMCO, ITU, NAM, OAU, UN, UNESCO, UPU,
WHO, WMO','ebc9cf3177465ecf6bde08cee20ff87b53cb887bfe9cc3a29be5b79e9272cbfc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a430312c3ae00636cd237bd070488c2a46de508995609c10e5a23ef720e5d6dc',1982,'NA','Namibia','government',385,'Official name: Namibia
Type: former German colony of South-West Africa man-
dated to South Africa by League of Nations in 1920; UN
formally ended South Africa''s mandate on 27 October 1966,
but South Africa has retained administrative control
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly in
northern sector, and zone open to white settlement, with
administrative subdivisions similar to a province of South
Africa
Legal system: based on Roman-Dutch law and customary
law
Branches: since September 1977 Administrator-General,
appointed by South African Government, has exercised
coordinative functions over zone of white settlement and
tribal homelands, where traditional chiefs and representative
bodies exercise limited autonomy; Namibian National As-
sembly, elected December 1978, has been granted legislative
powers, subject to Administrator-General''s veto; a Ministers''
Council, composed of members of the National Assembly
and with limited executive powers, established July 1980
Government leader: Danie HOUGH, Administrator-
General
Suffrage: several tribal homelands have adult franchise
for homeland legislatures; all ethnic groups were eligible to
vote in 1978 election for Namibian National Assembly
Elections: election of Namibian National Assembly, De-
cember 1978
Political parties and leaders: there are approximately 50
political parties in Namibia; the major parties include (white
parties) — Action Front for the Preservation of the Turnhalle
Principles (AKTUR), also known as the National Party of South-
West Africa, Kosie Pretorius; Federal Party, Bryan O''Linn;
Republican Party, Dirk Mudge; many of the nonwhite parties
belong to the Democratic Turnhalle Alliance (DTA), a mul-
tiethnic alliance of traditional tribal leaders and the white
Republican Party, which is favored in South Africa; the other
multiethnic alliance, the Namibian National Front (NNF), the
white Federal Party, and nonwhite groups opposed to the
homeland system, operates independently; South-West Africa
People''s Organization Democrats (SWAPO-D), a predominant-
ly Ovambo party led by Andreas Shipanga, broke away from
Sam Nujoma''s SWAPO and is loosely affiliated with NNF
Voting strength: (1978 election) DTA won 41 seats in
Namibian National Assembly; AKTUR, 6 seats; 3 miniscule
parties, 1 seat each; NNF, SWAPO, and SWAPO-D boycot-
ted elections; 15 additional, appointed seats have not been
filled
Communists: no Communist Party, SWAPO guerrilla
force is supported by USSR, Cuba, and other Communist
states as well as OAU
Other political or pressure groups: South-West Africa
People''s Organization (SWAPO), led by Sam Nujoma, main-
tains a foreign-based guerrilla movement; is predominantly
Ovambo but has some influence among other tribes; is the
only Namibian group recognized by the UN General Assem-
bly and the Organization of African Unity','9c0291132c6881e76d1d0bb295832f6a6f0059f4622b819ea57e67528f83215e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('324fb5f4d1fcbb5906225ab04ed1393c31e8aa113c4e8c9ec6e8cbbd0e35afed',1982,'NR','Nauru','government',390,'Official name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in
Yaren District
Political subdivisions: 14 districts
Branches: president elected from and by Parliament for
an unfixed term; popularly elected 18-member unicameral
legislature, the Parliament; Cabinet to assist the President,
four members, appointed by President from Parliament
members
Government leader: President Hammer DEROBURT
Suffrage: universal adult
Elections: last held in December 1980
Political parties and leaders: governing faction, Presi-
dent DeRoburt; opposition Nauru Party, Lagumot Harris
164','4e4b032740bfb9e804691b12211172d613c559552e686146651ff593f7a4b06d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12b55ec78bfd5aaf41276ca367d6b7e6442b6da66d78ae455efd9e7c5282fa1a',1982,'NP','Nepal','government',391,'NAURU (Continued)
Member of: no present plans to join UN; enjoys "special
membership" in Commonwealth; South Pacific Commission,
ESCAP, INTERPOL, ITU, UPU
Official name: Kingdom of Nepal
Type: nominally a constitutional monarchy; King Biren-
dra exercises autocratic control over multitiered panchayat
system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English
common law; legal education at Nepal Law College in
Kathmandu; has not accepted compulsory ICJ jurisdiction
National holiday: Birthday of the King, 28 December
165
NEPAL (Continued)
Branches: Council of Ministers appointed by the King;
directly elected National Panchayat (Assembly)
Government leaders: King BIRENDRA Bir Bikram Shah
Dev; Prime Minister Surya Bahadur THAPA
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected
by universal suffrage; district panchayat members are indi-
rectly elected; a constitutional amendment in 1980 provided
for direct elections to the National Panchayat, which consists
of 140 members (including 28 members appointed by the
King), who serve five-year terms; Nepal''s first general
election in 22 years was held in May 1981
Political parties and leaders: all political parties
outlawed
Communists: the two wings of the Communist Party of
Nepal (CPN) — pro-Soviet and pro-Chinese — are split into
several lesser factions; the combined membership is about
6,500, with the majority (perhaps 5,000) in the pro-Chinese
wing; the CPN continues to operate more or less openly;
internal dissension, however, greatly hinders its effectiveness
Other political or pressure groups: proscribed Nepali
Congress Party led by B. P. Koirala
Member of: ADB, Colombo Plan, FAO, G-77, IBRD,
ICAO, IDA, IFAD, IFC, ILO, IMCO, IMF, IPU, ITU,
NAM, UN, UNESCO, UPU, WHO, WMO, WTO','d5fa5967693dc88c82cb098eaef8bc7b2129c82334b67caee22c42b473cfcc84','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afae52bfe5bfcd109357058ace187d68d7ef0ac53b358ee2ae93f083f369c966',1982,'NL','Netherlands','government',397,'Official name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The
Hague
Political subdivisions: 11 provinces governed by centrally
appointed commissioners of Queen
Legal system: civil law system incorporating French penal
theory; constitution of 1815 frequently amended, reissued 1947;
judicial review in the Supreme Court of legislation of lower
order than Acts of Parliament; legal education at six law schools;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Queen *s Day, 30 April
Branches: executive (Queen and Cabinet of Ministers),
which is responsible to bicameral States General (parliament)
consisting of a First Chamber (75 indirectly elected mem-
bers) and a Second Chamber (150 directly elected members);
independent judiciary
Government leaders: Head of State, Queen BEATRIX;
Prime Minister, Andreas A. M. VAN AGT
Suffrage: universal over age 18
Elections: must be held at least every four years for lower
house (most recent held 26 May 1981), and every three years
for half of upper house (most recent May 1981)
Political parties and leaders: Christian Democratic Ap-
peal (CDA; fused into a single party as of 11 October 1980),
Chairman Pieter Bukman; Labor (PvdA), Max van den Berg;
Liberal (WD), Jan Kamminga; Democrats ''66 (D''66), J. M.
M. van Berkom; Communist (CPN), Henk Hoekstra; Pacifist
Socialist (PSP), Bram van der Lek; Political Reformed (SGP),
Hette G. Abma; Reformed Political Union (GPV), Jan van
der Jagt; Radical Party (PPR), Herman Verbeek; Democratic
Socialist 70 (DS''70), Z. Hartog; Rightist Peoples Party (RVP),
Hendrik Koekoek; Reformed Political Federation (RPF), P.
Lamgeler
Voting strength (1981 election): 28.3% PvdA (44 seats),
30.8% CDA (48 seats), 17.3% WD (28 seats), 11.1% D''66 (17
seats), 2.0% SGP (3 seats), 2.]% CPN (2 seats), 2.0% PPR (3
seats), 0.8% GPV (1 seat), 2.1% PSP (1 seat), 0.2% RPF (2
seats), 0.6% DS''70 (1 seat)
Communists: CPN claims about 27,000 members
Other political or pressure groups: large multinational
firms; Federation of Netherlands Trade Union Movement
(comprising Socialist and Catholic trade unions) and a
Protestant trade union; Federation of Catholic and Protes-
tant Employers Associations; the nondenominational Feder-
ation of Netherlands Enterprises; and IKV — Interchurch
Peace Council
Member of: ADB, Benelux, Council of Europe, DAC, EC,
ECE, EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA,
IFAD, IFC, IHO, ILO, IMCO, IMF, INRO, International
Lead and Zinc Study Group, IPU, ITC, ITU, IWC—
International Wheat Council (with respect to interests of the
Netherlands Antilles and Suriname), NATO, OAS (observer),
OECD, UN, UNESCO, UPU, WEU, WHO, WIPO, WMO,
WSG
Official name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands, en-
joying complete domestic autonomy
Capital: Willemstad, Curacao
Political subdivisions: four island territories — Aruba,
Bonaire, Curacao, and the Windward Islands — St. Eustatius,
southern part of St. Martin (northern part is French), Saba
Legal system: based on Dutch civil law system, with some
English common law influence; constitution adopted 1954
Branches: federal executive power rests nominally with
Governor (appointed by the Crown), actual power exercised
by eight-member Council of Ministers or cabinet presided
over by Minister-President; legislative power rests with
22-member Legislative Council; independent court system
under control of Chief Justice of Supreme Court of Justice
(administrative functions under Minister of Justice); each
island territory has island council headed by Lieutenant
Governor
Government leaders: Prime Minister Domenico Felip
MARTINA (leader of Movement for a New Antilles) won
election on 6 July 1979; Governor Bernardito M. LEITO; in
September 1981 Aruba *s People''s Electoral Party (MEP), led
by Gilberto "Betico" Croes, pulled out of the governing
coalition demanding independence; talks are being held with
the Netherlands on the future status of the Antilles
Suffrage: universal age 18 and over
Elections: Federal elections mandatorily held every four
years, last regular held 17 June 1977 (early elections were
held 6 July 1979); island council elections every 4 years, last
held 25 April 1979
Political parties and leaders: political parties are indig-
enous to each island:
Curacao: Movement for a New Antilles (MAN), Do-
menico Felip Martina; Democratic Party (DP), S. G. M.
Rozendal; National People''s Party-United (NVP-U) Edsel
Jenerun; Frente Obrero de Liberation'' 30 di Mayo (FOL),
Wilson "Papa" Godett; Social Democratic Party (PSD), R. J.
Isa
Aruba: People''s Electoral Movement (MEP), G. F.
"Betico" Croes; Aruban Patriotic Party (PPA), L. O. Chance;
Aruban People''s Party (A VP), D. G. Croes
Bonaire: Labor Party (POB); Democratic Party Bonaire
(UPB); New Democratic Action (ADEN)
Windward Islands: Windward Islands Democratic
Party (DPWI); United Federation of Antillean Workers
(UFA); Windward Islands Political Movement (W1PM); and
others
Voting strength: (1977 federal election) 6 seats DP, 5 seats
MEP, 3 seats FOL, 3 seats NVP, 3 seats PPA, 1 seat DPWI, 1
seat UPB
Communists: no Communist party
Member of: EC (associate), FAO, GATT, IAEA, IBRD,
1CAO, IDA, IFAD, IFC, ILO, 1MCO, IMF, ITU, UN,
UNESCO, UPU, WHO, W1PO, WMO','33b032bfaa8eaffb115c371758cfbeade675ee5b75f9125254330f496613026f','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5818ae4a4a637910187ed4f6c148c4644e189e9ce7d658e17f26adb7f5b3f476',1982,'NC','New Caledonia','government',402,'Official name: Territory of New Caledonia and
Dependencies
Type: French overseas territory; represented in French
parliament by one deputy and one senator
Capital: Noumea
Political subdivisions: 4 islands or island group depen-
dencies— Isle of Pines, Loyalty Islands, Huon Islands, Island
of New Caledonia
Legal system: French law
Branches: administered by High Commissioner, responsi-
ble to French Ministry for Overseas France and Governing
Council; Assemblee Territoriale
170','dd2726c0e561050f8cfa72de99d8cd8178ff6bfbd7d0a04167d2ff2c770053e8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4669283ed764c2cfd01eff21c38d0757f7e4a4373c75d8ba24d63252457e6f7',1982,'NZ','New Zealand','government',403,'NEW CALEDONIA (Continued)
Government leader: Claude CHARBONNIAUD, French
High Commissioner and President of the Council of
Suffrage: universal
Elections: Assembly elections every five years, last in
September 1977
Political parties: Rassemblement pour la Caledonie —
Conservative; Union Caledonienne — eventual independ-
ence; Union Multiraciale and Palika — independence parties
Voting strength (1977 election): Rassemblement pour la
Caledonie, 12 seats; Union Caledonienne, 9 seats; Palika, 2
seats; 8 other parties divide up remaining 12 seats
Communists: number unknown; Union Caledonienne
strongly leftist; some politically active Communists were
deported during 1950s; small number of North Vietnamese
Other political parties and pressure groups: several
lesser parties
Member of: EIB (associate)
Official name: New Zealand
Type: independent state within Commonwealth, recogniz-
ing Elizabeth II as head of state
Capital: Wellington
Political subdivisions: 239 territorial units (boroughs,
counties, town and district councils); 657 special-purpose
bodies
Legal system: based on English law, with special land
legislation and land courts for Maoris; constitution consists of
171
NEW ZEALAND (Continued)
various documents, including certain acts of the UK and
New Zealand Parliaments; legal education at Victoria, Auck-
land, Canterbury, and Otago Universities; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: Waitangi Day, 6 February
Branches: unicameral legislature (House of Representa-
tives, commonly called Parliament); Cabinet responsible to
Parliament; three-level court system (magistrates, courts,
Supreme Court, and Court of Appeal)
Government leader: Prime Minister Robert D.
MULDOON
Suffrage: universal age 18 and over
Elections: held at three-year intervals or sooner if parlia-
ment is dissolved by Prime Minister; last election November
1981
Political parties and leaders: National Party (Govern-
ment), Robert D. Muldoon; Labor Party (Opposition), Wal-
lace E. Rowling; Social Credit Political League, Bruce
Beetham; Communist Party of New Zealand (Marxist-
Leninist; pro-Albania), Richard C. Wolfe; Socialist Unity
Party (pro-Soviet), G. H. (Bill) Andersen
Voting strength (1981 election): National Party 47 seats,
Labor Party 43 seats, Social Credit 2 seats
Communists: CPNZ about 300, SUP about 100
Member of: ADB, ANZUS, ASPAC, Colombo Plan, Com-
monwealth of Nations, DAC, ESCAP, FAO, GATT, IAEA,
IBRD, ICAO, ICO, IDA, IEA, IFAD, IFC, IHO, 1LO,
IMCO, IMF, 1PU, ISO, ITU, OECD, UN, UNESCO, UPU,
WHO, WMO, WSG','0eb48760a0b7410ebd0586cdc544f34f16d93e796a5cc32e3169be942097c0ed','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc765894559c9f72bae2ff4500cae0130145b40d9f77cb5567b3947a94f5703a',1982,'NI','Nicaragua','government',410,'Official name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: 1 national district and 16
departments
Legal system: the Sandinista-appointed Government of
National Reconstruction revoked the constitution of 1974
and issued a Fundamental Statute and a Program of the
Government of National Reconstruction to guide its actions
until a new constitution is drafted
National holiday: Independence Day, 15 September
Branches: executive and administrative responsibility for-
mally reside in the three-member junta of the Government
of National Reconstruction; in reality, the junta shares power
with, and in fact is dominated by, the nine-member Sandin-
ista National Directorate; a 51-member quasi-legislative
Council of State was established in May 1980; the country''s
highest judicial authority is the junta-appointed Supreme
Court, comprised of six members
Government leader: Coordinator of the Junta Daniel
ORTEGA Saavedra often acts as government leader on
official occasions
Elections: the Sandinistas announced in August 1980 that
neither national nor municipal elections would be held until
1985
Political parties and leaders: all political parties except
those favoring a return to Somozaism are permitted to
function; only the Liberal Party, because of its ties to the
Somoza family, has been specifically banned; among the
parties that have been active under the new government are
the Nicaraguan Democratic Movement (Alfonso Robelo), the
Social Democratic Party (Wilfredo Montalvan), the Social
Christian Party (Adan Fletes), and the Democratic Conserva-
tive Party (Emilio Alvarez Montalvan); the Sandinistas have
made major strides toward developing a grassroots party
apparatus and have formalized their alliance with other
leftist parties by creating the Revolutionary Patriotic Front
Communists: the Nicaraguan Socialist Party (PSN),
founded in 1944, has served as Nicaragua''s Moscow-line
Communist party; it is allied with the Sandinistas; the
Nicaraguan Communist Party (Eli Altamirano) — formed in
1967 when it broke with the PSN, splinter Trotskyite and
Maoist groups, including the Workers Front and the Move-
ment for Popular Action — have all been viewed as oppo-
nents by the Sandinista National Liberation Front (FSLN)
Other political or pressure groups: the Superior Council
of Private Enterprise (COSEP) is an umbrella group compris-
ing 11 different chambers of associations, including such
groups as the Chamber of Commerce, the Chamber of
Industry, and the Nicaraguan Institute of Development
173
NICARAGUA (Continued)
Member of: CACM, FAO, G-77, GATT, IADB, IAEA,
IBRD, ICAC. ICAO, ICO, IDA, IDB. IFAD, IFC ILO, IMF,
INTELSAT, IPU, ISO, ITU, NAM, NAMUCAR (Caribbean
Multinational Shipping Line — Naviera national del Cartbel
OAS, ODECA, SELA, UN, UNESCO, UPEB, UPU, WHO,
WMO, WTO','53c5661f0857a4ed694a321a79cc14e11457786a6941304095b5956b2c7197e8','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d36c020c56e2f4c5e487d30644ada71b2707ef5b6a21be5cd8831269b11f8a1c',1982,'NE','Niger','government',415,'Official name: Republic of Niger
Type: republic; military regime in power since April 1974
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and
customary law; constitution adopted 1960, suspended 1974;
judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory 1CJ
jurisdiction
National holiday: Proclamation of the Republic, 18
December
Branches: executive authority exercised by Supreme Mili-
tary Council (SMC) composed of army officers; Cabinet
includes some civilian technocrats
Government leader: Lt. Col. Seyni KOUNTCHE, Presi-
dent of Supreme Military Council, Chief of State, Minister
of Defense, and Minister of Interior
Suffrage: suspended
Elections: political activity banned
Political parties and leaders: political parties banned
Communists: no Communist party; some sympathizers in
outlawed Sawaba party
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, 1FAD, IFC, 1LO, IMF, IPU, 1SCON, ITU, Lake
Chad Basin Commission, Niger River Commission, NAM,
OAU, OCAM, UN, UNESCO, UPU, WHO, WIPO, WMO','3b70cfd9e178dae1675c605668b7bc30823449c74b13e5de986e3ab0e1e317d4','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('846bd88db8cf55400c00854855742a3120371eedcd053a5f76861166f3acffe6',1982,'NO','Norway','government',419,'Official name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 19 counties, 2 territories, 404
communes, 47 towns
Legal system: mixture of customary law, civil law system,
and common law traditions; constitution adopted 1814,
modified 1884; Supreme Court renders advisory opinions to
legislature when asked; legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Constitution Day, 17 May
Branches: legislative authority rests jointly with Crown
and parliament (Storting); executive power vested in Crown
but exercised by cabinet responsible to parliament; Supreme
Court, 5 superior courts, 104 lower courts
Government leaders: King OLAV V; Prime Minister
Kare WILLOCH
Suffrage: universal, but not compulsory, over age 20
Elections: held every four years (next in 1985)
Political parties and leaders: Labor, Gro Harlem Brundt-
land; Conservative, Jo Benkow; Center, Johan J. Jakobsen;
Christian People''s, Kare Kristiansen; Liberal, Odd Einar
Dorum; Socialist Left, Berge Furre; Norwegian Communist,
Hans I. Kleven; Progressive, Carl I. Hagen
Voting strength (1981 election): Labor, 37.3%; Conserva-
tive, 31.6%; Christian People''s, 9.3%; Center, 6.7%; Socialist
Left (Socialist Electoral Alliance, formerly antitax), 4.9%;
Liberal, 3.9%; Progressive, 4.5%; Norwegian Communist,
0.3%; Red Electoral Alliance, 0.7%; Liberal People''s Party
(antitax), 0.6%
Communists: 2,500 est.; a number of sympathizers as
indicated by the 24,618 votes cast in the 1981 election for
the Norwegian Communist Party and the Red Electoral
Alliance
Member of: ADB, Council of Europe, DAC, EC (Free
Trade Agreement), EFTA, ESRO (observer), FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA (associate
member), IFAD, IFC, IHO, ILO, International Lead and
Zinc Study Group, IMCO, IMF, IPU, ITU, IWC— Interna-
tional Whaling Commission, IWC — International Wheat
Council, NATO, Nordic Council, OECD, UN, UNESCO,
UPU, WHO, WIPO, WMO, WSG
Official name: United Kingdom of Great Britain and
Northern Ireland
Type: constitutional monarchy
Capital: London
Political subdivisions: 635 parliamentary constituencies
Legal system: common law tradition with early Roman
and modern continental influences; no judicial review of
Acts of Parliament; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: celebration of birthday of the Queen,
16 June
Branches: legislative authority resides in Parliament; ex-
ecutive authority lies with collectively responsible Cabinet
led by Prime Minister; House of Lords is supreme judicial
authority and highest court of appeal
Government leader: Chief of State, Queen ELIZABETH
II; Head of Government, Prime Minister Margaret
THATCHER
Suffrage: universal over age 18
Elections: at discretion of Prime Minister, but must be
held before expiration of a five-year electoral mandate; last
election 3 May 1979
Political parties and leaders: Conservative, Margaret
Thatcher; Labor, Michael Foot; Liberal, David Steel; Social
Democratic, joint leadership at present; Communist, Gordan
McLennan; Scottish National, Gordon Wilson; Plaid Cymru,
Dafydd Wigley
Voting strength: (1979 election) Conservative 339 seats
(43.9%), Labor 268 seats (36.9%), Liberal 11 seats (13.8%),
Scottish''National 2 seats (1.6%), Plaid Cymru 2 seats (0.4%),
other 13 seats (2.8%); (1981 byelections) Conservative 336
seats, Labor 250 seats, Liberal 12 seats, Social Democratic 28
seats, Scottish National 2 seats, Plaid Cymru 2 seats, others
13 seats
Communists: 29,000
Other political or pressure groups: Trades Union Con-
gress, Confederation of British Industry, National Farmers*
Union, Campaign for Nuclear Disarmament
Member of: ADB, CENTO, Colombo Plan, Council of
Europe, DAC, EC, EEC, ELDO, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA,
IFAD, IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IOOC, IPU, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC — International
Wheat Council, NATO, OECD, UN, UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG','421321908dea1bd0a44f64ecb927491807c9c328382af80109dd3d977921ae6a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5b1defa3c6720965834d1008f95a340e39bd7c5c235af49b9e76b799c24bd58',1982,'OM','Oman','government',423,'Official name: Sultanate of Oman
Type: absolute monarchy; independent, with strong resid-
ual UK influence
Capital: Muscat
Political subdivisions: 1 province (Dhofar), 9 regions, and
numerous districts (wilayats)
Legal system: based on English common law and Islamic
law; no constitution; ultimate appeal to the Sultan; has not
accepted compulsory 1CJ jurisdiction
National holiday: 18 November
Government leader: Sultan Qaboos bin SAID (Al Bu Said)
Other political or pressure groups: outlawed Popular
Front for the Liberation of Oman (PFLO), based in South','28041184150c7640f7c337b8071e7391ee66964c27fa00d10c13a0bee99ff2a6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe13938e0ba69d25d31d57d3471118445a6325f5c437fa1435fc629c683bd759',1982,'PK','Pakistan','government',424,'OMAN (Continued)
Member of: Arab League, FAO, G-77, GCC, IBRD,
ICAO, IDA, IFAD, IFC, IMCO, IMF, ISCON, ITU, NAM,
UN, UNESCO, UPU, WHO, WMO','cba2c68ea652a7fc34581a1ef2d547d05a12a960683c729e6ed9f62a720de7af','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15caedcdcabda44bb999f118142b329d029a744a746c7556c9c06cefe774730a',1982,'PA','Panama','government',429,'Official name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 intendancy
Legal system: based on civil law system; constitution
adopted in 1972; judicial review of legislative acts in the
Supreme Court; legal education at University of Panama;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Independence Day, 3 November
Branches: President and Vice President, elected by Na-
tional Assembly; popularly elected unicameral legislature,
National Assembly of Community (Corregimiento) Repre-
sentatives; legislative powers currently exercised in the main
by National Council on Legislation, but constitutional
amendments, approved in October 1978, give somewhat
broader role to National Assembly; presidentially appointed
Supreme Court subject to Corregimiento review under new
constitutional amendment
Government leaders: Aristides ROYO is constitutional
President and Chief of State, but remains accountable to the
National Guard General Staff
Suffrage: universal and compulsory over age 18
Elections: elections for National Assembly in August
1978, Assembly chose President and Vice President in
October 1978; constitutional reforms allow Assembly to elect
from its own membership representatives comprising two-
thirds of the primary legislative organ, the National Council
on Legislation; the remaining one-third of the Council''s 56
representatives was chosen in September 1980 by direct
popular elections; direct popular elections for President and
Vice President and the Assembly will be held in 1984
Political parties and leaders: legislation providing for
legalization of political parties, which were suspended fol-
lowing 1968 Torrijos coup, approved October 1978; since
early 1979, all political parties and groups have been allowed
to organize under new democratization program; Revolu-
tionary Democratic Party (PRD; official government party),
Gerardo Gonzalez; Communist People''s Party (PdP; pro-
government), Ruben Darto Souza; Liberal Party (PL; opposi-
tion), Arnulfo Escalona; Christian Democratic Party (PDC;
opposition), Guillermo Cochez; Panamenista Party (PP; op-
position), Arnulfo Arias
Voting strength: only two progovernment and two small
opposition parties registered candidates for 1980 legislative
elections; half the candidates ran as independents
Communists: 500 active and several hundred inactive
members People''s Party (PdP); 1,500 members and sympathiz-
ers of rival Fraccion movement which split from PdP in 1974
Other political or pressure groups: National Council of
Private Enterprise (CONEP); Panamanian Association of
Business Executives (APEDE)
Member of: FAO, G-77, 1ADB, IAEA, IBRD, 1CAO, ICO,
IDA, IFAD, 1DB, IFC, ILO, IMCO, IMF, ITU, 1WC—
International Whaling Commission, 1WC — International
Wheat Council, NAM, OAS, SELA, UN, UNESCO, UPEB,
UPU, WHO, WMO, WTO
182
PANAMA (Continued)','c0d9bb84e3bf902de2eaf77cd8d4fad9595b6ef2d2dab283388048ec3b5386ca','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82799f1d3cc916068b5090a81c2d81c8c18a2ceb35d3cfa0cb7c7cf41d2da4d8',1982,'PG','Papua New Guinea','government',433,'Official name: Papua New Guinea
Type: independent parliamentary state within Common-
wealth recognizing Elizabeth II as head of state
Capital: Port Moresby
Political subdivisions: 19 administrative districts (15 in
New Guinea, 4 in Papua)
Legal system: based on English common law
National holiday: Independence Day, 16 September
Branches: executive — National Executive Council; legis-
lature— House of Assembly (109 members); judiciary — court
system consists of Supreme Court of Papua New Guinea and
various inferior courts (district courts, local courts, children''s
courts, wardens'' courts)
Government leaders: Governor General Sir Tore LOKO-
LOKO; Prime Minister Sir Julius CHAN
Suffrage: universal adult suffrage
Elections: preferential-type elections for 109-member
House of Assembly every five years, next held in June 1982
Political parties: Pangu Party, People''s Progress Party,
United Party, Papua Besena, National Party, Melanesian
Alliance
Communists: no significant strength
Member of: ADB, CIPEC (associate), Commonwealth,
ESCAP (associate), FAO, G-77, GATT (de facto), IBRD,
ICAO, IDA, IFAD, IFC, ILO, IMCO, IMF, ITU, South
Pacific Commission, South Pacific Forum, UN, UNESCO,
UPU, WHO, WMO (associate)','bb24a14f730e23e07cbb4acd76dc84249786f97cefdb04d6c6e34e9b97540d59','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aab1e3ec95c41ca5c0a18c6c3461e618804b53703680b0145a5a873f2db22145',1982,'PY','Paraguay','government',437,'Official name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 19 departments and the national
capital
Legal system: based on Argentine codes, Roman law, and
French codes; constitution promulgated 1967; judicial re-
view of legislative acts in Supreme Court; legal education at
National University of Asuncion and Catholic University of
Our Lady of the Assumption; does not accept compulsory
1CJ jurisdiction
National holiday: Independence Day, 14 May
Branches: President heads executive; bicameral legisla-
ture; judiciary headed by Supreme Court
Government leader: President Gen. Alfredo STROESS-
NER
185
PARAGUAY (Continued)
Fiscal year: calendar year
Suffrage; universal; compulsory between ages of 18-60
Elections: President and Congress elected together every
five years; last election held in February 1978
Political parties and leaders: Colorado Party, Juan Ra-
mon Chavez; Liberal Party, Fulvio Hugo Celauro; Febrer-
ista Party, Alarico Quinones Cabral; Radical Liberal Party,
German Acosta Caballero; Christian Democratic Party, R6-
mulo Perina
Voting strength (February 1978 general election): 90%
Colorado Party, 5% Radical Liberal Party, 3% Liberal Party,
Febrerista Party boycotted elections
Communists: Oscar Creydt faction and Miguel Angel
Soler faction (both illegal); est. 3,000 to 4,000 party members
and sympathizers in Paraguay, very few are hard core; party
in exile is small and deeply divided
Other political or pressure groups: Popular Colorado
Movement (MoPoCo) led by Epifanio Mendez, in exile;
National Accord includes MoPoCo and Febrerista, Radical
Liberal, and Christian Democratic Parties
Member of: FAO, G-77, IADB, IAEA, IBRD, 1CAO, ICO,
IDA, IDB, IFAD, IFC, ILO, IMF, IPU, ITU, LAFTA, OAS,
SELA, UN, UNESCO, UPU, WHO, WMO, WSG','1a5da78cb71cb1e075e7266f178b624eb42ff7bcddd41208b3aedeb9d642605d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6c4bb6b774bded6d561ae2154afd346e4f4bd0f8a898c367c75d22d1a0b39fe',1982,'PE','Peru','government',441,'Official name: Republic of Peru
Type: republic; under civilian government since July 1980
Capital: Lima
Political subdivisions: 23 departments with limited
autonomy plus constitutional Province of Callao
Legal system: based on civil law system; 1979 constitution
reestablished civilian government with a popularly elected
president and bicameral legislature; legal education at the
National Universities in Lima, Trujillo, Arequipa, and
Cuzco; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 28 July
Branches: executive, judicial, legislative
Government leader: President Fernando BELAUNDE
Terry
Suffrage: obligatory for literate citizens (defined as adult
men and women and married persons over age 18) until age
60
Elections: elections for a civilian government were held
on 18 May 1980, with the new government installed on 28
July 1980
Political parties and leaders: Popular Action Party (AP),
Fernando Belaunde Terry; American Popular Revolutionary
Alliance (APRA), Fernando Leon de Vivero; Popular Chris-
tian Party (PPC), Luis Bedoya Reyes; United Left (1U),
Alfonso Barrantes
Voting strength (1980 presidential election): 45% AP,
27% APRA, 10% PPC
Communists: pro-Soviet (PCP/S) 2,000; pro-Chinese (2
factions) 1,200
Member of: AIOEC, ASSIMER, CIPEC, FAO, G-77,
GATT, IADB, IAEA, IATP, IBRD, 1CAO, ICO, IDA, 1DB,
1FAD, IFC, ILO, International Lead and Zinc Study Group,
1MCO, IMF, ISO, ITU, 1WC— International Wheat Council,
LAFTA and Andean Pact, NAM, OAS, UN, UNESCO,
UPU, WHO, WMO, WSG, WTO','ddd971634fc4e20973645230ffb9c290811bb221dbfb6064dec12ee0fd9f65ea','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1837018c37ac4e3c050ab5ec7bb3390b937231d162528543aa09d13f920aa204',1982,'PL','Poland','government',445,'Official name: Polish People''s Republic
Type: Communist state, temporarily under martial law
Capital: Warsaw
Political subdivisions: 49 provinces
Legal system: mixture of Continental (Napoleonic) civil
law and Communist legal theory; constitution adopted 1952;
court system parallels administrative divisions with Supreme
Court, composed of 104 justices, at apex; no judicial review
of legislative acts; legal education at seven law schools; has
not accepted compulsory ICJ jurisdiction
National holiday: National Liberation Day, 22 July
Branches: legislative, executive, judicial system domi-
nated by parallel Communist party apparatus
Government leaders: Wojciech JARUZELSK1, Chairman
of Council of Ministers (Premier); Henryk Jabllonski, Chair-
man of Council of State (President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every four
years
Dominant political party and leader: Polish United
Workers'' Party (PZPR; Communist), Wojciech Jaruzelski,
First Secretary
Voting strength (1975 election): 99% voted for
Communist-approved single slate
Communists: 3,091,900 party members (1980)
Other political or pressure groups: National Unity Front
(FJN), including United Peasant Party (ZSL), Democratic
Party (SD), progovernment pseudo-Catholic Pax Association
and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church
Member of: CEMA, FAO, GATT, IAEA, ICAO, ICES,
IHO, Indochina Truce Commission, 1LO, IMCO, Interna-
tional Lead and Zinc Study Group, 1PU, ISO, 1TC, ITU,
Korea Truce Commission, UN, UNESCO, UPU, WHO, all
specialized agencies except IMF and IBRD, Warsaw Pact,
WIPO, WMO, WTO','41cb6680d08393b0373e1c279a87690f6f0bb304de0aa3ce4a31580de40f43a5','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5d5fe69d32bebc3ba0d666020cf73318fc546d069bd5a55e2f83a49850cdbe1',1982,'PT','Portugal','government',450,'Official name: Portuguese Republic
191
PORTUGAL (Continued)
Type: republic, first government under new constitution
formed July 1976
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal;
Portugal''s two autonomous regions, the Azores and Madeira
Islands, have 4 districts (3 of them in the Azores), Macao,
Portugal''s remaining overseas territory, was granted broad
executive and legislative autonomy in February 1976; Portu-
gal has not officially recognized the unilateral annexation of
Portuguese Timor by Indonesia
Legal system: civil law system; constitution adopted April
1976 to be amended by Assembly elected in October 1980;
until then, legislative assembly acts to be reviewed for
constitutionality by Revolutionary Council, with the advice
of a Constitutional Commission of legal experts; laws judged
unconstitutional by Council must be vetoed by President;
Assembly can override veto by two-thirds majority; legal
education at Universities of Lisbon and Coimbra; accepts
compulsory ICJ jurisdiction, with reservations
National holiday: 25 April
Branches: executive with President and Prime Minister,
with 19-member Revolutionary Council, made up of mili-
tary officers, responsible for safeguarding the constitution;
popularly elected Assembly of the Republic; independent
judiciary
Government leaders: President Gen. Antonio dos Santos
Ramalho EANES; Prime Minister Francisco Pinto
BALSEMAO
Suffrage: universal over age 18
Elections: national elections for Assembly of the Republic
normally to be held every four years; new Assembly, with
constituent powers, elected October 1980; national election
for President to be held every five years, second constitu-
tional president elected in December 1980; local elections to
be held every three years, next elections in December 1982
Political parties and leaders: the Portuguese Socialist
Party (PS) is led by Mario Soares; the Social Democratic
Party (PSD), formerly the Popular Democratic Party (PPD),
by Francisco Pinto Balsemao; the Social Democratic Center
(CDS) by Diogo Freitas do Amaral; and the Portuguese
Communist Party (PCP) by Alvaro Cunhal
Voting strength: (1980 parliamentary election) the Demo-
cratic Alliance (AD) — consisting primarily of the PSD and
the CDS — polled over 47.0% of the vote; the Socialists — in a
coalition with two smaller parties — polled 28.0% of the vote;
and the Communists — in a front coalition called the United
Peoples Alliance (APU)— 16.9%, (1979 local elections) AD
47%, PS 27%, APU 21%
Communists: Portuguese Communist Party claims mem-
bership of 164,713 (April 1979)
Member of: Council of Europe, EFTA, FAO, GATT,
IAEA, IATP, IBRD, ICAC, ICAO (restricted membership),
ICES, ICO, IEA, I FAD, IFC, IHO, ILO, IMCO, IMF,
IOOC, ISO, ITU, IWC— International Wheat Council,
NATO, OECD, UN, UNESCO, UPU, WHO, WIPO, WMO,
WSG','7febcb075de315d375944be4d467528549f5320326dfc8fd9f34d871cea7bf0c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5f2b223463b3412e5ad1c03999d11c8a41da72eb5d7d6eefdac2543d96988e4',1982,'SA','Saudi Arabia','government',454,'Offical name: State of Qatar
Type: traditional monarchy; independence declared in
1971
Capital: Doha
Legal system: discretionary system of law controlled by
the ruler, although civil codes are being implemented;
Islamic law is significant in personal matters; a constitution
was promulgated in 1970
National holiday: 3 September
Government leader: Amir Khalifa bin Hamad Al THAN1
Suffrage: no specific provisions for suffrage laid down
Elections: constitution calls for elections for part of State
Advisory Council, a consultative body, but none have been
held
193
REUNION
QATAR (Continued)
Political parties and pressure groups: none; a few small
clandestine organizations are active
Branches: Council of Ministers; appointive 30-member
Advisory Council
Member of: Arab League, FAO, G-77, GATT (de facto),
GCQIBRD, 1CAO, 1FAD, ILO, IMCO, IMF, ISCON, ITU,
NAM, OAPEC, OPEC, UN, UNESCO, UPU, WHO, WIPO,
WMO
Official name: Department of Reunion
Type: overseas department of France; represented in
French Parliament by three deputies and two senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect ap-
pointed by the French Minister of Interior, assisted by a
Secretary General and an elected 36-man General Council
Government leader: Prefect Michel LEVALLOIS
Suffrage: universal adult
Elections: last municipal and general council elections in
1976; parliamentary election June 1981
194
REUNION (Continued)
Political parties and leaders: Reunion Communist Party
(RCP) led by Paul Verges and the Popular Movement for the
Liberation of Reunion led by Georges Sinamale; other
political candidates affiliated with metropolitan French
parties, which do not maintain permanent organizations on
Reunion
Voting strength (Parliamentary election 1981): the
French Democratic Union-Rally for the Republic coalition
elected two deputies; the Socialists elected one deputy
Communists: Communist Party small, but has support
among sugarcane cutters, the minuscule OCMLR, and in Le
Port District
Member of: EC, WFTU
SAO TOME AND PRINCIPE (Continued)
Suffrage: universal for age 18 and over
Elections: da Costa reelected May 1980 by Popular
Assembly; Assembly elections held March-April 1980
Political parties and leaders: Movement for the Liber-
ation of Sao Tome and Principe (MLSTP), Secretary General
Manuel Pinto da Costa
Communists: no Communist party, probably a few Com-
munist sympathizers
Member of: AFDB, FAO, G-77, GATT (de facto), IBRD,
1CCO, IDA, IMF, ITU, NAM, OAU, UN, UPU, WHO,
WMO
Official name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic
representatives located in Jiddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several
secular codes have been introduced; commercial disputes
handled by special committees; has not accepted compulsory
1CJ jurisdiction
National holiday: 23 September
Branches: King Khalid (Al Saud, Khalid ibn *Abd al-
*Aziz) rules in consultation with royal family (especially
Crown Prince Fahd), and Council of Ministers
204
SAUDI ARABIA (Continued)
Government leader: King and Prime Minister Khalid ibn
''Abd al-''Aziz Al SA''UD
Communists: negligible
Member of: Arab League, FAO, G-77, GCC, IAEA,
IBRD, ICAO, IDA, IFAD, IFC, ILO, IMCO, IMF, ISCON,
ITU, IWC— International Wheat Council, NAM, OAPEC,
OPEC, UN, UNESCO, UPU, WHO, WMO','c5ce34e67c8ea162d836d0e21ddaee6914b408868538a8083670ecd45dd5e396','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5cd858439ac1fedafffe67c9051435f4b1a7ca1230e5ac234bbf1c9bbce3d9e',1982,'RO','Romania','government',458,'Official name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 41 counties including city of Bu-
charest, which has administrative status equal to a county,
and 46 municipalities
Legal system; mixture of civil law system and Communist
legal theory that increasingly reflects Romanian traditions;
constitution adopted 1965; legal education at University of
Bucharest and two other law schools; has not accepted
compulsory 1CJ jurisdiction
National holiday: Liberation Day, 23 August
Branches: Presidency; Council of Ministers; the Grand
National Assembly, under which is Office of Prosecutor
General and Supreme Court; Council of State
Government leaders: Nicolae CEAU§ESCU, President of
the Socialist Republic, head of state; Hie VERDET, Prime
Minister
Suffrage: universal over age 18, compulsory
Elections: elections held every five years for Grand
National Assembly deputies and local peopled councils
Political parties and leaders: Communist Party of Roma-
nia only functioning party, Nicolae Ceau§escu, Secretary
General
Voting strength (1980 election): overall participation
reached 99.99%; of those registered to vote (15,631,351),
98.52% voted for party candidates
Communists: 3,044,336 (March 1981)
Member of: CEMA, FAO, G-77, GATT, IAEA, IBRD,
1CAO, 1FAD, 1LO, 1MCO, IMF, IPU, ITC, ITU, UN,
UNESCO, UPU, Warsaw Pact, WHO, W1PO, WMO, WTO','c75143e40f8fb9816e8cb8e057ad5aebe864c5679fb0cc574b1f4987d567e4b3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2865959923acdde841ab9f81b3741a827155dbd0137c568a1a828c4770d95331',1982,'RW','Rwanda','government',463,'Official name: Republic of Rwanda
Type: republic, presidential system in which military
leaders hold key offices; new constitution adopted 17 De-
cember 1978
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into
143 communes
Legal system: based on German and Belgian civil law
systems and customary law; judicial review of legislative acts
in the Supreme Court; has not accepted compulsory 1CJ
jurisdiction
National holiday: Independence Day, 1 July
Branches: executive (President, 16-member Cabinet); leg-
islative (National Development Council); judiciary (4 senior
courts, magistrates)
Government leader: Maj. Gen. Juvenal HABYARI-
MANA, President and Head of State
Suffrage: universal
197
RWANDA (Continued)
Elections: national elections including constitutional ref-
erendum and presidential plebiscite held December 1978;
National Development Council elected in December 1981
Political parties and leaders: National Revolutionary
Movement for Development (MRND), General Habyari-
mana (officially not a party — a "development movement"
only)
Communists: no Communist party
Member of: AFDB, EAMA, FAO, G-77, GATT, IBRD,
1CAO, ICO, IDA, IFAD, IFC, ILO, IMF, 1PU, ITU, NAM,
OAU, OCAM, UN, UNESCO, UPU, WHO, WMO, WTO','224ef737c1d4779a88075e4ba765a9909a04367809a732da97634b7202518660','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6503e2f06629c9dab03dd1da32fa0efe805eca996e95a19a5c313bb55c8adc55',1982,'SM','San Marino','government',466,'Official name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the
Kingdom of Italy concluded a treaty guaranteeing the
independence of San Marino; although legally sovereign, San
Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9
castelli: Acquaviva, Borgo Maggiore, Chiesanuova, Dog-
manano, Faetano, Fiorentino, Monte Giardino, San Marino,
Serravalle
Legal system: based on civil law system with Italian law
influences; electoral law of 1926 serves some of the functions
of a constitution; has not accepted compulsory ICJ
jurisdiction
National holidays: 1 April, 1 October
Branches: the Grand and General Council is the legisla-
tive body elected by popular vote; its 60 members serve
five-year terms; Council in turn elects two Captains-Regent
who exercise executive power for term of six months, the
Council of State whose members head government adminis-
trative departments, and the Council of Twelve, the su-
preme judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the Secretary
of State for Internal Affairs
Government leaders: since 17 July 1978 Secretary of State
for Foreign and Political Affairs and for Information, Gior-
dano Bruno REFFI (Socialist); Secretary of State for Internal
Affairs and Justice, Alvaro SELVA (Communist); Secretary
of State for Budget, Finance, and Planning, Emilio BALDO
(Unitary Socialist)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council
required at least every five years; an election was held 28
May 1978
Political parties and leader;; Christian Democratic Party
(DCS), Gian Luigi Berti; Social Democratic Party (PSDSM),
Alvaro Casali; Socialist Party (PSS), Remy Giacomini; Com-
munist Party (PCS), Umberto Barulli; People''s Democratic
Party (PDP), leader unknown; Committee for the Defense of
the Republic (CDR), leader unknown
Voting strength (1974 election): 39.6% DCS, 23.7% PCS,
15.4% PSDIS, 13.9% PSS, 1.9% PDP, 2.9% CDR
Communists: approx. 300 members (number of sympa-
thizers cannot be determined); PSS, in government with
Christian Democrats since March 1973, formed a govern-
ment with the PCS from the end of World War II to 1957
Other political parties or pressure groups: political par-
ties influenced by policies of their counterparts in Italy, the
two Socialist parties are not united
Member of: ICJ, International Institute for Unification of
Private Law, International Relief Union, IRC, UPU, WTO','557b37bf8b3c5076e027abfc9d3a44b8aa5d58fdf44f17b6c55a821b58ba98f3','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5196847902b8180544b931df2bf6b6c62dd5a590fff4935d3ea23309202aea2f',1982,'ST','Sao Tome and Principe','government',471,'Official name: Democratic Republic of Sao Tome and
Principe
Type: republic established when independence received
from Portugal in July 1975; constitution adopted December
1975
Capital: Sao Tome
Legal system: based on Portuguese law system and
customary law; has not accepted compulsory 1CJ jurisdiction
National holiday: Independence Day, 12 July
Branches: da Costa heads the government assisted by a
cabinet of ministers; elected National Popular Assembly
Government leader: President Manuel Pinto DA COSTA
203','3a54c55e1fabe3b1cb8697d3a21d6b4c4558599c6cf6d069c2003a6f9d2e3bec','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88f4d0e1de10570aebcd0d3a7ffac83bc252e64ed1e2af23a7b2d3a1d156b2b9',1982,'SN','Senegal','government',474,'Official name: Republic of Senegal
Type: republic (early in 1982, Senegal and The Gambia
formed a loose confederation named Senegambia which calls
for the integration of their armed forces, economies and
monetary systems, and foreign policies)
Capital: Dakar
Political subdivisions: 8 regions, subdivided into 27
departments, 95 arrondissements
Legal system: based on French civil law system; constitu-
tion adopted 1960, revised 1963 and 1970; judicial review of
legislative acts in Supreme Court (which also audits the
governments accounting office); legal education at Universi-
ty of Dakar; has not accepted compulsory 1CJ jurisdiction
National holiday: Independence Day, 4 April
Branches: government dominated by President who is
assisted by Prime Minister, appointed by President, and
subject to dismissal by President or censure by National
Assembly; 100-member National Assembly, elected for five
years (effective 1978); President elected for five-year term
(effective 1978) by universal suffrage; judiciary headed by
Supreme Court, with members appointed by President
Government leaders: Abdou DIOUF, President; Habib
TH1AM, Prime Minister
Suffrage: universal adult
Elections: presidential and legislative elections held Feb-
ruary 1978 for five-year term
Political parties and leaders: legal parties are Parti
Socialiste (PS), moderate ruling party led by President Abdou
Diouf; Parti Democratique Senegalaise (PDS), progressive
socialist party led by Abdoulaye Wade; Rassemblement
National Democratique (RND), left-leaning Nationalist
group led by Cheikh Anta Diop; Mouvement Republicain
Senegalais (MRS), conservative group led by Boubakar
Gueye; Parti Africain de Tlndependance (PAI), Marxist-
Leninist group led by Mahjemout Diop; Parti de l''lndepen-
dance et du Travail (PIT) Marxist- Leninist group led by
Amath Dansoko; Mouvement Democratique et Populaire
(MDP), left-leaning activist group led by Mamadou Dia;
Mouvement Revolutionnaire pour la Democratic Nouvelle
(MRDN)-Ande Jeuf, Maoist group led by Landing Savane;
Ligue Democratique-Mouvement pour le Parti du Travail
(LD-MPT), Marxist-Leninist group led by Babacar Sane;
Union pour la Democratique Populaire (UDP), Marxist-
Leninist group led by Hamedine Racine Guisse; Parti Popu-
laire Senegalaise (PPS), ill-defined left-leaning Nationalist
group led by Oumar Wone.
Communists: small number of Communists and
sympathizers
Other political or pressure groups: students and teachers
occasionally strike
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, E1B (associate), FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, IFAD, 1FC, ILO, IMCO, IMF, ISCON, ITU,
NAM, OAU, OCAM, OMVS (Organization for the Develop-
ment of the Senegal River Valley), UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO
206','a2983d2d2d0942f68d9ecc8aba6891c1c5683ae179617ff115b3abe0cd344f07','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8a4ae07c2a2ed7c705eee48a0fb4c4b7a0152a5f7fd39e3508dfb9fa8788290',1982,'SC','Seychelles','government',475,'SENEGAL (Continued)
Official name: Republic of Seychelles
Type: republic; member of the Commonwealth
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil
law system, and customary law
National holiday: 29 June
Branches: President, Council of Ministers
207
SEYCHELLES (Continued)
Fiscal year/calendar year
Government leader: President France Albert RENE
Suffrage: universal adult
Elections: general elections held June 1979 gave 98%
approval to Rene as only presidential candidate on yes/no
ballot
Political parties and leaders: Ren6, who heads the
Seychelles People''s Progressive Front, came to power by a
military coup in June 1977. Until then he had been Prime
Minister in an uneasy coalition with then President James
Mancham, who headed the Seychelles Democratic Party.
Rene banned the Seychelles Democratic Party in mid-March
1978 and announced a new constitution in March 1979 that
turned the country into a one-party state
Communists: negligible, although some Cabinet Ministers
espouse pro-Soviet line
Other political or pressure groups: trade unions
Member of: G-77, GATT (de facto), IAEA, 1CAO, IFAD,
1LO, IMCO, IMF, NAM, OAU, UN, UNESCO, UPU,
WHO, WMO','9a553447a02375a9f4d38191a45a09e035fb15fe822c79c5a22b79c2a5b9d9d2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06a06bfc1da9e0cefe0d85cb0e7847f602858c2bef4ad3d2ca72a77a74617402',1982,'SL','Sierra Leone','government',481,'Official name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12 dis-
tricts with 146 chiefdoms, where paramount chief and
council of elders constitute basic unit of government; plus
western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws
indigenous to local tribes; constitution adopted April 1971;
highest court of appeal is the Sierra Leone Court of Appeals;
has not accepted compulsory 1CJ jurisdiction
National holiday: National Day, 19 April
Branches: executive authority exercised by President;
parliament consists of 104 authorized seats, 85 of which are
filled by elected representatives of constituencies and 12 by
Paramount Chiefs elected by fellow Paramount Chiefs in
each district; President authorized to appoint up to seven
members, of which two, currently, are filled by the heads of
the Army and the Police; independent judiciary
Government leader: President Siaka P. STEVENS heads
government composed of members of his A PC political
party
Suffrage: universal over age 21
Elections: the Constitution of Sierra Leone Act, 1971, has
been replaced by the Constitution of Sierra Leone, 1978,
which provides for one-party rule; Dr. Siaka Stevens was
named as the first Executive President under the one-party
constitution; the President''s tenure has been extended from
five to seven years; next presidential election 1982
Political parties and leaders: All People''s Congress
(APC), headed by Stevens
Communists: no party, although there are a few Commu-
nists and a slightly larger number of sympathizers
Member of: AFDB, AIOEC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IAEA, IBA, IBRD, 1CAO,
ICO, IDA, IFAD, IFC, 1LO, 1MCO, IMF, 1PU, 1SCON,
ITU, NAM, OAU, UN, UNESCO, UPU, WHO, WMO,
WTO','dede3051fb5e9b99c718b0566363c3ac304676898b6e1c55c111e60e91d4bb67','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a2a9f3845847d402aa81b6b18f13bdbcdf68f430dfec53353a5b176f50e9490',1982,'SG','Singapore','government',486,'Official name: Republic of Singapore
Type: republic within Commonwealth since separation
from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution
based on preindependence State of Singapore constitution;
legal education at University of Singapore; has not accepted
compulsory 1CJ jurisdiction
National holiday: 9 August
210
SINGAPORE (Continued)
Branches: ceremonial President; executive power exer-
cised by Prime Minister and Cabinet responsible to unitary
legislature
Government leaders: President C. V. Devan NAIR;
Prime Minister LEE Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every five years
Political parties and leaders: government — People''s Ac-
tion Party (PAP), Lee Kuan Yew; opposition — Barisan Sosia-
lis (BS), Dr. Lee Siew Choh; Workers'' Party (WP), J. B.
Jeyaretnam; United People''s Front (UPF), Harbans Singh;
Singapore Democratic Party (SDP), Chiam See Tong, Com-
munist Party illegal
Voting strength (1980 election): PAP won all 75 seats in
Parliament and received 75.5% of vote; WP won seat in
byelection in October 1981
Communists: 200-500; Barisan Sosialis infiltrated by
Communists
Member of: ADB, ANRPC, ASEAN, Colombo Plan, G-77,
GATT, IAEA, IBRD, ICAO, IFC, IHO, ILO, IMCO, IMF,
IPU, ISO, ITU, NAM, UN, UNESCO, UPU, WHO, WMO,
WTO','6a9e8f78759ffe92392b48b045552d8d5aa3837321e3a26fb317c1a6cf822538','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('608cc8ec421e3c0b752aef12b890374e544847a98f9f02d3d85842d152723493',1982,'SB','Solomon Islands','government',489,'Official name: Solomon Islands
Type: independent parliamentary state within
Commonwealth
Capital: Honiara on the island of Guadalcanal
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates Courts, also a
system of native courts throughout the islands
Branches: executive authority in Governor General; a
Legislative Assembly of 38 members
Government leaders: Governor General Baddeley DE-
VESI, Prime Minister Solomon MAMALON1
Suffrage: universal age 21 and over
Elections: every four yeacs, latest August 1980
Political parties and leaders: United Party, Peter Keni-
lorea; People''s Alliance Party, Solomon Mamaloni, National
Democratic Party, Bartholemew Ulufa''alu
Member of: ADB, GATT (de facto), IBRD, IDA, 1FAD,
IMF, UN, UPU','f9f23d1cc61bb3a85ef95657aff14ab97fcace83499e68efc10d7b2402feb37c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('080d6e29f0de29ed3c4ff14621e66d39a807ac99b615b4e83f9f4fb00be051e5',1982,'SO','Somalia','government',493,'Official name: Somali Democratic Republic
Type: republic
Capital: Mogadishu
National holiday: 21 October
Political subdivisions: 16 regions, 60 districts
Organization: executive authority is exercised by the
Supreme Revolutionary Council, composed of military offi-
cers and headed by President Siad
Government leader: President Maj. Gen. MOHAMED
Siad Barre
Political party and leader: the Somali Revolutionary
Socialist Party (SRSP), created on 1 July 1976, is sole legal
party; Maj. Gen. Mohamed Siad Barre is general secretary of
the SRSP
Communists: probably some Communist sympathizers in
the government hierarchy
Member of: AFDB, Arab League, EAMA, FAO, G-77,
IBRD, 1CAO, IDA, 1FAD, IFC, ILO, IMCO, IMF, ISCON,
ITU, NAM, OAU, UN, UNESCO, UPU, WHO, WMO','2a07baa05878871976b13a3db8bb1a7819527fc2b59ceab39e5540d46cd6062e','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b240ae7ea7851fd827b22cd3f382332f081b99c00c6b57aadecf246d131caf0',1982,'ZA','South Africa','government',497,'Official name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town;
judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by cen-
trally appointed administrator; provincial councils, elected
by white electorate, retain limited powers
Legal system: based on Roman-Dutch law and English
common law; constitution enacted 1961, changing the Union
of South Africa into a republic; possibility of judicial review
of Acts of Parliament concerning dual official languages;
accepts compulsory 1CJ jurisdiction, with reservations
National holiday: Republic Day, 31 May
Branches: State President as formal chief of state; Prime
Minister as head of government; Cabinet responsible to the
legislature; legislature elected ^directly by white electorate;
judiciary maintains substantial independence of government
influence
Government leaders: State President Marais VILJOEN;
Prime Minister Pieter W. BOTHA
Suffrage: general suffrage limited to whites over 18 (17 in
Natal Province)
Elections: must be held at least every five years; last
elections 30 November 1977
Political parties and leaders: National Party, P. W.
Botha; Progressive Federal Party, Frederick Van Zyl Slab-
bert, Colin Eglin; New Republic Party, Vause Raw
Voting strength: (1977 general elections) parliamentary
seats: 134 National Party, 17 Progressive Federal Party, 10
New Republic Party, 3 South Africa Party (recently ab-
sorbed into the National Party) #
Communists: small Communist Party illegal since 1950;
party in exile maintains headquarters in London; Dr. Yasuf
Dadoo, Moses Kotane, Joe Slovo
Other political groups: (insurgent groups in exile) African
National Congress (ANC), Oliver Tambo; Pan-Africanist
Congress (PAC), Vusumzi Make
Member of: GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO,
International Lead and Zinc Study Group, IMF, ISO, ITU,
IWC — International Whaling Commission, 1WC — Interna-
tional Wheat Council, UN, UPU (South Africa in process of
being expelled from UPU but they have not been officially
notified as yet), WHO, W1PO, WMO, WSG
Official name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, consisting of 20
autonomous republics, 6 krays, 122 oblasts, 8 autonomous
oblasts, and 10 autonomous okrugs
1 The US Government does not recognize the incorporation of the
Baltic States — Estonia, Latvia, and Lithuania — into the Soviet
Union.
215
SOVIET UNION (Continued)
Legal system: civil law system as modified by Communist
legal theory; revised constitution adopted 1977; no judicial
review of legislative acts; legal education at 18 universities
and 4 law institutes; has not accepted compulsory ICJ
jurisdiction
National holiday: October Revolution Day, 7 November
Branches: Council of Ministers (executive), Supreme Sovi-
et (legislative), Supreme Court of USSR (judicial)
Government leaders: Leonid I. BREZHNEV, General
Secretary of the Central Committee of the Communist Party
and Chairman of the Presidium of the USSR Supreme
Soviet; Nikolay A. TIKHONOV, Chairman of the USSR
Council of Ministers
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every five years; 1,500
deputies elected in 1979; 71.7% party members
Political party: Communist Party of the Soviet Union
(CPSU) only party permitted
Voting strength (1979 election): 174,944,173 persons over
18; allegedly 99.99% voted
Communists: over 17 million party members
Other political or pressure groups: Komsomol, trade
unions, and other organizations which facilitate Communist
control
Member of: CEMA, Geneva Disarmament Conference,
IAEA, 1BEC, ICAC, ICAO, ICCAT, ICCO, ICES, 1LB, 1LO,
IMCO, International Lead and Zinc Study Group, INRO,
1PU, ISO, ITC, ITU, IWC— International Whaling Commis-
sion, IWC— Internationa] Wheat Council, UN, UNESCO,
UPU, Warsaw Pact, WFTU, WHO, W1PO, WMO, WTO','3f1b6a22d7dd72eaee5909be47fbc7cd31fa39af2bfe93965d4facdb055212d6','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f6c4c1b018d4be2edfb650e2fdb03e1ef9aba3cbb3785c0ef82654bb5e19415',1982,'LK','Sri Lanka','government',501,'Official name; Democratic Socialist Republic of Sri
Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 24 administrative
districts, and four categories of semiautonomous elected
local governments
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim and customary law;
new constitution 7 September 1978 reinstituted a strong,
independent judiciary; legal education at Sri Lanka Law
College and University of Sri Lanka, Peradeniya; has not
accepted compulsory 1CJ jurisdiction
National holiday: Independence Day, 22 May
Branches: the 1978 constitution established a strong presi-
dential form of government under J. R. Jayewardene, who
had been Prime Minister since his party''s election victory in
July 1977; Jayewardene will remain President until 1984,
regardless of whether Parliament is dissolved and subsequent
parliamentary elections are held; when Jayewardene''s term
in office expires, a new President will be chosen by a direct
national election for a six-year term
Government leader: President J. R. JAYEWARDENE
Suffrage: universal over age 18
Elections: national elections, ordinarily held every six
years; must be held more frequently if government loses
confidence vote; last election held July 1977
Political parties and leaders: Sri Lanka Freedom Party-
Sirimavo, Sirimavo Ratwatte Dias Bandaranaike, president,
and Sri Lanka Freedom Party — Maitwripala, Maitwripala
Senanayake, president (this split in the SLFP may eventually
be resolved; both sides allege to be the "official" SLFP;
Lanka Sama Samaja Party (Trotskyite), C. R. de Silva,
president; Naya Sama Samaja Party, V. Nanayakkara, lead-
er; Tamil United Liberation Front, A. Amirthalingam, lead-
er; United National Party, J. R. Jayewardene; Communist
Party/Moscow, K. P. Silva, general secretary; Communist
Party/Peking, N. Shanmugathasan, general secretary; Maha-
jana Eksath Peramuna (People''s United Front), M. B. Rat-
nayaka, president; Janatha Vimukthi Peramuna (People''s
Liberation Front), Rohana Wijeweera, leader
Voting strength (1977 election): 30% Sri Lanka Freedom
Party, 51% United National Party, 3.9% Lanka Sama Samaja
Party, 1.8% Communist Party/Moscow, 6.5% TULF minor
parties and independents accounted for remainder
Communists: approximately 107,000 voted for the Com-
munist Party in the July 1977 general election; Communist
Party/Moscow approximately 5,000 members (1975), Com-
munist Party/Peking 1,000 members (1970 est.)
Other political or pressure groups: Buddhist clergy,
Sinhalese Buddhist lay groups; far-left violent revolutionary
groups; labor unions
Member of: ADB, ANRPC, Colombo Plan, Common-
wealth, FAO, G-77, GATT (de facto), IAEA, IBRD, 1CAO,
IDA, 1FAD, 1FC, ILO, IMCO, IMF, 1PU, ITU, NAM, UN,
219','0cc0c4dc8547cd00cda8a2a2b6791f4d721db062828119fe1dc6eb456508a48a','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee4af8e5274bde511ee85c0898ebfe62d7da6ace933a3d03d92a9aaff99b3f21',1982,'SR','Suriname','government',504,'Official name: Republic of Suriname
Type: military-civilian rule
Capital: Paramaribo
Political subdivisions: 9 districts before 1980 coup, each
headed by District Commissioner responsible to Minister of
District Government and Decentralization except for Para-
maribo, whose commissioner is responsible to Minister of
Home Affairs, not functioning at present; 100 "People''s
Committees" installed at local level
Legal system: transitional constitution in effect
National holiday: Independence Day, 25 November
Branches: new government announced on 1 April 1982 —
Policy Center makes policy and decisions; Council of Minis-
ters implements decisions; President is a ceremonial
figurehead
Government leaders: Lt. Col. Daysi BOUTERSE, Army
Commander and strongman; Acting President Lachmiper-
sad Frederick RAMDAT-M1S1ER
Suffrage: suspended
Elections: no elections planned
Political parties and leaders: Revolutionary Front (De-
cember 1981) official party established by Lt. Col. Daysi
Bouterse; regular party activity officially suspended, al-
though some continue low^Jevel functioning; National Party
of Suriname (NPS), Henck Arron; Nationalist Republic Party
(PNR), Edward Bruma (principal leftist party); Progressive
Reform Party (VHP), J. Lachmon; Pendawa Lima, S. Somo-
hardjo; Javanese Farmers'' Party (KTPI), Willy Soemita;
Progressive Suriname People''s Party (PSV), Emile Wijntuin;
Reformed Progressive Party (HPP), Pannalal Parmessar
Voting strength (1977): NPK 22 seats, Opposition United
Democratic Parties Combination (VDP) 17 seats
Communists: (all small groups) Democratic Peoples Front;
Communist Party of Suriname (KPS); People''s Party (VP),
Ruben Lie Pauw Sam; Revolutionary People''s Party (RVP),
Edward Narrendorp
Member of: EC (associate), ECLA, FAO, GATT, 1BA,
IBRD, 1CAO, 1LO, 1MCO, IMF, ITU, NAM, OAS, UN,
UNESCO, UPU, WHO, W1PO, WMO
Official name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza II; independent
member of Commonwealth since September 1968
Capital: Mbabane (administrative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law
in statutory courts, Swazi traditional law and custom in
traditional courts; legal education at University of Botswana
and Swaziland; has not accepted compulsory 1CJ jurisdiction
National holiday: Independence Day, 6 September
Branches: constitution was repealed and Parliament dis-
solved by King in April 1973; new bicameral Parliament
formally opened in January 1979; 80-member electoral
college chose 40 members of lower house and 10 members of
upper house; additional 10 members for each house chosen
223','69ddbec618103a016c3202f1f1fe139c33b8316a95f7d047a7ab7f3ba3b68536','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3722b72cac184067adfdb42258e984d8efb29da81764dde4014c7de2f97cd628',1982,'SE','Sweden','government',506,'SWAZILAND (Continued)
by King; executive authority vested in King whose assent is
required before parliamentary acts become law; King''s
authority exercised through Prime Minister and Cabinet
who must be members of Parliament; judiciary is part of
Ministry of Justice but otherwise independent of executive
and legislative branches; cases from subordinate courts can
be appealed to the High Court and the Court of Appeal
Government leaders: Head of State, King SOBHUZA 11;
Prime Minister Prince Mabandla (Fred E.) DLAM1NI
Suffrage: universal for adults
Communists: no Communist party
Member of: AFDB, FAO, G-77, GATT (de facto), IBRD,
ICAO, IDA, 1FAD, IFC, 1LO, IMF, ISO, ITU, NAM, OAU,
UN, UNESCO, UPU, WHO
Official name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 counties, 278 municipalities
(townships)
224
SWEDEN (Continued)
Legal system: civil law system influenced by customary
law; a new constitution was adopted in 1975 replacing the
Acts of 1809, 1866, and 1949; legal education at Universities
of Lund, Stockholm, and Uppsala; accepts compulsory 1CJ
jurisdiction, with reservations
National holiday: no national holiday; King''s birthday, 30
April, celebrated as such by Swedish embassies
Branches: legislative authority rests with unicameral par-
liament (Riksdag); executive power vested in Cabinet, re-
sponsible to parliament; Supreme Court, 6 superior courts,
108 lower courts
Government leaders: Chief of State, King CARL XVI
Gustaf; Head of Government, Prime Minister Thorbjorn
FALLDIN
Suffrage: universal, but not compulsory, over age 18; after
three years of legal residence immigrants may vote in county
and municipal, but not in national elections
Elections: every three years (next in September 1982)
Political parties and leaders: Moderate Coalition (con-
servative), Ulf Adelsohn; Center, Thorbjorn Falldin; People''s
Party (Liberal), Ola Ullsten; Social Democratic, Olof Palme;
Left Party-Communist, Lars Werner; Swedish Communist
Party, Roland Pettersson; Communist Workers'' Party, Rolf
Hagel
Voting strength (1979 election): 43.2% Social Democratic,
20.3% Moderate Coalition, 18.1% Center, 10.6% Liberal,
5.6% Communist, 2.1% other
Communists: 17,000; a number of sympathizers as indi-
cated by the 327,079 votes cast for the three largest Commu-
nist parties in 1979 elections; an additional 17,274 votes cast
for Maoist KPML-R
Member of: ADB, Council of Europe, DAC, EC (Free
Trade Agreement), EFTA, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, ICO, IDA, IDB, IEA, 1FAD,
IFC, IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ISO, ITU, IWC— International Whaling
Commission, IWC — International Wheat Council, Nordic
Council, OECD, UN, UNESCO, UPU, WHO, W1PO,
WMO, WSG','e64be8577b603a7dc5630dded1c217b6f51de7316ac901e27da64790b9e19805','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9878c169243b2d4bf67e0391c7860e98fa414d68c93535b7d3c883ef72257cc',1982,'CH','Switzerland','government',512,'Official name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 23 cantons (3 divided into half
cantons)
Legal system: civil law system influenced by customary
law; constitution adopted 1874, amended since; judicial
review of legislative acts, except with respect to federal
decrees of general obligatory character; legal education at
Universities of Bern, Geneva, and Lausanne, and four other
university schools of law; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: 1 August
Branches: bicameral parliament has legislative authority;
federal council (Bundesrat) has executive authority; justice
left chiefly to cantons
Government leader; Fritz HONEGGER, President (1982,
rotates annually)
Suffrage: universal over age 20
Elections: held every four years; next elections 1983
Political parties and leaders: Social Democratic Party
(SPS), Helmut Hubacher, president; Radical Democratic
Party (FDP), Yann Richter, president; Christian Democratic
People s Party (CVP), Hans Wyer, president; Swiss People''s
Party (SVP), Fritz Hofmann, chairman; Communist Party
(PdA), Armand Magnin, chairman; National Action Party
(N.A.), Hans Zwicky, chairman
Voting strength (1979 election): 25.5% FDP, 25.5% SPS,
22.0% CVP, 11.5% SVP, 4.0% LdU, 4.0% LPS, 1.5% PdA,
1.5% EVP, 4.5% others
Communists: about 5,000 members
Other parties: Landesring (LdU); Republican Movement
(Rep); Liberal Party (LPS); Evangelical Peoples Party (EVP);
Maoist Party (POSH/PSA)
Member of: ADB, Council of Europe, DAC, EFTA,
ELDO (observer), ESRO, FAO, GATT, IAEA, 1CAC, 1CAO,
ICO, IEA, IFAD, 1LO, 1MCO, 1PU, ITU, 1WC— Interna-
tional Wheat Council, OECD, UN (permanent observer),
UNESCO, UPU, WCL, WHO, WIPO, WMO, WSG, WTO
Official name: Syrian Arab Republic
Type: republic; under leftwing military regime since
March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus
administered as separate unit
Legal system: based on Islamic law and civil law system;
special religious courts; constitution promulgated in 1973;
legal education at Damascus University and University of
Aleppo; has not accepted compulsory 1CJ jurisdiction
227
SYRIA (Continued)
National holiday; Independence Day, 17 April
Branches: executive powers vested in President and
Council of Ministers; legislative power rests in the People''s
Assembly; seat of power is the Ba''th Party Regional (Syrian)
Command
Government leader: President Hafiz al-ASSAD
Suffrage: universal at age 18
Elections: People''s Assembly election November 1981;
presidential election February 1978
Political parties and leaders: ruling party is the Arab
Socialist Resurrectionist (Ba''th) Party; the "national front"
cabinet is dominated by Ba''thists but includes independents
and members of the Syrian Arab Socialist Party (ASP), Arab
Socialist Union (ASU), Socialist Unionist Movement, and
Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering about
5,000
Other political or pressure groups: non-Ba*th parties
have little effective political influence; Communist Party
ineffective; greatest threat to Assad regime lies in factional-
ism in the military; conservative religious leaders; Muslim
Brotherhood
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFAD, 1FC, ILO, 1MCO, IMF, IOOC, 1PU,
1SCON, ITU, 1WC— International Wheat Council, NAM,
OAPEC, UN, UNESCO, UPU, WFTU, WHO, WMO, WSG,
WTO
Official name: United Republic of Tanzania
Type: republic; single party on the mainland and on
Zanzibar
Capital: Dar es Salaam
Political subdivisions: 25 regions — 20 on mainland, 5 on
Zanzibar islands
Legal system: based on English common law, Islamic law,
customary law, and German civil law system; permanent
constitution adopted 1977, replaced interim constitution
adopted 1965; judicial review of legislative acts limited to
matters of interpretation; legal education at University of
Dar es Salaam; has not accepted compulsory 1CJ jurisdiction
National holiday: "Union Day," 26 April
Branches: President Julius Nyerere has full executive
authority on the mainland; National Assembly dominated by
Nyerere and the Chama Cha Mapinduzi (Revolutionary
Party); National Assembly consists of 233 members, 72 from
Zanzibar, of which 10 are directly elected, 65 appointed
from the mainland, plus 96 directly elected from the
mainland; Vice President Aboud Jumbe (President of Zanzi-
bar) and the Revolutionary Council still run Zanzibar except
for certain specifically designated union matters
Government leaders: President Julius K. NYERERE;
Prime Minister Cleopa D. MSUYA
Suffrage: universal over 18
Political party and leaders: Chama Cha Mapinduzi
(Revolutionary Party), only political party, dominated by
Nyerere and Vice President Jumbe, his top lieutenant; party
was formed in 1977 as a result of the earlier union of the
Tanganyika African National Union, the sole mainland
party, and the Afro-Shirazi Party, the only party in Zanzibar
Voting strength (October 1980 national elections): close
to 7 million registered voters; Nyerere received 93% of about
6 million votes cast; general elections scheduled for late 1985
Communists: a few Communist sympathizers, especially
on Zanzibar
Member of: AFDB, Commonwealth, FAO, G-77, GATT,
IAEA, IBRD, ICAC, ICAO, ICO, IDA, 1FAD, IFC, ILO,
IMCO, IMF, ITU, NAM, OAU, UN, UNESCO, UPU,
WHO, WMO, WTO','eae229aaf742845e7f7270ac1e6d29d9a7c1062b45d237e245a5e544f9562918','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a9ae2f95a70ba14114ac677f491d5d0ce00b40a26edaafda7652ff8c623fe8e',1982,'TO','Tonga','government',519,'Official name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nuku alofa (located on Tongatapu Island)
Political subdivisions: three main island groups (Tonga-
tapu, Ha api, Vava''u)
Legal system: based on English law
Branches: executive (King and Privy Council); legislative
(Legislative Assembly composed of seven nobles elected by
their peers, seven elected representatives of the people, eight
Ministers of the Crown; the King appoints one of the seven
nobles to be the speaker); Judiciary (Supreme Court, magis-
trate courts, Land Court)
Government leaders: King Taufa''ahau TUPOU IV; Pre-
mier, Prince Fatafehi TlTlPELEHAKE (younger brother of
the King)
233','ef360762ed822e377dc3787176d9f2f50380528771cd1ff02cfa89864f0dab49','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a91e33732dee1ed6fc906f40e91fe003916a0801fe2bb48a3f349cb3489c20e',1982,'TT','Trinidad and Tobago','government',520,'TONGA (Continued)
Suffrage: granted to all literate adults over 21 years of age
who pay taxes
Elections: held every three years, last in April 1978
Communists: none known
Member of: ADB, Commonwealth, ESCAP, South Pacific
Bureau for Economic Cooperation, South Pacific Bureau
Forum
Official name: Republic of Trinidad and Tobago
Type: independent state since August 1962; in August
1976 country officially became a republic severing legal ties
to British crown
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is
30th)
234
TRINIDAD AND TOBAGO (Continued)
Legal system: based on English common law; constitution
came into effect 1976; judicial review of legislative acts in
the Supreme Court; has not accepted compulsory ICJ
jurisdiction
National holiday: 31 August
Branches: legislative branch consists of 36-member elect-
ed House of Representatives and 31 -member appointed
Senate; executive is Cabinet led by the Prime Minister;
judiciary is headed by the Chief Justice and includes a Court
of Appeal, High Court, and lower courts
Government leaders: Prime Minister George CHAM-
BERS, President Ellis CLARKE
Suffrage: universal over age 18
Elections: elections to be held at intervals of not more
than five years; last election held 9 November 1981
Political parties and leaders: People''s National Move-
ment (PNM), George Chambers; United Labor Front (ULF),
Basdeo Panday; Organization for National Reconstruction
(ONR), Karl Hudson-Phillips; Democratic Action Congress
(DAC), Arthur Napoleon Raymond Robinson; Tapia House
Movement, Lloyd Best
Voting strength (198i election): 55% of registered voters
cast ballots; PNM captured 26 seats^in House of Representa-
tives, ULF 8, and DAC the 2 Tobago seats
Communists: not significant
Other political pressure groups: National Joint Action
Committee (NJAC), radical antigovernment Black-identity
organization; Trinidad and Tobago Peace Council, leftist
organization affiliated with the World Peace Council; Trini-
dad and Tobago Chamber of Industry and Commerce;
Trinidad and Tobago Labor Congress, moderate labor feder-
ation; Council of Progressive Trade Unions, radical labor
federation
Member of: CARICOM, Commonwealth, FAO, G-77,
GATT, IADB, IBRD, International Coffee Agreement,
ICAO, ICO, IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU,
IWC— International Wheat Council, NAM, OAS, SELA,
UN, UNESCO, UPU, WHO, WMO, WTO','f403e7eee3b09bd022cc54a9d7f1ae4fa5ce218c541a3eaa50c54fa50e398451','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c5ed8b32d8611bbf6c8817575134eeb2d7e126d5301b9badaeceb968a5f9449',1982,'TN','Tunisia','government',526,'Official name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system and
Islamic law; constitution patterned on Turkish and US
constitutions adopted 1959; some judicial review of legisla-
tive acts in the Supreme Court in joint session; legal educa-
tion at Institute of Higher Studies and Superior School of
Law of the University of Tunis
National holiday: Independence Day, 1 June
Branches: executive dominant; unicameral legislative
largely advisory; judicial, patterned on French and Koranic
systems
Government leaders: President Habib BOURGUIBA;
Prime Minister Mohamed MZALI
Suffrage: universal over age 21
Elections: national elections held every five years; last
elections 1 November 1981
Political party and leader: Destourian Socialist Party, led
by Habib Bourguiba, is official ruling party
Voting strength (1981 election): over 95% Destourian
Socialist Party; 3.23% Social Democrats, under 1% Popular
United Movement, under 1% Communist Party
Communists: a small number of nominal Communists,
mostly students; Tunisian Communist Party legalized in July
1981
Member of: AFDB, Arab League, AlOEC, FAO, G-77,
GATT (de facto), IAEA, IBRD, 1CAO, IDA, IFAD, IFC,
ILO, International Lead and Zinc Study Group, IMCO,
IMF, lOOC, 1SCON, ITU, IWC— International Wheat
Council, NAM, OAU, UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO
Official name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961, but is now being revised
by an assembly selected by the military government that
took over on 12 September 1980; legal education at Universi-
ties of Ankara and Istanbul; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Republic Day, 29 October
237
TURKEY (Continued)
Branches: the 12 September military takeover resulted in
the dissolution of Parliament and Prime Minister Demirel''s
government; the generals substituted a five-man National
Security Council to serve as the executive branch and
appointed a civilian Cabinet headed by retired Adm. Bulend
Ulusu to run the country until a new constitution is promul-
gated and civilian rule restored; the Constituent Assembly
established in October 1981 now serves as the legislative
branch of government; highest court for ordinary criminal
and civil cases is Court of Cassation, which hears appeals
directly'' from criminal, commercial, basic, and peace courts
Government leaders: Head of State, Gen. Kenan EVREN
(Chairman, National Security Council); Prime Minister
Adm. Bulend ULUSU
Suffrage: universal over age 21
Elections: Republican People''s Party won a plurality in
June 1977; the Justice Party formed a minority government
in October 1979; inability to elect a permanent president in
1980 contributed in part to the military decision to take over
the government
Political parties and leaders: the military government
disbanded all political parties after it took over on 12
September 1980 and has detained some political leaders; the
commanders might allow political activity after the pro-
posed constitution is submitted to a referendum and ap-
proved by the citizens; Justice Party (JP), Suleyman Demirel;
Republican People''s Party (RPP), Bulent Ecevit; National
Salvation Party (NSP), Necmettin Erbakan; Democratic Par-
ty (DP), Faruk Sukan; Republican Reliance Party (RRP),
Turhan Feyzioglu; Nationalist Action Party (NAP), Alpaslan
Turkes; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced resig-
nation of Demirel government in March 1971 and directly
intervened in the political process in September 1980; an
active radical left and right contributed to violence that took
more than 3,000 lives in 1978-80; left-right violence brought
the country to virtual civil war and prompted the military to
intervene in September 1980
Member of: ASS1MER, Council of Europe, EC (associate
member), ECOSOC, FAO, GATT, IAEA, IBRD, 1CAC,
1CAO, IDA, IEA, IFAD, 1FC, IHO, 1LO, IMCO, IMF,
IOOC, IPU, ISCON, ITC, ITU, NATO, OECD, Regional
Cooperation for Development, UN, UNESCO, UPU, WHO,
WIPO, WMO, WSG, WTO','264945d4d7e67972054f2d7490e6c2ef370fdd93b4ec93bbe6977421786aa597','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('878a8828cf47604a8ca947bbdcbac862ee4d7ae0db9c100ba07802b766db33d6',1982,'WS','Samoa','government',531,'Official name: Tuvalu
Type: constitutional monarchy within the Commonwealth
Capital: Funafuti
House of Assembly: eight members
Government leader; Prime Minister Dr. Tomasi
PUAPUA','9a583a30432531fd7316d6fd76cce8ccc29b2a2da56a390f4325bf318e3e429c','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48981e7291c226ff2cae9aaee5f72f3b06bd9b8624530997e817bbcc5c1a450e',1982,'UG','Uganda','government',534,'Official name: Republic of Uganda
Type: republic, independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: provisional government plans to restore
system based on English common law and customary law to
reinstitute a normal judicial system; legal education at
Makerere University, Kampala; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 9 October
Branches: government that assumed power in December
1980 consists of three branches — an executive headed by a
President, a National Assembly, and a judiciary; in practice
President has most power
Government leader: President Milton OBOTE
Suffrage: universal adult
Elections: general election (held December 1980) elected
present National Assembly; winning party then named
President
Political parties: Ugandan People''s Congress (UPC),
Democratic Party (DP), Uganda Patriotic Movement (UPM)
Voting strength: (December 1980 election) 126 total
elected seats— UPC 74 seats, DP 51 seats, UPM 1 seat
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, FAO, G-77, GATT,
IAEA, IBRD; ICAC, ICAO, ICO, IDA, IFAD, IFC, ILO,
IMF, ISCON, ISO, ITU, NAM, OAU, UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO','a89c8856a4fc1baffd57a379d67fa1c26c5bbcae3427ffbc33f3af3a0be906e0','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef1c95aaf8bbd7b558c8532d1f464ca4d44238b2cddf25a88eb57b038002261a',1982,'AE','United Arab Emirates','government',537,'Official name: United Arab Emirates (composed of for-
mer Trucial States)
Member states: Abu Dhabi; Ajman; Dubai; al Fujayrah;
Ras al-Khaymah; Sharjah; Umm al-Qaywayn
Type: federation; constitution signed December 1971,
which delegated specified powers to the United Arab Emir-
ates central government and reserved other powers to
member shaykhdoms
Capital: Abu Dhabi
Legal system: secular codes are being introduced by the
UAE Government and in several member shaykhdoms;
Islamic law remains very influential
National holiday: 2 December
Branches: Supreme Council of Rulers (seven members),
from which a President and Vice President are elected;
Prime Minister and Council of Ministers; Federal National
Assembly; federal Supreme Court
Government leaders: Shaykh Zayid bin Sultan Al NU-
HAYYAN of Abu Dhabi, President; Shaykh Rashid ibn Sa''id
Al MAKTUM of Dubai, Vice President and Prime Minister
Suffrage: none
Elections: none
Political or pressure groups: none; a few small clandes-
tine groups are active
Member of: Arab League, G-77, GATT (de facto), GCC,
1CAO, 1FAD, ILO, IMCO, IMF, NAM, OAPEC, OPEC,
UN, UNESCO, UPU, WHO, W1PO, WTO','0c29010a2eac489925fd7999a78c0611b5e504de25238ac5b7f6e3c9d1804abc','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5d556e8646fafee813761d8f033b0f71c867c41de73352c81d4a4a77e5cd26d',1982,'US','United States','government',541,'Official name: United States of America
Type: federal republic; strong democratic tradition
Capital: Washington, D.C.
Political subdivisions: 50 states, the District of Columbia,
Commonwealth of Puerto Rico, Guam, Virgin Islands,
American Samoa, Wake and Midway Islands; under UN
trusteeship Caroline, Marshall, and Northern Mariana
Islands
Legal system: based on English common law; dual system
of courts, state and federal; constitution adopted 1789;
judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 4 July
Branches: executive (President), bicameral legislative
(House of Representatives and Senate), and judicial (Su-
preme Court); branches, in principle, independent and
maintain balance of power
Government leaders: Ronald Wilson REAGAN, Presi-
dent; George Herbert Walker BUSH, Vice President
Suffrage: all citizens over age 18, not compulsory
Elections: presidential, every four years (last November
1980); all members of the House of Representatives, every
two years; one-third of members of the Senate, every two
years
Political parties and leaders: Republican Party, Richard
Richards, chairman; Democratic Party, Charles T. Manatt,
chairman; several other groups or parties of minor political
significance
Voting strength: national average of voting age popula-
tion voting, 53.9% (1980 presidential election) — Republican
Party (Ronald Reagan), 50% of the popular vote (489
electoral votes); Democratic Party (Jimmy Carter), 42% (42
electoral votes); John Anderson (third-line candidate), 6% (no
electoral votes); other, 2% (no electoral votes)
Communists: Communist Party membership, claimed
15,000-20,000 (1981); general secretary, Gus Hall; in the
1980 presidential election the Communist Party candidate
received 43,896 votes; Socialist Workers Party membership,
claimed 1,800; national secretary, Jack Barnes; in the 1980
presidential election, the Socialist Workers Party candidate
received 48,650 votes
Member of: ADB, ANZUS, BIS, CCC, CENTO, Colombo
Plan, DAC, FAO, GATT, Group of Ten, 1ADB, IAEA,
IBRD, ICAC, ICAO, ICEM, ICES, ICO, IDA, 1DB, IEA,
IFAD, IFC, IHO, International Lead and Zinc Study Group,
IMCO, IMF, INTELSAT, IPU, ITC, ITU, IWC— Interna-
tional Whaling Commission, IWC — International Wheat
Council, NATO, OAS, OECD, SPC, UN, UNESCO, UPU,
WHO, W1PO, WMO, WSG, WTO
Official name: Republic of Upper Volta
Type: military; on 25 November 1980 a bloodless military
coup ended three years of civilian rule and suspended
political activity
Capital: Ouagadougou
Political subdivisions: 10 departments, composed of 44
cercles, headed by civilian administrators
Legal system: based on French civil law system and
customary law
245
UPPER VOLTA (Continued)
National holiday: Proclamation of the Republic, 11
December
Branches: President is an army officer; I7-man military
and civilian Cabinet was appointed 7 December 1980;
Supreme Court
Government leaders: Col. Save ZERBO, President, Mili-
tary Committee of Reform for National Progress (CMRPN);
Lt. Col. Felix T1ENTARABOUM, Foreign Minister
Suffrage: universal for adults
Elections: political process suspended pending gradual
return to civilian rule
Political parties and leaders: all political parties banned
following November 1980 coup
Communists: no Communist party; some sympathizers
Other political or pressure groups: labor organizations
are badly splintered, students and teachers occasionally
strike; recent strike helped precipitate military coup
Member of: AFDB, CEAO, EAMA, ECA, EIB (associate),
Entente, FAO, G-77, IBRD, ICAO, IDA, IFAD, IFC, ILO,
IMF, IPU, ISCON, ITU, NAM, Niger River Commission,
OAU, OCAM, UN, UNESCO, UPU, WCL, WHO, WIPO,
WMO, WTO','84b4c49a6ed2efe9a9a11368f5104273e61146914c08ed1aefb4bb5fc1203994','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8c95048db27fa1aa82ecaa57e0a814e96a53663c8282f0d4a6fd73e1655a6ac',1982,'UY','Uruguay','government',545,'Official name: Oriental Republic of Uruguay
Type: republic, government under military control
Capital: Montevideo
Political subdivisions: 19 departments with limited
autonomy
Legal system: based on Spanish civil law system; most
recent constitution implemented 1967 but large portions are
currently in suspension and the whole is under study for
revision; legal education at University of the Republic at
Montevideo; accepts compulsory ICJ jurisdiction
National holiday: Independence Day, 25 August
Branches: executive, headed by President; since 1973 the
military has had dominant influence in policymaking; bi-
cameral legislature (closed indefinitely by presidential de-
cree in June 1973), Council of State set up to act as
legislature; national judiciary headed by court of justice
Government leader: President Gregorio ALVAREZ
Manfredini
Suffrage: universal over age 18
Elections: projected for 1984
Political parties and leaders: political activities were
permitted in mid-1981 for the first time since the military
takeover in 1973; parties are scheduled to hold internal
elections to choose leaders in November 1982
Voting strength (1971 elections): 40.8% Colorado, 40.1%
Blanco, 18.6% Frente Amplio, 0.5% Radical Christian Union
Communists: 5,000-10,000 including former youth group
and sympathizers
Other political or pressure groups: Christian Democratic
Party (PDC); Communist Party (PCU), proscribed in 1973;
Socialist Party of Uruguay (PSU), proscribed in 1973; Na-
tional Liberation Movement (MLN) — Tupamaros, leftist rev-
olutionary terrorist group, proscribed and now virtually
annihilated
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAO, 1DB, IFAD, IFC, ILO, IMCO, IMF, ITU, LAFTA,
OAS, SELA, UN, UNESCO, UPU, WHO, WMO, WSG','bf1864eb9b9397f27bdda2e47520825c7a44184644b971d3b9453b74299b7793','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6212f4f462ad2c4adbc2694a8e8b2a49a7c881562f8518afebd14f8f26474c36',1982,'VU','Vanuatu','government',549,'Official name: Republic of Vanuatu
Type: republic, formerly Anglo-French condominium of
New Hebrides, independent 30 July 1980
Capital: Port-Vila
Political subdivisions: 4 administrative districts
Legal system: unified system being created from former
dual French and British systems
Branches: Parliament of 39 members, elected November
1979
Government leader: Prime Minister Father Walter L1N1
Political parties and leaders: National Party (Vanuaaku
Pati), chairman Walter Lini
Member of: South Pacific Forum, UN
Official name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter s,
the Vatican Palace and Museum, and neighboring buildings
covering more than 13 acres; 13 buildings in Rome, although
outside the boundaries, enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of 1929
serve some of the functions of a constitution
National holiday: 30 June
Branches: the Pope possesses full executive, legislative,
and judicial powers; he delegates these powers to the
governor of Vatican City, who is subject to pontifical
appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal
advisers), the Roman Curia (which carries on the central
administration of the Roman Catholic Church), the Presi-
dence of the Prefecture for the Economy, and the synod of
bishops (created in 1965)
249
VENEZUELA
VATICAN CITY (Continued)
Government leader: Supreme Pontiff, JOHN PAUL II
(Karol WOJTYLA, elected Pope 16 October 1978)
Suffrage: limited to cardinab less than 80 in age
Elections: Supreme Pontiff elected for life by College of
Cardinals
Communists: none known
Other political or pressure groups: none (exclusive of
influence exercised by other church officers in universal
Roman Catholic Church)
Member: IAEA; ITU, IWC— International Wheat Coun-
cil, UPU, WTO; permanent observer status at FAO, OAS,
UN, and UNESCO
Official name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2
federal territories, and 72 island dependencies in the
Caribbean
Legal system: based on Napoleonic code; constitution
promulgated 1961; judicial review of legislative acts in
Cassation Court only; dual court system, state and federal;
250
VENEZUELA (Continued)
legal education at Central University of Venezuela; has not
accepted compulsory 1CJ jurisdiction
National holiday: Independence Day, 5 July
Branches: executive (President), bicameral legislature,
judiciary
Government leader: President Luis HERRERA
CAMPINS
Suffrage: universal and compulsory over age 18, though
rarely enforced
Elections: every five years by secret ballot; last held
December 1978; next national election for President and
bicameral legislature to be held 4 December 1983
Political parties and leaders: Social Christian Party
(COPEI), Rafael Caldera; Accion Democr&tica (AD), Carlos
Andres Perez, Gonzalo Barrios; Movement to Socialism
(MAS), Teodoro Petkoff, Pompeyo M&rauez
Voting strength (1978 election): 46% COPEI, 43% AD,
5% MAS, 6% others '' .
Communists: 3,000-5,000 members (est.)*
Other political or pressure groups: Fedecamaras (a con-
servative business group); Pro- Venezuela (PRO-VEN; a left-
ist, nationalist economic group)
Member of: Andean Pact, AlOEC, FAO, G-77, IADB,
IAEA, IBRD, 1CAO, ICO, 1DB, I FAD, IFC, IHO, 1LO,
1MCO, IMF, 1PU, ITU, IWC— International Wheat Coun-
cil, LAFTA, NAMUCAR (Caribbean Multinational Shipping
Line— Naviera Multinational del Car\\he\\ OAS, OPEC,
SELA, UN, UNESCO, UPU, WHO, WMO, WTO','277bf3b237a1b7e85de2c7c229cf2e21125d51917a1b2124d671bfc73d39317d','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cdbe1aec49572446c783531854ceefb933b0269d2c4212721986934bd9a99f4',1982,'WF','Wallis and Futuna','government',553,'Official name: Territory of the Wallis and Futuna Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members; popular
election of one deputy to National Assembly in Paris and one
senator
Government leaders: Superior Administrator Pierre 1S-
SAC; President of Territorial Assembly Robert TH1L
Suffrage: universal adult
Elections: every five years
253
WALLIS AND FUTUNA (Continued)','ce591404d95a9b92fd5d92e4d624b3bc5f90d3644408743a62ec54943fba10b7','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43391fd6fd8a0362e7723ba6bd6bbb4e2345b7bef08cb250b0638a5db6c85329',1982,'EH','Western Sahara','government',557,'Official name: Western Sahara
Type: legal status of territory and question of sovereignty
unresolved — territory partitioned between Morocco and
Mauritania in April 1976, with Morocco acquiring the
northern two-thirds including the rich phosphate reserves at
Bu Craa. Mauritania, under pressure from the Polisario
guerrillas, abandoned all claims to its portion in August 1979;
Morocco moved to occupy that sector shortly thereafter and
has since asserted administrative control there; OAU-
sponsored referendum proposed to resolve situation while
guerrilla activities continue into 1982
254
WESTERN SAMOA
WESTERN SAHARA (Continued)
Official name: Independent State of Western Samoa
Type: constitutional monarchy under native chief; special
treaty relationship with New Zealand
Capital: Apia
Legal system: based on English common law and local
customs; constitution came into effect upon independence in
1962; judicial review of legislative acts with respect to
fundamental rights of the citizen; has not accepted compul-
sory 1CJ jurisdiction
National holiday: 1 January
255
YEMEN (ADEN)
WESTERN SAMOA (Continued)
Branches; Head of State and Executive Council; Legisla-
tive Assembly; Supreme Court, Court of Appeal, Land and
Titles Court, village courts
Government leaders: Head of State, MAL1ETOA Tanu-
mafili II; Prime Minister Taisi Tupuola EF1
Suffrage: 45 Samoan members of Legislative Assembly
are elected by holders of matai (heads of family) titles (about
12,000 persons); two members who do not have traditional
family ties are elected by universal adult suffrage
Elections: held triennially, last in February 1982
Political parties and leaders: no clearly defined political
party structure
Communists: unknown
Member of: ADB, Commonwealth, ESCAP, FAO, G-77,
IBRD, IDA, 1FAD, 1FC, IMF, South Pacific Forum, South
Pacific Commission, UN, UPU, WHO
Official name: People''s Democratic Republic of Yemen
Type: republic; power centered in ruling Yemeni Socialist
Party (YSP)
Capital: Aden; Madinat ash Sha''b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters)
and English common law (for commercial matters); highest
judicial organ, Federal High Court, interprets constitution
and determines disputes between states
National holiday: 14 October
Branches: Supreme People''s Council; Cabinet
Government leaders: Chairman of the Presidium of the
Supreme People''s Council, YSP Secretary General, and
Prime Minister — "Ali Nasir Muhammad al-HASANl
256
YEMEN (ADEN) (Continued)
Suffrage: granted by constitution to all citizens 18 and
over
Elections: elections for legislative body, Supreme Peopled
Council, called for in constitution; none have been held
Political parties and leaders: Yemeni Socialist Party
(YSP), the only legal party, is coalition of National Front,
Ba''th, and Communist Parties
Communists: unknown number
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, IDA, IFAD, ILO, 1MCO, IMF, 1SCON, ITU,
NAM, UN, UNESCO, UPU, WHO, WMO, WTO
Official name: Yemen Arab Republic
Type: republic; military regime assumed power in June
1974
Capital: Sanaa
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and
local customary law; first constitution promulgated Decem-
ber 1970, suspended June 1974; has not accepted compulsory
ICJ jurisdiction
National holiday: Proclamation of the Republic, 26
September
Branches: President, Prime Minister, Cabinet; Constitu-
ent Assembly
Government leaders: Col. *Ali ''Abdallah SAL1H, Presi-
dent; *Abd Al-KARIM IRYANI, Prime Minister
Communists: small number
Political parties or pressure groups: conservative tribal
groups, some Muslim Brotherhood followers, leftist senti-
ment represented by pro-Iraqi Ba''thists, Nasirists, small
clandestine groups supported by Yemen (Aden)
Member of: Arab League, FAO, G-77, IBRD, ICAO,
IDA, 1FAD, 1FC, ILO, IMCO, IMF, ISCON, ITU, NAM,
UN," UNESCO, UPU, WHO, WIPO, WMO
Official name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: six republics with two autonomous
provinces (within the Republic of Serbia)
Legal system: mixture of civil law system and Communist
legal theory; constitution adopted 1974; legal education at
several law schools; has not accepted compulsory ICJ
jurisdiction
National holiday: Proclamation of the Socialist Federal
Republic of Yugoslavia, 29 November
Branches: parliament (Federal Assembly) constitutionally
supreme; executive includes cabinet (Federal Executive
Council) and the federal administration; judiciary; the State
Presidency is a collective policymaking body composed of a
representative from each republic and province, Sergej
KRAIGHER presides as President of the Republic
Government leader: Veselin Djuranovic, President of the
Federal Executive Council
Suffrage: universal over age 18
Elections: Federal Assembly elected every four years by a
complicated, indirect system of voting
Political parties and leaders: League of Communists of
Yugoslavia (LCY) only; leaders are party President Dusan
Dragosavac, influential Presidium members Milos Minic,
Vladimir Bakaric, and Stane Dolanc
Communists: 2.1 million party members (December 1981)
Other political or pressure groups: Socialist Alliance of
Working People of Yugoslavia (SAWPY), the major mass
front organization for the LCY; Confederation of Trade
Unions of Yugoslavia (CTUY), Union of Youth of Yugoslavia
(UYY), Federation of Yugoslav War Veterans (SUBNOR)
Member of: ASSIMER, CEMA (observer but participates
in certain commissions), EC (five-year nonpreferential trade
agreement signed in May 1973 currently being renegoti-
ated), FAO, G-77, GATT, IAEA, IBA, IBRD, ICAC, ICAO,
IDA, IFAD, IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IPU, ITC, ITU, NAM, OECD
(participant in some activities), UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO
Official name: Republic of Zaire (until October 1971
known as Democratic Republic of the Congo)
Type: republic; constitution establishes strong presidential
system
Capital: Kinshasa
Political subdivisions: eight regions and federal district of
Kinshasa
Legal system: based on Belgian civil law system and tribal
law; new constitution promulgated February 1978; legal
education at National University of Zaire; has not accepted
compulsory ICJ jurisdiction
260
ZAIRE (Continued)
National holiday: Independence Day, 30 June; Anniver-
sary of the Regime, 24 November
Branches: President elected 1970 for seven-year term;
General Mobutu reelected December 1977; limits on reelec-
tion removed by new constitution; national Legislative
Council of 210 members elected for five-year term; the
official party is the supreme political institution
Government leader: Lt. Gen. MOBUTU Sese Seko,
President
Suffrage: universal and compulsory over age 18
Elections: elections for rural collectivities urban zone
councils, and the Legislative Council of the Popular Move-
ment of the Revolution to be held May-September 1982;
presidential referendum/election held December 1977
Political parties and leaders: Popular Movement of the
Revolution (MPR), only legal* party, organized from the
president on down
Voting strength: MPR slate polled 97.5% of vote in 1977
Political Bureau elections; in February 1980 President Mo-
butu announced there would be no further elections to the
Political Bureau
Communists: no Communist party
Member of: AFDB, APC, C1PEC, EAMA, E1B (associate),
FAO, G-77, GATT, IAEA, IBRD, 1CAO, ICO, IDA, 1FAD,
1FC, IHO, 1LO, 1MCO, IMF, 1PU, 1TC, ITU, NAM, OAU,
OCAM, UDEAC, UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO','4c9c63ab7c379afb1f00ccbbcbf4c6ce1382134682b73393034c08f1001cfe18','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a6ad7e38c742d5be2988e9cda7dff4f2f3429d10598ccda953239b7708aa896',1982,'ZM','Zambia','government',561,'Official name: Republic of Zambia
Type: one-party state
Capital: Lusaka
Political subdivisions: nine provinces
Legal system: based on English common law and custom-
ary law; new constitution adopted September 1973; judicial
review of legislative acts in an ad hoc constitutional council;
legal education at University of Zambia in Lusaka; has not
accepted compulsory 1CJ jurisdiction
National holiday: 24 October
Branches: modified presidential system; legislature;
judiciary
Government leaders: President Kenneth David
KAUNDA; Prime Minister Nalumino MUND1A
Suffrage: universal adult
Elections: general election held 12 December 1978; next
general election scheduled for 1983
Political parties and leaders: United National Independ-
ence Party (UN1P), Kenneth Kaunda; former opposition
party banned in December 1972 when one-party state
proclaimed
Voting strength (1978 election): 70% of eligible voters
went to polls; Kaunda was only candidate for President;
National Assembly seats were contested by members of
UN1P
Communists: no Communist party, but socialist sympa-
thizers in upper levels of government and UN1P
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IAEA, IBRD, 1CAO, IDA, 1DB, IEA, IFAD, 1FC,
1LO, International Lead and Zinc Study Group, IMF, 1PU,
ITU, NAM, OAU, UN, UNESCO, UPU, WHO, W1PO,
WMO, WTO','e3c2436e5b84a88bd558d8c40c0e1038cbeab50529f0f6dcd1b7ebcb8e1743f2','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06b608b9aa3d7512d2a73dd2382a7595a7532e50d17de6648f2de570f6d13227',1982,'ZW','Zimbabwe','government',566,'Official name: Republic of Zimbabwe
Type: independent since 18 April 1980; a British-style
parliamentary democracy
Capital: Salisbury
Political subdivisions: eight provinces
Legal system: British common law tradition
Branches: legislative authority resides in a Parliament
consisting of a 100-member House of Assembly (with 20
seats reserved for whites) and a 40-member Senate (10
263
ZIMBABWE (Continued)
elected by white members of the House, 14 elected by the
other members of the House; 10 chiefs, 5 from Mashonaland
and 5 from Matabeleland, elected by members of the
Council of Chiefs; 6 appointed by the President, on the
advice of the Prime Minister); executive authority lies with a
Cabinet led by the Prime Minister; the High Court is the
superior judicial authority
Government leaders: President Canaan BANANA; Prime
Minister Robert MUGABE
Suffrage: universal over age 18
Elections: at discretion of Prime Minister but must be
held before expiration of five-year electoral mandate
Political parties and leaders: Zimbabwe African National
Union (ZANU), Robert Mugabe; Zimbabwe African People''s
Union (ZAPU), Joshua Nkomo; Republican Front (RF), Ian.
Smith; United African National Council (UANC), Bishop
Abel Muzorewa; others failed to win any seats in Parliament
Voting strength (February 1980 elections): ZANU (also
known as ZANU-PF), 57 seats; ZAPU (also known as the
Patriotic Front), 20 seats; RF, 20 seats; UANC, 3 seats
Communists: negligible
Member of: IAEA, IBRD, IDA, IFC, ILO, IMF, UN,
UPU, WHO','69d7e6ffd15262b08e7758382ea81db5314b4292cbdfd229d7f636796e468400','internet-archive','1982CIAWorldFactbook','txt','4d3f5462d81d553b52e8dfe76f7b8c96c6de3bb0d67fb02552588f56fbfec367','https://archive.org/download/1982CIAWorldFactbook/1982CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82123df14674f11f91b743d0c595f806e4c6f458ba73ca73082bf671b3d27cb8',2006,'','','raw',1,'The Project Gutenberg EBook of The 2006 CIA World Factbook, by United States
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2006 CIA World Factbook
Author: United States
Release Date: December 12, 2008 [EBook #27509]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2006 CIA WORLD FACTBOOK ***
Produced by Al Haines
THE CIA WORLD FACTBOOK 2006
CONTENTS
Countries and Locations
Field Listings
Rank Orders
Appendixes
Notes and Definitions
History of The World Factbook
Contributors and Copyright Information
Purchasing Information
Frequently Asked Questions (FAQs)
=====================================================================
What''s New
- Country information has been updated as of 19 December 2006.
- There have been some significant changes to the latest edition of
The World Factbook. The successful secession referendum held in
Montenegro in May of 2006 allowed it to legally leave its union
with Serbia the following month. These two Balkan countries have now
been formally recognized and are listed separately in the Factbook.
- In the Government category, the ''Capital'' entry has been greatly
expanded and now contains up to four subfields, including significant
new information having to do with time. The subfields consist of the
name of the capital itself, its geographic coordinates, the time
difference at the capital from coordinated universal time (UTC), and,
if applicable, information on daylight saving time (DST). Where
appropriate, a special note has been added to highlight those
countries that have multiple time zones.
- The Transnational issues category now has a "Trafficking in persons"
entry. Human trafficking connotes modern-day slavery and this important
new field will include information on the most egregious countries
(Tier 2 Watch List and Tier 3) as listed in the US State Department''s
annual report.
- A new Appendix G lists Weights and Measures. The appendix includes
information on mathematical notation and metric interrelationships,
as well as over 400 examples of standard conversion factors.
- Revision of some individual country maps, first introduced in the
2001 edition, is continued in this edition. Several regional maps
have also been updated to reflect boundary changes and place name
spelling changes.
=====================================================================
The World Factbook (2006) - Country Listing
[Transcriber''s note: To search on a country in this file, prefix the
country''s name with "@", e.g. "@Afghanistan". "Afghanistan" will find
all occurrences; prefixing it with "@" will find the correct location.]
World
A','78bd4303697060ae053da76d0dd86384174c5f263a6892a528b6dbe53ef7a706','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc2b25698820054db48ed6d37865eb3989cece3e6f01d884852f43d2ba0c86aa',2006,'ET','Ethiopia','raw',2,'Europa Island
European Union entry follows Taiwan
F
Falkland Islands (Islas Malvinas)','a3f242142f5c679e6bc84b2de40b959a981663bba1ffa29911500bc4ea89bd2d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d22dd47bb9b914a4fee38d671f951fe359e589ca23fe8e4a0bdd53105edb9b6',2006,'ZW','Zimbabwe','raw',3,'Taiwan
European Union
=====================================================================
Field Listings
[Transcriber''s note: To search on a field code in this file, prefix
the code number with "@", e.g. "@2001". "2001" will find all
occurrences; prefixing it with "@" will find the correct location.]
Code Field Description
2001 GDP (purchasing power parity)
2002 Population growth rate (%)
2003 GDP - real growth rate (%)
2004 GDP - per capita (PPP)
2006 Dependency status
2007 Diplomatic representation from the US
2008 Transportation - note
2010 Age structure (%)
2011 Geographic coordinates
2012 GDP - composition by sector (%)
2013 Radio broadcast stations
2015 Television broadcast stations
2018 Sex ratio (male(s)/female)
2019 Heliports
2020 Elevation extremes (m)
2021 Natural hazards
2022 People - note
2023 Area - comparative
2024 Military service age and obligation (years of age)
2025 Manpower fit for military service
2026 Manpower reaching military service age annually
2028 Background
2030 Airports - with paved runways
2031 Airports - with unpaved runways
2032 Environment - current issues
2033 Environment - international agreements
2034 Military expenditures - percent of GDP (%)
2038 Electricity - production (kWh)
2042 Electricity - consumption (kWh)
2043 Electricity - imports (kWh)
2044 Electricity - exports (kWh)
2046 Population below poverty line (%)
2047 Household income or consumption by percentage share (%)
2048 Labor force - by occupation (%)
2049 Exports - commodities
2050 Exports - partners (%)
2051 Administrative divisions
2052 Agriculture - products
2053 Airports
2054 Birth rate (births/1,000 population)
2055 Military branches
2056 Budget
2057 Capital
2058 Imports - commodities
2059 Climate
2060 Coastline (km)
2061 Imports - partners (%)
2062 Economic aid - donor
2063 Constitution
2064 Economic aid - recipient
2065 Currency (code)
2066 Death rate (deaths/1,000 population)
2067 Military expenditures - dollar figure
2068 Dependent areas
2070 Disputes - international
2075 Ethnic groups (%)
2076 Exchange rates
2077 Executive branch
2078 Exports
2079 Debt - external
2080 Fiscal year
2081 Flag description
2085 Roadways (km)
2086 Illicit drugs
2087 Imports
2088 Independence
2089 Industrial production growth rate (%)
2090 Industries
2091 Infant mortality rate (deaths/1,000 live births)
2092 Inflation rate (consumer prices) (%)
2093 Waterways (km)
2094 Judicial branch
2095 Labor force
2096 Land boundaries (km)
2097 Land use (%)
2098 Languages (%)
2100 Legal system
2101 Legislative branch
2102 Life expectancy at birth (years)
2103 Literacy (%)
2105 Manpower available for military service
2106 Maritime claims
2107 International organization participation
2108 Merchant marine
2109 National holiday
2110 Nationality
2111 Natural resources
2112 Net migration rate (migrant(s)/1,000 population)
2113 Geography - note
2115 Political pressure groups and leaders
2116 Economy - overview
2117 Pipelines (km)
2118 Political parties and leaders
2119 Population
2120 Ports and terminals
2121 Railways (km)
2122 Religions (%)
2123 Suffrage
2124 Telephone system
2125 Terrain
2127 Total fertility rate (children born/woman)
2128 Government type
2129 Unemployment rate (%)
2137 Military - note
2138 Communications - note
2140 Government - note
2142 Country name
2144 Location
2145 Map references
2146 Irrigated land (sq km)
2147 Area (sq km)
2149 Diplomatic representation in the US
2150 Telephones - main lines in use
2151 Telephones - mobile cellular
2153 Internet users
2154 Internet country code
2155 HIV/AIDS - adult prevalence rate (%)
2156 HIV/AIDS - people living with HIV/AIDS
2157 HIV/AIDS - deaths
2172 Distribution of family income - Gini index
2173 Oil - production (bbl/day)
2174 Oil - consumption (bbl/day)
2175 Oil - imports (bbl/day)
2176 Oil - exports (bbl/day)
2177 Median age (years)
2178 Oil - proved reserves (bbl)
2179 Natural gas - proved reserves (cu m)
2180 Natural gas - production (cu m)
2181 Natural gas - consumption (cu m)
2182 Natural gas - imports (cu m)
2183 Natural gas - exports (cu m)
2184 Internet hosts
2185 Investment (gross fixed) (% of GDP)
2186 Public debt (% of GDP)
2187 Current account balance
2188 Reserves of foreign exchange and gold
2193 Major infectious diseases
2194 Refugees and internally displaced persons
2195 GDP (official exchange rate)
2196 Trafficking in persons
======================================================================
Rank Orders
[Transcriber''s note: To search on a rank order in this file, prefix
the rank''s name with "@", e.g. "@Population". "Population" will find
all occurrences; prefixing it with "@" will find the correct location.]
Guide to Rank Order Pages
Rank Order pages are presorted lists of data from selected Factbook
data fields. Rank Order pages are generally given in descending
order -highest to lowest - such as Population and Area. The two
exceptions are Unemployment Rate and Inflation Rate, which are in
ascending - lowest to highest - order. Rank Order pages are
available for the following 47 fields in six of the nine Factbook
categories.','3b8a80798e52f9fd82c52da37f6d3e21c6e3618795f8bde83200567f14176bc1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b7d099c7f8beca12c6b76e168aa5e9ccd31038d27e44b74182f2d211ddef9bd',2006,'ZW','Zimbabwe','military-and-security',19,'Military expenditures - dollar figure
Military expenditures - percent of GDP
Factbook fields with Rank Order pages are easily identified with a
small bar chart icon to the right of the data field title.
Not all Rank Order pages include the same number of entries because
information for a particular field is not available for all
countries. In addition, not all data fields are suitable for
displaying as Rank Order pages, such as those containing textual
information. Textual information is more readily viewed by clicking
on the Field Listing icon next to the Data field title. The other
icon next to the data field title provides the definition of the
field.
All of the ''Rank Order'' pages can be downloaded as tab-delimited
data files and can be opened in other applications such as
spreadsheets and databases. To save a Rank Order page in a
spreadsheet, first click on the ''Download Datafile'' choice above the
Rank Order page you selected; then, at the top of your browser
window, click on ''File'' and ''Save As''. After saving the file, open
the spreadsheet, find the saved file, and ''Open'' it.
Additional Rank Order pages being considered for future updates of
the Factbook Web site include:
Median age
Literacy
Population below the poverty line
This page was last updated on 4 April, 2006
=====================================================================
Appendixes
Appendix A - Abbreviations
Appendix B - International Organizations and Groups
Appendix C - Selected International Environmental Agreements
Appendix D - Cross-Reference list of Country Data Codes
Appendix E - Cross-Reference List of Hydrographic Data Codes
Appendix F - Cross-Reference List of Geographic Names
Appendix G - Weights and Measures
======================================================================
Notes and Definitions
Along with regular information updates, The World Factbook features
several new or revised fields. In the Economy category, the Factbook is
now reporting national GDP figures in US dollars converted at Official
Exchange Rates (OER) in addition to GDP at Purchasing Power Parity
(PPP) rates, since both measures contain information useful to our
readers. Traditionally, only PPP-converted GDP values had been
reported. In the Transportation category, the former Highways entry is
now Roadways, while Ports and harbors has been retitled Ports and
terminals.
Abbreviations
This information is included in Appendix A: Abbreviations, which
includes all abbreviations and acronyms used in the Factbook, with
their expansions.
Acronyms
An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up
solely from the first letter of the major words in the expanded form is
rendered in all capital letters (NATO from North Atlantic Treaty
Organization; an exception would be ASEAN for Association of Southeast
Asian Nations). In general, an acronym made up of more than the first
letter of the major words in the expanded form is rendered with only an
initial capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned Movement).
Hybrid forms are sometimes used to distinguish between initially
identical terms (WTO: for World Trade Organization and WToO for World
Tourism Organization.)
Administrative divisions
This entry generally gives the numbers, designatory terms, and first-
order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet
acted on by BGN are noted.
Age structure
This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64
years, 65 years and over). The age structure of a population affects a
nation''s key socioeconomic issues. Countries with young populations
(high percentage under age 15) need to invest more in schools, while
countries with older populations (high percentage ages 65 and over)
need to invest more in the health sector. The age structure can also be
used to help predict potential political issues. For example, the rapid
growth of a young adult population unable to find employment can lead
to unrest.
Agriculture - products
This entry is an ordered listing of major crops and products starting
with the most important.
Airports
This entry gives the total number of airports or airfields recognizable
from the air. The runway(s) may be paved (concrete or asphalt surfaces)
or unpaved (grass, earth, sand, or gravel surfaces) but may include
closed or abandoned installations. Airports or airfields that are no
longer recognizable (overgrown, no facilities, etc.) are not included.
Note that not all airports have accomodations for refueling,
maintenance, or air traffic control.
Airports - with paved runways
This entry gives the total number of airports with paved runways
(concrete or asphalt surfaces) by length. For airports with more than
one runway, only the longest runway is included according to the
following five groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3)
1,524 to 2,437 m, (4) 914 to 1,523 m, and (5) under 914 m. Only
airports with usable runways are included in this listing. Not all
airports have facilities for refueling, maintenance, or air traffic
control.
Airports - with unpaved runways
This entry gives the total number of airports with unpaved runways
(grass, dirt, sand, or gravel surfaces) by length. For airports with
more than one runway, only the longest runway is included according to
the following five groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3)
1,524 to 2,437 m, (4) 914 to 1,523 m, and (5) under 914 m. Only
airports with usable runways are included in this listing. Not all
airports have facilities for refueling, maintenance, or air traffic
control.
Appendixes
This section includes Factbook-related material by topic.
Area
This entry includes three subfields. Total area is the sum of all land
and water areas delimited by international boundaries and/or
coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of the
surfaces of all inland water bodies, such as lakes, reservoirs, or
rivers, as delimited by international boundaries and/or coastlines.
Area - comparative
This entry provides an area comparison based on total area equivalents.
Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of
the Census. The smaller entities are compared with Washington, DC (178
sq km, 69 sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi,
146 acres).','153b6643bd9d11933029af66b4b7760a7efbb1fc15ad0501c978ae18eeeb91c8','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3d64fe5a179b4841f3850c9bdea282e53d26b0b1a4698f9108d728bcbd2300f',2006,'EH','Western Sahara','military-and-security',32,'This category includes the entries dealing with a country''s military
structure, manpower, and expenditures.
Military - note
This entry includes miscellaneous military information of significance
not included elsewhere.
Military branches
This entry lists the service branches subordinate to defense ministries
or the equivalent (typically ground, naval, air, and marine forces).
Military expenditures - dollar figure
This entry gives spending on defense programs in US dollars for the
most recent year available; dollar figures for military expenditures
should be treated with caution because of different price patterns and
accounting methods among nations, as well as wide variations in the
strength of different currencies.
Military expenditures - percent of GDP
This entry gives spending on defense programs for the most recent year
available as a percent of gross domestic product (GDP); the GDP is
calculated on an exchange rate basis, i.e., not in terms of purchasing
power parity (PPP).
Military service age and obligation
This entry gives the required ages for voluntary or conscript military
service and the length of sevice obligation.
Money figures
All money figures are expressed in contemporaneous US dollars unless
otherwise indicated.
National holiday
This entry gives the primary national day of celebration - usually
independence day.
Nationality
This entry provides the identifying terms for citizens - noun and
adjective.
Natural gas - consumption
This entry is the total natural gas consumed in cubic meters (cu m).
The discrepancy between the amount of natural gas produced and/or
imported and the amount consumed and/or exported is due to the omission
of stock changes and other complicating factors.
Natural gas - exports
This entry is the total natural gas exported in cubic meters (cu m).
Natural gas - imports
This entry is the total natural gas imported in cubic meters (cu m).
Natural gas - production
This entry is the total natural gas produced in cubic meters (cu m).
The discrepancy between the amount of natural gas produced and/or
imported and the amount consumed and/or exported is due to the omission
of stock changes and other complicating factors.
Natural gas - proved reserves
This entry is the stock of proved reserves of natural gas in cubic
meters (cu m). Proved reserves are those quantities of natural gas,
which, by analysis of geological and engineering data, can be estimated
with a high degree of confidence to be commercially recoverable from a
given date forward, from known reservoirs and under current economic
conditions.
Natural hazards
This entry lists potential natural disasters.
Natural resources
This entry lists a country''s mineral, petroleum, hydropower, and other
resources of commercial importance.
Net migration rate
This entry includes the figure for the difference between the number of
persons entering and leaving a country during the year per 1,000
persons (based on midyear population). An excess of persons entering
the country is referred to as net immigration (e.g., 3.56
migrants/1,000 population); an excess of persons leaving the country as
net emigration (e.g., -9.26 migrants/1,000 population). The net
migration rate indicates the contribution of migration to the overall
level of population change. High levels of migration can cause problems
such as increasing unemployment and potential ethnic strife (if people
are coming in) or a reduction in the labor force, perhaps in certain
key sectors (if people are leaving).
Oil - consumption
This entry is the total oil consumed in barrels per day (bbl/day). The
discrepancy between the amount of oil produced and/or imported and the
amount consumed and/or exported is due to the omission of stock
changes, refinery gains, and other complicating factors.
Oil - exports
This entry is the total oil exported in barrels per day (bbl/day),
including both crude oil and oil products.
Oil - imports
This entry is the total oil imported in barrels per day (bbl/day),
including both crude oil and oil products.
Oil - production
This entry is the total oil produced in barrels per day (bbl/day). The
discrepancy between the amount of oil produced and/or imported and the
amount consumed and/or exported is due to the omission of stock
changes, refinery gains, and other complicating factors.
Oil - proved reserves
This entry is the stock of proved reserves of crude oil in barrels
(bbl). Proved reserves are those quantities of petroleum which, by
analysis of geological and engineering data, can be estimated with a
high degree of confidence to be commercially recoverable from a given
date forward, from known reservoirs and under current economic
conditions.','8d33d2f20d5bee8124d13b5a6b5b0dd9e56128518193debab423ccabcbf8c271','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b965c772995f40342ee53d2c9b5c7c3161b0e9c685388fdce1486e36248654c',2006,'EH','Western Sahara','geography',25,'This category includes the entries dealing with the natural environment
and the effects of human activity.
Geography - note
This entry includes miscellaneous geographic information of
significance not included elsewhere.
Gini index
See entry for Distribution of family income - Gini index
Spelling and Pronunciation
Policies and Procedures
Technical
General
Can you provide additional information for a specific country?
The staff cannot provide data beyond what appears in The World
Factbook. The format and information in the Factbook are tailored to
the specific requirements of US Government officials and content is
focused on their current and anticipated needs. The staff welcomes
suggestions for new entries.
How often is The World Factbook updated?
Formerly our Web site (and the published Factbook) were only updated
annually. Beginning in November 2001 we instituted a new system of
more frequent online updates. The World Factbook is currently
updated every two weeks.
The annual printed version of the Factbook is usually released about
midyear. US Government officials may obtain information about
Factbook availability from their own organizations or through
liaison channels to the CIA. Other users may obtain sales
information through the following channels:
Superintendent of Documents
P. O. Box 371954 Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512-1800
FAX: [1] (202) 512-2250
http://bookstore.gpo.gov
National Technical Information Service
5285 Port Royal Road Springfield, VA 22161
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov
Can I use some or all of The World Factbook for my Web site (book,
research project, homework, etc.)?
The World Factbook is in the public domain and may be used freely by
anyone at anytime without seeking permission. However, US Code
prohibits use of the CIA seal in a manner which implies that the CIA
approved, endorsed, or authorized such use. If you have any
questions about your intended use, you should consult with legal
counsel. Further information on The World Factbook''s use is
described on the Contributors and Copyright Information page. As a
courtesy, please cite The World Factbook when used.
Why doesn''t The World Factbook include information on states,
departments, provinces, etc., in the country format?
The World Factbook provides national-level information on countries,
territories, and dependencies, but not subnational administrative
units within a country. A good encyclopedia should provide
state/province-level information.
Is it possible to access older editions of The World Factbook to do
comparative research and trend analysis?
Only the current version is available for browsing on the CIA Web
site. In the future, the staff hopes to post electronic versions of
The World Factbook as far back as 1986. Hardcopy editions for
earlier years are available from libraries.
Would it be possible to set up a partnership or collaboration
between the producers of The World Factbook and other organizations
or individuals?
The World Factbook does not partner with other organizations or
individuals, but we do welcome comments and suggestions that such
groups or persons choose to provide.
I can''t find a geographic name for a particular country. Why not?
The World Factbook is not a gazetteer (a dictionary or index of
places, usually with descriptive or statistical information) and
cannot provide more than the names of the administrative divisions
(in the Government category) and major cities/towns (on the country
maps). Our expanded Cross-Reference List of Geographic Names,
however, includes many of the world''s major geographic features as
well as historic (former) names of countries and cities mentioned in
The World Factbook.
Why are Taiwan and the European Union listed out of alphabetical
order at the end of the Factbook entries?
Taiwan is listed after the regular entries because even though the
mainland People''s Republic of China claims Taiwan, elected Taiwanese
authorities de facto administer the island and reject mainland
sovereignty claims. With the establishment of diplomatic relations
with China on January 1, 1979, the US Government recognized the
People''s Republic of China as the sole legal government of China,
acknowledging the Chinese position that there is only one China and
that Taiwan is part of China.
The European Union (EU) is not a country, but it has taken on many
nation-like attributes and these are likely to be expanded in the
future. A more complete explanation on the inclusion of the EU into
the Factbook may be found in the Preliminary statement.
Since we have an ambassador who represents the US at the Vatican,
why is this entity not listed in the Factbook?
Vatican City is found under Holy See. The term "Holy See" refers to
the authority, jurisdiction, and sovereignty vested in the Pope and
his advisors to direct the worldwide Catholic Church. The Holy See
has a legal personality that allows it to enter into treaties as the
juridical equal of a state and to send and receive diplomatic
representatives. Vatican City, created in 1929 to administer
properties belonging to the Holy See in Rome, is recognized under
international law as a sovereign state, but it does not send or
receive diplomatic representatives. Consequently, Holy See is
included as a Factbook entry, with Vatican City cross-referenced in
the Geographic Names appendix.
Why is Palestine not listed in The World Factbook?
The areas that could potentially form a future Palestinian state --
the West Bank and Gaza Strip -- do appear in the Factbook. These
areas are presently Israeli-occupied with current status subject to
the Israeli-Palestinian 1995 Interim Agreement; their permanent
status is to be determined through further negotiation.
Why are the Golan Heights not shown as part of Israel or Northern
Cyprus with Turkey?
Territorial occupations/annexations not recognized by the United
States Government are not shown on US Government maps.
Why don''t you include information on entities such as Tibet,
Kashmir, or Kosovo?
The World Factbook provides information on the administrative
divisions of a country as recommended by the United States Board on
Geographic Names (BGN). The BGN is a component of the US Government
that develops policies, principles, and procedures governing the
spelling, use, and application of geographic names--domestic,
foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to have access to
uniform names of geographic features.
Also included in the Factbook are entries on parts of the world
whose status has not yet been resolved (e.g., West Bank, Spratly
Islands). Specific regions within a country or areas in dispute
among countries are not covered.
What do you mean when you say that a country is "doubly landlocked"?
A doubly landlocked country is one that is separated from an ocean
or an ocean-accessible sea by two intervening countries. Uzbekistan
and Liechtenstein are the only countries that fit this definition.
Spelling and Pronunciation
Why is the spelling of proper names such as rulers, presidents, and
prime ministers in The World Factbook different than their spelling
in my country?
The Factbook staff applies the names and spellings from the Chiefs
of State link on the CIA Web site. The World Factbook is prepared
using the standard American English computer keyboard and does not
use any special characters, symbols, or most diacritical markings in
its spellings. Surnames are always spelled with capital letters;
they may appear first in some cultures.
The spelling of geographic names, features, cities, administrative
divisions, etc. in the Factbook differs from those used in my
country. Why is this?
The United States Board on Geographic Names (BGN) recommends and
approves names and spellings. The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic
names--domestic, foreign, Antarctic, and undersea. Its decisions
enable all departments and agencies of the US Government to use
uniform names of geographic features. (A note is usually included
where changes may have occurred but have not yet been approved by
the BGN). The World Factbook is prepared using the standard American
English computer keyboard and does not use any special characters,
symbols, or most diacritical markings in its spellings.
Why doesn''t The World Factbook include pronunciations of country or
leader names?
There are too many variations in pronunciation among
English-speaking countries, not to mention English renditions of
non-English names, for pronunciations to be included. American
English pronunciations are included for some countries like Qatar
and Kiribati.
Why is the name of the Labour party misspelled?
When American and British spellings of common English words differ,
The World Factbook always uses the American spelling, even when
these common words form part of a proper name in British English.
Policies and Procedures
What is The World Factbook''s source for a specific subject field?
The Factbook staff uses many different sources to publish what we
judge are the most reliable and consistent data for any particular
category. Space considerations preclude a listing of these various
sources.
The names of some geographic features provided in the Factbook
differ from those used in other publications. For example, in Asia
the Factbook has Burma as the country name, but in other
publications Myanmar is used; also, the Factbook uses Sea of Japan
whereas other publications label it East Sea. What is your policy on
naming geographic features?
The Factbook staff follows the guidance of the United States Board
on Geographic Names (BGN). The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic
names--domestic, foreign, Antarctic, and undersea. Its decisions
enable all departments and agencies of the US Government to have
access to uniform names of geographic features. The position of the
BGN is that the names Burma and Sea of Japan be used in official US
Government maps and publications.
Why is most of the statistical information in the Factbook given in
metric units, rather than the units standard to US measure?
US Federal agencies are required by the Metric Conversion Act of
1975 (Public Law 94-168) and by Executive Order 12770 of July 1991
to use the International System of Units, commonly referred to as
the metric system or SI. In addition, the metric system is used by
over 95 percent of the world''s population.
Why don''t you include information on minimum and maximum temperature
extremes?
The Factbook staff judges that this information would only be useful
for some (generally smaller) countries. Larger countries can have
large temperature extremes that do not represent the landmass as a
whole. In the future, such a category may be adopted listing the
extremes, but also adding a normal temperature range found
throughout most of a country''s territory.
What information sources are used for the country flags?
Flag designs used in The World Factbook are those recognized by the
protocol office of the US Department of State.
Why do your GDP (Gross Domestic Product) statistics differ from
other sources?
We have two sets of GDP dollar estimates in The World Factbook , one
derived from purchasing power parity (PPP) calculations and the
other derived using official exchange rates (OER). Other sources
probably use one of the two. See the Notes and Definitions section
on GDP and GDP methodology for more information.
On the CIA Web site, Chiefs of State is updated weekly, but the last
update for the Factbook was an earlier date. Why the discrepancy?
Although Chiefs of State and The World Factbook both appear on the
CIA Web site, they are produced and updated by separate staffs.
Chiefs of State includes fewer countries but more leaders, and is
updated more frequently than The World Factbook, which has a much
larger database, and includes all countries.
Some percentage distributions do not add to 100. Why not?
Because of rounding, percentage distributions do not always add
precisely to 100%. Rounding of numbers always results in a loss of
precision--i.e., error. This error becomes apparent when percentage
data are totaled, as the following two examples show:
Original Data Rounded to whole integer
Example 1 43.2 43
30.4 30
26.4 26
---- --
100.0 99
Example 2 42.8 43
31.6 32
25.6 26
---- --
100.0 101
When this occurs, we do not force the numbers to add exactly to 100,
because doing so would introduce additional error into the
distribution.
What rounding convention does The World Factbook use?
In deciding on the number of digits to present, the Factbook staff
assesses the accuracy of the original data and the needs of US
Government officials. All of the economic data are processed by
computer--either at the source or by the Factbook staff. The economic
data presented in The Factbook, therefore, follow the rounding
convention used by virtually all numerical software applications,
namely, any digit followed by a "5" is rounded up to the next higher
digit, no matter whether the original digit is even or odd. Thus,
for example, when rounded to the nearest integer, 2.5 becomes 3,
rather than 2, as occurred in some pre-computer rounding systems.
Why do you list "Independence" dates for countries like France,
Germany, and the United Kingdom?
For most countries, this entry presents the date that sovereignty
was achieved and from which nation, empire, or trusteeship. For
other countries, the date may be some other significant nationhood
event such as the traditional founding date or the date of
unification, federation, confederation, establishment, or state
succession and so may not strictly be an "Independence" date.
Dependent entities have the nature of their dependency status noted
in this same entry.
Technical
Does The World Factbook comply with Section 508 of the
Rehabilitation Act regarding accessibility of Web pages?
The World Factbook home page has a link entitled "Text/Low Bandwidth
Version." The country data in the text version is fully accessible.
We believe The World Factbook is compliant with the Section 508 law
in both fact and spirit. If you are experiencing difficulty, please
use our comment form to provide us details of the specific problem
you are experiencing and the assistive software and/or hardware that
you are using so that we can work with our technical support staff
to find and implement a solution. We welcome visitors'' suggestions
to improve accessibility of The World Factbook and the CIA Web site.
I am using the Factbook online and it is not working. What is wrong?
Hundreds of "Factbook" look-alikes exist on the Internet. The
Factbook site at: www.cia.gov is the only official site.
When I attempt to download a PDF (Portable Document Format) map file
(or some other map) the file has no image. Can you fix this?
Some of the files on The World Factbook Web site are large and could
take several minutes to download on a dial-up connection. The screen
might be blank during the download process.
When I open a map on The World Factbook site, it is fuzzy or
granular, or too big or too small. Why?
Adjusting the resolution setting on your monitor should correct this
problem.
Is The World Factbook country data available in machine-readable
format? All I can find is HTML, but I''m looking for simple tabular
data.
The Factbook Web site now features "Rank Order" pages for selected
Factbook entries. "Rank Order" pages are available for those data
fields identified with a small bar chart icon located next to the
title of the data entry. In addition, all of the "Rank Order" pages
can be downloaded as tab-delimited data files that can be opened in
other applications such as spreadsheets and databases.
This page was last updated on 23 August, 2006
=====================================================================
@Afghanistan
Introduction Afghanistan','4bcb208fbd16901744783c676600639f2bc13e28b4badbd652a745356b8a6e1b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

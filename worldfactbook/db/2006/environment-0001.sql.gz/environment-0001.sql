SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aed401e16ab3f9f389fb94cafa8c53894bcf38abf3865225b3f4d40eab8fa59',2006,'EH','Western Sahara','environment',24,'Soil degradation - damage to the land''s productive capacity because of
poor agricultural practices such as the excessive use of pesticides or
fertilizers, soil compaction from heavy equipment, or erosion of
topsoil, eventually resulting in reduced ability to produce
agricultural products.
Soil erosion - the removal of soil by the action of water or wind,
compounded by poor agricultural practices, deforestation, overgrazing,
and desertification.
Ultraviolet (UV) radiation - a portion of the electromagnetic energy
emitted by the sun and naturally filtered in the upper atmosphere by
the ozone layer; UV radiation can be harmful to living organisms and
has been linked to increasing rates of skin cancer in humans.
Water-born diseases - those in which bacteria survive in, and are
transmitted through, water; always a serious threat in areas with an
untreated water supply.
Environment - international agreements
This entry separates country participation in international
environmental agreements into two levels - party to and signed, but not
ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements
This information is presented in Appendix C: Selected International
Environmental Agreements, which includes the name, abbreviation, date
opened for signature, date entered into force, objective, and parties
by category.
Ethnic groups
This entry provides an ordered listing of ethnic groups starting with
the largest and normally includes the percent of total population.
Exchange rates
This entry provides the official value of a country''s monetary unit at
a given date or over a given period of time, as expressed in units of
local currency per US dollar and as determined by international market
forces or official fiat.
Executive branch
This entry includes several subfields. Chief of state includes the name
and title of the titular leader of the country who represents the state
at official and ceremonial functions but may not be involved with the
day-to-day activities of the government. Head of government includes
the name and title of the top administrative leader who is designated
to manage the day-to-day activities of the government. For example, in
the UK, the monarch is the chief of state, and the prime minister is
the head of government. In the US, the president is both the chief of
state and the head of government. Cabinet includes the official name
for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession
to power, date of the last election, and date of the next election.
Election results includes the percent of vote for each candidate in the
last election.
Exports
This entry provides the total US dollar amount of merchandise exports
on an f.o.b. (free on board) basis. These figures are calculated on an
exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
Exports - commodities
This entry provides a rank ordering of exported products starting with
the most important; it sometimes includes the percent of total dollar
value.
Exports - partners
This entry provides a rank ordering of trading partners starting with
the most important; it sometimes includes the percent of total dollar
value.
Fiscal year
This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but
which may begin in any month. All yearly references are for the
calendar year (CY) unless indicated as a noncalendar fiscal year (FY).
Flag description
This entry provides a written flag description produced from actual
flags or the best information available at the time the entry was
written. The flags of independent states are used by their dependencies
unless there is an officially recognized local flag. Some disputed and
other areas do not have flags.
Flag graphic
Most versions of the Factbook include a color flag at the beginning of
the country profile. The flag graphics were produced from actual flags
or the best information available at the time of preparation. The flags
of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not
have flags.
GDP (official exchange rate)
This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. A nation''s
GDP at offical exchange rates (OER) is the home-currency-denominated
annual GDP figure divided by the bilateral average US exchange rate
with that country in that year. The measure is simple to compute and
gives a precise measure of the value of output. Many economists prefer
this measure when gauging the economic power an economy maintains vis-
à-vis its neighbors, judging that an exchange rate captures the
purchasing power a nation enjoys in the international marketplace.
Official exchange rates, however, can be artifically fixed and/or
subject to manipulation - resulting in claims of the country having an
under- or over-valued currency - and are not necessarily the equivalent
of a market-determined exchange rate. Moreover, even if the official
exchange rate is market-determined, market exchange rates are
frequently established by a relatively small set of goods and services
(the ones the country trades) and may not capture the value of the
larger set of goods the country produces. Furthermore, OER-converted
GDP is not well suited to comparing domestic GDP over time, since
appreciation/depreciation from one year to the next will make the OER
GDP value rise/fall regardless of whether home-currency-denominated GDP
changed.
GDP (purchasing power parity)
This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. A nation''s
GDP at purchasing power parity (PPP) exchange rates is the sum value of
all goods and services produced in the country valued at prices
prevailing in the United States. This is the measure most economists
prefer when looking at per-capita welfare and when comparing living
conditions or use of resources across countries. The measure is
difficult to compute, as a US dollar value has to be assigned to all
goods and services in the country regardless of whether these goods and
services have a direct equivalent in the United States (for example,
the value of an ox-cart or non-US military equipment); as a result, PPP
estimates for some countries are based on a small and sometimes
different set of goods and services. In addition, many countries do not
formally participate in the World Bank''s PPP project that calculates
these measures, so the resulting GDP estimates for these countries may
lack precision. For many developing countries, PPP-based GDP measures
are multiples of the official exchange rate (OER) measure. The
difference between the OER- and PPP-denominated GDP values for most of
the weathly industrialized countries are generally much smaller.
GDP - composition by sector
This entry gives the percentage contribution of agriculture, industry,
and services to total GDP. The distribution will total less than 100
percent if the data are incomplete.
GDP - per capita (PPP)
This entry shows GDP on a purchasing power parity basis divided by
population as of 1 July for the same year.
GDP - real growth rate
This entry gives GDP growth on an annual basis adjusted for inflation
and expressed as a percent.
GDP methodology
In the Economy category, GDP dollar estimates for countries are
reported both on an official exchange rate (OER) and a purchasing power
parity (PPP) basis. Both measures contain information that is useful to
the reader. The PPP method involves the use of standardized
international dollar price weights, which are applied to the quantities
of final goods and services produced in a given economy. The data
derived from the PPP method probably provides the best available
starting point for comparisons of economic strength and well-being
between countries. In contrast, the currency exchange rate method
involves a variety of international and domestic financial forces that
may not capture the value of domestic output. Furthermore, exchange
rates may suddenly go up or down by 10% or more because of market
forces or official fiat whereas real output has remained unchanged. On
12 January 1994, for example, the 14 countries of the African Financial
Community (whose currencies are tied to the French franc) devalued
their currencies by 50%. This move, of course, did not cut the real
output of these countries by half. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries
are often rough approximations. In developing countries with weak
currencies, the exchange rate estimate of GDP in dollars is typically
one-fourth to one-half the PPP estimate. Most of the GDP estimates for
developing countries are based on extrapolation of PPP numbers
published by the UN International Comparison Program (UNICP) and by
Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. GDP derived using the OER method
should be used for the purpose of calculating the share of items such
as exports, imports, military expenditures, external debt, or the
current account balance, because the dollar values presented in the
Factbook for these items have been converted at official exchange
rates, not at PPP. One should use the OER GDP figure to calculate the
proportion of, say, Chinese defense expenditures in GDP, because that
share will be the same as one calculated in local currency units.
Comparison of OER GDP with PPP GDP may also indicate whether a currency
is over- or under-valued. If OER GDP is smaller than PPP GDP, the
official exchange rate may be undervalued, and vice versa. However,
there is no strong historical evidence that market exchange rates move
in the direction implied by the PPP rate, at least not in the short- or
medium-term. Note: the numbers for GDP and other economic data should
not be chained together from successive volumes of the Factbook because
of changes in the US dollar measuring rod, revisions of data by
statistical agencies, use of new or different sources of information,
and changes in national statistical methods and practices.
GNP
Gross national product (GNP) is the value of all final goods and
services produced within a nation in a given year, plus income earned
by its citizens abroad, minus income earned by foreigners from domestic
production. The Factbook, following current practice, uses GDP rather
than GNP to measure national production. However, the user must realize
that in certain countries net remittances from citizens working abroad
may be important to national well-being.
GWP
This entry gives the gross world product (GWP) or aggregate value of
all final goods and services produced worldwide in a given year.
Geographic coordinates
This entry includes rounded latitude and longitude figures for the
purpose of finding the approximate geographic center of an entity and
is based on the Gazetteer of Conventional Names, Third Edition, August
1988, US Board on Geographic Names and on other sources.
Geographic names
This information is presented in Appendix F: Cross-Reference List of
Geographic Names. It includes a listing of various alternate names,
former names, local names, and regional names referenced to one or more
related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.','490ecd2503475d56b82a7280b7b12d8b4e10fbb86dfa47d0159d2da3516fd457','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3558d1f70e6a0a54382572b8e7c53ba0f929af1017e6e51c594bb975ef01463d',2006,'UA','Ukraine','environment',190,'Geography - note:
vegetation scanty
People Saint Pierre and Miquelon
Population:
7,026 (July 2006 est.)
Age structure:
0-14 years: 23.5% (male 843/female 807)
15-64 years: 65.7% (male 2,342/female 2,272)
65 years and over: 10.8% (male 348/female 414) (2006 est.)
Median age:
total: 34.1 years
male: 33.7 years
female: 34.5 years (2006 est.)
Population growth rate:
0.17% (2006 est.)
Birth rate:
13.52 births/1,000 population (2006 est.)
Death rate:
6.83 deaths/1,000 population (2006 est.)
Net migration rate:
-4.98 migrant(s)/1,000 population (2006 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.01 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.38 deaths/1,000 live births
male: 8.46 deaths/1,000 live births
female: 6.24 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.61 years
male: 76.27 years
female: 81.06 years (2006 est.)
Total fertility rate:
2.01 children born/woman (2006 est.)
HIV/AIDS - adult prevalence rate:
NA
HIV/AIDS - people living with HIV/AIDS:
NA
HIV/AIDS - deaths:
NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups:
Basques and Bretons (French fishermen)
Religions:
Roman Catholic 99%
Languages:
French (official)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
Government Saint Pierre and Miquelon
Country name:
conventional long form: Territorial Collectivity of Saint Pierre
and Miquelon
conventional short form: Saint Pierre and Miquelon
local long form: Departement de Saint-Pierre et Miquelon
local short form: Saint-Pierre et Miquelon
Dependency status:
self-governing territorial collectivity of France
Government type:
NA
Capital:
name: Saint-Pierre
geographic coordinates: 46 46 N, 56 11 W
time difference: UTC-3 (2 hours ahead of Washington, DC during
Standard Time)
daylight saving time: +1hr, begins second Sunday in March; ends
first Sunday in November; note - these new dates become effective in
2007
Administrative divisions:
none (territorial collectivity of France); note - there are no
first-order administrative divisions as defined by the US
Government, but there are two communes - Saint Pierre, Miquelon at
the second order
Independence:
none (territorial collectivity of France; has been under French
control since 1763)
National holiday:
Bastille Day, 14 July (1789)
Constitution:
4 October 1958 (French Constitution)
Legal system:
French law with special adaptations for local conditions, such as
housing and taxation
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Jacques CHIRAC of France (since 17 May
1995), represented by Prefect Yves FAUQUEUR (since 28 August 2006)
head of government: President of the General Council Marc
PLANTAGENEST (since NA)
cabinet: NA
elections: French president elected by popular vote for a five-year
term; election last held, 21 April 2002 (first round) and 5 May 2002
(second round) (next to be held in 2007); prefect appointed by the
French president on the advice of the French Ministry of Interior;
president of the General Council is elected by the members of the
council
Legislative branch:
unicameral General Council or Conseil General (19 seats - 15 from
Saint Pierre and 4 from Miquelon; members are elected by popular
vote to serve six-year terms)
elections: elections last held 19 and 26 March 2000 (next to be held
in April 2006)
election results: percent of vote by party - NA%; seats by party -
PS 12, PRG 2, UDF-RPR 5
note: Saint Pierre and Miquelon elect 1 seat to the French Senate;
elections last held 26 September 2004 (next to be held in September
2013); results - percent of vote by party - NA; seats by party - UMP
1; Saint Pierre and Miquelon also elects 1 seat to the French
National Assembly; elections last held, first round - 9 June 2002,
second round - 16 June 2002 (next to be held NA 2007); results -
percent of vote by party - NA; seats by party - UDF 1
Judicial branch:
Superior Tribunal of Appeals or Tribunal Superieur d''Appel
Political parties and leaders:
Left Radical Party or PRG; Rassemblement pour la Republique or RPR
(now UMP); Socialist Party or PS; Union pour la Democratie Francaise
or UDF
Political pressure groups and leaders:
NA
International organization participation:
UPU, WFTU
Diplomatic representation in the US:
none (territorial collectivity of France)
Diplomatic representation from the US:
none (territorial collectivity of France)
Flag description:
a yellow sailing ship facing the hoist side rides on a dark blue
background with yellow wavy lines under the ship; on the hoist side,
a vertical band is divided into three parts: the top part (called
ikkurina) is red with a green diagonal cross extending to the
corners overlaid by a white cross dividing the rectangle into four
sections; the middle part has a white background with an ermine
pattern; the third part has a red background with two stylized
yellow lions outlined in black, one above the other; these three
heraldic arms represent settlement by colonists from the Basque
Country (top), Brittany, and Normandy; the flag of France is used
for official occasions
Economy Saint Pierre and Miquelon
Economy - overview:
The inhabitants have traditionally earned their livelihood by
fishing and by servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining, however, because of
disputes with Canada over fishing quotas and a steady decline in the
number of ships stopping at Saint Pierre. In 1992, an arbitration
panel awarded the islands an exclusive economic zone of 12,348 sq km
to settle a longstanding territorial dispute with Canada, although
it represents only 25% of what France had sought. The islands are
heavily subsidized by France to the great betterment of living
standards. The government hopes an expansion of tourism will boost
economic prospects. Recent test drilling for oil may pave the way
for development of the energy sector.
GDP (purchasing power parity):
$48.3 million
note: supplemented by annual payments from France of about $60
million (2003 est.)
GDP (official exchange rate):
NA
GDP - real growth rate:
NA%
GDP - per capita (PPP):
$7,000 (2001 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Labor force:
3,261 (1999)
Labor force - by occupation:
agriculture: 18%
industry: 41%
services: 41% (1996 est.)
Unemployment rate:
10.3% (1999)
Population below poverty line:
NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices):
2.1% (1991-96 average)
Budget:
revenues: $70 million
expenditures: $60 million; including capital expenditures of $24
million (1996 est.)
Agriculture - products:
vegetables; poultry, cattle, sheep, pigs; fish
Industries:
fish processing and supply base for fishing fleets; tourism
Industrial production growth rate:
NA%
Electricity - production:
44.15 million kWh (2003)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
41.06 million kWh (2003)
Electricity - exports:
0 kWh (2003)
Electricity - imports:
0 kWh (2003)
Oil - production:
0 bbl/day (2003 est.)
Oil - consumption:
480 bbl/day (2003 est.)
Oil - exports:
NA bbl/day
Oil - imports:
NA bbl/day
Natural gas - production:
0 cu m (2003 est.)
Natural gas - consumption:
0 cu m (2003 est.)
Exports:
$7 million f.o.b. (2004 est.)
Exports - commodities:
fish and fish products, soybeans, animal feed, mollusks and
crustaceans, fox and mink pelts
Exports - partners:
Spain 33.6%, Belgium 21.8%, India 18.3%, France 9.4%, US 7.5% (2005)
Imports:
$70 million f.o.b. (2004 est.)
Imports - commodities:
meat, clothing, fuel, electrical equipment, machinery, building
materials
Imports - partners:
France 51.3%, Canada 31.8%, Belgium 4.1% (2005)
Debt - external:
$NA
Economic aid - recipient:
approximately $60 million in annual grants from France
Currency (code):
euro (EUR)
Currency code:
EUR
Exchange rates:
euros per US dollar - 0.8041 (2005), 0.8054 (2004), 0.886 (2003),
1.0626 (2002), 1.1175 (2001)
Fiscal year:
calendar year
Communications Saint Pierre and Miquelon
Telephones - main lines in use:
4,800 (2002)
Telephones - mobile cellular:
NA
Telephone system:
general assessment: adequate
domestic: NA
international: country code - 508; radiotelephone communication with
most countries in the world; 1 earth station in French domestic
satellite system
Radio broadcast stations:
AM 1, FM 4, shortwave 0 (1998)
Radios:
4,000 (1997)
Television broadcast stations:
0 (there are, however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions:
4,000 (1997)
Internet country code:
.pm
Internet hosts:
0 (2006)
Internet Service Providers (ISPs):
1 (2000)
Internet users:
NA
Transportation Saint Pierre and Miquelon
Airports:
2 (2006)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2006)
Ports and terminals:
Saint-Pierre
Military Saint Pierre and Miquelon
Military - note:
defense is the responsibility of France
Transnational Issues Saint Pierre and Miquelon
Disputes - international:
none
This page was last updated on 19 December, 2006
======================================================================
@Saint Vincent and the Grenadines
Introduction Saint Vincent and the Grenadines
International Red Cross and Red Crescent Movement (ICRM): established
- 1928
aim - to promote worldwide humanitarian aid through the International
Committee of the Red Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent Societies (IFRCS; formerly
League of Red Cross and Red Crescent Societies or LORCS) in peacetime
National Societies - (182 countries); note - same as membership for
International Federation of Red Cross and Red Crescent Societies
(IFRCS)
International Telecommunication Union (ITU): established - 17 May 1865
set up as the International Telegraph Union; 9 December 1932 adopted
present name; effective - 1 January 1934; affiliated with the UN - 15
November 1947
aim - to deal with world telecommunications issues; a UN specialized
agency
members - (191) includes all UN member countries except East Timor,
Palau (190 total); plus Holy See
Islamic Development Bank (IDB): established - 15 December 1973 by
declaration of intent; effective - 12 August 1974
aim - to promote Islamic economic aid and social development
members - (55 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt,
Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq,
Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman,
Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan,
Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
Latin American Economic System (LAES): note - also known as Sistema
Economico Latinoamericana (SELA)
established - 17 October 1975
aim - to promote economic and social development through regional
cooperation
members - (27) Argentina, Barbados, Belize, Bolivia, Brazil, Chile,
Colombia, Costa Rica, Cuba, Dominican Republic, Ecuador, El Salvador,
Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico,
Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and Tobago,
Uruguay, Venezuela
Latin American Integration Association (LAIA): note - also known as
Asociacion Latinoamericana de Integracion (ALADI)
established - 12 August 1980; effective - 18 March 1981
aim - to promote freer regional trade
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba,
Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela
observers - (26) China, Corporacion Andina de Fomento, Costa Rica,
Dominican Republic, EC, El Salvador, Guatemala, Honduras, Inter-
American Development Bank, Inter-American Institute for Cooperation on
Agriculture, Italy, Japan, South Korea, Latin America Economic System,
Nicaragua, Organization of American States, Panama, Pan-American Health
Organization, Portugal, Romania, Russia, Spain, Switzerland, Ukraine,
United Nations Development Program, United Nations Economic Commission
for Latin America and the Caribbean
League of Arab States (LAS): note - also known as Arab League (AL)
established - 22 March 1945
aim - aim - to promote economic, social, political, and military
cooperation
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
least developed countries (LLDCs): that subgroup of the less developed
countries (LDCs) initially identified by the UN General Assembly in
1971 as having no significant economic growth, per capita GDPs normally
less than $1,000, and low literacy rates; also known as the undeveloped
countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan,
Botswana, Burkina Faso, Burma, Burundi, Cape Verde, Central African
Republic, Chad, Comoros, Djibouti, Equatorial Guinea, Eritrea,
Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos,
Lesotho, Malawi, Maldives, Mali, Mauritania, Mozambique, Nepal, Niger,
Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
less developed countries (LDCs): the bottom group in the hierarchy of
developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent
areas with low levels of output, living standards, and technology; per
capita GDPs are generally below $5,000 and often less than $1,500;
however, the group also includes a number of countries with high per
capita incomes, areas of advanced technology, and rapid rates of
growth; includes the advanced developing countries, developing
countries, Four Dragons (Four Tigers), least developed countries
(LLDCs), low-income countries, middle-income countries, newly
industrializing economies (NIEs), the South, Third World,
underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and
Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin
Islands, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape
Verde, Cayman Islands, Central African Republic, Chad, Chile, China,
Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia,
Falkland Islands, Fiji, French Guiana, French Polynesia, Gabon, The
Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, India, Indonesia, Iran, Iraq, Isle of Man,
Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar,
Malawi, Malaysia, Maldives, Mali, Marshall Islands, Martinique,
Mauritania, Mauritius, Mayotte, Federated States of Micronesia,
Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue,
Norfolk Island, Northern Mariana Islands, Oman, Palau, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn
Islands, Puerto Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts
and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and
the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos
Islands, Tuvalu, UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam,
Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen,
Zambia, Zimbabwe; note - similar to the new International Monetary Fund
(IMF) term "developing countries" which adds Malta, Mexico, South
Africa, and Turkey but omits in its recently published statistics
American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman
Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea,
Falkland Islands, French Guiana, French Polynesia, Gaza Strip,
Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle of Man,
Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat, Nauru, New
Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau,
Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and
Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin
Islands, Wallis and Futuna, West Bank, Western Sahara
low-income countries: another term for those less developed countries
with below-average per capita GDPs; see less developed countries (LDCs)
middle-income countries: another term for those less developed
countries with above-average per capita GDPs; see less developed
countries (LDCs)
Multilateral Investment Guarantee Agency (MIGA): established - 12
April 1988
aim - encourages flow of foreign direct investment among member
countries by offering investment insurance, consultation, and
negotiation on conditions for foreign investment and technical
assistance; a UN specialized agency
members - (168) includes all UN member countries except Andorra,
Bhutan, Brunei, Burma, Comoros, Cuba, Djibouti, Iraq, Kirabati, North
Korea, Liberia, Liechtenstein, Marshall Islands, Mexico, Monaco,
Montenegro, Nauru, NZ, Niger, San Marino, Sao Tome and Principe,
Somalia, Tonga, Tuvalu
Near Abroad: Russian term for the 14 non-Russian successor states of
the USSR, in which 25 million ethnic Russians live and in which Moscow
has expressed a strong national security interest; the 14 countries are
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,
Bharat (local name for India) India 20 00 N 77 00 E
Bhopal (city) India 23 16 N 77 24 E
Biafra (region) Nigeria 5 30 N 7 30 E
Big Diomede Island Russia 65 46 N 169 06 W
Bijagos, Arquipelago dos Guinea-Bissau 11 25 N 16 20 W
(island group)
Bikini Atoll Marshall Islands 11 35 N 165 23 E
Bilbao (city) Spain 43 15 N 2 58 W
Bioko (island) Equatorial Guinea 3 30 N 8 42 E
Biscay, Bay of Atlantic Ocean 44 00 N 4 00 W
Bishkek (capital) Kyrgyzstan 42 54 N 74 36 E
Bishop Rock United Kingdom 49 52 N 6 27 W
Bismarck Archipelago (island Papua New Guinea 5 00 S 150 00 E
group)
Bismarck Sea Pacific Ocean 4 00 S 148 00 E
Bissau (capital) Guinea-Bissau 11 51 N 15 35 W
Bjornoya (Bear Island) Svalbard 74 26 N 19 05 E
Black Forest (region) Germany 48 00 N 8 15 E
Black Rock (island) South Georgia and 53 39 S 41 48 W
the South Sandwich
Islands
Black Sea Atlantic Ocean 43 00 N 35 00 E
Bloemfontein (judicial South Africa 29 12 S 26 07 E
capital)
Bo Hai (gulf) Pacific Ocean 38 00 N 120 00 E
Boa Vista (island) Cape Verde 16 05 N 22 50 W
Bogota (capital) Colombia 4 36 N 74 05 W
Bohemia (region) Czech Republic 50 00 N 14 30 E
Bombay (city; see Mumbai) India 18 58 N 72 50 E
Bonaire (island) Netherlands Antilles 12 10 N 68 15 W
Bonifacio, Strait of Atlantic Ocean 41 01 N 14 00 E
Bonin Islands Japan 27 00 N 142 10 E
Bonn (former capital) Germany 50 44 N 7 05 E
Bophuthatswana (region; South Africa 26 30 S 25 30 E
enclave)
Bora-Bora (island) French Polynesia 16 30 S 151 45 W
Bordeaux (city) France 44 50 N 0 34 W
Borneo (island) Brunei, Indonesia, 0 30 N 114 00 E','e333f2a33b87c5be1053ef9baa26a8e5356483cb794aee57ac894c5d81e998f1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02cad5de82372644c5ede8f83f4ec30e885ce12b281811ce2aea83230b29cd63',2006,'ZW','Zimbabwe','environment',994,'members - (8) Canada, Denmark (Greenland, Faroe Islands), Finland,
Iceland, Norway, Russia, Sweden, US
permanent participants - (6) Aleut International Association, Arctic
Athabaskan Council, Gurch''in Council International, Inuit Circumpolar
Conference, Russian Association of Indigenous People of the North,
Saami Council
observers - (5) France, Germany, Netherlands, Poland, UK
ASEAN Regional Forum (ARF): established - 25 July 1994
aim - to foster constructive dialogue and consultation on political and
security issues of common interest and concern
members - (26) Australia, Bangladesh, Brunei, Burma, Cambodia, Canada,
China, East Timor, EU, India, Indonesia, Japan, North Korea, South
Korea, Laos, Malaysia, Mongolia, NZ, Pakistan, Papua New Guinea,
Philippines, Russia, Singapore, Thailand, US, Vietnam
Asian Development Bank (AsDB): established - 19 December 1966
aim - to promote regional economic cooperation
members - (47) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh,
Bhutan, Brunei, Burma, Cambodia, China, Cook Islands, East Timor, Fiji,
Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea,
Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands, Federated
States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Palau,
Papua New Guinea, Philippines, Samoa, Singapore, Solomon Islands, Sri
Lanka, Taiwan, Tajikistan, Thailand, Tonga, Turkmenistan, Tuvalu,
Uzbekistan, Vanuatu, Vietnam
nonregional members - (19) Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Ireland, Italy, Luxembourg, Netherlands, Norway,
Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
Asia-Pacific Economic Cooperation (APEC): established - 7 November
1989
aim - to promote trade and investment in the Pacific basin
members - (21) Australia, Brunei, Canada, Chile, China, Hong Kong,
Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New Guinea,
Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers - (3) Association of Southeast Asian Nations, Pacific
Economic Cooperation Council, Pacific Islands Forum Secretariat
Association of Southeast Asian Nations (ASEAN): established - 8 August
1967
aim - to encourage regional economic, social, and cultural cooperation
among the non-Communist countries of Southeast Asia
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
dialogue partners - (12) Australia, Canada, China, EU, India, Japan,
South Korea, NZ, Pakistan, Russia, US, UNDP
observers - (1) Papua New Guinea
Australia Group: established - June 1985
aim - to consult on and coordinate export controls related to chemical
and biological weapons
members - (40) Argentina, Australia, Austria, Belgium, Bulgaria,
Canada, Cyprus, Czech Republic, Denmark, Estonia, European Commission,
Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Japan, South Korea, Latvia, Lithuania, Luxembourg, Malta, Netherlands,
NZ, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Turkey, Ukraine, UK, US
Australia-New Zealand-United States Security Treaty (ANZUS):
established - 1 September 1951; effective - 29 April 1952
aim - to implement a trilateral mutual security agreement, although the
US suspended security obligations to NZ on 11 August 1986; Australia
and the US continue to hold annual meetings
members - (3) Australia, NZ, US
Baltic Assembly (BA): established - 12 May 1990
aim - to thoroughly discuss various cooperation issues between Baltic
states
members - (3) Estonia, Latvia, Lithuania
Bay of Bengal Iniative for Multisectoral Technical and Economic
Coopertion (BIMSTEC): established - June 1997
aim - to foster socio-economic cooperation among members
members - (7) Bangladesh, Bhutan, Burma, India, Nepal, Sri Lanka,
International Bank for Reconstruction and Development (IBRD): note -
also known as the World Bank
established - 22 July 1944; effective - 27 December 1945
aim - to provide economic development loans; a UN specialized agency
members - (184) includes all UN member countries except Andorra, Cuba,
North Korea, Liechtenstein, Monaco, Montenegro, Nauru, and Tuvalu
International Chamber of Commerce (ICC): established - 1919
aim - to promote free trade and private enterprise and to represent
business interests at national and international levels
members - (91 national committees) Algeria, Argentina, Australia,
Austria, Bahrain, Bangladesh, Belgium, Brazil, Burkina Faso, Cameroon,
Canada, Caribbean, Chile, China, Colombia, Costa Rica, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Finland, France, Georgia, Germany, Ghana, Greece, Guatemala,
Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel,
Italy, Japan, Jordan, South Korea, Kuwait, Lebanon, Lithuania,
Luxembourg, Madagascar, Malaysia, Mexico, Monaco, Morocco, Nepal,
Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal,
Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo, Tunisia,
Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela
International Civil Aviation Organization (ICAO): established - 7
December 1944; effective - 4 April 1947
aim - to promote international cooperation in civil aviation; a UN
specialized agency
members - (189) includes all UN member countries except Dominica,
Liechtenstein, Montenegro, and Tuvalu (188 total); plus Cook Islands
International Civilian Support Mission in Haiti (MICAH): established
17 December 1999 to promote respect for human rights; members included
Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo,
Tunisia, US; closed 2001
International Committee of the Red Cross (ICRC): established - 17
February 1863
aim - to provide humanitarian aid in wartime
members - (15-25 individuals) all Swiss nationals
International Confederation of Free Trade Unions (ICFTU): established
- December 1949
aim - to promote the trade union movement
members - (241 affiliated organizations in the following 155 countries
plus the Palestine Liberation Organization) Albania, Algeria, Angola,
Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bermuda, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burundi, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, El Salvador, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Holy See, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati,
South Korea, Kuwait, Latvia, Lebanon, Liberia, Lithuania, Luxembourg,
Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Mongolia, Montenegro, Montserrat, Morocco, Mozambique,
Namibia, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Helena,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka,
Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK,
US, Vanuatu, Venezuela, Yemen, Zambia, Zimbabwe, Palestine Liberation
Organization
International Court of Justice (ICJ): note - also known as the World
Court
established - 3 February 1946 superseded Permanent Court of
International Justice
aim - primary judicial organ of the UN
members - (15 judges) elected by the UN General Assembly and Security
Council to represent all principal legal systems
International Criminal Court (ICCt): established - 11 April 2002
aim - to hold all individuals and countries accountable to
international laws of conduct; to specify international standards of
conduct; to provide an important mechanism for implementing these
standards; to ensure that perpetrators are brought to justice
members (countries that have ratified the treaty) - (102) Afghanistan,
Albania, Andorra, Antigua and Barbuda, Argentina, Australia, Austria,
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Bulgaria, Burkina Faso, Burundi, Cambodia, Canada,
Central African Republic, Colombia, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Croatia, Cyprus, Denmark,
Djibouti, Dominica, Dominican Republic, East Timor, Ecuador, Estonia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Guinea, Guyana, Honduras, Hungary, Iceland, Ireland, Italy,
Jordan, Kenya, South Korea, Latvia, Lesotho, Liberia, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Malawi, Mali, Malta, Marshall
Islands, Mauritius, Mexico, Mongolia, Namibia, Nauru, Netherlands, NZ,
Niger, Nigeria, Norway, Panama, Paraguay, Peru, Poland, Portugal,
Romania, Saint Vincent and the Grenadines, Saint Kitts and Nevis,
Samoa, San Marino, Senegal, Serbia, Sierra Leone, Slovakia, Slovenia,
South Africa, Spain, Sweden, Switzerland, Tajikistan, Tanzania,
Trinidad and Tobago, Uganda, UK, Uruguay, Venezuela, Zambia; note -
Comoros and Saint Kitts and Nevis became full members on 1 November
2006
signatory states (countries that have signed, but not ratified, the
treaty) - (40) Algeria, Angola, Armenia, The Bahamas, Bahrain,
Bangladesh, Cameroon, Cape Verde, Chad, Chile, Cote d''Ivoire, Czech
Republic, Egypt, Eritrea, Guinea-Bissau, Haiti, Iran, Jamaica, Kuwait,
Kyrgyzstan, Madagascar, Moldova, Monaco, Morocco, Mozambique, Oman,
Philippines, Russia, Saint Lucia, Sao Tome and Principe, Seychelles,
Solomon Islands, Sudan, Syria, Thailand, Ukraine, UAE, Uzbekistan,
Yemen, Zimbabwe
International Criminal Police Organization (Interpol): established -
September 1923 set up as the International Criminal Police Commission;
13 June 1956 constitution modified and present name adopted
aim - to promote international cooperation among police authorities in
fighting crime
members - (186) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands
Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
subbureaus - (11) American Samoa, Anguilla, Bermuda, British Virgin
Islands, Cayman Islands, Gibraltar, Hong Kong, Macau, Montserrat,
Puerto Rico, Turks and Caicos Islands
International Development Association (IDA): established - 26 January
1960; effective - 24 September 1960
aim - to provide economic loans for low-income countries; UN
specialized agency and IBRD affiliate
members - (166)
Part I - (27 developed countries) Australia, Austria, Belgium, Canada,
Denmark, EU, Finland, France, Germany, Iceland, Ireland, Italy, Japan,
Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South
Africa, Spain, Sweden, Switzerland, UAE, UK, US
Part II - (139 less developed countries) Afghanistan, Albania, Algeria,
Angola, Argentina, Armenia, Azerbaijan, Bangladesh, Barbados, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cyprus, Czech Republic, Djibouti, Dominica,
Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Mongolia, Morocco,
Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, Sri
Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine,
Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
International Energy Agency (IEA): established - 15 November 1974
aim - to promote cooperation on energy matters, especially emergency
oil sharing and relations between oil consumers and oil producers;
established by the OECD
members - (27) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal,
Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
International Federation of Red Cross and Red Crescent Societies
(IFRCS): note - formerly known as League of Red Cross and Red Crescent
Societies (LORCS)
established - 5 May 1919
aim - to organize, coordinate, and direct international relief actions;
to promote humanitarian activities; to represent and encourage the
development of National Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to reduce the vulnerability
of people through development programs
members - (185 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia
and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization
observers - (2) Eritrea and Tuvalu
International Finance Corporation (IFC): established - 25 May 1955;
effective - 24 July 1956
aim - to support private enterprise in international economic
development; a UN specialized agency and IBRD affiliate
members - (177) includes all UN member countries except Andorra,
Brunei, Cuba, Guinea, North Korea, Liechtenstein, Monaco, Montenegro,
Nauru, Qatar, Saint Vincent and the Grenadines, San Marino, Sao Tome
and Principe, Suriname, Tuvalu
International Fund for Agricultural Development (IFAD): established -
November 1974
aim - to promote agricultural development; a UN specialized agency
members - (165)
Category I - (23 industrialized aid contributors) Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Iceland,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal,
Spain, Sweden, Switzerland, UK, US
Category II - (12 petroleum-exporting aid contributors) Algeria, Gabon,
Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia,
UAE, Venezuela
Category III - (130 aid recipients) Afghanistan, Albania, Angola,
Antigua and Barbuda, Argentina, Armenia, Azerbaijan, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
India, Israel, Jamaica, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Nicaragua, Niger, Niue, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao
Tome and Principe, Senegal, Serbia (suspended since 1992), Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam,
Yemen, Zambia, Zimbabwe
International Hydrographic Organization (IHO): note - name changed
from International Hydrographic Bureau on 22 September 1970
established - June 1919; effective - June 1921
aim - to train hydrographic surveyors and nautical cartographers to
achieve standardization in nautical charts and electronic chart
displays; to provide advice on nautical cartography and hydrography; to
develop the sciences in the field of hydrography and techniques used
for descriptive oceanograrphy
members - (76) Algeria, Argentina, Australia, Bahrain, Bangladesh,
Belgium, Brazil, Burma, Canada, Chile, China (including Hong Kong and
Macau), Colombia, Democratic Republic of the Congo (suspended),
Croatia, Cuba, Cyprus, Denmark, Dominican Republic (suspended),
Ecuador, Egypt, Estonia, Fiji, Finland, France, Germany, Greece,
Guatemala, Iceland, India, Indonesia, Iran, Italy, Jamaica, Japan,
North Korea, South Korea, Kuwait, Latvia, Malaysia, Mauritius, Mexico,
Monaco, Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman,
Pakistan, Papua New Guinea, Peru, Philippines, Poland, Portugal,
Russia, Serbia, Singapore, Slovenia, South Africa, Spain, Sri Lanka,
Suriname (suspended), Sweden, Syria, Thailand, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela
International Labor Organization (ILO): established - 28 June 1919 set
up as part of Treaty of Versailles; 11 April 1919 became operative; 14
December 1946 affiliated with the UN
aim - to deal with world labor issues; a UN specialized agency
members - (179) includes all UN member countries except Andorra,
Bhutan, Brunei, North Korea, Liechtenstein, Maldives, Marshall Islands,
Federated States of Micronesia, Monaco, Nauru, Palau, Tonga, and
Tuvalu; note - includes the following dependencies: Netherlands
(Netherlands Antilles and Aruba)
International Maritime Organization (IMO): note - name changed from
Intergovernmental Maritime Consultative Organization (IMCO) on 22 May
1982
established - 6 March 1948 set up as the Inter-Governmental Maritime
Consultative Organization; effective - 17 March 1958
aim - to deal with international maritime affairs; a UN specialized
agency
members - (167) includes all UN member countries except Afghanistan,
Andorra, Armenia, Belarus, Bhutan, Botswana, Burkina Faso, Burundi,
Central African Republic, Chad, Kyrgyzstan, Laos, Lesotho,
Liechtenstein, Mali, Federated States of Micronesia, Montenegro, Nauru,
Niger, Palau, Rwanda, Tajikistan, Uganda, Uzbekistan, Zambia
associate members - (3) Faroe Islands, Hong Kong, Macau
International Monetary Fund (IMF): established - 22 July 1944;
effective - 27 December 1945
aim - to promote world monetary stability and economic development; a
UN specialized agency
members - (184) includes all UN member countries except Andorra, Cuba,
North Korea, Liechtenstein, Monaco, Nauru, Tuvalu; note - includes the
following dependencies or areas of special interest: China (Hong Kong
and Macau), Netherlands (Netherlands Antilles and Aruba)
International Olympic Committee (IOC): established - 23 June 1894
aim - to promote the Olympic ideals and administer the Olympic games:
2006 Winter Olympics in Turin, Italy; 2008 Summer Olympics in Beijing,
China; 2010 Winter Olympics in Vancouver, Canada; 2012 Summer Olympics
in London, UK
National Olympic Committees - (201 and the Palestine Liberation
Organization) Afghanistan, Albania, Algeria, American Samoa, Andorra,
Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Cayman Islands, Central African Republic, Ch','974ddf33250a6eaef9aa7a19a1319be93fe638fa0b9aab42db8be48d80506189','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38aad18e679bace73c80f082729ee08ac400ee693a56ab66ae4766f17853e15a',2006,'ZW','Zimbabwe','environment',995,'ad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization
International Organization for Migration (IOM): note - established as
Provisional Intergovernmental Committee for the Movement of Migrants
from Europe; renamed Intergovernmental Committee for European Migration
(ICEM) on 15 November 1952; renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current name adopted 14 November 1989
established - 5 December 1951
aim - to facilitate orderly international emigration and immigration
members - (118) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada, Cape Verde,
Chile, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
South Korea, Kyrgyzstan, Latvia, Liberia, Libya, Lithuania, Luxembourg,
Madagascar, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Morocco, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Rwanda,
Senegal, Serbia, Sierra Leone, Slovakia, Slovenia, South Africa, Spain,
Sri Lanka, Sudan, Sweden, Switzerland, Tajikistan, Tanzania, Thailand,
Togo, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela,
Yemen, Zambia, Zimbabwe
observers - (20) Bhutan, Burundi, China, Cuba, Ethiopia, Guyana, Holy
See, India, Indonesia, Macedonia, Mozambique, Namibia, Nepal, Papua New
Guinea, Russia, San Marino, Sao Tome and Principe, Somalia,
Turkmenistan, Vietnam
International Organization for Standardization (ISO): established -
February 1947
aim - to promote the development of international standards with a view
to facilitating international exchange of goods and services and to
developing cooperation in the sphere of intellectual, scientific,
technological and economic activity
members - (103 national standards organizations) Algeria, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Ecuador, Egypt, Ethiopia, Fiji, Finland, France, Germany, Ghana,
Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Lebanon, Libya, Luxembourg, Macedonia, Malaysia,
Malta, Mauritius, Mexico, Mongolia, Morocco, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Panama, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Saint Lucia, Saudi Arabia, Serbia, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden,
Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia,
Turkey, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
correspondent members - (43 plus the Palestine Liberation Organization)
Afghanistan, Albania, Angola, Benin, Bhutan, Bolivia, Brunei, Burkina
Faso, Burma, Dominican Republic, El Salvador, Eritrea, Estonia,
Georgia, Guatemala, Guinea, Guinea-Bissau, Hong Kong, Kyrgyzstan,
Latvia, Lithuania, Macau, Madagascar, Malawi, Mali, Moldova,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Papua New Guinea,
Paraguay, Peru, Rwanda, Senegal, Seychelles, Swaziland, Togo,
Turkmenistan, Uganda, Yemen, Zambia, Palestine Liberation Organization
subscriber members - (9) Antigua and Barbuda, Burundi, Cambodia,
Dominica, Grenada, Guyana, Honduras, Lesotho, Saint Vincent and the
Grenadines
International Organization of the French-speaking World (OIF): note -
name changed from Agency of Cultural and Technical Cooperation (ACCT)
in 1997
established - 20 March 1970
aim - founded around a common language to promote and spread the
cultures of its members and to reinforce cultural and technical
cooperation between them
members - (55) Albania, Andorra, Belgium, Benin, Bulgaria, Burkina
Faso, Burundi, Cambodia, Cameroon, Canada, Canada - New Brunswick,
Canada - Quebec, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of Congo, Republic of Congo, Cote d''Ivoire, Cyprus,
Djibouti, Dominica, Egypt, Equatorial Guinea, France, French Community
of Belgium, Gabon, Ghana, Greece, Guinea, Guinea-Bissau, Haiti, Laos,
Lebanon, Luxembourg, Macedonia, Madagascar, Mali, Mauritania,
Mauritius, Moldova, Monaco, Morocco, Niger, Romania, Rwanda, Saint
Lucia, Sao Tome and Principe, Senegal, Seychelles, Switzerland, Togo,
Tunisia, Vanuatu, Vietnam
observers - (13) Armenia, Austria, Croatia, Czech Republic, Georgia,
Hungary, Lithuania, Mozambique, Poland, Serbia, Slovakia, Slovenia,
countries that have signed, but not yet ratified - (3) Ireland, Kuwait,
countries that have signed, but not yet ratified - (29) Afghanistan,
Bangladesh, Belarus, Bhutan, Burundi, Cambodia, Central African
Republic, Chad, Colombia, Republic of the Congo, Dominican Republic, El
Salvador, Ethiopia, Iran, North Korea, Lesotho, Liberia, Libya,
Liechtenstein, Madagascar, Malawi, Morocco, Niger, Niue, Rwanda,
Swaziland, Switzerland, Thailand, UAE
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in
Africa
note - abbreviated as Desertification
opened for signature - 14 October 1994
entered into force - 26 December 1996
objective - to combat desertification and mitigate the effects of
drought through national action programs that incorporate long-term
strategies supported by international cooperation and partnership
arrangements
parties - (178) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg,
Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Thailand, Tajikistan, Tanzania, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
United Nations Framework Convention on Climate Change
note - abbreviated as Climate Change
opened for signature - 9 May 1992
entered into force - 21 March 1994
objective - to achieve stabilization of greenhouse gas concentrations
in the atmosphere at a low enough level to prevent dangerous
anthropogenic interference with the climate system
parties - (189) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
This page was last updated on 19 December, 2006
=====================================================================
Appendix D - Cross-Reference List of Country Data Codes
FIPS 10: Countries, Dependencies, Areas of Special Sovereignty, and
Their Principal Administrative Divisions (FIPS 10) is maintained by
the Office of Targeting and Transnational Issues, National
Geospatial-Intelligence Agency, and published by the National
Institute of Standards and Technology (Department of Commerce).
FIPS 10 codes are intended for general use throughout the US
Government, especially in activities associated with the mission
of the Department of State and national defense programs.
ISO 3166: Codes for the Representation of Names of Countries
(ISO 3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character
alphabetic codes and three-digit numeric codes that may be needed
for activities involving exchange of data with international
organizations that have adopted that standard. Except for the numeric
codes, ISO 3166 codes have been adopted in the US as FIPS 104-1:
American National Standard Codes for the Representation of Names
of Countries, Dependencies, and Areas of Special Sovereignty for
Information Interchange.
Internet: The Internet country code is the two-letter digraph
maintained by the International Organization for Standardization
(ISO) in the ISO 3166 Alpha-2 list and used by the Internet Assigned
Numbers Authority (IANA) to establish country-coded top-level
domains (ccTLDs).
Entity FIPS 10 ISO 3166 Internet Comment
Afghanistan AF AF AFG 004 .af
Albania AL AL ALB 008 .al
Algeria AG DZ DZA 012 .dz
American Samoa AQ AS ASM 016 .as
Andorra AN AD AND 020 .ad
Angola AO AO AGO 024 .ao
Anguilla AV AI AIA 660 .ai
Antarctica AY AQ ATA 010 .aq
ISO defines as the territory south of 60 degrees south latitude
Antigua and Barbuda AC AG ATG 028 .ag
Argentina AR AR ARG 032 .ar
Armenia AM AM ARM 051 .am
Aruba AA AW ABW 533 .aw
Ashmore and
Cartier Islands AT - - -
ISO includes with Australia
Australia AS AU AUS 036 .au
ISO includes Ashmore and Cartier Islands, Coral Sea Islands
Austria AU AT AUT 040 .at
Azerbaijan AJ AZ AZE 031 .az
Bahamas, The BF BS BHS 044 .bs
Bahrain BA BH BHR 048 .bh
Baker Island FQ - - -
ISO includes with the US Minor Outlying Islands
Bangladesh BG BD BGD 050 .bd
Barbados BB BB BRB 052 .bb
Bassas da India BS - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Belarus BO BY BLR 112 .by
Belgium BE BE BEL 056 .be
Belize BH BZ BLZ 084 .bz
Benin BN BJ BEN 204 .bj
Bermuda BD BM BMU 060 .bm
Bhutan BT BT BTN 064 .bt
Bolivia BL BO BOL 068 .bo
Bosnia and
Herzegovina BK BA BIH 070 .ba
Botswana BC BW BWA 072 .bw
Bouvet Island BV BV BVT 074 .bv
Brazil BR BR BRA 076 .br
British Indian
Ocean Territory IO IO IOT 086 .io
British Virgin
Islands VI VG VGB 092 .vg
Brunei BX BN BRN 096 .bn
Bulgaria BU BG BGR 100 .bg
Burkina Faso UV BF BFA 854 .bf
Burma BM MM MMR 104 .mm
ISO uses the name Myanmar
Burundi BY BI BDI 108 .bi
Cambodia CB KH KHM 116 .kh
Cameroon CM CM CMR 120 .cm
Canada CA CA CAN 124 .ca
Cape Verde CV CV CPV 132 .cv
Cayman Islands CJ KY CYM 136 .ky
Central African
Republic CT CF CAF 140 .cf
Chad CD TD TCD 148 .td
Chile CI CL CHL 152 .cl
China CH CN CHN 156 .cn
see also Taiwan
Christmas Island KT CX CXR 162 .cx
Clipperton Island IP - - -
ISO includes with French Polynesia
Cocos (Keeling) IslandsCK CC CCK 166 .cc
Colombia CO CO COL 170 .co
Comoros CN KM COM 174 .km
Congo, Democratic
Republic of the CG CD COD 180 .cd
formerly Zaire
Congo, Republic of theCF CG COG 178 .cg
Cook Islands CW CK COK 184 .ck
Coral Sea Islands CR - - -
ISO includes with Australia
Costa Rica CS CR CRI 188 .cr
Cote d''Ivoire IV CI CIV 384 .ci
Croatia HR HR HRV 191 .hr
Cuba CU CU CUB 192 .cu
Cyprus CY CY CYP 196 .cy
Czech Republic EZ CZ CZE 203 .cz
Denmark DA DK DNK 208 .dk
Djibouti DJ DJ DJI 262 .dj
Dominica DO DM DMA 212 .dm
Dominican Republic DR DO DOM 214 .do
East Timor TT TL TLS 626 .tl
Ecuador EC EC ECU 218 .ec
Egypt EG EG EGY 818 .eg
El Salvador ES SV SLV 222 .sv
Equatorial Guinea EK GQ GNQ 226 .gq
Eritrea ER ER ERI 232 .er
Estonia EN EE EST 233 .ee
Ethiopia ET ET ETH 231 .et
Europa Island EU - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Falkland Islands (Islas Malvinas)FKFKFLK 238 .fk
Faroe Islands FO FO FRO 234 .fo
Fiji FJ FJ FJI 242 .fj
Finland FI FI FIN 246 .fi
France FR FR FRA 250 .fr
France, Metropolitan- FX FXX 249 .fx
ISO limits to the European part of France, excluding French
Guiana, French Polynesia, French Southern and Antarctic Lands,
Guadeloupe, Martinique, Mayotte, New Caledonia, Reunion, Saint
Pierre and Miquelon, Wallis and Futuna
French Guiana FG GF GUF 254 .gf
French Polynesia FP PF PYF 258 .pf
ISO includes Clipperton Island
French Southern and Antarctic LandsFSTFATF260 .tf
FIPS 10-4 does not include the French-claimed portion of
Antarctica (Terre Adelie)
Gabon GB GA GAB 266 .ga
Gambia, The GA GM GMB 270 .gm
Gaza Strip GZ PS PSE 275 .ps
ISO identifies as Occupied Palestinian Territory
Georgia GG GE GEO 268 .ge
Germany GM DE DEU 276 .de
Ghana GH GH GHA 288 .gh
Gibraltar GI GI GIB 292 .gi
Glorioso Islands GO - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Greece GR GR GRC 300 .gr
Greenland GL GL GRL 304 .gl
Grenada GJ GD GRD 308 .gd
Guadeloupe GP GP GLP 312 .gp
Guam GQ GU GUM 316 .gu
Guatemala GT GT GTM 320 .gt
Guernsey GK GG GGY 831 .gg
Guinea GV GN GIN 324 .gn
Guinea-Bissau PU GW GNB 624 .gw
Guyana GY GY GUY 328 .gy
Haiti HA HT HTI 332 .ht
Heard Island and
McDonald Islands HM HM HMD 334 .hm
Holy See
(Vatican City) VT VA VAT 336 .va
Honduras HO HN HND 340 .hn
Hong Kong HK HK HKG 344 .hk
Howland Island HQ - - -
ISO includes with the US Minor Outlying Islands
Hungary HU HU HUN 348 .hu
Iceland IC IS ISL 352 .is
India IN IN IND 356 .in
Indonesia ID ID IDN 360 .id
Iran IR IR IRN 364 .ir
Iraq IZ IQ IRQ 368 .iq
Ireland EI IE IRL 372 .ie
Isle of Man IM IM IMN 833 .im
Israel IS IL ISR 376 .il
Italy IT IT ITA 380 .it
Jamaica JM JM JAM 388 .jm
Jan Mayen JN - - -
ISO includes with Svalbard
Japan JA JP JPN 392 .jp
Jarvis Island DQ - - -
ISO includes with the US Minor Outlying Islands
Jersey JE JE JEY 832 .je
Johnston Atoll JQ - - -
ISO includes with the US Minor Outlying Islands
Jordan JO JO JOR 400 .jo
Juan de Nova Island JU - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Kazakhstan KZ KZ KAZ 398 .kz
Kenya KE KE KEN 404 .ke
Kingman Reef KQ - - -
ISO includes with the US Minor Outlying Islands
Kiribati KR KI KIR 296 .ki
Korea, North KN KP PRK 408 .kp
Korea, South KS KR KOR 410 .kr
Kuwait KU KW KWT 414 .kw
Kyrgyzstan KG KG KGZ 417 .kg
Laos LA LA LAO 418 .la
Latvia LG LV LVA 428 .lv
Lebanon LE LB LBN 422 .lb
Lesotho LT LS LSO 426 .ls
Liberia LI LR LBR 430 .lr
Libya LY LY LBY 434 .ly
Liechtenstein LS LI LIE 438 .li
Lithuania LH LT LTU 440 .lt
Luxembourg LU LU LUX 442 .lu
Macau MC MO MAC 446 .mo
Macedonia MK MK MKD 807 .mk
Madagascar MA MG MDG 450 .mg
Malawi MI MW MWI 454 .mw
Malaysia MY MY MYS 458 .my
Maldives MV MV MDV 462 .mv
Mali ML ML MLI 466 .ml
Malta MT MT MLT 470 .mt
Marshall Islands RM MH MHL 584 .mh
Martinique MB MQ MTQ 474 .mq
Mauritania MR MR MRT 478 .mr
Mauritius MP MU MUS 480 .mu
Mayotte MF YT MYT 175 .yt
Mexico MX MX MEX 484 .mx
Micronesia,
Federated
States of FM FM FSM 583 .fm
Midway Islands MQ - - -
ISO includes with the US Minor Outlying Islands
Moldova MD MD MDA 498 .md
Monaco MN MC MCO 492 .mc
Mongolia MG MN MNG 496 .mn
Montenegro MJ ME MNE 499 .me
new ccTLD takes effect in 2007, in the interim .cg.yu remains current
Montserrat MH MS MSR 500 .ms
Morocco MO MA MAR 504 .ma
Mozambique MZ MZ MOZ 508 .mz
Myanmar - - - -
see Burma
Namibia WA NA NAM 516 .na
Nauru NR NR NRU 520 .nr
Navassa Island BQ - - - -
ISO includes with the US Minor Outlying Islands
Nepal NP NP NPL 524 .np
Netherlands NL NL NLD 528 .nl','4539977691b08d16befe963143cef82b94fdeb2143f1eda4786e57a57671bc21','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39668cdf64e2c2b99690b870671db262140879a7fd6139ebd08ae9c894dbb3e8',2006,'TH','Thailand','environment',996,'Bank for International Settlements (BIS): established - 20 January
1930; effective - 17 March 1930
aim - to promote cooperation among central banks in international
financial settlements
members - (55) Algeria, Argentina, Australia, Austria, Belgium, Bosnia
and Herzegovina, Brazil, Bulgaria, Canada, Chile, China, Croatia, Czech
Republic, Denmark, Estonia, European Central Bank, Finland, France,
Germany, Greece, Hong Kong, Hungary, Iceland, India, Indonesia,
Ireland, Israel, Italy, Japan, South Korea, Latvia, Lithuania,
Macedonia, Malaysia, Mexico, Netherlands, NZ, Norway, Philippines,
Poland, Portugal, Romania, Russia, Saudi Arabia, Serbia, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Thailand,
Turkey, UK, US; note - Serbia and Montenegro have separate central
banks; their links with BIS are currently under review
Benelux Economic Union (Benelux): note - acronym from Belgium,
Netherlands, and Luxembourg
established - 3 February 1958; effective - 1 November 1960
aim - to develop closer economic cooperation and integration
members - (3) Belgium, Luxembourg, Netherlands
Big Seven: note - membership is the same as the Group of 7
established - 1975
aim - to discuss and coordinate major economic policies
members - (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus
the US
Black Sea Economic Cooperation Zone (BSEC): established - 25 June 1992
aim - to enhance regional stability through economic cooperation
members - (12) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece,
Moldova, Romania, Russia, Serbia, Turkey, Ukraine; note - Macedonia is
in the process of joining
observers - (16) Austria, Belarus, Black Sea Commission, Croatia, Czech
Republic, Egypt, Energy Charter Secretariat, France, Germany,
International Black Sea Club, Israel, Italy, Poland, Slovakia, Tunisia,
US; note - Bosnia and Herzegovina and Slovenia have applied for
observer status
Caribbean Community and Common Market (Caricom): established - 4 July
1973; effective - 1 August 1973
aim - to promote economic integration and development, especially among
the less developed countries
members - (15) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname,','f067fd6d7a525cc6042b08944282f73fa99d99ee820d3583ac58b1105cb131b7','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9a31f554b12a79a21c6910b231bd4a979f408a1c7573fe3443125ebcd12a71a',2006,'TT','Trinidad and Tobago','environment',997,'associate members - (5) Anguilla, Bermuda, British Virgin Islands,
Cayman Islands, Turks and Caicos Islands
Caribbean Development Bank (CDB): established - 18 October 1969;
effective - 26 January 1970
aim - to promote economic development and cooperation
regional members - (20) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia,
Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Trinidad and
Tobago, Turks and Caicos Islands, Venezuela
nonregional members - (5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC): see Monetary and
Economic Community of Central Africa (CEMAC)
Central African States Development Bank (BDEAC): note - acronym from
Banque de Developpement des Etats de l''Afrique Centrale
established - 3 December 1975
aim - to provide loans for economic development
members - (10) African Development Bank (AfDB), Cameroon, Central
African States Bank (BEAC), Central African Republic, Chad, Republic of
the Congo, Equatorial Guinea, France, Gabon, Kuwait
Central American Bank for Economic Integration (BCIE): note - acronym
from Banco Centroamericano de Integracion Economico
established - 13 December 1960 signature of Articles of Agreement; 31
May 1961 began operations
aim - to promote economic integration and development
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members - (5) Argentina, China, Colombia, Mexico, Spain
Central American Common Market (CACM): established - 13 December 1960,
collapsed in 1969, reinstated in 1991
aim - to promote establishment of a Central American Common Market
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua;
note - Panama, although not a member, pursues full regional cooperation
Central European Initiative (CEI): note - evolved from the
Quadrilateral Initiative and the Hexagonal Initiative
established - 11 November 1989 as the Quadrilateral Initiative, 27 July
1991 became the Hexagonal Initiative, July 1992 its present name was
adopted
aim - to form an economic and political cooperation group for the
region between the Adriatic and the Baltic Seas
members - (18) Albania, Austria, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Hungary, Italy, Macedonia, Moldova,
Montenegro, Poland, Romania, Serbia, Slovakia, Slovenia, Ukraine
centrally planned economies: a term applied mainly to the
traditionally Communist states that looked to the former USSR for
leadership; most are now evolving toward more democratic and market-
oriented systems; also known formerly as the Second World or as as the
Communist countries; through the 1980s, this group included Albania,
Bulgaria, Cambodia, China, Cuba, Czechoslovakia, German Democratic
Republic, Hungary, North Korea, Laos, Mongolia, Montenegro, Poland,
Romania, Serbia, USSR, Vietnam
Colombo Plan (CP): established - May 1950 proposal was adopted; 1 July
1951 commenced full operations
aim - to promote economic and social development in Asia and the
Pacific
members - (25) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Fiji,
India, Indonesia, Iran, Japan, South Korea, Laos, Malaysia, Maldives,
Mongolia, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Singapore, Sri Lanka, Thailand, US, Vietnam
Common Market for Eastern and Southern Africa (COMESA): note -
formerly known as Preferential Trade Area for Eastern and Southern
Africa (PTA)
established - 5 November 1993
aim - recognizing, promoting and protecting fundamental human rights,
commitment to the principles of liberty and rule of law, maintaining
peace and stability through the promotion and strengthening of good
neighborliness, commitment to peaceful settlement of disputes among
member states
members - (20) Angola, Burundi, Comoros, Democratic Republic of the
Congo, Djibouti, Egypt, Eritrea, Ethiopia, Kenya, Libya, Madagascar,
Malawi, Mauritius, Rwanda, Seychelles, Sudan, Swaziland, Uganda,
Zambia, Zimbabwe
Commonwealth (C): note - also known as Commonwealth of Nations
established - 31 December 1931
aim - to foster multinational cooperation and assistance, as a
voluntary association that evolved from the British Empire
members - (53) Antigua and Barbuda, Australia, The Bahamas, Bangladesh,
Barbados, Belize, Botswana, Brunei, Cameroon, Canada, Cyprus, Dominica,
Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius,
Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (suspended), Papua
New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Seychelles, Sierra Leone, Singapore, Solomon
Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad
and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia; note - on 7 December
2003 Zimbabwe withdrew its membership from the Commonwealth
Commonwealth of Independent States (CIS): established - 8 December
1991; effective - 21 December 1991
aim - to coordinate intercommonwealth relations and to provide a
mechanism for the orderly dissolution of the USSR
members - (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan,
Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,','d5b8b2cf62edaf19ffb558ec7d2c39871ccfa09dbe22e8f36a462a6a178fe71d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08f90dc9af89c5a858e1553d50f0c497e046647b0cc7812d027863a67a0cecd2',2006,'UZ','Uzbekistan','environment',998,'Communist countries: traditionally the Marxist-Leninist states with
authoritarian governments and command economies based on the Soviet
model; most of the original and the successor states are no longer
Communist; see centrally planned economies
Coordinating Committee on Export Controls (COCOM): established in 1949
to control the export of strategic products and technical data from
member countries to proscribed destinations; members were: Australia,
Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan,
Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US;
abolished 31 March 1994; COCOM members established a new organization,
the Wassenaar Arrangement, with expanded membership on 12 July 1996
that focuses on nonproliferation export controls as opposed to East-
West control of advanced technology
Council for Mutual Economic Assistance (CEMA): note - also known as
CMEA or Comecon
established 25 January 1949 to promote the development of socialist
economies and abolished 1 January 1991; members included Afghanistan
(observer), Albania (had not participated since 1961 break with USSR),
Angola (observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia (observer),
GDR, Hungary, Laos (observer), Mongolia, Mozambique (observer),
Nicaragua (observer), Poland, Romania, USSR, Vietnam, Yemen (observer),
Yugoslavia (associate)
Council of Arab Economic Unity (CAEU): established - 3 June 1957;
effective - 30 May 1964
aim - to promote economic integration among Arab nations
members - (10 plus the Palestine Liberation Organization) Egypt, Iraq,
Jordan, Kuwait, Libya, Mauritania, Somalia, Sudan, Syria, Yemen,
Palestine Liberation Organization
Council of Europe (CE): established - 5 May 1949; effective - 3 August
1949
aim - to promote increased unity and quality of life in Europe
members - (46) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium,
Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Turkey, Ukraine, UK
observers - (5) Canada, Holy See, Japan, Mexico, US
Council of the Baltic Sea States (CBSS): established - 6 March 1992
aim - to promote cooperation among the Baltic Sea states in the areas
of aid to new democratic institutions, economic development,
humanitarian aid, energy and the environment, cultural programs and
education, and transportation and communication
members - (12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia,
Lithuania, Norway, Poland, Russia, Sweden
observers - (7) France, Italy, Netherlands, Slovakia, Ukraine, UK, US
Council of the Entente (Entente): established - 29 May 1959
aim - to promote economic, social, and political coordination
members - (5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
countries in transition: a term used by the International Monetary
Fund (IMF) for the middle group in its hierarchy of advanced economies,
countries in transition, and developing countries; IMF statistics
include the following 28 countries in transition: Albania, Armenia,
Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech
Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Macedonia, Moldova, Mongolia, Montenegro, Poland, Romania,
Russia, Serbia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; note - this group is identical to the group traditionally
referred to as the "former USSR/Eastern Europe" except for the addition
of Mongolia
Customs Cooperation Council (CCC): note - see World Customs
Organization (WCO)
developed countries (DCs): the top group in the hierarchy of developed
countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less
developed countries (LDCs); includes the market-oriented economies of
the mainly democratic nations in the Organization for Economic
Cooperation and Development (OECD), Bermuda, Israel, South Africa, and
the European ministates; also known as the First World, high-income
countries, the North, industrial countries; generally have a per capita
GDP in excess of $10,000 although four OECD countries and South Africa
have figures well under $10,000 and two of the excluded OPEC countries
have figures of more than $10,000; the 34 DCs are: Andorra, Australia,
Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland,
France, Germany, Greece, Holy See, Iceland, Ireland, Israel, Italy,
Japan, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland,
Turkey, UK, US; note - similar to the new International Monetary Fund
(IMF) term "advanced economies" that adds Hong Kong, South Korea,
Singapore, and Taiwan but drops Malta, Mexico, South Africa, and Turkey
developing countries: a term used by the International Monetary Fund
(IMF) for the bottom group in its hierarchy of advanced economies,
countries in transition, and developing countries; IMF statistics
include the following 126 developing countries: Afghanistan, Algeria,
Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The
Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya,
Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique,
Namibia, Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, UAE, Uganda, Uruguay, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note - this category would
presumably also cover the following 46 other countries that are
traditionally included in the more comprehensive group of "less
developed countries": American Samoa, Anguilla, British Virgin Islands,
Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands,
Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza
Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle
of Man, Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat,
Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands,
Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint
Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu,
Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
East African Development Bank (EADB): established - 6 June 1967;
effective - 1 December 1967
aim - to promote economic development
members - (3) Kenya, Tanzania, Uganda
East Asia Summit (EAS): established - 14 December 2005
aim - to promote cooperation in political and security issues; to
promote development, financial stability, energy security, economic
integration and growth; to eradicate poverty and narrow the development
gap in East Asia, and to promote deeper cultural understanding
members - (16) Australia, Brunei, Burma, Cambodia, China, India,
Indonesia, Japan, South Korea, Laos, Malaysia, NZ, Philippines,
Singapore, Thailand, Vietnam
Economic and Monetary Union (EMU): note - an integral part of the
European Union; also known as the European Economic and Monetary Union
established - 1-2 December 1969 (proposed at summit conference of heads
of government; 7 February 1992 (Maastricht Treaty signed)
aim - to promote a single market by creating a single currency, the
euro; timetable - 2 May 1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and stock exchanges begin using
euros; 1 January 2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
members - (12) Austria, Belgium, Finland, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain
Economic and Monetary Community of Central Africa (CEMAC): note - was
formerly the Central African Customs and Economic Union (UDEAC)
established - 8 December 1964; effective - 1 January 1966
aim - to promote the establishment of a Central African Common Market
members - (6) Cameroon, Central African Republic, Chad, Republic of the
Congo, Equatorial Guinea, Gabon
Economic and Social Council (ECOSOC): established - 26 June 1945;
effective - 24 October 1945
aim - to coordinate the economic and social work of the UN; includes
five regional commissions (Economic Commission for Africa, Economic
Commission for Europe, Economic Commission for Latin America and the
Caribbean, Economic and Social Commission for Asia and the Pacific,
Economic and Social Commission for Western Asia) and nine functional
commissions (Commission for Social Development, Commission on Human
Rights, Commission on Narcotic Drugs, Commission on the Status of
Women, Commission on Population and Development, Statistical
Commission, Commission on Science and Technology for Development,
Commission on Sustainable Development, and Commission on Crime
Prevention and Criminal Justice)
members - (54) selected on a rotating basis from all regions
Economic Community of the Great Lakes Countries (CEPGL): note -
acronym from Communaute Economique des Pays des Grands Lacs
established - 20 September 1976
aim - to promote regional economic cooperation and integration
members - (3) Burundi, Democratic Republic of the Congo, Rwanda; note -
organization collapsed because of fighting in 1998; reactivated in 2006
Economic Community of West African States (ECOWAS): established - 28
May 1975
aim - to promote regional economic cooperation
members - (15) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The
Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Niger, Nigeria,
Senegal, Sierra Leone, Togo
Economic Cooperation Organization (ECO): established - 27-29 January
1985
aim - to promote regional cooperation in trade, transportation,
communications, tourism, cultural affairs, and economic development
members - (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan,
Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
Euro-Atlantic Partnership Council (EAPC): note - began as the North
Atlantic Cooperation Council (NACC); an extension of NATO
established - 8 November 1991; effective - 20 December 1991
aim - to discuss cooperation on mutual political and security issues
members - (46) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium,
Bulgaria, Canada, Croatia, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, Macedonia,
Moldova, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and Development (EBRD): established -
8-9 January 1990 (proposals made); 15 April 1991 (bank inaugurated)
aim - to facilitate the transition of seven centrally planned economies
in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market economies by committing
60% of its loans to privatization
members - (63) Albania, Armenia, Australia, Austria, Azerbaijan,
Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, EC, European Investment Bank
(EIB), Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Malta, Mexico, Moldova, Mongolia, Montenegro, Morocco, Netherlands, NZ,
Norway, Poland, Portugal, Romania, Russia, Serbia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine,
UK, US, Uzbekistan
European Community (or European Communities, EC): established 8 April
1965 to integrate the European Atomic Energy Community (Euratom), the
European Coal and Steel Community (ECSC), the European Economic
Community (EEC or Common Market), and to establish a completely
integrated common market and an eventual federation of Europe; merged
into the European Union (EU) on 7 February 1992; member states at the
time of merger were Belgium, Denmark, France, Germany, Greece, Ireland,
Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA): established - 4 January 1960;
effective - 3 May 1960
aim - to promote expansion of free trade
members - (4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB): established - 25 March 1957; effective
- 1 January 1958
aim - to promote economic development of the EU and its predecessors,
the EEC and the EC
members - (25) Austria, Belgium, Cyprus, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal,
Slovakia, Slovenia, Spain, Sweden, UK
European Organization for Nuclear Research (CERN): note - acronym
retained from the predecessor organization Conseil Europeenne pour la
Recherche Nucleaire
established - 1 July 1953; effective - 29 September 1954
aim - to foster nuclear research for peaceful purposes only
members - (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Italy, Netherlands, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers - (8) European Commission, India, Israel, Japan, Russia,
Turkey, United Nations Educational, Scientific, and Cultural
Organization (UNESCO), US
European Space Agency (ESA): established - 31 May 1975
aim - to promote peaceful cooperation in space research and technology
members - (17) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Norway, Portugal,
Spain, Sweden, Switzerland, UK
cooperating states - (4) Canada, Czech Republic, Hungary, Romania
European Union (EU): note - see European Union entry at the end of the
"country" listings
First World: another term for countries with advanced, industrialized
economies; this term is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO): established - 16 October 1945
aim - to raise living standards and increase availability of
agricultural products; a UN specialized agency
members - (190) includes all UN member countries except Andorra,
Brunei, Liechtenstein, Montenegro, and Singapore (187 total); plus Cook
Islands, EC, and Niue
former Soviet Union (FSU): former term often used to identify as a
group the successor nations to the Soviet Union or USSR; this group of
15 countries consists of: Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE): the middle group in the
hierarchy of developed countries (DCs), former USSR/Eastern Europe
(former USSR/EE), and less developed countries (LDCs); these countries
are in political and economic transition and may well be grouped
differently in the near future; this group of 27 countries consists of:
Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Poland,
Romania, Russia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan, Yugoslavia; this group is identical to the IMF group
"countries in transition" except for the IMF''s inclusion of Mongolia
Four Dragons: the four small Asian less developed countries (LDCs)
that have experienced unusually rapid economic growth; also known as
the Four Tigers; this group consists of Hong Kong, South Korea,
Singapore, Taiwan; these countries are included in the IMF''s "advanced
economies" group
Franc Zone (FZ): note - also known as Conference des Ministres des
Finances des Pays de la Zone Franc
established - 1964
aim - to form a monetary union among countries whose currencies
were0000000 linked to the French franc
members - (16) Benin, Burkina Faso, Cameroon, Central African Republic,
Chad, Comoros, Republic of the Congo, Cote d''Ivoire, Equatorial Guinea,
France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo
Front Line States (FLS): established to achieve black majority rule in
South Africa; has since gone out of existence; members included Angola,
Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT): see the World Trade
Organization (WTO)
Group of 2 (G-2): informal term that came into use about 1986; to
facilitate bilateral economic cooperation between the two most powerful
economic giants; members were Japan, US
Group of 3 (G-3): established - September 1990
aim - mechanism for policy coordination
members - (3) Colombia, Mexico, Venezuela
Group of 5 (G-5): established - 22 September 1985
aim - to coordinate the economic policies of five major noncommunist
economic powers
members - (5) France, Germany, Japan, UK, US
Group of 6 (G-6): note - also known as Groupe des Six Sur le
Desarmement; not to be confused with the Big Six
established - 22 May 1984
aim - to achieve nuclear disarmament
members - (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7): note - membership is the same as the Big Seven
established - 22 September 1985
aim - to facilitate economic cooperation among the seven major
noncommunist economic powers
members - (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada
and Italy
Group of 8 (G-8): established - October 1975
aim - to facilitate economic cooperation among the developed countries
(DCs) that participated in the Conference on International Economic
Cooperation (CIEC), held in several sessions between December 1975 and
3 June 1977
members - (8) Canada, France, Germany, Italy, Japan, Russia, UK, US
Group of 9 (G-9): established - NA
aim - to discuss matters of mutual interest on an informal basis
members - (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary,
Romania, Serbia, Sweden
Group of 10 (G-10): note - also known as the Paris Club; includes the
wealthiest members of the IMF who provide most of the money to be
loaned and act as the informal steering committee; name persists
despite increased membership
established - October 1962
aim - to coordinate credit policy
members - (11) Belgium, Canada, France, Germany, Italy, Japan,
Netherlands, Sweden, Switzerland, UK, US
observers - (4) BIS, EU, IMF, OECD
Group of 11 (G-11): note - also known as the Cartagena Group
established in 21-22 June 1984, in Cartagena, Colombia, aim was to
provide a forum for largest debtor nations in Latin America; members
were: Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic,
Ecuador, Mexico, Peru, Uruguay, Venezuela
Group of 15 (G-15): note - byproduct of the Nonaligned Movement; name
persists despite increased membership
established - September 1989
aim - to promote economic cooperation among developing nations; to act
as the main political organ for the Nonaligned Movement
members - (19) Algeria, Argentina, Brazil, Chile, Colombia, Egypt,
India, Indonesia, Iran, Jamaica, Kenya, Malaysia, Mexico, Nigeria,
Peru, Senegal, Sri Lanka, Venezuela, Zimbabwe
Group of 24 (G-24): established - 1 August 1989
aim - to promote the interests of developing countries in Africa, Asia,
and Latin America within the IMF
members - (24) Algeria, Argentina, Brazil, Colombia, Democratic
Republic of the Congo, Cote d''Ivoire, Egypt, Ethiopia, Gabon, Ghana,
Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru,
Philippines, South Africa, Sri Lanka, Syria, Trinidad and Tobago,
Venezuela
observers - (1) China
Group of 77 (G-77): established - 15 June1964; October 1967 first
ministerial meeting
aim - to promote economic cooperation among developing countries; name
persists in spite of increased membership
members - (130 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, Antigua and Barbuda, Argentina, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Djibouti, Dominica,
Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India,
Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia,
Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Federated
States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Qatar, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uruguay, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation
Organization
Gulf Cooperation Council (GCC): note - also known as the Cooperation
Council for the Arab States of the Gulf
established - 25 May 1981
aim - to promote regional cooperation in economic, social, political,
and military affairs
members - (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
Organization for Democracy and Economic Development (GUAM): note-
acronym standing for the member countries, Georgia, Ukraine,
Azerbaijan, Moldova; formerly known as GUUAM before Uzbekistan withdrew
in 5 May 2005
established - 7 June 2001
aim - commits the countries to cooperation and assistance in social and
economic development, the strengthening and broadening of trade and
economic relations, and the development and effective use of transport
and communications, highways, and related infrastructure crossing the
boundaries of the member states
members - (4) Azerbaijan, Georgia, Moldova, Ukraine
high income countries: another term for the industrialized countries
with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC): established - 21 December 1982
aim - to organize and promote regional cooperation in all sectors,
especially economic
members - (5) Comoros, France (for Reunion), Madagascar, Mauritius,
new independent states (NIS): a term referring to all the countries of
the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs): former term for the newly
industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs): that subgroup of the less
developed countries (LDCs) that has experienced particularly rapid
industrialization of their economies; formerly known as the newly
indust','354d7b7b16940bedecad9453cc73e94684adf53f62c9d2c5e799b56d9823a03a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed83daa22047d766641af647c399847faaff4eaa969664ff80494bc959bb3a69',2006,'UZ','Uzbekistan','environment',999,'rializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea,
Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM): established - 1-6 September 1961
aim - to establish political and military cooperation apart from the
traditional East or West blocs
members - (114 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic,
Chad, Chile, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominican
Republic, Ecuador, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon,
The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North
Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines,
Qatar, Rwanda, Saint Lucia, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Somalia, South
Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda,
UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization
observers - (15) Antigua and Barbuda, Armenia, Azerbaijan, Brazil,
China, Costa Rica, Croatia, Dominica, El Salvadore, Kazakhstan,
Kyrgyzstan, Mexico, Paraguay, Ukraine, Uruguay
guests - (24) Australia, Austria, Bosnia and Herzegovina, Bulgaria,
Canada, Czech Republic, Finland, Germany, Greece, Holy See, Hungary,
Italy, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, Spain, Sweden, Switzerland
Nordic Council (NC): established - 16 March 1952; effective - 12
February 1953
aim - to promote regional economic, cultural, and environmental
cooperation
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
observers - (3) the Sami (Lapp) local parliaments of Finland, Norway,
and Sweden
Nordic Investment Bank (NIB): established - 4 December 1975; effective
- 1 June 1976
aim - to promote economic cooperation and development
members - (8) Denmark (including Faroe Islands and Greenland), Estonia,
Finland (including Aland Islands), Iceland, Latvia, Lithuania, Norway,
observer - (4) India, Iran, Mongolia, Pakistan
socialist countries: in general, countries in which the government
owns and plans the use of the major factors of production; note - the
term is sometimes used incorrectly as a synonym for Communist countries
South: a popular term for the poorer, less industrialized countries
generally located south of the developed countries; the counterpart of
the North; see less developed countries (LDCs)
South American Community of Nations (CSN): established - 9 December
2004
aim - to coordinate common policies regarding multilateral
organizations, to integrate physical infrastructure, and to consolidate
the merger of CAN and Mercosur
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador,
Guyana, Paraguay, Peru, Surinam, Uruguay, Venezuela
observers - (2) Mexico, Panama
South Asia Co-operative Environment Program (SACEP): established -
January 1983
aim - to promote regional cooperation in South Asia in the field of
environment, both natural and human, and on issues of economic and
social development; to support conservation and management of natural
resources of the region
members - (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri
Lanka
South Asian Association for Regional Cooperation (SAARC): established
- 8 December 1985
aim - to promote economic, social, and cultural cooperation
members - (8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal,
Pakistan, Sri Lanka
observers - (2) China, Japan
South Pacific Forum (SPF): note - see Pacific Island Forum
South Pacific Regional Trade and Economic Cooperation Agreement
(Sparteca): established - 1981
aim - to redress unequal trade relationships of Australia and New
Zealand with small island economies in the Pacific region
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
Southeast European Cooperative Initiative (SECI): established - 6
December 1996
aim - to encourage cooperation among participating states and to
facilitate their integration into European structures
members - (12) Albania, Bosnia and Herzegovina, Bulgaria, Croatia,
Greece, Hungary, Macedonia, Moldova, Romania, Serbia, Slovenia, Turkey
observers - (15) Austria, Azerbaijan, Belgium, Canada, France, Georgia,
Germany, Italy, Japan, Netherlands, Portugal, Spain, Ukraine, UK, US
Southern African Customs Union (SACU): established - 11 December 1969
aim - to promote free trade and cooperation in customs matters
members - (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
Southern African Development Community (SADC): note - evolved from the
Southern African Development Coordination Conference (SADCC)
established - 17 August 1992
aim - to promote regional economic development and integration
members - (14) Angola, Botswana, Democratic Republic of the Congo,
Lesotho, Madagascar, Malawi, Mauritius, Mozambique, Namibia, South
Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common Market: note
- also known as Mercado Comun del Cono Sur (Mercosur)
established - 26 March 1991
aim - to increase regional economic cooperation
members - (5) Argentina, Brazil, Paraguay, Uruguay, Venezuela
associate members - (5) Bolivia, Chile, Colombia, Ecuador, Peru; note -
Mexico is to become an associate member by the end of 2006
Third World: another term for the less developed countries; the term
is obsolescent; see less developed countries (LDCs)
underdeveloped countries: refers to those less developed countries
with the potential for above-average economic growth; see less
developed countries (LDCs)
undeveloped countries: refers to those extremely poor less developed
countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
United Nations (UN): established - 26 June 1945; effective - 24
October 1945
aim - to maintain international peace and security and to promote
cooperation involving economic, social, cultural, and humanitarian
problems
constituent organizations - the UN is composed of six principal organs
and numerous subordinate agencies and bodies as follows:
1) Secretariat
2) General Assembly: Joint United Nations Program on HIV/AIDS (UN
AIDS), International Research and Training Institute for the
Advancement of Women (INSTRAW), Office of the United Nations High
Commissioner for Human Rights (OHCHR), Organization for the Prohibition
of Chemical Weapons (OPCW), Preparation Commission for the Nuclear-Ban-
Treaty Operation ((CTBTU), United Nations Center for Human Settlements
(UN-Habitat), United Nations Children''s Fund (UNICEF), United Nations
Conference on Trade and Development (UNCTAD), United Nations
Development Program (UNDP), United Nations Drug Control Program
(UNDCP), United Nations Environment Program (UNEP), United Nations High
Commissioner for Refugees (UNHCR), United Nations Institute for
Disarmament Research (UNIDIR), United Nations Institute for Training
and Research (UNITAR), United Nations Interregional Crime and Justice
Research Institute (UNICRI), United Nations Population Fund (UNFPA),
United Nations Office of Project Services (UNOPS), United Nations
Relief and Works Agency for Palestine Refugees in the Near East
(UNRWA), United Nations Research Institute for Social Development
(UNRISD), United Nations System Staff College (UNSSC), United Nations
University (UNU), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former
Yugoslavia (ICTY), International Criminal Tribunal for Rwanda (ICTR),
United Nations Compensation Commission, United Nations Disengagement
Observer Force (UNDOF), United Nations Integrated Mission in Timor-
Leste (UNMIT), United Nations Interim Administration Mission in Kosovo
(UNMIK), United Nations Interim Force in Lebanon (UNIFIL), United
Nations Mission in Liberia (UNMIL), United Nations Military Observer
Group in India and Pakistan (UNMOGIP), United Nations Operation in
Burundi (ONUB), United Nations Operation in Cote d''Ivoire (UNOCI),
United Nations Mission for the Referendum in Western Sahara (MINURSO),
United Nations Mission in Ethiopia and Eritrea (UNMEE), United Nations
Mission in the Sudan (UNMIS), United Nations Monitoring and
Verification Commission (UNMOVIC), United Nations Observer Mission in
Georgia (UNOMIG), United Nations Organization Mission in the Democratic
Republic of the Congo (MONUC), United Nations Peace-Keeping Force in
Cyprus (UNFICYP), United Nations Stabilization Mission in Haiti
(MINUSTAH), and United Nations Truce Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social
Development, Commission on Crime Prevention and Criminal Justice,
Commission on Narcotics Drugs, Commission on Population and
Development, Commission on Science and Technology for Development,
Commission on Sustainable Development, Commission on the Status of
Women, Economic and Social Commission for Asia and the Pacific (ESCAP),
Economic and Social Commission for Western Asia (ESCWA), Economic
Commission for Africa (ECA), Economic Commission for Europe (ECE),
Economic Commission for Latin America and the Caribbean (ECLAC), Food
and Agriculture Organization of the United Nations (FAO), International
Atomic Energy Agency (IAEA), International Bank for Reconstruction and
Development (IBRD), International Center for Secretariat of Investment
Disputes (ICSID), International Civil Aviation Organization (ICAO),
International Development Association (IDA), International Finance
Corporation (IFC), International Fund for Agricultural Development
(IFAD), International Labor Organization (ILO), International Maritime
Organization (IMO), International Monetary Fund (IMF), International
Telecommunication Union (ITU), Multilateral Investment Geographic
Agency (MIGA), Statistical Commission, United Nations Educational,
Scientific, and Cultural Organization (UNESCO), United Nations Forum on
Forests, United Nations Industrial Development Organization (UNIDO),
Universal Postal Union (UPU), World Health Organization (WHO), World
Intellectual Property Organization (WIPO), World Meteorological
Organization (WMO), World Tourism Organization (WToO), and World Trade
Organization (WTO)
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
United Nations Children''s Fund (UNICEF): note - acronym retained from
the predecessor organization, UN International Children''s Emergency
Fund
established - 11 December 1946
aim - to help establish child health and welfare services
members - (36) selected on a rotating basis from all regions
United Nations Conference on Trade and Development (UNCTAD):
established - 30 December 1964
aim - to promote international trade
members - (193) all UN members plus Holy See
United Nations Development Program (UNDP): established - 22 November
1965
aim - to provide technical assistance to stimulate economic and social
development
members (executive board) - (36) selected on a rotating basis from all
regions
United Nations Disengagement Observer Force (UNDOF): established - 31
May 1974
aim - to observe the 1973 Arab-Israeli cease-fire; established by the
UN Security Council
members - (7) Austria, Canada, India, Japan, Nepal, Poland, Slovakia
United Nations Educational, Scientific, and Cultural Organization
(UNESCO): established - 16 November 1945; effective - 4 November 1946
aim - to promote cooperation in education, science, and culture
members - (191) includes all UN member countries except Liechtenstein,
Montenegro, and Singapore (188 total); plus Cook Islands and Niue
associate members - (6) Aruba, British Virgin Islands, Cayman Islands,
Macau, Netherlands Antilles, Tokelau
United Nations Environment Program (UNEP): established - 15 December
1972
aim - to promote international cooperation on all environmental matters
members - (58) selected on a rotating basis from all regions
United Nations General Assembly: established - 26 June 1945; effective
- 24 October 1945
aim - to function as the primary deliberative organ of the UN
members - (192) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR): established - 3
December 1949; effective - 1 January 1951
aim - to ensure the humanitarian treatment of refugees and find
permanent solutions to refugee problems
members (executive committee) - (70) Algeria, Argentina, Australia,
Austria, Bangladesh, Belgium, Brazil, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Cote d''Ivoire, Cyprus, Denmark,
Ecuador, Egypt, Ethiopia, Finland, France, Germany, Ghana, Greece,
Guinea, Holy See, Hungary, India, Iran, Ireland, Israel, Italy, Japan,
Jordan, Kenya, South Korea, Lebanon, Lesotho, Madagascar, Mexico,
Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Nigeria,
Norway, Pakistan, Philippines, Poland, Portugal, Romania, Russia,
Serbia, Somalia, South Africa, Spain, Sudan, Sweden, Switzerland,
Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela, Yemen,
Argun River China, Russia 53 20 N 121 28 E
Aru Sea Pacific Ocean 6 15 S 135 00 E
As-Sudan (local name for Sudan 15 00 N 30 00 E
Sudan)
Ascension Island Saint Helena 7 57 S 14 22 W
Ashgabat, Ashkhabad (capital) Turkmenistan 37 57 N 58 23 E
Asmara, Asmera (capital) Eritrea 15 20 N 38 53 E
Assumption Island Seychelles 9 46 S 46 34 E
Astana (capital; formerly Kazakhstan 51 10 N 71 30 E
Akmola)
Asuncion (capital) Paraguay 25 16 S 57 40 W
Asuncion Island Northern Mariana 19 40 N 145 24 E
Islands
Atacama (desert) Chile 23 00 S 70 10 W
Atacama (region) Chile 24 30 S 69 15 W
Athens (capital) Greece 37 59 N 23 44 E
Attu Island United States 52 55 N 172 57 E
Auckland (city) New Zealand 36 52 S 174 46 E
Auckland Islands New Zealand 51 00 S 166 30 E
Australes, Iles (island French Polynesia 23 20 S 151 00 W
group; also Iles Tubuai)
Avarua (capital) Cook Islands 21 12 S 159 46 W
Axel Heiberg Island Canada 79 30 N 90 00 W
Azad Kashmir (region) Pakistan 34 30 N 74 00 E
Azarbaycan, Azerbaidzhan Azerbaijan 40 30 N 47 30 E
(local name for Azerbaijan)
Azores (islands) Portugal 38 30 N 28 00 W
Azov, Sea of Atlantic Ocean 49 00 N 36 00 E
Bab el Mandeb (strait) Indian Ocean 12 40 N 43 20 E
Babuyan Channel Pacific Ocean 18 44 N 121 40 E
Babuyan Islands Philippines 19 10 N 121 40 E
Baffin Bay Arctic Ocean 73 00 N 66 00 W
Baffin Island Canada 68 00 N 70 00 W
Baghdad (capital) Iraq 33 21 N 44 25 E
Baku (capital; also Baki, Azerbaijan 40 23 N 49 51 E
Baky)
Balabac Strait Pacific Ocean 7 35 N 117 00 E
Balearic Islands Spain 39 30 N 3 00 E
Balearic Sea (Iberian Sea) Atlantic Ocean 40 30 N 2 00 E
Bali (island) Indonesia 8 20 S 115 00 E
Bali Sea Indian Ocean 7 45 S 115 30 E
Balintang Channel Pacific Ocean 19 49 N 121 40 E
Balintang Islands Philippines 19 55 N 122 10 E
Balkan Peninsula Albania, Bosnia and 42 00 N 23 00 E
Herzegovina,
Bulgaria, Croatia,
Greece, Macedonia,
Montenegro, Romania,
Serbia, Slovenia,
Turkey (European
part)
Balleny Islands Antarctica 67 00 S 163 00 E
Balochistan (region) Pakistan 28 00 N 63 00 E
Baltic Sea Atlantic Ocean 57 00 N 19 00 E
Bamako (capital) Mali 12 39 N 8 00 W
Banaba (Ocean Island) Kiribati 0 52 S 169 35 E
Banat (region) Hungary, Romania, 45 30 N 21 00 E
Fernando Po (island; see Equatorial Guinea 3 30 N 8 42 E
Bioko)
Fernando de Noronha (island Brazil 3 51 S 32 25 W
group)
Filipinas (local name for the Philippines 13 00 N 122 00 E
Philippines; also Pilipinas)
Finland, Gulf of Atlantic Ocean 60 00 N 27 00 E
Florence (city) Italy 43 46 N 11 16 E
Flores (island) Indonesia 8 45 S 121 00 E
Flores Sea Pacific Ocean 7 40 S 119 45 E
Florida, Straits of Atlantic Ocean 25 00 N 79 45 W
Fongafale (largest island of Tuvalu 8 30 S 179 12 E
Funafuti)
Former Soviet Union (FSU) Armenia, Azerbaijan,
Belarus, Estonia,
Georgia, Kazakhstan,
Kyrgyzstan, Latvia,
Lithuania, Moldova,
Russia, Tajikistan,
Turkmenistan,
Ukraine, Uzbekistan
Formosa (island) Taiwan 23 30 N 121 00 E
Formosa Strait (see Taiwan Pacific Ocean 24 00 N 119 00 E
Strait)
Foroyar (local name for Faroe Faroe Islands 62 00 N 7 00 W
Islands)
Fort-de-France (capital) Martinique 14 36 N 61 05 W
Frankfurt am Main (city) Germany 50 07 N 8 41 E
Franz Josef Land (island Russia 81 00 N 55 00 E
group)
Freetown (capital) Sierra Leone 8 30 N 13 15 W
French Cameroon (former name Cameroon 6 00 N 12 00 E
for Cameroon)
French Guinea (former name Guinea 11 00 N 10 00 W
for Guinea)
French Indochina (former name Cambodia, Laos, 15 00 N 107 00 E
for French possessions in Vietnam
southeast Asia)
French Morocco (former name Morocco 32 00 N 5 00 W
for Morocco)
French Somaliland (former Djibouti 11 30 N 43 00 E
name for Djibouti)
French Sudan (former name for Mali 17 00 N 4 00 W
Mali)
French Territory of the Afars Djibouti 11 30 N 43 00 E
and Issas (or FTAI; former
name for Djibouti)
French Togoland (former name Togo 8 00 N 1 10 E
for Togo)
French West Indies (former Guadeloupe, 16 30 N 62 00 W
name for French possessions Martinique
in the West Indies)
Friendly Islands Tonga 20 00 S 175 00 W
Frisian Islands Denmark, Germany, 53 35 N 6 40 E','42376b6014c98b4df9b2b70aa9e05221f02179710e68f8179125a6affa72dd23','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19222f68db6cdbd96dfeaa0f589f1c54431108cb71a5763ac7643337fe5b4950',2006,'SC','Seychelles','environment',1000,'industrial countries: another term for the developed countries; see
developed countries (DCs)
Inter-American Development Bank (IADB): note - also known as Banco
Interamericano de Desarrollo (BID)
established - 8 April 1959; effective - 30 December 1959
aim - to promote economic and social development in Latin America
members - (47) Argentina, Austria, The Bahamas, Barbados, Belgium,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Croatia,
Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France,
Germany, Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica,
Japan, South Korea, Mexico, Netherlands, Nicaragua, Norway, Panama,
Paraguay, Peru, Portugal, Slovenia, Spain, Suriname, Sweden,
Switzerland, Trinidad and Tobago, UK, US, Uruguay, Venezuela
Inter-Governmental Authority on Development (IGAD): note - formerly
known as Inter-Governmental Authority on Drought and Development
(IGADD)
established - 15-16 January 1986 as the Inter-Governmental Authority on
Drought and Development; revitalized - 21 March 1996 as the Inter-
Governmental Authority on Development
aim - to promote a social, economic, and scientific community among its
members
members - (7) Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan,','89669f58c13351f14781bb88e9186bb72751c05809dcbe8c4100700d03cafcfa','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e71a6b706453f48f58ae2e91f209eb97daa351ad1e97b887834278b04f71b14',2006,'UG','Uganda','environment',1001,'Inter-Parliamentary Union (IPU): established - 1889
aim - fosters contacts among parliamentarians, considers and expresses
views of international interest and concern with the purpose of
bringing about action by parliaments and parliamentarians, contributes
to the defense and promotion of human rights, contributes to better
knowledge of representative institutions
members - (148) Albania, Algeria, Andorra, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Belarus, Belgium,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Chile,
China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kazahstan,
Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Liberia, Libya, Lichtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malaysia, Maldives, Mali, Malta, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Somalia, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Switzerland, Syria, Tanzania, Tajikistan, Thailand,
Togo, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (7) Andean Parliament, Central American Parliament,
Community Parliament of the Economic Community of West African States,
East African Legislative Assembly, European Parliament, Latin American
Parliament, Parliamentary Assembly of the Council of Europe
International Atomic Energy Agency (IAEA): established - 26 October
1956; effective - 29 July 1957
aim - to promote peaceful uses of atomic energy
members - (145) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bangladesh, Belarus, Belgium,
Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Eritrea, Estonia, Ethiopia, Finland, France, Gabon, Georgia, Germany,
Ghana, Greece, Guatemala, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia,
Lebanon, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Palau, Panama, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal,
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia,','fea779b7ff678fb704857b624e7eba6b0dc687ed082d64679755257f563bf917','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2caffeba9d928407d5d39cbf9d92bddc1b40614855cf8c50fa61b2a2654c15f',2006,'SE','Sweden','environment',1002,'North: a popular term for the rich industrialized countries generally
located in the northern portion of the Northern Hemisphere; the
counterpart of the South; see developed countries (DCs)
North American Free Trade Agreement (NAFTA): established - 17 December
1992
aim - to eliminate trade barriers, promote fair competition, increase
investment opportunities, provide protection of intellectual property
rights, and create procedures to settle disputes
members - (3) Canada, Mexico, US
North Atlantic Treaty Organization (NATO): established - 4 April 1949
aim - to promote mutual defense and cooperation
members - (26) Belgium, Bulgaria, Canada, Czech Republic, Denmark,
Estonia, France, Germany, Greece, Hungary, Iceland, Italy, Latvia,
Lithuania, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania,
Slovakia, Slovenia, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA): note - also known as OECD Nuclear Energy
Agency
established - 1 February 1958
aim - to promote the peaceful uses of nuclear energy; associated with
OECD
members - (28) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway,
Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG): note - also known as the London
Suppliers Group or the London Group
established - 1974; effective - 1975
aim - to establish guidelines for exports of nuclear materials,
processing equipment for uranium enrichment, and technical information
to countries of proliferation concern and regions of conflict and
instability
members - (45) Argentina, Australia, Austria, Belarus, Belgium, Brazil,
Bulgaria, Canada, China, Croatia, Cyprus, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, Kazakhstan, South Korea, Latvia, Lithuania, Luxembourg, Malta,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia,
Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine,
UK, US
observer - (1) European Commission (a policy-planning body for the EU)
Organization for Economic Cooperation and Development (OECD):
established - 14 December 1960; effective - 30 September 1961
aim - to promote economic cooperation and development
members - (30) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
special member - (1) EC
Organization for Security and Cooperation in Europe (OSCE): note -
formerly the Conference on Security and Cooperation in Europe (CSCE)
established 3 July 1975
established - 1 January 1995
aim - to foster the implementation of human rights, fundamental
freedoms, democracy, and the rule of law; to act as an instrument of
early warning, conflict prevention, and crisis management; and to serve
as a framework for conventional arms control and confidence building
measures
members - (56) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Malta, Moldova, Monaco, Montenegro, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine,
UK, US, Uzbekistan
partners for cooperation - (11) Afghanistan, Algeria, Egypt, Israel,
Japan, Jordan, South Korea, Mongolia, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW):
established - 29 April 1997
aim - to enforce the Convention on the Prohibition of the Development,
Production, Stockpiling, and Use of Chemical Weapons and on Their
Destruction; to provide a forum for consultation and cooperation among
the signatories of the Convention
members (countries that have ratified the Convention) - (180)
Afghanistan, Albania, Algeria, Andorra, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Djibouti, East Timor, Ecuador, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
signatory states (countries that have signed, but not ratified, the
Convention) - (6) The Bahamas, Burma, Republic of the Congo, Dominican
Republic, Guinea-Bissau, Israel
Organization of African Unity (OAU): see African Union
Organization of American States (OAS): established - 14 April 1890 as
the International Union of American Republics; 30 April 1948 adopted
present charter; effective - 13 December 1951
aim - to promote regional peace and security as well as economic and
social development
members - (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba
(excluded from formal participation since 1962), Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, US, Uruguay, Venezuela
observers - (60) Algeria, Angola, Armenia, Austria, Azerbaijan,
Belgium, Bosnia and Herzegovina, Bulgaria, China, Croatia, Cyprus,
Czech Republic, Denmark, Egypt, Equatorial Guinea, Estonia, EU,
Finland, France, Georgia, Germany, Ghana, Greece, Holy See, Hungary,
India, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia,
Lebanon, Luxembourg, Morocco, Netherlands, Nigeria, Norway, Pakistan,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia,
Serbia, Slovakia, Slovenia, Spain, Sri Lanka, Sweden, Switzerland,
Thailand, Tunisia, Turkey, Ukraine, UK, Yemen
Organization of Arab Petroleum Exporting Countries (OAPEC):
established - 9 January 1968
aim - to promote cooperation in the petroleum industry
members - (11) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar,
Saudi Arabia, Syria, Tunisia (suspended), UAE
Organization of Eastern Caribbean States (OECS): established - 18 June
1981; effective - 4 July 1981
aim - to promote political, economic, and defense cooperation
members - (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines
associate member - (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting Countries (OPEC): established - 14
September 1960
aim - to coordinate petroleum policies
members - (11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Organization of the Islamic Conference (OIC): established - 22-25
September 1969
aim - to promote Islamic solidarity in economic, social, cultural, and
political affairs
members - (56 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt,
Gabon, The Gambia, Guinea, Guinea-Bissau, Guyana, Indonesia, Iran,
Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman,
Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan,
Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
observers - (11) AU, Bosnia and Herzegovina, Central African Republic,
ECO, LAS, Moro National Liberation Front, NAM, Russia, Thailand,
Turkish Muslim Community of Kibris, UN
Pacific Community (SPC): note - formerly known as the South Pacific
Commission (SPC)
established - 6 February 1947; effective - 29 July 1948
aim - to promote regional cooperation in economic and social matters
members - (26) American Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands,
Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon Islands,
Tokelau, Tonga, Tuvalu, US, Vanuatu, Wallis and Futuna; note - UK
withdrew in January 2005
Pacific Islands Forum (PIF): note - formerly known as South Pacific
Forum (SPF)
established - 5 August 1971
aim - to promote regional cooperation in political matters
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
observers - (4) East Timor, French Polynesia, New Caledonia, Tokelau
Paris Club: established - 1956
aim - to provide a forum for debtor countries to negotiate rescheduling
of debt service payments or loans extended by governments or official
agencies of participating countries; to help restore normal trade and
project finance to debtor countries
members - (19) Australia, Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Ireland, Italy, Japan, Netherlands, Norway, Russia,
Spain, Sweden, Switzerland, UK, US
Partnership for Peace (PFP): established - 10-11 January 1994
aim - to expand and intensify political and military cooperation
throughout Europe, increase stability, diminish threats to peace, and
build relationships by promoting the spirit of practical cooperation
and commitment to democratic principles that underpin NATO; program
under the auspices of NATO
members - (20) Albania, Armenia, Austria, Azerbaijan, Belarus, Croatia,
Finland, Georgia, Ireland, Kazakhstan, Kyrgyzstan, Macedonia, Moldova,
Russia, Sweden, Switzerland, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; note - a nation that becomes a member of NATO is no longer
a member of PFP
Permanent Court of Arbitration (PCA): established - 29 July 1899
aim - to facilitate the settlement of international disputes
members - (105) Argentina, Australia, Austria, Belarus, Belgium,
Belize, Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa
Rica, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Germany, Greece, Guatemala, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Iran, Iraq, Ireland, Israel, Italy,
Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Malaysia, Malta, Mauritius, Mexico, Morocco, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Poland,
Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Thailand, Togo, Turkey,
Uganda, Ukraine, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
Rio Group (RG): note - formerly known as Grupo de los Ocho,
established NA December 1986; composed of the Contadora Group and the
Lima Group
established - 1988
aim - to consult on regional Latin American issues
members - (20) Argentina, Bolivia, Brazil, CARICOM, Chile, Colombia,
Costa Rica, Dominican Republic, Ecuador, El Salvador, Guatemala,
Guyana, Honduras, Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay,
Venezuela
Second World: another term for the traditionally Marxist-Leninist
states of the USSR and Eastern Europe, with authoritarian governments
and command economies based on the Soviet model; the term is fading
from use; see centrally planned economies
Secretariat of the Pacific Communities (SPC): established - 6 February
1947
aim - to serve island development in 22 Pacific countries; to develop
technical assistance and professional, scientific, and research
support; to build planning and management capability
members - (26) America Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, Niue, Northern Mariana Islands, NZ,
Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon Islands,
Tokelau, Tonga, Tuvalu, Vanuatu, US, Wallis and Futuna
Shanghai Cooperation Organization (SCO): established - 15 June 1901
aim - to combat terrorism, extremism, and separatism; to safeguard
regional security through mutual trust, disarmament, and cooperative
security; and to increase cooperation in political, trade, economic,
scientific and technological, cultural, and educational fields
members - (6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan,','6ff8616df4e8f8983b1fc5bcbbc8e9a12d0819d06adeaac17592eadd1e217cb9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e06dc8ae1c2483c139de84755a5582dcba04c380e203f5e47479d1622fa4dc42',2006,'ZM','Zambia','environment',1003,'United Nations Industrial Development Organization (UNIDO):
established - 17 November 1966; effective - 1 January 1967
aim - UN specialized agency that promotes industrial development
especially among the members
members - (171) includes all UN member countries except Andorra,
Antigua and Barbuda, Australia, Brunei, Canada, Estonia, Iceland,
Kiribati, Latvia, Liechtenstein, Marshall Islands, Federated States of
Micronesia, Montenegro, Nauru, Palau, Samoa, San Marino, Singapore,
Solomon Islands, Tuvalu, US
United Nations Institute for Training and Research (UNITAR):
established - 11 December 1963 adoption of the resolution establishing
the Institute; effective - 24 March 1965
aim - to help the UN become more effective through training and
research
members (Board of Trustees) - (18) Belgium, Brazil, China, Czech
Republic, Egypt, France, Ghana, Japan, Kuwait, Mexico, Monaco, Morocco,
Nigeria, Pakistan, Russia, South Africa, Switzerland, US; note - the UN
Secretary General can appoint up to 30 members
United Nations Interim Administration Mission in Kosovo (UNMIK):
established - 10 June 1999
aim - to promote the establishment of substantial autonomy and self-
government in Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key infrastructure and
humanitarian and disaster relief
note - gives civilian support only; works closely with NATO Kosovo
Force (KFOR)
United Nations Interim Force in Lebanon (UNIFIL): established - 19
March 1978
aim - to confirm the withdrawal of Israeli forces, and assist in
reestablishing Lebanese authority in southern Lebanon; established by
the UN Security Council
members - (11) Belgium, China, Finland, France, Ghana, India, Ireland,
Italy, Norway, Poland, Spain
United Nations Military Observer Group in India and Pakistan (UNMOGIP):
established - 24 January 1949
aim - to observe the 1949 India-Pakistan cease-fire; established by the
UN Security Council
members - (8) Chile, Croatia, Denmark, Finland, Italy, South Korea,
Sweden, Uruguay
United Nations Mission for the Referendum in Western Sahara (MINURSO):
established - 29 April 1991
aim - to supervise the cease-fire and conduct a referendum in Western
Sahara; established by the UN Security Council
members - (25) Argentina, Austria, Bangladesh, China, Croatia, Denmark,
Egypt, El Slavador, France, Ghana, Greece, Guinea, Honduras, Hungary,
Ireland, Italy, Kenya, Malaysia, Mongolia, Nigeria, Pakistan, Poland,
Russia, Sri Lanka, Uruguay
United Nations Mission in Ethiopia and Eritrea (UNMEE): established -
31 July 2000
aim - to monitor the cessation of hostilities
members - (39) Algeria, Austria, Bangladesh, Bosnia and Herzegovina,
Bulgaria, China, Croatia, Czech Republic, Denmark, Finland, France,
Germany, Ghana, Greece, Guatemala, India, Iran, Jordan, Kenya,
Malaysia, Namibia, Nepal, Nigeria, Norway, Paraguay, Peru, Poland,
Romania, Russia, South Africa, Spain, Sweden, Switzerland, Tanzania,
Tunisia, Ukraine, US, Uruguay, Zambia
United Nations Mission in Liberia (UNMIL): established - 19 September
2003
aim - to support the cease-fire agreement and peace process, protect UN
facilities and people, support humanitarian activities, and assist in
national security reform
Bangladesh, Benin, Bolivia, Brazil, Bulgaria, China, Croatia, Czech
Republic, Denmark, Ecuador, Egypt, El Salvador, Ethiopia, Finland,
France, The Gambia, Germany, Ghana, Indonesia, Ireland, Jordan, Kenya,
South Korea, Kyrgyzstan, Malawi, Malaysia, Mali, Moldova, Mongolia,
Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines,
Poland, Romania, Russia, Senegal, Serbia, Sweden, Togo, Ukraine, UK,
US, Zambia
United Nations Mission in Sierra Leone (UNAMSIL): established on 22
October 1999; aim was to to cooperate with the Government of Sierra
Leone and the other parties to the Peace Agreement in the
implementation of the agreement; to monitor the military and security
situation in Sierra Leone; to monitor the disarmament and
demobilization of combatants and members of the Civil Defense Forces
(CFD); to assist in monitoring respect for international humanitarian
law; mandate ended 31 December 2005; members were Bangladesh, Bolivia,
China, Croatia, Czech Republic, Egypt, The Gambia, Germany, Ghana,
Guinea, Indonesia, Jordan, Kenya, Kyrgyzstan, Malaysia, Nepal, Nigeria,
Pakistan, Russia, Slovakia, Sweden, Tanzania, Thailand, Ukraine, UK,
Uruguay, Zambia
United Nations Mission in the Sudan (UNMIS): established - March 2005
aim - to support implementation of the comprehensive Peace Agreement by
Monitoring and verifying the implementation of the Cease Fire
Agreement, by observing and monitoring movements of armed groups, and
by helping disarm, demobilizing and reintegrating armed bands
members - (59) Australia, Bangladesh, Benin, Bolivia, Botswana, Brazil,
Burkina Faso, Cambodia, Canada, China, Croatia, Denmark, Ecuador,
Egypt, El Salvador, Fiji, Finland, Gabon, Germany, Greece, Guatemala,
Guinea, India, Indonesia, Jordan, Kenya, South Korea, Kyrgyzstan,
Malawi, Malaysia, Mali, Moldova, Mongolia, Mozambique, Namibia, Nepal,
Netherland, NZ, Nigeria, Norway, Pakistan, Paraguay, Peru, Philippines,
Poland, Romania, Russia, Rwanda, Sri Lanka, Sweden, Tanzania, Thailand,
Turkey, Uganda, Ukraine, UK, Yemen, Zambia, Zimbabwe
United Nations Mission of Support in East Timor (UNMISET): established
on 17 May 2002 to provide assistance to structures critical to public
security and to assist in the development of law enforcement agencies;
to contribute to extenal security; members were Australia, Bangladesh,
Bolivia, Brazil, Denmark, Fiji, Jordan, Malaysia, Mozambique, Nepal,
NZ, Pakistan, Philippines, Portugal, Russia, Sweden; completed its
mandate 20 May 2005
United Nations Monitoring, Verification, and Inspection Commission
(UNMOVIC): note - formerly known as United Nations Special Commission
for the Elimination of Iraq''s Weapons of Mass Destruction (UNSCOM)
established - December 1999
aim - to identify, account for, and eliminate Iraq''s weapons of mass
destruction and the capacity to produce them
commissioners - (16) Argentina, Brazil, Canada, China, UN Department
for Disarmament Affairs, France, Germany, India, Japan, Mexico,
Nigeria, Russia, Senegal, Ukraine, UK, US
United Nations Operation in Burundi (ONUB): established - 21 May 2004
aim - to support and help implement the efforts undertaken by
Burundians to restore lasting peace and bring about national
reconciliation
members - (30) Algeria, Belgium, Benin, Burkina Faso, Chad, Egypt,
Ethiopia, The Gambia, Ghana, Guatemala, India, Jordan, Kenya, South
Korea, Malawi, Mali, Nambia, Nepal, Niger, Nigeria, Pakistan,
Philippines, Portugal, Russia, Senegal, South Africa, Thailand, Togo,
Tunisia, Yemen
United Nations Observer Mission in Georgia (UNOMIG): established - 24
August 1993
aim - to verify compliance with the cease-fire agreement, to monitor
weapons exclusion zone, and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security Council
members - (26) Albania, Austria, Bangladesh, Croatia, Czech Republic,
Denmark, Egypt, France, Germany, Greece, Hungary, India, Indonesia,
Jordan, South Korea, Pakistan, Poland, Romania, Russia, Sweden,
Switzerland, Turkey, Ukraine, UK, US, Uruguay
United Nations Organization Mission in the Democratic Republic of the
Congo (MONUC): established - 30 November 1999
aim - to establish contacts with the signatories to the cease-fire
agreement and to plan for the observation of the cease-fire and
disengagement of forces
members - (51) Algeria, Bangladesh, Belgium, Benin, Bolivia, Bosnia and
Herzegovina, Burkina Faso, Cameroon, Canada, China, Czech Republic,
Denmark, Egypt, France, Ghana, Guatemala, Guinea, India, Indonesia,
Ireland, Jordan, Kenya, Malawi, Malaysia, Mali, Mongolia, Morocco,
Mozambique, Nepal, Netherlands, Niger, Nigeria, Pakistan, Paraguay,
Peru, Poland, Romania, Russia, Senegal, Serbia, South Africa, Spain,
Sri Lanka, Sweden, Switzerland, Togo, Tunisia, Ukraine, UK, Uruguay,
United Nations Operation in Cote d''Ivoire (UNOCI): established - 27
February 2004
aim - to facilitate the implementation by the Ivorian parties of the
peace agreement signed by them in January 2003
members - (41) Bangladesh, Benin, Bolivia, Brazil, Chad, China,
Croatia, Dominican Republic, Ecuador, El Salvador, Ethiopia, France,
The Gambia, Ghana, Guatemala, Guinea, India, Ireland, Jordan, Kenya,
Moldova, Morocco, Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay,
Peru, Philippines, Poland, Romania, Russia, Senegal, Serbia, Tanzania,
Togo, Turkey, Uruguay, Vanuatu, Yemen
United Nations Peace-keeping Force in Cyprus (UNFICYP): established -
4 March 1964
aim - to serve as a peacekeeping force between Greek Cypriots and
Turkish Cypriots in Cyprus; established by the UN Security Council
members - (7) Argentina, Austria, Croatia, Hungary, Slovakia, UK,','9c250a2742a6aee65fee3bbaebb5082b59189c43cce564b5875123eee35bdee1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23e6de2cc888c41b283ef1cf523d56eb65b03f6e4bb2f9eb7d6a249519408c6c',2006,'UY','Uruguay','environment',1004,'United Nations Population Fund (UNFPA): note - acronym retained from
predecessor organization UN Fund for Population Activities
established - July 1967
aim - to assist both developed and developing countries to deal with
their population problems
members (executive board ) - (36) selected on a rotating basis from all
regions
United Nations Relief and Works Agency for Palestine Refugees in the
Near East (UNRWA): established - 8 December 1949
aim - to provide assistance to Palestinian refugees
members (advisory commission) - (22) Australia, Belgium, Canada,
Denmark, EC, Egypt, France, Germany, Italy, Japan, Jordan, Lebanon,
Netherlands, Norway, Saudi Arabia, Spain, Sweden, Switzerland, Syria,
Turkey, UK, US
United Nations Research Institute for Social Development (UNRISD):
established - 1963
aim - to conduct research into the problems of economic development
during different phases of economic growth
members - no country members, but a Board of Directors consisting of a
chairman appointed by the UN secretary general and 10 individual
members
United Nations Secretariat: established - 26 June 1945; effective - 24
October 1945
aim - to serve as the primary administrative organ of the UN; a
Secretary General is appointed for a five-year term by the General
Assembly on the recommendation of the Security Council
members - the UN Secretary General and staff
United Nations Security Council (UNSC): established - 26 June 1945;
effective - 24 October 1945
aim - to maintain international peace and security
permanent members - (5) China, France, Russia, UK, US
nonpermanent members - (10) elected for two-year terms by the UN
General Assembly; Argentina (2005-06), Republic of the Congo (2006-07),
Denmark (2005-06), Ghana (2006-07), Greece (2005-06), Japan (2005-06),
Peru (2006-07), Qatar (2006-07), Slovakia (2006-07), Tanzania (2005-06)
United Nations Stabilization Mission in Haiti (MINUSTAH): established
- 30 April 2004
aim - to stabilize Haiti in many areas for at least six months
members - (19) Argentina, Bolivia, Brazil, Canada, Chile, Croatia,
Ecuador, France, Guatemala, Jordan, Morocco, Nepal, Pakistan, Paraguay,
Peru, Philippines, Sri Lanka, US, Uruguay
United Nations Truce Supervision Organization (UNTSO): established -
June 1948
aim - to supervise the 1948 Arab-Israeli cease-fire; currently supports
timely deployment of reinforcements to other peacekeeping operations in
the region as needed; initially established by the UN Security Council
members - (23) Argentina, Australia, Austria, Belgium, Canada, Chile,
China, Denmark, Estonia, Finland, France, Ireland, Italy, Nepal,
Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden,
Switzerland, US
United Nations Trusteeship Council: established on 26 June 1945,
effective on 24 October 1945, to supervise the administration of the 11
UN trust territories; members were China, France, Russia, UK, US; it
formally suspended operations 1 November 1995 after the Trust Territory
of the Pacific Islands (Palau) became the Republic of Palau, a
constitutional government in free association with the US; the
Trusteeship Council was not dissolved
United Nations University (UNU): established - 3 December 1973
aim - to conduct research in development, welfare, and human survival
and to train scholars
members - (24 members of UNU Council and the Rector are appointed by
the Secretary General of the United Nations and the Director General of
UNESCO)
Universal Postal Union (UPU): established - 9 October 1874, affiliated
with the UN 15 November 1947; effective - 1 July 1948
aim - to promote international postal cooperation; a UN specialized
agency
members - (189) includes all UN member countries except Andorra,
Marshall Islands, Federated States of Micronesia, and Palau (188
total); plus Holy See; note - includes the following dependencies or
areas of special interest: Australia (Norfolk Island), China (Hong
Kong, Macau), Denmark (Faroe Islands, Greenland), France (French
Guiana, French Polynesia, French Southern and Antarctic Lands,
Guadeloupe, Iles Eparses, Martinique, Mayotte, New Caledonia, Reunion,
Saint Pierre and Miquelon, Wallis and Futuna), Netherlands (Aruba,
Netherlands Antilles), NZ (Cook Island, Niue, Tokelau), UK (Guernsey,
Isle of Man, Jersey; Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar,
Montserrat, Pitcairn, Saint Helena, Turks and Caicos), US (American
Samoa, Guam, Northern Mariana Islands, Puerto Rico, South Georgia and
South Sandwich Islands, Virgin Islands)
Warsaw Pact (WP): established 14 May 1955 to promote mutual defense;
members met 1 July 1991 to dissolve the alliance; member states at the
time of dissolution were: Bulgaria, Czechoslovakia, Hungary, Poland,
Romania, and the USSR; earlier members included German Democratic
Republic (GDR) and Albania
West African Development Bank (WADB): note - also known as Banque
Ouest-Africaine de Developpement (BOAD); is a financial institution of
WAEMU
established - 14 November 1973
aim - to promote regional economic development and integration
regional members - (9) Central Bank of West African States, Benin,
Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
international/nonregional members - (6) African Development Bank,
Belgium, European Investment Bank, France, Germany, People''s Bank of','fec2c0f0f57cab1f097fe7df68129f9c38aed7165c3d54678a5ef77d26d8ee4a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83ffa92e0276f02041a35fe8d794081e634f85031e8f6e69a98efd49ebcc62a4',2006,'CN','China','environment',1005,'West African Economic and Monetary Union (WAEMU): note - also known as
Union Economique et Monetaire Ouest Africaine (UEMOA)
established - 1 August 1994
aim - to increase competitiveness of members'' economic markets; to
create a common market
members - (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali,
Niger, Senegal, Togo
Western European Union (WEU): established - 23 October 1954; effective
- 6 May 1955
aim - to provide mutual defense and to move toward political
unification
members - (10) Belgium, France, Germany, Greece, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
associate members - (6) Czech Republic, Hungary, Iceland, Norway,
Poland, Turkey
associate partners - (7) Bulgaria, Estonia, Latvia, Lithuania, Romania,
Slovakia, Slovenia
observers - (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank Group: includes International Bank for Reconstruction and
Development (IBRD), International Development Association (IDA),
International Finance Corporation (IFC), and Multilateral Investment
Guarantee Agency (MIGA)
World Confederation of Labor (WCL): established - 19 June 1920 as the
International Federation of Christian Trade Unions (IFCTU), renamed 4
October 1968
aim - to promote the trade union movement
members - (105 national organizations) Antigua and Barbuda, Argentina,
Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Brazil,
Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic,
Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic,
Denmark, Dominica, Dominican Republic, Ecuador, El Salvador, France,
French Guiana, Gabon, The Gambia, Ghana, Guadeloupe, Guatemala, Guinea,
Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia, Iran,
Italy, Japan, Kazakhstan, South Korea, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Malta,
Martinique, Mauritania, Mauritius, Mexico, Morocco, Namibia, Nepal,
Netherlands, Netherlands Antilles, Nicaragua, Niger, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania,
Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Senegal, Serbia, Sierra Leone, Singapore, Slovakia, South
Africa, Spain, Sri Lanka, Suriname, Switzerland, Taiwan, Thailand,
Togo, Trinidad and Tobago, Ukraine, US, Uruguay, Venezuela, Vietnam,
Zambia, Zimbabwe
World Customs Organization (WCO): note - began as the Customs
Cooperation Council (CCC)
established - 15 December 1950
aim - to promote international cooperation in customs matters
members - (168) Afghanistan, Albania, Algeria, Andorra, Angola,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Benin, Bermuda,
Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Samoa, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
World Federation of Trade Unions (WFTU): established - 3 October 1945
aim - to promote the trade union movement
members - (125 and the Palestine Liberation Organization) Afghanistan,
Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea,
Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan,
Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon,
Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Mali,
Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia, NZ,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Puerto Rico, Reunion, Romania, Russia,
Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Sierra Leone, Slovakia, Solomon
Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Program (WFP): established - 24 November 1961
aim - to provide food aid in support of economic development or
disaster relief; an ECOSOC organization
members - (36) selected on a rotating basis from all regions
World Health Organization (WHO): established - 22 July 1946; effective
- 7 April 1948
aim - to deal with health matters worldwide; a UN specialized agency
members - (193) includes all UN member countries except Liechtenstein
(191 total); plus Cook Islands and Niue
World Intellectual Property Organization (WIPO): established - 14 July
1967; effective - 26 April 1970
aim - to furnish protection for literary, artistic, and scientific
works; a UN specialized agency
members - (183) includes all UN member countries except East Timor,
Kiribati, Marshall Islands, Federated States of Micronesia, Montenegro,
Nauru, Palau, Solomon Islands, Tuvalu, Vanuatu (182 total); plus Holy
See
World Meteorological Organization (WMO): established - 11 October
1947; effective - 4 April 1951
aim - to sponsor meteorological cooperation; a UN specialized agency
members - (188) includes all UN member countries except Andorra, East
Timor, Equatorial Guinea, Grenada, Liechtenstein, Marshall Islands,
Montenegro, Nauru, Palau, Saint Kitts and Nevis, Saint Vincent and the
Grenadines, San Marino, Tuvalu (179 total); plus Aruba, British
Caribbean Territories, Cook Islands, French Polynesia, Hong Kong,
Macau, Netherlands Antilles, New Caledonia, and Niue
World Tourism Organization (WToO): established - 2 January 1975
aim - to promote tourism as a means of contributing to economic
development, international understanding, and peace
members - (150) Afghanistan, Albania, Algeria, Andorra, Angola,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Belarus, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Djibouti, Dominican Republic, East Timor, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-
Bissau, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Libya,
Lithuania, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sudan, Swaziland, Switzerland, Syria, Tanzania, Thailand, Togo,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UK, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (7) Aruba, Flanders, Hong Kong, Macau, Madeira
Islands, Netherlands Antilles, Puerto Rico
observers - (1 plus Palestine Liberation Organization) Holy See,
Palestine Liberation Organization
World Trade Organization (WTO): note - succeeded General Agreement on
Tariff and Trade (GATT)
established - 15 April 1994; effective - 1 January 1995
aim - to provide a forum to resolve trade conflicts between members and
to carry on negotiations with the goal of further lowering and/or
eliminating tariffs and other trade barriers
members - (149) Albania, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium,
Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, EC, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho,
Liechtenstein, Lithuania, Luxembourg, Macau, Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Saudi Arabia, Senegal, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka,
Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US,
Uruguay, Venezuela, Zambia, Zimbabwe
observers - (32) Afghanistan, Algeria, Andorra, Azerbaijan, The
Bahamas, Belarus, Bhutan, Bosnia and Herzegovina, Cape Verde,
Equatorial Guinea, Ethiopia, Holy See, Iran, Iraq, Kazakhstan, Laos,
Lebanon, Libya, Montenegro, Russia, Samoa, Sao Tome and Principe,
Serbia, Seychelles, Sudan, Tajikistan, Tonga, Ukraine, Uzbekistan,
Vanuatu, Vietnam, Yemen; note - with the exception of the Holy See, an
observer must start accession negotiations within five years of
becoming observers; Montenegro and Serbia each sent observers
Zangger Committee (ZC): established - early 1970s
aim - to establish guidelines for the export control provisions of the
Nonproliferation of Nuclear Weapons Treaty (NPT)
members - (36) Argentina, Australia, Austria, Belgium, Bulgaria,
Canada, China, Croatia, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea,
Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK, US
observers - (1) EC
This page was last updated on 19 December, 2006
=====================================================================
Appendix C - Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
Antarctic - Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature - 1 December 1959
entered into force - 23 June 1961
objective - to ensure that Antarctica is used for peaceful purposes
only (such as international cooperation in scientific research); to
defer the question of territorial claims asserted by some nations and
not recognized by others; to provide an international forum for
management of the region; applies to land and ice shelves south of 60
degrees south latitude
parties - (45) Argentina, Australia, Austria, Belgium, Brazil,
Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Estonia, Finland, France, Germany, Greece, Guatemala,
Hungary, India, Italy, Japan, North Korea, South Korea, Netherlands,
NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia,
South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US,
Uruguay, Venezuela
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
note - abbreviated as Hazardous Wastes
opened for signature - 22 March 1989
entered into force - 5 May 1992
objective - to reduce transboundary movements of wastes subject to the
Convention to a minimum consistent with the environmentally sound and
efficient management of such wastes; to minimize the amount and
toxicity of wastes generated and ensure their environmentally sound
management as closely as possible to the source of generation; and to
assist LDCs in environmentally sound management of the hazardous and
other wastes they generate
parties - (149) Albania, Algeria, Andorra, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, EU,
Finland, France, The Gambia, Georgia, Germany, Greece, Guatemala,
Guinea, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Japan, Jordan, Kenya, Kiribati, South Korea,
Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Serbia,
Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified - (3) Afghanistan,
Haiti, US
Biodiversity
see Convention on Biological Diversity
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on
Climate Change
Convention for the Conservation of Antarctic Seals
note - abbreviated as Antarctic Seals
opened for signature - 1 June 1972
entered into force - 11 March 1978
objective - to promote and achieve the protection, scientific study,
and rational use of Antarctic seals, and to maintain a satisfactory
balance within the ecological system of Antarctica
parties - (16) Argentina, Australia, Belgium, Brazil, Canada, Chile,
France, Germany, Italy, Japan, Norway, Poland, Russia, South Africa,
UK, US
countries that have signed, but not yet ratified - (1) NZ
Convention on Biological Diversity
note - abbreviated as Biodiversity
opened for signature - 5 June 1992
entered into force - 29 December 1993
objective - to develop national strategies for the conservation and
sustainable use of biological diversity
parties - (182) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (6) Afghanistan,
Kuwait, Serbia, Thailand, Tuvalu, US
Convention on Fishing and Conservation of Living Resources of the High
Seas
note - abbreviated as Marine Life Conservation
opened for signature - 29 April 1958
entered into force - 20 March 1966
objective - to solve through international cooperation the problems
involved in the conservation of living resources of the high seas,
considering that because of the development of modern technology some
of these resources are in danger of being overexploited
parties - (37) Australia, Belgium, Bosnia and Herzegovina, Burkina
Faso, Cambodia, Colombia, Denmark, Dominican Republic, Fiji, Finland,
France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Serbia,
Sierra Leone, Solomon Islands, South Africa, Spain, Switzerland,
Thailand, Tonga, Trinidad and Tobago, Uganda, UK, US, Venezuela
countries that have signed, but not yet ratified - (21) Afghanistan,
Argentina, Bolivia, Canada, Costa Rica, Cuba, Ghana, Iceland,
Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ,
Pakistan, Panama, Sri Lanka, Tunisia, Uruguay
Convention on Long-Range Transboundary Air Pollution
note - abbreviated as Air Pollution
opened for signature - 13 November 1979
entered into force - 16 March 1983
objective - to protect the human environment against air pollution and
to gradually reduce and prevent air pollution, including long-range
transboundary air pollution
parties - (48) Armenia, Austria, Belarus, Belgium, Bosnia and
Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece,
Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova,
Monaco, Netherlands, Norway, Poland, Portugal, Romania, Russia, Serbia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
countries that have signed, but not yet ratified - (2) Holy See, San
Marino
Convention on Wetlands of International Importance Especially as
Waterfowl Habitat (Ramsar)
note - abbreviated as Wetlands
opened for signature - 2 February 1971
entered into force - 21 December 1975
objective - to stem the progressive encroachment on and loss of
wetlands now and in the future, recognizing the fundamental ecological
functions of wetlands and their economic, cultural, scientific, and
recreational value
parties - (125) Albania, Algeria, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Belarus,
Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina Faso, Cambodia, Canada, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic,
Denmark, Ecuador, Egypt, El Salvador, Estonia, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-
Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Latvia,
Lebanon, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar,
Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Monaco,
Mongolia, Morocco, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Russia, Senegal, Serbia, Sierra
Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname,
Sweden, Switzerland, Syria, Tajikistan, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Zambia
Convention on the Conservation of Antarctic Marine Living Resources
note - abbreviated as Antarctic-Marine Living Resources
opened for signature - 5 May 1980
entered into force - 7 April 1982
objective - to safeguard the environment and protect the integrity of
the ecosystem of the seas surrounding Antarctica, and to conserve
Antarctic marine living resources
parties - (31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada,
Chile, EU, Finland, France, Germany, Greece, India, Italy, Japan, South
Korea, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South
Africa, Spain, Sweden, Ukraine, UK, US, Uruguay, Vanuatu
Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
note - abbreviated a','8aaf69b50d683f16c097104195ee8ee8285b50998695fda33d955a7e45001a82','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('824de07f760444c683218b1de5d2c3b81b94fa5b731872c9a61c10fa3f062ca6',2006,'CN','China','environment',1006,'s Endangered Species
opened for signature - 3 March 1973
entered into force - 1 July 1975
objective - to protect certain endangered species from overexploitation
by means of a system of import/export permits
parties - (156) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Latvia, Liberia, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,','6d3d1e0cbcf49760a89a87b8b2c822ec29170c92fcf3a0118ddf6900d52505ba','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f3d1616550abed307c9153e7b1f80f308029010225d081c38923317f9192c82',2006,'LS','Lesotho','environment',1007,'Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter (London Convention)
note - abbreviated as Marine Dumping
opened for signature - 29 December 1972
entered into force - 30 August 1975
objective - to control pollution of the sea by dumping and to encourage
regional agreements supplementary to the Convention
parties - (78) Afghanistan, Antigua and Barbuda, Argentina, Australia,
Azerbaijan, Barbados, Belarus, Belgium, Brazil, Canada, Cape Verde,
Chile, China, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Egypt,
Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras,
Hong Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Libya,
Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru, Netherlands, NZ,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Philippines,
Poland, Portugal, Russia, Saint Lucia, Serbia, Seychelles, Slovenia,
Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland,
Tonga, Tunisia, Ukraine, UAE, UK, US, Vanuatu
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
note - abbreviated as Environmental Modification
opened for signature - 10 December 1976
entered into force - 5 October 1978
objective - to prohibit the military or other hostile use of
environmental modification techniques in order to further world peace
and trust among nations
parties - (66) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Bangladesh, Belarus, Belgium, Benin, Brazil,
Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Egypt, Finland, Germany, Ghana, Greece,
Guatemala, Hungary, India, Ireland, Italy, Japan, North Korea, South
Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ,
Niger, Norway, Pakistan, Papua New Guinea, Poland, Romania, Russia,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Slovakia, Solomon Islands, Spain, Sri Lanka, Sweden, Switzerland,
Tajikistan, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan, Vietnam,','ec80893845632be77404c1485d6df87f03e984619641169c886e1c2c37763fd7','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d88d74cb98381f5524d9c2a0d5393bf54a9aa791e287fa347c69c2a0d82bbd6',2006,'YE','Yemen','environment',1008,'countries that have signed, but not yet ratified - (17) Bolivia,
Democratic Republic of the Congo, Ethiopia, Holy See, Iceland, Iran,
Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal,
Sierra Leone, Syria, Turkey, Uganda
Desertification
see United Nations Convention to Combat Desertification in those
Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use
of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal
International Convention for the Regulation of Whaling
note - abbreviated as Whaling
opened for signature - 2 December 1946
entered into force - 10 November 1948
objective - to protect all species of whales from overhunting; to
establish a system of international regulation for the whale fisheries
to ensure proper conservation and development of whale stocks; and to
safeguard for future generations the great natural resources
represented by whale stocks
parties - (42) Antigua and Barbuda, Argentina, Australia, Austria,
Brazil, Chile, China, Costa Rica, Denmark, Dominica, Finland, France,
Germany, Grenada, Guinea, India, Ireland, Italy, Japan, Kenya, South
Korea, Mexico, Monaco, Morocco, Netherlands, NZ, Norway, Oman, Panama,
Peru, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Senegal, Solomon Islands, South Africa, Spain, Sweden,
Switzerland, UK, US
International Tropical Timber Agreement, 1983
note - abbreviated as Tropical Timber 83
opened for signature - 18 November 1983
entered into force - 1 April 1985; this agreement expired when the
International Tropical Timber Agreement, 1994, went into force
objective - to provide an effective framework for cooperation between
tropical timber producers and consumers and to encourage the
development of national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic resources
parties - (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cameroon, Canada, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Denmark, Ecuador, Egypt, EU,
Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras,
India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New
Guinea, Peru, Philippines, Portugal, Russia, Spain, Sweden,
Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
International Tropical Timber Agreement, 1994
note - abbreviated as Tropical Timber 94
opened for signature - 26 January 1994
entered into force - 1 January 1997
objective - to ensure that by the year 2000 exports of tropical timber
originate from sustainably managed sources; to establish a fund to
assist tropical timber producers in obtaining the resources necessary
to reach this objective
parties - (58) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cambodia, Cameroon, Canada, Central African Republic, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Denmark, Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany,
Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy,
Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands,
NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and
Tobago, UK, US, Uruguay, Vanuatu, Venezuela
countries that have signed, but not yet ratified - (1) Ireland
Kyoto Protocol to the United Nations Framework Convention on Climate
Change
note - abbreviated as Climate Change-Kyoto Protocol
opened for signature - 16 March 1998
entered into force - 23 February 2005
objective - to further reduce greenhouse gas emissions by enhancing the
national programs of developed countries aimed at this goal and by
establishing percentage reduction targets for the developed countries
parties - (144) Algeria, Antigua and Barbuda, Argentina, Armenia,
Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados, Belgium,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria, Burma,
Burundi, Cambodia, Cameroon, Canada, Chile, China, Colombia, Cook
Island, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Estonia, EU, Fiji, Finland, France, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Honduras,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kenya, Kiribati, South Korea, Kyrgyzstan, Laos, Latvia,
Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi
Arabia, Senegal, Seychelles, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen
countries that have signed, but not yet ratified - (6) Australia,
Croatia, Kazakhstan, Monaco, US, Zambia
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the
High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer
< I>note - abbreviated as Ozone Layer Protection
opened for signature - 16 September 1987
entered into force - 1 January 1989
objective - to protect the ozone layer by controlling emissions of
substances that deplete it
parties - (183) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE,
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
note - abbreviated as Ship Pollution
opened for signature - 17 February 1978
entered into force - 2 October 1983
objective - to preserve the marine environment through the complete
elimination of pollution by oil and other harmful substances and the
minimization of accidental discharge of such substances
parties - (119) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada,
Chile, China, Colombia, Comoros, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, Equatorial Guinea, Estonia, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guyana, Honduras,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica,
Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon,
Liberia, Lithuania, Luxembourg, Malawi, Malaysia, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Monaco, Morocco, Netherlands,
NZ, Nicaragua, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Romania, Russia, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Switzerland, Syria, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam
Protocol on Environmental Protection to the Antarctic Treaty
note - abbreviated as Antarctic-Environmental Protocol
opened for signature - 4 October 1991
entered into force - 14 January 1998
objective - to provide for comprehensive protection of the Antarctic
environment and dependent and associated ecosystems; applies to the
area covered by the Antarctic Treaty
consultative parties - (27) Argentina, Australia, Belgium, Brazil,
Bulgaria, Chile, China, Ecuador, Finland, France, Germany, India,
Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland,
Russia, South Africa, Spain, Sweden, UK, US, Uruguay
non consultative parties - (16) Austria, Canada, Colombia, Cuba, Czech
Republic, Denmark, Greece, Guatemala, Hungary, North Korea, Papua New
Guinea, Romania, Slovakia, Switzerland, Turkey, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
note - abbreviated as Air Pollution-Nitrogen Oxides
opened for signature - 31 October 1988
entered into force - 14 February 1991
objective - to provide for the control or reduction of nitrogen oxides
and their transboundary fluxes
parties - (28) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, EU, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands,
Norway, Russia, Slovakia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified - (1) Poland
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
note - abbreviated as Air Pollution-Volatile Organic Compounds
opened for signature - 18 November 1991
entered into force - 29 September 1997
objective - to provide for the control and reduction of emissions of
volatile organic compounds in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (21) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Hungary, Italy, Liechtenstein,
Luxembourg, Monaco, Netherlands, Norway, Slovakia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified - (6) Canada, EU,
Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
note - abbreviated as Air Pollution-Sulphur 94
opened for signature - 14 June 1994
entered into force - 5 August 1998
objective - to provide for a further reduction in sulfur emissions or
transboundary fluxes
parties - (23) Austria, Belgium, Canada, Croatia, Czech Republic,
Denmark, EU, Finland, France, Germany, Greece, Ireland, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia,
Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified - (5) Bulgaria,
Hungary, Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
note - abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature - 24 June 1998
entered into force - 23 October 2003
objective - to provide for the control and reduction of emissions of
persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (22) Austria, Bulgaria, Canada, Cyprus, Czech Republic,
Denmark, EU, Finland, France, Germany, Hungary, Iceland, Latvia,
Liechtenstein, Luxembourg, Moldova, Netherlands, Norway, Romania,
Slovakia, Sweden, Switzerland
countries that have signed, but not yet ratified - (14) Armenia,
Belgium, Croatia, Greece, Ireland, Italy, Lithuania, Poland, Portugal,
Slovenia, Spain, Ukraine, UK, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
note - abbreviated as Air Pollution-Sulphur 85
opened for signature - 8 July 1985
entered into force - 2 September 1987
objective - to provide for a 30% reduction in sulfur emissions or
transboundary fluxes by 1993
parties - (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space,
and Under Water
note - abbreviated as Nuclear Test Ban
opened for signature - 5 August 1963
entered into force - 10 October 1963
objective - to obtain an agreement on general and complete disarmament
under strict international control in accordance with the objectives of
the United Nations; to put an end to the armaments race and eliminate
incentives for the production and testing of all kinds of weapons,
including nuclear weapons
parties - (113) Afghanistan, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, The Bahamas, Bangladesh, Belgium, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma,
Canada, Central African Republic, Chad, China, Colombia, Democratic
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece,
Guatemala, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, Liberia, Luxembourg, Madagascar, Malawi,
Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Panama, Papua New
Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San
Marino, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, UK, US, Venezuela, Zambia
countries that have signed, but not yet ratified - (17) Algeria,
Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya, Mali,
Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam,
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS)
note - abbreviated as Law of the Sea
opened for signature - 10 December 1982
entered into force - 16 November 1994
objective - to set up a comprehensive new legal regime for the sea and
oceans; to include rules concerning environmental standards as well as
enforcement provisions dealing with pollution of the marine environment
parties - (148) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain,
Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Cameroon, Canada, Cape Verde, Chile, China, Comoros, Democratic
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Egypt, Equatorial Guinea, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South
Korea, Kuwait, Laos, Latvia, Lebanon, Lithuania, Luxembourg, Macedonia,
Madagascar, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco,
Mongolia, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia,
Tuvalu, Uganda, Ukraine, UK, Uruguay, Vanuatu, Vietnam, Yemen, Zambia,','330842c547aac198b459fad85f5bd4831de2a37f9996b5ceb3ba2a9cbb3ed6c4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae0430c5764eaa03029075abb5de5d6f2d9ea0abd7afe15ee847d96952f3cd2b',2006,'NL','Netherlands','environment',1009,'Antilles NT AN ANT 530 .an
New Caledonia NC NC NCL 540 .nc
New Zealand NZ NZ NZL 554 .nz
Nicaragua NU NI NIC 558 .ni
Niger NG NE NER 562 .ne
Nigeria NI NG NGA 566 .ng
Niue NE NU NIU 570 .nu
Norfolk Island NF NF NFK 574 .nf
Northern Mariana
Islands CQ MP MNP 580 .mp
Norway NO NO NOR 578 .no
Oman MU OM OMN 512 .om
Pakistan PK PK PAK 586 .pk
Palau PS PW PLW 585 .pw
Palmyra Atoll LQ - - -
ISO includes with the US Minor Outlying Islands
Panama PM PA PAN 591 .pa
Papua New Guinea PP PG PNG 598 .pg
Paracel Islands PF - - -
Paraguay PA PY PRY 600 .py
Peru PE PE PER 604 .pe
Philippines RP PH PHL 608 .ph
Pitcairn Islands PC PN PCN 612 .pn
Poland PL PL POL 616 .pl
Portugal PO PT PRT 620 .pt
Puerto Rico RQ PR PRI 630 .pr
Qatar QA QA QAT 634 .qa
Reunion RE RE REU 638 .re
Romania RO RO ROU 642 .ro
Russia RS RU RUS 643 .ru
Rwanda RW RW RWA 646 .rw
Saint Helena SH SH SHN 654 .sh
Saint Kitts
and Nevis SC KN KNA 659 .kn
Saint Lucia ST LC LCA 662 .lc
Saint Pierre
and Miquelon SB PM SPM 666 .pm
Saint Vincent and
the Grenadines VC VC VCT 670 .vc
Samoa WS WS WSM 882 .ws
San Marino SM SM SMR 674 .sm
Sao Tome and
Principe TP ST STP 678 .st
Saudi Arabia SA SA SAU 682 .sa
Senegal SG SN SEN 686 .sn
Serbia RB RS SRB 688 .rs
.yu remains in service until the end of 2006
Seychelles SE SC SYC 690 .sc
Sierra Leone SL SL SLE 694 .sl
Singapore SN SG SGP 702 .sg
Slovakia LO SK SVK 703 .sk
Slovenia SI SI SVN 705 .si
Solomon Islands BP SB SLB 090 .sb
Somalia SO SO SOM 706 .so
South Africa SF ZA ZAF 710 .za
South Georgia and
the Islands SX GS SGS 239 .gs
Spain SP ES ESP 724 .es
Spratly Islands PG - - -
Sri Lanka CE LK LKA 144 .lk
Sudan SU SD SDN 736 .sd
Suriname NS SR SUR 740 .sr
Svalbard SV SJ SJM 744 .sj
ISO includes Jan Mayen
Swaziland WZ SZ SWZ 748 .sz
Sweden SW SE SWE 752 .se
Switzerland SZ CH CHE 756 .ch
Syria SY SY SYR 760 .sy
Taiwan TW TW TWN 158 .tw
Tajikistan TI TJ TJK 762 .tj
Tanzania TZ TZ TZA 834 .tz
Thailand TH TH THA 764 .th
Togo TO TG TGO 768 .tg
Tokelau TL TK TKL 772 .tk
Tonga TN TO TON 776 .to
Trinidad and Tobago TD TT TTO 780 .tt
Tromelin Island TE - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Tunisia TS TN TUN 788 .tn
Turkey TU TR TUR 792 .tr
Turkmenistan TX TM TKM 795 .tm
Turks and Caicos IslandsTK TC TCA 796 .tc
Tuvalu TV TV TUV 798 .tv
Uganda UG UG UGA 800 .ug
Ukraine UP UA UKR 804 .ua
United Arab EmiratesAE AE ARE 784 .ae
United Kingdom UK GB GBR 826 .uk
United States US US USA 840 .us
Frunze (city; former name for Kyrgyzstan 42 54 N 74 36 E
Bishkek)
Funafuti (capital, atoll) Tuvalu 8 30 S 179 12 E
Fundy, Bay of Atlantic Ocean 45 00 N 66 00 W
Futuna Islands (Hoorn Wallis and Futuna 14 19 S 178 05 W
Islands/Iles de Horne)
Fyn (island) Denmark 55 20 N 10 25 E
Gaborone (capital) Botswana 24 45 S 25 55 E
Galapagos Islands Ecuador 0 00 N 90 30 W
(Archipielago de Colon)
Galicia (region) Poland, Ukraine 49 30 N 23 00 E
Galicia (region) Spain 42 45 N 8 10 E
Galilee (region) Israel 32 54 N 35 20 E
Galleons Passage Atlantic Ocean 11 00 N 60 55 W
Gambier Islands (Iles French Polynesia 23 09 S 134 58 W
Gambier)
Gaspar Strait Pacific Ocean 3 00 S 107 00 E
Gdansk (city; formerly Poland 54 23 N 18 40 E
Danzig)
Geneva (city) Switzerland 46 12 N 6 10 E
Genoa (city) Italy 44 25 N 8 57 E
George Town (capital) Cayman Islands 19 20 N 81 23 W
George Town (city) Malaysia 5 26 N 100 16 E
George Town (city) The Bahamas 23 30 N 75 46 W
Georgetown (capital) Guyana 6 48 N 58 10 W
Georgetown (city) The Gambia 13 30 N 14 47 W
German Democratic Republic Germany 52 00 N 13 00 E
(East Germany; former name
for eastern portion of
Germany)
German Southwest Africa Namibia 22 00 S 17 00 E
(former name for Namibia)
Germany, Federal Republic of Germany 51 00 N 9 00 E
Gibraltar (city, peninsula) Gibraltar 36 11 N 5 22 W
Gibraltar, Strait of Atlantic Ocean 35 57 N 5 36 W
Gidi Pass Egypt 30 13 N 33 09 E
Gilbert Islands Kiribati 1 25 N 173 00 E
Goa (state) India 15 20 N 74 00 E
Gobi (desert) China, Mongolia 42 30 N 107 00 E
Godthab (capital; also Nuuk) Greenland 64 11 N 51 44 W
Golan Heights (region) Syria 33 00 N 35 45 E
Gold Coast (former name for Ghana 8 00 N 2 00 W
Ghana)
Golfo San Jorge (gulf) Atlantic Ocean 46 00 S 66 00 W
Golfo San Matias (gulf) Atlantic Ocean 41 30 S 64 00 W
Good Hope, Cape of South Africa 34 24 S 18 30 E
Goteborg (city) Sweden 57 43 N 11 58 E
Gotland (island) Sweden 57 30 N 18 33 E
Gough Island Saint Helena 40 20 S 9 55 W
Graham Land (region) Antarctica 65 00 S 64 00 W
Gran Chaco (region) Argentina, Paraguay 24 00 S 60 00 W
Grand Bahama (island) The Bahamas 26 40 N 78 35 W
Grand Banks (fishing ground) Atlantic Ocean 47 06 N 55 48 W
Grand Cayman (island) Cayman Islands 19 20 N 81 20 W
Grand Turk (capital; also Turks and Caicos 21 28 N 71 08 W
Cockburn Town) Islands
Great Australian Bight Indian Ocean 35 00 S 130 00 E
Great Belt (strait; also Atlantic Ocean 55 30 N 11 00 E
Store Baelt)
Great Bitter Lake Egypt 30 20 N 32 23 E
Great Britain (island) United Kingdom 54 00 N 2 00 W
Great Channel Indian Ocean 6 25 N 94 20 E
Great Inagua (island) The Bahamas 21 00 N 73 20 W
Great Rift Valley Ethiopia, Kenya 0 30 N 36 00 E
Greater Sunda Islands Brunei, Indonesia, 2 00 S 110 00 E','859527b1d7ee66945b12513d1791d72b0021e11ec80df4592dbc8ba06e265139','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aedbc46b1111692ab40b7baa9efaa167f0d3ac6eeff5f81a18a92020b1a88f7d',2006,'US','United States','environment',1010,'Minor Outlying
Islands - UM UMI 581 .um
ISO includes Baker Island, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island,
Palmyra Atoll, Wake Island
Uruguay UY UY URY 858 .uy
Uzbekistan UZ UZ UZB 860 .uz
Vanuatu NH VU VUT 548 .vu
Venezuela VE VE VEN 862 .ve
Vietnam VM VN VNM 704 .vn
Virgin Islands VQ VI VIR 850 .vi
Virgin Islands (UK) - - - .vg
see British Virgin Islands
Virgin Islands (US) - - - .vi
see Virgin Islands
Wake Island WQ - - - -
ISO includes with the US Minor Outlying Islands
Wallis and Futuna WF WF WLF 876 .wf
West Bank WE PS PSE 275 .ps
ISO identifies as Occupied Palestinian Territory
Western Sahara WI EH ESH 732 .eh
Western Samoa - - - .ws
see Samoa
World - - - -
the Factbook uses the W data code from DIAM 65-18 Geopolitical
Data Elements and Related Features, Data Standard No. 3,
December 1994, published by the Defense Intelligence Agency
Yemen YM YE YEM 887 .ye
Zaire - - - -
see Democratic Republic of the Congo
Zambia ZA ZM ZMB 894 .zm
Zimbabwe ZI ZW ZWE 716 .zw
This page was last updated on 19 December, 2006
=====================================================================
Appendix E - Cross-Reference List of Hydrographic Data Codes
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft
4th Edition 1986, published by the International Hydrographic Bureau of
the International Hydrographic Organization
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd
Edition 1953, published by the International Hydrographic Organization
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958,
published by the Aeronautical Chart and Information Center (ACIC),
United States Air Force; note - ACIC is now part of the National
Imagery and Mapping Agency (NIMA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data
Standard No. 4, Defense Intelligence Agency Manual 65-18, December
1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes
similar to the Federal Information Processing Standards (FIPS) 10-4
country codes. The names and limits of the following oceans and seas
are not always directly comparable because of differences in the
customers, needs, and requirements of the individual organizations.
Even the number of principal water bodies varies from organization to
organization. Factbook users, for example, find the Atlantic Ocean and
Pacific Ocean entries useful, but none of the following standards
include those oceans in their entirety. Nor is there any provision for
combining codes or overcodes to aggregate water bodies. The recently
delimited Southern Ocean is not included.
Principal Oceans and Seas of the World
With Hydrographic Codes by Institution
IHO 23-4th IHO 23-3rd* ACIC M 49-1 DIAM 65-18
Arctic Ocean 9 17 A 5A
Atlantic Ocean - - - -
Baltic Sea 2 1 B26 7B
Eastern Mediterranean 3.1.2 28 B - 8E
Indian Ocean 5 45 F 6A
Mediterranean Sea 3.1 28 B11 -
North Atlantic Ocean 1 23 B 1A
North Pacific Ocean 7 57 D 3A
Pacific Ocean - - - -
South Atlantic Ocean 4 32 C 2A
South China and Eastern
Archipelagic Seas 6 49, 48 D18 plus 3U plus
others others
South Pacific Ocean 8 61 E 4A
Western Mediterranean 3.1.1 28 A - 8W
*The letters after the numbers are subdivisions, not footnotes.
This page was last updated on 19 December, 2006
=====================================================================
Appendix F - Cross-Reference List of Geographic Names
Name Entry in The Latitude Longitude
World Factbook (deg min) (deg min)
Abidjan (capital) Cote d''Ivoire 5 19 N 4 02 W
Abkhazia (region) Georgia 43 00 N 41 00 E
Abu Dhabi (capital) United Arab Emirates 24 28 N 54 22 E
Abu Musa (island) Iran 25 52 N 55 03 E
Abuja (capital) Nigeria 9 12 N 7 11 E
Abyssinia (former name for Ethiopia 8 00 N 38 00 E
Ethiopia)
Acapulco (city) Mexico 16 51 N 99 55 W
Accra (capital) Ghana 5 33 N 0 13 W
Adamstown (capital) Pitcairn Islands 25 04 S 130 05 W
Addis Ababa (capital) Ethiopia 9 02 N 38 42 E
Adelie Land (claimed by Antarctica 66 30 S 139 00 E
France; also Terre Adelie)
Aden (city) Yemen 12 46 N 45 01 E
Aden, Gulf of Indian Ocean 12 30 N 48 00 E
Admiralty Island United States 57 44 N 134 20 W
(Alaska)
Admiralty Islands Papua New Guinea 2 10 S 147 00 E
Adriatic Sea Atlantic Ocean 42 30 N 16 00 E
Adygey (region) Russia 44 30 N 40 10 E
Aegean Islands Greece 38 00 N 25 00 E
Aegean Sea Atlantic Ocean 38 30 N 25 00 E
Afars and Issas, French Djibouti 11 30 N 43 00 E
Territory of the (or FTAI;
former name for Djibouti)
Afghanestan (local name for Afghanistan 33 00 N 65 00 E
Afghanistan)
Agalega Islands Mauritius 10 25 S 56 40 E
Agana (city; former name for Guam 13 28 N 144 45 E
Hagatna)
Ajaccio (city) France (Corsica) 41 55 N 8 44 E
Ajaria (region) Georgia 41 45 N 42 10 E
Akmola (city; former name for Kazakhstan 51 10 N 71 30 E
Astana)
Aksai Chin (region) China (de facto), 35 00 N 79 00 E
India (claimed)
Al Arabiyah as Suudiyah Saudi Arabia 25 00 N 45 00 E
(local name for Saudi Arabia)
Al Bahrayn (local name for Bahrain 26 00 N 50 33 E
Bahrain)
Al Imarat al Arabiyah al United Arab Emirates 24 00 N 54 00 E
Muttahidah (local name for
the United Arab Emirates)
Al Iraq (local name for Iraq) Iraq 33 00 N 44 00 E
Al Jaza''ir (local name for Algeria 28 00 N 3 00 E
Algeria)
Al Kuwayt (local name for Kuwait 29 30 N 45 45 E
Kuwait)
Al Maghrib (local name for Morocco 32 00 N 5 00 W
Morocco)
Al Urdun (local name for Jordan 31 00 N 36 00 E
Jordan)
Al Yaman (local name for Yemen 15 00 N 48 00 E
Yemen)
Aland Islands Finland 60 15 N 20 00 E
Alaska (state) United States 65 00 N 153 00 W
Alaska, Gulf of Pacific Ocean 58 00 N 145 00 W
Alboran Sea Atlantic Ocean 36 00 N 2 30 W
Aldabra Islands (Groupe Seychelles 9 25 S 46 22 E
d''Aldabra)
Alderney (island) Guernsey 49 43 N 2 12 W
Aleutian Islands United States 52 00 N 176 00 W
(Alaska)
Alexander Archipelago (island United States 57 00 N 134 00 W
group) (Alaska)
Alexander Island Antarctica 71 00 S 70 00 W
Alexandretta (region; former Turkey 36 34 N 36 08 E
name for Iskenderun)
Alexandria (city) Egypt 31 12 N 29 54 E
Algiers (capital) Algeria 36 47 N 2 03 E
Alhucemas, Penon de (island Spain 35 13 N 3 53 W
group)
Alma-Ata (city; former name Kazakhstan 43 15 N 76 57 E
for Almaty)
Almaty (former capital) Kazakhstan 43 15 N 76 57 E
Alofi (capital) Niue 19 01 S 169 55 W
Alphonse Island Seychelles 7 01 S 52 45 E
Alsace (region) France 48 30 N 7 20 E
Amami Strait Pacific Ocean 28 40 N 129 30 E
Amindivi Islands (former name India 11 30 N 72 30 E
for Laccadive Islands)
Amirante Isles (island group; Seychelles 6 00 S 53 10 E
also Les Amirantes)
Amman (capital) Jordan 31 57 N 35 56 E
Amsterdam (capital) Netherlands 52 23 N 4 54 E
Amsterdam Island (Ile French Southern and 37 52 S 77 32 E
Amsterdam) Antarctic Lands
Amundsen Sea Southern Ocean 72 30 S 112 00 W
Amur River China, Russia 52 56 N 141 10 E
Amurskiy Liman (strait) Pacific Ocean 53 00 N 141 30 E
Anadyrskiy Zaliv (gulf) Pacific Ocean 64 00 N 177 00 E
Anatolia (region) Turkey 39 00 N 35 00 E
Andaman Islands India 12 00 N 92 45 E
Andaman Sea Indian Ocean 10 00 N 95 00 E
Andorra la Vella (capital) Andorra 42 30 N 1 30 E
Andros (island) Greece 37 45 N 24 42 E
Andros Island The Bahamas 24 26 N 77 57 W
Anegada Passage Atlantic Ocean 18 30 N 63 40 W
Angkor Wat (ruins) Cambodia 13 26 N 103 50 E
Anglo-Egyptian Sudan (former Sudan 15 00 N 30 00 E
name for Sudan)
Anjouan (island) Comoros 12 15 S 44 25 E
Ankara (capital) Turkey 39 56 N 32 52 E
Annobon (island) Equatorial Guinea 1 25 S 5 36 E
Antananarivo (capital) Madagascar 18 52 S 47 30 E
Antigua (island) Antigua and Barbuda 14 34 N 90 44 W
Antipodes Islands New Zealand 49 41 S 178 43 E
Antwerp (city) Belgium 51 13 N 4 25 E
Aomen (local Chinese short- Macau 22 10 N 113 33 E
form name for Macau)
Aozou Strip (region) Chad 22 00 N 18 00 E
Apia (capital) Samoa 13 50 S 171 45W
Aqaba, Gulf of Indian Ocean 29 00 N 34 30 E
Arab, Shatt al (river) Iran, Iraq 29 57 N 48 34 E
Arabian Sea Indian Ocean 15 00 N 65 00 E
Arafura Sea Pacific Ocean 9 00 S 133 00 E
Aral Sea Kazakhstan, 45 00 N 60 00 E','c8619e2b483c501c028bf9e97c3c85409359efbd3f42e84b8a79ad835b669c09','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('164e7b270c83ee9468c60fe1f648bcbd38879b1aa4fbdb062aeebd163103ea88',2006,'RS','Serbia','environment',1011,'Banda Sea Pacific Ocean 5 00 S 128 00 E
Bandar Seri Begawan (capital) Brunei 4 52 S 114 55 E
Bangka (island) Indonesia 2 30 S 106 00 E
Bangkok (capital) Thailand 13 45 N 100 31 E
Bangui (capital) Central African 4 22 N 18 35 E
Republic
Banjul (capital) The Gambia 13 28 N 16 39 W
Banks Island Australia 10 12 S 142 16 E
Banks Island Canada 75 15 N 121 30 W
Banks Islands (Iles Banks) Vanuatu 14 00 S 167 30 E
Barbuda (island) Antigua and Barbuda 17 38 N 61 48 W
Barcelona (city) Spain 41 25 N 2 13 E
Barents Sea Arctic Ocean 74 00 N 36 00 E
Barranquilla (city) Colombia 10 59 N 74 48 W
Bashi Channel Pacific Ocean 22 00 N 121 00 E
Basilan Strait Pacific Ocean 6 49 N 122 05 E
Basque Provinces Spain 43 00 N 2 30 W
Bass Strait Pacific Ocean 39 20 S 145 30 E
Basse-Terre (capital) Guadeloupe 16 00 N 61 44 W
Basseterre (capital) Saint Kitts and 17 18 N 62 43 W
Nevis
Bastia (city) France (Corsica) 42 42 N 9 27 E
Basutoland (former name for Lesotho 29 30 S 28 30 E
Lesotho)
Batan Islands Philippines 20 30 N 121 50 E
Bavaria (region; also Bayern) Germany 48 30 N 11 30 E
Beagle Channel Atlantic Ocean 54 53 S 68 10 W
Bear Island (see Bjornoya) Svalbard 74 26 N 19 05 E
Beaufort Sea Arctic Ocean 73 00 N 140 00 W
Bechuanaland (former name for Botswana 22 00 S 24 00 E
Botswana)
Beijing (capital) China 39 56 N 116 24 E
Beirut (capital) Lebanon 33 53 N 35 30 E
Bekaa Valley Lebanon 34 00 N 36 05 E
Belau (Palau Islands) Palau 7 30 N 134 30 E
Belep Islands (Iles Belep) New Caledonia 19 45 S 163 40 E
Belfast (city) United Kingdom 54 36 N 5 55 W
Belgian Congo (former name Democratic Republic 0 00 N 25 00 E
for Democratic Republic of of the Congo
the Congo)
Belgie, Belgique (local name Belgium 50 50 N 4 00 E
for Belgium)
Belgrade (capital) Serbia 44 50 N 20 30 E
Belize City Belize 17 30 N 88 12 W
Belle Isle, Strait of Atlantic Ocean 51 35 N 56 30 W
Bellingshausen Sea Southern Ocean 71 00 S 85 00 W
Belmopan (capital) Belize 17 15 N 88 46 W
Belorussia (former name for Belarus 53 00 N 28 00 E
Belarus)
Benadir (region; former name Somalia 4 00 N 46 00 E
of Italian Somaliland)
Bengal, Bay of Indian Ocean 15 00 N 90 00 E
Berau, Gulf of Pacific Ocean 2 30 S 132 30 E
Bering Island Russia 55 00 N 166 30 E
Bering Sea Pacific Ocean 60 00 N 175 00 W
Bering Strait Pacific Ocean 65 30 N 169 00 W
Berkner Island Antarctica 79 30 S 49 30 W
Berlin (capital) Germany 52 31 N 13 24 E
Berlin, East (former name for Germany 52 30 N 13 33 E
eastern sector of Berlin)
Berlin, West (former name for Germany 52 30 N 13 20 E
western sector of Berlin)
Bern (capital) Switzerland 46 57 N 7 26 E
Bessarabia (region) Moldova, Romania, 47 00 N 28 30 E','7048134396ed4cc4f54b0a85ac21a09fe29ea380ab1177ee23a6770088112ddd','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1513d52d9272d3817188ac750b6744163dc37a82a30ea6275d700b22eb76860f',2006,'MY','Malaysia','environment',1012,'Bornholm (island) Denmark 55 10 N 15 00 E
Bosna i Hercegovina (local Bosnia and 44 00 N 18 00 E
name for Bosnia and Herzegovina
Herzegovina)
Bosnia (political region) Bosnia and 44 00 N 18 00 E
Herzegovina
Bosporus (strait) Atlantic Ocean 41 00 N 29 00 E
Bothnia, Gulf of Atlantic Ocean 63 00 N 20 00 E
Bougainville (island) Papua New Guinea 6 00 S 155 00 E
Bougainville Strait Pacific Ocean 6 40 S 156 10 E
Bounty Islands New Zealand 47 43 S 174 00 E
Bourbon Island (former name Reunion 21 06 S 55 36 E
of Reunion)
Brasilia (capital) Brazil 15 47 S 47 55 W
Bratislava (capital) Slovakia 48 09 N 17 07 E
Brazzaville (capital) Republic of the 4 16 S 15 17 E
Green Islands Papua New Guinea 4 30 S 154 10 E
Greenland Sea Arctic Ocean 79 00 N 5 00 W
Grenadines, Northern (island Saint Vincent and 13 15 N 61 12 W
group) the Grenadines
Grenadines, Southern (island Grenada 12 07 N 61 40 W
group)
Grytviken (town; on South South Georgia and 54 15 S 36 45 W
Georgia) the South Sandwich
Islands
Guadalahara (city) Mexico 20 40 N 103 24 W
Guadalcanal (island) Solomon Islands 9 32 S 160 12 E
Guadalupe, Isla de (island) Mexico 29 11 N 118 17 W
Guangzhou (city; also Canton) China 23 09 N 113 21 E
Guantanamo Bay (US Naval Cuba 20 00 N 75 08 W
Base)
Guatemala (capital) Guatemala 14 38 N 90 31 W
Guine-Bissau (local name for Guinea-Bissau 12 00 N 15 00 W
Guinea-Bissau)
Guinea Ecuatorial (local name Equatorial Guinea 2 00 N 10 00 E
for Equatorial Guinea)
Guinea, Gulf of Atlantic Ocean 3 00 N 2 30 E
Guinee (local name for Guinea 11 00 N 10 00 W
Guinea)
Guyane Francaise (local name French Guiana 4 00 N 53 00 W
for French Guiana)
Ha''apai Group (island group) Tonga 19 42 S 174 29 W
Habomai Islands Russia (de facto) 43 30 N 146 10 E
Hadhramaut (region) Yemen 15 00 N 50 00 E
Hagatna (capital; formerly Guam 13 28 N 144 45 E
Agana)
Hague, The (seat of Netherlands 52 05 N 4 18 E','c19e385878289ef5df430797114d3502f382aef40ec82575661e7205a80d147b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3dad39ef1aa319c6ad4f208e0fe297284f0dcf07f3667235f97188e018a95ff',2006,'CG','Congo','environment',1013,'Bridgetown (capital) Barbados 13 06 N 59 37 W
Brisbane (city) Australia 27 28 S 153 02 E
Bristol Bay Pacific Ocean 57 00 N 160 00 W
Bristol Channel Atlantic Ocean 51 18 N 3 30 W
Britain (see Great Britain) United Kingdom 54 00 N 2 00 W
British Bechuanaland (region; South Africa 27 30 S 23 30 E
former name for northwest
South Africa)
British Central African Malawi 13 30 S 34 00 E
Protectorate (former name of
Nyasaland)
British East Africa (former Kenya, Tanzania, 1 00 N 38 00 E
name for British possessions Uganda
in eastern Africa)
British Guiana (former name Guyana 5 00 N 59 00 W
for Guyana)
British Honduras (former name Belize 17 15 N 88 45 W
for Belize)
British Solomon Islands Solomon Islands 8 00 S 159 00 E
(former name for Solomon
Islands)
British Somaliland (former Somalia 10 00 N 49 00 E
name for northern Somalia)
Brussels (capital) Belgium 50 50 N 4 20 E
Bubiyan (island) Kuwait 29 47 N 48 10 E
Bucharest (capital) Romania 44 26 N 26 06 E
Budapest (capital) Hungary 47 30 N 19 05 E
Buenos Aires (capital) Argentina 34 36 S 58 27 W
Bujumbura (capital) Burundi 3 23 S 29 22 E
Bukovina (region) Romania, Ukraine 48 00 N 26 00 E
Byelarus (local name for Belarus 53 00 N 28 00 E
Belarus)
Byelorussia (former name for Belarus 53 00 N 28 00 E
Belarus)
Cabinda (province) Angola 5 33 S 12 12 E
Cabo Verde (local name for Cape Verde 16 00 N 24 00 W
Cape Verde)
Cabot Strait Atlantic Ocean 47 20 N 59 30 W
Caicos Islands Turks and Caicos 21 56 N 71 58 W
Islands
Cairo (capital) Egypt 30 03 N 31 15 E
Calcutta (city) India 22 32 N 88 21 E
Calgary (city) Canada 51 02 N 114 04 W
California, Gulf of Pacific Ocean 28 00 N 112 00 W
Cameroun (local name for Cameroon 6 00 N 12 00 E
Cameroon)
Campbell Island New Zealand 52 33 S 169 09 E
Campeche, Bay of Atlantic Ocean 20 00 N 94 00 W
Canal Zone (former name for Panama 9 00 N 79 45 W
US possessions in Panama)
Canarias Sea Atlantic Ocean 28 00 N 16 00 W
Canary Islands Spain 28 00 N 15 30 W
Canberra (capital) Australia 35 17 S 149 08 E
Cancun (city) Mexico 21 10 N 86 50 W
Canton (city; now Guangzhou) China 23 06 N 113 16 E
Canton Island (Kanton Island) Kiribati 2 49 S 171 40 W
Cape Juby (region; former Morocco 27 53 N 12 58 W
name for Southern Morocco)
Cape Province (region; former South Africa 31 30 S 22 30 E
name for Northern, Western,
and Eastern Cape Provinces of
South Africa)
Cape Town (legislative South Africa 33 57 S 18 25 E
capital)
Cape of Good Hope (cape; also South Africa 34 15 S 18 20 E
alternate name for Cape
Province of South Africa)
Caracas (capital) Venezuela 10 30 N 66 56 W
Cargados Carajos Shoals Mauritius 16 25 S 59 38 E
Caribbean Sea Atlantic Ocean 15 00 N 73 00 W
Caroline Islands Federated States of 7 30 N 148 00 E
Micronesia, Palau
Carpatho-Ukraine (region; Ukraine 48 22 N 23 32 E
former name for Zakarpats''ka
oblast'')
Carpentaria, Gulf of Pacific Ocean 14 00 S 139 00 E
Casablanca (city) Morocco 33 35 N 7 34 W
Castries (capital) Saint Lucia 14 01 N 61 00 W
Catalonia (region) Spain 42 00 N 2 00 E
Cato Island Australia 23 15 S 155 32 E
Caucasus (region) Russia 42 00 N 45 00 E
Cayenne (capital) French Guiana 4 56 N 52 20 W
Celebes (island) Indonesia 2 00 S 121 00 E
Celebes Sea Pacific Ocean 3 00 N 122 00 E
Celtic Sea Atlantic Ocean 51 00 N 6 30 W
Central African Empire Central African 7 00 N 21 00 E
(former name for Central Republic
African Republic)
Ceram (Seram) Sea Pacific Ocean 2 30 S 129 30 E
Ceska Republika (local name Czech Republic 49 45 N 15 30 E
for Czech Republic)
Ceskoslovensko (former local Czech Republic, 49 00 N 17 30 E
name for Czechoslovakia) Slovakia
Cetinje (capital city) Montenegro 42 24 N 18 55 E
Ceuta (city) Spain 35 53 N 5 19 W
Ceylon (former name for Sri Sri Lanka 7 00 N 81 00 E
Lanka)
Chafarinas, Islas (island) Spain 35 12 N 2 26 W
Chagos Archipelago (Oil British Indian Ocean 6 00 S 71 30 E
Islands) Territory
Challenger Deep (Mariana Pacific Ocean 11 22 N 142 36 E
Trench)
Channel Islands Guernsey, Jersey 49 20 N 2 20 W
Charlotte Amalie (capital) Virgin Islands 18 21 N 64 56 W
Chatham Islands New Zealand 44 00 S 176 30 W
Chechnya (region; also Russia 43 15 N 45 40 E
Chechnia)
Cheju Strait Pacific Ocean 34 00 N 126 30 E
Cheju-do (island) Korea, South 33 20 N 126 30 E
Chengdu (city) China 30 43 N 104 04 E
Chennai (city; also Madras) India 13 04 N 80 16 E
Chesterfield Islands (Iles New Caledonia 19 52 S 158 15 E
Chesterfield)
Chihli, Gulf of (see Bo Hai) Pacific Ocean 38 30 N 120 00 E
Chiloe (island) Chile 42 50 S 74 00 W
China, People''s Republic of China 35 00 N 105 00 E
China, Republic of Taiwan 23 30 N 121 00 E
Chisinau (capital; also Moldova 47 00 N 28 50 E
Kishinev)
Choiseul (island) Solomon Islands 7 05 S 121 00 E
Choson (local name for North North Korea 40 00 N 127 00 E
Korea)
Christmas Island (Indian Australia 10 25 S 105 39 E
Ocean)
Christmas Island (Pacific Kiribati 1 52 N 157 20 W
Ocean; also Kiritimati)
Chukchi Sea Arctic Ocean 69 00 N 171 00 W
Chuuk Islands (Truk Islands) Federated States of 7 25 N 151 47 W
Micronesia
Cilicia (region) Turkey 36 50 N 34 30 E
Ciskei (enclave) South Africa 33 00 S 27 00 E
Citta del Vaticano (local Holy See 41 54 N 12 27 E
name for Vatican City)
Cochin China (region) Vietnam 11 00 N 107 00 E
Coco, Isla del (island) Costa Rica 5 32 N 87 04 W
Cocos Islands Cocos (Keeling) 12 30 S 96 50 E
Islands
Colombo (capital) Sri Lanka 6 56 N 79 51 E
Colon, Archipielago de Ecuador 0 00 N 90 30 W
(Galapagos Islands)
Commander Islands Russia 55 00 N 167 00 E
(Komandorskiye Ostrova)
Comores (local name for Comoros 12 10 S 44 15 E
Comoros)
Con Son (islands) Vietnam 8 43 N 106 36 E
Conakry (capital) Guinea 9 31 N 13 43 W
Confederatio Helvetica (local Switzerland 47 00 N 8 00 E
name for Switzerland)
Congo (Brazzaville) (former Republic of the 1 00 S 15 00 E
name for Republic of the Congo
Congo)
Congo (Leopoldville) (former Democratic Republic 0 00 N 25 00 E
name for the Democratic of the Congo
Republic of the Congo)
Constantinople (city; former Turkey 41 01 N 28 58 E
name for Istanbul)
Cook Strait Pacific Ocean 41 15 S 174 30 E
Copenhagen (capital) Denmark 55 40 N 12 35 E
Coral Sea Pacific Ocean 15 00 S 150 00 E
Corfu (island) Greece 39 40 N 19 45 E
Corinth (region) Greece 37 56 N 22 56 E
Corisco (island) Equatorial Guinea 0 55 N 9 19 E
Corn Islands (Islas del Maiz) Nicaragua 12 15 N 83 00 W
Corocoro Island Guyana, Venezuela 3 38 N 66 50 W
Corsica (island; also Corse) France 42 00 N 9 00 E
Cosmoledo Group (island Seychelles 9 43 S 47 35 E
group; also Atoll de
Cosmoledo)
Cotonou (former capital) Benin 6 21 N 2 26 E
Cotopaxi (volcano) Ecuador 0 39 S 78 26 W
Courantyne River Guyana, Suriname 5 57 N 57 06 W
Cozumel (island) Mexico 20 30 N 86 55 W
Crete (island) Greece 35 15 N 24 45 E
Crimea (region) Ukraine 45 00 N 34 00 E
Crimean Peninsula Ukraine 45 00 N 34 00 E
Crooked Island Passage Atlantic Ocean 22 55 N 74 35 W
Crozet Islands (Iles Crozet) French Southern and 46 30 S 51 00 E
Antarctic Lands
Cyclades (island group) Greece 37 00 N 25 10 E
Cyrenaica (region) Libya 31 00 N 22 00 E
Czechoslovakia (former name Czech Republic, 49 00 N 18 00 E
for the entity that Slovakia
subsequently split into the
Czech Republic and Slovakia)
D''Entrecasteaux Islands Papua New Guinea 9 30 S 150 40 E
Dagestan (region) Russia 43 00 N 47 00 E
Dahomey (former name for Benin 9 30 N 2 15 E
Benin)
Daito Islands Japan 43 00 N 17 00 E
Dakar (capital) Senegal 14 40 N 17 26 W
Dalmatia (region) Croatia 43 00 N 17 00 E
Daman (city; also Damao) India 20 10 N 73 00 E
Damascus (capital) Syria 33 30 N 36 18 E
Danger Islands (see Pukapuka Cook Islands 10 53 S 165 49 W
Atoll)
Danish Straits Atlantic Ocean 58 00 N 11 00 E
Danish West Indies (former Virgin Islands 18 20 N 64 50 W
name for the Virgin Islands)
Danmark (local name) Denmark 56 00 N 10 00 E
Danzig (city; former name for Poland 54 23 N 18 40 E
Gdansk)
Dao Bach Long Vi (island) Vietnam 20 08 N 107 44 E
Dar es Salaam (capital) Tanzania 6 48 S 39 17 E
Dardanelles (strait) Atlantic Ocean 40 15 N 26 25 E
Davis Strait Atlantic Ocean 67 00 N 57 00 W
Dead Sea Israel, Jordan, West 32 30 N 35 30 E
Bank
Deception Island Antarctica 62 56 S 60 34 W
Denmark Strait Atlantic Ocean 67 00 N 24 00 W
Desolation Islands (Isles French Southern and 49 30 S 69 30 E
Kerguelen) Antarctic Lands
Deutschland (local name for Germany 51 00 N 9 00 E
Germany)
Devils Island (Ile du Diable) French Guiana 5 17 N 52 35 W
Devon Island Canada 76 00 N 87 00 W
Dhaka (capital) Bangladesh 23 43 N 90 25 E
Dhivehi Raajje (local name Maldives 3 15 N 73 00 E
for Maldives)
Dhofar (region) Oman 17 00 N 54 10 E
Diego Garcia (island) British Indian Ocean 7 20 S 72 25 E
Territory
Diego Ramirez (islands) Chile 56 30 S 68 43 W
Dili (capital) East Timor 8 35 S 125 36 E
Dilmun (former name for Bahrain 7 00 N 81 00 E
Bahrain)
Diomede Islands Russia (Big 65 47 N 169 00 W
Diomede), United
States (Little
Diomede)
Diu (region) India 20 42 N 70 59 E
Djibouti (capital) Djibouti 11 30 N 43 15 E
Dnieper (river) Belarus, Russia, 46 30 N 32 18 E
Ukraine (Dnyapro,
Dnepr, Dnipro)
Dniester (river) Moldova, Ukraine 46 18 N 30 17 E
(Nistru, Dnister)
Dobruja (region) Bulgaria, Romania 43 30 N 28 00 E
Dodecanese (island group) Greece 36 00 N 27 05 E
Dodoma (city) Tanzania 6 11 S 35 45 E
Doha (capital) Qatar 25 17 N 51 32 E
Donets Basin Russia, Ukraine 48 15 N 38 30 E
Douala (city) Cameroon 4 03 N 9 42 E
Douglas (capital) Man, Isle of 54 09 N 4 28 W
Dover, Strait of Atlantic Ocean 51 00 N 1 30 E
Drake Passage Atlantic Ocean, 60 00 S 60 00 W
Southern Ocean
Druk Yul (local name for Bhutan 27 30 N 90 30 E
Bhutan)
Dubai, Dubayy (city) United Arab Emirates 25 18 N 55 18 E
Dublin (capital) Ireland 53 20 N 6 15 W
Duesseldorf (city) Germany 51 13 N 6 47 E
Durban (city) South Africa 29 51 S 31 02 E
Dushanbe (capital) Tajikistan 38 35 N 68 48 E
Dutch Antilles (former name Netherlands Antilles 12 10 N 68 30 W
for the Netherlands Antilles)
Dutch East Indies (former Indonesia 5 00 S 120 00 E
name for Indonesia)
Dutch Guiana (former name for Suriname 4 00 N 56 00 W
Suriname)
Dutch West Indies (former Netherlands Antilles 12 10 N 68 30 W
name for the Netherlands
Antilles)
Dzungarian Gate (valley) China, Kazakhstan 45 25 N 82 25 E
East China Sea Pacific Ocean 30 00 N 126 00 E
East Frisian Islands Germany 53 44 N 7 25 E
East Germany (German Germany 52 00 N 13 00 E
Democratic Republic; former
name for eastern portion of
Germany)
East Korea Strait (Eastern Pacific Ocean 34 00 N 129 00 E
Channel or Tsushima Strait)
East Pakistan (former name Bangladesh 24 00 N 90 00 E
for Bangladesh)
East Siberian Sea Arctic Ocean 74 00 N 166 00 E
Easter Island (Isla de Chile 27 07 S 109 22 W
Pascua)
Eastern Channel (East Korea Pacific Ocean 34 00 N 129 00 E
Strait or Tsushima Strait)
Eastern Samoa (former name American Samoa 14 20 S 170 00 W
for American Samoa)
Edinburgh (city) United Kingdom 55 57 N 3 11 W
Eesti (local name for Estonia 59 00 N 26 00 E
Estonia)
Eire (local name for Ireland) Ireland 53 00 N 8 00 W
Elba (island) Italy 42 46 N 10 17 E
Elemi Triangle (region) Ethiopia (claimed), 5 00 N 35 30 E
Kenya (de facto),
Sudan (claimed)
Ellada, Ellas (local name for Greece 39 00 N 22 00 E
Greece)
Ellef Ringnes Island Canada 78 00 N 103 00 W
Ellesmere Island Canada 81 00 N 80 00 W
Ellice Islands Tuvalu 8 00 S 178 00 E
Ellsworth Land (region) Antarctica 75 00 S 92 00 W
Elobey, Islas de (island Equatorial Guinea 0 59 N 9 33 E
group)
Enderbury Island Kiribati 3 08 S 171 05 W
Enewetak Atoll (Eniwetok Marshall Islands 11 30 N 162 15 E
Atoll)
England (region) United Kingdom 52 30 N 1 30 W
English Channel Atlantic Ocean 50 20 N 1 00 W
Eniwetok Atoll (see Enewetak Marshall Islands 11 30 N 162 15 E
Atoll)
Eolie, Isole (island group) Italy 38 30 N 15 00 E
Epirus, Northern (region) Albania, Greece 40 00 N 20 30 E
Episkopi Cantonment (capital) Akrotiri, Dhekelia 34 40 N 32 51 E
Ertra (local name for Eritrea 15 00 N 39 00 E
Eritrea)
Espana Spain 40 00 N 4 00 W
Essequibo (region; claimed by Guyana 6 59 N 58 23 W
Venezuela)
Etorofu (island; also Iturup) Russia (de facto) 44 55 N 147 40 E
Farquhar Group (island group; Seychelles 10 10 S 51 10 E
also Atoll de Farquhar)
Fergana Valley Kyrgyzstan, 41 00 N 72 00 E
Tajikistan,','0da61932e03ab41960413d773ddc4abd12e801c3a353c29fc93487700e36d5ff','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

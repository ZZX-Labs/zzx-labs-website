SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44d7f8cebd931dede45adf98b8dae004ddc99571c998f65377e3508407d1556a',2006,'EH','Western Sahara','transportation',35,'This category includes the entries dealing with the means for movement
of people and goods.
Transportation - note
This entry includes miscellaneous transportation information of
significance not included elsewhere.
UTC (Coordinated Universal Time)
See entry for Coordinated Universal Time.
Unemployment rate
This entry contains the percent of the labor force that is without
jobs. Substantial underemployment might be noted.
Waterways
This entry gives the total length of navigable rivers, canals, and
other inland bodies of water.
Weights and Measures
This information is presented in Appendix G: Weights and Measures and
includes mathematical notations (mathematical powers and names), metric
interrelationships (prefix; symbol; length, weight, or capacity; area;
volume), and standard conversion factors.
Years
All year references are for the calendar year (CY) unless indicated as
fiscal year (FY). The calendar year is an accounting period of 12
months from 1 January to 31 December. The fiscal year is an accounting
period of 12 months other than 1 January to 31 December.
Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates.
This page was last updated on 19 December 2006
=====================================================================
A Brief History of Basic Intelligence and The World Factbook
The Intelligence Cycle is the process by which information is
acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source, data that
may be fragmentary, contradictory, unreliable, ambiguous, deceptive,
or wrong. Intelligence is information that has been collected,
integrated, evaluated, analyzed, and interpreted. Finished
intelligence is the final product of the Intelligence Cycle ready to
be delivered to the policymaker.
The three types of finished intelligence are: basic, current,
and estimative. Basic intelligence provides the fundamental and
factual reference material on a country or issue. Current
intelligence reports on new developments. Estimative intelligence
judges probable outcomes. The three are mutually supportive: basic
intelligence is the foundation on which the other two are
constructed; current intelligence continually updates the inventory
of knowledge; and estimative intelligence revises overall
interpretations of country and issue prospects for guidance of basic
and current intelligence. The World Factbook, The President''s Daily
Brief, and the National Intelligence Estimates are examples of the
three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington but only since World
War II have they been coordinated on a government-wide basis. Three
programs have highlighted the development of coordinated basic
intelligence since that time: (1) the Joint Army Navy Intelligence
Studies (JANIS), (2) the National Intelligence Survey (NIS), and (3)
The World Factbook.
During World War II, intelligence consumers realized that the
production of basic intelligence by different components of the US
Government resulted in a great duplication of effort and conflicting
information. The Japanese attack on Pearl Harbor in 1941 brought
home to leaders in Congress and the executive branch the need for
integrating departmental reports to national policymakers. Detailed
and coordinated information was needed not only on such major powers
as Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and Marines
had to launch amphibious operations against many islands about which
information was unconfirmed or nonexistent. Intelligence authorities
resolved that the United States should never again be caught
unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train (Office
of Naval Intelligence - ONI), and Gen. William J. Donovan (Director
of the Office of Strategic Services - OSS) decided that a joint
effort should be initiated. A steering committee was appointed on 27
April 1943 that recommended the formation of a Joint Intelligence
Study Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS was the
first interdepartmental basic intelligence program to fulfill the
needs of the US Government for an authoritative and coordinated
appraisal of strategic basic intelligence. Between April 1943 and
July 1947, the board published 34 JANIS studies. JANIS performed
well in the war effort, and numerous letters of commendation were
received, including a statement from Adm. Forrest Sherman, Chief of
Staff, Pacific Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based planners."
The need for more comprehensive basic intelligence in the
postwar world was well expressed in 1946 by George S. Pettee, a
noted author on national security. He wrote in The Future of
American Secret Intelligence (Infantry Journal Press, 1946, page 46)
that world leadership in peace requires even more elaborate
intelligence than in war. "The conduct of peace involves all
countries, all human activities - not just the enemy and his war
production."
The Central Intelligence Agency was established on 26 July 1947
and officially began operating on 18 September 1947. Effective 1
October 1947, the Director of Central Intelligence assumed
operational responsibility for JANIS. On 13 January 1948, the
National Security Council issued Intelligence Directive (NSCID) No.
3, which authorized the National Intelligence Survey (NIS) program
as a peacetime replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced, government agencies
had to develop more comprehensive gazetteers and better maps. The US
Board on Geographic Names (BGN) compiled the names; the Department
of the Interior produced the gazetteers; and CIA produced the maps.
The Hoover Commission''s Clark Committee, set up in 1954 to
study the structure and administration of the CIA, reported to
Congress in 1955 that: "The National Intelligence Survey is an
invaluable publication which provides the essential elements of
basic intelligence on all areas of the world. There will always be a
continuing requirement for keeping the Survey up-to-date." The
Factbook was created as an annual summary and update to the
encyclopedic NIS studies. The first classified Factbook was
published in August 1962, and the first unclassified version was
published in June 1971. The NIS program was terminated in 1973
except for the Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with sales
through the US Government Printing Office (GPO). The Factbook was
first made available on the Internet in June 1997. The year 2006
marks the 59th anniversary of the establishment of the Central
Intelligence Agency and the 63nd year of continuous basic
intelligence support to the US Government by The World Factbook and
its two predecessor programs.
This page was last updated on 28 November, 2006
=====================================================================
Contributors and Copyright Information
The World Factbook is prepared by the Central Intelligence Agency
for the use of US Government officials, and the style, format,
coverage, and content are designed to meet their specific
requirements. Information is provided by Antarctic Information
Program (National Science Foundation), Armed Forces Medical
Intelligence Center (Department of Defense), Bureau of the Census
(Department of Commerce), Bureau of Labor Statistics (Department of
Labor), Central Intelligence Agency, Council of Managers of National
Antarctic Programs, Defense Intelligence Agency (Department of
Defense), Department of Energy, Department of State, Fish and
Wildlife Service (Department of the Interior), Maritime
Administration (Department of Transportation), National
Geospatial-Intelligence Agency (Department of Defense), Naval
Facilities Engineering Command (Department of Defense), Office of
Insular Affairs (Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on Geographic Names
(Department of the Interior), US Transportation Command (Department
of Defense), Oil & Gas Journal, and other public and private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA).
The official seal of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50 U.S.C. section
403m). Misuse of the official seal of the CIA could result in civil
and criminal penalties.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Hours: Monday-Friday 8:00 AM-4:30 PM Eastern Standard Time
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
=====================================================================
Purchasing Information
The Central Intelligence Agency (CIA) publishes The World Factbook
in printed and Internet versions. US Government officials may obtain
information about availability of the Factbook from their
organizations or through liaison channels to the CIA. Other users
may obtain sales information about printed copies from the following:
Superintendent of Documents
P. O. Box 371954
Pittsburgh, PA 15250-7954
Hours: Monday-Friday 7:30 AM-9:00 PM Eastern Standard Time (EST)
Telephone: [1] (202) 512-1800; toll free: [1] (866) 512-1800
FAX: [1] (202) 512-2104
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Hours: Monday-Friday 8:00 AM-6:00 PM Eastern Standard Time (EST)
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The World Factbook can be accessed on the Internet at:
http://www.cia.gov/cia/publications/factbook/index.html
This page was last updated on 23 March, 2006
=====================================================================
Frequently Asked Questions (FAQs)
The World Factbook staff thanks you for your comments, suggestions,
updates, kudos, and corrections over the past years. The willingness
of readers from around the world to share their observations and
specialized knowledge is very helpful as we try to produce the best
possible publications. Please feel free to continue to write and
e-mail e-mail us. When submitting corrections or updates to the
Factbook, please include your source(s) of information. At least two
Factbook staffers review every submitted item. The sheer volume of
correspondence precludes detailed personal replies, but we sincerely
appreciate your time and interest in the Factbook. If you include
your e-mail address we will at least acknowledge your note. Thank
you again.
Answers to many frequently asked questions (FAQs) are explained in
the Notes and Definitions section in The World Factbook. Please
review this section to see if your question is already answered
there. In addition, we have compiled the following list of FAQs to
answer other common questions. Select from the following categories
to narrow your search:
General','3bec613dba7feb83e084f3e674dcbad8fe6807839dc5c67d86c141db43e91662','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

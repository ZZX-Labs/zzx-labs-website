SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e855e7fe767fb562339eda66b891c168711d5267aa9440b3cf289c3eda6c7868',2006,'GL','Greenland','terrorism',92,'Geography Djibouti
Location:
Eastern Africa, bordering the Gulf of Aden and the Red Sea, between
Eritrea and Somalia
Geographic coordinates:
11 30 N, 43 00 E
Map references:
Africa
Area:
total: 23,000 sq km
land: 22,980 sq km
water: 20 sq km
Area - comparative:
slightly smaller than Massachusetts
Land boundaries:
total: 516 km
border countries: Eritrea 109 km, Ethiopia 349 km, Somalia 58 km
Coastline:
314 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate:
desert; torrid, dry
Terrain:
coastal plain and plateau separated by central mountains
Elevation extremes:
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources:
geothermal areas, gold, clay, granite, limestone, marble, salt,
diatomite, gypsum, pumice, petroleum
Land use:
arable land: 0.04%
permanent crops: 0%
other: 99.96% (2005)
Irrigated land:
10 sq km (2003)
Natural hazards:
earthquakes; droughts; occasional cyclonic disturbances from the
Indian Ocean bring heavy rains and flash floods
Environment - current issues:
inadequate supplies of potable water; limited arable land;
desertification; endangered species
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Geography - note:
strategic location near world''s busiest shipping lanes and close to
Arabian oilfields; terminus of rail traffic into Ethiopia; mostly
wasteland; Lac Assal (Lake Assal) is the lowest point in Africa
People Djibouti
Population:
486,530 (July 2006 est.)
Age structure:
0-14 years: 43.3% (male 105,760/female 105,068)
15-64 years: 53.3% (male 135,119/female 124,367)
65 years and over: 3.3% (male 8,183/female 8,033) (2006 est.)
Median age:
total: 18.2 years
male: 18.7 years
female: 17.7 years (2006 est.)
Population growth rate:
2.02% (2006 est.)
Birth rate:
39.53 births/1,000 population (2006 est.)
Death rate:
19.31 deaths/1,000 population (2006 est.)
Net migration rate:
0 migrant(s)/1,000 population (2006 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 1.02 male(s)/female
total population: 1.05 male(s)/female (2006 est.)
Infant mortality rate:
total: 102.44 deaths/1,000 live births
male: 110.07 deaths/1,000 live births
female: 94.58 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 43.17 years
male: 41.86 years
female: 44.52 years (2006 est.)
Total fertility rate:
5.31 children born/woman (2006 est.)
HIV/AIDS - adult prevalence rate:
2.9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS:
9,100 (2003 est.)
HIV/AIDS - deaths:
690 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A and E, and typhoid fever
vectorborne disease: malaria (2005)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups:
Somali 60%, Afar 35%, French, Arab, Ethiopian, and Italian 5%
Religions:
Muslim 94%, Christian 6%
Languages:
French (official), Arabic (official), Somali, Afar
Literacy:
definition: age 15 and over can read and write
total population: 67.9%
male: 78%
female: 58.4% (2003 est.)
Government Djibouti
Country name:
conventional long form: Republic of Djibouti
conventional short form: Djibouti
local long form: Republique de Djibouti/Jumhuriyat Jibuti
local short form: Djibouti/Jibuti
former: French Territory of the Afars and Issas, French Somaliland
Government type:
republic
Capital:
name: Djibouti
geographic coordinates: 11 30 N, 43 15 E
time difference: UTC+3 (8 hours ahead of Washington, DC during
Standard Time)
Administrative divisions:
6 districts (cercles, singular - cercle); Ali Sabieh, Arta, Dikhil,
Djibouti, Obock, Tadjourah
Independence:
27 June 1977 (from France)
National holiday:
Independence Day, 27 June (1977)
Constitution:
multiparty constitution approved by referendum 4 September 1992
Legal system:
based on French civil law system, traditional practices, and
Islamic law
Suffrage:
18 years of age; universal adult
Executive branch:
chief of state: President Ismail Omar GUELLEH (since 8 May 1999)
head of government: Prime Minister Mohamed Dileita DILEITA (since 4
March 2001)
cabinet: Council of Ministers responsible to the president
elections: president elected by popular vote for a six-year term
(eligible for a second term); election last held 8 April 2005 (next
to be held by April 2011); prime minister appointed by the president
election results: Ismail Omar GUELLEH reelected president; percent
of vote - Ismail Omar GUELLEH 100%
Legislative branch:
unicameral Chamber of Deputies or Chambre des Deputes (65 seats;
members elected by popular vote for five-year terms)
elections: last held 10 January 2003 (next to be held January 2008)
election results: percent of vote - RPP 62.2%, FRUD 36.9%; seats -
RPP 65, FRUD 0; note - RPP (the ruling party) dominated the election
Judicial branch:
Supreme Court or Cour Supreme
Political parties and leaders:
Democratic National Party or PND [ADEN Robleh Awaleh]; Democratic
Renewal Party or PRD [Abdillahi HAMARITEH]; Djibouti Development
Party or PDD [Mohamed Daoud CHEHEM]; Front pour la Restauration de
l''Unite Democratique or FRUD [Ali Mohamed DAOUD]; People''s Progress
Assembly or RPP [Ismail Omar GUELLEH] (governing party); Peoples
Social Democratic Party or PPSD [Moumin Bahdon FARAH]; Republican
Alliance for Democracy or ARD [Ahmed Dini AHMED]; Union for
Democracy and Justice or UDJ
Political pressure groups and leaders:
Union for Presidential Majority UMP (coalition includes RPP, FRUD,
PPSD and PND); Union for Democratic Changeover or UAD (opposition
coalition includes ARD, MRDD, UDJ, and PDD) [Ahmed Dini AHMED]
International organization participation:
ACCT, ACP, AfDB, AFESD, AMF, AU, COMESA, FAO, G-77, IBRD, ICAO,
ICCt, ICFTU, ICRM, IDA, IDB, IFAD, IFC, IFRCS, IGAD, ILO, IMF, IMO,
Interpol, IOC, IPU, ITU, LAS, NAM, OIC, OIF, OPCW (signatory), UN,
UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WToO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Roble OLHAYE Oudine
chancery: Suite 515, 1156 15th Street NW, Washington, DC 20005
telephone: [1] (202) 331-0270
FAX: [1] (202) 331-0302
Diplomatic representation from the US:
chief of mission: Ambassador W. Stuart SYMINGTON
embassy: Plateau du Serpent, Boulevard Marechal Joffre, Djibouti
mailing address: B. P. 185, Djibouti
telephone: [253] 35 39 95
FAX: [253] 35 39 40
Flag description:
two equal horizontal bands of light blue (top) and light green with
a white isosceles triangle based on the hoist side bearing a red
five-pointed star in the center
Economy Djibouti
Economy - overview:
The economy is based on service activities connected with the
country''s strategic location and status as a free trade zone in
northeast Africa. Two-thirds of the inhabitants live in the capital
city; the remainder are mostly nomadic herders. Scanty rainfall
limits crop production to fruits and vegetables, and most food must
be imported. Djibouti provides services as both a transit port for
the region and an international transshipment and refueling center.
Djibouti has few natural resources and little industry. The nation
is, therefore, heavily dependent on foreign assistance to help
support its balance of payments and to finance development projects.
An unemployment rate of at least 50% continues to be a major
problem. While inflation is not a concern, due to the fixed tie of
the Djiboutian franc to the US dollar, the artificially high value
of the Djiboutian franc adversely affects Djibouti''s balance of
payments. Per capita consumption dropped an estimated 35% over the
last seven years because of recession, civil war, and a high
population growth rate (including immigrants and refugees). Faced
with a multitude of economic difficulties, the government has fallen
in arrears on long-term external debt and has been struggling to
meet the stipulations of foreign aid donors.
GDP (purchasing power parity):
$619 million (2002 est.)
GDP (official exchange rate):
$702 million
GDP - real growth rate:
3.2% (2005 est.)
GDP - per capita (PPP):
$1,000 (2005 est.)
GDP - composition by sector:
agriculture: 17.9%
industry: 22.5%
services: 59.6% (2001 est.)
Labor force:
282,000 (2000)
Labor force - by occupation:
agriculture: NA%
industry: NA%
services: NA%
Unemployment rate:
50% (2004 est.)
Population below poverty line:
50% (2001 est.)
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices):
3% (2005 est.)
Budget:
revenues: $135 million
expenditures: $182 million; including capital expenditures of $NA
(1999 est.)
Agriculture - products:
fruits, vegetables; goats, sheep, camels, animal hides
Industries:
construction, agricultural processing, salt
Industrial production growth rate:
3% (1996 est.)
Electricity - production:
240 million kWh (2003)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
223.2 million kWh (2003)
Electricity - exports:
0 kWh (2003)
Electricity - imports:
0 kWh (2003)
Oil - production:
0 bbl/day (2003)
Oil - consumption:
12,000 bbl/day (2003 est.)
Oil - exports:
NA bbl/day
Oil - imports:
NA bbl/day
Natural gas - production:
0 cu m (2003 est.)
Natural gas - consumption:
0 cu m (2003 est.)
Exports:
$250 million f.o.b. (2004 est.)
Exports - commodities:
reexports, hides and skins, coffee (in transit)
Exports - partners:
Somalia 55.2%, Yemen 19.5%, Ethiopia 17.9% (2005)
Imports:
$987 million f.o.b. (2004 est.)
Imports - commodities:
foods, beverages, transport equipment, chemicals, petroleum products
Imports - partners:
Saudi Arabia 21.7%, India 18.5%, China 10%, Ethiopia 4.8%, France
4.5%, US 4.3%, Japan 4.2% (2005)
Debt - external:
$394 million (2004 est.)
Economic aid - recipient:
$64.1 million (2004)
Currency (code):
Djiboutian franc (DJF)
Currency code:
DJF
Exchange rates:
Djiboutian francs per US dollar - 177.72 (2005), 177.72 (2004),
177.72 (2003), 177.72 (2002), 177.72 (2001)
Fiscal year:
calendar year
Communications Djibouti
Telephones - main lines in use:
11,100 (2004)
Telephones - mobile cellular:
34,500 (2004)
Telephone system:
general assessment: telephone facilities in the city of Djibouti
are adequate, as are the microwave radio relay connections to
outlying areas of the country
domestic: microwave radio relay network
international: country code - 253; submarine cable to Jiddah, Suez,
Sicily, Marseille, Colombo, and Singapore; satellite earth stations
- 1 Intelsat (Indian Ocean) and 1 Arabsat; Medarabtel regional
microwave radio relay telephone network
Radio broadcast stations:
AM 1, FM 2, shortwave 0 (2001)
Radios:
52,000 (1997)
Television broadcast stations:
1 (2002)
Televisions:
28,000 (1997)
Internet country code:
.dj
Internet hosts:
1,540 (2006)
Internet Service Providers (ISPs):
1 (2000)
Internet users:
9,000 (2005)
Transportation Djibouti
Airports:
13 (2006)
Airports - with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2006)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2006)
Railways:
total: 100 km (Djibouti segment of the Addis Ababa-Djibouti railway)
narrow gauge: 100 km 1.000-m gauge
note: railway under joint control of Djibouti and Ethiopia (2005)
Roadways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1999)
Merchant marine:
total: 1 ship (1000 GRT or over) 1,369 GRT/3,030 DWT
by type: cargo 1 (2006)
Ports and terminals:','4661f049cebcc0c3ca54ac1f495afa441b7c7161201ff9769eb606119066c2b3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8a74da3ca731f3c9e571978f08addcb4170998f693e148764fa61da113d7c53',2006,'DJ','Djibouti','terrorism',93,'Military Djibouti
Military branches:
Djibouti National Army (includes Navy and Air Force)
Military service age and obligation:
18 years of age (est.); no conscription (2001)
Manpower available for military service:
males age 18-49: 95,328
females age 18-49: 87,795 (2005 est.)
Manpower fit for military service:
males age 18-49: 46,020
females age 18-49: 42,181 (2005 est.)
Military expenditures - dollar figure:
$29.05 million (2005 est.)
Military expenditures - percent of GDP:
4.3% (2005 est.)
Transnational Issues Djibouti
Disputes - international:
Djibouti maintains economic ties and border accords with
"Somaliland" leadership while maintaining some political ties to
various factions in Somalia; thousands of Somali refugees await
repatriation in UNHCR camps in Djibouti
Refugees and internally displaced persons:
refugees (country of origin): 17,331 (Somalia) (2005)
Trafficking in persons:
current situation: Djibouti is a source, transit, and destination
country for women and children trafficked for the purposes of sexual
exploitation and possibly forced labor; small numbers are trafficked
from Ethiopia and Somalia for sexual exploitation; economic migrants
from these countries also fall victim to trafficking upon reaching
Djibouti City or the Ethiopia-Djibouti trucking corridor; women and
children from neighboring countries reportedly transit Djibouti to
Arab countries and Somalia for ultimate use in forced labor or
sexual exploitation
tier rating: Tier 2 Watch List - Djibouti does not fully comply with
the minimum standards for the elimination of trafficking; however,
it is making significant efforts to do so based partly on the
government''s commitments to undertake future action
This page was last updated on 19 December, 2006
======================================================================
@Dominica
Introduction Dominica','cb9f1d166660e1cf47757a17b5bb7a335da49e07f3f24ed2a7be6f921d44cead','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

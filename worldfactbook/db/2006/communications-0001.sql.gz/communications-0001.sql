SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da5e5dcc961e5e354abdf989f61f65f89e5c668fc5e5cdcf2ef1334b26c8c284',2006,'ZW','Zimbabwe','communications',6,'Telephones - main lines in use
Telephones - mobile cellular
Internet hosts
Internet users
This category deals with the means of exchanging information and
includes the telephone, radio, television, and Internet host entries.
Communications - note
This entry includes miscellaneous communications information of
significance not included elsewhere.
Constitution
This entry includes the dates of adoption, revisions, and major
amendments.
Coordinated Universal Time (UTC)
UTC is the international atomic time scale that serves as the basis of
timekeeping for most of the world. The hours, minutes, and seconds
expressed by UTC represent the time of day at the Prime Meridian (0º
longitude) located near Greenwich, England as reckoned from midnight.
UTC is calculated by the Bureau International des Poids et Measures
(BIPM) in Sevres, France. The BIPM averages data collected from more
than 200 atomic time and frequency standards located at about 50
laboratories worldwide. UTC is the basis for all civil time with the
Earth divided into time zones expressed as positive or negative
differences from UTC. UTC is also referred to as "Zulu time." See the
Standard Time Zones of the World map included with the Reference Maps.
Country data codes
see Data codes
Country map
Most versions of the Factbook provide a country map in color. The maps
were produced from the best information available at the time of
preparation. Names and/or boundaries may have changed subsequently.
Country name
This entry includes all forms of the country''s name approved by the US
Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local
long form (Repubblica Italiana), local short form (Italia), former
(Kingdom of Italy), as well as the abbreviation. Also see the
Terminology note.
Crude oil
See entry for oil.
Currency (code)
This entry identifies the national medium of exchange and, in
parenthesis, gives the International Organization for Standardization
(ISO) 4217 alphabetic currency code for each country.
Current account balance
This entry records a country''s net trade in goods and services, plus
net earnings from rents, interest, profits, and dividends, and net
transfer payments (such as pension funds and worker remittances) to and
from the rest of the world during the period specified. These figures
are calculated on an exchange rate basis, i.e., not in purchasing power
parity (PPP) terms.
Data codes
This information is presented in Appendix D: Cross-Reference List of
Country Data Codes and Appendix E: Cross-Reference List of Hydrographic
Data Codes.
Date of information
In general, information available as of 1 January 2006, was used in the
preparation of this edition.
Daylight Saving Time (DST)
This entry is included for those entities that have adopted a policy of
adjusting the official local time forward, usually one hour, from
Standard Time during summer months. Such policies are most common in
mid-latitude regions.
Death rate
This entry gives the average annual number of deaths during a year per
1,000 population at midyear; also known as crude death rate. The death
rate, while only a rough indicator of the mortality situation in a
country, accurately indicates the current mortality impact on
population growth. This indicator is significantly affected by age
distribution, and most countries will eventually show a rise in the
overall death rate, in spite of continued decline in mortality at all
ages, as declining fertility results in an aging population.
Debt - external
This entry gives the total public and private debt owed to nonresidents
repayable in foreign currency, goods, or services. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power
parity (PPP) terms.
Dependency status
This entry describes the formal relationship between a particular
nonindependent entity and an independent state.
Dependent areas
This entry contains an alphabetical listing of all nonindependent
entities associated in some way with a particular independent state.
Diplomatic representation
The US Government has diplomatic relations with 188 independent states,
including 187 of the 192 UN members (excluded UN members are Bhutan,
Cuba, Iran, North Korea, and the US itself). In addition, the US has
diplomatic relations with 1 independent state that is not in the UN,
the Holy See, as well as with the EU.
Diplomatic representation from the US
This entry includes the chief of mission, embassy address, mailing
address, telephone number, FAX number, branch office locations,
consulate general locations, and consulate locations.
Diplomatic representation in the US
This entry includes the chief of mission, chancery, telephone, FAX,
consulate general locations, and consulate locations.
Disputes - international
This entry includes a wide variety of situations that range from
traditional bilateral boundary disputes to unilateral claims of one
sort or another. Information regarding disputes over international
terrestrial and maritime boundaries has been reviewed by the US
Department of State. References to other situations involving borders
or frontiers may also be included, such as resource disputes,
geopolitical questions, or irredentist issues; however, inclusion does
not necessarily constitute official acceptance or recognition by the US
general assessment: system was once one of the best in
Africa, but now suffers from poor maintenance; more than 100,000
outstanding requests for connection despite an equally large number
of installed but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: country code - 263; satellite earth stations - 2
Intelsat; two international digital gateway exchanges (in Harare and
Gweru)
This page was last updated on 19 December, 2006
======================================================================
@2125 Terrain
mostly high plateau with higher central plateau (high
veld); mountains in east
This page was last updated on 19 December, 2006
======================================================================
@2127 Total fertility rate (children born/woman)
3.13 children born/woman (2006 est.)
This page was last updated on 19 December, 2006
======================================================================
@2128 Government type
parliamentary democracy
This page was last updated on 19 December, 2006
======================================================================
@2129 Unemployment rate (%)
80% (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2137 Military - note
Akrotiri
Akrotiri has a full RAF base, Headquarters for British
Forces on Cyprus, and Episkopi Support Unit
conventional long form: Republic of Zimbabwe
conventional short form: Zimbabwe
former: Southern Rhodesia, Rhodesia
This page was last updated on 19 December, 2006
======================================================================
@2144 Location
Southern Africa, between South Africa and Zambia
This page was last updated on 19 December, 2006
======================================================================
@2145 Map references
Africa
This page was last updated on 19 December, 2006
======================================================================
@2146 Irrigated land (sq km)
1,740 sq km (2003)
This page was last updated on 19 December, 2006
======================================================================
@2147 Area (sq km)
total: 390,580 sq km
land: 386,670 sq km
water: 3,910 sq km
This page was last updated on 19 December, 2006
======================================================================
@2149 Diplomatic representation in the US
chief of mission: Ambassador Dr. Machivenyika T. MAPURANGA
chancery: 1608 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 332-7100
FAX: [1] (202) 483-9326
This page was last updated on 19 December, 2006
======================================================================
@2150 Telephones - main lines in use
328,000 (2005)
This page was last updated on 19 December, 2006
======================================================================
@2151 Telephones - mobile cellular
699,000 (2005)
This page was last updated on 19 December, 2006
======================================================================
@2153 Internet users
1 million (2005)
This page was last updated on 19 December, 2006
======================================================================
@2154 Internet country code
.zw
This page was last updated on 19 December, 2006
======================================================================
@2155 HIV/AIDS - adult prevalence rate (%)
24.6% (2001 est.)
This page was last updated on 19 December, 2006
======================================================================
@2156 HIV/AIDS - people living with HIV/AIDS
1.8 million (2001 est.)
This page was last updated on 19 December, 2006
======================================================================
@2157 HIV/AIDS - deaths
170,000 (2003 est.)
This page was last updated on 19 December, 2006
======================================================================
@2172 Distribution of family income - Gini index
56.8 (2003)
This page was last updated on 19 December, 2006
======================================================================
@2173 Oil - production (bbl/day)
0 bbl/day (2003 est.)
This page was last updated on 19 December, 2006
======================================================================
@2174 Oil - consumption (bbl/day)
22,500 bbl/day (2003 est.)
This page was last updated on 19 December, 2006
======================================================================
@2175 Oil - imports (bbl/day)
23,000 bbl/day
This page was last updated on 19 December, 2006
======================================================================
@2176 Oil - exports (bbl/day)
0 bbl/day
This page was last updated on 19 December, 2006
======================================================================
@2177 Median age (years)
total: 19.9 years
male: 19.7 years
female: 20 years (2006 est.)
This page was last updated on 19 December, 2006
======================================================================
@2178 Oil - proved reserves (bbl)
0 cu m (2003 est.)
This page was last updated on 19 December, 2006
======================================================================
@2181 Natural gas - consumption (cu m)
0 cu m (2003 est.)
This page was last updated on 19 December, 2006
======================================================================
@2182 Natural gas - imports (cu m)
7,954 (2006)
This page was last updated on 19 December, 2006
======================================================================
@2185 Investment (gross fixed) (% of GDP)
7.9% of GDP (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2186 Public debt (% of GDP)
109.8% of GDP (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2187 Current account balance
$-519 million (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2188 Reserves of foreign exchange and gold
$160 million (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2193 Major infectious diseases
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid
vectorborne disease: malaria
water contact disease: schistosomiasis (2005)
This page was last updated on 19 December, 2006
======================================================================
@2194 Refugees and internally displaced persons
IDPs: 400,000-450,000 (MUGABE-led political violence, human
rights violations, land reform, and economic collapse) (2005)
This page was last updated on 19 December, 2006
======================================================================
@2195 GDP (official exchange rate)
$3.207 billion (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2196 Trafficking in persons
current situation: Zimbabwe is a source, transit, and
destination country for women and children trafficked for forced
labor and sexual exploitation; children may be trafficked internally
for forced agricultural labor, domestic servitude, and sexual
exploitation; women and girls are lured out of the country to South
Africa, China, Egypt, and Zambia with false job or scholarship
promises that result in domestic servitude or commercial sexual
exploitation; there are reports of South African employers demanding
sex from undocumented Zimbabwean workers under threat of
deportation; women and children from Malawi, Zambia, and the
Democratic Republic of the Congo transit Zimbabwe en route to South
Africa; small numbers of South African girls are trafficked to
Zimbabwe for domestic labor
tier rating: Tier 3 - Zimbabwe does not fully comply with the
minimum standards for the elimination of trafficking and is not
making significant efforts to do so
This page was last updated on 19 December, 2006
======================================================================
Rank code: @2001
Rank Country GDP (purchasing power parity) Date of Information
1 World $ 60,630,000,000,000 2005 est.
2 United States $ 12,310,000,000,000 2005 est.
3 European Union $ 12,180,000,000,000 2005 est.
4 China $ 8,883,000,000,000 2005 est.
5 Japan $ 4,025,000,000,000 2005 est.
6 India $ 3,666,000,000,000 2005 est.
7 Germany $ 2,480,000,000,000 2005 est.
8 United Kingdom $ 1,818,000,000,000 2005 est.
9 France $ 1,794,000,000,000 2005 est.
10 Italy $ 1,667,000,000,000 2005 est.
11 Russia $ 1,584,000,000,000 2005 est.
12 Brazil $ 1,536,000,000,000 2005 est.
13 Canada $ 1,111,000,000,000 2005 est.
14 Korea, South $ 1,101,000,000,000 2005 est.
15 Mexico $ 1,064,000,000,000 2005 est.
16 Spain $ 1,033,000,000,000 2005 est.
17 Indonesia $ 869,700,000,000 2005 est.
18 Australia $ 635,500,000,000 2005 est.
19 Taiwan $ 630,000,000,000 2005 est.
20 Turkey $ 584,500,000,000 2005 est.
21 Iran $ 569,900,000,000 2005 est.
22 Thailand $ 550,200,000,000 2005 est.
23 Argentina $ 543,400,000,000 2005 est.
24 South Africa $ 540,800,000,000 2005 est.
25 Poland $ 505,200,000,000 2005 est.
26 Netherlands $ 497,900,000,000 2005 est.
27 Philippines $ 412,500,000,000 2005 est.
28 Pakistan $ 395,200,000,000 2005 est.
29 Saudi Arabia $ 346,300,000,000 2005 est.
30 Colombia $ 341,100,000,000 2005 est.
31 Ukraine $ 329,100,000,000 2005 est.
32 Belgium $ 322,300,000,000 2005 est.
33 Bangladesh $ 305,900,000,000 2005 est.
34 Egypt $ 304,300,000,000 2005 est.
35 Malaysia $ 287,000,000,000 2005 est.
36 Sweden $ 268,300,000,000 2005 est.
37 Austria $ 265,800,000,000 2005 est.
38 Switzerland $ 240,900,000,000 2005 est.
39 Greece $ 238,200,000,000 2005 est.
40 Algeria $ 235,500,000,000 2005 est.
41 Vietnam $ 235,200,000,000 2005 est.
42 Hong Kong $ 234,300,000,000 2005 est.
43 Czech Republic $ 204,400,000,000 2005 est.
44 Portugal $ 200,600,000,000 2005 est.
45 Norway $ 196,400,000,000 2005 est.
46 Chile $ 189,900,000,000 2005 est.
47 Denmark $ 189,300,000,000 2005 est.
48 Romania $ 181,800,000,000 2005 est.
49 Nigeria $ 175,500,000,000 2005 est.
50 Peru $ 167,300,000,000 2005 est.
51 Ireland $ 165,100,000,000 2005 est.
52 Hungary $ 163,100,000,000 2005 est.
53 Venezuela $ 162,100,000,000 2005 est.
54 Finland $ 161,900,000,000 2005 est.
55 Israel $ 156,900,000,000 2005 est.
56 Morocco $ 135,100,000,000 2005 est.
57 Singapore $ 126,500,000,000 2005 est.
58 Kazakhstan $ 125,300,000,000 2005 est.
59 United Arab Emirates $ 115,800,000,000 2005 est.
60 New Zealand $ 102,000,000,000 2005 est.
61 Iraq $ 94,100,000,000 2005 est.
62 Slovakia $ 88,780,000,000 2005 est.
63 Sri Lanka $ 86,070,000,000 2005 est.
64 Sudan $ 85,890,000,000 2005 est.
65 Tunisia $ 82,850,000,000 2005 est.
66 Burma $ 80,110,000,000 2005 est.
67 Puerto Rico $ 73,270,000,000 2005 est.
68 Belarus $ 73,090,000,000 2005 est.
69 Bulgaria $ 71,670,000,000 2005 est.
70 Syria $ 71,420,000,000 2005 est.
71 Libya $ 68,000,000,000 2005 est.
72 Dominican Republic $ 67,440,000,000 2005 est.
73 Ethiopia $ 64,730,000,000 2005 est.
74 Ecuador $ 57,230,000,000 2005 est.
75 Guatemala $ 56,860,000,000 2005 est.
76 Croatia $ 55,790,000,000 2005 est.
77 Ghana $ 54,860,000,000 2005 est.
78 Uzbekistan $ 50,310,000,000 2005 est.
79 Lithuania $ 49,410,000,000 2005 est.
80 Uganda $ 47,760,000,000 2005 est.
81 Kuwait $ 47,360,000,000 2005 est.
82 Costa Rica $ 45,670,000,000 2005 est.
83 Angola $ 45,320,000,000 2005 est.
84 Slovenia $ 43,270,000,000 2005 est.
85 Azerbaijan $ 42,990,000,000 2005 est.
86 Serbia $ 41,150,000,000 2005 est.
87 Congo, Democratic Republic of the $ 40,670,000,000 2005 est.
88 Oman $ 40,390,000,000 2005 est.
89 Cuba $ 40,060,000,000 2005 est.
90 Korea, North $ 40,000,000,000 2005 est.
91 Cameroon $ 39,750,000,000 2005 est.
92 Nepal $ 39,140,000,000 2005 est.
93 Turkmenistan $ 39,140,000,000 2005 est.
94 Kenya $ 37,890,000,000 2005 est.
95 Cambodia $ 34,080,000,000 2005 est.
96 Uruguay $ 33,980,000,000 2005 est.
97 Latvia $ 31,460,000,000 2005 est.
98 El Salvador $ 31,300,000,000 2005 est.
99 Luxembourg $ 30,900,000,000 2005 est.
100 Paraguay $ 29,110,000,000 2005 est.
101 Cote d''Ivoire $ 27,580,000,000 2005 est.
102 Tanzania $ 27,110,000,000 2005 est.
103 Jordan $ 26,850,000,000 2005 est.
104 Mozambique $ 26,180,000,000 2005 est.
105 Bolivia $ 25,820,000,000 2005 est.
106 Equatorial Guinea $ 25,690,000,000 2005 est.
107 Zimbabwe $ 25,690,000,000 2005 est.
108 Qatar $ 24,460,000,000 2005 est.
109 Estonia $ 23,340,000,000 2005 est.
110 Panama $ 23,330,000,000 2005 est.
111 Bosnia and Herzegovina $ 23,090,000,000 2005 est.
112 Lebanon $ 22,780,000,000 2005 est.
113 Afghanistan $ 21,500,000,000 2004 est.
114 Honduras $ 20,610,000,000 2005 est.
115 Senegal $ 20,570,000,000 2005 est.
116 Yemen $ 19,360,000,000 2005 est.
117 Albania $ 18,870,000,000 2005 est.
118 Guinea $ 18,650,000,000 2005 est.
119 Trinidad and Tobago $ 18,110,000,000 2005 est.
120 Botswana $ 17,530,000,000 2005 est.
121 Cyprus $ 16,810,000,000 2005 est.
122 Burkina Faso $ 16,660,000,000 2005 est.
123 Nicaragua $ 16,100,000,000 2005 est.
124 Madagascar $ 16,050,000,000 2005 est.
125 Georgia $ 16,030,000,000 2005 est.
126 Macedonia $ 15,940,000,000 2005 est.
127 Bahrain $ 15,900,000,000 2005 est.
128 Mauritius $ 15,730,000,000 2005 est.
129 Armenia $ 14,450,000,000 2005 est.
130 Papua New Guinea $ 14,370,000,000 2005 est.
131 Namibia $ 14,160,000,000 2005 est.
132 Chad $ 13,980,000,000 2005 est.
133 Haiti $ 13,970,000,000 2005 est.
134 Mali $ 13,610,000,000 2005 est.
135 Rwanda $ 12,540,000,000 2005 est.
136 Laos $ 12,290,000,000 2005 est.
137 Jamaica $ 12,180,000,000 2005 est.
138 Niger $ 11,590,000,000 2005 est.
139 Zambia $ 10,630,000,000 2005 est.
140 Iceland $ 10,590,000,000 2005 est.
141 Kyrgyzstan $ 10,080,000,000 2005 est.
142 Macau $ 10,000,000,000 2004
143 Gabon $ 9,739,000,000 2005 est.
144 Togo $ 8,802,000,000 2005 est.
145 Tajikistan $ 8,617,000,000 2005 est.
146 Benin $ 8,419,000,000 2005 est.
147 Moldova $ 8,410,000,000 2005 est.
148 Malta $ 7,861,000,000 2005 est.
149 Malawi $ 7,364,000,000 2005 est.
150 Mauritania $ 6,901,000,000 2005 est.
151 Brunei $ 6,842,000,000 2003 est.
152 Martinique $ 6,117,000,000 2003 est.
153 Bahamas, The $ 6,105,000,000 2005 est.
154 Swaziland $ 5,680,000,000 2005 est.
155 Burundi $ 5,404,000,000 2005 est.
156 Mongolia $ 5,272,000,000 2005 est.
157 Fiji $ 5,255,000,000 2005 est.
158 Lesotho $ 5,008,000,000 2005 est.
159 Sierra Leone $ 4,939,000,000 2005 est.
160 Barbados $ 4,815,000,000 2005 est.
161 Somalia $ 4,809,000,000 2005 est.
162 Reunion $ 4,790,000,000 2005 est.
163 Central African Republic $ 4,677,000,000 2005 est.
164 Congo, Republic of the $ 4,585,000,000 2005 est.
165 French Polynesia $ 4,580,000,000 2003 est.
166 Cyprus $ 4,540,000,000 2005 est.
167 Bermuda $ 4,500,000,000 2004 est.
168 Eritrea $ 4,471,000,000 2005 est.
169 Jersey $ 3,600,000,000 2003 est.
170 Guadeloupe $ 3,513,000,000 2003 est.
171 Guyana $ 3,439,000,000 2005 est.
172 New Caledonia $ 3,158,000,000 2003 est.
173 Gambia, The $ 3,034,000,000 2005 est.
174 Cape Verde $ 2,990,000,000 2005 est.
175 Bhutan $ 2,900,000,000 2003 est.
176 Suriname $ 2,893,000,000 2005 est.
177 Netherlands Antilles $ 2,800,000,000 2004 est.
178 Liberia $ 2,643,000,000 2005 est.
179 Guernsey $ 2,590,000,000 2003 est.
180 Guam $ 2,500,000,000 2005 est.
181 Montenegro $ 2,412,000,000 2005 est.
182 Aruba $ 2,258,000,000 2005 est.
183 Isle of Man $ 2,113,000,000 2003 est.
184 Cayman Islands $ 1,939,000,000 2004 est.
185 Andorra $ 1,840,000,000 2004
186 West Bank $ 1,800,000,000 2003 est.
187 Liechtenstein $ 1,786,000,000 2001 est.
188 Belize $ 1,778,000,000 2004 est.
189 Virgin Islands $ 1,577,000,000 2004 est.
190 French Guiana $ 1,551,000,000 2003 est.
191 Maldives $ 1,250,000,000 2002 est.
192 Guinea-Bissau $ 1,171,000,000 2005 est.
193 Greenland $ 1,100,000,000 2001 est.
194 Faroe Islands $ 1,000,000,000 2001 est.
195 Samoa $ 1,000,000,000 2002 est.
196 San Marino $ 940,000,000 2001 est.
197 Northern Mariana Islands $ 900,000,000 2000 est.
198 Monaco $ 870,000,000 2000 est.
199 Saint Lucia $ 866,000,000 2002 est.
200 British Virgin Islands $ 853,400,000 2004 est.
201 Solomon Islands $ 800,000,000 2002 est.
202 Gibraltar $ 769,000,000 2000 est.
203 Gaza Strip $ 768,000,000 2003 est.
204 Antigua and Barbuda $ 750,000,000 2002 est.
205 Seychelles $ 626,000,000 2002 est.
206 Djibouti $ 619,000,000 2002 est.
207 American Samoa $ 510,100,000 2003 est.
208 Mayotte $ 466,800,000 2003 est.
209 Comoros $ 441,000,000 2002 est.
210 Grenada $ 440,000,000 2002 est.
211 Dominica $ 384,000,000 2003 est.
212 East Timor $ 370,000,000 2004 est.
213 Saint Vincent and the Grenadines $ 342,000,000 2002 est.
214 Saint Kitts and Nevis $ 339,000,000 2002 est.
215 Micronesia, Federated States of $ 277,000,000 2002 est.
216 Vanuatu $ 276,300,000 2003 est.
217 Turks and Caicos Islands $ 216,000,000 2002 est.
218 Sao Tome and Principe $ 214,000,000 2003 est.
219 Cook Islands $ 183,200,000 2005 est.
220 Tonga $ 178,500,000 2004 est.
221 Kiribati $ 142,900,000 2004 est.
222 Palau $ 124,500,000 2004 est.
223 Marshall Islands $ 115,000,000 2001 est.
224 Anguilla $ 108,900,000 2004 est.
225 Falkland Islands (Islas Malvinas) $ 75,000,000 2002 est.
226 Nauru $ 60,000,000 2005 est.
227 Wallis and Futuna $ 60,000,000 2004 est.
228 Saint Pierre and Miquelon $ 48,300,000 2003 est.
229 Montserrat $ 29,000,000 2002 est.
230 Saint Helena $ 18,000,000 1998 est.
231 Tuvalu $ 14,940,000 2002 est.
232 Niue $ 7,600,000 2000 est.
233 Tokelau $ 1,500,000 1993 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2003
Rank Country GDP - real growth rate(%) Date of Information
1 Azerbaijan 26.40 2005 est.
2 Angola 19.90 2005 est.
3 Equatorial Guinea 18.60 2005 est.
4 Afghanistan 14.00 2005 est.
5 Armenia 13.90 2005 est.
6 Cambodia 13.40 2005 est.
7 Liechtenstein 11.00 1999 est.
8 Cyprus 10.60 2005 est.
9 Estonia 10.50 2005 est.
10 Anguilla 10.20 2004 est.
11 Latvia 10.20 2005 est.
12 China 10.20 2005 est.
13 Faroe Islands 10.00 2001 est.
14 Liberia 9.80 2005 est.
15 Kazakhstan 9.50 2005 est.
16 Dominican Republic 9.30 2005 est.
17 Georgia 9.30 2005 est.
18 Venezuela 9.30 2005 est.
19 Argentina 9.20 2005 est.
20 Belarus 9.20 2005 est.
21 Ethiopia 8.90 2005 est.
22 United Arab Emirates 8.80 2005 est.
23 Qatar 8.8','497d9ad1fe0a35608988c0c26a9ef1a1f8bd66d4c808d509859a9c67ea167bce','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b3158a0161b5027bf4ce45696d3caf22b1256f4152a68e7ef441a7bf0fa73c',2006,'ZW','Zimbabwe','communications',7,'0 2005 est.
24 Vietnam 8.50 2005 est.
25 India 8.40 2005 est.
26 Libya 8.40 2005 est.
27 Kuwait 8.30 2005 est.
28 Congo, Republic of the 8.20 2005 est.
29 Cuba 8.00 2005 est.
30 Sudan 8.00 2005 est.
31 Lithuania 7.50 2005 est.
32 Mozambique 7.50 2005 est.
33 Sierra Leone 7.50 2005 est.
34 Turkey 7.40 2005 est.
35 Hong Kong 7.30 2005 est.
36 Laos 7.30 2005 est.
37 Congo, Democratic Republic of the 7.10 2005 est.
38 Moldova 7.10 2005 est.
39 Niger 7.00 2005 est.
40 Uzbekistan 7.00 2005 est.
41 Trinidad and Tobago 7.00 2005 est.
42 Iran 6.90 2005 est.
43 Nigeria 6.90 2005 est.
44 Vanuatu 6.80 2005 est.
45 Tanzania 6.80 2005 est.
46 Uruguay 6.80 2005 est.
47 Tajikistan 6.70 2005 est.
48 Pakistan 6.60 2005 est.
49 Saudi Arabia 6.50 2005 est.
50 Bangladesh 6.40 2005 est.
51 Singapore 6.40 2005 est.
52 Russia 6.40 2005 est.
53 Panama 6.40 2005 est.
54 Peru 6.40 2005 est.
55 Chile 6.30 2005 est.
56 Isle of Man 6.30
57 Mongolia 6.20 2005 est.
58 Niue 6.20
59 West Bank 6.20 2004 est.
60 Czech Republic 6.10 2005 est.
61 Senegal 6.10 2005 est.
62 Mali 6.10 2005 est.
63 Chad 6.00 2005 est.
64 Turkmenistan 6.00 2005 est.
65 Sao Tome and Principe 6.00 2004 est.
66 Slovakia 6.00 2005 est.
67 Sri Lanka 6.00 2005 est.
68 Bahrain 5.90 2005 est.
69 Ghana 5.90 2005 est.
70 Costa Rica 5.90 2005 est.
71 Bhutan 5.90 2005 est.
72 Serbia 5.90 2005 est.
73 Jordan 5.80 2005 est.
74 Kenya 5.80 2005 est.
75 Iceland 5.60 2005 est.
76 Indonesia 5.60 2005 est.
77 Oman 5.60 2005 est.
78 Algeria 5.50 2005 est.
79 Samoa 5.50 2005 est.
80 Palau 5.50 2005 est.
81 Mauritania 5.50 2005 est.
82 Gambia, The 5.50 2005 est.
83 Ireland 5.50 2005 est.
84 Cape Verde 5.50 2005 est.
85 Bulgaria 5.50 2005 est.
86 Botswana 5.50 2005 est.
87 Albania 5.50 2005 est.
88 Burma 5.20 2005 est.
89 Israel 5.20 2005 est.
90 Malaysia 5.20 2005 est.
91 Rwanda 5.20 2005 est.
92 Colombia 5.20 2005 est.
93 Madagascar 5.10 2005 est.
94 Saint Lucia 5.10 2005 est.
95 Bosnia and Herzegovina 5.00 2005 est.
96 Zambia 5.00 2005 est.
97 Suriname 5.00 2005 est.
98 Egypt 4.90 2005 est.
99 South Africa 4.90 2005 est.
100 Saint Vincent and the Grenadines 4.90 2005 est.
101 Turks and Caicos Islands 4.90 2000 est.
102 Saint Kitts and Nevis 4.90 2005 est.
103 Philippines 4.80 2005 est.
104 Ecuador 4.70 2005 est.
105 World 4.70 2005 est.
106 Bermuda 4.60 2004 est.
107 Gaza Strip 4.50 2003 est.
108 Thailand 4.50 2005 est.
109 Solomon Islands 4.40 2005 est.
110 Croatia 4.30 2005 est.
111 Honduras 4.20 2005 est.
112 Tunisia 4.20 2005 est.
113 Barbados 4.10 2005 est.
114 Romania 4.10 2005 est.
115 Hungary 4.10 2005 est.
116 Bolivia 4.10 2005 est.
117 Andorra 4.00 2004 est.
118 Norway 4.00 2005 est.
119 Taiwan 4.00 2005 est.
120 Uganda 4.00 2005 est.
121 Slovenia 4.00 2005 est.
122 Nicaragua 4.00 2005 est.
123 Macedonia 4.00 2005 est.
124 Korea, South 4.00 2005 est.
125 Luxembourg 4.00 2005 est.
126 Antigua and Barbuda 3.80 2005 est.
127 Cyprus 3.80 2005 est.
128 Belize 3.80 2005 est.
129 Bahamas, The 3.70 2005 est.
130 Greece 3.70 2005 est.
131 Benin 3.50 2005 est.
132 Marshall Islands 3.50 2005 est.
133 Spain 3.50 2005 est.
134 Burkina Faso 3.50 2005 est.
135 Poland 3.40 2005 est.
136 Denmark 3.20 2005 est.
137 Djibouti 3.20 2005 est.
138 Namibia 3.20 2005 est.
139 United States 3.20 2005 est.
140 Guatemala 3.20 2005 est.
141 Dominica 3.10 2005 est.
142 American Samoa 3.00
143 Papua New Guinea 3.00 2005 est.
144 Mexico 3.00 2005 est.
145 Finland 3.00 2005 est.
146 Guernsey 3.00 2003 est.
147 Comoros 3.00 2005 est.
148 Canada 2.90 2005 est.
149 Gabon 2.90 2005 est.
150 El Salvador 2.80 2005 est.
151 Yemen 2.80 2005 est.
152 Syria 2.80 2005 est.
153 Macau 2.80 3rd Quarter 2005
154 Australia 2.70 2005 est.
155 Nepal 2.70 2005 est.
156 Paraguay 2.70 2005 est.
157 Sweden 2.70 2005 est.
158 Japan 2.60 2005 est.
159 Ukraine 2.60 2005 est.
160 Mauritius 2.50 2005 est.
161 Puerto Rico 2.50 2005 est.
162 Reunion 2.50 2005 est.
163 Aruba 2.40 2005 est.
164 Tonga 2.40 2005 est.
165 Somalia 2.40 2005 est.
166 Cameroon 2.40 2005 est.
167 Brazil 2.30 2005 est.
168 New Zealand 2.30 2005 est.
169 San Marino 2.30 2002 est.
170 Guinea-Bissau 2.30 2005 est.
171 Central African Republic 2.20 2005 est.
172 Eritrea 2.00 2005 est.
173 Guinea 2.00 2005 est.
174 Virgin Islands 2.00 2002 est.
175 Malawi 1.90 2005 est.
176 Switzerland 1.90 2005 est.
177 United Kingdom 1.90 2005 est.
178 Austria 1.80 2005 est.
179 Greenland 1.80 2001 est.
180 Swaziland 1.80 2005 est.
181 East Timor 1.80 2005 est.
182 Haiti 1.80 2005 est.
183 Jamaica 1.80 2005 est.
184 Brunei 1.70 2004 est.
185 Fiji 1.70 2005 est.
186 European Union 1.70 2005 est.
187 Morocco 1.70 2005 est.
188 Belgium 1.50 2005 est.
189 Netherlands 1.50 2005 est.
190 France 1.20 2005 est.
191 Lesotho 1.20 2005 est.
192 Tuvalu 1.20 2002 est.
193 Burundi 1.10 2005 est.
194 Cote d''Ivoire 1.00 2005 est.
195 Korea, North 1.00 2005 est.
196 Malta 1.00 2005 est.
197 Netherlands Antilles 1.00 2004 est.
198 British Virgin Islands 1.00 2002 est.
199 Togo 1.00 2005 est.
200 Cayman Islands 0.90 2004 est.
201 Germany 0.90 2005 est.
202 Grenada 0.90 2005 est.
203 Monaco 0.90 2000 est.
204 Portugal 0.40 2005 est.
205 Micronesia, Federated States of 0.30 2005 est.
206 Kiribati 0.30 2005
207 Cook Islands 0.10 2005 est.
208 Italy 0.10 2005 est.
209 Lebanon 0.10 2005 est.
210 Kyrgyzstan -0.60 2005 est.
211 Montserrat -1.00 2002 est.
212 Guyana -3.00 2005 est.
213 Seychelles -3.00 2005 est.
214 Iraq -3.00 2005 est.
215 Maldives -3.60 2005 est.
216 Zimbabwe -7.70 2005 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2004
Rank Country GDP - per capita (PPP) Date of Information
1 Bermuda $ 69,900 2004 est.
2 Luxembourg $ 65,900 2005 est.
3 Equatorial Guinea $ 50,200 2005 est.
4 United Arab Emirates $ 45,200 2005 est.
5 Cayman Islands $ 43,800 2004 est.
6 Norway $ 42,800 2005 est.
7 United States $ 41,600 2005 est.
8 Ireland $ 41,100 2005 est.
9 Guernsey $ 40,000 2003 est.
10 Jersey $ 40,000 2003 est.
11 British Virgin Islands $ 38,500 2004 est.
12 Iceland $ 35,700 2005 est.
13 Denmark $ 34,800 2005 est.
14 San Marino $ 34,600 2001 est.
15 Hong Kong $ 34,000 2005 est.
16 Canada $ 33,900 2005 est.
17 Austria $ 32,500 2005 est.
18 Switzerland $ 32,200 2005 est.
19 Australia $ 31,600 2005 est.
20 Japan $ 31,600 2005 est.
21 Belgium $ 31,100 2005 est.
22 Finland $ 31,000 2005 est.
23 Netherlands $ 30,300 2005 est.
24 Germany $ 30,100 2005 est.
25 United Kingdom $ 30,100 2005 est.
26 Sweden $ 29,800 2005 est.
27 France $ 29,600 2005 est.
28 Italy $ 28,700 2005 est.
29 Singapore $ 28,600 2005 est.
30 Qatar $ 28,300 2005 est.
31 European Union $ 28,100 2005 est.
32 Gibraltar $ 27,900 2000 est.
33 Isle of Man $ 27,800 2003 est.
34 Taiwan $ 27,500 2005 est.
35 Monaco $ 27,000 2000 est.
36 Spain $ 25,600 2005 est.
37 New Zealand $ 25,300 2005 est.
38 Falkland Islands (Islas Malvinas) $ 25,000 2002 est.
39 Israel $ 25,000 2005 est.
40 Liechtenstein $ 25,000 1999 est.
41 Andorra $ 24,000 2004
42 Brunei $ 23,600 2003 est.
43 Bahrain $ 23,100 2005 est.
44 Korea, South $ 22,600 2005 est.
45 Greece $ 22,300 2005 est.
46 Faroe Islands $ 22,000 2001 est.
47 Macau $ 22,000 2004
48 Aruba $ 21,800 2004 est.
49 Cyprus $ 21,600
50 Slovenia $ 21,500 2005 est.
51 Kuwait $ 20,300 2005 est.
52 Bahamas, The $ 20,200 2005 est.
53 Czech Republic $ 20,000 2005 est.
54 Greenland $ 20,000 2001 est.
55 Malta $ 19,700 2005 est.
56 Portugal $ 19,000 2005 est.
57 Puerto Rico $ 18,700 2005 est.
58 Estonia $ 17,500 2005 est.
59 French Polynesia $ 17,500 2003 est.
60 Barbados $ 17,300 2005 est.
61 Trinidad and Tobago $ 16,800 2005 est.
62 Hungary $ 16,300 2005 est.
63 Slovakia $ 16,300 2005 est.
64 Netherlands Antilles $ 16,000 2004 est.
65 Guam $ 15,000 2005 est.
66 New Caledonia $ 15,000 2003 est.
67 Virgin Islands $ 14,500 2004 est.
68 Martinique $ 14,400 2003 est.
69 Lithuania $ 14,100 2005 est.
70 Argentina $ 13,700 2005 est.
71 Latvia $ 13,700 2005 est.
72 Oman $ 13,500 2005 est.
73 Poland $ 13,100 2005 est.
74 Saudi Arabia $ 13,100 2005 est.
75 Mauritius $ 12,800 2005 est.
76 Northern Mariana Islands $ 12,500 2000 est.
77 Croatia $ 12,400 2005 est.
78 South Africa $ 12,200 2005 est.
79 Malaysia $ 12,000 2005 est.
80 Chile $ 11,900 2005 est.
81 Libya $ 11,800 2005 est.
82 Turks and Caicos Islands $ 11,500 2002 est.
83 Costa Rica $ 11,400 2005 est.
84 Russia $ 11,000 2005 est.
85 Antigua and Barbuda $ 10,900 2005 est.
86 Botswana $ 10,700 2005 est.
87 Mexico $ 10,000 2005 est.
88 Uruguay $ 9,900 2005 est.
89 Bulgaria $ 9,600 2005 est.
90 World $ 9,500 2005 est.
91 Cook Islands $ 9,100 2005 est.
92 Anguilla $ 8,800 2004 est.
93 Thailand $ 8,600 2005 est.
94 Iran $ 8,400 2005 est.
95 Turkey $ 8,400 2005 est.
96 Brazil $ 8,300 2005 est.
97 Kazakhstan $ 8,300 2005 est.
98 French Guiana $ 8,300 2003 est.
99 Saint Kitts and Nevis $ 8,200 2005 est.
100 Tunisia $ 8,200 2005 est.
101 Romania $ 8,100 2005 est.
102 Colombia $ 7,900 2005 est.
103 Guadeloupe $ 7,900 2003 est.
104 Turkmenistan $ 7,900 2005 est.
105 Macedonia $ 7,800 2005 est.
106 Seychelles $ 7,800 2002 est.
107 Palau $ 7,600 2005 est.
108 Dominican Republic $ 7,500 2005 est.
109 Panama $ 7,400 2005 est.
110 Algeria $ 7,200 2005 est.
111 Cyprus $ 7,135
112 Belarus $ 7,100 2005 est.
113 Gabon $ 7,000 2005 est.
114 Namibia $ 7,000 2005 est.
115 Ukraine $ 7,000 2005 est.
116 Saint Pierre and Miquelon $ 7,000 2001 est.
117 Belize $ 6,800 2005 est.
118 China $ 6,800 2005 est.
119 Suriname $ 6,600 2005 est.
120 Venezuela $ 6,400 2005 est.
121 Cape Verde $ 6,200 2005 est.
122 Reunion $ 6,200 2005 est.
123 Lebanon $ 6,000 2005 est.
124 Peru $ 6,000 2005 est.
125 Fiji $ 5,900 2005 est.
126 American Samoa $ 5,800 2005 est.
127 Niue $ 5,800 2003 est.
128 Azerbaijan $ 5,400 2005 est.
129 Albania $ 5,300 2005 est.
130 Bosnia and Herzegovina $ 5,200 2005 est.
131 Nauru $ 5,000 2005 est.
132 Swaziland $ 5,000 2005 est.
133 Armenia $ 4,800 2005 est.
134 Saint Lucia $ 4,800 2005 est.
135 El Salvador $ 4,700 2005 est.
136 Jordan $ 4,700 2005 est.
137 Philippines $ 4,700 2005 est.
138 Guatemala $ 4,700 2005 est.
139 Paraguay $ 4,600 2005 est.
140 Guyana $ 4,500 2005 est.
141 Jamaica $ 4,500 2005 est.
142 Serbia $ 4,400 2005 est.
143 Sri Lanka $ 4,300 2005 est.
144 Ecuador $ 4,300 2005 est.
145 Morocco $ 4,100 2005 est.
146 Egypt $ 3,900 2005 est.
147 Grenada $ 3,900 2005 est.
148 Syria $ 3,900 2005 est.
149 Maldives $ 3,900 2002 est.
150 Angola $ 3,800 2005 est.
151 Wallis and Futuna $ 3,800 2004 est.
152 Dominica $ 3,800 2005 est.
153 Montenegro $ 3,800 2005 est.
154 Indonesia $ 3,600 2005 est.
155 Saint Vincent and the Grenadines $ 3,600 2005 est.
156 Cuba $ 3,500 2005 est.
157 Georgia $ 3,400 2005 est.
158 Montserrat $ 3,400 2002 est.
159 India $ 3,400 2005 est.
160 Bolivia $ 2,900 2005 est.
161 Nicaragua $ 2,900 2005 est.
162 Marshall Islands $ 2,900 2005 est.
163 Vanuatu $ 2,900 2003 est.
164 Honduras $ 2,900 2005 est.
165 Vietnam $ 2,800 2005 est.
166 Mayotte $ 2,600 2003 est.
167 Papua New Guinea $ 2,600 2005 est.
168 Cambodia $ 2,500 2005 est.
169 Lesotho $ 2,500 2005 est.
170 Saint Helena $ 2,500 1998 est.
171 Ghana $ 2,500 2005 est.
172 Pakistan $ 2,400 2005 est.
173 Cameroon $ 2,300 2005 est.
174 Micronesia, Federated States of $ 2,300 2005 est.
175 Mauritania $ 2,200 2005 est.
176 Tonga $ 2,200 2005 est.
177 Bangladesh $ 2,100 2005 est.
178 Zimbabwe $ 2,100 2005 est.
179 Samoa $ 2,100 2005 est.
180 Sudan $ 2,100 2005 est.
181 Guinea $ 2,000 2005 est.
182 Kyrgyzstan $ 2,000 2005 est.
183 Laos $ 2,000 2005 est.
184 Gambia, The $ 1,900 2005 est.
185 Kiribati $ 1,900 2004 est.
186 Moldova $ 1,900 2005 est.
187 Mongolia $ 1,900 2005 est.
188 Uzbekistan $ 1,900 2005 est.
189 Iraq $ 1,800 2005 est.
190 Senegal $ 1,800 2005 est.
191 Uganda $ 1,800 2005 est.
192 Burma $ 1,700 2005 est.
193 Haiti $ 1,700 2005 est.
194 Korea, North $ 1,700 2005 est.
195 Cote d''Ivoire $ 1,600 2005 est.
196 Togo $ 1,600 2005 est.
197 Tuvalu $ 1,600 2002 est.
198 Rwanda $ 1,500 2005 est.
199 Bhutan $ 1,400 2003 est.
200 Nepal $ 1,400 2005 est.
201 Nigeria $ 1,400 2005 est.
202 Chad $ 1,400 2005 est.
203 Congo, Republic of the $ 1,300 2005 est.
204 Mozambique $ 1,300 2005 est.
205 Mali $ 1,200 2005 est.
206 Burkina Faso $ 1,200 2005 est.
207 Sao Tome and Principe $ 1,200 2003 est.
208 Tajikistan $ 1,200 2005 est.
209 Benin $ 1,100 2005 est.
210 Kenya $ 1,100 2005 est.
211 West Bank $ 1,100 2003 est.
212 Central African Republic $ 1,100 2005 est.
213 Djibouti $ 1,000 2005 est.
214 Eritrea $ 1,000 2005 est.
215 Tokelau $ 1,000 1993 est.
216 Niger $ 1,000 2005 est.
217 Ethiopia $ 900 2005 est.
218 Zambia $ 900 2005 est.
219 Yemen $ 900 2005 est.
220 Liberia $ 900 2005 est.
221 Madagascar $ 900 2005 est.
222 Afghanistan $ 800 2004 est.
223 East Timor $ 800 2005 est.
224 Sierra Leone $ 800 2005 est.
225 Guinea-Bissau $ 800 2005 est.
226 Burundi $ 700 2005 est.
227 Tanzania $ 700 2005 est.
228 Congo, Democratic Republic of the $ 700 2005 est.
229 Solomon Islands $ 600 2005 est.
230 Comoros $ 600 2005 est.
231 Somalia $ 600 2005 est.
232 Malawi $ 600 2005 est.
233 Gaza Strip $ 600 2003 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2034
Rank Country Military expenditures - percent of GDP(%) Date of Information
1 Eritrea 17.70 2005 est.
2 Jordan 11.40 2005 est.
3 Oman 11.40 2003
4 Qatar 10.00
5 Saudi Arabia 10.00 2002
6 Angola 8.80 2005 est.
7 Israel 7.70 2005 est.
8 Liberia 7.50 2005 est.
9 Madagascar 7.20 2005 est.
10 Armenia 6.50 FY01
11 Yemen 6.40 2005 est.
12 Macedonia 6.00
13 Syria 5.90
14 Burundi 5.60 2005 est.
15 Maldives 5.50 2005 est.
16 Turkey 5.30 2003
17 Brunei 5.10 2003 est.
18 Morocco 5.00 2003 est.
19 Bahrain 4.90 2005 est.
20 Singapore 4.90
21 Bosnia and Herzegovina 4.50
22 China 4.30 2005 est.
23 Djibouti 4.30 2005 est.
24 Greece 4.30 2003
25 Kuwait 4.20 2005 est.
26 United States 4.06 2005 est.
27 Zimbabwe 4.00 2005 est.
28 Libya 3.90
29 Tajikistan 3.90 FY01
30 Pakistan 3.90 2005 est.
31 Cyprus 3.80
32 Chile 3.50 2005 est.
33 Botswana 3.40 2005 est.
34 Ethiopia 3.40 2005 est.
35 Gabon 3.40 2005 est.
36 Egypt 3.40 2004
37 Turkmenistan 3.40
38 Colombia 3.40 FY01
39 Iran 3.30 2003 est.
40 Algeria 3.20 2005 est.
41 United Arab Emirates 3.10
42 Guinea-Bissau 3.10 2005 est.
43 Lebanon 3.10 2004
44 Cambodia 3.00
45 Comoros 3.00 2005 est.
46 Sudan 3.00 2004
47 Indonesia 3.00 2004
48 Guinea 2.90 2005 est.
49 Rwanda 2.90 2005 est.
50 Australia 2.70 2005 est.
51 Azerbaijan 2.60
52 Korea, South 2.60 2005 est.
53 Sri Lanka 2.60 2005 est.
54 France 2.60 2005 est.
55 Bulgaria 2.60 2003
56 Honduras 2.55 2005 est.
57 India 2.50 2005 est.
58 Vietnam 2.50
59 Romania 2.47 2002
60 Taiwan 2.40 2005 est.
61 United Kingdom 2.40 2003
62 Croatia 2.39 2002 est.
63 Benin 2.30 2005 est.
64 Namibia 2.30 2005 est.
65 Portugal 2.30 2003
66 Fiji 2.20 FY02
67 Uganda 2.20 2005 est.
68 Mongolia 2.20 FY02
69 Burma 2.10
70 Uruguay 2.10 2005 est.
71 Seychelles 2.10 2005 est.
72 Lesotho 2.10 2005 est.
73 Equatorial Guinea 2.10 2005 est.
74 Malaysia 2.03
75 Ecuador 2.00 2005 est.
76 World 2.00
77 Uzbekistan 2.00
78 Finland 2.00 FY98/99
79 Estonia 2.00 2002 est.
80 Lithuania 1.90 FY01
81 Mali 1.90 2005 est.
82 Norway 1.90 2003
83 Slovakia 1.87 2005
84 Czech Republic 1.81
85 Bangladesh 1.80 2005 est.
86 Zambia 1.80 2005 est.
87 Thailand 1.80 2003
88 Italy 1.80 2004
89 Cuba 1.80 2005 est.
90 Hungary 1.75 2002 est.
91 Poland 1.71 2002
92 Afghanistan 1.70 2005 est.
93 Sierra Leone 1.70 2005 est.
94 Slovenia 1.70 FY00
95 Belize 1.70 2005 est.
96 Cote d''Ivoire 1.60 2005 est.
97 Togo 1.60 2005 est.
98 Netherlands 1.60 2004
99 Kenya 1.60 2005 est.
100 Congo, Democratic Republic of the 1.50 2005 est.
101 Tunisia 1.50
102 Sweden 1.50 2005 est.
103 South Africa 1.50 2005 est.
104 Nepal 1.50 2005 est.
105 Cameroon 1.50 2005 est.
106 Germany 1.50 2003
107 Denmark 1.50 2004
108 Albania 1.49 FY02
109 Bolivia 1.40 2005 est.
110 Senegal 1.40 2005 est.
111 Swaziland 1.40 2005 est.
112 Ukraine 1.40 FY02
113 Papua New Guinea 1.40 FY02
114 Peru 1.40 2003 est.
115 Niger 1.40 2005 est.
116 Belarus 1.40 FY02
117 Kyrgyzstan 1.40 FY01
118 Mauritania 1.40 2005 est.
119 Congo, Republic of the 1.40 2005 est.
120 Argentina 1.30 FY00
121 Burkina Faso 1.30 2005 est.
122 Mozambique 1.30 2005 est.
123 Belgium 1.30 2003
124 Brazil 1.30 2005 est.
125 Latvia 1.20 FY01
126 Spain 1.20 2003
127 Venezuela 1.20 2005 est.
128 Canada 1.10 2003
129 Bhutan 1.00 2005 est.
130 Switzerland 1.00 FY01
131 Panama 1.00 2005 est.
132 New Zealand 1.00 FY02
133 Malta 1.00 2005 est.
134 Japan 1.00 2005 est.
135 Central African Republic 1.00 2005 est.
136 Chad 1.00 2005 est.
137 El Salvador 1.00 2005 est.
138 Austria 0.90 2004
139 Somalia 0.90 2005 est.
140 Philippines 0.90 2005 est.
141 Paraguay 0.90 2003 est.
142 Luxembourg 0.90 2003
143 Kazakhstan 0.90 FY02
144 Haiti 0.90 2003 est.
145 Guyana 0.90 2003 est.
146 Ireland 0.90 FY00/01
147 Ghana 0.80 2005 est.
148 Sao Tome and Principe 0.80 2005 est.
149 Malawi 0.80 2005 est.
150 Mexico 0.80 2005 est.
151 Nigeria 0.80 2005 est.
152 Cape Verde 0.70 2005 est.
153 Nicaragua 0.70 2005 est.
154 Suriname 0.70 2003 est.
155 Trinidad and Tobago 0.60 2003 est.
156 Georgia 0.59
157 Guatemala 0.50 2005 est.
158 Costa Rica 0.40 2005 est.
159 Jamaica 0.40 2003 est.
160 Gambia, The 0.40 2005 est.
161 Laos 0.40 2005 est.
162 Moldova 0.40 FY02
163 Mauritius 0.20 2005 est.
164 Tanzania 0.20 2005 est.
165 Bermuda 0.11
166 Dominican Republic 0.00 2002 est.
167 Iceland 0.00
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2038
Rank Country Electricity - production(kWh) Date of Information
1 World 16,540,000,000,000 2003 est.
2 United States 3,892,000,000,000 2003
3 European Union 2,925,000,000,000 2002 est.
4 China 2,190,000,000,000 2004
5 Japan 1,017,000,000,000 2003
6 Russia 931,000,000,000 2004
7 Canada 566,300,000,000 2003
8 Germany 558,100,000,000 2003
9 India 556,800,000,000 2003
10 France 536,900,000,000 2003
11 Brazil 387,500,000,000 2004
12 United Kingdom 369,900,000,000 2003
13 Korea, South 342,100,000,000 2004
14 Italy 270,100,000,000 2003
15 Spain 247,300,000,000 2003
16 Australia 237,000,000,000 2004
17 Taiwan 218,300,000,000 2004
18 South Africa 215,900,000,000 2003
19 Mexico 209,200,000,000 2003
20 Ukraine 181,300,000,000 2004
21 Poland 150,800,000,000 2004
22 Saudi Arabia 145,100,000,000 2003
23 Iran 142,300,000,000 2003
24 Turkey 133,600,000,000 2003
25 Sweden 127,900,000,000 2003
26 Indonesia 120,200,000,000 2004
27 Thailand 114,700,000,000 2003
28 Norway 105,600,000,000 2003
29 Netherlands 95,000,000,000 2004
30 Venezuela 87,440,000,000 2003
31 Argentina 87,160,000,000 2004
32 Czech Republic 84,330,000,000 2004
33 Egypt 84,260,000,000 2003
34 Finland 79,610,000,000 2003
35 Malaysia 79,280,000,000 2003
36 Belgium 78,770,000,000 2003
37 Pakistan 76,920,000,000 2003
38 Austria 63,690,000,000 2004
39 Switzerland 63,400,000,000 2003
40 Kazakhstan 60,330,000,000 2003
41 Romania 57,000,000,000 2004
42 Greece 54,560,000,000 2003
43 Paraguay 51,290,000,000 2003
44 Colombia 50,430,000,000 2003
45 Philippines 47,820,000,000 2003
46 Uzbekistan 46,520,000,000 2003
47 Vietnam 46,200,000,000 2004
48 Chile 45,300,000,000 2003
49 United Arab Emirates 45,120,000,000 2004
50 Bulgaria 45,000,000,000 2004
51 Portugal 44,320,000,000 2003
52 Israel 44,240,000,000 2003
53 Denmark 43,320,000,000 2003
54 New Zealand 39,820,000,000 2003
55 Kuwait 38,190,000,000 2003
56 Hong Kong 37,300,000,000 2004
57 Singapore 36,800,000,000 2004
58 Serbia 33,870,000,000 2004
59 Hungary 32,210,000,000 2003
60 Iraq 31,700,000,000 2005
61 Slovakia 30,570,000,000 2004
62 Belarus 30,000,000,000 2004
63 Syria 29,530,000,000 2003 est.
64 Algeria 26,990,000,000 2003 est.
65 Ireland 23,410,000,000 2003
66 Puerto Rico 23,030,000,000 2003
67 Peru 22,680,000,000 2003 est.
68 Azerbaijan 20,000,000,000 2003
69 Lithuania 19,000,000,000 2004
70 Korea, North 18,750,000,000 2003
71 Bangladesh 17,420,000,000 2003
72 Morocco 17,350,000,000 2003
73 Tajikistan 16,500,000,000 2004
74 Cuba 15,650,000,000 2004
75 Nigeria 15,590,000,000 2003
76 Mozambique 15,140,000,000 2003
77 Libya 14,400,000,000 2003
78 Slovenia 14,020,000,000 2003
79 Kyrgyzstan 13,770,000,000 2003
80 Dominican Republic 12,600,000,000 2003
81 Tunisia 11,560,000,000 2003
82 Turkmenistan 11,410,000,000 2004 est.
83 Ecuador 11,270,000,000 2003
84 Croatia 11,150,000,000 2003
85 Lebanon 10,670,000,000 2003
86 Bosnia and Herzegovina 10,510,000,000 2003
87 Estonia 10,304,000,000 2004
88 Oman 10,300,000,000 2003
89 Qatar 9,735,000,000 2003
90 Zimbabwe 8,877,000,000 2003
91 Georgia 8,634,000,000 2003
92 Iceland 8,619,000,000 2004
93 Uruguay 8,611,000,000 2003
94 Zambia 8,347,000,000 2003
95 Costa Rica 7,726,000,000 2003
96 Jordan 7,517,000,000 2003
97 Burma 7,393,000,000 2003
98 Bahrain 7,345,000,000 2003
99 Sri Lanka 7,308,000,000 2003
100 Guatemala 6,898,000,000 2003
101 Armenia 6,317,000,000 2005
102 Macedonia 6,271,000,000 2005
103 Trinidad and Tobago 6,076,000,000 2003
104 Congo, Democratic Republic of the 6,036,000,000 2003
105 Albania 5,680,000,000 2004
106 Panama 5,398,000,000 2003
107 Ghana 5,356,000,000 2003
108 Cote d''Ivoire 5,127,000,000 2003
109 Kenya 4,342,000,000 2003
110 Honduras 4,338,000,000 2003
111 Bolivia 4,250,000,000 2003
112 El Salvador 4,158,000,000 2004
113 Latvia 3,970,000,000 2003
114 Yemen 3,848,000,000 2003 est.
115 Cyprus 3,801,000,000 2003
116 Laos 3,767,000,000 2003
117 Jamaica 3,717,000,000 2004
118 Mongolia 3,240,000,000 2005 est.
119 Luxembourg 3,203,000,000 2005 est.
120 Sudan 3,165,000,000 2003
121 Tanzania 3,152,000,000 2003
122 Cameroon 2,988,000,000 2003
123 Moldova 2,942,000,000 2003
124 Brunei 2,906,000,000 2004
125 Nicaragua 2,887,000,000 2004
126 Montenegro 2,864,000,000 2005 est.
127 Nepal 2,565,000,000 2005
128 Angola 2,240,000,000 2004
129 Malta 2,082,000,000 2003
130 Ethiopia 2,058,000,000 2003
131 Suriname 2,014,000,000 2003
132 Mauritius 1,941,000,000 2003
133 Macau 1,893,000,000 2004
134 Bhutan 1,882,000,000 2003
135 Bahamas, The 1,810,000,000 2003
136 Uganda 1,729,000,000 2003
137 Papua New Guinea 1,592,000,000 2003
138 New Caledonia 1,581,000,000 2003
139 Gabon 1,487,000,000 2003
140 Namibia 1,464,000,000 2003
141 Senegal 1,332,000,000 2003
142 Malawi 1,296,000,000 2003
143 Martinique 1,205,000,000 2003
144 Reunion 1,190,000,000 2003
145 Guadeloupe 1,165,000,000 2003
146 Virgin Islands 1,040,000,000 2003
147 Netherlands Antilles 1,017,000,000 2003
148 Afghanistan 905,000,000 2003
149 Botswana 891,000,000 2004
150 Guam 840,100,000 2003
151 Madagascar 825,400,000 2003
152 Mali 820,000,000 2003
153 Barbados 819,000,000 2003
154 Guyana 779,000,000 2003
155 Fiji 775,700,000 2003
156 Guinea 775,000,000 2003
157 Aruba 770,000,000 2003
158 Bermuda 682,500,000 2005
159 Haiti 546,000,000 2003
160 Liberia 509,400,000 2003
161 French Polynesia 493,700,000 2003
162 French Guiana 465,200,000 2003
163 Cayman Islands 441,900,000 2003
164 Swaziland 392,000,000 2003
165 Burkina Faso 375,600,000 2003
166 Lesotho 350,000,000 2003
167 Congo, Republic of the 343,000,000 2003
168 Saint Lucia 281,000,000 2003
169 Eritrea 270,900,000 2003
170 Sierra Leone 260,600,000 2003
171 Faroe Islands 260,200,000 2003
172 Greenland 242,200,000 2003
173 Seychelles 241,300,000 2003
174 Djibouti 240,000,000 2003
175 Somalia 235,600,000 2003
176 Niger 230,000,000 2003
177 Micronesia, Federated States of 192,000,000 2002
178 Mauritania 185,600,000 2003
179 Togo 165,900,000 2003
180 Grenada 159,800,000 2003
181 Burundi 141,300,000 2003
182 Gambia, The 140,000,000 2003
183 Maldives 135,000,000 2003
184 American Samoa 130,000,000 2003
185 Cambodia 123,700,000 2003
186 Belize 120,000,000 2003
187 Chad 120,000,000 2003
188 Samoa 116,000,000 2003
189 Saint Kitts and Nevis 111,700,000 2003
190 Gibraltar 106,100,000 2003
191 Central African Republic 106,000,000 2003
192 Antigua and Barbuda 100,000,000 2003
193 Rwanda 98,000,000','2acf5071689ef6036653fd5fb9ab2abb762e344537347e68da48ba61d716d0f8','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa591add67d25fab2eea82c28cff2b165efdf7daa4835999902696ebf3e73537',2006,'ZW','Zimbabwe','communications',8,'2003
194 Saint Vincent and the Grenadines 95,000,000 2003
195 Western Sahara 85,000,000 2003
196 Dominica 69,980,000 2003
197 Benin 69,000,000 2003
198 Guinea-Bissau 56,000,000 2003
199 Solomon Islands 55,000,000 2003
200 Cape Verde 44,150,000 2003
201 Saint Pierre and Miquelon 44,150,000 2003
202 Vanuatu 41,000,000 2003
203 British Virgin Islands 34,550,000 2003
204 Tonga 34,000,000 2003
205 Equatorial Guinea 29,430,000 2003
206 Cook Islands 28,000,000 2003
207 Nauru 23,000,000 2003
208 Falkland Islands (Islas Malvinas) 22,230,000 2003
209 Comoros 18,000,000 2003
210 Sao Tome and Principe 15,000,000 2003
211 Kiribati 12,000,000 2003
212 Saint Helena 5,000,000 2003
213 Turks and Caicos Islands 5,000,000 2003
214 Niue 3,000,000 2003
215 Montserrat 2,000,000 2003
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2042
Rank Country Electricity - consumption(kWh) Date of Information
1 World 15,450,000,000,000 2003 est.
2 United States 3,656,000,000,000 2003
3 European Union 2,711,000,000,000 2002 est.
4 China 2,170,000,000,000 2004
5 Japan 946,300,000,000 2003
6 Russia 811,500,000,000 2004
7 Canada 520,900,000,000 2003
8 India 519,000,000,000 2003
9 Germany 510,400,000,000 2003
10 France 433,300,000,000 2003
11 Brazil 359,600,000,000 2004
12 United Kingdom 346,100,000,000 2003
13 Korea, South 321,100,000,000 2004
14 Italy 302,200,000,000 2003
15 Spain 231,200,000,000 2003
16 Australia 221,000,000,000 2004
17 Taiwan 206,100,000,000 2004
18 South Africa 197,400,000,000 2003
19 Mexico 193,900,000,000 2003
20 Ukraine 176,000,000,000 2004
21 Turkey 140,300,000,000 2005
22 Saudi Arabia 134,900,000,000 2003
23 Iran 132,100,000,000 2003
24 Sweden 131,800,000,000 2003
25 Poland 121,300,000,000 2004
26 Thailand 107,300,000,000 2003
27 Norway 106,100,000,000 2003
28 Indonesia 105,400,000,000 2004
29 Netherlands 101,600,000,000 2003
30 Argentina 82,970,000,000 2004
31 Venezuela 81,320,000,000 2003
32 Belgium 79,660,000,000 2003
33 Finland 78,940,000,000 2003
34 Egypt 78,160,000,000 2003
35 Malaysia 73,630,000,000 2003
36 Pakistan 71,540,000,000 2003
37 Austria 64,780,000,000 2004
38 Czech Republic 57,120,000,000 2004
39 Switzerland 55,860,000,000 2003
40 Greece 53,500,000,000 2005 est.
41 Kazakhstan 52,550,000,000 2003
42 Vietnam 52,000,000,000 2004
43 Colombia 48,830,000,000 2003
44 Uzbekistan 48,450,000,000 2003
45 Philippines 44,480,000,000 2003
46 Chile 44,130,000,000 2003
47 Portugal 44,010,000,000 2003
48 Israel 39,670,000,000 2003
49 Hong Kong 39,220,000,000 2004
50 United Arab Emirates 38,320,000,000 2002
51 Romania 37,500,000,000 2003
52 New Zealand 37,030,000,000 2003
53 Hungary 36,960,000,000 2003
54 Kuwait 35,520,000,000 2003
55 Belarus 34,300,000,000 2004
56 Iraq 33,300,000,000 2005
57 Singapore 33,200,000,000 2004
58 Denmark 31,680,000,000 2003
59 Syria 28,260,000,000 2003 est.
60 Bulgaria 25,100,000,000 2004
61 Algeria 24,900,000,000 2003 est.
62 Slovakia 24,800,000,000 2004
63 Ireland 22,970,000,000 2003
64 Puerto Rico 21,420,000,000 2003
65 Peru 21,090,000,000 2003
66 Azerbaijan 20,250,000,000 2003
67 Morocco 17,580,000,000 2003
68 Korea, North 17,430,000,000 2003
69 Bangladesh 16,200,000,000 2003
70 Croatia 15,810,000,000 2003
71 Tajikistan 15,050,000,000 2003
72 Nigeria 14,460,000,000 2003
73 Libya 13,390,000,000 2003
74 Cuba 13,270,000,000 2004
75 Slovenia 12,520,000,000 2003
76 Lithuania 12,079,000,000 2004
77 Dominican Republic 11,710,000,000 2003
78 Zimbabwe 11,220,000,000 2003
79 Tunisia 10,760,000,000 2003
80 Lebanon 10,670,000,000 2003
81 Ecuador 10,550,000,000 2003
82 Mozambique 10,460,000,000 2003
83 Georgia 9,800,000,000 2005
84 Oman 9,582,000,000 2003
85 Qatar 9,053,000,000 2003
86 Bosnia and Herzegovina 8,849,000,000 2003
87 Turkmenistan 8,847,000,000 2002
88 Kyrgyzstan 8,783,000,000 2003
89 Iceland 8,619,000,000 2004
90 Jordan 7,959,000,000 2003
91 Macedonia 7,933,000,000 2005
92 Uruguay 7,762,000,000 2003
93 Costa Rica 7,120,000,000 2003
94 Burma 6,875,000,000 2003
95 Bahrain 6,830,000,000 2003
96 Sri Lanka 6,796,000,000 2003
97 Albania 6,760,000,000 2004
98 Estonia 6,260,000,000 2004
99 Luxembourg 6,140,000,000 2005 est.
100 Guatemala 6,025,000,000 2003
101 Latvia 5,839,000,000 2003
102 Trinidad and Tobago 5,651,000,000 2003
103 Zambia 5,345,000,000 2003
104 Ghana 5,081,000,000 2003
105 Panama 4,870,000,000 2003
106 El Salvador 4,450,000,000 2004
107 Armenia 4,374,000,000 2005
108 Honduras 4,369,000,000 2003
109 Congo, Democratic Republic of the 4,324,000,000 2003
110 Kenya 4,238,000,000 2003
111 Bolivia 3,963,000,000 2003
112 Cyprus 3,535,000,000 2003
113 Paraguay 3,528,000,000 2003
114 Cote d''Ivoire 3,418,000,000 2003
115 Mongolia 3,370,000,000 2005 est.
116 Laos 3,298,000,000 2003
117 Moldova 3,036,000,000 2003
118 Jamaica 2,974,000,000 2004
119 Tanzania 2,959,000,000 2003
120 Sudan 2,943,000,000 2003
121 Yemen 2,827,000,000 2003 est.
122 Cameroon 2,779,000,000 2003
123 Brunei 2,726,000,000 2004
124 Botswana 2,641,000,000 2004
125 Namibia 2,372,000,000 2003
126 Malta 1,936,000,000 2003
127 Ethiopia 1,914,000,000 2003
128 Angola 1,900,000,000 2004
129 Macau 1,899,000,000 2004
130 Suriname 1,873,000,000 2003
131 Nepal 1,850,000,000 2005
132 Nicaragua 1,848,000,000 2004
133 Mauritius 1,805,000,000 2003
134 Bahamas, The 1,683,000,000 2003
135 Papua New Guinea 1,481,000,000 2003
136 New Caledonia 1,470,000,000 2003
137 Uganda 1,448,000,000 2003
138 Gabon 1,383,000,000 2003
139 Senegal 1,239,000,000 2003
140 Malawi 1,206,000,000 2003
141 Swaziland 1,161,000,000 2003
142 Martinique 1,120,000,000 2003
143 Reunion 1,107,000,000 2003
144 Guadeloupe 1,084,000,000 2003
145 Afghanistan 1,042,000,000 2003
146 Virgin Islands 967,300,000 2003
147 Netherlands Antilles 945,800,000 2003
148 Guam 781,300,000 2003
149 Madagascar 767,700,000 2003
150 Mali 762,600,000 2003
151 Barbados 761,700,000 2003
152 Guyana 724,500,000 2003
153 Fiji 721,400,000 2003
154 Guinea 720,800,000 2003
155 Aruba 716,100,000 2003
156 Togo 654,300,000 2003
157 Jersey 630,100,000 2004 est.
158 Congo, Republic of the 619,000,000 2003
159 Bermuda 616,700,000 2005
160 Benin 538,200,000 2003
161 Haiti 507,800,000 2003
162 Liberia 473,800,000 2003
163 French Polynesia 459,200,000 2003
164 French Guiana 432,600,000 2003
165 Cayman Islands 411,000,000 2003
166 Lesotho 363,500,000 2003
167 Burkina Faso 349,300,000 2003
168 Niger 263,900,000 2003
169 Saint Lucia 261,400,000 2003
170 Eritrea 251,900,000 2003
171 Bhutan 250,300,000 2003
172 Sierra Leone 242,400,000 2003
173 Faroe Islands 242,000,000 2003
174 Greenland 225,300,000 2003
175 Seychelles 224,400,000 2003
176 Djibouti 223,200,000 2003
177 Somalia 219,100,000 2003
178 Micronesia, Federated States of 178,600,000 2002
179 Mauritania 172,600,000 2003
180 Grenada 148,600,000 2003
181 Burundi 141,400,000 2003
182 Gambia, The 130,200,000 2003
183 Maldives 125,600,000 2003
184 Rwanda 121,100,000 2003
185 American Samoa 120,900,000 2003
186 Cambodia 115,000,000 2003
187 Belize 111,600,000 2003
188 Chad 111,600,000 2003
189 Samoa 107,900,000 2003
190 Saint Kitts and Nevis 103,900,000 2003
191 Gibraltar 98,690,000 2003
192 Central African Republic 98,580,000 2003
193 Antigua and Barbuda 93,000,000 2003
194 Saint Vincent and the Grenadines 88,350,000 2003
195 Mayotte 87,790,000
196 Western Sahara 83,700,000 2003
197 Dominica 65,090,000 2003
198 Guinea-Bissau 52,080,000 2003
199 Solomon Islands 51,150,000 2003
200 Anguilla 42,600,000
201 Cape Verde 41,060,000 2003
202 Saint Pierre and Miquelon 41,060,000 2003
203 Vanuatu 38,130,000 2003
204 Cook Islands 34,460,000 2005 est.
205 British Virgin Islands 32,130,000 2003
206 Tonga 31,620,000 2003
207 Equatorial Guinea 27,370,000 2003
208 Nauru 21,390,000 2003
209 Falkland Islands (Islas Malvinas) 20,680,000 2003
210 Comoros 16,740,000 2003
211 Sao Tome and Principe 13,950,000 2003
212 Kiribati 11,160,000 2003
213 Saint Helena 4,650,000 2003
214 Turks and Caicos Islands 4,650,000 2003
215 Niue 2,790,000 2003
216 Montserrat 1,860,000 2003
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2053
Rank Country Airports Date of Information
1 World 49,024 2006
2 United States 14,858 2006
3 Brazil 4,276 2006
4 Mexico 1,839 2006
5 Russia 1,623 2006
6 Argentina 1,381 2006
7 Canada 1,337 2006
8 Bolivia 1,084 2006
9 Colombia 984 2006
10 Paraguay 881 2006
11 South Africa 731 2006
12 Indonesia 662 2006
13 Papua New Guinea 582 2006
14 Germany 554 2006
15 Ukraine 499 2006
16 China 486 2006
17 France 477 2006
18 United Kingdom 471 2006
19 Australia 455 2006
20 Guatemala 450 2006
21 Zimbabwe 403 2006
22 Venezuela 375 2006
23 Chile 363 2006
24 Ecuador 359 2006
25 India 341 2006
26 Iran 321 2006
27 Peru 268 2006
28 Philippines 256 2006
29 Sweden 255 2006
30 Angola 244 2006
31 Congo, Democratic Republic of the 234 2006
32 Kenya 225 2006
33 Bulgaria 217 2006
34 Saudi Arabia 208 2006
35 Nicaragua 176 2006
36 Japan 175 2006
37 Cuba 170 2006
38 Mozambique 158 2006
39 Costa Rica 157 2006
40 Spain 157 2006
41 Kazakhstan 150 2006
42 Finland 148 2006
43 Algeria 142 2006
44 Libya 141 2006
45 Pakistan 139 2006
46 Oman 137 2006
47 Namibia 137 2006
48 Italy 133 2006
49 Tanzania 124 2006
50 Poland 122 2006
51 Czech Republic 121 2006
52 New Zealand 118 2006
53 Malaysia 117 2006
54 Panama 117 2006
55 Turkey 117 2006
56 Honduras 116 2006
57 Madagascar 116 2006
58 Zambia 111 2006
59 Iraq 110 2006
60 Thailand 108 2006
61 Korea, South 107 2006
62 Norway 99 2006
63 Iceland 98 2006
64 Denmark 92 2006
65 Syria 92 2006
66 Lithuania 91 2006
67 Guyana 90 2006
68 Egypt 88 2006
69 Sudan 88 2006
70 Belarus 86 2006
71 Botswana 85 2006
72 Burma 85 2006
73 Ethiopia 84 2006
74 Greece 82 2006
75 Korea, North 77 2006
76 El Salvador 75 2006
77 Nigeria 69 2006
78 Croatia 68 2006
79 Portugal 66 2006
80 Somalia 65 2006
81 Switzerland 65 2006
82 Bahamas, The 64 2006
83 Uruguay 64 2006
84 Romania 61 2006
85 Uzbekistan 61 2006
86 Morocco 60 2006
87 Gabon 56 2006
88 Austria 55 2006
89 Israel 53 2006
90 Liberia 53 2006
91 Chad 52 2006
92 French Polynesia 51 2006
93 Central African Republic 50 2006
94 Nepal 48 2006
95 Cameroon 47 2006
96 Suriname 47 2006
97 Afghanistan 46 2006
98 Latvia 46 2006
99 Yemen 46 2006
100 Hungary 46 2006
101 Laos 44 2006
102 Mongolia 44 2006
103 Belgium 43 2006
104 Belize 43 2006
105 Malawi 42 2006
106 Taiwan 42 2006
107 Tajikistan 40 2006
108 Serbia 39 2006
109 United Arab Emirates 37 2006
110 Kyrgyzstan 37 2006
111 Azerbaijan 36 2006
112 Ireland 36 2006
113 Slovakia 36 2006
114 Solomon Islands 35 2006
115 Cote d''Ivoire 35 2006
116 Jamaica 35 2006
117 Burkina Faso 34 2006
118 Dominican Republic 33 2006
119 Congo, Republic of the 32 2006
120 Vietnam 32 2006
121 Vanuatu 31 2006
122 Uganda 31 2006
123 Puerto Rico 30 2006
124 Tunisia 30 2006
125 Mali 29 2006
126 Turkmenistan 29 2006
127 Bosnia and Herzegovina 28 2006
128 Fiji 28 2006
129 Lesotho 28 2006
130 Guinea-Bissau 28 2006
131 Niger 28 2006
132 Netherlands 27 2006
133 Mauritania 25 2006
134 New Caledonia 25 2006
135 Estonia 24 2006
136 Georgia 23 2006
137 Antarctica 20 2006
138 Senegal 20 2006
139 Cambodia 20 2006
140 Kiribati 19 2006
141 Swaziland 18 2006
142 Eritrea 17 2006
143 Macedonia 17 2006
144 Jordan 17 2006
145 Bangladesh 16 2006
146 Sri Lanka 16 2006
147 Cyprus 16 2006
148 Guinea 16 2006
149 Marshall Islands 15 2006
150 Seychelles 15 2006
151 Greenland 14 2006
152 Slovenia 14 2006
153 Armenia 13 2006
154 Djibouti 13 2006
155 Ghana 12 2006
156 Haiti 12 2006
157 Moldova 12 2006
158 Albania 11 2006
159 Western Sahara 11 2006
160 French Guiana 11 2006
161 Sierra Leone 10 2006
162 Cook Islands 9 2006
163 Rwanda 9 2006
164 Guadeloupe 9 2006
165 Singapore 9 2006
166 Togo 9 2006
167 Burundi 8 2006
168 East Timor 8 2006
169 Turks and Caicos Islands 8 2006
170 Cape Verde 7 2006
171 Lebanon 7 2006
172 Kuwait 7 2006
173 Micronesia, Federated States of 6 2006
174 Saint Vincent and the Grenadines 6 2006
175 Tonga 6 2006
176 Trinidad and Tobago 6 2006
177 Mauritius 6 2006
178 Benin 5 2006
179 Northern Mariana Islands 5 2006
180 Falkland Islands (Islas Malvinas) 5 2006
181 Maldives 5 2006
182 Qatar 5 2006
183 Netherlands Antilles 5 2006
184 Montenegro 5 2006
185 Guam 5 2006
186 Comoros 4 2006
187 Equatorial Guinea 4 2006
188 Samoa 4 2006
189 Svalbard 4 2006
190 Antigua and Barbuda 3 2006
191 West Bank 3 2006
192 British Virgin Islands 3 2006
193 Palau 3 2006
194 Spratly Islands 3 2006
195 Midway Islands 3 2006
196 Hong Kong 3 2006
197 Grenada 3 2006
198 Bahrain 3 2006
199 Anguilla 3 2006
200 American Samoa 3 2006
201 Cayman Islands 3 2006
202 Bhutan 2 2006
203 Montserrat 2 2006
204 Wallis and Futuna 2 2006
205 Virgin Islands 2 2006
206 Sao Tome and Principe 2 2006
207 Saint Lucia 2 2006
208 Saint Kitts and Nevis 2 2006
209 Saint Pierre and Miquelon 2 2006
210 Reunion 2 2006
211 Martinique 2 2006
212 Brunei 2 2006
213 Dominica 2 2006
214 Gaza Strip 2 2006
215 Luxembourg 2 2006
216 Guernsey 2 2006
217 Aruba 1 2006
218 Barbados 1 2006
219 Wake Island 1 2006
220 Tuvalu 1 2006
221 Tromelin Island 1 2006
222 Saint Helena 1 2006
223 Paracel Islands 1 2006
224 Mayotte 1 2006
225 Macau 1 2006
226 Palmyra Atoll 1 2006
227 Christmas Island 1 2006
228 Juan de Nova Island 1 2006
229 Johnston Atoll 1 2006
230 Jan Mayen 1 2006
231 Jersey 1 2006
232 British Indian Ocean Territory 1 2006
233 Isle of Man 1 2006
234 Nauru 1 2006
235 Norfolk Island 1 2006
236 Niue 1 2006
237 Malta 1 2006
238 Glorioso Islands 1 2006
239 Gibraltar 1 2006
240 Gambia, The 1 2006
241 Faroe Islands 1 2006
242 Europa Island 1 2006
243 Cocos (Keeling) Islands 1 2006
244 Bermuda 1 2006
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2054
Rank Country Birth rate(births/1,000 population) Date of Information
1 Niger 50.73 2006 est.
2 Mali 49.82 2006 est.
3 Uganda 47.35 2006 est.
4 Afghanistan 46.60 2006 est.
5 Sierra Leone 45.76 2006 est.
6 Chad 45.73 2006 est.
7 Burkina Faso 45.62 2006 est.
8 Somalia 45.13 2006 est.
9 Angola 45.11 2006 est.
10 Liberia 44.77 2006 est.
11 Congo, Democratic Republic of the 43.69 2006 est.
12 Malawi 43.13 2006 est.
13 Yemen 42.89 2006 est.
14 Congo, Republic of the 42.57 2006 est.
15 Burundi 42.22 2006 est.
16 Guinea 41.76 2006 est.
17 Madagascar 41.41 2006 est.
18 Zambia 41.00 2006 est.
19 Mauritania 40.99 2006 est.
20 Mayotte 40.95 2006 est.
21 Nigeria 40.43 2006 est.
22 Rwanda 40.37 2006 est.
23 Sao Tome and Principe 40.25 2006 est.
24 Kenya 39.72 2006 est.
25 Djibouti 39.53 2006 est.
26 Gaza Strip 39.45 2006 est.
27 Gambia, The 39.37 2006 est.
28 Benin 38.85 2006 est.
29 Ethiopia 37.98 2006 est.
30 Tanzania 37.71 2006 est.
31 Guinea-Bissau 37.22 2006 est.
32 Togo 37.01 2006 est.
33 Comoros 36.93 2006 est.
34 Haiti 36.44 2006 est.
35 Oman 36.24 2006 est.
36 Gabon 36.16 2006 est.
37 Equatorial Guinea 35.59 2006 est.
38 Laos 35.49 2006 est.
39 Mozambique 35.18 2006 est.
40 Cote d''Ivoire 35.11 2006 est.
41 Maldives 34.81 2006 est.
42 Sudan 34.53 2006 est.
43 Eritrea 34.33 2006 est.
44 Central African Republic 33.91 2006 est.
45 Cameroon 33.89 2006 est.
46 Bhutan 33.65 2006 est.
47 Marshall Islands 33.05 2006 est.
48 Senegal 32.78 2006 est.
49 Tajikistan 32.65 2006 est.
50 Iraq 31.98 2006 est.
51 West Bank 31.67 2006 est.
52 Nepal 30.98 2006 est.
53 Kiribati 30.65 2006 est.
54 Ghana 30.52 2006 est.
55 Solomon Islands 30.01 2006 est.
56 Guatemala 29.88 2006 est.
57 Bangladesh 29.80 2006 est.
58 Pakistan 29.74 2006 est.
59 Papua New Guinea 29.36 2006 est.
60 Saudi Arabia 29.34 2006 est.
61 Paraguay 29.10 2006 est.
62 Belize 28.84 2006 est.
63 Honduras 28.24 2006 est.
64 Zimbabwe 28.01 2006 est.
65 Syria 27.76 2006 est.
66 Turkmenistan 27.61 2006 est.
67 Swaziland 27.41 2006 est.
68 East Timor 26.99 2006 est.
69 Cambodia 26.90 2006 est.
70 El Salvador 26.61 2006 est.
71 Libya 26.49 2006 est.
72 Uzbekistan 26.36 2006 est.
73 Tonga 25.37 2006 est.
74 Philippines 24.89 2006 est.
75 Cape Verde 24.87 2006 est.
76 Nauru 24.76 2006 est.
77 Lesotho 24.75 2006 est.
78 Micronesia, Federated States of 24.68 2006 est.
79 Nicaragua 24.51 2006 est.
80 Namibia 24.32 2006 est.
81 Bolivia 23.30 2006 est.
82 Dominican Republic 23.22 2006 est.
83 Botswana 23.08 2006 est.
84 Egypt 22.94 2006 est.
85 Malaysia 22.86 2006 est.
86 Kyrgyzstan 22.80 2006 est.
87 Vanuatu 22.72 2006 est.
88 Fiji 22.55 2006 est.
89 American Samoa 22.46 2006 est.
90 Ecuador 22.29 2006 est.
91 Tuvalu 22.18 2006 est.
92 Grenada 22.08 2006 est.
93 India 22.01 2006 est.
94 Morocco 21.98 2006 est.
95 Kuwait 21.94 2006 est.
96 Turks and Caicos Islands 21.84 2006 est.
97 Panama 21.74 2006 est.
98 Mongolia 21.59 2006 est.
99 Jordan 21.25 2006 est.
100 Cook Islands 21.00 2001 census
101 Jamaica 20.82 2006 est.
102 Azerbaijan 20.74 2006 est.
103 Mexico 20.69 2006 est.
104 Colombia 20.48 2006 est.
105 Peru 20.48 2006 est.
106 French Guiana 20.46 2006 est.
107 Indonesia 20.34 2006 est.
108 World 20.05 2006 est.
109 Saint Lucia 19.68 2006 est.
110 Northern Mariana Islands 19.43 2006 est.
111 United Arab Emirates 18.96 2006 est.
112 Reunion 18.90 2006 est.
113 Brunei 18.79 2006 est.
114 Guam 18.79 2006 est.
115 Venezuela 18.71 2006 est.
116 Lebanon 18.52 2006 est.
117 Costa Rica 18.32 2006 est.
118 Guyana 18.28 2006 est.
119 South Africa 18.20 2006 est.
120 New Caledonia 18.11 2006 est.
121 Palau 18.03 2006 est.
122 Suriname 18.02 2006 est.
123 Saint Kitts and Nevis 18.02 2006 est.
124 Israel 17.97 2006 est.
125 Burma 17.91 2006 est.
126 Bahrain 17.80 2006 est.
127 Montserrat 17.59 2006 est.
128 Bahamas, The 17.57 2006 est.
129 Algeria 17.14 2006 est.
130 Iran 17.00 2006 est.
131 Antigua and Barbuda 16.93 2006 est.
132 Vietnam 16.86 2006 est.
133 Argentina 16.73 2006 est.
134 French Polynesia 16.68 2006 est.
135 Turkey 16.62 2006 est.
136 Brazil 16.56 2006 est.
137 Samoa 16.43 2006 est.
138 Saint Vincent and the Grenadines 16.18 2006 est.
139 Seychelles 16.03 2006 est.
140 Kazakhstan 16.00 2006 est.
141 Greenland 15.93 2006 est.
142 Moldova 15.70 2006 est.
143 Qatar 15.56 2006 est.
144 Korea, North 15.54 2006 est.
145 Tunisia 15.52 2006 est.
146 Sri Lanka 15.51 2006 est.
147 Mauritius 15.43 2006 est.
148 Dominica 15.27 2006 est.
149 Chile 15.23 2006 est.
150 Albania 15.11 2006 est.
151 Guadeloupe 15.05 2006 est.
152 British Virgin Islands 14.89 2006 est.
153 Netherlands Antilles 14.78 2006 est.
154 Ireland 14.45 2006 est.
155 Anguilla 14.17 2006 est.
156 United States 14.14 2006 est.
157 Faroe Islands 14.05 2006 est.
158 Virgin Islands 13.96 2006 est.
159 Uruguay 13.91 2006 est.
160 Thailand 13.87 2006 est.
161 New Zealand 13.76 2006 est.
162 Martinique 13.74 2006 est.
163 Iceland 13.64 2006 est.
164 Saint Pierre and Miquelon 13.52 2006 est.
165 China 13.25 2006 est.
166 Trinidad and Tobago 12.90 2006 est.
167 Puerto Rico 12.77 2006 est.
168 Cayman Islands 12.74 2006 est.
169 Barbados 12.71 2006 est.
170 Montenegro 12.60 2004
171 Cyprus 12.56 2006 est.
172 Taiwan 12.56 2006 est.
173 Australia 12.14 2006 est.
174 Saint Helena 12.13 2006 est.
175 Armenia 12.07 2006 est.
176 Macedonia 12.02 2006 est.
177 France 11.99 2006 est.
178 Luxembourg 11.94 2006 est.
179 Cuba 11.89 2006 est.
180 Norway 11.46 2006 est.
181 Bermuda 11.40 2006 est.
182 Belarus 11.16 2006 est.
183 Denmark 11.13 2006 est.
184 Isle of Man 11.05 2006 est.
185 Aruba 11.03 2006 est.
186 Netherlands 10.90 2006 est.
187 Canada 10.78 2006 est.
188 Gibraltar 10.74 2006 est.
189 Portugal 10.72 2006 est.
190 United Kingdom 10.71 2006 est.
191 Romania 10.70 2006 est.
192 Slovakia 10.65 2006 est.
193 Finland 10.45 2006 est.
194 Georgia 10.41 2006 est.
195 Belgium 10.38 2006 est.
196 Sweden 10.27 2006 est.
197 Malta 10.22 2006 est.
198 Liechtenstein 10.21 2006 est.
199 Spain 10.06 2006 est.
200 Estonia 10.04 2006 est.
201 San Marino 10.02 2006 est.
202 European Union 10.00 2006 est.
203 Korea, South 10.00 2006 est.
204 Russia 9.95 2006 est.
205 Poland 9.85 2006 est.
206 Hungary 9.72 2006 est.
207 Switzerland 9.71 2006 est.
208 Greece 9.68 2006 est.
209 Bulgaria 9.65 2006 est.
210 Croatia 9.61 2006 est.
211 Japan 9.37 2006 est.
212 Singapore 9.34 2006 est.
213 Jersey 9.30 2006 est.
214 Latvia 9.24 2006 est.
215 Monaco 9.19 2006 est.
216 Czech Republic 9.02 2006 est.
217 Slovenia 8.98 2006 est.
218 Ukraine 8.82 2006 est.
219 Guernsey 8.81 2006 est.
220 Bosnia and Herzegovina 8.77 2006 est.
221 Lithuania 8.75 2006 est.
222 Austria 8.74 2006 est.
223 Italy 8.72 2006 est.
224 Andorra 8.71 2006 est.
225 Macau 8.48 2006 est.
226 Germany 8.25 2006 est.
227 Hong Kong 7.29 2006 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2066
Rank Country Death rate(deaths/1,000 population) Date of Information
1 Swaziland 29.74 2006 est.
2 Botswana 29.50 2006 est.
3 Lesotho 28.71 2006 est.
4 Angola 24.20 2006 est.
5 Liberia 23.10 2006 est.
6 Sierra Leone 23.03 2006 est.
7 South Africa 22.00 2006 est.
8 Zimbabwe 21.84 2006 est.
9 Mozambique 21.35 2006 est.
10 Niger 20.91 2006 est.
11 Afghanistan 20.34 2006 est.
12 Zambia 19.93 2006 est.
13 Malawi 19.33 2006 est.
14 Djibouti 19.31 2006 est.
15 Namibia 18.86 2006 est.
16 Central African Republic 18.65 2006 est.
17 Nigeria 16.94 2006 est.
18 Mali 16.89 2006 est.
19 Somalia 16.63 2006 est.
20 Guinea-Bissau 16.53 2006 est.
21 Tanzania 16.39 2006 est.
22 Chad 16.38 2006 est.
23 Rwanda 16.09 2006 est.
24 Burkina Faso 15.60 2006 est.
25 Guinea 15.48 2006 est.
26 Equatorial Guinea 15.06 2006 est.
27 Ethiopia 14.86 2006 est.
28 Cote d''Ivoire 14.84 2006 est.
29 Russia 14.65 2006 est.
30 Ukraine 14.39 2006 est.
31 Bulgaria 14.27 2006 est.
32 Belarus 14.02 2006 est.
33 Kenya 14.02 2006 est.
34 Latvia 13.66 2006 est.
35 Cameroon 13.47 2006 est.
36 Burundi 13.46 2006 est.
37 Congo, Democratic Republic of the 13.27 2006 est.
38 Estonia 13.25 2006 est.
39 Hungary 13.11 2006 est.
40 Congo, Republic of the 12.93 2006 est.
41 Monaco 12.91 2006 est.
42 Bhutan 12.70 2006 est.
43 Moldova 12.64 2006 est.
44 Gambia, The 12.25 2006 est.
45 Gabon 12.25 2006 est.
46 Uganda 12.24 2006 est.
47 Benin 12.22 2006 est.
48 Haiti 12.17 2006 est.
49 Mauritania 12.16 2006 est.
50 Romania 11.77 2006 est.
51 Laos 11.55 2006 est.
52 Croatia 11.48 2006 est.
53 Isle of Man 11.19 2006 est.
54 Madagascar 11.11 2006 est.
55 Lithuania 10.98 2006 est.
56 Germany 10.62 2006 est.
57 Czech Republic 10.59 2006 est.
58 Trinidad and Tobago 10.57 2006 est.
59 Portugal 10.50 2006 est.
60 Italy 10.40 2006 est.
61 Denmark 10.36 2006 est.
62 Slovenia 10.31 2006 est.
63 Sweden 10.31 2006 est.
64 Belgium 10.27 2006 est.
65 Greece 10.24 2006 est.
66 United Kingdom 10.13 2006 est.
67 European Union 10.10 2006 est.
68 Guernsey 10.01 2006 est.
69 Poland 9.89 2006 est.
70 Finland 9.86 2006 est.
71 Burma 9.83 2006 est.
72 Togo 9.83 2006 est.
73 Austria 9.76 2006 est.
74 Azerbaijan 9.75 2006 est.
75 Ghana 9.72 2006 est.
76 Spain 9.72 2006 est.
77 Eritrea 9.60 2006 est.
78 Slovakia 9.45 2006 est.
79 Kazakhstan 9.42 2006 est.
80 Senegal 9.42 2006 est.
81 Norway 9.40 2006 est.
82 Gibraltar 9.31 2006 est.
83 Nepal 9.31 2006 est.
84 Jersey 9.28 2006 est.
85 Georgia 9.23 2006 est.
86 Montenegro 9.20 2004
87 Japan 9.16 2006 est.
88 France 9.14 2006 est.
89 Cambodia 9.06 2006 est.
90 Bahamas, The 9.05 2006 est.
91 Uruguay 9.05 2006 est.
92 Sudan 8.97 2006 est.
93 Macedonia 8.77 2006 est.
94 Faroe Islands 8.70 2006 est.
95 Netherlands 8.68 2006 est.
96 Barbados 8.67 2006 est.
97 World 8.67 2006 est.
98 Turkmenistan 8.60 2006 est.
99 Switzerland 8.49 2006 est.
100 Luxembourg 8.41 2006 est.
101 Saint Kitts and Nevis 8.33 2006 est.
102 Yemen 8.30 2006 est.
103 Guyana 8.28 2006 est.
104 Bangladesh 8.27 2006 est.
105 Bosnia and Herzegovina 8.27 2006 est.
106 Kiribati 8.26 2006 est.
107 United States 8.26 2006 est.
108 Tajikistan 8.25 2006 est.
109 Armenia 8.23 2006 est.
110 Pakistan 8.23 2006 est.
111 Comoros 8.20 2006 est.
112 India 8.18 2006 est.
113 San Marino 8.17 2006 est.
114 Malta 8.10 2006 est.
115 Greenland 7.84 200','7aefabfb7f407a8f93b5637916d938b889537118090be561997be3e868c85371','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64e8a7c73c63f999f4df68cad2b06557c153a0cb7d825eb6674157073f32bf37',2006,'ZW','Zimbabwe','communications',9,'6 est.
116 Uzbekistan 7.84 2006 est.
117 Ireland 7.82 2006 est.
118 Vanuatu 7.82 2006 est.
119 Canada 7.80 2006 est.
120 Bermuda 7.74 2006 est.
121 Mayotte 7.70 2006 est.
122 Cyprus 7.68 2006 est.
123 Puerto Rico 7.65 2006 est.
124 Argentina 7.55 2006 est.
125 Bolivia 7.53 2006 est.
126 New Zealand 7.53 2006 est.
127 Australia 7.51 2006 est.
128 Suriname 7.27 2006 est.
129 Papua New Guinea 7.25 2006 est.
130 Cuba 7.22 2006 est.
131 Liechtenstein 7.18 2006 est.
132 Korea, North 7.13 2006 est.
133 Tuvalu 7.11 2006 est.
134 Montserrat 7.10 2006 est.
135 Kyrgyzstan 7.08 2006 est.
136 Maldives 7.06 2006 est.
137 Thailand 7.04 2006 est.
138 China 6.97 2006 est.
139 Mongolia 6.95 2006 est.
140 Grenada 6.88 2006 est.
141 Mauritius 6.86 2006 est.
142 Saint Pierre and Miquelon 6.83 2006 est.
143 Palau 6.80 2006 est.
144 Dominica 6.73 2006 est.
145 Iceland 6.72 2006 est.
146 Nauru 6.70 2006 est.
147 Aruba 6.68 2006 est.
148 Samoa 6.62 2006 est.
149 Cape Verde 6.55 2006 est.
150 Saint Helena 6.53 2006 est.
151 Sri Lanka 6.52 2006 est.
152 Jamaica 6.52 2006 est.
153 Martinique 6.48 2006 est.
154 Taiwan 6.48 2006 est.
155 Sao Tome and Principe 6.47 2006 est.
156 Netherlands Antilles 6.45 2006 est.
157 Virgin Islands 6.43 2006 est.
158 Hong Kong 6.29 2006 est.
159 Seychelles 6.29 2006 est.
160 Andorra 6.25 2006 est.
161 Indonesia 6.25 2006 est.
162 East Timor 6.24 2006 est.
163 Peru 6.23 2006 est.
164 Vietnam 6.22 2006 est.
165 Lebanon 6.21 2006 est.
166 Israel 6.18 2006 est.
167 Brazil 6.17 2006 est.
168 Guadeloupe 6.09 2006 est.
169 Saint Vincent and the Grenadines 5.98 2006 est.
170 Turkey 5.97 2006 est.
171 Korea, South 5.85 2006 est.
172 Chile 5.81 2006 est.
173 El Salvador 5.78 2006 est.
174 Dominican Republic 5.73 2006 est.
175 Belize 5.72 2006 est.
176 New Caledonia 5.69 2006 est.
177 Fiji 5.65 2006 est.
178 Colombia 5.58 2006 est.
179 Morocco 5.58 2006 est.
180 Iran 5.55 2006 est.
181 Reunion 5.49 2006 est.
182 Philippines 5.41 2006 est.
183 Antigua and Barbuda 5.37 2006 est.
184 Iraq 5.37 2006 est.
185 Panama 5.36 2006 est.
186 Anguilla 5.34 2006 est.
187 Honduras 5.28 2006 est.
188 Tonga 5.28 2006 est.
189 Egypt 5.23 2006 est.
190 Albania 5.22 2006 est.
191 Guatemala 5.20 2006 est.
192 Tunisia 5.13 2006 est.
193 Saint Lucia 5.08 2006 est.
194 Malaysia 5.05 2006 est.
195 Venezuela 4.92 2006 est.
196 Cayman Islands 4.89 2006 est.
197 French Guiana 4.88 2006 est.
198 Syria 4.81 2006 est.
199 Marshall Islands 4.78 2006 est.
200 Micronesia, Federated States of 4.75 2006 est.
201 Mexico 4.74 2006 est.
202 Qatar 4.72 2006 est.
203 French Polynesia 4.69 2006 est.
204 Algeria 4.61 2006 est.
205 Paraguay 4.49 2006 est.
206 Guam 4.48 2006 est.
207 Macau 4.47 2006 est.
208 Nicaragua 4.45 2006 est.
209 British Virgin Islands 4.42 2006 est.
210 United Arab Emirates 4.40 2006 est.
211 Costa Rica 4.36 2006 est.
212 Singapore 4.28 2006 est.
213 Ecuador 4.23 2006 est.
214 Turks and Caicos Islands 4.21 2006 est.
215 Bahrain 4.14 2006 est.
216 Solomon Islands 3.92 2006 est.
217 West Bank 3.92 2006 est.
218 Oman 3.81 2006 est.
219 Gaza Strip 3.80 2006 est.
220 Libya 3.48 2006 est.
221 Brunei 3.45 2006 est.
222 American Samoa 3.27 2006 est.
223 Jordan 2.65 2006 est.
224 Saudi Arabia 2.58 2006 est.
225 Kuwait 2.41 2006 est.
226 Northern Mariana Islands 2.29 2006 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2067
Rank Country Military expenditures - dollar figure Date of Information
1 United States $ 518,100,000,000 2005 est.
2 China $ 81,480,000,000 2005 est.
3 France $ 45,000,000,000 2005
4 Japan $ 44,310,000,000 2005 est.
5 United Kingdom $ 42,836,500,000 2003
6 Germany $ 35,063,000,000 2003
7 Italy $ 28,182,800,000 2003
8 Korea, South $ 21,060,000,000 2005 est.
9 India $ 19,040,000,000 2005 est.
10 Saudi Arabia $ 18,000,000,000 2002
11 Australia $ 17,840,000,000 2005 est.
12 Turkey $ 12,155,000,000 2003
13 Brazil $ 9,940,000,000 2005 est.
14 Spain $ 9,906,500,000 2003
15 Canada $ 9,801,700,000 2003
16 Israel $ 9,450,000,000 2005 est.
17 Netherlands $ 9,408,000,000 2004
18 Taiwan $ 7,930,000,000 2005 est.
19 Mexico $ 6,070,000,000 2005 est.
20 Greece $ 5,890,000,000 2004
21 Sweden $ 5,510,000,000 2005 est.
22 Svalbard $ 5,501,000,000
23 Korea, North $ 5,217,400,000 FY02
24 Singapore $ 4,470,000,000
25 Argentina $ 4,300,000,000
26 Iran $ 4,300,000,000 2003 est.
27 Pakistan $ 4,260,000,000 2005 est.
28 Norway $ 4,033,500,000 2003
29 Belgium $ 3,999,000,000 2003
30 Chile $ 3,910,000,000 2005 est.
31 South Africa $ 3,550,000,000 2005 est.
32 Poland $ 3,500,000,000 2002
33 Portugal $ 3,497,800,000 2003
34 Colombia $ 3,300,000,000
35 Denmark $ 3,271,600,000 2003
36 Kuwait $ 3,010,000,000 2005 est.
37 Algeria $ 3,000,000,000 2005 est.
38 Switzerland $ 2,548,000,000 FY01
39 Egypt $ 2,440,000,000 2003
40 Morocco $ 2,310,000,000 2003 est.
41 Montenegro $ 2,306,000,000
42 Czech Republic $ 2,170,000,000 2004
43 Angola $ 2,000,000,000 2005 est.
44 Finland $ 1,800,000,000 FY98/99
45 Thailand $ 1,775,000,000
46 Malaysia $ 1,690,000,000
47 Venezuela $ 1,610,000,000 2005 est.
48 United Arab Emirates $ 1,600,000,000
49 Austria $ 1,497,000,000 FY01/02
50 Jordan $ 1,400,000,000 2005 est.
51 Iraq $ 1,340,000,000 2005 est.
52 Indonesia $ 1,300,000,000 2004
53 Libya $ 1,300,000,000
54 New Zealand $ 1,147,000,000 FY03/04
55 Hungary $ 1,080,000,000 2002 est.
56 Bangladesh $ 1,010,000,000 2005 est.
57 Western Sahara $ 992,200,000
58 Yemen $ 992,200,000 2005 est.
59 Romania $ 985,000,000 2002
60 Syria $ 858,000,000
61 Philippines $ 836,900,000 2005 est.
62 Peru $ 829,300,000 2003 est.
63 Nigeria $ 737,600,000 2005 est.
64 Qatar $ 723,000,000
65 Ireland $ 700,000,000 FY00/01
66 Cuba $ 694,000,000 2005 est.
67 Ecuador $ 650,000,000 2005 est.
68 Vietnam $ 650,000,000
69 Bahrain $ 627,700,000 2005 est.
70 Croatia $ 620,000,000 2004
71 Ukraine $ 617,900,000 FY02
72 Sri Lanka $ 606,200,000 2005 est.
73 Sudan $ 587,000,000 2004
74 Lebanon $ 540,600,000 2004
75 Belarus $ 420,500,000 2006
76 Slovakia $ 406,000,000 2002
77 Cyprus $ 384,000,000
78 Uruguay $ 371,200,000 2005 est.
79 Slovenia $ 370,000,000 FY00
80 Bulgaria $ 356,000,000 FY02
81 Tunisia $ 356,000,000
82 Madagascar $ 329,000,000 2005 est.
83 Botswana $ 325,500,000 2005 est.
84 Ethiopia $ 295,900,000 2005 est.
85 Brunei $ 290,700,000 2003 est.
86 Kenya $ 280,500,000 2005 est.
87 Gabon $ 253,500,000 2005 est.
88 Oman $ 252,990,000 2004
89 Cote d''Ivoire $ 246,600,000 2005 est.
90 Bosnia and Herzegovina $ 234,300,000
91 Luxembourg $ 231,600,000 2003
92 Lithuania $ 230,800,000 FY01
93 Cameroon $ 230,200,000 2005 est.
94 Kazakhstan $ 221,800,000 FY02
95 Eritrea $ 220,100,000 2005 est.
96 Macedonia $ 200,000,000
97 Uzbekistan $ 200,000,000
98 Turks and Caicos Islands $ 192,800,000
99 Uganda $ 192,800,000 2005 est.
100 Guatemala $ 169,800,000 2005 est.
101 El Salvador $ 161,700,000 2005 est.
102 Estonia $ 155,000,000 2002 est.
103 Equatorial Guinea $ 152,200,000 2005 est.
104 Panama $ 150,000,000 2005 est.
105 Namibia $ 149,500,000 2005 est.
106 Armenia $ 135,000,000 FY01
107 Bolivia $ 130,000,000 2005 est.
108 Zimbabwe $ 124,700,000 2005 est.
109 Afghanistan $ 122,400,000 2005 est.
110 Zambia $ 121,700,000 2005 est.
111 Azerbaijan $ 121,000,000
112 Guinea $ 119,700,000 2005 est.
113 Senegal $ 117,300,000 2005 est.
114 Cambodia $ 112,000,000
115 Mali $ 106,300,000 2005 est.
116 Nepal $ 104,900,000 2005 est.
117 Congo, Democratic Republic of the $ 103,700,000 2005 est.
118 Benin $ 100,900,000 2005 est.
119 Turkmenistan $ 90,000,000
120 Latvia $ 87,000,000 FY01
121 Congo, Republic of the $ 85,220,000 2005 est.
122 Ghana $ 83,650,000 2005 est.
123 Costa Rica $ 83,460,000 2005 est.
124 Mozambique $ 78,030,000 2005 est.
125 Burkina Faso $ 74,830,000 2005 est.
126 Chad $ 68,950,000 2005 est.
127 Liberia $ 67,400,000 2005 est.
128 Trinidad and Tobago $ 66,720,000 2003 est.
129 Tokelau $ 66,720,000
130 Albania $ 56,500,000 FY02
131 Rwanda $ 53,660,000 2005 est.
132 Paraguay $ 53,100,000 2003 est.
133 Honduras $ 52,800,000 2005 est.
134 Maldives $ 45,070,000 2005 est.
135 Niger $ 44,780,000 2005 est.
136 Burundi $ 43,900,000 2005 est.
137 Swaziland $ 41,600,000 2005 est.
138 Lesotho $ 41,100,000 2005 est.
139 Burma $ 39,000,000
140 Malta $ 38,168,000 2005 est.
141 Fiji $ 36,000,000 2004
142 Tajikistan $ 35,400,000 FY01
143 Nicaragua $ 32,270,000 2005 est.
144 Jamaica $ 31,170,000 2003 est.
145 Togo $ 29,980,000 2005 est.
146 Djibouti $ 29,050,000 2005 est.
147 Haiti $ 25,960,000 2003 est.
148 Mongolia $ 23,100,000 FY02
149 Georgia $ 23,000,000
150 Somalia $ 22,340,000 2005 est.
151 Tanzania $ 21,200,000 2005 est.
152 Mauritania $ 19,320,000 2005 est.
153 Kyrgyzstan $ 19,200,000 FY01
154 Belize $ 19,000,000 2005 est.
155 Papua New Guinea $ 16,900,000 2003
156 Central African Republic $ 16,370,000 2005 est.
157 Malawi $ 15,810,000 2005 est.
158 Serbia $ 14,850,000
159 Seychelles $ 14,850,000 2005 est.
160 Sierra Leone $ 14,250,000 2005 est.
161 Comoros $ 12,870,000 2005 est.
162 Mauritius $ 12,040,000 2005 est.
163 Laos $ 11,040,000 2005 est.
164 Guinea-Bissau $ 9,460,000 2005 est.
165 Moldova $ 8,700,000 2004
166 Bhutan $ 8,290,000 2005 est.
167 Suriname $ 7,500,000 2003 est.
168 Cape Verde $ 7,180,000 2005 est.
169 Guyana $ 6,480,000 2003 est.
170 East Timor $ 4,400,000 FY03
171 Bermuda $ 4,030,000 2001
172 Gambia, The $ 1,550,000 2005 est.
173 San Marino $ 700,000 FY00/01
174 Sao Tome and Principe $ 581,729 2005 est.
175 Dominican Republic $ 0 2002 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2078
Rank Country Exports Date of Information
1 World $ 10,330,000,000,000 2004 est.
2 European Union $ 1,318,000,000,000 2004
3 Germany $ 1,016,000,000,000 2005 est.
4 United States $ 927,500,000,000 2005 est.
5 China $ 752,200,000,000 2005 est.
6 Japan $ 550,500,000,000 2005 est.
7 France $ 443,400,000,000 2005 est.
8 United Kingdom $ 372,700,000,000 2005 est.
9 Italy $ 371,900,000,000 2005 est.
10 Netherlands $ 365,100,000,000 2005 est.
11 Canada $ 364,800,000,000 2005 est.
12 Korea, South $ 288,200,000,000 2005 est.
13 Hong Kong $ 286,300,000,000 2005 est.
14 Belgium $ 269,600,000,000 2005 est.
15 Russia $ 245,000,000,000 2005 est.
16 Mexico $ 213,700,000,000 2005 est.
17 Singapore $ 204,800,000,000 2005 est.
18 Spain $ 194,300,000,000 2005 est.
19 Taiwan $ 189,400,000,000 2005 est.
20 Saudi Arabia $ 165,000,000,000 2005 est.
21 Switzerland $ 148,600,000,000 2005 est.
22 Malaysia $ 147,100,000,000 2005 est.
23 Sweden $ 126,600,000,000 2005 est.
24 Austria $ 122,500,000,000 2005 est.
25 Brazil $ 115,100,000,000 2005 est.
26 Norway $ 111,200,000,000 2005 est.
27 Thailand $ 105,800,000,000 2005 est.
28 United Arab Emirates $ 103,100,000,000 2005 est.
29 Australia $ 103,000,000,000 2005 est.
30 Ireland $ 102,000,000,000 2005 est.
31 Poland $ 92,720,000,000 2005 est.
32 Denmark $ 84,950,000,000 2005 est.
33 Indonesia $ 83,640,000,000 2005 est.
34 Czech Republic $ 78,370,000,000 2005 est.
35 India $ 76,230,000,000 2005 est.
36 Turkey $ 72,490,000,000 2005 est.
37 Finland $ 67,880,000,000 2005 est.
38 Hungary $ 61,750,000,000 2005 est.
39 Iran $ 55,420,000,000 2005 est.
40 Venezuela $ 52,730,000,000 2005 est.
41 Nigeria $ 52,160,000,000 2005 est.
42 South Africa $ 50,910,000,000 2005 est.
43 Algeria $ 49,590,000,000 2005 est.
44 Puerto Rico $ 46,900,000,000 2001
45 Kuwait $ 44,430,000,000 2005 est.
46 Philippines $ 41,250,000,000 2005 est.
47 Israel $ 40,140,000,000 2005 est.
48 Argentina $ 40,000,000,000 2005 est.
49 Portugal $ 38,800,000,000 2005 est.
50 Ukraine $ 38,220,000,000 2005 est.
51 Chile $ 38,030,000,000 2005 est.
52 Vietnam $ 32,230,000,000 2005 est.
53 Romania $ 31,200,000,000 2005
54 Libya $ 30,790,000,000 2005 est.
55 Slovakia $ 30,700,000,000 2005 est.
56 Kazakhstan $ 30,090,000,000 2005 est.
57 Angola $ 26,800,000,000 2005 est.
58 Qatar $ 24,900,000,000 2005 est.
59 New Zealand $ 22,210,000,000 2005 est.
60 Colombia $ 19,300,000,000 2005 est.
61 Oman $ 19,010,000,000 2005 est.
62 Greece $ 18,540,000,000 2005 est.
63 Slovenia $ 18,530,000,000 2005 est.
64 Iraq $ 17,780,000,000 2004
65 Belarus $ 16,140,000,000 2005 est.
66 Peru $ 15,950,000,000 2005 est.
67 Pakistan $ 14,850,000,000 2005 est.
68 Egypt $ 14,330,000,000 2005 est.
69 Luxembourg $ 13,390,000,000 2005 est.
70 Lithuania $ 11,800,000,000 2005 est.
71 Bulgaria $ 11,670,000,000 2005 est.
72 Bahrain $ 11,170,000,000 2005 est.
73 Croatia $ 10,300,000,000 2005 est.
74 Tunisia $ 10,300,000,000 2005 est.
75 Morocco $ 9,472,000,000 2005 est.
76 Bangladesh $ 9,372,000,000 2005 est.
77 Ecuador $ 9,224,000,000 2005 est.
78 Trinidad and Tobago $ 9,161,000,000 2005 est.
79 Panama $ 7,481,000,000 2005 est.
80 Estonia $ 7,439,000,000 2005 est.
81 Costa Rica $ 7,005,000,000 2005 est.
82 Sudan $ 6,989,000,000 2005 est.
83 Equatorial Guinea $ 6,727,000,000 2005 est.
84 Cote d''Ivoire $ 6,490,000,000 2005 est.
85 Sri Lanka $ 6,442,000,000 2005 est.
86 Yemen $ 6,387,000,000 2005 est.
87 Syria $ 6,344,000,000 2005 est.
88 Azerbaijan $ 6,117,000,000 2005 est.
89 Dominican Republic $ 5,818,000,000 2005 est.
90 Gabon $ 5,813,000,000 2005 est.
91 Uzbekistan $ 5,000,000,000 2005 est.
92 Latvia $ 4,860,000,000 2005 est.
93 Turkmenistan $ 4,700,000,000 2005 est.
94 Serbia $ 4,553,000,000 2005 est.
95 Brunei $ 4,514,000,000 2004 est.
96 Virgin Islands $ 4,234,000,000
97 Jordan $ 4,226,000,000 2005 est.
98 Guatemala $ 3,940,000,000 2005 est.
99 Botswana $ 3,680,000,000 2005 est.
100 El Salvador $ 3,586,000,000 2005 est.
101 Uruguay $ 3,550,000,000 2005 est.
102 Macau $ 3,465,000,000 2004
103 Cameroon $ 3,236,000,000 2005 est.
104 Iceland $ 3,215,000,000 2005 est.
105 Kenya $ 3,173,000,000 2005 est.
106 Paraguay $ 3,130,000,000 2005 est.
107 Burma $ 3,111,000,000 2004
108 Chad $ 3,016,000,000 2005 est.
109 Ghana $ 2,911,000,000 2005 est.
110 Papua New Guinea $ 2,833,000,000 2005 est.
111 Malta $ 2,744,000,000 2005 est.
112 Bosnia and Herzegovina $ 2,700,000,000 2005 est.
113 Cambodia $ 2,663,000,000 2005 est.
114 Liechtenstein $ 2,470,000,000 1996
115 Cuba $ 2,388,000,000 2005 est.
116 Bolivia $ 2,371,000,000 2005 est.
117 Congo, Republic of the $ 2,209,000,000 2005 est.
118 Netherlands Antilles $ 2,076,000,000 2004 est.
119 Macedonia $ 2,047,000,000 2005 est.
120 Namibia $ 2,040,000,000 2005 est.
121 Swaziland $ 1,991,000,000 2005 est.
122 Mauritius $ 1,949,000,000 2005 est.
123 Zambia $ 1,947,000,000 2005 est.
124 Lebanon $ 1,782,000,000 2005 est.
125 Honduras $ 1,726,000,000 2005 est.
126 Mozambique $ 1,690,000,000 2005 est.
127 Zimbabwe $ 1,644,000,000 2005 est.
128 Jamaica $ 1,608,000,000 2004 est.
129 Tanzania $ 1,581,000,000 2005 est.
130 Nicaragua $ 1,550,000,000 2005 est.
131 Senegal $ 1,526,000,000 2005 est.
132 Bermuda $ 1,469,000,000 2004 est.
133 Georgia $ 1,400,000,000 2005 est.
134 Korea, North $ 1,275,000,000 2004 est.
135 Cyprus $ 1,237,000,000 2005 est.
136 Congo, Democratic Republic of the $ 1,108,000,000 2004 est.
137 Moldova $ 1,040,000,000 2005 est.
138 New Caledonia $ 999,000,000 2004 est.
139 Madagascar $ 951,000,000 2005 est.
140 Tajikistan $ 950,000,000 2005 est.
141 Liberia $ 910,000,000 2004 est.
142 Suriname $ 881,000,000 2004 est.
143 Mongolia $ 852,000,000 2004 est.
144 Benin $ 826,900,000 2005 est.
145 Nepal $ 822,000,000 2005 est.
146 Armenia $ 800,000,000 2005 est.
147 Mauritania $ 784,000,000 2004 est.
148 Togo $ 768,000,000 2005 est.
149 Uganda $ 768,000,000 2005 est.
150 Kyrgyzstan $ 759,000,000 2005 est.
151 Fiji $ 719,600,000 2005
152 Monaco $ 656,500,000
153 Albania $ 650,100,000 2005 est.
154 Guinea $ 612,100,000 2005 est.
155 Ethiopia $ 612,000,000 2005 est.
156 Lesotho $ 602,800,000 2005 est.
157 Guyana $ 587,200,000 2005 est.
158 Faroe Islands $ 533,000,000 2004 est.
159 Greenland $ 480,000,000 2004 est.
160 Afghanistan $ 471,000,000 2005 est.
161 Bahamas, The $ 469,300,000 2004 est.
162 American Samoa $ 445,600,000 FY04 est.
163 Martinique $ 404,200,000 2002
164 Burkina Faso $ 395,000,000 2005 est.
165 Haiti $ 390,700,000 2005 est.
166 Laos $ 379,000,000 2005 est.
167 Malawi $ 364,000,000 2005 est.
168 Belize $ 349,900,000 2005 est.
169 Mali $ 323,000,000 2004 est.
170 Seychelles $ 312,100,000 2005 est.
171 Gibraltar $ 271,000,000 2004 est.
172 Gaza Strip $ 270,000,000 2003
173 West Bank $ 270,000,000 2003
174 Djibouti $ 250,000,000 2004 est.
175 Reunion $ 248,500,000 2002
176 Somalia $ 241,000,000 2004 est.
177 Niger $ 222,000,000 2004 est.
178 French Polynesia $ 211,000,000 2005 est.
179 Barbados $ 209,000,000 2004 est.
180 Sierra Leone $ 185,000,000 2004 est.
181 Montenegro $ 171,300,000 2003
182 Solomon Islands $ 171,000,000 2004 est.
183 Turks and Caicos Islands $ 169,200,000 2000
184 Bhutan $ 154,000,000 2000 est.
185 Guadeloupe $ 147,800,000 2002
186 Andorra $ 145,000,000 2004
187 Gambia, The $ 140,300,000 2005 est.
188 French Guiana $ 137,500,000 2003
189 Central African Republic $ 131,000,000 2004 est.
190 Falkland Islands (Islas Malvinas) $ 125,000,000 2004 est.
191 Maldives $ 123,000,000 2004 est.
192 Guinea-Bissau $ 116,000,000 2004 est.
193 Rwanda $ 98,000,000 2005 est.
194 Samoa $ 94,000,000 2004 est.
195 Saint Lucia $ 82,000,000 2004 est.
196 Aruba $ 80,000,000 2004 est.
197 Dominica $ 74,000,000 2004 est.
198 Cape Verde $ 73,350,000 2005 est.
199 Saint Kitts and Nevis $ 70,000,000 2004 est.
200 Cyprus $ 69,000,000 2005 est.
201 Burundi $ 52,000,000 2005 est.
202 Antigua and Barbuda $ 46,810,000 2004 est.
203 Guam $ 45,000,000 2004 est.
204 Grenada $ 40,000,000 2004 est.
205 Saint Vincent and the Grenadines $ 37,000,000 2004 est.
206 Vanuatu $ 34,110,000 2004 est.
207 Comoros $ 34,000,000 2004 est.
208 Tonga $ 34,000,000 2004 est.
209 Eritrea $ 33,580,000 2005 est.
210 British Virgin Islands $ 25,300,000 2002
211 Saint Helena $ 19,000,000 2004 est.
212 Kiribati $ 17,000,000 2004 est.
213 Anguilla $ 14,560,000 2005 est.
214 Micronesia, Federated States of $ 14,000,000 2004 est.
215 East Timor $ 10,000,000 2005 est.
216 Marshall Islands $ 9,100,000 2000
217 Sao Tome and Principe $ 8,000,000 2005 est.
218 Saint Pierre and Miquelon $ 7,000,000 2004 est.
219 Palau $ 5,882,000 2004 est.
220 Cook Islands $ 5,222,000 2005
221 Mayotte $ 4,850,000 2004
222 Cayman Islands $ 2,520,000 2004
223 Norfolk Island $ 1,500,000 FY91/92
224 Tuvalu $ 1,000,000 2004 est.
225 Montserrat $ 700,000 2001
226 Niue $ 201,400 2004
227 Nauru $ 64,000 2005 est.
228 Wallis and Futuna $ 47,450 2004
229 Tokelau $ 0 2002
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2079
Rank Country Debt - external Date of Information
1 World $ 36,890,000,000,000 2004 est.
2 United States $ 8,837,000,000,000 30 June 2005 est.
3 United Kingdom $ 7,107,000,000,000 30 June 2005
4 Germany $ 3,626,000,000,000 30 June 2005
5 France $ 2,826,000,000,000 30 June 2005
6 Netherlands $ 1,645,000,000,000 30 June 2005
7 Japan $ 1,545,000,000,000 31 December 2004
8 Ireland $ 1,049,000,000,000 30 June 2005
9 Belgium $ 980,100,000,000 30 June 2005 est.
10 Spain $ 970,700,000,000 2005 est.
11 Italy $ 922,500,000,000 2005 est.
12 Switzerland $ 856,000,000,000 30 June 2005
13 Sweden $ 516,100,000,000 30 June 2005
14 Austria $ 510,600,000,000 30 June 2005 est.
15 Canada $ 439,800,000,000 30 November 2005
16 Denmark $ 352,900,000,000 30 June 2005
17 Australia $ 323,400,000,000 2005 est.
18 Portugal $ 287,800,000,000 2005 est.
19 Norway $ 281,000,000,000 30 June 2005
20 China $ 252,800,000,000 2005 est.
21 Russia $ 215,300,000,000 2005 est.
22 Finland $ 211,700,000,000 30 June 2005
23 Brazil $ 188,000,000,000 2005 est.
24 Turkey $ 170,100,000,000 2005 est.
25 Korea, South $ 153,900,000,000 2005 est.
26 Mexico $ 137,200,000,000 2005 est.
27 Indonesia $ 135,000,000,000 2005 est.
28 India $ 125,500,000,000 2005 est.
29 Argentina $ 118,200,000,000 2005 est.
30 Poland $ 101,500,000,000 2005 est.
31 Iraq $ 92,330,000,000 2005 est.
32 Taiwan $ 87,500,000,000 2005 est.
33 Israel $ 75,550,000,000 2005 est.
34 Greece $ 75,180,000,000 2005 est.
35 Hong Kong $ 72,040,000,000 2005 est.
36 Hungary $ 66,220,000,000 2005 est.
37 Philippines $ 65,710,000,000 2005 est.
38 Thailand $ 52,460,000,000 2005 est.
39 Malaysia $ 52,000,000,000 2005 est.
40 Czech Republic $ 49,140,000,000 2005 est.
41 Chile $ 47,450,000,000 2005 est.
42 New Zealand $ 42,840,000,000 2005 est.
43 Kazakhstan $ 41,660,000,000 2005 est.
44 Venezuela $ 41,510,000,000 2005 est.
45 Pakistan $ 38,800,000,000 2005 est.
46 Saudi Arabia $ 36,780,000,000 2005 est.
47 Romania $ 35,680,000,000 2005 est.
48 Egypt $ 35,260,000,000 2005 est.
49 United Arab Emirates $ 34,470,000,000 2005 est.
50 Nigeria $ 32,450,000,000 2005 est.
51 Colombia $ 32,350,000,000 2005 est.
52 Peru $ 30,940,000,000 2005 est.
53 Croatia $ 30,620,000,000 2005 est.
54 South Africa $ 29,970,000,000 2005 est.
55 Sudan $ 27,340,000,000 2005 est.
56 Slovakia $ 26,940,000,000 2005 est.
57 Lebanon $ 26,000,000,000 2005 est.
58 Ukraine $ 23,930,000,000 2005 est.
59 Singapore $ 23,760,000,000 2005 est.
60 Qatar $ 21,130,000,000 2005 est.
61 Bangladesh $ 20,630,000,000 2005 est.
62 Vietnam $ 20,160,000,000 2005 est.
63 Algeria $ 19,450,000,000 2005 est.
64 Iran $ 19,060,000,000 2005 est.
65 Slovenia $ 18,970,000,000 2005 est.
66 Ecuador $ 18,090,000,000 2005 est.
67 Monaco $ 18,000,000,000 2000 est.
68 Kuwait $ 16,120,000,000 2005 est.
69 Tunisia $ 16,090,000,000 2005 est.
70 Morocco $ 15,610,000,000 2005 est.
71 Serbia $ 15,430,000,000 2005 est.
72 Bulgaria $ 15,320,000,000 2005 est.
73 Cote d''Ivoire $ 13,430,000,000 2005 est.
74 Uruguay $ 13,240,000,000 2005 est.
75 Cuba $ 12,560,000,000 2005 est.
76 Korea, North $ 12,000,000,000 1996 est.
77 Lithuania $ 11,700,000,000 2 February 2006
78 Sri Lanka $ 11,050,000,000 2005 est.
79 Estonia $ 11,030,000,000 2005 est.
80 Latvia $ 10,800,000,000 1 January 2006
81 Congo, Democratic Republic of the $ 10,600,000,000 2003 est.
82 Cyprus $ 10,530,000,000 2005 est.
83 Panama $ 9,758,000,000 2005 est.
84 Angola $ 9,401,000,000 2005 est.
85 Cameroon $ 9,168,000,000 2005 est.
86 Syria $ 8,566,000,000 2005 est.
87 Jordan $ 8,528,000,000 2005 est.
88 Tanzania $ 8,178,000,000 2005 est.
89 El Salvador $ 8,087,000,000 2005 est.
90 Afghanistan $ 8,000,000,000 2004
91 Dominican Republic $ 7,687,000,000 2005 est.
92 Kenya $ 7,391,000,000 2005 est.
93 Jamaica $ 7,162,000,000 2005 est.
94 Ghana $ 6,999,000,000 2005 est.
95 Burma $ 6,990,000,000 2005 est.
96 Bahrain $ 6,814,000,000 2005 est.
97 Bolivia $ 6,309,000,000 2005 est.
98 Honduras $ 5,795,000,000 2005 est.
99 Guatemala $ 5,503,000,000 2005 est.
100 Mozambique $ 5,456,000,000 2005 est.
101 Yemen $ 5,347,000,000 2005 est.
102 Zimbabwe $ 5,216,000,000 2005 est.
103 Ethiopia $ 5,101,000,000 2005 est.
104 Costa Rica $ 5,049,000,000 2005 est.
105 Uzbekistan $ 5,032,000,000 2005 est.
106 Congo, Republic of the $ 5,000,000,000 2000 est.
107 Uganda $ 4,973,000,000 2005 est.
108 Belarus $ 4,662,000,000 30 June 2005 est.
109 Zambia $ 4,641,000,000 2005 est.
110 Madagascar $ 4,600,000,000 2002
111 Oman $ 4,361,000,000 2005 est.
112 Libya $ 4,267,000,000 2005 est.
113 Gabon $ 3,903,000,000 2005 est.
114 Senegal $ 3,529,000,000 2005 est.
115 Guinea $ 3,460,000,000 2003 est.
116 Paraguay $ 3,450,000,000 2005 est.
117 Nepal $ 3,340,000,000 March 2005
118 Malawi $ 3,287,000,000 2005 est.
119 Mauritius $ 3,246,000,000 2005 est.
120 Liberia $ 3,200,000,000 2005 est.
121 Nicaragua $ 3,188,000,000 2005 est.
122 Bosnia and Herzegovina $ 3,116,000,000 2005 est.
123 Macau $ 3,100,000,000 2004
124 Iceland $ 3,073,000,000 2002
125 Somalia $ 3,000,000,000 2001 est.
126 Mali $ 2,800,000,000 2002
127 Trinidad and Tobago $ 2,767,000,000 2005 est.
128 Netherlands Antilles $ 2,680,000,000 2004
129 Mauritania $ 2,500,000,000 2000
130 Laos $ 2,490,000,000 2001
131 Kyrgyzstan $ 2,428,000,000 31 December 2004 est.
132 Turkmenistan $ 2,400,000,000 2001 est.
133 Macedonia $ 2,190,000,000 2005 est.
134 Niger $ 2,100,000,000','2441f576dd7537937c62e42f3c35a11b99284e5f185124217f50ee799242d7de','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4102561b602b8eb600c675e53cf6a13ce36a87d5035f0a8a1b6967b8543d176b',2006,'ZW','Zimbabwe','communications',10,'2003 est.
135 Georgia $ 2,040,000,000 2004
136 Togo $ 2,000,000,000 2005
137 Moldova $ 1,986,000,000 2005 est.
138 Papua New Guinea $ 1,882,000,000 2005 est.
139 Azerbaijan $ 1,873,000,000 2005 est.
140 Burkina Faso $ 1,850,000,000 2003
141 Armenia $ 1,819,000,000 20 September 2005
142 Sierra Leone $ 1,610,000,000 2003 est.
143 Benin $ 1,600,000,000 2000
144 Albania $ 1,550,000,000 2004
145 Chad $ 1,500,000,000 2003 est.
146 Rwanda $ 1,400,000,000 2004 est.
147 Belize $ 1,362,000,000 June 2004 est.
148 Mongolia $ 1,360,000,000 2004
149 Haiti $ 1,313,000,000 2005 est.
150 Burundi $ 1,200,000,000 2003
151 Guyana $ 1,200,000,000 2002
152 Central African Republic $ 1,060,000,000 2002 est.
153 Guinea-Bissau $ 941,500,000 2000 est.
154 Tajikistan $ 888,000,000 2004 est.
155 French Guiana $ 800,300,000 2003
156 Cambodia $ 800,000,000 2003 est.
157 Lesotho $ 735,000,000 2002
158 Namibia $ 712,900,000 2005 est.
159 Barbados $ 668,000,000 2003
160 Gambia, The $ 628,800,000 2003 est.
161 Bhutan $ 593,000,000 2004
162 Botswana $ 519,000,000 2005 est.
163 Seychelles $ 508,000,000 2005 est.
164 Suriname $ 504,300,000 2005 est.
165 Aruba $ 478,600,000 2005 est.
166 Antigua and Barbuda $ 427,300,000 2000
167 Djibouti $ 394,000,000 2004 est.
168 Swaziland $ 357,000,000 2003 est.
169 Equatorial Guinea $ 353,000,000 2005 est.
170 Grenada $ 347,000,000 2004
171 Bahamas, The $ 342,600,000 2004 est.
172 Cape Verde $ 325,000,000 2002
173 Sao Tome and Principe $ 318,000,000 2002
174 Saint Kitts and Nevis $ 314,000,000 2004
175 Eritrea $ 311,000,000 2000 est.
176 Maldives $ 304,000,000 2004 est.
177 Saint Lucia $ 257,000,000 2004
178 Comoros $ 232,000,000 2000 est.
179 Saint Vincent and the Grenadines $ 223,000,000 2004
180 Dominica $ 213,000,000 2004
181 Malta $ 188,800,000 2005
182 Martinique $ 180,000,000 1994
183 Samoa $ 177,000,000 2004
184 Solomon Islands $ 166,000,000 2004
185 Bermuda $ 160,000,000 FY99/00
186 Cook Islands $ 141,000,000 1996 est.
187 Fiji $ 127,000,000 2004 est.
188 Marshall Islands $ 86,500,000 FY99/00 est.
189 Vanuatu $ 81,200,000 2004
190 Tonga $ 80,700,000 2004
191 New Caledonia $ 79,000,000 1998 est.
192 Cayman Islands $ 70,000,000 1996
193 Faroe Islands $ 64,000,000 1999
194 Micronesia, Federated States of $ 60,800,000 FY05 est.
195 British Virgin Islands $ 36,100,000 1997
196 Nauru $ 33,300,000 2002
197 Greenland $ 25,000,000 1999
198 Kiribati $ 10,000,000 1999 est.
199 Montserrat $ 8,900,000 1997
200 Anguilla $ 8,800,000 1998
201 Wallis and Futuna $ 3,670,000
202 Niue $ 418,000 2002 est.
203 Brunei $ 0
204 Palau $ 0 FY99/00
205 Tokelau $ 0
206 West Bank $ 0 2002
207 East Timor $ 0
208 Gaza Strip $ 0 2002
209 Liechtenstein $ 0 2001
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2085
Rank Country Roadways(km) Date of Information
1 World 32,345,165 2002
2 United States 6,407,637 2004
3 European Union 4,634,810 1999-2000
4 India 3,851,440 2002
5 China 1,809,829 2003
6 Brazil 1,724,929 2000
7 Japan 1,183,000 2003
8 Canada 1,042,300 2005
9 France 891,290 2003
10 Russia 871,000 2004
11 Australia 810,641 2004
12 Spain 666,292 2003
13 Italy 479,688 2004
14 Sweden 424,981 2003
15 Poland 423,997 2004
16 United Kingdom 387,674 2004
17 Indonesia 368,360 2002
18 South Africa 362,099 2002
19 Mexico 349,038 2003
20 Turkey 347,553 2004
21 Kazakhstan 258,029 2003
22 Pakistan 255,856 2004
23 Bangladesh 239,226 2003
24 Germany 231,581 2005
25 Argentina 229,144 2004
26 Vietnam 222,179 2004
27 Philippines 200,037 2003
28 Romania 198,817 2003
29 Nigeria 194,394 1999
30 Iran 178,152 2002
31 Ukraine 169,447 2004
32 Hungary 159,568 2005
33 Congo, Democratic Republic of the 157,000 1999
34 Saudi Arabia 152,044 2000
35 Belgium 149,757 2003
36 Netherlands 134,000 2004
37 Austria 133,718 2003
38 Czech Republic 127,747 2003
39 Greece 116,470 1999
40 Colombia 110,000 2000
41 Algeria 104,000 1999
42 Bulgaria 102,016 2003
43 Zimbabwe 97,440 2002
44 Sri Lanka 97,287 2003
45 Korea, South 97,252 2004
46 Venezuela 96,155 1999
47 Ireland 95,736 2002
48 Belarus 93,055 2003
49 New Zealand 92,662 2003
50 Norway 92,513 2005
51 Syria 91,795 2003
52 Zambia 91,440 2001
53 Libya 83,200 1999
54 Uzbekistan 81,600 1999
55 Cameroon 80,932 2002
56 Cote d''Ivoire 80,000 2006
57 Chile 79,605 2001
58 Lithuania 79,497 2005
59 Tanzania 78,891 2003
60 Peru 78,672 2003
61 Finland 78,189 2006
62 Uruguay 77,732 2004
63 Portugal 72,600 2002
64 Denmark 72,257 2005
65 Malaysia 71,814 2001
66 Yemen 71,300 2005
67 Switzerland 71,297 2004
68 Uganda 70,746 2003
69 Latvia 69,919 2003
70 Egypt 64,000 1999
71 Kenya 63,000 2004
72 Cuba 60,858 1999
73 Bolivia 60,762 2003
74 Morocco 57,694 2002
75 Thailand 57,403 2000
76 Estonia 56,849 2003
77 Angola 51,429 2001
78 Madagascar 49,827 1999
79 Mongolia 49,250 2002
80 Iraq 45,550 1999
81 Guinea 44,348 2003
82 Ecuador 43,197 2003
83 Slovakia 42,993 2003
84 Ghana 42,623 2004
85 Namibia 42,237 2002
86 Slovenia 38,400 2003
87 Serbia 37,887 2002
88 Taiwan 37,299 2002
89 Costa Rica 35,889 2003
90 Oman 34,965 2001
91 Afghanistan 34,789 2003
92 Ethiopia 33,856 2003
93 Chad 33,400 1999
94 Laos 32,620 2002
95 Gabon 32,333 2003
96 Korea, North 31,200 1999 est.
97 Mozambique 30,400 1999
98 Paraguay 29,500 1999
99 Malawi 28,400 1999
100 Croatia 28,344 2004
101 Tajikistan 27,767 2000
102 Azerbaijan 27,016 2003
103 Burma 27,000 2005
104 Puerto Rico 25,645 2004
105 Botswana 25,233 2003
106 Turkmenistan 24,000 1999
107 Central African Republic 23,810 1999
108 Somalia 22,100 1999
109 Bosnia and Herzegovina 21,846 2005
110 Georgia 20,247 2003
111 Papua New Guinea 19,600 1999
112 Nicaragua 19,036 2005
113 Tunisia 18,997 2001
114 Jamaica 18,700 1999
115 Kyrgyzstan 18,500 1999
116 Albania 18,000 2002
117 Israel 17,364 2004
118 Benin 16,000 2005
119 Nepal 15,905 2003
120 Mali 15,100 1999
121 Cyprus 14,496 2005/1996 est.
122 Burundi 14,480 1999
123 Guatemala 14,095 1999
124 Honduras 13,603 1999
125 Senegal 13,576 2003
126 Iceland 13,028 2005
127 Congo, Republic of the 12,800 1999
128 Moldova 12,730 2003
129 Dominican Republic 12,600 1999
130 Burkina Faso 12,506 1999
131 Cambodia 12,323 2000
132 Rwanda 12,000 1999
133 Sudan 11,900 1999
134 Panama 11,643 2000
135 Sierra Leone 11,300 2002
136 Liberia 10,600 1999
137 Niger 10,100 1999
138 El Salvador 10,029 1999
139 Macedonia 8,684 1999
140 Trinidad and Tobago 8,320 1999
141 Bhutan 8,050 2003
142 Guyana 7,970 1999
143 Mauritania 7,660 1999
144 Armenia 7,633 2003
145 Togo 7,520 1999
146 Jordan 7,364 2003
147 Montenegro 7,353 2005
148 Lebanon 7,300 1999
149 Lesotho 5,940 1999
150 New Caledonia 5,432 2000
151 Luxembourg 5,210 2002
152 East Timor 5,000 2005
153 Suriname 4,492 2002
154 Kuwait 4,450 1999
155 Guinea-Bissau 4,400 1999
156 Haiti 4,160 1999
157 West Bank 4,158 2003
158 Eritrea 4,010 1999
159 Gambia, The 3,742 2003
160 Swaziland 3,594 2002
161 Bahrain 3,498 2003
162 Fiji 3,440 1999
163 Singapore 3,234 2005
164 Djibouti 2,890 1999
165 Equatorial Guinea 2,880 1999
166 Belize 2,872 1999
167 Bahamas, The 2,693 1999
168 French Polynesia 2,590 1999
169 Brunei 2,525 2000
170 Malta 2,227 2004
171 Martinique 2,105 2000
172 Mauritius 2,020 2005
173 Hong Kong 1,955 2005
174 Barbados 1,600 2003
175 Solomon Islands 1,360 1999
176 Cape Verde 1,350 2000
177 Virgin Islands 1,257 2004
178 Qatar 1,230 1999
179 Reunion 1,214 2001
180 Antigua and Barbuda 1,165 2002
181 Grenada 1,127 1999
182 United Arab Emirates 1,088 1999
183 Vanuatu 1,070 1999
184 Guam 977 2004
185 Guadeloupe 947 2002
186 Saint Lucia 910 2000
187 Comoros 880 1999
188 Saint Vincent and the Grenadines 829 2003
189 French Guiana 817 1998
190 Isle of Man 800 1999
191 Samoa 790 1999
192 Cayman Islands 785 2002
193 Dominica 780 1999
194 Tonga 680 1999
195 Kiribati 670 1999
196 Northern Mariana Islands 536 2004
197 Faroe Islands 458 2003
198 Seychelles 458 2003
199 Bermuda 447 2002
200 Falkland Islands (Islas Malvinas) 440 2003
201 Macau 368 2005
202 Cook Islands 320 2003
203 Sao Tome and Principe 320 1999
204 Saint Kitts and Nevis 320 1999 est
205 Andorra 269
206 Micronesia, Federated States of 240 1999
207 Niue 234 2001
208 Montserrat 227 2003
209 Saint Helena 198 2002
210 American Samoa 185 2004
211 British Virgin Islands 177 2002
212 Christmas Island 142 2006
213 Turks and Caicos Islands 121 2003
214 Anguilla 105 2002
215 San Marino 104 2003
216 Maldives 88 2006
217 Norfolk Island 80 2002
218 Marshall Islands 65 2002
219 Monaco 50 1999
220 Gibraltar 29 2002
221 Cocos (Keeling) Islands 22 2006
222 Tuvalu 8 2002
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2087
Rank Country Imports Date of Information
1 World $ 10,300,000,000,000 2004 est.
2 United States $ 1,727,000,000,000 2005 est.
3 European Union $ 1,402,000,000,000 2004
4 Germany $ 801,000,000,000 2005 est.
5 China $ 631,800,000,000 2005 est.
6 United Kingdom $ 483,700,000,000 2005 est.
7 France $ 473,300,000,000 2005 est.
8 Japan $ 451,100,000,000 2005 est.
9 Italy $ 369,200,000,000 2005 est.
10 Netherlands $ 326,600,000,000 2005 est.
11 Canada $ 317,700,000,000 2005 est.
12 Hong Kong $ 291,600,000,000 2005 est.
13 Spain $ 271,800,000,000 2005 est.
14 Belgium $ 264,500,000,000 2005 est.
15 Korea, South $ 256,000,000,000 2005 est.
16 Mexico $ 223,700,000,000 2005 est.
17 Singapore $ 188,300,000,000 2005 est.
18 Taiwan $ 181,600,000,000 2005 est.
19 Switzerland $ 135,000,000,000 2005 est.
20 Russia $ 125,000,000,000 2005 est.
21 Australia $ 119,600,000,000 2005 est.
22 Austria $ 118,800,000,000 2005 est.
23 Malaysia $ 118,700,000,000 2005 est.
24 India $ 113,100,000,000 2005 est.
25 Thailand $ 107,000,000,000 2005 est.
26 Sweden $ 104,400,000,000 2005 est.
27 Turkey $ 101,200,000,000 2005 est.
28 Poland $ 95,670,000,000 2005 est.
29 Brazil $ 78,020,000,000 2005 est.
30 Czech Republic $ 76,590,000,000 2005 est.
31 Denmark $ 74,690,000,000 2005 est.
32 Ireland $ 65,470,000,000 2005 est.
33 Hungary $ 64,830,000,000 2005 est.
34 Indonesia $ 62,020,000,000 2005 est.
35 Portugal $ 60,350,000,000 2005 est.
36 United Arab Emirates $ 60,150,000,000 2005 est.
37 Norway $ 58,120,000,000 2005 est.
38 Finland $ 56,450,000,000 2005 est.
39 South Africa $ 52,970,000,000 2005 est.
40 Greece $ 48,200,000,000 2005 est.
41 Saudi Arabia $ 44,930,000,000 2005 est.
42 Israel $ 43,190,000,000 2005 est.
43 Philippines $ 42,660,000,000 2005 est.
44 Iran $ 42,500,000,000 2005 est.
45 Romania $ 41,000,000,000 2005
46 Ukraine $ 37,180,000,000 2005 est.
47 Vietnam $ 36,880,000,000 2005 est.
48 Slovakia $ 32,900,000,000 2005 est.
49 Chile $ 30,090,000,000 2005 est.
50 Puerto Rico $ 29,100,000,000 2001
51 Argentina $ 28,800,000,000 2005 est.
52 Nigeria $ 25,950,000,000 2005 est.
53 Venezuela $ 24,630,000,000 2005 est.
54 New Zealand $ 24,570,000,000 2005 est.
55 Egypt $ 24,100,000,000 2005 est.
56 Algeria $ 22,530,000,000 2005 est.
57 Pakistan $ 21,260,000,000 2005 est.
58 Slovenia $ 19,620,000,000 2005 est.
59 Iraq $ 19,570,000,000 2004
60 Croatia $ 18,930,000,000 2005 est.
61 Luxembourg $ 18,740,000,000 2005 est.
62 Morocco $ 18,150,000,000 2005 est.
63 Colombia $ 18,000,000,000 2005 est.
64 Kazakhstan $ 17,510,000,000 2005 est.
65 Belarus $ 16,940,000,000 2005 est.
66 Bulgaria $ 16,780,000,000 2005
67 Lithuania $ 15,500,000,000 2005 est.
68 Bangladesh $ 12,970,000,000 2005 est.
69 Tunisia $ 12,860,000,000 2005 est.
70 Kuwait $ 12,230,000,000 2005 est.
71 Peru $ 12,150,000,000 2005 est.
72 Libya $ 10,820,000,000 2005 est.
73 Serbia $ 10,580,000,000 2005 est.
74 Dominican Republic $ 9,747,000,000 2005 est.
75 Costa Rica $ 9,690,000,000 2005 est.
76 Estonia $ 9,189,000,000 2005 est.
77 Lebanon $ 8,855,000,000 2005 est.
78 Panama $ 8,734,000,000 2005 est.
79 Oman $ 8,709,000,000 2005 est.
80 Jordan $ 8,681,000,000 2005 est.
81 Ecuador $ 8,436,000,000 2005 est.
82 Sri Lanka $ 8,370,000,000 2005 est.
83 Latvia $ 8,190,000,000 2005
84 Angola $ 8,165,000,000 2005 est.
85 Bahrain $ 7,830,000,000 2005 est.
86 Guatemala $ 7,744,000,000 2005 est.
87 Cuba $ 6,916,000,000 2005 est.
88 Bosnia and Herzegovina $ 6,800,000,000 2005 est.
89 Qatar $ 6,706,000,000 2005 est.
90 El Salvador $ 6,678,000,000 2005 est.
91 Trinidad and Tobago $ 6,011,000,000 2005 est.
92 Syria $ 5,973,000,000 2005 est.
93 Cyprus $ 5,552,000,000 2005 est.
94 Kenya $ 5,126,000,000 2005 est.
95 Sudan $ 5,028,000,000 2005 est.
96 Liberia $ 4,839,000,000 2004 est.
97 Cote d''Ivoire $ 4,759,000,000 2005 est.
98 Azerbaijan $ 4,656,000,000 2005 est.
99 Virgin Islands $ 4,609,000,000
100 Iceland $ 4,582,000,000 2005 est.
101 Netherlands Antilles $ 4,383,000,000 2004 est.
102 Ghana $ 4,273,000,000 2005 est.
103 Yemen $ 4,190,000,000 2005 est.
104 Turkmenistan $ 4,175,000,000 2005 est.
105 Honduras $ 4,161,000,000 2005 est.
106 Jamaica $ 4,093,000,000 2004 est.
107 Afghanistan $ 3,870,000,000 2005 est.
108 Malta $ 3,859,000,000 2005 est.
109 Paraguay $ 3,832,000,000 2005 est.
110 Uzbekistan $ 3,800,000,000 2005 est.
111 Uruguay $ 3,540,000,000 2005 est.
112 Cambodia $ 3,538,000,000 2005 est.
113 Macau $ 3,478,000,000 2004
114 Burma $ 3,454,000,000 2004
115 Botswana $ 3,370,000,000 2005 est.
116 Reunion $ 3,306,000,000 2002
117 Macedonia $ 3,196,000,000 2005 est.
118 Gibraltar $ 2,967,000,000 2004 est.
119 Nicaragua $ 2,865,000,000 2005 est.
120 Korea, North $ 2,819,000,000 2004 est.
121 Ethiopia $ 2,722,000,000 2005 est.
122 Cameroon $ 2,514,000,000 2005 est.
123 Mauritius $ 2,507,000,000 2005 est.
124 Georgia $ 2,500,000,000 2005 est.
125 Albania $ 2,473,000,000 2005 est.
126 Senegal $ 2,405,000,000 2005 est.
127 Tanzania $ 2,391,000,000 2005 est.
128 Namibia $ 2,350,000,000 2005 est.
129 Martinique $ 2,307,000,000 2002
130 Moldova $ 2,230,000,000 2005 est.
131 Swaziland $ 2,149,000,000 2005 est.
132 Zimbabwe $ 2,059,000,000 2005 est.
133 Mozambique $ 2,041,000,000 2005 est.
134 Nepal $ 2,000,000,000 2005 est.
135 Gaza Strip $ 1,952,000,000 2003
136 West Bank $ 1,952,000,000 2003
137 Zambia $ 1,934,000,000 2005 est.
138 Equatorial Guinea $ 1,864,000,000 2005 est.
139 Mali $ 1,858,000,000 2004 est.
140 Bolivia $ 1,845,000,000 2005 est.
141 Bahamas, The $ 1,820,000,000 2004 est.
142 Guadeloupe $ 1,766,000,000 2002
143 French Polynesia $ 1,706,000,000 2005 est.
144 Papua New Guinea $ 1,651,000,000 2005 est.
145 Brunei $ 1,641,000,000 2004 est.
146 New Caledonia $ 1,636,000,000 2004 est.
147 Uganda $ 1,608,000,000 2005 est.
148 Gabon $ 1,533,000,000 2005 est.
149 Armenia $ 1,500,000,000 2005 est.
150 Barbados $ 1,476,000,000 2004 est.
151 Haiti $ 1,471,000,000 2005 est.
152 Fiji $ 1,462,000,000 2005
153 Madagascar $ 1,400,000,000 2005 est.
154 Congo, Democratic Republic of the $ 1,319,000,000 2004 est.
155 Tajikistan $ 1,250,000,000 2005 est.
156 Lesotho $ 1,166,000,000 2005 est.
157 Mauritania $ 1,124,000,000 2004 est.
158 Andorra $ 1,077,000,000 1998
159 Togo $ 1,047,000,000 2005 est.
160 Benin $ 1,043,000,000 2005 est.
161 Mongolia $ 1,011,000,000 2004 est.
162 Burkina Faso $ 992,000,000 2005 est.
163 Djibouti $ 987,000,000 2004 est.
164 Bermuda $ 982,000,000 2004 est.
165 Kyrgyzstan $ 937,400,000 2005 est.
166 Liechtenstein $ 917,300,000 1996
167 Aruba $ 875,000,000 2004 est.
168 Cayman Islands $ 866,900,000 2004
169 Congo, Republic of the $ 806,500,000 2005 est.
170 Suriname $ 750,000,000 2004 est.
171 Chad $ 749,100,000 2005 est.
172 Guam $ 701,000,000 2004 est.
173 Guyana $ 681,600,000 2005 est.
174 Guinea $ 680,000,000 2005 est.
175 Eritrea $ 676,500,000 2005 est.
176 Malawi $ 645,000,000 2005 est.
177 Faroe Islands $ 639,000,000 2004 est.
178 Monaco $ 636,600,000
179 French Guiana $ 625,000,000 2002 est.
180 Belize $ 622,400,000 2005 est.
181 Montenegro $ 601,700,000 2003
182 Greenland $ 601,000,000 2004 est.
183 Niger $ 588,000,000 2004 est.
184 Somalia $ 576,000,000 2004 est.
185 Maldives $ 567,000,000 2004 est.
186 Laos $ 541,000,000 2005 est.
187 Sierra Leone $ 531,000,000 2004 est.
188 Cape Verde $ 500,000,000 2005 est.
189 Seychelles $ 459,900,000 2005 est.
190 Cyprus $ 415,200,000 2005 est.
191 Saint Lucia $ 410,000,000 2004 est.
192 Saint Kitts and Nevis $ 405,000,000 2004 est.
193 Antigua and Barbuda $ 378,000,000 2004 est.
194 American Samoa $ 308,800,000 FY04 est.
195 Samoa $ 285,000,000 2004 est.
196 Grenada $ 276,000,000 2004 est.
197 Mayotte $ 256,700,000 2004
198 Rwanda $ 243,000,000 2005 est.
199 Dominica $ 234,000,000 2004 est.
200 Saint Vincent and the Grenadines $ 225,000,000 2004 est.
201 Northern Mariana Islands $ 214,400,000
202 Central African Republic $ 203,000,000 2004 est.
203 East Timor $ 202,000,000 2004 est.
204 Burundi $ 200,000,000 2005 est.
205 Gambia, The $ 197,000,000 2005 est.
206 Bhutan $ 196,000,000 2000 est.
207 British Virgin Islands $ 187,000,000 2002 est.
208 Guinea-Bissau $ 176,000,000 2004 est.
209 Turks and Caicos Islands $ 175,600,000 2000
210 Solomon Islands $ 159,000,000 2004 est.
211 Micronesia, Federated States of $ 132,700,000 2004
212 Anguilla $ 129,900,000 2005 est.
213 Tonga $ 122,000,000 2004 est.
214 Vanuatu $ 117,100,000 2004 est.
215 Comoros $ 115,000,000 2004 est.
216 Palau $ 107,300,000 2004 est.
217 Falkland Islands (Islas Malvinas) $ 90,000,000 2004 est.
218 Cook Islands $ 81,040,000 2005
219 Saint Pierre and Miquelon $ 70,000,000 2004 est.
220 Kiribati $ 62,000,000 2004 est.
221 Wallis and Futuna $ 61,170,000 2004
222 Marshall Islands $ 54,700,000 2000
223 Saint Helena $ 45,000,000 2004 est.
224 Sao Tome and Principe $ 38,000,000 2005 est.
225 Nauru $ 20,000,000 2004 est.
226 Norfolk Island $ 17,900,000 FY91/92
227 Montserrat $ 17,000,000 2001
228 Tuvalu $ 9,186,000 2004 est.
229 Niue $ 9,038,000 2004
230 Tokelau $ 969,200 2002
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2089
Rank Country Industrial production growth rate(%) Date of Information
1 Azerbaijan 40.00 2005 est.
2 Equatorial Guinea 30.00 2002 est.
3 China 29.50 2005 est.
4 Cambodia 22.00 2002 est.
5 Turkmenistan 22.00 2003 est.
6 Burundi 18.00 2001
7 Vietnam 17.20 2005 est.
8 Moldova 17.00 2003 est.
9 Belarus 15.60 2005 est.
10 Lesotho 15.50 1999
11 Cote d''Ivoire 15.00 1998 est.
12 Iceland 14.20 2005 est.
13 Burkina Faso 14.00 2001 est.
14 Angola 13.50 2004
15 Kuwait 13.10 2005 est.
16 Laos 13.00 2005 est.
17 Pakistan 10.70 2005 est.
18 Qatar 10.00 2003 est.
19 Estonia 9.70 2005 est.
20 Singapore 9.50 2005 est.
21 Bhutan 9.30 1996 est.
22 Thailand 9.10 2005 est.
23 Trinidad and Tobago 9.00 2005 est.
24 Uganda 9.00 2005 est.
25 Sudan 8.50 1999 est.
26 East Timor 8.50
27 Uruguay 8.50 2005 est.
28 Tanzania 8.40 1999 est.
29 Benin 8.30 2001 est.
30 Sri Lanka 8.20 2005 est.
31 Tajikistan 8.20 2002 est.
32 Algeria 8.00 2005 est.
33 Mauritius 8.00 2000 est.
34 Faroe Islands 8.00 1999 est.
35 Bulgaria 7.90 2005
36 Malawi 7.90 2005 est.
37 Zambia 7.90 2005 est.
38 India 7.90 2005 est.
39 Argentina 7.70 2005 est.
40 Uzbekistan 7.70 2005 est.
41 Honduras 7.70 2003 est.
42 Armenia 7.50 2005 est.
43 Jordan 7.50 2005 est.
44 Botswana 7.50 2005 est.
45 Brunei 7.30 2003 est.
46 Hungary 7.30 2005 est.
47 Lithuania 7.30 2005 est.
48 Venezuela 7.20 2005 est.
49 Kyrgyzstan 7.10 2004 est.
50 Rwanda 7.00 2001 est.
51 Syria 7.00 2002 est.
52 Peru 6.90 2005 est.
53 Macedonia 6.80 2005 est.
54 Bangladesh 6.70 2005 est.
55 Ethiopia 6.70 2001 est.
56 Suriname 6.50 1994 est.
57 Antigua and Barbuda 6.00 1997 est.
58 San Marino 6.00 1997 est.
59 Korea, South 5.90 2005 est.
60 Turkey 5.90 2005 est.
61 Bolivia 5.70 2004 est.
62 Costa Rica 5.70 2005 est.
63 Czech Republic 5.70 2005
64 Latvia 5.60 2005 est.
65 Bosnia and Herzegovina 5.50 2003 est.
66 Saudi Arabia 5.30 2005 est.
67 Cuba 5.10 2005 est.
68 Niger 5.10 2003 est.
69 Croatia 5.10 2005 est.
70 Chad 5.00 1995
71 Egypt 5.00 2005 est.
72 Indonesia 4.80 2005 est.
73 Austria 4.70 2005 est.
74 Guinea-Bissau 4.70 2003 est.
75 Belize 4.60 1999
76 Kazakhstan 4.60 2005 est.
77 Kenya 4.60 2005 est.
78 Luxembourg 4.50 2005 est.
79 Cameroon 4.20 1999 est.
80 Guatemala 4.10 1999
81 Oman 4.10 2005 est.
82 Taiwan 4.10 2005 est.
83 Malaysia 4.10 2005 est.
84 Mongolia 4.10 2002 est.
85 United Arab Emirates 4.00 2000
86 Russia 4.00 2005 est.
87 Morocco 4.00
88 Ghana 3.80 2000 est.
89 Nepal 3.80 FY04/05
90 Nigeria 3.80 2005 est.
91 Slovakia 3.80 2005 est.
92 Colombia 3.70 2005 est.
93 Poland 3.70 2005 est.
94 Swaziland 3.70 FY95/96
95 South Africa 3.60 2005 est.
96 Zimbabwe 3.60 2005 est.
97 Brazil 3.40 2005 est.
98 Chile 3.40 2005 est.
99 Mozambique 3.40 2000
100 Isle of Man 3.20 FY96/97
101 Ukraine 3.20 2005 est.
102 United States 3.20 2005 est.
103 Albania 3.10 2004 est.
104 Anguilla 3.10 1997 est.
105 Slovenia 3.10 2005 est.
106 Senegal 3.10 2005 est.
107 Central African Republic 3.00 2002
108 Djibouti 3.00 1996 est.
109 Ireland 3.00 2005 est.
110 Iran 3.00 2005 est.
111 Madagascar 3.00 2000 est.
112 Switzerland 3.00 2005 est.
113 Yemen 3.00 2003 est.
114 World 3.00 2003 est.
115 Georgia 3.00 2000
116 Germany 2.90 2005 est.
117 Israel 2.80 2005 est.
118 Samoa 2.80 2000
119 Canada 2.60 2005 est.
120 Nicaragua 2.40 2005 est.
121 Philippines 2.20 2005 est.
122 Ecuador 2.10 2005 est.
123 Bahrain 2.00 2000 est.
124 Dominican Republic 2.00 2001 est.
125 Mauritania 2.00 2000 est.
126 Mexico 1.90 2005 est.
127 Romania 1.90 2005 est.
128 Panama 1.70 2005 est.
129 Denmark 1.60 2005 est.
130 Sweden 1.60 2005 est.
131 Gabon 1.60 2002 est.
132 El Salvador 1.50 2005 est.
133 Japan 1.50 2005 est.
134 Serbia 1.40 2006 est.
135 European Union 1.30 2005 est.
136 Australia 1.10 2005 est.
137 Cook Islands 1.00 2002
138 Tonga 1.00 2003 est.
139 Vanuatu 1.00 1997 est.
140 Tunisia 0.90 2005 est.
141 Grenada 0.70 1997 est.
142 Spain 0.70 2005 est.
143 Kiribati 0.70 1991 est.
144 Cyprus 0.40
145 France 0.20 2005 est.
146 Congo, Republic of the 0.00 2002 est.
147 Paraguay 0.00 2000 est.
148 Portugal 0.00 2005 est.
149 Belgium -0.20 2005 est.
150 Cyprus -0.30
151 Greece -0.30 2005 est.
152 Norway -0.50 2005 est.
153 Hong Kong -0.60 2005 est.
154 New Caledonia -0.60 1996
155 Maldives -0.90 2004 est.
156 Saint Vincent and the Grenadines -0.90 1997 est.
157 Italy -1.00 2005 est.
158 Netherlands -1.40 2005 est.
159 United Kingdom -1.90 2005 est.
160 Comoros -2.00 1999 est.
161 Finland -2.00 2005 est.
162 Jamaica -2.00 2000 est.
163 New Zealand -2.50 2005 est.
164 Barbados -3.20 2000 est.
165 Saint Lucia -8.90 1997 est.
166 Dominica -10.00 1997 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2091
Rank Country Infant mortality rate(deaths/1,000 live births) Date of Information
1 Angola 185.36 2006 est.
2 Sierra Leone 160.39 2006 est.
3 Afghanistan 160.23 2006 est.
4 Liberia 155.76 2006 est.
5 Mozambique 129.24 2006 est.
6 Niger 118.25 2006 est.
7 Somalia 114.89 2006 est.
8 Mali 107.58 2006 est.
9 Tajikistan 106.49 2006 est.
10 Guinea-Bissau 105.21 2006 est.
11 Djibouti 102.44 2006 est.
12 Bhutan 98.41 2006 est.
13 Nigeria 97.14 2006 est.
14 Tanzania 96.48 2006 est.
15 Malawi 94.37 2006 est.
16 Ethiopia 93.62 2006 est.
17 Chad 91.45 2006 est.
18 Burkina Faso 91.35 2006 est.
19 Guinea 90.00 2006 est.
20 Rwanda 89.61 2006 est.
21 Equatorial Guinea 89.21 2006 est.
22 Cote d''Ivoire 89.11 2006 est.
23 Congo, Democratic Republic of the 88.62 2006 est.
24 Lesotho 87.24 2006 est.
25 Zambia 86.84 2006 est.
26 Central African Republic 85.63 2006 est.
27 Congo, Republic of the 85.29 2006 est.
28 Laos 83.31 2006 est.
29 Benin 79.56 2006 est.
30 Azerbaijan 79.00 2006 est.
31 Madagascar 75.21 2006 est.
32 Comoros 72.85 2006 est.
33 Turkmenistan 72.56 2006 est.
34 Swaziland 71.85 2006 est.
35 Haiti 71.65 2006 est.
36 Gambia, The 71.58 2006 est.
37 Pakistan 70.45 2006 est.
38 Uzbekistan 69.99 2006 est.
39 Mauritania 69.48 2006 est.
40 Cambodia 68.78 2006 est.
41 Uganda 66.15 2006 est.
42 Nepal 65.32 2006 est.
43 Cameroon 63.52 2006 est.
44 Burundi 63.13 2006 est.
45 Burma 61.85 2006 est.
46 Sudan 61.05 2006 est.
47 Bangladesh 60.83 2006 est.
48 Mayotte 60.76 2006 est.
49 South Africa','bf9e79e2f0a1efeb5bce3697d4d13383dfbb237c6977f5a472100c935ec18781','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24c32be9cff6f344a4d26d28320b7331c8122832db3a03762e7db0c46f87f638',2006,'ZW','Zimbabwe','communications',11,'60.66 2006 est.
50 Togo 60.63 2006 est.
51 Yemen 59.88 2006 est.
52 Kenya 59.26 2006 est.
53 Ghana 55.02 2006 est.
54 Maldives 54.89 2006 est.
55 India 54.63 2006 est.
56 Gabon 54.51 2006 est.
57 Vanuatu 53.80 2006 est.
58 Botswana 53.70 2006 est.
59 Senegal 52.94 2006 est.
60 Mongolia 52.12 2006 est.
61 Bolivia 51.77 2006 est.
62 Zimbabwe 51.71 2006 est.
63 Papua New Guinea 49.96 2006 est.
64 World 48.87 2006 est.
65 Iraq 48.64 2006 est.
66 Namibia 48.10 2006 est.
67 Kiribati 47.27 2006 est.
68 Cape Verde 46.52 2006 est.
69 Eritrea 46.30 2006 est.
70 East Timor 45.89 2006 est.
71 Sao Tome and Principe 41.83 2006 est.
72 Iran 40.30 2006 est.
73 Morocco 40.24 2006 est.
74 Turkey 39.69 2006 est.
75 Moldova 38.38 2006 est.
76 Kyrgyzstan 34.49 2006 est.
77 Indonesia 34.39 2006 est.
78 Guyana 32.19 2006 est.
79 Egypt 31.33 2006 est.
80 Guatemala 30.94 2006 est.
81 Peru 30.94 2006 est.
82 Algeria 29.87 2006 est.
83 Micronesia, Federated States of 29.16 2006 est.
84 Syria 28.61 2006 est.
85 Brazil 28.60 2006 est.
86 Marshall Islands 28.43 2006 est.
87 Kazakhstan 28.30 2006 est.
88 Dominican Republic 28.25 2006 est.
89 Nicaragua 28.11 2006 est.
90 Samoa 26.85 2006 est.
91 Honduras 25.82 2006 est.
92 Romania 25.50 2006 est.
93 Vietnam 25.14 2006 est.
94 Trinidad and Tobago 25.05 2006 est.
95 Belize 24.89 2006 est.
96 Paraguay 24.78 2006 est.
97 Bahamas, The 24.68 2006 est.
98 El Salvador 24.39 2006 est.
99 Tunisia 23.84 2006 est.
100 Lebanon 23.72 2006 est.
101 Libya 23.71 2006 est.
102 Korea, North 23.29 2006 est.
103 China 23.12 2006 est.
104 Suriname 23.02 2006 est.
105 Ecuador 22.87 2006 est.
106 Philippines 22.81 2006 est.
107 Armenia 22.47 2006 est.
108 Gaza Strip 22.40 2006 est.
109 Venezuela 21.54 2006 est.
110 Albania 20.75 2006 est.
111 Solomon Islands 20.63 2006 est.
112 Colombia 20.35 2006 est.
113 Anguilla 20.32 2006 est.
114 Mexico 20.26 2006 est.
115 Bulgaria 19.85 2006 est.
116 Thailand 19.49 2006 est.
117 Tuvalu 19.47 2006 est.
118 West Bank 19.15 2006 est.
119 Oman 18.89 2006 est.
120 Antigua and Barbuda 18.86 2006 est.
121 Saint Helena 18.34 2006 est.
122 Qatar 18.04 2006 est.
123 Georgia 17.97 2006 est.
124 Malaysia 17.16 2006 est.
125 Bahrain 16.80 2006 est.
126 Jordan 16.76 2006 est.
127 British Virgin Islands 16.72 2006 est.
128 Panama 16.37 2006 est.
129 Jamaica 15.98 2006 est.
130 Greenland 15.40 2006 est.
131 Turks and Caicos Islands 15.18 2006 est.
132 Seychelles 15.14 2006 est.
133 Russia 15.13 2006 est.
134 Argentina 14.73 2006 est.
135 Mauritius 14.59 2006 est.
136 Palau 14.46 2006 est.
137 Saint Vincent and the Grenadines 14.40 2006 est.
138 Grenada 14.27 2006 est.
139 Saint Kitts and Nevis 14.12 2006 est.
140 United Arab Emirates 14.09 2006 est.
141 Sri Lanka 13.97 2006 est.
142 Dominica 13.71 2006 est.
143 Saint Lucia 13.17 2006 est.
144 Belarus 13.00 2006 est.
145 Saudi Arabia 12.81 2006 est.
146 Fiji 12.30 2006 est.
147 Tonga 12.30 2006 est.
148 Brunei 12.25 2006 est.
149 Barbados 11.77 2006 est.
150 French Guiana 11.76 2006 est.
151 Uruguay 11.61 2006 est.
152 Ukraine 9.90 2006 est.
153 Bosnia and Herzegovina 9.82 2006 est.
154 Macedonia 9.81 2006 est.
155 Nauru 9.78 2006 est.
156 Netherlands Antilles 9.76 2006 est.
157 Kuwait 9.71 2006 est.
158 Costa Rica 9.70 2006 est.
159 Latvia 9.35 2006 est.
160 Puerto Rico 9.14 2006 est.
161 American Samoa 9.07 2006 est.
162 Chile 8.58 2006 est.
163 Guadeloupe 8.41 2006 est.
164 Hungary 8.39 2006 est.
165 Bermuda 8.30 2006 est.
166 French Polynesia 8.29 2006 est.
167 Cayman Islands 8.00 2006 est.
168 Virgin Islands 7.86 2006 est.
169 Estonia 7.73 2006 est.
170 Reunion 7.63 2006 est.
171 New Caledonia 7.57 2006 est.
172 Saint Pierre and Miquelon 7.38 2006 est.
173 Slovakia 7.26 2006 est.
174 Poland 7.22 2006 est.
175 Montserrat 7.19 2006 est.
176 Cyprus 7.04 2006 est.
177 Northern Mariana Islands 6.98 2006 est.
178 Martinique 6.95 2006 est.
179 Israel 6.89 2006 est.
180 Guam 6.81 2006 est.
181 Lithuania 6.78 2006 est.
182 Croatia 6.72 2006 est.
183 United States 6.43 2006 est.
184 Taiwan 6.29 2006 est.
185 Cuba 6.22 2006 est.
186 Korea, South 6.16 2006 est.
187 Faroe Islands 6.12 2006 est.
188 Italy 5.83 2006 est.
189 Isle of Man 5.82 2006 est.
190 Aruba 5.79 2006 est.
191 New Zealand 5.76 2006 est.
192 San Marino 5.63 2006 est.
193 Greece 5.43 2006 est.
194 Monaco 5.35 2006 est.
195 Ireland 5.31 2006 est.
196 Jersey 5.16 2006 est.
197 European Union 5.10 2006 est.
198 United Kingdom 5.08 2006 est.
199 Gibraltar 5.06 2006 est.
200 Portugal 4.98 2006 est.
201 Netherlands 4.96 2006 est.
202 Luxembourg 4.74 2006 est.
203 Canada 4.69 2006 est.
204 Guernsey 4.65 2006 est.
205 Liechtenstein 4.64 2006 est.
206 Australia 4.63 2006 est.
207 Belgium 4.62 2006 est.
208 Austria 4.60 2006 est.
209 Denmark 4.51 2006 est.
210 Slovenia 4.40 2006 est.
211 Spain 4.37 2006 est.
212 Macau 4.35 2006 est.
213 Switzerland 4.34 2006 est.
214 France 4.21 2006 est.
215 Germany 4.12 2006 est.
216 Andorra 4.04 2006 est.
217 Czech Republic 3.89 2006 est.
218 Malta 3.86 2006 est.
219 Norway 3.67 2006 est.
220 Finland 3.55 2006 est.
221 Iceland 3.29 2006 est.
222 Japan 3.24 2006 est.
223 Hong Kong 2.95 2006 est.
224 Sweden 2.76 2006 est.
225 Singapore 2.29 2006 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2092
Rank Country Inflation rate (consumer prices)(%) Date of Information
1 Nauru -3.60 1993
2 San Marino -1.70 2001
3 Vanuatu -1.60 2005 est.
4 Northern Mariana Islands -0.80 2000
5 New Caledonia -0.60 2000 est.
6 Barbados -0.50 2003 est.
7 Japan -0.30 2005 est.
8 Dominica -0.10 2005 est.
9 Gabon -0.10 2005 est.
10 Macedonia 0.00 2005 est.
11 Niger 0.20 2004 est.
12 Cape Verde 0.40 2005 est.
13 Singapore 0.40 2005 est.
14 Saudi Arabia 0.40 2005 est.
15 Kiribati 0.50 2005 est.
16 Sweden 0.50 2005 est.
17 Armenia 0.60 2005 est.
18 Antigua and Barbuda 0.90 2005 est.
19 Brunei 0.90 2004
20 Hong Kong 0.90 2005 est.
21 Finland 0.90 2005 est.
22 French Guiana 1.00 2003
23 Morocco 1.00 2005 est.
24 Liechtenstein 1.00 2001
25 Sierra Leone 1.00 2002 est.
26 Saint Vincent and the Grenadines 1.00 2005 est.
27 French Polynesia 1.10 2006 est.
28 Bahamas, The 1.20 2004
29 Switzerland 1.20 2005 est.
30 Oman 1.20 2005 est.
31 Israel 1.30 2005 est.
32 East Timor 1.40 2005
33 Gibraltar 1.50 1998
34 Greenland 1.60 1999 est.
35 Norway 1.60 2005 est.
36 Peru 1.60 2005 est.
37 Seychelles 1.60 2005 est.
38 France 1.70 2005 est.
39 Papua New Guinea 1.70 2005 est.
40 Senegal 1.70 2005 est.
41 Netherlands 1.70 2005 est.
42 China 1.80 2005 est.
43 Denmark 1.80 2005 est.
44 Algeria 1.90 2005 est.
45 Czech Republic 1.90 2005 est.
46 Monaco 1.90 2000
47 Cameroon 2.00 2005 est.
48 Germany 2.00 2005 est.
49 British Virgin Islands 2.00 2005
50 Italy 2.00 2005 est.
51 Cook Islands 2.10 2005 est.
52 United Kingdom 2.10 2005 est.
53 Tunisia 2.10 2005 est.
54 Saint Pierre and Miquelon 2.10 1991-96 average
55 Ecuador 2.10 2005 est.
56 Netherlands Antilles 2.10 2003 est.
57 Canada 2.20 2005 est.
58 Poland 2.20 2005 est.
59 European Union 2.20 2005 est.
60 Virgin Islands 2.20 2003
61 Micronesia, Federated States of 2.20 2005
62 Congo, Republic of the 2.20 2005 est.
63 Austria 2.30 2005 est.
64 Namibia 2.30 2005 est.
65 Taiwan 2.30 2005 est.
66 Portugal 2.30 2005 est.
67 Albania 2.40 2005 est.
68 Ireland 2.40 2005 est.
69 Lebanon 2.40 2005 est.
70 Guam 2.50 2005 est.
71 Luxembourg 2.50 2005 est.
72 Slovenia 2.50 2005 est.
73 Cyprus 2.60
74 Montserrat 2.60 2002 est.
75 Australia 2.70 2005 est.
76 Bahrain 2.70 2005 est.
77 Isle of Man 2.70 2003 est.
78 Palau 2.70 2005 est.
79 Slovakia 2.70 2005 est.
80 Lithuania 2.70 2005
81 Bermuda 2.80 November 2005
82 Belgium 2.80 2005 est.
83 Wallis and Futuna 2.80
84 Korea, South 2.80 2005 est.
85 Panama 2.90 2005 est.
86 Saint Lucia 2.90 2005 est.
87 Belize 3.00 2005 est.
88 Chad 3.00 2005 est.
89 Djibouti 3.00 2005 est.
90 Fiji 3.00 2005
91 Malaysia 3.00 2005 est.
92 Marshall Islands 3.00 2005 est.
93 New Zealand 3.00 2005 est.
94 Malta 3.00 2005 est.
95 Grenada 3.00 2005 est.
96 Comoros 3.00 2005 est.
97 Chile 3.10 2005 est.
98 Saint Helena 3.20 1997 est.
99 United States 3.20 2005 est.
100 Croatia 3.30 2005 est.
101 Samoa 3.30 2005
102 Aruba 3.40 2005
103 Spain 3.40 2005 est.
104 Montenegro 3.40 2004
105 Libya 3.40 2005 est.
106 Andorra 3.40 2004
107 Benin 3.50 2005 est.
108 Greece 3.50 2005 est.
109 Central African Republic 3.60 2001 est.
110 Hungary 3.60 2005 est.
111 Falkland Islands (Islas Malvinas) 3.60 1998
112 Tuvalu 3.70 2003 est.
113 Macau 3.80 2nd quarter, 2005
114 Cote d''Ivoire 3.90 2005 est.
115 Iceland 4.00 2005 est.
116 Guinea-Bissau 4.00 2002 est.
117 Niue 4.00 2005
118 Mexico 4.00 2005 est.
119 South Africa 4.00 2005 est.
120 Turks and Caicos Islands 4.00 1995
121 Swaziland 4.00 2005 est.
122 Estonia 4.10 2005 est.
123 Kuwait 4.10 2005 est.
124 Dominican Republic 4.20 2005 est.
125 India 4.20 2005 est.
126 Tanzania 4.30 2005 est.
127 Bosnia and Herzegovina 4.40 2005 est.
128 Cayman Islands 4.40 2004
129 Jordan 4.50 2005 est.
130 Thailand 4.50 2005 est.
131 Mali 4.50 2002 est.
132 El Salvador 4.70 2005 est.
133 Lesotho 4.70 2005 est.
134 Uruguay 4.70 2005 est.
135 Egypt 4.90 2005 est.
136 Guernsey 4.90 2004 est.
137 Bulgaria 5.00 2005
138 Equatorial Guinea 5.00 2005 est.
139 Colombia 5.00 2005 est.
140 Mauritius 5.00 2005 est.
141 Syria 5.00 2005 est.
142 Faroe Islands 5.10 1999
143 Kyrgyzstan 5.20 2005 est.
144 Anguilla 5.30
145 Jersey 5.30 2004
146 Bolivia 5.40 2005 est.
147 Cambodia 5.80 2005 est.
148 Maldives 6.00 2005 est.
149 Togo 6.00 2005 est.
150 Burkina Faso 6.40 2005 est.
151 Mozambique 6.50 2005 est.
152 Puerto Rico 6.50 2003 est.
153 Solomon Islands 6.60 2005 est.
154 Latvia 6.80 2005 est.
155 Paraguay 6.80 2005 est.
156 Brazil 6.90 2005 est.
157 Guyana 6.90 2005 est.
158 Uzbekistan 6.90 2005 est.
159 Trinidad and Tobago 6.90 2005 est.
160 Bangladesh 7.00 2005 est.
161 West Bank 7.00 2003 est.
162 Cuba 7.00 2005 est.
163 Bhutan 7.00 2005 est.
164 Gaza Strip 7.00 2003
165 Mauritania 7.00 2003 est.
166 Laos 7.00 2005 est.
167 Tajikistan 7.10 2005 est.
168 Kazakhstan 7.60 2005 est.
169 Philippines 7.60 2005 est.
170 Nepal 7.80 October 2005 est.
171 Rwanda 8.00 2005 est.
172 Uganda 8.10 2005 est.
173 Georgia 8.20 2005 est.
174 Turkey 8.20 2005 est.
175 Vietnam 8.30 2005 est.
176 Botswana 8.60 2005 est.
177 Saint Kitts and Nevis 8.70 2005 est.
178 Gambia, The 8.80 2005 est.
179 Honduras 8.80 2005 est.
180 Qatar 8.80 2005 est.
181 Congo, Democratic Republic of the 9.00 2004 est.
182 Sudan 9.00 2005 est.
183 Romania 9.00 2005
184 Cyprus 9.10
185 Guatemala 9.10 2005 est.
186 Pakistan 9.10 2005 est.
187 Mongolia 9.50 2005 est.
188 Suriname 9.50 2005 est.
189 Azerbaijan 9.60 2005 est.
190 Argentina 9.60 2005 est.
191 Nicaragua 9.60 2005 est.
192 Belarus 10.30 2005 est.
193 Kenya 10.30 2005 est.
194 United Arab Emirates 10.50 2005 est.
195 Indonesia 10.50 2005 est.
196 Turkmenistan 10.50 2005 est.
197 Tonga 11.10 2005 est.
198 Sri Lanka 11.60 2005 est.
199 Ethiopia 11.60 2005 est.
200 Yemen 11.80 2005 est.
201 Moldova 11.90 2005 est.
202 Russia 12.70 2005 est.
203 Iran 13.50 2005 est.
204 Nigeria 13.50 2005 est.
205 Ukraine 13.50 2005 est.
206 Costa Rica 13.80 2005 est.
207 Eritrea 15.00 2005 est.
208 Liberia 15.00 2003 est.
209 Madagascar 15.00 2005 est.
210 Ghana 15.10 2005 est.
211 Sao Tome and Principe 15.20 2005 est.
212 Jamaica 15.30 2005 est.
213 Malawi 15.40 2005 est.
214 Serbia 15.50 2005 est.
215 Haiti 15.70 2005 est.
216 Burundi 16.00 2005 est.
217 Venezuela 16.00 2005 est.
218 Afghanistan 16.30 2005 est.
219 Zambia 18.30 2005 est.
220 Burma 20.20 2005 est.
221 Angola 23.00 2005 est.
222 Guinea 25.00 2005 est.
223 Iraq 33.00 2005 est.
224 Zimbabwe 266.80 2005 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2093
Rank Country Waterways(km) Date of Information
1 World 671,886 2004
2 China 123,964 2003
3 Russia 102,000 2005
4 European Union 53,512
5 Brazil 50,000 2005
6 United States 41,009 2004
7 Indonesia 21,579 2005
8 Colombia 18,000 2005
9 Vietnam 17,702 2005
10 Congo, Democratic Republic of the 15,000 2005
11 India 14,500 2005
12 Burma 12,800 2005
13 Argentina 11,000 2005
14 Papua New Guinea 10,940 2003
15 Bolivia 10,000 2005
16 Peru 8,808 2005
17 Nigeria 8,600 2005
18 France 8,500 2000
19 Bangladesh 8,372 2005
20 Finland 7,842 2005
21 Germany 7,467 2005
22 Malaysia 7,200 2005
23 Venezuela 7,100 2005
24 Netherlands 6,183 2005
25 Iraq 5,279 2004
26 Laos 4,600 2005
27 Congo, Republic of the 4,385 2005
28 Sudan 4,068 2005
29 Kazakhstan 4,000 2005
30 Thailand 4,000 2005
31 Poland 3,997 2005
32 French Guiana 3,760 2003
33 Egypt 3,500 2005
34 Philippines 3,219 2005
35 United Kingdom 3,200 2003
36 Paraguay 3,100 2005
37 Mexico 2,900 2005
38 Central African Republic 2,800 2005
39 Belarus 2,500 2003
40 Cambodia 2,400 2005
41 Italy 2,400 2004
42 Ukraine 2,253 2006
43 Korea, North 2,250 2006
44 Zambia 2,250 2005
45 Nicaragua 2,220 2005
46 Sweden 2,052 2005
47 Belgium 2,043 2003
48 Australia 2,000 2002
49 Mali 1,815 2005
50 Japan 1,770 2006
51 Romania 1,731 2005
52 Hungary 1,622 2006
53 Korea, South 1,608 2006
54 Gabon 1,600 2005
55 Uruguay 1,600 2005
56 Norway 1,577 2002
57 Ecuador 1,500 2005
58 Angola 1,300 2005
59 Turkmenistan 1,300 2006
60 Guinea 1,300 2005
61 Ghana 1,293 2005
62 Afghanistan 1,200 2005
63 Turkey 1,200 2005
64 Suriname 1,200 2005
65 Uzbekistan 1,100 2006
66 Senegal 1,000 2005
67 Spain 1,000 2003
68 Guatemala 990 2004
69 Cote d''Ivoire 980 2005
70 Syria 900 2005
71 Iran 850 2006
72 Belize 825 2005
73 Panama 800 2005
74 Sierra Leone 800 2005
75 Croatia 785 2006
76 Ireland 753 2005
77 Costa Rica 730 2005
78 Malawi 700 2006
79 Czech Republic 664 2005
80 Canada 631 2003
81 Kyrgyzstan 600 2006
82 Madagascar 600 2005
83 Serbia 587 2005
84 Mongolia 580 2004
85 Estonia 500 2005
86 Bulgaria 470 2006
87 Honduras 465 2005
88 Mozambique 460 2002
89 Lithuania 425 2005
90 Moldova 424 2005
91 Denmark 400 2001
92 Gambia, The 390 2004
93 Austria 358 2003
94 Latvia 300 2005
95 Niger 300 2005
96 Cuba 240 2005
97 Portugal 210 2003
98 Brunei 209 2005
99 Fiji 203 2004
100 Tajikistan 200 2006
101 Slovakia 172 2005
102 Sri Lanka 160 2005
103 Benin 150 2005
104 Switzerland 65 2003
105 Togo 50 2005
106 Albania 43 2006
107 Luxembourg 37 2003
108 Liechtenstein 28 2005
109 Greece 6 2006
110 Kiribati 5 2003
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2095
Rank Country Labor force Date of Information
1 World 3,001,000,000 2005 est.
2 China 791,400,000 2005 est.
3 India 496,400,000 2005 est.
4 European Union 218,500,000 2005 est.
5 United States 149,300,000 2005 est.
6 Indonesia 94,200,000 2005 est.
7 Brazil 90,410,000 2005 est.
8 Russia 74,220,000 2005 est.
9 Bangladesh 66,600,000 2005 est.
10 Japan 66,400,000 2005 est.
11 Nigeria 57,210,000 2005 est.
12 Pakistan 46,840,000 2005 est.
13 Vietnam 44,390,000 2005 est.
14 Mexico 43,400,000 2005 est.
15 Germany 43,320,000 2005 est.
16 Philippines 36,730,000 2005 est.
17 Thailand 35,360,000 2005 est.
18 United Kingdom 30,070,000 2005 est.
19 Burma 27,750,000 2005 est.
20 France 27,720,000 2005 est.
21 Ethiopia 27,270,000
22 Turkey 24,700,000 2005 est.
23 Italy 24,490,000 2005 est.
24 Iran 23,680,000 2005 est.
25 Korea, South 23,530,000 2005 est.
26 Ukraine 22,670,000 2005 est.
27 Egypt 21,340,000 2005 est.
28 Spain 20,670,000 2005 est.
29 Colombia 20,520,000 2005
30 Tanzania 19,220,000 2005 est.
31 Poland 17,100,000 2005 est.
32 Canada 16,300,000 December 2005
33 Argentina 15,340,000 2005 est.
34 South Africa 15,230,000 2005 est.
35 Afghanistan 15,000,000 2004 est.
36 Congo, Democratic Republic of the 14,510,000
37 Uzbekistan 14,260,000 2005 est.
38 Uganda 13,170,000 2005 est.
39 Venezuela 12,310,000 2005 est.
40 Kenya 11,850,000 2005 est.
41 Morocco 11,190,000 2005 est.
42 Malaysia 10,670,000 2005 est.
43 Ghana 10,620,000 2005 est.
44 Taiwan 10,600,000 2005 est.
45 Australia 10,420,000 2005 est.
46 Nepal 10,400,000 2004 est.
47 Algeria 10,150,000 2005 est.
48 Korea, North 9,600,000
49 Romania 9,310,000 2005 est.
50 Mozambique 9,200,000 2000 est.
51 Peru 9,060,000 2005 est.
52 Sri Lanka 8,080,000 2005 est.
53 Kazakhstan 7,850,000 2005 est.
54 Netherlands 7,530,000 2005 est.
55 Sudan 7,415,000 1996 est.
56 Iraq 7,400,000 2004 est.
57 Madagascar 7,300,000 2000
58 Cambodia 7,000,000 2003 est.
59 Cote d''Ivoire 6,950,000 2005 est.
60 Cameroon 6,860,000 2005 est.
61 Saudi Arabia 6,760,000 2005 est.
62 Chile 6,300,000 2005 est.
63 Yemen 5,830,000 2005 est.
64 Angola 5,580,000 2005 est.
65 Portugal 5,520,000 2005 est.
66 Azerbaijan 5,450,000 2005 est.
67 Czech Republic 5,270,000 2005 est.
68 Syria 5,120,000 2004 est.
69 Burkina Faso 5,000,000 2003
70 Senegal 4,820,000 2005 est.
71 Zambia 4,800,000 2005 est.
72 Belgium 4,770,000 2005 est.
73 Greece 4,720,000 2005 est.
74 Cuba 4,600,000 2005 est.
75 Rwanda 4,600,000 2000
76 Ecuador 4,600,000 2005 est.
77 Malawi 4,500,000 2001 est.
78 Sweden 4,490,000 2005 est.
79 Belarus 4,300,000 31 December 2005
80 Bolivia 4,220,000 2005 est.
81 Hungary 4,180,000 2005 est.
82 Zimbabwe 3,940,000 2005 est.
83 Mali 3,930,000 2001 est.
84 Switzerland 3,800,000 2005 est.
85 Guatemala 3,760,000 2005 est.
86 Somalia 3,700,000
87 Tajikistan 3,700,000 2003
88 Hong Kong 3,610,000 October 2005
89 Haiti 3,600,000 1995
90 Austria 3,490,000 2005 est.
91 Tunisia 3,410,000 2005 est.
92 Bulgaria 3,340,000 2005 est.
93 Benin 3,211,000
94 Guinea 3,000,000 1999
95 Burundi 2,990,000 2002
96 Serbia 2,961,000 2002 est.
97 Denmark 2,900,000 2005 est.
98 El Salvador 2,810,000 2005 est.
99 United Arab Emirates 2,800,000 2005 est.
100 Laos 2,800,000 2002 est.
101 Chad 2,719,000
102 Kyrgyzstan 2,700,000 2000
103 Paraguay 2,680,000 2005 est.
104 Finland 2,610,000 2005 est.
105 Lebanon 2,600,000 2001 est.
106 Honduras 2,540,000 2005 est.
107 Israel 2,420,000 2005 est.
108 Papua New Guinea 2,413,000 2004
109 Norway 2,400,000 2005 est.
110 Turkmenistan 2,320,000 2003 est.
111 Singapore 2,280,000 September 2005 est.
112 Slovakia 2,240,000 30 September 2005 est.
113 New Zealand 2,130,000 2005 est.
114 Georgia 2,040,000 2004 est.
115 Ireland 2,030,000 2005 est.
116 Nicaragua 2,010,000 2005 est.
117 Costa Rica 1,820,000 2005 est.
118 Croatia 1,710,000 2005 est.
119 Kuwait 1,670,000 2005 est.
120 Libya 1,640,000 2005 est.
121 Lithuania 1,610,000 2005 est.
122 Uruguay 1,520,000 2005 est.
123 Mongolia 1,488,000 2003
124 Jordan 1,460,000 2005 est.
125 Panama 1,390,000 2005 est.
126 Sierra Leone 1,369,000 1981 est.
127 Moldova 1,340,000 2005 est.
128 Togo 1,302,000 1998
129 Puerto Rico 1,300,000 2000
130 Armenia 1,200,000 2005
131 Jamaica 1,200,000 2005 est.
132 Latvia 1,110,000 2005 est.
133 Albania 1,090,000 2004 est.
134 Bosnia and Herzegovina 1,026,000 2001
135 Oman 920,000 2002 est.
136 Slovenia 920,000 2005 est.
137 Macedonia 855,000 2004 est.
138 Lesotho 838,000 2000
139 Namibia 820,000 2005 est.
140 Mauritania 786,000 2001
141 Estonia 670,000 2005 est.
142 Gabon 640,000 2005 est.
143 Trinidad and Tobago 620,000 2005 est.
144 West Bank 614,000 April-June 2005
145 Mauritius 570,000 2005 est.
146 Guinea-Bissau 480,000 1999
147 Qatar 440,000 2005 est.
148 Guyana 418,000 2001 est.
149 Gambia, The 400,000 1996
150 Bahrain 380,000 2005 est.
151 Cyprus 370,000 2005 est.
152 Luxembourg 316,500 2005 est.
153 Reunion 299,000 2002
154 Botswana 288,400 2004
155 Djibouti 282,000 2000
156 Gaza Strip 278,000 April-June 2005
157 Montenegro 259,100 2004
158 Macau 251,200 3rd Quarter, 2005
159 Solomon Islands 249,200 1999
160 Guadeloupe 191,400 1999
161 Bahamas, The 176,300 2004
162 Iceland 165,900 2005 est.
163 Martinique 165,900 1998
164 Malta 160,000 2005 est.
165 Suriname 156,700 2004
166 Swaziland 155,700 2003
167 Brunei 146,300 2003 est.
168 Comoros 144,500 1996 est.
169 Fiji 137,000 1999
170 Barbados 128,500 2001 est.
171 Cape Verde 120,600
172 Cyprus 95,025 2005 est.
173 Belize 90,000 2001 est.
174 Samoa 90,000 2000 est.
175 Maldives 88,000 2000
176 Netherlands Antilles 83,600 2005
177 New Caledonia 78,990 2004
178 Vanuatu 76,410
179 Niger 70,000 2002 est.
180 French Polynesia 65,870 December 2005
181 French Guiana 62,630 1999
182 Guam 62,050 2002 est.
183 Jersey 52,790 2004
184 Andorra 48,740 2004
185 Mayotte 44,560 2002
186 Northern Mariana Islands 44,470 2000
187 Virgin Islands 43,980 2004 est.
188 Saint Lucia 43,800 2001 est.
189 Grenada 42,300 1996
190 Saint Vincent and the Grenadines 41,680 1991 est.
191 Aruba 41,500 2004 est.
192 Monaco 41,110 2004
193 Isle of Man 39,690 2001
194 Bermuda 38,360 2004
195 Micronesia, Federated States of 37,410
196 Sao Tome and Principe 35,050
197 Tonga 33,910 2003
198 Guernsey 32,290 2001
199 Seychelles 30,900 1996
200 Antigua and Barbuda 30,000
201 Liechtenstein 29,500 31 December 2001
202 Dominica 25,000 1999 est.
203 Greenland 24,500 1999 est.
204 Faroe Islands 24,250 October 2000
205 Cayman Islands 23,450 2004
206 San Marino 19,970 2003
207 Saint Kitts and Nevis 18,170 June 1995
208 American Samoa 17,630 2005
209 Marshall Islands 14,680 2000
210 British Virgin Islands 12,770 2004
211 Gibraltar 12,690 2001
212 Western Sahara 12,000
213 Palau 9,777 2005
214 Kiribati 7,870 2001 est.
215 Cook Islands 6,820 2001
216 Anguilla 6,049 2001
217 Turks and Caicos Islands 4,848 1990 est.
218 Montserrat 4,521 2000 est.
219 Tuvalu 3,615 2004 est.
220 Saint Pierre and Miquelon 3,261 1999
221 Wallis and Futuna 3,104
222 Saint Helena 2,486 1998 est.
223 Falkland Islands (Islas Malvinas) 1,724
224 Norfolk Island 1,345
225 Niue 663
226 Tokelau 440
227 Pitcairn Islands 15 2004
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2102
Rank Country Life expectancy at birth(years) Date of Information
1 Andorra 83.51 2006 est.
2 Macau 82.19 2006 est.
3 San Marino 81.71 2006 est.
4 Singapore 81.71 2006 est.
5 Hong Kong 81.59 2006 est.
6 Japan 81.25 2006 est.
7 Sweden 80.51 2006 est.
8 Switzerland 80.51 2006 est.
9 Australia 80.50 2006 est.
10 Guernsey 80.42 2006 est.
11 Iceland 80.31 2006 est.
12 Canada 80.22 2006 est.
13 Cayman Islands 80.07 2006 est.
14 Italy 79.81 2006 est.
15 Gibraltar 79.80 2006 est.
16 France 79.73 2006 est.
17 Monaco 79.69 2006 est.
18 Liechtenstein 79.68 2006 est.
19 Spain 79.65 2006 est.
20 Norway 79.54 2006 est.
21 Israel 79.46 2006 est.
22 Jersey 79.38 2006 est.
23 Faroe Islands 79.35 2006 est.
24 Aruba 79.28 2006 est.
25 Greece 79.24 2006 est.
26 Martinique 79.18 2006 est.
27 Austria 79.07 2006 est.
28 Virgin Islands 79.05 2006 est.
29 Malta 79.01 2006 est.
30 Netherlands 78.96 2006 est.
31 Luxembourg 78.89 2006 est.
32 Montserrat 78.85 2006 est.
33 New Zealand 78.81 2006 est.
34 Germany 78.80 2006 est.
35 Belgium 78.77 2006 est.
36 Saint Pierre and Miquelon 78.61 2006 est.
37 Guam 78.58 2006 est.
38 United Kingdom 78.54 2006 est.
39 Finland 78.50 2006 est.
40 Isle of Man 78.49 2006 est.
41 Jordan 78.40 2006 est.
42 Puerto Rico 78.40 2006 est.
43 European Union 78.30 2006 est.
44 Guadeloupe 78.06 2006 est.
45 Bosnia and Herzegovina 78.00 2006 est.
46 Bermuda 77.96 2006 est.
47 Saint Helena 77.93 2006 est.
48 United States 77.85 2006 est.
49 Cyprus 77.82 2006 est.
50 Denmark 77.79 2006 est.
51 Ireland 77.73 2006 est.
52 Portugal 77.70 2006 est.
53 Albania 77.43 2006 est.
54 Taiwan 77.43 2006 est.
55 Cuba 77.41 2006 est.
56 Anguilla 77.28 2006 est.
57 French Guiana 77.27 2006 est.
58 Kuwait 77.20 2006 est.
59 Korea, South 77.04 2006 est.
60 Costa Rica 77.02 2006 est.
61 Chile 76.77 2006 est.
62 Libya 76.69 2006 est.
63 British Virgin Islands 76.68 2006 est.
64 Ecuador 76.42 2006 est.
65 Slovenia 76.33 2006 est.
66 Uruguay 76.33 2006 est.
67 Czech Republic 76.22 2006 est.
68 Argentina 76.12 2006 est.
69 French Polynesia 76.10 2006 est.
70 Northern Mariana Islands 76.09 2006 est.
71 Georgia 76.09 2006 est.
72 American Samoa 76.05 2006 est.
73 Netherlands Antilles 76.03 2006 est.
74 Saudi A','46957d2bdb1121e1a9ae02e544a9d1046c2edfe48b30538b57d488b206438ae4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('491fe898c206ed12fb03ab32efdd972b2db2ea6f445977980292f35e8731d3e4',2006,'ZW','Zimbabwe','communications',12,'rabia 75.67 2006 est.
75 United Arab Emirates 75.44 2006 est.
76 Mexico 75.41 2006 est.
77 Panama 75.22 2006 est.
78 Tunisia 75.12 2006 est.
79 Paraguay 75.10 2006 est.
80 Brunei 75.01 2006 est.
81 Poland 74.97 2006 est.
82 Dominica 74.87 2006 est.
83 Slovakia 74.73 2006 est.
84 Turks and Caicos Islands 74.73 2006 est.
85 Croatia 74.68 2006 est.
86 Venezuela 74.54 2006 est.
87 Bahrain 74.45 2006 est.
88 New Caledonia 74.27 2006 est.
89 Lithuania 74.20 2006 est.
90 Reunion 74.18 2006 est.
91 Serbia 74.00
92 Macedonia 73.97 2006 est.
93 Qatar 73.90 2006 est.
94 Saint Vincent and the Grenadines 73.85 2006 est.
95 Saint Lucia 73.84 2006 est.
96 Sri Lanka 73.41 2006 est.
97 Oman 73.37 2006 est.
98 West Bank 73.27 2006 est.
99 Algeria 73.26 2006 est.
100 Jamaica 73.24 2006 est.
101 Solomon Islands 72.91 2006 est.
102 Lebanon 72.88 2006 est.
103 Barbados 72.79 2006 est.
104 Hungary 72.66 2006 est.
105 Mauritius 72.63 2006 est.
106 Turkey 72.62 2006 est.
107 China 72.58 2006 est.
108 Malaysia 72.50 2006 est.
109 Saint Kitts and Nevis 72.40 2006 est.
110 Bulgaria 72.30 2006 est.
111 Thailand 72.25 2006 est.
112 Antigua and Barbuda 72.16 2006 est.
113 Seychelles 72.08 2006 est.
114 Estonia 72.04 2006 est.
115 Colombia 71.99 2006 est.
116 Brazil 71.97 2006 est.
117 Gaza Strip 71.97 2006 est.
118 Armenia 71.84 2006 est.
119 Dominican Republic 71.73 2006 est.
120 Korea, North 71.65 2006 est.
121 Romania 71.63 2006 est.
122 El Salvador 71.49 2006 est.
123 Latvia 71.33 2006 est.
124 Egypt 71.29 2006 est.
125 Samoa 71.00 2006 est.
126 Morocco 70.94 2006 est.
127 Vietnam 70.85 2006 est.
128 Cape Verde 70.73 2006 est.
129 Nicaragua 70.63 2006 est.
130 Palau 70.42 2006 est.
131 Syria 70.32 2006 est.
132 Marshall Islands 70.31 2006 est.
133 Iran 70.26 2006 est.
134 Philippines 70.21 2006 est.
135 Micronesia, Federated States of 70.05 2006 est.
136 Ukraine 69.98 2006 est.
137 Greenland 69.94 2006 est.
138 Indonesia 69.87 2006 est.
139 Peru 69.84 2006 est.
140 Fiji 69.82 2006 est.
141 Tonga 69.82 2006 est.
142 Guatemala 69.38 2006 est.
143 Honduras 69.33 2006 est.
144 Belarus 69.08 2006 est.
145 Iraq 69.01 2006 est.
146 Suriname 69.01 2006 est.
147 Kyrgyzstan 68.49 2006 est.
148 Tuvalu 68.32 2006 est.
149 Belize 68.30 2006 est.
150 Sao Tome and Principe 67.31 2006 est.
151 Russia 67.08 2006 est.
152 Kazakhstan 66.89 2006 est.
153 Trinidad and Tobago 66.76 2006 est.
154 East Timor 66.26 2006 est.
155 Guyana 65.86 2006 est.
156 Bolivia 65.84 2006 est.
157 Moldova 65.65 2006 est.
158 Bahamas, The 65.60 2006 est.
159 Papua New Guinea 65.28 2006 est.
160 Tajikistan 64.94 2006 est.
161 Mongolia 64.89 2006 est.
162 Grenada 64.87 2006 est.
163 World 64.77 2006 est.
164 India 64.71 2006 est.
165 Uzbekistan 64.58 2006 est.
166 Maldives 64.41 2006 est.
167 Azerbaijan 63.85 2006 est.
168 Pakistan 63.39 2006 est.
169 Nauru 63.08 2006 est.
170 Vanuatu 62.85 2006 est.
171 Bangladesh 62.46 2006 est.
172 Comoros 62.33 2006 est.
173 Yemen 62.12 2006 est.
174 Kiribati 62.08 2006 est.
175 Turkmenistan 61.83 2006 est.
176 Mayotte 61.76 2006 est.
177 Burma 60.97 2006 est.
178 Nepal 60.18 2006 est.
179 Cambodia 59.29 2006 est.
180 Senegal 59.25 2006 est.
181 Eritrea 59.03 2006 est.
182 Sudan 58.92 2006 est.
183 Ghana 58.87 2006 est.
184 Togo 57.42 2006 est.
185 Madagascar 57.34 2006 est.
186 Laos 55.49 2006 est.
187 Bhutan 54.78 2006 est.
188 Gabon 54.49 2006 est.
189 Gambia, The 54.14 2006 est.
190 Haiti 53.23 2006 est.
191 Mauritania 53.12 2006 est.
192 Benin 53.04 2006 est.
193 Congo, Republic of the 52.80 2006 est.
194 Uganda 52.67 2006 est.
195 Congo, Democratic Republic of the 51.46 2006 est.
196 Cameroon 51.16 2006 est.
197 Burundi 50.81 2006 est.
198 Equatorial Guinea 49.54 2006 est.
199 Guinea 49.50 2006 est.
200 Ethiopia 49.03 2006 est.
201 Mali 49.00 2006 est.
202 Kenya 48.93 2006 est.
203 Burkina Faso 48.85 2006 est.
204 Cote d''Ivoire 48.82 2006 est.
205 Somalia 48.47 2006 est.
206 Chad 47.52 2006 est.
207 Rwanda 47.30 2006 est.
208 Nigeria 47.08 2006 est.
209 Guinea-Bissau 46.87 2006 est.
210 Tanzania 45.64 2006 est.
211 Niger 43.76 2006 est.
212 Central African Republic 43.54 2006 est.
213 Namibia 43.39 2006 est.
214 Afghanistan 43.34 2006 est.
215 Djibouti 43.17 2006 est.
216 South Africa 42.73 2006 est.
217 Malawi 41.70 2006 est.
218 Sierra Leone 40.22 2006 est.
219 Zambia 40.03 2006 est.
220 Mozambique 39.82 2006 est.
221 Liberia 39.65 2006 est.
222 Zimbabwe 39.29 2006 est.
223 Angola 38.62 2006 est.
224 Lesotho 34.40 2006 est.
225 Botswana 33.74 2006 est.
226 Swaziland 32.62 2006 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2108
Rank Country Merchant marine Date of Information
1 World 33,222 2006
2 Panama 5,473 2006
3 China 1,723 2006
4 Liberia 1,687 2006
5 Malta 1,220 2006
6 Russia 1,178 2006
7 Bahamas, The 1,177 2006
8 Singapore 1,063 2006
9 Antigua and Barbuda 1,011 2006
10 Hong Kong 924 2006
11 Cyprus 884 2006
12 Indonesia 824 2006
13 Greece 817 2006
14 Marshall Islands 795 2006
15 Norway 724 2006
16 Japan 683 2006
17 Korea, South 669 2006
18 Italy 591 2006
19 Saint Vincent and the Grenadines 589 2006
20 Netherlands 558 2006
21 Turkey 545 2006
22 Cambodia 544 2006
23 United States 465 2006
24 United Kingdom 449 2006
25 Philippines 403 2006
26 Thailand 400 2006
27 Germany 394 2006
28 India 316 2006
29 Malaysia 312 2006
30 Isle of Man 305 2006
31 Denmark 293 2006
32 Belize 285 2006
33 Vietnam 267 2006
34 Korea, North 232 2006
35 Georgia 222 2006
36 Ukraine 202 2006
37 Sweden 198 2006
38 Gibraltar 180 2006
39 Canada 173 2006
40 Spain 169 2006
41 Netherlands Antilles 152 2006
42 Iran 141 2006
43 Brazil 137 2006
44 Honduras 136 2006
45 Bermuda 132 2006
46 Cayman Islands 132 2006
47 Comoros 121 2006
48 Taiwan 112 2006
49 Portugal 111 2006
50 Syria 108 2006
51 Finland 87 2006
52 Azerbaijan 84 2006
53 French Southern and Antarctic Lands 77 2006
54 Monaco 77 2006
55 Egypt 76 2006
56 Bulgaria 75 2006
57 Croatia 72 2006
58 Belgium 66 2006
59 France 61 2006
60 Mongolia 61 2006
61 Saudi Arabia 60 2006
62 United Arab Emirates 58 2006
63 Barbados 58 2006
64 Mexico 56 2006
65 Venezuela 56 2006
66 Sierra Leone 54 2006
67 Australia 53 2006
68 Nigeria 52 2006
69 Tuvalu 52 2006
70 Vanuatu 51 2006
71 Saint Kitts and Nevis 50 2006
72 Lithuania 49 2006
73 Dominica 48 2006
74 Chile 46 2006
75 Slovakia 43 2006
76 Bangladesh 42 2006
77 Luxembourg 42 2006
78 Algeria 41 2006
79 Argentina 41 2006
80 Morocco 41 2006
81 Lebanon 39 2006
82 Kuwait 38 2006
83 Estonia 35 2006
84 Burma 34 2006
85 Ecuador 31 2006
86 Switzerland 27 2006
87 Slovenia 26 2006
88 Jordan 25 2006
89 Albania 24 2006
90 Bolivia 24 2006
91 Papua New Guinea 24 2006
92 Ireland 23 2006
93 Romania 23 2006
94 Qatar 23 2006
95 Sri Lanka 22 2006
96 Latvia 21 2006
97 Paraguay 21 2006
98 Faroe Islands 18 2006
99 Israel 18 2006
100 Libya 18 2006
101 Colombia 17 2006
102 Maldives 17 2006
103 Pakistan 16 2006
104 Tonga 16 2006
105 French Polynesia 13 2006
106 Uruguay 13 2006
107 New Zealand 13 2006
108 Iraq 13 2006
109 Cuba 11 2006
110 Poland 11 2006
111 Jamaica 10 2006
112 Madagascar 9 2006
113 Tunisia 9 2006
114 Tanzania 9 2006
115 Austria 8 2006
116 Wallis and Futuna 8 2006
117 Turkmenistan 8 2006
118 Sao Tome and Principe 8 2006
119 Trinidad and Tobago 8 2006
120 Ethiopia 8 2006
121 Bahrain 8 2006
122 Brunei 8 2006
123 Cape Verde 7 2006
124 Fiji 7 2006
125 Moldova 7 2006
126 Guyana 7 2006
127 Cook Islands 6 2006
128 Mauritius 6 2006
129 Kazakhstan 6 2006
130 Eritrea 6 2006
131 Gambia, The 5 2006
132 Seychelles 5 2006
133 Angola 4 2006
134 Peru 4 2006
135 Yemen 4 2006
136 Montenegro 4 2006
137 Ghana 4 2006
138 Greenland 3 2006
139 South Africa 3 2006
140 Kenya 3 2006
141 Puerto Rico 3 2006
142 Costa Rica 2 2006
143 Togo 2 2006
144 Sudan 2 2006
145 New Caledonia 2 2006
146 Mozambique 2 2006
147 Kiribati 2 2006
148 Gabon 2 2006
149 Micronesia, Federated States of 2 2006
150 Anguilla 1 2006
151 Cameroon 1 2006
152 Djibouti 1 2006
153 Laos 1 2006
154 Samoa 1 2006
155 Namibia 1 2006
156 British Virgin Islands 1 2006
157 Somalia 1 2006
158 Reunion 1 2006
159 Suriname 1 2006
160 Oman 1 2006
161 Iceland 1 2006
162 Dominican Republic 1 2006
163 Czech Republic 1 2006
164 Equatorial Guinea 1 2006
165 Congo, Republic of the 1 2006
166 Congo, Democratic Republic of the 1 2006
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2119
Rank Country Population Date of Information
1 World 6,525,170,264 July 2006 est.
2 China 1,313,973,713 July 2006 est.
3 India 1,095,351,995 July 2006 est.
4 European Union 456,953,258 July 2006 est.
5 United States 298,444,215 July 2006 est.
6 Indonesia 245,452,739 July 2006 est.
7 Brazil 188,078,227 July 2006 est.
8 Pakistan 165,803,560 July 2006 est.
9 Bangladesh 147,365,352 July 2006 est.
10 Russia 142,893,540 July 2006 est.
11 Nigeria 131,859,731 July 2006 est.
12 Japan 127,463,611 July 2006 est.
13 Mexico 107,449,525 July 2006 est.
14 Philippines 89,468,677 July 2006 est.
15 Vietnam 84,402,966 July 2006 est.
16 Germany 82,422,299 July 2006 est.
17 Egypt 78,887,007 July 2006 est.
18 Ethiopia 74,777,981 July 2006 est.
19 Turkey 70,413,958 July 2006 est.
20 Iran 68,688,433 July 2006 est.
21 Thailand 64,631,595 July 2006 est.
22 Congo, Democratic Republic of the 62,660,551 July 2006 est.
23 France 60,876,136 July 2006 est.
24 United Kingdom 60,609,153 July 2006 est.
25 Italy 58,133,509 July 2006 est.
26 Korea, South 48,846,823 July 2006 est.
27 Burma 47,382,633 July 2006 est.
28 Ukraine 46,710,816 July 2006 est.
29 South Africa 44,187,637 July 2006 est.
30 Colombia 43,593,035 July 2006 est.
31 Sudan 41,236,378 July 2006 est.
32 Spain 40,397,842 July 2006 est.
33 Argentina 39,921,833 July 2006 est.
34 Poland 38,536,869 July 2006 est.
35 Tanzania 37,445,392 July 2006 est.
36 Kenya 34,707,817 July 2006 est.
37 Morocco 33,241,259 July 2006 est.
38 Canada 33,098,932 July 2006 est.
39 Algeria 32,930,091 July 2006 est.
40 Afghanistan 31,056,997 July 2006 est.
41 Peru 28,302,603 July 2006 est.
42 Nepal 28,287,147 July 2006 est.
43 Uganda 28,195,754 July 2006 est.
44 Uzbekistan 27,307,134 July 2006 est.
45 Saudi Arabia 27,019,731 July 2006 est.
46 Iraq 26,783,383 July 2006 est.
47 Venezuela 25,730,435 July 2006 est.
48 Malaysia 24,385,858 July 2006 est.
49 Korea, North 23,113,019 July 2006 est.
50 Taiwan 23,036,087 July 2006 est.
51 Ghana 22,409,572 July 2006 est.
52 Romania 22,303,552 July 2006 est.
53 Yemen 21,456,188 July 2006 est.
54 Australia 20,264,082 July 2006 est.
55 Sri Lanka 20,222,240 July 2006 est.
56 Mozambique 19,686,505 July 2006 est.
57 Syria 18,881,361 July 2006 est.
58 Madagascar 18,595,469 July 2006 est.
59 Cote d''Ivoire 17,654,843 July 2006 est.
60 Cameroon 17,340,702 July 2006 est.
61 Netherlands 16,491,461 July 2006 est.
62 Chile 16,134,219 July 2006 est.
63 Kazakhstan 15,233,244 July 2006 est.
64 Burkina Faso 13,902,972 July 2006 est.
65 Cambodia 13,881,427 July 2006 est.
66 Ecuador 13,547,510 July 2006 est.
67 Malawi 13,013,926 July 2006 est.
68 Niger 12,525,094 July 2006 est.
69 Guatemala 12,293,545 July 2006 est.
70 Zimbabwe 12,236,805 July 2006 est.
71 Angola 12,127,071 July 2006 est.
72 Senegal 11,987,121 July 2006 est.
73 Mali 11,716,829 July 2006 est.
74 Zambia 11,502,010 July 2006 est.
75 Cuba 11,382,820 July 2006 est.
76 Greece 10,688,058 July 2006 est.
77 Portugal 10,605,870 July 2006 est.
78 Belgium 10,379,067 July 2006 est.
79 Belarus 10,293,011 July 2006 est.
80 Czech Republic 10,235,455 July 2006 est.
81 Tunisia 10,175,014 July 2006 est.
82 Hungary 9,981,334 July 2006 est.
83 Chad 9,944,201 July 2006 est.
84 Guinea 9,690,222 July 2006 est.
85 Serbia 9,396,411 2002 census
86 Dominican Republic 9,183,984 July 2006 est.
87 Sweden 9,016,596 July 2006 est.
88 Bolivia 8,989,046 July 2006 est.
89 Somalia 8,863,338 July 2006 est.
90 Rwanda 8,648,248 July 2006 est.
91 Haiti 8,308,504 July 2006 est.
92 Austria 8,192,880 July 2006 est.
93 Burundi 8,090,068 July 2006 est.
94 Azerbaijan 7,961,619 July 2006 est.
95 Benin 7,862,944 July 2006 est.
96 Switzerland 7,523,934 July 2006 est.
97 Bulgaria 7,385,367 July 2006 est.
98 Honduras 7,326,496 July 2006 est.
99 Tajikistan 7,320,815 July 2006 est.
100 Hong Kong 6,940,432 July 2006 est.
101 El Salvador 6,822,378 July 2006 est.
102 Paraguay 6,506,464 July 2006 est.
103 Laos 6,368,481 July 2006 est.
104 Israel 6,352,117 July 2006 est.
105 Sierra Leone 6,005,250 July 2006 est.
106 Jordan 5,906,760 July 2006 est.
107 Libya 5,900,754 July 2006 est.
108 Papua New Guinea 5,670,544 July 2006 est.
109 Nicaragua 5,570,129 July 2006 est.
110 Togo 5,548,702 July 2006 est.
111 Denmark 5,450,661 July 2006 est.
112 Slovakia 5,439,448 July 2006 est.
113 Finland 5,231,372 July 2006 est.
114 Kyrgyzstan 5,213,898 July 2006 est.
115 Turkmenistan 5,042,920 July 2006 est.
116 Eritrea 4,786,994 July 2006 est.
117 Georgia 4,661,473 July 2006 est.
118 Norway 4,610,820 July 2006 est.
119 Bosnia and Herzegovina 4,498,976 July 2006 est.
120 Croatia 4,494,749 July 2006 est.
121 Singapore 4,492,150 July 2006 est.
122 Moldova 4,466,706 July 2006 est.
123 Central African Republic 4,303,356 July 2006 est.
124 New Zealand 4,076,140 July 2006 est.
125 Costa Rica 4,075,261 July 2006 est.
126 Ireland 4,062,235 July 2006 est.
127 Puerto Rico 3,927,188 July 2006 est.
128 Lebanon 3,874,050 July 2006 est.
129 Congo, Republic of the 3,702,314 July 2006 est.
130 Lithuania 3,585,906 July 2006 est.
131 Albania 3,581,655 July 2006 est.
132 Uruguay 3,431,932 July 2006 est.
133 Panama 3,191,319 July 2006 est.
134 Mauritania 3,177,388 July 2006 est.
135 Oman 3,102,229 July 2006 est.
136 Liberia 3,042,004 July 2006 est.
137 Armenia 2,976,372 July 2006 est.
138 Mongolia 2,832,224 July 2006 est.
139 Jamaica 2,758,124 July 2006 est.
140 United Arab Emirates 2,602,713 July 2006 est.
141 West Bank 2,460,492
142 Kuwait 2,418,393 July 2006 est.
143 Bhutan 2,279,723 July 2006 est.
144 Latvia 2,274,735 July 2006 est.
145 Macedonia 2,050,554 July 2006 est.
146 Namibia 2,044,147 July 2006 est.
147 Lesotho 2,022,331 July 2006 est.
148 Slovenia 2,010,347 July 2006 est.
149 Gambia, The 1,641,564 July 2006 est.
150 Botswana 1,639,833 July 2006 est.
151 Guinea-Bissau 1,442,029 July 2006 est.
152 Gaza Strip 1,428,757 July 2006 est.
153 Gabon 1,424,906 July 2006 est.
154 Estonia 1,324,333 July 2006 est.
155 Mauritius 1,240,827 July 2006 est.
156 Swaziland 1,136,334 July 2006 est.
157 Trinidad and Tobago 1,065,842 July 2006 est.
158 East Timor 1,062,777 July 2006 est.
159 Fiji 905,949 July 2006 est.
160 Qatar 885,359 July 2006 est.
161 Reunion 787,584 July 2006 est.
162 Cyprus 784,301 July 2006 est.
163 Guyana 767,245 July 2006 est.
164 Bahrain 698,585 July 2006 est.
165 Comoros 690,948 July 2006 est.
166 Montenegro 630,548 2004
167 Solomon Islands 552,438 July 2006 est.
168 Equatorial Guinea 540,109 July 2006 est.
169 Djibouti 486,530 July 2006 est.
170 Luxembourg 474,413 July 2006 est.
171 Macau 453,125 July 2006 est.
172 Guadeloupe 452,776 July 2006 est.
173 Suriname 439,117 July 2006 est.
174 Martinique 436,131 July 2006 est.
175 Cape Verde 420,979 July 2006 est.
176 Malta 400,214 July 2006 est.
177 Brunei 379,444 July 2006 est.
178 Maldives 359,008 July 2006 est.
179 Bahamas, The 303,770 July 2006 est.
180 Iceland 299,388 July 2006 est.
181 Belize 287,730 July 2006 est.
182 Barbados 279,912 July 2006 est.
183 French Polynesia 274,578 July 2006 est.
184 Western Sahara 273,008 July 2006 est.
185 Netherlands Antilles 221,736 July 2006 est.
186 New Caledonia 219,246 July 2006 est.
187 Vanuatu 208,869 July 2006 est.
188 Mayotte 201,234 July 2006 est.
189 French Guiana 199,509 July 2006 est.
190 Sao Tome and Principe 193,413 July 2006 est.
191 Samoa 176,908 July 2006 est.
192 Guam 171,019 July 2006 est.
193 Saint Lucia 168,458 July 2006 est.
194 Saint Vincent and the Grenadines 117,848 July 2006 est.
195 Tonga 114,689 July 2006 est.
196 Virgin Islands 108,605 July 2006 est.
197 Micronesia, Federated States of 108,004 July 2006 est.
198 Kiribati 105,432 July 2006 est.
199 Jersey 91,084 July 2006 est.
200 Grenada 89,703 July 2006 est.
201 Northern Mariana Islands 82,459 July 2006 est.
202 Seychelles 81,541 July 2006 est.
203 Isle of Man 75,441 July 2006 est.
204 Aruba 71,891 July 2006 est.
205 Andorra 71,201 July 2006 est.
206 Antigua and Barbuda 69,108 July 2006 est.
207 Dominica 68,910 July 2006 est.
208 Bermuda 65,773 July 2006 est.
209 Guernsey 65,409 July 2006 est.
210 Marshall Islands 60,422 July 2006 est.
211 American Samoa 57,794 July 2006 est.
212 Greenland 56,361 July 2006 est.
213 Faroe Islands 47,246 July 2006 est.
214 Cayman Islands 45,436 July 2006 est.
215 Saint Kitts and Nevis 39,129 July 2006 est.
216 Liechtenstein 33,987 July 2006 est.
217 Monaco 32,543 July 2006 est.
218 San Marino 29,251 July 2006 est.
219 Gibraltar 27,928 July 2006 est.
220 British Virgin Islands 23,098 July 2006 est.
221 Cook Islands 21,388 July 2006 est.
222 Turks and Caicos Islands 21,152 July 2006 est.
223 Palau 20,579 July 2006 est.
224 Wallis and Futuna 16,025 July 2006 est.
225 Anguilla 13,477 July 2006 est.
226 Nauru 13,287 July 2006 est.
227 Tuvalu 11,810 July 2006 est.
228 Montserrat 9,439 July 2006 est.
229 Saint Helena 7,502 July 2006 est.
230 Saint Pierre and Miquelon 7,026 July 2006 est.
231 Falkland Islands (Islas Malvinas) 2,967 July 2006 est.
232 Svalbard 2,701 July 2006 est.
233 Niue 2,166 July 2006 est.
234 Norfolk Island 1,828 July 2006 est.
235 Christmas Island 1,493
236 Tokelau 1,392 July 2006 est.
237 Holy See (Vatican City) 932 July 2006 est.
238 Cocos (Keeling) Islands 574 July 2006 est.
239 Pitcairn Islands 45 July 2006 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2121
Rank Country Railways(km) Date of Information
1 World 1,115,205 2003
2 United States 226,605 2004
3 European Union 222,293 2003
4 Russia 87,157 2005
5 China 74,408 2004
6 India 63,230 2005
7 Canada 48,467 2005
8 Australia 47,738 2005
9 Germany 47,201 2005
10 Argentina 31,902 2005
11 Brazil 29,252 2005
12 France 29,085 2005
13 Japan 23,556 2005
14 Poland 23,072 2005
15 Ukraine 22,473 2005
16 South Africa 20,872 2005
17 Italy 19,459 2005
18 Mexico 17,562 2005
19 United Kingdom 17,156 2005
20 Spain 14,873 2005
21 Kazakhstan 13,700 2005
22 Sweden 11,481 2005
23 Romania 11,385 2005
24 Czech Republic 9,572 2005
25 Turkey 8,697 2005
26 Pakistan 8,163 2004
27 Hungary 7,937 2005
28 Iran 7,256 2005
29 Chile 6,585 2005
30 Indonesia 6,458 2005
31 Austria 6,011 2005
32 Sudan 5,978 2005
33 Finland 5,741 2005
34 Belarus 5,512 2005
35 Korea, North 5,214 2005
36 Congo, Democratic Republic of the 5,138 2005
37 Egypt 5,063 2005
38 Switzerland 4,583 2005
39 Bulgaria 4,294 2005
40 Cuba 4,226 2005
41 Serbia 4,135 2005
42 New Zealand 4,128 2005
43 Norway 4,077 2005
44 Thailand 4,071 2005
45 Algeria 3,973 2005
46 Burma 3,955 2005
47 Uzbekistan 3,950 2005
48 Tanzania 3,690 2005
49 Slovakia 3,662 2005
50 Belgium 3,521 2005
51 Bolivia 3,519 2005
52 Nigeria 3,505 2005
53 Korea, South 3,472 2005
54 Peru 3,462 2005
55 Ireland 3,312 2005
56 Colombia 3,304 2005
57 Mozambique 3,123 2005
58 Zimbabwe 3,077 2005
59 Azerbaijan 2,957 2005
60 Portugal 2,850 2005
61 Netherlands 2,808 2005
62 Kenya 2,778 2005
63 Bangladesh 2,768 2005
64 Angola 2,761 2005
65 Croatia 2,726 2005
66 Syria 2,711 2005
67 Denmark 2,673 2005
68 Vietnam 2,600 2005
69 Greece 2,571 2005
70 Taiwan 2,497 2005
71 Turkmenistan 2,440 2005
72 Namibia 2,382 2005
73 Latvia 2,303 2005
74 Iraq 2,200 2005
75 Zambia 2,173 2005
76 Tunisia 2,153 2005
77 Uruguay 2,073 2005
78 Morocco 1,907 2005
79 Malaysia 1,890 2005
80 Mongolia 1,810 2005
81 Lithuania 1,771 2005
82 Georgia 1,612 2005
83 Sri Lanka 1,449 2005
84 Saudi Arabia 1,392 2005
85 Uganda 1,244 2005
86 Slovenia 1,229 2005
87 Moldova 1,138 2005
88 Cameroon 987 2005
89 Ecuador 966 2005
90 Estonia 958 2005
91 Ghana 953 2005
92 Senegal 906 2005
93 Philippines 897 2005
94 Congo, Republic of the 894 2005
95 Botswana 888 2005
96 Guatemala 886 2005
97 Madagascar 854 2005
98 Israel 853 2005
99 Armenia 845 2005
100 Guinea 837 2005
101 Gabon 814 2005
102 Malawi 797 2005
103 Mali 729 2005
104 Honduras 699 2005
105 Macedonia 699 2005
106 Venezuela 682 2005
107 Ethiopia 681 2005
108 Cote d''Ivoire 660 2005
109 Burkina Faso 622 2005
110 Bosnia and Herzegovina 608 2005
111 Cambodia 602 2005
112 Fiji 597 2005
113 Benin 578 2005
114 Togo 568 2005
115 Dominican Republic 517 2005
116 Jordan 505 2005
117 Liberia 490 2005
118 Tajikistan 482 2005
119 Kyrgyzstan 470 2005
120 Albania 447 2005
121 Lebanon 401 2006
122 Panama 355 2005
123 Eritrea 306 2005
124 Swaziland 301 2005
125 El Salvador 283 2005
126 Costa Rica 278 2005
127 Luxembourg 274 2005
128 Jamaica 272 2003
129 Montenegro 250 2005
130 Guyana 187 2001 est.
131 Djibouti 100 2005
132 Puerto Rico 96 2005
133 Isle of Man 65 2006
134 Nepal 59 2005
135 Saint Kitts and Nevis 50 2005
136 Paraguay 36 2005
137 Nicaragua 6 2005
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2127
Rank Country Total fertility rate(children born/woman) Date of Information
1 Niger 7.46 2006 est.
2 Mali 7.42 2006 est.
3 Somalia 6.76 2006 est.
4 Uganda 6.71 2006 est.
5 Afghanistan 6.69 2006 est.
6 Yemen 6.58 2006 est.
7 Burundi 6.55 2006 est.
8 Burkina Faso 6.47 2006 est.
9 Congo, Democratic Republic of the 6.45 2006 est.
10 Angola 6.35 2006 est.
11 Chad 6.25 2006 est.
12 Sierra Leone 6.08 2006 est.
13 Congo, Republic of the 6.07 2006 est.
14 Liberia 6.02 2006 est.
15 Malawi 5.92 2006 est.
16 Mauritania 5.86 2006 est.
17 Guinea 5.79 2006 est.
18 Mayotte 5.79 2006 est.
19 Gaza Strip 5.78 2006 est.
20 Oman 5.77 2006 est.
21 Madagascar 5.62 2006 est.
22 Sao Tome and Principe 5.62 2006 est.
23 Nigeria 5.49 2006 est.
24 Rwanda 5.43 2006 est.
25 Zambia 5.39 2006 est.
26 Djibouti 5.31 2006 est.
27 Gambia, The 5.30 2006 est.
28 Ethiopia 5.22 2006 est.
29 Benin 5.20 2006 est.
30 Eritrea 5.08 2006 est.
31 Comoros 5.03 2006 est.
32 Tanzania 4.97 2006 est.
33 Togo 4.96 2006 est.
34 Haiti 4.94 2006 est.
35 Kenya 4.91 2006 est.
36 Maldives 4.90 2006 est.
37 Guinea-Bissau 4.86 2006 est.
38 Bhutan 4.74 2006 est.
39 Gabon 4.74 2006 est.
40 Sudan 4.72 2006 est.
41 Laos 4.68 2006 est.
42 Mozambique 4.62 2006 est.
43 Equatorial Guinea 4.55 2006 est.
44 Cote d''Ivoire 4.50 2006 est.
45 Central African Republic 4.41 2006 est.
46 Cameroon 4.39 2006 est.
47 Senegal 4.38 2006 est.
48 West Bank 4.28 2006 est.
49 Iraq 4.18 2006 est.
50 Kiribati 4.16 2006 est.
51 Nepal 4.10 2006 est.
52 Pakistan 4.00 2006 est.
53 Saudi Arabia 4.00 2006 est.
54 Tajikistan 4.00 2006 est.
55 Ghana 3.99 2006 est.
56 Solomon Islands 3.91 2006 est.
57 Paraguay 3.89 2006 est.
58 Papua New Guinea 3.88 2006 est.
59 Marshall Islands 3.85 2006 est.
60 Guatemala 3.82 2006 est.
61 Belize 3.60 2006 est.
62 Honduras 3.59 2006 est.
63 East Timor 3.53 2006 est.
64 Swaziland 3.53 2006 est.
65 Syria 3.40 2006 est.
66 Cape Verde 3.38 2006 est.
67 Cambodia 3.37 2006 est.
68 Turkmenistan 3.37 2006 est.
69 Lesotho 3.28 2006 est.
70 Libya 3.28 2006 est.
71 American Samoa 3.16 2006 est.
72 Micronesia, Federated States of 3.16 2006 est.
73 Zimbabwe 3.13 2006 est.
74 El Salvador 3.12 2006 est.
75 Bangladesh 3.11 2006 est.
76 Philippines 3.11 2006 est.
77 Nauru 3.11 2006 est.
78 Namibia 3.06 2006 est.
79 Turks and Caicos Islands 3.05 2006 est.
80 Malaysia 3.04 2006 est.
81 Tonga 3.00 2006 est.
82 French Guiana 2.98 2006 est.
83 Tuvalu 2.98 2006 est.
84 Samoa 2.94 2006 est.
85 Kuwait 2.91 2006 est.
86 Uzbekistan 2.91 2006 est.
87 United Arab Emirates 2.88 2006 est.
88 Bolivia 2.85 2006 est.
89 Dominican Republic 2.83 2006 est.
90 Egypt 2.83 2006 est.
91 Qatar 2.81 2006 est.
92 Botswana 2.79 2006 est.
93 Nicaragua 2.75 2006 est.
94 Fiji 2.73 2006 est.
95 India 2.73 2006 est.
96 Vanuatu 2.70 2006 est.
97 Kyrgyzstan 2.69 2006 est.
98 Ecuador 2.68 2006 est.
99 Morocco 2.68 2006 est.
100 Panama 2.68 2006 est.','bd8f84fad28fb71e0ba0cc44d6acbc874c55dc6021bb708bb741fb125abad259','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cebf06b3ceb24fa56fcdcd52ae4f6143dc7ae9dd4cb2c1d9f0edc94c8bebccb3',2006,'ZW','Zimbabwe','communications',13,'101 Jordan 2.63 2006 est.
102 Bahrain 2.60 2006 est.
103 World 2.59 2006 est.
104 Guam 2.58 2006 est.
105 Colombia 2.54 2006 est.
106 Peru 2.51 2006 est.
107 Azerbaijan 2.46 2006 est.
108 Palau 2.46 2006 est.
109 Reunion 2.45 2006 est.
110 Mexico 2.42 2006 est.
111 Israel 2.41 2006 est.
112 Jamaica 2.41 2006 est.
113 Greenland 2.40 2006 est.
114 Indonesia 2.40 2006 est.
115 Grenada 2.34 2006 est.
116 Suriname 2.32 2006 est.
117 Saint Kitts and Nevis 2.31 2006 est.
118 Brunei 2.28 2006 est.
119 New Caledonia 2.28 2006 est.
120 Mongolia 2.25 2006 est.
121 Antigua and Barbuda 2.24 2006 est.
122 Costa Rica 2.24 2006 est.
123 Venezuela 2.23 2006 est.
124 South Africa 2.20 2006 est.
125 Bahamas, The 2.18 2006 est.
126 Saint Lucia 2.18 2006 est.
127 Faroe Islands 2.17 2006 est.
128 Virgin Islands 2.17 2006 est.
129 Argentina 2.16 2006 est.
130 Korea, North 2.10 2006 est.
131 United States 2.09 2006 est.
132 Guyana 2.04 2006 est.
133 Albania 2.03 2006 est.
134 French Polynesia 2.01 2006 est.
135 Saint Pierre and Miquelon 2.01 2006 est.
136 Chile 2.00 2006 est.
137 Netherlands Antilles 1.99 2006 est.
138 Burma 1.98 2006 est.
139 Mauritius 1.95 2006 est.
140 Dominica 1.94 2006 est.
141 Iceland 1.92 2006 est.
142 Turkey 1.92 2006 est.
143 Brazil 1.91 2006 est.
144 Vietnam 1.91 2006 est.
145 Cayman Islands 1.90 2006 est.
146 Guadeloupe 1.90 2006 est.
147 Lebanon 1.90 2006 est.
148 Algeria 1.89 2006 est.
149 Kazakhstan 1.89 2006 est.
150 Uruguay 1.89 2006 est.
151 Bermuda 1.89 2006 est.
152 Ireland 1.86 2006 est.
153 Moldova 1.85 2006 est.
154 Sri Lanka 1.84 2006 est.
155 France 1.84 2006 est.
156 Saint Vincent and the Grenadines 1.83 2006 est.
157 Cyprus 1.82 2006 est.
158 Iran 1.80 2006 est.
159 Aruba 1.79 2006 est.
160 New Zealand 1.79 2006 est.
161 Martinique 1.79 2006 est.
162 Luxembourg 1.78 2006 est.
163 Norway 1.78 2006 est.
164 Serbia 1.78 2006 est.
165 Montserrat 1.77 2006 est.
166 Australia 1.76 2006 est.
167 Monaco 1.76 2006 est.
168 Puerto Rico 1.75 2006 est.
169 Denmark 1.74 2006 est.
170 Tunisia 1.74 2006 est.
171 Seychelles 1.74 2006 est.
172 Trinidad and Tobago 1.74 2006 est.
173 Anguilla 1.73 2006 est.
174 China 1.73 2006 est.
175 Finland 1.73 2006 est.
176 British Virgin Islands 1.72 2006 est.
177 Cuba 1.66 2006 est.
178 United Kingdom 1.66 2006 est.
179 Sweden 1.66 2006 est.
180 Netherlands 1.66 2006 est.
181 Barbados 1.65 2006 est.
182 Isle of Man 1.65 2006 est.
183 Gibraltar 1.65 2006 est.
184 Belgium 1.64 2006 est.
185 Thailand 1.64 2006 est.
186 Canada 1.61 2006 est.
187 Jersey 1.58 2006 est.
188 Macedonia 1.57 2006 est.
189 Taiwan 1.57 2006 est.
190 Saint Helena 1.55 2006 est.
191 Liechtenstein 1.51 2006 est.
192 Malta 1.50 2006 est.
193 European Union 1.47 2006 est.
194 Portugal 1.47 2006 est.
195 Belarus 1.43 2006 est.
196 Switzerland 1.43 2006 est.
197 Georgia 1.42 2006 est.
198 Estonia 1.40 2006 est.
199 Japan 1.40 2006 est.
200 Croatia 1.40 2006 est.
201 Guernsey 1.39 2006 est.
202 Germany 1.39 2006 est.
203 Bulgaria 1.38 2006 est.
204 Romania 1.37 2006 est.
205 Austria 1.36 2006 est.
206 Greece 1.34 2006 est.
207 San Marino 1.34 2006 est.
208 Armenia 1.33 2006 est.
209 Slovakia 1.33 2006 est.
210 Hungary 1.32 2006 est.
211 Andorra 1.30 2006 est.
212 Italy 1.28 2006 est.
213 Spain 1.28 2006 est.
214 Russia 1.28 2006 est.
215 Korea, South 1.27 2006 est.
216 Latvia 1.27 2006 est.
217 Poland 1.25 2006 est.
218 Slovenia 1.25 2006 est.
219 Northern Mariana Islands 1.24 2006 est.
220 Bosnia and Herzegovina 1.22 2006 est.
221 Czech Republic 1.21 2006 est.
222 Lithuania 1.20 2006 est.
223 Ukraine 1.17 2006 est.
224 Singapore 1.06 2006 est.
225 Macau 1.02 2006 est.
226 Hong Kong 0.95 2006 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2129
Rank Country Unemployment rate(%) Date of Information
1 Andorra 0.00 1996 est.
2 Norfolk Island 0.00
3 Guernsey 0.50 1999 est.
4 Isle of Man 0.60 2004 est.
5 Uzbekistan 0.70 2005 est.
6 Jersey 0.90 2004 est.
7 Faroe Islands 1.00 October 2000
8 Azerbaijan 1.10 2005 est.
9 Liechtenstein 1.30 September 2002
10 Belarus 1.60 2005
11 Vanuatu 1.70
12 Thailand 1.80 2005 est.
13 Cuba 1.90 2005 est.
14 Gibraltar 2.00 2001 est.
15 Kiribati 2.00 1992 est.
16 Bermuda 2.10 2004 est.
17 Iceland 2.10 2005 est.
18 Kuwait 2.20 2004 est.
19 United Arab Emirates 2.40 2001
20 Laos 2.40 2005 est.
21 Vietnam 2.40 2005 est.
22 Bangladesh 2.50 2005 est.
23 Cambodia 2.50 2000 est.
24 San Marino 2.60 2001
25 Qatar 2.70 2001
26 Papua New Guinea 2.80 2004
27 Nigeria 2.90 2005 est.
28 Singapore 3.10 2005 est.
29 Ukraine 3.10 2005 est.
30 Mexico 3.60 2005 est.
31 British Virgin Islands 3.60 1997
32 Malaysia 3.60 2005 est.
33 Korea, South 3.70 2005 est.
34 New Zealand 3.70 2005 est.
35 Switzerland 3.80 2005 est.
36 Northern Mariana Islands 3.90
37 Cyprus 4.00
38 Macau 4.10 3rd Quarter 2005
39 Taiwan 4.10 2005 est.
40 Palau 4.20 2005 est.
41 Ireland 4.30 2005 est.
42 Cayman Islands 4.40 2004
43 Japan 4.40 2005 est.
44 Luxembourg 4.50 2005 est.
45 Saint Kitts and Nevis 4.50 1997
46 Norway 4.60 2005 est.
47 United Kingdom 4.70 2005 est.
48 Brunei 4.80 2004
49 Burma 5.00 2005 est.
50 Australia 5.10 2005 est.
51 United States 5.10 2005 est.
52 Austria 5.20 2005 est.
53 Hong Kong 5.50 2005 est.
54 Cyprus 5.60
55 Nicaragua 5.60 2005 est.
56 Denmark 5.70 2005 est.
57 Sweden 5.80 2005 est.
58 Montserrat 6.00 1998 est.
59 Virgin Islands 6.20 2004
60 Slovenia 6.30 2005 est.
61 El Salvador 6.50 2005 est.
62 Costa Rica 6.60 2005 est.
63 Netherlands 6.60 2005 est.
64 Pakistan 6.60 2005 est.
65 Mongolia 6.70 2003
66 Canada 6.80 2005 est.
67 Aruba 6.90 2005 est.
68 Hungary 7.20 2005
69 Guatemala 7.50 2003 est.
70 Latvia 7.50 2005 est.
71 Fiji 7.60 1999
72 Russia 7.60 2005 est.
73 Portugal 7.60 2005 est.
74 Peru 7.60 2005 est.
75 Sri Lanka 7.70 2005 est.
76 Romania 7.70 2005 est.
77 Italy 7.70 2005 est.
78 Estonia 7.80 2005
79 Malta 7.80 2005 est.
80 Czech Republic 7.90 2005
81 Anguilla 8.00 2002
82 Central African Republic 8.00 2001 est.
83 Bolivia 8.00 2005 est.
84 Trinidad and Tobago 8.00 2005 est.
85 Moldova 8.00 2002 est.
86 Chile 8.10 2005 est.
87 Kazakhstan 8.10 2005 est.
88 Lithuania 8.20 2005
89 Belgium 8.40 2005 est.
90 Finland 8.40 2005 est.
91 Philippines 8.70 2005 est.
92 India 8.90 2005 est.
93 China 9.00 2005 est.
94 Israel 9.00 2005 est.
95 Spain 9.20 2005 est.
96 European Union 9.40 2005 est.
97 Egypt 9.50 2005 est.
98 Suriname 9.50 2004
99 Mauritius 9.60 2005 est.
100 Brazil 9.80 2005 est.
101 Panama 9.80 2005 est.
102 Bulgaria 9.90 2005
103 France 9.90 2005 est.
104 Greece 9.90 2005 est.
105 Greenland 10.00 2000 est.
106 Turks and Caicos Islands 10.00 1997 est.
107 Bahamas, The 10.20 2005 est.
108 Turkey 10.20 2005 est.
109 Saint Pierre and Miquelon 10.30 1999
110 Barbados 10.70 2003 est.
111 Ecuador 10.70 2005 est.
112 Antigua and Barbuda 11.00 2001 est.
113 Morocco 11.00 2005 est.
114 Iran 11.20 2004 est.
115 Guam 11.40 2002 est.
116 Jamaica 11.50 2005 est.
117 Argentina 11.60 2005 est.
118 Germany 11.70 2005 est.
119 Colombia 11.80 2005 est.
120 Indonesia 11.80 2005 est.
121 French Polynesia 11.80 1994
122 Niue 12.00
123 Tajikistan 12.00 2004 est.
124 Puerto Rico 12.00 2002
125 Uruguay 12.20 2005 est.
126 Venezuela 12.20 2005 est.
127 Syria 12.30 2004 est.
128 Grenada 12.50 2000
129 Jordan 12.50 2004 est.
130 Georgia 12.60 2004 est.
131 Belize 12.90 2003
132 Cote d''Ivoire 13.00 1998
133 Saudi Arabia 13.00 2004 est.
134 Tonga 13.00 FY03/04 est.
135 Cook Islands 13.10 2005
136 Saint Helena 14.00 1998 est.
137 Tunisia 14.20 2005 est.
138 Albania 14.30 2005 est.
139 Mali 14.60 2001 est.
140 Bahrain 15.00 2005 est.
141 Oman 15.00 2004 est.
142 Saint Vincent and the Grenadines 15.00 2001 est.
143 Wallis and Futuna 15.20
144 Paraguay 16.00 2005 est.
145 Slovakia 16.40 2005 est.
146 Dominican Republic 17.00 2005 est.
147 Netherlands Antilles 17.00 2002 est.
148 Algeria 17.10 2005 est.
149 New Caledonia 17.10 2004
150 Croatia 18.00 2005 est.
151 Lebanon 18.00 1997 est.
152 Kyrgyzstan 18.00 2004 est.
153 Poland 18.20 2005 est.
154 Sudan 18.70 2002 est.
155 French Guiana 19.20 December 2003
156 West Bank 19.90 January-September 2005
157 Comoros 20.00 1996 est.
158 Ghana 20.00 1997 est.
159 Saint Lucia 20.00 2003 est.
160 Mauritania 20.00 2004 est.
161 Cape Verde 21.00 2000 est.
162 Mozambique 21.00 1997 est.
163 Gabon 21.00 1997 est.
164 Micronesia, Federated States of 22.00 2000 est.
165 Monaco 22.00 1999
166 Dominica 23.00 2000 est.
167 Botswana 23.80 2004
168 Iraq 25.00 2005 est.
169 South Africa 26.60 2005 est.
170 Guadeloupe 26.90 2003
171 Martinique 27.20 1998
172 Montenegro 27.70 2005
173 Honduras 28.00 2005 est.
174 American Samoa 29.80 2005
175 Cameroon 30.00 2001 est.
176 World 30.00
177 Libya 30.00 2004 est.
178 Equatorial Guinea 30.00 1998 est.
179 Marshall Islands 30.90 2000 est.
180 Gaza Strip 31.00 January-September 2005 avg.
181 Reunion 31.00 2002
182 Armenia 31.60 2004 est.
183 Serbia 31.60 2005 est.
184 Mayotte 32.80 2003
185 Namibia 35.00 1998
186 Yemen 35.00 2003 est.
187 Macedonia 37.30 2005 est.
188 Afghanistan 40.00 2005 est.
189 Kenya 40.00 2001 est.
190 Swaziland 40.00 2005 est.
191 Nepal 42.00 2004 est.
192 Lesotho 45.00 2002
193 Bosnia and Herzegovina 45.50 31 December 2004 est.
194 Senegal 48.00 2001 est.
195 Djibouti 50.00 2004 est.
196 Zambia 50.00 2000 est.
197 East Timor 50.00 2001 est.
198 Cocos (Keeling) Islands 60.00 2000 est.
199 Turkmenistan 60.00 2004 est.
200 Zimbabwe 80.00 2005 est.
201 Liberia 85.00 2003 est.
202 Nauru 90.00 2004 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2147
Rank Country Area(sq km) Date of Information
1 World 510,072,000
2 Pacific Ocean 155,557,000
3 Atlantic Ocean 76,762,000
4 Indian Ocean 68,556,000
5 Southern Ocean 20,327,000
6 Russia 17,075,200
7 Arctic Ocean 14,056,000
8 Antarctica 14,000,000
9 Canada 9,984,670
10 United States 9,631,420
11 China 9,596,960
12 Brazil 8,511,965
13 Australia 7,686,850
14 European Union 3,976,372
15 India 3,287,590
16 Argentina 2,766,890
17 Kazakhstan 2,717,300
18 Sudan 2,505,810
19 Algeria 2,381,740
20 Congo, Democratic Republic of the 2,345,410
21 Greenland 2,166,086
22 Mexico 1,972,550
23 Saudi Arabia 1,960,582
24 Indonesia 1,919,440
25 Libya 1,759,540
26 Iran 1,648,000
27 Mongolia 1,564,116
28 Peru 1,285,220
29 Chad 1,284,000
30 Niger 1,267,000
31 Angola 1,246,700
32 Mali 1,240,000
33 South Africa 1,219,912
34 Colombia 1,138,910
35 Ethiopia 1,127,127
36 Bolivia 1,098,580
37 Mauritania 1,030,700
38 Egypt 1,001,450
39 Tanzania 945,087
40 Nigeria 923,768
41 Venezuela 912,050
42 Namibia 825,418
43 Pakistan 803,940
44 Mozambique 801,590
45 Turkey 780,580
46 Chile 756,950
47 Zambia 752,614
48 Burma 678,500
49 Afghanistan 647,500
50 Somalia 637,657
51 Central African Republic 622,984
52 Ukraine 603,700
53 Botswana 600,370
54 Madagascar 587,040
55 Kenya 582,650
56 France 547,030
57 Yemen 527,970
58 Thailand 514,000
59 Spain 504,782
60 Turkmenistan 488,100
61 Cameroon 475,440
62 Papua New Guinea 462,840
63 Sweden 449,964
64 Uzbekistan 447,400
65 Morocco 446,550
66 Iraq 437,072
67 Paraguay 406,750
68 Zimbabwe 390,580
69 Japan 377,835
70 Germany 357,021
71 Congo, Republic of the 342,000
72 Finland 338,145
73 Malaysia 329,750
74 Vietnam 329,560
75 Norway 323,802
76 Cote d''Ivoire 322,460
77 Poland 312,685
78 Italy 301,230
79 Philippines 300,000
80 Ecuador 283,560
81 Burkina Faso 274,200
82 New Zealand 268,680
83 Gabon 267,667
84 Western Sahara 266,000
85 Guinea 245,857
86 United Kingdom 244,820
87 Ghana 239,460
88 Romania 237,500
89 Laos 236,800
90 Uganda 236,040
91 Guyana 214,970
92 Oman 212,460
93 Belarus 207,600
94 Kyrgyzstan 198,500
95 Senegal 196,190
96 Syria 185,180
97 Cambodia 181,040
98 Uruguay 176,220
99 Tunisia 163,610
100 Suriname 163,270
101 Nepal 147,181
102 Bangladesh 144,000
103 Tajikistan 143,100
104 Greece 131,940
105 Nicaragua 129,494
106 Eritrea 121,320
107 Korea, North 120,540
108 Malawi 118,480
109 Benin 112,620
110 Honduras 112,090
111 Liberia 111,370
112 Bulgaria 110,910
113 Cuba 110,860
114 Guatemala 108,890
115 Iceland 103,000
116 Korea, South 98,480
117 Hungary 93,030
118 Portugal 92,391
119 Jordan 92,300
120 French Guiana 91,000
121 Serbia 88,361
122 Azerbaijan 86,600
123 Austria 83,870
124 United Arab Emirates 82,880
125 Czech Republic 78,866
126 Panama 78,200
127 Sierra Leone 71,740
128 Ireland 70,280
129 Georgia 69,700
130 Sri Lanka 65,610
131 Lithuania 65,200
132 Latvia 64,589
133 Svalbard 61,020
134 Togo 56,785
135 Croatia 56,542
136 British Indian Ocean Territory 54,400
137 Bosnia and Herzegovina 51,129
138 Costa Rica 51,100
139 Slovakia 48,845
140 Dominican Republic 48,730
141 Bhutan 47,000
142 Estonia 45,226
143 Denmark 43,094
144 Netherlands 41,526
145 Switzerland 41,290
146 Guinea-Bissau 36,120
147 Taiwan 35,980
148 Moldova 33,843
149 Belgium 30,528
150 Lesotho 30,355
151 Armenia 29,800
152 Albania 28,748
153 Solomon Islands 28,450
154 Equatorial Guinea 28,051
155 Burundi 27,830
156 Haiti 27,750
157 Rwanda 26,338
158 Macedonia 25,333
159 Djibouti 23,000
160 Belize 22,966
161 El Salvador 21,040
162 Israel 20,770
163 Slovenia 20,273
164 New Caledonia 19,060
165 Fiji 18,270
166 Kuwait 17,820
167 Swaziland 17,363
168 East Timor 15,007
169 Montenegro 14,026
170 Bahamas, The 13,940
171 Puerto Rico 13,790
172 Vanuatu 12,200
173 Falkland Islands (Islas Malvinas) 12,173
174 Marshall Islands 11,854
175 Qatar 11,437
176 Gambia, The 11,300
177 Jamaica 10,991
178 Lebanon 10,400
179 Cyprus 9,250
180 French Southern and Antarctic Lands 7,829
181 West Bank 5,860
182 Brunei 5,770
183 Trinidad and Tobago 5,128
184 French Polynesia 4,167
185 Cape Verde 4,033
186 South Georgia and the South Sandwich Islands 3,903
187 Samoa 2,944
188 Luxembourg 2,586
189 Reunion 2,517
190 Comoros 2,170
191 Mauritius 2,040
192 Virgin Islands 1,910
193 Guadeloupe 1,780
194 Faroe Islands 1,399
195 Martinique 1,100
196 Hong Kong 1,092
197 Sao Tome and Principe 1,001
198 Netherlands Antilles 960
199 Kiribati 811
200 Dominica 754
201 Tonga 748
202 Micronesia, Federated States of 702
203 Singapore 693
204 Bahrain 665
205 Saint Lucia 616
206 Isle of Man 572
207 Guam 541
208 Northern Mariana Islands 477
209 Andorra 468
210 Palau 458
211 Seychelles 455
212 Antigua and Barbuda 443
213 Barbados 431
214 Turks and Caicos Islands 430
215 Saint Helena 413
216 Heard Island and McDonald Islands 412
217 Saint Vincent and the Grenadines 389
218 Jan Mayen 377
219 Mayotte 374
220 Gaza Strip 360
221 Grenada 344
222 Malta 316
223 Maldives 300
224 Wallis and Futuna 274
225 Cayman Islands 262
226 Saint Kitts and Nevis 261
227 Niue 260
228 Saint Pierre and Miquelon 242
229 Cook Islands 237
230 American Samoa 199
231 Aruba 193
232 Liechtenstein 160
233 British Virgin Islands 153
234 Christmas Island 135
235 Dhekelia 131
236 Akrotiri 123
237 Jersey 116
238 Anguilla 102
239 Montserrat 102
240 Iles Eparses 80
241 Guernsey 78
242 San Marino 61
243 Bermuda 53
244 Bouvet Island 49
245 Pitcairn Islands 47
246 Norfolk Island 35
247 Macau 28
248 Europa Island 28
249 Tuvalu 26
250 United States Pacific Island Wildlife Refuges 22
251 Nauru 21
252 Cocos (Keeling) Islands 14
253 Palmyra Atoll 12
254 Tokelau 10
255 Gibraltar 7
256 Wake Island 7
257 Midway Islands 6
258 Clipperton Island 6
259 Navassa Island 5
260 Ashmore and Cartier Islands 5
261 Glorioso Islands 5
262 Spratly Islands 5
263 Jarvis Island 5
264 Juan de Nova Island 4
265 Coral Sea Islands 3
266 Johnston Atoll 3
267 Monaco 2
268 Howland Island 2
269 Baker Island 1
270 Kingman Reef 1
271 Tromelin Island 1
272 Holy See (Vatican City) 0
273 Bassas da India 0
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2150
Rank Country Telephones - main lines in use Date of Information
1 World 1,263,367,600 2005
2 China 350,433,000 2005
3 United States 268,000,000 2003
4 European Union 238,763,162 2002
5 Japan 58,780,000 2005
6 Germany 55,046,000 2005
7 India 49,750,000 2005
8 Brazil 42,382,000 2004
9 Russia 40,100,000 2005
10 France 35,700,000 2005
11 United Kingdom 32,943,000 2005
12 Italy 25,049,000 2005
13 Korea, South 23,745,000 2005
14 Mexico 19,512,000 2005
15 Iran 18,986,000 2005
16 Turkey 18,978,000 2005
17 Spain 18,322,000 2005
18 Canada 18,276,000 2005
19 Vietnam 15,845,000 2005
20 Taiwan 13,615,000 2005
21 Indonesia 12,772,000 2005
22 Ukraine 12,142,000 2004
23 Poland 11,803,000 2005
24 Australia 11,460,000 2005
25 Egypt 10,396,100 2005
26 Argentina 8,800,000 2005
27 Colombia 7,678,800 2005
28 Netherlands 7,600,000 2005
29 Thailand 7,035,000 2005
30 Sweden 6,447,000 2004
31 Greece 6,303,000 2005
32 Pakistan 5,277,500 2005
33 Switzerland 5,123,000 2005
34 Belgium 4,801,000 2004
35 South Africa 4,729,000 2005
36 Romania 4,391,000 2005
37 Malaysia 4,366,000 2005
38 Portugal 4,234,000 2005
39 Saudi Arabia 3,800,000 2005
40 Hong Kong 3,794,600 2005
41 Austria 3,705,000 2005
42 Venezuela 3,605,500 2005
43 Philippines 3,437,500 2004
44 Chile 3,435,900 2005
45 Hungary 3,356,000 2005
46 Denmark 3,350,000 2005
47 Belarus 3,284,300 2005
48 Czech Republic 3,217,300 2005
49 Israel 2,936,300 2005
50 Syria 2,903,000 2005
51 Serbia 2,685,400 2004
52 Algeria 2,572,000 2005
53 Kazakhstan 2,500,000 2004
54 Bulgaria 2,483,500 2005
55 Peru 2,250,500 2005
56 Norway 2,129,000 2005
57 Finland 2,120,000 2005
58 Ireland 2,033,000 2005
59 Croatia 1,889,500 2005
60 Singapore 1,848,000 2005
61 New Zealand 1,800,500 2004
62 Uzbekistan 1,717,100 2003
63 Ecuador 1,701,500 2005
64 Costa Rica 1,388,500 2005
65 Morocco 1,341,200 2005
66 Tunisia 1,257,500 2005
67 Sri Lanka 1,244,000 2005
68 United Arab Emirates 1,237,000 2005
69 Nigeria 1,223,300 2005
70 Slovakia 1,197,000 2005
71 Guatemala 1,132,100 2004
72 Puerto Rico 1,111,900 2004
73 Azerbaijan 1,091,400 2005
74 Bangladesh 1,070,000 2005
75 Iraq 1,034,200 2004
76 Uruguay 1,000,000 2004
77 Lebanon 990,000 2005
78 Korea, North 980,000 2003
79 El Salvador 971,500 2005
80 Bosnia and Herzegovina 968,900 2005
81 Moldova 929,400 2005
82 Dominican Republic 894,500 2005
83 Cuba 849,900 2005
84 Slovenia 816,400 2005
85 Lithuania 801,100 2005
86 Yemen 798,100 2004
87 Libya 750,000 2003
88 Latvia 731,000 2005
89 Georgia 683,200 2004
90 Sudan 670,000 2005
91 Bolivia 646,300 2005
92 Jordan 617,300 2004
93 Ethiopia 610,300 2005
94 Armenia 582,500 2004
95 Macedonia 533,200 2005
96 Kuwait 510,300 2005
97 Honduras 494,400 2005
98 Burma 476,200 2005
99 Nepal 448,600 2005
100 Estonia 442,000 2005
101 Panama 440,100 2005
102 Kyrgyzstan 438,200 2005
103 Cyprus 420,000
104 Turkmenistan 376,100 2003
105 Mauritius 359,000 2005
106 West Bank 357,300 2004
107 Gaza Strip 349,000 2005
108 Jamaica 342,000 2005
109 Zimbabwe 328,000 2005
110 Trinidad and Tobago 323,500 2005
111 Ghana 321,500 2005
112 Paraguay 320,300 2005
113 Reunion 300,000 2001
114 Kenya 281,800 2005
115 Senegal 266,600 2005
116 Oman 265,200 2005
117 Cote d''Ivoire 257,900 2004
118 Albania 255,000 2003
119 Tajikistan 245,200 2004
120 Luxembourg 244,500 2005
121 Nicaragua 220,900 2005
122 Guadeloupe 210,000 2001
123 Qatar 205,400 2005
124 Malta 202,100 2005
125 Bahrain 196,500 2005
126 Iceland 193,900 2005
127 Montenegro 177,663 2005
128 Macau 174,400 2005
129 Martinique 172,000 2001
130 Mongolia 156,000 2005
131 Tanzania 148,400 2004
132 Haiti 140,000 2004
133 Bahamas, The 139,900 2004
134 Barbados 134,900 2005
135 Botswana 132,000 2005
136 Namibia 127,900 2004
137 Guyana 110,100 2005
138 Malawi 102,700 2005
139 Fiji 102,000 2003
140 Uganda 100,800 2005
141 Afghanistan 100,000 2005
142 Somalia 100,000 2005
143 Cameroon 99,400 2004
144 Burkina Faso 97,400 2005
145 Zambia 94,700 2005
146 Angola 94,300 2005
147 Laos 90,067 2006
148 Brunei 90,000 2002
149 Cyprus 86,228
150 Guam 84,134 2001
151 Suriname 81,100 2004
152 Netherlands Antilles 81,000 2001
153 Benin 76,300 2005
154 Mali 75,000 2005
155 Jersey 73,900 2001
156 Cape Verde 71,400 2005
157 Virgin Islands 70,900 2004
158 Mozambique 69,700 2004
159 Madagascar 66,900 2005
160 Papua New Guinea 62,000 2002
161 Togo 58,600 2005
162 Bermuda 56,000 2002
163 New Caledonia 55,300 2005
164 Guernsey 55,100 2004
165 French Polynesia 53,400 2005
166 Saint Lucia 51,100 2002
167 French Guiana 51,000 2001
168 Isle of Man 51,000 1999
169 Lesotho 48,000 2005
170 Gambia, The 44,000 2005
171 Mauritania 41,000 2005
172 Gabon 39,100 2005
173 Antigua and Barbuda 38,000 2004
174 Cayman Islands 38,000 2002
175 Eritrea 37,700 2005
176 Aruba 37,100 2002
177 Cambodia 36,400 2003
178 Andorra 35,400 2005
179 Swaziland 35,000 2005
180 Monaco 33,700 2002
181 Belize 33,300 2005
182 Bhutan 32,700 2005
183 Grenada 32,700 2004
184 Maldives 32,300 2005
185 Burundi 27,700 2004
186 Guinea 26,200 2003
187 Greenland 25,300 2002
188 Saint Kitts and Nevis 25,000 2004
189 Gibraltar 24,512 2002
190 Niger 24,000 2005
191 Sierra Leone 24,000 2002
192 Faroe Islands 23,800 2005
193 Rwanda 23,000 2004
194 Saint Vincent and the Grenadines 22,500 2005
195 Seychelles 21,400 2005
196 Northern Mariana Islands 21,000 2000
197 Dominica 21,000 2004
198 San Marino 20,600 2002
199 Liechtenstein 19,900 2002
200 Comoros 16,900 2005
201 American Samoa 15,000 2001
202 Congo, Republic of the 13,800 2004
203 Samoa 13,300 2003
204 Chad 13,000 2004
205 Micronesia, Federated States of 12,400 2005
206 British Virgin Islands 11,700 2002
207 Tonga 11,200 2002
208 Djibouti 11,100 2004
209 Congo, Democratic Republic of the 10,600 2005
210 Guinea-Bissau 10,600 2003
211 Central African Republic 10,000 2004
212 Equatorial Guinea 10,000 2005
213 Mayotte 10,000 2002
214 Solomon Islands 7,400 2005
215 Sao Tome and Principe 7,000 2004
216 Liberia 6,900 2002
217 Vanuatu 6,800 2004
218 Palau 6,700 2002
219 Anguilla 6,200 2002
220 Cook Islands 6,200 2002
221 Turks and Caicos Islands 5,700 2002
222 Marshall Islands 5,510 2004
223 Holy See (Vatican City) 5,120 2005
224 Saint Pierre and Miquelon 4,800 2002
225 Kiribati 4,500 2002
226 Norfolk Island 2,532 2004
227 Falkland Islands (Islas Malvinas) 2,400 2002
228 Saint Helena 2,200 2002
229 Nauru 1,900 2002
230 Wallis and Futuna 1,900 2002
231 Niue 1,100 2002
232 Tuvalu 700 2002
233 Tokelau 300 2002
234 Cocos (Keeling) Islands 287 1992
235 Pitcairn Islands 1 2004
236 Antarctica 0 2001
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2151
Rank Country Telephones - mobile cellular Date of Information
1 World 2,168,433,600 2005
2 China 393,428,000 2005
3 European Union 314,644,700 2002
4 United States 219,400,000 2005
5 Russia 120,000,000 2005
6 Japan 94,745,000 2005
7 Brazil 86,210,000 2005
8 Germany 79,200,000 2005
9 Italy 72,200,000 2005
10 India 69,193,321 2006
11 United Kingdom 61,091,000 2004
12 France 48,058,000 2005
13 Mexico 47,462,000 2005
14 Indonesia 46,910,000 2005
15 Turkey 43,609,000 2005
16 Spain 41,328,000 2005
17 Korea, South 38,342,000 2005
18 South Africa 33,960,000 2005
19 Philippines 32,810,000 2005
20 Poland 29,166,400 2005
21 Thailand 27,379,000 2005
22 Taiwan 22,170,000 2005
23 Argentina 22,100,000 2005
24 Colombia 21,850,000 2005
25 Nigeria 21,571,131 2006
26 Malaysia 19,545,000 2005
27 Australia 18,420,000 2005
28 Ukraine 17,214,000 2005
29 Canada 16,600,000 2005
30 Netherlands 15,834,000 2005
31 Egypt 14,045,134 2005
32 Algeria 13,661,000 2005
33 Romania 13,354,000 2005
34 Saudi Arabia 13,300,000 2005
35 Pakistan 12,771,000 2005
36 Venezuela 12,496,000 2005
37 Morocco 12,393,000 2005
38 Czech Republic 11,776,000 2005
39 Portugal 11,448,000 2005
40 Chile 10,570,000 2005
41 Greece 10,043,000 2005
42 Vietnam 9,593,000 2005
43 Belgium 9,460,000 2005
44 Hungary 9,320,000 2005
45 Bangladesh 9,000,000 2005
46 Hong Kong 8,693,000 2005
47 Sweden 8,436,000 2005
48 Austria 8,160,000 2005
49 Israel 7,757,000 2005
50 Iran 7,222,000 2005
51 Switzerland 6,847,000 2005
52 Ecuador 6,246,000 2005
53 Bulgaria 6,245,000 2005
54 Tunisia 5,681,000 2005
55 Peru 5,583,000 2005
56 Denmark 5,469,000 2005
57 Finland 5,','86e8d46777b2f290c908f2943aa1c76a12549ec8f9c5540493e2932021cf15bc','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1428525d8f04ebee9ef378d6f7f7b8ccd9213234b31cc407dee164d23708f098',2006,'ZW','Zimbabwe','communications',14,'231,000 2005
58 Serbia 5,229,000 2005
59 Kazakhstan 4,955,000 2005
60 Norway 4,755,000 2005
61 Kenya 4,612,000 2005
62 Slovakia 4,540,000 2005
63 United Arab Emirates 4,535,000 2005
64 Singapore 4,385,000 2005
65 Lithuania 4,353,000 2005
66 Ireland 4,210,000 2005
67 Belarus 4,098,000 2005
68 Dominican Republic 3,623,000 2005
69 New Zealand 3,530,000 2005
70 Sri Lanka 3,362,000 2005
71 Guatemala 3,168,300 2004
72 Croatia 2,984,000 2005
73 Syria 2,950,000 2005
74 Ghana 2,842,000 2005
75 Congo, Democratic Republic of the 2,746,000 2005
76 Jamaica 2,700,000 2005
77 Puerto Rico 2,682,000 2004
78 Bolivia 2,421,000 2005
79 El Salvador 2,412,000 2005
80 Kuwait 2,380,000 2005
81 Cameroon 2,259,000 2005
82 Azerbaijan 2,242,000 2005
83 Cote d''Ivoire 2,190,000 2005
84 Yemen 2,000,000 2005
85 Tanzania 1,942,000 2005
86 Paraguay 1,887,000 2005
87 Latvia 1,872,000 2005
88 Sudan 1,828,000 2005
89 Slovenia 1,759,000 2005
90 Senegal 1,730,000 2005
91 Jordan 1,594,500 2004
92 Bosnia and Herzegovina 1,594,000 2005
93 Uganda 1,525,000 2005
94 Georgia 1,459,000 2005
95 Estonia 1,445,000 2005
96 Panama 1,352,000 2005
97 Oman 1,333,000 2005
98 Honduras 1,282,000 2005
99 Macedonia 1,261,000 2005
100 Albania 1,259,000 2004
101 Mozambique 1,220,000 2005
102 Afghanistan 1,200,000 2005
103 Nicaragua 1,119,000 2005
104 Costa Rica 1,101,000 2005
105 Gaza Strip 1,095,000 2005
106 West Bank 1,095,000 2005
107 Angola 1,094,100 2005
108 Moldova 1,090,000 2005
109 Cambodia 1,062,000 2005
110 Lebanon 990,000 2005
111 Zambia 946,600 2005
112 Mali 869,600 2005
113 Botswana 823,100 2005
114 Trinidad and Tobago 800,000 2005
115 Bahrain 748,700 2005
116 Mauritania 745,600 2005
117 Luxembourg 720,000 2005
118 Uzbekistan 720,000 2005
119 Cyprus 718,800
120 Qatar 716,800 2005
121 Mauritius 713,300 2005
122 Zimbabwe 699,000 2005
123 Gabon 649,800 2005
124 Uruguay 600,000 2004
125 Reunion 579,200 2004
126 Iraq 574,000 2004
127 Burkina Faso 572,200 2005
128 Mongolia 557,200 2005
129 Montenegro 543,220 2005
130 Kyrgyzstan 541,700 2005
131 Macau 532,800 2005
132 Laos 520,546 2006
133 Madagascar 504,700 2005
134 Somalia 500,000 2005
135 Namibia 495,000 2005
136 Congo, Republic of the 490,000 2005
137 Togo 443,600 2005
138 Malawi 429,300 2005
139 Ethiopia 410,600 2005
140 Haiti 400,000 2004
141 Benin 386,700 2005
142 Malta 324,000 2005
143 Armenia 320,000 2005
144 Martinique 319,900 2002
145 Guadeloupe 314,700 2004
146 Iceland 304,000 2005
147 Niger 299,900 2005
148 Rwanda 290,000 2005
149 Guyana 281,400 2005
150 Tajikistan 265,000 2005
151 Nepal 248,800 2005
152 Gambia, The 247,500 2005
153 Lesotho 245,100 2005
154 Libya 234,800 2004
155 Suriname 232,800 2005
156 Chad 210,000 2005
157 Barbados 206,200 2005
158 Brunei 205,900 2004
159 Netherlands Antilles 200,000 2004
160 Swaziland 200,000 2005
161 Guinea 189,000 2005
162 Bahamas, The 186,000 2004
163 Burma 183,400 2005
164 Liberia 160,000 2005
165 Maldives 153,400 2005
166 Burundi 153,000 2005
167 Cyprus 143,178
168 Fiji 142,200 2004
169 Cuba 134,500 2005
170 New Caledonia 134,300 2005
171 Sierra Leone 113,200 2003
172 Aruba 98,400 2004
173 French Guiana 98,000 2004
174 Guam 98,000 2004
175 Equatorial Guinea 96,900 2005
176 Belize 93,100 2005
177 Saint Lucia 93,000 2004
178 French Polynesia 87,000 2005
179 Jersey 83,900 2004
180 Cape Verde 81,700 2005
181 Saint Vincent and the Grenadines 70,600 2005
182 Guinea-Bissau 67,000 2005
183 Andorra 64,600 2005
184 Virgin Islands 64,200 2004
185 Central African Republic 60,000 2004
186 Seychelles 57,000 2005
187 Antigua and Barbuda 54,000 2004
188 Turkmenistan 52,000 2004
189 Bermuda 49,000 2004
190 Mayotte 48,100 2004
191 Guernsey 43,800 2004
192 Grenada 43,300 2004
193 Faroe Islands 42,500 2005
194 Dominica 41,800 2004
195 Eritrea 40,400 2005
196 Bhutan 37,800 2005
197 Djibouti 34,500 2004
198 Greenland 32,200 2004
199 Papua New Guinea 26,000 2005
200 Samoa 24,000 2005
201 Northern Mariana Islands 20,500 2004
202 Monaco 19,300 2002
203 Cayman Islands 17,000 2002
204 San Marino 16,800 2002
205 Tonga 16,400 2004
206 Comoros 16,100 2005
207 Micronesia, Federated States of 14,100 2005
208 Vanuatu 12,700 2005
209 Sao Tome and Principe 12,000 2005
210 Liechtenstein 11,400 2002
211 Saint Kitts and Nevis 10,000 2004
212 Gibraltar 9,797 2002
213 British Virgin Islands 8,000 2002
214 Solomon Islands 6,000 2005
215 American Samoa 2,377 1999
216 Anguilla 1,800 2002
217 Turks and Caicos Islands 1,700 1999
218 Cook Islands 1,500 2002
219 Nauru 1,500 2002
220 Marshall Islands 1,198 2004
221 Palau 1,000 2002
222 Kiribati 600 2004
223 Niue 400 2002
224 Montserrat 70 1994
225 Falkland Islands (Islas Malvinas) 0 2001
226 Western Sahara 0 1999
227 Wallis and Futuna 0 1994
228 Norfolk Island 0 2002
229 Tuvalu 0 2004
230 Tokelau 0 2001
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2153
Rank Country Internet users Date of Information
1 World 1,018,057,389 2005
2 European Union 239,881,917 2006
3 United States 205,326,680 2005
4 China 123,000,000 2006
5 Japan 86,300,000 2005
6 India 60,000,000 2005
7 Germany 50,616,000 2006
8 United Kingdom 37,600,000 2005
9 Korea, South 33,900,000 2005
10 France 29,521,000 2006
11 Italy 28,870,000 2005
12 Brazil 25,900,000 2005
13 Russia 23,700,000 2005
14 Canada 21,900,000 2005
15 Spain 19,204,771 2006
16 Mexico 18,622,500 2005
17 Indonesia 16,000,000 2005
18 Turkey 16,000,000 2005
19 Australia 14,663,622 2006
20 Taiwan 13,210,000 2005
21 Vietnam 13,100,000 2006
22 Malaysia 11,016,000 2005
23 Netherlands 10,806,328 2004
24 Poland 10,600,000 2005
25 Pakistan 10,500,000 2005
26 Argentina 10,000,000 2005
27 Thailand 8,420,000 2005
28 Philippines 7,820,000 2005
29 Portugal 7,782,700 2006
30 Iran 7,500,000 2005
31 Sweden 6,800,000 2005
32 Chile 6,700,000 2005
33 Ukraine 5,278,100 2005
34 Belgium 5,100,000 2005
35 South Africa 5,100,000 2005
36 Czech Republic 5,100,000 2005
37 Switzerland 5,097,822 2005
38 Egypt 5,000,000 2005
39 Nigeria 5,000,000 2005
40 Romania 4,940,000 2005
41 Hong Kong 4,878,713 2005
42 Colombia 4,739,000 2005
43 Austria 4,650,000 2005
44 Morocco 4,600,000 2005
45 Peru 4,600,000 2005
46 Greece 3,800,000 2005
47 Denmark 3,762,500 2005
48 Israel 3,700,000 2006
49 Belarus 3,394,400 2005
50 Finland 3,286,000 2005
51 New Zealand 3,200,000 2005
52 Norway 3,140,000 2005
53 Hungary 3,050,000 2005
54 Venezuela 3,040,000 2005
55 Sudan 2,800,000 2005
56 Saudi Arabia 2,540,000 2005
57 Slovakia 2,500,000 2005
58 Singapore 2,421,800 2005
59 Bulgaria 2,200,000 2005
60 Ireland 2,060,000 2005
61 Algeria 1,920,000 2005
62 Croatia 1,451,100 2005
63 Serbia 1,400,000 2006
64 United Arab Emirates 1,397,200 2005
65 Lithuania 1,221,700 2005
66 Syria 1,100,000 2005
67 Slovenia 1,090,000 2005
68 Jamaica 1,067,000 2005
69 Kenya 1,054,900 2005
70 Latvia 1,030,000 2005
71 Costa Rica 1,000,000 2005
72 Zimbabwe 1,000,000 2005
73 Puerto Rico 1,000,000 2005
74 Tunisia 953,800 2005
75 Dominican Republic 938,300 2005
76 Uzbekistan 880,000 2005
77 Bosnia and Herzegovina 806,400 2005
78 Guatemala 756,000 2005
79 Kuwait 700,000 2005
80 Lebanon 700,000 2005
81 Estonia 690,000 2005
82 Uruguay 680,000 2005
83 Azerbaijan 678,800 2005
84 El Salvador 637,100 2005
85 Jordan 629,500 2005
86 Ecuador 616,000 2005
87 Senegal 540,000 2005
88 Haiti 500,000 2005
89 Uganda 500,000 2005
90 Bolivia 480,000 2005
91 Benin 425,000 2005
92 Moldova 406,000 2005
93 Ghana 401,300 2005
94 Kazakhstan 400,000 2005
95 Macedonia 392,671 2005
96 Tanzania 333,000 2005
97 Luxembourg 315,000 2005
98 Bangladesh 300,000 2005
99 Panama 300,000 2005
100 Togo 300,000 2005
101 Cyprus 298,000 2005
102 Sri Lanka 280,000 2005
103 Kyrgyzstan 280,000 2005
104 Mongolia 268,300 2005
105 Iceland 258,000 2005
106 Oman 245,000 2005
107 Gaza Strip 243,000 2005
108 West Bank 243,000 2005
109 Zambia 231,000 2005
110 Honduras 223,000 2005
111 Yemen 220,000 2005
112 Qatar 219,000 2005
113 Libya 205,000 2005
114 Macau 201,000 2004
115 Paraguay 200,000 2005
116 Reunion 200,000 2005
117 Cuba 190,000 2005
118 Mauritius 180,000 2005
119 Georgia 175,600 2005
120 Nepal 175,000 2005
121 Angola 172,000 2005
122 Papua New Guinea 170,000 2005
123 Cameroon 167,000 2005
124 Barbados 160,000 2005
125 Guyana 160,000 2005
126 Trinidad and Tobago 160,000 2005
127 Cote d''Ivoire 160,000 2005
128 Bahrain 152,700 2005
129 Armenia 150,000 2005
130 Congo, Democratic Republic of the 140,600 2005
131 Nicaragua 140,000 2005
132 Mozambique 138,000 2005
133 Malta 127,200 2005
134 Ethiopia 113,000 2005
135 Martinique 107,000 2005
136 Bahamas, The 93,000 2005
137 Madagascar 90,000 2005
138 Somalia 90,000 2005
139 Guadeloupe 79,000 2005
140 Guam 79,000 2004
141 Burma 78,000 2005
142 New Caledonia 76,000 2005
143 Albania 75,000 2005
144 Namibia 75,000 2005
145 Eritrea 70,000 2005
146 Gabon 67,000 2005
147 Burkina Faso 64,600 2005
148 Fiji 61,000 2004
149 Botswana 60,000 2002
150 Mali 60,000 2005
151 Brunei 56,000 2005
152 French Polynesia 55,000 2005
153 Saint Lucia 55,000 2005
154 Malawi 52,500 2005
155 Montenegro 50,000 2004
156 Gambia, The 49,000 2005
157 Guinea 46,000 2005
158 Lesotho 43,000 2005
159 Cambodia 41,000 2005
160 Bermuda 39,000 2005
161 French Guiana 38,000 2005
162 Greenland 38,000 2005
163 Rwanda 38,000 2005
164 Congo, Republic of the 36,000 2005
165 Guernsey 36,000 2005
166 Turkmenistan 36,000 2005
167 Swaziland 36,000 2005
168 Iraq 36,000 2005
169 Belize 35,000 2005
170 Chad 35,000 2005
171 Faroe Islands 33,000 2005
172 Afghanistan 30,000 2005
173 Virgin Islands 30,000 2002
174 Suriname 30,000 2005
175 Jersey 27,000 2005
176 Guinea-Bissau 26,000 2005
177 Bhutan 25,000 2005
178 Laos 25,000 2005
179 Cape Verde 25,000 2005
180 Burundi 25,000 2005
181 Aruba 24,000 2002
182 Niger 24,000 2005
183 Andorra 21,900 2005
184 Dominica 20,500 2005
185 Antigua and Barbuda 20,000 2005
186 Sao Tome and Principe 20,000 2005
187 Seychelles 20,000 2005
188 Liechtenstein 20,000 2002
189 Comoros 20,000 2005
190 Grenada 19,000 2005
191 Maldives 19,000 2005
192 Monaco 16,000 2002
193 San Marino 14,300 2002
194 Micronesia, Federated States of 14,000 2005
195 Mauritania 14,000 2005
196 Northern Mariana Islands 10,000 2003
197 Sierra Leone 10,000 2005
198 Saint Kitts and Nevis 10,000 2002
199 Cayman Islands 9,909 2003
200 Central African Republic 9,000 2005
201 Djibouti 9,000 2005
202 Solomon Islands 8,400 2005
203 Saint Vincent and the Grenadines 8,000 2005
204 Vanuatu 7,500 2004
205 Gibraltar 6,200 2002
206 Samoa 6,000 2004
207 Equatorial Guinea 5,000 2005
208 Tajikistan 5,000 2005
209 British Virgin Islands 4,000 2002
210 Cook Islands 3,600 2002
211 Anguilla 3,000 2002
212 Tonga 3,000 2004
213 Kiribati 2,000 2004
214 Netherlands Antilles 2,000 2000
215 Marshall Islands 2,000 2005
216 Falkland Islands (Islas Malvinas) 1,900 2002
217 Tuvalu 1,300 2002
218 Liberia 1,000 2002
219 East Timor 1,000 2004
220 Saint Helena 1,000 2003
221 Niue 900 2002
222 Wallis and Futuna 900 2002
223 Norfolk Island 700
224 Christmas Island 464 2001
225 Nauru 300 2002
226 Holy See (Vatican City) 93 2000
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2155
Rank Country HIV/AIDS - adult prevalence rate(%) Date of Information
1 Swaziland 38.80 2003 est.
2 Botswana 37.30 2003 est.
3 Lesotho 28.90 2003 est.
4 Zimbabwe 24.60 2001 est.
5 South Africa 21.50 2003 est.
6 Namibia 21.30 2003 est.
7 Zambia 16.50 2003 est.
8 Malawi 14.20 2003 est.
9 Central African Republic 13.50 2003 est.
10 Mozambique 12.20 2003 est.
11 Guinea-Bissau 10.00 2003 est.
12 Tanzania 8.80 2003 est.
13 Gabon 8.10 2003 est.
14 Cote d''Ivoire 7.00 2003 est.
15 Sierra Leone 7.00 2001 est.
16 Cameroon 6.90 2003 est.
17 Kenya 6.70 2003 est.
18 Burundi 6.00 2003 est.
19 Liberia 5.90 2003 est.
20 Haiti 5.60 2003 est.
21 Nigeria 5.40 2003 est.
22 Rwanda 5.10 2003 est.
23 Congo, Republic of the 4.90 2003 est.
24 Chad 4.80 2003 est.
25 Ethiopia 4.40 2003 est.
26 Congo, Democratic Republic of the 4.20 2003 est.
27 Burkina Faso 4.20 2003 est.
28 Togo 4.10 2003 est.
29 Uganda 4.10 2003 est.
30 Angola 3.90 2003 est.
31 Equatorial Guinea 3.40 2001 est.
32 Guinea 3.20 2003 est.
33 Trinidad and Tobago 3.20 2003 est.
34 Ghana 3.10 2003 est.
35 Bahamas, The 3.00 2003 est.
36 Djibouti 2.90 2003 est.
37 Eritrea 2.70 2003 est.
38 Cambodia 2.60 2003 est.
39 Guyana 2.50 2003 est.
40 Belize 2.40 2003 est.
41 Sudan 2.30 2001 est.
42 Benin 1.90 2003 est.
43 Mali 1.90 2003 est.
44 Honduras 1.80 2003 est.
45 Dominican Republic 1.70 2003 est.
46 Madagascar 1.70 2003 est.
47 Suriname 1.70 2001 est.
48 Barbados 1.50 2003 est.
49 Thailand 1.50 2003 est.
50 Ukraine 1.40 2003 est.
51 Burma 1.20 2003 est.
52 Niger 1.20 2003 est.
53 Jamaica 1.20 2003 est.
54 Gambia, The 1.20 2003 est.
55 Estonia 1.10 2001 est.
56 Russia 1.10 2001 est.
57 Guatemala 1.10 2003 est.
58 Somalia 1.00 2001 est.
59 India 0.90 2001 est.
60 Panama 0.90 2003 est.
61 Senegal 0.80 2003 est.
62 Argentina 0.70 2001 est.
63 Brazil 0.70 2003 est.
64 Venezuela 0.70 2001 est.
65 Spain 0.70 2001 est.
66 El Salvador 0.70 2003 est.
67 Colombia 0.70 2003 est.
68 Costa Rica 0.60 2003 est.
69 Mauritania 0.60 2003 est.
70 Latvia 0.60 2001 est.
71 United States 0.60 2003 est.
72 Papua New Guinea 0.60 2003 est.
73 Italy 0.50 2001 est.
74 Paraguay 0.50 2003 est.
75 Peru 0.50 2003 est.
76 Nepal 0.50 2001 est.
77 France 0.40 2003 est.
78 Vietnam 0.40 2003 est.
79 Switzerland 0.40 2001 est.
80 Portugal 0.40 2001 est.
81 Malaysia 0.40 2003 est.
82 Austria 0.30 2003 est.
83 Ecuador 0.30 2003 est.
84 Belarus 0.30 2001 est.
85 Uruguay 0.30 2001 est.
86 Chile 0.30 2003 est.
87 Mexico 0.30 2003 est.
88 Libya 0.30 2001 est.
89 Canada 0.30 2003 est.
90 Bermuda 0.30 2005
91 Bahrain 0.20 2001 est.
92 Belgium 0.20 2003 est.
93 United Kingdom 0.20 2001 est.
94 Singapore 0.20 2003 est.
95 Nicaragua 0.20 2003 est.
96 Netherlands 0.20 2001 est.
97 Malta 0.20 2001 est.
98 Moldova 0.20 2001 est.
99 Luxembourg 0.20 2001 est.
100 Kazakhstan 0.20 2001 est.
101 Iceland 0.20 2001 est.
102 Greece 0.20 2001 est.
103 Denmark 0.20 2003 est.
104 United Arab Emirates 0.18 2001 est.
105 Comoros 0.12 2001 est.
106 Kuwait 0.12 2001 est.
107 Algeria 0.10 2001 est.
108 Australia 0.10 2003 est.
109 Bangladesh 0.10 2001 est.
110 Bolivia 0.10 2003 est.
111 Bulgaria 0.10 2001 est.
112 Sri Lanka 0.10 2001 est.
113 Maldives 0.10 2001 est.
114 Oman 0.10 2001 est.
115 Mauritius 0.10 2001 est.
116 Morocco 0.10 2001 est.
117 Macedonia 0.10 2001 est.
118 Georgia 0.10 2001 est.
119 Fiji 0.10 2003 est.
120 Finland 0.10 2003 est.
121 Czech Republic 0.10 2001 est.
122 Ireland 0.10 2001 est.
123 Egypt 0.10 2001 est.
124 Cyprus 0.10 2003 est.
125 Cuba 0.10 2003 est.
126 China 0.10 2003 est.
127 Tajikistan 0.10 2001 est.
128 Syria 0.10 2001 est.
129 Sweden 0.10 2001 est.
130 Slovenia 0.10 2001 est.
131 Philippines 0.10 2003 est.
132 Romania 0.10 2001 est.
133 Poland 0.10 2001 est.
134 Pakistan 0.10 2001 est.
135 Mongolia 0.10 2003 est.
136 Yemen 0.10 2001 est.
137 Uzbekistan 0.10 2001 est.
138 Turkmenistan 0.10 2004 est.
139 Turkey 0.10 2001 est.
140 Tunisia 0.10 2005 est.
141 Slovakia 0.10 2001 est.
142 Lithuania 0.10 2001 est.
143 Lebanon 0.10 2001 est.
144 Laos 0.10 2003 est.
145 Korea, South 0.10 2003 est.
146 Kyrgyzstan 0.10 2001 est.
147 Jordan 0.10 2001 est.
148 Japan 0.10 2003 est.
149 New Zealand 0.10 2003 est.
150 Norway 0.10 2001 est.
151 Iraq 0.10 2001 est.
152 Israel 0.10 2001 est.
153 Iran 0.10 2001 est.
154 Indonesia 0.10 2003 est.
155 Hungary 0.10 2001 est.
156 Croatia 0.10 2001 est.
157 Hong Kong 0.10 2003 est.
158 Germany 0.10 2001 est.
159 Brunei 0.10 2003 est.
160 Bhutan 0.10 2001 est.
161 Bosnia and Herzegovina 0.10 2001 est.
162 Azerbaijan 0.10 2003 est.
163 Armenia 0.10 2003 est.
164 Qatar 0.09 2001 est.
165 Cape Verde 0.04
166 Afghanistan 0.01 2001 est.
167 Saudi Arabia 0.01 2001 est.
168 Svalbard 0.00 2001
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2156
Rank Country HIV/AIDS - people living with HIV/AIDS Date of Information
1 South Africa 5,300,000 2003 est.
2 India 5,100,000 2001 est.
3 Nigeria 3,600,000 2003 est.
4 Zimbabwe 1,800,000 2001 est.
5 Tanzania 1,600,000 2003 est.
6 Ethiopia 1,500,000 2003 est.
7 Mozambique 1,300,000 2003 est.
8 Kenya 1,200,000 2003 est.
9 Congo, Democratic Republic of the 1,100,000 2003 est.
10 United States 950,000 2003 est.
11 Zambia 920,000 2003 est.
12 Malawi 900,000 2003 est.
13 Russia 860,000 2001 est.
14 China 840,000 2003 est.
15 Brazil 660,000 2003 est.
16 Cote d''Ivoire 570,000 2003 est.
17 Thailand 570,000 2003 est.
18 Cameroon 560,000 2003 est.
19 Uganda 530,000 2001 est.
20 Sudan 400,000 2001 est.
21 Ukraine 360,000 2001 est.
22 Botswana 350,000 2003 est.
23 Ghana 350,000 2003 est.
24 Burma 330,000 2003 est.
25 Lesotho 320,000 2003 est.
26 Burkina Faso 300,000 2003 est.
27 Haiti 280,000 2003 est.
28 Central African Republic 260,000 2003 est.
29 Burundi 250,000 2003 est.
30 Rwanda 250,000 2003 est.
31 Angola 240,000 2003 est.
32 Vietnam 220,000 2003 est.
33 Swaziland 220,000 2003 est.
34 Namibia 210,000 2001 est.
35 Chad 200,000 2003 est.
36 Colombia 190,000 2003 est.
37 Cambodia 170,000 2003 est.
38 Sierra Leone 170,000 2001 est.
39 Mexico 160,000 2003 est.
40 Guinea 140,000 2003 est.
41 Madagascar 140,000 2003 est.
42 Italy 140,000 2001 est.
43 Mali 140,000 2003 est.
44 Spain 140,000 2001 est.
45 Argentina 130,000 2001 est.
46 France 120,000 2003 est.
47 Indonesia 110,000 2003 est.
48 Togo 110,000 2003 est.
49 Venezuela 110,000 1999 est.
50 Liberia 100,000 2003 est.
51 Congo, Republic of the 90,000 2003 est.
52 Dominican Republic 88,000 2003 est.
53 Peru 82,000 2003 est.
54 Guatemala 78,000 2003 est.
55 Pakistan 74,000 2001 est.
56 Niger 70,000 2003 est.
57 Benin 68,000 2003 est.
58 Honduras 63,000 2003 est.
59 Nepal 61,000 2001 est.
60 Eritrea 60,000 2003 est.
61 Canada 56,000 2003 est.
62 Malaysia 52,000 2003 est.
63 United Kingdom 51,000 2001 est.
64 Gabon 48,000 2003 est.
65 Senegal 44,000 2003 est.
66 Germany 43,000 2001 est.
67 Somalia 43,000 2001 est.
68 Iran 31,000 2001 est.
69 El Salvador 29,000 2003 est.
70 Trinidad and Tobago 29,000 2003 est.
71 Chile 26,000 2003 est.
72 Jamaica 22,000 2003 est.
73 Portugal 22,000 2001 est.
74 Ecuador 21,000 2003 est.
75 Netherlands 19,000 2001 est.
76 Guinea-Bissau 17,000 2001 est.
77 Kazakhstan 16,500 2001 est.
78 Panama 16,000 2003 est.
79 Papua New Guinea 16,000 2003 est.
80 Belarus 15,000 2001 est.
81 Morocco 15,000 2001 est.
82 Paraguay 15,000 1999 est.
83 Australia 14,000 2003 est.
84 Poland 14,000 2003 est.
85 Bangladesh 13,000 2001 est.
86 Switzerland 13,000 2001 est.
87 Costa Rica 12,000 2003 est.
88 Yemen 12,000 2001 est.
89 Japan 12,000 2003 est.
90 Egypt 12,000 2001 est.
91 Guyana 11,000 2003 est.
92 Uzbekistan 11,000 2003 est.
93 Austria 10,000 2003 est.
94 Belgium 10,000 2003 est.
95 Libya 10,000 2001 est.
96 Mauritania 9,500 2003 est.
97 Algeria 9,100 2003 est.
98 Greece 9,100 2001 est.
99 Djibouti 9,100 2003 est.
100 Philippines 9,000 2003 est.
101 Korea, South 8,300 2003 est.
102 Estonia 7,800 2003 est.
103 Latvia 7,600 2001 est.
104 Puerto Rico 7,397
105 Gambia, The 6,800 2003 est.
106 Romania 6,500 2001 est.
107 Nicaragua 6,400 2003 est.
108 Uruguay 6,000 2001 est.
109 Equatorial Guinea 5,900 2001 est.
110 Bahamas, The 5,600 2003 est.
111 Moldova 5,500 2001 est.
112 Suriname 5,200 2001 est.
113 Denmark 5,000 2003 est.
114 Bolivia 4,900 2003 est.
115 Singapore 4,100 2003 est.
116 Kyrgyzstan 3,900 2003 est.
117 Belize 3,600 2003 est.
118 Sweden 3,600 2001 est.
119 Sri Lanka 3,500 2001 est.
120 Cuba 3,300 2003 est.
121 Georgia 3,000 2003 est.
122 Israel 3,000 1999 est.
123 Ireland 2,800 2001 est.
124 Lebanon 2,800 2003 est.
125 Hungary 2,800 2001 est.
126 Armenia 2,600 2003 est.
127 Hong Kong 2,600 2003 est.
128 Barbados 2,500 2003 est.
129 Czech Republic 2,500 2001 est.
130 Norway 2,100 2001 est.
131 Laos 1,700 2003 est.
132 Finland 1,500 2003 est.
133 Azerbaijan 1,400 2003 est.
134 New Zealand 1,400 2003 est.
135 Lithuania 1,300 2003 est.
136 Oman 1,300 2001 est.
137 Cyprus 1,000 1999 est.
138 Tunisia 1,000 2003 est.
139 Bosnia and Herzegovina 900 2003 est.
140 Cape Verde 775
141 Mauritius 700 2001 est.
142 Bahrain 600 2003 est.
143 Jordan 600 2003 est.
144 Fiji 600 2003 est.
145 Iraq 500 2003 est.
146 Mongolia 500 2003 est
147 Syria 500 2003 est.
148 Malta 500 2003 est.
149 Luxembourg 500 2003 est.
150 Bulgaria 346 2001 est.
151 Slovenia 280 2001 est.
152 Iceland 220 2001 est.
153 Brunei 200 2003 est.
154 Slovakia 200 2003 est.
155 Croatia 200 2001 est.
156 Macedonia 200 2003 est.
157 Turkmenistan 200 2003 est.
158 Tajikistan 200 2003 est.
159 Bermuda 163 2005
160 Bhutan 100 1999 est.
161 Maldives 100 2001 est.
162 Greenland 100
163 Samoa 12
164 Svalbard 0 2001
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2157
Rank Country HIV/AIDS - deaths Date of Information
1 South Africa 370,000 2003 est.
2 India 310,000 2001 est.
3 Nigeria 310,000 2003 est.
4 Zimbabwe 170,000 2003 est.
5 Tanzania 160,000 2003 est.
6 Kenya 150,000 2003 est.
7 Ethiopia 120,000 2003 est.
8 Mozambique 110,000 2003 est.
9 Congo, Democratic Republic of the 100,000 2003 est.
10 Zambia 89,000 2003 est.
11 Malawi 84,000 2003 est.
12 Uganda 78,000 2003 est.
13 Thailand 58,000 2003 est.
14 Cameroon 49,000 2003 est.
15 Cote d''Ivoire 47,000 2003 est.
16 China 44,000 2003 est.
17 Botswana 33,000 2003 est.
18 Ghana 30,000 2003 est.
19 Lesotho 29,000 2003 est.
20 Burkina Faso 29,000 2003 est.
21 Burundi 25,000 2003 est.
22 Haiti 24,000 2003 est.
23 Central African Republic 23,000 2003 est.
24 Sudan 23,000 2003 est.
25 Rwanda 22,000 2003 est.
26 Angola 21,000 2003 est.
27 Burma 20,000 2003 est.
28 Ukraine 20,000 2003 est.
29 Chad 18,000 2003 est.
30 Swaziland 17,000 2003 est.
31 Namibia 16,000 2003 est.
32 Brazil 15,000 2003 est.
33 Cambodia 15,000 2003 est.
34 United States 14,000 2003 est.
35 Mali 12,000 2003 est.
36 Sierra Leone 11,000 2001 est.
37 Togo 10,000 2003 est.
38 Congo, Republic of the 9,700 2003 est.
39 Guinea 9,000 2003 est.
40 Russia 9,000 2001 est.
41 Vietnam 9,000 2003 est.
42 Dominican Republic 7,900 2003 est.
43 Madagascar 7,500 2003 est.
44 Liberia 7,200 2003 est.
45 Eritrea 6,300 2003 est.
46 Benin 5,800 2003 est.
47 Guatemala 5,800 2003 est.
48 Mexico 5,000 2003 est.
49 Pakistan 4,900 2003 est.
50 Niger 4,800 2003 est.
51 Peru 4,200 2003 est.
52 Honduras 4,100 2003 est.
53 Venezuela 4,100 2003 est.
54 Colombia 3,600 2003 est.
55 Senegal 3,500 2003 est.
56 Nepal 3,100 2003 est.
57 Gabon 3,000 2003 est.
58 Indonesia 2,400 2003 est.
59 El Salvador 2,200 2003 est.
60 Malaysia 2,000 2003 est.
61 Trinidad and Tobago 1,900 2003 est.
62 Ecuador 1,700 2003 est.
63 Argentina 1,500 2003 est.
64 Canada 1,500 2003 est.
65 Chile 1,400 2003 est.
66 Guinea-Bissau 1,200 2001 est.
67 Guyana 1,100 2003 est.
68 Belarus 1,000 2001 est.
69 Spain 1,000 2003 est.
70 Portugal 1,000 2003 est.
71 Italy 1,000 2003 est.
72 Germany 1,000 2003 est.
73 France 1,000 2003 est.
74 Costa Rica 900 2003 est.
75 Jamaica 900 2003 est.
76 Iran 800 2003 est.
77 Egypt 700 2003 est.
78 Djibouti 690 2003 est.
79 Bangladesh 650 2001 est.
80 Gambia, The 600 2003 est.
81 Paraguay 600 2003 est.
82 Papua New Guinea 600 2003 est.
83 Algeria 500 2003 est.
84 Japan 500 2003 est.
85 Latvia 500 2003 est.
86 Philippines 500 2003 est.
87 Uzbekistan 500 2003 est.
88 Uruguay 500 2003 est.
89 United Kingdom 500 2003 est.
90 Suriname 500 2003 est.
91 Jordan 500 2003 est.
92 Bermuda 392 2005
93 Equatorial Guinea 370 2001 est.
94 Romania 350 2001 est.
95 Moldova 300 2001 est.
96 Cape Verde 225
97 Armenia 200 2003 est.
98 Lithuania 200 2003 est.
99 Lebanon 200 2003 est.
100 Laos 200 2003 est.
101 Kazakhstan 200 2003 est.
102 Korea, South 200 2003 est.
103 Kyrgyzstan 200 2003 est.
104 Hong Kong 200 2003 est.
105 Georgia 200 2003 est.
106 Fiji 200 2003 est.
107 Tunisia 200 2003 est.
108 Syria 200 2003 est','5d46ed0ae08aa5a08fdd61085ae874e1d97b1781deb83b4ed5d0c12c472a4d92','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59eec73c44c41bc8a83e6b85caef5d48bd4eff6c08184e7e982ca5153fc79f53',2006,'ZW','Zimbabwe','communications',15,'.
109 Singapore 200 2003 est.
110 New Zealand 200 2003 est.
111 Oman 200 2003 est.
112 Mongolia 200 2003 est.
113 Estonia 200 2003 est.
114 Cuba 200 2003 est.
115 Sri Lanka 200 2003 est.
116 Brunei 200 2003 est.
117 Bahamas, The 200 2003 est.
118 Barbados 200 2003 est.
119 Bahrain 200 2003 est.
120 Azerbaijan 100 2001 est.
121 Turkmenistan 100 2004 est.
122 Tajikistan 100 2001 est.
123 Switzerland 100 2003 est.
124 Sweden 100 2003 est.
125 Slovenia 100 2003 est.
126 Poland 100 2001 est.
127 Norway 100 2003 est.
128 Netherlands 100 2003 est.
129 Malta 100 2003 est.
130 Mauritius 100 2001 est.
131 Macedonia 100 2003 est.
132 Luxembourg 100 2003 est.
133 Slovakia 100 2001 est.
134 Israel 100 2001 est.
135 Iceland 100 2003 est.
136 Hungary 100 2001 est.
137 Greece 100 2003 est.
138 Finland 100 2003 est.
139 Bulgaria 100 2001 est.
140 Bosnia and Herzegovina 100 2001 est.
141 Denmark 100 2003 est.
142 Ireland 100 2003 est.
143 Belgium 100 2003 est.
144 Austria 100 2003 est.
145 Czech Republic 10 2001 est.
146 Croatia 10 2001 est.
147 Samoa 3
148 Svalbard 0 2001
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2173
Rank Country Oil - production(bbl/day) Date of Information
1 World 79,650,000 2003 est.
2 Saudi Arabia 9,475,000 2005 est.
3 Russia 9,150,000 2005 est.
4 United States 7,610,000 2005 est.
5 Iran 3,979,000 2005 est.
6 China 3,504,000 2004
7 European Union 3,424,000 2001
8 Mexico 3,420,000 2005 est.
9 Norway 3,220,000 2005 est.
10 Venezuela 3,081,000 2005 est.
11 Nigeria 2,451,000 2005 est.
12 Kuwait 2,418,000 2005 est.
13 Canada 2,400,000 2004
14 United Arab Emirates 2,396,000 2005 est.
15 United Kingdom 2,393,000 2003 est.
16 Iraq 2,093,000 2005 est.
17 Brazil 2,010,000 2005 est.
18 Libya 1,643,000 2005 est.
19 Angola 1,600,000 2005 est.
20 Algeria 1,373,000 2005 est.
21 Kazakhstan 1,300,000 2005 est.
22 Indonesia 1,061,000 2005 est.
23 Qatar 790,500 2005 est.
24 India 785,000 2005 est.
25 Malaysia 770,000 2005 est.
26 Oman 769,000 2005 est.
27 Argentina 745,000 2005 est.
28 Egypt 700,000 2005 est.
29 Australia 530,000 2005 est.
30 Colombia 512,400 2005 est.
31 Ecuador 493,200 2005 est.
32 Azerbaijan 477,000 2005 est.
33 Equatorial Guinea 420,000 2005 est.
34 Syria 403,800 2005 est.
35 Sudan 401,300 2005 est.
36 Vietnam 400,000 2005 est.
37 Yemen 387,500 2005 est.
38 Denmark 376,900 2003
39 Gabon 268,900 2005 est.
40 Congo, Republic of the 267,100 2005 est.
41 Thailand 230,000 2005 est.
42 Chad 225,000 2005 est.
43 South Africa 216,700 2003 est.
44 Turkmenistan 203,400 2003 est.
45 Brunei 200,800 2005
46 Bahrain 188,300 2005 est.
47 Germany 158,700 2003
48 Uzbekistan 152,000 2004
49 Trinidad and Tobago 150,000 2005 est.
50 Italy 136,200 2003 est.
51 Japan 120,700 2003 est.
52 Peru 120,000 2005 est.
53 Romania 119,000 2005 est.
54 Netherlands 94,870 2003
55 Ukraine 85,660 2004
56 Cameroon 82,300 2005 est.
57 France 76,300 2003 est.
58 Tunisia 76,000 2004 est.
59 Cuba 72,000 2005 est.
60 Pakistan 63,000 2005 est.
61 Papua New Guinea 50,000 January 2006 est.
62 Turkey 50,000 2005 est.
63 Hungary 45,190 2005
64 Bolivia 42,000 2005 est.
65 Belarus 36,000 2004 est.
66 Cote d''Ivoire 32,900 2005 est.
67 New Zealand 31,740 2003 est.
68 Spain 24,540 2003 est.
69 Poland 24,530 2003 est.
70 Guatemala 22,300 2005 est.
71 Congo, Democratic Republic of the 22,000 2003
72 Croatia 20,500 2005 est.
73 Burma 18,500 2005 est.
74 Austria 17,810 2004
75 Czech Republic 15,240 2005
76 Serbia 14,660 2003
77 Virgin Islands 14,650 2003 est.
78 Philippines 14,360 2003 est.
79 Nicaragua 14,300 2005 est.
80 Lithuania 14,000 2004
81 Belgium 13,060 2003
82 Suriname 12,000 2004 est.
83 Slovakia 11,480 2005 est.
84 Finland 9,013 2003 est.
85 Taiwan 8,354 2003 est.
86 Singapore 8,290 2003 est.
87 Ghana 7,433 2003 est.
88 Bangladesh 6,825 2003
89 Estonia 6,000 2004
90 Greece 5,805 2003 est.
91 Chile 4,000 2005 est.
92 Albania 3,600 2005 est.
93 Israel 2,740 2003 est.
94 Sweden 2,441 2003 est.
95 Aruba 2,363 2003
96 Kyrgyzstan 1,990 2003
97 Georgia 1,982 2003
98 Switzerland 1,950 2003 est.
99 Barbados 1,000 2003
100 Bulgaria 1,000 2004
101 Mongolia 549 2005 est.
102 Puerto Rico 436 2003 est.
103 Uruguay 435 2003 est.
104 Benin 400 2003
105 Tajikistan 355 2003 est.
106 Cyprus 300 2005 est.
107 Morocco 300 2005 est.
108 Zambia 130 2003 est.
109 Madagascar 89 2003 est.
110 Jordan 40 2004 est.
111 Slovenia 11 2003 est.
112 Sierra Leone 1 2003 est.
113 Antigua and Barbuda 0 2003
114 Botswana 0 2003
115 Bahamas, The 0 2003
116 Solomon Islands 0 2003 est.
117 Liberia 0 2003 est.
118 Latvia 0 2004
119 Lebanon 0 2003 est.
120 Laos 0 2003 est.
121 Korea, South 0 2004
122 Kiribati 0 2003 est.
123 Korea, North 0 2004 est.
124 Kenya 0 2003 est.
125 Jamaica 0 2003 est.
126 Zimbabwe 0 2003 est.
127 Swaziland 0 2004 est.
128 Samoa 0 2003 est.
129 Western Sahara 0 2003 est.
130 Namibia 0 2003 est.
131 British Virgin Islands 0 2003
132 Saint Vincent and the Grenadines 0 2003 est.
133 Burkina Faso 0 2003
134 Uganda 0 2003 est.
135 Tanzania 0 2003 est.
136 Sao Tome and Principe 0 2003 est.
137 Togo 0 2003 est.
138 Tonga 0 2003 est.
139 Turks and Caicos Islands 0 2003 est.
140 Saint Lucia 0 2003 est.
141 Somalia 0 2003 est.
142 Saint Helena 0 2003 est.
143 Senegal 0 2003 est.
144 Seychelles 0 2003 est.
145 Saint Kitts and Nevis 0 2003 est.
146 Saint Pierre and Miquelon 0 2003 est.
147 Rwanda 0 2003 est.
148 Reunion 0 2003 est.
149 Guinea-Bissau 0 2003 est.
150 Portugal 0 2003 est.
151 Panama 0 2004 est.
152 Paraguay 0 2003 est.
153 Netherlands Antilles 0 2003 est.
154 Nauru 0 2003 est.
155 Nepal 0 2005 est.
156 Vanuatu 0 2003 est.
157 Niger 0 2003 est.
158 Niue 0 2003 est.
159 New Caledonia 0 2003 est.
160 Mozambique 0 2003 est.
161 Maldives 0 2003 est.
162 Malta 0 2003 est.
163 Mauritania 0 2005 est.
164 Mauritius 0 2003 est.
165 Mali 0 2003 est.
166 Macedonia 0 2005 est.
167 Malawi 0 2003 est.
168 Montserrat 0 2003 est.
169 Moldova 0 2003 est.
170 Macau 0 2004 est.
171 Martinique 0 2003 est.
172 Luxembourg 0 2003 est.
173 Lesotho 0 2003 est.
174 Iceland 0 2003 est.
175 Honduras 0 2003 est.
176 Hong Kong 0 2003 est.
177 Ireland 0 2003 est.
178 Dominican Republic 0 2003
179 Dominica 0 2003
180 Djibouti 0 2003
181 Cook Islands 0 2003
182 Cape Verde 0 2003
183 Central African Republic 0 2003
184 Costa Rica 0 2003
185 Comoros 0 2003
186 Cayman Islands 0 2003
187 Sri Lanka 0 2003 est.
188 Cambodia 0 2003
189 Burundi 0 2003
190 Haiti 0 2003 est.
191 Guyana 0 2003 est.
192 Guinea 0 2003 est.
193 Guam 0 2003 est.
194 Guadeloupe 0 2003 est.
195 Greenland 0 2003 est.
196 Grenada 0 2003 est.
197 Gibraltar 0 2003 est.
198 Gambia, The 0 2003 est.
199 French Polynesia 0 2003 est.
200 Faroe Islands 0 2003 est.
201 Falkland Islands (Islas Malvinas) 0 2003 est.
202 Fiji 0 2003 est.
203 French Guiana 0 2003 est.
204 Ethiopia 0 2003 est.
205 El Salvador 0 2003 est.
206 Eritrea 0 2003 est.
207 Bhutan 0 2003
208 Bosnia and Herzegovina 0 2003
209 Belize 0 2003
210 Bermuda 0 2003
211 Armenia 0 2005
212 American Samoa 0 2003
213 Afghanistan 0 2003
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2174
Rank Country Oil - consumption(bbl/day) Date of Information
1 World 80,100,000 2003 est.
2 United States 20,030,000 2003 est.
3 European Union 14,590,000 2001
4 China 6,391,000 2004
5 Japan 5,578,000 2003 est.
6 Russia 2,800,000 2005 est.
7 Germany 2,677,000 2003
8 India 2,320,000 2003 est.
9 Canada 2,300,000 2004
10 Korea, South 2,061,000 2004
11 France 2,060,000 2003 est.
12 Italy 1,874,000 2003 est.
13 Saudi Arabia 1,775,000 2003
14 Mexico 1,752,000 2004 est.
15 United Kingdom 1,722,000 2003 est.
16 Brazil 1,610,000 2004
17 Spain 1,544,000 2003 est.
18 Iran 1,425,000 2003 est.
19 Indonesia 1,084,000 2005 est.
20 Netherlands 920,000 2003 est.
21 Taiwan 915,000 2003 est.
22 Australia 875,600 2003 est.
23 Thailand 851,000 2004 est.
24 Singapore 800,000 2005 est.
25 Turkey 715,100 2005 est.
26 Belgium 624,200 2003 est.
27 Egypt 566,000 2003 est.
28 Venezuela 530,000 2003 est.
29 Malaysia 510,000 2003 est.
30 Ukraine 491,700 2004
31 South Africa 484,000 2003 est.
32 Poland 476,200 2003 est.
33 Argentina 450,000 2001 est.
34 Greece 435,700 2005 est.
35 Pakistan 365,000 2004 est.
36 Iraq 351,500 2005 est.
37 Sweden 346,100 2003 est.
38 Philippines 335,000 2003 est.
39 Portugal 326,500 2003 est.
40 United Arab Emirates 310,000 2004 est.
41 Nigeria 310,000 2003 est.
42 Kuwait 305,000 2003 est.
43 Hong Kong 293,000 2004 est.
44 Israel 270,100 2003 est.
45 Colombia 270,000 2003 est.
46 Switzerland 258,900 2003 est.
47 Norway 257,200 2003 est.
48 Belarus 252,000 2003 est.
49 Austria 249,000 2004 est.
50 Algeria 246,000 2004 est.
51 Syria 240,000 2004 est.
52 Libya 237,000 2004 est.
53 Chile 228,000 2003 est.
54 Kazakhstan 221,000 2003 est.
55 Finland 219,700 2003 est.
56 Puerto Rico 218,000 2003 est.
57 Vietnam 216,000 2003 est.
58 Romania 212,000 2004 est.
59 Cuba 205,000 2003 est.
60 Czech Republic 202,000 2004 est.
61 Denmark 188,300 2003 est.
62 Ireland 175,600 2003 est.
63 Morocco 158,000 2003 est.
64 Peru 157,000 2003 est.
65 Ecuador 155,000 2003 est.
66 New Zealand 151,900 2003 est.
67 Hungary 136,000 2004
68 Dominican Republic 128,000 2003 est.
69 Azerbaijan 123,000 2003 est.
70 Uzbekistan 120,000 2004
71 Virgin Islands 105,000 2003 est.
72 Jordan 103,000 2004 est.
73 Lebanon 102,000 2003 est.
74 Bulgaria 98,000 2004
75 Croatia 90,000 2003 est.
76 Tunisia 90,000 2003 est.
77 Serbia 85,000 2003 est.
78 Bangladesh 84,000 2003 est.
79 Turkmenistan 80,000 2003 est.
80 Yemen 80,000 2003 est.
81 Sri Lanka 79,000 2003 est.
82 Panama 78,000 2003 est.
83 Slovakia 74,000 2004 est.
84 Netherlands Antilles 72,500 2003 est.
85 Sudan 70,000 2004 est.
86 Jamaica 69,000 2003 est.
87 Guatemala 66,000 2003 est.
88 Oman 62,000 2003 est.
89 Estonia 60,000 2004
90 Luxembourg 55,700 2003 est.
91 Cyprus 52,000 2003 est.
92 Kenya 52,000 2003 est.
93 Slovenia 52,000 2003 est.
94 Lithuania 52,000 2004
95 Bolivia 48,000 2003 est.
96 Latvia 47,000 2004
97 Angola 46,000 2003 est.
98 Armenia 40,000 2003 est.
99 Costa Rica 40,000 2003 est.
100 El Salvador 40,000 2003 est.
101 Ghana 39,000 2003 est.
102 Uruguay 38,000 2003 est.
103 Honduras 37,000 2003 est.
104 Moldova 37,000 2003 est.
105 Qatar 33,000 2003 est.
106 Burma 32,000 2003 est.
107 Senegal 31,000 2003 est.
108 Trinidad and Tobago 29,000 2003 est.
109 Ethiopia 27,000 2003 est.
110 Bahrain 26,000 2003 est.
111 Albania 25,200 2005 est.
112 Nicaragua 25,200 2005 est.
113 Korea, North 25,000 2003
114 Tajikistan 25,000 2003 est.
115 Paraguay 25,000 2003 est.
116 Mauritania 24,000 2003 est.
117 Gibraltar 23,500 2003 est.
118 Bahamas, The 23,000 2003 est.
119 Cameroon 23,000 2001 est.
120 Macedonia 23,000 2005 est.
121 Zimbabwe 22,500 2003 est.
122 Tanzania 22,000 2003 est.
123 Bosnia and Herzegovina 21,000 2003 est.
124 Mauritius 21,000 2003 est.
125 Cote d''Ivoire 20,000 2003 est.
126 Guam 19,000 2003 est.
127 Reunion 18,500 2003 est.
128 Malta 18,000 2003 est.
129 Papua New Guinea 18,000 January 2006 est.
130 Iceland 17,280 2003 est.
131 Namibia 16,000 2003 est.
132 Madagascar 15,000 2003 est.
133 Suriname 14,000 2004 est.
134 Martinique 13,800 2003 est.
135 Georgia 13,000 2003 est.
136 Guadeloupe 13,000 2003 est.
137 Gabon 12,250 2003 est.
138 Zambia 12,250 2003 est.
139 Botswana 12,000 2003 est.
140 Macau 12,000 2003 est.
141 Djibouti 12,000 2003 est.
142 Benin 12,000 2003 est.
143 Nepal 11,980 2005 est.
144 Haiti 11,800 2003 est.
145 Guyana 11,300 2003 est.
146 Mongolia 11,220 2005 est.
147 Kyrgyzstan 11,000 2003 est.
148 Mozambique 11,000 2003 est.
149 Brunei 10,770 2005 est.
150 Barbados 10,000 2003 est.
151 Uganda 10,000 2003 est.
152 Fiji 10,000 2003 est.
153 New Caledonia 10,000 2003 est.
154 Togo 8,500 2003 est.
155 Guinea 8,400 2003 est.
156 Congo, Democratic Republic of the 8,300 2003 est.
157 Burkina Faso 8,000 2003 est.
158 Seychelles 7,600 2003 est.
159 French Guiana 6,600 2003 est.
160 Sierra Leone 6,510 2003 est.
161 Aruba 6,500 2003 est.
162 Belize 6,000 2003 est.
163 Rwanda 6,000 2003 est.
164 Malawi 5,450 2003 est.
165 Niger 5,400 2003 est.
166 Congo, Republic of the 5,200 2003 est.
167 Afghanistan 5,000 2003 est.
168 Somalia 5,000 2003 est.
169 French Polynesia 4,800 2003 est.
170 Bermuda 4,658 2005 est.
171 Eritrea 4,600 2003 est.
172 Faroe Islands 4,500 2003 est.
173 Mali 4,250 2003 est.
174 American Samoa 4,000 2003 est.
175 Maldives 4,000 2003 est.
176 Greenland 3,850 2003 est.
177 Cambodia 3,700 2003 est.
178 Antigua and Barbuda 3,600 2003 est.
179 Swaziland 3,500 2003 est.
180 Liberia 3,400 2003 est.
181 Burundi 3,000 2003 est.
182 Laos 2,950 2003 est.
183 Saint Lucia 2,520 2003 est.
184 Cayman Islands 2,450 2003 est.
185 Guinea-Bissau 2,450 2003 est.
186 Central African Republic 2,400 2003 est.
187 Gambia, The 2,000 2003 est.
188 Grenada 1,800 2003 est.
189 Western Sahara 1,750 2003 est.
190 Chad 1,450 2003 est.
191 Lesotho 1,400 2003
192 Saint Vincent and the Grenadines 1,300 2003 est.
193 Solomon Islands 1,270 2003 est.
194 Cape Verde 1,200 2003 est.
195 Equatorial Guinea 1,200 2003 est.
196 Bhutan 1,100 2003 est.
197 Nauru 1,000 2003 est.
198 Samoa 1,000 2003 est.
199 Dominica 800 2003 est.
200 Tonga 800 2003 est.
201 Comoros 700 2003 est.
202 Saint Kitts and Nevis 700 2003 est.
203 Sao Tome and Principe 650 2003 est.
204 Vanuatu 620 2003 est.
205 Saint Pierre and Miquelon 480 2003 est.
206 British Virgin Islands 410 2003 est.
207 Cook Islands 400 2003 est.
208 Montserrat 380 2003 est.
209 Falkland Islands (Islas Malvinas) 200 2003 est.
210 Kiribati 200 2003 est.
211 Saint Helena 100 2003 est.
212 Turks and Caicos Islands 80 2003 est.
213 Niue 20 2003 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2175
Rank Country Oil - imports(bbl/day) Date of Information
1 European Union 15,690,000 2001
2 United States 13,150,000 2004
3 Japan 5,449,000 2001
4 China 3,226,000 2004
5 Netherlands 2,284,000 2001
6 France 2,281,000 2001
7 Korea, South 2,263,000 2004
8 Italy 2,158,000 2001
9 Germany 2,135,000 2003
10 India 2,090,000
11 Spain 1,582,000 2001
12 United Kingdom 1,084,000 2003
13 Belgium 1,042,000 2001
14 Canada 963,000 2004
15 Turkey 616,500 2001
16 Brazil 572,600
17 Sweden 553,100 2001
18 Australia 530,800 2001
19 Greece 468,300 2001
20 Ukraine 444,600
21 Poland 413,700 2001
22 Belarus 360,000 2004 est.
23 Portugal 357,300 2001
24 Indonesia 345,700 2005 est.
25 Finland 318,300 2001
26 Philippines 312,000 2003
27 Switzerland 289,500 2001
28 Chile 221,500 2003 est.
29 Mexico 205,000 2004
30 Denmark 195,000 2001
31 Czech Republic 182,000 2004
32 Ireland 178,600 2001
33 Romania 163,000 2004
34 Austria 152,600 2004
35 Morocco 147,800
36 Dominican Republic 129,900 2003
37 New Zealand 119,700 2001
38 Jordan 100,000 2004 est.
39 Hungary 94,000 2004
40 Lithuania 93,000 2004
41 Norway 88,870 2001
42 Bulgaria 85,000 2004 est.
43 Russia 75,000
44 Slovakia 59,000
45 Estonia 54,000 2004
46 Luxembourg 50,700 2001
47 Burma 49,230 2003
48 Kazakhstan 47,000 2003
49 Latvia 47,000 2004
50 Zimbabwe 23,000
51 Korea, North 22,000 2004 est.
52 Albania 21,600 2005 est.
53 Botswana 16,000 2001
54 Nicaragua 15,560 2005 est.
55 Iceland 15,470 2001
56 Namibia 12,770
57 Nepal 11,760
58 Mongolia 11,210 2005 est.
59 Suriname 1,644 2003
60 United Arab Emirates 0 2004
61 Saudi Arabia 0 2003
62 Sudan 0 2004
63 Libya 0
64 Algeria 0 2004 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2176
Rank Country Oil - exports(bbl/day) Date of Information
1 Saudi Arabia 7,920,000 2003
2 European Union 5,322,000 2001
3 Russia 5,150,000 2004
4 Norway 3,466,000 2001
5 United Arab Emirates 2,500,000 2004 est.
6 Iran 2,500,000 2004 est.
7 Venezuela 2,100,000 2004 est.
8 Kuwait 1,970,000 2003
9 Mexico 1,863,000 2004
10 Canada 1,600,000 2004
11 United Kingdom 1,498,000 2001
12 Iraq 1,420,000 2005 est.
13 Netherlands 1,418,000 2001
14 Libya 1,340,000
15 Algeria 1,127,000 2004 est.
16 United States 1,048,000 2004
17 Kazakhstan 890,000 2003
18 Oman 721,000 2004
19 Korea, South 645,200 2004
20 Australia 523,400 2001
21 Italy 456,600 2001
22 Belgium 450,000 2001
23 Indonesia 431,500 2004 est.
24 France 409,600 2001
25 Ecuador 387,000 2004 est.
26 Yemen 370,300 2003
27 India 350,000
28 China 340,300 2004
29 Denmark 332,100 2001
30 Syria 285,000 2004
31 Sudan 275,000 2004
32 Brazil 241,700
33 Malaysia 230,200 2003
34 Sweden 203,700 2001
35 Brunei 192,700 2005
36 Spain 135,100 2001
37 Egypt 134,000
38 Finland 101,000 2001
39 Japan 93,360 2001
40 Greece 84,720 2001
41 Poland 53,000 2001
42 Peru 49,000 2004 est.
43 Hungary 47,180 2001
44 Turkey 46,110 2001
45 New Zealand 30,220 2001
46 Austria 30,140 2004
47 Bahamas, The 29,000 2003
48 Portugal 28,830 2001
49 Ireland 27,450 2001
50 Czech Republic 26,670 2001
51 Belarus 14,500 2003 est.
52 Germany 12,990 2003
53 Switzerland 10,420 2001
54 Ukraine 8,891
55 Burma 3,356 2003
56 Guatemala 3,104 2003
57 Slovakia 2,160
58 Suriname 1,370 2003
59 Nicaragua 759 2004
60 Luxembourg 634 2001
61 Mongolia 515 2005 est.
62 Albania 0 2005 est.
63 Zimbabwe 0
64 Philippines 0 2001
65 Morocco 0
66 Jordan 0 2004 est.
67 Latvia 0 2004
68 Iceland 0 2001
69 Bermuda 0
70 Estonia 0 2004
71 Chile 0
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2178
Rank Country Oil - proved reserves(bbl) Date of Information
1 World 1,349,000,000,000 1 January 2002 est.
2 Saudi Arabia 262,700,000,000 2005 est.
3 Canada 178,900,000,000 2004 est.
4 Iran 133,300,000,000 2005 est.
5 Iraq 112,500,000,000 2005 est.
6 United Arab Emirates 97,800,000,000 2005 est.
7 Kuwait 96,500,000,000 2005 est.
8 Venezuela 75,590,000,000 2005 est.
9 Russia 69,000,000,000 2003 est.
10 Libya 40,000,000,000 2005 est.
11 Nigeria 36,000,000,000 2005 est.
12 Mexico 33,310,000,000 2005 est.
13 Kazakhstan 26,000,000,000 1 January 2004
14 Angola 25,000,000,000 2005 est.
15 United States 22,450,000,000 1 January 2002
16 China 18,260,000,000 2004
17 Qatar 16,000,000,000 2005 est.
18 Brazil 15,120,000,000 2005 est.
19 Algeria 12,460,000,000 2005 est.
20 Norway 9,859,000,000 1 January 2002
21 European Union 7,294,000,000 1 January 2002
22 Oman 6,100,000,000 2005 est.
23 India 5,700,000,000 2005 est.
24 Indonesia 4,600,000,000 2005 est.
25 Ecuador 4,512,000,000 2005 est.
26 United Kingdom 4,500,000,000 31 December 2004
27 Yemen 4,370,000,000 2005 est.
28 Australia 3,664,000,000 1 January 2002
29 Malaysia 3,100,000,000 2005 est.
30 Argentina 2,950,000,000 2005 est.
31 Egypt 2,700,000,000 2005 est.
32 Syria 2,500,000,000 2005 est.
33 Gabon 1,921,000,000 2005 est.
34 Tunisia 1,700,000,000 2005 est.
35 Sudan 1,600,000,000 2005 est.
36 Congo, Democratic Republic of the 1,538,000,000 1 January 2002
37 Colombia 1,492,000,000 2005 est.
38 Brunei 1,255,000,000 1 January 2002
39 Denmark 1,230,000,000 1 January 2002
40 Burma 1,000,000,000 2005
41 Mauritania 1,000,000,000 2005
42 Trinidad and Tobago 990,000,000 1 January 2004
43 Uzbekistan 600,000,000 1 January 2005
44 Vietnam 600,000,000 2005 est.
45 Azerbaijan 589,000,000 1 January 2002
46 Italy 586,600,000 1 January 2002
47 Thailand 583,000,000 November 2003
48 Equatorial Guinea 563,500,000 1 January 2002
49 Cuba 532,000,000 1 January 2002
50 Romania 500,000,000 yearend 2004
51 Bolivia 458,800,000 1 January 2002
52 Germany 395,800,000 1 January 2004
53 Ukraine 395,000,000 9 November 2004
54 Peru 370,000,000 2005 est.
55 Pakistan 341,800,000 2005 est.
56 Turkey 288,400,000 1 January 2002
57 Turkmenistan 273,000,000 1 January 2002
58 Guatemala 263,000,000 1 January 2002
59 Cote d''Ivoire 220,000,000 2005 est.
60 Albania 185,500,000 1 January 2002
61 Papua New Guinea 170,000,000 2005 est.
62 Philippines 152,000,000 1 January 2004
63 Chile 150,000,000 1 January 2004
64 Suriname 150,000,000 2005
65 France 144,300,000 1 January 2002
66 Poland 142,400,000 December 2004
67 Bahrain 124,000,000 2005 est.
68 Hungary 102,000,000 1 January 2006
69 Morocco 100,000,000 2005 est.
70 Croatia 93,600,000 1 January 2002
71 Congo, Republic of the 93,500,000 1 January 2002
72 New Zealand 89,620,000 1 January 2002
73 Netherlands 88,060,000 1 January 2002
74 Cameroon 85,000,000 2005 est.
75 Austria 84,300,000 2004
76 Serbia 38,750,000 1 January 2002
77 Japan 29,290,000 1 January 2002
78 Bangladesh 28,450,000 1 January 2002
79 Bulgaria 15,000,000 1 January 2005
80 Czech Republic 15,000,000 1 January 2006
81 Lithuania 12,000,000 2004
82 Spain 10,500,000 1 January 2002
83 Slovakia 9,000,000 1 January 2006
84 Ghana 8,255,000 1 January 2002
85 South Africa 7,840,000 1 January 2002
86 Greece 4,500,000 1 January 2002
87 Benin 4,105,000 1 January 2002
88 Taiwan 2,900,000 2005 est.
89 Israel 1,920,000 1 January 2002
90 Barbados 1,254,000 1 January 2002
91 Jordan 445,000 1 January 2002
92 Ethiopia 214,000 1 January 2002
93 Afghanistan 0 1 January 2002
94 Somalia 0 1 January 2002
95 Namibia 0 1 January 2002
96 Tanzania 0 1 January 2002
97 Rwanda 0 1 January 2002
98 Ireland 0 1 January 2002
99 Mozambique 0 1 January 2002
100 Madagascar 0 1 January 2002
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2179
Rank Country Natural gas - proved reserves(cu m) Date of Information
1 World 174,600,000,000,000 1 January 2002
2 Russia 47,570,000,000,000 2003
3 Iran 26,620,000,000,000 2005
4 Qatar 25,770,000,000,000 2005
5 Saudi Arabia 6,544,000,000,000 2005
6 United Arab Emirates 6,006,000,000,000 2005
7 United States 5,353,000,000,000 1 January 2002
8 Algeria 4,531,000,000,000 2005
9 Nigeria 4,502,000,000,000 2005
10 Venezuela 4,191,000,000,000 2005
11 European Union 3,256,000,000,000 1 January 2002
12 Iraq 3,115,000,000,000 2005
13 Kazakhstan 3,000,000,000,000 1 January 2004
14 Indonesia 2,557,000,000,000 2005
15 Australia 2,549,000,000,000 1 January 2002
16 China 2,530,000,000,000 2004
17 Malaysia 2,124,000,000,000 2005
18 Norway 2,118,000,000,000 1 January 2002
19 Turkmenistan 2,010,000,000,000 1 January 2002
20 Egypt 1,900,000,000,000 2005
21 Uzbekistan 1,875,000,000,000 1 January 2005
22 Netherlands 1,756,000,000,000 1 January 2002
23 Canada 1,673,000,000,000 2004
24 Kuwait 1,572,000,000,000 2005
25 Libya 1,321,000,000,000 2005
26 Ukraine 1,121,000,000,000 9 November 2004
27 India 853,500,000,000 2005
28 Azerbaijan 849,500,000,000 1 January 2002
29 Oman 829,100,000,000 2005
30 Pakistan 759,700,000,000 2005
31 Trinidad and Tobago 733,000,000,000 1 January 2004
32 Bolivia 679,600,000,000 1 January 2002
33 Argentina 663,500,000,000 2005
34 United Kingdom 628,600,000,000 31 December 2004
35 Yemen 478,600,000,000 2005
36 Mexico 424,300,000,000 2005
37 Brunei 390,800,000,000 1 January 2002
38 Thailand 377,700,000,000 November 2003
39 Papua New Guinea 345,500,000,000 2005
40 Germany 305,800,000,000 1 January 2004
41 Bangladesh 300,200,000,000 1 January 2002
42 Romania 300,000,000,000 yearend 2004
43 Burma 283,200,000,000 2005
44 Peru 247,100,000,000 2005
45 Syria 240,700,000,000 2005
46 Brazil 240,000,000,000 2005
47 Italy 226,500,000,000 1 January 2002
48 Vietnam 192,600,000,000 2005
49 Poland 154,400,000,000 December 2004
50 Colombia 127,600,000,000 2005
51 Mozambique 127,400,000,000 1 January 2002
52 Cameroon 110,400,000,000 2005
53 Philippines 106,800,000,000 1 January 2004
54 Afghanistan 99,960,000,000 1 January 2002
55 Chile 97,980,000,000 1 January 2004
56 Bahrain 92,030,000,000 2005
57 Congo, Republic of the 90,610,000,000 1 January 2002
58 Sudan 84,950,000,000 2005
59 Tunisia 77,870,000,000 2005
60 Taiwan 76,460,000,000 2005
61 Denmark 73,510,000,000 1 January 2002
62 Cuba 70,790,000,000 1 January 2002
63 Namibia 62,300,000,000 1 January 2002
64 Rwanda 56,630,000,000 1 January 2002
65 Serbia 48,140,000,000 1 January 2002
66 Angola 45,870,000,000 2005
67 Japan 3','21afc2e250c14805858c3efb60929e9cd7b99bf887a2b1e1dae866ce8032fbd4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db1a145f117b69530dd3c936e0397d48efcad54bdcd363ea340207f99a93cd99',2006,'ZW','Zimbabwe','communications',16,'9,640,000,000 1 January 2002
68 Israel 38,940,000,000 1 January 2002
69 New Zealand 37,380,000,000 1 January 2002
70 Equatorial Guinea 36,810,000,000 1 January 2002
71 Gabon 33,980,000,000 2005
72 Hungary 33,980,000,000 1 January 2003
73 Cote d''Ivoire 29,730,000,000 2005
74 Ethiopia 24,920,000,000 1 January 2002
75 Croatia 24,720,000,000 1 January 2002
76 Ghana 23,790,000,000 1 January 2002
77 Austria 23,200,000,000 2004
78 Tanzania 22,650,000,000 1 January 2002
79 Ireland 19,820,000,000 1 January 2002
80 Slovakia 15,010,000,000 1 January 2003
81 France 14,330,000,000 1 January 2002
82 Ecuador 9,769,000,000 2005
83 Turkey 8,495,000,000 1 January 2002
84 Jordan 6,230,000,000 1 January 2002
85 Bulgaria 5,670,000,000 1 January 2005
86 Somalia 5,663,000,000 1 January 2002
87 Czech Republic 3,964,000,000 1 January 2003
88 Guatemala 3,087,000,000 1 January 2002
89 Albania 2,832,000,000 1 January 2002
90 Spain 2,662,000,000 1 January 2002
91 Benin 1,218,000,000 1 January 2002
92 Morocco 1,218,000,000 2005
93 Congo, Democratic Republic of the 991,100,000 1 January 2002
94 Greece 991,100,000 1 January 2002
95 Barbados 141,600,000 1 January 2002
96 South Africa 28,320,000 1 January 2002
97 Madagascar 0 1 January 2002
98 Mauritania 0 2005
99 Suriname 0 2005
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2180
Rank Country Natural gas - production(cu m) Date of Information
1 World 2,674,000,000,000 2003 est.
2 Russia 587,000,000,000 2005 est.
3 United States 539,000,000,000 2003 est.
4 European Union 239,200,000,000 2001
5 Canada 165,800,000,000 2003 est.
6 United Kingdom 102,800,000,000 2003 est.
7 Indonesia 83,400,000,000 2005 est.
8 Algeria 82,400,000,000 2003 est.
9 Iran 79,000,000,000 2003 est.
10 Norway 73,400,000,000 2003 est.
11 Netherlands 73,130,000,000 2003 est.
12 Saudi Arabia 60,060,000,000 2003 est.
13 Uzbekistan 55,800,000,000 2004
14 Turkmenistan 54,600,000,000 2004 est.
15 Malaysia 53,500,000,000 2003 est.
16 Mexico 47,300,000,000 2004 est.
17 United Arab Emirates 44,790,000,000 2003 est.
18 Argentina 41,040,000,000 2003 est.
19 Australia 35,600,000,000 2003 est.
20 China 35,020,000,000 2003
21 Qatar 30,800,000,000 2003 est.
22 Venezuela 29,700,000,000 2003 est.
23 India 27,100,000,000 2003 est.
24 Egypt 27,000,000,000 2003 est.
25 Trinidad and Tobago 24,700,000,000 2003 est.
26 Pakistan 23,800,000,000 2003 est.
27 Thailand 22,280,000,000 2003 est.
28 Germany 22,220,000,000 2003 est.
29 Ukraine 20,300,000,000 2004
30 Nigeria 19,200,000,000 2003 est.
31 Kazakhstan 18,500,000,000 2004 est.
32 Oman 16,500,000,000 2003 est.
33 Brazil 15,790,000,000 2005 est.
34 Italy 13,550,000,000 2003 est.
35 Romania 13,200,000,000 2004 est.
36 Bangladesh 11,900,000,000 2003 est.
37 Brunei 11,400,000,000 2003 est.
38 Burma 9,980,000,000 2003 est.
39 Bahrain 9,650,000,000 2003 est.
40 Kuwait 8,300,000,000 2003 est.
41 Denmark 7,965,000,000 2003 est.
42 Libya 7,000,000,000 2003 est.
43 Syria 6,950,000,000 2003 est.
44 Bolivia 6,720,000,000 2003 est.
45 Vietnam 6,342,000,000 2005 est.
46 Colombia 6,080,000,000 2003 est.
47 Azerbaijan 5,130,000,000 2003 est.
48 New Zealand 4,773,000,000 2003 est.
49 Poland 4,330,000,000 2004
50 Hungary 3,100,000,000 2003 est.
51 Japan 2,814,000,000 2003 est.
52 South Africa 2,350,000,000 2003 est.
53 Philippines 2,300,000,000 2003 est.
54 Tunisia 2,150,000,000 2003 est.
55 Austria 1,960,000,000 2004
56 Croatia 1,850,000,000 2003 est.
57 France 1,566,000,000 2003 est.
58 Iraq 1,500,000,000 2003 est.
59 Cote d''Ivoire 1,300,000,000 2003 est.
60 Equatorial Guinea 1,270,000,000 2003 est.
61 Chile 1,000,000,000 2003 est.
62 Taiwan 970,000,000 2003 est.
63 Angola 720,000,000 2003 est.
64 Cuba 704,000,000 2004
65 Ireland 673,000,000 2003 est.
66 Serbia 650,000,000 2003 est.
67 Peru 560,000,000 2003 est.
68 Turkey 560,000,000 2003 est.
69 Jordan 390,000,000 2003 est.
70 Belarus 250,000,000 2004 est.
71 Spain 216,000,000 2003 est.
72 Israel 200,000,000 2003 est.
73 Slovakia 165,000,000 2004 est.
74 Papua New Guinea 140,000,000 2003 est.
75 Czech Republic 133,000,000 2003 est.
76 Gabon 90,000,000 2003 est.
77 Mozambique 60,000,000 2003 est.
78 Afghanistan 50,000,000 2003 est.
79 Senegal 50,000,000 2003 est.
80 Ecuador 50,000,000 2003 est.
81 Albania 30,000,000 2003 est.
82 Tajikistan 30,000,000 2004 est.
83 Barbados 29,170,000 2003 est.
84 Greece 27,000,000 2003 est.
85 Georgia 20,000,000 2003 est.
86 Kyrgyzstan 6,000,000 2003 est.
87 Morocco 5,000,000 2003 est.
88 Bulgaria 1,130,000 2003
89 Aruba 0 2003 est.
90 Botswana 0 2003 est.
91 Belgium 0 2003 est.
92 Belize 0 2003 est.
93 Benin 0 2003 est.
94 Bhutan 0 2003 est.
95 Guinea 0 2003 est.
96 Guatemala 0 2003 est.
97 Guam 0 2003 est.
98 Guadeloupe 0 2003 est.
99 Greenland 0 2003 est.
100 Grenada 0 2003 est.
101 Gibraltar 0 2003 est.
102 Ghana 0 2003 est.
103 Falkland Islands (Islas Malvinas) 0 2003 est.
104 Luxembourg 0 2003 est.
105 Lesotho 0 2003 est.
106 Liberia 0 2003 est.
107 Lithuania 0 2004
108 Latvia 0 2003
109 Lebanon 0 2003 est.
110 Laos 0 2003 est.
111 Korea, South 0 2003 est.
112 Kiribati 0 2003 est.
113 Zimbabwe 0 2003 est.
114 Zambia 0 2003 est.
115 Yemen 0 2003 est.
116 Swaziland 0 2003 est.
117 Samoa 0 2003 est.
118 Western Sahara 0 2003 est.
119 Namibia 0 2003 est.
120 Virgin Islands 0 2003 est.
121 British Virgin Islands 0 2003 est.
122 Saint Vincent and the Grenadines 0 2003 est.
123 Uruguay 0 2003 est.
124 Burkina Faso 0 2003 est.
125 Uganda 0 2003 est.
126 Tanzania 0 2003 est.
127 Sao Tome and Principe 0 2003 est.
128 Togo 0 2003 est.
129 Tonga 0 2003 est.
130 Turks and Caicos Islands 0 2003 est.
131 Switzerland 0 2003 est.
132 Sweden 0 2003 est.
133 Sudan 0 2003 est.
134 Saint Lucia 0 2003 est.
135 Somalia 0 2003 est.
136 Singapore 0 2004 est.
137 Sierra Leone 0 2003 est.
138 Slovenia 0 2003 est.
139 Saint Helena 0 2003 est.
140 Seychelles 0 2003 est.
141 Saint Kitts and Nevis 0 2003 est.
142 Saint Pierre and Miquelon 0 2003 est.
143 Rwanda 0 2003 est.
144 Puerto Rico 0 2003 est.
145 Reunion 0 2003 est.
146 Guinea-Bissau 0 2003 est.
147 Portugal 0 2003 est.
148 Panama 0 2003 est.
149 Paraguay 0 2003 est.
150 Nicaragua 0 2003 est.
151 Netherlands Antilles 0 2003 est.
152 Suriname 0 2003 est.
153 Nauru 0 2003 est.
154 Nepal 0 2003 est.
155 Vanuatu 0 2003 est.
156 Niger 0 2003 est.
157 Niue 0 2003 est.
158 New Caledonia 0 2003 est.
159 Maldives 0 2003 est.
160 Malta 0 2003 est.
161 Mauritania 0 2003 est.
162 Mauritius 0 2003 est.
163 Mali 0 2003 est.
164 Macedonia 0 2003 est.
165 Malawi 0 2003 est.
166 Montserrat 0 2003 est.
167 Mongolia 0 2003 est.
168 Moldova 0 2003 est.
169 Macau 0 2003 est.
170 Martinique 0 2003 est.
171 Madagascar 0 2003 est.
172 Korea, North 0 2003 est.
173 Kenya 0 2003 est.
174 Jamaica 0 2003 est.
175 Iceland 0 2003 est.
176 Honduras 0 2003 est.
177 Hong Kong 0
178 Haiti 0 2003 est.
179 Guyana 0 2003 est.
180 Fiji 0 2003 est.
181 Finland 0 2003 est.
182 French Guiana 0 2003 est.
183 Ethiopia 0 2003 est.
184 El Salvador 0 2003 est.
185 Eritrea 0 2003 est.
186 Estonia 0 2004
187 Dominican Republic 0 2003 est.
188 Gambia, The 0 2003 est.
189 French Polynesia 0 2003 est.
190 Faroe Islands 0 2003 est.
191 Dominica 0 2003 est.
192 Djibouti 0 2003 est.
193 Cyprus 0 2003 est.
194 Cook Islands 0 2003 est.
195 Cape Verde 0 2003 est.
196 Central African Republic 0 2003 est.
197 Costa Rica 0 2003 est.
198 Comoros 0 2003 est.
199 Cameroon 0 2003 est.
200 Cayman Islands 0 2003 est.
201 Congo, Democratic Republic of the 0 2003 est.
202 Congo, Republic of the 0 2003 est.
203 Sri Lanka 0 2003 est.
204 Chad 0 2003 est.
205 Cambodia 0 2003 est.
206 Burundi 0 2003 est.
207 Solomon Islands 0 2003 est.
208 Bosnia and Herzegovina 0 2003 est.
209 Bahamas, The 0 2003 est.
210 Bermuda 0 2003 est.
211 Armenia 0 2005 est.
212 American Samoa 0 2003 est.
213 Antigua and Barbuda 0 2003 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2181
Rank Country Natural gas - consumption(cu m) Date of Information
1 World 2,675,000,000,000 2003 est.
2 United States 633,600,000,000 2003 est.
3 European Union 465,600,000,000 2001
4 Russia 402,100,000,000 2004 est.
5 United Kingdom 95,150,000,000 2003 est.
6 Germany 93,880,000,000 2003 est.
7 Canada 90,950,000,000 2003 est.
8 Japan 86,510,000,000 2003 est.
9 Iran 79,000,000,000 2003 est.
10 Italy 76,880,000,000 2003 est.
11 Ukraine 75,800,000,000 2004
12 Saudi Arabia 60,060,000,000 2003 est.
13 Mexico 55,100,000,000 2004 est.
14 Netherlands 50,400,000,000 2003 est.
15 Uzbekistan 49,300,000,000 2004
16 France 43,740,000,000 2003 est.
17 United Arab Emirates 37,880,000,000 2003 est.
18 Argentina 34,580,000,000 2003 est.
19 China 33,440,000,000 2003 est.
20 Venezuela 29,700,000,000 2003 est.
21 Thailand 29,150,000,000 2003 est.
22 Malaysia 28,530,000,000 2003 est.
23 India 27,100,000,000 2003 est.
24 Egypt 27,000,000,000 2003 est.
25 Australia 25,080,000,000 2003 est.
26 Korea, South 24,090,000,000 2003 est.
27 Pakistan 23,800,000,000 2003 est.
28 Spain 23,270,000,000 2003 est.
29 Turkey 22,600,000,000 2005 est.
30 Indonesia 22,500,000,000 2005 est.
31 Brazil 21,740,000,000 2005 est.
32 Algeria 21,320,000,000 2003 est.
33 Belarus 20,500,000,000 2005 est.
34 Romania 18,800,000,000 2004 est.
35 Turkmenistan 15,500,000,000 2004 est.
36 Belgium 15,480,000,000 2003 est.
37 Kazakhstan 15,200,000,000 2004 est.
38 Poland 14,970,000,000 2003 est.
39 Hungary 13,000,000,000 2004
40 Trinidad and Tobago 12,790,000,000 2003 est.
41 Bangladesh 11,900,000,000 2003 est.
42 Qatar 11,610,000,000 2003 est.
43 Bahrain 9,650,000,000 2003 est.
44 Czech Republic 9,623,000,000 2003 est.
45 Azerbaijan 9,200,000,000 2003 est.
46 Austria 9,010,000,000 2004
47 Taiwan 8,450,000,000 2003 est.
48 Kuwait 8,300,000,000 2003 est.
49 Nigeria 7,410,000,000 2003 est.
50 Oman 7,090,000,000 2003 est.
51 Chile 7,060,000,000 2003 est.
52 Syria 6,950,000,000 2003 est.
53 Slovakia 6,800,000,000 2004 est.
54 Vietnam 6,342,000,000 2005 est.
55 Libya 6,250,000,000 2003 est.
56 Colombia 6,080,000,000 2003 est.
57 Singapore 5,320,000,000 2003 est.
58 Denmark 5,173,000,000 2003 est.
59 Finland 5,028,000,000 2003 est.
60 New Zealand 4,773,000,000 2003 est.
61 Ireland 4,298,000,000 2003 est.
62 Norway 4,140,000,000 2003 est.
63 Tunisia 3,840,000,000 2003 est.
64 Switzerland 3,209,000,000 2003 est.
65 Bulgaria 3,100,000,000 2004
66 Lithuania 3,100,000,000 2004
67 Croatia 2,990,000,000 2003 est.
68 Portugal 2,983,000,000 2003 est.
69 Serbia 2,550,000,000 2003 est.
70 Moldova 2,380,000,000 2003 est.
71 South Africa 2,350,000,000 2003 est.
72 Greece 2,340,000,000 2005 est.
73 Philippines 2,300,000,000 2003 est.
74 Latvia 1,760,000,000 2004 est.
75 Bolivia 1,740,000,000 2003 est.
76 Brunei 1,730,000,000 2003 est.
77 Armenia 1,685,000,000 2005 est.
78 Burma 1,569,000,000 2003 est.
79 Georgia 1,500,000,000 2005 est.
80 Kyrgyzstan 1,500,000,000 2004 est.
81 Iraq 1,500,000,000 2003 est.
82 Estonia 1,420,000,000 2004
83 Tajikistan 1,400,000,000 2004 est.
84 Cote d''Ivoire 1,300,000,000 2003 est.
85 Equatorial Guinea 1,270,000,000 2003 est.
86 Luxembourg 1,205,000,000 2003 est.
87 Slovenia 1,100,000,000 2003 est.
88 Sweden 980,000,000 2003 est.
89 Peru 910,000,000 2004 est.
90 Puerto Rico 740,000,000 2003 est.
91 Angola 720,000,000 2003 est.
92 Cuba 704,000,000 2004
93 Hong Kong 692,200,000 2003 est.
94 Morocco 650,000,000 2003 est.
95 Jordan 390,000,000 2003 est.
96 Dominican Republic 300,000,000 2003 est.
97 Israel 200,000,000 2003 est.
98 Bosnia and Herzegovina 160,000,000 2003 est.
99 Papua New Guinea 140,000,000 2003 est.
100 Gabon 90,000,000 2003 est.
101 Mozambique 60,000,000 2003 est.
102 Uruguay 60,000,000 2003 est.
103 Afghanistan 50,000,000 2003 est.
104 Senegal 50,000,000 2003 est.
105 Ecuador 50,000,000 2003 est.
106 Albania 30,000,000 2003 est.
107 Barbados 29,170,000 2003 est.
108 Aruba 0 2003 est.
109 Bahamas, The 0 2003 est.
110 Solomon Islands 0 2003 est.
111 Burundi 0 2003 est.
112 Zimbabwe 0 2003 est.
113 Zambia 0 2003 est.
114 Yemen 0 2003 est.
115 Swaziland 0 2003 est.
116 Samoa 0 2003 est.
117 Western Sahara 0 2003 est.
118 Namibia 0 2003 est.
119 Virgin Islands 0 2003 est.
120 British Virgin Islands 0 2003 est.
121 Saint Vincent and the Grenadines 0 2003 est.
122 Burkina Faso 0 2003 est.
123 Uganda 0 2003 est.
124 Tanzania 0 2003 est.
125 Sao Tome and Principe 0 2003 est.
126 Togo 0 2003 est.
127 Tonga 0 2003 est.
128 Turks and Caicos Islands 0 2003 est.
129 Sudan 0 2003 est.
130 Saint Lucia 0 2003 est.
131 Somalia 0 2003 est.
132 Sierra Leone 0 2003 est.
133 Saint Helena 0 2003 est.
134 Seychelles 0 2003 est.
135 Saint Kitts and Nevis 0 2003 est.
136 Saint Pierre and Miquelon 0 2003 est.
137 Netherlands Antilles 0 2003 est.
138 Suriname 0 2003 est.
139 Nauru 0 2003 est.
140 Nepal 0 2003 est.
141 Vanuatu 0 2003 est.
142 Niger 0 2003 est.
143 Niue 0 2003 est.
144 New Caledonia 0 2003 est.
145 Mali 0 2003 est.
146 Rwanda 0 2003 est.
147 Reunion 0 2003 est.
148 Guinea-Bissau 0 2003 est.
149 Panama 0 2003 est.
150 Paraguay 0 2003 est.
151 Nicaragua 0 2003 est.
152 Macedonia 0 2003 est.
153 Malawi 0 2003 est.
154 Montserrat 0 2003 est.
155 Mongolia 0 2003 est.
156 Macau 0 2003 est.
157 Martinique 0 2003 est.
158 Madagascar 0 2003 est.
159 Lesotho 0 2003 est.
160 Maldives 0 2003 est.
161 Malta 0 2003 est.
162 Mauritania 0 2003 est.
163 Mauritius 0 2003 est.
164 Liberia 0 2003 est.
165 Lebanon 0 2003 est.
166 Laos 0 2003 est.
167 Kiribati 0 2003 est.
168 Korea, North 0 2003 est.
169 Kenya 0 2003 est.
170 Jamaica 0 2003 est.
171 Guyana 0 2003 est.
172 Guinea 0 2003 est.
173 Guatemala 0 2003 est.
174 Guam 0 2003 est.
175 Guadeloupe 0 2003 est.
176 Greenland 0 2003 est.
177 Grenada 0 2003 est.
178 Gibraltar 0 2003 est.
179 Ghana 0 2003 est.
180 Iceland 0 2003 est.
181 Honduras 0 2003 est.
182 Haiti 0 2003 est.
183 Gambia, The 0 2003 est.
184 French Polynesia 0 2003 est.
185 Faroe Islands 0 2003 est.
186 Falkland Islands (Islas Malvinas) 0 2003 est.
187 Fiji 0 2003 est.
188 French Guiana 0 2003 est.
189 Ethiopia 0 2003 est.
190 El Salvador 0 2003 est.
191 Eritrea 0 2003 est.
192 Dominica 0 2003 est.
193 Djibouti 0 2003 est.
194 Cyprus 0 2003 est.
195 Cook Islands 0 2003 est.
196 Cape Verde 0 2003 est.
197 Central African Republic 0 2003 est.
198 Costa Rica 0 2003 est.
199 Comoros 0 2003 est.
200 Cameroon 0 2003 est.
201 Cayman Islands 0 2003 est.
202 Congo, Democratic Republic of the 0 2003 est.
203 Congo, Republic of the 0 2003 est.
204 Sri Lanka 0 2003 est.
205 Chad 0 2003 est.
206 Cambodia 0 2003 est.
207 Bhutan 0 2003 est.
208 Benin 0 2003 est.
209 Belize 0 2003 est.
210 Bermuda 0 2003 est.
211 American Samoa 0 2003 est.
212 Botswana 0 2003 est.
213 Antigua and Barbuda 0 2003 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2182
Rank Country Natural gas - imports(cu m) Date of Information
1 World 696,000,000,000 2001 est.
2 European Union 297,800,000,000 2001
3 United States 114,100,000,000 2004 est.
4 Germany 85,020,000,000 2003
5 Japan 77,730,000,000 2001 est.
6 Ukraine 59,800,000,000 2004
7 Italy 54,780,000,000 2001 est.
8 France 40,260,000,000 2001 est.
9 Korea, South 21,110,000,000 2003 est.
10 Netherlands 20,780,000,000 2001 est.
11 Belarus 20,500,000,000 2005 est.
12 Spain 17,260,000,000 2001 est.
13 Turkey 15,750,000,000 2001 est.
14 Belgium 15,400,000,000 2001 est.
15 Russia 12,000,000,000 2004 est.
16 Hungary 10,950,000,000 2004
17 Czech Republic 9,800,000,000 2004
18 Poland 9,450,000,000 2004
19 Canada 8,730,000,000 2003 est.
20 Mexico 7,850,000,000 2004 est.
21 Taiwan 7,480,000,000 2005 est.
22 Slovakia 7,300,000,000 2004 est.
23 Austria 7,050,000,000 2004
24 Brazil 5,947,000,000 2005 est.
25 Romania 5,900,000,000 2004 est.
26 Chile 5,337,000,000 2002 est.
27 Thailand 5,200,000,000 2001 est.
28 Iran 4,920,000,000 2003 est.
29 Finland 4,567,000,000 2001 est.
30 Ireland 3,384,000,000 2001 est.
31 Lithuania 3,100,000,000 2004
32 Switzerland 3,093,000,000 2001 est.
33 Bulgaria 2,900,000,000 2004
34 United Kingdom 2,700,000,000 2001 est.
35 Portugal 2,553,000,000 2001 est.
36 Singapore 2,500,000,000 2001 est.
37 Moldova 2,050,000,000 2001 est.
38 Greece 2,018,000,000 2001 est.
39 Latvia 1,760,000,000 2004
40 Armenia 1,685,000,000 2005 est.
41 Tunisia 1,580,000,000 2001 est.
42 Georgia 1,500,000,000 2005 est.
43 Kyrgyzstan 1,500,000,000 2004 est.
44 Estonia 1,420,000,000 2004
45 Tajikistan 1,400,000,000 2004 est.
46 Croatia 1,080,000,000 2001 est.
47 Azerbaijan 1,000,000,000 2001 est.
48 Sweden 968,000,000 2001 est.
49 Slovenia 963,000,000 2002
50 Luxembourg 867,000,000 2001 est.
51 Puerto Rico 630,000,000 2001 est.
52 Bosnia and Herzegovina 300,000,000 2001 est.
53 Hong Kong 71,150,000 2004 est.
54 Uruguay 65,000,000 2003 est.
55 United Arab Emirates 0 2003 est.
56 Afghanistan 0 2001 est.
57 Argentina 0 2001 est.
58 Bolivia 0 2001 est.
59 Syria 0 2001 est.
60 Senegal 0 2001 est.
61 South Africa 0 2001 est.
62 Saudi Arabia 0 2002
63 Philippines 0 2004 est.
64 Serbia 0
65 Qatar 0 2001 est.
66 Papua New Guinea 0 2001 est.
67 Peru 0 2004 est.
68 Yemen 0 2003 est.
69 Venezuela 0 2004 est.
70 Uzbekistan 0 2004
71 Turkmenistan 0 2004 est.
72 Trinidad and Tobago 0 2001 est.
73 New Zealand 0 2001 est.
74 Norway 0 2001 est.
75 Nigeria 0 2001 est.
76 Mozambique 0 2001 est.
77 Malaysia 0 2001 est.
78 Oman 0 2001 est.
79 Libya 0 2001 est.
80 Kuwait 0 2002 est.
81 Pakistan 0 2001 est.
82 Jordan 0 2001 est.
83 Iraq 0 2004 est.
84 Cote d''Ivoire 0 2001 est.
85 Israel 0 2001 est.
86 India 0 2001 est.
87 Indonesia 0 2005 est.
88 Gabon 0 2001 est.
89 Ecuador 0 2001 est.
90 Denmark 0 2001 est.
91 Cuba 0 2004
92 Colombia 0 2004 est.
93 Cameroon 0
94 China 0 2004
95 Congo, Republic of the 0
96 Brunei 0 2001 est.
97 Burma 0 2003 est.
98 Equatorial Guinea 0 2001 est.
99 Egypt 0 2001 est.
100 Bangladesh 0 2001 est.
101 Barbados 0 2001 est.
102 Bahrain 0 2002 est.
103 Australia 0 2001 est.
104 Angola 0 2001 est.
105 Albania 0 2001 est.
106 Algeria 0 2005 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2183
Rank Country Natural gas - exports(cu m) Date of Information
1 World 667,600,000,000 2001 est.
2 Russia 157,200,000,000 2004 est.
3 Canada 91,520,000,000 2003 est.
4 European Union 78,100,000,000 2001
5 Algeria 57,980,000,000 2001 est.
6 Norway 50,500,000,000 2001 est.
7 Netherlands 49,280,000,000 2001 est.
8 Turkmenistan 38,600,000,000 2004 est.
9 Indonesia 37,500,000,000 2005 est.
10 United States 24,190,000,000 2004
11 Malaysia 22,410,000,000 2001 est.
12 Qatar 18,200,000,000 2004 est.
13 United Kingdom 15,750,000,000 2001 est.
14 Trinidad and Tobago 11,790,000,000 2003 est.
15 Australia 9,744,000,000 2001 est.
16 Brunei 9,000,000,000 2001 est.
17 Burma 8,424,000,000 2003 est.
18 Nigeria 7,830,000,000 2001 est.
19 Germany 7,731,000,000 2003
20 Oman 7,430,000,000 2001 est.
21 United Arab Emirates 7,190,000,000 2003 est.
22 Uzbekistan 6,500,000,000 2004
23 Argentina 6,050,000,000 2001 est.
24 Kazakhstan 4,100,000,000 2004 est.
25 Ukraine 3,900,000,000 2004
26 Iran 3,400,000,000 2003 est.
27 Denmark 3,100,000,000 2001 est.
28 Bolivia 2,900,000,000 2001 est.
29 China 2,790,000,000 2004
30 France 1,725,000,000 2001 est.
31 Libya 770,000,000 2001 est.
32 Italy 61,000,000 2001 est.
33 Poland 44,000,000 2004
34 Hungary 4,000,000 2001 est.
35 Czech Republic 1,000,000 2001 est.
36 Slovakia 1,000,000 2004 est.
37 Afghanistan 0 2001 est.
38 Austria 0 2004
39 Barbados 0 2001 est.
40 Bangladesh 0 2001 est.
41 Japan 0 2001 est.
42 Iraq 0 2004 est.
43 Cote d''Ivoire 0 2001 est.
44 Israel 0 2001 est.
45 India 0 2001 est.
46 Croatia 0 2001 est.
47 Hong Kong 0 2004 est.
48 Greece 0 2001 est.
49 Ecuador 0 2001 est.
50 Spain 0 2001 est.
51 Singapore 0 2001 est.
52 Slovenia 0 2003
53 Senegal 0 2001 est.
54 South Africa 0 2001 est.
55 Saudi Arabia 0 2002
56 Puerto Rico 0 2001 est.
57 Philippines 0 2004 est.
58 Romania 0 2003 est.
59 Yemen 0 2003 est.
60 Vietnam 0 2005 est.
61 Venezuela 0 2004 est.
62 Uruguay 0 2003 est.
63 Taiwan 0 2005 est.
64 Turkey 0 2001 est.
65 Tunisia 0 2001 est.
66 Tajikistan 0 2004 est.
67 Thailand 0 2001 est.
68 Switzerland 0 2001 est.
69 Syria 0 2001 est.
70 Sweden 0 2001 est.
71 Serbia 0
72 Papua New Guinea 0 2001 est.
73 Portugal 0 2001 est.
74 Pakistan 0 2001 est.
75 Peru 0 2004 est.
76 New Zealand 0 2001 est.
77 Mozambique 0 2001 est.
78 Mexico 0 2004 est.
79 Moldova 0 2001 est.
80 Luxembourg 0 2001 est.
81 Lithuania 0 2004
82 Latvia 0 2004 est.
83 Kuwait 0 2002 est.
84 Korea, South 0 2003 est.
85 Kyrgyzstan 0 2004 est.
86 Jordan 0 2001 est.
87 Cuba 0 2004
88 Colombia 0 2004 est.
89 Cameroon 0
90 Chile 0 2002
91 Congo, Republic of the 0
92 Bulgaria 0 2003
93 Brazil 0 2005 est.
94 Belarus 0 2004 est.
95 Gabon 0 2001 est.
96 Finland 0 2001 est.
97 Estonia 0 2004
98 Equatorial Guinea 0 2001 est.
99 Ireland 0 2001 est.
100 Egypt 0 2001 est.
101 Bosnia and Herzegovina 0 2001 est.
102 Belgium 0 2001 est.
103 Bahrain 0 2002 est.
104 Azerbaijan 0 2001 est.
105 Albania 0 2001 est.
106 Armenia 0 2005 est.
107 Angola 0 2001 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2184
Rank Country Internet hosts Date of Information
1 United States 195,138,696 2005
2 Japan 28,321,846 2006
3 European Union 22,000,414
4 Germany 11,859,131 2006
5 Netherlands 8,363,158 2006
6 Australia 7,772,888 2006
7 Brazil 6,508,431 2006
8 United Kingdom 6,064,860 2006
9 Korea, South 5,433,591 2005
10 Taiwan 4,320,310 2006
11 Canada 3,934,223 2006
12 Mexico 3,426,680 2006
13 France 3,148,379 2006
14 Sweden 2,958,435 2006
15 Belgium 2,870,770 2006
16 Spain 2,520,711 2006
17 Switzerland 2,442,659 2006
18 Denmark 2,415,530 2006
19 Austria 2,062,035 2006
20 Russia 1,979,924 2006
21 Italy 1,731,165 2006
22 Finland 1,633,614 2006
23 Argentina 1,612,423 2006
24 India 1,543,289 2006
25 Norway 1,364,448 2006
26 Turkey 1,313,135 2006
27 Czech Republic 1,267,265 2006
28 Israel 1,251,881 2006
29 New Zealand 1,050,197 2006
30 Thailand 938,784 2006
31 Singapore 898,762 2006
32 Portugal 845,980 2005
33 Hong Kong 800,834 2006
34 South Africa 645,179 2006
35 Hungary 608,085 2006
36 Greece 587,717 2006
37 Colombia 581,877 2006
38 Chile 506,055 2006
39 Poland 358,476 2006
40 United Arab Emirates 337,092 2006
41 Peru 269,981 2006
42 Ireland 238,191 2006
43 China 232,780 2006
44 Ukraine 229,110 2006
45 Iceland 212,897 2006
46 Slovakia 210,758 2006
47 Bulgaria 184,975 2006
48 Indonesia 170,834 2006
49 Malaysia 158,650 2006
50 Lithuania 148,675 2006
51 Uruguay 145,774 2006
52 Philippines 111,262 2006
53 Dominican Republic 91,895 2006
54 Luxembourg 88,661 2006
55 Pakistan 72,765 2006
56 Cyprus 67,589 2006
57 Latvia 65,858 2006
58 Slovenia 61,735 2006
59 Moldova 58,886 2006
60 Romania 57,470 2006
61 Estonia 52,241 2006
62 Venezuela 51,968 2006
63 Guatemala 49,026 2006
64 Belarus 33,641 2006
65 Bosnia and Herzegovina 31,490 2006
66 Trinidad and Tobago 30,732 2006
67 Nicaragua 24,452 2006
68 Kazakhstan 21,187 2006
69 Bolivia 20,085 2006
70 Netherlands Antilles 19,204 2006
71 Ecuador 19,027 2006
72 Kyrgyzstan 18,928 2006
73 Croatia 18,825 2006
74 Tonga 18,775 2006
75 Nepal 17,789 2006
76 Andorra 14,944 2006
77 French Polynesia 14,047 2006
78 Malta 14,025 2006
79 New Caledonia 13,962 2006
80 Kenya 13,274 2006
81 Paraguay 13,178 2006
82 Costa Rica 12,751 2006
83 Monaco 12,720 2006
84 Vietnam 12,114 2006
85 Aruba 11,548 2006
86 Saudi Arabia 10,931 2006
87 Georgia 10,752 2006
88 Samoa 10,680 2006
89 Uzbekistan 9,058 2006
90 Fiji 8,987 2006
91 Greenland 8,851 2006
92 Cayman Islands 8,611 2006
93 Tanzania 8,609 2006
94 Armenia 8,163 2006
95 Bermuda 8,114 2006
96 Zimbabwe 7,954 2006
97 Antarctica 7,757 2006
98 Bhutan 7,567 2006
99 Panama 7,149 2006
100 Mozambique 6,985 2006
101 Faroe Islands 6,915 2006
102 Sri Lanka 6,526 2006
103 Botsw','2fc1738164bd7ddc048e87cc334c53d72232514d0a99d2b2a1172882193edd83','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4469027a1b981791b2a52a6e1a24d21ec018e8e7bdd90600769a027016442530',2006,'ZW','Zimbabwe','communications',17,'ana 5,499 2006
104 Iran 5,242 2006
105 Mauritius 4,997 2006
106 Liechtenstein 4,697 2006
107 El Salvador 4,682 2006
108 Honduras 3,973 2006
109 Belize 3,905 2006
110 Virgin Islands 3,855 2006
111 Macedonia 3,716 2006
112 Oman 3,555 2006
113 Namibia 3,527 2006
114 Jordan 3,441 2006
115 Lebanon 3,307 2006
116 Zambia 3,227 2006
117 Morocco 3,218 2006
118 San Marino 3,140 2006
119 Turks and Caicos Islands 2,735 2006
120 Solomon Islands 2,658 2006
121 Cote d''Ivoire 2,534 2006
122 Angola 2,525 2006
123 Swaziland 2,472 2006
124 Christmas Island 2,368 2006
125 Kuwait 2,310 2006
126 Egypt 2,254 2006
127 Cuba 2,234 2006
128 Antigua and Barbuda 2,231 2006
129 Bahrain 2,165 2006
130 Congo, Democratic Republic of the 1,778 2006
131 Rwanda 1,590 2006
132 Papua New Guinea 1,573 2006
133 Nigeria 1,549 2006
134 Djibouti 1,540 2006
135 Madagascar 1,504 2006
136 American Samoa 1,456 2006
137 Cook Islands 1,456 2006
138 Jamaica 1,402 2006
139 Cambodia 1,378 2006
140 Uganda 1,365 2006
141 Maldives 1,357 2006
142 Guernsey 1,245 2006
143 Jersey 1,240 2006
144 Algeria 1,202 2006
145 Laos 1,108 2006
146 Eritrea 1,088 2006
147 Guyana 1,046 2006
148 Azerbaijan 880 2006
149 Benin 867 2006
150 Sao Tome and Principe 735 2006
151 Gibraltar 641 2006
152 Bahamas, The 591 2006
153 Turkmenistan 585 2006
154 Micronesia, Federated States of 550 2006
155 British Virgin Islands 525 2006
156 Togo 520 2006
157 Bangladesh 469 2006
158 Albania 430 2006
159 Tunisia 428 2006
160 Guadeloupe 422 2006
161 Vanuatu 413 2006
162 Senegal 412 2006
163 Puerto Rico 404 2006
164 Anguilla 403 2006
165 Burkina Faso 399 2006
166 Montserrat 386 2006
167 Ghana 380 2006
168 Malawi 377 2006
169 Guinea 367 2006
170 Saint Helena 329 2006
171 Gabon 322 2006
172 Qatar 301 2006
173 Tokelau 298 2006
174 Isle of Man 290 2006
175 Barbados 282 2006
176 Mali 278 2006
177 Mongolia 272 2006
178 South Georgia and the South Sandwich Islands 271 2006
179 Dominica 263 2006
180 Cape Verde 234 2006
181 Niger 189 2006
182 Yemen 171 2006
183 Lesotho 168 2006
184 Burundi 160 2006
185 Suriname 126 2006
186 Macau 108 2006
187 French Guiana 106 2006
188 Falkland Islands (Islas Malvinas) 103 2006
189 Norfolk Island 100 2006
190 Tajikistan 98 2006
191 Saint Vincent and the Grenadines 94 2006
192 Ethiopia 88 2006
193 Guam 76 2006
194 Martinique 72 2006
195 Seychelles 72 2006
196 East Timor 68 2006
197 Syria 66 2006
198 British Indian Ocean Territory 65 2006
199 Nauru 52 2006
200 Saint Kitts and Nevis 50 2006
201 Congo, Republic of the 46 2004
202 Holy See (Vatican City) 45 2006
203 Burma 42 2006
204 Kiribati 42 2006
205 Cameroon 39 2006
206 French Southern and Antarctic Lands 38 2006
207 Mauritania 32 2006
208 Libya 31 2006
209 Reunion 29 2006
210 Brunei 27 2005
211 Afghanistan 22 2006
212 Saint Lucia 21 2006
213 Northern Mariana Islands 20 2005
214 Sierra Leone 20 2006
215 Equatorial Guinea 19 2006
216 Grenada 17 2006
217 Sudan 16 2006
218 Gambia, The 14 2006
219 Central African Republic 10 2006
220 Chad 9 2006
221 Liberia 8 2006
222 Pitcairn Islands 8 2006
223 Bouvet Island 6 2006
224 Marshall Islands 6 2006
225 Haiti 6 2006
226 Comoros 5 2006
227 Iraq 5 2006
228 Guinea-Bissau 5 2006
229 Palau 3 2006
230 Somalia 3 2006
231 Mayotte 1 2006
232 Wallis and Futuna 1 2006
233 Saint Pierre and Miquelon 0 2006
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2185
Rank Country Investment (gross fixed)(% of GDP) Date of Information
1 Azerbaijan 54.40 2005 est.
2 China 44.40 2005 est.
3 Seychelles 42.00 2005 est.
4 Equatorial Guinea 39.90 2005 est.
5 Turkmenistan 35.60 2005 est.
6 Guyana 34.40 2005 est.
7 Vietnam 33.10 2005 est.
8 Jamaica 32.40 2005 est.
9 Sao Tome and Principe 32.20 2005 est.
10 Angola 30.30 2005 est.
11 Iran 30.10 2005 est.
12 Lesotho 29.90 2005 est.
13 Mozambique 29.60 2005 est.
14 Spain 29.40 2005 est.
15 Korea, South 29.30 2005 est.
16 Estonia 29.10 2005 est.
17 Thailand 29.00 2005 est.
18 Iceland 28.70 2005 est.
19 Croatia 28.60 2005 est.
20 India 28.10 2005 est.
21 Latvia 27.80 2005 est.
22 Haiti 27.40 2004 est.
23 Zambia 27.10 2005 est.
24 Ireland 27.00 2005 est.
25 Nicaragua 27.00 2005 est.
26 Kazakhstan 26.50 2005 est.
27 Czech Republic 26.40 2005 est.
28 Madagascar 26.40 2005 est.
29 Sri Lanka 26.10 2005 est.
30 Slovakia 26.00 2005 est.
31 Australia 25.90 2005 est.
32 Eritrea 25.10 2005 est.
33 Belarus 24.80 2005 est.
34 Slovenia 24.80 2005 est.
35 Cape Verde 24.80 2005 est.
36 Gabon 24.70 2005 est.
37 Greece 24.60 2005 est.
38 Bangladesh 24.40 2005 est.
39 Moldova 24.40 2005 est.
40 Romania 24.30 2005 est.
41 Namibia 24.30 2005 est.
42 Dominican Republic 24.10 2005 est.
43 Georgia 24.00 2005 est.
44 Bulgaria 23.80 2005 est.
45 New Zealand 23.80 2005 est.
46 Morocco 23.70 2005 est.
47 Uganda 23.40 2005 est.
48 Cambodia 23.30 2005 est.
49 Ghana 23.30 2005 est.
50 Honduras 23.20 2005 est.
51 Japan 23.20 2005 est.
52 Hungary 23.10 2005 est.
53 Algeria 22.60 2005 est.
54 Malta 22.60 2005 est.
55 Albania 22.40 2005 est.
56 Ecuador 22.40 2005 est.
57 Tunisia 22.40 2005 est.
58 Chile 22.10 2005 est.
59 Indonesia 22.00 2005 est.
60 Ethiopia 21.90 2005 est.
61 Syria 21.90 2005 est.
62 Qatar 21.90 2005 est.
63 Lithuania 21.80 2005 est.
64 Singapore 21.80 2005 est.
65 Portugal 21.60 2005 est.
66 Togo 21.60 2005 est.
67 Argentina 21.50 2005 est.
68 Congo, Republic of the 21.50 2005 est.
69 Armenia 21.40 2005 est.
70 Nigeria 21.30 2005 est.
71 Switzerland 21.30 2005 est.
72 Mauritius 21.20 2005 est.
73 Ukraine 20.90 2005 est.
74 Austria 20.80 2005 est.
75 Hong Kong 20.80 2005 est.
76 Denmark 20.80 2005 est.
77 United Arab Emirates 20.70 2005 est.
78 Burkina Faso 20.70 2005 est.
79 Italy 20.60 2005 est.
80 Canada 20.50 2005 est.
81 Taiwan 20.40 2005 est.
82 Botswana 20.30 2005 est.
83 Luxembourg 20.30 2005 est.
84 Jordan 20.20 2005 est.
85 Senegal 20.10 2005 est.
86 Gambia, The 20.00 2005 est.
87 Malaysia 20.00 2005 est.
88 Belgium 19.90 2005 est.
89 Benin 19.90 2005 est.
90 Brazil 19.90 2005 est.
91 Costa Rica 19.60 2005 est.
92 France 19.60 2005 est.
93 Turkey 19.60 2005 est.
94 Trinidad and Tobago 19.60 2005 est.
95 European Union 19.60 2005 est.
96 Bahrain 19.50 2005 est.
97 Netherlands 19.50 2005 est.
98 Paraguay 19.40 2005 est.
99 Tajikistan 19.40 2005 est.
100 Mexico 19.30 2005 est.
101 Cyprus 19.20 2005 est.
102 Papua New Guinea 19.20 2005 est.
103 Finland 19.20 2005 est.
104 Venezuela 19.00 2005 est.
105 Peru 18.90 2005 est.
106 Norway 18.70 2005 est.
107 Colombia 18.60 2005 est.
108 Tanzania 18.60 2005 est.
109 Lebanon 18.40 2005 est.
110 Macedonia 18.30 2005 est.
111 Chad 18.20 2005 est.
112 Poland 18.20 2005 est.
113 Russia 18.10 2005 est.
114 Rwanda 18.10 2005 est.
115 Belize 17.80 2005 est.
116 Israel 17.50 2005 est.
117 Cameroon 17.30 2005 est.
118 Guinea 17.30 2005 est.
119 Egypt 17.20 2005 est.
120 Germany 17.10 2005 est.
121 Kenya 17.00 2005 est.
122 Sweden 17.00 2005 est.
123 South Africa 16.80 2005 est.
124 United States 16.70 2005 est.
125 United Kingdom 16.60 2005 est.
126 Panama 16.50 2005 est.
127 Saudi Arabia 16.30 2005 est.
128 Sudan 16.30 2005 est.
129 El Salvador 15.80 2005 est.
130 Guatemala 15.60 2005 est.
131 Philippines 15.50 2005 est.
132 Pakistan 15.30 2005 est.
133 Oman 14.80 2005 est.
134 Kuwait 14.30 2005 est.
135 Serbia 14.20 2005 est.
136 Yemen 14.20 2005 est.
137 Uruguay 12.90 2005 est.
138 Kyrgyzstan 12.60 2005 est.
139 Bolivia 12.50 2005 est.
140 Burundi 11.60 2005 est.
141 Burma 11.50 2005 est.
142 Cuba 11.50 2005 est.
143 Libya 11.40 2005 est.
144 Swaziland 10.60 2005 est.
145 Malawi 10.20 2005 est.
146 Cote d''Ivoire 8.60 2005 est.
147 Zimbabwe 7.90 2005 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2186
Rank Country Public debt(% of GDP) Date of Information
1 Malawi 195.90 2005 est.
2 Lebanon 180.50 2005 est.
3 Seychelles 167.00 2005 est.
4 Japan 158.00 2005 est.
5 Jamaica 128.70 2005 est.
6 Zimbabwe 109.80 2005 est.
7 Italy 108.80 2005 est.
8 Sudan 107.00 2005 est.
9 Greece 106.80 2005 est.
10 Ethiopia 106.20
11 Egypt 104.70 2005 est.
12 Singapore 102.90 2005 est.
13 Israel 99.70 2005 est.
14 Belgium 94.30 2005 est.
15 Sri Lanka 92.80 2005 est.
16 Nicaragua 82.30 2005 est.
17 Uruguay 81.90 2005 est.
18 Bhutan 81.40
19 Moldova 79.60 2005 est.
20 Jordan 79.10 2005 est.
21 Ghana 75.90 2005 est.
22 Argentina 72.50 2005 est.
23 Philippines 72.30 2005 est.
24 Morocco 72.00 2005 est.
25 Zambia 71.50 2005 est.
26 Cyprus 70.30 2005 est.
27 Canada 69.60 2005 est.
28 Honduras 68.40 2005 est.
29 Turkey 68.00 2005 est.
30 Mauritius 67.50 2005 est.
31 Germany 67.30 2005 est.
32 France 66.20 2005 est.
33 Cameroon 65.90 2005 est.
34 Tanzania 65.80 2005 est.
35 Austria 65.10 2005 est.
36 Panama 64.90 2005 est.
37 United States 64.70 2005 est.
38 Cote d''Ivoire 64.50 2005 est.
39 Uganda 64.30 2005 est.
40 Portugal 63.90 2005 est.
41 Tunisia 59.10 2005 est.
42 Hungary 58.90 2005 est.
43 Costa Rica 56.80 2005 est.
44 India 53.80 2005 est.
45 Pakistan 53.80 2005 est.
46 Serbia 53.10 2005 est.
47 Netherlands 52.70 2005 est.
48 Switzerland 52.00 2005 est.
49 Brazil 51.60 2005 est.
50 Sweden 50.40 2005 est.
51 Kenya 50.20 2005 est.
52 Norway 50.10 2005 est.
53 Indonesia 49.90 2005 est.
54 Croatia 49.70 2005 est.
55 Colombia 49.50 2005 est.
56 Vietnam 48.20 2005 est.
57 Poland 47.70 2005 est.
58 Thailand 47.60 2005 est.
59 El Salvador 46.70 2005 est.
60 Aruba 46.30
61 Malaysia 46.20 2005 est.
62 Senegal 46.00 2005 est.
63 Dominican Republic 45.50 2005 est.
64 Bangladesh 44.50 2005 est.
65 Saudi Arabia 44.20 2005 est.
66 United Kingdom 43.10 2005 est.
67 Trinidad and Tobago 43.00 2005 est.
68 Papua New Guinea 42.90 2005 est.
69 Spain 42.90 2005 est.
70 Slovakia 42.50 2005 est.
71 Ecuador 40.10 2005 est.
72 Syria 40.10 2005 est.
73 Finland 39.60 2005 est.
74 Angola 38.30 2005 est.
75 Peru 38.00 2005 est.
76 Denmark 37.00 2005 est.
77 Uzbekistan 36.10 2005 est.
78 Paraguay 36.00 2005 est.
79 South Africa 35.80 2005 est.
80 Qatar 35.60 2005 est.
81 Yemen 34.40 2005 est.
82 Venezuela 34.20 2005 est.
83 Macedonia 33.70 2005 est.
84 Gabon 33.60 2005 est.
85 Taiwan 33.60 2005 est.
86 Bahrain 33.50 2005 est.
87 Namibia 32.70 2005 est.
88 Bulgaria 31.90 2005 est.
89 Iceland 31.60 2005 est.
90 Algeria 30.20 2005 est.
91 Bosnia and Herzegovina 29.00
92 Iran 28.90 2005 est.
93 Slovenia 28.50 2005 est.
94 Ireland 26.70 2005 est.
95 Czech Republic 25.90 2005 est.
96 Guatemala 25.90 2005 est.
97 China 24.40 2005 est.
98 New Zealand 21.30 2005 est.
99 Mozambique 21.00
100 Romania 20.30 2005 est.
101 Korea, South 20.00 2005 est.
102 Lithuania 18.70 2005 est.
103 United Arab Emirates 17.50 2005 est.
104 Mexico 17.40 2005 est.
105 Ukraine 17.00 2005 est.
106 Australia 16.10 2005 est.
107 Russia 12.90 2005 est.
108 Kuwait 12.10 2005 est.
109 Azerbaijan 11.30 2005 est.
110 Nigeria 11.00 2005 est.
111 Latvia 10.90 2005 est.
112 Kazakhstan 10.50 2005 est.
113 Libya 8.20 2005 est.
114 Oman 8.10 2005 est.
115 Chile 7.50 2005 est.
116 Equatorial Guinea 6.40
117 Botswana 6.20 2005 est.
118 Wallis and Futuna 5.60
119 Estonia 4.80 2005 est.
120 Hong Kong 1.80 2005 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2187
Rank Country Current account balance Date of Information
1 Japan $ 165,600,000,000 2005 est.
2 China $ 160,800,000,000 2005 est.
3 Germany $ 115,500,000,000 2005 est.
4 Saudi Arabia $ 90,730,000,000 2005 est.
5 Russia $ 84,250,000,000 2005 est.
6 Switzerland $ 58,240,000,000 2005 est.
7 Norway $ 49,490,000,000 2005 est.
8 Netherlands $ 39,950,000,000 2005 est.
9 Singapore $ 32,740,000,000 2005 est.
10 Kuwait $ 26,920,000,000 2005 est.
11 Sweden $ 25,620,000,000 2005 est.
12 Venezuela $ 25,360,000,000 2005 est.
13 Canada $ 24,960,000,000 2005 est.
14 Hong Kong $ 19,700,000,000 2005 est.
15 Algeria $ 18,790,000,000 2005 est.
16 United Arab Emirates $ 18,540,000,000 2005 est.
17 Korea, South $ 16,560,000,000 2005 est.
18 Taiwan $ 16,220,000,000 2005 est.
19 Brazil $ 14,190,000,000 2005 est.
20 Malaysia $ 14,060,000,000 2005 est.
21 Iran $ 13,270,000,000 2005 est.
22 Libya $ 10,730,000,000 2005 est.
23 Qatar $ 9,270,000,000 2005 est.
24 Denmark $ 7,753,000,000 2005 est.
25 Belgium $ 6,305,000,000 2005 est.
26 Nigeria $ 5,597,000,000 2005 est.
27 Argentina $ 5,448,000,000 2005 est.
28 Finland $ 5,043,000,000 2005 est.
29 Oman $ 4,796,000,000 2005 est.
30 Angola $ 4,054,000,000 2005 est.
31 Luxembourg $ 3,560,000,000
32 Trinidad and Tobago $ 2,880,000,000 2005 est.
33 Ukraine $ 2,531,000,000 2005 est.
34 Israel $ 2,385,000,000 2005 est.
35 Philippines $ 2,354,000,000 2005 est.
36 Egypt $ 2,207,000,000 2005 est.
37 Indonesia $ 2,016,000,000 2005 est.
38 Botswana $ 1,584,000,000 2005 est.
39 Bahrain $ 1,531,000,000 2005 est.
40 Austria $ 1,467,000,000 2005 est.
41 Morocco $ 1,255,000,000 2005 est.
42 Yemen $ 1,224,000,000 2005 est.
43 Syria $ 1,097,000,000 2005 est.
44 Uzbekistan $ 1,082,000,000 2005 est.
45 Peru $ 1,030,000,000 2005 est.
46 Belarus $ 852,000,000 2005 est.
47 Chile $ 702,700,000 2005 est.
48 Burma $ 700,000,000 2005 est.
49 Gabon $ 675,000,000 2005 est.
50 Namibia $ 509,200,000 2005 est.
51 Congo, Republic of the $ 493,000,000 2005 est.
52 Papua New Guinea $ 482,100,000 2005 est.
53 Bolivia $ 462,000,000 2005 est.
54 Equatorial Guinea $ 264,000,000 2005 est.
55 Turkmenistan $ 236,000,000 2005 est.
56 Azerbaijan $ 167,300,000 2005 est.
57 British Virgin Islands $ 134,300,000
58 Cuba $ 49,000,000 2005 est.
59 Cameroon $ 39,000,000 2005 est.
60 Bangladesh $ 37,000,000 2005 est.
61 Cook Islands $ 26,670,000
62 Haiti $ 23,000,000 2005 est.
63 Palau $ 15,090,000
64 Swaziland $ 7,000,000 2005 est.
65 Tuvalu $ 2,323,000
66 Samoa $ -2,428,000
67 Tonga $ -4,321,000
68 Comoros $ -17,000,000 2005 est.
69 Kiribati $ -19,870,000
70 Sao Tome and Principe $ -20,000,000 2005 est.
71 Vanuatu $ -28,350,000
72 Burundi $ -29,000,000 2005 est.
73 Seychelles $ -32,000,000 2005 est.
74 Micronesia, Federated States of $ -34,300,000
75 Honduras $ -42,300,000 2005 est.
76 Anguilla $ -42,870,000
77 Tajikistan $ -44,000,000 2005 est.
78 Gambia, The $ -53,000,000 2005 est.
79 Macedonia $ -81,100,000 2005 est.
80 Cape Verde $ -82,000,000 2005 est.
81 Antigua and Barbuda $ -83,400,000
82 Uruguay $ -87,900,000 2005 est.
83 Lesotho $ -92,000,000 2005 est.
84 Guyana $ -112,000,000 2005 est.
85 Armenia $ -118,000,000 2005 est.
86 Kyrgyzstan $ -134,000,000 2005 est.
87 Laos $ -134,000,000 2005 est.
88 Dominican Republic $ -143,000,000 2005 est.
89 Cambodia $ -166,000,000 2005 est.
90 Rwanda $ -166,000,000 2005 est.
91 Belize $ -180,000,000 2005 est.
92 Cote d''Ivoire $ -193,000,000 2005 est.
93 Togo $ -199,000,000 2005 est.
94 Malawi $ -218,000,000 2005 est.
95 Paraguay $ -255,000,000 2005 est.
96 Guinea $ -268,400,000 2005 est.
97 Moldova $ -285,000,000 2005 est.
98 Eritrea $ -291,000,000 2005 est.
99 Slovenia $ -303,000,000 2005 est.
100 Vietnam $ -309,000,000 2005 est.
101 Mauritius $ -342,000,000 2005 est.
102 Uganda $ -355,000,000 2005 est.
103 Tunisia $ -359,200,000 2005 est.
104 Benin $ -400,000,000 2005 est.
105 Albania $ -416,000,000 2005 est.
106 Zambia $ -420,000,000 2005 est.
107 Madagascar $ -438,000,000 2005 est.
108 Burkina Faso $ -460,000,000 2005 est.
109 Fiji $ -465,800,000
110 Kazakhstan $ -485,700,000 2005 est.
111 Zimbabwe $ -519,000,000 2005 est.
112 Tanzania $ -558,000,000 2005 est.
113 Ecuador $ -566,000,000 2005 est.
114 Malta $ -598,000,000 2005 est.
115 Chad $ -602,000,000 2005 est.
116 Georgia $ -625,000,000 2005 est.
117 Mozambique $ -639,000,000 2005 est.
118 Panama $ -705,700,000 2005 est.
119 Sri Lanka $ -776,000,000 2005 est.
120 El Salvador $ -778,000,000 2005 est.
121 Ghana $ -790,000,000 2005 est.
122 Nicaragua $ -835,000,000 2005 est.
123 Ethiopia $ -844,000,000 2005 est.
124 Senegal $ -848,000,000 2005 est.
125 Costa Rica $ -955,000,000 2005 est.
126 Cyprus $ -962,300,000 2005 est.
127 Jamaica $ -974,000,000 2005 est.
128 Pakistan $ -1,109,000,000 2005 est.
129 Guatemala $ -1,341,000,000 2005 est.
130 Estonia $ -1,375,000,000 2005 est.
131 Kenya $ -1,543,000,000 2005 est.
132 Jordan $ -1,613,000,000 2005 est.
133 Lithuania $ -1,771,000,000 2005
134 Colombia $ -1,931,000,000 2005 est.
135 Latvia $ -1,959,000,000 2005 est.
136 Bosnia and Herzegovina $ -2,087,000,000 2005 est.
137 Serbia $ -2,451,000,000 2005 est.
138 Czech Republic $ -2,496,000,000 2005 est.
139 Croatia $ -2,541,000,000 2005 est.
140 Iceland $ -2,607,000,000 2005 est.
141 Sudan $ -3,013,000,000 2005 est.
142 Thailand $ -3,689,000,000 2005 est.
143 Ireland $ -3,833,000,000 2005 est.
144 Bulgaria $ -3,919,000,000 2005
145 Slovakia $ -4,066,000,000 2005 est.
146 Lebanon $ -4,239,000,000 2005 est.
147 Poland $ -4,364,000,000 2005 est.
148 Mexico $ -5,708,000,000 2005 est.
149 Hungary $ -7,963,000,000 2005 est.
150 Romania $ -8,200,000,000 2005
151 Iraq $ -9,447,000,000 2004 est.
152 New Zealand $ -9,688,000,000 2005 est.
153 South Africa $ -11,080,000,000 2005 est.
154 India $ -12,950,000,000 2005 est.
155 Portugal $ -17,100,000,000 2005 est.
156 Greece $ -17,860,000,000 2005 est.
157 Turkey $ -23,080,000,000 2005 est.
158 Italy $ -26,380,000,000 2005 est.
159 France $ -38,780,000,000 2005 est.
160 Australia $ -42,090,000,000 2005 est.
161 United Kingdom $ -57,610,000,000 2005 est.
162 Spain $ -83,140,000,000 2005 est.
163 United States $ -829,100,000,000 2005 est.
This file was last updated on 19 December, 2006
======================================================================
Rank code: @2188
Rank Country Reserves of foreign exchange and gold Date of Information
1 Japan $ 835,500,000,000 2005 est.
2 China $ 825,600,000,000 2005 est.
3 Taiwan $ 258,000,000,000 2005 est.
4 Korea, South $ 210,400,000,000 2005 est.
5 Russia $ 182,200,000,000 2005 est.
6 India $ 136,000,000,000 2005 est.
7 Hong Kong $ 124,300,000,000 2005 est.
8 Singapore $ 115,800,000,000 2005 est.
9 Germany $ 101,700,000,000 2005 est.
10 United States $ 86,940,000,000 2004 est.
11 France $ 74,360,000,000 2005 est.
12 Mexico $ 74,100,000,000 2005 est.
13 Malaysia $ 70,230,000,000 2005 est.
14 Italy $ 65,950,000,000 2005 est.
15 Switzerland $ 57,640,000,000 2005 est.
16 Algeria $ 56,580,000,000 2005 est.
17 Brazil $ 53,800,000,000 2005 est.
18 Turkey $ 52,490,000,000 2005 est.
19 Thailand $ 52,070,000,000 2005 est.
20 United Kingdom $ 48,660,000,000 2005 est.
21 Norway $ 46,990,000,000 2005 est.
22 Iran $ 45,460,000,000 2005 est.
23 Australia $ 43,260,000,000 2005 est.
24 Poland $ 42,560,000,000 2005 est.
25 Libya $ 39,700,000,000 2005 est.
26 Indonesia $ 34,580,000,000 2005 est.
27 Denmark $ 34,030,000,000 2005 est.
28 Canada $ 33,020,000,000 2005 est.
29 Venezuela $ 29,640,000,000 2005 est.
30 Czech Republic $ 29,360,000,000 2005 est.
31 Nigeria $ 28,280,000,000 2005 est.
32 Argentina $ 28,090,000,000 2005 est.
33 Israel $ 28,060,000,000 2005 est.
34 Saudi Arabia $ 26,760,000,000 2005 est.
35 United Arab Emirates $ 23,530,000,000 2005 est.
36 Sweden $ 22,330,000,000 2005 est.
37 Romania $ 21,600,000,000 2005 est.
38 Egypt $ 21,390,000,000 2005 est.
39 South Africa $ 20,630,000,000 2005 est.
40 Netherlands $ 20,540,000,000 2005 est.
41 Ukraine $ 19,390,000,000 2005 est.
42 Hungary $ 18,590,000,000 2005 est.
43 Philippines $ 18,500,000,000 2005 est.
44 Spain $ 17,230,000,000 2005 est.
45 Chile $ 16,930,000,000 2005 est.
46 Lebanon $ 16,620,000,000 2005 est.
47 Morocco $ 16,470,000,000 2005 est.
48 Slovakia $ 14,970,000,000 2005 est.
49 Colombia $ 14,960,000,000 2005 est.
50 Peru $ 14,180,000,000 2005 est.
51 Belgium $ 12,000,000,000 2005 est.
52 Austria $ 11,830,000,000 2005 est.
53 Finland $ 11,400,000,000 2005 est.
54 Pakistan $ 10,950,000,000 2005 est.
55 Portugal $ 10,360,000,000 2005 est.
56 Iraq $ 9,161,000,000 2005 est.
57 Kuwait $ 8,972,000,000 2005 est.
58 New Zealand $ 8,893,000,000 2005 est.
59 Vietnam $ 8,863,000,000 2005 est.
60 Croatia $ 8,800,000,000 2005 est.
61 Bulgaria $ 8,695,000,000 2005
62 Slovenia $ 8,160,000,000 2005 est.
63 Kazakhstan $ 7,070,000,000 2005 est.
64 Botswana $ 6,309,000,000 2005 est.
65 Yemen $ 6,143,000,000 2005 est.
66 Jordan $ 5,463,000,000 2005 est.
67 Syria $ 5,363,000,000 2005 est.
68 Serbia $ 5,350,000,000
69 Trinidad and Tobago $ 4,888,000,000 2005 est.
70 Qatar $ 4,552,000,000 2005 est.
71 Cyprus $ 4,429,000,000 2005 est.
72 Tunisia $ 4,375,000,000 2005 est.
73 Oman $ 4,358,000,000 2005 est.
74 Lithuania $ 3,815,000,000 2005
75 Guatemala $ 3,673,000,000 2005 est.
76 Angola $ 3,197,000,000 2005 est.
77 Uruguay $ 3,079,000,000 2005 est.
78 Turkmenistan $ 2,963,000,000 2005 est.
79 Bangladesh $ 2,825,000,000 2005 est.
80 Sri Lanka $ 2,737,000,000 2005 est.
81 Uzbekistan $ 2,681,000,000 2005 est.
82 Cuba $ 2,618,000,000 2005 est.
83 Malta $ 2,579,000,000 2005 est.
84 Bosnia and Herzegovina $ 2,531,000,000 2005 est.
85 Sudan $ 2,450,000,000 2005 est.
86 Bahrain $ 2,432,000,000 2005 est.
87 Latvia $ 2,361,000,000 2005 est.
88 Honduras $ 2,339,000,000 2005 est.
89 Costa Rica $ 2,313,000,000 2005 est.
90 Greece $ 2,287,000,000 2005 est.
91 Jamaica $ 2,170,000,000 2005 est.
92 Ecuador $ 2,148,000,000 2005 est.
93 Equatorial Guinea $ 2,103,000,000 2005 est.
94 Tanzania $ 2,074,000,000 2005 est.
95 Estonia $ 1,948,000,000 2005 est.
96 Ghana $ 1,897,000,000 2005 est.
97 Dominican Republic $ 1,853,000,000 2005 est.
98 El Salvador $ 1,833,000,000 2005 est.
99 Kenya $ 1,799,000,000 2005 est.
100 Bolivia $ 1,798,000,000 2005 est.
101 Albania $ 1,461,000,000 2005 est.
102 Cote d''Ivoire $ 1,420,000,000 2005 est.
103 Mauritius $ 1,366,000,000 2005 est.
104 Macedonia $ 1,341,000,000 2005 est.
105 Paraguay $ 1,297,000,000 2005 est.
106 Uganda $ 1,286,000,000 2005 est.
107 Ethiopia $ 1,226,000,000 2005 est.
108 Belarus $ 1,215,000,000 2005 est.
109 Panama $ 1,211,000,000 2005 est.
110 Azerbaijan $ 1,192,000,000 2005 est.
111 Senegal $ 1,191,000,000 2005 est.
112 Cambodia $ 1,145,000,000 2005 est.
113 Iceland $ 1,069,000,000 2005 est.
114 Mozambique $ 1,051,000,000 2005 est.
115 Cameroon $ 964,800,000 2005 est.
116 Ireland $ 869,300,000 2005 est.
117 Burkina Faso $ 764,000,000 2005 est.
118 Burma $ 763,000,000 2005 est.
119 Armenia $ 754,900,000 2005 est.
120 Papua New Guinea $ 748,800,000 2005 est.
121 Nicaragua $ 727,800,000 2005 est.
122 Benin $ 676,000,000 2005 est.
123 Gabon $ 675,200,000 2005 est.
124 Kyrgyzstan $ 612,300,000 2005 est.
125 Moldova $ 597,500,000 2005 est.
126 Lesotho $ 573,000,000 2005 est.
127 Madagascar $ 572,000,000 2005 est.
128 Zambia $ 559,800,000 2005 est.
129 Georgia $ 474,200,000 2005 est.
130 Rwanda $ 357,000,000 2005 est.
131 Togo $ 318,000,000 2005 est.
132 Namibia $ 312,100,000 2005 est.
133 Swaziland $ 311,000,000 2005 est.
134 Chad $ 297,000,000 2005 est.
135 Luxembourg $ 279,100,000 2005 est.
136 Congo, Republic of the $ 273,000,000 2005 est.
137 Guyana $ 261,000,000 2005 est.
138 Laos $ 249,000,000 2005 est.
139 Tajikistan $ 186,800,000 2005 est.
140 Zimbabwe $ 160,000,000 2005 est.
141 Malawi $ 151,000,000 2005 est.
142 Cape Verde $ 150,000,000 2005 est.
143 Burundi $ 105,000,000 2005 est.
144 Haiti $ 100,000,000 2005 est.
145 Belize $ 87,000,000 2005 est.
146 Gambia, The $ 82,000,000 2005 est.
147 Samoa $ 70,150,000
148 Guinea $ 69,830,000 2005 est.
149 Seychelles $ 41,000,000 2005 est.
150 Tonga $ 40,830,000
151 Vanuatu $ 40,540,000
152 Eritrea $ 30,000,000 2005 est.
153 Sao Tome and Principe $ 20,000,000 2005 est.
This file was last updated on 19 December, 2006
======================================================================
Appendix A - Abbreviations
ABEDA: Arab Bank for Economic Development in Africa
ACCT: Agency for the French-Speaking Community (see International
Organization of the French-speaking World)
ACP Group: African, Caribbean, and Pacific Group of States
AfDB: African Development Bank
AFESD: Arab Fund for Economic and Social Development
Air Pollution: Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides: Proto','3acf380cc72af4c192e144eddba2050334790a1dbf44b7a87ae2e07c5df6bda9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ace5d799b67b3cd638c357213f6ed44fa92ac00aaf306adce1569ee00cd4728',2006,'ZW','Zimbabwe','communications',18,'col to the 1979 Convention on
Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants: Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution on Persistent
Organic Pollutants
Air Pollution-Sulphur 85: Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on the Reduction of Sulphur Emissions
or Their Transboundary Fluxes by at Least 30%
Air Pollution-Sulphur 94: Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on Further Reduction of Sulphur
Emissions
Air Pollution-Volatile Organic Compounds: Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution Concerning the
Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AMF: Arab Monetary Fund
AMU: Arab Maghreb Union
Antarctic-Environmental Protocol: Protocol on Environmental Protection
to the Antarctic Treaty
Antarctic Marine Living Resources: Convention on the Conservation of
Antarctic Marine Living Resources
Antarctic Seals: Convention for the Conservation of Antarctic Seals
ANZUS: Australia-New Zealand-United States Security Treaty
APEC: Asia-Pacific Economic Cooperation
Arabsat: Arab Satellite Communications Organization
ARF: ASEAN Regional Forum
AsDB: Asian Development Bank
ASEAN: Association of Southeast Asian Nations
AU: African Union
Autodin: Automatic Digital Network
BA: Baltic Assembly
bbl/day: barrels per day
BCIE: Central American Bank for Economic Integration
BDEAC: Central African States Development Bank
Benelux: Benelux Economic Union
BIMSTEC: Bay of Bengal Iniative for Multisectoral Technical and
Economic Cooperation
Biodiversity: Convention on Biological Diversity
BGN: United States Board on Geographic Names
BIS: Bank for International Settlements
BSEC: Black Sea Economic Cooperation Zone
C: Commonwealth
c.i.f.: cost, insurance, and freight
CACM: Central American Common Market
CAEU: Council of Arab Economic Unity
CAN: Andean Community of Nations
Caricom: Caribbean Community and Common Market
CB: citizen''s band mobile radio communications
CBSS: Council of the Baltic Sea States
CCC: Customs Cooperation Council
CDB: Caribbean Development Bank
CE: Council of Europe
CEI: Central European Initiative
CEMAC: Monetary and Economic Community of Central Africa
CEPGL: Economic Community of the Great Lakes Countries
CERN: European Organization for Nuclear Research
CEPT: Conference Europeanne des Poste et Telecommunications
CIS: Commonwealth of Independent States
CITES: see Endangered Species
Climate Change: United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol: Kyoto Protocol to the United Nations
Framework Convention on Climate Change
COCOM: Coordinating Committee on Export Controls
Comsat: Communications Satellite Corporation
COMESA: Common Market for Eastern and Southern Africa
CP: Colombo Plan
CY: calendar year
DC: developed country
Desertification: United Nations Convention to Combat Desertification
in Those Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
DDT: dichloro-diphenyl-trichloro-ethane
DIA: United States Defense Intelligence Agency
DSN: Defense Switched Network
DWT: deadweight ton
EADB: East African Development Bank
EAPC: Euro-Atlantic Partnership Council
EBRD: European Bank for Reconstruction and Development
EC: European Community
ECA: Economic Commission for Africa
ECE: Economic Commission for Europe
ECLAC: Economic Commission for Latin America and the Caribbean
ECO: Economic Cooperation Organization
ECOSOC: Economic and Social Council
ECOWAS: Economic Community of West African States
ECSC: European Coal and Steel Community
EEC: European Economic Community
EFTA: European Free Trade Association
EEZ: exclusive economic zone
EIB: European Investment Bank
EMU: European Monetary Union
Endangered Species: Convention on the International Trade in
Endangered Species of Wild Flora and Fauna (CITES)
Entente: Council of the Entente
Environmental Modification: Convention on the Prohibition of Military
or Any Other Hostile Use of Environmental Modification Techniques
ESA: European Space Agency
ESCAP: Economic and Social Commission for Asia and the Pacific
ESCWA: Economic and Social Commission for Western Asia
est.: estimate
EU: European Union
Euratom: European Atomic Energy Community
Eutelsat: European Telecommunications Satellite Organization
Ex-Im: Export-Import Bank of the United States
f.o.b.: free on board
FAO: Food and Agriculture Organization
FAX: facsimile
FLS: Front Line States
FOC: flags of convenience
FSU: former Soviet Union
FY: fiscal year
FZ: Franc Zone
G-2: Group of 2
G-3: Group of 3
G-5: Group of 5
G-6: Group of 6
G-7: Group of 7
G-8: Group of 8
G-9: Group of 9
G-10: Group of 10
G-15: Group of 15
G-11: Group of 11
G-24: Group of 24
G-77: Group of 77
GATT: General Agreement on Tariffs and Trade; now WTO
GCC: Gulf Cooperation Council
GDP: gross domestic product
GMT: Greenwich Mean Time
GNP: gross national product
GRT: gross register ton
GSM: global system for mobile cellular communications
GUAM: acronym for member states - Georgia, Ukraine, Azerbaijan,
Moldova
GWP: gross world product
Hazardous Wastes: Basel Convention on the Control of Transboundary
Movements of Hazardous Wastes and Their Disposal
HF: high-frequency
HIV/AIDS: human immunodeficiency virus/acquired immune deficiency
syndrome
IADB: Inter-American Development Bank
IAEA: International Atomic Energy Agency
IANA: Internet Assigned Numbers Authority
IBRD: International Bank for Reconstruction and Development (World
Bank)
ICAO: International Civil Aviation Organization
ICC: International Chamber of Commerce
ICCt: International Criminal Court
ICFTU: International Confederation of Free Trade Unions
ICJ: International Court of Justice (World Court)
ICRC: International Committee of the Red Cross
ICRM: International Red Cross and Red Crescent Movement
ICSID: International Center for Secretariat of Investment Disputes
ICTR: International Criminal Tribunal for Rwanda
ICTY: International Criminal Tribunal for the former Yugoslavia
IDA: International Development Association
IDB: Islamic Development Bank
IDP: internally displaced person
IEA: International Energy Agency
IFAD: International Fund for Agricultural Development
IFC: International Finance Corporation
IFRCS: International Federation of Red Cross and Red Crescent
Societies
IGAD: Inter-Governmental Authority on Development
IHO: International Hydrographic Organization
ILO: International Labor Organization
IMF: International Monetary Fund
IMO: International Maritime Organization
Inmarsat: International Maritime Satellite Organization
InOC: Indian Ocean Commission
INSTRAW: International Research and Training Institute for the
Advancement of Women
Intelsat: International Telecommunications Satellite Organization
Interpol: International Criminal Police Organization
Intersputnik: International Organization of Space Communications
IOC: International Olympic Committee
IOM: International Organization for Migration
IPU: Inter-parliamentary Union
ISO: International Organization for Standardization
ISP: Internet Service Provider
ITU: International Telecommunication Union
kHz: kilohertz
km: kilometer
kW: kilowatt
kWh: kilowatt-hour
LAES: Latin American Economic System
LAIA: Latin American Integration Association
LAS: League of Arab States
Law of the Sea: United Nations Convention on the Law of the Sea (LOS)
LDC: less developed country
LLDC: least developed country
London Convention: see Marine Dumping
LOS: see Law of the Sea
m: meter
Marecs: Maritime European Communications Satellite
Marine Dumping: Convention on the Prevention of Marine Pollution by
Dumping Wastes and Other Matter
Marine Life Conservation: Convention on Fishing and Conservation of
Living Resources of the High Seas
MARPOL: see Ship Pollution
Medarabtel: Middle East Telecommunications Project of the
International Telecommunications Union
Mercosur: Southern Cone Common Market
MHz: megahertz
MICAH: International Civilian Support Mission in Haiti
MINURSO: United Nations Mission for the Referendum in Western Sahara
MIGA: Multilateral Investment Geographic Agency
MINUSTAH: United Nations Stabilization Mission in Haiti
MONUC: United Nations Organization Mission in the Democratic Republic
of the Congo
NA: not available
NAFTA: North American Free Trade Agreement
NAM: Nonaligned Movement
NATO: North Atlantic Treaty Organization
NC: Nordic Council
NEA: Nuclear Energy Agency
NEGL: negligible
NGA: National Geospatial-Intelligence Agency
NIB: Nordic Investment Bank
NIC: newly industrializing country
NIE: newly industrializing economy
NIS: new independent states
nm: nautical mile
NMT: Nordic Mobile Telephone
NSG: Nuclear Suppliers Group
Nuclear Test Ban: Treaty Banning Nuclear Weapons Tests in the
Atmosphere, in Outer Space, and Under Water
NZ: New Zealand
OAPEC: Organization of Arab Petroleum Exporting Countries
OAS: Organization of American States
OAU: Organization of African Unity; see African Union
ODA: official development assistance
OECD: Organization for Economic Cooperation and Development
OECS: Organization of Eastern Caribbean States
OHCHR: Office of the United Nations High Commissioner for Human Rights
OIC: Organization of the Islamic Conference
OIF: International Organization of the French-speaking World
ONUB: United Nations Operation in Burundi
OOF: other official flows
OPANAL: Agency for the Prohibition of Nuclear Weapons in Latin America
and the Caribbean
OPCW: Organization for the Prohibition of Chemical Weapons
OPEC: Organization of Petroleum Exporting Countries
OSCE: Organization for Security and Cooperation in Europe
Ozone Layer Protection: Montreal Protocol on Substances That Deplete
the Ozone Layer
PCA: Permanent Court of Arbitration
PFP: Partnership for Peace
PIF: Pacific Islands Forum
PPP: purchasing power parity
Ramsar: see Wetlands
RG: Rio Group
SAARC: South Asian Association for Regional Cooperation
SACU: Southern African Customs Union
SACEP: South Asia Co-opeative Environment Programme
SADC: Southern African Development Community
SCO: Shanghai Cooperative Organization
SAFE: South African Far East Cable
SECI: Southeast European Cooperative Initiative
SHF: super-high-frequency
Ship Pollution: Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
Sparteca: South Pacific Regional Trade and Economic Cooperation
Agreement
SPC: Secretariat of the Pacific Communities
SPF: South Pacific Forum
sq km: square kilometer
sq mi: square mile
TAT: Trans-Atlantic Telephone
Tropical Timber 83: International Tropical Timber Agreement, 1983
Tropical Timber 94: International Tropical Timber Agreement, 1994
UAE: United Arab Emirates
UDEAC: Central African Customs and Economic Union
UHF: ultra-high-frequency
UK: United Kingdom
UN: United Nations
UNAMSIL: United Nations Mission in Sierra Leone
UNCLOS: United Nations Convention on the Law of the Sea, also know as
LOS
UNCTAD: United Nations Conference on Trade and Development
UNDCP: United Nations Drug Control Program
UNDOF: United Nations Disengagement Observer Force
UNDP: United Nations Development Program
UNEP: United Nations Environment Program
UNESCO: United Nations Educational, Scientific, and Cultural
Organization
UNFICYP: United Nations Peace-keeping Force in Cyprus
UNFPA: United Nations Population Fund
UNHCR: United Nations High Commissioner for Refugees
UNICEF: United Nations Children''s Fund
UNICRI: United Nations Interregional Crime and Justice Research
Institute
UNIDIR: United Nations Institute for Disarmament Research
UNIDO: United Nations Industrial Development Organization
UNIFIL: United Nations Interim Force in Lebanon
UNITAR: United Nations Institute for Training and Research
UNMEE: United Nations Mission in Ethiopia and Eritrea
UNMIK: United Nations Interim Administration Mission in Kosovo
UNMIL: United Nations Mission in Liberia
UNMOGIP: United Nations Military Observer Group in India and Pakistan
UNMOVIC: United Nations Monitoring, Verification, and Inspection
Commission
UNOCI: United Nations Operation in Cote d''Ivoire
UNOMIG: United Nations Observer Mission in Georgia
UNOPS: United Nations Office of Project Services
UNRISD: United Nations Research Institute for Social Development
UNRWA: United Nations Relief and Works Agency for Palestine Refugees
in the Near East
UNSC: United Nations Security Council
UNSSC: Untied Nations System Staff College
UNTSO: United Nations Truce Supervision Organization
UNU: United Nations University
UPU: Universal Postal Union
US: United States
USSR: Union of Soviet Socialist Republics (Soviet Union); used for
information dated before 25 December 1991
UTC: Coordinated Universal Time
UV: ultra violet
VHF: very-high-frequency
VSAT: very small aperture terminal
WADB: West African Development Bank
WAEMU: West African Economic and Monetary Union
WCL: World Confederation of Labor
WCO: World Customs Organization
Wetlands: Convention on Wetlands of International Importance
Especially As Waterfowl Habitat
WEU: Western European Union
WFP: World Food Program
WFTU: World Federation of Trade Unions
Whaling: International Convention for the Regulation of Whaling
WHO: World Health Organization
WIPO: World Intellectual Property Organization
WMO: World Meteorological Organization
WP: Warsaw Pact
WTO: World Trade Organization note - see WToO for World Tourism
Organization
WToO: World Tourism Organization
ZC: Zangger Committee
This page was last updated on 19 December, 2006
=====================================================================
Appendix B - International Organizations and Groups
advanced developing countries: another term for those less developed
countries (LDCs) with particularly rapid industrial development; see
newly industrializing economies (NIEs)
advanced economies: a term used by the International Monetary FUND
(IMF) for the top group in its hierarchy of advanced economies,
countries in transition, and developing countries; it includes the
following 28 advanced economies: Australia, Austria, Belgium, Canada,
Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland, Ireland,
Israel, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway,
Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; note -
this group would presumably also cover the following seven smaller
countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein,
Monaco, and San Marino that are included in the more comprehensive
group of "developed countries"
African Development Bank (AfDB): note - its predecessor was
Organization of African Unity (OAU)
established - 9 September 1999
aim - to promote economic and social development
regional members - (53) Algeria, Angola, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The
Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya,
Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique,
Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland,
Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members - (24) Argentina, Austria, Belgium, Brazil, Canada,
China, Denmark, Finland, France, Germany, India, Italy, Japan, South
Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain,
Sweden, Switzerland, UK, US
African Union (AU): note - replaces Organization of African Unity
(OAU)
established - 8 July 2001
aim - to achieve greater unity among African States; to defend states''
integrity and independence; to accelerate political, social, and
economic integration; to encourage international cooperation; to
promote democratic principles and institutions
members - (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The
Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya,
Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia,
Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic (Western
Sahara), Sao Tome and Principe, Senegal, Seychelles, Sierra Leone,
Somalia, South Africa, Sudan, Swaziland, Tanzania, Togo, Tunisia,
Uganda, Zambia, Zimbabwe
African, Caribbean, and Pacific Group of States (ACP Group):
established - 6 June 1975
aim - to manage their preferential economic and aid relationship with
the EU
members - (79) Angola, Antigua and Barbuda, The Bahamas, Barbados,
Belize, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cook Islands, Cote d''Ivoire, Cuba,
Djibouti, Dominica, Dominican Republic, East Timor, Equatorial Guinea,
Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea,
Guinea-Bissau, Guyana, Haiti, Jamaica, Kenya, Kiribati, Lesotho,
Liberia, Madagascar, Malawi, Mali, Marshall Islands, Mauritania,
Mauritius, Federated States of Micronesia, Mozambique, Namibia, Nauru,
Niger, Nigeria, Niue, Palau, Papua New Guinea, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands,
Somalia, South Africa, Sudan, Suriname, Swaziland, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
Agency for the Prohibition of Nuclear Weapons in Latin America and the
Caribbean (OPANAL): note - acronym from Organismo para la Proscripcion
de las Armas Nucleares en la America Latina y el Caribe (OPANAL)
established - 14 February 1967 under the Treaty of Tlatelolco;
effective - 25 April 1969 on the 11th ratification
aim - to encourage the peaceful uses of atomic energy and prohibit
nuclear weapons
members - (33) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominica,
Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana,
Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, Uruguay, Venezuela
Andean Community of Nations (CAN): note - formerly known as the Andean
Group (AG), the Andean Parliament, and most recently as the Andean
Common Market (Ancom)
established - 26 May 1969; present name established 1 October 1992;
effective - 16 October 1969
aim - to promote harmonious development through economic integration
members - (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
associate members - (5) Chile, Argentina, Brazil, Paraguay, Uruguay
observers - (2) Mexico, Panama
Arab Bank for Economic Development in Africa (ABEDA): note - also
known as Banque Arabe de Developpement Economique en Afrique (BADEA)
established - 18 February 1974; effective - 16 September 1974
aim - to promote economic development
members - (17 plus the Palestine Liberation Organization) Algeria,
Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE,
Palestine Liberation Organization; note - these are all the members of
the Arab League excluding Comoros, Djibouti, Somalia, Yemen
Arab Fund for Economic and Social Development (AFESD): established -
16 May 1968
aim - to promote economic and social development
members - (20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq (suspended 1993), Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia
(suspended 1993), Sudan, Syria, Tunisia, UAE, Yemen, Palestine
Liberation Organization
Arab Maghreb Union (AMU): established - 17 February 1989
aim - to promote cooperation and integration among the Arab states of
northern Africa
members - (5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF): established - 27 April 1976; effective - 2
February 1977
aim - to promote Arab cooperation, development, and integration in
monetary and economic affairs
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Arctic Council: established - 18 September 1996
aim - to address the common concerns and challenges faced by Arctic
governments and the people of the Arctic; to protect the Arctic','a34efe58c132c0ee1395cd1a61e3d90ab0ac507e0b6ba67022f8fa0dcc95224e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10648ba4222dfa6f2677af085c39c4f18a34a4a7c8f0fa55ddbb54487dbd3c3',2006,'GY','Guyana','communications',225,'domestic: radiotelephone communications between islands
international: country code - 688; international calls can be made
by satellite
Radio broadcast stations:
AM 1, FM 1, shortwave 0 (2004)
Radios:
4,000 (1997)
Television broadcast stations:
0 (2004)
Televisions:
800
Internet country code:
.tv
Internet Service Providers (ISPs):
1 (2000)
Internet users:
1,300 (2002)
Transportation Tuvalu
Airports:
1 (2006)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2006)
Roadways:
total: 8 km
paved: 8 km (2002)
Merchant marine:
total: 52 ships (1000 GRT or over) 196,790 GRT/256,436 DWT
by type: bulk carrier 3, cargo 37, chemical tanker 1, container 2,
passenger 3, passenger/cargo 1, petroleum tanker 4, specialized
tanker 1
foreign-owned: 43 (China 23, Hong Kong 8, Kenya 1, Russia 2,
Singapore 6, Thailand 1, Turkey 2) (2006)
Ports and terminals:
Funafuti
Military Tuvalu
Military branches:
no regular military forces; Police Force
Military expenditures - dollar figure:
NA
Military expenditures - percent of GDP:
NA
Transnational Issues Tuvalu
Disputes - international:
none
This page was last updated on 19 December, 2006
======================================================================
@Uganda
Introduction Uganda
mostly rolling highlands; low coastal plain; savanna in south
2.04 children born/woman (2006 est.)
republic
9.1% (understated) (2000)
conventional long form: Cooperative Republic of Guyana
conventional short form: Guyana
former: British Guiana
Northern South America, bordering the North Atlantic Ocean,
between Suriname and Venezuela
South America
1,500 sq km (2003)
total: 214,970 sq km
land: 196,850 sq km
water: 18,120 sq km
chief of mission: Ambassador Bayney KARRAN
chancery: 2490 Tracy Place NW, Washington, DC 20008
telephone: [1] (202) 265-6900
FAX: [1] (202) 232-1297
consulate(s) general: New York
110,100 (2005)
281,400 (2005)
160,000 (2005)
.gy
2.5% (2003 est.)
11,000 (2003 est.)
1,100 (2003 est.)
0 bbl/day (2003 est.)
11,300 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 27.4 years
male: 26.9 years
female: 27.9 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,046 (2006)
34.4% of GDP (2005 est.)
$-112 million (2005 est.)
$261 million (2005 est.)
$782 million (2005 est.)','a8aa28b2028b686b3ce4f5fb0ea774c6206ce58c7052ee5c22c6a805d13eb8ec','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e893dac5f07ce0f33bc832611771da8fc65dc755b6672d2452046d03c03176cf',2006,'TV','Tuvalu','communications',791,'domestic: radiotelephone communications between islands
international: country code - 688; international calls can be made
by satellite
very low-lying and narrow coral atolls
2.98 children born/woman (2006 est.)
constitutional monarchy with a parliamentary democracy
NA%
conventional long form: none
conventional short form: Tuvalu
local long form: none
local short form: Tuvalu
former: Ellice Islands
note: "Tuvalu" means "group of eight," referring to the country''s
eight traditionally inhabited islands
Oceania, island group consisting of nine coral atolls in the
South Pacific Ocean, about one-half of the way from Hawaii to
Oceania
NA
total: 26 sq km
land: 26 sq km
water: 0 sq km
Tuvalu does not have an embassy in the US - the country''s
only diplomatic post is in Fiji - Tuvalu does, however, have a UN
office located at 800 2nd Avenue, Suite 400D, New York, NY 10017,
telephone: [1] (212) 490-0534
700 (2002)
0 (2004)
1,300 (2002)
.tv
NA
NA
NA
total: 24.6 years
male: 23.6 years
female: 26 years (2006 est.)
$2.323 million
$14.94 million','7f84b38c07969ee88b81b873d15461fe04896089d7589970d7e3b3f8b20ca54b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b702f1327823a984a241117192ebad2fa6fb685386858ff88523e07d4c38ef1e',2006,'UG','Uganda','communications',792,'general assessment: seriously inadequate; two cellular
systems have been introduced, but a sharp increase in the number of
main lines is essential; e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio relay, and
radiotelephone communication stations, fixed and mobile cellular
systems for short-range traffic
international: country code - 256; satellite earth stations - 1
Intelsat (Atlantic Ocean) and 1 Inmarsat; analog links to Kenya and
Tanzania
mostly plateau with rim of mountains
6.71 children born/woman (2006 est.)
republic
NA%
conventional long form: Republic of Uganda
conventional short form: Uganda
Eastern Africa, west of Kenya
Africa
90 sq km (2003)
total: 236,040 sq km
land: 199,710 sq km
water: 36,330 sq km
chief of mission: Ambassador Edith G. SSEMPALA
chancery: 5911 16th Street NW, Washington, DC 20011
telephone: [1] (202) 726-7100 through 7102, 0416
FAX: [1] (202) 726-1727
100,800 (2005)
1.525 million (2005)
500,000 (2005)
.ug
4.1% (2003 est.)
530,000 (2001 est.)
78,000 (2003 est.)
43 (1999)
0 bbl/day (2003 est.)
10,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 15 years
male: 14.9 years
female: 15.1 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,365 (2006)
23.4% of GDP (2005 est.)
64.3% of GDP (2005 est.)
$-355 million (2005 est.)
$1.286 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: malaria and African trypanosomiasis (sleeping
sickness) are high risks in some locations
water contact disease: schistosomiasis (2005)
Vietnam
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: dengue fever, malaria, Japanese encephalitis,
and plague are high risks in some locations
animal contact disease: rabies
water contact disease: leptospirosis
note: at present, H5N1 avian influenza poses a minimal risk; during
outbreaks among birds, rare cases could occur among US personnel who
have close contact with infected birds or poultry (2005)
refugees (country of origin): 214,673 (Sudan) 18,902 (Rwanda)
14,982 (Democratic Republic of Congo)
IDPs: 1,330,000-2,000,000 note - ongoing Lord''s Resistance Army
(LRA) rebellion, mainly in the north; LRA frequently attacks IDP
camps (2005)
$7.909 billion (2005 est.)','4a1b1e72640a796190585e9acfff4175f6e95680979c9a23c30ae6a494c43c47','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7717e9ef48156833bbd6d382bec9d4e5b12656af574f7bf6c1fd09e1633df9c',2006,'UA','Ukraine','communications',793,'general assessment: Ukraine''s telecommunication development
plan, running through 2005, emphasizes improving domestic trunk
lines, international connections, and the mobile cellular system
domestic: at independence in December 1991, Ukraine inherited a
telephone system that was antiquated, inefficient, and in disrepair;
more than 3.5 million applications for telephones could not be
satisfied; telephone density is rising slowly and the domestic trunk
system is being improved; the mobile cellular telephone system is
expanding at a high rate
international: country code - 380; two new domestic trunk lines are
a part of the fiber-optic Trans-Asia-Europe (TAE) system and three
Ukrainian links have been installed in the fiber-optic
Trans-European Lines (TEL) project that connects 18 countries;
additional international service is provided by the
Italy-Turkey-Ukraine-Russia (ITUR) fiber-optic submarine cable and
by earth stations in the Intelsat, Inmarsat, and Intersputnik
satellite systems
most of Ukraine consists of fertile plains (steppes) and
plateaus, mountains being found only in the west (the Carpathians),
and in the Crimean Peninsula in the extreme south
1.17 children born/woman (2006 est.)
republic
3.1% officially registered; large number of unregistered or
underemployed workers; the International Labor Organization
calculates that Ukraine''s real unemployment level is around 9-10%
(2005 est.)
conventional long form: none
conventional short form: Ukraine
local long form: none
local short form: Ukrayina
former: Ukrainian National Republic, Ukrainian State, Ukrainian
Soviet Socialist Republic
Eastern Europe, bordering the Black Sea, between Poland,
Romania, and Moldova in the west and Russia in the east
Asia, Europe
22,080 sq km (2003)
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
chief of mission: Ambassador Oleh V. SHAMSHUR
chancery: 3350 M Street NW, Washington, DC 20007
telephone: [1] (202) 333-0606
FAX: [1] (202) 333-0817
consulate(s) general: Chicago, New York, San Francisco
12.142 million (2004)
17.214 million (2005)
5,278,100 (2005)
.ua
1.4% (2003 est.)
360,000 (2001 est.)
20,000 (2003 est.)
29 (1999)
85,660 bbl/day (2004)
491,700 bbl/day (2004)
444,600 bbl/day NA bbl/day
8,891 bbl/day NA bbl/day
total: 39.2 years
male: 35.9 years
female: 42.2 years (2006 est.)
395 million bbl (9 November 2004)
1.121 trillion cu m (9 November 2004)
20.3 billion cu m (2004)
75.8 billion cu m (2004)
59.8 billion cu m (2004)
3.9 billion cu m (2004)
229,110 (2006)
20.9% of GDP (2005 est.)
17% of GDP (2005 est.)
$2.531 billion (2005 est.)
$19.39 billion (2005 est.)
$75.14 billion (2005 est.)','1775bd8af719df9ebde3fc48aebeebdfafaca8c830ec729e4bca79aa2de88b38','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06cd7305f4ce8a45944a18a860109a8647793ac897b36bd93f01b863d5a88425',2006,'AE','United Arab Emirates','communications',794,'general assessment: modern fiber-optic
integrated services; digital network with rapidly growing use of
mobile cellular telephones; key centers are Abu Dhabi and Dubai
domestic: microwave radio relay, fiber optic and coaxial cable
international: country code - 971; satellite earth stations - 3
Intelsat (1 Atlantic Ocean and 2 Indian Ocean) and 1 Arabsat;
submarine cables to Qatar, Bahrain, India, and Pakistan;
tropospheric scatter to Bahrain; microwave radio relay to Saudi
Arabia
flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in east
2.88 children born/woman (2006 est.)
federation with specified powers delegated to
the UAE federal government and other powers reserved to member
emirates
2.4% (2001)
conventional long form: United Arab Emirates
conventional short form: none
local long form: Al Imarat al Arabiyah al Muttahidah
local short form: none
former: Trucial Oman, Trucial States
abbreviation: UAE
Middle East, bordering the Gulf of Oman and the
Persian Gulf, between Oman and Saudi Arabia
Middle East
760 sq km (2003)
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
chief of mission: Ambassador Saqr Ghobash Said
GHOBASH
chancery: 3522 International Court NW, Suite 400, Washington, DC
20008
telephone: [1] (202) 243-2400
FAX: [1] (202) 243-2432
consulate(s): New York, Houston
1.237 million (2005)
4.535 million (2005)
1,397,200 (2005)
.ae
0.18% (2001 est.)
NA
NA
2.396 million bbl/day (2005 est.)
310,000 bbl/day (2004 est.)
0 bbl/day (2004)
2.5 million bbl/day (2004 est.)
total: 28.1 years
male: 34.8 years
female: 23.3 years (2006 est.)
97.8 billion bbl (2005 est.)
6.006 trillion cu m (2005)
44.79 billion cu m (2003 est.)
37.88 billion cu m (2003 est.)
0 cu m (2003 est.)
7.19 billion cu m (2003 est.)
337,092 (2006)
20.7% of GDP (2005 est.)
17.5% of GDP (2005 est.)
$18.54 billion (2005 est.)
$23.53 billion (2005 est.)
$98.1 billion (2005 est.)
current situation: the United Arab Emirates is
a destination country for men, women, and children trafficked from
South and East Asia, Eastern Europe, Africa, and the Middle East for
involuntary servitude and for sexual exploitation; an estimated
10,000 women from sub-Saharan Africa, Eastern Europe, South and East
Asia, Iraq, Iran, and Morocco may be victims of sex trafficking in
the UAE; women also migrate from Africa, and South and Southeast
Asia to work as domestic servants, but may have their passports
confiscated, be denied permission to leave the place of employment
in the home, or face sexual or physical abuse by their employers;
men from South Asia come to the UAE to work in the construction
industry, but may be subjected to conditions of involuntary
servitude as they are coerced to pay off recruitment and travel
costs, sometimes having their wages denied for months at a time;
victims of child camel jockey trafficking may still remain in the
UAE, despite a July 2005 law banning the practice; while all
identified victims were repatriated at the government''s expense to
their home countries, questions persist as to the effectiveness of
the ban and the true number of victims
tier rating: Tier 2 Watch List - UAE is placed on the Tier 2 Watch
List for its failure to show increased efforts to combat trafficking
in 2005, particularly in its efforts to address the large-scale
trafficking of foreign girls and women for commercial sexual
exploitation','aea85340250d81866d586e145ff93e1018f9ab25640f875541b239bd007712ae','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53239f242763f19f10e608dea7dbee291a88b5312b4d816ff74b6c935cbd22db',2006,'GB','United Kingdom','communications',795,'general assessment: technologically advanced domestic
and international system
domestic: equal mix of buried cables, microwave radio relay, and
fiber-optic systems
international: country code - 44; 40 coaxial submarine cables;
satellite earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 Inmarsat (Atlantic Ocean region), and 1 Eutelsat;
at least 8 large international switching centers
mostly rugged hills and low mountains; level to
rolling plains in east and southeast
1.66 children born/woman (2006 est.)
constitutional monarchy
4.7% (2005 est.)
conventional long form: United Kingdom of Great
Britain and Northern Ireland; note - Great Britain includes England,
Scotland, and Wales
conventional short form: United Kingdom
abbreviation: UK
Western Europe, islands including the northern
one-sixth of the island of Ireland between the North Atlantic Ocean
and the North Sea, northwest of France
Europe
1,700 sq km (2003)
total: 244,820 sq km
land: 241,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland Islands
chief of mission: Ambassador David G. MANNING
chancery: 3100 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-6500
FAX: [1] (202) 588-7870
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, New York, San Francisco
consulate(s): Dallas, Denver, Miami, Orlando
32.943 million (2005)
61.091 million (2004)
37.6 million (2005)
.uk
0.2% (2001 est.)
51,000 (2001 est.)
less than 500 (2003 est.)
36.8 (1999)
2.393 million bbl/day (2003 est.)
1.722 million bbl/day (2003 est.)
1.084 million bbl/day (2003)
1.498 million bbl/day (2001)
total: 39.3 years
male: 38.2 years
female: 40.4 years (2006 est.)
4.5 billion bbl (31 December 2004)
628.6 billion cu m (31 December 2004)
102.8 billion cu m (2003 est.)
95.15 billion cu m (2003 est.)
2.7 billion cu m (2001 est.)
15.75 billion cu m (2001 est.)
6,064,860 (2006)
16.6% of GDP (2005 est.)
43.1% of GDP (2005 est.)
$-57.61 billion (2005 est.)
$48.66 billion (2005 est.)
$2.228 trillion (2005 est.)','78fbc60f553ffa9686aafe08c5a9479b3aa539e28ff6d164ed5b423eff86b816','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('891e87c8c3d65da24cbc22f534724443fb0214142489648136c50f725402be9d',2006,'US','United States','communications',796,'general assessment: a large, technologically advanced,
multipurpose communications system
domestic: a large system of fiber-optic cable, microwave radio
relay, coaxial cable, and domestic satellites carries every form of
telephone traffic; a rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: country code - 1; 24 ocean cable systems in use;
satellite earth stations - 61 Intelsat (45 Atlantic Ocean and 16
Pacific Ocean), 5 Intersputnik (Atlantic Ocean region), and 4
Inmarsat (Pacific and Atlantic Ocean regions) (2000)
vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in
Alaska; rugged, volcanic topography in Hawaii
United States Pacific Island Wildlife Refuges
low and nearly level
sandy coral islands with narrow fringing reefs that have developed
at the top of submerged volcanic mountains, which in most cases rise
steeply from the ocean floor
2.09 children born/woman (2006 est.)
Constitution-based federal republic; strong democratic
tradition
5.1% (2005 est.)
conventional long form: United States of America
conventional short form: United States
abbreviation: US or USA
United States Pacific Island Wildlife Refuges
conventional long
form: none
conventional short form: Baker Island; Howland Island; Jarvis
Island; Johnston Atoll; Kingman Reef; Midway Islands; Palmyra Atoll
North America, bordering both the North Atlantic Ocean
and the North Pacific Ocean, between Canada and Mexico
United States Pacific Island Wildlife Refuges
Oceania
Baker Island: atoll in the North Pacific Ocean 1,830 nm (3,389 km)
southwest of Honolulu, about half way between Hawaii and Australia
Howland Island: island in the North Pacific Ocean 1,815 nm (3,361
km) southwest of Honolulu, about half way between Hawaii and
North America
United States Pacific Island Wildlife Refuges
Oceania
223,850 sq km (2003)
total: 9,631,420 sq km
land: 9,161,923 sq km
water: 469,497 sq km
note: includes only the 50 states and District of Columbia
United States Pacific Island Wildlife Refuges
total - 6,959.41 sq
km; emergent land - 22.41 sq km; submerged - 6,937 sq km
Baker Island: total - 129 sq km; emergent land - 2.1 sq km;
submerged - 127 sq km
Howland Island: total - 139 sq km; emergent land - 2.6 sq km;
submerged - 136 sq km
Jarvis Island: total - 152 sq km; emergent land - 5 sq km; submerged
- 147 sq km
Johnston Atoll: total - 276.6 sq km; emergent land - 2.6 sq km;
submerged - 274 sq km
Kingman Reef: total - 1,958.01 sq km; emergent land - 0.01 sq km;
submerged - 1,958 sq km
Midway Islands: total - 2,355.2 sq km; emergent land - 6.2 sq km;
submerged - 2,349 sq km
Palmyra Atoll: total - 1,949.9 sq km; emergent land - 3.9 sq km;
submerged - 1,946 sq km
268 million (2003)
219.4 million (2005)
205,326,680 (2005)
.us
0.6% (2003 est.)
950,000 (2003 est.)
14,000 (2003 est.)
45 (2004)
7.61 million bbl/day (2005 est.)
20.03 million bbl/day (2003 est.)
13.15 million bbl/day (2004)
1.048 million bbl/day (2004)
total: 36.5 years
male: 35.1 years
female: 37.8 years (2006 est.)
22.45 billion bbl (1 January 2002)
5.353 trillion cu m (1 January 2002)
539 billion cu m (2003 est.)
633.6 billion cu m (2003 est.)
114.1 billion cu m (2004 est.)
24.19 billion cu m (2004)
195,138,696 (2005)
16.7% of GDP (2005 est.)
64.7% of GDP (2005 est.)
$-829.1 billion (2005 est.)
$86.94 billion (2004 est.)
refugees (country of origin): the US admitted 52,868
refugees during FY03/04 including: 13,331 (Somalia), 6,000 (Laos),
3,482 (Ukraine), 2,959 (Cuba), 1,787 (Iran); note - 32,229 refugees
had been admitted as of 30 June 2005
$12.49 trillion (2005 est.)','846ab0dd3bb3fcf7effb0d21d608f15f8849a18dff4e139d7c0f93e3a52dfa18','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3455eb09ce43ea40c190b15ee37d332aa5d98f10b510c61c12b1277a754c5464',2006,'UY','Uruguay','communications',797,'general assessment: fully digitalized
domestic: most modern facilities concentrated in Montevideo; new
nationwide microwave radio relay network
international: country code - 598; satellite earth stations - 2
Intelsat (Atlantic Ocean) (2002)
mostly rolling plains and low hills; fertile coastal lowland
1.89 children born/woman (2006 est.)
constitutional republic
12.2% (2005 est.)
conventional long form: Oriental Republic of Uruguay
conventional short form: Uruguay
local long form: Republica Oriental del Uruguay
local short form: Uruguay
former: Banda Oriental, Cisplatine Province
Southern South America, bordering the South Atlantic Ocean,
between Argentina and Brazil
South America
2,100 sq km (2003)
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
chief of mission: Ambassador Carlos Alberto GIANELLI Derois
chancery: 1913 I Street NW, Washington, DC 20006
telephone: [1] (202) 331-1313 through 1316
FAX: [1] (202) 331-8142
consulate(s) general: Chicago, Los Angeles, Miami, New York
consulate(s): San Juan (Puerto Rico)
1 million (2004)
600,000 (2004)
680,000 (2005)
.uy
0.3% (2001 est.)
6,000 (2001 est.)
less than 500 (2003 est.)
44.6 (2000)
435 bbl/day (2003 est.)
38,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 32.7 years
male: 31.3 years
female: 34.2 years (2006 est.)
0 cu m (2003 est.)
60 million cu m (2003 est.)
65 million cu m (2003 est.)
0 cu m (2003 est.)
145,774 (2006)
12.9% of GDP (2005 est.)
Venezuela
19% of GDP (2005 est.)
Vietnam
33.1% of GDP (2005 est.)
81.9% of GDP (2005 est.)
$-87.9 million (2005 est.)
$3.079 billion (2005 est.)
$13.24 billion (2005 est.)','9870f7ed5efe0a419f1ed493b7c1c1d2519127c3e1048dab13e19672cca6e4a0','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d84096732ef703daebf679e5c6a6024e550905fbb6de3f25f87cec75a40bdb88',2006,'UZ','Uzbekistan','communications',798,'general assessment: antiquated and inadequate; in serious
need of modernization
domestic: the domestic telephone system is being expanded and
technologically improved, particularly in Tashkent (Toshkent) and
Samarqand, under contracts with prominent companies in
industrialized countries; moreover, by 1998, six cellular networks
had been placed in operation - four of the GSM type (Global System
for Mobile Communication), one D-AMPS type (Digital Advanced Mobile
Phone System), and one AMPS type (Advanced Mobile Phone System)
international: country code - 998; linked by landline or microwave
radio relay with CIS member states and to other countries by leased
connection via the Moscow international gateway switch; after the
completion of the Uzbek link to the Trans-Asia-Europe (TAE)
fiber-optic cable, Uzbekistan will be independent of Russian
facilities for international communications; Inmarsat also provides
an international connection, albeit an expensive one; satellite
earth stations - NA (1998)
mostly flat-to-rolling sandy desert with dunes; broad,
flat intensely irrigated river valleys along course of Amu Darya,
Syr Darya (Sirdaryo), and Zarafshon; Fergana Valley in east
surrounded by mountainous Tajikistan and Kyrgyzstan; shrinking Aral
Sea in west
2.91 children born/woman (2006 est.)
republic; authoritarian presidential rule, with little
power outside the executive branch
0.7% officially, plus another 20% underemployed (2005
est.)
conventional long form: Republic of Uzbekistan
conventional short form: Uzbekistan
local long form: Ozbekiston Respublikasi
local short form: Ozbekiston
former: Uzbek Soviet Socialist Republic
Central Asia, north of Afghanistan
Asia
42,810 sq km (2003)
total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
chief of mission: Ambassador Abdulaziz KAMILOV
chancery: 1746 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 887-5300
FAX: [1] (202) 293-6804
consulate(s) general: New York
1,717,100 (2003)
720,000 (2005)
880,000 (2005)
.uz
less than 0.1% (2001 est.)
11,000 (2003 est.)
less than 500 (2003 est.)
26.8 (2000)
Venezuela
49.1 (1998)
Vietnam
36.1 (1998)
152,000 bbl/day (2004)
120,000 bbl/day (2004)
NA bbl/day
NA bbl/day
total: 22.7 years
male: 22 years
female: 23.3 years (2006 est.)
600 million bbl (1 January 2005)
Venezuela
75.59 billion bbl (2005 est.)
Vietnam
600 million bbl (2005 est.)
World
1.349 trillion bbl (1 January 2002 est.)
1.875 trillion cu m (1 January 2005)
Venezuela
4.191 trillion cu m (2005)
Vietnam
192.6 billion cu m (2005)
World
174.6 trillion cu m (1 January 2002)
55.8 billion cu m (2004)
49.3 billion cu m (2004)
0 cu m (2004)
Venezuela
0 cu m (2004 est.)
Vietnam
NA cu m
World
696 billion cu m (2001 est.)
6.5 billion cu m (2004)
Venezuela
0 cu m (2004 est.)
Vietnam
0 cu m (2005 est.)
World
667.6 billion cu m (2001 est.)
9,058 (2006)
36.1% of GDP (2005 est.)
Venezuela
34.2% of GDP (2005 est.)
Vietnam
48.2% of GDP (2005 est.)
$1.082 billion (2005 est.)
$2.681 billion (2005 est.)
refugees (country of origin): 39,202 (Tajikistan) 5,238
(Afghanistan)
IDPs: 3,000 (forced population transfers by government from villages
near Tajikistan border) (2005)
West Bank
refugees (country of origin): 699,817 (Palestinian
Refugees (UNRWA)) (2005)
World
the United Nations High Commissioner for Refugees (UNHCR)
estimated that in December 2004 there was a global population of 9.2
million refugees, the lowest number in 25 years, and as many as 25
million IDPs in over 49 countries (2005)
$9.86 billion (2005 est.)
current situation: Uzbekistan is a source and, to a
lesser extent, a transit country for women trafficked to Asia and
the Middle East for the purpose of sexual exploitation; women from
other Central Asian countries and China are trafficked through
Uzbekistan; men are trafficked for purposes of forced labor in the
construction and agricultural industries to Ukraine, Russia,
Kazakhstan, and Kyrgyzstan; men and women are also trafficked within
the country
tier rating: Tier 3 - Uzbekistan is placed on Tier 3 because it
failed to fulfill commitments by the country to take additional
steps during 2005, including the adoption of comprehensive
anti-trafficking legislation, criminal code amendments to raise
trafficking penalties, support to the country''s first trafficking
shelter, and approval of a national action plan
Venezuela
current situation: Venezuela is a source, transit, and
destination country for women and children trafficked for the
purposes of sexual exploitation and forced labor; women and children
from Colombia, China, Peru, Ecuador, and the Dominican Republic are
trafficked to and through Venezuela and subjected to commercial
sexual exploitation or forced labor; Venezuelans are trafficked
internally and to Western Europe, particularly Spain and the
Netherlands, and to countries in the Caribbean region for commercial
sexual exploitation; Venezuela is a transit country for illegal
migrants from other countries in the region and for Asian nationals,
some are believed to be trafficking victims
tier rating: Tier 3 - Venezuela does not fully comply with the
minimum standards for the elimination of trafficking and is not
making significant efforts to do so
World
current situation: about 600,000 to 800,000 people, mostly
women and children, are trafficked annually across national borders,
not including millions trafficked within their own countries; at
least 80% of the victims are female; 75% of all victims are
trafficked into commercial sexual exploitation; roughly two-thirds
of the global victims are trafficked intra-regionally within East
Asia and the Pacific (260,000 to 280,000 people) and Europe and
Eurasia (170,000 to 210,000 people)','f1f5cd4efa0c5e93bc426cdef971177989bb8f112b7bd68173123f8b3544a55b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b134f929164a50d20d972c05ae3b2fb03fa31d6e185526b1219cfa569972b99',2006,'VU','Vanuatu','communications',799,'general assessment: NA
domestic: NA
international: country code - 678; satellite earth station - 1
Intelsat (Pacific Ocean)
Venezuela
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth stations; recent
substantial improvement in telephone service in rural areas;
substantial increase in digitalization of exchanges and trunk lines;
installation of a national interurban fiber-optic network capable of
digital multimedia services
international: country code - 58; 3 submarine coaxial cables;
satellite earth stations - 1 Intelsat (Atlantic Ocean) and 1
PanAmSat; participating with Colombia, Ecuador, Peru, and Bolivia in
the construction of an international fiber-optic network
Vietnam
general assessment: Vietnam is putting considerable effort
into modernization and expansion of its telecommunication system,
but its performance continues to lag behind that of its more modern
neighbors
domestic: all provincial exchanges are digitalized and connected to
Hanoi, Da Nang, and Ho Chi Minh City by fiber-optic cable or
microwave radio relay networks; main lines have been substantially
increased, and the use of mobile telephones is growing rapidly
international: country code - 84; satellite earth stations - 2
Intersputnik (Indian Ocean region)
Virgin Islands
general assessment: modern system with total digital
switching, uses fiber-optic cable and microwave radio relay
domestic: full range of services available
international: country code - 1-340; 2 submarine cable connections
(Taino Carib, Americas-1); satellite earth stations - NA
Wake Island
general assessment: satellite communications; 1 DSN
circuit off the Overseas Telephone System (OTS)
domestic: NA
international: NA
mostly mountainous islands of volcanic origin; narrow
coastal plains
Venezuela
Andes Mountains and Maracaibo Lowlands in northwest;
central plains (llanos); Guiana Highlands in southeast
Vietnam
low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
Virgin Islands
mostly hilly to rugged and mountainous with little
level land
Wake Island
atoll of three low coral islands, Peale, Wake, and
Wilkes, built up on an underwater volcano; central lagoon is former
crater, islands are part of the rim
2.7 children born/woman (2006 est.)
Venezuela
2.23 children born/woman (2006 est.)
Vietnam
1.91 children born/woman (2006 est.)
Virgin Islands
2.17 children born/woman (2006 est.)
parliamentary republic
Venezuela
federal republic
Vietnam
Communist state
Virgin Islands
NA
1.7% NA%
Venezuela
12.2% (2005 est.)
Vietnam
2.4% (2005 est.)
Virgin Islands
6.2% (2004)
conventional long form: Republic of Vanuatu
conventional short form: Vanuatu
local long form: Ripablik blong Vanuatu
local short form: Vanuatu
former: New Hebrides
Venezuela
conventional long form: Bolivarian Republic of Venezuela
conventional short form: Venezuela
local long form: Republica Bolivariana de Venezuela
local short form: Venezuela
Vietnam
conventional long form: Socialist Republic of Vietnam
conventional short form: Vietnam
local long form: Cong Hoa Xa Hoi Chu Nghia Viet Nam
local short form: Viet Nam
abbreviation: SRV
Virgin Islands
conventional long form: United States Virgin Islands
conventional short form: Virgin Islands
former: Danish West Indies
abbreviation: USVI
Wake Island
conventional long form: none
conventional short form: Wake Island
Oceania, group of islands in the South Pacific Ocean, about
three-quarters of the way from Hawaii to Australia
Venezuela
Northern South America, bordering the Caribbean Sea and
the North Atlantic Ocean, between Colombia and Guyana
Vietnam
Southeastern Asia, bordering the Gulf of Thailand, Gulf of
Tonkin, and South China Sea, alongside China, Laos, and Cambodia
Virgin Islands
Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, east of Puerto Rico
Wake Island
Oceania, atoll in the North Pacific Ocean, about
two-thirds of the way from Hawaii to the Northern Mariana Islands
Oceania
Venezuela
South America
Vietnam
Southeast Asia
Virgin Islands
Central America and the Caribbean
Wake Island
Oceania
NA
Venezuela
5,750 sq km (2003)
Vietnam
30,000 sq km (2003)
Virgin Islands
NA
Wake Island
0 sq km
total: 12,200 sq km
land: 12,200 sq km
water: 0 sq km
note: includes more than 80 islands, about 65 of which are inhabited
Venezuela
total: 912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Vietnam
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Virgin Islands
total: 1,910 sq km
land: 346 sq km
water: 1,564 sq km
Wake Island
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Vanuatu does not have an embassy in the US; it does,
however, have a Permanent Mission to the UN
Venezuela
chief of mission: Ambassador Bernardo ALVAREZ Herrera
chancery: 1099 30th Street NW, Washington, DC 20007
telephone: [1] (202) 342-2214
FAX: [1] (202) 342-6820
consulate(s) general: Boston, Chicago, Houston, Miami, New Orleans,
New York, San Francisco, San Juan (Puerto Rico)
Vietnam
chief of mission: Ambassador Nguyen Tam CHIEN
chancery: 1233 20th Street NW, Suite 400, Washington, DC 20036
telephone: [1] (202) 861-0737
FAX: [1] (202) 861-0917
consulate(s) general: San Francisco
Virgin Islands
none (territory of the US)
6,800 (2004)
Venezuela
3,605,500 (2005)
Vietnam
15.845 million (2005)
Virgin Islands
70,900 (2004)
12,700 (2005)
Venezuela
12.496 million (2005)
Vietnam
9.593 million (2005)
Virgin Islands
64,200 (2004)
7,500 (2004)
Venezuela
3.04 million (2005)
Vietnam
13.1 million (2006)
Virgin Islands
30,000 (2002)
.vu
Venezuela
.ve
Vietnam
.vn
Virgin Islands
.vi
NA
Venezuela
0.7% - note - no country specific models provided (2001
est.)
Vietnam
0.4% (2003 est.)
Virgin Islands
NA
NA
Venezuela
110,000 (1999 est.)
Vietnam
220,000 (2003 est.)
Virgin Islands
NA
NA
Venezuela
4,100 (2003 est.)
Vietnam
9,000 (2003 est.)
Virgin Islands
NA
0 bbl/day (2003 est.)
Venezuela
3.081 million bbl/day (2005 est.)
Vietnam
400,000 bbl/day (2005 est.)
Virgin Islands
14,650 bbl/day (2003 est.)
620 bbl/day (2003 est.)
Venezuela
530,000 bbl/day (2003 est.)
Vietnam
216,000 bbl/day (2003 est.)
Virgin Islands
105,000 bbl/day (2003 est.)
NA bbl/day
Venezuela
NA bbl/day
Vietnam
NA bbl/day
Virgin Islands
NA bbl/day
NA bbl/day
Venezuela
2.1 million bbl/day (2004 est.)
Vietnam
NA bbl/day
Virgin Islands
NA bbl/day
total: 23 years
male: 23 years
female: 23 years (2006 est.)
Venezuela
total: 26 years
male: 25.4 years
female: 26.6 years (2006 est.)
Vietnam
total: 25.9 years
male: 24.8 years
female: 27.1 years (2006 est.)
Virgin Islands
total: 37.1 years
male: 36.2 years
female: 38 years (2006 est.)
West Bank
total: 18.3 years
male: 18.2 years
female: 18.5 years (2006 est.)
World
total: 27.6 years
male: 27 years
female: 28.2 years (2006 est.)
0 cu m (2003 est.)
Venezuela
29.7 billion cu m (2003 est.)
Vietnam
6.342 billion cu m (2005 est.)
Virgin Islands
0 cu m (2003 est.)
0 cu m (2003 est.)
Venezuela
29.7 billion cu m (2003 est.)
Vietnam
6.342 billion cu m (2005 est.)
Virgin Islands
0 cu m (2003 est.)
413 (2006)
Venezuela
51,968 (2006)
Vietnam
12,114 (2006)
Virgin Islands
3,855 (2006)
$-28.35 million
Venezuela
$25.36 billion (2005 est.)
Vietnam
$-309 million (2005 est.)
$40.54 million
Venezuela
$29.64 billion (2005 est.)
Vietnam
$8.863 billion (2005 est.)
$341 million
Venezuela
$106.1 billion (2005 est.)
Vietnam
$43.75 billion (2005 est.)
Virgin Islands
NA','3295f3c93ae02a17f3937736115d1d18e8da9941f8b44b56431f5676f6bc702e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aee22174c0374f1946a4a928e175760b95c68080e05bc843007cd79444d16de7',2006,'WF','Wallis and Futuna','communications',800,'general assessment: NA
domestic: NA
international: country code - 681
West Bank
general assessment: NA
domestic: Israeli company BEZEK and the Palestinian company PALTEL
are responsible for fixed line services in the Gaza Strip; the
Palestinian JAWAL company provides cellular services
international: country code - 970
volcanic origin; low hills
West Bank
mostly rugged dissected upland, some vegetation in west,
but barren in east
NA children born/woman
West Bank
4.28 children born/woman (2006 est.)
NA
15.2% NA%
West Bank
19.9% (includes Gaza Strip) (January-September 2005)
defense is the responsibility of France
conventional long form: Territory of the Wallis
and Futuna Islands
conventional short form: Wallis and Futuna
local long form: Territoire des Iles Wallis et Futuna
local short form: Wallis et Futuna
West Bank
conventional long form: none
conventional short form: West Bank
Oceania, islands in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
West Bank
Middle East, west of Jordan
Oceania
West Bank
Middle East
NA
West Bank
150 sq km; note - includes Gaza Strip (2003)
total: 274 sq km
land: 274 sq km
water: 0 sq km
note: includes Ile Uvea (Wallis Island), Ile Futuna (Futuna Island),
Ile Alofi, and 20 islets
West Bank
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the northwest quarter
of the Dead Sea, but excludes Mt. Scopus; East Jerusalem and
Jerusalem No Man''s Land are also included only as a means of
depicting the entire area occupied by Israel in 1967
none (overseas territory of France)
1,900 (2002)
West Bank
357,300 (includes Gaza Strip) (2004)
0 (1994)
West Bank
1.095 million (includes Gaza Strip) (2005)
900 (2002)
West Bank
243,000 (includes Gaza Strip) (2005)
.wf
West Bank
.ps
NA
West Bank
NA
NA
West Bank
NA
NA
West Bank
NA
1 (2006)
5.6% of GDP
NA
West Bank
$3.45 billion','fd4f056a8c129f513ea654468f4e4e76d339ad2eae453cce350c2e37e3b3d7f0','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88f07ba72f5cfbc6e5ac5fa346fbabb8497ca10566c9c9c7e45235db5a6ecfc8',2006,'EH','Western Sahara','communications',801,'general assessment: sparse and limited system
domestic: NA
international: country code - 212; tied into Morocco''s system by
microwave radio relay, tropospheric scatter, and satellite;
satellite earth stations - 2 Intelsat (Atlantic Ocean) linked to
Rabat, Morocco
World
general assessment: NA
domestic: NA
international: NA
mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
World
the greatest ocean depth is the Mariana Trench at 10,924 m in
the Pacific Ocean
NA children born/woman
World
2.59 children born/woman (2006 est.)
legal status of territory and issue of sovereignty
unresolved; territory contested by Morocco and Polisario Front
(Popular Front for the Liberation of the Saguia el Hamra and Rio de
Oro), which in February 1976 formally proclaimed a
government-in-exile of the Sahrawi Arab Democratic Republic (SADR),
led by President Mohamed ABDELAZIZ; territory partitioned between
Morocco and Mauritania in April 1976, with Morocco acquiring
northern two-thirds; Mauritania, under pressure from Polisario
guerrillas, abandoned all claims to its portion in August 1979;
Morocco moved to occupy that sector shortly thereafter and has since
asserted administrative control; the Polisario''s government-in-exile
was seated as an Organization of African Unity (OAU) member in 1984;
guerrilla activities continued sporadically, until a UN-monitored
cease-fire was implemented 6 September 1991
NA%
World
30% combined unemployment and underemployment in many
non-industrialized countries; developed countries typically 4%-12%
unemployment
conventional long form: none
conventional short form: Western Sahara
former: Spanish Sahara
Northern Africa, bordering the North Atlantic Ocean,
between Mauritania and Morocco
Africa
World
Physical Map of the World, Political Map of the World,
Standard Time Zones of the World
NA
World
2,770,980 sq km (2003)
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
World
total: 510.072 million sq km
land: 148.94 million sq km
water: 361.132 million sq km
note: 70.8% of the world''s surface is water, 29.2% is land
none
about 2,000 (1999 est.)
World
1,263,367,600 (2005)
0 (1999)
World
2,168,433,600 (2005)
NA
World
1,018,057,389 (2005)
.eh
NA
World
NA
NA
World
NA
NA
World
NA
0 bbl/day (2003 est.)
World
79.65 million bbl/day (2003 est.)
1,750 bbl/day (2003 est.)
World
80.1 million bbl/day (2003 est.)
NA bbl/day
NA bbl/day
0 cu m (2003 est.)
World
2.674 trillion cu m (2003 est.)
0 cu m (2003 est.)
World
2.675 trillion cu m (2003 est.)
degree of risk: intermediate
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: may be a significant risk in some locations
during the transmission season (typically April through November)
(2005)
NA
World
$43.07 trillion (2005 est.)','0f2deb31e00bb8d6fe2fbf54e97fbe9a4c02790d6a88a182b72b9c216c309910','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f6b5e95bc7ad1e15a801a8ed6a3d6c26559cd461e30cd19eff3cfe3c30b2ed4',2006,'YE','Yemen','communications',802,'general assessment: since unification in 1990, efforts have
been made to create a national telecommunications network
domestic: the national network consists of microwave radio relay,
cable, tropospheric scatter, and GSM cellular mobile telephone
systems
international: country code - 967; satellite earth stations - 3
Intelsat (2 Indian Ocean and 1 Atlantic Ocean), 1 Intersputnik
(Atlantic Ocean region), and 2 Arabsat; microwave radio relay to
Saudi Arabia and Djibouti
narrow coastal plain backed by flat-topped hills and rugged
mountains; dissected upland desert plains in center slope into the
desert interior of the Arabian Peninsula
6.58 children born/woman (2006 est.)
republic
35% (2003 est.)
a Coast Guard was established in 2002
This page was last updated on 19 December, 2006
======================================================================
@2138 Communications - note
conventional long form: Republic of Yemen
conventional short form: Yemen
local long form: Al Jumhuriyah al Yamaniyah
local short form: Al Yaman
former: Yemen Arab Republic [Yemen (Sanaa) or North Yemen] and
People''s Democratic Republic of Yemen [Yemen (Aden) or South Yemen]
Middle East, bordering the Arabian Sea, Gulf of Aden, and Red
Sea, between Oman and Saudi Arabia
Middle East
5,500 sq km (2003)
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen Arab Republic (YAR
or North Yemen), and the former People''s Democratic Republic of
Yemen (PDRY or South Yemen)
chief of mission: Ambassador Abd al-Wahab Abdallah al-HAJRI
chancery: 2319 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 965-4760
FAX: [1] (202) 337-2017
798,100 (2004)
2 million (2005)
220,000 (2005)
.ye
0.1% (2001 est.)
12,000 (2001 est.)
NA
33.4 (1998)
387,500 bbl/day (2005 est.)
80,000 bbl/day (2003 est.)
NA bbl/day
370,300 bbl/day (2003)
total: 16.6 years
male: 16.6 years
female: 16.6 years (2006 est.)
4.37 billion bbl (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2179 Natural gas - proved reserves (cu m)
478.6 billion cu m (2005)
This page was last updated on 19 December, 2006
======================================================================
@2180 Natural gas - production (cu m)
0 cu m (2003 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
This page was last updated on 19 December, 2006
======================================================================
@2183 Natural gas - exports (cu m)
0 cu m (2003 est.)
This page was last updated on 19 December, 2006
======================================================================
@2184 Internet hosts
171 (2006)
14.2% of GDP (2005 est.)
34.4% of GDP (2005 est.)
$1.224 billion (2005 est.)
$6.143 billion (2005 est.)
refugees (country of origin): 63,511 (Somalia) (2005)
$14.34 billion (2005 est.)','6ed0ff09589750830d545064c12f4b1f067cd14eaeb63ae8a950ba81b6bc953e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19be991b696d202915bb91891e832c806c6d31897725e1dcd95a3ee4593b322d',2006,'ZM','Zambia','communications',803,'general assessment: facilities are aging but still among the
best in Sub-Saharan Africa
domestic: high-capacity microwave radio relay connects most larger
towns and cities; several cellular telephone services in operation;
Internet service is widely available; very small aperture terminal
(VSAT) networks are operated by private firms
international: country code - 260; satellite earth stations - 2
Intelsat (1 Indian Ocean and 1 Atlantic Ocean)
mostly high plateau with some hills and mountains
5.39 children born/woman (2006 est.)
republic
50% (2000 est.)
conventional long form: Republic of Zambia
conventional short form: Zambia
former: Northern Rhodesia
Southern Africa, east of Angola
Africa
1,560 sq km (2003)
total: 752,614 sq km
land: 740,724 sq km
water: 11,890 sq km
chief of mission: Ambassador Inonge MBIKUSITA-LEWANIKA
chancery: 2419 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-9717 through 9719
FAX: [1] (202) 332-0826
94,700 (2005)
946,600 (2005)
231,000 (2005)
.zm
16.5% (2003 est.)
920,000 (2003 est.)
89,000 (2003 est.)
52.6 (1998)
130.2 bbl/day (2003 est.)
12,250 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 16.5 years
male: 16.3 years
female: 16.7 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
3,227 (2006)
27.1% of GDP (2005 est.)
71.5% of GDP (2005 est.)
$-420 million (2005 est.)
$559.8 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: malaria and plague are high risks in some
locations
water contact disease: schistosomiasis (2005)
refugees (country of origin): 88,842 (Angola) 66,248
(Democratic Republic of the Congo) 5,791 (Rwanda) (2005)
$5.351 billion (2005 est.)','f5dea02c54ddd6a520bbefb8098a4bbab8c1dedc499929351d77ac108704770b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa182d84d194bd7f738739a1d5cea0a5d665b7d4ef8ac5676bed482c5ad94d2f',2006,'AF','Afghanistan','communications',804,'mostly rugged mountains; plains in north and southwest
6.69 children born/woman (2006 est.)
Islamic republic
40% (2005 est.)
in March 2003, ''af'' was established as Afghanistan''s
domain name; Internet access is growing through Internet cafes as
well as public "telekiosks" in Kabul (2002)
conventional long form: Islamic Republic of Afghanistan
conventional short form: Afghanistan
local long form: Jomhuri-ye Eslami-ye Afghanestan
local short form: Afghanestan
former: Republic of Afghanistan
Akrotiri
conventional long form: Akrotiri Sovereign Base Area
conventional short form: Akrotiri
Southern Asia, north and west of Pakistan, east of Iran
Akrotiri
peninsula on the southwest coast of Cyprus
Asia
Akrotiri
Middle East
27,200 sq km (2003)
total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Akrotiri
total: 123 sq km
note: includes a salt lake and wetlands
chief of mission: Ambassador Said Tayeb JAWAD
chancery: 2341 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] 202-483-6410
FAX: [1] 202-483-6488
consulate(s) general: Los Angeles, New York
Akrotiri
none (overseas territory of the UK)
100,000 (2005)
1.2 million (2005)
30,000 (2005)
.af
0.01% (2001 est.)
NA
NA
0 bbl/day (2003)
5,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.6 years
male: 17.6 years
female: 17.6 years (2006 est.)
0 bbl (1 January 2002)
99.96 billion cu m (1 January 2002)
50 million cu m (2003 est.)
50 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
22 (2006)
degree of risk: high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria is a high risk countrywide below 2,000
meters from March through November
animal contact disease: rabies (2005)
IDPs: 200,000-300,000 (mostly Pashtuns and Kuchis
displaced in south and west due to drought and instability) (2005)
$7.095 billion','076ebfb2bd3016b19ecca9ed95ac5d6391e82fbcf6684a1ecc213788194223ef','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed56d73fbb224fc56a567c669e2774c64e183e21f1aa57d05b82c0720449f496',2006,'AL','Albania','communications',805,'mostly mountains and hills; small plains along coast
2.03 children born/woman (2006 est.)
emerging democracy
14.3% official rate, but may exceed 30% (2005 est.)
conventional long form: Republic of Albania
conventional short form: Albania
local long form: Republika e Shqiperise
local short form: Shqiperia
former: People''s Socialist Republic of Albania
Southeastern Europe, bordering the Adriatic Sea and Ionian
Sea, between Greece and Serbia and Montenegro
Europe
3,530 sq km (2003)
total: 28,748 sq km
land: 27,398 sq km
water: 1,350 sq km
chief of mission: Ambassador Aleksander SALLABANDA
chancery: 2100 S Street NW, Washington, DC 20008
telephone: [1] (202) 223-4942
FAX: [1] (202) 628-7342
255,000 (2003)
1.259 million (2004)
75,000 (2005)
.al
NA
NA
NA
28.2 (2002)
3,600 bbl/day (2005 est.)
25,200 bbl/day (2005 est.)
21,600 bbl/day (2005 est.)
0 bbl/day (2005 est.)
total: 28.9 years
male: 28.3 years
female: 29.5 years (2006 est.)
185.5 million bbl (1 January 2002)
2.832 billion cu m (1 January 2002)
30 million cu m (2003 est.)
30 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
430 (2006)
22.4% of GDP (2005 est.)
$-416 million (2005 est.)
$1.461 billion (2005 est.)
$8.657 billion (2005 est.)','d1b93a863b0a8986c4f8d161c2fc66a0c3f4bbb39e19cfa67e838d4c4c8fdd7f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62708d79c4dd82631509b2ede38cd7ed052d3843310fde9970d923b6adc942ca',2006,'DZ','Algeria','communications',806,'mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
1.89 children born/woman (2006 est.)
republic
17.1% (2005 est.)
conventional long form: People''s Democratic Republic of
conventional short form: Algeria
local long form: Al Jumhuriyah al Jaza''iriyah ad Dimuqratiyah ash
Sha''biyah
local short form: Al Jaza''ir
Northern Africa, bordering the Mediterranean Sea, between
Morocco and Tunisia
Africa
5,690 sq km (2003)
total: 2,381,740 sq km
land: 2,381,740 sq km
water: 0 sq km
chief of mission: Ambassador Amine KHERBI
chancery: 2118 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 265-2800
FAX: [1] (202) 667-2174
2.572 million (2005)
13.661 million (2005)
1.92 million (2005)
.dz
0.1% ; note - no country specific models provided (2001 est.)
9,100 (2003 est.)
less than 500 (2003 est.)
35.3 (1995)
1.373 million bbl/day (2005 est.)
246,000 bbl/day (2004 est.)
0 bbl/day (2004 est.)
1.127 million bbl/day (2004 est.)
total: 24.9 years
male: 24.7 years
female: 25.1 years (2006 est.)
12.46 billion bbl (2005 est.)
4.531 trillion cu m (2005)
82.4 billion cu m (2003 est.)
21.32 billion cu m (2003 est.)
0 cu m (2005 est.)
57.98 billion cu m (2001 est.)
1,202 (2006)
22.6% of GDP (2005 est.)
30.2% of GDP (2005 est.)
$18.79 billion (2005 est.)
$56.58 billion (2005 est.)
degree of risk: intermediate
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: cutaneous leishmaniasis is a high risk in some
locations (2005)
refugees (country of origin): 102,000 (Western Saharan
Sahrawi, mostly living in Algerian-sponsored camps in the
southwestern Algerian town of Tindouf)
IDPs: 400,000-600,000 (conflict between government forces, Islamic
insurgents) (2005)
$85.31 billion (2005 est.)
current situation: Algeria is a transit and destination
country for men, women, and children from sub-Saharan Africa and
Asia trafficked for forced labor and sexual exploitation; many
victims willingly migrate to Algeria en route to European countries
with the help of smugglers, where they are often forced into
prostitution, labor, and begging to pay off their smuggling debt;
armed militants reportedly traffic women for sexual exploitation and
involuntary servitude, and children may be trafficked for forced
labor as domestic servants or street vendors
tier rating: Tier 2 Watch List - Algeria took no steps to assess the
scope of trafficking in the country and reported no investigations
or prosecutions for trafficking offenses this year','e2234cb1d453c5697b7467d57f062e2c1f961d781c1ef850f14a2a1ad22f7712','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77464df09f726aace948c7fbdea0f820e5eb9a4b328b5a57fc6f4c799f1bd50f',2006,'AS','American Samoa','communications',807,'five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls (Rose Island, Swains Island)
3.16 children born/woman (2006 est.)
NA
29.8% (2005)
defense is the responsibility of the US
conventional long form: Territory of American Samoa
conventional short form: American Samoa
abbreviation: AS
Oceania, group of islands in the South Pacific Ocean,
about half way between Hawaii and New Zealand
Oceania
NA
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
none (territory of the US)
15,000 (2001)
2,377 (1999)
NA
.as
NA
NA
NA
0 bbl/day (2003)
4,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 23.2 years
male: 22.9 years
female: 23.4 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,456 (2006)
$333.8 million','c8417ff913ef504075102e1ac73c958e79cb823ace0562a091a3b91c708ff756','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('197e8f7cb074f85aa5453e9b3e1517c4ece4cde923e98ff1376e0eb31eb4c63d',2006,'AD','Andorra','communications',808,'rugged mountains dissected by narrow valleys
1.3 children born/woman (2006 est.)
parliamentary democracy (since March 1993) that retains as
its chiefs of state a coprincipality; the two princes are the
president of France and bishop of Seo de Urgel, Spain, who are
represented locally by coprinces'' representatives
0% (1996 est.)
defense is the responsibility of France and Spain
conventional long form: Principality of Andorra
conventional short form: Andorra
local long form: Principat d''Andorra
local short form: Andorra
Southwestern Europe, between France and Spain
Europe
NA
total: 468 sq km
land: 468 sq km
water: 0 sq km
chief of mission: Ambassador (vacant); Charge d''Affaires
Jelena V. PIA-COMELLA
chancery: 2 United Nations Plaza, 25th Floor, New York, NY 10017
telephone: [1] (212) 750-8064
FAX: [1] (212) 750-6630
35,400 (2005)
64,600 (2005)
21,900 (2005)
.ad
NA
NA
NA
total: 40.9 years
male: 41.2 years
female: 40.7 years (2006 est.)
14,944 (2006)
NA','899b0992f68649267914142456bde7428eec559c3b0a858a85835f8e0b66c40c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb8ac6416aab7ffdf0d00977c902f4f2cc76a7ecb55ea0553ef7a93285cdcf11',2006,'AO','Angola','communications',809,'narrow coastal plain rises abruptly to vast interior plateau
6.35 children born/woman (2006 est.)
republic; multiparty presidential regime
extensive unemployment and underemployment affecting more
than half the population (2001 est.)
conventional long form: Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People''s Republic of Angola
Southern Africa, bordering the South Atlantic Ocean, between
Namibia and Democratic Republic of the Congo
Africa
800 sq km (2003)
total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
chief of mission: Ambassador Josefina Perpetua Pitra DIAKITI
chancery: 2108 16th Street NW, Washington, DC 20009
telephone: [1] (202) 785-1156
FAX: [1] (202) 785-1258
consulate(s) general: Houston, New York
94,300 (2005)
1,094,100 (2005)
172,000 (2005)
.ao
3.9% (2003 est.)
240,000 (2003 est.)
21,000 (2003 est.)
1.6 million bbl/day (2005 est.)
46,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18 years
male: 18 years
female: 18 years (2006 est.)
25 billion bbl (2005 est.)
45.87 billion cu m (2005)
720 million cu m (2003 est.)
720 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
2,525 (2006)
30.3% of GDP (2005 est.)
38.3% of GDP (2005 est.)
$4.054 billion (2005 est.)
$3.197 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, typhoid fever
vectorborne diseases: malaria, African trypanosomiasis (sleeping
sickness) are high risks in some locations
respiratory disease: meningococcal meningitis
water contact disease: schistosomiasis (2005)
refugees (country of origin): 13,510 (Democratic Republic of
Congo)
IDPs: 40,000-60,000 (27-year civil war ending in 2002; 4 million
IDPs already have returned) (2005)
$24.35 billion (2005 est.)','3f0e41a58036c37fe1b47ea801cfeae2be9849dc5eebad13977f90b73e275f92','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e458a7347a604305138eb2853f637752dd56cf62224d223c0d4f441090a437a',2006,'AI','Anguilla','communications',810,'flat and low-lying island of coral and limestone
1.73 children born/woman (2006 est.)
NA
8% (2002)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Anguilla
Caribbean, islands between the Caribbean Sea and North
Atlantic Ocean, east of Puerto Rico
Central America and the Caribbean
NA
total: 102 sq km
land: 102 sq km
water: 0 sq km
none (overseas territory of the UK)
6,200 (2002)
1,800 (2002)
3,000 (2002)
.ai
NA
NA
NA
total: 31.2 years
male: 31.2 years
female: 31.1 years (2006 est.)
403 (2006)
$-42.87 million
$108.9 million','9cefca4f707d329179c38c3d936d6656a7690b95a836ea50ae99223e6d5fc456','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e49cff66ebda6194788c3627118f0363ad53054a55b3384c15a73cd0e0eab2d3',2006,'AQ','Antarctica','communications',811,'about 98% thick continental ice sheet and 2% barren rock,
with average elevations between 2,000 and 4,000 meters; mountain
ranges up to nearly 5,000 meters; ice-free coastal areas include
parts of southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the coastline, and floating ice
shelves constitute 11% of the area of the continent
Antarctic Treaty Summary - the Antarctic Treaty, signed
on 1 December 1959 and entered into force on 23 June 1961,
establishes the legal framework for the management of Antarctica;
the 28th Antarctic Treaty Consultative Meeting was held in
Stockholm, Sweden in June 2005; at these periodic meetings,
decisions are made by consensus (not by vote) of all consultative
member nations; at the end of 2005, there were 45 treaty member
nations: 28 consultative and 17 non-consultative; consultative
(decision-making) members include the seven nations that claim
portions of Antarctica as national territory (some claims overlap)
and 21 non-claimant nations; the US and Russia have reserved the
right to make claims; the US does not recognize the claims of
others; Antarctica is administered through meetings of the
consultative member nations; decisions from these meetings are
carried out by these member nations (with respect to their own
nationals and operations) in accordance with their own national
laws; the years in parentheses indicate when a consultative
member-nation acceded to the Treaty and when it was accepted as a
consultative member, while no date indicates the country was an
original 1959 treaty signatory; claimant nations are - Argentina,
Australia, Chile, France, NZ, Norway, and the UK. Nonclaimant
consultative nations are - Belgium, Brazil (1975/1983), Bulgaria
(1978/1998) China (1983/1985), Ecuador (1987/1990), Finland
(1984/1989), Germany (1979/1981), India (1983/1983), Italy
(1981/1987), Japan, South Korea (1986/1989), Netherlands
(1967/1990), Peru (1981/1989), Poland (1961/1977), Russia, South
Africa, Spain (1982/1988), Sweden (1984/1988), Ukraine (1992/2004),
Uruguay (1980/1985), and the US; non-consultative members, with year
of accession in parentheses, are - Austria (1987), Canada (1988),
Colombia (1989), Cuba (1984), Czech Republic (1962/1993), Denmark
(1965), Estonia (2001), Greece (1987), Guatemala (1991), Hungary
(1984), North Korea (1987), Papua New Guinea (1981), Romania (1971),
Slovakia (1962/1993), Switzerland (1990), Turkey (1996), and
Venezuela (1999); note - Czechoslovakia acceded to the Treaty in
1962 and separated into the Czech Republic and Slovakia in 1993;
Article 1 - area to be used for peaceful purposes only; military
activity, such as weapons testing, is prohibited, but military
personnel and equipment may be used for scientific research or any
other peaceful purpose; Article 2 - freedom of scientific
investigation and cooperation shall continue; Article 3 - free
exchange of information and personnel, cooperation with the UN and
other international agencies; Article 4 - does not recognize,
dispute, or establish territorial claims and no new claims shall be
asserted while the treaty is in force; Article 5 - prohibits nuclear
explosions or disposal of radioactive wastes; Article 6 - includes
under the treaty all land and ice shelves south of 60 degrees 00
minutes south and reserves high seas rights; Article 7 -
treaty-state observers have free access, including aerial
observation, to any area and may inspect all stations,
installations, and equipment; advance notice of all expeditions and
of the introduction of military personnel must be given; Article 8 -
allows for jurisdiction over observers and scientists by their own
states; Article 9 - frequent consultative meetings take place among
member nations; Article 10 - treaty states will discourage
activities by any country in Antarctica that are contrary to the
treaty; Article 11 - disputes to be settled peacefully by the
parties concerned or, ultimately, by the ICJ; Articles 12, 13, 14 -
deal with upholding, interpreting, and amending the treaty among
involved nations; other agreements - some 200 recommendations
adopted at treaty consultative meetings and ratified by governments
include - Agreed Measures for Fauna and Flora (1964) which were
later incorporated into the Environmental Protocol; Convention for
the Conservation of Antarctic Seals (1972); Convention on the
Conservation of Antarctic Marine Living Resources (1980); a mineral
resources agreement was signed in 1988 but remains unratified; the
Protocol on Environmental Protection to the Antarctic Treaty was
signed 4 October 1991 and entered into force 14 January 1998; this
agreement provides for the protection of the Antarctic environment
through six specific annexes: 1) environmental impact assessment, 2)
conservation of Antarctic fauna and flora, 3) waste disposal and
waste management, 4) prevention of marine pollution, 5) area
protection and management and 6) liability arising from
environmental emergencies; it prohibits all activities relating to
mineral resources except scientific research; a permanent Antarctic
Treaty Secretariat was established in 2004 in Buenos Aires, Argentina
the Antarctic Treaty prohibits any measures of a military
nature, such as the establishment of military bases and
fortifications, the carrying out of military maneuvers, or the
testing of any type of weapon; it permits the use of military
personnel or equipment for scientific research or for any other
peaceful purposes
conventional long form: none
conventional short form: Antarctica
continent mostly south of the Antarctic Circle
Antarctic Region
total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72 million sq km
ice-covered) (est.)
note: fifth-largest continent, following Asia, Africa, North
America, and South America, but larger than Australia and the
subcontinent of Europe
0; note - information for US bases only (2001)
NA
.aq
7,757 (2006)','31090aa0de9230095e2d123e1b17cabe8d52b8f57dc8c6fb741d8401fa3cb475','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48db3d545b21e68621fb3a4b242ac1669741b68a7879b5231e5ce7e4e8f7e2c8',2006,'AG','Antigua and Barbuda','communications',812,'mostly low-lying limestone and coral islands,
with some higher volcanic areas
Arctic Ocean
central surface covered by a perennial drifting polar
icepack that, on average, is about 3 meters thick, although pressure
ridges may be three times that thickness; clockwise drift pattern in
the Beaufort Gyral Stream, but nearly straight-line movement from
the New Siberian Islands (Russia) to Denmark Strait (between
Greenland and Iceland); the icepack is surrounded by open seas
during the summer, but more than doubles in size during the winter
and extends to the encircling landmasses; the ocean floor is about
50% continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonosov Ridge)
2.24 children born/woman (2006 est.)
constitutional parliamentary democracy
11% (2001 est.)
conventional long form: none
conventional short form: Antigua and Barbuda
Caribbean, islands between the Caribbean Sea and
the North Atlantic Ocean, east-southeast of Puerto Rico
Arctic Ocean
body of water between Europe, Asia, and North America,
mostly north of the Arctic Circle
Central America and the Caribbean
Arctic Ocean
Arctic Region
NA
total: 442.6 sq km (Antigua 280 sq km; Barbuda
161 sq km)
land: 442.6 sq km
water: 0 sq km
note: includes Redonda, 1.6 sq km
Arctic Ocean
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea, Chukchi Sea,
East Siberian Sea, Greenland Sea, Hudson Bay, Hudson Strait, Kara
Sea, Laptev Sea, Northwest Passage, and other tributary water bodies
chief of mission: Ambassador Deborah Mae LOVELL
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 362-5122
FAX: [1] (202) 362-5225
consulate(s) general: Miami
38,000 (2004)
54,000 (2004)
20,000 (2005)
.ag
NA
NA
NA
0 bbl/day (2003)
3,600 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 30 years
male: 29.5 years
female: 30.5 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
2,231 (2006)
$-83.4 million
$905 million','f92d2e80884abf14ad0dffbf9abdebe73d13552a3dcceb5b1cfe8c2a8a86f242','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd6adc2d1a496739a75cc289864df76657021e8237deeedfb264b7316d740dbb',2006,'AR','Argentina','communications',813,'rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western
border
2.16 children born/woman (2006 est.)
republic
11.6% (2005 est.)
the Argentine military is a well-organized force
constrained by the country''s prolonged economic hardship; the
country has recently experienced a strong recovery, and the military
is now implementing "Plan 2000," aimed at making the ground forces
lighter and more responsive (2005)
conventional long form: Argentine Republic
conventional short form: Argentina
local long form: Republica Argentina
local short form: Argentina
Southern South America, bordering the South Atlantic
Ocean, between Chile and Uruguay
South America
15,500 sq km (2003)
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
chief of mission: Ambassador Jose Octavio BORDON
chancery: 1600 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 238-6400
FAX: [1] (202) 332-3171
consulate(s) general: Atlanta, Chicago, Houston, Los Angeles, Miami,
New York
8.8 million (2005)
22.1 million (2005)
10 million (2005)
.ar
0.7% (2001 est.)
130,000 (2001 est.)
1,500 (2003 est.)
52.2 (2001)
745,000 bbl/day (2005 est.)
450,000 bbl/day (2001 est.)
NA bbl/day
NA bbl/day
total: 29.7 years
male: 28.8 years
female: 30.7 years (2006 est.)
2.95 billion bbl (2005 est.)
663.5 billion cu m (2005)
41.04 billion cu m (2003 est.)
34.58 billion cu m (2003 est.)
0 cu m (2001 est.)
6.05 billion cu m (2001 est.)
1,612,423 (2006)
21.5% of GDP (2005 est.)
72.5% of GDP (2005 est.)
$5.448 billion (2005 est.)
$28.09 billion (2005 est.)
$182 billion (2005 est.)
current situation: Argentina is primarily a destination
country for women and children trafficked for sexual and labor
exploitation with most victims trafficked internally, from rural to
urban areas, for exploitation in prostitution; foreign women and
children trafficked for commercial sexual exploitation come
primarily from Paraguay, but also from Bolivia, Brazil, the
Dominican Republic, Colombia, and Chile; Bolivians are trafficked
for forced labor; Argentine women and girls are also trafficked to
neighboring countries for sexual exploitation
tier rating: Tier 2 Watch List - Argentina failed to show evidence
of increasing efforts to combat trafficking particularly in the key
area of prosecutions; government efforts to improve interagency
anti-trafficking coordination did not achieve significant progress
in moving cases against traffickers through the judicial system; the
government made progress in other areas, by submitting
anti-trafficking legislation to Congress in August 2005 and
sensitizing provincial and municipal government officials to the
trafficking problem','55090e2fbcf44d9f61f9ef61bc2b7e163d6922e45f919deb8922e4d9b1db1599','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('035340eb5736b0b470a9f247bbb7ff7fd906b53b19e5aa295e9f8addfc454087',2006,'AM','Armenia','communications',814,'Armenian Highland with mountains; little forest land; fast
flowing rivers; good soil in Aras River valley
1.33 children born/woman (2006 est.)
republic
31.6% (2004 est.)
conventional long form: Republic of Armenia
conventional short form: Armenia
local long form: Hayastani Hanrapetut''yun
local short form: Hayastan
former: Armenian Soviet Socialist Republic; Armenian Republic
Southwestern Asia, east of Turkey
Asia
2,860 sq km (2003)
total: 29,800 sq km
land: 28,400 sq km
water: 1,400 sq km
chief of mission: Ambassador Tatoul MARKARIAN
chancery: 2225 R Street NW, Washington, DC 20008
telephone: [1] (202) 319-1976
FAX: [1] (202) 319-2982
consulate(s) general: Los Angeles
582,500 (2004)
320,000 (2005)
150,000 (2005)
.am
0.1% (2003 est.)
2,600 (2003 est.)
less than 200 (2003 est.)
41.3 (2004)
0 bbl/day (2005)
40,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 30.4 years
male: 27.8 years
female: 33.2 years (2006 est.)
0 cu m (2005 est.)
1.685 billion cu m (2005 est.)
1.685 billion cu m (2005 est.)
0 cu m (2005 est.)
8,163 (2006)
21.4% of GDP (2005 est.)
$-118 million (2005 est.)
$754.9 million (2005 est.)
refugees (country of origin): 235,101 (Azerbaijan)
IDPs: 50,000 (conflict with Azerbaijan over Nagorno-Karabakh) (2005)
$4.868 billion (2005 est.)
current situation: Armenia is a major source and, to a
lesser extent, a transit and destination country for women and girls
trafficked for sexual exploitation largely to the UAE and Turkey;
traffickers, many of them women, route victims directly into Dubai
or through Moscow; profits derived from the trafficking of Armenian
victims reportedly increased dramatically from 2005
tier rating: Tier 2 Watch List - Armenia has failed to show evidence
of increasing efforts, particularly in the areas of enforcement,
trafficking-related corruption, and victim protection; the
government increased implementation of its anti-trafficking law, but
failed to impose significant penalties for convicted traffickers and
failed to vigorously investigate and prosecute ongoing and
widespread allegations of public officials'' complicity in
trafficking; victim protection efforts remain in early, formative
stages and a lack of sensitivity for victims remains a problem,
particularly in the judiciary','3fb5d64fc64b45f58f24a0ce538b098d8fc2f3f5ec20ee456ad2212945035e78','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71496bb577ece53bbea82d83544006f94df356942dc247c0642096926a6ff082',2006,'AW','Aruba','communications',815,'flat with a few hills; scant vegetation
Ashmore and Cartier Islands
low with sand and coral
Atlantic Ocean
surface usually covered with sea ice in Labrador Sea,
Denmark Strait, and coastal portions of the Baltic Sea from October
to June; clockwise warm-water gyre (broad, circular system of
currents) in the northern Atlantic, counterclockwise warm-water gyre
in the southern Atlantic; the ocean floor is dominated by the
Mid-Atlantic Ridge, a rugged north-south centerline for the entire
Atlantic basin
1.79 children born/woman (2006 est.)
parliamentary democracy
6.9% (2005 est.)
defense is the responsibility of the Kingdom of the Netherlands
Ashmore and Cartier Islands
defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy and Royal
Australian Air Force
Baker Island
defense is the responsibility of the US; visited
annually by the US Coast Guard
conventional long form: none
conventional short form: Aruba
Ashmore and Cartier Islands
conventional long form: Territory of
Ashmore and Cartier Islands
conventional short form: Ashmore and Cartier Islands
Caribbean, island in the Caribbean Sea, north of Venezuela
Ashmore and Cartier Islands
Southeastern Asia, islands in the Indian
Ocean, midway between northwestern Australia and Timor island
Atlantic Ocean
body of water between Africa, Europe, the Southern
Ocean, and the Western Hemisphere
Central America and the Caribbean
Ashmore and Cartier Islands
Southeast Asia
Atlantic Ocean
Political Map of the World
0.01 sq km (1998 est.)
Ashmore and Cartier Islands
0 sq km
total: 193 sq km
land: 193 sq km
water: 0 sq km
Ashmore and Cartier Islands
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West, Middle, and East Islets) and
Cartier Island
Atlantic Ocean
total: 76.762 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea, Davis Strait,
Denmark Strait, part of the Drake Passage, Gulf of Mexico, Labrador
Sea, Mediterranean Sea, North Sea, Norwegian Sea, almost all of the
Scotia Sea, and other tributary water bodies
none (represented by the Kingdom of the Netherlands); note -
Mr. Henry BAARH, Minister Plenipotentiary for Aruba at the Embassy
of the Kingdom of the Netherlands
Ashmore and Cartier Islands
none (territory of Australia)
37,100 (2002)
98,400 (2004)
24,000 (2002)
.aw
NA
NA
NA
2,363 bbl/day (2003)
6,500 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 38.5 years
male: 36.4 years
female: 40.3 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
11,548 (2006)
46.3% of GDP
$2.258 billion','190c153f099e04e9064d687e35143b2b1714205c19c042900f4a8b1cdb72393e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea7917a690467849438786af7ba14e0b7e4555b3a0c4474d454adc82cb85c214',2006,'AU','Australia','communications',816,'mostly low plateau with deserts; fertile plain in southeast
1.76 children born/woman (2006 est.)
federal parliamentary democracy
5.1% (2005 est.)
conventional long form: Commonwealth of Australia
conventional short form: Australia
Oceania, continent between the Indian Ocean and the South
Pacific Ocean
Jarvis Island: island in the South Pacific Ocean 1,305 nm (2,417 km)
south of Honolulu, about half way between Hawaii and the Cook Islands
Johnston Atoll: atoll in the North Pacific Ocean 717 nm (1,328 km)
southwest of Honolulu, about one-third of the way from Hawaii to the
Oceania
25,450 sq km (2003)
total: 7,686,850 sq km
land: 7,617,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie Island
chief of mission: Ambassador Dennis J. RICHARDSON
chancery: 1601 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 797-3000
FAX: [1] (202) 797-3168
consulate(s) general: Atlanta, Chicago, Honolulu, Los Angeles, New
York, San Francisco
11.46 million (2005)
18.42 million (2005)
14,663,622 (2006)
.au
0.1% (2003 est.)
14,000 (2003 est.)
less than 200 (2003 est.)
35.2 (1994)
530,000 bbl/day (2005 est.)
875,600 bbl/day (2003 est.)
530,800 bbl/day (2001)
523,400 bbl/day (2001)
total: 36.9 years
male: 36 years
female: 37.7 years (2006 est.)
3.664 billion bbl (1 January 2002)
2.549 trillion cu m (1 January 2002)
35.6 billion cu m (2003 est.)
25.08 billion cu m (2003 est.)
0 cu m (2001 est.)
9.744 billion cu m (2001 est.)
7,772,888 (2006)
25.9% of GDP (2005 est.)
16.1% of GDP (2005 est.)
$-42.09 billion (2005 est.)
$43.26 billion (2005 est.)
$612.8 billion (2005 est.)','f6a36ec02b0ccd4cd531ac9cc6861c671215cccb8a96c174615fd5427ad78f2d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e80d67aa529b83166609f994ec0252ecf2d40b1eb6951c94b20daddf7c83c447',2006,'AT','Austria','communications',817,'in the west and south mostly mountains (Alps); along the
eastern and northern margins mostly flat or gently sloping
1.36 children born/woman (2006 est.)
federal republic
5.2% (2005 est.)
conventional long form: Republic of Austria
conventional short form: Austria
local long form: Republik Oesterreich
local short form: Oesterreich
Central Europe, north of Italy and Slovenia
Europe
40 sq km (2003)
total: 83,870 sq km
land: 82,444 sq km
water: 1,426 sq km
chief of mission: Ambassador Eva NOWOTNY
chancery: 3524 International Court NW, Washington, DC 20008-3035
telephone: [1] (202) 895-6700
FAX: [1] (202) 895-6750
consulate(s) general: Chicago, Los Angeles, New York
3.705 million (2005)
8.16 million (2005)
4.65 million (2005)
.at
0.3% (2003 est.)
10,000 (2003 est.)
less than 100 (2003 est.)
31 (2002)
17,810 bbl/day (2004)
249,000 bbl/day (2004 est.)
152,600 bbl/day (2004)
30,140 bbl/day (2004)
total: 40.9 years
male: 39.8 years
female: 42 years (2006 est.)
84.3 million bbl (2004)
23.2 billion cu m (2004)
1.96 billion cu m (2004)
9.01 billion cu m (2004)
7.05 billion cu m (2004)
0 cu m (2004)
2,062,035 (2006)
20.8% of GDP (2005 est.)
65.1% of GDP (2005 est.)
$1.467 billion (2005 est.)
$11.83 billion (2005 est.)
$293.4 billion (2005 est.)','b18aec6ef392ab6f68ab9ab34bd10fc09f736d716aca85a896af7258ddffbb1c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('463a7e641cb9d4c70605314d418600cf827e4e9d6b830e120aa964df9ff92021',2006,'AZ','Azerbaijan','communications',818,'large, flat Kur-Araz Ovaligi (Kura-Araks Lowland) (much
of it below sea level) with Great Caucasus Mountains to the north,
Qarabag Yaylasi (Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian Sea
Bahamas, The
long, flat coral formations with some low rounded hills
2.46 children born/woman (2006 est.)
Bahamas, The
2.18 children born/woman (2006 est.)
republic
Bahamas, The
constitutional parliamentary democracy
1.1% official rate (2005 est.)
Bahamas, The
10.2% (2005 est.)
conventional long form: Republic of Azerbaijan
conventional short form: Azerbaijan
local long form: Azarbaycan Respublikasi
local short form: Azarbaycan
former: Azerbaijan Soviet Socialist Republic
Bahamas, The
conventional long form: Commonwealth of The Bahamas
conventional short form: The Bahamas
Southwestern Asia, bordering the Caspian Sea, between
Iran and Russia, with a small European portion north of the Caucasus
range
Bahamas, The
Caribbean, chain of islands in the North Atlantic
Ocean, southeast of Florida, northeast of Cuba
Asia
Bahamas, The
Central America and the Caribbean
14,550 sq km (2003)
Bahamas, The
10 sq km (2003)
total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous Republic and the
Nagorno-Karabakh region; the region''s autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November 1991
Bahamas, The
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
chief of mission: Ambassador Yashar ALIYEV
chancery: 2741 34th Street NW, Washington, DC 20008
telephone: [1] (202) 337-3500
FAX: [1] (202) 337-5911
Consulate(s) general: Los Angeles
Bahamas, The
chief of mission: vacant
chancery: 2220 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 319-2660
FAX: [1] (202) 319-2668
consulate(s) general: Miami, New York
1,091,400 (2005)
Bahamas, The
139,900 (2004)
2.242 million (2005)
Bahamas, The
186,000 (2004)
678,800 (2005)
Bahamas, The
93,000 (2005)
.az
Bahamas, The
.bs
less than 0.1% (2003 est.)
Bahamas, The
3% (2003 est.)
1,400 (2003 est.)
Bahamas, The
5,600 (2003 est.)
less than 100 (2001 est.)
Bahamas, The
less than 200 (2003 est.)
36.5 (2001)
477,000 bbl/day (2005 est.)
Bahamas, The
0 bbl/day (2003)
123,000 bbl/day (2003 est.)
Bahamas, The
23,000 bbl/day (2003 est.)
NA bbl/day
Bahamas, The
NA bbl/day
NA bbl/day
Bahamas, The
transhipments of 29,000 bbl/day (2003)
total: 27.7 years
male: 26.3 years
female: 29.2 years (2006 est.)
Bahamas, The
total: 27.8 years
male: 27.1 years
female: 28.6 years (2006 est.)
589 million bbl (1 January 2002)
849.5 billion cu m (1 January 2002)
5.13 billion cu m (2003 est.)
Bahamas, The
0 cu m (2003 est.)
9.2 billion cu m (2003 est.)
Bahamas, The
0 cu m (2003 est.)
1 billion cu m (2001 est.)
0 cu m (2001 est.)
880 (2006)
Bahamas, The
591 (2006)
54.4% of GDP (2005 est.)
11.3% of GDP (2005 est.)
$167.3 million (2005 est.)
$1.192 billion (2005 est.)
refugees (country of origin): 8,367 (Russia)
IDPs: 528,000 (conflict with Armenia over Nagorno-Karabakh) (2005)
$10.4 billion (2005 est.)
Bahamas, The
$5.783 billion (2005 est.)','6029fd81849593c55a58e57fa705781cc99d6179ccce17504f91f1b40026b50b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0daad8f1f78c2def397e9dbd4e7a2c069b6cac3646f0c95e74c1f626acb1673f',2006,'BH','Bahrain','communications',819,'mostly low desert plain rising gently to low central
escarpment
Baker Island
low, nearly level coral island surrounded by a narrow
fringing reef
2.6 children born/woman (2006 est.)
constitutional hereditary monarchy
15% (2005 est.)
conventional long form: Kingdom of Bahrain
conventional short form: Bahrain
local long form: Mamlakat al Bahrayn
local short form: Al Bahrayn
former: Dilmun
Baker Island
conventional long form: none
conventional short form: Baker Island
Middle East, archipelago in the Persian Gulf, east of Saudi
Arabia
Baker Island
Oceania, atoll in the North Pacific Ocean, about half
way between Hawaii and Australia
Middle East
Baker Island
Oceania
40 sq km (2003)
Baker Island
0 sq km
total: 665 sq km
land: 665 sq km
water: 0 sq km
Baker Island
total: 1.4 sq km
land: 1.4 sq km
water: 0 sq km
chief of mission: Ambassador Nasir bin Muhammad al-BALUSHI
chancery: 3502 International Drive NW, Washington, DC 20008
telephone: [1] (202) 342-1111
FAX: [1] (202) 362-2192
consulate(s) general: New York
196,500 (2005)
748,700 (2005)
152,700 (2005)
.bh
0.2% (2001 est.)
less than 600 (2003 est.)
less than 200 (2003 est.)
188,300 bbl/day (2005 est.)
26,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 29.4 years
male: 32.4 years
female: 25.8 years (2006 est.)
124 million bbl (2005 est.)
92.03 billion cu m (2005)
9.65 billion cu m (2003 est.)
9.65 billion cu m (2003 est.)
0 cu m (2002 est.)
0 cu m (2002 est.)
2,165 (2006)
19.5% of GDP (2005 est.)
33.5% of GDP (2005 est.)
$1.531 billion (2005 est.)
$2.432 billion (2005 est.)
$11.01 billion (2005 est.)
current situation: Bahrain is a destination country for men
and women from South and Southeast Asia who migrate willingly to
work as laborers or domestic servants, but may be subjected to
conditions of involuntary servitude when faced with exorbitant
recruitment and transportation fees, withholding of their passports,
restrictions on their movement, non-payment of wages, and physical
or sexual abuse; Eastern European women are also believed to be
trafficked to Bahrain for the purpose of commercial sexual
exploitation or forced labor
tier rating: Tier 2 Watch List - Bahrain''s efforts to address
trafficking in persons are based largely on pledges of future
efforts; the government did not enact a comprehensive
anti-trafficking law extending labor protection to domestic workers','286f4bfb88e59a275a8a93fd416c3750cc2e7050613f75f48cbd8127ca530338','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3c841a47865b52b43f60ea015dbd1a23a7ecaf90a0e8e3588ce3c3d2bd21266',2006,'BD','Bangladesh','communications',820,'mostly flat alluvial plain; hilly in southeast
3.11 children born/woman (2006 est.)
parliamentary democracy
2.5% (includes underemployment) (2005 est.)
conventional long form: People''s Republic of Bangladesh
conventional short form: Bangladesh
local long form: Gana Prajatantri Banladesh
local short form: Banladesh
former: East Bengal, East Pakistan
Southern Asia, bordering the Bay of Bengal, between Burma
and India
Asia
47,250 sq km (2003)
total: 144,000 sq km
land: 133,910 sq km
water: 10,090 sq km
chief of mission: Ambassador Shamsher Mobin CHOWDHURY
chancery: 3510 International Drive NW, Washington, DC 20008
telephone: [1] (202) 244-0183
FAX: [1] (202) 244-5366
consulate(s) general: Los Angeles, New York
1.07 million (2005)
9 million (2005)
300,000 (2005)
.bd
less than 0.1% (2001 est.)
13,000 (2001 est.)
650 (2001 est.)
31.8 (2000)
6,825 bbl/day (2003)
84,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 22.2 years
male: 22.2 years
female: 22.2 years (2006 est.)
28.45 million bbl (1 January 2002)
300.2 billion cu m (1 January 2002)
11.9 billion cu m (2003 est.)
11.9 billion cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
469 (2006)
24.4% of GDP (2005 est.)
44.5% of GDP (2005 est.)
$37 million (2005 est.)
$2.825 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A and E,
and typhoid fever
vectorborne diseases: dengue fever and malaria are high risks in
some locations
water contact disease: leptospirosis
animal contact disease: rabies (2005)
refugees (country of origin): 20,402 (Burma)
IDPs: 61,000 (land conflicts, religious persecution) (2005)
$63.56 billion (2005 est.)','381213de07234827d9a5993823d6bd7b55abef91a56c93a220a6ae2de50ddbd2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cae2556ab84cd5a63d3a5cf8db0d1ab17359357e976a71cb9a5e2eb585a8c86',2006,'BB','Barbados','communications',821,'relatively flat; rises gently to central highland region
Bassas da India
volcanic rock
1.65 children born/woman (2006 est.)
parliamentary democracy
10.7% (2003 est.)
the Royal Barbados Defense Force includes a land-based
Troop Command and a small Coast Guard; the primary role of the land
element is to defend the island against external aggression; the
Command consists of a single, part-time battalion with a small
regular cadre that is deployed throughout the island; it
increasingly supports the police in patrolling the coastline to
prevent smuggling and other illicit activities (2005)
Bassas da India
defense is the responsibility of France
conventional long form: none
conventional short form: Barbados
Bassas da India
conventional long form: none
conventional short form: Bassas da India
Caribbean, island in the North Atlantic Ocean, northeast of
Venezuela
Bassas da India
Southern Africa, islands in the southern Mozambique
Channel, about one-half of the way from Madagascar to Mozambique
Central America and the Caribbean
Bassas da India
Africa
50 sq km (2003)
Bassas da India
0 sq km
total: 431 sq km
land: 431 sq km
water: 0 sq km
Bassas da India
total: 0.2 sq km
land: 0.2 sq km
water: 0 sq km
chief of mission: Ambassador Michael Ian KING
chancery: 2144 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 939-9200
FAX: [1] (202) 332-7467
consulate(s) general: Miami, New York
consulate(s): Los Angeles
134,900 (2005)
206,200 (2005)
160,000 (2005)
.bb
1.5% (2003 est.)
2,500 (2003 est.)
less than 200 (2003 est.)
1,000 bbl/day (2003)
10,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 34.6 years
male: 33.4 years
female: 35.6 years (2006 est.)
1.254 million bbl (1 January 2002)
141.6 million cu m (1 January 2002)
29.17 million cu m (2003 est.)
29.17 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
282 (2006)
$2.964 billion (2005 est.)','3fec88a8792c1b2d1ba5bc585fd5242fcc9a8de302aea399a3576c3fe0d294d6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('266dc852fa98980b23f1a7bde850967c6ae6927e634236043fa333549e4b8ce7',2006,'BY','Belarus','communications',822,'generally flat and contains much marshland
1.43 children born/woman (2006 est.)
republic in name, although in fact a dictatorship
1.6% officially registered unemployed; large number of
underemployed workers (2005)
conventional long form: Republic of Belarus
conventional short form: Belarus
local long form: Respublika Byelarus''
local short form: Byelarus''
former: Belorussian (Byelorussian) Soviet Socialist Republic
Eastern Europe, east of Poland
Europe
1,310 sq km (2003)
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
chief of mission: Ambassador Mikhail KHVOSTOV
chancery: 1619 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 986-1604
FAX: [1] (202) 986-1805
consulate(s) general: New York
3,284,300 (2005)
4.098 million (2005)
3,394,400 (2005)
.by
0.3% (2001 est.)
15,000 (2001 est.)
1,000 (2001 est.)
30.4 (2000)
36,000 bbl/day (2004 est.)
252,000 bbl/day (2003 est.)
360,000 bbl/day (2004 est.)
14,500 bbl/day (2003 est.)
total: 37.2 years
male: 34.5 years
female: 39.9 years (2006 est.)
250 million cu m (2004 est.)
20.5 billion cu m (2005 est.)
20.5 billion cu m (2005 est.)
0 cu m (2004 est.)
33,641 (2006)
24.8% of GDP (2005 est.)
$852 million (2005 est.)
$1.215 billion (2005 est.)
$26.69 billion (2005 est.)','d100bc8ea83d4ccca549cd04feb99da8156fd5275cf3329ea1078757cae02227','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0037098326f810450663dd7b9d32f3db1ce03eed76c91cd6453f39b9f74f612d',2006,'BE','Belgium','communications',823,'flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
1.64 children born/woman (2006 est.)
federal parliamentary democracy under a constitutional
monarchy
8.4% (2005 est.)
conventional long form: Kingdom of Belgium
conventional short form: Belgium
local long form: Royaume de Belgique/Koninkrijk Belgie
local short form: Belgique/Belgie
Western Europe, bordering the North Sea, between France and
the Netherlands
Europe
400 sq km (2003)
total: 30,528 sq km
land: 30,278 sq km
water: 250 sq km
chief of mission: Ambassador Franciskus VAN DAELE
chancery: 3330 Garfield Street NW, Washington, DC 20008
telephone: [1] (202) 333-6900
FAX: [1] (202) 333-3079
consulate(s) general: Los Angeles, New York
consulate(s): Atlanta
4.801 million (2004)
9.46 million (2005)
5.1 million (2005)
.be
0.2% (2003 est.)
10,000 (2003 est.)
less than 100 (2003 est.)
25 (1996)
Bolivia
60.6 (2002)
13,060 bbl/day (2003)
624,200 bbl/day (2003 est.)
1.042 million bbl/day (2001)
450,000 bbl/day (2001)
total: 40.9 years
male: 39.6 years
female: 42.1 years (2006 est.)
0 cu m (2003 est.)
15.48 billion cu m (2003 est.)
15.4 billion cu m (2001 est.)
Bolivia
0 cu m (2001 est.)
0 cu m (2001 est.)
Bolivia
2.9 billion cu m (2001 est.)
2,870,770 (2006)
19.9% of GDP (2005 est.)
94.3% of GDP (2005 est.)
$6.305 billion (2005 est.)
$12 billion (2005 est.)
$350.3 billion (2005 est.)','08841348234cf83e3ebcdd1d242161c94bc4c34f4ba1a40a89acb43a43b95193','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df82052bd2c8a55056d53e3d2bab866fe6a21f2a33378dcdb5f4e539acf8489',2006,'BZ','Belize','communications',824,'flat, swampy coastal plain; low mountains in south
3.6 children born/woman (2006 est.)
parliamentary democracy
12.9% (2003)
conventional long form: none
conventional short form: Belize
former: British Honduras
Central America, bordering the Caribbean Sea, between
Guatemala and Mexico
Central America and the Caribbean
30 sq km (2003)
total: 22,966 sq km
land: 22,806 sq km
water: 160 sq km
chief of mission: Ambassador Lisa M. SHOMAN
chancery: 2535 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 332-9636
FAX: [1] (202) 332-6888
consulate(s) general: Los Angeles
33,300 (2005)
93,100 (2005)
35,000 (2005)
.bz
2.4% (2003 est.)
3,600 (2003 est.)
less than 200 (2003 est.)
0 bbl/day (2003)
6,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 19.6 years
male: 19.5 years
female: 19.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
3,905 (2006)
17.8% of GDP (2005 est.)
$-180 million (2005 est.)
$87 million (2005 est.)
$908 million (2005 est.)
current situation: Belize is a source, transit, and
destination country for men, women, and children trafficked for the
purposes of labor and sexual exploitation; women and girls are
trafficked mainly from Central America, and exploited in
prostitution; children are trafficked to Belize for labor
exploitation; Belize''s largely unmonitored borders with Guatemala,
Honduras, and Mexico facilitate the movement of illegal migrants who
are vulnerable to traffickers; girls are trafficked within the
country for sexual exploitation, sometimes with the consent and
complicity of their close relatives; there are unconfirmed reports
that Indian and Chinese migrants are trafficked for involuntary
servitude in homes and shops
tier rating: Tier 3 - Belize has failed to show evidence of
significant law enforcement or victim protection efforts
Bolivia
current situation: Bolivia is a source and transit country
for men, women, and children trafficked for the purposes of labor
and sexual exploitation to Argentina, Brazil, and Chile, as well as
to Spain; children are trafficked internally for sexual
exploitation, forced mining, and agricultural labor; illegal
migrants from Asia transiting Bolivia are vulnerable as trafficking
victims
tier rating: Tier 2 Watch List - Bolivia has failed to show evidence
of increasing efforts to combat trafficking in the areas of
prosecutions and victim protection','77892f558cafbe25b31816c111fa53b893c3832461c009fdb0680d32aa815807','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('266cd3b0c75cf78e79132a625801b27f847d6ef4d4479613f5d9066f8c3fe03e',2006,'BJ','Benin','communications',825,'mostly flat to undulating plain; some hills and low mountains
5.2 children born/woman (2006 est.)
republic
NA%
conventional long form: Republic of Benin
conventional short form: Benin
local long form: Republique du Benin
local short form: Benin
former: Dahomey
Western Africa, bordering the Bight of Benin, between Nigeria
and Togo
Africa
120 sq km (2003)
total: 112,620 sq km
land: 110,620 sq km
water: 2,000 sq km
chief of mission: Ambassador Cyrille Segbe OGUIN
chancery: 2124 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 232-6656
FAX: [1] (202) 265-1996
76,300 (2005)
386,700 (2005)
425,000 (2005)
.bj
1.9% (2003 est.)
68,000 (2003 est.)
5,800 (2003 est.)
400 bbl/day (2003)
12,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.6 years
male: 17.2 years
female: 18 years (2006 est.)
4.105 million bbl (1 January 2002)
Bolivia
458.8 million bbl (1 January 2002)
1.218 billion cu m (1 January 2002)
Bolivia
679.6 billion cu m (1 January 2002)
0 cu m (2003 est.)
0 cu m (2003 est.)
867 (2006)
19.9% of GDP (2005 est.)
Bolivia
12.5% of GDP (2005 est.)
$-400 million (2005 est.)
Bolivia
$462 million (2005 est.)
$676 million (2005 est.)
Bolivia
$1.798 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria, yellow fever, and others are high
risks in some locations
respiratory disease: meningococcal meningitis (2005)
$4.34 billion (2005 est.)','77ab0ea4ae639525fbe9f61801cc9201f54b859075c78e05bb47911a769e4ecf','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b9b0d8956b0b3686139e297ea4a2b14e5f4953fc4cca5dc6796192cb75a1fd5',2006,'BM','Bermuda','communications',826,'low hills separated by fertile depressions
1.89 children born/woman (2006 est.)
parliamentary; self-governing territory
2.1% (2004 est.)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Bermuda
former: Somers Islands
North America, group of islands in the North Atlantic Ocean,
east of South Carolina (US)
North America
NA
total: 53.3 sq km
land: 53.3 sq km
water: 0 sq km
none (overseas territory of the UK)
56,000 (2002)
49,000 (2004)
39,000 (2005)
.bm
0.297% (2005)
163 (2005)
392 (2005)
0 bbl/day (2003)
4,658 bbl/day (2005 est.)
NA bbl/day
0 bbl/day NA bbl/day
total: 40.2 years
male: 39.3 years
female: 41 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
8,114 (2006)
NA','057ecdfd2c1c501d38fddef4cb7552e851f1cc95c819e61e2369b738379b5f4a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f95e30c52c4b0fd350486afd31cda89b1fb80ce86d867a1e792cd75eec48b766',2006,'BT','Bhutan','communications',827,'mostly mountainous with some fertile valleys and savanna
Bolivia
rugged Andes Mountains with a highland plateau (Altiplano),
hills, lowland plains of the Amazon Basin
4.74 children born/woman (2006 est.)
Bolivia
2.85 children born/woman (2006 est.)
monarchy; special treaty relationship with India
Bolivia
republic
NA%
Bolivia
8% in urban areas; widespread underemployment (2005 est.)
conventional long form: Kingdom of Bhutan
conventional short form: Bhutan
local long form: Druk Gyalkhap
local short form: Druk Yul
Bolivia
conventional long form: Republic of Bolivia
conventional short form: Bolivia
local long form: Republica de Bolivia
local short form: Bolivia
Southern Asia, between China and India
Bolivia
Central South America, southwest of Brazil
Asia
Bolivia
South America
400 sq km (2003)
Bolivia
1,320 sq km (2003)
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Bolivia
total: 1,098,580 sq km
land: 1,084,390 sq km
water: 14,190 sq km
none; note - Bhutan has a Permanent Mission to the UN;
address: 2 United Nations Plaza, 27th Floor, New York, NY 10017;
telephone [1] (212) 826-1919; FAX [1] (212) 826-2998; the Bhutanese
mission to the UN has consular jurisdiction in the US
consulate(s) general: New York
Bolivia
chief of mission: Ambassador Gustavo GUZMAN Saldana
chancery: 3014 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 483-4410
FAX: [1] (202) 328-3712
consulate(s) general: Houston, Miami, New York, Oklahoma City, San
Francisco, Seattle, Washington, DC
32,700 (2005)
Bolivia
646,300 (2005)
37,800 (2005)
Bolivia
2.421 million (2005)
25,000 (2005)
Bolivia
480,000 (2005)
.bt
Bolivia
.bo
less than 0.1% (2001 est.)
Bolivia
0.1% (2003 est.)
less than 100 (1999 est.)
Bolivia
4,900 (2003 est.)
NA
Bolivia
less than 500 (2003 est.)
0 bbl/day (2003)
Bolivia
42,000 bbl/day (2005 est.)
1,100 bbl/day (2003 est.)
Bolivia
48,000 bbl/day (2003 est.)
NA bbl/day
Bolivia
NA bbl/day
NA bbl/day
Bolivia
NA bbl/day
total: 20.4 years
male: 20.2 years
female: 20.6 years (2006 est.)
Bolivia
total: 21.8 years
male: 21.2 years
female: 22.5 years (2006 est.)
0 cu m (2003 est.)
Bolivia
6.72 billion cu m (2003 est.)
0 cu m (2003 est.)
Bolivia
1.74 billion cu m (2003 est.)
7,567 (2006)
Bolivia
20,085 (2006)
81.4% of GDP
$840.5 million
Bolivia
$9.657 billion (2005 est.)','bf75cd699c033efe224eeacb4b95eea89799d940823102eb9bb1eb238b748484','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1906307638b5e2c9329fe4c2b7b4c238ad806f085d92b3e6ab4553794dfa0f5a',2006,'BA','Bosnia and Herzegovina','communications',828,'mountains and valleys
1.22 children born/woman (2006 est.)
emerging federal democratic republic
45.5% official rate; grey economy may reduce
actual unemployment to 25-30% (31 December 2004 est.)
conventional long form: none
conventional short form: Bosnia and Herzegovina
local long form: none
local short form: Bosna i Hercegovina
former: People''s Republic of Bosnia and Herzegovina, Socialist
Republic of Bosnia and Herzegovina
Southeastern Europe, bordering the Adriatic
Sea and Croatia
Europe
30 sq km (2003)
total: 51,129 sq km
land: 51,129 sq km
water: 0 sq km
chief of mission: Ambassador Bisera TURKOVIC
chancery: 2109 E Street NW, Washington, DC 20037
telephone: [1] (202) 337-1500
FAX: [1] (202) 337-1502
consulate(s) general: Chicago, New York
968,900 (2005)
1.594 million (2005)
806,400 (2005)
.ba
less than 0.1% (2001 est.)
900 (2003 est.)
100 (2001 est.)
26.2 (2001)
0 bbl/day (2003)
21,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 38.4 years
male: 37.2 years
female: 39.5 years (2006 est.)
0 cu m (2003 est.)
160 million cu m (2003 est.)
300 million cu m (2001 est.)
0 cu m (2001 est.)
31,490 (2006)
29% of GDP
$-2.087 billion (2005 est.)
$2.531 billion (2005 est.)
refugees (country of origin): 19,213 (Croatia)
IDPs: 309,200 (Bosnian Croats, Serbs, and Muslims displaced in
1992-95 war) (2005)
Burma
IDPs: 550,000-1,000,000 (government offensives against ethnic
insurgent groups near borders; most IDPs are ethnic Karen, Karenni,
Shan, Tavoyan, and Mon) (2005)
$8.495 billion (2005 est.)','f536016d83beb9e4412cab14a38ed2f505d904dd18f30344a7818181f822dc2d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cb52ed9aedc1648d465460c2b219440fb8de94557f045683d4448dfc454f864',2006,'BW','Botswana','communications',829,'predominantly flat to gently rolling tableland; Kalahari
Desert in southwest
2.79 children born/woman (2006 est.)
parliamentary republic
23.8% (2004)
conventional long form: Republic of Botswana
conventional short form: Botswana
local long form: Republic of Botswana
local short form: Botswana
former: Bechuanaland
Southern Africa, north of South Africa
Africa
10 sq km (2003)
total: 600,370 sq km
land: 585,370 sq km
water: 15,000 sq km
chief of mission: Ambassador Lapologang Caesar LEKOA
chancery: 1531-1533 New Hampshire Avenue NW, Washington, DC 20036
telephone: [1] (202) 244-4990
FAX: [1] (202) 244-4164
132,000 (2005)
823,100 (2005)
60,000 (2002)
.bw
37.3% (2003 est.)
350,000 (2003 est.)
33,000 (2003 est.)
63 (1993)
0 bbl/day (2003)
12,000 bbl/day (2003 est.)
16,000 bbl/day (2001)
NA bbl/day
total: 19.4 years
male: 18.8 years
female: 20 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
5,499 (2006)
20.3% of GDP (2005 est.)
6.2% of GDP (2005 est.)
$1.584 billion (2005 est.)
$6.309 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria (2005)
$9.046 billion (2005 est.)','956754471bd99f2c445eb0f9a275f3e2c9e0e4e19f4fafc819978e6e2c0f3abc','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cae42ac4c33a379ec4e6b47bcc837d189b04dcff9c2c9aa72711bb27991583b',2006,'BV','Bouvet Island','communications',830,'volcanic; coast is mostly inaccessible
defense is the responsibility of Norway
automatic meteorological station
Coral Sea Islands
there are automatic weather stations on many of
the isles and reefs relaying data to the mainland
Europa Island
1 meteorological station
Glorioso Islands
1 meteorological station
Iles Eparses
Europa Island, Glorioso Islands, Juan de Nova Island,
Tromelin Island: 1 meteorological station on each possession; note -
meteorological station on Tromelin Island is important for
forecasting cyclones
Juan de Nova Island
1 meteorological station
Saint Helena
South Africa maintains a meteorological station on
Gough Island
Tromelin Island
important meteorological station
This page was last updated on 19 December, 2006
======================================================================
@2140 Government - note
conventional long form: none
conventional short form: Bouvet Island
island in the South Atlantic Ocean, southwest of the
Cape of Good Hope (South Africa)
Antarctic Region
0 sq km
total: 49 sq km
land: 49 sq km
water: 0 sq km
.bv
6 (2006)','900050815d21bc84a4237f4bcff99bd7310dc6652e2bb77cd50386467f7e74c2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38ad95eb6e9bcbe3bfb00756fe9c66403974ba8cd7c0215ce60b441e48c20377',2006,'BR','Brazil','communications',831,'mostly flat to rolling lowlands in north; some plains, hills,
mountains, and narrow coastal belt
1.91 children born/woman (2006 est.)
British Virgin Islands
1.72 children born/woman (2006 est.)
Brunei
2.28 children born/woman (2006 est.)
federative republic
British Virgin Islands
NA
Brunei
constitutional sultanate
9.8% (2005 est.)
British Virgin Islands
3.6% (1997)
Brunei
4.8% (2004)
conventional long form: Federative Republic of Brazil
conventional short form: Brazil
local long form: Republica Federativa do Brasil
local short form: Brasil
Eastern South America, bordering the Atlantic Ocean
South America
29,200 sq km (2003)
total: 8,511,965 sq km
land: 8,456,510 sq km
water: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha, Atol das Rocas,
Ilha da Trindade, Ilhas Martin Vaz, and Penedos de Sao Pedro e Sao
Paulo
chief of mission: Ambassador Roberto P. ABDENUR
chancery: 3006 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 238-2700
FAX: [1] (202) 238-2827
consulate(s) general: Boston, Chicago, Houston, Los Angeles, Miami,
New York, San Francisco
42.382 million (2004)
86.21 million (2005)
British Virgin Islands
8,000 (2002)
Brunei
205,900 (2004)
25.9 million (2005)
British Virgin Islands
4,000 (2002)
Brunei
56,000 (2005)
.br
0.7% (2003 est.)
British Virgin Islands
NA
Brunei
less than 0.1% (2003 est.)
660,000 (2003 est.)
British Virgin Islands
NA
Brunei
less than 200 (2003 est.)
15,000 (2003 est.)
British Virgin Islands
NA
Brunei
less than 200 (2003 est.)
59.7 (2004)
2.01 million bbl/day (2005 est.)
British Virgin Islands
0 bbl/day (2003)
Brunei
200,800 bbl/day (2005)
1.61 million bbl/day (2004)
British Virgin Islands
410 bbl/day (2003 est.)
Brunei
10,770 bbl/day (2005 est.)
572,600 bbl/day NA bbl/day
British Virgin Islands
NA bbl/day
Brunei
NA bbl/day
241,700 bbl/day NA bbl/day
British Virgin Islands
NA bbl/day
Brunei
192,700 bbl/day (2005)
total: 28.2 years
male: 27.5 years
female: 29 years (2006 est.)
British Virgin Islands
total: 31.4 years
male: 31.6 years
female: 31.2 years (2006 est.)
Brunei
total: 27.4 years
male: 28 years
female: 26.7 years (2006 est.)
15.12 billion bbl (2005 est.)
Brunei
1.255 billion bbl (1 January 2002)
240 billion cu m (2005)
Brunei
390.8 billion cu m (1 January 2002)
15.79 billion cu m (2005 est.)
British Virgin Islands
0 cu m (2003 est.)
Brunei
11.4 billion cu m (2003 est.)
21.74 billion cu m (2005 est.)
British Virgin Islands
0 cu m (2003 est.)
Brunei
1.73 billion cu m (2003 est.)
5.947 billion cu m (2005 est.)
Brunei
0 cu m (2001 est.)
0 cu m (2005 est.)
Brunei
9 billion cu m (2001 est.)
6,508,431 (2006)
19.9% of GDP (2005 est.)
51.6% of GDP (2005 est.)
$14.19 billion (2005 est.)
British Virgin Islands
$134.3 million
$53.8 billion (2005 est.)
$619.7 billion (2005 est.)
British Virgin Islands
$839.7 million
Brunei
$5.486 billion
current situation: Brazil is a source and destination country
for women and girls trafficked for sexual exploitation within Brazil
and to destinations in South America, the Caribbean, Western Europe,
Japan, the US, and the Middle East, and for men trafficked within
the country for forced agricultural labor; child sex tourism is a
problem within the country, particularly in the resort areas and
coastal cities of Brazil''s northeast; foreign victims from Bolivia,
Peru, China, and Korea are trafficked to Brazil for labor
exploitation in factories
tier rating: Tier 2 Watch List - Brazil has failed to show evidence
of increasing efforts to fight trafficking, specifically for its
failure to apply effective criminal penalties against traffickers
who exploit forced labor
Burma
current situation: Burma is a source country for men, women,
and children trafficked to East and Southeast Asia for sexual
exploitation, domestic service, and forced commercial labor; a
significant number of victims are economic migrants who wind up in
forced or bonded labor and forced prostitution; to a lesser extent,
Burma is a country of transit and destination for women trafficked
from China for sexual exploitation; internal trafficking of persons
occurs primarily for labor in industrial zones and agricultural
estates; internal trafficking of women and girls for sexual
exploitation occurs from villages to urban centers and other areas;
the military junta''s economic mismanagement, human rights abuses,
and policy of using forced labor are driving factors behind Burma''s
large trafficking problem
tier rating: Tier 3 - Burma does not fully comply with the minimum
standards for the elimination of trafficking and is not making
significant efforts to do so','43fecac80e874e2c2173d195138df1491bb0d361d23a1605d0bbd882a4e26f2f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d722add85412aac0b614bf2ac4eda5f3a2e1304849e3ffdcb276f8e8862935c2',2006,'IO','British Indian Ocean Territory','communications',832,'flat and low (most areas do not
exceed two meters in elevation)
British Virgin Islands
coral islands relatively flat; volcanic
islands steep, hilly
Brunei
flat coastal plain rises to mountains in east; hilly lowland
in west
defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
British Virgin Islands
defense is the responsibility of the UK
conventional long form: British
Indian Ocean Territory
conventional short form: none
abbreviation: BIOT
British Virgin Islands
conventional long form: none
conventional short form: British Virgin Islands
abbreviation: BVI
Brunei
conventional long form: Negara Brunei Darussalam
conventional short form: Brunei
local long form: Negara Brunei Darussalam
local short form: Brunei
archipelago in the Indian Ocean,
south of India, about one-half the way from Africa to Indonesia
British Virgin Islands
Caribbean, between the Caribbean Sea and the
North Atlantic Ocean, east of Puerto Rico
Brunei
Southeastern Asia, bordering the South China Sea and Malaysia
Political Map of the World
British Virgin Islands
Central America and the Caribbean
Brunei
Southeast Asia
0 sq km
British Virgin Islands
NA
Brunei
10 sq km (2003)
total: 54,400 sq km
land: 60 sq km; Diego Garcia 44 sq km
water: 54,340 sq km
note: includes the entire Chagos Archipelago of 55 islands
British Virgin Islands
total: 153 sq km
land: 153 sq km
water: 0 sq km
note: comprised of 16 inhabited and more than 20 uninhabited
islands; includes the islands of Tortola, Anegada, Virgin Gorda,
Jost van Dyke
Brunei
total: 5,770 sq km
land: 5,270 sq km
water: 500 sq km
none (overseas territory of the UK)
British Virgin Islands
none (overseas territory of the UK)
Brunei
chief of mission: Ambassador Pengiran Anak Dato PUTEH
chancery: 3520 International Court NW #300, Washington, DC 20008
telephone: [1] (202) 237-1838
FAX: [1] (202) 885-0560
NA
British Virgin Islands
11,700 (2002)
Brunei
90,000 (2002)
.io
British Virgin Islands
.vg
Brunei
.bn
65 (2006)
British Virgin Islands
525 (2006)
Brunei
27 (2005)','bdb229302d9fc3a0d57abb48cdbbc2da2ebe331fe39dd96b1b7a56d140ef99fb','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c1df3531d200c31ad1fd78a92cb129a126e180889a86b51ede2a771cef5b13d',2006,'BG','Bulgaria','communications',833,'mostly mountains with lowlands in north and southeast
1.38 children born/woman (2006 est.)
parliamentary democracy
9.9% (2005)
conventional long form: Republic of Bulgaria
conventional short form: Bulgaria
local long form: Republika Balgariya
local short form: Balgariya
Southeastern Europe, bordering the Black Sea, between
Romania and Turkey
Europe
5,880 sq km (2003)
total: 110,910 sq km
land: 110,550 sq km
water: 360 sq km
chief of mission: Ambassador Elena B. POPTODOROVA
chancery: 1621 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 387-0174
FAX: [1] (202) 234-7973
consulate(s) general: Chicago, Los Angeles, New York
2,483,500 (2005)
6.245 million (2005)
2.2 million (2005)
.bg
less than 0.1% (2001 est.)
346 (2001 est.)
100 (2001 est.)
31.9 (2001)
1,000 bbl/day (2004)
98,000 bbl/day (2004)
85,000 bbl/day (2004 est.)
NA bbl/day
total: 40.8 years
male: 38.7 years
female: 42.9 years (2006 est.)
15 million bbl (1 January 2005)
Burma
less than 1 billion bbl (2005)
5.67 billion cu m (1 January 2005)
Burma
283.2 billion cu m (2005)
1.13 million cu m (2003)
3.1 billion cu m (2004)
2.9 billion cu m (2004)
Burma
0 cu m (2003 est.)
0 cu m (2003)
Burma
8.424 billion cu m (2003 est.)
184,975 (2006)
23.8% of GDP (2005 est.)
31.9% of GDP (2005 est.)
$-3.919 billion (2005)
$8.695 billion (2005)
$25.79 billion (2005 est.)','48b2958d912ad9f486acfa70fcb56d7c1762ff9fe0c48f6d290ee3639cb7f8a4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dffe49ff7fd4d96afc45e1118f358131ae1ae7ffd34473e599e0c03f6e51b8f',2006,'BF','Burkina Faso','communications',834,'mostly flat to dissected, undulating plains; hills in
west and southeast
Burma
central lowlands ringed by steep, rugged highlands
6.47 children born/woman (2006 est.)
Burma
1.98 children born/woman (2006 est.)
parliamentary republic
Burma
military junta
NA%
Burma
5% (2005 est.)
conventional long form: none
conventional short form: Burkina Faso
local long form: none
local short form: Burkina Faso
former: Upper Volta, Republic of Upper Volta
Burma
conventional long form: Union of Burma
conventional short form: Burma
local long form: Pyidaungzu Myanma Naingngandaw (translated by the
US Government as Union of Myanma and by the Burmese as Union of
Myanmar)
local short form: Myanma Naingngandaw
former: Socialist Republic of the Union of Burma
note: since 1989 the military authorities in Burma have promoted the
name Myanmar as a conventional name for their state; this decision
was not approved by any sitting legislature in Burma, and the US
Government did not adopt the name, which is a derivative of the
Burmese short-form name Myanma Naingngandaw
Western Africa, north of Ghana
Burma
Southeastern Asia, bordering the Andaman Sea and the Bay of
Bengal, between Bangladesh and Thailand
Africa
Burma
Southeast Asia
250 sq km (2003)
Burma
18,700 sq km (2003)
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Burma
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
chief of mission: Ambassador Tertius ZONGO
chancery: 2340 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 332-5577
FAX: [1] (202) 667-1882
Burma
chief of mission: Ambassador (vacant); Charge d''Affaires MYINT
LWIN
chancery: 2300 S Street NW, Washington, DC 20008
telephone: [1] (202) 332-3344
FAX: [1] (202) 332-4351
consulate(s) general: New York
97,400 (2005)
Burma
476,200 (2005)
572,200 (2005)
Burma
183,400 (2005)
64,600 (2005)
Burma
78,000 (2005)
.bf
Burma
.mm
4.2% (2003 est.)
Burma
1.2% (2003 est.)
300,000 (2003 est.)
Burma
330,000 (2003 est.)
29,000 (2003 est.)
Burma
20,000 (2003 est.)
48.2 (1998)
0 bbl/day (2003)
Burma
18,500 bbl/day (2005 est.)
8,000 bbl/day (2003 est.)
Burma
32,000 bbl/day (2003 est.)
NA bbl/day
Burma
49,230 bbl/day (2003)
NA bbl/day
Burma
3,356 bbl/day (2003)
total: 16.5 years
male: 16.3 years
female: 16.7 years (2006 est.)
Burma
total: 27 years
male: 26.4 years
female: 27.6 years (2006 est.)
0 cu m (2003 est.)
Burma
9.98 billion cu m (2003 est.)
0 cu m (2003 est.)
Burma
1.569 billion cu m (2003 est.)
399 (2006)
Burma
42 (2006)
20.7% of GDP (2005 est.)
Burma
11.5% of GDP (2005 est.)
$-460 million (2005 est.)
Burma
$700 million (2005 est.)
$764 million (2005 est.)
Burma
$763 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria is a high risk in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
Burma
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: dengue fever and malaria are high risks in
some locations (2005)
$5.405 billion (2005 est.)
Burma
$7.464 billion (2005 est.)','a88548270df6a39d160c34096b08b9d689ec5cbc78d49708e27be54b141e4c81','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('217ea79526c5015e8229ed004904b4b1169ab547db8928bf2d2e3a47a75765b2',2006,'BI','Burundi','communications',835,'hilly and mountainous, dropping to a plateau in east, some
plains
6.55 children born/woman (2006 est.)
republic
NA%
conventional long form: Republic of Burundi
conventional short form: Burundi
local long form: Republique du Burundi/Republika y''u Burundi
local short form: Burundi
former: Urundi
Central Africa, east of Democratic Republic of the Congo
Africa
210 sq km (2003)
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
chief of mission: Ambassador Celestin NIYONGABO
chancery: Suite 212, 2233 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 342-2574
FAX: [1] (202) 342-2578
27,700 (2004)
153,000 (2005)
25,000 (2005)
.bi
6% (2003 est.)
250,000 (2003 est.)
25,000 (2003 est.)
33.3 (1998)
0 bbl/day (2003)
3,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 16.6 years
male: 16.4 years
female: 16.9 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
160 (2006)
11.6% of GDP (2005 est.)
$-29 million (2005 est.)
$105 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria (2005)
refugees (country of origin): 48,424 (Democratic Republic of
the Congo)
IDPs: 145,000 (armed conflict between government and rebels; most
IDPs in northern and western Burundi) (2005)
$730 million (2005 est.)','31ebba4be162b96630a4d76175fbeadf9e6ea061509eafd95872c652aec4006f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd12e062885713389bf35c837316b7516fc65b05f3b5fb076e2d5387911e9298',2006,'KH','Cambodia','communications',836,'mostly low, flat plains; mountains in southwest and north
3.37 children born/woman (2006 est.)
multiparty democracy under a constitutional monarchy
2.5% (2000 est.)
conventional long form: Kingdom of Cambodia
conventional short form: Cambodia
local long form: Preahreacheanachakr Kampuchea (phonetic
pronunciation)
local short form: Kampuchea
former: Kingdom of Cambodia, Khmer Republic, Democratic Kampuchea,
People''s Republic of Kampuchea, State of Cambodia
Southeastern Asia, bordering the Gulf of Thailand, between
Thailand, Vietnam, and Laos
Southeast Asia
2,700 sq km (2003)
total: 181,040 sq km
land: 176,520 sq km
water: 4,520 sq km
chief of mission: Ambassador EK SEREYWATH
chancery: 4530 16th Street NW, Washington, DC 20011
telephone: [1] (202) 726-7742
FAX: [1] (202) 726-8381
36,400 (2003)
1.062 million (2005)
41,000 (2005)
.kh
2.6% (2003 est.)
170,000 (2003 est.)
15,000 (2003 est.)
40 (2004 est.)
0 bbl/day (2003)
3,700 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 20.6 years
male: 19.9 years
female: 21.4 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,378 (2006)
23.3% of GDP (2005 est.)
$-166 million (2005 est.)
$1.145 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: dengue fever, malaria, and Japanese
encephalitis are high risks in some locations
note: at present, H5N1 avian influenza poses a minimal risk; during
outbreaks among birds, rare cases could occur among US citizens who
have close contact with infected birds or poultry (2005)
$4.729 billion (2005 est.)
current situation: Cambodia is a source, destination, and
transit country for men, women, and children trafficked for the
purposes of sexual exploitation and forced labor; a significant
number of women and children are trafficked to Thailand and Malaysia
for commercial sexual exploitation and forced labor; men are
trafficked primarily to Thailand for forced labor in the
construction and agricultural sectors, particularly the fishing
industry, while women and girls are trafficked for factory and
domestic work; children are trafficked to Vietnam and Thailand for
the purpose of forced begging; Cambodia is a transit and destination
point for women from Vietnam trafficked for sexual exploitation;
trafficking for sexual exploitation also occurs within Cambodia''s
borders, from rural areas to the cities
tier rating: Tier 2 Watch List - Cambodia does not fully comply with
the minimum standards for the elimination of trafficking; however,
it is committed to making significant efforts to sustain progress
over the coming year','4caeb1cd61a7b09fd792d79c9fbdc2e1d1a63ed8c7134d6887e42c4f5f2632cd','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9daa9bb05aaff8b282383ffb3108fcd7ce1fba7c00554cd670cd29a16d86b112',2006,'CM','Cameroon','communications',837,'diverse, with coastal plain in southwest, dissected plateau
in center, mountains in west, plains in north
4.39 children born/woman (2006 est.)
republic; multiparty presidential regime
30% (2001 est.)
conventional long form: Republic of Cameroon
conventional short form: Cameroon
local long form: Republique du Cameroun/Republic of Cameroon
local short form: Cameroun/Cameroon
former: French Cameroon, British Cameroon, Federal Republic of
Cameroon, United Republic of Cameroon
Western Africa, bordering the Bight of Biafra, between
Equatorial Guinea and Nigeria
Africa
260 sq km (2003)
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
chief of mission: Ambassador Jerome MENDOUGA
chancery: 2349 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-8790
FAX: [1] (202) 387-3826
99,400 (2004)
2.259 million (2005)
167,000 (2005)
.cm
6.9% (2003 est.)
560,000 (2003 est.)
49,000 (2003 est.)
44.6 (2001)
82,300 bbl/day (2005 est.)
23,000 bbl/day (2001 est.)
NA bbl/day
NA bbl/day
total: 18.9 years
male: 18.7 years
female: 19 years (2006 est.)
85 million bbl (2005 est.)
110.4 billion cu m (2005)
0 cu m (2003 est.)
0 cu m (2003 est.)
0 cu m NA cu m
0 cu m NA cu m
39 (2006)
17.3% of GDP (2005 est.)
65.9% of GDP (2005 est.)
$39 million (2005 est.)
$964.8 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: malaria and yellow fever are high risks in
some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
refugees (country of origin): 39,290 (Chad) 16,686
(Nigeria) 9,634 (Cote d''Ivoire) (2005)
$15.35 billion (2005 est.)','d251f0b42b413381b4258c78116b94facce649868c6a631b53b00e0967a11f89','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('840e32379ad70c4b3a448e2a8f84d35d5356820738b6e89326869a0eb37f4763',2006,'CA','Canada','communications',838,'mostly plains with mountains in west and lowlands in southeast
Cape Verde
steep, rugged, rocky, volcanic
1.61 children born/woman (2006 est.)
Cape Verde
3.38 children born/woman (2006 est.)
constitutional monarchy that is also a parliamentary
democracy and a federation
Cape Verde
republic
6.8% (2005 est.)
Cape Verde
21% (2000 est.)
conventional long form: none
conventional short form: Canada
Cape Verde
conventional long form: Republic of Cape Verde
conventional short form: Cape Verde
local long form: Republica de Cabo Verde
local short form: Cabo Verde
Northern North America, bordering the North Atlantic Ocean on
the east, North Pacific Ocean on the west, and the Arctic Ocean on
the north, north of the conterminous US
Cape Verde
Western Africa, group of islands in the North Atlantic
Ocean, west of Senegal
North America
Cape Verde
Political Map of the World
7,850 sq km (2003)
Cape Verde
30 sq km (2003)
total: 9,984,670 sq km
land: 9,093,507 sq km
water: 891,163 sq km
Cape Verde
total: 4,033 sq km
land: 4,033 sq km
water: 0 sq km
chief of mission: Ambassador Michael WILSON
chancery: 501 Pennsylvania Avenue NW, Washington, DC 20001
telephone: [1] (202) 682-1740
FAX: [1] (202) 682-7701
consulate(s) general: Atlanta, Boston, Buffalo, Chicago, Dallas,
Denver, Detroit, Los Angeles, Miami, Minneapolis, New York, Phoenix,
San Diego, San Francisco, Seattle, Tucson
consulate(s): Anchorage, Houston, Philadelphia, Princeton (New
Jersey), Raleigh, San Jose (California)
Cape Verde
chief of mission: Ambassador Jose BRITO
chancery: 3415 Massachusetts Avenue NW, Washington, DC 20007
telephone: [1] (202) 965-6820
FAX: [1] (202) 965-1207
consulate(s) general: Boston
18.276 million (2005)
Cape Verde
71,400 (2005)
16.6 million (2005)
Cape Verde
81,700 (2005)
21.9 million (2005)
Cape Verde
25,000 (2005)
.ca
Cape Verde
.cv
0.3% (2003 est.)
Cape Verde
0.035% (2001 est.)
56,000 (2003 est.)
Cape Verde
775 (2001)
1,500 (2003 est.)
Cape Verde
225 (as of 2001)
33.1 (1998)
2.4 million bbl/day (2004)
Cape Verde
0 bbl/day (2003)
2.3 million bbl/day (2004)
Cape Verde
1,200 bbl/day (2003 est.)
963,000 bbl/day (2004)
Cape Verde
NA bbl/day
1.6 million bbl/day (2004)
Cape Verde
NA bbl/day
total: 38.9 years
male: 37.8 years
female: 39.9 years (2006 est.)
Cape Verde
total: 19.8 years
male: 19 years
female: 20.7 years (2006 est.)
178.9 billion bbl
note: includes oil sands (2004 est.)
1.673 trillion cu m (2004)
165.8 billion cu m (2003 est.)
Cape Verde
0 cu m (2003 est.)
90.95 billion cu m (2003 est.)
Cape Verde
0 cu m (2003 est.)
8.73 billion cu m (2003 est.)
91.52 billion cu m (2003 est.)
3,934,223 (2006)
Cape Verde
234 (2006)
20.5% of GDP (2005 est.)
Cape Verde
24.8% of GDP (2005 est.)
69.6% of GDP (2005 est.)
$24.96 billion (2005 est.)
Cape Verde
$-82 million (2005 est.)
$33.02 billion (2005 est.)
Cape Verde
$150 million (2005 est.)
$1.035 trillion (2005 est.)
Cape Verde
$1.128 billion (2005 est.)','92e6df6a27d162311139c007c15febd60b1b5071bc7fca790e2e192d37c3dda5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('065d92b86abd9166c21332caa5843d38931cacad3383abaf6ee7541045b38db6',2006,'KY','Cayman Islands','communications',839,'low-lying limestone base surrounded by coral reefs
1.9 children born/woman (2006 est.)
British crown colony
4.4% (2004)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Cayman Islands
Caribbean, three island (Grand Cayman, Cayman Brac,
Little Cayman) group in Caribbean Sea, 240 km south of Cuba and 268
km northwest of Jamaica
Central America and the Caribbean
NA
total: 262 sq km
land: 262 sq km
water: 0 sq km
none (overseas territory of the UK)
38,000 (2002)
17,000 (2002)
9,909 (2003)
.ky
NA
NA
NA
0 bbl/day (2003)
2,450 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 37.2 years
male: 36.8 years
female: 37.5 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
8,611 (2006)
NA','8f5712a273a3e61122043c7854a6981503369b2bae0b7f2ce826a1e6f9f65599','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a97504c30496819f4a2f4b83e09fae654b7d073e2a673a1db8eb7eeab4e518d',2006,'CF','Central African Republic','communications',840,'vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
4.41 children born/woman (2006 est.)
republic
8% (23% for Bangui) (2001 est.)
conventional long form: Central African
Republic
conventional short form: none
local long form: Republique Centrafricaine
local short form: none
former: Ubangi-Shari, Central African Empire
abbreviation: CAR
Central Africa, north of Democratic
Republic of the Congo
Africa
20 sq km (2003)
total: 622,984 sq km
land: 622,984 sq km
water: 0 sq km
chief of mission: Ambassador Emmanuel
TOUABOY
chancery: 1618 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 483-7800
FAX: [1] (202) 332-9893
10,000 (2004)
60,000 (2004)
9,000 (2005)
.cf
13.5% (2003 est.)
260,000 (2003 est.)
23,000 (2003 est.)
61.3 (1993)
0 bbl/day (2003)
2,400 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.4 years
male: 18 years
female: 18.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
10 (2006)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria
respiratory disease: meningococcal meningitis (2005)
refugees (country of origin): 19,470
(Sudan) 1,864 (Chad) 6,484 (Democratic Republic of the Congo)
IDPs: 200,000 (unrest following coup in 2003) (2005)
$1.462 billion (2005 est.)
current situation: Central African Republic
is a source and destination country for children trafficked for
domestic servitude, sexual exploitation, and forced labor in shops
and commercial labor activities; while the majority of child victims
are trafficked within the country, some are also trafficked to and
from Cameroon and Nigeria
tier rating: Tier 2 Watch List - the Central African Republic failed
to provide evidence of increasing efforts to combat trafficking in
persons during 2005, specifically its inadequate law enforcement
response to trafficking crimes','fa7bd40104331c5d9fbc4a6ac870477b182dd46c8f5e0df288fb4898f123aeab','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daf60eb813f014b981845017881e127c68fef0bc3033f50ff21466a4458c88f9',2006,'TD','Chad','communications',841,'broad, arid plains in center, desert in north, mountains in
northwest, lowlands in south
6.25 children born/woman (2006 est.)
republic
NA%
conventional long form: Republic of Chad
conventional short form: Chad
local long form: Republique du Tchad/Jumhuriyat Tshad
local short form: Tchad/Tshad
Central Africa, south of Libya
Africa
300 sq km (2003)
total: 1.284 million sq km
land: 1,259,200 sq km
water: 24,800 sq km
chief of mission: Ambassador Mahamat Adam BECHIR
chancery: 2002 R Street NW, Washington, DC 20009
telephone: [1] (202) 462-4009
FAX: [1] (202) 265-1937
13,000 (2004)
210,000 (2005)
35,000 (2005)
.td
4.8% (2003 est.)
200,000 (2003 est.)
18,000 (2003 est.)
225,000 bbl/day (2005 est.)
1,450 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 16 years
male: 15.3 years
female: 16.6 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
9 (2006)
18.2% of GDP (2005 est.)
$-602 million (2005 est.)
$297 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
Congo, Democratic Republic of the
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria, plague, and African trypanosomiasis
(sleeping sickness) are high risks in some locations
water contact disease: schistosomiasis (2005)
Congo, Republic of the
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria (2005)
Cote d''Ivoire
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: malaria, yellow fever, and others are high
risks in some locations
water contact: schistosomiasis (2005)
refugees (country of origin): 224,924 (Sudan), 29,683 (Central
African Republic) (2005)
$4.799 billion (2005 est.)','4ceca3b222f72f7a67be1b50f1640b470f8b61589c5e0fb957c3a5aa25bbea80','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a3c90a0d4462a9b148befe13ab280769f4c06ba96aa15d2eceb03fcd0a41171',2006,'CL','Chile','communications',842,'low coastal mountains; fertile central valley; rugged Andes in
east
2 children born/woman (2006 est.)
republic
8.1% (2005 est.)
conventional long form: Republic of Chile
conventional short form: Chile
local long form: Republica de Chile
local short form: Chile
Southern South America, bordering the South Pacific Ocean,
between Argentina and Peru
South America
19,000 sq km (2003)
total: 756,950 sq km
land: 748,800 sq km
water: 8,150 sq km
note: includes Easter Island (Isla de Pascua) and Isla Sala y Gomez
chief of mission: Ambassador Mariano FERNANDEZ
chancery: 1732 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 530-4104, 530-4106, 530-4107
FAX: [1] (202) 887-5579
consulate(s) general: Chicago, Houston, Los Angeles, Miami, New
York, Philadelphia, San Francisco, San Juan (Puerto Rico)
3,435,900 (2005)
10.57 million (2005)
6.7 million (2005)
.cl
0.3% (2003 est.)
26,000 (2003 est.)
1,400 (2003 est.)
57.1 (2000)
4,000 bbl/day (2005 est.)
228,000 bbl/day (2003 est.)
221,500 bbl/day (2003 est.)
0 bbl/day
total: 30.4 years
male: 29.5 years
female: 31.4 years (2006 est.)
150 million bbl (1 January 2004)
97.98 billion cu m (1 January 2004)
1 billion cu m (2003 est.)
7.06 billion cu m (2003 est.)
5.337 billion cu m (2002 est.)
0 cu m (2002)
506,055 (2006)
22.1% of GDP (2005 est.)
7.5% of GDP (2005 est.)
$702.7 million (2005 est.)
$16.93 billion (2005 est.)
$115.6 billion (2005 est.)','48e80c5e46a28b2f2f3dc070858f74f85d9471f1092548968945393c952c5495','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e3b0360601f1f70423f0b8678f168132805e565f35dc22bb8ff4767c4dee113',2006,'CN','China','communications',843,'mostly mountains, high plateaus, deserts in west; plains,
deltas, and hills in east
1.73 children born/woman (2006 est.)
Communist state
9% official registered unemployment in urban areas in 2004;
substantial unemployment and underemployment in rural areas; an
official Chinese journal estimated overall unemployment (including
rural areas) for 2003 at 20% (2005 est.)
conventional long form: People''s Republic of China
conventional short form: China
local long form: Zhonghua Renmin Gongheguo
local short form: Zhongguo
abbreviation: PRC
Eastern Asia, bordering the East China Sea, Korea Bay, Yellow
Sea, and South China Sea, between North Korea and Vietnam
Asia
545,960 sq km (2003)
total: 9,596,960 sq km
land: 9,326,410 sq km
water: 270,550 sq km
chief of mission: Ambassador ZHOU Wenzhong
chancery: 2300 Connecticut Avenue NW, Washington, DC 20008
telephone: [1] (202) 328-2500
FAX: [1] (202) 328-2582
consulate(s) general: Chicago, Houston, Los Angeles, New York, San
Francisco
350.433 million (2005)
393.428 million (2005)
123 million (2006)
.cn
0.1% (2003 est.)
840,000 (2003 est.)
44,000 (2003 est.)
44 (2002)
3.504 million bbl/day (2004)
6.391 million bbl/day (2004)
3.226 million bbl/day (2004)
340,300 bbl/day (2004)
total: 32.7 years
male: 32.3 years
female: 33.2 years (2006 est.)
18.26 billion bbl (2004)
2.53 trillion cu m (2004)
35.02 billion cu m (2003)
33.44 billion cu m (2003 est.)
0 cu m (2004)
2.79 billion cu m (2004)
232,780 (2006)
44.4% of GDP (2005 est.)
24.4% of GDP (2005 est.)
$160.8 billion (2005 est.)
$825.6 billion (2005 est.)
refugees (country of origin): 299,287 (Vietnam) estimated
30,000-50,000 (North Korea) (2005)
$2.225 trillion (2005 est.)
current situation: China is a source, transit, and destination
country for women, men, and children trafficked for purposes of
sexual exploitation and forced labor; the majority of trafficking in
China is internal, but there is also international trafficking of
Chinese citizens; women are lured through false promises of
legitimate employment into commercial sexual exploitation in Taiwan,
Thailand, Malaysia, and Japan; Chinese men and women are smuggled to
countries throughout the world at enormous personal expense and then
forced into commercial sexual exploitation or exploitative labor to
repay debts to traffickers; women and children are trafficked into
China from Mongolia, Burma, North Korea, Russia, and Vietnam for
forced labor, marriage, and sexual slavery; most North Koreans enter
northeastern China voluntarily, but others reportedly are trafficked
into China from North Korea; domestic trafficking remains the most
significant problem in China, with an estimated minimum of
10,000-20,000 victims trafficked each year; the actual number of
victims could be much greater; some experts believe that the serious
and prolonged imbalance in the male-female birth ratio may now be
contributing to Chinese and foreign girls and women being trafficked
as potential brides
tier rating: Tier 2 Watch List - China failed to show evidence of
increasing efforts to address transnational trafficking; while the
government provides reasonable protection to internal victims of
trafficking, protection for Chinese and foreign victims of
transnational trafficking remain inadequate','8fdea163dc0244b2f6e3dbc94d738fab7875c8399b80b139117251003260ee51','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('456a95414eef631c698889c4e359bf21f5e45349c1517c0b3a5006b37ee1febb',2006,'CX','Christmas Island','communications',844,'steep cliffs along coast rise abruptly to central
plateau
Clipperton Island
coral atoll
NA
NA
defense is the responsibility of Australia
Clipperton Island
defense is the responsibility of France
conventional long form: Territory of Christmas
Island
conventional short form: Christmas Island
Clipperton Island
conventional long form: none
conventional short form: Clipperton Island
local long form: none
local short form: Ile Clipperton
former: sometimes called Ile de la Passion
Southeastern Asia, island in the Indian Ocean,
south of Indonesia
Clipperton Island
Middle America, atoll in the North Pacific Ocean,
1,120 km southwest of Mexico
Southeast Asia
Clipperton Island
Political Map of the World
NA
Clipperton Island
0 sq km
total: 135 sq km
land: 135 sq km
water: 0 sq km
Clipperton Island
total: 6 sq km
land: 6 sq km
water: 0 sq km
none (territory of Australia)
NA
NA
464 (2001)
.cx
NA
NA
NA
2,368 (2006)','3ef28a74ed03111a4f0c0bc5dbbdc7d95075364c535650cac574dc2f87b321a3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7ccbc661343546ea45577b82746f5ff9d35db09f9d14fd43704544bedca8dcd',2006,'CC','Cocos (Keeling) Islands','communications',845,'flat, low-lying coral atolls
NA
NA
60% (2000 est.)
defense is the responsibility of Australia;
the territory has a five-person police force
conventional long form: Territory of Cocos
(Keeling) Islands
conventional short form: Cocos (Keeling) Islands
Southeastern Asia, group of islands in the
Indian Ocean, southwest of Indonesia, about halfway from Australia
to Sri Lanka
Southeast Asia
NA
total: 14 sq km
land: 14 sq km
water: 0 sq km
note: includes the two main islands of West Island and Home Island
none (territory of Australia)
287 (1992)
note - analog cellular service available
NA
.cc
NA
NA
NA','50a05285e9752f0a30c9a430a8691f5869144e592b3c1cda9f52d9dac8e8bb53','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f553d3716cdc37f703ec3205b6fcb738032d8d07aabbdef89e08a4f9160e0ed7',2006,'CO','Colombia','communications',846,'flat coastal lowlands, central highlands, high Andes
Mountains, eastern lowland plains
2.54 children born/woman (2006 est.)
republic; executive branch dominates government structure
11.8% (2005 est.)
conventional long form: Republic of Colombia
conventional short form: Colombia
local long form: Republica de Colombia
local short form: Colombia
Northern South America, bordering the Caribbean Sea,
between Panama and Venezuela, and bordering the North Pacific Ocean,
between Ecuador and Panama
South America
9,000 sq km (2003)
total: 1,138,910 sq km
land: 1,038,700 sq km
water: 100,210 sq km
note: includes Isla de Malpelo, Roncador Cay, and Serrana Bank
chief of mission: Ambassador Carolina BARCO Isakson
chancery: 2118 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 387-8338
FAX: [1] (202) 232-8643
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, Miami, New York, San Francisco, San Juan (Puerto Rico),
Washington, DC
7,678,800 (2005)
21.85 million (2005)
4.739 million (2005)
.co
0.7% (2003 est.)
190,000 (2003 est.)
3,600 (2003 est.)
53.8 (2005)
512,400 bbl/day (2005 est.)
270,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 26.3 years
male: 25.4 years
female: 27.2 years (2006 est.)
1.492 billion bbl (2005 est.)
Congo, Democratic Republic of the
1.538 billion bbl (1 January 2002)
Congo, Republic of the
93.5 million bbl (1 January 2002)
Cote d''Ivoire
220 million bbl (2005 est.)
127.6 billion cu m (2005)
Congo, Democratic Republic of the
991.1 million cu m (1 January 2002)
Congo, Republic of the
90.61 billion cu m (1 January 2002)
Cote d''Ivoire
29.73 billion cu m (2005)
6.08 billion cu m (2003 est.)
6.08 billion cu m (2003 est.)
0 cu m (2004 est.)
Congo, Republic of the
0 cu m
Cote d''Ivoire
0 cu m (2001 est.)
0 cu m (2004 est.)
Congo, Republic of the
0 cu m
Cote d''Ivoire
0 cu m (2001 est.)
581,877 (2006)
18.6% of GDP (2005 est.)
Congo, Republic of the
21.5% of GDP (2005 est.)
49.5% of GDP (2005 est.)
$-1.931 billion (2005 est.)
$14.96 billion (2005 est.)
Congo, Republic of the
$273 million (2005 est.)
IDPs: 2,900,000 - 3,400,000 (conflict between government
and FARC; drug wars) (2004)
Congo, Democratic Republic of the
refugees (country of origin):
5,277 (Republic of Congo) 11,816 (Rwanda) 18,953 (Uganda) 19,400
(Burundi) 45,226 (Sudan) 98,383 (Angola)
IDPs: 2.33 million (fighting between government forces and rebels
since mid-1990s; most IDPs are in eastern provinces) (2005)
Congo, Republic of the
refugees (country of origin): 53,834
(Democratic Republic of Congo)
IDPs: 60,000 (multiple civil wars since 1992; most IDPs are ethnic
Lari) (2005)
$97.73 billion (2005 est.)','322ad31eefe536193f390d92ce11b85856c460db97833fbeed08dc9ae87f044d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9776e2c998e0e147732e433d530da64316528d4730cc64ab94186c10eb8ecc45',2006,'KM','Comoros','communications',847,'volcanic islands, interiors vary from steep mountains to low
hills
Congo, Democratic Republic of the
vast central basin is a low-lying
plateau; mountains in east
Congo, Republic of the
coastal plain, southern basin, central
plateau, northern basin
5.03 children born/woman (2006 est.)
Congo, Democratic Republic of the
6.45 children born/woman (2006
est.)
Congo, Republic of the
6.07 children born/woman (2006 est.)
republic
Congo, Democratic Republic of the
transitional government
Congo, Republic of the
republic
20% (1996 est.)
Congo, Democratic Republic of the
NA%
Congo, Republic of the
NA%
conventional long form: Union of the Comoros
conventional short form: Comoros
local long form: Union des Comores
local short form: Comores
Congo, Democratic Republic of the
conventional long form: Democratic
Republic of the Congo
conventional short form: none
local long form: Republique Democratique du Congo
local short form: none
former: Congo Free State, Belgian Congo, Congo/Leopoldville,
Congo/Kinshasa, Zaire
abbreviation: DRC
Congo, Republic of the
conventional long form: Republic of the Congo
conventional short form: Congo (Brazzaville)
local long form: Republique du Congo
local short form: none
former: Middle Congo, Congo/Brazzaville, Congo
Southern Africa, group of islands at the northern mouth of
the Mozambique Channel, about two-thirds of the way between northern
Madagascar and northern Mozambique
Congo, Democratic Republic of the
Central Africa, northeast of Angola
Congo, Republic of the
Western Africa, bordering the South Atlantic
Ocean, between Angola and Gabon
Africa
Congo, Democratic Republic of the
Africa
Congo, Republic of the
Africa
NA
Congo, Democratic Republic of the
110 sq km (2003)
Congo, Republic of the
20 sq km (2003)
total: 2,170 sq km
land: 2,170 sq km
water: 0 sq km
Congo, Democratic Republic of the
total: 2,345,410 sq km
land: 2,267,600 sq km
water: 77,810 sq km
Congo, Republic of the
total: 342,000 sq km
land: 341,500 sq km
water: 500 sq km
chief of mission: Representative to the US and Ambassador to
the UN Mahmoud M. ABOUD
chancery: Mission to the US, 336 East 45th Street (2nd floor), New
York, NY 10017
telephone: [1] (212) 750-1637
Congo, Democratic Republic of the
chief of mission: Ambassador Faida
MITIFU
chancery: 1800 New Hampshire Avenue NW, Washington, DC 20009: note -
Consular Office at 1726 M Street, NW, Washington, DC, 20036
telephone: [1] (202) 234-7690, 7691
FAX: [1] (202) 234-2609
Congo, Republic of the
chief of mission: Ambassador Serge MOMBOULI
chancery: 4891 Colorado Avenue NW, Washington, DC 20011
telephone: [1] (202) 726-5500
FAX: [1] (202) 726-1860
16,900 (2005)
Congo, Democratic Republic of the
10,600 (2005)
Congo, Republic of the
13,800 (2004)
16,100 (2005)
Congo, Democratic Republic of the
2.746 million (2005)
Congo, Republic of the
490,000 (2005)
20,000 (2005)
Congo, Democratic Republic of the
140,600 (2005)
Congo, Republic of the
36,000 (2005)
.km
Congo, Democratic Republic of the
.cd
Congo, Republic of the
.cg
0.12% (2001 est.)
Congo, Democratic Republic of the
4.2% (2003 est.)
Congo, Republic of the
4.9% (2003 est.)
NA
Congo, Democratic Republic of the
1.1 million (2003 est.)
Congo, Republic of the
90,000 (2003 est.)
NA
Congo, Democratic Republic of the
100,000 (2003 est.)
Congo, Republic of the
9,700 (2003 est.)
0 bbl/day (2003)
Congo, Democratic Republic of the
22,000 bbl/day (2003)
Congo, Republic of the
267,100 bbl/day (2005 est.)
700 bbl/day (2003 est.)
Congo, Democratic Republic of the
8,300 bbl/day (2003 est.)
Congo, Republic of the
5,200 bbl/day (2003 est.)
NA bbl/day
Congo, Democratic Republic of the
NA bbl/day
Congo, Republic of the
NA bbl/day
NA bbl/day
Congo, Democratic Republic of the
NA bbl/day
Congo, Republic of the
NA bbl/day
total: 18.6 years
male: 18.4 years
female: 18.9 years (2006 est.)
Congo, Democratic Republic of the
total: 16.2 years
male: 16 years
female: 16.4 years (2006 est.)
Congo, Republic of the
total: 16.6 years
male: 16.4 years
female: 16.9 years (2006 est.)
0 cu m (2003 est.)
Congo, Democratic Republic of the
0 cu m (2003 est.)
Congo, Republic of the
0 cu m (2003 est.)
0 cu m (2003 est.)
Congo, Democratic Republic of the
0 cu m (2003 est.)
Congo, Republic of the
0 cu m (2003 est.)
5 (2006)
Congo, Democratic Republic of the
1,778 (2006)
Congo, Republic of the
46 (2004)
$-17 million (2005 est.)
Congo, Republic of the
$493 million (2005 est.)
$402 million (2005 est.)
Congo, Democratic Republic of the
$7.328 billion (2005 est.)
Congo, Republic of the
$4.694 billion (2005 est.)','01f24fa0248e89713b41702c5f2ba3afb03fe60fd566e6ce9ed19d99a71e0304','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c2f6d2133666642a7b27e2941b6d5a9f70e146c807d8003295fbf21b4321463',2006,'CK','Cook Islands','communications',848,'low coral atolls in north; volcanic, hilly islands in
south
Coral Sea Islands
sand and coral reefs and islands (or cays)
3.1 children born/woman (2001 census)
self-governing parliamentary democracy
13.1% (2005)
defense is the responsibility of New Zealand, in
consultation with the Cook Islands and at its request
Coral Sea Islands
defense is the responsibility of Australia;
visited regularly by the Royal Australian Navy; Australia has
control over the activities of visitors
conventional long form: none
conventional short form: Cook Islands
former: Harvey Islands
Coral Sea Islands
conventional long form: Coral Sea Islands Territory
conventional short form: Coral Sea Islands
Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Coral Sea Islands
Oceania, islands in the Coral Sea, northeast of
Oceania
Coral Sea Islands
Oceania
NA
Coral Sea Islands
0 sq km
total: 236.7 sq km
land: 236.7 sq km
water: 0 sq km
Coral Sea Islands
total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and reefs scattered over a sea
area of about 780,000 sq km, with the Willis Islets the most
important
none (self-governing in free association with New
Zealand)
Coral Sea Islands
none (territory of Australia)
6,200 (2002)
1,500 (2002)
3,600 (2002)
.ck
NA
NA
NA
0 bbl/day (2003)
400 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 25.3 years
male: 24.7 years
female: 25.9 years (2001 census)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,456 (2006)
$26.67 million
$183.2 million','902c4fdec9156d4138b5a07e04145c15dc1598c608c226c3ba32aacda29d6dbb','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67abd5558e45eec6a8b7db124759a9d6a44225691da83f0db32c104b82a0e2da',2006,'CR','Costa Rica','communications',849,'coastal plains separated by rugged mountains including
over 100 volcanic cones, of which several are major volcanoes
Cote d''Ivoire
mostly flat to undulating plains; mountains in
northwest
2.24 children born/woman (2006 est.)
Cote d''Ivoire
4.5 children born/woman (2006 est.)
democratic republic
Cote d''Ivoire
republic; multiparty presidential regime established
1960
6.6% (2005 est.)
Cote d''Ivoire
13% in urban areas (1998)
conventional long form: Republic of Costa Rica
conventional short form: Costa Rica
local long form: Republica de Costa Rica
local short form: Costa Rica
Cote d''Ivoire
conventional long form: Republic of Cote d''Ivoire
conventional short form: Cote d''Ivoire
local long form: Republique de Cote d''Ivoire
local short form: Cote d''Ivoire
former: Ivory Coast
Central America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Nicaragua and Panama
Cote d''Ivoire
Western Africa, bordering the North Atlantic Ocean,
between Ghana and Liberia
Central America and the Caribbean
Cote d''Ivoire
Africa
1,080 sq km (2003)
Cote d''Ivoire
730 sq km (2003)
total: 51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Cote d''Ivoire
total: 322,460 sq km
land: 318,000 sq km
water: 4,460 sq km
chief of mission: Ambassador Tomas DUENAS
chancery: 2114 S Street NW, Washington, DC 20008
telephone: [1] (202) 234-2945
FAX: [1] (202) 265-4795
consulate(s) general: Atlanta, Chicago, Hammond (temporary location
in Louisiana), Houston, Los Angeles, Miami, New York, San Juan
(Puerto Rico), Tampa (temporarily closed), Washington, DC
consulate(s): San Francisco
Cote d''Ivoire
chief of mission: Ambassador Daouda DIABATE
chancery: 3421 Massachusetts Avenue NW, Washington, DC 20007
telephone: [1] (202) 797-0300
FAX: [1] (202) 244-3088
1,388,500 (2005)
Cote d''Ivoire
257,900 (2004)
1.101 million (2005)
Cote d''Ivoire
2.19 million (2005)
1 million (2005)
Cote d''Ivoire
160,000 (2005)
.cr
Cote d''Ivoire
.ci
0.6% (2003 est.)
Cote d''Ivoire
7% (2003 est.)
12,000 (2003 est.)
Cote d''Ivoire
570,000 (2003 est.)
900 (2003 est.)
Cote d''Ivoire
47,000 (2003 est.)
46.5 (2000)
Cote d''Ivoire
45.2 (1998)
0 bbl/day (2003)
Cote d''Ivoire
32,900 bbl/day (2005 est.)
40,000 bbl/day (2003 est.)
Cote d''Ivoire
20,000 bbl/day (2003 est.)
NA bbl/day
Cote d''Ivoire
NA bbl/day
NA bbl/day
Cote d''Ivoire
NA bbl/day
total: 26.4 years
male: 26 years
female: 26.9 years (2006 est.)
Cote d''Ivoire
total: 19.2 years
male: 19.4 years
female: 18.9 years (2006 est.)
0 cu m (2003 est.)
Cote d''Ivoire
1.3 billion cu m (2003 est.)
0 cu m (2003 est.)
Cote d''Ivoire
1.3 billion cu m (2003 est.)
12,751 (2006)
Cote d''Ivoire
2,534 (2006)
19.6% of GDP (2005 est.)
Cote d''Ivoire
8.6% of GDP (2005 est.)
56.8% of GDP (2005 est.)
Cote d''Ivoire
64.5% of GDP (2005 est.)
$-955 million (2005 est.)
Cote d''Ivoire
$-193 million (2005 est.)
$2.313 billion (2005 est.)
Cote d''Ivoire
$1.42 billion (2005 est.)
refugees (country of origin): 8,266 (Colombia) (2005)
Cote d''Ivoire
refugees (country of origin): 70,402 (Liberia)
IDPs: 500,000-800,000 (2002 coup; most IDPs are in western regions)
(2005)
$19.38 billion (2005 est.)
Cote d''Ivoire
$16.57 billion (2005 est.)','04078857efcc31c3b78e5c98c47c3a1ddbba8c2c3963c3b78a3ebe7de7abfa94','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0190518dcf596be6e108190390e6752c7fc3ec0e80704c0b7204d72a0715302',2006,'HR','Croatia','communications',850,'geographically diverse; flat plains along Hungarian border,
low mountains and highlands near Adriatic coastline and islands
1.4 children born/woman (2006 est.)
presidential/parliamentary democracy
18% official rate; labor force surveys indicate unemployment
around 14% (2005 est.)
conventional long form: Republic of Croatia
conventional short form: Croatia
local long form: Republika Hrvatska
local short form: Hrvatska
former: People''s Republic of Croatia, Socialist Republic of Croatia
Southeastern Europe, bordering the Adriatic Sea, between
Bosnia and Herzegovina and Slovenia
Europe
110 sq km (2003)
total: 56,542 sq km
land: 56,414 sq km
water: 128 sq km
chief of mission: Ambassador Neven JURICA
chancery: 2343 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-5899
FAX: [1] (202) 588-8936
consulate(s) general: Chicago, Los Angeles, New York
1,889,500 (2005)
2.984 million (2005)
1,451,100 (2005)
.hr
less than 0.1% (2001 est.)
200 (2001 est.)
less than 10 (2001 est.)
29 (2001)
Czech Republic
27.3 (2003)
20,500 bbl/day (2005 est.)
90,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 40.3 years
male: 38.3 years
female: 42.1 years (2006 est.)
93.6 million bbl (1 January 2002)
24.72 billion cu m (1 January 2002)
1.85 billion cu m (2003 est.)
2.99 billion cu m (2003 est.)
1.08 billion cu m (2001 est.)
0 cu m (2001 est.)
18,825 (2006)
28.6% of GDP (2005 est.)
49.7% of GDP (2005 est.)
$-2.541 billion (2005 est.)
$8.8 billion (2005 est.)
IDPs: 12,600 (Croats and Serbs displaced in 1992-95 war)
(2005)
$34.94 billion (2005 est.)','7ece0cb5a50fcfa067bc1312cb4848084c905137ce9b55d930077d71255016e1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b46160a0e44c461e57fe9afe7c298ffdcea12cc2beff1b3dbbfe0bdf8ee46a98',2006,'CU','Cuba','communications',851,'mostly flat to rolling plains, with rugged hills and mountains
in the southeast
1.66 children born/woman (2006 est.)
Communist state
1.9% (2005 est.)
Moscow, for decades the key military supporter and supplier of
Cuba, cut off almost all military aid by 1993
Dhekelia
includes Dhekelia Garrison and Ayios Nikolaos Station
connected by a roadway
Europa Island
defense is the responsibility of France
European Union
In November 2004, the European Union heads of
government signed a "Treaty Establishing a Constitution for Europe"
that offers possibilities - with some limits - for increased defense
and security cooperation. If ratified, in a process that may take
some two years, this treaty will in effect make operational the
European Security and Defense Policy (ESDP) approved in the 2000
Nice Treaty. Despite limits of cooperation for some EU members,
development of a European military planning unit is likely to
continue. So is creation of a rapid-reaction military force and a
humanitarian aid system, which the planning unit will support.
France, Germany, Belgium, Netherlands, Luxembourg, and Italy
continue to press for wider coordination. The five-nation Eurocorps
- created in 1992 by France, Germany, Belgium, Spain, and Luxembourg
- has already deployed troops and police on peacekeeping missions to
Bosnia and Herzegovina, Macedonia, and the Democratic Republic of
Congo and assumed command of the International Security Assistance
Force (ISAF) in Afghanistan in August 2004. Eurocorps directly
commands the 5,000-man Franco-German Brigade, the Multinational
Command Support Brigade, and EUFOR, which took over from SFOR in
Bosnia in December 2004. Other troop contributions are under
national command - commitments to provide 67,100 troops were made at
the Helsinki EU session in 2000. Some 56,000 EU troops were actually
deployed in 2003. In August 2004, the new European Defense Agency,
tasked with promoting cooperative European defense capabilities,
began operations. In November 2004, the EU Council of Ministers
formally committed to creating thirteen 1,500-man "battle groups" by
the end of 2007, to respond to international crises on a rotating
basis. Twenty-two of the EU''s 25 nations have agreed to supply
troops. France, Italy, and the UK are to form the first three battle
groups in 2005, with Spain to follow. In May 2005, Norway, Sweden,
and Finland agreed to establish one of the battle groups, possibly
to include Estonian forces. The remaining groups are to be formed by
2007. (2005)
Falkland Islands (Islas Malvinas)
defense is the responsibility of
the UK
conventional long form: Republic of Cuba
conventional short form: Cuba
local long form: Republica de Cuba
local short form: Cuba
Caribbean, island between the Caribbean Sea and the North
Atlantic Ocean, 150 km south of Key West, Florida
Central America and the Caribbean
8,700 sq km (2003)
total: 110,860 sq km
land: 110,860 sq km
water: 0 sq km
none; note - Cuba has an Interests Section in the Swiss
Embassy, headed by Principal Officer Bernardo GUANCHE Hernandez;
address: Cuban Interests Section, Swiss Embassy, 2630 16th Street
NW, Washington, DC 20009; telephone: [1] (202) 797-8518; FAX: [1]
(202) 797-8521
849,900 (2005)
134,500 (2005)
190,000
note: private citizens are prohibited from buying computers or
accessing the Internet without special authorization; foreigners may
access the Internet in large hotels but are subject to firewalls;
some Cubans buy illegal passwords on the black market or take
advantage of public outlets, to access limited email and the
government-controlled "intranet" (2005)
.cu
less than 0.1% (2003 est.)
3,300 (2003 est.)
less than 200 (2003 est.)
72,000 bbl/day (2005 est.)
205,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 35.9 years
male: 35.2 years
female: 36.5 years (2006 est.)
532 million bbl (1 January 2002)
Czech Republic
15 million bbl (1 January 2006)
70.79 billion cu m (1 January 2002)
Czech Republic
3.964 billion cu m (1 January 2003)
704 million cu m (2004)
704 million cu m (2004)
0 cu m (2004)
Czech Republic
9.8 billion cu m (2004)
0 cu m (2004)
Czech Republic
1 million cu m (2001 est.)
2,234 (2006)
11.5% of GDP (2005 est.)
$49 million (2005 est.)
$2.618 billion (2005 est.)
$39.51 billion
current situation: Cuba is a source country for women and
children trafficked for the purposes of sexual exploitation and
forced child labor; Cuba is a major destination for sex tourism,
which largely caters to European, Canadian, and Latin American
tourists and involves large numbers of minors; there are reports
that Cuban women have been trafficked to Mexico for sexual
exploitation; forced labor victims also include children coerced
into working in commercial agriculture
tier rating: Tier 3 - Cuba does not fully comply with the minimum
standards for the elimination of trafficking and is not making
significant efforts to do so','d2438fed0f313911a33f61b0345a73fa2f8f95aeec2f07f56e71dacd1a016b28','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7924e6d0950f929daedfc2b23bc4d20c565af675a698d7e0e6004f4b7f439868',2006,'CY','Cyprus','communications',852,'central plain with mountains to north and south; scattered
but significant plains along southern coast
Czech Republic
Bohemia in the west consists of rolling plains,
hills, and plateaus surrounded by low mountains; Moravia in the east
consists of very hilly country
1.82 children born/woman (2006 est.)
Czech Republic
1.21 children born/woman (2006 est.)
republic
note: a separation of the two ethnic communities inhabiting the
island began following the outbreak of communal strife in 1963; this
separation was further solidified after the Turkish intervention in
July 1974 that followed a Greek junta-supported coup attempt gave
the Turkish Cypriots de facto control in the north; Greek Cypriots
control the only internationally recognized government; on 15
November 1983 Turkish Cypriot "President" Rauf DENKTASH declared
independence and the formation of a "Turkish Republic of Northern
Cyprus" (TRNC), which is recognized only by Turkey
Czech Republic
parliamentary democracy
Republic of Cyprus: 4% (2005 est.); north Cyprus: 5.6% (2004
est.)
Czech Republic
7.9% (2005)
conventional long form: Republic of Cyprus
conventional short form: Cyprus
local long form: Kypriaki Dimokratia/Kibris Cumhuriyeti
local short form: Kypros/Kibris
note: the Turkish Cypriot community (north Cyprus) refers to itself
as the "Turkish Republic of Northern Cyprus" (TRNC)
Czech Republic
conventional long form: Czech Republic
conventional short form: Czech Republic
local long form: Ceska Republika
local short form: Cesko
Middle East, island in the Mediterranean Sea, south of Turkey
Czech Republic
Central Europe, southeast of Germany
Middle East
Czech Republic
Europe
400 sq km (2003)
Czech Republic
240 sq km (2003)
total: 9,250 sq km (of which 3,355 sq km are in north Cyprus)
land: 9,240 sq km
water: 10 sq km
Czech Republic
total: 78,866 sq km
land: 77,276 sq km
water: 1,590 sq km
chief of mission: Ambassador Andreas KAKOURIS
chancery: 2211 R Street NW, Washington, DC 20008
telephone: [1] (202) 462-5772, 462-0873
FAX: [1] (202) 483-6710
consulate(s) general: New York
note: representative of the Turkish Cypriot community in the US is
Osman ERTUG; office at 1667 K Street NW, Washington, DC; telephone
[1] (202) 887-6198
Czech Republic
chief of mission: Ambassador Petr KOLAR
chancery: 3900 Spring of Freedom Street NW, Washington, DC 20008
telephone: [1] (202) 274-9100
FAX: [1] (202) 966-8540
consulate(s) general: Chicago, Los Angeles, New York
Republic of Cyprus: 420,000 (2005); north Cyprus: 86,228
(2002)
Czech Republic
3,217,300 (2005)
Republic of Cyprus: 718,800 (2005); north Cyprus: 143,178
(2002)
Czech Republic
11.776 million (2005)
298,000 (2005)
Czech Republic
5.1 million (2005)
.cy
Czech Republic
.cz
0.1% (2003 est.)
Czech Republic
less than 0.1% (2001 est.)
less than 1,000 (1999 est.)
Czech Republic
2,500 (2001 est.)
NA
Czech Republic
less than 10 (2001 est.)
Republic of Cyprus: 300 bbl/day (2005 est.)
Czech Republic
15,240 bbl/day (2005)
Republic of Cyprus: 52,000 bbl/day (2003 est.)
Czech Republic
202,000 bbl/day (2004 est.)
NA bbl/day
Czech Republic
182,000 bbl/day (2004)
NA bbl/day
Czech Republic
26,670 bbl/day (2001)
total: 34.9 years
male: 33.9 years
female: 35.9 years (2006 est.)
Czech Republic
total: 39.3 years
male: 37.5 years
female: 41.1 years (2006 est.)
0 cu m (2003 est.)
Czech Republic
133 million cu m (2003 est.)
0 cu m (2003 est.)
Czech Republic
9.623 billion cu m (2003 est.)
67,589 (2006)
Czech Republic
1,267,265 (2006)
Republic of Cyprus: 19.2% of GDP (2005 est.)
Czech Republic
26.4% of GDP (2005 est.)
Republic of Cyprus: 70.3% of GDP (2005 est.)
Czech Republic
25.9% of GDP (2005 est.)
Republic of Cyprus: $-962.3 million (2005 est.)
Czech Republic
$-2.496 billion (2005 est.)
Republic of Cyprus: $4.429 billion; north Cyprus $NA (2005
est.)
Czech Republic
$29.36 billion (2005 est.)
IDPs: 265,000 (both Turkish and Greek Cypriots; many
displaced for over 30 years) (2005)
Republic of Cyprus: $15.4 billion (2005 est.)
Czech Republic
$109.4 billion (2005 est.)
current situation: Cyprus is primarily a destination country
for a large number of women trafficked from Eastern and Central
Europe, the Philippines, and the Dominican Republic for the purpose
of sexual exploitation; traffickers continued to fraudulently
recruit victims for work as dancers in cabarets and nightclubs on
short-term "artiste" visas, for work in pubs and bars on employment
visas, or for illegal work on tourist or student visas; there were
credible reports of female domestic workers from India, Sri Lanka,
and the Philippines forced to work excessively long hours and denied
proper compensation
tier rating: Tier 2 Watch List - Cyprus does not fully comply with
the minimum standards for the elimination of trafficking and failed
to show evidence of increasing efforts to address its serious
trafficking for sexual exploitation problem; however, it is making
significant efforts to do so','aabb8b271498f9785521cca067658b4a951762e2e98a5eb88266a612291a3ca0','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b17bf82c4ba04d4679460d8fd94fc0438eda88f0c047e17058e645eecb3040b5',2006,'DK','Denmark','communications',853,'low and flat to gently rolling plains
1.74 children born/woman (2006 est.)
constitutional monarchy
5.7% (2005 est.)
conventional long form: Kingdom of Denmark
conventional short form: Denmark
local long form: Kongeriget Danmark
local short form: Danmark
Dhekelia
conventional long form: Dhekelia Sovereign Base Area
conventional short form: Dhekelia
Northern Europe, bordering the Baltic Sea and the North Sea,
on a peninsula north of Germany (Jutland); also includes two major
islands (Sjaelland and Fyn)
Dhekelia
on the southeast coast of Cyprus near Famagusta
Europe
Dhekelia
Middle East
4,490 sq km (2003)
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in the Baltic Sea and the rest
of metropolitan Denmark (the Jutland Peninsula, and the major
islands of Sjaelland and Fyn), but excludes the Faroe Islands and
chief of mission: Ambassador Friis Arne PETERSEN
chancery: 3200 Whitehaven Street NW, Washington, DC 20008
telephone: [1] (202) 234-4300
FAX: [1] (202) 328-1470
consulate(s) general: Chicago, New York
Dhekelia
none (overseas territory of the UK)
3.35 million (2005)
5.469 million (2005)
3,762,500 (2005)
.dk
0.2% (2003 est.)
5,000 (2003 est.)
less than 100 (2003 est.)
23.2 (2002)
376,900 bbl/day (2003)
188,300 bbl/day (2003 est.)
195,000 bbl/day (2001)
332,100 bbl/day (2001)
total: 39.8 years
male: 38.9 years
female: 40.7 years (2006 est.)
1.23 billion bbl (1 January 2002)
73.51 billion cu m (1 January 2002)
7.965 billion cu m (2003 est.)
5.173 billion cu m (2003 est.)
0 cu m (2001 est.)
3.1 billion cu m (2001 est.)
2,415,530 (2006)
20.8% of GDP (2005 est.)
37% of GDP (2005 est.)
$7.753 billion (2005 est.)
$34.03 billion (2005 est.)
$243.4 billion (2005 est.)','3bc0fd9ec204cf487967e6bb1064fda2342b4b4f900ca9918080187c6c71da67','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d5620ec14b766de6dffaf8ab7449a55fc8c35992525a2ceaae77713a6ec29cd',2006,'DJ','Djibouti','communications',854,'coastal plain and plateau separated by central mountains
5.31 children born/woman (2006 est.)
republic
50% (2004 est.)
conventional long form: Republic of Djibouti
conventional short form: Djibouti
local long form: Republique de Djibouti/Jumhuriyat Jibuti
local short form: Djibouti/Jibuti
former: French Territory of the Afars and Issas, French Somaliland
Eastern Africa, bordering the Gulf of Aden and the Red Sea,
between Eritrea and Somalia
Africa
10 sq km (2003)
total: 23,000 sq km
land: 22,980 sq km
water: 20 sq km
chief of mission: Ambassador Roble OLHAYE Oudine
chancery: Suite 515, 1156 15th Street NW, Washington, DC 20005
telephone: [1] (202) 331-0270
FAX: [1] (202) 331-0302
11,100 (2004)
34,500 (2004)
9,000 (2005)
.dj
2.9% (2003 est.)
9,100 (2003 est.)
690 (2003 est.)
0 bbl/day (2003)
12,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.2 years
male: 18.7 years
female: 17.7 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,540 (2006)
degree of risk: high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A and E, and typhoid fever
vectorborne disease: malaria (2005)
refugees (country of origin): 17,331 (Somalia) (2005)
$702 million
current situation: Djibouti is a source, transit, and
destination country for women and children trafficked for the
purposes of sexual exploitation and possibly forced labor; small
numbers are trafficked from Ethiopia and Somalia for sexual
exploitation; economic migrants from these countries also fall
victim to trafficking upon reaching Djibouti City or the
Ethiopia-Djibouti trucking corridor; women and children from
neighboring countries reportedly transit Djibouti to Arab countries
and Somalia for ultimate use in forced labor or sexual exploitation
tier rating: Tier 2 Watch List - Djibouti does not fully comply with
the minimum standards for the elimination of trafficking; however,
it is making significant efforts to do so based partly on the
government''s commitments to undertake future action','56925a87a0dbe3de7d9348596f6228eb663d4d9d37ef6808cdaa7f57cbe3436c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('891fff3b6237c35a1525e4fa0bba4bc6da5ee09a3785d2054d50d40e3b03798d',2006,'DM','Dominica','communications',855,'rugged mountains of volcanic origin
1.94 children born/woman (2006 est.)
parliamentary democracy
23% (2000 est.)
conventional long form: Commonwealth of Dominica
conventional short form: Dominica
Caribbean, island between the Caribbean Sea and the North
Atlantic Ocean, about one-half of the way from Puerto Rico to
Central America and the Caribbean
NA
total: 754 sq km
land: 754 sq km
water: 0 sq km
chief of mission: Ambassador Judith Anne ROLLE, Third
Secretary
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 364-6781
FAX: [1] (202) 364-6791
consulate(s) general: New York
21,000 (2004)
41,800 (2004)
20,500 (2005)
.dm
NA
NA
NA
0 bbl/day (2003)
800 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 30.1 years
male: 29.8 years
female: 30.4 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
263 (2006)
$279 million','ff7e7104e5b92b34e57a1e0e27c21e0d9a8de58a23abffd49dcd72ed6df9f41b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('878b8f8e49373660ba1a2e90070d40283b9f70dbbed856c9cba6d005d48f622b',2006,'DO','Dominican Republic','communications',856,'rugged highlands and mountains with fertile
valleys interspersed
East Timor
mountainous
2.83 children born/woman (2006 est.)
East Timor
3.53 children born/woman (2006 est.)
representative democracy
East Timor
republic
17% (2005 est.)
East Timor
50% estimated; note - unemployment in urban areas reached
20%; data do not include underemployed (2001 est.)
conventional long form: Dominican Republic
conventional short form: The Dominican
local long form: Republica Dominicana
local short form: La Dominicana
East Timor
conventional long form: Democratic Republic of Timor-Leste
conventional short form: East Timor
local long form: Republika Demokratika Timor Lorosa''e [Tetum];
Republica Democratica de Timor-Leste [Portuguese]
local short form: Timor Lorosa''e [Tetum]; Timor-Leste [Portuguese]
former: Portuguese Timor
Caribbean, eastern two-thirds of the island of
Hispaniola, between the Caribbean Sea and the North Atlantic Ocean,
east of Haiti
East Timor
Southeastern Asia, northwest of Australia in the Lesser
Sunda Islands at the eastern end of the Indonesian archipelago; note
- East Timor includes the eastern half of the island of Timor, the
Oecussi (Ambeno) region on the northwest portion of the island of
Timor, and the islands of Pulau Atauro and Pulau Jaco
Central America and the Caribbean
East Timor
Southeast Asia
2,750 sq km (2003)
East Timor
1,065 sq km (est.)
total: 48,730 sq km
land: 48,380 sq km
water: 350 sq km
East Timor
total: 15,007 sq km
land: NA sq km
water: NA sq km
chief of mission: Ambassador Flavio Dario ESPINAL
Jacobo
chancery: 1715 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 332-6280
FAX: [1] (202) 265-8057
consulate(s) general: Anchorage, Boston, Chicago, Mayaguez (Puerto
Rico), Miami, New Orleans, New York, San Francisco, San Juan (Puerto
Rico)
East Timor
chief of mission: Ambassador (vacant); Charge d''Affaires
Constancio PINTO
chancery: 4201 Connecticut Avenue NW, Washington, DC 20008
telephone: 202 966-3202
FAX: 202 966-3205
consulate(s) general: New York
894,500 (2005)
East Timor
NA
3.623 million (2005)
East Timor
NA
938,300 (2005)
East Timor
1,000 (2004)
.do
East Timor
.tl; note - ICANN approved the change from .tp in January
2005
1.7% (2003 est.)
East Timor
NA
88,000 (2003 est.)
East Timor
NA
7,900 (2003 est.)
East Timor
NA
47.4 (1998)
East Timor
38 (2002 est.)
0 bbl/day (2003)
128,000 bbl/day (2003 est.)
129,900 bbl/day (2003)
NA bbl/day
total: 24.1 years
male: 24 years
female: 24.3 years (2006 est.)
East Timor
total: 20.8 years
male: 20.8 years
female: 20.7 years (2006 est.)
0 cu m (2003 est.)
300 million cu m (2003 est.)
NA cu m
91,895 (2006)
East Timor
68 (2006)
24.1% of GDP (2005 est.)
45.5% of GDP (2005 est.)
$-143 million (2005 est.)
$1.853 billion (2005 est.)
$18.15 billion (2005 est.)
East Timor
$349 million','ac39ed6b43b71e91b541fcaf2d1a99e54d413899d288b4623921dd3eead6b663','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50a9b74c0916cda2816064588d3c4bf6cbaae2b32cf5d783c4f33a0ab039655c',2006,'EC','Ecuador','communications',857,'coastal plain (costa), inter-Andean central highlands
(sierra), and flat to rolling eastern jungle (oriente)
2.68 children born/woman (2006 est.)
republic
10.7% official rate; but underemployment of 47% (2005 est.)
conventional long form: Republic of Ecuador
conventional short form: Ecuador
local long form: Republica del Ecuador
local short form: Ecuador
Western South America, bordering the Pacific Ocean at the
Equator, between Colombia and Peru
South America
8,650 sq km (2003)
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
chief of mission: Ambassador Luis Benigno GALLEGOS Chiriboga
chancery: 2535 15th Street NW, Washington, DC 20009
telephone: [1] (202) 234-7200
FAX: [1] (202) 667-3482
consulate(s) general: Chicago, Houston, Jersey City (New Jersey),
Los Angeles, Miami, New Orleans, New York, San Francisco,
Washington, DC
1,701,500 (2005)
6.246 million (2005)
616,000 (2005)
.ec
0.3% (2003 est.)
21,000 (2003 est.)
1,700 (2003 est.)
42
note: data are for urban households (2003)
493,200 bbl/day (2005 est.)
155,000 bbl/day (2003 est.)
NA bbl/day
387,000 bbl/day (2004 est.)
total: 23.6 years
male: 23.1 years
female: 24 years (2006 est.)
4.512 billion bbl (2005 est.)
9.769 billion cu m (2005)
50 million cu m (2003 est.)
50 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
19,027 (2006)
22.4% of GDP (2005 est.)
40.1% of GDP (2005 est.)
$-566 million (2005 est.)
$2.148 billion (2005 est.)
refugees (country of origin): 8,270 (Colombia) (2005)
$30.7 billion (2005 est.)','33c8f80baa9d2ef167666d5fcdf3d16610f48a4be54d810d85af9b73b654815b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b281851853a754e3c5375aeaf09cc9da630ab251199bdcd8f8f3b3020a62343d',2006,'EG','Egypt','communications',858,'vast desert plateau interrupted by Nile valley and delta
2.83 children born/woman (2006 est.)
republic
9.5% (2005 est.)
conventional long form: Arab Republic of Egypt
conventional short form: Egypt
local long form: Jumhuriyat Misr al-Arabiyah
local short form: Misr
former: United Arab Republic (with Syria)
Northern Africa, bordering the Mediterranean Sea, between
Libya and the Gaza Strip, and the Red Sea north of Sudan, and
includes the Asian Sinai Peninsula
Africa
34,220 sq km (2003)
total: 1,001,450 sq km
land: 995,450 sq km
water: 6,000 sq km
chief of mission: Ambassador Nabil FAHMY
chancery: 3521 International Court NW, Washington, DC 20008
telephone: [1] (202) 895-5400
FAX: [1] (202) 244-4319
consulate(s) general: Chicago, Houston, New York, San Francisco
10,396,100 (2005)
14,045,134 (2005)
5 million (2005)
.eg
less than 0.1% (2001 est.)
12,000 (2001 est.)
700 (2003 est.)
34.4 (2001)
700,000 bbl/day (2005 est.)
566,000 bbl/day (2003 est.)
NA bbl/day
134,000 bbl/day NA bbl/day
total: 24 years
male: 23.6 years
female: 24.3 years (2006 est.)
2.7 billion bbl (2005 est.)
1.9 trillion cu m (2005)
27 billion cu m (2003 est.)
27 billion cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
2,254 (2006)
17.2% of GDP (2005 est.)
104.7% of GDP (2005 est.)
$2.207 billion (2005 est.)
$21.39 billion (2005 est.)
refugees (country of origin): 70,245 (Palestinian Territories)
14,904 (Sudan) (2005)
$92.6 billion (2005 est.)
current situation: Egypt is a transit country for women
trafficked from Eastern Europe to Israel for the purpose of sexual
exploitation; these women generally arrive as tourists and are
subsequently trafficked through the Sinai Desert by Bedouin tribes;
men and women from sub-Saharan Africa and Asia are believed to be
trafficked through the Sinai Desert to Israel and Europe for labor
exploitation; some Egyptian children from rural areas are trafficked
within the country to work as domestic servants or laborers in the
agriculture industry
tier rating: Tier 2 Watch List - Egypt is placed on the Tier 2 Watch
List for its failure to show evidence of increasing efforts to
address trafficking over the past year, particularly in the area of
law enforcement','6e3a4682dc660c757a8ada84e6d1e5385d18be3affceaa1fb57646e2a33338de','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5dfbfaf31bc4b67b73d18e9bf9f52d857209d9749935e3dbaa7e3df9e526ebd',2006,'SV','El Salvador','communications',859,'mostly mountains with narrow coastal belt and central
plateau
3.12 children born/woman (2006 est.)
republic
6.5% official rate; but the economy has much
underemployment (2005 est.)
conventional long form: Republic of El Salvador
conventional short form: El Salvador
local long form: Republica de El Salvador
local short form: El Salvador
Central America, bordering the North Pacific Ocean,
between Guatemala and Honduras
Central America and the Caribbean
450 sq km (2003)
total: 21,040 sq km
land: 20,720 sq km
water: 320 sq km
chief of mission: Ambassador Rene Antonio LEON Rodriguez
chancery: 2308 California Street NW, Washington, DC 20008
telephone: [1] (202) 265-9671
FAX: [1] (202) 234-3834
consulate(s) general: Chicago, Dallas, Elizabeth (New Jersey),
Houston, Las Vegas, Los Angeles, Miami, New York (2), Nogales
(Arizona), Santa Ana (California), San Francisco, Washington, DC
consulate(s): Boston
971,500 (2005)
2.412 million (2005)
637,100 (2005)
.sv
0.7% (2003 est.)
29,000 (2003 est.)
2,200 (2003 est.)
52.5 (2001)
0 bbl/day (2003 est.)
40,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 21.8 years
male: 20.7 years
female: 22.9 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
4,682 (2006)
15.8% of GDP (2005 est.)
46.7% of GDP (2005 est.)
$-778 million (2005 est.)
$1.833 billion (2005 est.)
$16.52 billion (2005 est.)','535dc73d4efd6046b0987578948659e360d86924b2a6ba61c4cac9b57689658c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f148fae37a56574254b2c0706c7599110a1fe43655fe8b80e90254b9e837cc57',2006,'GQ','Equatorial Guinea','communications',860,'coastal plains rise to interior hills; islands are
volcanic
4.55 children born/woman (2006 est.)
republic
30% (1998 est.)
conventional long form: Republic of Equatorial
Western Africa, bordering the Bight of Biafra,
between Cameroon and Gabon
Africa
NA
total: 28,051 sq km
land: 28,051 sq km
water: 0 sq km
chief of mission: Ambassador Purificacion ANGUE
ONDO
chancery: 2020 16th Street NW, Washington, DC 20009
telephone: [1] (202) 518-5700
FAX: [1] (202) 518-5252
10,000 (2005)
96,900 (2005)
5,000 (2005)
.gq
3.4% (2001 est.)
5,900 (2001 est.)
370 (2001 est.)
420,000 bbl/day (2005 est.)
1,200 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.8 years
male: 18.2 years
female: 19.4 years (2006 est.)
563.5 million bbl (1 January 2002)
36.81 billion cu m (1 January 2002)
1.27 billion cu m (2003 est.)
1.27 billion cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
19 (2006)
39.9% of GDP (2005 est.)
6.4% of GDP
$264 million (2005 est.)
$2.103 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria (2005)
$7.644 billion (2005 est.)
current situation: Equatorial Guinea is a transit
and destination country for women and children trafficked for forced
labor, involuntary domestic servitude, and commercial sexual
exploitation from surrounding countries - primarily Benin, Nigeria,
Mali, and Cameroon; victims work in the agricultural and commercial
sectors of Malabo and Bata, where demand is high due to a booming
oil sector; children work as farmhands, street vendors, or household
servants; girls and women are also trafficked for commercial sexual
exploitation
tier rating: Tier 2 Watch List - Equatorial Guinea is placed on the
Tier 2 Watch List for its failure to provide adequate evidence of
concrete measures to address trafficking over the past year','667ea2e0293f30bbf6103a22e2d7b2a8c03f2750a35c4086a6444a0dd0158d43','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34d0453e7bb4d37c4137cf4687555ee8e57c60754b890a22597e343987aec351',2006,'ER','Eritrea','communications',861,'dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
5.08 children born/woman (2006 est.)
transitional government
note: following a successful referendum on independence for the
Autonomous Region of Eritrea on 23-25 April 1993, a National
Assembly, composed entirely of the People''s Front for Democracy and
Justice or PFDJ, was established as a transitional legislature; a
Constitutional Commission was also established to draft a
constitution; ISAIAS Afworki was elected president by the
transitional legislature; the constitution, ratified in May 1997,
did not enter into effect, pending parliamentary and presidential
elections; parliamentary elections had been scheduled in December
2001, but were postponed indefinitely; currently the sole legal
party is the People''s Front for Democracy and Justice (PFDJ)
NA%
conventional long form: State of Eritrea
conventional short form: Eritrea
local long form: Hagere Ertra
local short form: Ertra
former: Eritrea Autonomous Region in Ethiopia
Eastern Africa, bordering the Red Sea, between Djibouti and
Africa
210 sq km (2003)
total: 121,320 sq km
land: 121,320 sq km
water: 0 sq km
chief of mission: Ambassador GHIRMAI Ghebremariam
chancery: 1708 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 319-1991
FAX: [1] (202) 319-1304
consulate(s) general: Oakland (California)
37,700 (2005)
40,400 (2005)
70,000 (2005)
.er
2.7% (2003 est.)
60,000 (2003 est.)
6,300 (2003 est.)
0 bbl/day (2003 est.)
4,600 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.8 years
male: 17.6 years
female: 18 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,088 (2006)
25.1% of GDP (2005 est.)
$-291 million (2005 est.)
$30 million (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria is a high risk in some locations (2005)
IDPs: 59,000 (border war with Ethiopia from 1998-2000; most
IDPs are near the central border region) (2005)
$1.244 billion (2005 est.)','bedd9732ee35ea16216524013f8a83e26fa08e281f3c1e936e6ecd0ae8b7d4f4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('decb0d8b7531ee81743e24c042d40d27aad073d6b43564749df65f4250c3b273',2006,'EE','Estonia','communications',862,'marshy, lowlands; flat in the north, hilly in the south
1.4 children born/woman (2006 est.)
parliamentary republic
7.8% (2005)
conventional long form: Republic of Estonia
conventional short form: Estonia
local long form: Eesti Vabariik
local short form: Eesti
former: Estonian Soviet Socialist Republic
Eastern Europe, bordering the Baltic Sea and Gulf of
Finland, between Latvia and Russia
Europe
40 sq km (2003)
total: 45,226 sq km
land: 43,211 sq km
water: 2,015 sq km
note: includes 1,520 islands in the Baltic Sea
chief of mission: Ambassador Juri LUIK
chancery: 2131 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-0101
FAX: [1] (202) 588-0108
consulate(s) general: New York
442,000 (2005)
1.445 million (2005)
690,000 (2005)
.ee
1.1% (2001 est.)
7,800 (2003 est.)
less than 200 (2003 est.)
33 (2003)
6,000 bbl/day (2004)
60,000 bbl/day (2004)
54,000 bbl/day (2004)
0 bbl/day (2004)
total: 39.3 years
male: 35.8 years
female: 42.6 years (2006 est.)
0 cu m (2004)
1.42 billion cu m (2004)
1.42 billion cu m (2004)
European Union
297.8 billion cu m (2001)
0 cu m (2004)
European Union
78.1 billion cu m (2001)
52,241 (2006)
29.1% of GDP (2005 est.)
4.8% of GDP (2005 est.)
$-1.375 billion (2005 est.)
$1.948 billion (2005 est.)
$12.19 billion (2005 est.)','d4c833314d25be22eea820c166e931d8e71d72201bbc2cb37ef8384732e14395','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d703b404f38faabcf79e80f14e09efb19fe58d2bc3b27eba8c51eb7034b33c0',2006,'ET','Ethiopia','communications',863,'high plateau with central mountain range divided by Great
Rift Valley
Europa Island
low and flat
European Union
fairly flat along the Baltic and Atlantic coast;
mountainous in the central and southern areas
Falkland Islands (Islas Malvinas)
rocky, hilly, mountainous with
some boggy, undulating plains
5.22 children born/woman (2006 est.)
European Union
1.47 children born/woman (2006 est.)
Falkland Islands (Islas Malvinas)
NA children born/woman
federal republic
Falkland Islands (Islas Malvinas)
NA
NA%
European Union
9.4% (2005 est.)
Falkland Islands (Islas Malvinas)
full employment; labor shortage
(2001)
conventional long form: Federal Democratic Republic of
conventional short form: Ethiopia
local long form: Ityop''iya Federalawi Demokrasiyawi Ripeblik
local short form: Ityop''iya
former: Abyssinia, Italian East Africa
abbreviation: FDRE
Europa Island
conventional long form: none
conventional short form: Europa Island
local long form: none
local short form: Ile Europa
Falkland Islands (Islas Malvinas)
conventional long form: none
conventional short form: Falkland Islands (Islas Malvinas)
Eastern Africa, west of Somalia
Europa Island
Southern Africa, island in the Mozambique Channel,
about half way between southern Madagascar and southern Mozambique
European Union
Europe between Belarus, Ukraine, Russia, southeastern
Europe, and the North Atlantic Ocean
Falkland Islands (Islas Malvinas)
Southern South America, islands in
the South Atlantic Ocean, east of southern Argentina
Africa
Europa Island
Africa
European Union
Europe
Falkland Islands (Islas Malvinas)
South America
2,900 sq km (2003)
Europa Island
0 sq km
European Union
131,250 sq km (2003)
Falkland Islands (Islas Malvinas)
NA
total: 1,127,127 sq km
land: 1,119,683 sq km
water: 7,444 sq km
Europa Island
total: 28 sq km
land: 28 sq km
water: 0 sq km
European Union
total: 3,976,372 sq km
Falkland Islands (Islas Malvinas)
total: 12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East and West Falkland and
about 200 small islands
chief of mission: Ambassador Samuel ASSEFA
chancery: 3506 International Drive NW, Washington, DC 20008
telephone: [1] (202) 364-1200
FAX: [1] (202) 587-0195
consulate(s) general: Los Angeles
consulate(s): New York
European Union
chief of mission: Ambassador John BRUTON
chancery: 2300 M Street, NW, Washington, DC 20037
telephone: [1] (202) 862-9500
FAX: [1] (202) 429-1766
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)
610,300 (2005)
European Union
238,763,162 (2002)
Falkland Islands (Islas Malvinas)
2,400 (2002)
410,600 (2005)
European Union
314,644,700 (2002)
Falkland Islands (Islas Malvinas)
0 (2001)
113,000 (2005)
European Union
239,881,917 (2006)
Falkland Islands (Islas Malvinas)
1,900 (2002)
.et
European Union
.eu (effective 2005); note - see country entries of
member states for individual country codes
Falkland Islands (Islas Malvinas)
.fk
4.4% (2003 est.)
European Union
NA
Falkland Islands (Islas Malvinas)
NA
1.5 million (2003 est.)
European Union
NA
Falkland Islands (Islas Malvinas)
NA
120,000 (2003 est.)
European Union
NA
Falkland Islands (Islas Malvinas)
NA
30 (2000)
European Union
32 (2003 est.)
0 bbl/day (2003 est.)
European Union
3.424 million bbl/day (2001)
Falkland Islands (Islas Malvinas)
0 bbl/day (2003 est.)
27,000 bbl/day (2003 est.)
European Union
14.59 million bbl/day (2001)
Falkland Islands (Islas Malvinas)
200 bbl/day (2003 est.)
NA bbl/day
European Union
15.69 million bbl/day (2001)
Falkland Islands (Islas Malvinas)
NA bbl/day
NA bbl/day
European Union
5.322 million bbl/day (2001)
Falkland Islands (Islas Malvinas)
NA bbl/day
total: 17.8 years
male: 17.7 years
female: 17.9 years (2006 est.)
European Union
NA
214,000 bbl (1 January 2002)
European Union
7.294 billion bbl (1 January 2002)
24.92 billion cu m (1 January 2002)
European Union
3.256 trillion cu m (1 January 2002)
0 cu m (2003 est.)
European Union
239.2 billion cu m (2001)
Falkland Islands (Islas Malvinas)
0 cu m (2003 est.)
0 cu m (2003 est.)
European Union
465.6 billion cu m (2001)
Falkland Islands (Islas Malvinas)
0 cu m (2003 est.)
88 (2006)
European Union
22,000,414 (2004); note - sum of individual country
Internet hosts
Falkland Islands (Islas Malvinas)
103 (2006)
21.9% of GDP (2005 est.)
European Union
19.6% of GDP (2005 est.)
106.2% of GDP
$-844 million (2005 est.)
European Union
$NA
$1.226 billion (2005 est.)
European Union
$NA
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, typhoid fever, and hepatitis E
vectorborne diseases: malaria and cutaneous leishmaniasis are high
risks in some locations
respiratory disease: meningococcal meningitis
animal contact disease: rabies
water contact disease: schistosomiasis (2005)
refugees (country of origin): 90,451 (Sudan) 16,470
(Somalia) 8,719 (Eritrea)
IDPs: 132,000 (border war with Eritrea from 1998-2000 and ethnic
clashes in Gambela; most IDPs are in Tigray and Gambela Provinces)
(2005)
Gaza Strip
refugees (country of origin): 986,034 (Palestinian
Refugees (UNRWA)) (2005)
$8.819 billion (2005 est.)
European Union
$13.31 trillion (2005 est.)
Falkland Islands (Islas Malvinas)
NA','1d55ff243c28a3cec8d722d2a7834c7d19c62811d1b46af6c4dfb6b53d3c5fa5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe7c6caa148c72be12a0a328833f156d2e168774c54253ac3982fe29c92db6de',2006,'FO','Faroe Islands','communications',864,'rugged, rocky, some low peaks; cliffs along most of
coast
2.17 children born/woman (2006 est.)
NA
1% (October 2000)
defense is the responsibility of Denmark
conventional long form: none
conventional short form: Faroe Islands
local long form: none
local short form: Foroyar
Northern Europe, island group between the Norwegian
Sea and the North Atlantic Ocean, about one-half of the way from
Iceland to Norway
Europe
0 sq km
total: 1,399 sq km
land: 1,399 sq km
water: 0 sq km (some lakes and streams)
none (self-governing overseas administrative division
of Denmark)
23,800 (2005)
42,500 (2005)
33,000 (2005)
.fo
NA
NA
NA
0 bbl/day (2003 est.)
4,500 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 35 years
male: 34.7 years
female: 35.5 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
6,915 (2006)
NA','cfcdba88c4efc4775a70e11d5f9c4ea8c4e4d3ad2b3b7df35ea8ca3276c48d93','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb99708d24ee36b27d0a62925e816a040058ed205392b51cb2fd63aaebf89a0',2006,'FJ','Fiji','communications',865,'mostly mountains of volcanic origin
2.73 children born/woman (2006 est.)
republic
7.6% (1999)
conventional long form: Republic of the Fiji Islands
conventional short form: Fiji
local long form: Republic of the Fiji Islands/Matanitu ko Viti
local short form: Fiji/Viti
Oceania, island group in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Oceania
30 sq km (2003)
total: 18,270 sq km
land: 18,270 sq km
water: 0 sq km
chief of mission: Ambassador Jesoni VITUSAGAVULU
chancery: 2233 Wisconsin Avenue NW, Suite 240, Washington, DC 20007
telephone: [1] (202) 337-8320
FAX: [1] (202) 337-1996
102,000 (2003)
142,200 (2004)
61,000 (2004)
.fj
0.1% (2003 est.)
600 (2003 est.)
less than 200 (2003 est.)
0 bbl/day (2003 est.)
10,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 24.6 years
male: 24.1 years
female: 25 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
8,987 (2006)
$-465.8 million
$2.81 billion (2005 est.)','25482ff7d5e97928e7277ca158ba969904fa724d3d348d3742aa0f10c98d7b65','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cad3cc164fd0af01981ae92f5183f9f603a1152b9e7024aa46b511ef17034055',2006,'FI','Finland','communications',866,'mostly low, flat to rolling plains interspersed with lakes
and low hills
1.73 children born/woman (2006 est.)
republic
8.4% (2005 est.)
conventional long form: Republic of Finland
conventional short form: Finland
local long form: Suomen tasavalta/Republiken Finland
local short form: Suomi/Finland
Northern Europe, bordering the Baltic Sea, Gulf of Bothnia,
and Gulf of Finland, between Sweden and Russia
Europe
640 sq km (2003)
total: 338,145 sq km
land: 304,473 sq km
water: 33,672 sq km
chief of mission: Ambassador Pekka LINTU
chancery: 3301 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 298-5800
FAX: [1] (202) 298-6030
consulate(s) general: Los Angeles, New York
2.12 million (2005)
5.231 million (2005)
3.286 million (2005)
.fi; note - the IANA has assigned the ccTLD of .ax to the
Aland Islands
less than 0.1% (2003 est.)
1,500 (2003 est.)
less than 100 (2003 est.)
26.9 (2000)
9,013 bbl/day (2003 est.)
219,700 bbl/day (2003 est.)
318,300 bbl/day (2001)
101,000 bbl/day (2001)
total: 41.3 years
male: 39.7 years
female: 42.8 years (2006 est.)
0 cu m (2003 est.)
5.028 billion cu m (2003 est.)
4.567 billion cu m (2001 est.)
0 cu m (2001 est.)
1,633,614 (2006)
19.2% of GDP (2005 est.)
39.6% of GDP (2005 est.)
$5.043 billion (2005 est.)
$11.4 billion (2005 est.)
$184.2 billion (2005 est.)','d514d962ccb58ec62830e6a15d59aba48b7aa547428b7ba56e67e6c312bde3b6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51010638904536cdf2707bf1b4c9636e2c7d6482e1939739c587772ac5a0a93a',2006,'FR','France','communications',867,'mostly flat plains or gently rolling hills in north and west;
remainder is mountainous, especially Pyrenees in south, Alps in east
1.84 children born/woman (2006 est.)
republic
9.9% (2005 est.)
conventional long form: French Republic
conventional short form: France
local long form: Republique francaise
local short form: France
Western Europe, bordering the Bay of Biscay and English
Channel, between Belgium and Spain, southeast of the UK; bordering
the Mediterranean Sea, between Italy and Spain
Johnston Atoll
Oceania, atoll in the North Pacific Ocean 717 nm
(1328 km) southwest of Honolulu, Hawaii, about one-third of the way
from Hawaii to the Marshall Islands
Europe
26,000 sq km (2003)
total: 547,030 sq km
land: 545,630 sq km
water: 1,400 sq km
note: includes only metropolitan France; excludes the overseas
administrative divisions
chief of mission: Ambassador Jean-David LEVITTE
chancery: 4101 Reservoir Road NW, Washington, DC 20007
telephone: [1] (202) 944-6000
FAX: [1] (202) 944-6166
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, Miami, New Orleans, New York, San Francisco
35.7 million (2005)
48.058 million (2005)
29.521 million (2006)
.fr
0.4% (2003 est.)
120,000 (2003 est.)
less than 1,000 (2003 est.)
32.7 (1995)
76,300 bbl/day (2003 est.)
2.06 million bbl/day (2003 est.)
2.281 million bbl/day (2001)
409,600 bbl/day (2001)
total: 39.1 years
male: 37.6 years
female: 40.7 years (2006 est.)
144.3 million bbl (1 January 2002)
14.33 billion cu m (1 January 2002)
1.566 billion cu m (2003 est.)
43.74 billion cu m (2003 est.)
40.26 billion cu m (2001 est.)
1.725 billion cu m (2001 est.)
3,148,379 (2006)
19.6% of GDP (2005 est.)
66.2% of GDP (2005 est.)
$-38.78 billion (2005 est.)
$74.36 billion (2005 est.)
$2.055 trillion (2005 est.)','0072c99bdb514a9e33c96c41be1fe33b4e705f14c0cace98a89ba8d149a348a1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9faea2126c31c8b2853a333ece2be509bb58792232c7baceb5997e89820a4830',2006,'GF','French Guiana','communications',868,'low-lying coastal plains rising to hills and small
mountains
2.98 children born/woman (2006 est.)
NA
19.2% (December 2003)
defense is the responsibility of France
conventional long form: Department of Guiana
conventional short form: French Guiana
local long form: none
local short form: Guyane
Northern South America, bordering the North Atlantic
Ocean, between Brazil and Suriname
South America
20 sq km (2003)
total: 91,000 sq km
land: 89,150 sq km
water: 1,850 sq km
none (overseas department of France)
51,000 (2001)
98,000 (2004)
38,000 (2005)
.gf
NA
NA
NA
0 bbl/day (2003 est.)
6,600 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 28.6 years
male: 29.6 years
female: 27.4 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
106 (2006)
NA','162155bb56ec5a7e51b991ce633032ffe4605104ffebea9c8cca5be65bc91802','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4892277d5ae8aa3875938ce5f85c62a727a6b534807665e6be1b43f8d365cafc',2006,'PF','French Polynesia','communications',869,'mixture of rugged high islands and low islands with
reefs
French Southern and Antarctic Lands
volcanic
2.01 children born/woman (2006 est.)
NA
11.8% (1994)
defense is the responsibility of France
French Southern and Antarctic Lands
defense is the responsibility of
under certain acts of France, French Polynesia has
acquired autonomy in all areas except those relating to police and
justice, monetary policy, tertiary education, immigration, and
defense and foreign affairs; the duties of its president are
fashioned after those of the French prime minister
conventional long form: Overseas Lands of French
Polynesia
conventional short form: French Polynesia
local long form: Pays d''outre-mer de la Polynesie Francaise
local short form: Polynesie Francaise
former: French Colony of Oceania
French Southern and Antarctic Lands
conventional long form:
Territory of the French Southern and Antarctic Lands
conventional short form: French Southern and Antarctic Lands
local long form: Territoire des Terres Australes et Antarctiques
Francaises
local short form: Terres Australes et Antarctiques Francaises
abbreviation: TAAF
Oceania, archipelagoes in the South Pacific Ocean
about one-half of the way from South America to Australia
French Southern and Antarctic Lands
southeast of Africa, islands in
the southern Indian Ocean, about equidistant between Africa,
Antarctica, and Australia; note - French Southern and Antarctic
Lands include Ile Amsterdam, Ile Saint-Paul, Iles Crozet, and Iles
Kerguelen in the southern Indian Ocean, along with the
French-claimed sector of Antarctica, "Adelie Land"; the US does not
recognize the French claim to "Adelie Land"
Oceania
French Southern and Antarctic Lands
Antarctic Region
10 sq km (2003)
French Southern and Antarctic Lands
0 sq km
total: 4,167 sq km (118 islands and atolls)
land: 3,660 sq km
water: 507 sq km
French Southern and Antarctic Lands
total: 7,829 sq km
land: 7,829 sq km
water: 0 sq km
note: includes Ile Amsterdam, Ile Saint-Paul, Iles Crozet, and Iles
Kerguelen; excludes "Adelie Land" claim of about 500,000 sq km in
Antarctica that is not recognized by the US
none (overseas lands of France)
French Southern and Antarctic Lands
none (overseas territory of
France)
53,400 (2005)
87,000 (2005)
55,000 (2005)
.pf
French Southern and Antarctic Lands
.tf
NA
NA
NA
0 bbl/day (2003 est.)
4,800 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 27.9 years
male: 28.2 years
female: 27.5 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
14,047 (2006)
French Southern and Antarctic Lands
38 (2006)
NA','40d33de218b5e49c8aabfd2aa35670da544d117e13a187af799f8f608b0985ad','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fefd0a6f76fa59f303a1f23c015ad6e20fc43f68ddb7c2a2e864f24b27717351',2006,'GA','Gabon','communications',870,'narrow coastal plain; hilly interior; savanna in east and south
Gambia, The
flood plain of the Gambia River flanked by some low hills
Gaza Strip
flat to rolling, sand- and dune-covered coastal plain
4.74 children born/woman (2006 est.)
Gambia, The
5.3 children born/woman (2006 est.)
Gaza Strip
5.78 children born/woman (2006 est.)
republic; multiparty presidential regime
Gambia, The
republic
21% (1997 est.)
Gambia, The
NA%
Gaza Strip
31% (includes West Bank) (January-September 2005 avg.)
conventional long form: Gabonese Republic
conventional short form: Gabon
local long form: Republique gabonaise
local short form: Gabon
Gambia, The
conventional long form: Republic of The Gambia
conventional short form: The Gambia
Gaza Strip
conventional long form: none
conventional short form: Gaza Strip
local long form: none
local short form: Qita Ghazzah
Western Africa, bordering the Atlantic Ocean at the Equator,
between Republic of the Congo and Equatorial Guinea
Gambia, The
Western Africa, bordering the North Atlantic Ocean and
Africa
Gambia, The
Africa
Gaza Strip
Middle East
70 sq km (2003)
Gambia, The
20 sq km (2003)
Gaza Strip
150 sq km; note - includes West Bank (2003)
total: 267,667 sq km
land: 257,667 sq km
water: 10,000 sq km
Gambia, The
total: 11,300 sq km
land: 10,000 sq km
water: 1,300 sq km
Gaza Strip
total: 360 sq km
land: 360 sq km
water: 0 sq km
chief of mission: Ambassador Jules Marius OGOUEBANDJA
chancery: Suite 200, 2034 20th Street NW, Washington, DC 20009
telephone: [1] (202) 797-1000
FAX: [1] (202) 332-0668
consulate(s): New York
Gambia, The
chief of mission: Ambassador Dodou Bammy JAGNE
chancery: Suite 905, 1156 15th Street NW, Washington, DC 20005
telephone: [1] (202) 785-1379
FAX: [1] (202) 785-1430
39,100 (2005)
Gambia, The
44,000 (2005)
Gaza Strip
349,000 (includes West Bank) (2005)
649,800 (2005)
Gambia, The
247,500 (2005)
Gaza Strip
1.095 million (includes West Bank) (2005)
67,000 (2005)
Gambia, The
49,000 (2005)
Gaza Strip
243,000 (includes West Bank) (2005)
.ga
Gambia, The
.gm
Gaza Strip
.ps
8.1% (2003 est.)
Gambia, The
1.2% (2003 est.)
Gaza Strip
NA
48,000 (2003 est.)
Gambia, The
6,800 (2003 est.)
Gaza Strip
NA
3,000 (2003 est.)
Gambia, The
600 (2003 est.)
Gaza Strip
NA
268,900 bbl/day (2005 est.)
Gambia, The
0 bbl/day (2003 est.)
12,250 bbl/day (2003 est.)
Gambia, The
2,000 bbl/day (2003 est.)
NA bbl/day
Gambia, The
NA bbl/day
NA bbl/day
Gambia, The
NA bbl/day
total: 18.6 years
male: 18.4 years
female: 18.8 years (2006 est.)
Gambia, The
total: 17.7 years
male: 17.6 years
female: 17.8 years (2006 est.)
Gaza Strip
total: 15.8 years
male: 15.7 years
female: 16 years (2006 est.)
1.921 billion bbl (2005 est.)
33.98 billion cu m (2005)
90 million cu m (2003 est.)
Gambia, The
0 cu m (2003 est.)
90 million cu m (2003 est.)
Gambia, The
0 cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
322 (2006)
Gambia, The
14 (2006)
24.7% of GDP (2005 est.)
Gambia, The
20% of GDP (2005 est.)
33.6% of GDP (2005 est.)
$675 million (2005 est.)
Gambia, The
$-53 million (2005 est.)
$675.2 million (2005 est.)
Gambia, The
$82 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria (2005)
Gambia, The
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: dengue fever, malaria, Crimean-Congo
hemorrhagic fever, yellow fever are high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
$6.697 billion (2005 est.)
Gambia, The
$429 million (2005 est.)
Gaza Strip
NA','8250b7b20cb2d93114235d946169bfcbf5da01c8dadadd2413ed6c9e2a681139','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87c51d8f2d8d2abbf4b4caca30a16b77ddb77893f5519498f357af36a8d7b86c',2006,'GE','Georgia','communications',871,'largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhet''is Dablobi
(Kolkhida Lowland) opens to the Black Sea in the west; Mtkvari River
Basin in the east; good soils in river valley flood plains,
foothills of Kolkhida Lowland
1.42 children born/woman (2006 est.)
republic
12.6% (2004 est.)
a CIS peacekeeping force of Russian troops is deployed in
the Abkhazia region of Georgia together with a UN military observer
group; a Russian peacekeeping battalion is deployed in South Ossetia
conventional long form: none
conventional short form: Georgia
local long form: none
local short form: Sak''art''velo
former: Georgian Soviet Socialist Republic
Southwestern Asia, bordering the Black Sea, between Turkey
and Russia
Asia
4,690 sq km (2003)
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
chief of mission: Ambassador Vasil SIKHARULIDZE
chancery: 1101 15th Street NW, Suite 602, Washington, DC 20005
telephone: [1] (202) 387-2390
FAX: [1] (202) 393-4537
683,200 (2004)
1.459 million (2005)
175,600 (2005)
.ge
less than 0.1% (2001 est.)
3,000 (2003 est.)
less than 200 (2003 est.)
38 (2003)
1,982 bbl/day (2003)
13,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 37.7 years
male: 35.3 years
female: 40.1 years (2006 est.)
20 million cu m (2003 est.)
1.5 billion cu m (2005 est.)
1.5 billion cu m (2005 est.)
NA cu m
10,752 (2006)
24% of GDP (2005 est.)
$-625 million (2005 est.)
$474.2 million (2005 est.)
IDPs: 260,000 (displaced from Abkhazia and South Ossetia)
(2005)
$6.4 billion (2005 est.)','506cc4e163aa4d0f40cdaca5fff7a8853a81092646db7bf14dc8fd11c84c387a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6131e85484855029f667b8d6a2c0c8eaa827a0ca09263239372b4485412e422',2006,'DE','Germany','communications',872,'lowlands in north, uplands in center, Bavarian Alps in south
1.39 children born/woman (2006 est.)
federal republic
11.7% (2005 est.)
conventional long form: Federal Republic of Germany
conventional short form: Germany
local long form: Bundesrepublik Deutschland
local short form: Deutschland
former: German Empire, German Republic, German Reich
Central Europe, bordering the Baltic Sea and the North Sea,
between the Netherlands and Poland, south of Denmark
Europe
4,850 sq km (2003)
total: 357,021 sq km
land: 349,223 sq km
water: 7,798 sq km
chief of mission: Ambassador Klaus SCHARIOTH
chancery: 4645 Reservoir Road NW, Washington, DC 20007
telephone: [1] (202) 298-4000
FAX: [1] (202) 298-4249
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, Miami, New York, San Francisco
55.046 million (2005)
79.2 million (2005)
50.616 million (2006)
.de
0.1% (2001 est.)
43,000 (2001 est.)
less than 1,000 (2003 est.)
28.3 (2000)
158,700 bbl/day (2003)
2.677 million bbl/day (2003)
2.135 million bbl/day (2003)
12,990 bbl/day (2003)
total: 42.6 years
male: 41.3 years
female: 43.9 years (2006 est.)
395.8 million bbl (1 January 2004)
305.8 billion cu m (1 January 2004)
22.22 billion cu m (2003 est.)
93.88 billion cu m (2003 est.)
85.02 billion cu m (2003)
7.731 billion cu m (2003)
11,859,131 (2006)
17.1% of GDP (2005 est.)
67.3% of GDP (2005 est.)
$115.5 billion (2005 est.)
$101.7 billion (2005 est.)
$2.73 trillion (2005 est.)','898a66f5b6c63aca914e2214dc01993c0972ced0a91b2c23d2b1409dd8d76322','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37492003e06b90b4a0715cfee564de05614dd8f5357e8513e3d9e965c2fe5a8d',2006,'GH','Ghana','communications',873,'mostly low plains with dissected plateau in south-central area
3.99 children born/woman (2006 est.)
constitutional democracy
20% (1997 est.)
conventional long form: Republic of Ghana
conventional short form: Ghana
former: Gold Coast
Western Africa, bordering the Gulf of Guinea, between Cote
d''Ivoire and Togo
Africa
310 sq km (2003)
total: 239,460 sq km
land: 230,940 sq km
water: 8,520 sq km
chief of mission: Ambassador Fritz Kwabena POKU
chancery: 1156 15th St. NW #905, Washington, DC 20005
telephone: [1] (202) 785-1379
FAX: [1] (202) 785-1430
consulate(s) general: New York
321,500 (2005)
2.842 million (2005)
401,300 (2005)
.gh
3.1% (2003 est.)
350,000 (2003 est.)
30,000 (2003 est.)
30 (1999)
7,433 bbl/day (2003 est.)
39,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 19.9 years
male: 19.7 years
female: 20.1 years (2006 est.)
8.255 million bbl (1 January 2002)
23.79 billion cu m (1 January 2002)
0 cu m (2003 est.)
0 cu m (2003 est.)
380 (2006)
23.3% of GDP (2005 est.)
75.9% of GDP (2005 est.)
$-790 million (2005 est.)
$1.897 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are high risks in
some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
refugees (country of origin): 40,853 (Liberia) (2005)
$9.413 billion (2005 est.)','ae7e9ce07190fe218eeabdbd8da9c3b1ba4c488ca5b7d76489ef5e214b912b25','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc15deb8e10d39f57b49b181fbabbda7972d74b6352dff9609fc216a1ff32401',2006,'GI','Gibraltar','communications',874,'a narrow coastal lowland borders the Rock of Gibraltar
Glorioso Islands
low and flat
1.65 children born/woman (2006 est.)
NA
2% (2001 est.)
defense is the responsibility of the UK; the last British
regular infantry forces left Gibraltar in 1992, replaced by the
Royal Gibraltar Regiment
Glorioso Islands
defense is the responsibility of France
conventional long form: none
conventional short form: Gibraltar
Glorioso Islands
conventional long form: none
conventional short form: Glorioso Islands
local long form: none
local short form: Iles Glorieuses
Southwestern Europe, bordering the Strait of Gibraltar,
which links the Mediterranean Sea and the North Atlantic Ocean, on
the southern coast of Spain
Glorioso Islands
Southern Africa, group of islands in the Indian
Ocean, northwest of Madagascar
Europe
Glorioso Islands
Africa
NA
Glorioso Islands
0 sq km
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Glorioso Islands
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ile Glorieuse, Ile du Lys, Verte Rocks, Wreck Rock,
and South Rock
none (overseas territory of the UK)
24,512 (2002)
9,797 (2002)
6,200 (2002)
.gi
NA
NA
NA
0 bbl/day (2003 est.)
23,500 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 39.8 years
male: 39.4 years
female: 40.1 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
641 (2006)
NA','7dc10359f8fad8bbbbde6ff12dc8b6d3a97ec59906967ddeb3cf33169e255cea','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42640331563050d90c719259892e1c4e468069aeb99ec885d40179c588c78a44',2006,'GR','Greece','communications',875,'mostly mountains with ranges extending into the sea as
peninsulas or chains of islands
1.34 children born/woman (2006 est.)
parliamentary republic
9.9% (2005 est.)
conventional long form: Hellenic Republic
conventional short form: Greece
local long form: Elliniki Dhimokratia
local short form: Ellas or Ellada
former: Kingdom of Greece
Southern Europe, bordering the Aegean Sea, Ionian Sea, and
the Mediterranean Sea, between Albania and Turkey
Europe
14,530 sq km (2003)
total: 131,940 sq km
land: 130,800 sq km
water: 1,140 sq km
chief of mission: Ambassador Alexandros P. MALLIAS
chancery: 2221 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 939-1300
FAX: [1] (202) 939-1324
consulate(s) general: Boston, Chicago, Los Angeles, New York, San
Francisco, Tampa
consulate(s): Atlanta, Houston, New Orleans
6.303 million (2005)
10.043 million (2005)
3.8 million (2005)
.gr
0.2% (2001 est.)
9,100 (2001 est.)
less than 100 (2003 est.)
35.1 (2003)
5,805 bbl/day (2003 est.)
435,700 bbl/day (2005 est.)
468,300 bbl/day (2001)
84,720 bbl/day (2001)
total: 40.8 years
male: 39.7 years
female: 42 years (2006 est.)
4.5 million bbl (1 January 2002)
991.1 million cu m (1 January 2002)
27 million cu m (2003 est.)
2.34 billion cu m (2005 est.)
2.018 billion cu m (2001 est.)
0 cu m (2001 est.)
587,717 (2006)
24.6% of GDP (2005 est.)
106.8% of GDP (2005 est.)
$-17.86 billion (2005 est.)
$2.287 billion (2005 est.)
$209.7 billion (2005 est.)','1326292c051766d6b6ab7c9ac6898333fad429285e67cca96664327733456a6f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27f273f2374c7adb53aa918857d18e71c14d1da0c730f538e59cfa6939042781',2006,'GL','Greenland','communications',876,'flat to gradually sloping icecap covers all but a narrow,
mountainous, barren, rocky coast
2.4 children born/woman (2006 est.)
parliamentary democracy within a constitutional monarchy
10% (2000 est.)
defense is the responsibility of Denmark
conventional long form: none
conventional short form: Greenland
local long form: none
local short form: Kalaallit Nunaat
Northern North America, island between the Arctic Ocean
and the North Atlantic Ocean, northeast of Canada
Arctic Region
NA
Dhekelia
total: 130.8 sq km
note: area surrounds three Cypriot enclaves
total: 2,166,086 sq km
land: 2,166,086 sq km (410,449 sq km ice-free, 1,755,637 sq km
ice-covered) (2000 est.)
none (self-governing overseas administrative division of
Denmark)
25,300 (2002)
32,200 (2004)
38,000 (2005)
.gl
NA
100 (1999)
NA
0 bbl/day (2003 est.)
3,850 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 34 years
male: 35.3 years
female: 32.3 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
8,851 (2006)
NA','89ff61d5b032ce821c3136e75f3caa4f4601c65753fe1b34fefc475df833c1d5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2e97dfc2c64581f43fe901e87d499fc362e190eb5ac8417b6f40c42fb9c232b',2006,'GD','Grenada','communications',877,'volcanic in origin with central mountains
2.34 children born/woman (2006 est.)
parliamentary democracy
12.5% (2000)
conventional long form: none
conventional short form: Grenada
Caribbean, island between the Caribbean Sea and Atlantic
Ocean, north of Trinidad and Tobago
Central America and the Caribbean
NA
total: 344 sq km
land: 344 sq km
water: 0 sq km
chief of mission: Ambassador Denis G. ANTOINE
chancery: 1701 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 265-2561
FAX: [1] (202) 265-2468
consulate(s) general: New York
32,700 (2004)
43,300 (2004)
19,000 (2005)
.gd
NA
NA
NA
0 bbl/day (2003 est.)
1,800 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 21.7 years
male: 22.1 years
female: 21.2 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
17 (2006)
$454 million','9c536722523b18360711e8490d7cb15c4f01759777946bd8ae38828a39767634','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74adb2dba0de18959da20f7529bc6e429dece15f28b4ef819dd2aaac1289e6b3',2006,'GP','Guadeloupe','communications',878,'Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation; most of the
seven other islands are volcanic in origin
1.9 children born/woman (2006 est.)
NA
26.9% (2003)
defense is the responsibility of France
conventional long form: Department of Guadeloupe
conventional short form: Guadeloupe
local long form: Departement de la Guadeloupe
local short form: Guadeloupe
Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, southeast of Puerto Rico
Central America and the Caribbean
60 sq km (2003)
total: 1,780 sq km
land: 1,706 sq km
water: 74 sq km
note: Guadeloupe is an archipelago of nine inhabited islands,
including Basse-Terre, Grande-Terre, Marie-Galante, La Desirade,
Iles des Saintes (2), Saint-Barthelemy, Iles de la Petite Terre, and
Saint-Martin (French part of the island of Saint Martin)
none (overseas department of France)
210,000 (2001)
314,700 (2004)
79,000 (2005)
.gp
NA
NA
NA
0 bbl/day (2003 est.)
13,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 32.2 years
male: 31.3 years
female: 33.2 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
422 (2006)
NA','f6aa0f769ca6ce5da07b8adda0818d8db25b63f7f6755b2888a4da9ada816c25','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a411b738b3f9b4411fa06f96231551f303c84cc80bb76f49b7a5f33f9fec1487',2006,'GU','Guam','communications',879,'volcanic origin, surrounded by coral reefs; relatively flat
coralline limestone plateau (source of most fresh water), with steep
coastal cliffs and narrow coastal plains in north, low hills in
center, mountains in south
2.58 children born/woman (2006 est.)
NA
11.4% (2002 est.)
defense is the responsibility of the US
conventional long form: Territory of Guam
conventional short form: Guam
local long form: Guahan
local short form: Guahan
Oceania, island in the North Pacific Ocean, about
three-quarters of the way from Hawaii to the Philippines
Oceania
NA
total: 541.3 sq km
land: 541.3 sq km
water: 0 sq km
none (territory of the US)
84,134 (2001)
98,000 (2004)
79,000 (2004)
.gu
NA
NA
NA
0 bbl/day (2003 est.)
19,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 28.6 years
male: 28.3 years
female: 28.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
76 (2006)
$2.773 billion','64e96f67e8ab5a9639445a4ca36d697df53d13573bb26ca9dc30acfdc8a46869','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2261817460a2d7eea31f782529ac42d3e9b3f7c74aab3329a485b3292845def',2006,'GT','Guatemala','communications',880,'mostly mountains with narrow coastal plains and rolling
limestone plateau
3.82 children born/woman (2006 est.)
constitutional democratic republic
7.5% (2003 est.)
conventional long form: Republic of Guatemala
conventional short form: Guatemala
local long form: Republica de Guatemala
local short form: Guatemala
Central America, bordering the North Pacific Ocean,
between El Salvador and Mexico, and bordering the Gulf of Honduras
(Caribbean Sea) between Honduras and Belize
Central America and the Caribbean
1,300 sq km (2003)
total: 108,890 sq km
land: 108,430 sq km
water: 460 sq km
chief of mission: Ambassador Guillermo CASTILLO
chancery: 2220 R Street NW, Washington, DC 20008
telephone: [1] (202) 745-4952
FAX: [1] (202) 745-1908
consulate(s) general: Chicago, Denver, Houston, Los Angeles, Miami,
New York, Providence, San Francisco
1,132,100 (2004)
3,168,300 (2004)
756,000 (2005)
.gt
1.1% (2003 est.)
78,000 (2003 est.)
5,800 (2003 est.)
48.3 (2000)
22,300 bbl/day (2005 est.)
66,000 bbl/day (2003 est.)
NA bbl/day
3,104 bbl/day (2003)
total: 18.9 years
male: 18.5 years
female: 19.4 years (2006 est.)
263 million bbl (1 January 2002)
3.087 billion cu m (1 January 2002)
0 cu m (2003 est.)
0 cu m (2003 est.)
49,026 (2006)
15.6% of GDP (2005 est.)
25.9% of GDP (2005 est.)
$-1.341 billion (2005 est.)
$3.673 billion (2005 est.)
IDPs: 250,000 (government''s scorched-earth offensive in
1980s against indigenous people) 30,000 (Hurricane "Stan" October
2005) (2005)
$26.98 billion (2005 est.)','28f9b224bd1029d669e289fa590ae2bdaf80d26837fb625938333042df00ab51','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2150f8582bc897de50e39c24993ec5a34034a9450e411f41ad09bb60e99ad09',2006,'GG','Guernsey','communications',881,'mostly level with low hills in southwest
1.39 children born/woman (2006 est.)
NA
0.5% (1999 est.)
defense is the responsibility of the UK
conventional long form: Bailiwick of Guernsey
conventional short form: Guernsey
Western Europe, islands in the English Channel, northwest
of France
Europe
NA
total: 78 sq km
land: 78 sq km
water: 0 sq km
note: includes Alderney, Guernsey, Herm, Sark, and some other
smaller islands
none (British crown dependency)
55,100 (2004)
43,800 (2004)
36,000 (2005)
.gg
NA
NA
NA
total: 41.3 years
male: 40.4 years
female: 42.2 years (2006 est.)
1,245 (2006)
NA','2d249eaf1d6304347ae096ef239a27ced308d904ceacf8e262bb799aa8151dc3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7836458bb0d0118bbd29d458b0f1218f1bc89285c9cf8dd8b786350d0c47e044',2006,'GN','Guinea','communications',882,'generally flat coastal plain, hilly to mountainous interior
5.79 children born/woman (2006 est.)
republic
NA%
conventional short form: Equatorial Guinea
local long form: Republica de Guinea Ecuatorial/Republique de Guinee
equatoriale
local short form: Guinea Ecuatorial/Guinee equatoriale
former: Spanish Guinea
conventional long form: Republic of Guinea
conventional short form: Guinea
local long form: Republique de Guinee
local short form: Guinee
former: French Guinea
Western Africa, bordering the North Atlantic Ocean, between
Guinea-Bissau and Sierra Leone
Africa
950 sq km (2003)
total: 245,857 sq km
land: 245,857 sq km
water: 0 sq km
chief of mission: Ambassador (vacant); Charge d''Affaires
Ibrihama Sory TRAORE
chancery: 2112 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 986-4300
FAX: [1] (202) 478-3800
26,200 (2003)
189,000 (2005)
46,000 (2005)
.gn
3.2% (2003 est.)
140,000 (2003 est.)
9,000 (2003 est.)
40.3 (1994)
0 bbl/day (2003 est.)
8,400 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.7 years
male: 17.4 years
female: 17.9 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
367 (2006)
17.3% of GDP (2005 est.)
$-268.4 million (2005 est.)
$69.83 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are high risks in
some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis
aerosolized dust or soil contact disease: Lassa fever (2005)
refugees (country of origin): 127,256 (Liberia) 7,165 (Sierra
Leone) 7,064 (Cote d''Ivoire)
IDPs: 82,000 (cross-border incursions from Liberia, Sierra Leone,
Cote d''Ivoire) (2005)
$3.576 billion (2005 est.)','107e09cb83f4cb7aa586416be5dcb71c70fc1a708d526d5ed78a32cd3e40f6b7','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bf3952cf9d3244d91f5fcd7e9dcfeb3d967eaa9dc58e0eb3856ffafcacd6142',2006,'GW','Guinea-Bissau','communications',883,'mostly low coastal plain rising to savanna in east
4.86 children born/woman (2006 est.)
republic
NA%
conventional long form: Republic of Guinea-Bissau
conventional short form: Guinea-Bissau
local long form: Republica da Guine-Bissau
local short form: Guine-Bissau
former: Portuguese Guinea
Western Africa, bordering the North Atlantic Ocean,
between Guinea and Senegal
Africa
250 sq km (2003)
total: 36,120 sq km
land: 28,000 sq km
water: 8,120 sq km
chief of mission: Ambassador (vacant); note -
Guinea-Bissau does not have official representation in Washington,
DC; Guinea-Bissau''s representative in Washington is Henrique Adriano
DA SILVA, P.O. Box 33813, Washington, DC 20033, telephone:
(301)947-3958
10,600 (2003)
67,000 (2005)
26,000 (2005)
.gw
10% (2003 est.)
17,000 (2001 est.)
1,200 (2001 est.)
0 bbl/day (2003 est.)
2,450 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 19 years
male: 18.4 years
female: 19.6 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
5 (2006)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are high risks in
some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
$280 million (2005 est.)','784d572fc900b8538fcba6fcf9d8a41ba6c1cf4e88d9b6738b1431aa1bc56923','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8cad91803e00cef5777e67de623257cbdd56a165f556a584cb22939c80f9206',2006,'HT','Haiti','communications',884,'mostly rough and mountainous
4.94 children born/woman (2006 est.)
elected government
Holy See (Vatican City)
ecclesiastical
widespread unemployment and underemployment; more than
two-thirds of the labor force do not have formal jobs (2002 est.)
conventional long form: Republic of Haiti
conventional short form: Haiti
local long form: Republique d''Haiti/Repiblik d'' Ayiti
local short form: Haiti/Ayiti
Caribbean, western one-third of the island of Hispaniola,
between the Caribbean Sea and the North Atlantic Ocean, west of the
Central America and the Caribbean
920 sq km (2003)
total: 27,750 sq km
land: 27,560 sq km
water: 190 sq km
chief of mission: Ambassador Raymond JOSEPH (as of October
2005)
chancery: 2311 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 332-4090
FAX: [1] (202) 745-7215
consulate(s) general: Boston, Chicago, Miami, New York, San Juan
(Puerto Rico)
140,000 (2004)
Holy See (Vatican City)
5,120 (2005)
400,000 (2004)
Holy See (Vatican City)
NA
500,000 (2005)
Holy See (Vatican City)
93 (2000)
.ht
5.6% (2003 est.)
Holy See (Vatican City)
NA
280,000 (2003 est.)
Holy See (Vatican City)
NA
24,000 (2003 est.)
Holy See (Vatican City)
NA
0 bbl/day (2003 est.)
11,800 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.2 years
male: 17.8 years
female: 18.6 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
6 (2006)
Holy See (Vatican City)
45 (2006)
27.4% of GDP (2004 est.)
$23 million (2005 est.)
$100 million (2005 est.)
$4.321 billion (2005 est.)','0ade26be26a08fa77fc41281406205c68dc140fa5ca6a331c083873890591eab','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1e9d011c9c76b2d4ac108003473026a3e63240e98c366e52ec298a087749416',2006,'HM','Heard Island and McDonald Islands','communications',885,'Heard Island - 80% ice-covered,
bleak and mountainous, dominated by a large massif (Big Ben) and an
active volcano (Mawson Peak); McDonald Islands - small and rocky
Holy See (Vatican City)
urban; low hill
defense is the responsibility of
Australia; Australia conducts fisheries patrols
Holy See (Vatican City)
defense is the responsibility of Italy;
ceremonial and limited security duties performed by Pontifical Swiss
Guard
conventional long form: Territory
of Heard Island and McDonald Islands
conventional short form: Heard Island and McDonald Islands
abbreviation: HIMI
Holy See (Vatican City)
conventional long form: The Holy See (State
of the Vatican City)
conventional short form: Holy See (Vatican City)
local long form: Santa Sede (Stato della Citta del Vaticano)
local short form: Santa Sede (Citta del Vaticano)
islands in the Indian Ocean, about
two-thirds of the way from Madagascar to Antarctica
Holy See (Vatican City)
Southern Europe, an enclave of Rome (Italy)
Antarctic Region
Holy See (Vatican City)
Europe
0 sq km
Holy See (Vatican City)
0 sq km
total: 412 sq km
land: 412 sq km
water: 0 sq km
Holy See (Vatican City)
total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
none (territory of Australia)
Holy See (Vatican City)
chief of mission: Apostolic Nuncio
Archbishop Pietro SAMBI
chancery: 3339 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 333-7121
FAX: [1] (202) 337-4036
.hm
Holy See (Vatican City)
.va','a4414c193ad7be0234d4e8fc0ebd1967c500a500742bc3776166628c118bfff6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abf92cdc6095849c32a5f3634288d5402d47751daccea67465fe8ba5e0f18387',2006,'HN','Honduras','communications',886,'mostly mountains in interior, narrow coastal plains
3.59 children born/woman (2006 est.)
democratic constitutional republic
28% (2005 est.)
conventional long form: Republic of Honduras
conventional short form: Honduras
local long form: Republica de Honduras
local short form: Honduras
Central America, bordering the Caribbean Sea, between
Guatemala and Nicaragua and bordering the Gulf of Fonseca (North
Pacific Ocean), between El Salvador and Nicaragua
Central America and the Caribbean
800 sq km (2003)
total: 112,090 sq km
land: 111,890 sq km
water: 200 sq km
chief of mission: Ambassador Roberto FLORES Bermudez
chancery: Suite 4-M, 3007 Tilden Street NW, Washington, DC 20008
telephone: [1] (202) 966-7702
FAX: [1] (202) 966-9751
consulate(s) general: Atlanta, Chicago, Houston, Los Angeles, Miami,
New Orleans, New York, Phoenix, San Francisco
honorary consulate(s): Boston, Detroit, Jacksonville
494,400 (2005)
1.282 million (2005)
223,000 (2005)
.hn
1.8% (2003 est.)
63,000 (2003 est.)
4,100 (2003 est.)
55 (1999)
0 bbl/day (2003 est.)
37,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 19.5 years
male: 19.1 years
female: 19.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
3,973 (2006)
23.2% of GDP (2005 est.)
68.4% of GDP (2005 est.)
$-42.3 million (2005 est.)
$2.339 billion (2005 est.)
$7.812 billion (2005 est.)','0e954d220cc1fce75fe5e702eb91e6ad653dbcce2b463bf44d72ca1d3ea393ed','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('971410eb3232fed7646d8f2d568adb0149be0035b51db29339aaca2360f7baa8',2006,'HK','Hong Kong','communications',887,'hilly to mountainous with steep slopes; lowlands in north
Howland Island
low-lying, nearly level, sandy, coral island
surrounded by a narrow fringing reef; depressed central area
0.95 children born/woman (2006 est.)
limited democracy
5.5% (2005 est.)
defense is the responsibility of China
Howland Island
defense is the responsibility of the US; visited
annually by the US Coast Guard
conventional long form: Hong Kong Special Administrative
Region
conventional short form: Hong Kong
local long form: Xianggang Tebie Xingzhengqu
local short form: Xianggang
abbreviation: HK
Howland Island
conventional long form: none
conventional short form: Howland Island
Eastern Asia, bordering the South China Sea and China
Howland Island
Oceania, island in the North Pacific Ocean, about
half way between Hawaii and Australia
Southeast Asia
Howland Island
Oceania
20 sq km (1998 est.)
Howland Island
0 sq km
total: 1,092 sq km
land: 1,042 sq km
water: 50 sq km
Howland Island
total: 1.6 sq km
land: 1.6 sq km
water: 0 sq km
none (special administrative region of China)
3,794,600 (2005)
8.693 million (2005)
4,878,713 (2005)
.hk
0.1% (2003 est.)
2,600 (2003 est.)
less than 200 (2003 est.)
43.4 (1996)
0 bbl/day (2003 est.)
293,000 bbl/day (2004 est.)
NA bbl/day
NA bbl/day
total: 40.7 years
male: 40.4 years
female: 40.9 years (2006 est.)
0 cu m NA cu m
692.2 million cu m (2003 est.)
71.15 million cu m (2004 est.)
0 cu m (2004 est.)
800,834 (2006)
20.8% of GDP (2005 est.)
1.8% of GDP (2005 est.)
$19.7 billion (2005 est.)
$124.3 billion (2005 est.)
$172.6 billion (2005 est.)','46a31097aedc2af29d1c3b78f3c4ba858fd3efbb1b9ac9753461d8c6713c6c5c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cec0e670c62cc9a95a5250407b3e52e934580ac88a920b4a424a5eeb4585445',2006,'HU','Hungary','communications',888,'mostly flat to rolling plains; hills and low mountains on
the Slovakian border
1.32 children born/woman (2006 est.)
parliamentary democracy
7.2% (2005)
conventional long form: Republic of Hungary
conventional short form: Hungary
local long form: Magyar Koztarsasag
local short form: Magyarorszag
Central Europe, northwest of Romania
Europe
2,300 sq km (2003)
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
chief of mission: Ambassador Andras SIMONYI
chancery: 3910 Shoemaker Street NW, Washington, DC 20008
telephone: [1] (202) 362-6730
FAX: [1] (202) 966-8135
consulate(s) general: Los Angeles, New York
3.356 million (2005)
9.32 million (2005)
3.05 million (2005)
.hu
0.1% (2001 est.)
2,800 (2001 est.)
less than 100 (2001 est.)
24.96 (2002)
45,190 bbl/day (2005)
136,000 bbl/day (2004)
94,000 bbl/day (2004)
47,180 bbl/day (2001)
total: 38.7 years
male: 36.3 years
female: 41.4 years (2006 est.)
102 million bbl (1 January 2006)
33.98 billion cu m (1 January 2003)
3.1 billion cu m (2003 est.)
13 billion cu m (2004)
10.95 billion cu m (2004)
4 million cu m (2001 est.)
608,085 (2006)
23.1% of GDP (2005 est.)
58.9% of GDP (2005 est.)
$-7.963 billion (2005 est.)
$18.59 billion (2005 est.)
$106.4 billion (2005 est.)','27c638a1d8ae121c33f1b2a893da2673ef38d2b81b5a1efbede35eaf6aa0debb','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d35782c9a6e1911d085fb415eb3abf6daa301251134f6cbdf04a02b53da9eb5',2006,'IS','Iceland','communications',889,'mostly plateau interspersed with mountain peaks, icefields;
coast deeply indented by bays and fiords
Iles Eparses
Bassas da India: atoll, awash at high tide; shallow (15
m) lagoon
Europa Island, Glorioso Islands, Juan de Nova Island: low, flat, and
sandy
Tromelin Island: low, flat, sandy; likely volcanic seamount
1.92 children born/woman (2006 est.)
constitutional republic
2.1% (2005 est.)
under a 1951 bilateral agreement, Iceland''s defense was
provided by a US-manned Icelandic Defense Force (IDF) headquartered
in Keflavik; in October 2006, all US military forces in Iceland were
withdrawn; nonetheless, the US and Iceland signed a Joint
Understanding to strengthen their bilateral defense relationship,
including regular security consultations, military communications in
the event of national emergencies, annual bilateral exercises on
Icelandic territory, and future bilateral and NATO support to four
Iceland Air Defense System (IADS) radar sites
Iles Eparses
defense is the responsibility of France
conventional long form: Republic of Iceland
conventional short form: Iceland
local long form: Lydveldid Island
local short form: Island
Iles Eparses
conventional long form: none
conventional short form: Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island, Tromelin Island
local long form: none
local short form: Bassas da India, Ile Europa, Iles Glorieuses, Ile
Juan de Nova, Ile Tromelin
Northern Europe, island between the Greenland Sea and the
North Atlantic Ocean, northwest of the UK
Iles Eparses
Southern Africa, in the Indian Ocean
Bassas da India: atoll in the southern Mozambique Channel, about
half way from Madagascar to Mozambique
Europa Island: island in the Mozambique Channel, about half way
between southern Madagascar and southern Mozambique
Glorioso Islands: group of islands in the Indian Ocean, northwest of
Arctic Region
Iles Eparses
Africa
NA
total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
Iles Eparses
Bassas da India: total - 80 sq km; land - 0.2 sq km;
water - 79.8 sq km (lagoon)
Europa Island: total - 28 sq km; land - 28 sq km; water - 0 sq km
Glorioso Islands: total - 5 sq km; land - 5 sq km; water - 0 sq km
Juan de Nova Island: total - 4.4 sq km; land - 4.4 sq km; water - 0
sq km
Tromelin Island: total - 1 sq km; land - 1 sq km; water - 0 sq km
chief of mission: Ambassador Helgi AGUSTSSON
chancery: Suite 1200, 1156 15th Street NW, Washington, DC 20005-1704
telephone: [1] (202) 265-6653
FAX: [1] (202) 265-6656
consulate(s) general: New York
193,900 (2005)
304,000 (2005)
258,000 (2005)
.is
0.2% (2001 est.)
220 (2001 est.)
less than 100 (2003 est.)
0 bbl/day (2003 est.)
17,280 bbl/day (2003 est.)
15,470 bbl/day (2001)
0 bbl/day (2001)
total: 34.2 years
male: 33.8 years
female: 34.7 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
212,897 (2006)
28.7% of GDP (2005 est.)
31.6% of GDP (2005 est.)
$-2.607 billion (2005 est.)
$1.069 billion (2005 est.)
$13.05 billion (2005 est.)','ced2307d21b92a643325a47cc24d96aa58d3e8fcf845fc90a5474a10372ff7c5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8d4ab07e03e3ac60e39e5ddd6a75cf3d5ec883ad87a10aea2dee790885c0e48',2006,'IN','India','communications',890,'upland plain (Deccan Plateau) in south, flat to rolling plain
along the Ganges, deserts in west, Himalayas in north
Indian Ocean
surface dominated by counterclockwise gyre (broad,
circular system of currents) in the southern Indian Ocean; unique
reversal of surface currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-to-northeast
winds and currents, while high pressure over northern Asia from
cold, falling, winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean floor is dominated
by the Mid-Indian Ocean Ridge and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean Ridge, and Ninetyeast Ridge
2.73 children born/woman (2006 est.)
federal republic
8.9% (2005 est.)
conventional long form: Republic of India
conventional short form: India
local long form: Republic of India/Bharatiya Ganarajya
local short form: India/Bharat
Southern Asia, bordering the Arabian Sea and the Bay of
Bengal, between Burma and Pakistan
Indian Ocean
body of water between Africa, the Southern Ocean, Asia,
and Australia
Asia
Indian Ocean
Political Map of the World
558,080 sq km (2003)
total: 3,287,590 sq km
land: 2,973,190 sq km
water: 314,400 sq km
Indian Ocean
total: 68.556 million sq km
note: includes Andaman Sea, Arabian Sea, Bay of Bengal, Flores Sea,
Great Australian Bight, Gulf of Aden, Gulf of Oman, Java Sea,
Mozambique Channel, Persian Gulf, Red Sea, Savu Sea, Strait of
Malacca, Timor Sea, and other tributary water bodies
chief of mission: Ambassador Ranendra SEN
chancery: 2107 Massachusetts Avenue NW, Washington, DC 20008; note -
Consular Wing located at 2536 Massachusetts Avenue NW, Washington,
DC 20008
telephone: [1] (202) 939-7000
FAX: [1] (202) 265-4351
consulate(s) general: Chicago, Houston, New York, San Francisco
49.75 million (2005)
69,193,321 (2006)
60 million (2005)
.in
0.9% (2001 est.)
5.1 million (2001 est.)
310,000 (2001 est.)
32.5 (2000)
785,000 bbl/day (2005 est.)
2.32 million bbl/day (2003 est.)
2.09 million bbl/day
350,000 bbl/day
total: 24.9 years
male: 24.9 years
female: 24.9 years (2006 est.)
5.7 billion bbl (2005 est.)
853.5 billion cu m (2005)
27.1 billion cu m (2003 est.)
27.1 billion cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
1,543,289 (2006)
28.1% of GDP (2005 est.)
53.8% of GDP (federal and state debt combined) (2005 est.)
$-12.95 billion (2005 est.)
$136 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A and E,
and typhoid fever
vectorborne diseases: dengue fever, malaria, and Japanese
encephalitis are high risks in some locations
animal contact disease: rabies (2005)
refugees (country of origin): 92,394 (Tibet/China) 57,274 (Sri
Lanka) 9,761 (Afghanistan)
IDPs: 600,000 (resulting from 26 December 2004 tsunami); 500,000
(Jammu and Kashmir conflicts; most IDPs are Kashmiri Hindus) (2005)
$719.8 billion (2005 est.)
current situation: India is a source, destination, and transit
country for men, women, and children trafficked for the purposes of
forced or bonded labor and commercial sexual exploitation; the large
population of men, women, and children - numbering in the millions -
in debt bondage face involuntary servitude in brick kilns, rice
mills, and embroidery factories, while some children endure
involuntary servitude as domestic servants; internal trafficking of
women and girls for the purposes of commercial sexual exploitation
and forced marriage also occurs; the government estimates that 90
percent of India''s sex trafficking is internal; India is also a
destination for women and girls from Nepal and Bangladesh trafficked
for the purpose of commercial sexual exploitation; boys from
Afghanistan, Pakistan, and Bangladesh are trafficked through India
to the Gulf states for involuntary servitude as child camel jockeys;
Indian men and women migrate willingly to the Persian Gulf region
for work as domestic servants and low-skilled laborers, but some
later find themselves in situations of involuntary servitude
including extended working hours, nonpayment of wages, restrictions
on their movement by withholding of their passports or confinement
to the home, and physical or sexual abuse
tier rating: Tier 2 Watch List - India has been on the Tier 2 Watch
List since 2004 for its failure to show evidence of increasing
efforts to address trafficking in persons','2c4ca10aa2072cbf2a0c278dfdb67c5ee000dc3b58c1dbf961ec328191c40648','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f18c4c2c44b346a4d1672b5963633c1a3e5a6830bbca8501c9b59b6e10ce122',2006,'ID','Indonesia','communications',891,'mostly coastal lowlands; larger islands have interior
mountains
Iran
rugged, mountainous rim; high, central basin with deserts,
mountains; small, discontinuous plains along both coasts
2.4 children born/woman (2006 est.)
Iran
1.8 children born/woman (2006 est.)
republic
Iran
theocratic republic
11.8% (2005 est.)
Iran
11.2% (2004 est.)
conventional long form: Republic of Indonesia
conventional short form: Indonesia
local long form: Republik Indonesia
local short form: Indonesia
former: Netherlands East Indies; Dutch East Indies
Iran
conventional long form: Islamic Republic of Iran
conventional short form: Iran
local long form: Jomhuri-ye Eslami-ye Iran
local short form: Iran
former: Persia
Southeastern Asia, archipelago between the Indian Ocean
and the Pacific Ocean
Iran
Middle East, bordering the Gulf of Oman, the Persian Gulf, and
the Caspian Sea, between Iraq and Pakistan
Midway Islands
Oceania, atoll in the North Pacific Ocean, about
one-third of the way from Honolulu to Tokyo
Moldova
Eastern Europe, northeast of Romania
Southeast Asia
Iran
Middle East
45,000 sq km (2003)
Iran
76,500 sq km (2003)
total: 1,919,440 sq km
land: 1,826,440 sq km
water: 93,000 sq km
Iran
total: 1.648 million sq km
land: 1.636 million sq km
water: 12,000 sq km
chief of mission: Ambassador SUDJADNAN Parnohadiningrat
chancery: 2020 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 775-5200
FAX: [1] (202) 775-5365
consulate(s) general: Chicago, Houston, Los Angeles, New York, San
Francisco
Iran
none; note - Iran has an Interests Section in the Pakistani
Embassy; address: Iranian Interests Section, Pakistani Embassy, 2209
Wisconsin Avenue NW, Washington, DC 20007; telephone: [1] (202)
965-4990; FAX [1] (202) 965-1073
12.772 million (2005)
Iran
18.986 million (2005)
46.91 million (2005)
Iran
7.222 million (2005)
16 million (2005)
Iran
7.5 million (2005)
.id
Iran
.ir
0.1% (2003 est.)
Iran
less than 0.1% (2001 est.)
110,000 (2003 est.)
Iran
31,000 (2001 est.)
2,400 (2003 est.)
Iran
800 (2003 est.)
34.3 (2002)
Iran
43 (1998)
1.061 million bbl/day (2005 est.)
Iran
3.979 million bbl/day (2005 est.)
1.084 million bbl/day (2005 est.)
Iran
1.425 million bbl/day (2003 est.)
345,700 bbl/day (2005 est.)
Iran
NA bbl/day
431,500 bbl/day (2004 est.)
Iran
2.5 million bbl/day (2004 est.)
total: 26.8 years
male: 26.4 years
female: 27.3 years (2006 est.)
Iran
total: 24.8 years
male: 24.6 years
female: 25 years (2006 est.)
4.6 billion bbl (2005 est.)
Iran
133.3 billion bbl (2005 est.)
2.557 trillion cu m (2005)
Iran
26.62 trillion cu m (2005)
83.4 billion cu m (2005 est.)
Iran
79 billion cu m (2003 est.)
22.5 billion cu m (2005 est.)
Iran
79 billion cu m (2003 est.)
0 cu m (2005 est.)
Iran
4.92 billion cu m (2003 est.)
37.5 billion cu m (2005 est.)
Iran
3.4 billion cu m (2003 est.)
170,834 (2006)
Iran
5,242 (2006)
22% of GDP (2005 est.)
Iran
30.1% of GDP (2005 est.)
49.9% of GDP (2005 est.)
Iran
28.9% of GDP (2005 est.)
$2.016 billion (2005 est.)
Iran
$13.27 billion (2005 est.)
$34.58 billion (2005 est.)
Iran
$45.46 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A and E, and typhoid fever
vectorborne diseases: dengue fever, malaria, and chikungunya are
high risks in some locations
note: at present, H5N1 avian influenza poses a minimal risk; during
outbreaks among birds, rare cases could occur among US citizens who
have close contact with infected birds or poultry (2005)
IDPs: 570,000 (resulting from 26 December 2004 tsunami)
500,000 (government offensives against rebels in Aceh; most IDPs in
Aceh, Central Kalimantan, Maluku, and Central Sulawesi Provinces);
(2005)
Iran
refugees (country of origin): 952,802 (Afghanistan) 93,173
(Iraq) (2005)
$270 billion (2005 est.)
Iran
$181.2 billion (2005 est.)
current situation: Indonesia is a source, transit, and
destination country for women, children and men trafficked for the
purposes of sexual exploitation and forced labor; Indonesian victims
are trafficked to Malaysia, Saudi Arabia, Kuwait, UAE, Hong Kong,
Taiwan, Japan, South Korea, and Singapore; a significant number of
Indonesian women who go overseas each year to work as domestic
servants or "cultural performers" are subjected to conditions of
involuntary servitude and commercial sexual exploitation; to a
minimal extent, Indonesia is a destination for women from East Asia,
Europe, and South America who are trafficked for sexual
exploitation; there is extensive trafficking within Indonesia from
rural to urban metropolitan areas particularly for sexual
exploitation and involuntary domestic servitude
tier rating: Tier 2 Watch List - Indonesia is placed on the Tier 2
Watch List for its failure to provide evidence of increasing efforts
to combat trafficking
Iran
current situation: Iran is a source, transit, and destination
country for women and girls trafficked for the purposes of sexual
exploitation and involuntary servitude; according to foreign
observers, women and girls are trafficked to Pakistan, Turkey, the
Persian Gulf, and Europe for sexual exploitation, while boys from
Bangladesh, Pakistan, and Afghanistan are trafficked through Iran en
route to Persian Gulf states where they are ultimately forced to
work as camel jockeys, beggars, or laborers; Afghan women and girls
are trafficked to the country for forced marriages and sexual
exploitation; women and children are also trafficked internally for
the purposes of forced marriage, sexual exploitation, and
involuntary servitude
tier rating: Tier 3 - Iran is downgraded to Tier 3 after persistent,
credible reports of Iranian authorities punishing victims of
trafficking with beatings, imprisonment, and execution','86d435caa1a4a11e9e78987b6e257aec0c9168ed7dcd0067b5df8a8e56e1308e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('533ca56fc07511718d79d4a8d15ce5c922bd2c434cd905ee77a690cdd2c25270',2006,'IQ','Iraq','communications',892,'mostly broad plains; reedy marshes along Iranian border in
south with large flooded areas; mountains along borders with Iran
and Turkey
4.18 children born/woman (2006 est.)
transitional democracy
25% to 30% (2005 est.)
conventional long form: Republic of Iraq
conventional short form: Iraq
local long form: Al Jumhuriyah al Iraqiyah
local short form: Al Iraq
Middle East, bordering the Persian Gulf, between Iran and Kuwait
Middle East
35,250 sq km (2003)
total: 437,072 sq km
land: 432,162 sq km
water: 4,910 sq km
chief of mission: Ambassador Samir Shakir al-SUMAYDI
chancery: 1801 P Street, NW, Washington, DC 20036
telephone: [1] (202) 483-7500
FAX: [1] (202) 462-5066
1,034,200 (2004)
574,000 (2004)
36,000 (2005)
.iq
less than 0.1% (2001 est.)
less than 500 (2003 est.)
NA
2.093 million bbl/day; note - prewar production (in 2002) was
2.03 million bbl/day (2005 est.)
351,500 bbl/day (2005 est.)
NA bbl/day
1.42 million bbl/day (2005 est.)
total: 19.7 years
male: 19.6 years
female: 19.8 years (2006 est.)
112.5 billion bbl (2005 est.)
3.115 trillion cu m (2005)
1.5 billion cu m (2003 est.)
1.5 billion cu m (2003 est.)
0 cu m (2004 est.)
0 cu m (2004 est.)
5 (2006)
$-9.447 billion (2004 est.)
$9.161 billion (2005 est.)
refugees (country of origin): 22,711 (Palestinian Territories)
IDPs: 1 million (ongoing US-led war and Kurds'' subsequent return)
(2005)
$46.5 billion (2005 est.)','577ad374bbda1659495008dabd5ef36edf3fa18af1330e589954063a82dc448f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('029a30ab325396baa6b79c554ee731990780805728eea103e3ea6f38085204e6',2006,'IE','Ireland','communications',893,'mostly level to rolling interior plain surrounded by rugged
hills and low mountains; sea cliffs on west coast
1.86 children born/woman (2006 est.)
republic, parliamentary democracy
4.3% (2005 est.)
conventional long form: none
conventional short form: Ireland
local long form: none
local short form: Eire
Western Europe, occupying five-sixths of the island of
Ireland in the North Atlantic Ocean, west of Great Britain
Europe
NA
total: 70,280 sq km
land: 68,890 sq km
water: 1,390 sq km
chief of mission: Ambassador Noel FAHEY
chancery: 2234 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 462-3939
FAX: [1] (202) 232-5993
consulate(s) general: Boston, Chicago, New York, San Francisco
2.033 million (2005)
4.21 million (2005)
2.06 million (2005)
.ie
0.1% (2001 est.)
2,800 (2001 est.)
less than 100 (2003 est.)
35.9 (1996)
0 bbl/day (2003 est.)
175,600 bbl/day (2003 est.)
178,600 bbl/day (2001)
27,450 bbl/day (2001)
total: 34 years
male: 33.2 years
female: 34.8 years (2006 est.)
0 bbl (1 January 2002)
19.82 billion cu m (1 January 2002)
673 million cu m (2003 est.)
4.298 billion cu m (2003 est.)
3.384 billion cu m (2001 est.)
0 cu m (2001 est.)
238,191 (2006)
27% of GDP (2005 est.)
26.7% of GDP (2005 est.)
$-3.833 billion (2005 est.)
$869.3 million (2005 est.)
$188.4 billion (2005 est.)','0346dfbe651bba2ae49f117223a2ba95ff1307fadd03b54bf109865e4d0b5193','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2b100c9fb8da63e8dd932fc00fbb5ad7b3f5f190bd5caf0530e369fa8809f05',2006,'IM','Isle of Man','communications',894,'hills in north and south bisected by central valley
1.65 children born/woman (2006 est.)
parliamentary democracy
0.6% (2004 est.)
defense is the responsibility of the UK
Jan Mayen
defense is the responsibility of Norway
Jarvis Island
defense is the responsibility of the US; visited
annually by the US Coast Guard
conventional long form: none
conventional short form: Isle of Man
Western Europe, island in the Irish Sea, between Great
Britain and Ireland
Europe
0 sq km
total: 572 sq km
land: 572 sq km
water: 0 sq km
none (British crown dependency)
51,000 (1999)
NA
NA
.im
NA
NA
NA
total: 39.6 years
male: 38.4 years
female: 41 years (2006 est.)
290 (2006)
$2.26 billion','db5a2f223504a9a9b709c3df1641f9d7ecf45981229d2b45dd5591b0f8bf8b11','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27bc8415baf0a74f5ced94e18c7abbd2b828aa330e37127db2a596e576e92892',2006,'IL','Israel','communications',895,'Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
2.41 children born/woman (2006 est.)
parliamentary democracy
9% (2005 est.)
conventional long form: State of Israel
conventional short form: Israel
local long form: Medinat Yisra''el
local short form: Yisra''el
Middle East, bordering the Mediterranean Sea, between Egypt
and Lebanon
Middle East
1,940 sq km (2003)
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
chief of mission: Ambassador Salai MERIDOR
chancery: 3514 International Drive NW, Washington, DC 20008
telephone: [1] (202) 364-5500
FAX: [1] (202) 364-5607
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, Miami, New York, Philadelphia, San Francisco
2,936,300 (2005)
7.757 million (2005)
3.7 million (2006)
.il
0.1% (2001 est.)
3,000 (1999 est.)
100 (2001 est.)
34 (2005)
2,740 bbl/day (2003 est.)
270,100 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 29.6 years
male: 28.8 years
female: 30.5 years (2006 est.)
1.92 million bbl (1 January 2002)
38.94 billion cu m (1 January 2002)
200 million cu m (2003 est.)
200 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
1,251,881 (2006)
17.5% of GDP (2005 est.)
99.7% of GDP (2005 est.)
$2.385 billion (2005 est.)
$28.06 billion (2005 est.)
IDPs: 276,000 (Arab villagers displaced from homes in
northern Israel) (2005)
$114.3 billion (2005 est.)
current situation: Israel is a destination country for
low-skilled workers from Eastern Europe and Asia who migrate
voluntarily for contract labor in the construction, agriculture, and
health care industries, some of whom are subsequently subjected to
conditions of involuntary servitude; many labor recruitment agencies
in source countries and in Israel require workers to pay large
up-front fees that often lead to debt bondage and vulnerability to
forced labor; Israel is also a destination country for women
trafficked from Eastern Europe for the purpose of sexual exploitation
tier rating: Tier 2 Watch List - Israel is placed on the Tier 2
Watch List for its failure to provide evidence of increasing efforts
to address trafficking, namely the conditions of involuntary
servitude allegedly facing thousands of foreign migrant workers','b35b3614745cc814f93df8fd5b36c03552208dacfb2b4cb879217d7be24b27bf','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27c28d1f4afa37ad365408762989978c7180e6630e6217dd66905a86b14e0b3',2006,'IT','Italy','communications',896,'mostly rugged and mountainous; some plains, coastal lowlands
1.28 children born/woman (2006 est.)
republic
7.7% (2005 est.)
conventional long form: Italian Republic
conventional short form: Italy
local long form: Repubblica Italiana
local short form: Italia
former: Kingdom of Italy
Southern Europe, a peninsula extending into the central
Mediterranean Sea, northeast of Tunisia
Europe
27,500 sq km (2003)
total: 301,230 sq km
land: 294,020 sq km
water: 7,210 sq km
note: includes Sardinia and Sicily
chief of mission: Ambassador Giovanni CASTELLANETA
chancery: 3000 Whitehaven Street NW, Washington, DC 20008
telephone: [1] (202) 612-4400
FAX: [1] (202) 518-2151
consulate(s) general: Boston, Chicago, Houston, Miami, New York, Los
Angeles, Philadelphia, San Francisco
consulate(s): Detroit
25.049 million (2005)
72.2 million (2005)
28.87 million (2005)
.it
0.5% (2001 est.)
140,000 (2001 est.)
less than 1,000 (2003 est.)
36 (2000)
136,200 bbl/day (2003 est.)
1.874 million bbl/day (2003 est.)
2.158 million bbl/day (2001)
456,600 bbl/day (2001)
total: 42.2 years
male: 40.7 years
female: 43.7 years (2006 est.)
586.6 million bbl (1 January 2002)
226.5 billion cu m (1 January 2002)
13.55 billion cu m (2003 est.)
76.88 billion cu m (2003 est.)
54.78 billion cu m (2001 est.)
61 million cu m (2001 est.)
1,731,165 (2006)
20.6% of GDP (2005 est.)
108.8% of GDP (2005 est.)
$-26.38 billion (2005 est.)
$65.95 billion (2005 est.)
$1.71 trillion (2005 est.)','226b2696e59127a198153cc9983ef261db218c03c30f6d03f73d39cdd5a0e469','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0efec674c2768fad2c5e38288defb5cc1001d6f18e0ca580406344d9885797a9',2006,'JM','Jamaica','communications',897,'mostly mountains, with narrow, discontinuous coastal plain
Jan Mayen
volcanic island, partly covered by glaciers
2.41 children born/woman (2006 est.)
constitutional parliamentary democracy
11.5% (2005 est.)
conventional long form: none
conventional short form: Jamaica
Jan Mayen
conventional long form: none
conventional short form: Jan Mayen
Caribbean, island in the Caribbean Sea, south of Cuba
Jan Mayen
Northern Europe, island between the Greenland Sea and the
Norwegian Sea, northeast of Iceland
Central America and the Caribbean
Jan Mayen
Arctic Region
250 sq km (2002)
Jan Mayen
0 sq km
total: 10,991 sq km
land: 10,831 sq km
water: 160 sq km
Jan Mayen
total: 377 sq km
land: 377 sq km
water: 0 sq km
chief of mission: Ambassador Gordon SHIRLEY
chancery: 1520 New Hampshire Avenue NW, Washington, DC 20036
telephone: [1] (202) 452-0660
FAX: [1] (202) 452-0081
consulate(s) general: Miami, New York
342,000 (2005)
2.7 million (2005)
1.067 million (2005)
.jm
1.2% (2003 est.)
22,000 (2003 est.)
900 (2003 est.)
37.9 (2003)
0 bbl/day (2003 est.)
69,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 23 years
male: 22.4 years
female: 23.5 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,402 (2006)
32.4% of GDP (2005 est.)
128.7% of GDP (2005 est.)
$-974 million (2005 est.)
$2.17 billion (2005 est.)
$9.127 billion (2005 est.)
current situation: Jamaica is a source country for men,
women, and children trafficked for the purposes of sexual
exploitation and labor; information suggests that women from the
Dominican Republic and Eastern Europe are also trafficked to Jamaica
for sexual exploitation; women and children are trafficked
internally from rural to urban and tourist areas for sexual
exploitation; there may also be trafficking for domestic servitude
and forced labor
tier rating: Tier 2 Watch List - Jamaica is placed on the Tier 2
Watch List based on the determination that it is making significant
efforts to undertake future action','01cf348dee8984a7145364e57bd1476155c4cebd1b891612ebdd444e66353bd9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('639c8083d3607e2e1a94dbab4d4c7f086bc3a78f3e0e863f6115daa419df3d66',2006,'JP','Japan','communications',898,'mostly rugged and mountainous
Jarvis Island
sandy, coral island surrounded by a narrow fringing
reef
1.4 children born/woman (2006 est.)
constitutional monarchy with a parliamentary government
4.4% (2005 est.)
conventional long form: none
conventional short form: Japan
local long form: Nihon-koku/Nippon-koku
local short form: Nihon/Nippon
Jarvis Island
conventional long form: none
conventional short form: Jarvis Island
Eastern Asia, island chain between the North Pacific Ocean and
the Sea of Japan, east of the Korean Peninsula
Jarvis Island
Oceania, island in the South Pacific Ocean, about half
way between Hawaii and the Cook Islands
Asia
Jarvis Island
Oceania
25,920 sq km (2003)
Jarvis Island
0 sq km
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto), Daito-shoto,
Minami-jima, Okino-tori-shima, Ryukyu Islands (Nansei-shoto), and
Volcano Islands (Kazan-retto)
Jarvis Island
total: 4.5 sq km
land: 4.5 sq km
water: 0 sq km
chief of mission: Ambassador Ryozo KATO
chancery: 2520 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 238-6700
FAX: [1] (202) 328-2187
consulate(s) general: Anchorage, Atlanta, Boston, Chicago, Denver,
Detroit, Agana (Guam), Honolulu, Houston, Los Angeles, Miami, New
Orleans, New York, Portland (Oregon), San Francisco, Seattle
58.78 million (2005)
94.745 million (2005)
86.3 million (2005)
.jp
less than 0.1% (2003 est.)
12,000 (2003 est.)
500 (2003 est.)
37.9 (2000)
120,700 bbl/day (2003 est.)
5.578 million bbl/day (2003 est.)
5.449 million bbl/day (2001)
93,360 bbl/day (2001)
total: 42.9 years
male: 41.1 years
female: 44.7 years (2006 est.)
29.29 million bbl (1 January 2002)
39.64 billion cu m (1 January 2002)
2.814 billion cu m (2003 est.)
86.51 billion cu m (2003 est.)
77.73 billion cu m (2001 est.)
0 cu m (2001 est.)
28,321,846 (2006)
23.2% of GDP (2005 est.)
158% of GDP (2005 est.)
$165.6 billion (2005 est.)
$835.5 billion (2005 est.)
$4.664 trillion (2005 est.)','b8686bddfe078e2a3f7e9f693862b2c72249499b2a801cf729494a88e4e15ea4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b8db2e0a4a250695a56c060fb3605cf2a49c2e00fc65e7a47efef92b984b558',2006,'JE','Jersey','communications',899,'gently rolling plain with low, rugged hills along north coast
Johnston Atoll
mostly flat
1.58 children born/woman (2006 est.)
NA
0.9% (2004 est.)
defense is the responsibility of the UK
Johnston Atoll
defense is the responsibility of the US
Juan de Nova Island
defense is the responsibility of France
Kingman Reef
defense is the responsibility of the US
conventional long form: Bailiwick of Jersey
conventional short form: Jersey
Johnston Atoll
conventional long form: none
conventional short form: Johnston Atoll
Western Europe, island in the English Channel, northwest of
Europe
Johnston Atoll
Oceania
NA
Johnston Atoll
0 sq km
total: 116 sq km
land: 116 sq km
water: 0 sq km
Johnston Atoll
total: 2.63 sq km
land: 2.63 sq km
water: 0 sq km
none (British crown dependency)
73,900 (2001)
83,900 (2004)
27,000 (2005)
.je
NA
NA
NA
total: 41.4 years
male: 40.7 years
female: 42.1 years (2006 est.)
1,240 (2006)
NA','1876b0ea438be2bdcdf5723382001da0a8d5b9c165c345e15bb8b6557fcdb8f4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c11a0f41a1c91807bfa56226842f5483ff3902fca57e05ecf22947049b866e3',2006,'JO','Jordan','communications',900,'mostly desert plateau in east, highland area in west; Great
Rift Valley separates East and West Banks of the Jordan River
Juan de Nova Island
low and flat
2.63 children born/woman (2006 est.)
constitutional monarchy
12.5% official rate; unofficial rate is approximately 30%
(2004 est.)
conventional long form: Hashemite Kingdom of Jordan
conventional short form: Jordan
local long form: Al Mamlakah al Urduniyah al Hashimiyah
local short form: Al Urdun
former: Transjordan
Juan de Nova Island
conventional long form: none
conventional short form: Juan de Nova Island
local long form: none
local short form: Ile Juan de Nova
Middle East, northwest of Saudi Arabia
Juan de Nova Island
Southern Africa, island in the Mozambique
Channel, about one-third of the way between Madagascar and Mozambique
Middle East
Juan de Nova Island
Africa
750 sq km (2003)
Juan de Nova Island
0 sq km
total: 92,300 sq km
land: 91,971 sq km
water: 329 sq km
Juan de Nova Island
total: 4.4 sq km
land: 4.4 sq km
water: 0 sq km
chief of mission: Ambassador Karim Tawfiq KAWAR
chancery: 3504 International Drive NW, Washington, DC 20008
telephone: [1] (202) 966-2664
FAX: [1] (202) 966-3110
617,300 (2004)
1,594,500 (2004)
629,500 (2005)
.jo
less than 0.1% (2001 est.)
600 (2003 est.)
less than 500 (2003 est.)
36.4 (1997)
40 bbl/day (2004 est.)
103,000 bbl/day (2004 est.)
100,000 bbl/day (2004 est.)
0 bbl/day (2004 est.)
total: 23 years
male: 23.7 years
female: 22.4 years (2006 est.)
445,000 bbl (1 January 2002)
6.23 billion cu m (1 January 2002)
390 million cu m (2003 est.)
390 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
3,441 (2006)
20.2% of GDP (2005 est.)
79.1% of GDP (2005 est.)
$-1.613 billion (2005 est.)
$5.463 billion (2005 est.)
refugees (country of origin): 1,827,877 (Palestinian Refugees
(UNRWA))
IDPs: 168,000 (1967 Arab-Israeli War) (2005)
$11.51 billion (2005 est.)','13d032114b4a2a5b18f42166bd9d6940f907f34a741b99b034a3791dac17012a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85c24a110ad7ba4af2a5e7d0763b272d1f8f7f4a9ff58fcbf54ffa3873062941',2006,'KZ','Kazakhstan','communications',901,'extends from the Volga to the Altai Mountains and from
the plains in western Siberia to oases and desert in Central Asia
1.89 children born/woman (2006 est.)
republic; authoritarian presidential rule, with little
power outside the executive branch
8.1% (2005 est.)
conventional long form: Republic of Kazakhstan
conventional short form: Kazakhstan
local long form: Qazaqstan Respublikasy
local short form: Qazaqstan
former: Kazakh Soviet Socialist Republic
Central Asia, northwest of China; a small portion west of
the Ural River in eastern-most Europe
Asia
35,560 sq km (2003)
total: 2,717,300 sq km
land: 2,669,800 sq km
water: 47,500 sq km
chief of mission: Ambassador Kanat B. SAUDABAYEV
chancery: 1401 16th Street NW, Washington, DC 20036
telephone: [1] (202) 232-5488
FAX: [1] (202) 232-5845
consulate(s): New York
2.5 million (2004)
4.955 million (2005)
400,000 (2005)
.kz
0.2% (2001 est.)
16,500 (2001 est.)
less than 200 (2003 est.)
31.5 (2003)
1.3 million bbl/day (2005 est.)
221,000 bbl/day (2003 est.)
47,000 bbl/day (2003)
890,000 bbl/day (2003)
total: 28.8 years
male: 27.2 years
female: 30.5 years (2006 est.)
26 billion bbl (1 January 2004)
3 trillion cu m (1 January 2004)
18.5 billion cu m (2004 est.)
15.2 billion cu m (2004 est.)
NA cu m
Korea, South
21.11 billion cu m (2003 est.)
4.1 billion cu m (2004 est.)
Korea, South
0 cu m (2003 est.)
21,187 (2006)
26.5% of GDP (2005 est.)
10.5% of GDP (2005 est.)
$-485.7 million (2005 est.)
$7.07 billion (2005 est.)
refugees (country of origin): 13,684 (Russia) (2005)
$47.39 billion (2005 est.)','dfdbb7e99d9ce90899b840615c3a50694f9f0429f1939ae54aee858b089fc9af','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe1881104942f81dfa3e80e46dae5f5f46a2916ec587dc649be6ed7851f670e3',2006,'KE','Kenya','communications',902,'low plains rise to central highlands bisected by Great Rift
Valley; fertile plateau in west
Kingman Reef
low and nearly level
4.91 children born/woman (2006 est.)
republic
40% (2001 est.)
conventional long form: Republic of Kenya
conventional short form: Kenya
local long form: Republic of Kenya/Jamhuri y Kenya
local short form: Kenya
former: British East Africa
Kingman Reef
conventional long form: none
conventional short form: Kingman Reef
Eastern Africa, bordering the Indian Ocean, between Somalia
and Tanzania
Kingman Reef
Oceania, reef in the North Pacific Ocean, about half
way between Hawaii and American Samoa
Africa
Kingman Reef
Oceania
1,030 sq km (2003)
total: 582,650 sq km
land: 569,250 sq km
water: 13,400 sq km
Kingman Reef
total: 1 sq km
land: 1 sq km
water: 0 sq km
chief of mission: Ambassador Leonard NGAITHE
chancery: 2249 R Street NW, Washington, DC 20008
telephone: [1] (202) 387-6101
FAX: [1] (202) 462-3829
consulate(s) general: Los Angeles
281,800 (2005)
4.612 million (2005)
1,054,900 (2005)
.ke
6.7% (2003 est.)
1.2 million (2003 est.)
150,000 (2003 est.)
44.5 (1997)
Korea, South
35.8 (2000)
0 bbl/day (2003 est.)
52,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.2 years
male: 18.1 years
female: 18.3 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
13,274 (2006)
17% of GDP (2005 est.)
Korea, South
29.3% of GDP (2005 est.)
50.2% of GDP (2005 est.)
Korea, South
20% of GDP (2005 est.)
$-1.543 billion (2005 est.)
$1.799 billion (2005 est.)
Korea, South
$210.4 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria is a high risk in some locations
water contact disease: schistosomiasis (2005)
refugees (country of origin): 153,627 (Somalia) 12,595
(Ethiopia) 67,556 (Sudan)
IDPs: 360,000 (KANU attacks on opposition tribal groups in 1990s)
(2005)
Korea, North
IDPs: 50,000-250,000 (government repression and famine)
(2005)
$16.11 billion (2005 est.)
current situation: Kenya is a source, transit, and destination
country for men, women, and children trafficked for forced labor and
sexual exploitation; children are trafficked within the country for
domestic servitude, street vending, agricultural labor, and sexual
exploitation; men, women, and girls are trafficked to the Middle
East, other African nations, Western Europe, and North America for
domestic servitude, enslavement in massage parlors and brothels, and
manual labor; Chinese women trafficked for sexual exploitation
reportedly transit Nairobi and Bangladeshis may transit Kenya for
forced labor in other countries
tier rating: Tier 2 Watch List - Kenya is placed on the Tier 2 Watch
List due to a lack of evidence of increasing efforts to combat
severe forms of trafficking
Korea, North
current situation: North Korea is a source country for
men, women, and children trafficked for the purposes of forced labor
and sexual exploitation; North Korea''s own system of political
repression includes forced labor in a network of prison camps where
an estimated 150,000 to 200,000 persons are incarcerated; the
illegal status of North Koreans in China and other countries
increases their vulnerability to trafficking schemes and sexual and
physical abuse; North Koreans forcibly returned from China may be
subject to hard labor in prison camps operated by the government
tier rating: Tier 3 - North Korea does not fully comply with minimum
standards for the elimination of trafficking and is not making
significant efforts to do so','a1b00a58cfe752a05a7214ae0a290939af6f1b789366d1579bbbac4c108a183e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89b7cc71629a2668f139bc247594e50371a105c4a4697d9e9db35fd35d84eecf',2006,'KI','Kiribati','communications',903,'mostly low-lying coral atolls surrounded by extensive reefs
Korea, North
mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
Korea, South
mostly hills and mountains; wide coastal plains in west
and south
4.16 children born/woman (2006 est.)
Korea, North
2.1 children born/woman (2006 est.)
Korea, South
1.27 children born/woman (2006 est.)
republic
Korea, North
Communist state one-man dictatorship
Korea, South
republic
2% official rate; underemployment 70% (1992 est.)
Korea, North
NA%
Korea, South
3.7% (2005 est.)
Kiribati does not have military forces; defense assistance
is provided by Australia and NZ
Laos
Laos is one of the world''s least developed countries; the Lao
People''s Armed Forces are small, poorly funded, and ineffectively
resourced; there is little political will to allocate sparse funding
to the military, and the armed forces'' gradual degradation is likely
to continue; the massive drug production and trafficking industry
centered in the Golden Triangle makes Laos an important narcotics
transit country, and armed Wa and Chinese smugglers are active on
the Lao-Burma border (2005)
conventional long form: Republic of Kiribati
conventional short form: Kiribati
local long form: Republic of Kiribati
local short form: Kiribati
note: pronounced keer-ree-bahss
former: Gilbert Islands
Korea, North
conventional long form: Democratic People''s Republic of
Korea
conventional short form: North Korea
local long form: Choson-minjujuui-inmin-konghwaguk
local short form: Choson
abbreviation: DPRK
Korea, South
conventional long form: Republic of Korea
conventional short form: South Korea
local long form: Taehan-min''guk
local short form: Han''guk
abbreviation: ROK
Oceania, group of 33 coral atolls in the Pacific Ocean,
straddling the Equator; the capital Tarawa is about one-half of the
way from Hawaii to Australia; note - on 1 January 1995, Kiribati
proclaimed that all of its territory lies in the same time zone as
its Gilbert Islands group (GMT +12) even though the Phoenix Islands
and the Line Islands under its jurisdiction lie on the other side of
the International Date Line
Korea, North
Eastern Asia, northern half of the Korean Peninsula
bordering the Korea Bay and the Sea of Japan, between China and
South Korea
Korea, South
Eastern Asia, southern half of the Korean Peninsula
bordering the Sea of Japan and the Yellow Sea
Oceania
Korea, North
Asia
Korea, South
Asia
NA
Korea, North
14,600 sq km (2003)
Korea, South
8,780 sq km (2003)
total: 811 sq km
land: 811 sq km
water: 0 sq km
note: includes three island groups - Gilbert Islands, Line Islands,
Phoenix Islands
Korea, North
total: 120,540 sq km
land: 120,410 sq km
water: 130 sq km
Korea, South
total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Kiribati does not have an embassy in the US; there is an
honorary consulate in Honolulu
Korea, North
none; North Korea has a Permanent Mission to the UN in
New York
Korea, South
chief of mission: Ambassador LEE Tae-sik
chancery: 2450 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 939-5600
FAX: [1] (202) 387-0205
consulate(s) general: Agana (Guam), Atlanta, Boston, Chicago,
Honolulu, Houston, Los Angeles, New York, San Francisco, Seattle
4,500 (2002)
Korea, North
980,000 (2003)
Korea, South
23.745 million (2005)
600 (2004)
Korea, North
NA
Korea, South
38.342 million (2005)
2,000 (2004)
Korea, North
NA
Korea, South
33.9 million (2005)
.ki
Korea, North
.kp
Korea, South
.kr
NA
Korea, North
NA
Korea, South
less than 0.1% (2003 est.)
NA
Korea, North
NA
Korea, South
8,300 (2003 est.)
NA
Korea, North
NA
Korea, South
less than 200 (2003 est.)
0 bbl/day (2003 est.)
Korea, North
0 bbl/day (2004 est.)
Korea, South
0 bbl/day (2004)
200 bbl/day (2003 est.)
Korea, North
25,000 bbl/day (2003)
Korea, South
2.061 million bbl/day (2004)
NA bbl/day
Korea, North
22,000 bbl/day (2004 est.)
Korea, South
2.263 million bbl/day (2004)
NA bbl/day
Korea, North
NA bbl/day
Korea, South
645,200 bbl/day (2004)
total: 20.2 years
male: 19.8 years
female: 20.8 years (2006 est.)
Korea, North
total: 32 years
male: 30.7 years
female: 33.4 years (2006 est.)
Korea, South
total: 35.2 years
male: 34.2 years
female: 36.3 years (2006 est.)
0 cu m (2003 est.)
Korea, North
0 cu m (2003 est.)
Korea, South
0 cu m (2003 est.)
0 cu m (2003 est.)
Korea, North
0 cu m (2003 est.)
Korea, South
24.09 billion cu m (2003 est.)
42 (2006)
Korea, South
5,433,591 (2005)
$-19.87 million
Korea, South
$16.56 billion (2005 est.)
$76.4 million
Korea, North
NA
Korea, South
$801.2 billion (2005 est.)','db80d99ef8d356ad05b2c1af813be9f55b41b9b8c321c6db049ba80f1cf760c6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38837cbfdaa99da41e739e8a2daa37e9ebe86e345ac3b3c238bb1a15c365ee1f',2006,'KW','Kuwait','communications',904,'flat to slightly undulating desert plain
2.91 children born/woman (2006 est.)
constitutional hereditary emirate
2.2% (2004 est.)
conventional long form: State of Kuwait
conventional short form: Kuwait
local long form: Dawlat al Kuwayt
local short form: Al Kuwayt
Middle East, bordering the Persian Gulf, between Iraq and
Middle East
130 sq km (2003)
total: 17,820 sq km
land: 17,820 sq km
water: 0 sq km
chief of mission: Ambassador SALIM Abdallah al-Jabir al-Sabah
chancery: 2940 Tilden Street NW, Washington, DC 20008
telephone: [1] (202) 966-0702
FAX: [1] (202) 966-0517
510,300 (2005)
2.38 million (2005)
700,000 (2005)
.kw
0.12% (2001 est.)
NA
NA
2.418 million bbl/day (2005 est.)
305,000 bbl/day (2003 est.)
NA bbl/day
1.97 million bbl/day (2003)
total: 25.9 years
male: 28 years
female: 22.3 years (2006 est.)
96.5 billion bbl (2005 est.)
1.572 trillion cu m (2005)
8.3 billion cu m (2003 est.)
8.3 billion cu m (2003 est.)
0 cu m (2002 est.)
0 cu m (2002 est.)
2,310 (2006)
14.3% of GDP (2005 est.)
12.1% of GDP (2005 est.)
$26.92 billion (2005 est.)
$8.972 billion (2005 est.)
$52.76 billion (2005 est.)
current situation: Kuwait is a destination country for men
and women who migrate legally from South and Southeast Asia for
domestic or low-skilled labor, but are subjected to conditions of
involuntary servitude by employers in Kuwait including conditions of
physical and sexual abuse, non-payment of wages, confinement to the
home, and withholding of passports to restrict their freedom of
movement; Kuwait is reportedly a transit point for South and East
Asian workers recruited for low-skilled work in Iraq; some of these
workers are deceived as to the true location and nature of this
work, and others are subjected to conditions of involuntary
servitude in Iraq; in past years, Kuwait was also a destination
country for children exploited as camel jockeys, but this form of
trafficking appears to have ceased
tier rating: Tier 2 Watch List - Kuwait is placed on the Tier 2
Watch List because its efforts are based largely on pledges of
future actions
Laos
current situation: Laos is a source country for men and women
trafficked for the purposes of forced labor and sexual exploitation;
a significant number are economic migrants who are subjected to
commercial sexual exploitation or conditions of forced or bonded
labor in Thailand; to a lesser extent, Laos is a transit and
destination country for women who are trafficked for sexual
exploitation including a small number of victims from China and
Vietnam trafficked to work as street vendors and for sexual
exploitation in prostitution
tier rating: Tier 3 - Laos does not fully comply with the minimum
standards for the elimination of trafficking and is not making
significant efforts to do so','a8c29f6f8f0b058dc727ec52fa573c352a9c33ede13a84581305aa340a1d8794','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c06f7b98973cfb6071a2fb87d758d3808eeb9103066cef59becf4596fbda5a3',2006,'KG','Kyrgyzstan','communications',905,'peaks of Tien Shan and associated valleys and basins
encompass entire nation
Laos
mostly rugged mountains; some plains and plateaus
2.69 children born/woman (2006 est.)
Laos
4.68 children born/woman (2006 est.)
republic
Laos
Communist state
18% (2004 est.)
Laos
2.4% (2005 est.)
conventional long form: Kyrgyz Republic
conventional short form: Kyrgyzstan
local long form: Kyrgyz Respublikasy
local short form: Kyrgyzstan
former: Kirghiz Soviet Socialist Republic
Laos
conventional long form: Lao People''s Democratic Republic
conventional short form: Laos PDR or Laos
local long form: Sathalanalat Paxathipatai Paxaxon Lao
local short form: none
Central Asia, west of China
Laos
Southeastern Asia, northeast of Thailand, west of Vietnam
Asia
Laos
Southeast Asia
10,720 sq km (2003)
Laos
1,750 sq km (2003)
total: 198,500 sq km
land: 191,300 sq km
water: 7,200 sq km
Laos
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
chief of mission: Ambassador Zamira SYDYKOVA
chancery: 2360 Massachusetts Ave. NW, Washington, DC 20008
telephone: [1] (202) 338-5141
FAX: [1] (202) 386-7550
consulate(s): New York
Laos
chief of mission: Ambassador PHANTHONG Phommahaxay
chancery: 2222 S Street NW, Washington, DC 20008
telephone: [1] (202) 332-6416
FAX: [1] (202) 332-4923
438,200 (2005)
Laos
90,067 (2006)
541,700 (2005)
Laos
520,546 (2006)
280,000 (2005)
Laos
25,000 (2005)
.kg
Laos
.la
less than 0.1% (2001 est.)
Laos
0.1% (2003 est.)
3,900 (2003 est.)
Laos
1,700 (2003 est.)
less than 200 (2003 est.)
Laos
less than 200 (2003 est.)
29 (2001)
Laos
37 (1997)
1,990 bbl/day (2003)
Laos
0 bbl/day (2003 est.)
11,000 bbl/day (2003 est.)
Laos
2,950 bbl/day (2003 est.)
NA bbl/day
Laos
NA bbl/day
NA bbl/day
Laos
NA bbl/day
total: 23.6 years
male: 22.8 years
female: 24.5 years (2006 est.)
Laos
total: 18.9 years
male: 18.6 years
female: 19.2 years (2006 est.)
6 million cu m (2003 est.)
Laos
0 cu m (2003 est.)
1.5 billion cu m (2004 est.)
Laos
0 cu m (2003 est.)
1.5 billion cu m (2004 est.)
0 cu m (2004 est.)
18,928 (2006)
Laos
1,108 (2006)
12.6% of GDP (2005 est.)
$-134 million (2005 est.)
Laos
$-134 million (2005 est.)
$612.3 million (2005 est.)
Laos
$249 million (2005 est.)
$2.144 billion (2005 est.)
Laos
$2.523 billion (2005 est.)','7996c37edb9ed5477a34ebf46e59474275a70649eab0ab2f1007f6a9d1b2c9ee','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c0c9a1042b4f5700522cd8e264e87b72d97c09d16572fa2e8979db307dd0eb1',2006,'LV','Latvia','communications',906,'low plain
1.27 children born/woman (2006 est.)
parliamentary democracy
7.5% (2005 est.)
conventional long form: Republic of Latvia
conventional short form: Latvia
local long form: Latvijas Republika
local short form: Latvija
former: Latvian Soviet Socialist Republic
Eastern Europe, bordering the Baltic Sea, between Estonia and
Europe
200 sq km
note: land in Latvia is often too wet, and in need of drainage, not
irrigation; approximately 16,000 sq km or 85% of agricultural land
has been improved by drainage (2003)
total: 64,589 sq km
land: 63,589 sq km
water: 1,000 sq km
chief of mission: Ambassador Maris RIEKSTINS
chancery: 2306 Massachusetts Ave. NW, Washington, DC 20008
telephone: [1] (202) 328-2840
FAX: [1] (202) 328-2860
731,000 (2005)
1.872 million (2005)
1.03 million (2005)
.lv
0.6% (2001 est.)
7,600 (2001 est.)
less than 500 (2003 est.)
35 (2003)
0 bbl/day (2004)
47,000 bbl/day (2004)
47,000 bbl/day (2004)
0 bbl/day (2004)
total: 39.4 years
male: 36.3 years
female: 42.4 years (2006 est.)
0 cu m NA (2003)
1.76 billion cu m (2004 est.)
1.76 billion cu m (2004)
0 cu m (2004 est.)
65,858 (2006)
27.8% of GDP (2005 est.)
10.9% of GDP (2005 est.)
$-1.959 billion (2005 est.)
$2.361 billion (2005 est.)
$14.43 billion (2005 est.)','598bb0dab1623b96c2efa80daea1d8b7187419245ea5bdf212c4545b05c232be','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('331d1593e53f29a0a7400c3494c84974b390c0b9c4a7e5f2128d7423456fca65',2006,'LB','Lebanon','communications',907,'narrow coastal plain; El Beqaa (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
1.9 children born/woman (2006 est.)
republic
18% (1997 est.)
conventional long form: Lebanese Republic
conventional short form: Lebanon
local long form: Al Jumhuriyah al Lubnaniyah
local short form: Lubnan
former: Greater Lebanon
Middle East, bordering the Mediterranean Sea, between Israel
and Syria
Middle East
1,040 sq km (2003)
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
chief of mission: Ambassador (vacant)
chancery: 2560 28th Street NW, Washington, DC 20008
telephone: [1] (202) 939-6320
FAX: [1] (202) 939-6324
consulate(s) general: Detroit, New York, Los Angeles
990,000 (2005)
990,000 (2005)
700,000 (2005)
.lb
0.1% (2001 est.)
2,800 (2003 est.)
less than 200 (2003 est.)
0 bbl/day (2003 est.)
102,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 27.8 years
male: 26.7 years
female: 28.9 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
3,307 (2006)
18.4% of GDP (2005 est.)
180.5% of GDP (2005 est.)
$-4.239 billion (2005 est.)
$16.62 billion (2005 est.)
refugees (country of origin): 404,170 (Palestinian Refugees
(UNRWA))
IDPs: 300,000 (1975-90 civil war, Israeli invasions) (2005)
$20.7 billion (2005 est.)','003b87cb3290c84ba476960f71a07b9d7e82a6263ee70d8cd4be7f10b3ba3c1d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('289c2a005009040144074bfb15574d8ff63233f4a4ca7c09b2656136f247399d',2006,'LS','Lesotho','communications',908,'mostly highland with plateaus, hills, and mountains
3.28 children born/woman (2006 est.)
parliamentary constitutional monarchy
45% (2002)
the Lesotho Government in 1999 began an open debate on the
future structure, size, and role of the armed forces, especially
considering the Lesotho Defense Force''s (LDF) history of intervening
in political affairs
conventional long form: Kingdom of Lesotho
conventional short form: Lesotho
local long form: Kingdom of Lesotho
local short form: Lesotho
former: Basutoland
Southern Africa, an enclave of South Africa
Africa
30 sq km (2003)
total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
chief of mission: Ambassador Molelekeng E. RAPOLAKI
chancery: 2511 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 797-5533 through 5536
FAX: [1] (202) 234-6815
48,000 (2005)
245,100 (2005)
43,000 (2005)
.ls
28.9% (2003 est.)
320,000 (2003 est.)
29,000 (2003 est.)
63.2 (1995)
0 bbl/day (2003 est.)
1,400 bbl/day (2003)
NA bbl/day
NA bbl/day
total: 20.3 years
male: 19.7 years
female: 21 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
168 (2006)
29.9% of GDP (2005 est.)
$-92 million (2005 est.)
$573 million (2005 est.)
$1.362 billion (2005 est.)','3c46e1a9b652d6d15330ebe20b87ef98894f7b1c437a599809a0b4b47f1f528f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e32b04624f6499f0c2b5b3f36b32ef51b8ced3605c0dc6c7452e3a5139796e6',2006,'LR','Liberia','communications',909,'mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
6.02 children born/woman (2006 est.)
republic
85% (2003 est.)
conventional long form: Republic of Liberia
conventional short form: Liberia
Western Africa, bordering the North Atlantic Ocean, between
Cote d''Ivoire and Sierra Leone
Africa
30 sq km (2003)
total: 111,370 sq km
land: 96,320 sq km
water: 15,050 sq km
chief of mission: Ambassador Charles A. MINOR
chancery: 5201 16th Street NW, Washington, DC 20011
telephone: [1] (202) 723-0437
FAX: [1] (202) 723-0436
consulate(s) general: New York
6,900 (2002)
160,000 (2005)
1,000 (2002)
.lr
5.9% (2003 est.)
100,000 (2003 est.)
7,200 (2003 est.)
0 bbl/day (2003 est.)
3,400 bbl/day (2003 est.)
NA bbl/day
total: 18.1 years
male: 18 years
female: 18.3 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
8 (2006)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are high risks in
some locations
water contact disease: schistosomiasis
aerosolized dust or soil contact disease: Lassa fever (2005)
refugees (country of origin): 13,941 (Sierra Leone) 12,408
(Cote d''Ivoire)
IDPs: 464,000 (civil war from 1990-2004; IDP resettlement began in
November 2004) (2005)
Macedonia
IDPs: 2,678 (ethnic conflict in 2001) (2005)
$902.9 million','406368195cc5573d662aa594522055f61ab4a5d044d1ed7961a4b54383ee769a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36b66ab711b4d103894c1bdbf8eede9b7c4dd1b45bbc6c6c529da6d2f5365079',2006,'LY','Libya','communications',910,'mostly barren, flat to undulating plains, plateaus, depressions
3.28 children born/woman (2006 est.)
Jamahiriya (a state of the masses) in theory, governed by the
populace through local councils; in fact, a military dictatorship
30% (2004 est.)
conventional long form: Great Socialist People''s Libyan Arab
Jamahiriya
conventional short form: Libya
local long form: Al Jumahiriyah al Arabiyah al Libiyah ash Shabiyah
al Ishtirakiyah al Uzma
local short form: none
Northern Africa, bordering the Mediterranean Sea, between
Egypt and Tunisia
Africa
4,700 sq km (2003)
total: 1,759,540 sq km
land: 1,759,540 sq km
water: 0 sq km
chief of mission: ambassador (vacant); Charge d''Affaires Ali
AUJALI
chancery: 2600 Virginia Avenue NW, Suite 705, Washington, DC 20037
telephone: [1] (202) 944-9601
FAX: [1] (202) 944-9060
750,000 (2003)
234,800 (2004)
205,000 (2005)
.ly
0.3% (2001 est.)
10,000 (2001 est.)
NA
1.643 million bbl/day (2005 est.)
237,000 bbl/day (2004 est.)
0 bbl/day NA bbl/day
1.34 million bbl/day NA bbl/day
total: 23 years
male: 23.1 years
female: 22.9 years (2006 est.)
40 billion bbl (2005 est.)
1.321 trillion cu m (2005)
7 billion cu m (2003 est.)
6.25 billion cu m (2003 est.)
0 cu m (2001 est.)
770 million cu m (2001 est.)
31 (2006)
11.4% of GDP (2005 est.)
8.2% of GDP (2005 est.)
$10.73 billion (2005 est.)
$39.7 billion (2005 est.)
degree of risk: intermediate
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: may be a significant risk in some locations
during the transmission season (typically April through October)
(2005)
$31.49 billion (2005 est.)
current situation: Libya is a transit and destination country
for men, women, and children from sub-Saharan Africa and Asia
trafficked for forced labor and sexual exploitation; many victims
willingly migrate to Libya en route to Europe with the help of
smugglers, but may be forced into prostitution or work as laborers
and beggars to pay off their $800-$1,200 smuggling debt; laborers
from Egypt, Sudan, and Ethiopia are reportedly trafficked to Libya
for the purpose of labor exploitation
tier rating: Tier 2 Watch List - Libya is placed on the Tier 2 Watch
List for its lack of evidence of increasing efforts to address
trafficking since 2004
Macau
current situation: Macau is a transit and destination
territory for women trafficked for the purpose of commercial sexual
exploitation; most females in Macau''s sizeable sex industry come
from the interior regions of China or Mongolia, though a significant
number also come from Russia, Eastern Europe, Thailand, and Vietnam;
the majority of women in Macau''s prostitution trade appear to have
entered Macau and the sex trade voluntarily, though there is
evidence that some are deceived or coerced into sexual servitude,
often through the use of debt bondage; organized criminal syndicates
are reportedly involved in bringing women to Macau, and fear of
reprisals from these groups may prevent some women from seeking help
tier rating: Tier 2 Watch List - Macau is placed on the Tier 2 Watch
List for failing to show evidence of increasing efforts to address
trafficking since 2004','3566da4c85c600bee1ca53e410f28226ef61cb76cf09ecc3b11f535aada4f4d4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('165394d565e4aa6be6d6c4951509357feba7dd742148691859ed3d41f1a434f4',2006,'LI','Liechtenstein','communications',911,'mostly mountainous (Alps) with Rhine Valley in western
third
1.51 children born/woman (2006 est.)
constitutional monarchy
1.3% (September 2002)
defense is the responsibility of Switzerland
Macau
defense is the responsiblity of China
conventional long form: Principality of Liechtenstein
conventional short form: Liechtenstein
local long form: Fuerstentum Liechtenstein
local short form: Liechtenstein
Central Europe, between Austria and Switzerland
Europe
NA
total: 160 sq km
land: 160 sq km
water: 0 sq km
chief of mission: Ambassador Claudia FRITSCHE
chancery: 888 17th Street NW, Suite 1250, Washington, DC 20006
telephone: [1] (202) 331-0590
FAX: [1] (202) 331-3221
19,900 (2002)
11,400 (2002)
20,000 (2002)
.li
NA
NA
NA
total: 39.6 years
male: 39.2 years
female: 40.1 years (2006 est.)
4,697 (2006)
$2.487 billion','b46832d7c0a2c16cbdcafd108a98ffe9f68c7553251b5b7bd44735abc60d92e6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b9e125b101783bce0c832fac05977b1b1859e172af100c3d0175f943908b4ab',2006,'LT','Lithuania','communications',912,'lowland, many scattered small lakes, fertile soil
1.2 children born/woman (2006 est.)
parliamentary democracy
8.2% (2005)
conventional long form: Republic of Lithuania
conventional short form: Lithuania
local long form: Lietuvos Respublika
local short form: Lietuva
former: Lithuanian Soviet Socialist Republic
Eastern Europe, bordering the Baltic Sea, between Latvia
and Russia
Europe
70 sq km (2003)
total: 65,200 sq km
land: NA sq km
water: NA sq km
chief of mission: Ambassador (vacant); Charge d''Affaires
Kornelija JURGAITIENE
chancery: 4590 MacArthur Blvd. NW, Suite 200, Washington, DC 20007
telephone: [1] (202) 234-5860
FAX: [1] (202) 328-0466
consulate(s) general: Chicago, New York
801,100 (2005)
4.353 million (2005)
1,221,700 (2005)
.lt
0.1% (2001 est.)
1,300 (2003 est.)
less than 200 (2003 est.)
32.5 (2003)
Macedonia
28.2 (1998)
14,000 bbl/day (2004)
52,000 bbl/day (2004)
93,000 bbl/day bbl/day (2004)
NA bbl/day
total: 38.2 years
male: 35.7 years
female: 40.8 years (2006 est.)
12 million bbl (2004)
0 cu m (2004)
3.1 billion cu m (2004)
3.1 billion cu m (2004)
0 cu m (2004)
148,675 (2006)
21.8% of GDP (2005 est.)
18.7% of GDP (2005 est.)
Macedonia
33.7% of GDP (2005 est.)
$-1.771 billion (2005)
$3.815 billion (2005)
$23.5 billion (2005 est.)','8aac460fda9d6f9f20105aa819e96e4a06ec895f6281bf7f3a350c6dedcc0236','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11bfa7113c5f9b02a8f70f4aef80d33454e44b9f9173b9b66f316e925d5b0a8c',2006,'LU','Luxembourg','communications',913,'mostly gently rolling uplands with broad, shallow
valleys; uplands to slightly mountainous in the north; steep slope
down to Moselle flood plain in the southeast
Macau
generally flat
Macedonia
mountainous territory covered with deep basins and
valleys; three large lakes, each divided by a frontier line; country
bisected by the Vardar River
1.78 children born/woman (2006 est.)
Macau
1.02 children born/woman (2006 est.)
Macedonia
1.57 children born/woman (2006 est.)
constitutional monarchy
Macau
limited democracy
Macedonia
parliamentary democracy
4.5% (2005 est.)
Macau
4.1% (3rd Quarter 2005)
Macedonia
37.3% (2005 est.)
conventional long form: Grand Duchy of Luxembourg
conventional short form: Luxembourg
local long form: Grand Duche de Luxembourg
local short form: Luxembourg
Macau
conventional long form: Macau Special Administrative Region
conventional short form: Macau
local long form: Aomen Tebie Xingzhengqu (Chinese); Regiao
Administrativa Especial de Macau (Portuguese)
local short form: Aomen (Chinese); Macau (Portuguese)
Macedonia
conventional long form: Republic of Macedonia
conventional short form: Macedonia
local long form: Republika Makedonija
local short form: Makedonija
note: the provisional designation used by the UN, EU, and NATO is
Former Yugoslav Republic of Macedonia (FYROM)
former: People''s Republic of Macedonia, Socialist Republic of
Macedonia
Western Europe, between France and Germany
Macau
Eastern Asia, bordering the South China Sea and China
Macedonia
Southeastern Europe, north of Greece
Europe
Macau
Southeast Asia
Macedonia
Europe
NA
Macau
NA
Macedonia
550 sq km (2003)
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Macau
total: 28.2 sq km
land: 28.2 sq km
water: 0 sq km
Macedonia
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
chief of mission: Ambassador Joseph WEYLAND
chancery: 2200 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-4171/72
FAX: [1] (202) 328-8270
consulate(s) general: New York, San Francisco
Macau
none (special administrative region of China)
Macedonia
chief of mission: Ambassador Ljupco JORDANOVSKI
chancery: 2129 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 667-0501
FAX: [1] (202) 667-2131
consulate(s) general: Southfield (Michigan)
244,500 (2005)
Macau
174,400 (2005)
Macedonia
533,200 (2005)
720,000 (2005)
Macau
532,800 (2005)
Macedonia
1.261 million (2005)
315,000 (2005)
Macau
201,000 (2004)
Macedonia
392,671 (2005)
.lu
Macau
.mo
Macedonia
.mk
0.2% (2001 est.)
Macau
NA
Macedonia
less than 0.1% (2001 est.)
less than 500 (2003 est.)
Macau
NA
Macedonia
less than 200 (2003 est.)
less than 100 (2003 est.)
Macau
NA
Macedonia
less than 100 (2003 est.)
0 bbl/day (2003 est.)
Macau
0 bbl/day (2004 est.)
Macedonia
0 bbl/day (2005 est.)
55,700 bbl/day (2003 est.)
Macau
12,000 bbl/day (2003 est.)
Macedonia
23,000 bbl/day (2005 est.)
50,700 bbl/day (2001)
Macau
NA bbl/day
Macedonia
NA bbl/day
634 bbl/day (2001)
Macau
NA bbl/day
Macedonia
NA bbl/day
total: 38.7 years
male: 37.7 years
female: 39.7 years (2006 est.)
Macau
total: 36.1 years
male: 35.7 years
female: 36.4 years (2006 est.)
Macedonia
total: 34.1 years
male: 33.2 years
female: 35.1 years (2006 est.)
0 cu m (2003 est.)
Macau
0 cu m (2003 est.)
Macedonia
0 cu m (2003 est.)
1.205 billion cu m (2003 est.)
Macau
0 cu m (2003 est.)
Macedonia
0 cu m (2003 est.)
867 million cu m (2001 est.)
0 cu m (2001 est.)
88,661 (2006)
Macau
108 (2006)
Macedonia
3,716 (2006)
20.3% of GDP (2005 est.)
Macedonia
18.3% of GDP (2005 est.)
$3.56 billion
Macedonia
$-81.1 million (2005 est.)
$279.1 million (2005 est.)
Macedonia
$1.341 billion (2005 est.)
$31.76 billion (2005 est.)
Macau
$10.05 billion (2004)
Macedonia
$5.304 billion (2005 est.)','72c9e858df9ec3049e08edcff4968ef4763c2d16febf8ca52a2fb9e688c34958','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b03323121f5e08c6331e6a860c760b7305429a7f6cacbc7dfdcb86b0d049f35',2006,'MG','Madagascar','communications',914,'narrow coastal plain, high plateau and mountains in center
5.62 children born/woman (2006 est.)
republic
conventional long form: Republic of Madagascar
conventional short form: Madagascar
local long form: Republique de Madagascar/Repoblikan''i Madagasikara
local short form: Madagascar/Madagasikara
former: Malagasy Republic
Juan de Nova Island: island in the Mozambique Channel, about
one-third of the way between Madagascar and Mozambique
Tromelin Island: island in the Indian Ocean, east of Madagascar
Southern Africa, island in the Indian Ocean, east of
Africa
10,860 sq km (2003)
total: 587,040 sq km
land: 581,540 sq km
water: 5,500 sq km
chief of mission: Ambassador Rajaonarivony NARISOA
chancery: 2374 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-5525, 5526
FAX: [1] (202) 265-3034
consulate(s) general: New York
66,900 (2005)
504,700 (2005)
90,000 (2005)
.mg
1.7% (2003 est.)
140,000 (2003 est.)
7,500 (2003 est.)
47.5 (2001)
89.27 bbl/day (2003 est.)
15,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.5 years
male: 17.3 years
female: 17.7 years (2006 est.)
0 bbl (1 January 2002)
0 cu m (1 January 2002)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,504 (2006)
26.4% of GDP (2005 est.)
$-438 million (2005 est.)
$572 million (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and plague are high risks in some
locations
water contact disease: schistosomiasis (2005)
$4.719 billion (2005 est.)','15d59583a0dcd7e6b27647d26e14847abe7936627757ecd9ee4cbdcf7a08458f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49e9d4a6c6fccfbd499ca8f62836a6cd6b03cccb6212d46933372eee7e973408',2006,'MW','Malawi','communications',915,'narrow elongated plateau with rolling plains, rounded hills,
some mountains
5.92 children born/woman (2006 est.)
multiparty democracy
NA%
the executive exerts considerable influence over the
legislature
conventional long form: Republic of Malawi
conventional short form: Malawi
local long form: Dziko la Malawi
local short form: Malawi
former: British Central African Protectorate, Nyasaland
Protectorate, Nyasaland
Southern Africa, east of Zambia
Africa
560 sq km (2003)
total: 118,480 sq km
land: 94,080 sq km
water: 24,400 sq km
chief of mission: Ambassador Bernard Herbert SANDE
chancery: 1156 15th Street, NW, Suite 320, Washington, DC 20005
telephone: [1] (202) 721-0270
FAX: [1] (202) 721-0288
102,700 (2005)
429,300 (2005)
52,500 (2005)
.mw
14.2% (2003 est.)
900,000 (2003 est.)
84,000 (2003 est.)
50.3 (1997)
0 bbl/day (2003 est.)
5,450 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 16.5 years
male: 16.2 years
female: 16.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
377 (2006)
10.2% of GDP (2005 est.)
195.9% of GDP (2005 est.)
$-218 million (2005 est.)
$151 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and plague are high risks in some
locations
water contact disease: schistosomiasis (2005)
$1.984 billion (2005 est.)','f54989164619b109b3059ab4c1b2b292694ed77a9ef3861357b2acca50c95b35','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd0ccceb8b03d8419ac02f0803c7c5a049f24028252a17d4e090022a805e88b4',2006,'MY','Malaysia','communications',916,'coastal plains rising to hills and mountains
3.04 children born/woman (2006 est.)
constitutional monarchy
note: nominally headed by paramount ruler and a bicameral Parliament
consisting of a nonelected upper house and an elected lower house;
all Peninsular Malaysian states have hereditary rulers except Melaka
and Pulau Pinang (Penang); those two states along with Sabah and
Sarawak in East Malaysia have governors appointed by government;
powers of state governments are limited by federal constitution;
under terms of federation, Sabah and Sarawak retain certain
constitutional prerogatives (e.g., right to maintain their own
immigration controls); Sabah holds 25 seats in House of
Representatives; Sarawak holds 28 seats in House of Representatives
3.6% (2005 est.)
conventional long form: none
conventional short form: Malaysia
local long form: none
local short form: Malaysia
former: Federation of Malaysia
Southeastern Asia, peninsula bordering Thailand and
northern one-third of the island of Borneo, bordering Indonesia,
Brunei, and the South China Sea, south of Vietnam
Southeast Asia
3,650 sq km (2003)
total: 329,750 sq km
land: 328,550 sq km
water: 1,200 sq km
chief of mission: Ambassador GHAZZALI bin Sheikh Abdul
Khalid
chancery: 3516 International Court NW, Washington, DC 20008
telephone: [1] (202) 572-9700
FAX: [1] (202) 572-9882
consulate(s) general: Los Angeles, New York
4.366 million (2005)
19.545 million (2005)
11.016 million (2005)
.my
0.4% (2003 est.)
52,000 (2003 est.)
2,000 (2003 est.)
49.2 (1997)
770,000 bbl/day (2005 est.)
510,000 bbl/day (2003 est.)
NA bbl/day
230,200 bbl/day (2003)
total: 24.1 years
male: 23.6 years
female: 24.8 years (2006 est.)
3.1 billion bbl (2005 est.)
2.124 trillion cu m (2005)
53.5 billion cu m (2003 est.)
28.53 billion cu m (2003 est.)
0 cu m (2001 est.)
22.41 billion cu m (2001 est.)
158,650 (2006)
20% of GDP (2005 est.)
46.2% of GDP (2005 est.)
$14.06 billion (2005 est.)
$70.23 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: dengue fever and malaria are high risks in
some locations (2005)
refugees (country of origin): 15,181 (Indonesia) 9,601
(Burma) (2005)
$122 billion (2005 est.)
current situation: Malaysia is a destination and, to a
lesser extent, a source and transit country for men and women
trafficked for the purposes of sexual exploitation and forced labor;
foreign victims, mostly women and girls from China, Indonesia,
Thailand, the Philippines, and Vietnam, are trafficked to Malaysia
for commercial sexual exploitation; economic migrants from countries
in the region who work as domestic servants or laborers in the
construction and agricultural sectors face exploitative conditions
in Malaysia that meet the definition of involuntary servitude; some
Malaysian women, primarily of Chinese ethnicity, are trafficked
abroad for sexual exploitation
tier rating: Tier 2 Watch List - Malaysia is placed on Tier 2 Watch
List for its failure to provide evidence of increasing efforts to
combat trafficking, particularly its failure to provide protection
for victims of trafficking','7b1798012c395509bcadc823b637e81f02d1a2a793b4f08a157e3810506624dc','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2900fa51c5aff27f5ade457297e847c4691929e2eb555d5b93a295da248ca65a',2006,'MV','Maldives','communications',917,'flat, with white sandy beaches
4.9 children born/woman (2006 est.)
republic
NEGL% (2003 est.)
conventional long form: Republic of Maldives
conventional short form: Maldives
local long form: Dhivehi Raajjeyge Jumhooriyyaa
local short form: Dhivehi Raajje
Southern Asia, group of atolls in the Indian Ocean,
south-southwest of India
Asia
NA
total: 300 sq km
land: 300 sq km
water: 0 sq km
chief of mission: Ambassador Mohamed LATHEEF
chancery: 800 2nd Avenue, Suite 400E, New York, NY 10017
telephone: [1] (212) 599-6195
FAX: [1] (212) 661-6405
32,300 (2005)
153,400 (2005)
19,000 (2005)
.mv
0.1% (2001 est.)
less than 100 (2001 est.)
NA
0 bbl/day (2003 est.)
4,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.9 years
male: 17.8 years
female: 18 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
1,357 (2006)
IDPs: 11,000 (December 2004 tsunami victims) (2005)
$817 million','37a53db40849b3e4307efa932cdaa3cb71db087e59970e17783b6ad3f7baf93e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d92b2ea53429b5a62aae1bc761b6fc84073d7f31cb7c01ede90d89afe0b80eaf',2006,'ML','Mali','communications',918,'mostly flat to rolling northern plains covered by sand; savanna
in south, rugged hills in northeast
7.42 children born/woman (2006 est.)
republic
14.6% (2001 est.)
conventional long form: Republic of Mali
conventional short form: Mali
local long form: Republique de Mali
local short form: Mali
former: French Sudan and Sudanese Republic
Western Africa, southwest of Algeria
Africa
2,360 sq km (2003)
total: 1.24 million sq km
land: 1.22 million sq km
water: 20,000 sq km
chief of mission: Ambassador Abdoulaye DIOP
chancery: 2130 R Street NW, Washington, DC 20008
telephone: [1] (202) 332-2249, 939-8950
FAX: [1] (202) 332-6603
75,000 (2005)
869,600 (2005)
60,000 (2005)
.ml
1.9% (2003 est.)
140,000 (2003 est.)
12,000 (2003 est.)
50.5 (1994)
0 bbl/day (2003 est.)
4,250 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 15.8 years
male: 15.4 years
female: 16.3 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
278 (2006)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria is a high risk in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
refugees (country of origin): 6,185 (Mauritania) (2005)
$5.434 billion (2005 est.)','4be39497250dea88b0345502d17fb7d5501a6292a3dbaef5855ae7a71badf74e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa41a60fecc8060bdfe142840adb07ee0f79dfaa7b2fa95f611ea90cbb8f516a',2006,'MT','Malta','communications',919,'mostly low, rocky, flat to dissected plains; many coastal
cliffs
1.5 children born/woman (2006 est.)
republic
7.8% (2005 est.)
conventional long form: Republic of Malta
conventional short form: Malta
local long form: Repubblika ta'' Malta
local short form: Malta
Southern Europe, islands in the Mediterranean Sea, south of
Sicily (Italy)
Europe
20 sq km (2003)
total: 316 sq km
land: 316 sq km
water: 0 sq km
chief of mission: Ambassador John LOWELL
chancery: 2017 Connecticut Avenue NW, Washington, DC 20008
telephone: [1] (202) 462-3611, 3612
FAX: [1] (202) 387-5470
consulate(s): New York
202,100 (2005)
324,000 (2005)
127,200 (2005)
.mt
0.2% (2001 est.)
less than 500 (2003 est.)
less than 100 (2003 est.)
0 bbl/day (2003 est.)
18,000 bbl/day (2003 est.)
NEGL (2001)
NA bbl/day
total: 38.7 years
male: 37.2 years
female: 40.1 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
14,025 (2006)
22.6% of GDP (2005 est.)
$-598 million (2005 est.)
$2.579 billion (2005 est.)
$5.193 billion (2005 est.)','d23d3fa8a03d7c9af3843d815513e44545c804ffd7a8ca48e14b0937a4f4a0a6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a666ce6c2e6ce2885cf7823b14c9109aeeb03c8b3501af8afc26a8a80efbafb',2006,'MH','Marshall Islands','communications',920,'low coral limestone and sand islands
3.85 children born/woman (2006 est.)
constitutional government in free association with
the US; the Compact of Free Association entered into force 21
October 1986 and the Amended Compact entered into force in May 2004
30.9% (2000 est.)
defense is the responsibility of the US
conventional long form: Republic of the Marshall
Islands
conventional short form: Marshall Islands
local long form: Republic of the Marshall Islands
local short form: Marshall Islands
abbreviation: RMI
former: Trust Territory of the Pacific Islands, Marshall Islands
District
Oceania, two archipelagic island chains of 29
atolls, each made up of many small islets, and five single islands
in the North Pacific Ocean, about one-half of the way from Hawaii to
Navassa Island
Caribbean, island in the Caribbean Sea, 35 miles west
of Tiburon Peninsula of Haiti
Kingman Reef: reef in the North Pacific Ocean 930 nm (1,722 km)
south of Honolulu, about half way between Hawaii and American Samoa
Midway Islands: atoll in the North Pacific Ocean 1,260 nm (2,334 km)
northwest of Honolulu near the end of the Hawaiian Archipelago,
about one-third of the way from Honolulu to Tokyo
Palmyra Atoll: atoll in the North Pacific Ocean 960 nm (1,778 km)
south of Honolulu, about half way between Hawaii and American Samoa
Oceania
0 sq km
total: 11,854.3 sq km
land: 181.3 sq km
water: 11,673 sq km (note - lagoon waters)
note: includes the atolls of Bikini, Enewetak, Kwajalein, Majuro,
Rongelap, and Utirik
chief of mission: Ambassador Banny DE BRUM
chancery: 2433 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-5414
FAX: [1] (202) 232-3236
consulate(s) general: Honolulu
5,510 (2004)
1,198 (2004)
2,000 (2005)
.mh
NA
NA
NA
total: 20.3 years
male: 20.4 years
female: 20.3 years (2006 est.)
6 (2006)
$144 million','fec2038ab109fcc4eacf59dfbcabc5d7f48573d86d35fa12de5ebdd3c623bf48','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d32a8f3458e0e94bd5c91206dccccafb933bbf77c135879253e4be21188182e',2006,'MQ','Martinique','communications',921,'mountainous with indented coastline; dormant volcano
1.79 children born/woman (2006 est.)
NA
27.2% (1998)
defense is the responsibility of France
conventional long form: Department of Martinique
conventional short form: Martinique
local long form: Departement de la Martinique
local short form: Martinique
Caribbean, island between the Caribbean Sea and North
Atlantic Ocean, north of Trinidad and Tobago
Central America and the Caribbean
70 sq km (2003)
total: 1,100 sq km
land: 1,060 sq km
water: 40 sq km
none (overseas department of France)
172,000 (2001)
319,900 (2002)
107,000 (2005)
.mq
NA
NA
NA
0 bbl/day (2003 est.)
13,800 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 34.1 years
male: 33.4 years
female: 34.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
72 (2006)
NA','f85d8146d4859e46a5a7d006da0c73e75dc9b05da4b03b300a5ea3f4e03f6f2e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ecfe545e5ebe88020afe9ab4da604fd6cd921197d1cc84aff71483f90b2e173',2006,'MR','Mauritania','communications',922,'mostly barren, flat plains of the Sahara; some central
hills
5.86 children born/woman (2006 est.)
republic
20% (2004 est.)
conventional long form: Islamic Republic of Mauritania
conventional short form: Mauritania
local long form: Al Jumhuriyah al Islamiyah al Muritaniyah
local short form: Muritaniyah
Northern Africa, bordering the North Atlantic Ocean,
between Senegal and Western Sahara
Africa
490 sq km (2002)
total: 1,030,700 sq km
land: 1,030,400 sq km
water: 300 sq km
chief of mission: Ambassador Tijani Ould Mohamed EL KERIM
chancery: 2129 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 232-5700, 5701
FAX: [1] (202) 319-2623
41,000 (2005)
745,600 (2005)
14,000 (2005)
.mr
0.6% (2003 est.)
9,500 (2003 est.)
less than 500 (2003 est.)
39 (2000)
0 bbl/day (2005 est.)
24,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17 years
male: 16.8 years
female: 17.3 years (2006 est.)
1 billion bbl (2005)
0 cu m (2005)
0 cu m (2003 est.)
0 cu m (2003 est.)
32 (2006)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and Rift Valley fever are high risks
in some locations
respiratory disease: meningococcal meningitis (2005)
$1.346 billion (2005 est.)
current situation: Mauritania is a source and destination
country for children trafficked for the purpose of forced labor,
begging, and domestic servitude; adults and children are subjected
to slavery-related practices rooted in ancestral master-slave
relationships in isolated parts of the country where a barter
economy exists
tier rating: Tier 2 Watch List - Mauritania is placed on the Tier 2
Watch List for its failure to show evidence of increased efforts to
combat trafficking, particularly in the area of law enforcement','1c4d3fc71f61d6b87f9816cef3e8074c02a6e9cafee2ab84a3ee2129edfd0d21','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fe561472425e87b7a4837df9cb0e25998086346f26b67187274850df121165d',2006,'MU','Mauritius','communications',923,'small coastal plain rising to discontinuous mountains
encircling central plateau
1.95 children born/woman (2006 est.)
parliamentary democracy
9.6% (2005 est.)
conventional long form: Republic of Mauritius
conventional short form: Mauritius
local long form: Republic of Mauritius
local short form: Mauritius
Southern Africa, island in the Indian Ocean, east of
Political Map of the World
220 sq km (2003)
total: 2,040 sq km
land: 2,030 sq km
water: 10 sq km
note: includes Agalega Islands, Cargados Carajos Shoals (Saint
Brandon), and Rodrigues
chief of mission: Ambassador Usha JEETAH
chancery: 4301 Connecticut Avenue NW, Suite 441, Washington, DC 20008
telephone: [1] (202) 244-1491, 1492
FAX: [1] (202) 966-0983
359,000 (2005)
713,300 (2005)
180,000 (2005)
.mu
0.1% (2001 est.)
700 (2001 est.)
less than 100 (2001 est.)
37 (1987 est.)
0 bbl/day (2003 est.)
21,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 30.8 years
male: 30 years
female: 31.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
4,997 (2006)
21.2% of GDP (2005 est.)
67.5% of GDP (2005 est.)
$-342 million (2005 est.)
$1.366 billion (2005 est.)
$6.681 billion (2005 est.)','8933c10f98e12f8cf714bbc6f3bf4bda692ba1a9a1477e9d7f5b77803cbcbc29','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28954f3877432cd97a3383b5e3b14d23e9b48aa9dc25c76af82be91ff5c4ebd7',2006,'YT','Mayotte','communications',924,'generally undulating, with deep ravines and ancient volcanic
peaks
5.79 children born/woman (2006 est.)
NA
32.8% (2003)
defense is the responsibility of France; small contingent of
French forces stationed on the island
conventional long form: Territorial Collectivity of Mayotte
conventional short form: Mayotte
Southern Africa, island in the Mozambique Channel, about
one-half of the way from northern Madagascar to northern Mozambique
Africa
NA
total: 374 sq km
land: 374 sq km
water: 0 sq km
none (territorial collectivity of France)
10,000 (2002)
48,100 (2004)
NA
.yt
NA
NA
NA
total: 17 years
male: 18 years
female: 16 years (2006 est.)
1 (2006)
NA','d4e1a0a5ce27698468c684e06cf112085a387d7a8b74766cb466f2f9e773ae6a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7f59e9e638a0f6a08c6c3cef6c54fdad779da0e691b1321c8a1344929fe6e75',2006,'MX','Mexico','communications',925,'high, rugged mountains; low coastal plains; high plateaus;
desert
2.42 children born/woman (2006 est.)
federal republic
3.6% plus underemployment of perhaps 25% (2005 est.)
conventional long form: United Mexican States
conventional short form: Mexico
local long form: Estados Unidos Mexicanos
local short form: Mexico
Middle America, bordering the Caribbean Sea and the Gulf of
Mexico, between Belize and the US and bordering the North Pacific
Ocean, between Guatemala and the US
North America
63,200 sq km (2003)
total: 1,972,550 sq km
land: 1,923,040 sq km
water: 49,510 sq km
chief of mission: Ambassador Carlos Alberto DE ICAZA Gonzalez
chancery: 1911 Pennsylvania Avenue NW, Washington, DC 20006
telephone: [1] (202) 728-1600
FAX: [1] (202) 728-1698
consulate(s) general: Atlanta, Austin, Boston, Chicago, Dallas,
Denver, El Paso, Houston, Los Angeles, Miami, New Orleans, New York,
Nogales (Arizona), Omaha, Orlando, Phoenix, Sacramento, San Antonio,
San Diego, San Francisco, San Jose, San Juan (Puerto Rico)
consulate(s): Albuquerque, Brownsville (Texas), Calexico
(California), Del Rio (Texas), Detroit, Douglas (Arizona), Eagle
Pass (Texas), Fresno (California), Indianapolis (Indiana), Kansas
City (Missouri), Laredo (Texas), Las Vegas, McAllen (Texas), Midland
(Texas), Oxnard (California), Philadelphia, Portland (Oregon),
Presidio (Texas), Raleigh, Saint Paul (Minnesota), Salt Lake City,
San Bernardino, Santa Ana (California), Seattle, Tucson, Yuma
(Arizona)
19.512 million (2005)
47.462 million (2005)
18,622,500 (2005)
.mx
0.3% (2003 est.)
160,000 (2003 est.)
5,000 (2003 est.)
54.6 (2000)
Moldova
36.2 (2001)
3.42 million bbl/day (2005 est.)
Moldova
0 bbl/day (2003 est.)
1.752 million bbl/day (2004 est.)
Moldova
37,000 bbl/day (2003 est.)
205,000 bbl/day (2004)
Moldova
NA bbl/day
1.863 million bbl/day (2004)
Moldova
NA bbl/day
total: 25.3 years
male: 24.3 years
female: 26.2 years (2006 est.)
33.31 billion bbl (2005 est.)
424.3 billion cu m (2005)
47.3 billion cu m (2004 est.)
Moldova
0 cu m (2003 est.)
55.1 billion cu m (2004 est.)
Moldova
2.38 billion cu m (2003 est.)
7.85 billion cu m (2004 est.)
Moldova
2.05 billion cu m (2001 est.)
0 cu m (2004 est.)
Moldova
0 cu m (2001 est.)
3,426,680 (2006)
19.3% of GDP (2005 est.)
Moldova
24.4% of GDP (2005 est.)
17.4% of GDP (2005 est.)
Moldova
79.6% of GDP (2005 est.)
$-5.708 billion (2005 est.)
$74.1 billion (2005 est.)
Moldova
$597.5 million (2005 est.)
IDPs: 12,000 (government''s quashing of Zapatista uprising in
1994 in eastern Chiapas Region) (2005)
Moldova
IDPs: 1,000 (internal secessionist uprising in Transnistrian
region in 1991) (2005)
$693 billion (2005 est.)
current situation: Mexico is a source, transit, and
destination country for persons trafficked for sexual exploitation
and labor; while the vast majority of victims are Central Americans
trafficked along Mexico''s southern border, other source regions
include South America, the Caribbean, Eastern Europe, Africa, and
Asia; women and children are trafficked from rural regions to urban
centers and tourist areas for sexual exploitation, often through
fraudulent offers of employment or through threats of physical
violence; the Mexican trafficking problem is often conflated with
alien smuggling, and frequently the same criminal networks are
involved; pervasive corruption among state and local law enforcement
often impedes investigations
tier rating: Tier 2 Watch List - Mexico remains on the Tier 2 Watch
List for the third consecutive year based on future commitments to
undertake additional efforts in prosecution, protection, and
prevention of trafficking in persons, and the failure of the
government to provide critical law enforcement data','5be8beeef82456e518f47784c42b9a3df2623adefe45d8e9a272dd0ac52309b2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca79a6b6a4619c16b6cfb41c1babd55f4fe1f22d923cbebc0836cca2bc72ea45',2006,'FM','Micronesia, Federated States of','communications',926,'islands vary geologically from high
mountainous islands to low, coral atolls; volcanic outcroppings on
Pohnpei, Kosrae, and Chuuk
Midway Islands
low, nearly level
Moldova
rolling steppe, gradual slope south to Black Sea
3.16 children born/woman (2006 est.)
Moldova
1.85 children born/woman (2006 est.)
constitutional government in free
association with the US; the Compact of Free Association entered
into force 3 November 1986 and the Amended Compact entered into
force May 2004
Moldova
republic
22% (2000 est.)
Moldova
8%; note - roughly 25% of working age Moldovans are employed
abroad (2002 est.)
defense is the responsibility of the
US
Midway Islands
defense is the responsibility of the US
conventional long form: Federated
States of Micronesia
conventional short form: none
local long form: Federated States of Micronesia
local short form: none
former: Trust Territory of the Pacific Islands, Ponape, Truk, and
Yap Districts
abbreviation: FSM
Midway Islands
conventional long form: none
conventional short form: Midway Islands
Moldova
conventional long form: Republic of Moldova
conventional short form: Moldova
local long form: Republica Moldova
local short form: Moldova
former: Moldavian Soviet Socialist Republic; Moldovan Soviet
Socialist Republic
Oceania, island group in the North
Pacific Ocean, about three-quarters of the way from Hawaii to
Oceania
Midway Islands
Oceania
Moldova
Europe
NA
Midway Islands
0 sq km
Moldova
3,000 sq km (2003)
total: 702 sq km
land: 702 sq km
water: 0 sq km (fresh water only)
note: includes Pohnpei (Ponape), Chuuk (Truk) Islands, Yap Islands,
and Kosrae (Kosaie)
Midway Islands
total: 6.2 sq km
land: 6.2 sq km
water: 0 sq km
note: includes Eastern Island, Sand Island, and Spit Island
Moldova
total: 33,843 sq km
land: 33,371 sq km
water: 472 sq km
chief of mission: Ambassador Jesse
Bibiano MAREHALAU
chancery: 1725 N Street NW, Washington, DC 20036
telephone: [1] (202) 223-4383
FAX: [1] (202) 223-4391
consulate(s) general: Honolulu, Tamuning (Guam)
Moldova
chief of mission: Ambassador Nicolae CHIRTOACA
chancery: 2101 S Street NW, Washington, DC 20008
telephone: [1] (202) 667-1130
FAX: [1] (202) 667-1204
12,400 (2005)
Moldova
929,400 (2005)
14,100 (2005)
Moldova
1.09 million (2005)
14,000 (2005)
Moldova
406,000 (2005)
.fm
Moldova
.md
NA
Moldova
0.2% (2001 est.)
NA
Moldova
5,500 (2001 est.)
NA
Moldova
less than 300 (2001 est.)
total: 20.9 years
male: 20.5 years
female: 21.4 years (2006 est.)
Moldova
total: 32.3 years
male: 30.3 years
female: 34.3 years (2006 est.)
550 (2006)
Moldova
58,886 (2006)
$-34.3 million
Moldova
$-285 million (2005 est.)
$232 million
Moldova
$2.416 billion (2005 est.)','90ec56a2975d876414768c5fe7d5586b817b8ca96014151475f2dfd5b13fbb9f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('796d9d5d7ff678522e41a1d5848c373a0e9d3d756a8c38483b8d840eab88029d',2006,'MC','Monaco','communications',927,'hilly, rugged, rocky
1.76 children born/woman (2006 est.)
constitutional monarchy
22% (1999)
defense is the responsibility of France; the Palace Guard
performs ceremonial duties (2003)
conventional long form: Principality of Monaco
conventional short form: Monaco
local long form: Principaute de Monaco
local short form: Monaco
Western Europe, bordering the Mediterranean Sea on the
southern coast of France, near the border with Italy
Europe
NA
total: 1.95 sq km
land: 1.95 sq km
water: 0 sq km
Monaco does not have an embassy in the US
consulate(s) general: New York
33,700 (2002)
19,300 (2002)
16,000 (2002)
.mc
NA
NA
NA
total: 45.4 years
male: 43.3 years
female: 47.3 years (2006 est.)
12,720 (2006)
NA','7cf28c43e38205b359a67aca01dc1732052361e0b61fe421ee612a2c708b5342','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4726747bcd717a928a776a7dca53f6f0e23e127e119af5b9d1c3b53ac018b7d5',2006,'MN','Mongolia','communications',928,'vast semidesert and desert plains, grassy steppe, mountains
in west and southwest; Gobi Desert in south-central
2.25 children born/woman (2006 est.)
mixed parliamentary/presidential
6.7% (2003)
conventional long form: none
conventional short form: Mongolia
local long form: none
local short form: Mongol Uls
former: Outer Mongolia
Northern Asia, between China and Russia
Asia
840 sq km (2003)
total: 1,564,116 sq km
chief of mission: Ambassador Ravdan BOLD
chancery: 2833 M Street NW, Washington, DC 20007
telephone: [1] (202) 333-7117
FAX: [1] (202) 298-9227
156,000 (2005)
557,200 (2005)
268,300 (2005)
.mn
less than 0.1% (2003 est.)
less than 500 (2003 est)
less than 200 (2003 est.)
44 (1998)
548.8 bbl/day (2005 est.)
11,220 bbl/day (2005 est.)
11,210 bbl/day (2005 est.)
515 bbl/day (2005 est.)
total: 24.6 years
male: 24.3 years
female: 25 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
272 (2006)
$1.4 billion (2005 est.)','c77e769c6041e7f466737554af0e9c0a3ee8d7b91bc3351d9cf71c8a042eb08e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98320c86bb2be1037642f6f6aa4e84d4323a7cd722ab31950cc4a5bedd6b7efb',2006,'ME','Montenegro','communications',929,'highly indented coastline with narrow coastal plain
backed by rugged high limestone mountains and plateaus
republic
27.7% (2005)
Montenegrin plans call for the establishment of a fully
professional armed forces
conventional long form: Republic of Montenegro
conventional short form: Montenegro
local long form: Republika Crna Gora
local short form: Crna Gora
former: People''s Republic of Montenegro, Socialist Republic of
Southeastern Europe, between the Adriatic Sea and Serbia
Europe
NA
total: 14,026 sq km
land: 13,812 sq km
water: 214 sq km
chief of mission: Ambassador Miodrag VLAHOVIC
177,663 (2005)
543,220 (2005)
50,000 (2004)
.me
NA
NA
NA
% of GDP NA
% of GDP NA
NA
NA
$1.125 billion (2005 est.)','e7dad985b4d4bc51877e0d59be33b299ff9f7ffda6386f6a233e48a3ac7d4f08','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ce80475bd7102f988ed51f4eefc3b7810a8d75df9f091953b83ea5af8fed0f',2006,'MS','Montserrat','communications',930,'volcanic island, mostly mountainous, with small coastal
lowland
1.77 children born/woman (2006 est.)
NA
6% (1998 est.)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Montserrat
Caribbean, island in the Caribbean Sea, southeast of
Central America and the Caribbean
NA
total: 102 sq km
land: 102 sq km
water: 0 sq km
none (overseas territory of the UK)
NA
70 (1994)
NA
.ms
NA
NA
NA
0 bbl/day (2003 est.)
380 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 28.9 years
male: 28.6 years
female: 29.2 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
386 (2006)
NA','ac0d510257bfbd1b5442a2a3d864e3dfd6427e3713c887e293bedabcc5c878bb','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c4b30ff5b8cca5519a3ac6789a2e745b41d09417727280e45696bf8a2385f57',2006,'MA','Morocco','communications',931,'northern coast and interior are mountainous with large areas
of bordering plateaus, intermontane valleys, and rich coastal plains
2.68 children born/woman (2006 est.)
constitutional monarchy
11% (2005 est.)
conventional long form: Kingdom of Morocco
conventional short form: Morocco
local long form: Al Mamlakah al Maghribiyah
local short form: Al Maghrib
Northern Africa, bordering the North Atlantic Ocean and the
Mediterranean Sea, between Algeria and Western Sahara
Africa
14,450 sq km (2003)
total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
chief of mission: Ambassador Aziz MEKOUAR
chancery: 1601 21st Street NW, Washington, DC 20009
telephone: [1] (202) 462-7979
FAX: [1] (202) 265-0161
consulate(s) general: New York
1,341,200 (2005)
12.393 million (2005)
4.6 million (2005)
.ma
0.1% (2001 est.)
15,000 (2001 est.)
NA
40 (2005 est.)
300 bbl/day (2005 est.)
158,000 bbl/day (2003 est.)
147,800 bbl/day NA bbl/day
0 bbl/day NA bbl/day
total: 23.9 years
male: 23.4 years
female: 24.5 years (2006 est.)
100 million bbl (2005 est.)
1.218 billion cu m (2005)
5 million cu m (2003 est.)
650 million cu m (2003 est.)
NA cu m
NA cu m
3,218 (2006)
23.7% of GDP (2005 est.)
72% of GDP (2005 est.)
$1.255 billion (2005 est.)
$16.47 billion (2005 est.)
degree of risk: intermediate
food or waterborne diseases: bacterial diarrhea, and hepatitis A
vectorborne diseases: may be a significant risk in some locations
during the transmission season (typically April through November)
(2005)
$51.94 billion (2005 est.)','d5fc8b442d1acba272fca82445914580365b2e840124e426b831f02d53bb2e52','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be73910f10809a989d610507a6ab0718c3c2dd3e10934d5b49764d4eab7ebf80',2006,'MZ','Mozambique','communications',932,'mostly coastal lowlands, uplands in center, high plateaus
in northwest, mountains in west
4.62 children born/woman (2006 est.)
republic
21% (1997 est.)
conventional long form: Republic of Mozambique
conventional short form: Mozambique
local long form: Republica de Mocambique
local short form: Mocambique
former: Portuguese East Africa
Southeastern Africa, bordering the Mozambique Channel,
between South Africa and Tanzania
Africa
1,180 sq km (2003)
total: 801,590 sq km
land: 784,090 sq km
water: 17,500 sq km
chief of mission: Ambassador Armando PANGUENE
chancery: 1990 M Street NW, Suite 570, Washington, DC 20036
telephone: [1] (202) 293-7146
FAX: [1] (202) 835-0245
69,700 (2004)
1.22 million (2005)
138,000 (2005)
.mz
12.2% (2003 est.)
1.3 million (2003 est.)
110,000 (2003 est.)
39.6 (1996-97)
0 bbl/day (2003 est.)
11,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.3 years
male: 17.8 years
female: 18.8 years (2006 est.)
0 bbl (1 January 2002)
127.4 billion cu m (1 January 2002)
60 million cu m (2003 est.)
60 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
6,985 (2006)
29.6% of GDP (2005 est.)
21% of GDP
$-639 million (2005 est.)
$1.051 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and plague are high risks in some
locations
water contact disease: schistosomiasis (2005)
$5.727 billion (2005 est.)','7badda6093ef4d481488edce3425b7784249524fc897da9068c8c4892853b2fe','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1255cc10dbdedee189b497ae8decdd3143d2c59da7bf23061b1ecdef8031a06',2006,'NA','Namibia','communications',933,'mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
3.06 children born/woman (2006 est.)
republic
35% (1998)
conventional long form: Republic of Namibia
conventional short form: Namibia
local long form: Republic of Namibia
local short form: Namibia
former: German Southwest Africa, South-West Africa
Southern Africa, bordering the South Atlantic Ocean, between
Angola and South Africa
Africa
80 sq km (2003)
total: 825,418 sq km
land: 825,418 sq km
water: 0 sq km
chief of mission: Ambassador Patrick NANDAGO
chancery: 1605 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 986-0540
FAX: [1] (202) 986-0443
127,900 (2004)
495,000 (2005)
75,000 (2005)
.na
21.3% (2003 est.)
210,000 (2001 est.)
16,000 (2003 est.)
70.7 (2003)
0 bbl/day (2003 est.)
16,000 bbl/day (2003 est.)
12,770 bbl/day NA bbl/day
NA bbl/day
total: 20 years
male: 19.8 years
female: 20.1 years (2006 est.)
0 bbl (1 January 2002)
62.3 billion cu m (1 January 2002)
0 cu m (2003 est.)
0 cu m (2003 est.)
3,527 (2006)
24.3% of GDP (2005 est.)
32.7% of GDP (2005 est.)
$509.2 million (2005 est.)
$312.1 million (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria
water contact disease: schistosomiasis (2005)
refugees (country of origin): 12,618 (Angola) (2005)
$4.976 billion (2005 est.)','3707861718c54338a8bd136d5cb9022e077a72c91b3e2c3a4ea2f332f2f0bf17','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dec7681040bb2e84f8e89ec2f0ca9e952afab8d03bf26e738e76fff437c3bf58',2006,'NR','Nauru','communications',934,'sandy beach rises to fertile ring around raised coral reefs
with phosphate plateau in center
Navassa Island
raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m high)
3.11 children born/woman (2006 est.)
republic
90% (2004 est.)
Nauru maintains no defense forces; under an informal
agreement, defense is the responsibility of Australia
Navassa Island
defense is the responsibility of the US
Netherlands Antilles
defense is the responsibility of the Kingdom of
the Netherlands
conventional long form: Republic of Nauru
conventional short form: Nauru
local long form: Republic of Nauru
local short form: Nauru
former: Pleasant Island
Navassa Island
conventional long form: none
conventional short form: Navassa Island
Oceania, island in the South Pacific Ocean, south of the
Oceania
Navassa Island
Central America and the Caribbean
NA
total: 21 sq km
land: 21 sq km
water: 0 sq km
Navassa Island
total: 5.4 sq km
land: 5.4 sq km
water: 0 sq km
chief of mission: Ambassador Vinci Niel CLODUMAR
chancery: 800 2nd Avenue, Suite 400 D, New York, NY 10017
telephone: [1] (212) 937-0074
FAX: [1] (212) 937-0079
consulate(s): Agana (Guam)
1,900 (2002)
1,500 (2002)
300 (2002)
.nr
NA
NA
NA
0 bbl/day (2003 est.)
1,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 20.6 years
male: 20 years
female: 21.2 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
52 (2006)
NA','3db447c55bc898d191c3eac0ab1db0046d73f21abad8c0dc64594b2329f9cff4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e3e59c4664e1a6e3b80b8dc33903f84414690614ffb7b3672207f0004665bc4',2006,'NP','Nepal','communications',935,'Tarai or flat river plain of the Ganges in south, central hill
region, rugged Himalayas in north
4.1 children born/woman (2006 est.)
parliamentary democracy and constitutional monarchy
42% (2004 est.)
conventional long and short form: Nepal
local long and short form: Nepal
Southern Asia, between China and India
Asia
11,700 sq km (2003)
total: 147,181 sq km
land: 143,181 sq km
water: 4,000 sq km
chief of mission: Ambassador (vacant)
chancery: 2131 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 667-4550
FAX: [1] (202) 667-5534
consulate(s) general: New York
448,600 (2005)
248,800 (2005)
175,000 (2005)
.np
0.5% (2001 est.)
61,000 (2001 est.)
3,100 (2003 est.)
37.7 (FY04/05)
0 bbl/day (2005 est.)
11,980 bbl/day (2005 est.)
11,760 bbl/day NA bbl/day
NA bbl/day
total: 20.3 years
male: 20.1 years
female: 20.4 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
17,789 (2006)
refugees (country of origin): 104,915 (Bhutan)
IDPs: 100,000-200,000 (ongoing conflict between government forces
and Maoist rebels; displacement spread across the country) (2005)
$6.655 billion (2005 est.)','acefd7aa6b5f4f9d15a28cf82736a7e003a67e66892eb86d2d216b347afe3f5a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88cca78ef669736054d00010fe669925bb68794de527107c29d1ca49f66c5a79',2006,'NL','Netherlands','communications',936,'mostly coastal lowland and reclaimed land (polders);
some hills in southeast
Netherlands Antilles
generally hilly, volcanic interiors
1.66 children born/woman (2006 est.)
Netherlands Antilles
1.99 children born/woman (2006 est.)
constitutional monarchy
Netherlands Antilles
parliamentary
6.6% (2005 est.)
Netherlands Antilles
17% (2002 est.)
conventional long form: Kingdom of the Netherlands
conventional short form: Netherlands
local long form: Koninkrijk der Nederlanden
local short form: Nederland
Netherlands Antilles
conventional long form: none
conventional short form: Netherlands Antilles
local long form: none
local short form: Nederlandse Antillen
former: Curacao and Dependencies
Western Europe, bordering the North Sea, between Belgium
and Germany
Netherlands Antilles
Caribbean, two island groups in the Caribbean
Sea - composed of five islands, Curacao and Bonaire located off the
coast of Venezuela, and St. Maarten, Saba, and St. Eustatius lie
east of the US Virgin Islands
Europe
Netherlands Antilles
Central America and the Caribbean
5,650 sq km (2003)
Netherlands Antilles
NA
total: 41,526 sq km
land: 33,883 sq km
water: 7,643 sq km
Netherlands Antilles
total: 960 sq km
land: 960 sq km
water: 0 sq km
note: includes Bonaire, Curacao, Saba, Sint Eustatius, and Sint
Maarten (Dutch part of the island of Saint Martin)
chief of mission: Ambassador Christiaan Mark Johan KRONER
chancery: 4200 Linnean Avenue NW, Washington, DC 20008
telephone: [1] (202) 244-5300
FAX: [1] (202) 362-3430
consulate(s) general: Chicago, Los Angeles, Miami, New York
consulate(s): Boston
Netherlands Antilles
none (represented by the Kingdom of the
Netherlands); note - Mr. Jeffrey CORRION, Minister Plenipotentiary
for Aruba at the Embassy of the Kingdom of the Netherlands
7.6 million (2005)
Netherlands Antilles
81,000 (2001)
15.834 million (2005)
Netherlands Antilles
200,000 (2004)
10,806,328 (2004)
Netherlands Antilles
2,000 (2000)
.nl
Netherlands Antilles
.an
0.2% (2001 est.)
Netherlands Antilles
NA
19,000 (2001 est.)
Netherlands Antilles
NA
less than 100 (2003 est.)
Netherlands Antilles
NA
30.9 (2005)
94,870 bbl/day (2003)
Netherlands Antilles
0 bbl/day (2003 est.)
920,000 bbl/day (2003 est.)
Netherlands Antilles
72,500 bbl/day (2003 est.)
2.284 million bbl/day (2001)
Netherlands Antilles
NA bbl/day
1.418 million bbl/day (2001)
Netherlands Antilles
NA bbl/day
total: 39.4 years
male: 38.6 years
female: 40.2 years (2006 est.)
Netherlands Antilles
total: 32.8 years
male: 31.1 years
female: 34.4 years (2006 est.)
88.06 million bbl (1 January 2002)
1.756 trillion cu m (1 January 2002)
73.13 billion cu m (2003 est.)
Netherlands Antilles
0 cu m (2003 est.)
50.4 billion cu m (2003 est.)
Netherlands Antilles
0 cu m (2003 est.)
20.78 billion cu m (2001 est.)
49.28 billion cu m (2001 est.)
8,363,158 (2006)
Netherlands Antilles
19,204 (2006)
19.5% of GDP (2005 est.)
52.7% of GDP (2005 est.)
$39.95 billion (2005 est.)
$20.54 billion (2005 est.)
$581.3 billion (2005 est.)
Netherlands Antilles
NA','ff7ba3ab8df3cacdb86d7c5bee011e2f95a2c86b189e783acbd949a3a94edd65','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('255a8fa54d836b72614c00871ecef5600015a5e4ebb40e0bfa9ca805cdf964c6',2006,'NC','New Caledonia','communications',937,'coastal plains with interior mountains
2.28 children born/woman (2006 est.)
NA
17.1% (2004)
defense is the responsibility of France
conventional long form: Territory of New Caledonia and
Dependencies
conventional short form: New Caledonia
local long form: Territoire des Nouvelle-Caledonie et Dependances
local short form: Nouvelle-Caledonie
Oceania, islands in the South Pacific Ocean, east of
Oceania
100 sq km (2003)
total: 19,060 sq km
land: 18,575 sq km
water: 485 sq km
none (overseas territory of France)
55,300 (2005)
134,300 (2005)
76,000 (2005)
.nc
NA
NA
NA
0 bbl/day (2003 est.)
10,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 27.8 years
male: 27.4 years
female: 28.2 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
13,962 (2006)
NA','5a782de126904fd045ef94256b32830ab97e91c903fe65e8119498c0ff0cf101','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('219fe9e36a209382b50551259972361a572604db8de7e4b0d4804d945e6196fd',2006,'NZ','New Zealand','communications',938,'predominately mountainous with some large coastal plains
1.79 children born/woman (2006 est.)
parliamentary democracy
3.7% (2005 est.)
conventional long form: none
conventional short form: New Zealand
abbreviation: NZ
Oceania, islands in the South Pacific Ocean, southeast
of Australia
Oceania
2,850 sq km (2003)
total: 268,680 sq km
land: 268,021 sq km
water: NA
note: includes Antipodes Islands, Auckland Islands, Bounty Islands,
Campbell Island, Chatham Islands, and Kermadec Islands
chief of mission: Ambassador Roy N. FERGUSON
chancery: 37 Observatory Circle NW, Washington, DC 20008
telephone: [1] (202) 328-4800
FAX: [1] (202) 667-5227
consulate(s) general: Los Angeles, New York
1,800,500 (2004)
3.53 million (2005)
3.2 million (2005)
.nz
0.1% (2003 est.)
1,400 (2003 est.)
less than 200 (2003 est.)
36.2 (1997)
31,740 bbl/day (2003 est.)
151,900 bbl/day (2003 est.)
119,700 bbl/day (2001)
30,220 bbl/day (2001)
total: 33.9 years
male: 33.2 years
female: 34.7 years (2006 est.)
89.62 million bbl (1 January 2002)
37.38 billion cu m (1 January 2002)
4.773 billion cu m (2003 est.)
4.773 billion cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
1,050,197 (2006)
23.8% of GDP (2005 est.)
21.3% of GDP (2005 est.)
$-9.688 billion (2005 est.)
$8.893 billion (2005 est.)
$94.6 billion (2005 est.)','2400435d870b32df696c517863972b5bdc6e9b4559e5c3fa2f6ef01c1b3396fb','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfd04d3c7e797698fb43dff8df9267732977dd8cf318d4153e0b90c6a843fa6c',2006,'NI','Nicaragua','communications',939,'extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by
volcanoes
2.75 children born/woman (2006 est.)
republic
5.6% plus underemployment of 46.5% (2005 est.)
conventional long form: Republic of Nicaragua
conventional short form: Nicaragua
local long form: Republica de Nicaragua
local short form: Nicaragua
Central America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Costa Rica and Honduras
Central America and the Caribbean
610 sq km (2003)
total: 129,494 sq km
land: 120,254 sq km
water: 9,240 sq km
chief of mission: Ambassador Salvador STADTHAGEN
chancery: 1627 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 939-6570, [1] (202) 939-6573
FAX: [1] (202) 939-6545
consulate(s) general: Houston, Los Angeles, Miami, New York, San
Francisco
220,900 (2005)
1.119 million (2005)
140,000 (2005)
.ni
0.2% (2003 est.)
6,400 (2003 est.)
less than 500 (2003 est.)
55.1 (2001)
14,300 bbl/day (2005 est.)
25,200 bbl/day (2005 est.)
15,560 bbl/day (2005 est.)
758.9 bbl/day (2004)
total: 20.9 years
male: 20.5 years
female: 21.4 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
24,452 (2006)
27% of GDP (2005 est.)
82.3% of GDP (2005 est.)
$-835 million (2005 est.)
$727.8 million (2005 est.)
$5.03 billion (2005 est.)','38a2999abe2131e93140349107964df98ea14f3fb88ec03e7477f7952e358064','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61d239d3619f9a9e7f1702b8d1e571be4b703fb7ff4f68eedeb18bc651033c75',2006,'NE','Niger','communications',940,'predominately desert plains and sand dunes; flat to rolling
plains in south; hills in north
7.46 children born/woman (2006 est.)
republic
NA%
conventional long form: Republic of Niger
conventional short form: Niger
local long form: Republique du Niger
local short form: Niger
Western Africa, southeast of Algeria
Africa
730 sq km (2003)
total: 1.267 million sq km
land: 1,266,700 sq km
water: 300 sq km
chief of mission: Ambassador Aminata Maiga Djibrilla TOURE
chancery: 2204 R Street NW, Washington, DC 20008
telephone: [1] (202) 483-4224 through 4227
FAX: [1] (202)483-3169
24,000 (2005)
299,900 (2005)
24,000 (2005)
.ne
1.2% (2003 est.)
70,000 (2003 est.)
4,800 (2003 est.)
50.5 (1995)
0 bbl/day (2003 est.)
5,400 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 16.5 years
male: 16.5 years
female: 16.4 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
189 (2006)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria is a high risk in some locations
respiratory disease: meningococcal meningitis (2005)
$3.432 billion (2005 est.)','4b861d48cbd8da5c4103a3ae217a985eca0dbcec15453c01e1f553dc93088239','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e30eb8b6d2bbc40497eada4d515d9c337f6efd9e6afceaca5f092a11defbafe',2006,'NG','Nigeria','communications',941,'southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
5.49 children born/woman (2006 est.)
federal republic
2.9% (2005 est.)
conventional long form: Federal Republic of Nigeria
conventional short form: Nigeria
Western Africa, bordering the Gulf of Guinea, between Benin
and Cameroon
Africa
2,820 sq km (2003)
total: 923,768 sq km
land: 910,768 sq km
water: 13,000 sq km
chief of mission: Ambassador Professor George A. OBIOZOR
chancery: 3519 International Court NW, Washington, DC 20008
telephone: [1] (202) 986-8400
FAX: [1] (202) 775-1385
consulate(s) general: Atlanta, New York
1,223,300 (2005)
21,571,131 (2006)
5 million (2005)
.ng
5.4% (2003 est.)
3.6 million (2003 est.)
310,000 (2003 est.)
50.6 (1996-97)
2.451 million bbl/day (2005 est.)
310,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.7 years
male: 18.7 years
female: 18.6 years (2006 est.)
36 billion bbl (2005 est.)
4.502 trillion cu m (2005)
19.2 billion cu m (2003 est.)
7.41 billion cu m (2003 est.)
0 cu m (2001 est.)
7.83 billion cu m (2001 est.)
1,549 (2006)
21.3% of GDP (2005 est.)
11% of GDP (2005 est.)
$5.597 billion (2005 est.)
$28.28 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria
respiratory disease: meningococcal meningitis
aerosolized dust or soil contact disease: one of the most highly
endemic areas for Lassa fever (2005)
IDPs: 200,000 - 250,000 (communal violence between
Christians and Muslims since President OBASANJO''s election in 1999)
(2005)
$77.33 billion (2005 est.)','8b5e218ab1973ca406057b4595f6d46554f98bedcb3028d003c016e8ef973398','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28cd28f3ebd017a512ff5871bc011f522d1003541a71e40323488809b97a7a42',2006,'NU','Niue','communications',942,'steep limestone cliffs along coast, central plateau
NA
self-governing parliamentary democracy
12% NA%
defense is the responsibility of New Zealand
conventional long form: none
conventional short form: Niue
former: Savage Island
Oceania, island in the South Pacific Ocean, east of Tonga
Oceania
NA
total: 260 sq km
land: 260 sq km
water: 0 sq km
none (self-governing territory in free association with New
Zealand)
1,100 est (2002)
400 (2002)
900 (2002)
.nu
NA
NA
NA
0 bbl/day (2003 est.)
20 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
0 cu m (2003 est.)
0 cu m (2003 est.)
$10.01 million','dfa5bf0518380751babb5f7aaaf4f289bb15b279d4cafc81e0b10bf88f9c6488','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96ce25c156a1b6985b6698e76d5d9f43cc726ea0b27f4fcbe87766586193a854',2006,'NF','Norfolk Island','communications',943,'volcanic formation with mostly rolling plains
NA
NA
0%
defense is the responsibility of Australia
conventional long form: Territory of Norfolk Island
conventional short form: Norfolk Island
Oceania, island in the South Pacific Ocean, east of
Oceania
NA
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
none (territory of Australia)
2,532; note - a mix of analog (2500) and digital (32)
circuits (2004)
0 (proposed cellular service disallowed in August
2002 island referendum) (2002)
700
.nf
NA
NA
NA
100 (2006)','5dbfb5933927e31b6f16d82a6b07610a297ea674a24bc1cba983690b8bb9a8e2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46710da3b40d8c4ff74d3870ea1f8763b6ddd9022a2e2c184dad264f3cdee7a5',2006,'MP','Northern Mariana Islands','communications',944,'southern islands are limestone with level
terraces and fringing coral reefs; northern islands are volcanic
1.24 children born/woman (2006 est.)
commonwealth; self-governing with locally
elected governor, lieutenant governor, and legislature
3.9% NA%
defense is the responsibility of the US
conventional long form: Commonwealth of the
conventional short form: Northern Mariana Islands
abbreviation: CNMI
former: Trust Territory of the Pacific Islands, Mariana Islands
District
Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from Hawaii to the Philippines
Oceania
NA
total: 477 sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and Tinian
21,000 (2000)
20,500 (2004)
10,000 (2003)
.mp
NA
NA
NA
total: 29.5 years
male: 31.7 years
female: 28.5 years (2006 est.)
20 (2005)
$633.4 million','9e6fb85335cb86f822b39170bea985dca37c03258f44128dfa43e2ae97320e77','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3b6e41c504f264efbb2dc1a3c7dd371105de67da7da63dc02199bcf54fe0e1e',2006,'NO','Norway','communications',945,'glaciated; mostly high plateaus and rugged mountains broken
by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
1.78 children born/woman (2006 est.)
constitutional monarchy
4.6% (2005 est.)
conventional long form: Kingdom of Norway
conventional short form: Norway
local long form: Kongeriket Norge
local short form: Norge
Northern Europe, bordering the North Sea and the North
Atlantic Ocean, west of Sweden
Europe
1,270 sq km (2003)
total: 323,802 sq km
land: 307,442 sq km
water: 16,360 sq km
chief of mission: Ambassador Knut VOLLEBAEK
chancery: 2720 34th Street NW, Washington, DC 20008
telephone: [1] (202) 333-6000
FAX: [1] (202) 337-0870
consulate(s) general: Houston, Minneapolis, New York, San Francisco
2.129 million (2005)
4.755 million (2005)
3.14 million (2005)
.no
0.1% (2001 est.)
2,100 (2001 est.)
less than 100 (2003 est.)
25.8 (2000)
3.22 million bbl/day (2005 est.)
257,200 bbl/day (2003 est.)
88,870 bbl/day (2001)
3.466 million bbl/day (2001)
total: 38.4 years
male: 37.6 years
female: 39.3 years (2006 est.)
9.859 billion bbl (1 January 2002)
2.118 trillion cu m (1 January 2002)
73.4 billion cu m (2003 est.)
4.14 billion cu m (2003 est.)
0 cu m (2001 est.)
50.5 billion cu m (2001 est.)
1,364,448 (2006)
18.7% of GDP (2005 est.)
50.1% of GDP (2005 est.)
$49.49 billion (2005 est.)
$46.99 billion (2005 est.)
$246.9 billion (2005 est.)','e8563678191a95f7ab29e0d92a80d6fc2d2f7a588676bc907309738be6cb904b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05d6f8ff618ffaae79145700bd07665017fe807e3306db9495abe9b05b7f05a2',2006,'OM','Oman','communications',946,'central desert plain, rugged mountains in north and south
Pacific Ocean
surface currents in the northern Pacific are dominated
by a clockwise, warm-water gyre (broad circular system of currents)
and in the southern Pacific by a counterclockwise, cool-water gyre;
in the northern Pacific, sea ice forms in the Bering Sea and Sea of
Okhotsk in winter; in the southern Pacific, sea ice from Antarctica
reaches its northernmost extent in October; the ocean floor in the
eastern Pacific is dominated by the East Pacific Rise, while the
western Pacific is dissected by deep trenches, including the Mariana
Trench, which is the world''s deepest
5.77 children born/woman (2006 est.)
monarchy
15% (2004 est.)
conventional long form: Sultanate of Oman
conventional short form: Oman
local long form: Saltanat Uman
local short form: Uman
former: Muscat and Oman
Middle East, bordering the Arabian Sea, Gulf of Oman, and
Persian Gulf, between Yemen and UAE
Pacific Ocean
body of water between the Southern Ocean, Asia,
Australia, and the Western Hemisphere
Middle East
Pacific Ocean
Political Map of the World
720 sq km (2003)
total: 212,460 sq km
land: 212,460 sq km
water: 0 sq km
Pacific Ocean
total: 155.557 million sq km
note: includes Bali Sea, Bering Sea, Bering Strait, Coral Sea, East
China Sea, Gulf of Alaska, Gulf of Tonkin, Philippine Sea, Sea of
Japan, Sea of Okhotsk, South China Sea, Tasman Sea, and other
tributary water bodies
chief of mission: Ambassador Hunaina bint Sultan bin Ahmad
al-MUGHAIRI
chancery: 2535 Belmont Road, NW, Washington, DC 20008
telephone: [1] (202) 387-1980 through 1981, 1988
FAX: [1] (202) 745-4933
265,200 (2005)
1.333 million (2005)
245,000 (2005)
.om
0.1% (2001 est.)
1,300 (2001 est.)
less than 200 (2003 est.)
769,000 bbl/day (2005 est.)
62,000 bbl/day (2003 est.)
NA bbl/day
721,000 bbl/day (2004)
total: 19 years
male: 21.7 years
female: 16.5 years (2006 est.)
6.1 billion bbl (2005 est.)
829.1 billion cu m (2005)
16.5 billion cu m (2003 est.)
7.09 billion cu m (2003 est.)
0 cu m (2001 est.)
7.43 billion cu m (2001 est.)
3,555 (2006)
14.8% of GDP (2005 est.)
8.1% of GDP (2005 est.)
$4.796 billion (2005 est.)
$4.358 billion (2005 est.)
$24.98 billion (2005 est.)
current situation: Oman is a destination country for men and
women primarily from Pakistan, Bangladesh, and India who migrate
willingly, but may subsequently become victims of trafficking when
subjected to conditions of involuntary servitude as domestic workers
and laborers; there have been occasional reports that expatriate
children engaged in camel racing may transit or reside in Omani
territory
tier rating: Tier 2 Watch List - Oman is placed on the Tier 2 Watch
List because of a lack of evidence of increasing efforts to combat
severe forms of trafficking in persons in 2005','b77c19ca53b89d157ef66b8e187ee9abbbffabe966f00ce964ecad6fc715c58c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('931d04543909b3084c6e8b0e56d2a8c0585a46a71b2f7735d5187007085d9fbd',2006,'PK','Pakistan','communications',947,'flat Indus plain in east; mountains in north and northwest;
Balochistan plateau in west
4 children born/woman (2006 est.)
federal republic
6.6% plus substantial underemployment (2005 est.)
conventional long form: Islamic Republic of Pakistan
conventional short form: Pakistan
local long form: Jamhuryat Islami Pakistan
local short form: Pakistan
former: West Pakistan
Southern Asia, bordering the Arabian Sea, between India on
the east and Iran and Afghanistan on the west and China in the north
Asia
182,300 sq km (2003)
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
chief of mission: Ambassador Mahmud Ali DURRANI
chancery: 3517 International Court, Washington, DC 20008
telephone: [1] (202) 243-6500
FAX: [1] (202) 686-1544
consulate(s) general: Boston, Chicago, Houston, Los Angeles, New
York, Sunnyvale (California)
5,277,500 (2005)
12.771 million (2005)
10.5 million (2005)
.pk
0.1% (2001 est.)
74,000 (2001 est.)
4,900 (2003 est.)
41 (FY98/99)
63,000 bbl/day (2005 est.)
365,000 bbl/day (2004 est.)
NA bbl/day
NA bbl/day
total: 19.8 years
male: 19.7 years
female: 20 years (2006 est.)
341.8 million bbl (2005 est.)
759.7 billion cu m (2005)
23.8 billion cu m (2003 est.)
23.8 billion cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
72,765 (2006)
15.3% of GDP (2005 est.)
53.8% of GDP (2005 est.)
$-1.109 billion (2005 est.)
$10.95 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A and E,
and typhoid fever
vectorborne diseases: dengue fever, malaria, and cutaneous
leishmaniasis are high risks depending on location
animal contact disease: rabies (2005)
refugees (country of origin): 960,041 (Afghanistan)
IDPs: undetermined (government strikes on Islamic militants in South
Waziristan); 3 million (October 2005 earthquake) (2005)
$89.55 billion (2005 est.)','fb02bf4580aeba4eb4b3eccf84a32b9d8cd238bf8eda5772febd53299c19f7c3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c9ab6658d8d555b5f91e2b4ba70f626025a220aa3bebdfa91daf9be8ac906eb',2006,'PW','Palau','communications',948,'varying geologically from the high, mountainous main island of
Babelthuap to low, coral islands usually fringed by large barrier
reefs
Palmyra Atoll
very low
2.46 children born/woman (2006 est.)
constitutional government in free association with the US; the
Compact of Free Association entered into force 1 October 1994
4.2% (2005 est.)
defense is the responsibility of the US; under a Compact of
Free Association between Palau and the US, the US military is
granted access to the islands for 50 years, but it has not stationed
any military forces there (2005)
Palmyra Atoll
defense is the responsibility of the US
conventional long form: Republic of Palau
conventional short form: Palau
local long form: Beluu er a Belau
local short form: Belau
former: Trust Territory of the Pacific Islands, Palau District
Palmyra Atoll
conventional long form: none
conventional short form: Palmyra Atoll
Oceania, group of islands in the North Pacific Ocean,
southeast of the Philippines
Palmyra Atoll
Oceania, atoll in the North Pacific Ocean, about half
way between Hawaii and American Samoa
Oceania
Palmyra Atoll
Oceania
NA
total: 458 sq km
land: 458 sq km
water: 0 sq km
Palmyra Atoll
total: 11.9 sq km
land: 11.9 sq km
water: 0 sq km
chief of mission: Ambassador Hersey KYOTA
chancery: 1700 Pennsylvania Avenue NW, Suite 400, Washington, DC
20006
telephone: [1] (202) 452-6814
FAX: [1] (202) 452-6281
consulate(s) general: Honolulu
consulate(s): Tamuning (Guam)
6,700 (2002)
1,000 (2002)
.pw
NA
NA
NA
total: 31.7 years
male: 32.7 years
female: 30.7 years (2006 est.)
3 (2006)
$15.09 million
$145 million','44f621a0660779c5ce4c03336b72db88e4f2b5ab2b8a56d0dfee6e41f3a2bd58','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a56834d1a82bb208c77f00698608ef968ab8effaea84cb6541bc92e432ede26',2006,'PA','Panama','communications',949,'interior mostly steep, rugged mountains and dissected, upland
plains; coastal areas largely plains and rolling hills
2.68 children born/woman (2006 est.)
constitutional democracy
9.8% (2005 est.)
on 10 February 1990, the government of then President ENDARA
abolished Panama''s military and reformed the security apparatus by
creating the Panamanian Public Forces; in October 1994, Panama''s
Legislative Assembly approved a constitutional amendment prohibiting
the creation of a standing military force, but allowing the
temporary establishment of special police units to counter acts of
"external aggression"
Paracel Islands
occupied by China
Pitcairn Islands
defense is the responsibility of the UK
conventional long form: Republic of Panama
conventional short form: Panama
local long form: Republica de Panama
local short form: Panama
Central America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Colombia and Costa Rica
Central America and the Caribbean
430 sq km (2003)
total: 78,200 sq km
land: 75,990 sq km
water: 2,210 sq km
chief of mission: Ambassador Federico HUMBERT Arias
chancery: 2862 McGill Terrace NW, Washington, DC 20008
telephone: [1] (202) 483-1407
FAX: [1] (202) 483-8416
consulate(s) general: Atlanta, Houston, Miami, New Orleans, New
York, Philadelphia, San Francisco, San Juan (Puerto Rico), Tampa
440,100 (2005)
1.352 million (2005)
300,000 (2005)
.pa
0.9% (2003 est.)
16,000 (2003 est.)
less than 500 (2003 est.)
56.4 (2000)
0 bbl/day (2004 est.)
78,000 bbl/day (2003 est.)
NA bbl/day; note - imports oil
NA bbl/day
total: 26.1 years
male: 25.8 years
female: 26.5 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
7,149 (2006)
16.5% of GDP (2005 est.)
64.9% of GDP (2005 est.)
$-705.7 million (2005 est.)
$1.211 billion (2005 est.)
$14.89 billion (2005 est.)','5dfc6ae92aaaee1c889797e9a6c6ef8c4c1f90335a6935a960823361284ca1ee','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('205ca86c9f7fce853e1b9c5db20eb8cde099d42ec00f610d85c319e116b329fc',2006,'PG','Papua New Guinea','communications',950,'mostly mountains with coastal lowlands and rolling
foothills
Paracel Islands
mostly low and flat
3.88 children born/woman (2006 est.)
constitutional parliamentary democracy
2.8% up to 80% in urban areas (2004)
conventional long form: Independent State of Papua
New Guinea
conventional short form: Papua New Guinea
local short form: Papuaniugini
former: Territory of Papua and New Guinea
abbreviation: PNG
Paracel Islands
conventional long form: none
conventional short form: Paracel Islands
Oceania, group of islands including the eastern
half of the island of New Guinea between the Coral Sea and the South
Pacific Ocean, east of Indonesia
Paracel Islands
Southeastern Asia, group of small islands and reefs
in the South China Sea, about one-third of the way from central
Vietnam to the northern Philippines
Oceania
Paracel Islands
Southeast Asia
NA
Paracel Islands
0 sq km
total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Paracel Islands
total: NA sq km
land: NA sq km
water: 0 sq km
chief of mission: Ambassador Evan Jeremy PAKI
chancery: 1779 Massachusetts Avenue NW, Suite 805, Washington, DC
20036
telephone: [1] (202) 745-3680
FAX: [1] (202) 745-3679
62,000 (2002)
26,000 (2005)
170,000 (2005)
.pg
0.6% (2003 est.)
16,000 (2003 est.)
600 (2003 est.)
50.9 (1996)
50,000 bbl/day (January 2006 est.)
18,000 bbl/day (January 2006 est.)
NA bbl/day
NA bbl/day
total: 21.2 years
male: 21.4 years
female: 21.1 years (2006 est.)
170 million bbl (2005 est.)
345.5 billion cu m (2005)
140 million cu m (2003 est.)
140 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
1,573 (2006)
19.2% of GDP (2005 est.)
42.9% of GDP (2005 est.)
$482.1 million (2005 est.)
$748.8 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: dengue fever and malaria are high risks in
some locations (2005)
$3.924 billion (2005 est.)','41d418065f5dbe150344a7c984ac51c333fd3aba86edcc965e90ad3809b6b33c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f3049579aa1ac5ffb9836a5d659ccff3f9f99d1c0b3c4d3a27d73f65c9d2ce7',2006,'PY','Paraguay','communications',951,'grassy plains and wooded hills east of Rio Paraguay; Gran
Chaco region west of Rio Paraguay mostly low, marshy plain near the
river, and dry forest and thorny scrub elsewhere
3.89 children born/woman (2006 est.)
constitutional republic
16% (2005 est.)
conventional long form: Republic of Paraguay
conventional short form: Paraguay
local long form: Republica del Paraguay
local short form: Paraguay
Central South America, northeast of Argentina
South America
670 sq km (2003)
total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
chief of mission: Ambassador James SPALDING Hellmers
chancery: 2400 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 483-6960 through 6962
FAX: [1] (202) 234-4508
consulate(s) general: Kansas City, Los Angeles, Miami, New York
320,300 (2005)
1.887 million (2005)
200,000 (2005)
.py
0.5% (2003 est.)
15,000 (1999 est.)
600 (2003 est.)
56.8 (1999)
0 bbl/day (2003 est.)
25,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 21.3 years
male: 21.1 years
female: 21.6 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
13,178 (2006)
19.4% of GDP (2005 est.)
36% of GDP (2005 est.)
$-255 million (2005 est.)
$1.297 billion (2005 est.)
$7.281 billion (2005 est.)','a34a56954145e84868cba436356f52aba33cc7d9c2e8711190f02c41d75b73b1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('548ccd3069223f345d322637d120ebf8ca612e9d48fed45afc59e7ce5b40e2ee',2006,'PE','Peru','communications',952,'western coastal plain (costa), high and rugged Andes in center
(sierra), eastern lowland jungle of Amazon Basin (selva)
2.51 children born/woman (2006 est.)
constitutional republic
7.6% in metropolitan Lima; widespread underemployment (2005
est.)
conventional long form: Republic of Peru
conventional short form: Peru
local long form: Republica del Peru
local short form: Peru
Western South America, bordering the South Pacific Ocean,
between Chile and Ecuador
South America
12,000 sq km (2003)
total: 1,285,220 sq km
land: 1.28 million sq km
water: 5,220 sq km
chief of mission: Ambassador Felipe ORTIZ de Zevallos
chancery: 1700 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 833-9860 through 9869
FAX: [1] (202) 659-8124
consulate(s) general: Boston, Chicago, Denver, Hartford, Houston,
Los Angeles, Miami, New York, Paterson (New Jersey), San Francisco,
Washington, DC
2,250,500 (2005)
5.583 million (2005)
4.6 million (2005)
.pe
0.5% (2003 est.)
82,000 (2003 est.)
4,200 (2003 est.)
49.8 (2000)
120,000 bbl/day (2005 est.)
157,000 bbl/day (2003 est.)
NA bbl/day
49,000 bbl/day (2004 est.)
total: 25.3 years
male: 25 years
female: 25.5 years (2006 est.)
370 million bbl (2005 est.)
247.1 billion cu m (2005)
560 million cu m (2003 est.)
910 million cu m (2004 est.)
0 cu m (2004 est.)
0 cu m (2004 est.)
269,981 (2006)
18.9% of GDP (2005 est.)
38% of GDP (2005 est.)
$1.03 billion (2005 est.)
$14.18 billion (2005 est.)
IDPs: 60,000 (civil war from 1980-2000; most IDPs are
indigenous peasants in Andean and Amazonian regions) (2005)
$69.81 billion (2005 est.)
current situation: Peru is primarily a source country for women
and children trafficked internally for the purposes of sexual
exploitation and forced domestic labor; most victims are girls and
young women moved internally from rural to urban areas, or from city
to city, and lured or coerced into prostitution in nightclubs, bars,
and brothels; Peruvians have also been trafficked for sexual
exploitation to Spain, Japan, the United States, and Venezuela; the
government acknowledges that sex tourism occurs, particularly in the
Amazon region of the country
tier rating: Tier 2 Watch List - Peru is placed on the Tier 2 Watch
List for failure to show evidence of increasing efforts to eliminate
trafficking in 2005','2244c36ba1627c407cdc567230891a65323155c03a7f074b12588871c0dc3214','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0790bad1ba1ee8ac9220966754f384e9b48501f06f8dbe8a5222cddaa8a521b4',2006,'PH','Philippines','communications',953,'mostly mountains with narrow to extensive coastal
lowlands
Pitcairn Islands
rugged volcanic formation; rocky coastline with
cliffs
3.11 children born/woman (2006 est.)
Pitcairn Islands
NA
republic
Pitcairn Islands
NA
8.7% (2005 est.)
conventional long form: Republic of the Philippines
conventional short form: Philippines
local long form: Republika ng Pilipinas
local short form: Pilipinas
Pitcairn Islands
conventional long form: Pitcairn, Henderson, Ducie,
and Oeno Islands
conventional short form: Pitcairn Islands
Southeastern Asia, archipelago between the Philippine
Sea and the South China Sea, east of Vietnam
Pitcairn Islands
Oceania, islands in the South Pacific Ocean, about
midway between Peru and New Zealand
Southeast Asia
Pitcairn Islands
Oceania
15,500 sq km (2003)
Pitcairn Islands
NA
total: 300,000 sq km
land: 298,170 sq km
water: 1,830 sq km
Pitcairn Islands
total: 47 sq km
land: 47 sq km
water: 0 sq km
chief of mission: Ambassador Willy C. GAA
chancery: 1600 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 467-9300
FAX: [1] (202) 328-7614
consulate(s) general: Chicago, Honolulu, Los Angeles, New York, San
Francisco, San Jose (Northern Mariana Islands), Tamuning (Guam)
Pitcairn Islands
none (overseas territory of the UK)
3,437,500 (2004)
Pitcairn Islands
1 (there are 17 telephones on one party line);
(2004)
32.81 million (2005)
7.82 million (2005)
Pitcairn Islands
NA
.ph
Pitcairn Islands
.pn
less than 0.1% (2003 est.)
Pitcairn Islands
NA
9,000 (2003 est.)
Pitcairn Islands
NA
less than 500 (2003 est.)
Pitcairn Islands
NA
46.6 (2003)
14,360 bbl/day (2003 est.)
335,000 bbl/day (2003 est.)
312,000 bbl/day (2003)
0 bbl/day (2001)
total: 22.5 years
male: 22 years
female: 23 years (2006 est.)
152 million bbl (1 January 2004)
106.8 billion cu m (1 January 2004)
2.3 billion cu m (2003 est.)
2.3 billion cu m (2003 est.)
0 cu m (2004 est.)
0 cu m (2004 est.)
111,262 (2006)
Pitcairn Islands
8 (2006)
15.5% of GDP (2005 est.)
72.3% of GDP (2005 est.)
$2.354 billion (2005 est.)
$18.5 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: dengue fever and malaria are high risks in
some locations
animal contact disease: rabies (2005)
IDPs: 150,000 (fighting between government troops and
MILF and Abu Sayyaf groups) (2005)
Russia
IDPs: 339,000 (displacement from Chechnya and North Ossetia)
(2005)
$91.36 billion (2005 est.)','45a973a8735f2737e80a630e802747c72e8b7e9561994ba399c6b14bb24d8104','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de57598a3613f8f5bfff70f8489332f58c995097b440103a19306ce0b46c007f',2006,'PL','Poland','communications',954,'mostly flat plain; mountains along southern border
1.25 children born/woman (2006 est.)
republic
18.2% (2005 est.)
conventional long form: Republic of Poland
conventional short form: Poland
local long form: Rzeczpospolita Polska
local short form: Polska
Central Europe, east of Germany
Europe
1,000 sq km (2003)
total: 312,685 sq km
land: 304,465 sq km
water: 8,220 sq km
chief of mission: Ambassador Janusz REITER
chancery: 2640 16th Street NW, Washington, DC 20009
telephone: [1] (202) 234-3800 through 3802
FAX: [1] (202) 328-6271
consulate(s) general: Chicago, Los Angeles, New York
11.803 million (2005)
29,166,400 (2005)
10.6 million (2005)
.pl
0.1% ; note - no country specific models provided (2001 est.)
14,000 (2003 est.)
100 (2001 est.)
34.1 (2002)
24,530 bbl/day (2003 est.)
476,200 bbl/day (2003 est.)
413,700 bbl/day (2001)
53,000 bbl/day (2001)
total: 37 years
male: 35.1 years
female: 39 years (2006 est.)
142.4 million bbl (December 2004)
154.4 billion cu m (December 2004)
4.33 billion cu m (2004)
14.97 billion cu m (2003 est.)
9.45 billion cu m (2004)
44 million cu m (2004)
358,476 (2006)
18.2% of GDP (2005 est.)
47.7% of GDP (2005 est.)
$-4.364 billion (2005 est.)
$42.56 billion (2005 est.)
$246.2 billion (2005 est.)','e3c6a4720faab9cbf081d00b3c01f08b4f23c54a68bcfec9c9e250a85b17d6f2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10b70e6c75c3074f86416dc4ef57e0dbd0be2c2e00e9f42104f621b3e03941a8',2006,'PT','Portugal','communications',955,'mountainous north of the Tagus River, rolling plains in
south
1.47 children born/woman (2006 est.)
parliamentary democracy
7.6% (2005 est.)
conventional long form: Portuguese Republic
conventional short form: Portugal
local long form: Republica Portuguesa
local short form: Portugal
Southwestern Europe, bordering the North Atlantic Ocean,
west of Spain
Europe
6,500 sq km (2003)
total: 92,391 sq km
land: 91,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
chief of mission: Ambassador Pedro Manuel Dos Reis Alves
CATARINO
chancery: 2012 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 350-5400
FAX: [1] (202) 462-3726
consulate(s) general: Boston, New York, Newark (New Jersey), San
Francisco
consulate(s): New Bedford (Massachusetts), Providence (Rhode Island)
4.234 million (2005)
11.448 million (2005)
7,782,700 (2006)
.pt
0.4% (2001 est.)
22,000 (2001 est.)
less than 1,000 (2003 est.)
38.5 (1997)
0 bbl/day (2003 est.)
326,500 bbl/day (2003 est.)
357,300 bbl/day (2001)
28,830 bbl/day (2001)
total: 38.5 years
male: 36.4 years
female: 40.6 years (2006 est.)
0 cu m (2003 est.)
2.983 billion cu m (2003 est.)
2.553 billion cu m (2001 est.)
0 cu m (2001 est.)
845,980 (2005)
21.6% of GDP (2005 est.)
63.9% of GDP (2005 est.)
$-17.1 billion (2005 est.)
$10.36 billion (2005 est.)
$170.3 billion (2005 est.)','0ca1ceff54e9ae114b5f6d03305248b50a69626b0d064001f5fcf8e4bd9fd81b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c9e7198f0064a7ce58232d828d84fa73c45ec6c7d6a994956e5a86cf2d042be',2006,'PR','Puerto Rico','communications',956,'mostly mountains with coastal plain belt in north;
mountains precipitous to sea on west coast; sandy beaches along most
coastal areas
1.75 children born/woman (2006 est.)
commonwealth
12% (2002)
defense is the responsibility of the US
Reunion
defense is the responsibility of France
Saint Helena
defense is the responsibility of the UK
conventional long form: Commonwealth of Puerto Rico
conventional short form: Puerto Rico
Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, east of the Dominican Republic
Central America and the Caribbean
400 sq km (2003)
total: 13,790 sq km
land: 8,870 sq km
water: 4,921 sq km
none (territory of the US with commonwealth status)
1,111,900 (2004)
2.682 million (2004)
1 million (2005)
.pr
NA
7,397 (1997)
NA
436.1 bbl/day (2003 est.)
218,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 34.7 years
male: 33 years
female: 36.4 years (2006 est.)
0 cu m (2003 est.)
740 million cu m (2003 est.)
630 million cu m (2001 est.)
0 cu m (2001 est.)
404 (2006)
NA','771148acd7f66fc1841f3fe912ba4ed198e4b79aa238cae552da20de59914872','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9b76d1d265832caad7b5e0d730f483e8daf107278e5ed0c59305ca9cdf9206a',2006,'QA','Qatar','communications',957,'mostly flat and barren desert covered with loose sand and
gravel
Reunion
mostly rugged and mountainous; fertile lowlands along coast
2.81 children born/woman (2006 est.)
Reunion
2.45 children born/woman (2006 est.)
traditional emirate
Reunion
NA
2.7% (2001)
Reunion
31% (2002)
conventional long form: State of Qatar
conventional short form: Qatar
local long form: Dawlat Qatar
local short form: Qatar
note: closest approximation of the native pronunciation falls
between cutter and gutter, but not like guitar
Reunion
conventional long form: Department of Reunion
conventional short form: Reunion
local long form: none
local short form: Ile de la Reunion
former: Bourbon Island
Middle East, peninsula bordering the Persian Gulf and Saudi
Arabia
Reunion
Southern Africa, island in the Indian Ocean, east of
Middle East
Reunion
World
130 sq km (2002)
Reunion
120 sq km (2003)
total: 11,437 sq km
land: 11,437 sq km
water: 0 sq km
Reunion
total: 2,517 sq km
land: 2,507 sq km
water: 10 sq km
chief of mission: Ambassador Nasir bin Hamad bin Mubarak
al-KHALIFA
chancery: 2555 M Street NW, Washington, DC 20037
telephone: [1] (202) 274-1600 and 274-1603
FAX: [1] (202) 237-0061
consulate(s) general: Houston
Reunion
none (overseas department of France)
205,400 (2005)
Reunion
300,000 (2001)
716,800 (2005)
Reunion
579,200 (2004)
219,000 (2005)
Reunion
200,000 (2005)
.qa
Reunion
.re
0.09% (2001 est.)
Reunion
NA
NA
Reunion
NA
NA
Reunion
NA
790,500 bbl/day (2005 est.)
Reunion
0 bbl/day (2003 est.)
33,000 bbl/day (2003 est.)
Reunion
18,500 bbl/day (2003 est.)
NA bbl/day
Reunion
NA bbl/day
NA bbl/day
Reunion
NA bbl/day
total: 31.7 years
male: 37.1 years
female: 22.7 years (2006 est.)
Reunion
total: 26.9 years
male: 25.7 years
female: 28.1 years (2006 est.)
16 billion bbl (2005 est.)
25.77 trillion cu m (2005)
30.8 billion cu m (2003 est.)
Reunion
0 cu m (2003 est.)
11.61 billion cu m (2003 est.)
Reunion
0 cu m (2003 est.)
0 cu m (2001 est.)
18.2 billion cu m (2004 est.)
301 (2006)
Reunion
29 (2006)
21.9% of GDP (2005 est.)
35.6% of GDP (2005 est.)
$9.27 billion (2005 est.)
$4.552 billion (2005 est.)
$28.07 billion (2005 est.)
Reunion
NA
current situation: Qatar is a destination country for men and
women from South and Southeast Asia who migrate willingly, but are
subsequently trafficked into involuntary servitude as domestic
workers and laborers; the problem of trafficking of foreign children
as camel jockeys was thoroughly addressed by government action in
2005, but independent confirmation of the problem''s complete
elimination is not yet available
tier rating: Tier 2 Watch List - Qatar has made noticeable progress
in rescuing and repatriating child camel jockeys, establishing a
shelter for abused domestic workers, and creating hotlines to
register complaints; however, Qatar is placed on the Tier 2 Watch
List for its failure to provide sufficient evidence of increasing
efforts to combat trafficking in persons in 2005, particularly with
regard to labor exploitation
Russia
current situation: Russia is a source, transit, and
destination country for men, women, and children trafficked for
various purposes; it remains a significant source of women
trafficked to over 50 countries for commercial sexual exploitation;
Russia is also a transit and destination country for men and women
trafficked from Central Asia, Eastern Europe, and North Korea to
Central and Western Europe and the Middle East for purposes of
forced labor and sexual exploitation; internal trafficking remains a
problem in Russia with women trafficked from rural areas to urban
centers for commercial sexual exploitation, and men are trafficked
internally and from Central Asia for forced labor in the
construction and agricultural industries; debt bondage is common
among trafficking victims, and child sex tourism remains a concern
tier rating: Tier 2 Watch List - Russia is placed on the Tier 2
Watch List for a third consecutive year for its continued failure to
show evidence of increasing efforts to combat trafficking,
particularly in the area of victim protection and assistance','24f69221b5ca0ad3861b5250469c58079fb4c232362d94194597e9f4469edbd8','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e32fe1ec87bef3959c2e4a2e84934d77a268eeb99055802cf4c3a9bbb3f1ecf',2006,'RO','Romania','communications',958,'central Transylvanian Basin is separated from the Plain of
Moldavia on the east by the Carpathian Mountains and separated from
the Walachian Plain on the south by the Transylvanian Alps
Russia
broad plain with low hills west of Urals; vast coniferous
forest and tundra in Siberia; uplands and mountains along southern
border regions
1.37 children born/woman (2006 est.)
Russia
1.28 children born/woman (2006 est.)
republic
Russia
federation
7.7% (2005 est.)
Russia
7.6% plus considerable underemployment (2005 est.)
conventional long form: none
conventional short form: Romania
local long form: none
local short form: Romania
Russia
conventional long form: Russian Federation
conventional short form: Russia
local long form: Rossiyskaya Federatsiya
local short form: Rossiya
former: Russian Empire, Russian Soviet Federative Socialist Republic
Southeastern Europe, bordering the Black Sea, between
Bulgaria and Ukraine
Russia
Northern Asia (the area west of the Urals is considered part
of Europe), bordering the Arctic Ocean, between Europe and the North
Pacific Ocean
Europe
Russia
Asia
30,770 sq km (2003)
Russia
46,000 sq km (2003)
total: 237,500 sq km
land: 230,340 sq km
water: 7,160 sq km
Russia
total: 17,075,200 sq km
land: 16,995,800 sq km
water: 79,400 sq km
chief of mission: Ambassador (vacant); Charge d''Affaires
Daniela GITMAN
chancery: 1607 23rd Street NW, Washington, DC 20008
telephone: [1] (202) 332-4846, 4848, 4851, 4852
FAX: [1] (202) 232-4748
consulate(s) general: Chicago, Los Angeles, New York
Russia
chief of mission: Ambassador Yuriy Viktorovich USHAKOV
chancery: 2650 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 298-5700, 5701, 5704, 5708
FAX: [1] (202) 298-5735
consulate(s) general: Houston, New York, San Francisco, Seattle
4.391 million (2005)
Russia
40.1 million (2005)
13.354 million (2005)
Russia
120 million (2005)
4.94 million (2005)
Russia
23.7 million (2005)
.ro
Russia
.ru; note - Russia also has responsibility for a legacy
domain ".su" that was allocated to the Soviet Union, and whose legal
status and ownership are contested by the Russian Government, ICANN,
and several Russian commercial entities
less than 0.1% (2001 est.)
Russia
1.1% (2001 est.)
6,500 (2001 est.)
Russia
860,000 (2001 est.)
350 (2001 est.)
Russia
9,000 (2001 est.)
28.8 (2003)
Russia
40 (2002)
119,000 bbl/day (2005 est.)
Russia
9.15 million bbl/day (2005 est.)
212,000 bbl/day (2004 est.)
Russia
2.8 million bbl/day (2005 est.)
163,000 bbl/day bbl/day (2004)
Russia
75,000 bbl/day
NA bbl/day
Russia
5.15 million bbl/day (2004)
total: 36.6 years
male: 35.3 years
female: 37.9 years (2006 est.)
Russia
total: 38.4 years
male: 35.2 years
female: 41.3 years (2006 est.)
500 million bbl (yearend 2004)
Russia
69 billion bbl (2003 est.)
300 billion cu m (yearend 2004)
Russia
47.57 trillion cu m (2003)
13.2 billion cu m (2004 est.)
Russia
587 billion cu m (2005 est.)
18.8 billion cu m (2004 est.)
Russia
402.1 billion cu m (2004 est.)
5.9 billion cu m (2004 est.)
Russia
12 billion cu m (2004 est.)
0 cu m (2003 est.)
Russia
157.2 billion cu m (2004 est.)
57,470 (2006)
Russia
1,979,924 (2006)
24.3% of GDP (2005 est.)
Russia
18.1% of GDP (2005 est.)
20.3% of GDP (2005 est.)
Russia
12.9% of GDP (2005 est.)
$-8.2 billion (2005)
Russia
$84.25 billion (2005 est.)
$21.6 billion (2005 est.)
Russia
$182.2 billion (2005 est.)
$72.7 billion (2005 est.)
Russia
$740.7 billion (2005 est.)','3abef948516795d661202332ca417bb5c7b2106c75988263383bcc6b21acc925','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf7eb5126f7cadb10f977adbb8f1ade72b56d0a2e43363d94daa1d6aeecebabd',2006,'RW','Rwanda','communications',959,'mostly grassy uplands and hills; relief is mountainous with
altitude declining from west to east
Saint Helena
the islands of this group result from volcanic activity
associated with the Atlantic Mid-Ocean Ridge
Saint Helena: rugged, volcanic; small scattered plateaus and plains
Ascension: surface covered by lava flows and cinder cones of 44
dormant volcanoes; ground rises to the east
Tristan da Cunha: sheer cliffs line the coastline of the nearly
circular island; the flanks of the central volcanic peak are deeply
dissected; narrow coastal plain lies between The Peak and the
coastal cliffs
5.43 children born/woman (2006 est.)
Saint Helena
1.55 children born/woman (2006 est.)
republic; presidential, multiparty system
Saint Helena
NA
NA%
Saint Helena
14% (1998 est.)
conventional long form: Republic of Rwanda
conventional short form: Rwanda
local long form: Republika y''u Rwanda
local short form: Rwanda
former: Ruanda, German East Africa
Saint Helena
conventional long form: none
conventional short form: Saint Helena
Central Africa, east of Democratic Republic of the Congo
Saint Helena
islands in the South Atlantic Ocean, about midway
between South America and Africa; Ascension Island lies 700 nm
northwest of Saint Helena; Tristan da Cunha lies 2300 nm southwest
of Saint Helena
Africa
Saint Helena
Africa
90 sq km (2003)
Saint Helena
NA
total: 26,338 sq km
land: 24,948 sq km
water: 1,390 sq km
Saint Helena
total: 413 sq km
land: Saint Helena Island 122 sq km; Ascension Island 90 sq km;
Tristan da Cunha island group 201 sq km
water: 0 sq km
chief of mission: Ambassador Zac NSENGA
chancery: 1714 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 232-2882
FAX: [1] (202) 232-4544
Saint Helena
none (overseas territory of the UK)
23,000 (2004)
Saint Helena
2,200 (2002)
290,000
note: Rwanda has mobile cellular service between Kigali and several
provincial capitals (2005)
Saint Helena
NA
38,000 (2005)
Saint Helena
1,000 note - includes Ascension Island (2003)
.rw
Saint Helena
.sh; note - the IANA has assigned .ac as the ccTLD for
Ascension Island
5.1% (2003 est.)
Saint Helena
NA
250,000 (2003 est.)
Saint Helena
NA
22,000 (2003 est.)
Saint Helena
NA
28.9 (1985)
0 bbl/day (2003 est.)
Saint Helena
0 bbl/day (2003 est.)
6,000 bbl/day (2003 est.)
Saint Helena
100 bbl/day (2003 est.)
NA bbl/day
Saint Helena
NA bbl/day
NA bbl/day
Saint Helena
NA bbl/day
total: 18.6 years
male: 18.4 years
female: 18.8 years (2006 est.)
Saint Helena
total: 36 years
male: 36.2 years
female: 35.8 years (2006 est.)
0 bbl (1 January 2002)
56.63 billion cu m (1 January 2002)
0 cu m (2003 est.)
Saint Helena
0 cu m (2003 est.)
0 cu m (2003 est.)
Saint Helena
0 cu m (2003 est.)
1,590 (2006)
Saint Helena
329 (2006)
18.1% of GDP (2005 est.)
$-166 million (2005 est.)
$357 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria (2005)
refugees (country of origin): 45,460 (Democratic Republic of
the Congo)
IDPs: 4,158 (incursions by Hutu rebels from Democratic Republic of
the Congo, 1997-99; most IDPs in northwest) (2005)
$1.817 billion (2005 est.)
Saint Helena
NA','6a48ba7a45d0cb17fccdf3841e5a20505f7262fd7a02abf030a87f2a6b36aabc','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc32af926545594ad21d65302d1f43a9b0084e5477fa9324808378f9fe1e0e63',2006,'KN','Saint Kitts and Nevis','communications',960,'volcanic with mountainous interiors
2.31 children born/woman (2006 est.)
parliamentary democracy
4.5% (1997)
conventional long form: Federation of Saint
Kitts and Nevis
conventional short form: Saint Kitts and Nevis
former: Federation of Saint Christopher and Nevis
Caribbean, islands in the Caribbean Sea, about
one-third of the way from Puerto Rico to Trinidad and Tobago
Central America and the Caribbean
NA
total: 261 sq km (Saint Kitts 168 sq km; Nevis
93 sq km)
land: 261 sq km
water: 0 sq km
chief of mission: Ambassador Dr. Izben
Cordinal WILLIAMS
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 686-2636
FAX: [1] (202) 686-5740
consulate(s) general: New York
25,000 (2004)
10,000 (2004)
10,000 (2002)
.kn
NA
NA
NA
0 bbl/day (2003 est.)
700 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 27.8 years
male: 27.1 years
female: 28.6 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
50 (2006)
$453 million','cedb652e8433f21ef7553c7d00ac591c90ae720a1254a0c73a8bdc3487e26722','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b2b8ed6de16791c0b42f11abc70f663e7dd0ea74b67cb21074bab00e3dd1ef3',2006,'LC','Saint Lucia','communications',961,'volcanic and mountainous with some broad, fertile valleys
2.18 children born/woman (2006 est.)
parliamentary democracy
20% (2003 est.)
conventional long form: none
conventional short form: Saint Lucia
Caribbean, island between the Caribbean Sea and North
Atlantic Ocean, north of Trinidad and Tobago
Central America and the Caribbean
30 sq km (2003)
total: 616 sq km
land: 606 sq km
water: 10 sq km
chief of mission: Ambassador Sonia Merlyn JOHNNY
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 364-6792 through 6795
FAX: [1] (202) 364-6723
consulate(s) general: Miami, New York
51,100 (2002)
93,000 (2004)
55,000 (2005)
.lc
NA
NA
NA
0 bbl/day (2003 est.)
2,520 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 25.2 years
male: 24.4 years
female: 26.1 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
21 (2006)
$825 million','af59e2c6a7c10c41984775d826fffa20ab721d62680c2d5b99aa96b9871adec0','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9ab1b4ee93fee87484fb49a31c0ebf25fde67346fa6cdf9a30d4aaac4d6793',2006,'PM','Saint Pierre and Miquelon','communications',962,'mostly barren rock
2.01 children born/woman (2006 est.)
NA
10.3% (1999)
defense is the responsibility of France
conventional long form: Territorial
Collectivity of Saint Pierre and Miquelon
conventional short form: Saint Pierre and Miquelon
local long form: Departement de Saint-Pierre et Miquelon
local short form: Saint-Pierre et Miquelon
Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland (Canada)
North America
NA
total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the Saint Pierre and the
Miquelon groups
none (territorial collectivity of France)
4,800 (2002)
NA
NA
.pm
NA
NA
NA
0 bbl/day (2003 est.)
480 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 34.1 years
male: 33.7 years
female: 34.5 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
0 (2006)
NA','e42bbd08620d85977b7c454aabf973edc1bd1ad7f8a533e9391676dbbb645f12','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c133f2c23243d1af983934492f9435caaad7eb78c394d78a240e4f8aa5a5499',2006,'VC','Saint Vincent and the Grenadines','communications',963,'volcanic, mountainous
1.83 children born/woman (2006 est.)
parliamentary democracy
15% (2001 est.)
conventional long form: none
conventional short form: Saint Vincent and the Grenadines
Caribbean, islands between the
Caribbean Sea and North Atlantic Ocean, north of Trinidad and Tobago
Central America and the Caribbean
10 sq km (2003)
total: 389 sq km (Saint Vincent 344
sq km)
land: 389 sq km
water: 0 sq km
chief of mission: Ambassador
Ellsworth I. A. JOHN
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 364-6730
FAX: [1] (202) 364-6736
consulate(s) general: New York
22,500 (2005)
70,600 (2005)
8,000 (2005)
.vc
NA
NA
NA
0 bbl/day (2003 est.)
1,300 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 26.9 years
male: 26.7 years
female: 27.1 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
94 (2006)
$428 million','fc3afd63c9ace6c84557cf82adfa151ef5645a0cc5ac4db45dfd03e0fb44cc60','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fb5d2a41eb4ed621608a01f6b7b0de43ea47786251f58625e3388ccfa67a3a0',2006,'WS','Samoa','communications',964,'two main islands (Savaii, Upolu) and several smaller islands
and uninhabited islets; narrow coastal plain with volcanic, rocky,
rugged mountains in interior
2.94 children born/woman (2006 est.)
mix of parliamentary democracy and constitutional monarchy
NA%
Samoa has no formal defense structure or regular armed forces;
informal defense ties exist with NZ, which is required to consider
any Samoan request for assistance under the 1962 Treaty of Friendship
conventional long form: Independent State of Samoa
conventional short form: Samoa
local long form: Malo Sa''oloto Tuto''atasi o Samoa
local short form: Samoa
former: Western Samoa
Oceania, group of islands in the South Pacific Ocean, about
one-half of the way from Hawaii to New Zealand
Oceania
NA
total: 2,944 sq km
land: 2,934 sq km
water: 10 sq km
chief of mission: Ambassador Aliioaiga Feturi ELISAIA
chancery: 800 Second Avenue, Suite 400D, New York, NY 10017
telephone: [1] (212) 599-6196, 6197
FAX: [1] (212) 599-0797
13,300 (2003)
24,000 (2005)
6,000 (2004)
.ws
NA
12
3
0 bbl/day (2003 est.)
1,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 25.2 years
male: 28.1 years
female: 22 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
10,680 (2006)
$-2.428 million
$70.15 million
$399 million','553bfaa996c494ac48076a2c53e95f0524e4cb38bf93af9ea86bad2a804e6949','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01a21647de49fec348130a5ac91c217c8116dfcaf0c8fd711657178ff343a018',2006,'SM','San Marino','communications',965,'rugged mountains
1.34 children born/woman (2006 est.)
independent republic
2.6% (2001)
defense is the responsibility of Italy
conventional long form: Republic of San Marino
conventional short form: San Marino
local long form: Repubblica di San Marino
local short form: San Marino
Southern Europe, an enclave in central Italy
Europe
NA
total: 61.2 sq km
land: 61.2 sq km
water: 0 sq km
San Marino does not have an embassy in the US
honorary consulate(s) general: New York, Washington, DC
honorary consulate(s): Detroit, Honolulu
20,600 (2002)
16,800 (2002)
14,300 (2002)
.sm
NA
NA
NA
total: 40.6 years
male: 40.3 years
female: 41 years (2006 est.)
3,140 (2006)
$880 million','4b0caa160633cf5c2ec36874ebb92edf94bf1971b74bf5aabe8ddb392f6a5908','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee6b69c291b4480607773290efee6520926b000d9b82efd7d7bcc08640f4f345',2006,'ST','Sao Tome and Principe','communications',966,'volcanic, mountainous
5.62 children born/woman (2006 est.)
republic
NA%
Sao Tome and Principe''s army is a tiny force
with almost no resources at its disposal and would be wholly
ineffective operating unilaterally; infantry equipment is considered
simple to operate and maintain but may require refurbishment or
replacement after 25 years in tropical climates; poor pay and
conditions have been a problem in the past, as has alleged nepotism
in the promotion of officers, as reflected in the 1995 and 2003
coups; these issues are being addressed with foreign assistance as
initial steps towards the improvement of the army and its focus on
realistic security concerns; command is exercised from the
president, through the Minister of Defense, to the Chief of the
Armed Forces staff (2005)
conventional long form: Democratic Republic of
conventional short form: Sao Tome and Principe
local long form: Republica Democratica de Sao Tome e Principe
local short form: Sao Tome e Principe
Western Africa, islands in the Gulf of Guinea,
straddling the Equator, west of Gabon
Africa
100 sq km (2003)
total: 1,001 sq km
land: 1,001 sq km
water: 0 sq km
chief of mission: First Secretary Domingos
Augusto FERREIRA
chancery: 400 Park Avenue, 7th Floor, New York, NY 10022
telephone: [1] (212) 317-0580
FAX: [1] (212) 935-7348
consulate(s): Atlanta
7,000 (2004)
12,000 (2005)
20,000 (2005)
.st
NA
NA
NA
0 bbl/day (2003 est.)
650 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 16.2 years
male: 15.6 years
female: 16.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
735 (2006)
32.2% of GDP (2005 est.)
$-20 million (2005 est.)
$20 million (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne disease: malaria (2005)
$71.38 million','afc38f9f94222a0616e8ead55e13186fe5e09c69add07e29dc9346b8503ebcb8','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed42ef8be3d7191b6f4e60695edffbc9f310908a79845c2525249368c086e189',2006,'SA','Saudi Arabia','communications',967,'mostly uninhabited, sandy desert
4 children born/woman (2006 est.)
monarchy
13% among Saudi males only (local bank estimate; some
estimates range as high as 25%) (2004 est.)
conventional long form: Kingdom of Saudi Arabia
conventional short form: Saudi Arabia
local long form: Al Mamlakah al Arabiyah as Suudiyah
local short form: Al Arabiyah as Suudiyah
Middle East, bordering the Persian Gulf and the Red
Sea, north of Yemen
Middle East
16,200 sq km (2003)
total: 1,960,582 sq km
land: 1,960,582 sq km
water: 0 sq km
chief of mission: Ambassador TURKI al-Faysal bin Abd
al-Aziz Al Saud
chancery: 601 New Hampshire Avenue NW, Washington, DC 20037
telephone: [1] (202) 342-3800
FAX: [1] (202) 944-3113
consulate(s) general: Houston, Los Angeles, New York
3.8 million (2005)
13.3 million (2005)
2.54 million (2005)
.sa
0.01% (2001 est.)
NA
NA
9.475 million bbl/day (2005 est.)
1.775 million bbl/day (2003)
0 bbl/day (2003)
7.92 million bbl/day (2003)
total: 21.4 years
male: 22.9 years
female: 19.4 years (2006 est.)
262.7 billion bbl (2005 est.)
6.544 trillion cu m (2005)
60.06 billion cu m (2003 est.)
60.06 billion cu m (2003 est.)
0 cu m (2002)
0 cu m (2002)
10,931 (2006)
16.3% of GDP (2005 est.)
44.2% of GDP (2005 est.)
$90.73 billion (2005 est.)
$26.76 billion (2005 est.)
refugees (country of origin): 240,000 (Palestinian
Territories) (2005)
$264 billion (2005 est.)
current situation: Saudi Arabia is a destination
country for workers from South and Southeast Asia who are subjected
to conditions that constitute involuntary servitude including being
subjected to physical and sexual abuse, non-payment of wages,
confinement, and withholding of passports as a restriction on their
movement; domestic workers are particularly vulnerable because some
are confined to the house in which they work, unable to seek help;
Saudi Arabia is also a destination country for Nigerian, Yemeni,
Pakistani, Afghan, Somali, Malian, and Sudanese children trafficked
for forced begging and involuntary servitude as street vendors; some
Nigerian women were reportedly trafficked into Saudi Arabia for
commercial sexual exploitation
tier rating: Tier 3 - Saudi Arabia does not fully comply with the
minimum standards for the elimination of trafficking and is not
making significant efforts to do so','c37637257e400592624b36b23b6f1db84311ebd7b378771980ce9bb39a2f8cdd','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1b52d6fec050c62ee1a9b932c92cbfc8ad5634e4a66a866fd35859629359312',2006,'SN','Senegal','communications',968,'generally low, rolling, plains rising to foothills in
southeast
4.38 children born/woman (2006 est.)
republic
48%; note - urban youth 40% (2001 est.)
conventional long form: Republic of Senegal
conventional short form: Senegal
local long form: Republique du Senegal
local short form: Senegal
former: Senegambia (along with The Gambia); Mali Federation
Gaza Strip
Middle East, bordering the Mediterranean Sea, between
Egypt and Israel
Western Africa, bordering the North Atlantic Ocean, between
Guinea-Bissau and Mauritania
Africa
1,200 sq km (2003)
total: 196,190 sq km
land: 192,000 sq km
water: 4,190 sq km
chief of mission: Ambassador Amadou Lamine BA
chancery: 2112 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-0540
FAX: [1] (202) 332-6315
consulate(s) general: Houston, New York
266,600 (2005)
1.73 million (2005)
540,000 (2005)
.sn
0.8% (2003 est.)
44,000 (2003 est.)
3,500 (2003 est.)
41.3 (1995)
0 bbl/day (2003 est.)
31,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 19.1 years
male: 18.9 years
female: 19.3 years (2006 est.)
50 million cu m (2003 est.)
50 million cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
412 (2006)
20.1% of GDP (2005 est.)
46% of GDP (2005 est.)
$-848 million (2005 est.)
$1.191 billion (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: dengue fever, malaria, yellow fever,
Crimean-Congo hemorrhagic fever, and Rift Valley fever are high
risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
refugees (country of origin): 19,778 (Mauritania)
IDPs: 17,000 (clashes between government troops and separatists in
Casamance region) (2005)
$7.972 billion (2005 est.)','2eaa87065760b9eafb4ab0651f3c801a3e8dd00230fe4ff373081847b87a06ea','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f06b7d3e640e395c0b388c3a32a13e0f7f25a118e542f074b8cd9768bee64ad',2006,'RS','Serbia','communications',969,'extremely varied; to the north, rich fertile plains; to the
east, limestone ranges and basins; to the southeast, ancient
mountains and hills
1.78 children born/woman (2006 est.)
republic
31.6%
note: unemployment is approximately 50% in Kosovo (2005 est.)
conventional long form: Republic of Serbia
conventional short form: Serbia
local long form: Republika Srbija
local short form: Srbija
former: People''s Republic of Serbia, Socialist Republic of Serbia
Southeastern Europe, between Macedonia and Hungary
Europe
NA
total: 88,361 sq km
land: 88,361 sq km
water: 0 sq km
chief of mission: Ambassador Ivan VUJACIC
chancery: 2134 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 332-0333
FAX: [1] (202) 332-3933
consulate(s) general: Chicago, New York
2,685,400 (2004)
5.229 million (2005)
1.4 million (2006)
.rs; note - former ccTLD .yu will remain in service until the
end of 2006
14,660 bbl/day (2003)
85,000 bbl/day (2003 est.)
total: 40.4 years
male: 39.1 years
female: 41.7 years
38.75 million bbl (1 January 2002)
48.14 billion cu m (1 January 2002)
650 million cu m (2003 est.)
2.55 billion cu m (2003 est.)
0 cu m
0 cu m
NA
14.2% of GDP (2005 est.)
53.1% of GDP (2005 est.)
$-2.451 billion (2005 est.)
$5.35 billion
refugees (country of origin): 180,117 (Croatia); 95,297
(Bosnia and Herzegovina)
IDPs: 225,000 - 251,000 (mostly ethnic Serbs and Roma who fled
Kosovo in 1999) (2005)
$19.19 billion for Serbia alone (excluding Kosovo) (2005 est.)','bd2fb7958d6855ae14af0e00d81672893e4169ecaaff1677feabbf47d6dad501','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bf933b9a128f816935ba3a97533159dd1ba48bf24bfff61c309f16c79306f7e',2006,'SC','Seychelles','communications',970,'Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
1.74 children born/woman (2006 est.)
republic
NA%
conventional long form: Republic of Seychelles
conventional short form: Seychelles
local long form: Republic of Seychelles
local short form: Seychelles
archipelago in the Indian Ocean, northeast of Madagascar
Africa
NA
total: 455 sq km
land: 455 sq km
water: 0 sq km
chief of mission: Ambassador Jeremie BONNELAME
chancery: 800 Second Avenue, Suite 400C, New York, NY 10017
telephone: [1] (212) 972-1785
FAX: [1] (212) 972-1786
21,400 (2005)
57,000 (2005)
20,000 (2005)
.sc
NA
NA
NA
0 bbl/day (2003 est.)
7,600 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 28.1 years
male: 27 years
female: 29.1 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
72 (2006)
42% of GDP (2005 est.)
167% of GDP (2005 est.)
$-32 million (2005 est.)
$41 million (2005 est.)
$722 million (2005 est.)','e8ac0b3c4f6f19c012a8a74a1e867e5125136bb82baa0c44c971b55e222b3672','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9773806cc31f195f24eb228317dbddc497073bc85c44317e42be9d8dec3eacfa',2006,'SL','Sierra Leone','communications',971,'coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
6.08 children born/woman (2006 est.)
constitutional democracy
NA%
conventional long form: Republic of Sierra Leone
conventional short form: Sierra Leone
local long form: Republic of Sierra Leone
local short form: Sierra Leone
Western Africa, bordering the North Atlantic Ocean,
between Guinea and Liberia
Africa
300 sq km (2003)
total: 71,740 sq km
land: 71,620 sq km
water: 120 sq km
chief of mission: Ambassador Ibrahim M. KAMARA
chancery: 1701 19th Street NW, Washington, DC 20009
telephone: [1] (202) 939-9261 through 9263
FAX: [1] (202) 483-1793
24,000 (2002)
113,200 (2003)
10,000 (2005)
.sl
7% (2001 est.)
170,000 (2001 est.)
11,000 (2001 est.)
62.9 (1989)
0.8361 bbl/day (2003 est.)
6,510 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.4 years
male: 17.1 years
female: 17.7 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
20 (2006)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are high risks in
some locations
water contact disease: schistosomiasis
aerosolized dust or soil contact disease: Lassa fever (2005)
refugees (country of origin): 65,433 (Liberia) (2005)
$1.128 billion (2005 est.)','474b781de174c1abbdc9b7ecbcd64a29ae94d353b4879914000123d576c49937','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95bb4d9193f9d42a01be6bb9e4127a14e3bd19336dd6d17b5051186bfa4ad233',2006,'SG','Singapore','communications',972,'lowland; gently undulating central plateau contains water
catchment area and nature preserve
1.06 children born/woman (2006 est.)
parliamentary republic
3.1% (2005 est.)
conventional long form: Republic of Singapore
conventional short form: Singapore
local long form: Republic of Singapore
local short form: Singapore
Southeastern Asia, islands between Malaysia and Indonesia
Southeast Asia
NA
total: 692.7 sq km
land: 682.7 sq km
water: 10 sq km
chief of mission: Ambassador CHAN Heng Chee
chancery: 3501 International Place NW, Washington, DC 20008
telephone: [1] (202) 537-3100
FAX: [1] (202) 537-0876
consulate(s) general: San Francisco
consulate(s): New York
1.848 million (2005)
4.385 million (2005)
2,421,800 (2005)
.sg
0.2% (2003 est.)
4,100 (2003 est.)
less than 200 (2003 est.)
42.5 (1998)
8,290 bbl/day (2003 est.)
800,000 bbl/day (2005 est.)
NA bbl/day
NA bbl/day
total: 37.3 years
male: 36.9 years
female: 37.6 years (2006 est.)
0 cu m (2004 est.)
5.32 billion cu m (2003 est.)
2.5 billion cu m
note: from Indonesia and Malaysia (2001 est.)
0 cu m (2001 est.)
898,762 (2006)
21.8% of GDP (2005 est.)
102.9% of GDP (2005 est.)
$32.74 billion (2005 est.)
$115.8 billion (2005 est.)
$110.6 billion (2005 est.)','d6e0429bc03348a7b96894e95bb6766de8aa88c0178df86d29b56928a725269f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95c1ff952b697a7f137d3958627dd82abfe1d0b852868bcdd243313d27585381',2006,'SK','Slovakia','communications',973,'rugged mountains in the central and northern part and
lowlands in the south
1.33 children born/woman (2006 est.)
parliamentary democracy
16.4% (2005 est.)
conventional long form: Slovak Republic
conventional short form: Slovakia
local long form: Slovenska Republika
local short form: Slovensko
Central Europe, south of Poland
Europe
1,830 sq km (2003)
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
chief of mission: Ambassador Rastislav KACER
chancery: 3523 International Court NW, Washington, DC 20008
telephone: [1] (202) 237-1054
FAX: [1] (202) 237-6438
consulate(s) general: Los Angeles, New York
1.197 million (2005)
4.54 million (2005)
2.5 million (2005)
.sk
less than 0.1% (2001 est.)
less than 200 (2003 est.)
less than 100 (2001 est.)
25.8 (1996)
11,480 bbl/day (2005 est.)
74,000 bbl/day (2004 est.)
59,000 bbl/day bbl/day
2,160 bbl/day NA bbl/day
total: 35.8 years
male: 34.2 years
female: 37.6 years (2006 est.)
9 million bbl (1 January 2006)
15.01 billion cu m (1 January 2003)
165 million cu m (2004 est.)
6.8 billion cu m (2004 est.)
7.3 billion cu m (2004 est.)
1 million cu m (2004 est.)
210,758 (2006)
26% of GDP (2005 est.)
42.5% of GDP (2005 est.)
$-4.066 billion (2005 est.)
$14.97 billion (2005 est.)
$43.07 billion (2005 est.)','6a73b2a6861cb4b5d13c651dc7ac4643b66ecc0d4c05acb2a46f826b001bda5a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b5130298ed6b5455541abc320b16e6ed39fb7146b2a9d613b1139065717cef2',2006,'SI','Slovenia','communications',974,'a short coastal strip on the Adriatic, an alpine mountain
region adjacent to Italy and Austria, mixed mountains and valleys
with numerous rivers to the east
1.25 children born/woman (2006 est.)
parliamentary republic
6.3% (2005 est.)
conventional long form: Republic of Slovenia
conventional short form: Slovenia
local long form: Republika Slovenija
local short form: Slovenija
former: People''s Republic of Slovenia, Socialist Republic of Slovenia
Central Europe, eastern Alps bordering the Adriatic Sea,
between Austria and Croatia
Europe
30 sq km (2003)
total: 20,273 sq km
land: 20,151 sq km
water: 122 sq km
chief of mission: Ambassador Samuel ZBOGAR
chancery: 1525 New Hampshire Avenue NW, Washington, DC 20036
telephone: [1] (202) 667-5363
FAX: [1] (202) 667-4563
consulate(s) general: Cleveland, New York
816,400 (2005)
1.759 million (2005)
1.09 million (2005)
.si
less than 0.1% (2001 est.)
280 (2001 est.)
less than 100 (2003 est.)
28.4 (1998)
11.05 bbl/day (2003 est.)
52,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 40.6 years
male: 39 years
female: 42.2 years (2006 est.)
0 cu m (2003 est.)
1.1 billion cu m (2003 est.)
963 million cu m (2002)
0 cu m (2003)
61,735 (2006)
24.8% of GDP (2005 est.)
28.5% of GDP (2005 est.)
$-303 million (2005 est.)
$8.16 billion (2005 est.)
$35.21 billion (2005 est.)','85e645c9bea58ff70e185df7c0fbf38010ec72fab2cf034bf256596b9096f582','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8db3ecbca206e5a6ecec42188d7370d186078cfc5d75eb8cc8b1183c728f78d',2006,'SB','Solomon Islands','communications',975,'mostly rugged mountains with some low coral atolls
3.91 children born/woman (2006 est.)
parliamentary democracy
NA%
June 2003 Prime Minister Sir Allan KEMAKEZA sought
the intervention of Australia to aid in restoring order; parliament
approved the request for intervention in July 2003; troops from
Australia, NZ, Fiji, Papua New Guinea, and Tonga arrived 24 July
2003; by 2006, the Regional Assistance Mission to the Solomon
Islands (RAMSI) had been scaled back to 259 police officers and 20
military, in addition to civilian technical advisers; in response to
rioting that broke out in mid-April 2006, Australia dispatched an
addtional 220 troops and 70 police officers to help restore order
conventional long form: none
conventional short form: Solomon Islands
local long form: none
local short form: Solomon Islands
former: British Solomon Islands
Oceania, group of islands in the South Pacific
Ocean, east of Papua New Guinea
Oceania
NA
total: 28,450 sq km
land: 27,540 sq km
water: 910 sq km
chief of mission: Ambassador Collin David BECK
chancery: 800 Second Avenue, Suite 400L, New York, NY 10017
telephone: [1] (212) 599-6192, 6193
FAX: [1] (212) 661-8925
7,400 (2005)
6,000 (2005)
8,400 (2005)
.sb
NA
NA
NA
0 bbl/day (2003 est.)
1,270 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.9 years
male: 18.7 years
female: 19 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
2,658 (2006)
$286 million','a46fc4a7c9f06511f39bf888cec8b0672326aff7a367ff484e22872f976beed2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf17261adef0a8b7aad3d38da1bb0d94dba40544a78d16f7985635360d2b99e5',2006,'SO','Somalia','communications',976,'mostly flat to undulating plateau rising to hills in north
6.76 children born/woman (2006 est.)
no permanent national government; transitional,
parliamentary federal government
NA%
although an interim government was created in 2004, other
regional and local governing bodies continue to exist and control
various cities and regions of the country, including the
self-declared Republic of Somaliland in northwestern Somalia, the
semi-autonomous State of Puntland in northeastern Somalia, and
traditional clan and faction strongholds
This page was last updated on 19 December, 2006
======================================================================
@2142 Country name
conventional long form: none
conventional short form: Somalia
local long form: Jamhuuriyada Demuqraadiga Soomaaliyeed
local short form: Soomaaliya
former: Somali Republic; Somali Democratic Republic
Eastern Africa, bordering the Gulf of Aden and the Indian
Ocean, east of Ethiopia
Africa
2,000 sq km (2003)
total: 637,657 sq km
land: 627,337 sq km
water: 10,320 sq km
Somalia does not have an embassy in the US (ceased
operations on 8 May 1991); note - the TFG and other factions have
representatives in Washington and at the United Nations
100,000 (2005)
500,000 (2005)
90,000 (2005)
.so
1% (2001 est.)
43,000 (2001 est.)
NA
0 bbl/day (2003 est.)
5,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 17.6 years
male: 17.5 years
female: 17.7 years (2006 est.)
0 bbl (1 January 2002)
5.663 billion cu m (1 January 2002)
0 cu m (2003 est.)
0 cu m (2003 est.)
3 (2006)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A and E, and typhoid fever
vectorborne diseases: malaria and dengue fever are high risks in
some locations
water contact disease: schistosomiasis
animal contact disease: rabies (2005)
IDPs: 400,000 (civil war since 1988, clan-based competition
for resources) 5,000 (26 December 2004 tsunami) (2005)
$2.483 billion','3783402f03609c3bc8d0a82147388995af4672f64028c46dd61c87c4d4c5ade5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f27aefb7abad5b9e290dc31705341b1f7913dcbd79c98bc94d2ee29d15018f9',2006,'ZA','South Africa','communications',977,'vast interior plateau rimmed by rugged hills and narrow
coastal plain
2.2 children born/woman (2006 est.)
republic
26.6% (2005 est.)
with the end of apartheid and the establishment of
majority rule, former military, black homelands forces, and
ex-opposition forces were integrated into the South African National
Defense Force (SANDF); as of 2003 the integration process was
considered complete
conventional long form: Republic of South Africa
conventional short form: South Africa
former: Union of South Africa
abbreviation: RSA
Southern Africa, at the southern tip of the continent
of Africa
Africa
14,980 sq km (2003)
total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands (Marion Island and Prince
Edward Island)
chief of mission: Ambassador Barbara Joyce Mosima
MASEKELA
chancery: 3051 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 232-4400
FAX: [1] (202) 265-1607
consulate(s) general: Chicago, Los Angeles, New York
4.729 million (2005)
33.96 million (2005)
5.1 million (2005)
.za
21.5% (2003 est.)
5.3 million (2003 est.)
370,000 (2003 est.)
59.3 (1995)
216,700 bbl/day (2003 est.)
484,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 24.1 years
male: 23.3 years
female: 25 years (2006 est.)
7.84 million bbl (1 January 2002)
28.32 million cu m (1 January 2002)
2.35 billion cu m (2003 est.)
2.35 billion cu m (2003 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
645,179 (2006)
16.8% of GDP (2005 est.)
35.8% of GDP (2005 est.)
$-11.08 billion (2005 est.)
$20.63 billion (2005 est.)
refugees (country of origin): 5,774 (Angola) 9,516
(Democratic Republic of Congo) 7,118 (Somalia) (2005)
$187.3 billion (2005 est.)
current situation: South Africa is a source, transit,
and destination country for men, women, and children trafficked for
forced labor and sexual exploitation; women and girls are trafficked
internally - and occasionally to European and Asian countries - for
sexual exploitation; women from other African countries are
trafficked to South Africa and, less frequently, onward to Europe
for sexual exploitation; men and boys are trafficked from
neighboring countries for forced agricultural labor; Asian and
Eastern European women are trafficked to South Africa for
debt-bonded sexual exploitation
tier rating: Tier 2 Watch List - South Africa is placed on the Tier
2 Watch List for its failure to show increasing efforts to address
trafficking in 2005','f65fd35714748172638965c2aefe5ad38d30d901bddd637de5b4700d443ca8ae','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14963ab4e7ffa7194e58733a766d375401622f40684c4c6314eeae46bc0c44b0',2006,'GS','South Georgia and the South Sandwich Islands','communications',978,'most of the islands,
rising steeply from the sea, are rugged and mountainous; South
Georgia is largely barren and has steep, glacier-covered mountains;
the South Sandwich Islands are of volcanic origin with some active
volcanoes
Southern Ocean
the Southern Ocean is deep, 4,000 to 5,000 meters
over most of its extent with only limited areas of shallow water;
the Antarctic continental shelf is generally narrow and unusually
deep, its edge lying at depths of 400 to 800 meters (the global mean
is 133 meters); the Antarctic icepack grows from an average minimum
of 2.6 million square kilometers in March to about 18.8 million
square kilometers in September, better than a sixfold increase in
area; the Antarctic Circumpolar Current (21,000 km in length) moves
perpetually eastward; it is the world''s largest ocean current,
transporting 130 million cubic meters of water per second - 100
times the flow of all the world''s rivers
defense is the
responsibility of the UK
Spratly Islands
Spratly Islands consist of more than 100 small
islands or reefs, of which about 45 are claimed and occupied by
China, Malaysia, the Philippines, Taiwan, and Vietnam
Svalbard
demilitarized by treaty on 9 February 1920
conventional long form:
conventional short form: none
abbreviation: SGSSI
Southern South America,
islands in the South Atlantic Ocean, east of the tip of South America
Southern Ocean
body of water between 60 degrees south latitude and
Antarctic Region
Southern Ocean
Antarctic Region
0 sq km
total: 3,903 sq km
land: 3,903 sq km
water: 0 sq km
note: includes Shag Rocks, Black Rock, Clerke Rocks, South Georgia
Island, Bird Island, and the South Sandwich Islands, which consist
of eleven islands
Southern Ocean
total: 20.327 million sq km
note: includes Amundsen Sea, Bellingshausen Sea, part of the Drake
Passage, Ross Sea, a small part of the Scotia Sea, Weddell Sea, and
other tributary water bodies
none (overseas
territory of the UK, also claimed by Argentina)
.gs
271 (2006)','a89c1f115c46959e9ff55be688253aeb7f5984e44e386af66f8403e075454ed6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60914510171bd0a90cc949172807853fcb000fd782a98f0b5e9c3294438c4b59',2006,'ES','Spain','communications',979,'large, flat to dissected plateau surrounded by rugged hills;
Pyrenees in north
Spratly Islands
flat
1.28 children born/woman (2006 est.)
parliamentary monarchy
9.2% (2005 est.)
conventional long form: Kingdom of Spain
conventional short form: Spain
local long form: Reino de Espana
local short form: Espana
Spratly Islands
conventional long form: none
conventional short form: Spratly Islands
Southwestern Europe, bordering the Bay of Biscay,
Mediterranean Sea, North Atlantic Ocean, and Pyrenees Mountains,
southwest of France
Spratly Islands
Southeastern Asia, group of reefs and islands in the
South China Sea, about two-thirds of the way from southern Vietnam
to the southern Philippines
Europe
Spratly Islands
Southeast Asia
37,800 sq km (2003)
Spratly Islands
0 sq km
total: 504,782 sq km
land: 499,542 sq km
water: 5,240 sq km
note: there are 2 autonomous cities - Ceuta and Melilla - and 17
autonomous communities including Balearic Islands and Canary
Islands, and three small Spanish possessions off the coast of
Morocco - Islas Chafarinas, Penon de Alhucemas, and Penon de Velez
de la Gomera
Spratly Islands
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea mounts
scattered over an area of nearly 410,000 sq km of the central South
China Sea
chief of mission: Ambassador Carlos WESTENDORP
chancery: 2375 Pennsylvania Avenue NW, Washington, DC 20037
telephone: [1] (202) 452-0100, 728-2340
FAX: [1] (202) 833-5670
consulate(s) general: Boston, Chicago, Houston, Los Angeles, Miami,
New Orleans, New York, San Francisco, San Juan (Puerto Rico)
18.322 million (2005)
41.328 million (2005)
19,204,771 (2006)
.es
0.7% (2001 est.)
140,000 (2001 est.)
less than 1,000 (2003 est.)
32.5 (1990)
24,540 bbl/day (2003 est.)
1.544 million bbl/day (2003 est.)
1.582 million bbl/day (2001)
135,100 bbl/day (2001)
total: 39.9 years
male: 38.6 years
female: 41.3 years (2006 est.)
10.5 million bbl (1 January 2002)
2.662 billion cu m (1 January 2002)
216 million cu m (2003 est.)
23.27 billion cu m (2003 est.)
17.26 billion cu m (2001 est.)
0 cu m (2001 est.)
2,520,711 (2006)
29.4% of GDP (2005 est.)
42.9% of GDP (2005 est.)
$-83.14 billion (2005 est.)
$17.23 billion (2005 est.)
$1.019 trillion (2005 est.)','6b771101da714dcd7d7c15bb5a4c9071685325f6ad5fa9780963f402d02d19cf','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45187d82c9b30cb494388d7883276a98caee5ace9f5bcac594a9c877440b50b4',2006,'LK','Sri Lanka','communications',980,'mostly low, flat to rolling plain; mountains in
south-central interior
1.84 children born/woman (2006 est.)
republic
7.7% (2005 est.)
conventional long form: Democratic Socialist Republic of
conventional short form: Sri Lanka
local long form: Shri Lamka Prajatantrika Samajaya di
Janarajaya/Ilankai Jananayaka Choshalichak Kutiyarachu
local short form: Shri Lamka/Ilankai
former: Serendib, Ceylon
Southern Asia, island in the Indian Ocean, south of India
Asia
7,430 sq km (2003)
total: 65,610 sq km
land: 64,740 sq km
water: 870 sq km
chief of mission: Ambassador Bernard GOONETILLEKE
chancery: 2148 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 483-4025 (through 4028)
FAX: [1] (202) 232-7181
consulate(s) general: Los Angeles
consulate(s): New York
1.244 million (2005)
3.362 million (2005)
280,000 (2005)
.lk
less than 0.1% (2001 est.)
3,500 (2001 est.)
less than 200 (2003 est.)
34.4 (1995)
0 bbl/day (2003 est.)
79,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 29.8 years
male: 28.7 years
female: 30.9 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
6,526 (2006)
26.1% of GDP (2005 est.)
92.8% of GDP (2005 est.)
$-776 million (2005 est.)
$2.737 billion (2005 est.)
IDPs: 353,000 (both Tamils and non-Tamils displaced due to
Tamil conflict); 450,000 (resulting from 2004 tsunami) (2005)
$21.62 billion (2005 est.)','7105d478f9ecfb9f4ad31795a1c2dc12f83b4d25c055c9d9fb64884b1735792f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('169656ad9915784ae9f766d58b3f03cd5012a023bd4627553b7dc535479cebd9',2006,'SD','Sudan','communications',981,'generally flat, featureless plain; mountains in far south,
northeast and west; desert dominates the north
4.72 children born/woman (2006 est.)
Government of National Unity (GNU) - the National Congress
Party (NCP) and Sudan People''s Liberation Movement (SPLM) formed a
power-sharing government under the 2005 Comprehensive Peace
Agreement (CPA); the NCP, which came to power by military coup in
1989, is the majority partner; the agreement stipulates national
elections for the 2008 - 2009 timeframe.
18.7% (2002 est.)
conventional long form: Republic of the Sudan
conventional short form: Sudan
local long form: Jumhuriyat as-Sudan
local short form: As-Sudan
former: Anglo-Egyptian Sudan
Northern Africa, bordering the Red Sea, between Egypt and
Africa
18,630 sq km (2003)
total: 2,505,810 sq km
land: 2.376 million sq km
water: 129,810 sq km
chief of mission: Ambassador (vacant); Charge d''Affaires, Ad
Interim Khidir HAROUN (since April 2001)
chancery: 2210 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 338-8565
FAX: [1] (202) 667-2406
670,000 (2005)
1.828 million (2005)
2.8 million (2005)
.sd
2.3% (2001 est.)
400,000 (2001 est.)
23,000 (2003 est.)
401,300 bbl/day (2005 est.)
70,000 bbl/day (2004 est.)
0 bbl/day (2004)
275,000 bbl/day (2004)
total: 18.3 years
male: 18.1 years
female: 18.5 years (2006 est.)
1.6 billion bbl (2005 est.)
84.95 billion cu m (2005)
0 cu m (2003 est.)
0 cu m (2003 est.)
16 (2006)
16.3% of GDP (2005 est.)
Swaziland
10.6% of GDP (2005 est.)
107% of GDP (2005 est.)
$-3.013 billion (2005 est.)
Swaziland
$7 million (2005 est.)
$2.45 billion (2005 est.)
Swaziland
$311 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria, dengue fever, African trypanosomiasis
(sleeping sickness) are high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
Tanzania
degree of risk: very high
food or waterborne diseases: bacterial diarrhea, hepatitis A, and
typhoid fever
vectorborne diseases: malaria, Rift Valley fever and plague are high
risks in some locations
water contact disease: schistosomiasis (2005)
refugees (country of origin): 110,927 (Eritrea) 5,023 (Chad)
7,983 (Uganda) 14,812 (Ethiopia)
IDPs: 5,300,000 - 6,200,000 (internal conflict since 1980s; ongoing
genocide) (2005)
Syria
refugees (country of origin): 432,048 (Palestinian Refugees
(UNRWA)) 14,391 (Iraq)
IDPs: 170,000 (most displaced from Golan Heights during 1967
Arab-Israeli War) (2005)
Tanzania
refugees (country of origin): 443,706 (Burundi) 153,474
(Democratic Republic of the Congo) 3,036 (Somalia) (2005)
$22.75 billion (2005 est.)
current situation: Sudan is a source country for men, women,
and children trafficked for the purposes of forced labor and sexual
exploitation; Sudan may also be a transit and destination country
for Ethiopian women trafficked for domestic servitude; boys are
trafficked to the Middle East, particularly Qatar and the United
Arab Emirates, for use as camel jockeys; small numbers of girls are
reportedly trafficked within Sudan for domestic servitude, as well
as for commercial sexual exploitation in small brothels in
internally displaced persons (IDP) camps; the terrorist rebel
organization "Lord''s Resistance Army" (LRA) continues to abduct and
forcibly conscript small numbers of children in Southern Sudan for
use as cooks, porters, and combatants in its ongoing war against
Uganda; some of these children are then trafficked across borders
into Uganda or possibly the Democratic Republic of the Congo;
children are utilized by rebel groups and the Sudanese Armed Forces
and associated militias in the ongoing conflict in Darfur; during
the decades of civil war, thousands of Dinka women and children were
enslaved by members of Baggara tribes and subjected to various forms
of forced labor without remuneration, as well as physical and sexual
abuse; with the cessation of the North-South conflict and the
ongoing peace process, there were no known new abductions of Dinka
by Baggara tribes during 2005; however, inter-tribal abductions of a
different nature continue in Southern Sudan and warrant further
investigation
tier rating: Tier 3 - Sudan does not fully comply with the minimum
standards for the elimination of trafficking and is not making
significant efforts to do so
Syria
current situation: Syria is a destination country for women
from South and Southeast Asia and Africa for domestic servitude and
from Eastern Europe and Iraq for sexual exploitation; women are
recruited for work in Syria as domestic servants, but some face
conditions of exploitation and involuntary servitude including long
hours, non-payment of wages, withholding of passports and other
restrictions on movement, and physical and sexual abuse; Eastern
European women recruited for work in Syria as cabaret dancers are
not permitted to leave their work premises without permission and
have their passports withheld; some displaced Iraqi women and
children are reportedly forced into sexual exploitation
tier rating: Tier 3 - Syria does not fully comply with the minimum
standards for the elimination of trafficking and is not making
significant efforts to do so
Taiwan
current situation: Taiwan is primarily a destination for men,
women, and children trafficked for forced labor and sexual
exploitation; women from China and Southeast Asian countries are
trafficked for sexual exploitation and forced labor; women and
children, primarily from Vietnam, are trafficked through the use of
fraudulent marriages, deceptive employment offers, and illegal
smuggling for commercial sexual exploitation and forced labor; a
significant share of foreign workers - primarily from Vietnam,
Thailand, and the Philippines - are recruited legally for
low-skilled jobs, and are subjected to forced labor or involuntary
servitude by labor agencies or employers upon arrival in Taiwan; to
a much lesser extent, there is internal trafficking of children for
sexual exploitation and trafficking of a small and declining number
of Taiwanese women to Japan for commercial sexual exploitation
tier rating: Tier 2 Watch List - Taiwan is placed on the Tier 2
Watch List for its failure to show evidence of increasing efforts
over the past year to address trafficking, despite ample resources
to do so, particularly the serious level of forced labor and sexual
servitude among legally migrating Southeast Asian contract workers
and brides','cb7aa5adea2d6d2169bd5ad21da9d2e39fdb3d4946a57b9f7365272cc6116ef9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4dd4135478d09ad11abb73f2a2de522d59ce34ccf1f2d0a01d731db1f1f0c7f',2006,'SR','Suriname','communications',982,'mostly rolling hills; narrow coastal plain with swamps
Svalbard
wild, rugged mountains; much of high land ice covered; west
coast clear of ice about one-half of the year; fjords along west and
north coasts
Swaziland
mostly mountains and hills; some moderately sloping plains
2.32 children born/woman (2006 est.)
Svalbard
NA
Swaziland
3.53 children born/woman (2006 est.)
constitutional democracy
Svalbard
NA
Swaziland
monarchy
9.5% (2004)
Swaziland
40% (2005 est.)
conventional long form: Republic of Suriname
conventional short form: Suriname
local long form: Republiek Suriname
local short form: Suriname
former: Netherlands Guiana, Dutch Guiana
Svalbard
conventional long form: none
conventional short form: Svalbard (sometimes referred to as
Spitzbergen)
Swaziland
conventional long form: Kingdom of Swaziland
conventional short form: Swaziland
local long form: Umbuso weSwatini
local short form: eSwatini
Northern South America, bordering the North Atlantic Ocean,
between French Guiana and Guyana
Svalbard
Northern Europe, islands between the Arctic Ocean, Barents
Sea, Greenland Sea, and Norwegian Sea, north of Norway
Swaziland
Southern Africa, between Mozambique and South Africa
South America
Svalbard
Arctic Region
Swaziland
Africa
510 sq km (2003)
Svalbard
NA
Swaziland
500 sq km (2003)
total: 163,270 sq km
land: 161,470 sq km
water: 1,800 sq km
Svalbard
total: 61,020 sq km
land: 61,020 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear Island)
Swaziland
total: 17,363 sq km
land: 17,203 sq km
water: 160 sq km
chief of mission: Ambassador Henry Lothar ILLES
chancery: Suite 460, 4301 Connecticut Avenue NW, Washington, DC 20008
telephone: [1] (202) 244-7488
FAX: [1] (202) 244-5878
consulate(s) general: Miami
Swaziland
chief of mission: Ambassador Ephraim Mandla HLOPHE
chancery: 1712 New Hampshire Avenue, NW, Washington, DC 20009
telephone: [1] (202) 234-5002
FAX: [1] (202) 234-8254
81,100 (2004)
Svalbard
NA
Swaziland
35,000 (2005)
232,800 (2005)
Svalbard
NA
Swaziland
200,000 (2005)
30,000 (2005)
Svalbard
NA
Swaziland
36,000 (2005)
.sr
Svalbard
.sj
Swaziland
.sz
1.7% (2001 est.)
Svalbard
0% (2001)
Swaziland
38.8% (2003 est.)
5,200 (2001 est.)
Svalbard
0 (2001)
Swaziland
220,000 (2003 est.)
less than 500 (2003 est.)
Svalbard
0 (2001)
Swaziland
17,000 (2003 est.)
12,000 bbl/day (2004 est.)
Swaziland
0 bbl/day (2004 est.)
14,000 bbl/day (2004 est.)
Swaziland
3,500 bbl/day (2003 est.)
1,644 bbl/day (2003)
Swaziland
NA bbl/day
1,370 bbl/day (2003)
Swaziland
NA bbl/day
total: 26.5 years
male: 26 years
female: 26.9 years (2006 est.)
Swaziland
total: 18.5 years
male: 17.8 years
female: 19.2 years (2006 est.)
150 million bbl (2005)
Syria
2.5 billion bbl (2005 est.)
Taiwan
2.9 million bbl (2005 est.)
Tanzania
0 bbl (1 January 2002)
0 cu m (2005)
Syria
240.7 billion cu m (2005)
Taiwan
76.46 billion cu m (2005)
Tanzania
22.65 billion cu m (1 January 2002)
0 cu m (2003 est.)
Swaziland
0 cu m (2003 est.)
0 cu m (2003 est.)
Swaziland
0 cu m (2003 est.)
126 (2006)
Swaziland
2,472 (2006)
$1.3 billion (2005 est.)
Swaziland
$2.117 billion (2005 est.)','c7eb01534bb0c300583faa61f3267f00a1a6644a0c00966137bf9aad7285ab57','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31be366dc62c75863f9057705b0b490745423300a586d51172c40c3e02ae27e9',2006,'SE','Sweden','communications',983,'mostly flat or gently rolling lowlands; mountains in west
1.66 children born/woman (2006 est.)
constitutional monarchy
5.8% (2005 est.)
conventional long form: Kingdom of Sweden
conventional short form: Sweden
local long form: Konungariket Sverige
local short form: Sverige
Northern Europe, bordering the Baltic Sea, Gulf of Bothnia,
Kattegat, and Skagerrak, between Finland and Norway
Europe
1,150 sq km (2003)
total: 449,964 sq km
land: 410,934 sq km
water: 39,030 sq km
chief of mission: Ambassador Gunnar LUND
chancery: 902 30th Street NW, Washington, DC 20007
telephone: [1] (202) 467-2600
FAX: [1] (202) 467-2699
consulate(s) general: Los Angeles, New York
6.447 million (2004)
8.436 million (2005)
6.8 million (2005)
.se
0.1% (2001 est.)
3,600 (2001 est.)
less than 100 (2003 est.)
25 (2000)
2,441 bbl/day (2003 est.)
346,100 bbl/day (2003 est.)
553,100 bbl/day (2001)
203,700 bbl/day (2001)
total: 40.9 years
male: 39.8 years
female: 42 years (2006 est.)
0 cu m (2003 est.)
980 million cu m (2003 est.)
968 million cu m (2001 est.)
0 cu m (2001 est.)
2,958,435 (2006)
17% of GDP (2005 est.)
50.4% of GDP (2005 est.)
$25.62 billion (2005 est.)
$22.33 billion (2005 est.)
$348.1 billion (2005 est.)','1ba0825a7ba83532dc1347f90f6401e8e9febad30bccd495bee76a129cad55f0','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('381d8d352e93a60a95684329a9bd1bcea8ce5d5137e4c6a1ef08d61660a562e5',2006,'CH','Switzerland','communications',984,'mostly mountains (Alps in south, Jura in northwest) with
a central plateau of rolling hills, plains, and large lakes
Syria
primarily semiarid and desert plateau; narrow coastal plain;
mountains in west
Taiwan
eastern two-thirds mostly rugged mountains; flat to gently
rolling plains in west
1.43 children born/woman (2006 est.)
Syria
3.4 children born/woman (2006 est.)
Taiwan
1.57 children born/woman (2006 est.)
formally a confederation, but similar in structure to a
federal republic
Syria
republic under an authoritarian, military-dominated regime
Taiwan
multiparty democracy
3.8% (2005 est.)
Syria
12.3% (2004 est.)
Taiwan
4.1% (2005 est.)
conventional long form: Swiss Confederation
conventional short form: Switzerland
local long form: Schweizerische Eidgenossenschaft (German);
Confederation Suisse (French); Confederazione Svizzera (Italian)
local short form: Schweiz (German); Suisse (French); Svizzera
(Italian)
Syria
conventional long form: Syrian Arab Republic
conventional short form: Syria
local long form: Al Jumhuriyah al Arabiyah as Suriyah
local short form: Suriyah
former: United Arab Republic (with Egypt)
Taiwan
conventional long form: none
conventional short form: Taiwan
local long form: none
local short form: T''ai-wan
former: Formosa
Central Europe, east of France, north of Italy
Syria
Middle East, bordering the Mediterranean Sea, between Lebanon
and Turkey
Taiwan
Eastern Asia, islands bordering the East China Sea,
Philippine Sea, South China Sea, and Taiwan Strait, north of the
Philippines, off the southeastern coast of China
Europe
Syria
Middle East
Taiwan
Southeast Asia
250 sq km (2003)
Syria
13,330 sq km (2003)
Taiwan
NA
total: 41,290 sq km
land: 39,770 sq km
water: 1,520 sq km
Syria
total: 185,180 sq km
land: 184,050 sq km
water: 1,130 sq km
note: includes 1,295 sq km of Israeli-occupied territory
Taiwan
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
chief of mission: Ambassador Urs ZISWILER
chancery: 2900 Cathedral Avenue NW, Washington, DC 20008
telephone: [1] (202) 745-7900
FAX: [1] (202) 387-2564
consulate(s) general: Atlanta, Chicago, Houston, Los Angeles, New
York, San Francisco
consulate(s): Boston
Syria
chief of mission: Ambassador Imad MUSTAFA
chancery: 2215 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 232-6313
FAX: [1] (202) 234-9548
Taiwan
none; unofficial commercial and cultural relations with the
people of the US are maintained through an unofficial
instrumentality, the Taipei Economic and Cultural Representative
Office (TECRO) in the US with headquarters in Taipei and field
offices in Washington and 12 other US cities
5.123 million (2005)
Syria
2.903 million (2005)
Taiwan
13.615 million (2005)
6.847 million (2005)
Syria
2.95 million (2005)
Taiwan
22.17 million (2005)
5,097,822 (2005)
Syria
1.1 million (2005)
Taiwan
13.21 million (2005)
.ch
Syria
.sy
Taiwan
.tw
0.4% (2001 est.)
Syria
less than 0.1% (2001 est.)
Taiwan
NA
13,000 (2001 est.)
Syria
less than 500 (2003 est.)
Taiwan
NA
less than 100 (2003 est.)
Syria
less than 200 (2003 est.)
Taiwan
NA
33.1 (1992)
1,950 bbl/day (2003 est.)
Syria
403,800 bbl/day (2005 est.)
Taiwan
8,354 bbl/day (2003 est.)
258,900 bbl/day (2003 est.)
Syria
240,000 bbl/day (2004 est.)
Taiwan
915,000 bbl/day (2003 est.)
289,500 bbl/day (2001)
Syria
NA bbl/day
Taiwan
NA bbl/day
10,420 bbl/day (2001)
Syria
285,000 bbl/day (2004)
Taiwan
NA bbl/day
total: 40.1 years
male: 39 years
female: 41.1 years (2006 est.)
Syria
total: 20.7 years
male: 20.6 years
female: 20.9 years (2006 est.)
Taiwan
total: 34.6 years
male: 34.1 years
female: 35 years (2006 est.)
0 cu m (2003 est.)
Syria
6.95 billion cu m (2003 est.)
Taiwan
970 million cu m (2003 est.)
3.209 billion cu m (2003 est.)
Syria
6.95 billion cu m (2003 est.)
Taiwan
8.45 billion cu m (2003 est.)
3.093 billion cu m (2001 est.)
Syria
0 cu m (2001 est.)
Taiwan
7.48 billion cu m (2005 est.)
0 cu m (2001 est.)
Syria
0 cu m (2001 est.)
Taiwan
0 cu m (2005 est.)
2,442,659 (2006)
Syria
66 (2006)
Taiwan
4,320,310 (2006)
21.3% of GDP (2005 est.)
Syria
21.9% of GDP (2005 est.)
Taiwan
20.4% of GDP (2005 est.)
52% of GDP (2005 est.)
Syria
40.1% of GDP (2005 est.)
Taiwan
33.6% of GDP (2005 est.)
Tanzania
65.8% of GDP (2005 est.)
$58.24 billion (2005 est.)
Syria
$1.097 billion (2005 est.)
Taiwan
$16.22 billion (2005 est.)
$57.64 billion (2005 est.)
Syria
$5.363 billion (2005 est.)
Taiwan
$258 billion (2005 est.)
$367 billion (2005 est.)
Syria
$25.84 billion (2005 est.)
Taiwan
$323.4 billion (2005 est.)','7487ec63217f8642e78fdfa35b432fa846e4583de7f8bad4ebd013d32d79b418','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac47959f18f1b4c711ac33a05ca29de0980448df3f7545672eb8753cbf05156',2006,'TJ','Tajikistan','communications',985,'Pamir and Alay Mountains dominate landscape; western
Fergana Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Tanzania
plains along coast; central plateau; highlands in north,
south
4 children born/woman (2006 est.)
Tanzania
4.97 children born/woman (2006 est.)
republic
Tanzania
republic
12% (2004 est.)
Tanzania
NA%
conventional long form: Republic of Tajikistan
conventional short form: Tajikistan
local long form: Jumhurii Tojikiston
local short form: Tojikiston
former: Tajik Soviet Socialist Republic
Tanzania
conventional long form: United Republic of Tanzania
conventional short form: Tanzania
local long form: Jamhuri ya Muungano wa Tanzania
local short form: Tanzania
former: United Republic of Tanganyika and Zanzibar
Central Asia, west of China
Tanzania
Eastern Africa, bordering the Indian Ocean, between Kenya
and Mozambique
Asia
Tanzania
Africa
7,220 sq km (2003)
Tanzania
1,840 sq km (2003)
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Tanzania
total: 945,087 sq km
land: 886,037 sq km
water: 59,050 sq km
note: includes the islands of Mafia, Pemba, and Zanzibar
chief of mission: Ambassador Khamrokhon ZARIPOV
chancery: 1005 New Hampshire Avenue NW, Washington, DC 20037
telephone: [1] (202) 223-6090
FAX: [1] (202) 223-6091
Tanzania
chief of mission: Ambassador Andrew Mhando DARAJA
chancery: 2139 R Street NW, Washington, DC 20008
telephone: [1] (202) 939-6125
FAX: [1] (202) 797-7408
245,200 (2004)
Tanzania
148,400 (2004)
265,000 (2005)
Tanzania
1.942 million (2005)
5,000 (2005)
Tanzania
333,000 (2005)
.tj
Tanzania
.tz
less than 0.1% (2001 est.)
Tanzania
8.8% (2003 est.)
less than 200 (2003 est.)
Tanzania
1.6 million (2003 est.)
less than 100 (2001 est.)
Tanzania
160,000 (2003 est.)
34.7 (1998)
Tanzania
38.2 (1993)
354.8 bbl/day (2003 est.)
Tanzania
0 bbl/day (2003 est.)
25,000 bbl/day (2003 est.)
Tanzania
22,000 bbl/day (2003 est.)
NA bbl/day
Tanzania
NA bbl/day
NA bbl/day
Tanzania
NA bbl/day
total: 20 years
male: 19.7 years
female: 20.4 years (2006 est.)
Tanzania
total: 17.7 years
male: 17.5 years
female: 18 years (2006 est.)
30 million cu m (2004 est.)
Tanzania
0 cu m (2003 est.)
1.4 billion cu m (2004 est.)
Tanzania
0 cu m (2003 est.)
1.4 billion cu m (2004 est.)
0 cu m (2004 est.)
98 (2006)
Tanzania
8,609 (2006)
19.4% of GDP (2005 est.)
Tanzania
18.6% of GDP (2005 est.)
$-44 million (2005 est.)
Tanzania
$-558 million (2005 est.)
$186.8 million (2005 est.)
Tanzania
$2.074 billion (2005 est.)
$1.887 billion (2005 est.)
Tanzania
$12.12 billion (2005 est.)','429341575419bf55625b61bdc81958c5d76eb5fa8287c1031d33b5e2c9296de8','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83cb04ed22443d4adeadd2f18cc20bfa7b456027c0bedf6eeaf0dbf2182ea133',2006,'TH','Thailand','communications',986,'central plain; Khorat Plateau in the east; mountains
elsewhere
1.64 children born/woman (2006 est.)
constitutional monarchy
1.8% (2005 est.)
conventional long form: Kingdom of Thailand
conventional short form: Thailand
local long form: Ratcha Anachak Thai
local short form: Prathet Thai
former: Siam
Southeastern Asia, bordering the Andaman Sea and the Gulf
of Thailand, southeast of Burma
Southeast Asia
49,860 sq km (2003)
total: 514,000 sq km
land: 511,770 sq km
water: 2,230 sq km
chief of mission: Ambassador Virasakdi FUTRAKUL
chancery: 1024 Wisconsin Avenue NW, Suite 401, Washington, DC
20007-3681
telephone: [1] (202) 944-3600
FAX: [1] (202) 944-3611
consulate(s) general: Chicago, Los Angeles, New York
7.035 million (2005)
27.379 million (2005)
8.42 million (2005)
.th
1.5% (2003 est.)
570,000 (2003 est.)
58,000 (2003 est.)
51.1 (2002)
230,000 bbl/day (2005 est.)
851,000 bbl/day (2004 est.)
NA bbl/day
NA bbl/day
total: 31.9 years
male: 31.1 years
female: 32.8 years (2006 est.)
583 million bbl (November 2003)
377.7 billion cu m (November 2003)
22.28 billion cu m (2003 est.)
29.15 billion cu m (2003 est.)
5.2 billion cu m (2001 est.)
0 cu m (2001 est.)
938,784 (2006)
29% of GDP (2005 est.)
47.6% of GDP (2005 est.)
$-3.689 billion (2005 est.)
$52.07 billion (2005 est.)
degree of risk: high
food or waterborne diseases: bacterial diarrhea and hepatitis A
vectorborne diseases: dengue fever, malaria, Japanese encephalitis,
and plague are high risks in some locations
animal contact disease: rabies
water contact disease: leptospirosis
note: at present, H5N1 avian influenza poses a minimal risk; during
outbreaks among birds, rare cases could occur among US personnel who
have close contact with infected birds or poultry (2005)
refugees (country of origin): 120,814 (Burma)
IDPs: 6,000 (26 December 2004 tsunami) (2005)
Turkey
IDPs: 350,000-1,000,000 (fighting from 1984-99 between
Kurdish PKK and Turkish military; most IDPs in southeastern
provinces) (2005)
$183.9 billion (2005 est.)','8afac05df481d24ab0ef2bc0e52d57a807f50e56c1a4fa56e810c243e7292ab5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d62a6f112372cd68832d7c28ad154fb5fb174842e0ced0ded131fa7f4c3805',2006,'TG','Togo','communications',987,'gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
4.96 children born/woman (2006 est.)
republic under transition to multiparty democratic rule
NA%
conventional long form: Togolese Republic
conventional short form: Togo
local long form: Republique togolaise
local short form: none
former: French Togoland
Western Africa, bordering the Bight of Benin, between Benin and
Africa
70 sq km (2003)
total: 56,785 sq km
land: 54,385 sq km
water: 2,400 sq km
chief of mission: Ambassador Akoussoulelou BODJONA
chancery: 2208 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-4212
FAX: [1] (202) 232-3190
58,600 (2005)
443,600 (2005)
300,000 (2005)
.tg
4.1% (2003 est.)
110,000 (2003 est.)
10,000 (2003 est.)
0 bbl/day (2003 est.)
8,500 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 18.3 years
male: 17.8 years
female: 18.7 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
520 (2006)
21.6% of GDP (2005 est.)
$-199 million (2005 est.)
$318 million (2005 est.)
degree of risk: very high
food or waterborne diseases: bacterial and protozoal diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are high risks in
some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2005)
$1.999 billion (2005 est.)
current situation: Togo is a source, transit, and destination
country for children, women, and men trafficked for forced labor and
sexual exploitation; the majority of victims are children, and
trafficking within the country is more prevalent than international
trafficking; children are trafficked to work as domestic servants,
produce porters, roadside sellers, agricultural laborers, and for
sexual exploitation; Togolese women may be trafficked to Europe for
forced labor and sexual exploitation
tier rating: Tier 2 Watch List - Togo is placed on the Tier 2 Watch
List for failure to show evidence of increased efforts to combat
trafficking over the past year, particularly in the areas of
prosecution and protection','dc9d79117a56f8d6ef9ea21155107d35bc5b20483fd89b199e48c2dbbfba2cca','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8eb806b9e961f313617171b10836b303642074f3e47f39edb9c0a6732476ee8',2006,'TK','Tokelau','communications',988,'low-lying coral atolls enclosing large lagoons
NA
NA
NA%
defense is the responsibility of New Zealand
Tromelin Island
defense is the responsibility of France
Turkey
in the early 1990s, the Turkish Land Force was a large but
badly equipped infantry force; there were 14 infantry divisions, but
only one was mechanized, and out of 16 infantry brigades, only six
were mechanized; the overhaul that has taken place since has
produced highly mobile forces with greatly enhanced firepower in
accordance with NATO''s new strategic concept (2005)
conventional long form: none
conventional short form: Tokelau
Oceania, group of three atolls in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Oceania
NA
total: 10 sq km
land: 10 sq km
water: 0 sq km
none (territory of New Zealand)
300 (2002)
0 (2001)
NA
.tk
NA
NA
NA
298 (2006)
NA','bb3747a8b6257cbb0dd930cf5b5418fa90d2e617791c4073067f2ac8b13cf287','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8836553fe932aa9bb56a1e7382d612356b87c8dd7f56a99a065cc7ad1b7fe92',2006,'TO','Tonga','communications',989,'most islands have limestone base formed from uplifted coral
formation; others have limestone overlying volcanic base
3 children born/woman (2006 est.)
constitutional monarchy
13% (FY03/04 est.)
conventional long form: Kingdom of Tonga
conventional short form: Tonga
local long form: Pule''anga Tonga
local short form: Tonga
former: Friendly Islands
Oceania, archipelago in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Oceania
NA
total: 748 sq km
land: 718 sq km
water: 30 sq km
chief of mission: Ambassador Fekitamoeloa ''UTOIKAMANU
chancery: 250 East 51st Street, New York, NY 10022
telephone: [1] (917) 369-1025
FAX: [1] (917) 369-1024
consulate(s) general: San Francisco
11,200 (2002)
16,400 (2004)
3,000 (2004)
.to
NA
NA
NA
0 bbl/day (2003 est.)
800 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 20.7 years
male: 20.1 years
female: 21.3 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
18,775 (2006)
$-4.321 million
$40.83 million
$244 million','fe2d4a8ed5a9a4c5bc88327c39964881cce5a3012efc68b6a90b15a1e5439f40','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d404fec1fa5d52b5e2cd4f48ddf419bde5821980e991f7c816b7fc0417b2ce3',2006,'TT','Trinidad and Tobago','communications',990,'mostly plains with some hills and low mountains
Tromelin Island
low, flat, and sandy; likely volcanic
1.74 children born/woman (2006 est.)
parliamentary democracy
8% (2005 est.)
conventional long form: Republic of Trinidad and
Tobago
conventional short form: Trinidad and Tobago
Tromelin Island
conventional long form: none
conventional short form: Tromelin Island
local long form: none
local short form: Ile Tromelin
Caribbean, islands between the Caribbean Sea and
the North Atlantic Ocean, northeast of Venezuela
Tromelin Island
Southern Africa, island in the Indian Ocean, east of
Central America and the Caribbean
Tromelin Island
Africa
40 sq km (2003)
Tromelin Island
0 sq km
total: 5,128 sq km
land: 5,128 sq km
water: 0 sq km
Tromelin Island
total: 1 sq km
land: 1 sq km
water: 0 sq km
chief of mission: Ambassador Marina Annette
VALERE
chancery: 1708 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 467-6490
FAX: [1] (202) 785-3130
consulate(s) general: Miami, New York
323,500 (2005)
800,000 (2005)
160,000 (2005)
.tt
3.2% (2003 est.)
29,000 (2003 est.)
1,900 (2003 est.)
150,000 bbl/day (2005 est.)
29,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 31.2 years
male: 30.8 years
female: 31.7 years (2006 est.)
990 million bbl (1 January 2004)
733 billion cu m (1 January 2004)
24.7 billion cu m (2003 est.)
12.79 billion cu m (2003 est.)
0 cu m (2001 est.)
11.79 billion cu m (2003 est.)
30,732 (2006)
19.6% of GDP (2005 est.)
43% of GDP (2005 est.)
$2.88 billion (2005 est.)
$4.888 billion (2005 est.)
$13.02 billion (2005 est.)','3732eaee60c35487d27166dffffd00cfe16a442b053a24fca3fdce98d5065e35','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4dfc0ca30238887d305d3ab62119829990ef21cae6debdb63594ecd99f17458',2006,'TN','Tunisia','communications',991,'mountains in north; hot, dry central plain; semiarid south
merges into the Sahara
Turkey
high central plateau (Anatolia); narrow coastal plain;
several mountain ranges
1.74 children born/woman (2006 est.)
Turkey
1.92 children born/woman (2006 est.)
republic
Turkey
republican parliamentary democracy
14.2% (2005 est.)
Turkey
10.2% plus underemployment of 4% (2005 est.)
conventional long form: Tunisian Republic
conventional short form: Tunisia
local long form: Al Jumhuriyah at Tunisiyah
local short form: Tunis
Turkey
conventional long form: Republic of Turkey
conventional short form: Turkey
local long form: Turkiye Cumhuriyeti
local short form: Turkiye
Northern Africa, bordering the Mediterranean Sea, between
Algeria and Libya
Turkey
Southeastern Europe and Southwestern Asia (that portion of
Turkey west of the Bosporus is geographically part of Europe),
bordering the Black Sea, between Bulgaria and Georgia, and bordering
the Aegean Sea and the Mediterranean Sea, between Greece and Syria
Africa
Turkey
Middle East
3,940 sq km (2003)
Turkey
52,150 sq km (2003)
total: 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Turkey
total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
chief of mission: Ambassador Nejib HACHANA
chancery: 1515 Massachusetts Avenue NW, Washington, DC 20005
telephone: [1] (202) 862-1850
FAX: [1] (202) 862-1858
Turkey
chief of mission: Ambassador Nabi SENSOY
chancery: 2525 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 612-6700
FAX: [1] (202) 612-6744
consulate(s) general: Chicago, Houston, Los Angeles, New York
1,257,500 (2005)
Turkey
18.978 million (2005)
5.681 million (2005)
Turkey
43.609 million (2005)
953,800 (2005)
Turkey
16 million (2005)
.tn
Turkey
.tr
less than 0.1% (2005 est.)
Turkey
less than 0.1% - note - no country specific models provided
(2001 est.)
1,000 (2003 est.)
Turkey
NA
less than 200 (2003 est.)
Turkey
NA
40 (2005 est.)
Turkey
42 (2003)
76,000 bbl/day (2004 est.)
Turkey
50,000 bbl/day (2005 est.)
90,000 bbl/day (2003 est.)
Turkey
715,100 bbl/day (2005 est.)
NA bbl/day
Turkey
616,500 bbl/day (2001)
NA bbl/day
Turkey
46,110 bbl/day (2001)
total: 27.8 years
male: 27.3 years
female: 28.3 years (2006 est.)
Turkey
total: 28.1 years
male: 27.9 years
female: 28.3 years (2006 est.)
1.7 billion bbl (2005 est.)
Turkey
288.4 million bbl (1 January 2002)
77.87 billion cu m (2005)
Turkey
8.495 billion cu m (1 January 2002)
2.15 billion cu m (2003 est.)
Turkey
560 million cu m (2003 est.)
3.84 billion cu m (2003 est.)
Turkey
22.6 billion cu m (2005 est.)
1.58 billion cu m (2001 est.)
Turkey
15.75 billion cu m (2001 est.)
0 cu m (2001 est.)
Turkey
0 cu m (2001 est.)
428 (2006)
Turkey
1,313,135 (2006)
22.4% of GDP (2005 est.)
Turkey
19.6% of GDP (2005 est.)
59.1% of GDP (2005 est.)
Turkey
68% of GDP (2005 est.)
$-359.2 million (2005 est.)
Turkey
$-23.08 billion (2005 est.)
$4.375 billion (2005 est.)
Turkey
$52.49 billion (2005 est.)
degree of risk: intermediate
food or waterborne diseases: bacterial diarrhea and hepatitis A
vectorborne diseases: may be a significant risk in some locations
during the transmission season (typically April through November)
(2005)
$30.94 billion (2005 est.)
Turkey
$332.5 billion (2005 est.)','5a507be9997ece798a496ee8b6fd994a29981225b784fb57ac64451ff2089838','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d4c2db39f1bb25a95f02870247e2416bd934b8ae741285edba9b6b5618b2d5',2006,'TM','Turkmenistan','communications',992,'flat-to-rolling sandy desert with dunes rising to
mountains in the south; low mountains along border with Iran;
borders Caspian Sea in west
3.37 children born/woman (2006 est.)
republic; authoritarian presidential rule, with little
power outside the executive branch
60% (2004 est.)
conventional long form: none
conventional short form: Turkmenistan
local long form: none
local short form: Turkmenistan
former: Turkmen Soviet Socialist Republic
Central Asia, bordering the Caspian Sea, between Iran
and Kazakhstan
Asia
18,000 sq km (2003)
total: 488,100 sq km
land: 488,100 sq km
water: NEGL
chief of mission: Ambassador Meret Bairamovich ORAZOV
chancery: 2207 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-1500
FAX: [1] (202) 588-0697
376,100 (2003)
52,000 (2004)
36,000 (2005)
.tm
less than 0.1% (2004 est.)
less than 200 (2003 est.)
less than 100 (2004 est.)
40.8 (1998)
203,400 bbl/day (2003 est.)
80,000 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 21.8 years
male: 20.9 years
female: 22.7 years (2006 est.)
273 million bbl (1 January 2002)
2.01 trillion cu m (1 January 2002)
54.6 billion cu m (2004 est.)
15.5 billion cu m (2004 est.)
0 cu m (2004 est.)
38.6 billion cu m (2004 est.)
585 (2006)
35.6% of GDP (2005 est.)
$236 million (2005 est.)
$2.963 billion (2005 est.)
refugees (country of origin): 12,085 (Tajikistan) (2005)
$13.99 billion (2005 est.)','381a756543a513602459eedee5bb3cf8e18e14274793aa4cf42e7a67fa0d398c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e81b6dafd82624a41ea32bcf42cddc2ff7bc58e9cee86ae94da6c6bfbc763dc',2006,'TC','Turks and Caicos Islands','communications',993,'low, flat limestone; extensive marshes and
mangrove swamps
3.05 children born/woman (2006 est.)
NA
10% (1997 est.)
defense is the responsibility of the UK
United States Pacific Island Wildlife Refuges
defense is the
responsibility of the US
Virgin Islands
defense is the responsibility of the US
Wake Island
defense is the responsibility of the US; launch support
facility is part of the Ronald Reagan Ballistic Missile Defense Test
Site (RTS) administered by US Army Space and Missile Defense Command
(SMDC)
conventional long form: none
conventional short form: Turks and Caicos Islands
abbreviation: TCI
Caribbean, two island groups in the North
Atlantic Ocean, southeast of The Bahamas, north of Haiti
Central America and the Caribbean
NA
total: 430 sq km
land: 430 sq km
water: 0 sq km
none (overseas territory of the UK)
5,700 (2002)
1,700 (1999)
NA
.tc
NA
NA
NA
0 bbl/day (2003 est.)
80 bbl/day (2003 est.)
NA bbl/day
NA bbl/day
total: 27.5 years
male: 28.3 years
female: 26.8 years (2006 est.)
0 cu m (2003 est.)
0 cu m (2003 est.)
2,735 (2006)
NA','74664b92781cd32a2a72e2aa6156f19ca865b78601232f8f36e3596ca1e6e3b0','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

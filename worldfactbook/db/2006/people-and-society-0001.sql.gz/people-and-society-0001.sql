SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c479068a14c66259160585010d01635aa45cce12d824917d524842c07ca850e1',2006,'ZW','Zimbabwe','people-and-society',4,'Population
Birth rate
Death rate
Infant mortality rate
Life expectancy at birth - total
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS - deaths
Economy Zimbabwe
Economy - overview:
The government of Zimbabwe faces a wide variety of difficult
economic problems as it struggles with an unsustainable fiscal
deficit, an overvalued exchange rate, soaring inflation, and bare
shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo, for example, drained hundreds of millions of
dollars from the economy. Badly needed support from the IMF has been
suspended because of the government''s arrears on past loans, which
it began repaying in 2005. The official annual inflation rate rose
from 32% in 1998, to 133% at the end of 2004, and 585% at the end of
2005, although private sector estimates put the figure much higher.
Meanwhile, the official exchange rate fell from 24 Zimbabwean
dollars per US dollar in 1998 to 96,000 in mid-January 2006. The
government''s land reform program, characterized by chaos and
violence, has badly damaged the commercial farming sector, the
traditional source of exports and foreign exchange and the provider
of 400,000 jobs, turning Zimbabwe into a net importer of food
products.
GDP (purchasing power parity):
$25.69 billion (2005 est.)
GDP (official exchange rate):
$3.207 billion (2005 est.)
GDP - real growth rate:
-7.7% (2005 est.)
GDP - per capita (PPP):
$2,100 (2005 est.)
GDP - composition by sector:
agriculture: 17.9%
industry: 24.3%
services: 57.9% (2005 est.)
Labor force:
3.94 million (2005 est.)
Labor force - by occupation:
agriculture: 66%
industry: 10%
services: 24% (1996)
Unemployment rate:
80% (2005 est.)
Population below poverty line:
80% (2004 est.)
Household income or consumption by percentage share:
lowest 10%: 2%
highest 10%: 40.4% (1995)
Distribution of family income - Gini index:
56.8 (2003)
Inflation rate (consumer prices):
266.8% official data; private sector estimates are much higher
(2005 est.)
Investment (gross fixed):
7.9% of GDP (2005 est.)
Budget:
revenues: $1.409 billion
expenditures: $1.905 billion; including capital expenditures of $NA
(2005 est.)
Public debt:
109.8% of GDP (2005 est.)
Agriculture - products:
corn, cotton, tobacco, wheat, coffee, sugarcane, peanuts; sheep,
goats, pigs
Industries:
mining (coal, gold, platinum, copper, nickel, tin, clay, numerous
metallic and nonmetallic ores), steel; wood products, cement,
chemicals, fertilizer, clothing and footwear, foodstuffs, beverages
Industrial production growth rate:
3.6% (2005 est.)
Electricity - production:
8.877 billion kWh (2003)
Electricity - production by source:
fossil fuel: 47%
hydro: 53%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
11.22 billion kWh (2003)
Electricity - exports:
0 kWh (2003)
Electricity - imports:
3.3 billion kWh (2003)
Oil - production:
0 bbl/day (2003 est.)
Oil - consumption:
22,500 bbl/day (2003 est.)
Oil - exports:
0 bbl/day
Oil - imports:
23,000 bbl/day
Natural gas - production:
0 cu m (2003 est.)
Natural gas - consumption:
0 cu m (2003 est.)
Current account balance:
$-519 million (2005 est.)
Exports:
$1.644 billion f.o.b. (2005 est.)
Exports - commodities:
cotton, tobacco, gold, ferroalloys, textiles/clothing
Exports - partners:
South Africa 32.8%, China 7.4%, Japan 6.3%, Zambia 5.2%,
Netherlands 5%, US 4.6%, Italy 4.2%, Germany 4.1% (2005)
Imports:
$2.059 billion f.o.b. (2005 est.)
Imports - commodities:
machinery and transport equipment, other manufactures, chemicals,
fuels
Imports - partners:
South Africa 42.9%, China 4.6%, Botswana 3.3% (2005)
Reserves of foreign exchange and gold:
$160 million (2005 est.)
Debt - external:
$5.216 billion (2005 est.)
Economic aid - recipient:
$178 million; note - the EU and the US provide food aid on
humanitarian grounds (2000 est.)
Currency (code):
Zimbabwean dollar (ZWD)
Currency code:
ZWD
Exchange rates:
Zimbabwean dollars per US dollar - 4,303.28 (2005), 5,068.66
(2004), 697.424 (2003), 55.036 (2002), 55.052 (2001)
note: these are official exchange rates; non-official rates vary
significantly
Fiscal year:
calendar year
Communications Zimbabwe
Telephones - main lines in use:
328,000 (2005)
Telephones - mobile cellular:
699,000 (2005)
Telephone system:
general assessment: system was once one of the best in Africa, but
now suffers from poor maintenance; more than 100,000 outstanding
requests for connection despite an equally large number of installed
but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: country code - 263; satellite earth stations - 2
Intelsat; two international digital gateway exchanges (in Harare and
Gweru)
Radio broadcast stations:
AM 7, FM 20 (plus 17 repeater stations), shortwave 1 (1998)
Radios:
1.14 million (1997)
Television broadcast stations:
16 (1997)
Televisions:
370,000 (1997)
Internet country code:
.zw
Internet hosts:
7,954 (2006)
Internet Service Providers (ISPs):
6 (2000)
Internet users:
1 million (2005)
Transportation Zimbabwe
Airports:
403 (2006)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2006)
Airports - with unpaved runways:
total: 386
1,524 to 2,437 m: 5
914 to 1,523 m: 187
under 914 m: 194 (2006)
Pipelines:
refined products 261 km (2006)
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge (313 km electrified) (2005)
Roadways:
total: 97,440 km
paved: 18,514 km
unpaved: 78,926 km (2002)
Waterways:
on Lake Kariba, length small (2005)
Ports and terminals:
Binga, Kariba
Military Zimbabwe
Military branches:
Zimbabwe Defense Forces (ZDF): Zimbabwe National Army, Air Force of
Zimbabwe (AFZ), Zimbabwe Republic Police (2005)
Military service age and obligation:
18 years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 2,778,404
females age 18-49: 2,681,531 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,304,424
females age 18-49: 1,115,096 (2005 est.)
Military expenditures - dollar figure:
$124.7 million (2005 est.)
Military expenditures - percent of GDP:
4% (2005 est.)
Transnational Issues Zimbabwe
Disputes - international:
Botswana has built electric fences and South Africa has placed
military along the border to stem the flow of thousands of
Zimbabweans fleeing to find work and escape political persecution;
Namibia has supported and in 2004 Zimbabwe dropped objections to
plans between Botswana and Zambia to build a bridge over the Zambezi
River, thereby de facto recognizing a short, but not clearly
delimited Botswana-Zambia boundary in the river
Refugees and internally displaced persons:
IDPs: 400,000-450,000 (MUGABE-led political violence, human rights
violations, land reform, and economic collapse) (2005)
Trafficking in persons:
current situation: Zimbabwe is a source, transit, and destination
country for women and children trafficked for forced labor and
sexual exploitation; children may be trafficked internally for
forced agricultural labor, domestic servitude, and sexual
exploitation; women and girls are lured out of the country to South
Africa, China, Egypt, and Zambia with false job or scholarship
promises that result in domestic servitude or commercial sexual
exploitation; there are reports of South African employers demanding
sex from undocumented Zimbabwean workers under threat of
deportation; women and children from Malawi, Zambia, and the
Democratic Republic of the Congo transit Zimbabwe en route to South
Africa; small numbers of South African girls are trafficked to
Zimbabwe for domestic labor
tier rating: Tier 3 - Zimbabwe does not fully comply with the
minimum standards for the elimination of trafficking and is not
making significant efforts to do so
Illicit drugs:
transit point for African cannabis and South Asian heroin, mandrax,
and methamphetamines destined for the South African and European
markets
This page was last updated on 19 December, 2006
======================================================================
@2001 GDP (purchasing power parity)
$25.69 billion (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2002 Population growth rate (%)
0.62% (2006 est.)
This page was last updated on 19 December, 2006
======================================================================
@2003 GDP - real growth rate (%)
-7.7% (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2004 GDP - per capita (PPP)
$2,100 (2005 est.)
This page was last updated on 19 December, 2006
======================================================================
@2006 Dependency status
Akrotiri
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus','41ccb74467532b1539527913e2e3e83eb9053040d7722f3123db8cf4e10b3283','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d2426ce340cd42eace015ce70c1a7b560985f4869b9111a7298b5f68735b42d',2006,'EH','Western Sahara','people-and-society',33,'This category includes the entries dealing with the characteristics of
the people and their society.
People - note
This entry includes miscellaneous demographic information of
significance not included elsewhere.
Personal Names - Capitalization
The Factbook capitalizes the surname or family name of individuals for
the convenience of our users who are faced with a world of different
cultures and naming conventions. The need for capitalization, bold
type, underlining, italics, or some other indicator of the individual''s
surname is apparent in the following examples: MAO Zedong, Fidel CASTRO
Ruz, George W. BUSH, and TUNKU SALAHUDDIN Abdul Aziz Shah ibni Al-
Marhum Sultan Hisammuddin Alam Shah. By knowing the surname, a short
form without all capital letters can be used with confidence as in
President Castro, Chairman Mao, President Bush, or Sultan Tunku
Salahuddin. The same system of capitalization is extended to the names
of leaders with surnames that are not commonly used such as Queen
ELIZABETH II. For Vietnamese names, the given name is capitalized
because officials are referred to by their given name rather than by
their surname. For example, the president of Vietnam is Tran Duc LUONG.
His surname is Tran, but he is referred to by his given name -
President LUONG.
Personal Names - Spelling
The romanization of personal names in the Factbook normally follows the
same transliteration system used by the US Board on Geographic Names
for spelling place names. At times, however, a foreign leader expressly
indicates a preference for, or the media or official documents
regularly use, a romanized spelling that differs from the
transliteration derived from the US Government standard. In such cases,
the Factbook uses the alternative spelling.
Personal Names - Titles
The Factbook capitalizes any valid title (or short form of it)
immediately preceding a person''s name. A title standing alone is not
capitalized. Examples: President PUTIN and President BUSH are chiefs of
state. In Russia, the president is chief of state and the premier is
the head of the government, while in the US, the president is both
chief of state and head of government.
Petroleum
See entries under Oil.
Petroleum products
See entries under Oil.
Pipelines
This entry gives the lengths and types of pipelines for transporting
products like natural gas, crude oil, or petroleum products.
Political parties and leaders
This entry includes a listing of significant political organizations
and their leaders.
Political pressure groups and leaders
This entry includes a listing of organizations with leaders involved in
politics, but not standing for legislative election.
Population
This entry gives an estimate from the US Bureau of the Census based on
statistics from population censuses, vital statistics registration
systems, or sample surveys pertaining to the recent past and on
assumptions about future trends. The total population presents one
overall measure of the potential impact of the country on the world and
within its region. Note: starting with the 1993 Factbook, demographic
estimates for some countries (mostly African) have explicitly taken
into account the effects of the growing impact of the HIV/AIDS
epidemic. These countries are currently: The Bahamas, Benin, Botswana,
Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central
African Republic, Democratic Republic of the Congo, Republic of the
Congo, Cote d''Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti, Honduras,
Kenya, Lesotho, Malawi, Mozambique, Namibia, Nigeria, Rwanda, South
Africa, Swaziland, Tanzania, Thailand, Togo, Uganda, Zambia, and
Zimbabwe.
Population below poverty line
National estimates of the percentage of the population falling below
the poverty line are based on surveys of sub-groups, with the results
weighted by the number of people in each group. Definitions of poverty
vary considerably among nations. For example, rich nations generally
employ more generous standards of poverty than poor nations.
Population growth rate
The average annual percent change in the population, resulting from a
surplus (or deficit) of births over deaths and the balance of migrants
entering and leaving a country. The rate may be positive or negative.
The growth rate is a factor in determining how great a burden would be
imposed on a country by the changing needs of its people for
infrastructure (e.g., schools, hospitals, housing, roads), resources
(e.g., food, water, electricity), and jobs. Rapid population growth can
be seen as threatening by neighboring countries.
Ports and terminals
This entry lists major ports and terminals primarily on the basis of
the amount of cargo tonnage shipped through the facilities on an annual
basis. In some instances, the number of containers handled or ship
visits were also considered.
Public debt
This entry records the cumulatiive total of all government borrowings
less repayments that are denominated in a country''s home currency.
Public debt should not be confused with external debt, which reflects
the foreign currency liabilities of both the private and public sector
and must be financed out of foreign exchange earnings.
Radio broadcast stations
This entry includes the total number of AM, FM, and shortwave broadcast
stations.
Railways
This entry states the total route length of the railway network and of
its component parts by gauge: broad, standard, narrow, and dual. Other
gauges are listed under note.
Reference maps
This section includes world and regional maps.
Refugees and internally displaced persons
This entry includes those persons residing in a country as refugees or
internally displaced persons (IDPs). The definition of a refugee
according to a United Nations Convention is "a person who is outside
his/her country of nationality or habitual residence; has a well-
founded fear of persecution because of his/her race, religion,
nationality, membership in a particular social group or political
opinion; and is unable or unwilling to avail himself/herself of the
protection of that country, or to return there, for fear of
persecution." The UN established the Office of the UN High Commissioner
for Refugees (UNHCR) in 1950 to handle refugee matters worldwide. The
UN Relief and Works Agency for Palestine Refugees in the Near East
(UNRWA) has a different, operational definition for a Palestinian
refugee: "a person whose normal place of residence was Palestine during
the period 1 June 1946 to 15 May 1948 and who lost both home and means
of livelihood as a result of the 1948 conflict." However, UNHCR also
assists some 400,000 Palestinian refugees not covered under the UNRWA
definition. The term "internally displaced person" is not specifically
covered in the UN Convention; it is used to describe people who have
fled their homes for reasons similar to refugees, but who remain within
their own national territory and are subject to the laws of that state.
Religions
This entry is an ordered listing of religions by adherents starting
with the largest group and sometimes includes the percent of total
population.
Reserves of foreign exchange and gold
This entry gives the dollar value for the stock of all financial assets
that are available to the central monetary authority for use in meeting
a country''s balance of payments needs as of the end-date of the period
specified. This category includes not only foreign currency and gold,
but also a country''s holdings of Special Drawing Rights in the
International Monetary Fund, and its reserve position in the Fund.
Roadways
This entry gives the total length of the road network and includes the
length of the paved and unpaved portions.
Sex ratio
This entry includes the number of males for each female in five age
groups - at birth, under 15 years, 15-64 years, 65 years and over, and
for the total population. Sex ratio at birth has recently emerged as an
indicator of certain kinds of sex discrimination in some countries. For
instance, high sex ratios at birth in some Asian countries are now
attributed to sex-selective abortion and infanticide due to a strong
preference for sons. This will affect future marriage patterns and
fertility patterns. Eventually, it could cause unrest among young adult
males who are unable to find partners.
Suffrage
This entry gives the age at enfranchisement and whether the right to
vote is universal or restricted.
Telephone numbers
All telephone numbers in The World Factbook consist of the country code
in brackets, the city or area code (where required) in parentheses, and
the local number. The one component that is not presented is the
international access code, which varies from country to country. For
example, an international direct dial telephone call placed from the US
to Madrid, Spain, would be as follows: 011 [34] (1) 577-xxxx, where 011
is the international access code for station-to-station calls; 01 is
for calls other than station-to-station calls, [34] is the country code
for Spain, (1) is the city code for Madrid, 577 is the local exchange,
and xxxx is the local telephone number. An international direct dial
telephone call placed from another country to the US would be as
follows: international access code + [1] (202) 939-xxxx, where [ 1] is
the country code for the US, (202) is the area code for Washington, DC,
939 is the local exchange, and xxxx is the local telephone number.
Telephone system
This entry includes a brief general assessment of the system with
details on the domestic and international components. The following
terms and abbreviations are used throughout the entry:
Arabsat - Arab Satellite Communications Organization (Riyadh, Saudi
Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen''s band mobile radio communications.
Cellular telephone system - the telephones in this system are radio
transceivers, with each instrument having its own private radio
frequency and sufficient radiated power to reach the booster station in
its area (cell), from which the telephone signal is fed to a telephone
exchange.
Central American Microwave System - a trunk microwave radio relay
system that links the countries of Central America and Mexico with each
other.
Coaxial cable - a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a cylindrical
conducting shell; a large number of telephone channels can be made
available within the insulated space by the use of a large number of
carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network or
Autovon); basic general-purpose, switched voice network of the Defense
Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization (Paris).
Fiber-optic cable - a multichannel communications cable using a thread
of optical glass fibers as a transmission medium in which the signal
(voice, video, etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised by
the Groupe Special Mobile of the pan-European standardization
organization, Conference Europeanne des Posts et Telecommunications
(CEPT) in 1982.
HF - high frequency; any radio frequency in the 3,000- to 30,000-kHz
range.
Inmarsat - International Maritime Satellite Organization (London);
provider of global mobile satellite communications for commercial,
distress, and safety applications at sea, in the air, and on land.
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia.
Landline - communication wire or cable of any sort that is installed on
poles or buried in the ground.
Marecs - Maritime European Communications Satellite used in the
Inmarsat system on lease from the European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in the
Inmarsat system.
Medarabtel - the Middle East Telecommunications Project of the
International Telecommunications Union (ITU) providing a modern
telecommunications network, primarily by microwave radio relay, linking
Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, and Yemen; it was initially started in
Morocco in 1970 by the Arab Telecommunications Union (ATU) and was
known at that time as the Middle East Mediterranean Telecommunications
Network.
Microwave radio relay - transmission of long distance telephone calls
and television programs by highly directional radio microwaves that are
received and sent on from one booster station to another on an optical
path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system that
was developed jointly by the national telecommunications authorities of
the Nordic countries (Denmark, Finland, Iceland, Norway, and Sweden).
Orbita - a Russian television service; also the trade name of a packet-
switched digital telephone network.
Radiotelephone communications - the two-way transmission and reception
of sounds by broadcast radio on authorized frequencies using telephone
handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
SAFE - South African Far East Cable
Satellite communication system - a communication system consisting of
two or more earth stations and at least one satellite that provide long
distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system.
Satellite earth station - a communications facility with a microwave
radio transmitting and receiving antenna and required receiving and
transmitting equipment for communicating with satellites.
Satellite link - a radio connection between a satellite and an earth
station permitting communication between them, either one-way (down
link from satellite to earth station - television receive-only
transmission) or two-way (telephone channels).
SHF - super high frequency; any radio frequency in the 3,000- to
30,000-MHz range.
Shortwave - radio frequencies (from 1.605 to 30 MHz) that fall above
the commercial broadcast band and are used for communication over long
distances.
Solidaridad - geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite
telecommunications.
Submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity
submarine coaxial telephone cables linking Europe with North America.
Telefax - facsimile service between subscriber stations via the public
switched telephone network or the international Datel network.
Telegraph - a telecommunications system designed for unmodulated
electric impulse transmission.
Telex - a communication service involving teletypewriters connected by
wire through automatic exchanges.
Tropospheric scatter - a form of microwave radio transmission in which
the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances.
Trunk network - a network of switching centers, connected by
multichannel trunk lines.
UHF - ultra high frequency; any radio frequency in the 300- to 3,000-
MHz range.
VHF - very high frequency; any radio frequency in the 30- to 300-MHz
range.
Telephones - main lines in use
This entry gives the total number of main telephone lines in use.
Telephones - mobile cellular
This entry gives the total number of mobile cellular telephone
subscribers.
Television broadcast stations
This entry gives the total number of separate broadcast stations plus
any repeater stations.
Terminology
Due to the highly structured nature of the Factbook database, some
collective generic terms have to be used. For example, the word Country
in the Country name entry refers to a wide variety of dependencies,
areas of special sovereignty, uninhabited islands, and other entities
in addition to the traditional countries or independent states.
Military is also used as an umbrella term for various civil defense,
security, and defense activities in many entries. The Independence
entry includes the usual colonial independence dates and former ruling
states as well as other significant nationhood dates such as the
traditional founding date or the date of unification, federation,
confederation, establishment, or state succession that are not strictly
independence dates. Dependent areas have the nature of their dependency
status noted in this same entry.
Terrain
This entry contains a brief description of the topography.
Time Difference
This entry is expressed in The World Factbook in two ways. First, it is
stated as the difference in hours between the capital of an entity and
Coordinated Universal Time (UTC) during Standard Time. Additionally,
the difference in time between the capital of an entity and that
observed in Washington, D.C. is also provided. Note that the time
difference assumes both locations are simultaneously observing Standard
Time or Daylight Saving Time.
Time zones
Ten countries (Australia, Brazil, Canada, Indonesia, Kazakhstan,
Mexico, New Zealand, Russia, Spain, and the United States) and the
island of Greenland observe more than one official time depending on
the number of designated time zones within their boundaries. An
illustration of time zones throughout the world and within countries
can be seen in the Standard Time Zones of the World map included in the
Reference Maps section of The World Factbook.
Total fertility rate
This entry gives a figure for the average number of children that would
be born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each
age. The total fertility rate (TFR) is a more direct measure of the
level of fertility than the crude birth rate, since it refers to births
per woman. This indicator shows the potential for population change in
the country. A rate of two children per woman is considered the
replacement rate for a population, resulting in relative stability in
terms of total numbers. Rates above two children indicate populations
growing in size and whose median age is declining. Higher rates may
also indicate difficulties for families, in some situations, to feed
and educate their children and for women to enter the labor force.
Rates below two children indicate populations decreasing in size and
growing older. Global fertility rates are in general decline and this
trend is most pronounced in industrialized countries, especially
Western Europe, where populations are projected to decline dramatically
over the next 50 years.
Trafficking in persons
Trafficking in persons is modern-day slavery, involving victims who are
forced, defrauded, or coerced into labor or sexual exploitation. The
International Labor Organization (ILO), the UN agency charged with
addressing labor standards, employment, and social protection issues,
estimates that 12.3 million people worldwide are enslaved in forced
labor, bonded labor, forced child labor, sexual servitude, and
involuntary servitude at any given time. Human trafficking is a multi-
dimensional threat, depriving people of their human rights and
freedoms, risking global health, promoting social breakdown, inhibiting
development by depriving countries of their human capital, and helping
fuel the growth of organized crime. In 2000, the US Congress passed the
Trafficking Victims Protection Act (TVPA), reauthorized in 2003 and
2005, which provides tools for the US to combat trafficking in persons,
both domestically and abroad. One of the law¿s key components is the
creation of the US Department of State¿s annual Trafficking in Persons
Report, which assesses the government response in some 150 countries
with a significant number of victims trafficked across their borders
who are recruited, harbored, transported, provided, or obtained for
forced labor or sexual exploitation. Countries in the annual report are
rated in three tiers, based on government efforts to combat
trafficking. The countries identified in this entry are those listed in
the 2006 Trafficking in Persons Report as Tier 2 Watch List or Tier 3
based on the following definitions:
Tier 2 Watch List countries do not fully comply with the minimum
standards for the elimination of trafficking but are making significant
efforts to do so, and meet one of the following criteria: 1. they
display a high or significantly increasing number victims, 2. they have
failed to provide evidence of increasing efforts to combat trafficking
in persons, or, 3. they have committed to take action over the next
year.
Tier 3 countries neither satisfy the minimum standards for the
elimination of traffiking nor demonstrate a significant effort to do
so. Countries in this tier are subject to potential non-humanitarian
and non-trade sanctions.
$NA
World
GWP (gross world product): $60.63 trillion (2005 est.)
NA
World
1.14% (2006 est.)
NA%
World
4.7% (2005 est.)
$NA
World
$9,500 (2005 est.)','cc1a8651f563e60d08e140aafa1088c21055a681ddb857598b7b536c3a432a72','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce2602d4bea61da028bc00d2bd655343cadd1f1d011ef988c13469404e5f459f',2006,'AR','Argentina','people-and-society',235,'Religions:
nominally Roman Catholic 96%, Protestant 2%, other 2%
Languages:
Spanish (official), numerous indigenous dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.4%
male: 93.8%
female: 93.1% (2003 est.)
Government Venezuela
Country name:
conventional long form: Bolivarian Republic of Venezuela
conventional short form: Venezuela
local long form: Republica Bolivariana de Venezuela
local short form: Venezuela
Government type:
federal republic
Capital:
name: Caracas
geographic coordinates: 10 30 N, 66 56 W
time difference: UTC-4 (1 hour ahead of Washington, DC during
Standard Time)
Administrative divisions:
23 states (estados, singular - estado), 1 capital district*
(distrito capital), and 1 federal dependency** (dependencia
federal); Amazonas, Anzoategui, Apure, Aragua, Barinas, Bolivar,
Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**, Distrito
Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva
Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas, Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Independence:
5 July 1811 (from Spain)
National holiday:
Independence Day, 5 July (1811)
Constitution:
30 December 1999
Legal system:
open, adversarial court system
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Hugo CHAVEZ Frias (since 3 February
1999); Vice President Jose Vicente RANGEL Vale (since 28 April
2002); note - the president is both the chief of state and head of
$543.4 billion (2005 est.)
0.96% (2006 est.)
9.2% (2005 est.)
$13,700 (2005 est.)
chief of mission: Ambassador Earl Anthony WAYNE
embassy: Avenida Colombia 4300, C1425GMN Buenos Aires
mailing address: international mail: use street address; APO
address: Unit 4334, APO AA 34034
telephone: [54] (11) 5777-4533
FAX: [54] (11) 5777-4240','c573567b129d94af36ed1cebdc1669e7aaf46dcd66c1d17817b94922f2afdd1a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73e30745cc5cb60cbec649bce914d7557466151aab9dfad8cb868021cd0566b0',2006,'AF','Afghanistan','people-and-society',236,'$21.5 billion (2004 est.)
2.67% (2006 est.)
14% (2005 est.)
$800 (2004 est.)
chief of mission: Ambassador Ronald E. NEUMANN
embassy: The Great Masood Road, Kabul
mailing address: 6180 Kabul Place, Dulles, VA 20189-6180
telephone: [00 93] (20) 230-0436
FAX: [00 93] (20) 230-1364
Akrotiri
none (overseas territory of the UK)','9308732b91d0e68a4c068b24e16e95d4ac7ad3f38002f09b4750669f6f4fcc1d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c45862875cf4d96654d3a8d853aee83e4c9d7742f478ad259f8bd5eadc20dbb',2006,'AL','Albania','people-and-society',237,'$18.87 billion
note: Albania has a large gray economy that may be as large as 50%
of official GDP (2005 est.)
0.52% (2006 est.)
5.5% (2005 est.)
$5,300 (2005 est.)
chief of mission: Ambassador Marcie B. RIES
embassy: Rruga e Elbasanit, Labinoti #103, Tirana
mailing address: US Department of State, 9510 Tirana Place, Dulles,
VA 20189-9510
telephone: [355] (4) 247285
FAX: [355] (4) 232222','916833988221246d6893ade7df9b86ea4989253871240d517ad592b270c5f527','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0680c417f95dfa4d416a256470e8f2033c5109b5aeecf3689ddd581d196c23a',2006,'DZ','Algeria','people-and-society',238,'$235.5 billion (2005 est.)
1.22% (2006 est.)
5.5% (2005 est.)
$7,200 (2005 est.)
chief of mission: Ambassador Robert S. FORD
embassy: 04 Chemin Cheikh Bachir Ibrahimi El-Biar 16030, Algiers
mailing address: B. P. 408, Alger-Gare, 16030 Algiers
telephone: [213] (021) 69-12-55
FAX: [213] (021) 69-39-79','5bd77c90da545342f07346c902bd97d98f4fe18713b8cac9c071fedfce038a80','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24fb1a511d8a76276a2652838248ee4a0b5b3e48fd0a71c0e4322ac30a91fef9',2006,'AS','American Samoa','people-and-society',239,'$510.1 million (2003 est.)
-0.19% (2006 est.)
3% NA%
$5,800 (2005 est.)
unincorporated and unorganized territory of the US;
administered by the Office of Insular Affairs, US Department of the
Interior
none (territory of the US)','adfad3f531f1e9fa79c6dae0baa80260feb2fffde5056ebaf14008c31af4b28e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ea824ecb7405e310de20022453686b9ba9b330543ee1519a2a51cc820bf59d',2006,'AD','Andorra','people-and-society',240,'$1.84 billion (2004)
0.89% (2006 est.)
4% (2004 est.)
$24,000 (2004)
the US does not have an embassy in Andorra; the US
Ambassador to Spain is accredited to Andorra; US interests in
Andorra are represented by the Consulate General''s office in
Barcelona (Spain); mailing address: Paseo Reina Elisenda de
Montcada, 23, 08034 Barcelona, Spain; telephone: [34] (3) 280-2227;
FAX: [34] (3) 205-5206','d2055186738c75bd999129c2ef08e25d3bb836e52b354fac28fd4db5ac3ef8c4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fad437c689d22d252583110bc587d0947149fa3e50c1573d008287d0497f4ad',2006,'AO','Angola','people-and-society',241,'$45.32 billion (2005 est.)
2.45% (2006 est.)
19.9% (2005 est.)
$3,800 (2005 est.)
chief of mission: Ambassador Cynthia EFIRD
embassy: number 32 Rua Houari Boumedienne (in the Miramar area of
Luanda), Luanda
mailing address: international mail: Caixa Postal 6468, Luanda;
pouch: US Embassy Luanda,US Department of State, 2550 Luanda Place,
Washington, DC 20521-2550
telephone: [244] (222) 64-1000
FAX: [244] (222) 64-1232','8eb252031a77c36b1fdad198bca86389629ee8cdfd557385e8595a5804d8f90b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45c9cbf53a87d8eaf403c464d3df3a711e20260b87e14073c18232119473669f',2006,'AI','Anguilla','people-and-society',242,'$108.9 million (2004 est.)
1.57% (2006 est.)
10.2% (2004 est.)
$8,800 (2004 est.)
overseas territory of the UK
none (overseas territory of the UK)','14d55bd62fea719cb1e09f58964dc4fbf0baaa7f9663506dc6ab122a93363a27','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13385da890b93e07c0840783788da6baf203143f158133fb5faf700214992f42',2006,'AG','Antigua and Barbuda','people-and-society',243,'$750 million (2002 est.)
0.55% (2006 est.)
3.8% (2005 est.)
$10,900 (2005 est.)
the US does not have an embassy in Antigua and
Barbuda (embassy closed 30 June 1994); the US Ambassador to Barbados
is accredited to Antigua and Barbuda','c886e84098441ee8c7629a44b811d11b6f909145edaeead996e53a923e7d4ca3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff02b37362f7a44feb3e25c13b974a825889d602ac3af19398003f45a32c37e2',2006,'AM','Armenia','people-and-society',244,'$14.45 billion (2005 est.)
-0.19% (2006 est.)
13.9% (2005 est.)
$4,800 (2005 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires
Anthony F. GODFREY
embassy: 1 American Ave., Yerevan 375082
mailing address: American Embassy Yerevan, US Department of State,
7020 Yerevan Place, Washington, DC 20521-7020
telephone: [374](10) 464-700
FAX: [374](10) 464-742','b5cad5d447287c3bfdd20292a14d49e73cac9c7c44ff170f70c2c18bed7c0903','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96554122615b86b589fc22f2ef991658ebf2c174e3976acb11ac8ced0369f045',2006,'AW','Aruba','people-and-society',245,'$2.258 billion (2005 est.)
0.44% (2006 est.)
2.4% (2005 est.)
$21,800 (2004 est.)
member country of the Kingdom of the Netherlands; full
autonomy in internal affairs obtained in 1986 upon separation from
the Netherlands Antilles; Dutch Government responsible for defense
and foreign affairs
Ashmore and Cartier Islands
territory of Australia; administered by
the Australian Department of Transport and Regional Services
Baker Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Bassas da India
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
the US does not have an embassy in Aruba; the Consul General
to Netherlands Antilles is accredited to Aruba
Ashmore and Cartier Islands
none (territory of Australia)','51ff1bb6f43de669d5f3132ad3a3db010249a2515f2595a31a60861f8e496281','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa9326a8afaa92f11d09e8de84cd45bf69450295f57b4bf7d94a8a4ae50a38c3',2006,'AU','Australia','people-and-society',246,'$635.5 billion (2005 est.)
0.85% (2006 est.)
2.7% (2005 est.)
$31,600 (2005 est.)
chief of mission: Ambassador Robert D. McCALLUM, Jr.
embassy: Moonah Place, Yarralumla, Canberra, Australian Capital
Territory 2600
mailing address: APO AP 96549
telephone: [61] (02) 6214-5600
FAX: [61] (02) 6214-5970
consulate(s) general: Melbourne, Perth, Sydney','bc10caee786a8cab36fc33670ab344986e36b125c5e13e4d0a5e762739ad6e1a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e6398e9c54df7eeea0eb12b16f3344c32585f18a65b956d54c36606e0663b2a',2006,'AT','Austria','people-and-society',247,'$265.8 billion (2005 est.)
0.09% (2006 est.)
1.8% (2005 est.)
$32,500 (2005 est.)
chief of mission: Ambassador Susan R. McCAW
embassy: Boltzmanngasse 16, A-1090, Vienna
mailing address: use embassy street address
telephone: [43] (1) 31339-0
FAX: [43] (1) 3100682','e42c33643f16b8b1d4521500278af853f752a2397ca72471ff144671ad0573c1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b8a3c418408e201967bd4ade54d792d85ab507bfd93fe7cae30279143eae835',2006,'AZ','Azerbaijan','people-and-society',248,'$42.99 billion (2005 est.)
Bahamas, The
$6.105 billion (2005 est.)
0.66% (2006 est.)
Bahamas, The
0.64% (2006 est.)
26.4% (2005 est.)
Bahamas, The
3.7% (2005 est.)
$5,400 (2005 est.)
Bahamas, The
$20,200 (2005 est.)
chief of mission: Ambassador Anne E. DERSE
embassy: 83 Azadliyg Prospecti, Baku AZ1007
mailing address: American Embassy Baku, US Department of State, 7050
Baku Place, Washington, DC 20521-7050
telephone: [994] (12) 4980-335 through 337
FAX: [994] (12) 4656-671
Bahamas, The
chief of mission: Ambassador John D. ROOD
embassy: 42 Queen Street, Nassau
mailing address: local or express mail address: P. O. Box N-8197,
Nassau; US Department of State, 3370 Nassau Place, Washington, DC
20521-3370
telephone: [1] (242) 322-1181, 328-2206 (after hours)
FAX: [1] (242) 356-0222','26fd9a39c8c2127ba055f1ae6725fe011d88116bbf70b64561c572be05c4475f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e35aded76e79419c4fe6b5789da541106503b774f8b372f93f702ac1986e8a27',2006,'BH','Bahrain','people-and-society',249,'$15.9 billion (2005 est.)
1.45% (2006 est.)
5.9% (2005 est.)
$23,100 (2005 est.)
chief of mission: Ambassador William T. MONROE
embassy: Building #979, Road 3119 (next to Al-Ahli Sports Club),
Block 331, Zinj District, Manama
mailing address: American Embassy Manama, PSC 451, FPO AE
09834-5100; international mail: American Embassy, Box 26431, Manama
telephone: [973] 1724-2700
FAX: [973] 1727-0547','0b3cc575c225d6e72162e829c134d7a5f00e0067e46b488b9c498d4d43ea2f09','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f6ad1e3b3ff4b47121e4bb9f701b1a7a5195eb2ff796e97574abaa5ed100b36',2006,'BD','Bangladesh','people-and-society',250,'$305.9 billion (2005 est.)
2.09% (2006 est.)
6.4% (2005 est.)
$2,100 (2005 est.)
chief of mission: Ambassador Patricia A. BUTENIS
embassy: Madani Avenue, Baridhara, Dhaka 1212
mailing address: G. P. O. Box 323, Dhaka 1000
telephone: [880] (2) 885-5500
FAX: [880] (2) 882-3744','f686436513bb64d29f039a7fc2ff9a6b723743f1be3a10f8e8c2cac0f0553f56','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfc48758c5e3ae5d2f49b3f1349ce19015ac99596b1b32b9fb2221c924b3a252',2006,'BB','Barbados','people-and-society',251,'$4.815 billion (2005 est.)
0.37% (2006 est.)
4.1% (2005 est.)
$17,300 (2005 est.)
chief of mission: Ambassador Mary M. OURISMAN
embassy: Canadian Imperial Bank of Commerce Building, Broad Street,
Bridgetown; (courier) ALICO Building-Cheapside, Bridgetown
mailing address: P. O. Box 302, Bridgetown; CMR 1014, APO AA 34055
telephone: [1] (246) 436-4950
FAX: [1] (246) 429-5246, 429-3379','a660c24a9a4d046d3b3608e3e35f7c299dcefbd54f9d3a4f5111184d2890079f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc0444c2af3edd6a7ffd362de0d8bddf03a87478250e726b15a62d50e470f33e',2006,'BY','Belarus','people-and-society',252,'$73.09 billion (2005 est.)
-0.06% (2006 est.)
9.2% (2005 est.)
$7,100 (2005 est.)
chief of mission: Ambassador Karen B. STEWART
embassy: 46 Starovilenskaya St., Minsk 220002
mailing address: PSC 78, Box B Minsk, APO 09723
telephone: [375] (17) 210-12-83, 217-7347, 217-7348
FAX: [375] (17) 234-7853','ca288e303d8676fecaa94ea2500e90171faf5fc0d2226ef3339bdfedfa631632','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c31b21eccdfa8aadf5e44d7a2f3a106c588c5ddc0cc0c2717abae9f88f05fbdd',2006,'BE','Belgium','people-and-society',253,'$322.3 billion (2005 est.)
0.13% (2006 est.)
1.5% (2005 est.)
$31,100 (2005 est.)
chief of mission: Ambassador Tom C. KOROLOGOS
embassy: Regentlaan 27 Boulevard du Regent, B-1000 Brussels
mailing address: PSC 82, Box 002, APO AE 09710
telephone: [32] (2) 508-2111
FAX: [32] (2) 511-2725','f23f5d6549f352789912585f7fb21514cc9265d960f823e61b6a97ff79766f13','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9575d87dc0a7a5e49ecb862b6e8704c5ed50edc03b067035ca66de94e0cdefa1',2006,'BZ','Belize','people-and-society',254,'$1.778 billion (2004 est.)
2.31% (2006 est.)
3.8% (2005 est.)
$6,800 (2005 est.)
chief of mission: Ambassador Robert J. DIETER
embassy: 29 Gabourel Lane, Belize City
mailing address: P. O. Box 286, Belize City
telephone: [501] 227-7161 through 7163
FAX: [501] 223-0802','448abfdc65dd4f6e5fae6e5ce60d03df40bf174bad21bfac8040beec50f1b42f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec07c17626b4765a65b072d41060f66c8f00e9d4cc359df9f9cce86613cd46ee',2006,'BJ','Benin','people-and-society',255,'$8.419 billion (2005 est.)
2.73% (2006 est.)
3.5% (2005 est.)
$1,100 (2005 est.)
chief of mission: Ambassador Wayne NEILL
embassy: Rue Caporal Bernard Anani, Cotonou
mailing address: 01 B. P. 2012, Cotonou
telephone: [229] 30-06-50
FAX: [229] 30-06-70','06e930ad2115c9bdcac9f5be2811be35274025ee4b4c204fc94fa4ac347d85b7','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7af461b7e41264fb493393cbde922ce01e26491ed2ef7af8c2782d7a092861b',2006,'BM','Bermuda','people-and-society',256,'$4.5 billion (2004 est.)
0.61% (2006 est.)
4.6% (2004 est.)
$69,900 (2004 est.)
overseas territory of the UK
chief of mission: Consul General Gregory W. SLAYTON
consulate(s) general: Crown Hill, 16 Middle Road, Devonshire DVO3
mailing address: P. O. Box HM325, Hamilton HMBX; American Consulate
General Hamilton, US Department of State, 5300 Hamilton Place,
Washington, DC 20520-5300
telephone: [1] (441) 295-1342
FAX: [1] (441) 295-1592, [1] (441) 296-9233','7e4d5f636d64bec7d6dda3af3f3300a119445e5d94c79167048cdf6bbf241a5b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9779e45deec9f48919aade1d0348ef3d67e525ed43dc93767b1283ad009efb31',2006,'BT','Bhutan','people-and-society',257,'$2.9 billion (2003 est.)
Bolivia
$25.82 billion (2005 est.)
2.1% (2006 est.)
Bolivia
1.45% (2006 est.)
5.9% (2005 est.)
Bolivia
4.1% (2005 est.)
$1,400 (2003 est.)
Bolivia
$2,900 (2005 est.)
the US and Bhutan have no formal diplomatic relations,
although informal contact is maintained between the Bhutanese and US
Embassy in New Delhi (India)
Bolivia
chief of mission: Ambassador Philip S. GOLDBERG
embassy: Avenida Arce 2780, La Paz
mailing address: P. O. Box 425, La Paz; APO AA 34032
telephone: [591] (2) 216-8000
FAX: [591] (2) 216-8111','507801c76a1f2f5e91e1a5119145648d9068e1c24539f13487b2f234b4b5a456','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd6474c3e1b4716703b3a34b2df210ba6940512c68f4b9829c14fcf36971aa5c',2006,'BA','Bosnia and Herzegovina','people-and-society',258,'$23.09 billion
note: Bosnia has a large informal sector that could also be as much
as 50% of official GDP (2005 est.)
1.35% (2006 est.)
5% (2005 est.)
$5,200 (2005 est.)
chief of mission: Ambassador Douglas L.
McELHANEY
embassy: Alipasina 43, 71000 Sarajevo
mailing address: use street address
telephone: [387] (33) 445-700
FAX: [387] (33) 659-722
branch office(s): Banja Luka, Mostar','48f4b33f24d01a339f76d304df97fde6071ec53677d23e43df4bbd4aac4d9bc6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('525f48a0433f3eb58ab37b2924885a654985b1363666de282f70cc0185a0cfd6',2006,'BW','Botswana','people-and-society',259,'$17.53 billion (2005 est.)
-0.04% (2006 est.)
5.5% (2005 est.)
$10,700 (2005 est.)
chief of mission: Ambassador Katherine H. CANAVAN
embassy: address NA, Gaborone
mailing address: Embassy Enclave, P. O. Box 90, Gaborone
telephone: [267] 353982
FAX: [267] 312782','676af857ab2b525326f7157ca749c38952ed8c986908acb7b763c97927f93c81','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('731c831a344e880a05de42af89a426c77ba028d4e9cc74c32665a47c31c3aca3',2006,'BR','Brazil','people-and-society',260,'$1.536 trillion (2005 est.)
British Virgin Islands
$853.4 million (2004 est.)
Brunei
$6.842 billion (2003 est.)
1.04% (2006 est.)
British Virgin Islands
1.97% (2006 est.)
Brunei
1.87% (2006 est.)
2.3% (2005 est.)
British Virgin Islands
1% (2002 est.)
Brunei
1.7% (2004 est.)
$8,300 (2005 est.)
British Virgin Islands
$38,500 (2004 est.)
Brunei
$23,600 (2003 est.)
chief of mission: Ambassador Clifford M. SOBEL
embassy: Avenida das Nacoes, Quadra 801, Lote 3, Distrito Federal
Cep 70403-900, Brasilia
mailing address: Unit 3500, APO AA 34030
telephone: [55] (61) 3312-7000
FAX: [55] (61) 3225-9136
consulate(s) general: Rio de Janeiro, Sao Paulo
consulate(s): Recife','7869774a361f51607d7eeac3dcfc20a5329a11daabcc47b996d7d42342fd5d33','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16611d26f43c3877087845e353d6f13c90027e4f4d6235533424e2762a6a5893',2006,'BG','Bulgaria','people-and-society',261,'$71.67 billion (2005 est.)
-0.86% (2006 est.)
5.5% (2005 est.)
$9,600 (2005 est.)
chief of mission: Ambassador John Ross BEYRLE
embassy: 16 Kozyak Street, Sofia 1407
mailing address: American Embassy Sofia, US Department of State,
5740 Sofia Place, Washington, DC 20521-5740
telephone: [359] (2) 937-5100
FAX: [359] (2) 937-5320','eb95b66e70810139daa34f9136d2b7a89a0cbf63f5c8795e2e31154835d0e7e4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bc74e9e8c75ea690101d658b445e818b2ae54dfd253d0b21f6ea28c5f690059',2006,'BF','Burkina Faso','people-and-society',262,'$16.66 billion (2005 est.)
Burma
$80.11 billion (2005 est.)
3% (2006 est.)
Burma
0.81% (2006 est.)
3.5% (2005 est.)
Burma
5.2% (2005 est.)
$1,200 (2005 est.)
Burma
$1,700 (2005 est.)
chief of mission: Ambassador Jeanine E. JACKSON
embassy: 602 Avenue Raoul Follereau, Koulouba, Secteur 4
mailing address: 01 B. P. 35, Ouagadougou 01; pouch mail - US
Department of State, 2440 Ouagadougou Place, Washington, DC
20521-2440
telephone: [226] 50-30-67-23
FAX: [226] 50-30-38-90, 50-31-23-68
Burma
chief of mission: Ambassador (vacant); Charge d''Affaires Shari
VILLAROSA
embassy: 581 Merchant Street, Rangoon (GPO 521)
mailing address: Box B, APO AP 96546
telephone: [95] (1) 379-880, 379-881
FAX: [95] (1) 256-018','61e07ea0bb7dd9597c8c1dc9c6f07193553e2207a93b659e8d84828e9f74b0b5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51ad9977d2a49cc14d92a50b058f200227f83d374ac018b5c2b655d75c27037c',2006,'BI','Burundi','people-and-society',263,'$5.404 billion (2005 est.)
3.7% (2006 est.)
1.1% (2005 est.)
$700 (2005 est.)
chief of mission: Ambassador Patricia Newton MOLLER
embassy: Avenue des Etats-Unis, Bujumbura
mailing address: B. P. 1720, Bujumbura
telephone: [257] 223454
FAX: [257] 222926','c53c04383d89262acf2aded1bcfe908afb9f79e324950c78fdb99ecf291974f7','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86ed2c44f9fe6c1392d8f71991ac9bcfd072b3119bd74c1b899aeef105bbb57e',2006,'KH','Cambodia','people-and-society',264,'$34.08 billion (2005 est.)
1.78% (2006 est.)
13.4% (2005 est.)
$2,500 (2005 est.)
chief of mission: Ambassador Joseph A. MUSSOMELI
embassy: #1, Street 96, Sangkat Wat Phnom, Khan Daun Penh, Phnom Penh
mailing address: Box P, APO AP 96546
telephone: [855] (23) 728-000
FAX: [855] (23) 728-600','2301c9fac4bcc817a8317d5ad6760e05c7b25f85c0bba14985f4c57ded392c56','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead3bb9aebf6bcf7d98f80b53cdfea00d2a1d612c926fda25a0444939c41a4aa',2006,'CM','Cameroon','people-and-society',265,'$39.75 billion (2005 est.)
2.04% (2006 est.)
2.4% (2005 est.)
$2,300 (2005 est.)
chief of mission: Ambassador Niels MARQUARDT
embassy: Rue Nachtigal, Yaounde
mailing address: P. O. Box 817, Yaounde; pouch: American Embassy, US
Department of State, Washington, DC 20521-2520
telephone: [237] 220 15 00; Consular: [237] 220 16 03
FAX: [237] 220 16 20; Consular FAX: [237] 220 17 52
branch office(s): Douala','45202478e15e9a127b2fb2f237b968926d3acb547e162df59216647c5d6fddbb','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d9e25e5aca3e97f5a287dc8ff67a86a607ea57d6acfa740f6f2bc53c2b53593',2006,'CA','Canada','people-and-society',266,'$1.111 trillion (2005 est.)
Cape Verde
$2.99 billion (2005 est.)
0.88% (2006 est.)
Cape Verde
0.64% (2006 est.)
2.9% (2005 est.)
Cape Verde
5.5% (2005 est.)
$33,900 (2005 est.)
Cape Verde
$6,200 (2005 est.)
chief of mission: Ambassador David H. WILKINS
embassy: 490 Sussex Drive, Ottawa, Ontario K1N 1G8
mailing address: P. O. Box 5000, Ogdensburgh, NY 13669-0430
telephone: [1] (613) 238-5335, 4470
FAX: [1] (613) 688-3082
consulate(s) general: Calgary, Halifax, Montreal, Quebec, Toronto,
Vancouver, Winnipeg
Cape Verde
chief of mission: Ambassador Roger D. PIERCE
embassy: Rua Abilio Macedo n6, Praia
mailing address: C. P. 201, Praia
telephone: [238] 2-60-89-00
FAX: [238] 2-61-13-55','ae1c91166defbf3cbb7d7dbf67398ecbecc28a1960d791e058e1419b21a895d9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('545ec8bf5ef4e8b4dbf860b95a1b39aad16153ea132dfc1ec3779c33eb29abe4',2006,'KY','Cayman Islands','people-and-society',267,'$1.939 billion (2004 est.)
2.56% (2006 est.)
0.9% (2004 est.)
$43,800 (2004 est.)
overseas territory of the UK
none (overseas territory of the UK)','85a92f3eba4b353adfb33dd06e48e2cf2646af240dce824f7728f4f1e717a7fe','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6254d67f506b7aa1f3937928e935710d33a3ad8c93d701148f2f6c05ecf53b4',2006,'CF','Central African Republic','people-and-society',268,'$4.677 billion (2005 est.)
1.53% (2006 est.)
2.2% (2005 est.)
$1,100 (2005 est.)
chief of mission: Ambassador (vacant);
Charge d''Affaires James PANOS
embassy: Avenue David Dacko, Bangui
mailing address: B. P. 924, Bangui
telephone: [236] 61 02 00
FAX: [236] 61 44 94
note: the embassy is currently operating with a minimal staff','055bdc512d75cd6a994041250fdb07e9a3d2b7a793b034c9d2d21be8d1296abf','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d41c7fd643ff45856a23358b7198e06534737ce0fab03c81724f2aa78642cd5',2006,'TD','Chad','people-and-society',269,'$13.98 billion (2005 est.)
2.93% (2006 est.)
6% (2005 est.)
$1,400 (2005 est.)
chief of mission: Ambassador Marc M. WALL
embassy: Avenue Felix Eboue, N''Djamena
mailing address: B. P. 413, N''Djamena
telephone: [235] 516-211
FAX: [235] 515-654','c6fc84746717b87bc1f4be928bdb2df54d7ea9582f0c758a5d39e1e5e186abb6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c563acbdbd94760742f9f07ffea6eb715c94790ceaab558457555cb0ebdeaf64',2006,'CL','Chile','people-and-society',270,'$189.9 billion (2005 est.)
0.94% (2006 est.)
6.3% (2005 est.)
$11,900 (2005 est.)
chief of mission: Ambassador Craig A. KELLY
embassy: Avenida Andres Bello 2800, Las Condes, Santiago
mailing address: APO AA 34033
telephone: [56] (2) 232-2600
FAX: [56] (2) 330-3710','8a27fcf3f8a3d6ebf17d554e8b3b99fbeeadd4fbc3c412cd468541519a5f73a2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1c5f3fc0fe581973ec90bf32cedb1f57abeac304ea964eecafedb1a0e8f9f20',2006,'CN','China','people-and-society',271,'$8.883 trillion (2005 est.)
0.59% (2006 est.)
10.2% (official data) (2005 est.)
$6,800 (2005 est.)
chief of mission: Ambassador Clark T. RANDT, Jr.
embassy: Xiu Shui Bei Jie 3, 100600 Beijing
mailing address: PSC 461, Box 50, FPO AP 96521-0002
telephone: [86] (10) 6532-3831
FAX: [86] (10) 6532-3178
consulate(s) general: Chengdu, Guangzhou, Hong Kong and Macau,
Shanghai, Shenyang','52b72848f81f6e186283af78dbdc05769ad2686ca6c105ba8fbace094efd6482','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5cf02a48401f2c6cdadc0943cdf559242ae645f2a6795ffc479bb2c21383cc',2006,'CX','Christmas Island','people-and-society',272,'$NA
0% (2006 est.)
non-self governing territory of Australia;
administered by the Australian Department of Transport and Regional
Services
Clipperton Island
possession of France; administered by France from
French Polynesia by a high commissioner of the Republic
none (territory of Australia)','276f3b61b0e5f7ceed2b09329201a980574c0cfce0bba6084b6ebc35b1863a9a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db410f207f4efadad429ffe4e8f64f34000b450dd015ab5ddaab14410b778892',2006,'CC','Cocos (Keeling) Islands','people-and-society',273,'$NA
0% (2006 est.)
non-self governing territory of Australia;
administered from Canberra by the Australian Department of Transport
and Regional Services
none (territory of Australia)','92491f61374fb4b1f395d31b15fff39f38207d61f1524b12038d2d716707c0c3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bcbb70b42056e987cd0631d7481beb04a33f6bbd42fd1e1732199cc8faeba10',2006,'CO','Colombia','people-and-society',274,'$341.1 billion (2005 est.)
1.46% (2006 est.)
5.2% (2005 est.)
$7,900 (2005 est.)
chief of mission: Ambassador William B. WOOD
embassy: Calle 22D-BIS, numbers 47-51, Apartado Aereo 3831
mailing address: Carrera 45 #22D-45, Bogota, D.C., APO AA 34038
telephone: [57] (1) 315-0811
FAX: [57] (1) 315-2197','7e82ce65bb0b32b3da5b036113b93405b34e2fcd512fdf053dab1e8abb223428','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd94531446e9573652561458478c54d9d184482c62477d9ac694faeab1d5c689',2006,'KM','Comoros','people-and-society',275,'$441 million (2002 est.)
Congo, Democratic Republic of the
$40.67 billion (2005 est.)
Congo, Republic of the
$4.585 billion (2005 est.)
2.87% (2006 est.)
Congo, Democratic Republic of the
3.07% (2006 est.)
Congo, Republic of the
2.6% (2006 est.)
3% (2005 est.)
Congo, Democratic Republic of the
7.1% (2005 est.)
Congo, Republic of the
8.2% (2005 est.)
$600 (2005 est.)
Congo, Democratic Republic of the
$700 (2005 est.)
Congo, Republic of the
$1,300 (2005 est.)
the US does not have an embassy in Comoros; the ambassador
to Madagascar is accredited to Comoros
Congo, Democratic Republic of the
chief of mission: Ambassador Roger
MEECE
embassy: 310 Avenue des Aviateurs, Kinshasa
mailing address: Unit 31550, APO AE 09828
telephone: [243] (88) 43608
FAX: [243] (88) 43467
Congo, Republic of the
chief of mission: Ambassador (vacant); Charge
d''Affaires Mark BIEDLINGMAIER
embassy: NA
mailing address: NA
telephone: [243] (88) 43608
note: the embassy is temporarily collocated with the US Embassy in
the Democratic Republic of the Congo (US Embassy Kinshasa, 310
Avenue des Aviateurs, Kinshasa)','152cf46cc998d3fb34f264fb32873f63ed46c83e98b54437607393c47054730b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e80db7a754dd120ab98eb48588045d61e5beb08b9c617b487f2a2280bf3f4f23',2006,'CK','Cook Islands','people-and-society',276,'$183.2 million (2005 est.)
-1.2% between 1996-2001 (2001 census)
0.1% (2005 est.)
$9,100 (2005 est.)
self-governing in free association with New Zealand;
Cook Islands is fully responsible for internal affairs; New Zealand
retains responsibility for external affairs and defense, in
consultation with the Cook Islands
Coral Sea Islands
territory of Australia; administered from Canberra
by the Department of the Environment, Sport, and Territories
Dhekelia
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus
Europa Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
Falkland Islands (Islas Malvinas)
overseas territory of the UK; also
claimed by Argentina
none (self-governing in free association with New
Zealand)
Coral Sea Islands
none (territory of Australia)','95f0a41152882cf0d7be5d169a8ee543d49658ef47a4b65c1ea7106923448d1c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43070c9cb28249d4950ccfc54534baff0c84348592efb95bd2e31d6b54355ce1',2006,'CR','Costa Rica','people-and-society',277,'$45.67 billion (2005 est.)
Cote d''Ivoire
$27.58 billion (2005 est.)
1.45% (2006 est.)
Cote d''Ivoire
2.03% (2006 est.)
5.9% (2005 est.)
Cote d''Ivoire
1% (2005 est.)
$11,400 (2005 est.)
Cote d''Ivoire
$1,600 (2005 est.)
chief of mission: Ambassador Mark LANGDALE
embassy: Calle 120 Avenida O, Pavas, San Jose
mailing address: APO AA 34020
telephone: [506] 519-2000
FAX: [506] 519-2305
Cote d''Ivoire
chief of mission: Ambassador Aubrey HOOKS
embassy: Riviera Golf 01, Abidjan
mailing address: B. P. 1866, Abidjan 01
telephone: [225] 20 21 09 79
FAX: [225] 20 22 32 59','25433e70778b0a30da3babdb742c6d6c63a90fbf99727d567d19a3f89c920719','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e990f9b70a732f7803b772959d833842500e8343e25fc2883d057af2ea7bc8a9',2006,'HR','Croatia','people-and-society',278,'$55.79 billion (2005 est.)
-0.03% (2006 est.)
4.3% (2005 est.)
$12,400 (2005 est.)
chief of mission: Ambassador Robert A. BRADTKE
embassy: 2 Thomas Jefferson Street, 10010 Zagreb
mailing address: use street address
telephone: [385] (1) 661-2200
FAX: [385] (1) 661-2373','e9319caa4680fd41b752f940a28d0ceffee709cb06c093287dd9d35040cdc189','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c29318792498a8e3a27291aa4f26bfc4b45930fdbd37ab22e4b5ad03a59ce808',2006,'CU','Cuba','people-and-society',279,'$40.06 billion (2005 est.)
0.31% (2006 est.)
8% (2005 est.)
$3,500 (2005 est.)
none; note - the US has an Interests Section in the Swiss
Embassy, headed by Principal Officer Michael E. PARMLY; address:
USINT, Swiss Embassy, Calzada between L and M Streets, Vedado,
Havana; telephone: [53] (7) 833-3551 through 3559 (operator
assistance required); FAX: [53] (7) 833-3700; protecting power in
Cuba is Switzerland','8a2d1a720f8ec589ab536e69190f0ea3e8f372f793e44d5d3d753a7af24953a4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f33297b089df3e7488b8f1eadc051c83b35446cf9c9a43086957c06d577181eb',2006,'CY','Cyprus','people-and-society',280,'Republic of Cyprus: $16.81 billion; north Cyprus: $4.54
billion (2005 est.)
Czech Republic
$204.4 billion (2005 est.)
0.53% (2006 est.)
Czech Republic
-0.06% (2006 est.)
Republic of Cyprus: 3.8%; north Cyprus: 10.6% (2005 est.)
Czech Republic
6.1% (2005 est.)
Republic of Cyprus: $21,600 (2005 est.); north Cyprus: $7,135
(2004 est.)
Czech Republic
$20,000 (2005 est.)
chief of mission: Ambassador Ronald L. SCHLICHER
embassy: corner of Metochiou and Ploutarchou Streets, 2407 Engomi,
Nicosia
mailing address: P. O. Box 24536, 1385 Nicosia
telephone: [357] (22) 393939
FAX: [357] (22) 780944
Czech Republic
chief of mission: Ambassador Richard W. GRABER
embassy: Trziste 15, 11801 Prague 1
mailing address: use embassy street address
telephone: [420] 257 022 000
FAX: [420] 257 022 809','c6da981264afef39caa14476243da4db5213dc62c97667eae1803c306cff7389','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba83766eaaf73060e070565030790ab5e95da99e47f22bc27a1fec99bffc16b8',2006,'DK','Denmark','people-and-society',281,'$189.3 billion (2005 est.)
0.33% (2006 est.)
3.2% (2005 est.)
$34,800 (2005 est.)
chief of mission: Ambassador James P. CAIN
embassy: Dag Hammarskjolds Alle 24, 2100 Copenhagen
mailing address: PSC 73, APO AE 09716
telephone: [45] 33 41 71 00
FAX: [45] 35 43 02 23
Dhekelia
none (overseas territory of the UK)','523022c80ef19fcfcbc0523d80d385841b007f2b7691fd122793589050c1b077','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad5d8b7162d50fed5402708f8c0baa3ae3eeeda082a503aef84f129602f759e5',2006,'DJ','Djibouti','people-and-society',282,'$619 million (2002 est.)
2.02% (2006 est.)
3.2% (2005 est.)
$1,000 (2005 est.)
chief of mission: Ambassador W. Stuart SYMINGTON
embassy: Plateau du Serpent, Boulevard Marechal Joffre, Djibouti
mailing address: B. P. 185, Djibouti
telephone: [253] 35 39 95
FAX: [253] 35 39 40','03294eeb248fd51c0a9e5063435535c67f0b43411a91490f20b279ec4346475f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('841eb6da97fdf85fa27ae2fb6f033ff67e7d37c124412178f8b42992edd2f469',2006,'DM','Dominica','people-and-society',283,'$384 million (2003 est.)
-0.08% (2006 est.)
3.1% (2005 est.)
$3,800 (2005 est.)
the US does not have an embassy in Dominica; the US
Ambassador to Barbados is accredited to Dominica','a5e062100d49e06479b550c585133a233769eff31d501a1fb5c87dfabc9c4f23','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eebba91579cbc0406513cb47e6e9ab6fc91b4670ac380b249dc989428db34ec',2006,'DO','Dominican Republic','people-and-society',284,'$67.44 billion (2005 est.)
East Timor
$370 million (2004 est.)
1.47% (2006 est.)
East Timor
2.08% (2006 est.)
9.3% (2005 est.)
East Timor
1.8% (2005 est.)
$7,500 (2005 est.)
East Timor
$800 (2005 est.)
chief of mission: Ambassador Hans H. HERTELL
embassy: corner of Calle Cesar Nicolas Penson and Calle Leopoldo
Navarro, Santo Domingo
mailing address: Unit 5500, APO AA 34041-5500
telephone: [1] (809) 221-2171
FAX: [1] (809) 686-7437
East Timor
chief of mission: Ambassador Grover Joseph REES
embassy: Avenida de Portugal, Praia dos Conqueiros, Dili
mailing address: US Department of State, 8250 Dili Place,
Washington, DC 20521-8250
telephone: (670) 332-4684
FAX: (670) 331-3206','ab28e000fb329883d74ce97d1df3c61370194e4f3b1cea11fa3def92619fb61d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f05f6b1a21ecb74c2d1f2234f05762d98d10de9aa49b08f7dd745354d4ae718',2006,'EC','Ecuador','people-and-society',285,'$57.23 billion (2005 est.)
1.5% (2006 est.)
4.7% (2005 est.)
$4,300 (2005 est.)
chief of mission: Ambassador Linda L. JEWELL
embassy: Avenida 12 de Octubre y Avenida Patria, Quito
mailing address: APO AA 34039
telephone: [593] (2) 256-2890
FAX: [593] (2) 250-2052
consulate(s) general: Guayaquil','83c0aa6a7146b853724a612cbf609c19330beb9df2045e58eeab4c8656358e6d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('611208b25ea658346e6ce9f632e9edaa2eada5c2e1422e992bd176253a8cdbe0',2006,'EG','Egypt','people-and-society',286,'$304.3 billion (2005 est.)
1.75% (2006 est.)
4.9% (2005 est.)
$3,900 (2005 est.)
chief of mission: Ambassador Francis J. RICCIARDONE, Jr.
embassy: 8 Kamal El Din Salah St., Garden City, Cairo
mailing address: Unit 64900, Box 15, APO AE 09839-4900
telephone: [20] (2) 797-3300
FAX: [20] (2) 797-3200','6212db527ab4f230f2761ee08bdc68a20a45ef065c02190fae5aaa8387fbec10','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16b2b9e0eb02cedc9a2523da8ced9310b9298d59cb5ec0871be2a685aa26465f',2006,'SV','El Salvador','people-and-society',287,'$31.3 billion (2005 est.)
1.72% (2006 est.)
2.8% (2005 est.)
$4,700 (2005 est.)
chief of mission: Ambassador H. Douglas BARCLAY
embassy: Final Boulevard Santa Elena Sur, Antiguo Cuscatlan, La
Libertad, San Salvador
mailing address: Unit 3116, APO AA 34023
telephone: [503] 2278-4444
FAX: [503] 2278-5522','193b633533b8b021054ac00bf9af207d45ced2c74fca60cf9ad2dd275db47f96','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aceb284f7412fd34e0bc9c7c46f9971a677c9ae917db2773d8d01a914138f65',2006,'GQ','Equatorial Guinea','people-and-society',288,'$25.69 billion (2005 est.)
2.05% (2006 est.)
18.6% (2005 est.)
$50,200 (2005 est.)
chief of mission: the US ambassador to Cameroon is
accredited to Equatorial Guinea
embassy: adjacent to the golf course at the base of Mont Febe; note
- relocated embassy is opened for limited functions; inquiries
should continue to be directed to the US Embassy in Yaounde, Cameroon
mailing address: B.P. 817, Yaounde, Cameroon; US Embassy Yaounde, US
Department of State, Washington, DC 20521-2520
telephone: [237] 220 15 00
FAX: [237] 220 16 20','c93f18f5518ad6465cff7e121b435b45fed7063b9991be1defd0bc19858e9aa4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d502221b25082a2ed148d543930d881b7ee3b4c0564e16717c6014b7b5cf6fd',2006,'ER','Eritrea','people-and-society',289,'$4.471 billion (2005 est.)
2.47% (2006 est.)
2% (2005 est.)
$1,000 (2005 est.)
chief of mission: Ambassador Scott H. DELISI
embassy: 179 Alaa Street, Asmara
mailing address: P. O. Box 211, Asmara
telephone: [291] (1) 120004
FAX: [291] (1) 127584','a1e6c5e77ecd4e1a3bc77c0a0aa924f6229df62b0f45b224045abef791308d7f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a238f2c3a1726ee02f419a8f1eac0d305d682546320eee9e439c9ae8fd5f27c7',2006,'EE','Estonia','people-and-society',290,'$23.34 billion (2005 est.)
-0.64% (2006 est.)
10.5% (2005 est.)
$17,500 (2005 est.)
chief of mission: Ambassador Aldona Zofia WOS
embassy: Kentmanni 20, 15099 Tallinn
mailing address: use embassy street address
telephone: [372] 668-8100
FAX: [372] 668-8134','7c76d28486f9a4bcf5fe2aa44891e2d7e7b58de62d858813f0376b1292e5671a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afd699be60100a0e3f60bcccf7e19caeb87e73783ce54a1fd779d34f23b600a2',2006,'ET','Ethiopia','people-and-society',291,'$64.73 billion (2005 est.)
European Union
$12.18 trillion (2005 est.)
Falkland Islands (Islas Malvinas)
$75 million (2002 est.)
2.31% (2006 est.)
European Union
0.15% (2006 est.)
Falkland Islands (Islas Malvinas)
2.44% (2006 est.)
8.9% (2005 est.)
European Union
1.7% (2005 est.)
Falkland Islands (Islas Malvinas)
NA%
$900 (2005 est.)
European Union
$28,100 (2005 est.)
Falkland Islands (Islas Malvinas)
$25,000 (2002 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires
Vicki HUDDLESTON
embassy: Entoto Street, Addis Ababa
mailing address: P. O. Box 1014, Addis Ababa
telephone: [251] (1) 517-4000
FAX: [251] (1) 517-4888
European Union
chief of mission: Ambassador C. Boyden GRAY
embassy: 13 Zinnerstraat/Rue Zinner, B-1000 Brussels
mailing address: same as above
telephone: [32] (2) 508-2222
FAX: [32] (2) 512-5720
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)','95e55db3b7fdaac2369c321ad4ba8f64ca2d45ed10364772aa925a8a3a1680fe','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3233d58642948af3d3e32b9fc76ab5dd0107eb5c35d2c953019354fd49ea8f9a',2006,'FO','Faroe Islands','people-and-society',292,'$1 billion (2001 est.)
0.58% (2006 est.)
10% (2001 est.)
$22,000 (2001 est.)
part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark since 1948
none (self-governing overseas administrative division
of Denmark)','a477f2e1f1a703d61e4e15e479dbcdafbe141129ac71bf2dfc8628baa98e8a69','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e151136c691b800766b039cfa7979486c3724793d629f07d5e7333f6caaaa6f',2006,'FJ','Fiji','people-and-society',293,'$5.255 billion (2005 est.)
1.4% (2006 est.)
1.7% (2005 est.)
$5,900 (2005 est.)
chief of mission: Ambassador Larry Miles DINGER
embassy: 31 Loftus Street, Suva
mailing address: P. O. Box 218, Suva
telephone: [679] 331-4466
FAX: [679] 330-0081','f6cb741f00240210e2be643a97554665d759f9c9dd6e280468773680579dbd17','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b458bf3252551fd51376c6cf21a30c29634dd88c8a7b584a4c5753da518d264b',2006,'FI','Finland','people-and-society',294,'$161.9 billion (2005 est.)
0.14% (2006 est.)
3% (2005 est.)
$31,000 (2005 est.)
chief of mission: Ambassador Marilyn WARE
embassy: Itainen Puistotie 14B, 00140 Helsinki
mailing address: APO AE 09723
telephone: [358] (9) 616250
FAX: [358] (9) 6162 5800','bf8460e8b229e4d6c3915e4637e9d10665a55abd95c398b5839c651f0dc41293','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d982cfc35893d86f333fbe46f4707fa71932d905d53ce55788c76ca4048e062e',2006,'FR','France','people-and-society',295,'$1.794 trillion (2005 est.)
0.35% (2006 est.)
1.2% (2005 est.)
$29,600 (2005 est.)
chief of mission: Ambassador Craig R. STAPLETON
embassy: 2 Avenue Gabriel, 75382 Paris Cedex 08
mailing address: PSC 116, APO AE 09777
telephone: [33] (1) 43-12-22-22
FAX: [33] (1) 42 66 97 83
consulate(s) general: Marseille, Strasbourg','a97fb31295084f1ab0c07943e0dda7dfc74fadbd081efa8b6a0c611e00e9bbd9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0627383822011aacfe0fe5552d9b221c2d3b9092355b241f301a26e8bfc286c5',2006,'GF','French Guiana','people-and-society',296,'$1.551 billion (2003 est.)
1.96% (2006 est.)
NA%
$8,300 (2003 est.)
overseas department of France
none (overseas department of France)','b86543f446ab4e28ae3eea3c9e3a9fb694fc646228b7d6402bab5879f86d270d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79c6fe41858fe36249129cf29f22c1ce5f59603758ad360b78a13e3685f61660',2006,'PF','French Polynesia','people-and-society',297,'$4.58 billion (2003 est.)
1.48% (2006 est.)
NA% (2001 est.)
$17,500 (2003 est.)
overseas lands of France; overseas territory of
France from 1946-2004
French Southern and Antarctic Lands
overseas territory of France
since 1955; administered from Paris by Administrateur Superieur
Michel CHAMPON (since 20 December 2004), assisted by Secretary
General Jean-Yves HERMOSO (since NA)
none (overseas lands of France)
French Southern and Antarctic Lands
none (overseas territory of
France)','9548c411df1141f5989769708dfbf9c556aa96e5f083cab99eb9d7f3aa974ab4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb0efc87f8c8f4aa46d711c656baab8dea65272d463f5f0d2b9de53e1d307a89',2006,'GA','Gabon','people-and-society',298,'$9.739 billion (2005 est.)
Gambia, The
$3.034 billion (2005 est.)
Gaza Strip
$768 million (2003 est.)
2.13% (2006 est.)
Gambia, The
2.84% (2006 est.)
Gaza Strip
3.71% (2006 est.)
2.9% (2005 est.)
Gambia, The
5.5% (2005 est.)
Gaza Strip
4.5% (2003 est.)
$7,000 (2005 est.)
Gambia, The
$1,900 (2005 est.)
Gaza Strip
$600 (2003 est.)
chief of mission: Ambassador Barrie R. WALKLEY
embassy: Boulevard du Bord de Mer, Libreville
mailing address: Centre Ville, B. P. 4000, Libreville
telephone: [241] 76 20 03 through 76 20 04, after hours - 74 34 92
FAX: [241] 74 55 07
Gambia, The
chief of mission: Ambassador Joseph D. STAFFORD, III
embassy: Kairaba Avenue, Fajara, Banjul
mailing address: P. M. B. No. 19, Banjul
telephone: [220] 439-2856, 437-6169, 437-6170
FAX: [220] 439-2475','ea7bca2a031ef73bd561307d70f9e2371ee83200fa1412ab3111ad90982c2508','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ace5ca3635e857df77e3c4ecbfbb5509f7f9ca86ec3755e848f5a208b215b3ef',2006,'GE','Georgia','people-and-society',299,'$16.03 billion (2005 est.)
-0.34% (2006 est.)
9.3% (2005 est.)
$3,400 (2005 est.)
chief of mission: Ambassador John F. TEFFT
embassy: 11 George Balanchine St., T''bilisi 0131
mailing address: 7060 T''bilisi Place, Washington, DC 20521-7060
telephone: [995] (32) 27-70-00
FAX: [995] (32) 53-23-10','5186e7e8a8426f5d8472d3e437ddd3ac91ca2a82929a37b1600a7d188a11ac3f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccb87b4101bfaead3b7960bf019184e2494d385dec672284419e2d6fcb7d9dc9',2006,'DE','Germany','people-and-society',300,'$2.48 trillion (2005 est.)
-0.02% (2006 est.)
0.9% (2005 est.)
$30,100 (2005 est.)
chief of mission: Ambassador William R. TIMKEN, Jr.
embassy: Neustaedtische Kirchstrasse 4-5, 10117 Berlin; note - a new
embassy will be built near the Brandenburg Gate in Berlin; ground
was broken in October 2004 and completion is scheduled for 2008
mailing address: PSC 120, Box 1000, APO AE 09265
telephone: [49] (030) 2385 174
FAX: [49] (030) 8305-1215
consulate(s) general: Duesseldorf, Frankfurt am Main, Hamburg,
Leipzig, Munich','98d98d9a6e2914799a771910ce7d3eba648d02a1ddefa4aa51868d3431e1710e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7ebf936e503e11ae31ccdb08714ca9166e68d60b75858ad97e1e0b4d93db701',2006,'GH','Ghana','people-and-society',301,'$54.86 billion (2005 est.)
2.07% (2006 est.)
5.9% (2005 est.)
$2,500 (2005 est.)
chief of mission: Ambassador Mary Carlin YATES
embassy: 6th and 10th Lanes, 798/1 Osu, Accra
mailing address: P. O. Box 194, Accra
telephone: [233] (21) 775-347, 775-348
FAX: [233] (21) 701-813','a05297ec0e3b72fc460937b0be253fb92f739c3ba938dd06d604410d3ed76a50','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c67e7d7c420026d127a13bff4aed0e8392ffff1c3a2604aa85ae943cb0ac36a7',2006,'GI','Gibraltar','people-and-society',302,'$769 million (2000 est.)
0.14% (2006 est.)
NA%
$27,900 (2000 est.)
overseas territory of the UK
Glorioso Islands
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
none (overseas territory of the UK)','76d3d9a1455d8f44e8f25f997b505cb806cda77940b114cf389190aa743f8b55','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56b1c8d2006bd36602c87916baee844998b46e2545b88c8cb8bb64f1e3bd9d87',2006,'GR','Greece','people-and-society',303,'$238.2 billion (2005 est.)
0.18% (2006 est.)
3.7% (2005 est.)
$22,300 (2005 est.)
chief of mission: Ambassador Charles P. RIES
embassy: 91 Vasilisis Sophias Avenue, 10160 Athens
mailing address: PSC 108, APO AE 09842-0108
telephone: [30] (210) 721-2951
FAX: [30] (210) 645-6282
consulate(s) general: Thessaloniki','aaf0bbcfd53a119cef84abee68ca742bf9bd7bc2cb575a1c2f479e54b04a9535','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d37f5f576518aeab93a29ba42ac63076ae3f4004b33373dd829f29c8a9e8511',2006,'GL','Greenland','people-and-society',304,'$1.1 billion (2001 est.)
-0.03% (2006 est.)
1.8% (2001 est.)
$20,000 (2001 est.)
part of the Kingdom of Denmark; self-governing overseas
administrative division of Denmark since 1979
none (self-governing overseas administrative division of
Denmark)','5e483b2f424582571fe2f52b8d7587fa668bf1aea5f168e2506d33fd9534a5a4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('560a589fdea1cbb566afe4b614eaab7935301f6b67da581ab1cdcab7b096e9d0',2006,'GD','Grenada','people-and-society',305,'$440 million (2002 est.)
0.26% (2006 est.)
0.9% (2005 est.)
$3,900 (2005 est.)
chief of mission: the US Ambassador to Barbados is
accredited to Grenada
embassy: Lance-aux-Epines Stretch, Saint George''s
mailing address: P. O. Box 54, Saint George''s
telephone: [1] (473) 444-1173 through 1176
FAX: [1] (473) 444-4820','8881de8696a155b7e8a65b88f32cd84f19aa65169f19ff0ca06917ae79cfae45','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fa7a71eef90e839d04a5b155e25b43a546e40ea3d9c6646b908e5411d77c8a1',2006,'GP','Guadeloupe','people-and-society',306,'$3.513 billion (2003 est.)
0.88% (2006 est.)
NA%
$7,900 (2003 est.)
overseas department of France
none (overseas department of France)','3c8a62da7252570dbe44ccea29326c8587d49a94b62a4f8b38c245af63d56482','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e7011fdf69b029a17dcb6609073c7b7458a0e12696e49b1c9fc58b87773a783',2006,'GU','Guam','people-and-society',307,'$2.5 billion (2005 est.)
1.43% (2006 est.)
NA%
$15,000 (2005 est.)
organized, unincorporated territory of the US with policy
relations between Guam and the US under the jurisdiction of the
Office of Insular Affairs, US Department of the Interior
none (territory of the US)','384ebefba88f66532acfa166d7b5d89555ac2c88369ffd36a46b1e0661b897d4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5997a54234ba2cdd2e449202525b21325470c3f5741ba7f582e2922ddd7df1fb',2006,'GT','Guatemala','people-and-society',308,'$56.86 billion (2005 est.)
2.27% (2006 est.)
3.2% (2005 est.)
$4,700 (2005 est.)
chief of mission: Ambassador James M. DERHAM
embassy: 7-01 Avenida Reforma, Zone 10, Guatemala City
mailing address: APO AA 34024
telephone: [502] 2326-4000
FAX: [502] 2326-4654','685d461ebbc82dc1ea9d35f5c4443676ef6a9393991c5550f63f52aaf12c2213','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38243d79c53b8b985b0b9fb9361cd5947773e8c3c7d90e6ca1677e8fbb854264',2006,'GG','Guernsey','people-and-society',309,'$2.59 billion (2003 est.)
0.26% (2006 est.)
3% (2003 est.)
$40,000 (2003 est.)
British crown dependency
none (British crown dependency)','daffc7c8b2b30ed9212cb4ae389191f587c4a5fda04b2d106f7745b7819598a7','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b3d522890b1dd0615fc6efa638037fe57041fd67b309d530d640dc9a524ac47',2006,'GN','Guinea','people-and-society',310,'$18.65 billion (2005 est.)
2.63% (2006 est.)
2% (2005 est.)
$2,000 (2005 est.)
chief of mission: Ambassador Jackson C. MCDONALD
embassy: Koloma, Conakry, east of Hamdallaye Circle
mailing address: B. P. 603, Transversale No. 2, Centre Administratif
de Koloma, Commune de Ratoma, Conakry
telephone: [224] 30-42-08-61
FAX: [224] 30-42-08-73','349e4741ab06212a815c592076b400d3a7c9af157a82f04cded172c1897e722e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c28de9a8a4bafbde66e468dfa51b9dea7dbcbf8aa76a492dc1c511707db9e372',2006,'GW','Guinea-Bissau','people-and-society',311,'$1.171 billion (2005 est.)
2.07% (2006 est.)
2.3% (2005 est.)
$800 (2005 est.)
the US Embassy suspended operations on 14 June 1998 in
the midst of violent conflict between forces loyal to then President
VIEIRA and military-led junta; the US Ambassador to Senegal is
accredited to Guinea-Bissau','b2b61afce88361fbc277d235e57bab1785980f6bb4613da6c53ae293eeb20da4','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e5b2528020876e5a0762992a1ad8c76726d3732f8c0af468760617ab2a1d19e',2006,'GY','Guyana','people-and-society',312,'$3.439 billion (2005 est.)
0.25% (2006 est.)
-3% (2005 est.)
$4,500 (2005 est.)
chief of mission: Ambassador David M. ROBINSON
embassy: 100 Young and Duke Streets, Kingston, Georgetown
mailing address: P. O. Box 10507, Georgetown; US Embassy, 3170
Georgetown Place, Washington DC 20521-3170
telephone: [592] 225-4900 through 4909
FAX: [592] 225-8497','ff3c023f4dec5ac692e56afc4fcd3a6c8c7118e7d248cecaa3d67b64131fc931','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c7845420c8abb0957b9a6622734792b226d968d190e8129addc40bd59a9cdc8',2006,'HT','Haiti','people-and-society',313,'$13.97 billion (2005 est.)
Holy See (Vatican City)
$NA
2.3% (2006 est.)
Holy See (Vatican City)
0.01% (2006 est.)
1.8% (2005 est.)
$1,700 (2005 est.)
chief of mission: Ambassador Janet A. SANDERSON
embassy: 5 Harry S Truman Boulevard, Bicentenaire-Port-au-Prince
mailing address: P. O. Box 1761, Port-au-Prince
telephone: [509] 222-0200
FAX: [509] 223-9038','446fbdefdb9e42aa6528084fd5541983192a9229d452135283557190e6602336','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea969ea9348f310aff9df4fffe5c39e623acf6a84c75c96845d755fd5fd49359',2006,'HN','Honduras','people-and-society',314,'$20.61 billion (2005 est.)
2.16% (2006 est.)
4.2% (2005 est.)
$2,900 (2005 est.)
chief of mission: Ambassador Charles A. FORD
embassy: Avenida La Paz, Apartado Postal No. 3453, Tegucigalpa
mailing address: American Embassy, APO AA 34022, Tegucigalpa
telephone: [504] 236-9320, 238-5114
FAX: [504] 236-9037','03bc37a417140e3d871f1d7df951b3440b1f7ec8733ba23d1cf78099143dca90','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35035c53cd457837d7bb8219ef3c3527a924f968f5b11aff663658f2d2945251',2006,'HK','Hong Kong','people-and-society',315,'$234.3 billion (2005 est.)
0.59% (2006 est.)
7.3% (2005 est.)
$34,000 (2005 est.)
special administrative region of China
Howland Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Iles Eparses
possessions of France; administered by the Senior
Administrator of the Territory of the French Southern and Antarctic
Lands (TAAF), resident in Reunion
chief of mission: Consul General James B. CUNNINGHAM
consulate(s) general: 26 Garden Road, Hong Kong
mailing address: PSC 461, Box 1, FPO AP 96521-0006
telephone: [852] 2523-9011
FAX: [852] 2845-1598','61e48b45334e9e7c9fad8a804560ce199d3da83092ecfeb45d148a10062804b1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebf33bf861c90516b041e122975b7cca3c2622cb98bd4f6d2cc752686b4e9b12',2006,'HU','Hungary','people-and-society',316,'$163.1 billion (2005 est.)
-0.25% (2006 est.)
4.1% (2005 est.)
$16,300 (2005 est.)
chief of mission: Ambassador April H. FOLEY
embassy: Szabadsag ter 12, H-1054 Budapest
mailing address: pouch: American Embassy Budapest, 5270 Budapest
Place, US Department of State, Washington, DC 20521-5270
telephone: [36] (1) 475-4400
FAX: [36] (1) 475-4764','693aa1119094b6715581346c70f7e4dd75c614732822139619798c56aa1e1c47','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f786034678f579472080541c58fb59c324412f7e8e2585112801548f5c54e70',2006,'IS','Iceland','people-and-society',317,'$10.59 billion (2005 est.)
0.87% (2006 est.)
5.6% (2005 est.)
$35,700 (2005 est.)
chief of mission: Ambassador Carol VAN VOORST
embassy: Laufasvegur 21, 101 Reykjavik
mailing address: US Department of State, 5640 Reykjavik Place,
Washington, D.C. 20521-5640
telephone: [354] 562-9100
FAX: [354] 562-9118','b3cc5ca5530701f908f102218dd599890411df0037128027a065fb6bc4305cfb','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15b9ab5cd76f49e7241b6052964a0e823ccd9a65c87310839357c0e583bd99b7',2006,'IN','India','people-and-society',318,'$3.666 trillion (2005 est.)
1.38% (2006 est.)
8.4% (2005 est.)
$3,400 (2005 est.)
chief of mission: Ambassador David C. MULFORD
embassy: Shantipath, Chanakyapuri, New Delhi 110021
mailing address: use embassy street address
telephone: [91] (11) 2419-8000
FAX: [91] (11) 2419-0017
consulate(s) general: Chennai (Madras), Kolkata (Calcutta), Mumbai
(Bombay)','3024e794f71bfec35ee7505a4df89b017d128ad8208ccb5170f39f25e6ae1379','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('892abca91aebf01674db4ca515ac2aa7081a8c763671f1488942f88c6e0d86bb',2006,'ID','Indonesia','people-and-society',319,'$869.7 billion (2005 est.)
Iran
$569.9 billion (2005 est.)
1.41% (2006 est.)
Iran
1.1% (2006 est.)
5.6% (2005 est.)
Iran
6.9% (2005 est.)
$3,600 (2005 est.)
Iran
$8,400 (2005 est.)
chief of mission: Ambassador B. Lynn PASCOE
embassy: Jalan 1 Medan Merdeka Selatan 4-5, Jakarta 10110
mailing address: Unit 8129, Box 1, FPO AP 96520
telephone: [62] (21) 3435-9000
FAX: [62] (21) 3435-9922
consulate(s) general: Surabaya
consulate(s): Medan; Denpasar (consular agency)
Iran
none; note - protecting power in Iran is Switzerland','c20e1f55e733099afc62cc53d2c62a9d8dca85ead51e8f8c707f1b4ec631a801','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4665efcde518b104094c3815c658cc390312f80460c20f54b00e8f59d11868b2',2006,'IQ','Iraq','people-and-society',320,'$94.1 billion (2005 est.)
2.66% (2006 est.)
-3% (2005 est.)
$1,800 (2005 est.)
chief of mission: Ambassador Zalmay KHALILZAD
embassy: Baghdad
mailing address: APO AE 09316
telephone: 00-1-240-553-0584 ext. 5340 or 5635; note - Consular
Section
FAX: NA','5a0c48caf8bae117674a9d02295b620d391bf57082c668cbec70977c19198b12','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d972c5f4cdbee8b045b39c5a4351aee74d248593e178feae0aabab88c25cdfa4',2006,'IE','Ireland','people-and-society',321,'$165.1 billion (2005 est.)
1.15% (2006 est.)
5.5% (2005 est.)
$41,100 (2005 est.)
chief of mission: Ambassador Thomas C. FOLEY
embassy: 42 Elgin Road, Ballsbridge, Dublin 4
mailing address: use embassy street address
telephone: [353] (1) 668-8777
FAX: [353] (1) 668-9946','59b50843c4cd6762adfa1e5abc90d946bc5377556042ca896451dcd2a0ea7418','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66dc706fbf4c9aad77e03e57d2892717766b2f71e8cddf79d11e0230f1f80545',2006,'IM','Isle of Man','people-and-society',322,'$2.113 billion (2003 est.)
0.52% (2006 est.)
6.3% NA%
$27,800 (2003 est.)
British crown dependency
Jan Mayen
territory of Norway; since August 1994, administered from
Oslo through the county governor (fylkesmann) of Nordland; however,
authority has been delegated to a station commander of the Norwegian
Defense Communication Service
Jarvis Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
none (British crown dependency)','0fc4127d8898a155cebc103dccfa30b282fd19403652d4b58ff120fe4d29f5ff','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e0905ff16faebf370d0ea2c654dc79f7b18e33d8b24801e883b8749663ff3d9',2006,'IL','Israel','people-and-society',323,'$156.9 billion (2005 est.)
1.18% (2006 est.)
5.2% (2005 est.)
$25,000 (2005 est.)
chief of mission: Ambassador Richard H. JONES
embassy: 71 Hayarkon Street, Tel Aviv 63903
mailing address: PSC 98, Box 29, APO AE 09830
telephone: [972] (3) 519-7575
FAX: [972] (3) 516-4390
consulate(s) general: Jerusalem; note - an independent US mission,
established in 1928, whose members are not accredited to a foreign','a726f8a1365e4a52ad50882dc23d64f45e164c43b6545353450e53c752ee8747','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31a3f002dc5d0f9e4359eb7c13c770d1278e8ec77821f26a064b3a66f7f02fd1',2006,'IT','Italy','people-and-society',324,'$1.667 trillion (2005 est.)
0.04% (2006 est.)
0.1% (2005 est.)
$28,700 (2005 est.)','acaaca7c65cc3dacd3f01346b98c6e60851687ed4ab2d3ebf1d314be0487e8fa','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('614b664f30c503ff741dce33717529994c6b415b68a0d9553caae58e381ad18f',2006,'JP','Japan','people-and-society',325,'$4.025 trillion (2005 est.)
0.02% (2006 est.)
2.6% (2005 est.)
$31,600 (2005 est.)','d691f45ed71ed04996f5d419467fe347917211e80e0ccb3af74aa873f5db4728','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de30e6c10a19acde8f342ff2e529f7bdab6f78b96ca22472bb01ebf44e31d94f',2006,'JE','Jersey','people-and-society',326,'$3.6 billion (2003 est.)
0.28% (2006 est.)
NA%
$40,000 (2003 est.)
British crown dependency
Johnston Atoll
unincorporated territory of the US; administered from
Honolulu, HI, by Pacific Air Forces, Hickam Air Force Base, and the
Fish and Wildlife Service of the US Department of the Interior as
part of the National Wildlife Refuge system
Juan de Nova Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
Kingman Reef
unincorporated territory of the US; administered from
Washington, DC, by the US Fish and Wildlife Service of the
Department of the Interior
note: on 1 September 2000, the Department of the Interior accepted
restoration of its administrative jurisdiction over Kingman Reef
from the Department of the Navy; Executive Order 3223 signed 18
January 2001 established Kingman Reef National Wildlife Refuge to be
administered by the Director, US Fish and Wildlife Service; this
refuge is managed to protect the terrestrial and aquatic wildlife of
Kingman Reef out to the 12-nautical-mile territorial sea limit
Macau
special administrative region of China','0aa8d33dbe82184edb37cb9cd05438452a5e8817370a6386f1061a108bcd8e6b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dfdc37c34392d864698b71022cac4b0dfcf4d8fdd69a05162e48eab64b0ed25',2006,'JO','Jordan','people-and-society',327,'$26.85 billion (2005 est.)
2.49% (2006 est.)
5.8% (2005 est.)
$4,700 (2005 est.)','de6bff5d21b4d4f632ef42f0b00b31605527887a98d1812c12e1664a52cda5e5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6e45c881742323d45df5e981bef250e096da0a34e95774c24d4075d610ff9e3',2006,'KZ','Kazakhstan','people-and-society',328,'$125.3 billion (2005 est.)
0.33% (2006 est.)
9.5% (2005 est.)
$8,300 (2005 est.)','5b6b85caec2b5cfbbad4e60c06f3378088ae658edfac83512d517db4493b4ee2','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b26e3720f441f944350db96ad3638460d53aeedcbe40515be0925cbcae0e2426',2006,'KE','Kenya','people-and-society',329,'$37.89 billion (2005 est.)
2.57% (2006 est.)
5.8% (2005 est.)
$1,100 (2005 est.)','6fc10f7d6549c699840edde019df0f8a3393f238d2f6534964926d9da31bc2f3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88c29dcb2810885388b3430fc9d79c5ed41c56178c121c10c3781465ae604e8d',2006,'KI','Kiribati','people-and-society',330,'$142.9 million
note: supplemented by a nearly equal amount from external sources
(2004 est.)
Korea, North
$40 billion
note: North Korea does not publish any reliable National Income
Accounts data; the datum shown here is derived from purchasing power
parity (PPP) GDP estimates for North Korea that were made by Angus
Maddison in a study conducted for the OECD; his figure for 1999 was
extrapolated to 2005 using estimated real growth rates for North
Korea''s GDP and an inflation factor based on the US GDP deflator;
the result was rounded to the nearest $10 billion (2005 est.)
Korea, South
$1.101 trillion (2005 est.)
2.24% (2006 est.)
Korea, North
0.84% (2006 est.)
Korea, South
0.42% (2006 est.)
0.3% (2005)
Korea, North
1% (2005 est.)
Korea, South
4% (2005 est.)
$1,900 (2004 est.)
Korea, North
$1,700 (2005 est.)
Korea, South
$22,600 (2005 est.)','143a407d50b60869f54764afd8ebd8e997634b4e3791d35bf524f9b9b74b573d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('680d8c3277bc2c4b9905eec2c1271363de0a175e0e3d51965f5189c8f51954e4',2006,'KW','Kuwait','people-and-society',331,'$47.36 billion (2005 est.)
3.52%
note: this rate reflects a return to pre-Gulf crisis immigration of
expatriates (2006 est.)
8.3% (2005 est.)
$20,300 (2005 est.)','0d408698a40ed3d8b91caaeebfa638372404b5ad573421b31d0035373a526465','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02a300e7c0bec7d0cc76101d1cfd4e1ed778c8f0ec421a60b2eb7a16955dc000',2006,'KG','Kyrgyzstan','people-and-society',332,'$10.08 billion (2005 est.)
Laos
$12.29 billion (2005 est.)
1.32% (2006 est.)
Laos
2.39% (2006 est.)
-0.6% (2005 est.)
Laos
7.3% (2005 est.)
$2,000 (2005 est.)
Laos
$2,000 (2005 est.)','b0870d8e32d91902532a47cb61e14de2c5b9a014e0aae6bef479713fff7c3eee','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b538c47ca29177378a5a4823ddf6dfbb221e51b79624b8e43e08584b765cdc9',2006,'LV','Latvia','people-and-society',333,'$31.46 billion (2005 est.)
-0.67% (2006 est.)
10.2% (2005 est.)
$13,700 (2005 est.)','3a0d11503e01cfa7ff5a99146df9a77afdc1f3c9b6fd57ea8214a3385de6fd17','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abe5604d47745a4a8d5bd5a9392d5d01a40fc502ead8e8fbbfce8c85b31ce261',2006,'LB','Lebanon','people-and-society',334,'$22.78 billion (2005 est.)
1.23% (2006 est.)
0.1% (2005 est.)
$6,000 (2005 est.)','f40d9281a64b7c122a284402220273ba676dc14674905daa836b0d841f6e015d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bab0d5bb778f4e79585c563d39d9ae3806615aa913800de8174f032e30f5502',2006,'LS','Lesotho','people-and-society',335,'$5.008 billion (2005 est.)
-0.46% (2006 est.)
1.2% (2005 est.)
$2,500 (2005 est.)','a535ee3e75d8e5e1ad0b8db01b7af2d44f8154862b7209d4deb3adcc2c4e46ee','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba356a1c29aa4148d7cf528b12872b916d65713f635a91cb7cd0441be5739592',2006,'LI','Liechtenstein','people-and-society',336,'$1.786 billion (2001 est.)
0.78% (2006 est.)
11% (1999 est.)
$25,000 (1999 est.)','a8ba1064f77ead0f758651481feee3c5805c704f0641c9454af842ed913a4285','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae8f4b580b810336eae5c96e95dbc2a3b0d94b077ae77661f9dc808242ad58dd',2006,'LT','Lithuania','people-and-society',337,'$49.41 billion (2005 est.)
-0.3% (2006 est.)
7.5% (2005 est.)
$14,100 (2005 est.)','de7fcc6fcc8f3b0114a71679731f45a794fd516f1895dcdc1b9e35433b50f3f6','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74546db82d1663aeed1b8c2e2d8419273f9f523e60ee4d9e744bd7ce1d7c665f',2006,'LU','Luxembourg','people-and-society',338,'$30.9 billion (2005 est.)
Macau
$10 billion (2004)
Macedonia
$15.94 billion
note: Macedonia has a large informal sector (2005 est.)
1.23% (2006 est.)
Macau
0.86% (2006 est.)
Macedonia
0.26% (2006 est.)
4% (2005 est.)
Macau
2.8% (3rd Quarter 2005)
Macedonia
4% (2005 est.)
$65,900 (2005 est.)
Macau
$22,000 (2004)
Macedonia
$7,800 (2005 est.)','de1d700c93a2ae517325571bac93887984892ca86c021fb5f49fedbf5aa68bcd','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45cd1896e39efcdf6dc16b3ec969bf3f87e741b312456e77514d854ed54bb96b',2006,'MV','Maldives','people-and-society',339,'$1.25 billion (2002 est.)
2.78% (2006 est.)
-3.6% (2005 est.)
$3,900 (2002 est.)','8db9bc8a57f0cc629a0a1200156ee5c4fa6ba880bd6fb1072757b73f668f7e9d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('068ba44bedcad92125de5c4ea190039a9b758476648dc64eeb0b7ac85585d138',2006,'ML','Mali','people-and-society',340,'$13.61 billion (2005 est.)
2.63% (2006 est.)
6.1% (2005 est.)
$1,200 (2005 est.)','7b97d1b71aa154f6e63c988a9e99588d43133ef36b5c6e03d91fe0d28cd7967b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6179bcb2fc73db367994ab5e10f88525609054c3d4d2de1a70c2816bf80b2b42',2006,'MQ','Martinique','people-and-society',341,'$6.117 billion (2003 est.)
0.72% (2006 est.)
NA%
$14,400 (2003 est.)
overseas department of France','61a8ffd62e501ae586a84ed9e276a9936f8c2a65de595c12e05545b19c12f7ea','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88df9ce0690cd5aac8f762f475140a4a92d31e9af7d2fd690f187dd2f189b789',2006,'MR','Mauritania','people-and-society',342,'$6.901 billion (2005 est.)
2.88% (2006 est.)
5.5% (2005 est.)
$2,200 (2005 est.)','82f99a8fabe8a41e2504c15854d8fe5654a139aab1af4d0f2082e5549c1bd4f5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b07b9e35596aa9e9dc39f53b0464cca4691d2d37e747b8ab56cdd3b4edcc090',2006,'MU','Mauritius','people-and-society',343,'$15.73 billion (2005 est.)
0.82% (2006 est.)
2.5% (2005 est.)
$12,800 (2005 est.)','f382349b3e763f3c7c3eb8e0359aef4cb34ef399b08a800af3c10f0a1225ef90','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf3938b26a03505b787e9f9c0f68731593bebb909cf301e378b58955605f72eb',2006,'YT','Mayotte','people-and-society',344,'$466.8 million (2003 est.)
3.77% (2006 est.)
NA%
$2,600 (2003 est.)
departmental collectivity of France
Midway Islands
unincorporated territory of the US; formerly
administered from Washington, DC, by the US Navy; on 31 October
1996, through a presidential executive order, the jurisdiction and
control of the atoll was transferred to the Fish and Wildlife
Service of the US Department of the Interior as part of the National
Wildlife Refuge system','bf94221580d32186b928bb0b5ed8a32a9a5f3220d4c1ea9add1d8c349ac54340','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f66b965409732e1e2fb54e3572d28b5a5c20705d6e26c790edd257676ba7adbd',2006,'MX','Mexico','people-and-society',345,'$1.064 trillion (2005 est.)
1.16% (2006 est.)
3% (2005 est.)
$10,000 (2005 est.)','76c800dac41290abc29d12c3ee8560166fe9bb6777c11a326ec0db314337727b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6f2044756166e93c7a70c68bb0ff5f1f9ec7856b24aa1d32b7cc6184b0208c2',2006,'FM','Micronesia, Federated States of','people-and-society',346,'$277 million; note - supplemented by
grant aid, averaging perhaps $100 million annually (2002 est.)
Moldova
$8.41 billion (2005 est.)
-0.11% (2006 est.)
Moldova
0.28% (2006 est.)
0.3% (2005 est.)
Moldova
7.1% (2005 est.)
$2,300 (2005 est.)
Moldova
$1,900 (2005 est.)','70bb5647597278073aa2c58b77d1f477610724aefb45381b3476a82480561918','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc85e429361a33613209cc8dd271fbacf97ab00456051ab779cbce7c823ccad4',2006,'MC','Monaco','people-and-society',347,'$870 million
note: Monaco does not publish national income figures; the estimates
are extremely rough (2000 est.)
0.4% (2006 est.)
0.9% (2000 est.)
$27,000 (2000 est.)','983998c87c98e0cc6024f50b08da77b26c2b41aecf3b39fa3991afa8d381e4f1','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ebc42a55a2db72fd44447bf86631d80475334bed17aacbb00f4e415c51c0472',2006,'MN','Mongolia','people-and-society',348,'$5.272 billion (2005 est.)
1.46% (2006 est.)
6.2% according to official estimate (2005 est.)
$1,900 (2005 est.)','e76874cc9a616ff666a916fbaf6847104d79ea7c3394354da4e71b82ff61d6e3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ffa2a31a68d7de157cc7aded2f1c868e42c1b9bad1e4f4e26ed64b68e45cfeb',2006,'MS','Montserrat','people-and-society',349,'$29 million (2002 est.)
1.05% (2006 est.)
-1% (2002 est.)
$3,400 (2002 est.)
overseas territory of the UK
Navassa Island
unincorporated territory of the US; administered by
the Fish and Wildlife Service, US Department of the Interior, from
the Caribbean Islands National Wildlife Refuge in Boqueron, Puerto
Rico; in September 1996, the Coast Guard ceased operations and
maintenance of Navassa Island Light, a 46-meter-tall lighthouse on
the southern side of the island; there has also been a private claim
advanced against the island
Netherlands Antilles
an autonomous country within the Kingdom of the
Netherlands; full autonomy in internal affairs granted in 1954;
Dutch Government responsible for defense and foreign affairs','da77e9f3dbe013f9c84e9e683b9324f6be55e7818b574ef608a595417d28857f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c58cc3e1d6ef7d96d846094c014f7ca1b8359e4f9eb6a459b94ff492deab9ebb',2006,'MA','Morocco','people-and-society',350,'$135.1 billion (2005 est.)
1.55% (2006 est.)
1.7% (2005 est.)
$4,100 (2005 est.)','ed812c4c3f1f53f487553ddb074d1c3c10205e40f6688e66e247641ad5a56688','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88a5d47b8d99da9a01133b1859cf3990be5eaaa2b27bb69434ad0f2fde2a3d60',2006,'MZ','Mozambique','people-and-society',351,'$26.18 billion (2005 est.)
1.38% (2006 est.)
7.5% (2005 est.)
$1,300 (2005 est.)','af8d6d7037bd9ef8df6e6036dbe326d55f2a9957c49e04e0d1e32f33937e5a8c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3d2d4693acff0cf5868be881f11e24b995ddeeb8feeba2be9f88c0ab5a9b445',2006,'NA','Namibia','people-and-society',352,'$14.16 billion (2005 est.)
0.59% (2006 est.)
3.2% (2005 est.)
$7,000 (2005 est.)','70cbee8e9279d9229934fc3d2f4838be3162bcf986a19c3bda4a3c1ddc99acce','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5be6189c8539fe83ac74892854f48990beda4f55c7b1d6f9e282c972b04c1dbb',2006,'NP','Nepal','people-and-society',353,'$39.14 billion (2005 est.)
2.17% (2006 est.)
2.7% (2005 est.)
$1,400 (2005 est.)','184aa5a0412f8d5f7cf2309530469e7b99ee7bacd9352de8ae53924a1439a98c','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f7861cbd86d0f66fdd589c0843cf487694c7a9e9e77cfa8dd8fc91320b41d18',2006,'NL','Netherlands','people-and-society',354,'$497.9 billion (2005 est.)
Netherlands Antilles
$2.8 billion (2004 est.)
0.49% (2006 est.)
Netherlands Antilles
0.79% (2006 est.)
1.5% (2005 est.)
Netherlands Antilles
1% (2004 est.)
$30,300 (2005 est.)
Netherlands Antilles
$16,000 (2004 est.)','ae8ff501298954a4054331131f86aeae0d1b032e31b3f24acc981f3b45940660','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1dadc7748992f05b872db9a4d1bacfa050ec9872b77f577c0a43c36e6523e95',2006,'NC','New Caledonia','people-and-society',355,'$3.158 billion (2003 est.)
1.24% (2006 est.)
NA%
$15,000 (2003 est.)
territorial collectivity of France since 1998','f3c956b4e74781d529ff5af5180ab1f7719ba706cacc2eaf0f76bd6b364ae0de','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7183baf6d540be96cd7fc9d712726586436e7b76a09118e48c92ed7d959c2676',2006,'NG','Nigeria','people-and-society',356,'$175.5 billion (2005 est.)
2.38% (2006 est.)
6.9% (2005 est.)
$1,400 (2005 est.)','dde449e850266db6e24df328ece7bb2bcef943d264d3df6405d3144efcbd91fe','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d859c7bed49a97359b12977d98cc4bfc7304cd05929bff7d67f8c7b62adcd9f',2006,'NU','Niue','people-and-society',357,'$7.6 million (2000 est.)
0.01% (2006 est.)
6.2%
$5,800 (2003 est.)
self-governing in free association with New Zealand since 1974;
Niue fully responsible for internal affairs; New Zealand retains
responsibility for external affairs and defense; however, these
responsibilities confer no rights of control and are only exercised
at the request of the Government of Niue','76023f66fe5d85dafc677218393b937d746751042a078b8f31ab9f6b68fcf95a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9228855768cd819241a64edccb763d24e02783e375d105912521c10924ad84e',2006,'NF','Norfolk Island','people-and-society',358,'$NA
-0.01% (2006 est.)
territory of Australia; Canberra administers
Commonwealth responsibilities on Norfolk Island through the
Department of Environment, Sport, and Territories','88694aa708869ba86afaff86abf94e1de86e3e9bb413f747e65060c908d17e5b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02612dcc3d216b3b27a12d54e0ade6fba8b5349b89b8122edd95508996db39f0',2006,'MP','Northern Mariana Islands','people-and-society',359,'$900 million
note: GDP estimate includes US subsidy (2000 est.)
2.54% (2006 est.)
NA%
$12,500 (2000 est.)
commonwealth in political union with the
US; federal funds to the Commonwealth administered by the US
Department of the Interior, Office of Insular Affairs
Palmyra Atoll
incorporated territory of the US; privately owned, but
administered from Washington, DC, by the Fish and Wildlife Service
of the US Department of the Interior; the Office of Insular Affairs
of the US Department of the Interior continues to administer nine
excluded areas comprising certain tidal and submerged lands within
the 12 nm territorial sea or within the lagoon
Pitcairn Islands
overseas territory of the UK','5146c487341d4a10f459ceb9078f6ed8695eae32dc38559004d7accbd854ff3f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9600e17ddf2a0466b2a4ff7be5012a805b3874531b0c1738a81f7faf3236a0e4',2006,'OM','Oman','people-and-society',360,'$40.39 billion (2005 est.)
3.28% (2006 est.)
5.6% (2005 est.)
$13,500 (2005 est.)','29bf103d01c2758d5062159622167ac2dc27ffd4dc7fe83a87e3856fcfbdd01f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19d072f15613c98f034fa4f6fe427ca86a5c64865be85b0cf3e53ac1fb6dedc2',2006,'PK','Pakistan','people-and-society',361,'$395.2 billion (2005 est.)
2.09% (2006 est.)
6.6% (2005 est.)
$2,400 (2005 est.)','d724611f8a830f48c28641b418918b235d02705f601409c7857d3709bc3cced5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b66517181e04d328a04ab4433b7fe4b93325b0c115b12dd9d4e79e3b4087f85',2006,'PW','Palau','people-and-society',362,'$124.5 million; note - includes US subsidy (2004 est.)
1.31% (2006 est.)
5.5% (2005 est.)
$7,600 (2005 est.)','9e69c6ebdeb14003e6aa94cc0e502c6a68a472e70d8767a8c03c8c58982e5421','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a33e51cdfda5986da94884074124eaacd255f11077bd5c26b4aa5ca66987f23',2006,'PY','Paraguay','people-and-society',363,'$29.11 billion (2005 est.)
2.45% (2006 est.)
2.7% (2005 est.)
$4,600 (2005 est.)','913c14951181dca296b19abb64649b9f0aeefd3d471ef3012bb08b2694de9b2f','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27b3e3432f7a00ee7201b8a2d52e1ca00009e1df280be233152b8bd7f8ef6517',2006,'PE','Peru','people-and-society',364,'$167.3 billion (2005 est.)
1.32% (2006 est.)
6.4% (2005 est.)
$6,000 (2005 est.)','a63dba02c600bad0807ae4c08a096514a304594fa00a33708a56ab302b02db6e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('accac9f062e38d88f20cc6b68174565c4eb212627ae3c2794bdaf79a03a62077',2006,'PH','Philippines','people-and-society',365,'$412.5 billion (2005 est.)
Pitcairn Islands
$NA
1.8% (2006 est.)
Pitcairn Islands
-0.01% (2006 est.)
4.8% (2005 est.)
$4,700 (2005 est.)','bbfe5bd72f6cc3b358a53e4fa8aef788ec3addc7cbb86b647f5c089cbad16803','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a36a0352e554a2c37d3e12352efd2618a8733fd1e77ba4dad8cfccb875313406',2006,'PL','Poland','people-and-society',366,'$505.2 billion (2005 est.)
-0.05% (2006 est.)
3.4% (2005 est.)
$13,100 (2005 est.)','947a94385cc7ca20f77686508384a966346b170ae49cf3d155207cf970ba4a05','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3da19e9edf95515803b1558af11f738b027e71351f808c31e769a4605e31c768',2006,'PT','Portugal','people-and-society',367,'$200.6 billion (2005 est.)
0.36% (2006 est.)
0.4% (2005 est.)
$19,000 (2005 est.)','2a1f321277713377fd2b4e4243db65599d809a402940113b18b44986bfa80201','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd8cd789df98239e56b8a319150221fcbfdd15e680afa0129f07b04f25fd8494',2006,'PR','Puerto Rico','people-and-society',368,'$73.27 billion (2005 est.)
0.4% (2006 est.)
2.5% (2005 est.)
$18,700 (2005 est.)
unincorporated, organized territory of the US with
commonwealth status; policy relations between Puerto Rico and the US
conducted under the jurisdiction of the Office of the President
Reunion
overseas department of France
Saint Helena
overseas territory of the UK','f8e954182d9fa564c4cad38b7023142e64af649dc592a7e1769c8b46db3fc006','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b7785896b86f4c24e59748c6377943e08eed28332d1f2ccc635fe565c04d120',2006,'QA','Qatar','people-and-society',369,'$24.46 billion (2005 est.)
Reunion
$4.79 billion (2005 est.)
2.5% (2006 est.)
Reunion
1.34% (2006 est.)
8.8% (2005 est.)
Reunion
2.5% (2005 est.)
$28,300 (2005 est.)
Reunion
$6,200 (2005 est.)','5798115fe7a273aa4b449ac0312bb3a87de46d238ed21748cf68a41b26b94f05','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85ecd091fe8d67aaadbd98aec6826fcebf9857f14f62d6cf25c359f304b79508',2006,'RO','Romania','people-and-society',370,'$181.8 billion (2005 est.)
Russia
$1.584 trillion (2005 est.)
-0.12% (2006 est.)
Russia
-0.37% (2006 est.)
4.1% (2005 est.)
Russia
6.4% (2005 est.)
$8,100 (2005 est.)
Russia
$11,000 (2005 est.)','db4fd2ac5a6009361e0f777a402c9506a05a862f7c98930438f1a5add3de31f7','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb6742feb4efb1f0f748d235212b9dbd1fea41f23091741bdd879c4c570052d5',2006,'RW','Rwanda','people-and-society',371,'$12.54 billion (2005 est.)
Saint Helena
$18 million (1998 est.)
2.43% (2006 est.)
Saint Helena
0.56% (2006 est.)
5.2% (2005 est.)
Saint Helena
NA%
$1,500 (2005 est.)
Saint Helena
$2,500 (1998 est.)','8b6533388a8dfb81c94086d9a68fce0581e074db799fb2249f1922f980517caa','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf3cc7c3ca7b82ad9e25fa009faf262bec47717d34523cc6f61dd9df0fca5d1f',2006,'PM','Saint Pierre and Miquelon','people-and-society',372,'$48.3 million
note: supplemented by annual payments from France of about $60
million (2003 est.)
0.17% (2006 est.)
NA%
$7,000 (2001 est.)
self-governing territorial collectivity of','8c61cacc29dc6b02c4a508cf1faf1142c70be81f02ff69875c60f70d19c7925a','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10f62593f1c518bd007f26fef2014ac049a709e47f4b400a18dcefe93bc1ebd5',2006,'SA','Saudi Arabia','people-and-society',373,'$346.3 billion (2005 est.)
2.18% (2006 est.)
6.5% (2005 est.)
$13,100 (2005 est.)','37db68f8ec8727a5602c5dd810c372f3c3c3500ab8be8749a8c01749e1e307c9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('466a6d05daf5b5dc89384f3c5571c76bac7ec7f28724039a71456026271ccab8',2006,'SN','Senegal','people-and-society',374,'$20.57 billion (2005 est.)
2.34% (2006 est.)
6.1% (2005 est.)
$1,800 (2005 est.)','d9fc35724434d98a6163b2b74985b7f9f8f31270b8cf816df969c665657ee168','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05e38f1dc733adf95c04b42115d8cf7d7f38e00a63fda04c4d3d5877f325abec',2006,'RS','Serbia','people-and-society',375,'$41.15 billion for Serbia (including Kosovo) (2005 est.)
5.9% for Serbia alone (excluding Kosovo) (2005 est.)
$4,400 for Serbia (including Kosovo) (2005 est.)','9ce1db43c638de8c6735e588a64bfe0a061f222bc6ff3a28f13a18c3a717ae49','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ada277a62a5365c57fe65f8a4f55aa2bfa70160867feac7fd3f921938c55c285',2006,'SG','Singapore','people-and-society',376,'$126.5 billion (2005 est.)
1.42% (2006 est.)
6.4% (2005 est.)
$28,600 (2005 est.)','313150f2d631751ee75f491d64c90db9c6c83976ec5cf9e1d7300ff6c8305edd','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('887dcc6b4eac347c9f79a7521031e368673ec35f77b1a792e67729a71641896d',2006,'SI','Slovenia','people-and-society',377,'$43.27 billion (2005 est.)
-0.05% (2006 est.)
4% (2005 est.)
$21,500 (2005 est.)','7da992456526fc94337cb26b9707793b1687eaf4cba7af94f41545ef619b92e3','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c78db886af39b9bae38a2b650a5e2e6e25b060e731a2117fc2a7395c53f518ce',2006,'ZA','South Africa','people-and-society',378,'$540.8 billion (2005 est.)
-0.4% (2006 est.)
4.9% (2005 est.)
$12,200 (2005 est.)','a67ba6b5c198cecaeb7b9f5273e3f33933ad8763c9f96e13c5b5a2ab70691e00','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b0040307e03ac09b502edd45afbedb43a9da2629db1ce87cd8ffa1453db8f9d',2006,'ES','Spain','people-and-society',379,'$1.033 trillion (2005 est.)
0.13% (2006 est.)
3.5% (2005 est.)
$25,600 (2005 est.)','ce830fb0f148d925094fafb6629506ce41a56a96710913eea577cc0e1aed9ad5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59bcc45658e35a3138dc75abb042c4ce06007af18eb5410eb46cc5287d450429',2006,'SR','Suriname','people-and-society',380,'$2.893 billion (2005 est.)
Svalbard
$NA
Swaziland
$5.68 billion (2005 est.)
0.2% (2006 est.)
Svalbard
-0.02% (2006 est.)
Swaziland
-0.23% (2006 est.)
5% (2005 est.)
Svalbard
NA%
Swaziland
1.8% (2005 est.)
$6,600 (2005 est.)
Swaziland
$5,000 (2005 est.)','a14286bfefd613c02581bcf953a0405217acb42c184aaa72285914f9c6fa1936','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e95dc817a0ed951a1874e55032ddf37f901531f5129abb44c0b00993ca350e1',2006,'SE','Sweden','people-and-society',381,'$268.3 billion (2005 est.)
0.16% (2006 est.)
2.7% (2005 est.)
$29,800 (2005 est.)','3253587b415f9562608a93690044c425707f9da32e7531b864d838ccf9fd9714','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de38cd27dc8147ee2c8952bae1c308b27c52fff747d64d7127eaedf00ff8379e',2006,'CH','Switzerland','people-and-society',382,'$240.9 billion (2005 est.)
Syria
$71.42 billion (2005 est.)
Taiwan
$630 billion (2005 est.)
0.43% (2006 est.)
Syria
2.3% (2006 est.)
Taiwan
0.61% (2006 est.)
1.9% (2005 est.)
Syria
2.8% (2005 est.)
Taiwan
4% (2005 est.)
$32,200 (2005 est.)
Syria
$3,900 (2005 est.)
Taiwan
$27,500 (2005 est.)','45db4c0ab79404e70bc6fa257d120b0080b2411d2f0e3df8586546a28e4e8794','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a8354434a687a1f09a984c891a1505a4b41344ac41aabfafbbb09f06e3bbf76',2006,'TJ','Tajikistan','people-and-society',383,'$8.617 billion (2005 est.)
Tanzania
$27.11 billion (2005 est.)
2.19% (2006 est.)
Tanzania
1.83% (2006 est.)
6.7% (2005 est.)
Tanzania
6.8% (2005 est.)
$1,200 (2005 est.)
Tanzania
$700 (2005 est.)','ca682676531be99af05780dd8d4e94de160a5cfc6475ffdb60bcd894540bebac','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a1b6c2167da98aed0d551aa3a6d1796d3ee97431470a49b277a3d8316d8e895',2006,'TH','Thailand','people-and-society',384,'$550.2 billion (2005 est.)
0.68% (2006 est.)
4.5% (2005 est.)
$8,600 (2005 est.)','9aeb4d4493d70aad22172bafbdcab76b85ca996ec632f43e55d505bbd0fb76ee','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21c78c91e4e2d9c9d2c6ad115d3f4be5251b96d6e5385cd62bd57416707b2e4b',2006,'TK','Tokelau','people-and-society',385,'$1.5 million (1993 est.)
-0.01% (2006 est.)
NA%
$1,000 (1993 est.)
self-administering territory of New Zealand; note - Tokelau
and New Zealand have agreed to a draft constitution as Tokelau moves
toward free association with New Zealand; a UN sponsored referendum
on self-governance, in February 2006, did not produce the two thirds
majority vote necessary for changing the current political status
Tromelin Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands','f11149e644c6aa6f945b18cd1cd235c2adf581dfc03ac1de4a94034289411576','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1593cfc9bb664a5b7c9b885a28da117e4157b2ba5869f82292aeca15db1e8635',2006,'TO','Tonga','people-and-society',386,'$178.5 million (2004 est.)
2.01% (2006 est.)
2.4% (2005 est.)
$2,200 (2005 est.)','a5d45ce4b997ff4cfc636ccfb688b7fbf3183c5c04207fd74f205aeaeead6397','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab9bd944daaaa7401c19a6b7800c2997c8b40241c108d66e97cca7278973abab',2006,'TT','Trinidad and Tobago','people-and-society',387,'$18.11 billion (2005 est.)
-0.87% (2006 est.)
7% (2005 est.)
$16,800 (2005 est.)','ca5c94fe87fd48710ba57de3da18be0782288938a2262a49489b679df05854d5','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c394e36c06e55fef80f21032968b46b7d140e8c7be6b4d1ffc5e09d1515bdbde',2006,'TN','Tunisia','people-and-society',388,'$82.85 billion (2005 est.)
Turkey
$584.5 billion (2005 est.)
0.99% (2006 est.)
Turkey
1.06% (2006 est.)
4.2% (2005 est.)
Turkey
7.4% (2005 est.)
$8,200 (2005 est.)
Turkey
$8,400 (2005 est.)','64ea965f03d15fdee802ab0f894cf40fbb7b880df1a68e7866e17784d300e72b','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8a1f968f6ad708ad4fbca4fabf883a1934f09b3b0f9470986f105729aa9cfe4',2006,'TM','Turkmenistan','people-and-society',389,'$39.14 billion (2005 est.)
1.83% (2006 est.)
IMF estimate: 6%
note: official government statistics show 21.4% growth, but these
estimates are widely regarded as unreliable (2005 est.)
$7,900 (2005 est.)','5091e777bf0329b211c1a987be6656e439dafb6def91910e9e286a801c9cbd6d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0f76f6084ac4763eef31be9f35bb8b91fa6ff3903a0d941ae68c9fbb1b595f9',2006,'TC','Turks and Caicos Islands','people-and-society',390,'$216 million (2002 est.)
2.82% (2006 est.)
4.9% (2000 est.)
$11,500 (2002 est.)
overseas territory of the UK
United States Pacific Island Wildlife Refuges
unincorporated
territories of the US; administered from Washington, DC, by the Fish
and Wildlife Service of the US Department of the Interior as part of
the National Wildlife Refuge system
note on Palmyra Atoll: incorporated Territory of the US; partly
privately owned and partly federally owned; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior; the Office of Insular Affairs of the US
Department of the Interior continues to administer nine excluded
areas comprising certain tidal and submerged lands within the 12 nm
territorial sea or within the lagoon
Virgin Islands
organized, unincorporated territory of the US with
policy relations between the Virgin Islands and the US under the
jurisdiction of the Office of Insular Affairs, US Department of the
Interior
Wake Island
unincorporated territory of the US; administered from
Washington, DC, by the Department of the Interior; activities on the
island are conducted by the US Air Force','ca8ed804df1066c34222da433bb4e02ce14c6aca2340108bec663d92830978f8','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4465b79012b355171b5a99061fac864550f14e834018a25fa410f9f19f1d107',2006,'TV','Tuvalu','people-and-society',391,'$14.94 million (2002 est.)
1.51% (2006 est.)
1.2% (2002 est.)
$1,600 (2002 est.)','3e4ff00db9334fbc70788af5857170506729e64c23d1e5bb25816909b2f8baed','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e49feb1492e9e4b938898f3a47e654ec74760b67a4f4c88dfe789e06b2607c23',2006,'UA','Ukraine','people-and-society',392,'$329.1 billion (2005 est.)
-0.6% (2006 est.)
2.6% (2005 est.)
$7,000 (2005 est.)','5c36bd281c87308ac1af4c01ef815b5388e553a4cceef57f6ab36f67185541bf','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f0f141cc7b13d0009d44690b840cb66d899f9a46f025e0dbcf93251f937576e',2006,'AE','United Arab Emirates','people-and-society',393,'$115.8 billion (2005 est.)
1.52% (2006 est.)
8.8% (2005 est.)
$45,200 (2005 est.)','d16a3032ee82f2160201206fa4501622baa9d0bb4c34d2e0006a92eef521d692','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4285b5616b92854b9980c126a2857bb1188a2c99247bc84710b8fbddea560f7',2006,'GB','United Kingdom','people-and-society',394,'$1.818 trillion (2005 est.)
0.28% (2006 est.)
1.9% (2005 est.)
$30,100 (2005 est.)','18aa134662226c1f17e205ff7ab9d538106a80f3f0f58bdd3dd84e91de0b328d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23b21f96e790f24632bb0af5db4423216e4018a4891afc999bdd80d6def4a72b',2006,'US','United States','people-and-society',395,'$12.31 trillion (2005 est.)
0.91% (2006 est.)
3.2% (2005 est.)
$41,600 (2005 est.)','3ef32e6f7d0d963c661c3b89616afdb9bc1bf372116fee4a54c4aefabbb0f138','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6635abebd6b36055e5c824d1e14cd0a21b240c91128be6f6aedf2825048d5e5d',2006,'UY','Uruguay','people-and-society',396,'$33.98 billion (2005 est.)
0.46% (2006 est.)
6.8% (2005 est.)
$9,900 (2005 est.)','d599fe51fef1294637c4498b68299ac8355f5fa01b631b144ab05e3e429829b9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19d3e94e4e72fdd242c65691fe92b3aea54a114f10b41b57c385b64f8b6f38f2',2006,'VU','Vanuatu','people-and-society',397,'$276.3 million (2003 est.)
Venezuela
$162.1 billion (2005 est.)
Vietnam
$235.2 billion (2005 est.)
Virgin Islands
$1.577 billion (2004 est.)
1.49% (2006 est.)
Venezuela
1.38% (2006 est.)
Vietnam
1.02% (2006 est.)
Virgin Islands
-0.12% (2006 est.)
6.8% (2005 est.)
Venezuela
9.3% (2005 est.)
Vietnam
8.5% (2005 est.)
Virgin Islands
2% (2002 est.)
$2,900 (2003 est.)
Venezuela
$6,400 (2005 est.)
Vietnam
$2,800 (2005 est.)
Virgin Islands
$14,500 (2004 est.)','859f2cc43eff6dd8a97ba86fa026c07e0155366bc7849d4439f8be15e8675b1d','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5d13aa73cc6a85a199518ec65ffa2f4c11ea09abe09c3910ffdd26aaff963bd',2006,'WF','Wallis and Futuna','people-and-society',398,'$60 million (2004 est.)
West Bank
$1.8 billion (2003 est.)
NA
West Bank
3.06% (2006 est.)
NA%
West Bank
6.2% (2004 est.)
$3,800 (2004 est.)
West Bank
$1,100 (2003 est.)
overseas territory of France
This page was last updated on 19 December, 2006
======================================================================
@2007 Diplomatic representation from the US','9644afc2902c3078599ceccc23a9509e9628cd180a6f1269cb3fab8faabfbc2e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6cac1674d16a8b643fb4d614cda8dde32dbe38238f94dee48ecea31f1ddaca2',2006,'BV','Bouvet Island','people-and-society',399,'territory of Norway; administered by the Polar
Department of the Ministry of Justice and Police from Oslo','a602d22c9c2afea39d62ac445c6985ef01fa76486b333f2b4b13ad104c4d49dd','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecd733817bec4bbb127a90a9d297b59d93751e97d8a1492f02a1adeac8038f54',2006,'IO','British Indian Ocean Territory','people-and-society',400,'overseas territory of the UK;
administered by a commissioner, resident in the Foreign and
Commonwealth Office in London
British Virgin Islands
overseas territory of the UK; internal
self-governing
none (overseas territory of the UK)
British Virgin Islands
none (overseas territory of the UK)
Brunei
chief of mission: Ambassador Emil SKODON
embassy: Third Floor, Teck Guan Plaza, Jalan Sultan, Bandar Seri
Begawan, BS8811
mailing address: PSC 470 (BSB), FPO AP 96507; P.O. Box 2991, Bandar
Seri Begawan BS8675, Negara Brunei Darussalam
telephone: [673] 222-0384
FAX: [673] 222-5293','d730d639e836cc29deeef52a7242fde87b12c696074a6718e2fd9d98c8946010','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1294d5b67b1ed7cf9a3647a17e5ada9cbb8c4560e03d32ebe7dad64681039d63',2006,'HM','Heard Island and McDonald Islands','people-and-society',401,'territory of Australia;
administered from Canberra by the Australian Antarctic Division of
the Department of the Environment and Heritage
none (territory of Australia)
Holy See (Vatican City)
chief of mission: Ambassador Francis ROONEY
embassy: Villa Domiziana, Via delle Terme Deciane 26, 00153 Rome
mailing address: PSC 59, Box 66, APO AE 09624
telephone: [39] (06) 4674-3428
FAX: [39] (06) 575-8346','2362b7b24263254347c0bcd69c37ddbce37b60461e0ed98d80a8f4bc7b31842e','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('745d14f8d55fd74daafba91e9e28a9225d99dbd20be25264d27b0fd5d25c6359',2006,'GS','South Georgia and the South Sandwich Islands','people-and-society',402,'overseas territory of
the UK, also claimed by Argentina; administered from the Falkland
Islands by a commissioner, who is concurrently governor of the
Falkland Islands, representing Queen ELIZABETH II; Grytviken -
formerly a whaling station on South Georgia - is a scientific base
Svalbard
territory of Norway; administered by the Polar Department
of the Ministry of Justice, through a governor (sysselmann) residing
in Longyearbyen, Spitsbergen; by treaty (9 February 1920)
sovereignty was awarded to Norway','ad8c89205870ab553bc37190d4aaeb93154d7258cfd9567d8cfe19ba62751fb9','internet-archive','theciaworldfactb27509gut','txt','47947ad67828c8e1c7c85c37fbc3d09ec96dbc159648a573387515fa23e630fc','https://archive.org/download/theciaworldfactb27509gut/27509.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

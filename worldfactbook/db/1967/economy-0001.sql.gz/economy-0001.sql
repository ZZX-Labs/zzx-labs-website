SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e720bc20742a33c872c5e76425e2b2bcbe42477d8128b91020e85a515f31035',1967,'AF','Afghanistan','economy',7,'GNP: $2.8 billion (FY78 est.), $130 per capita;.real growth
rate about 3.7% (1970-78)
Agriculture: agriculture and animal husbandry account
for over 50% of GNP and occupy nearly 85% of the labor
force; main crops—wheat and other grains, cotton, fruits,
nuts; largely self-sufficient; food shortages—wheat, sugar,
tea
Major industries: cottage industries, food processing,
textiles, cement, coal mining
Electric power: 360,000 kW capacity (1977); 585 million
kWh produced (1977), 30 kWh per capita.
Exports: $340 million (f.o.b., FY78); fresh and dried
fruits, natural gas, karakul skins, carpets, hides, wool and
cotton
Imports: $410 million (f.o.b., FY78); non-metallic miner-
als, sugar, tires and tubes, textiles, tea, used clothing,
tobacco, transportation, and wheat
Major trade partners: exports—U.S.S.R., India, U.K.,
Pakistan, West Germany, Switzerland, U.S.; imports—Japan,
U.S:S.R., India, West Germany, U.K., U.S.
Budget: current expenditures $158 million, capital
expenditures $163 million for FY76
Monetary conversion rate: 45 Afghanis=US$1 (official,
early June 1978)
Fiscal year: 2] March-20 March','e3783af8f88da7d29c26372600cd65d44efe983e02170d28154d9a8d12378059','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdfd35195f755cfcaab1a3ad6a079d3ae972d041d693d54d49a06712ab8523da',1967,'BG','Bulgaria','economy',13,'GNP: est. $748 million in 1970 (at 1970 prices), $300 per
capita
Agriculture: food’ deficit area; main crops—corn, wheat,
tobacco, sugar beets, cotton; food shortages—wheat; caloric
intake, 2,100 calories per day per capita (1961/62)
Major industries: agricultural processing, textiles and
clothing, lumber, and extractive industries
Shortages: spare parts, machinery and equipment, wheat
Electric power: 500,000 kW capacity (1977); 1.8 billion
kWh produced (1977), 710 kWh per capita
Exports: $746 million (1971-75 est.); 1964 trade—55%
minerals, metals, fuels; 23% foodstuffs (including cigarettes);
17% agricultural materials (except foods); 5%. consumer
goods
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
i TE et, ie, Ete, Mi I, i eR i ii, Be Ne el, ME Se ii lll
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ALBANIA/ALGERIA
Imports: $1,238 million (1971-75 est.); 1964 trade—50%
machinery, equipment, and spare parts; 16% minerals,
metals, -fuels, construction materials; 16% foodstuffs; 7%
consumer goods; 7% fertilizers, other chemicals, rubber; 4%
agricultural materials (except foodstuffs)
Monetary conversion rate: 5 leks=US$1 (commercial);
12.5 leks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year 1 July-30 June
GNP: $20.9 billion, 1977 (at 1976 dollars), $2,360 per
capita; 1977 real growth rate, 0.4%
Agriculture: mainly self-sufficient; main crops—grain,
vegetables; caloric intake, 3,000 calories per day per capita
(1969/70)
Fishing: catch 160,000 metric tons (1976)
Major industries: agricultural processing, machinery,
textiles and- clothing, ‘mining, ore processing, timber
Shortages: some raw materials, metal products, meat and
dairy products; fodder ;
Crude steel: 2.6 million metric tons produced (1977), 290
kg per capita :
Electric power: 7,300,000 kW capacity (1977); 29.7
billion kWh produced (1977), 3,850 kWh per capita
Exports: $6,288 million (f.o.b., 1977); 46% machinery,
equipment, and transportation equipment; 15% fuels,
minerals, raw materials, metals, and other industrial
material; 2% agricultural raw materials; 29% foodstuffs, raw
materials for food industry, and animals; 10% industrial
consumer goods (1977)
- Imports: $6,198 million (f.0.b., 1977 est.); 89% machinery,
equipment, and transportation equipment; 45% fuels,
minerals, raw materials, metals, other materials; 7% agricul-
tural raw materials; 4% foodstuffs and animals; 5% industrial
consumer goods (1977)
Major trade partners: $12,486 million in 1977; 20% with
non-Communist countries, 56% with U.S.S.R., 24% with
other Communist countries
Monetary conversion rate: 0.948 leva=US$1 (1977)
Fiscal year: calendar year; economic data reported for
calendar years except for caloric intake, which is reported
for consumption year 1 July-30 June
NOTE: Foreign trade figures were converted at the 1977
rate of 0.911 leva=US$1
GDP: $3.7 billion (FY77, in current prices), $120 per
capita; real growth rate 6% (FY77); 2.5% over past decade
Agriculture: accounts for nearly 70% of total employment
and about 27% of GDP; main crops—paddy, sugarcane,
corn, peanuts; almost 100% self-sufficient; most rice grown
in deltaic land ;
Fishing: catch 501,560 metric tons (1976)
Major industries: agricultural processing; textiles and
footwear; wood and wood products; petroleum refining
Electric power: 450,000 kW capacity (1977); 890 million
kWh produced (1977), 30 kWh per capita
Exports: $208 million (f.0.b., 1977); rice, teak
Imports: $299 million (c.if., 1977); machinery and
transportation equipment, textiles, other manufactured
goods. SA Ms
Major trade partners: exports—Singapore, Western Eu-
rope, China, U.K., Japan; imports—Japan, Western Europe,
Singapore, U.K.
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Aa A Kh wa A ATA AT
Ae ee bh ee AR AA A om km Ae An Rene oe A A
oy eee, a Ow On
ee OD >
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BURMA/BURUNDI
Budget: (FY78) $2.765 billion revenues; $2.975 billion
expenditures; $210 million deficit; 30% military, 70%
civilian
Monetary conversion rate: 6.8608 kyat=US$] (market
rate July 1978)
Fiscal year: 1 April-31 March','c7b815bd624a71bd5b334e12c757d22dfb8cecce7a64919a5a1a35a5ff4a0114','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3702667e7974bd808f767c29a186b86c27155095205434356904eddcd79549f',1967,'DZ','Algeria','economy',17,'GDP: $19.6 billion (1977), $1,100 per capita; in real
terms, 8.8% growth in 1977
Agriculture: main crops—wheat, barley, grapes, citrus
fruits
Major industries: petroleum, light industries, natural gas,
mining, petrochemical, electrical, and automotive plants
under construction
Electric power: 1,700,000 kW capacity (1977); 4.5 billion
kWh produced (1977), 355 kWh per capita
Exports: $5.8 billion (f.0.b., 1977 est.); 90% hydrocarbons,
also wine, citrus fruit, iron ore, vegetables; U.S. took 56.2%
of Algerian crude oil, supplanting France as Algeria’s leading
trade partner
Imports: $6.9 billion (c.i.f., 1977); major items—capital
goods 35%, semi-finished goods 38%, foodstuffs 25%; from
France 23%, U.S. 9%
Monetary conversion rate: 1 DA=US$0.24
Fiscal year: calendar year
Economic activity in Gibraltar centers on commerce and
large British naval and air bases; nearly all trade in the
well-developed port is transit trade and port serves also as
important supply depot for fuel, water, and ships’ wares;
recently ‘built dockyards and machine shops provide
maintenance and repair services to 3,500-4,000 vessels that
call at Gibraltar each year.
U.K. military establishments and civil government employ
nearly half the insured labor force; local industry is confined
to manufacture of tobacco, roasted coffee, ice, mineral
waters, candy, beer, and canned fish; some factories for
manufacture of clothing are being developed; a small
segment of Jocal population makes its livelihood by fishing;
in recent years tourism has increased in importance.
Electric power: 40,000 kW capacity (1977); 80 million
kWh produced (1977), 2,760 kWh per capita
Exports: $23.87 million (1975-76), at exchange rate of 1]
pound =US$2.22; principally rexports of tobacco, petroleum,
and wine; 13% to U.K.
Imports: $60.0 million (1975-76), at exchange rate of 1
pound=US$2.22; 60% from U.K.
Major trade partners: U.K., Morocco, Portugal, Nether-
lands
Budget: (1975-76) revenue, $26.22 million; expenditure
$22.91 million, at exchange rate of 1 pound=US$2.22
Monetary conversion rate: 1 Gibraltar pound=
US$1.8062 (1976)','d6939b770e1a62d1fec821018f64feea3ec66baf338f30248244642e9405e78b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f8d39231720febcbc81fd23ad3fc8c4b7ad43dd637136ab8438ace55b23fcb8',1967,'AD','Andorra','economy',21,'Agriculture: sheep raising; small quantities of tobacco,
rye, wheat, barley, oats,-and some vegetables (less than 4% of
land is arable)
Major industries: tourism, sheep, timber, tobacco, and
smuggling
Shortages: food
Electric power: 25,000 kW capacity (1977); 100 million
kWh preduced (1977), 3,448 kWh per capita; power is
mainly exported to Spain and France
Major trade partners: Spain, France','48c9d3e8af7e1ad00c159e6da7e77a53bf79ca3b712cd85e68602bda71857751','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d06103fcb62db755efd33b3a2059c4e27677d3174ea1a10e2360b9c9031171f',1967,'AO','Angola','economy',25,'GDP: $2.8 billion (1977), $440 per capita, 6.1% real
growth (1970-72); real GDP growth has declined by at least
15% since independence
Agriculture: cash crops—coffee, sisal, corn, cotton, sugar,
manioc, and tobacco; food crops—cassava, corn, vegetables,
plantains, bananas, and other local foodstuffs; largely
self-sufficient in food
Fishing: catch 153,580 metric tons (1975); exports $53.0
million; imports $5.6 million (1973)
Major industries: mining (oil, diamonds), fish processing,
brewing, tobacco, sugar processing, textiles, cement, food
processing plants, building construction
Electric power: 525,000 kW capacity (1977); 1.3 billion
kWh produced (1977), 210 kWh per capita
Exports: est. $900 million (f.o.b., 1977); oil, coffee,
diamonds, sisal, fish and fish products, iron ore, timber, corn,
and cotton; exports down sharply 1975-77
Imports: est. $720 million (f.o.b., 1977); capital equip-
ment (machinery and electrical equipment), wines, bulk iron
and ironwork, steel and metals, vehicles and spare parts,
textiles and clothing, medicines; military deliveries partially
offset drop in imports in 1975-77
Major trade partners: Cuba; U.S.S.R., Portugal, Eastern
Europe, and USS.
Budget: (1975) balanced at about $740 million by former
Portuguese administration; budget not yet published by new
GDP: $52 million (1977 est.), $720 per capita; 2.0% real
growth
Agriculture: main crop, cotton
Major industries: oil refining, tourism
“Shortages: electric power
Electric power: 31,200 kW capacity (1977); 60 million
kWh produced (1977), 780 kWh per capita
Exports: $22 million (f.0.b., 1975); petroleum products,
cotton
Imports: $54 million (c.i.f., 1975); crude oil, food, clothing
Major trade partners: 30% U.K., 25% U.S., 18%
Commonwealth Caribbean countries (1975)
Aid: economic—bilateral commitments, including Ex-Im
(1970-76) from Western (non-U.S.) countries, $13.9 million;
no military aid
Budget: (current) revenues, $12 million; current expendi-
tures, $15 million (1977/78)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
Fiscal year: 1 April-30 March','71dc45c9414fd9186b37eeef92081f183757e3e55c09d5eedac62f4c2e6d9f3c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75943f16e15ac400f6f05223ef4e907bdc3cd561c5bd2c6330b1d5bac3f29011',1967,'AR','Argentina','economy',29,'GNP: $48 billion (1977), $1,840 per capita; 18%
government consumption, 62% private consumption, 22%
investment, —2% net foreign demand (1975); real GDP
growth rate 1977, 4.4%
Agriculture: main products—cereals, oilseeds, livestock
products; Argentina is a major world exporter of temperate
zone foodstuffs
Fishing: catch 281,727 metric tons (1976); exports $42
million (1976 est.)
Major industries: food processing (especially meatpack-
ing), motor vehicles, consumer durables, textiles, chemicals,
printing, and metallurgy
Crude steel: 2.7 million metric tons produced (1977), 90
kg per capita
Electric power: 9.16 million kW capacity (1977); 27
billion kWh produced (1977), 1,040 kWh per capita
Exports: $5.7 billion (f.0.b., 1977); meat, corn, wheat,
wool, hides, oilseeds
Imports: $4.2 billion (c.if., 1977); machinery, fuel and
lubricating oils, iron and steel, intermediate industrial
products
Major trade partners (1977): exports—10% Netherlands,
8% Brazil, 8% Italy, 7% U.S., 5% Japan; imports—19% U.S.,
10% FRG, 9% Japan, 9% Brazil
Aid: (FY70-76) economic—from U.S. $248 million; from
other Western countries $797 million; from Communist
countries $458 million; military—from U.S. $137 million
Budget: (1978) 8,000 billion pesos=$9.4 billion at
exchange rate of mid-September 1978
Monetary conversion rate: 850 pesos=US$1 (mid-
September 1978)
Fiscal year: calendar year
Government budget: Colony—revenues, $1.0 million
‘(FY68); expenditures, $1.1. million (FY68)
Agriculture: Colony—predominantly sheep farming; de-
pendencies—whaling and sealing
Major industries: Colony—wool processing; depend-
encies—whale and seal processing
Electric power: 1,250 kW capacity (1977); 2.5 million
kWh produced (1977), 1,150 kWh per capita
Exports: Colony—$2.28 million (1969); wool, hides and
skins, and other; dependencies—no exports in 1968 or 1969
Imports: Colony—$].22 million (1969); food, clothing,
fuels, and machinery; dependencies—$8,368 (1969); mineral
fuels and lubricants, food, and machinery
Major trade partners: nearly all exports to the U.K., also
some to the Netherlands and to Japan; imports from
Curacao, Japan, and the U.K.
Aid: economic—Western (non-U.S.) countries, $13 million
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
~
PLU A A AAR AAD AA ee ee
We. EN ae
i A 7
ae
Ae ee ee ay Re Ne Ce Oe eS Ce Eee eR ee ee ee ee es ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FALKLAND ISLANDS/FAROE ISLANDS
Monetary conversion rate: 1 Falkland Island
pound = US$2.60
GNP: $3.1 billion (1976), $1,110 per capita; 74% private
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A AAA ee A
ARAL AL AR AAA A AAA RA AR AAR A AA dO A A UO
ee Se ee eT ae ee
ra S
a te | A nd fe ie
GN TL FL I LI NINN I a NG Ne UL
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
URUGUAY/VATICAN CITY
consumption, 13% public consumption, 138% gross invest-
ment; real growth rate 1976, 1.5% e
Agriculture: large areas devoted to extensive livestock
grazing (17 million sheep, 11 million cattle); main crops— -
wheat, rice, corn; self-sufficient in most basic foodstuffs;
caloric intake, 3,000 calories per day per capita, with high
protein content
Major industries: meat processing, wool and_ hides,
textiles, footwear, cement, petroleum refining
Crude steel: rolled products 34,841 metric-tons produced,
castings 263 metric tons (1976)
Electric power: 700,000 kW capacity (1977); 3 billion
kWh produced (1977), 1,070 kWh per capita
Exports: $608 million (f.0.b., 1977); wool, hides
Imports: $730 million (c.i.f., 1977); fuels, metals, machin-
ery, transportation equipment
Major trade partners: exports—34% EC, 7% U.S., 29%
LAFTA; imports—29% LAFTA, 10% U.S., 20% EC (1975)
Aid: (FY70-76) economic—extensions from U.S. $60
million; from other Western countries $44 million; from
Communist countries $57 million; military—U.S. $39
million
Budget: (1977 est.) revenue, $623 million; expenditure,
$671 million ;
Monetary conversion rate: 5.46 pesos=US$! (January
1978)
Fiscal year: calendar year
‘The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter’s pence) from
Roman Catholics throughout the world; some income
derived from sale of Vatican postage stamps and tourist
mementos, fees for admission to Vatican museums, and sale
of publications; industrial activity consists solely of printing
and production of a small amount of .mosaics and _ staff
uniforms ©
The banking and financial activities of the Vatican are
worldwide; the Institute’ for Religious Agencies carries out
fiscal operations and invests and transfers funds of Roman
Catholic religious communities throughout the world; the
Cardinal’s Commission controls the administration of ordi-
nary assets of the Holy See and a Special Administration
manages the Holy See’s capital. assets ,
Electric power: obtained from Rome city grid; standby
diesel: powerplant with 2,100 kW capacity (1977)
GNP: $33 ‘billion (1977, in. 1977 dollars), $2,590 per
capita; 48% private consumption, 15% public consumption,
31% gross investment, 6% foreign sector (1976); Teal growth
rate 6.5% (1974-77)
Agriculture: main crops—sugarcane, corn, coffee, rice;
imports wheat (U.S.), corn (South Africa), sorghum (Argen-
tina, U.S.); caloric intake 2,600 calories per day per capita
(1972) .
Fishing: catch 145,727 metric tons (1976); exports $28.4
million (1976), imports $2.0 million (1976)
Major industries: petroleum, iron-ore mining, construc-
tion, food processing, textiles
'' Crude steel: 750,000 metric tons produced (1976), 60 kg
per capita
Electric power: 6,540,000 kW capacity (1978); 28 billion
kWh produced (1978), 2,200 kWh per -capita
Exports: $9.5 billion (f.o.b., 1977); petroleum $9.0 billion,
iron ore, coffee ,
Imports: $8.9 billion (f.o.b., 1977); industrial machinery
and equipment, chemicals, manufactures, wheat
Major trade partners: imports—39% U.S., 11% Japan,
12% West Germany; exports—36% U.S., 13% Canada
Aid: economic — assistance—extensions from + U.S.
(FY46-76), $128 million loans; $73 million grants; from
international organizations (FY46-75), $658 million; from
Communist countries (1954-76), $10 million; military—
assistance from U.S. (FY46-76), $153 million
Budget: 1978—revenues $10.7 billion; expenditures, $10.4
billion, capital $4.2 billion
Monetary conversion rate: 5.3207 bolivares=US$1 (sell-
ing rate), June 1978
Fiscal year: calendar year','def38cf53f763a8cfba4b37b0c919308bb46c052b065f8af0f6581d5ffe9340d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27315fe42397c9cd1a59e2f7aed1240c48295407db5209d3710127b2dc24ce2',1967,'AU','Australia','economy',33,'GNP: $95.2 billion (1977), $6,830 per capita; 60% private
consumption, 16% government current expenditure, 24%
investment (1975); 2% rea] average annual growth (1975-77)
Agriculture: large areas devoted to livestock grazing; 60%
of area used for crops is planted in wheat; major products—
wool, livestock, wheat, fruits, sugarcane; self-sufficient in
food; caloric intake, 3,300 calories per day per capita
Fishing: catch 113,961 metric tons (1976); exports $94.5
million (FY75), imports $86.2 million (FY75)
Major industries: mining, industrial and transportation
equipment, food processing, chemicals
Crude steel: 7.8 million metric‘tons produced (FY76), 570
kg per capita
Electric power: 22,457,000 kW capacity (1977); -84.1
billion kWh produced (1977), 6,070 kWh per capita
Exports: $13.4 billion (f.o.b., 1977); principal products
(1977)—44% agricultural products, 14% ‘metalliferous ores,
13% wool, 12% coal ; :
Imports: $13.6 billion (c.i.f., 1977); principal products
(1977)—41% manufactured raw materials, 28% capital
equipment, 25% consumer goods
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
AUSTRALIA/AUSTRIA
FEDERAL Son 2
. REPUBLIC
OF GERMANY
Major trade partners: (1977) exports—34% Japan, 9%
U.S., 5% New Zealand, 4% U.K.; imports—21% U.S., 11%
U.K., 21% Japan
Aid: economic—Australian aid abroad $2.3 billion
(FY65-75); $430 million (FY75), 55% for Papua New Guinea
Budget: expenditures, A$26.7 billion; receipts A$24.4
billion (FY78)
Monetary conversion rate: 0.87 Australian dollar=US$1
(A$1=US$1.15), September 1978
Fiscal year: ] July-30 June
GNP: $644 million (1975), $1,130 per capita; 5.8% real
growth rate (1971-75)
Agriculture: main crops—sugar, coconut products, ba-
nanas, ginger, rice; major deficiency, grains
Major industries: sugar processing, .tourism
Electric power: 90,000 kW capacity (1977); 270 million
kWh produced (1977), 450 kWh per capita
Exports: $187 million (f.o.b., 1977, including reexports);
70% sugar, 11% coconut oil, 9% gold
Imports: $279 million (f.o.b., 1977); 20% manufactured
goods, 19% food, 16% machinery, fuels, chemicals (1977)
Major trade partners: U.K., New Zealand, U.S., Canada,
Australia, Japan
Aid: disbursed 1968—Australia $1.5 million, U.S. $0.6
million, U.K. $4.2 million :
Budget: (FY75) revenues $107 million, expenditures $129
million
Monetary conversion rate: Fijian dollar=US$1.2119
(September 1978)
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
————SS
a,
EN Ne ee ee ee ee a eee ee ee ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FIJI/FINLAND
Fiscal year: calendar year
GDP: $740 per capita (1974)
Agriculture: copra, ‘subsistence crops of vegetables,
supplemented by domestic fishing
Industry: phosphate production, expected to:cease in 1978
Electric power: 16,000 kW capacity (1977); 45 million
kWh produced (1977), 820 kWh per capita
Exports: $8.6 million (1970 est.); 70% phosphate, copra
Imports: $3.1 million (1970 est.); foodstuffs, fuel
Budget: (est.) revenue 5.877 million NZ$, expenditure
4.577 million NZ$
Monetary conversion rate: 0.80 Australian$=US$1
March 1976
GNP: $43 billion (1977) about $310 per capita; real
average annual growth (1972-77), 7.7%
Agriculture: subsistence food production, and smallholder
and plantation production for export; main crops—rice,
rubber, copra, other tropical products; food shortage—rice,
wheat ;
Fishing: catch 1.6 million tons (1977); exports $150
million (1977), imports $8 million (1977)
Major industries: petroleum, agricultural processing,
textiles, mining
Electric power: 3,128,000 kW capacity (1977); 8.7 billion
kWh produced (1977), 65 kWh per capita
Exports: $10.9 billion (f.0.b., 1977); petroleum ($7.1
‘billion; 530 million bbls), timber, coffee, rubber, tin, palm
oil, tea, pepper, tobacco
Imports: $6.2 billion (c.i.f., 1977); rice, wheat, textiles,
chemicals, iron and -steel products, machinery, transport
equipment, consumer durables
Maior trade partners: exports (1977)—40% Japan, 28%
U.S., 9% Singapore; imports—30% Japan, 14% U.S., 8% West
Germany .
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
my
it
}
a
es a ee a ee” a
at oe os
we ae ee ee ee SS ee ee, a a a ee ee ee, ee ee ee eee
wr
x
a”
i is OE 2 tl i ll A cl. i a a eae i md | sa a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
INDONESIA/IRAN
Budget: (1978-79) expenditures, $11.6 billion; planned
receipts, $9.6 billion domestic, $2.0 billion foreign
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April-31 March ;
GNP: $75.9 billion (1977), $2,170 per capita; 1977 real
GNP growth, 2.8%
Agriculture: wheat, barley, rice, sugar beets, cotton, dates,
raisins, tea, tobacco, sheep, and goats
Major industries: crude oil production (2,080 million bbls
in 1977) and refining, textiles, cement and other building
materials, food processing (particularly sugar refining and
vegetable oil production), metal fabricating (steel and
copper)
Electric power: 6,300,000 kW capacity (1978); 20 billion
kWh produced (1978), 570 kWh per capita
Exports: $24.3 billion (f.0.b., 1977); 97% petroleum; also
carpets, raw cotton, fruits, and nuts, hide and leather items,
ores
Imports: $15.5 billion (f.0.b., 1977); machinery, iron and
steel products, chemicals, pharmaceuticals, electrical equip-
ment, agricultural products
Major trade partners: exports—Japan, U.S., West Ger-
many, Netherlands, Italy, U.K., Spain, France; imports—
U.S., West Germany, Japan, U.K., Italy
Budget: (FY78-79) $59.3 billion
Monetary conversion rate: 70.5 rials=US$1
Fiscal year: 21 March-20 March
GNP: $19 billion (1977 est.), $1,610 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry: crude petroleum (third largest producer
in Middle East); 2.3 million b/d (1977); petroleum revenues
for 1977, $10.3 billion
Electric power: 2,300,000 kW capacity (1978); 7 billion
kWh produced (1978), 560 kWh per capita
Exports: $11.8 billion (f.0.b., 1978 est.); net receipts from
oil, $11.5 billion; non-oil, $300 million est.
Imports: $6.4 billion (f.o.b. 1978 est.); 26% from
Communist countries (1973)
Major trade partners: exports—France, Italy, Brazil,
Japan, Turkey, U.K., U.S.S.R., other Communist countries;
imports— West Germany, Japan, France, U.S., U.K., U.S.S.R.
and other Communist countries (1977)
Budget: $15.8 billion (FY78), estimated
Monetary conversion rate: 1 Iraqi dinar=US$3.39 (end
of December 1977)
Fiscal year: 1 January-31 December
GNP: over $120 million (1975), $17,140 per capita (est.)
Agriculture: negligible; almost completely dependent on
imports for food, water
Major industries: mining of phosphates, about 2 million
tons per year :
Electric power: 9,000 kW capacity (1977); 26 million °
kWh produced (1977), 3,710 kWh per capita
Exports: $120 million (f.0.b., 1975 est.); consisting entirely
of phosphates
Imports: $5 million (c.i.f., FY70)
Major trade partners: exports—75% Australia and New
Zealand; imports—Australia, U.K., New Zealand, Japan
Monetary conversion rate: 1 Australian dol-
lar=US$1.2375 (July 1976)
Fiscal year: 1 July-30 June
GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing; major
products—coffee and vegetables; 60% self-sufficient in beef;
must import grains and vegetables
Industry: mining of nickel
Electric power: 320,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 12,310 kWh per capita
Exports: $289 million (f.o.b., 1975); 99% nickel
Imports: $348 million (c.if,, 1975); machinery, transport
equipment, food :
Major trade partners: (1972) exports—55% France, 24%
Japan, 11% U.S.; imports—52% France, 13% Australia, 12%
rest of EC
Monetary conversion rate: 86 CFP francs=US$1 (1972)
Agriculture: export crops of copra, cocoa, coffee, some
livestock and fish production; subsistence crops of copra,
taro, yams
Electric power: 4,000 kW capacity (1977); 13 million
kWh produced (1977), 180 kWh per capita
Exports: $27 million (1974); 24% copra, 59% frozen fish
Imports: $44 million (1974)
Monetary conversion rate: 1 pound=US$2.37 (official
currency), 0.74 Australian $=US$1, 86 Colonial Franc
Pacifique (CFP)=US$1 (1972)
GNP: $12.8 billion (1976), $4,060 per capita; real average
annual growth (1975-77), 1.4%
Agriculture: fodder and silage crops about one-half of
area planted in field crops; main products—wool, meat,
dairy products; New Zealand is food surplus country; caloric
intake, 3,500 calories per day per capita (1964)
Fishing: catch 70,449 metric tons (1976)
Major industries: food processing, textile production,
machinery, transport equipment; wood and paper products
Electric power: 5,380,000 kW capacity (1977); 22.1
billion kWh produced (1977), 7,060 kWh per capita
Exports: $3.2 billion (f.o.b., 1977); principal products
(trade year 1977)—24% meat, 14% dairy products, 20% wool
Imports: $3.4 billion (c.if., 1977); 29% machinery, 23%
manufactured goods, 11% chemicals (trade year 1977)
Major trade partners: (trade year 1977) exports—20%
U.K., 18% Japan, 12% Australia, 11% U.S.; imports—21%
Australia, 17% U.K., 15% Japan, 18% US.
Aid: gross official aid deliveries to LDC and multilateral
agencies FY75, $80.1 million
Budget: expenditures, 3,827 million NZ$, receipts, 3,330
million NZ$ (FY75)
Monetary conversion rate: NZ$1 =US$1.0571, September
1978 ,
Fiscal year: 1 April-31 March
NOTE: trade data are for year ending 30 June; trade year
and fiscal year do not correspond
GNP: $1.5 billion (FY77 est.); real average annual growth
rate (1969-74) 7% est.
Agriculture: main crops—coconuts, coffee, cocoa, tea
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Pe eS ea ee an Sa aes
Fue an ak nk eee
Ta mF
ae a a tN a kt mlm
en i ee eS
em A a tn
ee
Ate sd dos db oe bd oe 4 ot Oh wb oan ke
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
PAPUA NEW GUINEA/PARAGUAY
Major industries: sawmilling and timber processing,
copper mining (Bougainville)
Electric power: 284,000 kW capacity (1977); 700 million
kWh produced (1977), 250 kWh per capita
Exports: $636 million (f.0.b., FY77); principal Droducts—
copper, coconut products, coffee beans, cocoa, copra, timber
Imports: $484 million (f.0.b., FY77)
Major trade partners: Australia, U.K., Japan
Aid: economic—Australia, $1,158 million committed
(1976-81); World Bank group (1968-September 1969), $7.5
million committed; U.S. (FY70-74), $32.5 million extended
Budget: (75-76) receipts 400 million Australian dollars,
expenditures 408 million Australian dollars
Monetary conversion rate: Kina $1 =US$1.45 (September
1978)
Fiscal year: 1 July-30 June
See Gilbert Islands for economic data
GNP: $490 million (1976 est.), $290 per capita
Agriculture (all outside Aden): cotton is main cash crop;
cereals, dates, kat (qat), coffee, and livestock are raised and
there is a growing fishing industry; large amount of food
must be imported (particularly for Aden); cotton, hides,
skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150, 000
b/d) mid-1971; capacity 178,000 b/d at Little Aden operates
on imported crude; oil exploration activity
Electric power: 150,000 kW capacity (1977); 300 million
kWh produced (1977), 165 kWh per capita
Exports: $29 million (1977), excluding petroleum prod-
ucts. but including re-exports
Imports: $346 million (1977)
Major trade partners: Yemen, East Africa, but some
cement and sugar imported from Communist countries;
crude oil imported from Persian Gulf, exported mainly to
U.K. and Japan
Budget: (FY75-76)—revenues $40 million, expenditures
$102 million
Monetary conversion rate: 1 S. Yemeni dinar=US$2.90
Fiscal year: 1 April-31 March
GNP: $1,630 million (1976 est.), $300 per capita
Agriculture: sorghum and millet, qat (a mild narcotic),
cotton, coffee, fruits and vegetables; largely self-sufficient in
food
Major industries: cotton textiles and leather goods
produced on a small scale; handicraft and some fishing;
small aluminum products factory
Electric power: 50,000 kW capacity (1977); 100 million
kWh produced (1977), 20 kWh per capita
Exports: $19 million (f.o.b., 1976/77); qat, cotton, coffee,
hides, vegetables
Imports: $730 million (c.i.f., 1976/77); textiles and other
manufactured consumer goods, petroleum products, sugar,
grain, flour, other foodstuffs, and cement
Major trade partners: China, Yemen (Aden), U.S.S.R.,
Japan, U.K., Australia, Saudi Arabia
Budget: (FY75/76) $124 million revenue, $133 million
expenditures, $75 million development —
Monetary conversion rate: 1 Yemeni rial=US$0.22 as of
October. 1973
Fiscal year: 1 July-30 June
GNP: $48.0 billion (1977 est., at 1977 prices), $2,210 per
capita; real growth rate 5.7% (1971-77)
Agriculture: diversified agriculture with many small
private holdings and large agricultural combines; main
crops—corn, wheat, tobacco, sugar beets, and sunflowers;
occasionally a net exporter of foodstuffs and live animals;
imports tropical products, cotton, wool, and vegetable meal
feeds; caloric intake, 3,539 calories per day per capita (1975)
Major industries: metallurgy, machinery and equipment,
oil refining, chemicals, textiles, wood processing, food
processing
Shortages: electricity, fuels, steel
Crude steel: 3.2 million metric tons produced (1977), 150
kg per capita
‘Electric power: 10,800,000 kW capacity (1977); 48.6
billion kWh produced (1977), 2,230 kWh per capita
228
Exports: $5.25 billion (f.0.b., 1977); 32% machinery and
equipment; 23% intermediate goods; 45% other
Imports: $9.63 billion (c.i.f., 1977); 23% raw materials,
fuels; 35% machinery and equipment; 18% intermediate
goods; 24% other goods
Major trade partners: 67% non-Communist countries (6%
U.S., 44% other developed Western countries), 35% Commu-
nist countries
Aid: Yugoslav outstanding external debt (medium/long-
term) end 1976, $7 billion, of which $2.7 billion official,
largely non-Communist (U.S. $350 million, FRG $400
million, U.S.S.R. $200 million, IBRD $560 million end 1975);
Yugoslavia has extended aid totalling about $1.2 billion
(outstanding in 1976) to developing countries, largely since
the late 1960''s
Monetary conversion rate: (official) 18.25 new dinars=
US$1
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $3.59 billion (1976 prices), $140 per capita; 1.8%
real annual growth rate 1970-77
Agriculture: main cash crops—coffee, palm oil, rubber;
main food crops—manioc, bananas, root crops, corn; some
provinces self-sufficient
Fishing: catch 124,580 metric tons (1975); imports $38
million (1974)
Major industries: mining, mineral processing, light
industries
Electric power: 117,858 kW capacity (1976); 5.1 billion
kWh produced (1977), 190 kWh per capita
Exports: $1.2 billion (f.o.b., 1977 projected); copper,
cobalt, diamonds, other minerals, coffee
Imports: $1 billion (f.o.b., 1977 projected); consumer
goods, foodstuffs, mining and other machinery, transport
equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
Budget: 1977 proposed—revenue, 770 million; expendi-
tures, $976 million
Monetary conversion rate: ] zaire=US$0.831
Fiscal year: calendar year','2565dada40784b0c3642ba84ffe583702cdb8b7471015f0a0bb1ab52de2d3ba3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ff5ceca8ec867a835ce59bd0f2fb04161850458f2d190b6943b975475bf6b3',1967,'AT','Austria','economy',38,'GNP: $47.8 billion (1977), $6,360 per capita; 58.4%
private consumption, 16.2% public consumption, 27.0%
investment, 1.7% stock building; —3.3% net foreign balance;
1977 real GNP growth rate, 3.5%
Agriculture: livestock, cereals, potatoes, sugar beets; 84%
self-sufficient; caloric intake 3,230 calories per day per
capita (1969-70)
Major industries: foods, iron and steel, machinery,
textiles, chemicals, electrical, paper and pulp
Crude steel: 4.1 million metric tons produced (1977), 550
kg per capita (1977)
Electric power: 11,500,000 kW capacity (1977); 38.3
billion kWh produced (1977), 5,015 kWh per capita
Exports: $11.0 billion (1977); iron and steel products,
machinery and equipment, lumber, textiles, paper products,
chemicals
Imports: $15.4 billion (1977); machinery and equipment,
chemicals, textiles and clothing, petroleum, foodstuffs
Major trade partners: (1977) 35.9% West Germany, 8.9%
Italy, 6.4% Switzerland, 3.9% U.K., 3.1% U.S.; 76.8% OECD,
59.0 EC; 11.4% Communist countries
Aid: (1970-76) bilateral economic aid authorized (ODA
and OOF), $364 million
Budget: expenditures, $14.3 billion; revenues, $11.8
billion; deficit, $2.5 billion (1977 est.)
Monetary conversion rate: 16.53 shillings=US$1, 1977
average
Fiscal year: calendar year','19c0dd0d6ee6b85b445c9f355c333085c2c3c2e077a5f95ec6f0ef6beb115ea1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0123eda92b130bef57d6416df0eef0f984b800259dfb3abb20614e6ab8150ad',1967,'HT','Haiti','economy',41,'GNP: $758 million (at market prices, 1977), $3,510 per
capita; real growth rate 1977, 3.5%
Agriculture: food importer, main crops—fish, fruits,
vegetables
Major industries: tourism, cement, ‘oil refining, }umber,
salt production, rum, aragonite, pharmaceuticals, spiral
weld, and steel pipe
12
Electric power: 250,000 kW capacity (1977); 680 million
kWh produced (1977), 3,150 kWh per capita
Exports: $2.4 billion (f.0.b., 1977); fuel oil, pharmaceuti-
cals, cement, rum
Imports: $2.1 billion (c.i.f., 1977); crude oil, foodstuffs,
manufactured goods
Major trade partners: non-oil exports—U.S. 41%, U.K.
12%, Canada 3%; non-oil imports—U.S. 73%, U.K. 13%,
Canada 2% (1973)
Aid: economic—bilateral commitments including Ex-Im
(1970-76) from U.S. $34.3 million; from other Western
countries, $136.6 million; no military aid
Budget: (1978 projected), revenues, $186 million; expend-
itures, $199 million
Monetary conversion rate: 1 = Bahamian dollar
(B$1)=US$1
Fiscal year: calendar year
GNP: $1.1 billion (1977), $230 per capita; real growth rate
1977, 1.9%
Agriculture: main crops—coffee, sugarcane, rice, corn,
sorghum, pulses; caloric intake, 1,850 calories per day per
capita
Major industries: sugar refining, textiles, flour milling,
cement manufacturing, bauxite mining, tourism, light
assembly industries
Electric power: 90,000 kW capacity (1977); 175 million
kWh produced (1977), 40 kWh per capita
Exports: $143 million (f.0.b., 1977); coffee, light industrial
products, bauxite, sugar, essential oils, sisal
Imports: $245 million (f.0.b., 1977); consumer durables,
foodstuffs, industrial equipment, petroleum products, con-
struction materials
Major trade partners: exports—77% U.S.; imports—51%
U.S. (1977)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from U.S., $77.2 million; from other Western
countries, $51.7 million; military—U.S., $0.1 million
Budget: (1978/79 est.) revenue, $140 million; expendi-
ture, $257 million
Monetary conversion rate: 5 gourdes=US$1
Fiscal year: 1 October-80 September','a916be6b35462ae86da15f03fbcf11b607c1c32a1c4aba2d3f01436a594b0ec9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b87724a5f40e76fe84f5c814bf413f64404b57c1a5f522d6fed6b5c520ce7dd4',1967,'BH','Bahrain','economy',46,'GNP: $600 million (1976 est.), annual growth rate 4.1%
(1975-85 projected average), $2,430 per capita, dominated
by oil industry; 1977 average daily crude oil production,
56,000 bbls (oil expected to last 15° years if no new
discoveries are made); 1975 nonassociated natural gas
production, 102 billion ft?; government oil revenues for 1976
are estimated at $395.7 million -
Agriculture: produces dates, alfalfa, vegetables; dairy and
poultry farming; fishing; not self-sufficient in food
Major industries: petroleum refining, aluminum smelt-
ing, boatbuilding, shrimp fishing, pearls and sailmaking on a
smal] scale; major development projects include flourmill,
and ISA town; OAPEC dry dock to be built by 1977
. Electric power: 600,000 kW capacity (1977); 2.4 billion
kWh produced (1977), 8,450 kWh per capita
Exports: $1,840 million (f.o.b., 1977); non-oil exports
(including reexports), $396.8 million (1977); oil exports,
$1,443 million (1977)
Imports: $2,023 million (c.i.f., 1977)
Major trade partners: Saudi Arabia, U.K., U.S., Japan,
EC
Aid: received $110 million in bilateral commitments and
committed itself $8.5 million to multilateral agencies in
CY74
Budget: (1976) $489 million, 72% of revenues from oil
Monetary conversion rate: ] Bahrain dinar=US$2.52
(since January 1978)
Fiscal year: calendar year','71c8b7564db6299285c14a7fd26d70c4972df8794624341b93a669c8d6c99a91','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81c42f9eceae13ab63760da9f2bc3b710bc6f0dd5292c6fe88ebb61d83b9fbde',1967,'BD','Bangladesh','economy',50,'GNP: $7.2 billion est. (FY78, current prices), $90 per
capita; real growth, 8% (FY78)
Agriculture: large subsistence farming, heavily dependent
on monsoon rainfall; main crops are jute and rice;
shortages—grain, cotton, and oilseeds
Fishing: catch 821,000 metric tons (FY76)
Major industries: jute manufactures, food processing and
cotton textiles
Electric power: 915,000 kW capacity (1977); 1.6-billion
kWh produced (1977), 20 kWh per capita
Exports: $498 million (FY78); raw and manufactured jute,
leather, tea —
Imports: $1,274 million (FY78 est.); foodgrains, fuels, raw
cotton, fertilizer, manufactured products
Major trade partners: exports—U.S. 14%, U.K. 13%;
imports—Japan 22%, U.S. 10% (FY77)
Budget: (FY78 est.) domestic revenues, $823 million;
expenditures, $1,578 million
Monetary conversion rate: 14.787 taka=US$1 (July 1978)
Fiscal year: 1 July-30 June','abcfc4b8769f76c9e91a44143b7bbfc4577a35fbcdf75f95371ae263ae24dcee','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12459e2d4f8d4a292d09602bc8c6c1afa0fec5164d6f10d1f75f2ade2ee59962',1967,'BB','Barbados','economy',54,'GDP: $440 million (1977), $1,840 per capita; real growth
. rate 1977,. 3.0%
Agriculture: main products—sugarcane, subsistence foods
Major industries: tourism, sugar milling, light manu-
facturing
Electric power: 107,000 kW capacity (1977);.220 million
kWh produced (1977), 920 kWh per capita
Exports: $95 million (f.0.b., 1977); sugar and sugarcane
byproducts, clothing
Imports: $274 million (c.i.f., 1977); foodstuffs, machinery,
manufactured goods
Major trade partners: exports—34% U.S., 27% CARI-
COM, 10% U.K., 29% other; imports—25% U.S., 19% U.K.,
16% CARICOM, 7% Canada, 33% other’ (1977)
Aid: economic—bilateral commitments including Ex-Im
(1970-76) from U.S., $3.7 million; from other Western
countries, $41.4 million; no military aid:
Budget: (1978/79) revenues, $129 million; expenditures,
$191 million
Monetary conversion rate: 2 Barbados dollars=US$1
Fiscal year: 1 April-81 March','712d92a7afa5febb064807e437a9f59cae2575411dceb366c0c8475d74a0fb20','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7b850e3c6a77ddfbddae09326c606238e4b7c6c3a8acf48c835a631e9ba732e',1967,'BE','Belgium','economy',58,'GNP: $79 billion (1977), $8,040 per capita; 61.9%
consumption, 21.1% investment, 17.4% government, 0.3%
stock building, — 0.7% net foreign balance; 2.0%: real growth
rate in 1977
Agriculture: livestock production predominates; main
crops—grains, beets, potatoes; 80% self-sufficient in food;
caloric intake, 3,230 calories per day per capita (1969-70)
Fishing: catch 44,410 metric tons (1976); exports, $37
million (1975), imports $178 million (1975)
Major industries: engineering and metal products,
processed food and beverages, chemicals, basic metals,
textiles, and petroleum
Crude steel: 11.3 million metric tons produced; 1,150 kg
per capita (1977)
Electric power: 11,100,000 kW capacity (1977); 47.1
billion kWh produced (1977), 4,791 kWh per capita
‘Exports: (Belgium-Luxembourg Economic Union) $37.5
billion (f.o.b., 1977); iron and steel products, finished or
semifinished precious stones, textile products
Imports: (Belgium-Luxembourg Economie Union) $40.3
billion (c.i.f., 1977); nonelectrical machinery, motor vehicles,
textiles, chemicals, fuels
Major trade partners: (Belgium-Luxembourg Economic
Union, 1977) 69.3% EC (22.3% West Germany, 17.5%
France, 16.8% Netherlands, 7.3% U.K., 4.2% Italy), 5.1%
US.
Aid: (1970-76) bilateral economic aid authorized (ODA
and OOF), $1,580 million
Budget: (1977) revenues, $21.9 billion; expenditures,
$24.0 billion; deficit, $2.1 billion
Monetary conversion rate: (1977 average) Belgian Franc
35.841 =US$1
Fiscal year: calendar year','48a420a0b58be0acb06b0d76bbc20237813774bd272f07419f916c3ef1ec898d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0f3ffee6452ab5175dc8249c7cb8873dde26850f0945049371d83eb5eaa03dd',1967,'HN','Honduras','economy',63,'GDP: $96 million (1975), $700 per capita; 78% private
consumption, 17% public consumption, 36% domestic
investment, —31% net foreign balance (1968)
Agriculture: main products—sugarcane, citrus fruits,
corn, molasses, rice, beans, bananas, livestock products; net
importer of food; caloric intake, 2,500 calories per day per
capita
Major industries: timber and forest products, food
processing, furniture, rum, soap
Electric: power: 16,000 kW capacity (1977); 32 million
kWh produced (1977), 230 kWh per capita
18
Exports: $73 million (f.0.b., 1975); sugar, molasses,
clothing, lumber, citrus fruits, fish
Imports: $86 million (c.if., 1975); vehicles, building
materials, petroleum, food, textiles, machinery
Major trade partners: exports—U.S. 30%, U.K. 24%,
Mexico 22%, Canada 13%; imports—U.S. 34%, U.K. 25%,
Jamaica 7% (1970)
Aid: economic—bilateral commitments, including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $56.5 million;
from U.S., $2.5 million; no military aid
Monetary conversion rate: 2 Belize dollars=US$1
Fiscal year: calendar year
GDP: $1,421 million (1977), $490 per capita; 79% private
consumption, 10% government consumption, 22% domestic
investment; —11% net foreign balance (1975); real growth
rate, average 1971-75, 2.6%; real growth rate 1977, 8:3%
Agriculture: main crops—bananas, coffee, corn, beans,
cotton, sugarcane, tobacco; caloric intake, 2,200 calories per
day per capita (1970)
Fishing: catch 3,262 metric tons (1976); exports est. $0.8
million (1976); imports $0.8 million (1974)
Major industries: agricultural processing, textiles, cloth-
ing, wood products
Electric power: 172,500 kW capacity (1977); 450 million
kWh produced (1977), 155 kWh per capita
Exports: $520 million (f.o.b., 1977); bananas, coffee,
lumber, meat, petroleum products
Imports: $545 million (f.o.b. 1977); manufactured prod-
ucts, machinery, transportation equipment, chemicals,
petroleum
Major trade partners: exports—51% U.S., 12% CACM,
11% West germany; imports—42% U.S., 16% Venezuela, -
13% CACM, 7% Japan, 3% West Germany (1975)
Aid: economic—extensions from U.S. (FY46-76), $122
million loans, $96 million grants; from international
organizations (FY46-73), $291 million; from other Western
countries (1960-73), $7.0 million; military—assistance from
U.S. (FY46-75), $20 million
Budget (1978): expenditures, $416 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year','e03a1223c6168af1dbce03f6ab456adadc0a3715b1f4d6e90b04c866e2b94f6c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83fbec703eb6e308abe037991a0bd6a78840f0f105e351f5922ee1d356061885',1967,'BJ','Benin','economy',67,'GNP: $660 million (1977 est.), $200 per capita; 1.5% real
growth during 1970-1977
Agriculture: major cash crop is oil palms; peanuts, cotton,.
coffee, sheanuts, and tobacco also produced commercially;
main food crops—corn, cassava, yams, rice, sorghum and
millet; livestock, fish
Fishing: catch 25,504 metric tons (1976); exports 600
metric tons, imports 8,875 metric tons (1975)
Major industries: palm oi] and palm kernel oil processing
Electric power: 11,000 kW capacity (1977); 55 million
kWh produced (1977), 20 kWh per capita
Exports: $106 million (f.0.b., 1977); palm products (34%);
other agricultural products
Imports: $264 million (c.i.f., 1977); clothing and other
consumer goods, cement, lumber, fuels, foodstuffs, machin-
ery, and transport equipment
Major trade partners: France, EC, franc zone; preferen-
tial tariffs to EC and franc zone countries
Budget: 1977 est.—receipts $110 million, expenditures
$109 million :
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine (CFA) francs=US$1 (1977)
Fiscal year: calendar year','d6b2fe1ccc724f84fcffeff63777e52dd9f386c1b22c56ef79c528ad33966c50','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5ed648f40d0d1bb7489d589c4fe8e45981365292bce6db0c6231654b2f1c5d9',1967,'BM','Bermuda','economy',71,'GNP: $430 million (1976 est.), $7,540 per capita; real
growth rate 1976, est. 2.0%
Agriculture: main products—bananas, vegetables, Easter
lilies, dairy products, citrus fruits
Major industries: tourism, finance
Electric power: 86,200 kW capacity (1977); 300 million
kWh produced (1977), 5,170 kWh per capita
Exports: $47 million (f.o.b., 1976); mostly reexports of
drugs and bunker fuel
Imports: $165 million (f.0.b., 1976); fuel, foodstuffs,
machinery
Major trade partners: 45% U.S., 22% U.K., 9% Canada
(1976)
Aid: economic—bilateral commitments, including Ex-Im
(1970-76), from U.S. $34 million; from other Western
countries $109 million; no military aid
Budget: revenues, $87 million; expenditures $89 million;
expenditures $89 million (proposed 1978/79)
Monetary conversion rate: 1 Bermuda dollar=US$1
Fiscal year: 1 April-3] March
GNP: $90 million (1976); $70 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 3,000 kW capacity (1977); 8 million kWh
produced (1977), 6 kWh per capita
Exports: about $1 million annually; rice, dolomite, and
handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic—India (FY61]-72), $180 million
Monetary conversion rate: both ngultrums and Indian
rupees are legal tender; 8.77 ngultrums=8.77 Indian
rupees=US$1 as of October 1975
Fiscal year: 1 April-31 March','f3609337b5bd81c042a8f34736375316037d4de63e66ba77b1bd9109353589e1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d14f3e7295dddb79ec680b6df2a1cd8ff271b7379edff342dc481231c7032bf',1967,'BR','Brazil','economy',74,'GNP: $3.5 billion (1977, in 1977 dollars), $730 per capita;
69% private consumption, 17% public consumption, 20%
_ gross domestic investment, —6% net foreign balance (1976);
real growth rate (1972-76), average 6.4%; 1976 growth, 6.0%
Agriculture: main crops—potatoes, corn, rice, sugarcane,
yucca, bananas; imports significant quantities of wheat;
caloric intake, 70% of requirements (1976)
Major industries: mining, smelting, petroleum refining,
food processing, textiles, and clothing
Electric power: 367,000 kW capacity (1977); 1.1 billion
kWh produced (1977), 230 kWh per capita
Exports: $640 million (f.o.b., 1977 est.); tin, petroleum,
lead, zinc, silver, tungsten, antimony, bismuth, gold, coffee,
sugar, cotton, natural gas
Imports: $670 million (c.i.f., 1977); foodstuffs, chemicals,
capital goods, pharmaceuticals, transportation
Major trade partners: exports—Western Europe, 19% (of
which UK is largest market); Latin America, 38%; U.S., 30%;
Japan, 3.9%; imports—U.S., 24%; Western Europe, 15.4% (of
which West Germany is largest supplier); Japan, 15.7%;
Latin America, 33.6% (1975)
Aid: economic—extensions from U.S. (FY46-76), $335
million in loans, $342 million in grants; from international
organizations (FY46-75), $372 million; from other Western
countries (1960-75), $53.8 million; Communist countries
(1970-74), $59.7 million; military—assistance from U.S.
(FY52-76), $70 million
Budget: $474 million revenues, $583 million expenditures
(1978)
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
rm a ae oe A ALAR ee Ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BOLIVIA/BOTSWANA
Monetary conversion rate: 20 pesos=US$1
Fiscal year: calendar year
GNP: $163 billion (est. 1977 in 1977 prices), $1,450 per
capita; 25% gross investment, 80% consumption, —5% net
foreign balance (1976); real growth rate 4.78% (1977)
Agriculture: main products—coffee, rice, beef, corn,
milk, sugarcane, soybeans; nearly self-sufficient; caloric
intake, 2,900 calories per day per capita (1962)
Fishing: catch 950,000 metric tons (1976 est.); exports,
$53.8 million (f.o.b., 1976); imports, $60.8 million (f.o.b.,
1976) :
Major industries: textiles and other consumer goods,
chemicals, cement, lumber, steel, motor vehicles, other
metalworking industries .
Crude steel: 12.0 million metric tons capacity (1977 est.);
11.2 million metric tons produced (1977); 100 kg per capita
Electric power: 24,500,000 kW capacity (1977); 85 billion
kWh produced (1977), 760 kWh per capita
Exports: $12,141 million (f.0.b., 1977); coffee, manufac-
tures, iron ore, cotton, soybeans, sugar, wood, cocoa, beef,
shoes
Imports: $13,257 million (c.i.f., 1977); machinery, chemi-
cals, pharmaceuticals, petroleum, wheat, copper, aluminum
Major trade partners: exports—17.7% U.S., 8.8% West
Germany, 7.7% Netherlands, 5.6% Japan, 5.6% Italy, 4%
Spain; imports (non-oil)—20% U.S., 8.6% West Germany, 7%
Japan, 2.5% Italy, (1977)
Aid: economic—bilateral, including Ex-Im (FY70-76),
from U.S., $1,670.6 million; from other Western countries,
$3,069.4 million; from Communist countries, $303.5 million;
military—from U.S. (FY70-76), $214.1 million
Budget: (1977) revenues $17.2 billion, expenditures $17.1
billion
Monetary conversion rate: 18.69 cruzeiros=US$1 (Au-
gust 1978, changes frequently)
Fiscal year: calendar year
GNP: $460 million (1975 est.), $2,970 per capita
Agriculture: main crops—rubber, rice, pepper, must
import most food
Major industry: crude petroleum, liquefied natural gas
Electric power: 84,000 kW capacity (1977); 230 million
kWh produced (1977), 1,300 kWh per capita
26
Exports: $1,000 million (f.0.b., 1975); 95% crude petro-
leum and liquefied natural. gas
Imports: $200 million (c.i.f., 1975); 25% machinery and
transport equipment, 46% manufactured goods, 16% food
Major trade partners: exports of crude petroleum and
liquefied natural gas to Japan; imports from Japan 30%, U.S.
24%, U.K. 15%, Singapore 9%
Budget: (1976) revenues $640 million, expenditures $250
million, surplus $390 million; 20% defense
Monetary conversion rate: 2.5 Brunei dollars=US$1
Fiscal year: calendar year
GNP: $529 million (1977 est.); $1,240 per capita; real
growth rate 1977, 0.0%
Agriculture: main crops—rice, sugarcane, bananas; self-
sufficient in major staple (rice)
Communists:
Major industries: bauxite mining, alumina and aluminum
production, lumbering, food. processing
Electric power: 189,000 kW capacity (1977); 1 billion
kWh produced (1977), 2,850 kWh per capita
Exports: $303 million (f.0.b., 1976); bauxite, alumina,
aluminum, wood and wood products, rice
Imports: $282 million (c.i.f., 1976); capital equipment,
petroleum, iron and steel, cotton, flour, meat, dairy products
Major trade partners: exports—35% U.S., 34% EC, 18%
other European countries; imports—34% U.S., 838% EC, 13%
Caribbean ‘countries, 18% Europe (1975)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from U.S., $1.9 million, from other Western
countries, $423.9 million; no military aid
Budget: revenue, $352 million; expenditure, $367 million
(1978 est.)
Monetary conversion rate:
fl.)=US$0.560 (average 1977)
Fiscal year: calendar year','bafb0e50a04f105020cdd609fe7fbaf444585035a403adfdecf2e75090ae6d5a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41f3aea40eadc1090c2e2226dfbd874a3116bb9a29aa232d1173ffb88b0b9287',1967,'BW','Botswana','economy',79,'GDP: ‘$300 million (1975 est.), growth in constant prices,
less than 5% in 1977
Agriculture: principal crops are corn and sorghum;
livestock raised and exported
Major industries: livestock processing, mining of dia-
monds, coppér, nickel, and coal
Electric power: 75,000 kW capacity (1977); 85 million
kWh produced (1977), 120 kWh per capita
Exports: $176 million (1976); cattle, animal products,
minerals
Imports: $209 million (1976); foodstuffs, vehicles, textiles,
petroleum products
Major trade partners: South Africa and U.K.
Budget: (1977) revenue $107 million ($78 million from
domestic taxes and $29 million from borrowing and foreign
aid), current expenditures $70 million, investment expendi-
tures $44 million :
Monetary conversion rate: 1 pula=about US$1.20 as of
October 1977
Fiscal year: 1 April-31 March
GDP: $3.5 billion (1977), $520 per capita; economy
contracting since 1974 with estimated drop of 6% in 1978
Agriculture: main crops—tobacco, corn, sugar, cotton;
livestock; self-sufficient in foodstuffs
Major industries: mining, steel, textiles, chemicals, and
vehicles
Electric power: 1,453,000 kW capacity (1977); 7.5 billion
kWh produced (1977), 1,110 kWh per capita
Exports: $652 million (f.o.b., 1973), including net gold
sales and reexports; tobacco, asbestos, copper, meat, chrome,
gold, nickel, clothing, sugar
Imports: $541 million (c.i.f., 1973); machinery, petroleum
products, wheat, transport equipment
Net merchandise earnings: $264 million (1976)
Major trade partner: South Africa
Aid: economic—(1970-76) Western (non-U.S.) countries,
$19.1 million
Budget: FY77— revenues $797 million, expenditures $887
million, deficit $40 million
Monetary conversion rate: 1 Rhodesian dollar=US$1.50
Fiscal year: 1 July-30 June','bce054e88727096721a6cbe171edc747efcc11604a4a00bcfc2e69c92e4aca30','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0834fdee1288125f66d9681a9e79e51132aeddc6ceb8beecae367b2a8bff1f80',1967,'BI','Burundi','economy',84,'GNP: about $450 million (1976), $120 per capita; 2% real
growth (1970-74); real GDP growth ‘in 1976, 7.8%
Agriculture: major cash crops—coffee, cotton, tea; main
food crops—manioc, yams, corn, sorghums, bananas, haricot
beans; marginally self-sufficient
Industries: light consumer goods such as beverages,
blankets, shoes, soap, assembly of imports
Electric power: 7,500 kW capacity (diesel generator
1977); 25 million kWh produced (1977); 6 kWh per capita
Exports: $94.6 million (f.0.b., 1977); coffee (90%), tea,
cotton, hides, skins
Imports: $74.2 million (c.i.f., 1977); textiles, foodstuffs,
transport equipment, petroleum products
Major trade partners: U.S., EEC countries
Budget: FY77—revenue $47 million, current expenditure
$48 million
Monetary conversion rate: 90 Burundi francs=US$1
(official)
Fiscal year: calendar year','394c457ec30018ee6ce3aea4c61a947a489d6c235b0977a8ac6110c35ecee8eb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5074dbf4b1163222c55ef76fa95a497b3f8790369e72efa66d0f8205cfe9a05a',1967,'GA','Gabon','economy',89,'GDP: $2,500 million (mid 1977), per capita about $380;
real growth rate, 3.2% (1970-77)
Agriculture: commercial and food crops—cocoa, coffee,
timber, cotton, rubber, bananas, peanuts, palm oil and palm
kernels; root starches, livestock, millet, sorghum, and rice
Fishing: imports 7,024 metric tons, $2.2 million; exports
909 metric tons (largely shrimp), $3.5 million (1975)
Major industries: small aluminum plant, food processing
and light consumer goods industries, sawmills
Electric power: 358,000 kW capacity (1977); 1,347
million kWh produced (1977), 200 kWh per capita
Exports: $615 million (£.0.b., FY77); cocoa and coffee
about 60%; other exports include timber, aluminum, cotton,
natural rubber, bananas, peanuts, tobacco, and tea
Imports: $658 million (f.0.b., FY77); consumer goods,
machinery, transport equipment, alumina for refining,
petroleum products, food and beverages
Major trade partners: about 70% of total trade with
France and other EC countries; about 5% of total trade with
US.
Budget: FY78 budget est. balanced at $560 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 as of November 1977
Fiscal year: 1 July-30 June
GDP: $2,802 million (1977 est.), $4,990 per capita; 10%
growth (1970-77)
Agriculture: commercial—cocoa, coffee, wood, palm oil,
rice; main food crops—bananas, manioc, peanuts, root crops;
imports food
Fishing: catch 6,056 metric tons (1975)
Major industries: petroleum production, sawmills, petro-
leum refinery, natural gas, agricultural processing; mining of
increasing importance; major minerals—manganese, uran-
ium, gold, and iron
Electric power: 125,400 kW capacity (1977); 376 million
kWh produced (1977), 670 kWh per capita -
Exports: $1.0 billion (f.0.b., 1977); crude petroleum, wood |
and wood products, minerals (manganese, uranium concen-
trates, gold), coffee
Imports: $831 million (c.i.f. est., 1977); excluding UDEAC
trade; mining, roadbuilding machinery, electrical equip-
ment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and
Curacao; preferential tariffs to EC and franc zone
Aid: Western (non-U.S.) countries (1970-76), $387.6
million, Communist countries (1975), $25.0 million; U.S.
(1970-76), $22.1 million; military—U.S. (1970-76), $2.0
million
Budget: 1978 est.—receipts $1.0 billion, current expend-
itures $500 million, investment expenditures $350 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year
GNP: $115 million (FY76-77 est.), about $210 per capita
Agriculture: main crops—peanuts, rice, palm kernels
Fishing: catch 10,795 metric tons (1975); exports $956,000
(1974)
Major industry: peanut processing
Electric power: 10,000 kW capacity (1977); 30 million
kWh produced (1977), 50 kWh per capita
Exports: $48 million (f.o.b. 1977); peanuts. and peanut
products 90% to 95%, palm kernels
Imports: $66 million (f.o.b. 1977); textiles, foodstuffs,
tobacco, machinery, petroleum products
Major trade partners: exports—U.K. and France; ‘im- -
ports—U.K. and Japan :
Aid: économic—Western (non-U.S.) countries (1970-76),
$36.1 million; Communist countries (1970-76), $16.2 million;
OPEC (ODA) (1973-76), $15.9 million; U.S. (1970-76), $8.3
million :
72
Budget: (FY77 est.) current expenditures $25 million,
receipts $30 million; development expenditures $14 million,
development receipts $7.2 million
Monetary conversion rate: 1 Dalasi=US$0.49 (September
1978)
Fiscal year: 1 July-30 June
GNP: $69.2 billion in 1977 (1976 prices), $4,120 per
capita; 1977 growth rate 4.0%
Agriculture: food deficit area; main crops—potatoes, rye,
wheat, barley, oats, industrial crops; shortages in grain,
vegetables, vegetable oil, beef; caloric intake, 3,000 calories
per day per capita (71) :
Fish catch: 210,000 metric tons (1977) _
Major industries: metal fabrication, chemicals, light
industry; brown coal, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
Crude steel: 7.00 million metric tons produced (1977,
preliminary estimate), approx. 420 kg per capita
Electric power: 17,882,000 kW capacity (1977); 92 billion
kWh produced (1977), 5,500 kWh per capita
Exports: $12.7 billion, est. (f.0.b., 1977)
Imports: $14.3 billion, est. (f.0.b., 1977)
Major trade partners: $25,200 million (1976); 65%
Communist countries, 35% non-Communist countries
Monetary conversion rate: 3.48 DME=US$1 for trade
data (1976 rate)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for the consumption year 1 July-30 June
GNP: $517.1 billion (1977), $8,400 per capita (1977); 56%
consumption, 23% investment, 18% government .consump-
tion; net foreign balance 3% (distribution based’ on constant
‘price series)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Nn KA A AN A AA RA AM AR AA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GERMANY, FEDERAL REPUBLIC OF/GHANA
Agriculture: main crops—grains, potatoes, sugar beets;
75% self-sufficient; food shortages—fats and oils, pulses,
tropical products; caloric intake, 2,980 calories per day per
capita (1975-76)
Fishing: catch 394,452 metric tons, $155 million (1977):
exports $130 million, imports $352 million (1977)
Major industries: among world’s largest producers of
iron, steel, coal, cement, chemicals, machinery, ships,
vehicles
Shortages: fats and oils, sugar, cotton, wool, rubber,
petroleum, iron ore, bauxite, nonferrous metals, sulfur
Crude steel: 60 million metric tons capacity; 38.9 million
metric tons produced (1977); 630 kg per capita
Electric power: 78,000,000 kW capacity (1977); 335
billion kWh produced: (1977), 5,445 kWh per capita
Exports: $120 billion (f.0.b., 1977); manufactures 90.9%
(machines and machine tools, chemicals, motor vehicles, iron
and stee] products), agricultural products 5.3%, fuels 2.1%,
raw materials 1.7%
Imports: $103 billion (c.i.f., 1977); manufactures 60.2%,
fuels 8.1%, agricultural products 16.7%, raw materials 15.0%
Major trade partners: EC 45.7% (France 11.8%, Nether-
lands 11.3%, Belgium-Luxembourg 7.9%, Italy 7.6%); other
Europe 12.7%; OPEC 9.4%; Communist economic 7.0%;
US. 6.8%; (data include interzonal trade
_Aid: donor—(1970-76) bilateral economic aid authorized
(ODA and OOF), $11,659 million
Budget: (1977) expenditures $73.8 billion, revenues $64.1
billion, deficit $9.7 billion
Monetary conversion rate: DM 2.32 (West German
marks)=US$1] (1977 average)
Fiscal year: calendar year
GNP: $20 million (1975 estimate); per capita income $250
(1975 ést.) . .
Agriculture: cash crops—cocoa, copra, coconut, coffee,
palm oil, bananas
Major industries: food processing on small scale, timber
Electric power: 3,000 kW capacity (1977); 5 million kWh
produced (1977), 70 kWh per capita
Exports: $8.5 million (f.0.b., 1976); mainly cocoa (90%),
copra (7%), coffee, palm oil
Imports: $10 million (c:if., 1976); communications
equipment, light and heavy vehicles, food products,
beverages, fuels and lubricants :
Major trade partners: main partner, Portugal; followed
by Netherlands, West Germany, African neighbors
Aid: economic—(1970-76) Western (non-U.S.) countries,
$567.0 million .
Budget: balanced at an estimated $6.6 million (1975)
Monetary conversion rate: 40.64 escudos=US$1 (Novem-
ber 1977) .
Fiscal year: probably calendar year','ea90b17a4c991fe22bd3749a77729ca2d586776307f7e85624ed36b1e81b2c62','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('504d64071ea940167f297ef94dec676fb73240f4ad50b3bc4165b7d373105c81',1967,'CA','Canada','economy',93,'GNP: $195.3 billion (1977, in 1977 prices), $8,330 per
capita (1977); 59.6% consumption, 22.3% investment, 18.1%
government (1977); growth rate 4.8% (1970-77, real terms)
32
Agriculture: main products—livestock, grains (principally
wheat), dairy products; food shortages—fresh fruits and
vegetables; caloric intake, 3,180 calories per day per capita
(1966-67)
Fishing: catch 800,809 million metric tons; exports
383,602 metric tons (1977)
Major industries: mining, metals, food products, wood
and paper products; transportation equipment, chemicals
Shortages: rubber, rolled steel, fruits, precision
instruments
Crude steel: 13.6 million metric tons. produced (1977)
Electric power: 73,000,000 kW capacity (1977); 316,500
million kWh produced (1977), 18,347 kWh per capita
Exports: $43,373 million (f.0.b., 1977, source: I.F.S.);
principal items—transportation equipment, wood and wood
products including paper, ferrous and nonferrous ores, crude
petroleum, wheat; Canada is a major food exporter
Imports: $42,052 million (c.if., 1977, source: I.F.S.);
principal machinery,
crude petroleum, communication equipment, textiles, steel,
fabricated metals, office machines, fruits and vegetables
Major trade partners: 70% U.S., 10% EC, 5% Japan
(1977)
Aid: economic—(received U.S., $380.9 million Ex-Im
Bank); Canada commitments to LDCs (1970-76), bilateral
ODA and OOF commitments, $6.5 billion
Budget: total revenues $33,781 million; current expendi-
tures $39,930 million; gross capital formation $6,833 million;
budget deficit $6,149 million (1977) (National Accounts
Basis)
Monetary conversion rate: there is no designated par
value for the Canadian dollar, which was allowed to float
items—transportation equipment,
freely on the exchanges beginning 1 June 1970; since then
the Canadian dollar has moved between US$0.86-1.04 in
value, 1C$=US$0.9403 (official rate)
Fiscal year: 1 ApriJ-31 March
GDP: $50 million (1975 est.); $170 per capita income
Agriculture: main crops—corn, beans, manioc, sweet
potatoes; barely self-sufficient in food
Fishing: catch, 4,400 metric tons (1976 est.); largely
undeveloped but provides major source of export earnings
Major industries: salt mining
Electric power: 6,000 kW capacity (1977); 7 million kWh
produced (1977);.20 kWh per capita
Exports: $2.5 million (f.o.b., 1975); fish, bananas, salt
Imports: $31 million (c.if., 1975); machinery, textiles
Major trade partners: Portugal, U.K., Japan, African
neighbors
Budget: (est. 1976) $30 million expenditures, $15 million
revenues
Monetary conversion rate: 40.643 escudos=US$1
(November 1977)
Fiscal year: calendar year
GDP: $394 million (1976), $220 per capita
Agriculture: commercial—cotton, coffee, peanuts, ses-
ame, wood; main food crops—manioc, corn, peanuts, rice,
potatoes, beef; requires wheat, flour, rice, beef, and sugar
imports ;
Major industries: sawmills, cotton textile mills, brewery,
diamond mining and splitting
Electric power: 44,000 kW capacity (1977); 106 million
kWh produced (1977), 60 kWh per capita
Exports: $80 million (f.o.b., 1978 est.); cotton, coffee,
diamonds, timber
Imports: $100 million (f.o.b., 1978 est.); textiles, petrole-
um products, machinery and electrical equipment, motor
vehicles and equipment, chemicals and pharmaceuticals
Major trade partners: France, Yugoslavia, Japan, U.S.
Budget: 1978 proposed budget receipts and grants $78
million, expenditures $80 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year
GDP: $296 million (1977), $70 per capita; estimated real
annual growth rate 2.0%
Agriculture: commercial—cotton, gum arabic, livestock,
fish; food crops—peanuts, millet, sorghum, rice, sweet
potatoes, yams, cassava, dates; imports food
Fishing: catch 115,000 metric tons (1976 est.)
Major industries: agricultural and livestock processing
plants (cotton textile mill, slaughterhouses, brewery), natron
Electric power: 22,000 kW capacity (1977); 60 million
kWh produced (1977), 15 kWh per capita
Exports: $61 million (f.0.b., 1976); cotton 80%, livestock
and animal products
Imports: $114 million (c.i.f., 1976); cement, petroleum,
foodstuffs, machinery, textiles, and motor vehicles
Major trade partners: France (about 40% in 1973) and
UDEAC countries; preferential tariffs to EC and franc zone
countries
Budget: (1977) $73 million
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year','2eb94da330704c4ed92c534fa836cdf09e89673fe4bd8996b8787392b08b1e26','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('801dda034dd68bc4e0c3923f9efc168ae506f4abba81b093a26753d255ef4578',1967,'CL','Chile','economy',97,'GDP: $10.3 billion (1977), $970 per capita; 76.0% private
consumption, 15.8% government consumption; 9.2% gross
investment, — 1:0% net imports and factor payments abroad;
real growth rate, 1977, 8.6%; 1972-77 average annual
increase, negligible
Agriculture: main crops—wheat, other cereals, potatoes,
corn, sugar beet, fruits; about 85% self-sufficient; 2,650
calories per day per capita (1971 est.)
Fishing: catch 1.5 million metric tons (1977); exports $94
million (1977)
Major industries: copper, nitrates, foodstuffs, fish proc-
essing, transportation equipment, iron and steel, pulp and
paper
Crude steel: 0.7 million metric tons capacity (1967);
450,000 metric tons produced (1976), 42 kg per capita
Electric power: 2,775,000 kW capacity (1977); 9.73
billion kWh produced (1977), 910 kWh per capita
Exports: $2.2 billion (f.o.b., 1977); copper, iron ore, paper
products, foodstuffs
Imports: $2.3 billion (c.if., 1977); petroleum, capital
goods, consumer products
Major trade partners: exports—30% EC, 28% LAFTA,
14% US., 13% Japan; imports—34% LAFTA, 21% U.S., 15%
EC, 11% Japan
Aid: economic—bilateral ODA and OOF (1970-76), U.S.
$381 million; Western (non-U.S.) countries, $384.8 million;
Communist countries, $386.2 million; military—U.S. (1970-
76), $50.4 million
Budget: $2.5 billion revenues, $2.8 billion expenditures
(1977)
Monetary conversion rate: 33.05 pesos=US$1 (Septem-
ber 1978), changes daily
Fiscal year: calendar year','d07e0e2e6cc052ec89d956d147aa63a605ecaa34e7c472919dcb765238cd5e0d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a07b787fb7ad0fd6b68557ccdd9311f872df4716fc01718afb0ebdde90d7847',1967,'CN','China','economy',101,'GNP: $373 billion (1977), $390 per capita
Agriculture: main crops—rice, wheat, miscellaneous
grains, cotton; caloric intake, 2,000 calories per day per
capita (1977); agriculture mainly subsistence; grain imports
6.9 million metric tons in 1977
Major industries: iron and steel, coal, machine building,
armaments, textiles, petroleum
Shortages: complex machinery and equipment, highly
skilled scientists and technicians
_ Crude steel: 24 million metric tons produced, 25 kg per
capita (1977) ;
Electric power: 42,000,000 kW capacity (1977); 150
billion kWh produced (1977), 155 kWh per capita
Exports: $8.1 billion (f.0.b., 1977); agricultural products,
oil, minerals and metals, manufactured goods
$7.2 billion (ci.f., 1977); chemical
fertilizer, steel, industrial raw materials, machinery and
equipment
Imports: grain,
Major trade partners: Japan, Hong Kong, West Germany,
Australia, Romania, Canada, East Germany, U.S., U.S.S.R.,
Singapore (1977) ;
Monetary conversion rate: as of 30 June 1978, about 1.72
yuan=US$1 (arbitrarily established)
Fiscal year: calendar year.
GNP: $19.5 billion (1977, in 1977 prices), $1,170 per
capita; real growth, 8.3% (1970-76 average)
Agriculture: most arable land intensely farmed—60%
cultivated land under irrigation; main crops—rice, sweet
potatoes, sugarcane, bananas, pineapples, citrus fruits; food
shortages—wheat, corn, soybeans
Fishing: catch 854,784 metric tons (1977)
Major industries: textiles, clothing, chemicals, plywood,
electronics, sugar milling, food processing, cement, ship
building
40
Electric power: 7,100,000 kW capacity (1977); 30 billion
kWh produced (1977), 1,780 kWh per capita
Exports: $9,361 million (f.0.b., 1977); 25% textiles, 15.9%
‘electrical machinery, 7.5% plywood and wood products, 7%
machinery and metal products, 7.5% plastics, 5% sugar
Imports: $8,511] million (c.i.f., 1977); 18% machinery, 9%
electrical machinery, 9% basic metals, 10% crude oil, 10%
chemical products
Major trade partners: exports—38.8% U.S., 11.9% Japan;
imports—31% Japan, 23% U.S. (1977)
Aid: economic—U.S. (FY46-76), $2.2 billion committed;
IBRD (1964-75), $311 million committed; Japan (1965-74),
$247 million committed; ADB (1968-75), $93 million
committed; . military—U.S. (FY46-76), $4.3 billion com-
mitted
Central government budget: $3.5 billion (FY78)
Monetary conversion rate: NT$38 (New Taiwan)=US$1
Fiscal year: 1 July-30 June
Monetary conversion rate: 1.94 won=US$1, non-com-
mercial rate
Fiscal year: calendar year
GNP: $31.5 billion (1977, in 1977 prices), $880 per capita;
real growth 10.8% (1977); real growth 11.7% (1972-77
- average)
. Agriculture: 40% of the Sesiatiae live on the land, but
agriculture, forestry and fishery constitute 24% of GNP;
main crops—rice, barley; not self-sufficient; food short-
ages—wheat, dairy products, corn
‘ Fishing: catch 2,421,273 metric tons (1977)
Major industries: textiles and clothing, food processing,
chemical fertilizers, chemicals, plywood, steel, electronics
Shortages: base metals, petroleum, lumber and certain
food grains
Electric power: 5,790,180 kW capacity (1977); .26.5
billion kWh produced (1977), 720 kWh per capita .
: Exports: $10.0 billion (f.0.b., 1977); textiles and clothing,
electrical machinery, plywood, footwear, steel, ships
Imports: $10.8 billion (c.i.f., 1977); oil, ships, steel, wood,
wheat, organic chemicals, machinery
Major trade partners: exports—31% U.S., 21% Japan;
imports—36% Japan, 23% U.S. (1977)
Aid: economic—U.S. (FY46-77), $5.8 billion committed;
Japan (1965-75), $1.8 billion extended; military—U.S. (FY
46-77) $7.0 billion committed ,
Budget: $7.3 billion (1978)
Monetary conversion rate: rate fixed at 484 won=US$1
since December 1974
114
‘
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7','a445502d80f937b641c3cb6de4097802223b6349d532daa1cc5f45acc09bca2a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e0ea4f3b9e3615ba1cf166136687f2e6f451ad67fef76296f747225fc040e18',1967,'CO','Colombia','economy',105,'GNP: $20.7 billion, est. (1977, in 1977 prices), $830 per
capita; 75% private consumption, 6% public consumption,
18% gross investment, 1.0% net foreign balance (1977)
Agriculture: main crops—coffee, rice, corn, sugarcane,
plantains, bananas, cotton, tobacco; caloric intake, 2,140
calories per day per capita (1970)
Fishing: catch 75,107 metric tons 1976; exports $10.6
million (1973), imports $10.3 million (1973)
Major industries: textiles, food processing, clothing and
footwear, beverages, chemicals, and metal products
Crude steel: 356,000 metric tons produced (1976), 14 kg
per capita aa
Electric power: 4,650,000 kW capacity (1977); 13.8
billion kWh produced (1977), 550 kWh per capita
Exports: $2,433 million (f.o.b., 1977); coffee, fuel oil,
cotton, tobacco, sugar, textiles, cattle and hides
Imports: $1,880 million (c.if., 1977); transportation
equipment, machinery, industrial metals and raw materials,
chemicals and pharmaceuticals, fuels, fertilizers, paper and
paper products, foodstuffs and beverages
Major trade partners: exports—48% Japan, 27% U.S.,
16% Germany, 10% Venezuela, 6% Netherlands; imports—
38% US., 9% Germany, 8% Japan, 5% Ecuador (1976)
41
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
COLOMBIA/COMOROS
Aid: economic—extensions from U.S. (FY46-76), $991
million loans, $325 million grants; from international
organizations (FY46-75), $1.8 billion; from other Western
countries (1970-76), $249.8 million; from Communist
countries (1970-76), $275.4 million; military—assistance
from U.S. (FY46-76), $130 million :
Budget: (1978) revenues $2.09 billion; expenditures $2.30
billion
Monetary conversion rate: 39.02 pesos= US81 (June 1978,
changes frequently)
Fiscal year: calendar year
GNP: $652 million (1976), $2,680 per capita; real growth
rate, —1% (est.)
Agriculture: little production
Major industries: petroleum refining on Curacao and
Aruba; petroleum transshipment facilities on Curacao,
Aruba, and Bonaire; tourism on Curacao, Aruba, and St.
Martin; light manufacturing on Curacao and Aruba
Electric power: 300,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 6,880 kWh per capita
Exports: $2.6 billion (f.o.b., 1977); 96% petroleum
products, phosphate
Imports: $3.1 billion (c.i.f., 1977); 64% crude petroleum,
food, manufactures
Major trade partners: exports—46% U.S., 2% Canada, 1%
Netherlands; imports—35% Venezuela, 11% U.S., 4% Neth-
erlands (1977)
Aid: bilateral commitments (1970-76), economic—West-
ern (non-U.S.) countries $203.6 million
Budget: (1977) public sector current revenues, $278
million; public sector expenditures, $306 million
Monetary conversion rate: 1.8 Netherlands Antillean
florins (NAF)=US$1, official
Fiscal year: calendar year','27056eba57d7b0115a0d1f3821ebda07df77370d7cd652ea98afeba0183e3556','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97295ea7fd78d833c2d1d41d07d6d5452494f06e558ec5d103900ddd8380de21',1967,'KM','Comoros','economy',111,'GDP: about $700 million (1977 est.), $490-per capita; real
growth rate 2.5% per year (1970-77)
Agriculture: cash crops—sugarcane, wood, coffee, cocoa,
palm kernels, peanuts, tobacco; food crops—root crops, rice
corn, bananas, manioc, fish
Fishing: catch 19,447 metric tons (1976)
Major industries: crude oil, sawmills, brewery, cigarettes,
sugar mill, soap
Electric power: 63,200 kW capacity (1977); 130 million
kWh produced (1977), 90 kWh per capita
Exports: $214 million (f.0.b., 1977 est.); oil (58%), lumber,
tobacco, veneer, and plywood
Imports: $266 million (f.o.b., 1977 est.); machinery,
transport equipment, manufactured consumer goods, iron
and stéel, foodstuffs, petroleum products, sugar
>
Major trade partners: France and other EC countries
Budget: 1977 est.—revenue $216 million, expenditure
$240 million “
Monetary conversion rate: 245.67 Communaute Finan-
ciere Africaine francs=US$1 (1977)
Fiscal year: calendar year','693e9bd182cdae1aa283f15fcd6d2e807f1c5a8036b303ec68ff7a97d493ade4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84ec0a76d0405376c4fdb08c13f0afcc94886c4f83a438822821159de2b7b910',1967,'CK','Cook Islands','economy',115,'GDP: $400 per capita (1973)
Agriculture: export crops include copra, citrus fruits,
pineapples, tomatoes, and bananas, with subsistence crops of
yams and taro
Industry: fruit processing
Electric power: 3,000 kW capacity (1977); 10 million
kWh produced (1977), 560 kWh per capita
Exports: $2.7 million (1971); fruit juice, clothing, citrus
fruits
Imports: $5.8 million (1971)
Major trade partners: (1970) exports—98% New Zealand,
imports—76% New Zealand, 7% Japan
Monetary conversion rate: 1 NZ$=US$0.9947 (July
1976)','5f5be5ab3654944a6f93e0806a0483cf21602c2b32e41bfe1d061748dca93303','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73f4ca017d5695dd309e687039f88c185de97531269175dc7621ed362ea6b1ec',1967,'CR','Costa Rica','economy',119,'GDP: $2.8 billion (1978, in current prices), $1,370 per
capita; 66% private consumption, 16% public consumption,
22% gross domestic investment, —4% net foreign balance
(1976); real growth rate 1977, 6.9%; average growth
(1972-77), 6.2%
Agriculture: main products—bananas, coffee, sugarcane,
rice, corn, cocoa, livestock products; caloric intake, 2,610
calories per day per capita (1966)
Fishing: catch 12,728 metric tons (1976); exports, $5.1
million (1976), imports, $0.3 million (1976)
Major industries: food processing, textiles and clothing,
construction materials, fertilizer
Electric power: 410,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 830 kWh per capita
Exports: $815 million (f.0.b., 1977); coffee, bananas, beef,
sugar, cacao
Imports: $1,010 million (c.i.f., 1977); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels,
foodstuffs, fertilizer
Major trade partners: exports—38% U.S., 22% CACM,
11%. West Germany; imports—35% U.S., 18% CACM, 5%
West Germany, 11% Japan (1976)
Aid: (1970-76) economic bilateral commitments: U.S. $72
million, other Western countries $78 million, Communist
$17 million; military commitments negligible
Budget: (1977) $410 million current revenues, ~ $530
million total expenditures including debt amortization
Monetary conversion rate: 8.57 colones=US$1
Fiscal year: calendar year','4abdba3cfff587a6d6b3886bea482ce49acce213efc2b5dfdadcddfe6f8714d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a8cb9105aea2b55f1e72e09439eb6df2f3f72e9f9287516cb52a4383e365d4a',1967,'CY','Cyprus','economy',123,'GNP: $789.3 million (1976), $1,580 per capita; 1976 real
growth rate 14.6%
Agriculture: main crops—vine products, citrus, potatoes,
other vegetables; food shortages—grain, dairy products,
meat, fish; caloric intake, 2,460 calories per day per capita
(1964-66)
Major industries: mining (cupreous and iron pyrites,
asbestos), manufactures principally for local consumption—
food, beverages, footwear, clothing, cement
Shortages: water, petroleum
Electric power: 338,000 kW capacity (1977); 888 million
kWh produced (1977), 1,390 kWh per capita
Exports: $318 million (f.0.b., 1977, converted at average
trade conversion factor of 1 Cyprus pound=US$2.451);
principal items—asbestos, copper, pyrites, citrus, raisins, and
other agricultural products, potatoes, cement, clothing,
footwear, wine
Turkish Sector exports: $15.7 million (f.0.b., 1976, con-
verted at average conversion factor of 16.053 Turkish
lira=US$1); principal items—citrus fruits, potatoes, manu-
factured goods
Imports: $623 million (c.i.f., 1977, converted at average
trade conversion factor of 1 Cyprus pound=US$2.451);
principal items—manufactured goods, machinery and trans-
port equipment, petroleum products, foods
Turkish Sector imports: $65.9 million (c.i.f., 1976, con-
verted at average trade conversion factor of 16.053 Turkish
lira=US$1); principal items are foodstuffs, livestock, raw
materials, oil, machinery
Major trade partners: (1977) imports—19% U.K., 9%
Italy, 8% Greece, 8% West Germany, 6% U.S., 5% France;
exports—29% U.K., 18% Saudi Arabia, 9% Lebanon, 5%
Libya, 4% Egypt, 3% U.S.S.R., 3% Greece, 3% Syria
Turkish Sector major trade partners: (1976) imports—
48% Turkey, 22% U.K., 7% West Germany, 5% France, 3% .
Netherlands, 3% Italy; exports—33% U.K., 29% Turkey, 18%
Netherlands, 10% Italy
Aid: economic—U.S., $49 million authorized (FY70-76);
other Western bilateral authorizations (ODA and OOF), $34
million (1970-76); Greece, $79 million (1976)
Turkish Sector aid: Turkey, $70 million (1974-76)
Budget: 1977—revenues $167.6 million, expenditures
$229.4 million, deficit $61.8 million
Turkish Sector budget: revenues $38 million, expendi-
tures $78 million, deficit $40 million
Monetary ‘conversion rate: 1 Cyprus pound=US$2.61
(December 1971 through January 1973), 1 Cyprus
pound=US$$2.4510 (trade conversion factor for 1977)
Turkish Sector monetary conversion rate: 18.002 Turk-
ish lira=US$1 (trade conversion factor for 1977)
Fiscal year: calendar year
NOTE: 1974, 1975, 1976, and 1977 GNP, import, export,
and budget figures are Government of Cyprus figures which
include 100% of island until August 1974 and 60% of island
thereafter; the Turkish sector of island for last 4 months of
1974 is part of Turkish mainland economy; with the passage
of time, some information on the Turkish sector of the island
has become available.','69a28f3a132c8189d473b650bbe4f0ad8855cbe87fbca1c01699fc197efdbe83','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('411d4b1daf8f188231a5a072be0dc9943f5d2844fad7aec45e624e167d6d4329',1967,'RO','Romania','economy',125,'GNP: $63.2 billion in 1977 (in 1977 dollars), $4,200 per
capita; 1977 réal growth rate 3.4%
Agriculture: diversified agriculture; main crops—wheat,
rye, potatoes, sugar beets; net food importer—meat, wheat,
vegetable oils, fresh fruits and vegetables; caloric intake,
8,100 calories per day per capita (1967)
Major industries: machinery, food processing, metal-
lurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 15.1 million metric tons produced (1977),
1,000 kg per capita
Electric power: 15,200,000 kW capacity (1977); 66.4
billion kWh produced (1977), 4,410 kWh per capita
Exports: $10,495 million (f.0.b., 1977); 51% machinery,
equipment; 28% fuels, raw materials; 3% foods, food
products, and live animals; 18% consumer goods, excluding
foods (1977)
Imports: $10,888 million (f.0.b., 1977); 39% machinery,
equipment; 45% fuels, raw materials; 10% foods, food
products, and live animals; 6% consumer goods, excluding
foods (1977)
Monetary noncommercial
crowns=US$1, commercial 5.64 crowns=US$1
conversion _ rate: 10.15
Fiscal year: calendar year
NOTE: foreign trade figures were converted at the rate of
5.81 crowns=US$1
GNP: $57.0 billion (1977, in 1976 prices), $2,630 per
capita; 1977 real growth rate, 3.6%
174
Agriculture: net exporter; main crops—corn, wheat,
oilseed; livestock—cattle, hogs, sheep; caloric intake, 118%
of requirements
Fish catch: 127,197 metric tons (1976)
Major industries: machinery, metals, fuels, chemicals,
textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical coke,
cotton fibers, natural rubber
Crude steel: 11.5 million metric tons produced (1977),
530 kg per capita :
Electric power: 13,200,000 kW capacity (1977); 59.8
billion kWh produced (1977), 2,760 kWh per capita
Exports: $7.0 billion (f.0.b., 1977); 26% machinery and
equipment; 16% foodstuffs; 16% consumer goods; 24% fuels,
metals, materials; 18% other (1976)
Imports: $7.0 billion (mixture f.o.b. and c.i.f., 1977); 82%
machinery and equipment; 41% fuels, metals, raw materials; ,
8% foodstuffs; 19% other (1976)
Major trade partners: $14.0 billion in 1977; 57%
non-Communist countries, 43% Communist countries (18%
U.S.S.R.) (1976)
Monetary conversion rate: 4.47 lei=US$1 (commercial),
12 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year, 1 July-30 June','3dbf9e3e1f6c72b17ea9f5b669f4899e23ee90f02d7a1c723223f26600719096','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abcdf356daefe44da7a5fd3663c7d8605e77a4dc9452506a1194b5510891316f',1967,'DK','Denmark','economy',129,'GNP: $42.2 billion (1977), $8,290 per capita; 58% private
consumption, 20% investment, 25% government, — 2.5% net
foreign sector and stock building (1977); 1977 growth rate
1.2%, constant prices
51
‘
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
DENMARK/ DJIBOUTI
Agriculture: highly intensive, specializes in dairying and
animal husbandry; main crops—cereals, root crops; food
imports—oilseeds, grain, feedstuffs; caloric intake, 3,180
calories per day per capita (1968-69)
Fishing: catch 1.91 million metric tons (1976), exports
$462 million (1977)
Major industries: food processing, machinery and equip-
ment, textiles and clothing, chemical products, electronics,
transport equipment, metal products, brick and mortar,
furniture and other wood products
Crude steel: 685,000 metric tons produced (1976), 180 kg
per capita
Electric power: 7,400,000 kW capacity (1977); 23.9
billion kWh produced (1977), 4,690 kWh per capita
Exports: $10.1 billion (f.0.b., 1977); principal items—
meat, dairy products, industria] machinery and equipment,
textiles and clothing, chemical products, transport equip-
ment, fish, furs, and furniture
Imports: $13.3 billion (c.i.f., 1977); principal items—
industrial machinery, transport equipment, petroleum,
textile fibers and yarns, iron and steel products, chemicals,
grain and feedstuffs, wood and paper
Major trade partners: 46.1% EC-nine (17.7% West
Germany, 12.3% U.K.); 13.6% Sweden; 5.9% Norway; 5.7%
U.S.; 4.6% Netherlands; .4.4% Communist countries (1977)
Aid: donor—bilateral economic aid authorized (ODA and
OOF) $717 million (1970-76)
Budget: (FY77) expenditures $20.3 billion, revenues $20.1
billion
Monetary conversion rate: 6.0032 Kroner=US$1 (1977,
average exchange rate)
Fiscal year: calendar year, beginning 1] January 1979','ca125d4a7273f6ae056864e7ff75d3107ac86b0a69f5a53f9cc59bccb9d8fc7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b017b87e2507bdb5d5c1eb6d726eccdbf0cf6b0c9867d945f822d7a5a7460f27',1967,'DJ','Djibouti','economy',132,'GNP: $65 million (1972)
Agriculture: livestock; desert conditions limit commercial
crops to about 15 acres, including fruits and vegetables
Industry: ship repairs and services of port and railroad
drastically reduced with war in Ethiopia’s Ogaden that cut
the railroad line
Electric power: 23,500 kW capacity (1977); 55 million
kWh produced (1977), 310 kWh per capita
Imports: $74 million (1973); almost all domestically
needed goods—foods, machinery, transport equipment
Exports: $20 million, including transit trade (1973);. hides
and skins, and transit of coffee; since railroad line has been
cut, values have plummeted
Monetary conversion rate: 182 Djibouti francs=US$1
Fiscal year: probably same as that for France (calendar
year)','53378201f1c678ff1decf64a931f0549e93cc343d0d89816e976bf7a0fa57d95','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baf1cc68afd0bc13f1710025ebb5df63887b3b5e77fafc2640305663e4027a85',1967,'DM','Dominica','economy',136,'GNP: $32 million (1977 est.), $410 per capita; real growth
rate, 1977, 2.0% est.
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 10,000 kW capacity (1977); 7 million
kWh produced (1977), 90 kWh per capita
Exports: $10 million (f.0.b., 1976); bananas, lime juice and
oil, cocoa, reexports
Imports: $18 million (c.i.f., 1976); machinery and
equipment, foodstuffs, manufactured articles, cement
Major trade partners: 47% U.K., 15% Commonwealth
Caribbean countries, 7% U.S., 6% Canada (1975)
Aid: economic—bilateral including Ex-Im (1970-76),
from Western (non-U.S.) countries, $57 million; no military
aid d
Budget: revenues, $8 million; expenditures, $11 million
(1977/78 est.)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1
Fiscal year: 1 July-30 June','59fded14bfc38d37ba59a29470ab6c9158d6a7a752315d5d39a3ae871f3c5999','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c21a674e99964c01186095cfce16870a2a63c05472d98028fabc13e7c7b5092',1967,'DO','Dominican Republic','economy',140,'GNP: $4.4 billion (1977), $880 per capita; real growth rate
1977, 3.3%
Agriculture: main crops—sugarcane, coffee, cocoa, to-
bacco, rice, corn
.
Major industries: sugar processing, nickel mining, bauxite
mining, gold mining, textiles, cement
Electric power: 662,000 kW capacity (1977): 2 billion
kWh produced (1977), 400 kWh per capita
Exports: $780 million (f.0.b., 1977); sugar, nickel, coffee,
tobacco, cocoa, bauxite
Imports: $848 million (f.o.b., 1977); foodstuffs, petroleum,
industrial raw materials, capital equipment
Major trade partners: exports—81% U.S. (1977); im-
ports—50% U.S. (1977)
Aid: economic—bilateral commitments, including Ex-Im
(FY70-76), from U.S., $252 million; other Western countries,
$78 million; military—from U.S., $12 million
Budget: revenues, $600 million; expenditures, $635
million (1978 est.)
Monetary conversion rate: 1 peso=US$]
Fiscal year: calendar year','105a2400b19bf5bbb232751c85f5ba2260e803a4958fb3eff37cbf8054268cc6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6dc96b1dd84fe27659078359afc65cd821d8ad0e94ce1e5f2d5b7c2ccd730c1',1967,'EC','Ecuador','economy',144,'GNP: $5.6 billion est. (1977), $780 per capita; 70% private
consumption, 10% public consumption, 20% gross invest-
ment; average annual real growth rate 1974-77, 6.8%
Agriculture: main crops—bananas, coffee, cocoa, sugar-
cane, fruits, corn, potatoes, rice; caloric intake, 1,970 calories
per day per capita (1970)
Fishing: catch 233,400 metric tons (1975); exports $73
million (1977), imports negligible
Major industries: food processing, textiles, chemicals,
fishing, petroleum
Electric power: 552,000 kW capacity (1977); 2.1 billion
kWh produced (1977), 290 kWh per capita
Exports: $1.2 billion (f.0.b., 1977); petroleum, bananas,
coffee, cocoa, sugar, fish products
Imports: $1.5 billion (c.i''f., 1977); agricultural and
industrial machinery, industrial raw materials, building
supplies, chemical products, transportation and communica-
tion equipment . :
Major trade partners: exports (1977)—41% U.S., 20%
LAFTA, 15% EC; imports (1977)—41% U.S., 22% EC, 18%
Japan, 14% LAFTA
Aid: economic—bilateral ODA and OOF (1970-76), U.S.,
$117.5 million; other Western countries, $157.9 million;
OPEC, $22 million; Communist countries, $9.4 million;
military—(1970-76) U.S., $13.6 million
Budget: (1977) revenues, $885 million; expenditures,
$1,095 million
Monetary conversion rate: 25 sucres=US$1
Fiscal year: calendar year
GNP: $14.5 billion (1976), $380 per capita; average
annual growth rate of 9% in 1976
Agriculture: main cash crop—cotton; other crops—rice,
onions, beans, citrus fruit, wheat, corn, barley; not self-suffi-
cient in food, but agriculture a net earner of foreign
exchange ;
Major industries: textiles, food processing, chemicals,
petroleum, construction, cement
Electric power: 5,300,000 kW capacity (1977); 14 billion
kWh produced (1977), 350 kWh per capita
Monetary conversion rate: official rate—] Egyptian
pound=US$2.54 (selling rate); 0.394 Egyptian pound=
US$1 (selling rate); parallel market rate—1 Egyptian
pound=US$1.43, 0.699 Egyptian pound=US$1
Fiscal year: calendar year, beginning in 1975
57
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
EGYPT/EL SALVADOR','f11b994f99197f37d41f4883cb71a309c45d89fb45b620f8e5dc350d55fc3571','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55f3b0c861c39a85039b618e0a6f6b99b996266acd8cd9749c719a299e3af196',1967,'SV','El Salvador','economy',148,'GNP: $2.6 billion (1977), $610 per capita; 70% private
consumption, 11% government consumption, 19% domestic
investment; real growth rate, 4.9% (1977)
Agriculture: main crops—coffee, cotton, corn, sugar; rice,
beans; caloric intake, 2,000 calories per day per capita
(1963-64)
Fishing: catch 9,130 metric tons (1976)
Major industries: food processing, textiles, clothing,
petroleum products
Electric power: 557,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 280 kWh per capita
Exports: $968 million (f.o.b., 1977); coffee, cotton, sugar
Imports: $947 million (c.if., 1977); machinery, auto-
motive vehicles, petroleum, foodstuffs, fertilizer
Major trade partners: exports—33% U.S., 24% CACM,
11% other (1976); imports—29% U.S., 24% CACM, 7%
Venezuela, 14% West Germany, 8% Netherlands, 40% other
(1976)
Aid: economic—(FY70-76) from U.»., $60 million; from
other Western countries, $36 million; military—from U.S.
$10 million
Budget: (1978) $500 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year','0c525b39dd649a49e7411d0f3c8b8e729c4342044cd22893650b825fcdc4ea89','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8819ecaa5f290855355bd801b5508c711b705b3b8986b88c500e84795c4d944b',1967,'CM','Cameroon','economy',151,'GNP: $70 million (1972); $240 per capita
Agriculture: major cash crops—Rio Muni, timber, coffee;
Fernando Po, cocoa; main food products—rice, yams,
cassava, bananas, oil palm nuts, manioc, and livestock
60
Major industries: fishing, sawmilling
Electric power: 5,000 kW capacity (1977); 17 million
kWh produced (1977), 50 kWh per capita
Exports: $36 million (1974); cocoa, coffee, and wood
Imports: $20 million (1974); foodstuffs, chemicals and
chemical products, textiles
Major trade partner: Spain
Budget: (1973) receipts $9 million, expenditures $12
million
Monetary conversion rate: 68.85 Ekuele=US$1 (January
1977)','9269cc225f69c06029aa658aa8cc9215fcf457e09bc5afb078475ef5bc3089b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bd74b6cea33b615260e4e4812dcb072af1e11ad3e5fee937167fbebcee26c66',1967,'ET','Ethiopia','economy',155,'GDP: $2,891 million (1977 est.), $100 per capita; average
annual real growth rate 4% (1967-73), zero (1974 and in
1975)
Agriculture: main crops—coffee, teff, durra, barley,
wheat, corn, sugarcane, cotton, pulses, oilseeds; livestock
Major industries: cement, sugar refining, cotton textiles,
food processing, oil refinery
Electric power: 297,000 kW capacity (1977); 500 million
kWh produced (1977), 20 kWh per capita
Exports: $329 million (f.0.b., 1977); 75% coffee, 7% hides
and skins, 6% pulses, 2% oilseeds
Imports: $348 million (c.if.,. 1977); 18% petroleum
Major trade partners: imports—Saudi Arabia, Japan,
Italy, West Germany, Iran, U.K., France, and US:
exports—U.S., Djibouti, Saudi Arabia, Japan, Italy, West','eae83d2615dfe06d768a1f63343a686ce716f7b75f1540eb7553e1fc54fcaa2b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('952221eb340cacca5c5491e7674d7d402c23b2ab08cce8e700541ae1956a93f3',1967,'DE','Germany','economy',156,'Monetary conversion rate: 2.07 Ethiopian Birr=US$)
Fiscal year: 8 July-7 July
. Aid: economic—from U.S. (FY46-76), $129 million loans,
$236 million grants; from international organizations
(FY46-75), $246 million; from other Western countries
(1960-71), $12.3 million: military—assistance from USS.
(FY46-75), $41 million
Central government budget (1978 est.): expenditures,
$943 million; revenues, $943 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
Monetary conversion rate: 1 Tunisian dinar (TD)=
US$2.32
Fiscal year: calendar year
GNP: $45.0 billion (1977), $1,070 per capita; 3.8% real
growth 1977, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average years
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
-a.
ls rs
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1977); 22.0
billion kWh produced (1977), 510 kWh per capita
Exports: $2,671 million -(f.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $6,999 million (f.0.b., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals ,
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy (1976)
Budget: (FY77) revenues $11.2 billion, Secinisel $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.25 Turkish liras=US$1
(July 1978)
Fiscal year: 1 March-28 February','26b0e75e55bca1654ccb543107c43113464a749df981a49bccdefc7ed1710621','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5490fcc941f5595196939c0237aa9d1f4dd029cb9add055acadc227b343e1b1e',1967,'FO','Faroe Islands','economy',161,'GDP: $173.4 million (1974), about $4,340 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 341,962 metric tons (1976); exports, $94.7
million (1976)
Major industry: fishing
Electric power: 28,500 kW capacity (1977); 90 million
kWh produced (1977), 2,140 kWh per capita
Exports: $104.4 million (f.0.b., 1976); mostly fish and fish
products
Imports: $180.7 million (c.i.f., 1976); machinery and
transport equipment, petroleum and petroleum products,
food products
Major trade partners: 50.2% Denmark, 13.7% Norway,
7.9% U.K., 7.2% U.S., 4.4% Italy (1976)
Budget: (FY76) expenditures $52.8 million, revenues
$52.8 million
Monetary conversion rate: 6.00382 Danish Kroner=US$1
(1977, average)
Fiscal year: calendar year beginning 1 January 1979
63
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FAROE ISLANDS/FIJ1','772899fe021c563c86b0dc1fe1a0d4a03eb76796484bd3970f49598c8a33c89d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fdcc41c8f0095706bf22f2c61833ee380e8151c222f967c6dcf131c0c62b7ce',1967,'FI','Finland','economy',165,'GNP: $29 billion (1977), $6,110 per capita; 53%
consumption, 27% investment, 21% government; —1% net
exports of goods and services; 1976 growth rate 0.3%,
constant prices, 1977 growth rate —0.1%
Agriculture: animal husbandry, especially dairying, pre-
dominates; forestry important secondary occupation for
rural population; main crops—cereals, sugar beets, potatoes;
85% self-sufficient; shortages—food and fodder grains;
caloric intake 2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing and
shipbuilding, forestry and wood processing (pulp, paper),
copper refining :
Shortages: fossil fuels; industrial raw materials, except
wood, and iron ore
Crude steel: 1.7 million metric tons produced (1976), 360
kg per capita
Electric power: 9,400,000 kW capacity (1977); 33.1
billion kWh produced (1977), 6,975 kWh per capita
Exports: $7.7 billion (f.0.b., 1977); timber, paper and
pulp, ships, machinery, iron and steel, clothing and footwear
Imports: $7.6 billion (c.i.f., 1977); foodstuffs, petroleum
and petroleum products, chemicals, transport equipment,
iron and steel,. machinery, textile yarn and fabrics
Major trade partners: (1976) 37% EC-nine (13% West
Germany, 11% U.K.); 19% U.S.S.R., 16% Sweden; 5% U.S.
Aid: economic authorizations—U.S. $64 million (FY70-76)
Budget: (1976) expenditures $8.4 billion, revenues $7.8
billion
Monetary conversion rate: new markka (Fmk)
4.03=US$1 (1977 average, IMF)
Fiscal year: calendar year','8a72af6b45768f337cbb4692b449b9c0b7ebe34d8ae4e73ef227c3502594edcd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd34abe5acb777fb753929779aa61ab1aa4cf2fd8213d41e3851f12252281e2',1967,'FR','France','economy',169,'GNP: $381 billion (1977), $7,150 per capita; 6].2% private
consumption, 22.6% investment (including government),
15.8% government consumption; 1977 real growth rate,
2.4%; average annual growth rate, 4.8% (1966-76)
Agriculture: Western Europe’s foremost producer; main
products—beef, cereals, sugar beets, potatoes, wine grapes;
self-sufficient for most temperate zone foodstuffs; food
shortages—fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 805,925 metric tons (1976); exports
(includes shellfish, etc.) $122 million, imports $506 million
(1976)
Major industries: steel, machinery and equipment,
textiles and clothing, chemicals, food processing, metallurgy,
aircraft, motor vehicles
Shortages: crude oil, textile fibers, most nonferrous ores,
coking coal, fats and oils
Crude steel: 22.1 million metric tons produced (1977),
410 kg per capita
Electric power: 54,000,000 kW capacity (1977); 21]
billion kWh produced (1977), 3,955 kWh per capita
67
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FRANCE/FRENCH GUIANA
Exports: $65.0 billion (f.0.b., 1977); principal items—
machinery and transportation equipment, foodstuffs, agri-
cultural products, iron and steel products, textiles and
clothing, chemicals
Imports: $70.5 billion (c.i.f., 1977); principal items—
crude petroleum, machinery and equipment, chemicals, iron
and steel products, foodstuffs, agricultural products
Major trade partners: 18% West Germany; 9% Belgium-
Luxembourg; 10% Italy;.6% U.S.; 5% Netherlands; 6% U.K.;
2% Eastern Europe; 2% U.S.S.R.; 8% Franc Zone (1977)
Aid: donor—bilateral economic aid authorized (ODA and
OOF), $13,384 million (1970-76)
Budget: (1977) expenditures 355 billion francs, revenues
336 billion francs, deficit 19 billion francs
Monetary conversion rate: 1 franc=US$$0.2035 (1977
average)
Fiscal year: calendar year
GNP: $9.3 billion prelim. est. (1977, at 1977 prices),
$2,930 per capita; 63.4% consumption, 25.9% investment,
18.8% government, 2.0% inventories; — 10.2% net export of
goods and services; 1970-77 (inclusive) real growth rate,
average 3.1%
Agriculture: 70% of agricultural area used for permanent
hay and pasture; main products—livestock and dairy
products, turnips, barley, potatoes, sugar beets, wheat; 85%
self-sufficient; food shortages—grains, fruits, vegetables;
caloric’ intake 3,510 calories per day per capita (1970)
Fishing: catch 94,319 metric tons (1976); exports of fish
and fish products $37.3 million (1976), imports of fish and
fish products $15.7 million (1976)
Major industries: food products, brewing, textiles and
clothing, chemicals and pharmaceuticals, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel
‘and nonferrous metals, fertilizers, cereals and animal feeds,
textile fibers and textiles
Crude steel: 85,000 metric tons produced in 1975, 30 kg
per capita
Electric power: 2,400,000 kW capacity (1977); 9.8 billion
kWh produced (1977), 2,910 kWh per capita
Exports: $4,395 million (f.o.b., 1977); live animals, meat,
dairy products, textiles, clothing, chemicals, machinery
Imports: $5,377 million (c.if., 1977); petroleum and
petroleum products, machinery, chemicals, cereals, textiles
Major trade partners: 66% EC (42% U.K.); 8% USS.
(January-November 1977)
Aid: economic—EC Common Borrowing Facility, $300
million (1976)
Budget: (1978 projected) 2,368 million pounds expendi-
tures, 1,963 million pounds revenues, 405 million pounds
deficit, public sector borrowing requirement 82] million
pounds
Monetary conversion rate: 1 Irish pound=US$].7448
(1977) annual average, floating)
Fiscal year: calendar year
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee
Ow TW
ee ee eee
NN NN ar a
et A a a i A a a a ei ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
IRELAND/ISRAEL
GNP: $2.5 billion, $6,900 per capita (1977); 58.1% private
consumption, 14.5% government consumption, 28.3% invest-
ment, 2.8% change in stocks; —3.7% net foreign balance
Agriculture: mixed farming; main crops—grains, pota-
toes, fodder beets; food shortages—sugar, bread grains, fats
Major industries: iron and steel (25% of GNP), food
processing, chemicals, metal products and engineering, tires
123
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
LUXEMBOURG/MACAO
Crude steel: 4.28 million metric tons produced (1977), 12
metric tons per capita
Electric power: 1,850,000 kW capacity (1977); 1,300
million kWh produced (1977), 3,591 kWh per capita
Exports, Imports, Major trade partners: Luxembourg has
‘a customs union with Belgium under which foreign trade is
recorded jointly for the two countries; Luxembourg’s
principal exports are iron and steel: products, principal
imports are coal and consumer goods; most of its foreign
trade is with Germany, Belgium, France, and other EC
countries (for totals, see Belgium)
Budget: (1977) expenditures $1,056 million, revenues
$1,066 million, surplus. $10 million :
Monetary conversion rate: LF35.841=US$1, 1977 aver-
age; under the BLEU agreement, the Luxembourg franc is
equal in value to the Belgian franc which circulates freely in','4dab4bfc650f24895004fa5f121f59ea86546b2287b35c39459faa2f947748c0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48edcca9c4ba4f257669c5e114aae552bf0e5721229d45f52e44ffc945a86e61',1967,'GY','Guyana','economy',173,'GNP: $100 million (at market prices, 1975), $800 per
capita :
Agriculture: main crops—rice, corn, manioc, cocoa,
bananas, sugarcane ,
Fishing: catch 1,113 metric tons (1976)
Major industries: timber, rum, gold mining, production
of rosewood essence, and space center
Electric power: 29,000 kW capacity, (1977); 60 million
kWh produced (1977), 1,000 kWh per capita
Exports: $7.2 million (1977); shrimp, timber, rum
rosewood essence .
’
Imports: $143.4 million (1977); food (grains, processed
meat), other consumer goods, producer goods, and
petroleum
Major trade partners: exports—78% U.S., 11% France,
5% Martinique; imports—49% France, 10% US., 3%
Trinidad and Tobago (1969) .
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $356 million,
no ‘military aid’
Monetary conversion rate: 4.92 French francs=US$1
Fiscal year: calendar year
GNP: $418 million (1977), $510 per capita; real growth
rate 1977, —6.2%
Agriculture: main crops—sugarcane, rice, other food
crops; food shortages—wheat flour, cooking oil, processed
meat, dairy products
Major industries: bauxite mining, alumina production,
sugar and rice milling, timber
Electric power: 175,000 kW capacity (1977); 370 million:
kWh produced (1977), 450 kWh per capita
Exports: $258 million (f.o.b., 1977); bauxite, sugar,
alumina, rice, shrimp, molasses, timber, diamonds, rum
Imports: $314 million (c.if., 1977); manufactures, ma-
chinery, food, petroleum
Major trade partners: exports—31% U.K., 19% U.S., 16%
CARICOM, 5% Canada; imports—26% U.S., 21% U.K., 26%
CARICOM, 4% Canada (1977)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from U.S., $36.7 million; from other Western
countries, $63.9 million; from OPEC, $15 million; from
Communist countries, $46 million; no military aid
Budget: revenue, $189 million; expenditure, $252 million
(1978)
Monetary conversion rate: floating with US dollar, 1
US$=G$2.55
Fiseal year: calendar year','706764afa16d94b7abbc9e3d830eace3c302bae1037d853cbb5f9122921b5dd1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('639df1049703b84c8faaf87ecda30ebcdfb9870c2c1fe945993369e412ac7f7c',1967,'PF','French Polynesia','economy',177,'GDP: $259 million (1970) $1,960 per capita
Agriculture: coconut main crop
Major industries: maintenance of French nuclear test
base, tourism
Electric power: 36,000 kW capacity (1977); 105 million
kWh produced (1977), 750 kWh per capita
Exports: $19 million (1973); principal products—coconut
products (79%), mother-of-pearl (14%) (1971)
Imports: $211 million (1973)
Major trade partners: imports—59% France, 14% U.S.;
exports—86% France |
Aid: France’ $16 million (1973)
Monetary conversion rate: 100 CFP=1NZ$ (1971)','b7f9f3ed95554fadf3facec97ccd5d7bd152df2ba5d57d28c2078a6bed9d3370','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3687ed64a6e367361999df97e9df0dc40a539827e41b991d1f1571425726dc',1967,'GN','Guinea','economy',181,'GNP: $8 billion (1976 est.) at current prices, about $790
per capita; real growth rate less than 1% (1970-77)
Agriculture: main crop—cocoa; other crops include root
crops, corn, sorghum and millet, peanuts; not self-sufficient,
but can become so ;
. Fishing: catch 237,697 metric tons (1976 est.)
Major industries: mining, lumbering, light manufactur-
ing, fishing, aluminum
Electric power: 1,157,000 kW capacity (1977); 4.0 billion
kWh produced (1977), 390 kWh per capita
Exports: $804 billion (f.0.b., 1976); cocoa (about 70%),
wood, gold, diamonds, manganese, bauxite, and aluminum
76
(aluminum regularly excluded from balance of payments
data)
Imports: $845 billion (c.i.f., 1976); textiles and other
manufactured goods, food, fuels, transport equipment
Major trade partners: U.K., EC, and USS.
Budget: FY78 (proposed)—revenue $1,619 million includ-
ing grants, current expenditure $1,570 million, capital
expenditure $487 million
Monetary conversion rate: 1 Cedi=US$0.87
Fiscal year: 1 July-30 June
GNP: $1.1 billion (1977 est.), $240 per capita
Agriculture: cash crops—coffee, bananas, palm products,
peanuts, and pineapples; staple food crops—cassava, rice,
millet, corn, sweet potatoes; livestock raised in some areas
Major industries: bauxite mining, alumina, light manu-
facturing and processing industries
Electric power: 101,500 kW capacity (1977); 500 million
kWh produced (1977), 110 kWh per capita
Exports: $330 million (f.0.b., 1977 est.); bauxite, alumina,
coffee, pineapples, bananas, palm kernels
Imports: $280 million (f.o.b., 1977 est.); petroleum
products, metals, machinery and transport equipment,
foodstuffs, textiles
Major trade partners: Communist countries, Western
Europe’ (including France), U.S.
Budget: (FY77 est.) current revenue $238 million, current
expenditures $176 million
Monetary conversion rate: 21.25 syli=US$1 floating (end
1977)
Fiscal year: 1 October-30 September
GDP: $1.9 billion (1977), we per capita; real growth
—2.3% in 1976
Agriculture: main crops—peanuts, millet, sanchlin. man-
ioc, rice; peanuts primary cash crop; production of food
crops increasing but still insufficient for domestic re-
quirements
Fishing: catch 361,673 metric tons (1975); exports $30.9
million (1974)
Major industries: fishing, seneiltaed processing —e
light manufacturing, mining
Electric power: 183,850 kW capacity (1977); 603 million
kWh produced (1977), 120 kWh per capita -
Exports: $411 million (f.o.b., 1976/77); peanuts and
peanut products; phosphate . rock; canned fish
Imports: $605 million (c.i.f., 1976/77); food, consumer
goods, machinery, transport equipment
Major trade partners: France, EC (other than France),
and france zone
Aid: economic—Western (non-U.S.) countries (1970-76),
$526.5 million; Communist countries (1970-76), $87.7
million; OPEC (ODA) (1973-76), $81.0 million; U.S. (1970-
76), $42.3 million
Budget: 1978 revised estimate $378 million
Monetary conversion rate: francs; about 242.69 Com-
munaute Financiere Africaine francs=US$1 as of November
1977, floating
Fiscal year: 1 July-30 June','ae1c4b8c204f603b6b54ce6b4611611fa5fe69e56a090f1aa96c8302f61aa09c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f59949452439351e6b1428c48788e12943b20765a802360e6b205d37562a4492',1967,'GR','Greece','economy',187,'GNP: $26.7 billion (1977 est.), $2,920 per capita; 65.7%
consumption, 22.7% investment, 15.5% government; 1.9%
change in stocks; net foreign balance —5.8%; real growth
rate 4.0% (1977)
Agriculture: main crops—wheat, olives, tobacco; cotton;
nearly self-sufficient; food shortages—livestock products
Major industries: food and tobacco processing, textiles,
chemicals, metal products ,
Shortages: petroleum, minerals, feed grains
Crude steel: 899,750 metric tons produced (1976), 100 kg
per capita
Electric power: 4,800,000 kW capacity (1977); 18 billion
kWh produced (1977), 1,945 kWh per capita
Exports: $2,756 million (f.o.b., 1977); principal items—
tobacco, cotton, fruits, textiles
Imports: $6,853 million (c.i.f., 1977); principal items—
machinery and automotive equipment, petroleum and —
petroleum products, manufactured consumer goods, chemi-
cals, meat and live animals
Major trade partners: (1976)—41.6% EC, 9.2% CEMA
countries, 8.0% other European countries, 16.6% U.S.
Aid: economic (authorized)—U.S., $139 million
(FY70-76); other Western bilateral (ODA and OOF), $649
million (1970-76); military—U.S., $672 million (FY70-76)
Budget: (1978) expenditures $8.2 billion, revenues $6.8
billion
Monetary conversion rate: 1 drachma=US$0.027 (1977
average)
Fiscal year: calendar year','bce90468afda3548e3c16d8374357cc64c860a81e739989d727ad4bf3fb9e334','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d6c54a2a7401b2b335685686a27b1591c147d2969e1bf967714de3aa38743fc',1967,'GL','Greenland','economy',191,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing;
garden produce
Fishing: catch 44,675 tons (1976); exports $39.8 million
(1976)
Major industries: mining, slaughtering, fishing, sealing --
Electric power: 57,500 kW capacity (1977); 120 million
kWh produced (1977), 2,355 kWh per capita
Exports: $85.4 million (f.0.b., 1976); fish and fish
products, metallic ores and concentrates
Imports: $128.7 million (c.i.f., 1976); petroleum and
’ petroleum products, machinery and transport equipment,
food products
Major trade partners: (1976) Denmark 76.4%, Finland
5.8%, U.S. 4.9%, West Germany 3.0%, France and Monaco
2.7%
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
i i Oe a ee a a i a i id i i ad |
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GREENLAND/GRENADA
Monetary conversion rate: 6.0032 Danish Kroner=US$1
(1977, average)
Fiscal year: calendar year beginning 1 January 1979','f3f8f1ce10a2817397ab43cbbefde44f53901f107fe8447b158ce94b12ebecf9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c21f2eafc6660e532fa8b24c95504e2d35e0cc65f166bcb338992404064fdd61',1967,'GD','Grenada','economy',195,'GDP: $54 million (in current prices, 1977), $500 per
capita; real growth rate 1977, 5.8%
Agriculture: main crops—spices, cocoa, bananas |
Electric power: 7,000 kW capacity (1977); 25° million
kWh produced (1977), 230 kWh per capita
Exports: $13 million (f.o.b., 1977); nutmeg, cocoa beans,
bananas, mace
Imports: $32 million (c.if., 1977); food, machinery,
building materials
Major trade partners: exports—33% U.K., 19% West
Germany, 13% Netherlands; imports—27% West Indies,
27% U.K., 9% U.S. (1976)
Aid: economic—bilateral commitments, including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $37.5 million;
from OPEC, $1.2 million; no military aid.
81
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GRENADA/GUADELOUPE
Budget: (est. 1978) revenues, $18 million; expenditures,
$28 million
Monetary conversion rate: 2.70 East Caribbean dollars=
US$1
Fiscal year: calendar year','1229d93112a4ff360fec90b9c6f7b1ca8ab5ca7457e7ddbd4595d7836c7c1e7b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6e3a52120afe4885234096c0d6f871749e9dec3102759dbafe9831f5557af14',1967,'GP','Guadeloupe','economy',199,'GDP: $470 million (1975), $1,340 per capita; real growth
‘rate (1975) 1.4%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar milling
and rum distillation :
Electric power: 50,000 kW capacity (1977); 200 million
kWh produced (1977), 610 kWh per capita
Exports: $90 million (f.o.b., 1976); sugar, fruits- and
vegetables, bananas
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GUADELOUPE/GUATEMALA
Imports: $309 million (c.i.f., 1976); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Major trade partners: exports—71%, France, 17% U.S.,
7% Germany, 5% other; imports—70% France, 9% U.S., 3%
Germany, 3% Netherlands Antilles, 3% Netherlands, 12%
other (1968)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from Western (non-US) countries, $1.2 billion; no
military aid
Monetary conversion rate: 4.75 French francs=US$1
(1976)
Fiscal year: calendar year','072ffb023249c772c17b102f354ac8193122844d52bc64a73d4f2a03377e84a9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2728929c7e88f823838044c13968ec8deee8b7718d5a1e73189f50a0ba244f88',1967,'MX','Mexico','economy',202,'GNP: $5,445 million (1977 est.), $880 per capita; 77%
private consumption, 6% government consumption, 19%
domestic investment (1977), —2% net foreign balance
(1976); average annual real growth rate (1971-77), 5.8%
Agriculture: main products—coffee, cotton, corn, beans,
sugarcane, bananas, livestock; caloric intake, 2,200 calories
per day per capita (1967)
Fishing: catch 3,653 metric tons (1976); exports $2.6
million (1973), imports $0.7 million (1973)
Major industries: food processing, textiles arid clothing,
furniture, chemicals, nonmetallic minerals, metals
Electric power: 365,000 kW capacity (1977); 1.5 billion
kWh produced (1977), 240 kWh per capita
Exports: $782 million (f.0.b., 1976); coffee, cotton, sugar,
bananas, meat
Imports: $839 million (c.i.f., 1976); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels
Major trade partners: exports (1974)—34% US., 28%
CACM, 11% West Germany, 5% Japan; imports (1974)—
31% U.S., 17% CACM, 12% Venezuela, 9% Japan, 8% West
GDP: $74.2 billion (1977 prelim.), $1,150 per capita; 68%
private consumption, 12% public consumption, 12% private
investment, 8% public investment (1977); net foreign
balance —0%; real growth rate 1977, 3.2%
Agriculture: main crops—corn, cotton, wheat, coffee,
sugarcane, sorghum, oilseeds, pulses, and vegetables; general
self-sufficiency with minor exceptions in meat and dairy ~
products; caloric intake, 3,110 calories per day per capita
- (1968)
Fishing: catch 562,106 metric tons (1977); exports valued
. at $151.3 million, imports at $17.8 million (1975)
Major industries: processing of food, beverages, and
tobacco; chemicals, basic metals and metal products,
petroleum products, mining, textiles and clothing, and
transport equipment :
Crude steel: 9.0 million metric tons capacity (1977); 5.5
million metric tons produced (1977)
Electric power: 13,900,000 kW capacity (1977); 50.1
billion kWh produced (1977), 780 kWh per capita
Exports: $4,166 million (f.0.b., 1977); cotton, coffée,
nonferrous minerals (including lead and zinc), sugar, shrimp,
petroleum, sulfur, salt, cattle and meat, fresh fruit, tomatoes,
machinery and equipment
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
EN ee ee ae ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MEXICO/MONACO
Imports: $5,489 million (c.i.f., 1977); machinery, equip-
ment, industrial vehicles, and intermediate goods
Major trade partners: exports—63% U.S., 5% EC, 2%
Japan (1977); imports—64% U.S., 15% EC, 5% Japan
Aid: economic—(iricluding Ex-Imp Credits) extensions
(1970-76), from U.S. $804 million; from Communist
countries, $12 million; from other Western (non-U.S.)
countries, $1,106.5 million
Budget: 1978 federal, revenues $434 billion pesos,
expenditures $634 billion pesos
Monetary conversion rate: floating
Fiscal year: calendar year','15b192b3796ead1b7d4f1f48ef277767f3246d29e98c940410276441b196f077','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe07b7e38c2a8ea9d4fa17ed3c4bd5debdc2a3f526706ea19f8b3a90b08ea7e8',1967,'GW','Guinea-Bissau','economy',206,'GDP: $112 million (est. 1975), $230 per capita
Agriculture: main crops—palm oil, root crops, rice,
coconuts, peanuts
86
Electric power: 11,000 kW capacity (1977); 17 million
kWh produced (1977), 30 kWh per capita
Exports: $11 million (f.o.b., 1977); principally peanuts,
coconuts, shrimp, fish, wood
Imports: $31 million (c.if., 1977); foodstuffs, manufac-
tured goods, fuels, transport equipment
Major trade partners: mostly Portugal, also immediate
neighbors
Monetary conversion rate: using Portuguese currency;
40.643 escudos=US$1 (November 1977)
Fiscal year: probably is the calendar year','c68d8ed8c581480876df772bb0de5f307e985c77ca78841788b868c0aad6f810','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53af4c47af313dfb4b5c96ebb0e408b8fe41e7d1bc4adcd47863a40b1344da4c',1967,'PH','Philippines','economy',210,'GDP: $9.5 billion ( 1976, in 1976 prices), $2,130 per
capita (est.); average real growth~4.8% (1970-75)
Agriculture: agriculture occupies a minor position in the
economy; main products—rice, vegetables, dairy products;
less than 20% self-sufficient; food shortages—rice, wheat
Major industries: textiles and clothing, tourism, plastics,
electronics, light metal products, food processing
Shortages: industrial raw materials, water, food
Electric power: 3,127,000 kW capacity (1977); 8,375
million kWh produced (1977), 1,880 kWh per capita
Exports: $9.7 billion (f.0.b., 1977), including $1.4 billion
reexports; principal products clothing, plastic articles,
textiles, electrical goods, wigs, footwear, light metal
manufactures
Imports: $10.5 billion (c.if., 1977)
Major trade partners: (1977) exports—38.7% U.S., 10.5%
West Germany, 8.7% U.K.; imports—23.7% Japan, 16.6%
China, 12.5% USS.
Budget: (77/78) $1.82 billion
Monetary conversion rate: HK$4.62=US$1 (December
1977) \\
Fiseal year: 1 April-31 March
Agriculture: main crops—rice, vegetables; food short-
ages—rice, vegetables, meat; depends mostly on imports for
food requirements
Major industries: textiles, fireworks
Electric power:-116,000 kW capacity (1977); 210 million
kWh produced (1977), 840 kWh per capita
Exports: $185 million (f.0.b., 1976); textiles and clothing,
foodstuffs
Imports: $160 million (c.if., 1976)
Major trade partners: exports—23% West Germany, 17%
France, 10% U.K.; imports—68% Hong Kong, 24% China
(1976)
Monetary conversion rate: 5.4 patacas=US$1 (December
1975); pataca has been pegged to Hong Kong dollar starting
in 1977
Fiscal year: calendar year
GNP: $20.5 billion (1977), $460 per capita; 6.3% real
growth, 1976
Agriculture: main crops—rice, corn, coconut, sugarcane,
bananas, abaca, tobacco ‘
Fishing: catch 1.4 million metric tons (1976)
Major industries: mining, agricultural processing, textiles,
chemicals and chemical products
Electric power: 4,186,000 kW capacity (1977); 15.2
billion kWh produced (1977), 335 kWh per capita
Exports: $3,151 million (f.0.b., 1977); coconut products,
sugar, logs and lumber, copper concentrates, bananas,
garments, nickel, abaca
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Imports: $3,915 million (f.o.b., 1977); petroleum, indus-
trial equipment, wheat
Major trade partners: (1977) exports—35% U.S., 23%
Japan; imports—25% Japan, 20% USS.
Aid: commitments 1970-76: U.S. economic, $467.3 mil-
lion, military, $204.8 million; Western (except U.S.), $996.3
million; Eastern Europe, $35.5 million; OPEC, $61.0 million
Budget: (CY78) revenues $3.8 billion, expenditures $4.6
billion, deficit $0.8 billion; 11% military, 89% civilian
Monetary conversion rate: 7.87 pesos=US$1, July 1978
Fiscal year: calendar year','0587c6499389c029efede3bb8589f09c149810670fecdd7fb9d6fd0587e00994','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43da75cf338be9f47316a4f821ff29c83b214ec3ff1866d228a16ad47ad1f6d3',1967,'HU','Hungary','economy',215,'GNP: $29.4 billion in 1977 (at 1977 prices), $2,750 per
capita; 1977 growth rate, 4.8%
Agriculture: normally self-sufficient; main crops—corn,
wheat, potatoes, sugar beets, wine grapes; caloric intake
3,140 calories per day per capita (1970)
Major industries: mining, metallurgy, engineering indus-
tries, processed foods, textiles, chemicals (especially pharma-
ceuticals) .
Shortages: metallic ores (except bauxite), copper, high
grade coal, forest products, crude oil
Crude steel: 3.72 million metric tons produced (1977),
350 kg per capita
Electric power: 5,100,000 kW capacity (1977); 23.4
billion kWh produced (1977), 2,190 kWh. per capita
Exports: $7,959 million (f.o.b., 1977); 27% machinery,
°18% industrial consumer goods, 30% raw materials and
semimanufactures, 23% food and raw materials for the food
industry, energy sources 2% (distribution for 1977)
Imports: $8,558 million (c.i.f., 1977); 21% machinery, 8%
industrial consumer goods, 49% raw materials and semi-
manufactures; 11% food and raw materials for the food
industry, energy sources 11% (distribution for 1977)
Major trade partners: $16,517 million (1977); 57% with
Communist countries, 43% with non-Communist countries
Aid: U.S.S.R.—$338 million extended (1956-66), $10
million extended in 1967, $167 million extended in 1968; to
jess developed non-Communist countries—$764 million
(1954-77)
Monetary conversion rate: 37.83 forints=US$1 (commer-
cial); 18.90 forints=US$1, noncommercial (June 1978)
Fiscal year: same as calendar year; economic data
reported for calendar years','3e85b6f21e9157ec70eb4e69c8286867e6bed6e701b4e63363434ad724ae71e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44905fd2eb473d8fd57dfc4c7ed324745cef8106ee1b2e3dba6dfc0371818f2a',1967,'IS','Iceland','economy',219,'GNP: $1,415 million (1976), $6,350 per capita; 61.7%
consumption, 28.3% investment, 10.6% government, 1.9%
change in stocks; —2.5% net foreign balance (1977); 1977
growth rate 4.8%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips;
food shortages—grains, sugar, vegetable and other fibers;
caloric intake, 2,900 calories per day per capita (1964-66)
Fishing: landed 1,375,900 metric tons; exports $233.7
million (1977)
Major industries: fish processing, aluminum smelting,
diatomite production, hydro-electricity
93
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ICELAND/INDIA
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 653,000 kW capacity (1977); 2.5 billion
kWh produced (1977), 11,210 kWh per capita
Exports: $512.3 million (f.0.b., 1977); fish and fish
products, animal products, aluminum, diatomite
Imports: $608.3 million (c.if., 1977); machinery and.
transportation equipment, petroleum, foodstuffs, textiles
Major trade partners: (1977) exports—U.S. 30%, EC 31%,
U.S.S.R. 7%; imports—EC 47%, U.S. 6.5%, U.S.S.R. 9%
Aid: economic authorizations: U.S., $10 million (FY70-76)
Budget: (1977, approved) expenditures $448 million,
revenues $452 million
Monetary conversion rate: 198.9 kronur=US$1 (1977);
182.2 kronur=US$1 (1976)
Fiseal year: caleudar year','1e579f54d69becbb68098798e9ff0c629156bd5d7b7f3458f05ad5ba0800567a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('628ed94a67280cc7132f15a9acaf0941746de7da55548b7f711a9266c8925a07',1967,'IN','India','economy',223,'GNP: $88 billion (CY77 at current prices), $140 per
capita; real growth 6.0% in FY78
Agriculture: main crops—rice, other cereals, pulses,
‘oilseeds, cotton, jute, sugarcane, tobacco, tea, and coffee
‘Fishing: catch 2.5 million metric tons (FY78); exports
* $145 million (FY75), imports $3.3 million (1974).
Major industries: textiles, food processing, steel, machin-
ery, transportation equipment, cement, jute manufactures
Crude steel: 9.83 million metric tons of ingots (CY77)
Electric power: 24,910,000 kW capacity (1977); 99.6
billion kWh produced (1977), 155 kWh per capita
Exports: $6.1 billion (f.0.b., 1977); engineering goods,
textiles and clothing, tea
Imports: $6.8 billion (cif., 1977); machinery and
transport equipment, petroleum, grains and flour, fertilizers
Major trade partners: U.S., U.K., U.S.S.R., Japan
Budget: (FY79) central government receipts, $21.0 billion;
expenditures, $22.8 billion
Monetary conversion rate: 8.1 rupees=US$1 (August
1978)
Fiscal year: fiscal year ends 31 March of stated year','4f865dbfcb1cfb221dba053712c3dc3debb16765bf299c29f37471f858f280ba','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9316f2b75ad8cd7c84aa01322c5f9084fe37c95e54ee698140efde96c2f057b',1967,'IL','Israel','economy',229,'GNP: $13.3 billion (1977, in 1977 prices), $3,720 per
capita; 1977 growth of real GNP 1.0%
Agriculture: main products—citrus and. other fruits,
vegetables, beef and dairy products, poultry products
. Major industries: food processing, diamond cutting and
polishing, textiles and clothing, chemicals, metal products,
transport equipment, electrical equipment, miscellaneous
machinery, rubber and plastic products, potash mining
Electric power: 2,800,000 kW capacity (1978); 13.5
billion kWh produced (1978), 3,700 kWh per capita
Exports: $3.4 billion (f.0.b., 1977); major items—polished
diamonds, citrus and other fruits, textiles and clothing,
processed foods, fertilizer and chemical products; tourism is
leading foreign exchange earner
Imports: $5.4 billion (f.0.b., 1977); major items—military
equipment, rough diamonds, chemicals, machinery, iron and
steel, cereals, textiles, vehicles, ships, and aircraft
102
Major trade partners: exports—EC, U.S., U.K., Japan,
Hong Kong, Switzerland; imports—EC, U.S., U.K., Switzer-
land, Japan
Budget: FY ending 81 March 1979—$11 billion (con-_
verted at 18.5 Israeli pounds=US$1)
Monetary conversion rate: the Israeli pound was allowed
to float on 31 October 1977 and as of 12 October 1978 it was
roughly 18 Israeli pounds=US$1
Fiscal year: 1 April-31 March','3433769fe8b04512fadbdbcc4b72aea5ead7e538082c14dafc38b5f5a73cfe28','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c47efb7582f632e359124a0deb49db7db2cbe5fb7699a4af9ce8da027af78fcb',1967,'IT','Italy','economy',233,'GDP: $196 billion (1977), $3,470 per capita; 65.5%
private consumption, 19.8% gross fixed investment, 14.0%
government, 1.4% inventory change, net foreign balance
—0.7%; 1977 growth rate 1.7% (1970 constant prices)
Agriculture: important producer of fruits and vegetables;
main crops—cereals, potatoes, olives; 95% self-sufficient;
food shortages—fats, meat, fish, and eggs; daily caloric
intake, 3,835 calories per capita (1974)
Fishing: catch 337,994 metric tons (1977); exports $43
million (1977), imports $386 million (1977)
Major industries: machinery and transportation equip-
ment, iron and steel, chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 23.3 million metric tons produced (1977),
410 kg per capita
103
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ITALY/IVORY COAST
Electric power: 46,000,000 kW capacity (1977); 166.5
billion kWh produced (1977), 2,985 kWh per capita
Exports: $45.0 billion (f.o.b., 1977); principal items—
machinery and transport equipment, textiles, foodstuffs,
chemicals, footwear
Imports: $47.6 billion (c.if., 1977); principal items—
machinery and transport equipment, foodstuffs, ferrous and
nonferrous metals, wool, cotton, petroleum
Major trade partners: (1977) 48.5% EC-nine (20% West
Germany, 16% France, 5% U.K., 4% Netherlands, 3%
Belgium-Luxembourg); 7% U.S.; 3% U.S.S.R. and 2% other
Communist countries of Eastern Europe
Aid: donor—bilateral economic aid authorized (ODA and
OOF), $4,991 million (1970-76)
Monetary conversion rate: Smithsonian rate as of
December 1973, 650.4 lire=US$1; average of Friday closing
rates in 1977—882 lire=US$1
Fiscal year: calendar year
GDP: $6.7 billion (1978 est.), $940 capita; average annual
growth rate in constant prices, 7.5% (1975-78)
Agriculture: commercial—coffee, cocoa, wood, bananas,
pineapples, palm oil; food crops—corn, millet, yams, rice;
other commodities—cotton, rubber, tobacco, fish; self-
sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 76,995 metric tons (1976); exports $12.8
million (1975), imports $33.6 million (1975)
Major industries: food and lumber processing, oil
refinery, automobile assembly plant, textiles, soap, flour
mill, matches, three small shipyards, fertilizer plant, and
battery factory
Electric power: 525,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 170 kWh per capita
Exports: $2.5 billion (f.o.b., 1978 est.); cocoa (80%),
coffee, tropical woods, cotton, bananas, pineapples, palm oil
Imports: $1.9 billion (f.0.b., 1978 est.); manufactured
goods and semi-finished products (50%), consumer goods
(40%), raw materials and fuels .(10%)
Major trade partners: France and other EC countries
about 65%, U.S. 13%, Communist countries about 1%
Aid: economic—(1970-76) Western (non-U.S.), $818.16
million; U.S., $91.0 million; Communist countries, $0.2
million
Budget: 1978, proposed—revenues $1.7 billion, current
expenditures $1.0 billion, investment expenditures $900
million
Monetary conversion rate: about 245.67 Communaute
Financiere Africaine francs=US$1 (1977)
Fiseal year: calendar year','ecac54d3906c5c073aa67f9b4988fa7c6a40d5361d75104e87586e9fbfb2cbc4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e55b393bf033a2454e7b3e0c1776ca99ad953136d769c1a764d84930cb0b500',1967,'JM','Jamaica','economy',237,'GDP: $3.4 billion (1977), $1,610 per capita; real growth
rate 1977, —4.0%
Agriculture: main crops—sugarcane, citrus fruits, ba-
nanas, pimento, coconuts, coffee, cocoa
Major industries: bauxite mining, textiles, food process-
ing, light manufactures, tourism
Electric power: 850,000 kW capacity (1977); 2.6 billion
kWh produced (1977), 1,230 kWh per capita
Exports: $745 million (f.0.b., 1977); alumina, bauxite,
sugar, bananas, citrus fruits and fruit products, rum, cocoa
Imports: $863 million (c.i.f., 1977); fuels, machinery,
transportation and electrical equipment, food, fertilizer
Major trade partners: exports—U.S. 44%, U.K. 20%,
Norway 11%, Canada 8%; imports—U.S. 36%, U.K. 10%,
Canada 6% (1977)
Aid: economic—bilateral commitments including Ex-Im
(FY70/76) from U.S., $127.2 million; from other Western
countries, $197.1 million; from OPEC, $9 million; from
Communist countries, $9.7 million; no military aid
Budget: (1978/79)—revenue $803 million, expenditure
$1,119 million —
Monetary conversion rate: 1 Jamaican dollar=US$$0.645
Fiscal year: 1 April-31 March
GNP: $685 billion (1977, at 268.2 yen=US$1); $6,010 per
capita (1976); 53% personal consumption, 33% investment,
9% government current expenditure; real growth rate 5.2%
(1977); average annual growth rate (1974-76), 2.4%
Agriculture: land intensively cultivated—rice, sugar,
vegetables, fruits, 72% self-sufficient in food (1974); food
107
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
JAPAN/JORDAN
shortages—meat, wheat, feed grains, edible oi] and fats;
caloric intake, 2,502 calories per day per capita (1974)
Fishing: catch 10.6 million metric tons (1976)
Major industries: metallurgical and engineering indus-
tries, electrical and electronic industries, textiles, chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 102 million metric tons produced (1977)
Electric power: 123,793,000 kW capacity (1977); 537
billion kWh produced (1977), 4,690 kWh per capita
Exports: $79.3 billion (f.o.b., 1977); 68% machinery and
equipment, 18% metals and metal products, 6% textiles
Imports: $62.0 billion (f.0.b., 1977); 44% fossil fuels, 7%
metals and metal products, 14% foodstuffs, 7% machinery
and equipment
Major trade partners: exports—25% U.S., 6% Communist
countries, 11% EC, 3% Australia, 41% other; imports—18%
U.S., 8% Australia, 6% EC, 5% Communist countries
Aid: Japanese official foreign economic aid disbursements
3975, $1,148 million
Budget: revenues $120 billion, expenditures $177 billion,
deficit $57 billion (general account for fiscal year ending
March 1979)
Monetary conversion rate: 190.2 yen=US$1 (September
1978 average rate), floating since February 1973
Fiscal year: 1 April-31 March','6312d437ceed4232b892fe53cb4d6cce552cf8b3dd27c7a8e58d8b997e81198a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a147473a80d74e9e8694247574a8059be0c48cf458b529ad409d3b124eab041e',1967,'JO','Jordan','economy',241,'GNP: $1.9 billion (East Bank only, 1977 est.), $870 per
capita; real growth rate (1973-77), 14% .
Agriculture: main crops—fruits, vegetables, olive oil,
wheat; not self-sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining,
and cement production, light manufacturing
Electric power: 250,000 kW capacity (1978); 700 million
kWh produced (1978), 200 kWh per capita, East Bank only
Exports: $249 million (f.o.b., 1977); fruits and vegetables,
phosphate rock; Communist share 5% of total (1977)
Imports: $1,376 million (c.i.f., 1977); petroleum products,
textiles, capital goods, motor vehicles, foodstuffs; Communist
share 9% of total (1977)
Aid: economic—OPEC (ODA) (1973-76), $1,143.1 mil-
lion; U.S.. (1970-76), $486.3 million; Communist countries
(1970-76), $26.5 million; Western countries (1970-76),
$213.4 million; military—U.S. (1970-76), $459.6 million
Budget: (1977 est.)—expenditures $1,005 million (non-
military, $800 million, military $205 million), development
$412 million; deficit $45 million
Monetary conversion rate: 1 Jordanian dinar=US$3.04,
freely convertible (1977 average); 0.3300 Jordanian din-
ar=US$1 (August 1978); 1 Jordanian dinar=US$3.32
Fiscal year: calendar year
GNP: less than $500 million (1971), probably less than $50
per capita (1977)
Agriculture: mainly subsistence except for rubber planta-
tions; main crops—rice, rubber, corn; food shortages—rice,
meat, vegetables, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood
products
Shortages: fossil fuels ;
Electric power: 120,000 kW capacity (1977), 260 million
kWh produced (1977), 30 kWh per capita
Exports: probably less than $1 million est. (1977); natural
rubber, rice, pepper, wood
Imports: probably less than $20 million (1976); food, fuel,
machinery
Trade partners: exports—China; imports—China, North
Korea °
Aid: commitments (1970-76): U.S. economic, $652 mil-
lion; military, $1,260 million; Western (except U.S.), $10.8
million; Eastern Europe, $17 million; U.S.S.R., $25 million;
China, $90 million; military—U.S., $1,334 million (FY46-76)
Budget: no budget data available since Communists took
over government
Monetary conversion rate: no currency in use
Fiscal year: calendar year','7f1cfc45b38a90a04e5e789e883458635a59433c8d195ad9ac30da7f776aa26b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d317eba3143f9e47c84ae5a254e774c4a19494b5dc05f179b8e7071f3214a8c',1967,'KE','Kenya','economy',245,'GDP: $3,905 million at current prices (est. 1977), $270 per
capita; real average annual growth rate, 4.8% (1970-77)
Agriculture: main cash crops—coffee, sisal, tea, pyre-
thrum, cotton, livestock; food crops—corn, wheat, sugar-
cane, rice, cassava; largely self-sufficient in food
Fishing: 40,883 metric tons (1976)
Major industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, agricultural processing,
cigarettes, flour), oil refining, cement
Electric power: 420,000 kW capacity (1977); 1.3 billion
kWh produced (1977), 90 kWh per capita
Exports: $1,361 million (f.o.b., 1977); coffee ($524
million), tea, livestock products, pyrethrum, soda ash,
wattle-bark tanning extract
Imports: $1,290 million (c.i.f., 1977); machinery, trans-
port equipment, crude oil, paper and paper products, iron
and steel products, and textiles
Major trade partners: EC, Japan, Iran, U.S., Zambia,
Uganda, Tanzania
Budget: (FY77/78) current revenues $1,046 million;
current expenditures $918 million; development expendi-
tures $440 million
Monetary conversion rate: 7.94 Kenya shillings=US$1
Fiscal year: 1 July-30 June
GNP: $10.0 billion (1976 in 1975 dollars), $590 per capita
Agriculture: main crops—corn, rice, vegetables; food
shortages—meat, cooking oils; production of foodstuffs
adequate for domestic needs at low levels of consumption
Major industries: machine building, electric power,
chemicals, mining, metallurgy, textiles, food processing
Shortages: complex machinery. and equipment, coking
coal, petroleum
Crude steel: 2.8 million metric tons produced (1976), 106
kg per capita
Electric power: 4,750,000 kW capacity (1977); 28 billion
kWh produced (1977), 1,570 kWh per capita
Exports: $655 million (1977); minerals, chemical, and
metallurgical products
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
:
ue Ln ALAR ROR CACR AEM.
ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Imports: $777 million (1977); machinery and equipment,
petroleum, foodstuffs, coking coal
'' Major trade partners:-total trade turnover $1.4 billion;
38% with non-Communist countries, 62% with Communist
countries (1977)
Aid: economic and military aid from the U.S.S.R. and
Budget: revenues $71 million; expenditures $53.8 million
(1976 provisional)
Monetary conversion rate: 92.84 Rwanda francs=US$1
(official) since January 1974
Fiscal year: calendar year','114327bbd1f213c2865d580390bb9e15882d763e9dafbb8a1495e9966758ed83','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e84944129eef15b211f98feb997bb1e155998c3bf2104c0538d8b42962f0315',1967,'SA','Saudi Arabia','economy',249,'GNP: $13.9. billion (1976), $18,080 per capita est.
Agriculture: virtually none, dependent on imports for
food; approx. 75% of potable water must be distilled or
imported
Major industries: crude petroleum production average
for 1977, 1.92 million b/d; government revenues from taxes
and royalties on production, refining, and consumption, $8.5
billion, preliminary est. for 1976; refinery production 132
million bbls (1976), average b/d refinery capacity equaled
645,000 bbls at end of 1976; other major industries include
processing of fertilizers, chemicals; building materials; flour
Electric power: 2,200,000 kW capacity (1978); 7 billion
kWh produced (1978), 5,815 kWh per capita
Exports: $9.8 billion (f.0.b., 1977), of which petroleum
accounted for about 98%; nonpetroleum exports are mostly
reexports, $727 million (1976 est.)
Imports: $4.8 billion (c.i.f., 1977 est.); major suppliers—
US., Japan, U.K., West Germany
Aid: Western (non-U.S.) countries (1970-76), $2.0 million
Budget: (FY77/78) $7.9 billion revenues
Monetary conversion rate: 1 Kuwaiti dinar=US$3.68
(1978)
Fiscal year: 1 July-30 June
GNP: $250 million, $70 per capita (1976 est.)
Agriculture: main crops—rice (overwhelmingly domi-
nant), corn, vegetables; formerly self-sufficient; food short-
ages (due in part to distribution deficiencies), including rice
Major industries: tin mining, timber, tobacco, textiles,
electric power
Shortages: capital equipment, petroleum, transportation
system, trained personnel
Electric power: 61,000 kW capacity (1977); 295 million
kWh produced (1977), 80 kWh per capita
Exports: $8.5 million (f.o.b., 1977 est.); electric power,
forest products, tin concentrates; coffee, undeclared exports
of opium and tobacco
Imports: $55 million (c.i.f., est. 1977); rice and other
foodstuffs, petroleum products, machinery, transportation
equipment
Major trade partners: imports from Thailand, U.S.S.R.,
Japan, France, China, Vietnam; exports to Thailand and
Malaysia; trade with Communist countries insignificant;
Laos was once a major transit point in world gold trade,
value of 1973 gold reexports $55 million
Aid: economic—Communist: Eastern Europe, $4.0 mil-
lion (1974-75); U.S.S.R., $66 million committed (1975-76),
China, $42 million committed (1975-76); OPEC, $1.0
million (1975); Western: $151.4 million (1970-76); U.S.,
economic, $272.3 million (1970-75), military, $1,119.5
million (1970-75) : ,
Budget: (1973-74) receipts, 13.3 billion kip; expenditures,
36.0 billion kip; deficit 22.7 billion kip (provisional totals),
45% military, 55% civilian; no data available since
Communists fully took over government in 1975
Monetary conversion rate: 400 Liberation Kips
(K)=US$1.00, as of 5 May 1978
Fiscal year: 1 July-30 June
GNP: $4.0 billion (1976), $25,320 per capita
Agriculture: farming and grazing on small scale; commer-
cial fishing increasing in importance; most food imported;
‘rice and dates staple diet
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
OR AR oe RA A A on LARA AAA A AA A
ee or - 20
a Te ae TE ee a A aa eS a
kk
eS ee ae EE Sa OE aE ee Nee
ee a Se ee re ae
a ee i i i a
ee A i ad
ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
QATAR/REUNION
Major industries: oil production and refining; crude oil
production from onshore and offshore averaged 435,141 b/d
(1977); 100% takeover was announced in October 1976 of
the Qatar Petroleum Company, still negotiating with Qatar
Shell about offshore fields; oil revenues accrued $2 billion in
1976, representing 95% of government/royal family income;
major development projects include $7 million harbor at Ad
Dawhabh, fertilizer plant, 2° desalting plants, refrigerated
storage for fishing, and a cement plant
Electric power: capacity 560,000 kW (1977); 1.0 billion .
kWh produced (1977), 6,175 kWh per capita
Exports: crude oil dominates; exports $2.2 billion (1976)
of which petroleum is $2 billion
Imports: $817 million (c.i.f., 1976)
Aid: economic—(1970-76), Western (non-U.S.) countries,
$2.2 million
Budget: (1977) revenue $2.0 billion, expenditure $1.83
billion
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25
(1977)
Fiscal year: 1 April-31 March
GDP: $58 billion (1977), $9,210 per capita; annual growth
in real non-oil GNP approx. 15% (1973/77 average, non-oil)
Agriculture: dates, grains, livestock; not self-sufficient in
food
Major industries: petroleum production 8.6 million b/d
_ (1976); payments to Saudi Arabian Government, $31 billion
(1976 est.); cement production and small steel-rolling mill
and oil refinery; several other light industries, including
factories producing detergents, plastic products, furniture,
etc.; PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a major
fertilizer plant
Electric power: 4,100,000 kW capacity (1977); ‘8 billion
kWh produced (1977), 1,020 kWh per capita
Exports: $41.2 billion (f.0.b., 1977); 99% petroleum and
petroleum products
Imports: $17.4 billion (c.i.f., 1977); manufactured goods,
transportation equipment, construction materials, and proc-
essed food products
Major trade partners: exports—U.S., Western Europe,
Japan; imports—U.S., Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.28 as of
February 1976 (linked to SDR, freely convertible)
Fiscal year: follows Islamic year; the 1973-74 Saudi fiscal
year covers the period 30 June 1973 through 1 July 1974','8b2080b80ab4e815a9614e6062dcb23022fda5459b805db17c4c0eab30e518a5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e337da6e18c5d296d3737d17882e951e783bd68b94c001f7218b7a6e7a223f0',1967,'LB','Lebanon','economy',253,'Agriculture: fruits, wheat, corn, barley, potatoes, tobacco,
olives, onions; not self-sufficient in food
Major industries: service industries, food processing,
textiles, cement, oil refining, chemicals, some metal fabricat-
ing, tourism
Electric power: 540,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 490 kWh per capita
Exports: $632 million (1977)
Imports: $1.5 billion (1977)
Budget: (1977) expenditures $539 million, revenues $332
million
Monetary conversion rate: 2.95 Lebanese pounds=
US$1 as of August 1978
Fiscal year: calendar year','c1c5ed04cc395cac03dfe967d4258fc3ea39f80ef48b7e58d65fc06bbcf6328f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09cae56d8f8f4fa374480d7d8d6d47f3e5cd88b8f220ce55b838c128c10af52b',1967,'LS','Lesotho','economy',257,'GNP: $315 million (FY74 est.), $270 per capita
Agriculture: exceedingly primitive, mostly subsistence
farming and livestock; principal crops are corn, wheat,
pulses, sorghum, barley
Major industries: none
Electric power: approximately 20 million kWh imported
from South Africa (1977)
Exports: labor to South Africa (remittances $120 million
est. in 1976); $12.4 million (est. f.0.b., 1976), wool, mohair,
wheat, cattle, diamonds, peas, beans, corn, hides, skins
Imports: $154.3 million (est. c.if,, 1976); mainly corn,
building materials; clothing, vehicles, machinery, POL
Major trade partner: South Africa
Aid: economic—Western (non-U.S.) countries (1970-76),
$95.0 million; U.S. (1970-76), $25.7 million; OPEC (ODA)
(1973-76), $1.0 million
Budget: (FY76) revenues, $63 million; current expendi-
tures, $38 million; development budget, $25 million
- Monetary conversion rate: Lesotho uses the South
African rand; 1 SA rand=US$1.15 (as of March 1978)
Fiscal year: 1 April-31 March','d860e95706adaea55fda67a5bf780ab04503dd4790c2a96a3e80cd0bb45f019c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f45896454ae9e9f28afaa6b391a068c815640c57ab21d7ff4b8b632caf82d34c',1967,'LR','Liberia','economy',261,'GDP: $923-million (1976 est.), $600 per capita; 4%
current annual growth rate (1967-76)
Agriculture: rubber, rice, oil palm, cassava, coffee, cocoa;.
imports of rice, wheat, and live cattle and beef are necessary .
for basic diet
Fishing: catch 23,000 metric tons
Industry: rubber processing, food processing, construction
materials, furniture, palm oil processing, mining (iron ore,
diamonds), 10,000 b/d oil refinery
120
Electric power: 327,000 kW capacity (1977); 980 million
kWh produced (1977), 620.kWh per capita
Exports: $460 million (f.0.b., 1976); iron ore, rubber,
diamonds, lumber and logs, coffee, cocoa
Imports: $399 million (c.i.f., 1976); machinery, transpor-
tation equipment, petroleum products, manufactured goods,
foodstuffs
Major trade partners: U.S., West Germany, Netherlands,
Italy, Belgium
Aid: economic—(1970-76), Western (non-U.S.), $229.5
million; U.S.,’ $107.2 million; military—U.S., $7.6 million
Budget: (FY77) revenues $167 million, expenditures $167
million; development budget $39 million
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: 1 July-30 June','0cf8c53fe3632acfbfb3d99dc7cc7b91504fe8193030eb0a962814d2449a02ea','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6fa7fb2b9331eabbcd08c0b70a762459894fff3eddb24b6121247a0e6ad3ba2',1967,'LY','Libya','economy',265,'GDP: $16.6 billion (1977-at current prices), $6,260 per.
capita
Agriculture: main crops—wheat, barley, olives, dates,
citrus fruits, peanuts; approaching self-sufficiency in food
Major industries: petroleum, food processing, textiles,
handicrafts
Electric power: 1,300,000 kW capacity (1977); 2.1 billion.
kWh produced (1977), 760 kWh per capita
Exports: $11.4 billion (f.0.b., 1977); over 99% petroleum
Imports: $5.8 billion (c.i.f., 1977)
Major trade partners: imports—Italy, West Germany,
U.S.; exports—Italy, West Germany, U.K., U.S., France
Monetary conversion rate: 1 Libyan pound=US$3.38
Fiscal year: ] January-31 December (beginning 1974)','0aad8719479ceff56d2ce30ea87194f73a9b0207d3dd5b837ac0604f5df9ca71','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc5289192361b3c21e7e3e129fe4c0602cd991b1d7006318bc3fb517879ea248',1967,'LI','Liechtenstein','economy',269,'Liechtenstein has a prosperous economy based primarily
on small-scale light industry and some farming. Textiles,
ceramics, precision instruments, pharmaceuticals, and
canned foods are the principal manufactures, intended
almost entirely for export. Industry accounts for 95 percent
of total employment. Livestock raising and dairying are the
main sources of income in the small farm sector. A major
source of income to the government is the sale of postage
stamps to foreign collectors, estimated at $6 million
annually. In addition, low business taxes and easy incorpo-
rated rules have induced between 20,000 and 30,000 holding
companies, so-called letter box companies, to establish
nominal offices in the principality. The average tax paid by
one of these companies is about $400 a year.
The Liechtenstein economy is tied closely to that of
Switzerland in a customs union. No national accounts data
are available.
GNP: $291 million (1977 provisional)
Major trade partners: exports (1975)—$202 million;
50.6% EFTA, 41.4% Switzerland, 26.7%. EEC; exports
(1977) —$273 million
Electric power: 23,000 kW capacity (1977); 56 million
kWh produced (1977), 2,240 kWh per capita; power is
exchanged with Switzerland, but net exports average 35
million kWh yearly
Budget: (1978 est.) revenues $104.1 million, expenditures
$75.2 million, surplus $28.9 million','90be9db8d1d9fa898a0357c611ba1536b1294a24911e478a207ffedc7e226228','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7e2f7a0d1d7d1d9a14cab0da6391a0caccb86955dcd23a0c4c8f13fd7182f9f',1967,'MG','Madagascar','economy',276,'GDP: $2.0 billion (1977), about $250 per capita; real
growth less than. 1% (1970-75)
126
Agriculture: cash crops—coffee, vanilla, cloves, sugar,
tobacco, sisal, rice, raphia; food crops—rice, cassava, cereals,
potatoes, corn, beans, ‘bananas, coconuts, and peanuts;
animal husbandry widespread; imports some rice, milk, and
cereal
Fishing: catch 54,950 metric tons (1976); exports $16.5
million (1974)
Major industries: agricultural processing (meat canneries,
soap factories, brewery, tanneries, sugar refining), light
consumer goods industries (textiles, glassware), cement plant,
auto assembly plant, paper mill, oil refinery
Electric power: 95,000 kW -capacity (1977); 465 million
kWh produced (1977), 60 kWh per capita
Exports: $294 million (f.0.b., 1977 est.); 30% coffee, 8%
vanilla, 7% sugar, 6% cloves; agricultural and livestock
products account for about 85% of export earnings
Imports: $318 million (c.i.f., 1977 est.); about 19%
consumer goods, 21% foodstuffs, 41% primary products
(crude oil, fertilizers, metal products), 19% capital goods
(1974)
Major trade partners: France (in 1974 accounted for 37%
of exports and 48% of imports), U.S., EC; trade with
Communist countries remains a minute part of total trade
Budget: (1977) revenues $331 million, expenditures $344
million
Monetary conversion rate: 248 Malagasy francs=US$1
Fiscal year: calendar year','ec960665226ff44933d29742866ae7d20bafc0a25c0a96877719914507a54283','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbeb989fcf6a6ebe3bae67b9d85de7c7ee2bafcc75fb52c74fcb98aac79bdac1',1967,'MW','Malawi','economy',280,'GDP: $683.1 million (1977), $130 per capita; real average
annual’ growth rate (1970-77) 8.6%
Agriculture: cash crops—tobacco, tea, sugar, peanuts,
cotton, tung, maize; subsistence crops—corn, sorghum,
millet, pulses, root crops, fruit, vegetables, rice
Electric power: 105,000 kW capacity (1977); 315 million
kWh produced (1977), 60 kWh per capita
Major industries: agricultural processing (tea, tobacco,
sugar), sawmilling, cement, consumer goods
Exports: $215.30 million (f.0.b., 1977 est.); tobacco, tea,
sugar, peanuts, cotton :
Imports: $256 billion (c.if., 1977 est.); manufactured
goods, machinery and transport equipment, building and
construction materials, fuel, fertilizer
Major trade partners: exports—U.K., U.S., South Africa,
Netherlands; imports—South Africa, U.K., Japan, U.S., FRG,
Netherlands :
Aid: economic—(1970-76) Western (non-U.S.) countries,
$256.1 million; U.S., $7.3 million
Budget: FY77/78 revenues $92 million; expenditures $86
million
Monetary conversion rate: 1 Malawi kwacha=US$1.16
Fiscal year: 1 April-3] March','3dd6110bbfb9d4dd34207e00a9066663ad9bab3cd96138a13bca6f2e32906738','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9e4c842d85f42bfe65c0809fd861a387dc942c0031d92836e7d7fc61a3ec4b6',1967,'MY','Malaysia','economy',284,'GNP:
Malaysia: $12.4 billion (1977), $990 per capita; average
annual real growth 7.8% (1970-76); 8.0% (1977)
Agriculture:
Peninsular Malaysia: natural rubber, oil palm, rice;
10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops—rubber, tim-
‘ber, coconut, rice; food deficit—rice
Sarawak: main crops—rubber, timber, pepper; food
- deficit—rice
Fishing: catch 516,903 metric tons (1976)
Major industries:
Peninsular Malaysia: rubber and oil palm processing
and manufacturing, light manufacturing industry, elec-
tronics, tin mining and smelting, logging and processing
timber ;
129
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
MALAYSIA/MALDIVES
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum production
and refining, logging
Electric power:
Peninsular Malaysia: 1,595,000 kW capacity (1977);
7.0 billion kWh .produced (1977), 655 kWh per capita
Sabah: 131,700 kW capacity (1977); 355 million kWh
produced (1977), 400 kWh per ‘capita
Sarawak: 91,000 kW capacity (1977); 250 million kWh
produced (1977), 215 kWh per capita ,
Exports: $6.1 billion (f.o.b., 1977); natural rubber, palm
oil, tin, timber, petroleum
Imports: $5.0 billion (c.i.f., 1977)
Major trade partners: exports—19% Singapore, 18% U.S.,
20% Japan; imports—21% Japan, 11% U.K.., 12% US., 9%','a250070db16c8450179a0daf878d28b414d9a6e0438c6400616fa932f638ff3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dc4ae3c1aac197922c3108812cc87cc39c870e757c8ebb85e968496a6b46925',1967,'SG','Singapore','economy',285,'Aid: U.S. economic 1970-76, $23.1 million; military $64.7
million; Western (except U.S.), $562.6 million; OPEC, 1974-
76, $186.5 million
Budget: 1978 revenues $3.4 billion; expenditures $4.6
billion; deficit $1.2 billion; 20% military, 80% civilian
Monetary conversion rate: 2.30 ringgits= US$1 (August
1978) |
Fiscal year: calendar year
GDP: $6.65 billion (1977), $2,830 per capita; 10.5%
average annual real growth (1966-77), 8% (1977)
Agriculture: occupies a position of minor importance in
the economy, self-sufficient in pork, poultry, and eggs, must
import much of its other food requirements; major crops—
rubber, copra, fruit and vegetables
Fishing: catch 14,350 metric tons (1977), imports—69,729
metric tons (1977) .
Major industries: petroleum refining, oil drilling equip-
ment, rubber processing and rubber products, processed
food and beverages, electronics, ship repair, entrepot trade,
financial services
Electric power: 1,390,000 kW capacity (1977); 5 billion
kWh produced (1977), 2,210 kWh per capita
- Exports: $8.2 billion (f.0.b., 1977); 40% reexports;
petroleum products, rubber, manufactured goods
Imports: $10.5 billion (c.i.f., 1977); 23% goods reexported;
major retained imports—capital equipment, manufactured
goods, petroleum
Major trade partners: exports—Malaysia, U.S., Japan,
Hong Kong, U.K., Indonesia; imports—Japan, Malaysia,
U.S., Saudi Arabia
Aid: Western (except U.S.) (1970-76), $172.8 million
committed; U.S. (1970-76), $1.9 million committed
Budget: (FY77/78) revenues $1.6 billion, expenditures
$2.6 billion, deficit $800 million; 12% military, 83% civilian
Monetary conversion rate: 2.30 Singapore dollars=US$1]
(July 1978)
Fiscal year: 1 April-31 March','4de0eca71477b91c8e95bd7d29e5557dbc24c6407ea28a4e8102a1e4ccd84ae3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ed67406c5d33c473f6a4b412ada341e8bb411b9375b7fc4284e26ad75dfa73e',1967,'MV','Maldives','economy',290,'GNP: $17.4 million (1974), $150 per capita
Agriculture: crops—coconut and millet; shortages—rice,
wheat
Fishing: catch 32,300 metric tons (1976) -
Major industries: fishing; some coconut processing
Electric power: 4,000 kW capacity (1977): 6 million kWh
produced (1977), 40 kWh per capita —
Exports: $3 million (1975); fish
Imports: $9.3 million (1975)
Major trade partners: Sri Lanka, Japan
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka (1967),
$1 million committed; Kuwait $5 million; other OPEC
countries, Japan and India (amounts not known)
Monetary conversion rate: 3.93 Maldivian rupees=US$1,
official rate; 8.5 rupees=US$1, market rate (February 1978)
Fiscal year: calendar year
‘GDP: estimated about $645 million (1977), $110 per
capita; annual real growth rate 5.8% - (1973-76)
Agriculture: main crops—millet, sorghum, rice, corn,
peanuts; cash crops—peanuts, cotton, and livestock
Fishing: catch 100,000 metric tons (1975)
Major industries: small local consumer goods and
processing
Electric power: 42,000 kW capacity (1977); 105 million
kWh produced (1977), 20 kWh per capita
Exports: estimated $125 million (f.0.b., 1977); livestock,
peanuts, dried fish, cotton, and skins
Imports: estimated $170 million (c.if., 1977); ‘textiles,
vehicles, petroleum products, machinery, and sugar
Major trade partners: mostly with franc zone and
Western Europe; also with U.S.S.R., China
Budget: (1976) expenditures $102 million; revenues $82
million
Monetary conversion rate: 491.34 Mali francs=US$1,
1977 ;
Fiscal year: calendar year','0d3ac3e2a6e11f6760286f8638d1c1408522dc019051ffdfe4803a77efdaec3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('019a99ce6bba11eb9e8992e1a0ec0219538f05070ee027305168d2c6d86e1023',1967,'MT','Malta','economy',294,'GNP: $609 million (1977), $1,850 per capita; 72% private
consumption, 26% gross investment; 17% government
consumption, — 15% net foreign sector; in 1977 real GNP
growth was 9% (1977 prelim.); 12.5% (1971-76 average)
Agriculture: overall, 20% self-sufficient; adequate sup-
plies of vegetables, poultry, milk and pork products;
shortages in beef, grain, animal fodder, and fruits at various
seasons; main products—potatoes, cauliflowers, grapes,
wheat, barley, tomatoes, citrus, cut flowers, green peppers,
hogs, poultry, eggs; 2,680 calories per day per capita
Major industries: ship repair yard, clothing, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs (fuels and
raw materials) must be imported
'' Electric power: 120,000 kW capacity (1977); 420 million
kWh produced (1977), 1,280 kWh per capita
Exports: $289 million (f.o.b., 1977); clothing, textiles,
ships, printed matter :
Imports: $516 million (c.i.f.; 1977)
Major trade partners: 68% EC-nine (23% U.K., 18% West
Germany, 13% Italy); 6% U.S. (1977)
Aid: economic authorizations: U.S., $55 million (FY70-
76); other Western bilateral (ODA and OOF), $112 million
(1970-76); China, $45 million (1972); OPEC, $22 million
(1974-76)
Budget: (1978/79) projects $259 million in expenditures,
$237 million in revenues
Monetary conversion rate: 1 Maltese pound=US$2.37
(average 1977)
Fiscal year: 1 April-31 March
’','9e4e2443cd9cf4ef149dbc91e0c220d2a09ce5a4cbbd893a2fc3427dda5c504b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27eca2d029fae228a64360c07af054b68edac63f2bd19f4565e3da5ecb8159bf',1967,'MQ','Martinique','economy',298,'GNP: $1,169 million (1977 at current prices), $3,600 per
capita
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly
sugar milling and rum distillation; cement, oil refining and
tourism
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AA RA RRLAR AAR RAR RR AN RR AR AO RO
ae, ge SR OR RS
ee ee ee, eee ee ee ee ee ee ae Oe a ee EE OM OE ae See ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
_ January 1979
MARTINIQUE/MAURITANIA
Electric power: 95,500 kW capacity (1977); 150 million
kWh produced (1977), 430 kWh per capita
Exports: $128.1 million (f.o.b., 1977); bananas, refined
petroleum products, rum, sugar, pineapples
_Imports: $426.5 million (c.i.f., 1977); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from Western (non-U.S.) countries, $1.4 billion;
no military aid ;
Major trading partners: exports—82% France, 9% Italy,
9% other; imports—70% France, 6% United States, 3%
Netherlands Antilles, 3% Netherlands, 18% other (1968)
Monetary conversion rate: 4.75 French francs=US$1
(1976)
Fiscal year: calendar year','c4efe17ebde46156e0a411435000bf4f34d4486efadd7554b72fe049e8efbaa2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18557645315e62e567507800ca159a6185a2c97efadda4940c2ca43cc8c6e343',1967,'MR','Mauritania','economy',302,'GDP: about $328 million (1978 prov.), $240 per capita,
average annual increase in current prices about 2% (1971-78)
Agriculture: most Mauritanians are nomads or subsistence
farmers; main products—livestock, small grains, dates; cash
crops—gum arabic; livestock
Fishing: catch, 34,170 metric tons; exports, 29,891 metric
tons (1975)
Major industries: mining of iron ore and copper, fishing ~
Electric power: 70,000 kW capacity (1977); 100 million
kWh produced (1977), 70 kWh per capita
Exports: $136 million (f.o.b., 1978 prov.); iron ore, fish,
copper
Imports: $314 million (f.0.b., 1978 prov.); foodstuffs,
capital goods
Major trade partners: (trade figures not complete because
Mauritania has a form of customs union with Senegal and
much local trade unreported) France and other EC
members, U.K., and U.S. are main overseas partners
Budget: 1978 prov. $267 million expenditures, $44 million
grants, $138 million revenue
Monetary conversion rate: 45.68 Ouguiyas=US$1 as of
November 1977
Fiscal year: calendar year
-GNP: $9.7 billion (1977), about $530 per capita; average
annual real growth 4% during 1970-73, 9% in 1974, under
3% in 1975-77 :
Agriculture: cereal farming and livestock raising predomi-
nate; main products—wheat, barley, citrus fruit, wine,
vegetables, olives; some fishing
Fishing: catch 281,434 metric tons (1976); exports $64.5
million (1975) ,
’ Major sectors: mining and mineral processing (phos-
phates, smaller quantities of iron, manganese, lead, zinc, and
other minerals), food processing, textiles, construction and
tourism
Electric power: 1,200,000 kW capacity (1977); 3.1 billion
kWh produced (1977), 165 kWh per capita
Exports: $1,302 million (1977); 33% phosphates, 77%
other
Imports: $3.0 billion (1977); 34.0% capital goods, 13.5%
foodstuffs, 11.0% petroleum products
Major trade partners: France, West Germany, Italy
Budget: (1978) revenue $2.7 billion, expenditure $2.0
billion
Monetary conversion rate: 4.5 dirhams=US$1
Fiscal year: calendar year
Agriculture: practically none; some barley is grown in
nondrought years; fruit and vegetables in the few oases; food
imports are essential; camels, sheep, and goats are kept by
the nomadic natives; cash economy exists largely for the
garrison forces .
Major phosphate mining, fishing, and
handicrafts
Shortages: water
Electric power: 4,000 kW capacity (1975); 9 million kWh
produced (1975), 80 kWh per capita
Exports: in 1975, up to $75 million in phosphates, all other
exports valued at under $1 million
Imports: $1,443,000 (1968); fuel for . fishing fleet,
foodstuffs
Major trade partners: monetary trade largely with Spain
and Spanish possessions ©
industries:
Aid: small amounts from Spain in prior years
Monetary conversion rate: see Moroccan and Mauritan-
ian currencies','28de1acb0e23f6778cf07afe0bb72f58e47251fc7f09902489000aa9bbd060ef','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19ef8c1b5b31565623606fd287574ac4d925d3d6f8942970d377a0159a000964',1967,'MU','Mauritius','economy',306,'GNP: $570 million (1977), $640 per capita; real growth
(1970-76), 6%
Agriculture: sugar crop is major economic asset; about
40% of land area is planted to sugar; most food imported—
rice is the staple food—and since cultivation is already
intense and expansion of cultivable areas is unlikely, heavy
reliance on food imports except sugar and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea;
some small-scale, simple manufactures; tobacco fiber; some
MAURITIUS /MEXICO
fishing; tourism, diamond cutting, weaving and textiles,
electronics
Electric power: 81,000 kW capacity (1977); 312 million
kWh produced (1977), 8340 kWh per capita
Exports: $312 million (f.0.b., 1977); $268 million sugar, $4
million tea, $5 million molasses
Imports: $442 million (c.if., 1977); foodstuffs 30%,
manufactured goods about 25%
Major trade partners: all EC-nine countries and U.S.
have preferential treatment, U.K. buys over 50% of
Mauritius’ sugar export at heavily subsidized prices; small
amount of sugar exported to Canada, U.S., and Italy; imports
from U.K. and EC primarily, also from South Africa,
Australia, and Burma; some minor trade with China
Aid: economic—(1970-76) Western (non-U.S.) countries,.
$75.5 million, Communist countries, $40.2 million; U.S.,
$14.7 million
‘Budget: revenues $174 million, current expenditures $261
million (1977)
Monetary conversion rate: 6.6 Mauritian rupees=US$1
1977 (floating with pound sterling)
Fiscal year: 1 July-30 June
Agriculture: cash crops—almost entirely sugarcane, small
amounts of vanilla and perfume plants; food crops—tropical
fruit and vegetables, manioc, bananas, corn, market garden
produce, also some tea, tobacco, and coffee; food crop
inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling
plants, cigarette factory, 2 tea plants, fruit juice plant,
canning factory, a slaughterhouse, and a number of small
shops producing handicraft items
Electric power: 75,000 kW capacity (1977); 185 million
- . kWh produced (1977), 370 kWh per capita
Exports: $62 million (f.0.b., 1975); 90% sugar, 4% perfume
* essences, 5% rum and molasses, 1% vanilla and tea (1974)
Imports: $410 million (c.i-f., 1975); manufactured goods,
food, beverages, and tobacco, machinery and transportation
equipment, raw materials and petroleum products
Major trade partners: France (in 1970 supplied 62% of
Reunions imports, purchased 76% of its exports); Mauritius
(supplied 12% of imports)
‘Aid: economic—(1970-76) Western (non-U.S.) countries,
$2,106 million
Monetary conversion rate: 4.705 French francs=US$1
Fiscal year: probably calendar year ,','b3c5beb428f9cb199667acd43f0f6cf4188f4ccec1572d6a6de04cf6e30581e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c2d5147411f20ef8cb5620162f4b4745baa5439e438608e9771fa1f00909586',1967,'MC','Monaco','economy',310,'GNP: 55% tourism; 25%-30% industry (small and primar-
ily tourist oriented); 10%-15% registration fees and sales of
postage stamps; about 4% traceable to the Monte Carlo
casino
139
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MONACO/MONGOLIA
Major industries: chemicals, food processing, precision
instruments, glassmaking, printing
Electric power: 8,000 (standby) kW capacity (1977); 100
million kWh supplied by France (1977)
Trade: full customs integration with France, which
collects and rebates Monacan trade duties
Monetary conversion rate: ]1 franc=US$0.2102 (1977
average)','d5c2ce17f75d522ae363cd61f338be3514352e25d50d577341c1dd2da405cec5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd04e554ca8a06a4d5956ef8e73fc685b9a68f497ce08412674ebd94fead72a5',1967,'MN','Mongolia','economy',314,'Agriculture: livestock raising predominates; main crops—
wheat, oats, barley
Industries: processing of animal products; building
materials; mining , . ,
Electric power: 307,400 kW capacity (1977); 995 million.
kWh produced (1977), 650 kWh per capita
Exports: beef for slaughter meat products, wool, fluorspar,
other minerals
Imports: machinery and equipment, petroleum, clothing,
building materials, sugar, and tea
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee ee EE eS. a ee ee ee a OS a ee ee
Dn EE SE RE ES, OE
eee ee We ee OL ee, PG Mg a ee
COE ee nee Se ET, ae eee ee Ee ee! OS Oe, ee ee ee Te pe eee fe) Mee eee CM CS te ee eae. @ BY
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MONGOLIA/MOROCCO
Major trade partners: nearly all trade with Communist
countries (approx. 85% with U.S.S.R.); total turnover about
$1.0 billion (1977)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.11 tugriks=US$1 (June
1978); arbitrarily established
Fiscal year: calendar year','c2dc2987411c31de790b8bdc5f120eacc2941c0370938fe372e48fb2b41414f0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a78527beecbbfc300d60426acc1ac5812fa77b92210fd44c28f3832041ba8ace',1967,'MZ','Mozambique','economy',319,'GNP: $2.0 billion (1975 est.), about $220 per capita;
average annual growth probably negative in 1975-77
Agriculture: cash crops—raw cotton, cashew nuts, sugar,
tea, copra, sisal; other crops—corn, wheat, peanuts, potatoes,
beans, sorghum, and cassava; self-sufficient in food except
for wheat which must be imported
Major industries: food processing (chiefly sugar, tea,
wheat, flour, cashew kernels); chemicals (vegetable oil,
oilcakes, soap, paints); petroleum products; beverages;
textiles; nonmetallic mineral products (cement, glass, asbes-
tos, cement products); tobacco
Electric power: 1,664,000 kW capacity (1977); 4.6 billion
kWh produced (1977), 490 kWh per capita
Exports: $155 million (1977 est.); cashew nuts, cotton,
sugar, mineral products, timber products, tea, copra
Imports: $420 million (1977 est.); machinery and electri-
cal equipment, cotton textiles, vehicles, petroleum products,
wine, iron and steel
Major trade partners: Portugal, South Africa, U.S., U.K.,
West Germany
Budget: (FY76) expenditures, $310 million, revenues,
$237 million
Monetary conversion rate: 40.643 escudos= US$] as of
November 1977 ,
Fiseal year: calendar year
GDP: approximately $224 million (FY74), about $470 per
capita; growth rate in current prices as much as 11%
(FY71-74)
Agriculture: main crops—maize, cotton, rice, sugar, and
citrus fruits
Major industry: mining
Electric power: 75,000 kW capacity (1977); 130 million
kWh produced (1977), 250 kWh per capita
Exports: $191 million. (f.0.b., 1976); sugar, iron ore,
asbestos, wood and forest products, citrus; meat products,
cotton
Imports: $200 million (f.0.b., 1976); motor . vehicles,
petroleum products, foodstuffs, and clothing
Major trade partners: South Africa, U.K., U.S.
Aid: economic—Western (non-U.S.) countries (1970-76),
$90.7 million; U.S. (1970-76), $10.2 million
Budget: FY77—revenue $86 million, recurrent expendi-
ture $47 million, development expenditure $39 million
Monetary conversion rate: 1 Lilangeni=US$1.15 (as of
March 1978)
Fiscal year: 1 April-31 March','1711bc629207cc4dbd69b6b00388dc67d18f4b92b812cb6eeb6f1b25a7fa2798','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6e3a1b7ea4ee2851d9fe4851150d5a193d0d9a3c0bd99e623ca22fc5a134505',1967,'NA','Namibia','economy',323,'Agriculture: livestock raising (cattle and sheep) predomi-
nates, subsistence crops (millet, sorghum, corn, and some
wheat) are raised but most food must be imported
Fishing: catch 86,650 metric tons (1975) (processed
mostly in South African enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper,
lead, diamond, and uranium mining, dairy products
Electric power: 297,400 kW. capacity (1977); 1,110
million kWh produced (1977), 1,110 kWh per capita
Aid: South Africa is only donor
Monetary conversion rate: 1 South African Rand=
US$1.15 (as of March 1978); 0.87 SA Rand=US$1
Fiscal year: 1 April-31 March','46c0cf9cab8b2e8f5b7cfb59c5cb974ddbc5ab0ddb404482a0f6e078d4a4838a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('673eb8ff9bef530c5abb7f0edd3fecb7bd3a3b92e9ecc6cfca5e2f63264032c9',1967,'NP','Nepal','economy',327,'GDP: $1.3 billion (FY77, at current prices), $100 per
capita; 1% real growth in FY77
Agriculture: over 90% of population engaged in agricul-
ture; main crops—rice, corn, wheat, sugarcane, oilseeds
Major industries: small rice, jute, sugar, and oilseed mills;
match, cigarette, and brick factories
Electric power: 60,600 kW capacity (1977); 144 million
kWh produced (1977), 10 kWh per capita
Exports: $82 million est. (FY78); rice and other food
products, jute, timber
Imports: $206 million est. (FY78); manufactured con-
sumer goods, fuel, construction materials, food products
Major trade partner: over 80% India
Aid: economic commitments 1970-76: U.S.S.R., $3 mil-
lion; China, $118 million; OPEC, $18.1 million; U.S., $71
million; $78 million disbursements FY78
Budget: (FY78 est.) domestic revenues $128 million,
expenditures $231 million
Monetary conversion rate: 12 Nepalese rupees=US$1
Fiscal year: 15 July-14 July','7fae992d9244042d41f32c9b6a40b51f3932826f202cb0b53824b23353961c02','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0efaf9a29938a8d6ac33634571d8fbef92d28257db85948efecf2e351b675add',1967,'NL','Netherlands','economy',331,'GNP: $105.3 billion (1977 est. in 1977 prices), $7,590 per
capita; 57.7% consumption, 21.7% investment, 17.6% gov-
ernment, 2.7% foreign balance; 0.8% net income from
abroad
husbandry predominates; main
crops—horticultural crops, grains, potatoes, sugar beets; food
Agriculture: animal
shortages—grains, fats, oils; calorie intake, 3,186 calories per
day per capita (1970-71)
Fishing: catch 302,000 metric tons (1977); exports of fish
and fish products $251.2 million (1977), imports $125.8
million (1977) °
Major industries: food processing, metal and engineering
products, electrical and electronic machinery and equip-
ment, chemicals, petroleum products, and natural gas
Shortages: crude petroleum, raw cotton, base metals and
ores, pulp, pulpwood, lumber, feedgrains, and oilseeds
Crude steel: 7.7 million metric ton capacity; 5.2 million
metric tons produced (1976), 380 kg per capita
Electric power: 16,900,000 kW capacity (1977); 59 billion
kWh produced (1977), 4,245 kWh per capita —
Exports: $43.7 billion (f.0.b., 1977); foodstuffs, machinery,
chemicals, petroleum products, natural gas, textiles
Imports: $46.6 billion (c.i.f., 1977); machinery, transpor-
tation equipment, crude petroleum, foodstuffs, chemicals,
raw cotton, base metals and ores, pulp
Major trade partners: (1977) 62.2% EC, 27.6% West
Germany, 13.1% Belgium-Luxembourg, 6.1% U.S.
Aid: donar: bilateral economic aid authorized, $2,731
million (1970-76)
Budget: (1979 est.) revenues $40.2 billion, expenditures
$47.6 billion, deficit $7.4 billion at exchange rate of 2.21
guilders=$1 ,
Monetary conversion rate: 2.4543 guilders=US$1, aver-
age 1977 floating
Fiscal year: calendar year
148','2c089e369beee4a479f7fda2bf2f2564b365d31f91519953f9c559c49703a36b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f28b579674bf425f13d0a2e1ac78a2867fc8d49520ffebc250c17ba10e4d76a3',1967,'NI','Nicaragua','economy',338,'GDP: $2,242 million (1977 prelim.), $980 per capita; 70%
private consumption, 8% government consumption, 27%
domestic investment, —5% net foreign balance (1977); real
growth rate 1977, 5.9% prelim.
Agriculture: main’ crops—cotton, coffee, sugarcane, rice,
corn, beans, cattle; caloric intake, 2,300 calories per day per
capita (1966)
Fishing: catch 15,200 metric tons (1977); exports valued
at $22.7 million (1977)
Major industries: food processing, chemicals, metal
products, textiles and clothing
Electric power: 358,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 520 kWh per capita
Exports: $630 million (f.o.b., 1977); cotton, coffee,
chemical products, meat, sugar
Imports: $758 million (c.i.f., 1977); food and non-food
agricultural products, chemicals and pharmaceuticals, trans-
portation equipment, machinery, construction materials,
clothing, petroleum oe
Major trade partners: exports—19% U.S., 22% CACM,
28% EC, 31% other; imports—22% U.S., 26% CACM, 14%
EC, 37% other (1976)
Aid and Ex-Im Credits: economic—extensions (1970-76)
from U.S., $145.3 million; other Western countries, $26.8
million; military—(1970-76) from U.S., $17 million
Budget: 1978 expenditures $480 million, revenues $300
million
Monetary conversion rate: 7.0263 cordobas=US$1
(official)
Fiscal year: calendar year','052907be827bd096feb9482cf8e921fbeeadb890e38401629093de27a8fc3c47','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee27f0f0aec9ae849bce2814624e06c21bd5c77b2122f4e217c9d4b5bfdfba19',1967,'NE','Niger','economy',342,'GDP: $510 million (1976), $100 per capita, annual growth
estimated by U.S. Embassy at 9.8% (1973-76)
Agriculture: commercial—peanuts, cotton,
main food crops—millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill,
small cotton gins, oil presses, slaughterhouse, and a few other
smal] light industries; uranium production began in 1971
Electric power: 20,000 kW capacity (1977); 70 million
kWh produced (1977), 10 kWh per capita
Exports: $118 million (f.0.b., 1976); about 65% uranium,
rest peanuts and related products, livestock, hides, skins;
exports understated because much regional trade not
recorded
Imports: $177 million (c.i.f., 1976); fuels, machinery,
transport equipment, foodstuffs, consumer goods
Major trade partners: France (over 50%), other EC
countries, Nigeria, UDEAC countries, U.S.; preferential
tariff to EC and franc zone countries -
Aid: economic—Western (non-U.S.) companies (1970-76),
$372.1 million; U.S. (1970-76), $107.4 million; Communist
countries (1970-76), $54.4 million, OPEC (ODA) (1973-76),
$24.3 million
Budget: (FY76-77) revenue $131 million, expenditure $96
million, surplus $35 million
Monetary conversion rate: about 242.69 Communaute
Financiere Africaine=US$1 as of November 1977, floating
Fiscal year: 1 October-30 September','8b359d010bff034c1208da2144d61ae9ab8dd4b352f01c396d34ace9065ba01d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ebc2d45cb459298a81a49e5449c1b3d3bab1e6fb9687dbcb6027bc6983e66e6',1967,'NG','Nigeria','economy',347,'GDP: $33 billion (FY77 current prices), $500 per capita;
7.5% growth rate (1970-76)
Agriculture: main crops—peanuts, cotton, cocoa, rubber,
yams, cassava, sorghum, palm kernels, millet, corn, rice;
livestock; almost self-sufficient
Fishing: catch 494,767 metric tons (1976); imports $14.5
million (1974)
Major industries: mining—crude oil, natural gas, coal,
tin, columbite;. processing industries—oil palm, peanut,
cotton, rubber, petroleum, wood, hides, skins; manufacturing
industries—textiles, cement, building*materials, food prod-
ucts, footwear, chemical, printing, ceramics
Electric power: 1,367,000 kW capacity (1977); 4 billion
kWh produced (1977), 60 kWh per capita
Exports: $10.2 billion (f.0.b., 1978 est.); oil (95%), cocoa,
palm products, rubber, timber, tin
Imports: $12 billion (c.if., 1978 est.); machinery and
transport equipment, manufactured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY78-79 proposed—current revenue $10.9 bil-
lion, current expenditures, $4.2 billion; capital expenditures,
$7.0 billion
Monetary conversion rate: 1 Naira=US$1.59 (June 1978)
Fiscal year: 1 April-31 March','5ca2bac23ba4873ef5235412802ef43ee6b63bb94f6cc2a178e473bd6d58e928','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e981078a14a770f9ed4215b63c3a304278cb3d0e35442f5eb40f5ba46f9ad823',1967,'NO','Norway','economy',351,'GNP: $35.8 billion in 1977, $8,850 per capita; 56% private
consumption; 36% investment; 19% government; net foreign
balance — 11%; 1976 growth rate 3.9%, in constant prices;
4.8% average (1970-76)
Agriculture: animal husbandry predominates; main
crops—feed grains, potatoes, fruits, vegetables; 40% self-suf-
ficient; food shortages—food grains, sugar; caloric intake,
2,940 calories per day per capita (1969-70)
Fishing: catch 3.4 million metric tons (1976); value $476
million (1976); exports $467 million (1976)
Major industries: oil and gas, food processing, shipbuild-
ing, wood pulp, paper products, metals, chemicals
Shortages: most.raw materials with the exception of
timber, petroleum, iron, copper, and ilmenite ore, dairy
products and fish
Crude steel: 732,779 metric tons produced (1977), 180 kg
per capita
Electric power: 18,200,000 kW capacity (1977); 72.5
billion kWh produced (1977), 17,885 kWh per capita
Exports: $8,712 million (f.0.b., 1977); principal items—
metals, pulp and paper, fish products, ships, chemicals, oil
Imports: $12,874 million (c.i.f., 1977); principal items—
foodstuff, ships, fuels, motor vehicles, iron and_ steel,
chemical compounds, textiles
Major trade partners: 49% EC (19% U.K., 12% West
Germany, 6% Denmark); 16% Sweden; 5% U.S.; 3% East
Bloc countries (1977)
_ Aid: donor, bilateral economic aid authorized (ODA and
OOF), $503 million (1970-76)
Budget: (1977) revenues $8.8 billion, expenditures $9.3
billion
_Monetary conversion rate: 1 kroner=US$0.188 (1977)
Fiscal year: calendar year
GNP: $2.6 billion’ (1977); $4,880 per capita est.
Agriculture: based on subsistence farming (fruits, dates,
cereals, cattle, camels), fishing, and trade
Major industries: petroleum discovery in 1964; produc-
tion began in 1967; production 1977, 340,000 b/d; pipeline
capacity, 400,000 b/d; revenue for 1976 est. at $1.4 billion
Electric power: 240,000-kW capacity (1977); 380 million
kWh produced (1977), 690 kWh per capita
Exports: $1.6 billion (f.0.b., 1977), mostly petroleum;
non-oil exports (mostly agricultural)
Imports: $813 million (c.i.f., 1977)
Major trade partners: U.K., U.S., other European, Gulf
states, India, Australia, China, Japan
Aid: economic—OPEC (ODA) (1973-76), $857.2 million;
Western (non-U.S.) countries (1970-76), $9.9 million; U.S.
(1970-76), $1.0 million
Budget: (1977) revenues $2.082 billion; expenditures $2.2
billion
Monetary conversion rate: ] Riyal Omani=US$2.93 (as
of October 1978)
Fiscal year: calendar year','a4f953d7edd6e73b7697b5fbfd4e31971593f77dc4c504e4843761259e0a47bc','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0c4516980de56100e54f5b8d3a23f1c04e07bb0348c812f86eda0d16c29fa44',1967,'PK','Pakistan','economy',355,'GNP: $15.0 billion (FY78 est.), $200 per capita; average
annual real growth, 4.0% (1970-78) ‘
Agriculture: extensive irrigation; main crops—wheat, rice,
‘and cotton; foodgrain shortage, about 1 million tons
imported in FY78
Fishing: catch 197,550 metric tons (1978 est.)
Major industries: cotton textiles, food processing, tobacco,
engineering, chemicals, natural gas
Electric power: 3,430,000 kW capacity (1977); 13.5
billion kWh produced (1977), 175 kWh per capita
Exports: $1,342 million (f.o.b., 1978); cotton (raw and
manufactured), rice
Imports: $2,738 million (c.i.f., 1978); foodgrains, edible
oil, crude oil,machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Budget: expenditures, FY78—current expenditures,
$2,048.7 million; capital expenditures, $1,717.2 million
160
. Monetary conversion rate: 9.9 rupees=US$1 (since
February 1973)
Fiscal year: 1 July-30 June','c96c8592b09b7f9a3a001c2b37eeef5515475c7724f1476f673df87db5320d86','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d38426027c20bbbb7d7cf91474c8c49ef7727b8eae0c0c05c9081ed17a23d26',1967,'PA','Panama','economy',359,'GNP: $2,215 million (1977), $1,250 per capita; 72%
private consumption, 15% government consumption, 21%
gross fixed investment, — 8% net foreign balance (1977); real
growth (1977), 1.6%
Agriculture: main crops—bananas, rice, corn, coffee,
sugarcane; self-sufficient in most basic foods; 2,450 calories
per day per capita (1969 )
Fishing: catch 171,641 metric tons (1976); exports $18.8
million (1974); imports $2.2 million (1974)
Major industries: food processing, metal products,
construction materials, petroleum products, clothing, furni-
ture
Electric power (including Canal Zone): 600,000 kW
capacity (1977); 2.5 billion kWh produced (1977), 1,410
kWh per capita
Exports: $253 million (f.o.b., 1977); bananas, petroleum
products, shrimp, sugar, meat, coffee
Imports: $862 million (c.i.f., 1977); manufactures, trans-
portation equipment, crude petroleum, chemicals, foodstuffs
Major trade partners: exports—45% U.S., 12% Canal
Zone, 9% West Germany, 7% Italy, 6% Netherlands;
imports—31% U.S:, 18% Ecuador, 8% Venezuela, 8% Colon
Free Zone, 5% Japan, 4% Saudi Arabia, 3% Trinidad and
Tobago (1976)
Aid: economic—(FY70-76) U.S., $284 million; . other
Western countries, $266 million; military—U.S., $7 million
16]
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
PANAMA/PAPUA NEW GUINEA
Budget: (1978) $538 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year','7a4a411637e98e773873c13926bf8cbe44709389ade60d9a94a75349f7ee72c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ab13e2c0fb7a50fc875369014cc9f64e7202bd2540c831bb839839adf2e65ea',1967,'PY','Paraguay','economy',363,'GDP: $2.1 billion (1977, at current prices), $750 per
capita; 7.0% public consumption; 74.8% private consump-
tion, 29.4% gross domestic investment, — 11.2% net foreign
balance (1977); real growth rate 1977, 11.8%
Agriculture: main crops—oilseeds, cotton, wheat, manioc,
sweet potatoes, tobacco, corn, rice, sugarcane; self-sufficient
in most foods; caloric intake, 2,580 caloriés per day per
capita (1963-64); protein intake, 70 grams per day per capita
(20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling,
brewing, textiles, light consumer goods, cement
Electric power: 230,000 kW capacity (1977); 550 million
kWh produced (1977), 200 kWh per capita
Exports: $278.9 million (f.o.b., 1977); cotton, oilseeds,
meat products, tobacco, timber, coffee, essential oils, tung oil
Imports: $255.4 million (f.0.b., 1977); fuels and lubricants,
machinery and motors;—motor—vehicles; beverages~—and:
tobacco, foodstuffs
Major trade partners: exports—15% Netherlands, 14%
United States, 18% Argentina, 10% West Germany; im-
ports—21% Brazil, 16% Argentina, 12% U.S., 9% West
Germany (1977)
Aid: (1970-76) economic bilateral commitments, U.S. $54
million, other Western countries $69 million; military
commitments, U.S. $17 million
Budget: (1977) $250 million current revenues, $190
million total expenditures including amortizations
Monetary conversion rate: 126 guaranies=US$1 (official
rate, December 1978)
Fiscal year: calendar year','8c6cce21872986841efa7e00c4380130910c8abb6ca05cb69c7adcd02ac6a41e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eedc11bf1ec310fa371ba69945566ae3a0bb1834a067efd769b4869d41076f28',1967,'PE','Peru','economy',366,'GNP: $12.1 billion (1977, in current prices), $730 per
capita; 72.5% private consumption, 11.8% public consump-
tion, 20.1% gross investment; —4.4% net foreign balance
(1976); ‘real growth rate (1977), —1.24%
Agriculture: main crops—wheat, potatoes, beans, rice,
barley, coffee, cotton, sugarcane; imports—wheat, meat,
Jard and oils, rice, corn; caloric intake, 2,200 calories per day
per capita (1967)
Fishing: catch 2.5 million metric tons (1977); exports $215
million (1977)
’ Major industries: mining of metals, petroleum, fishing,
textiles and clothing, food processing, cement, auto assem-
bly, steel, ship-building, metal fabrication
Electric power: 2,073,000 kW capacity (1977); 8 billion
kWh produced (1977), 480 kWh per capita
Exports: $1,726 million (f.0.b., 1977); copper, fish and fish
products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $2,164 million (f.0.b., 1977); foodstuffs, machin-
ery, transport equipment, iron and steel semimanufactures,
chemicals, pharmaceuticals
Major trade partners: exports—24% U.S., 15% Latin
America, 21% EC, 14% Japan, 2% U.S.S.R. (1976); imports—
31% US., 28% EC, 17% Latin America, 12% Japan (1974)
Budget: (1977) $2.3 billion current revenues, $3.8 billion
total expenditures including debt amortization
Monetary conversion rate: 174 soles=US$1 (12 October
1978); floats against U.S. dollar
Fiscal year: calendar year','c5b3e96e04464277ae8188c1ee14a95304950d1a8b0f228d976b0596eafe2ee3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74c46031a23fb130e6b248cdd7948485c3bf1e3e13d18b1b92d8f8b4c61e0514',1967,'PL','Poland','economy',371,'GNP: $95.2 billion in 1977, at 1976 prices, $2,740 per
capita; 1977 growth rate, 5.1%
Agriculture: self-sufficient for minimum requirements;
main crops—grain, sugar beets, oilseeds, potatoes, exporter
of livestock products and sugar; importer of grains; 3,200
calories per day per capita (1970)
Fishing: catch 659,000 metric tons (1977)
Major industries: machine building, iron and _ steel,
extractive industries, chemicals, shipbuilding, and food
processing
Crude steel: 17.8 million metric tons produced (1977),
about 510 kg. per capita
Electric power: 21,749,000 kW capacity (1977); 109.4
billion kWh produced (1977), 3,150 kWh per capita
Exports: $12,405 million (f.o.b., 1977); 46% machinery
and equipment, 35% fuels, raw materials, and semimanufac-
tures, 10% agricultural and food products, 9% light industrial
products
Imports: $14,767 million (f.o.b., 1977); 41% siichiniery
and equipment; 41% fuels, raw materials, and semimanufac-
tures; 13% agricultural and food products; 5% light industrial
products
Major trade partners: $27,172 million (1977); 56% with
Communist countries, 44% with West
Monetary conversion rate: 3.32 zlotys=US$1 (commer-
cial); 33.20 zlotys=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data are
reported for calendar years except for caloric intake whichis
reported for the consumption year, 1 July-30 June','562181d88322564285d971f2b3f38972eebabfbe322ad4a18ada4f458fcdcd00','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41315e01e373fdb97e0017b880583cbb1d3b8c12e5f269966f8e6ee225d18bb',1967,'PT','Portugal','economy',374,'GNP: $14.8 billion est. (1977); 18% government consump-
tion, 84% private consumption; 10% gross fixed investment;
— 12% net exports; average annual real GNP growth 1970-
74, 8%; the Portuguese government puts the change in real
GNP at —2.7% in 1975 and 5.8% in 1976, but —7.0%-and
+3.3% appear more realistic; growth in real GNP in 1977
est. at 5.5%
Agriculture: generally underdeveloped; main crops—
grains, potatoes, olives, grapes for wine; deficit foods—sugar,
grain, meat, fish, oil seeds; caloric intake
Fishing: landed 339,191 metric tons (1976)
Major industries: textiles and footwear; wood pulp,
paper, and cork; metalworking; oil refining; chemicals; fish
canning; wine
Crude steel: 460,000 tons produced (1976), 50 kg per
capita
Electric power: 4,600,000 kW capacity (1977); 13.9
billion kWh produced (1977), 1,415 kWh per capita
Exports: $2.0 billion (f.0.b. 1977); principal items—cotton
textiles, cork and cork products, canned fish, wine, timber
and timber products, resin
Imports: $4.9 billion (f.0.b., 1977); principal items—
petroleum, cotton, industrial machinery, iron and steel,
chemicals
Major trade partners: 45% EC (12% U.K., 11% W.
Germany, 9% France, 4% Italy); 12% EFTA, 8% U.S., 4%
Spain, 3% Iraq, 3% Saudi Arabia, 3% Japan (1976)
Aid: economic authorizations: U.S:, $178 million
(FY70-76) ;
169
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
PORTUGAL/QATAR .
Budget: 1977—receipts, $2.7 billion; expenditures, $4.2
billion; deficit, $1.5 billion
Monetary conversion rate: ] escudo=US$0.0261 (average
1977)
Fiscal year: calendar year','9e0bd7e19f287bdc69eea7561dc33ea5c93761c2b66897d57721fddd55adf8ad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64d09990d755f6e4e286438646276c7b3baa256f10274a34e56db7e9bde1636b',1967,'RW','Rwanda','economy',380,'GDP: $603 million (1976 provisional), $140 per capita;
real average annual growth rate (1970-77), 5.5%
Agriculture: cash crops—mainly coffee, tea, some pyre-
thrum; main food crops—bananas, cassava; stock raising;
self-sufficiency declining; country imports foodstuffs
Major industries: mining of cassiterite (tin ore), wolfram
(tungsten ore), agricultural processing, and light consumer
goods
Electric power: 35,000 kW capacity (1977); 142 million
kWh produced (1977), 30 kWh per capita
Exports: $104 million (f.o.b., 1976); mainly coffee, tea,
cassiterite, wolfram, pyrethrum
Imports: $103.7 million (c.i.f., 1976); textiles, foodstuffs,
machines, equipment
Major trade partners: U.S., Belgium, West Germany,','90ab976e984c1356f6e34b1781b705e7f01b4d0dcca4d57fb16ad333752317c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a13fc9d590012da95184e4f94b4a24c14f13ccc61005e95635109ca12750c16',1967,'AI','Anguilla','economy',384,'GDP: $30.4 million (at normal prices, 1976), $210 per
capita
Agriculture: main crops—sugar on St. Christopher, cotton
on Nevis
Major industries: sugar processing, salt extraction
Electric power: 15,000 kW capacity (1977); 32 million
kWh produced (1977), 460 kWh per capita
Exports: $17.8 million (f.o.b., 1975); sugar, molasses,
cotton, salt, copra
Imports: $19.5 million (ci-f., 1975); foodstuffs, fuel;
manufactures :
Major trade partners: exports—50% U.S., 35% U.K.;
imports—21% U.K., 17% Japan, 11% U.S. (1973)
Aid: economic—bilateral commitments including Ex-Im
(FY70-76) from Western (non-U.S.) countries, $64.6 million;
no military aid
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
GNP: $57 million (in market prices, 1976)
Agriculture: main crops—bananas, copra, sugar, cocoa,
spices :
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 14,000 kW capacity (1977); 40 million
kWh produced (1977), 365 kWh per capita
Exports: $17 million (f.o.b., 1976); sugar, bananas, cocoa
Imports: $47 million (c.i.f., 1976); foodstuffs, machinery
and equipment, fertilizers, petroleum products
Aid: economic—bilateral commitments including Ex-Im
(FY70-76), from Western (non-U.S.) countries, $16.7 million;
no military aid
Major trade partners: 51% U.K., 9% Canada, 17% U.S.
(1970)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
GNP: $335 million (at market prices, 1976)
Agriculture: main crops—bananas, arrowroot, coconut
Major industries: food processing
Electric power: 6,500 kW capacity (1977); 18 million
kWh produced (1977), 190 kWh per capita
Exports: $9.3 million (f.o.b., 1976); bananas, arrowroot,
copra
Imports: $23.7 million (c.i.f., 1976); fertilizer, flour,
transportation equipment, lumber, textiles ;
Major trade partners: exports—61% U.K., 30% CARI-
COM, 9% U.S.; imports—29% CARICOM, 28% U.K., 9%
Canada, 9% U.S. (1972)
Aid: economic—bilateral economic commitments includ-
ing Ex-Im (FY 70-76), from Western (non-U.S.) countries, -
$46.2 million; no military aid
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)','078f53733c29402b4982e1773772854af72d315c072d3843951d806ea72930fb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('878078b5f4e8acd0d67aac584c7dbad213495619ef4473a4e021984791775b7c',1967,'SM','San Marino','economy',388,'. Principal economic activities of San Marino are farming,
livestock raising, light manufacturing, and tourism; the
largest share of government revenue is derived from the sale
of postage stamps throughout the world and from payments
by the Italian government in exchange for Italy’s:monopoly
_in retailing tobacco, gasoline, and a few other goods; main
problem is finding additional funds to finance badly needed
'' water and electric power systems expansions
Agriculture: principal crops are wheat (average annual
output about 4,400 metric tons/year) and grapes (average
annual output about 700 metric tons/year); other grains,
fruits, vegetables, and animal feedstuffs are also grown;
- livestock population numbers roughly 6,000 cows, oxen, and
sheep; cheese and hides are most important livestock
products ,
Electric power: imported from Italy
Manufacturing: consists mainly of cotton textile produc-
tion at Serravalle, brick and tile production at Dogane,
‘cement production at Acquaviva, Dogane, and Fiorentino,
and pottery production at Borgo Maggiore; some tanned
hides, paper, candy, baked goods, Moscato wine, and gold
and silver souvenirs are also produced ©
Foreign transactions: dominated by tourism; in summer
months 20,000 to 30,000 foreigners visit San Marino every
“179
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SAN MARINO/SAO TOME AND PRINCIPE
day; a number of hotels and restaurants have been built in
recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign
inflow; commodity trade consists primarily of exchanging
building stone, lime, wood, chestnuts, wheat, wine, baked
goods, hides, and ceramics for a wide variety of consumer
manufactures :','276fe25310ab1d210cc4fa79f32948837ef94c5c2e632dce4f97f7356e8530d8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb0c5a0c73c6058d342386e310e4bbf1e5f02016823a2242a356dbd55a2afe9d',1967,'SC','Seychelles','economy',392,'GDP: $43.1 million (1976); $710 per capita; 4.6% growth
rate (1974)
Agriculture: islands depend largely on coconut production
and export of copra; cinnamon, vanilla, and patchouli (used
for perfumes) are other cash crops; food crops—small
quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk
of the supply must be imported; fish is an important food
source :
Major industries: processing of coconut and vanilla,
fishing, small-scale manufacture of consumer goods, coir
rope factory, tea factory, tourism
Electric power: 11,000 kW capacity (1977); 25 million
kWh produced (1977), 410 kWh per capita
Exports: $8.7 million (f.0.b., 1977); cinnamon (bark and
oil) and vanilla account for almost 50% of the total, copra
accounts for about 40%, the remainder consisting of
patchouli, fish; and guano :
Imports: $37.1 million (c.if., 1977); food, tobacco, and
beverages account for about 40% of imports, manufactured
goods about 25%, machinery and transport equipment,
petroleum products, textiles
Major trade parterns: exports—India, U.S.; imports—
U.K., Kenya, South Africa, Burma, India, Australia -
Aid: economic—(1970-76) Western (non-U.S.) countries,
$72.4 million; US., $0.6 million
184
Budget: (1978) revenue $24 million, expenditure $15
million
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year','34821d6efb9dadcee1027f305d5851a11ae7f5a7e4ed11314c85106330339d92','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95a428225fe8a248de6cb25e5febd0bf9145633160464e4baf1ffc1731e0a561',1967,'SL','Sierra Leone','economy',396,'GDP: $657 million (mid 1977), $230 per capita; growth
rate 1.8% (mid-1971 to mid-1975)
Agriculture: main crops—palm kernels, coffee, cocoa,.
rice, yams, millet, ginger, cassava; much of cultivated land
devoted to subsistence farming; food crops insufficient for
domestic consumption
Fishing: catch 67,797 metric tons (1975); imports $2.7
million (1974)
Major industries: mining—diamonds, iron ore, bauxite,
rutile; manufacturing—beverages, textiles, cigarettes, con-
struction goods; 1 oil refinery .
Electric power: 85,000 kW capacity (1977); 264 million
kWh produced (1977), 90 kWh per capita
Exports: $118 million (f.0.b., 1977); diamonds, iron ore,
palm kernels, cocoa, coffee
Imports: $150 million (f.0.b., 1977); machinery and
transportation equipment, manufactured goods, foodstuffs,
petroleum products
Major trade partners: U.K., EC, U.S., Japan, Communist
countries ; a
Budget: (FY77 est.) current revenues $102 million, total
expenditures $145 million oh,
Monetary conversion: rate: 1 leone=US$0:95 (1978)
Fiscal year: 1 July-30 June','596e418a27a2dc85b963758875b481a7bae2b39504c4921dbb5ec0928a949599','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13583f7139d4504e25ac78aec5dced282f086a84bd8e82e484fe6985adfef4c2',1967,'SB','Solomon Islands','economy',402,'’ GDP: $64.1 million (1976) a
Agriculture: largely dominated by coconut production
with subsistence crops of yams, taro, bananas; self-sufficient
in rice :
Electric power: 10,000 kW capacity (1977); 22 million
kWh produced (1977), 105 kWh. per capita
Exports: $15.5 million (1975); 39% copra, 27% timber,
23% fish
Imports: $29.2 million (1975)
Major trade partners: exports—EEC excluding U.K. 42%,
Japan 29%; imports—Australia 34%, U.K. 14%, Japan 13%
(1975)
Budget: (1971) revenues $9.8 million, expenditures $9.9
million :
Monetary conversion rate: 1 Australian dol-
lar=US$1.1532 (September 1978) ''','89b748bfc4d79e319f1f31d08a915dca2e7f2decd9fcff0bf615ce224eb7634c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('886e94b61019ceca1cbb4e9c3e8afc44b65c4d0a9cbd1275be5a77560fc6fdd0',1967,'SO','Somalia','economy',406,'GDP: $340 million (1975 est.), $110 per capita
Agriculture: mainly a pastoral country, raising livestock;
crops—bananas, sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar
refinery, tuna and beef canneries, textiles,” iron rod plant,
and petroleum refining
Electric power: 18,000 kW capacity (1977); 45 million
kWh produced (1977), 10 kWh per capita
Exports: $84 million (f.0.b., 1977); livestock, hides, skins,
and bananas _
Imports: $201 million (f.0.b., 1977); textiles, cereals,
transport equipment, machinery, construction materials and
equipment, petroleum products; also: military materiel in
1977
Major trade partners: Arab countries and Italy; $21.4
million imports from Communist countries (1975. est.)
Monetary conversion rate: 6.295 Somali shillings=US$1
Fiscal year: 1 January-31 December','21a7edc6a267f342d313e55451fad8e8a77db636d861f3c2adb8c67303c0903e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c5232bb535ed028e389205c6556c066d491cced5417fd739000c027b16204f2',1967,'ZA','South Africa','economy',407,'GDP: $38.9 billion (1977), about $1,450 per capita; real
growth rate 0.5% (1977)
Agriculture: main crops—corn, wool, wheat, sugarcane,
tobacco, citrus fruits; dairy products; self-sufficient in
foodstuffs
Fishing: catch 638,035 metric tons (1976)
Major industries: mining, automobile assembly, metal-
working, machinery, textiles, iron and steel, chemical,
fertilizer, fishing
189
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a''s
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
Electric power: 15,272,800 kW capacity (1977); 87 billion
kWh produced (1977), 3,240 kWh per capita
Exports: $10.0 billion (f.o.b., 1977, excluding gold); wool,
diamonds, corn, uranium, sugar, fruit, hides, skins, metals,
metallic ores, asbestos, fish products; gold output $3.2 billion
(1977)
Imports: $6.3 billion (c.if., 1977); motor vehicles,
machinery, metals, petroleum products, textiles, chemicals
Major trade partners: U.S., West Germany, Japan, U.K.
Aid: no military or economic aid
Budget: FY79—revenue $8.8 billion, expenditures $10.3
billion
Monetary conversion rate: 1 SA Rand=US$1.15, 0.87 SA
Rand=US$1''
Fiscal year: 1 April-31 March
GDP: estimated at $150 million, $86 per capita
Agriculture: cash crops—tea, phormium tenax, small
amount of coffee; food crops—corn, sorghum, dry beans;
imports over half its foodstuffs from South Africa; two-thirds
of Transkei devoted to grazing—1.2 million cattle, 2.5
million sheep, 1.3 million goats
Major industries: forestry, textiles, tourism
Exports: timber, labor to South Africa, tea, sacks
Imports: foodstuffs, machines, equipment
Major trade partners: South Africa
Aid: South Africa, almost $500 million since 1970
Budget: $156 million (1976-77), about 70% of which is
provided by the South African government
Monetary conversion rate: 1 South African Rand=
US$1.15
Fiscal year: 1 April-31 March','d12cedf4fbc874ce4fc628fcf12934e7620e9a403409df3dbfb90d8bed6ac0b6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d760248e3a284c416074c211b6fbe0ef8f0dfaa177aaa52a53d22398e3fcf0c',1967,'ES','Spain','economy',409,'GNP: $116 billion (1977), $3,190 per capita; 69.7% private
consumption, 10.2% public consumption, 22.5% gross fixed
investment; — 2.4% foreign balance (1976); real growth rate
2.4% (1977)
Agriculture: main crops—cereals, oranges, grapes for
wine, potatoes, olives, sugar beets; virtually self-sufficient in
good crop years; caloric intake, 2,750 calories per day per
capita (1969-70) , ;
Fishing: landed 1.48 million metric tons valued at $1,152
million in 1976
Major industries: food processing, textiles and apparel
(including footwear), metal manufacturing, chemicals, ship-
building, automobiles
Shortages: crude petroleum, natural gas
Crude steel: 11.1 million metric tons produced (1977),
300 kg per capita ,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee a ee Oe, ee ee ee ee ee ee eee ee ee, |,
Ri Mr tit te i a a ee a a ot Ree ii ol i i eh il Sn Lee all
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SPAIN/SRI LANKA
Electric power: 29,100,000 kW capacity (1977); 93.7
billion kWh produced (1977), 2,565 kWh per capita
Exports: $10,208 million (f.0.b., 1977); principal items—
oranges and other fruits, iron and steel products, textiles,
wines, mercury, ships, canned fruits, vegetables, and
footwear .
Imports: $17,779 million (c.i.f., 1977); principal items—
machinery and transportation equipment, petroleum and
petroleum products, grains, cotton, iron and steel
Major trade partners: (1977) 11.3% U.S., 11.2% France,
10.2% West Germany, 5.7% U.K:, 38.7% EC, 60.6% OECD,
6.8% Latin America, 3.6% Communist countries _
Aid: economic authorizations—U.S., $1,246 million author-
ized (FY70-77); other Western bilateral (ODA and OOF),
$448 million (1970-76); military authorizations—U.S., $375
million (FY70-77)
Budget: (1978 central government)—budgeted revenues
$17,846 billion, budgeted expenditures $17,846 billion
Monetary conversion rate: 1 peseta=US$0.0124 (1977
average)
Fiscal year: calendar year','05402b0f3d254aa2770a673d4f76364ea61e6ab2be5801e05b49edfb8d77cfc1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('912acc808a268090c95c673c928f00043ccdff1687bb6716465132039f0d75c1',1967,'LK','Sri Lanka','economy',414,'GNP: $3.2 billion in 1977 (1977 prices), $220 per capita;
real growth rate 4.4% (1977), 3.0% (1976) . .
Agriculture: agriculture accounts for about 39% of GNP;
main crops—rice, rubber, tea, coconuts; 60% self-sufficient
in food; food shortages—rice, wheat, sugar
Fishing: catch 138,528 metric tons (1977)
Major industries: processing of rubber, tea, and other
agricultural commodities; consumer goods manufacture
Electric power: 430,000 kW capacity (1977); 1.4 billion
kWh produced (1977), 100 kWh per capita
Exports: $754 million (1977); tea, rubber, coconut
products :
Imports: $696 million (1977); food, petroleum, fertilizer
Major trade partners: (1977) exports—8% Pakistan, 8%
U.K.; imports—12.4% Saudi Arabia, 9.8% Iran
Budget: (1978) revenue $730 million, expenditure $1,061
million
Monetary conversion rate: 15.6 rupees=US$1 (July 1978)
Fiscal year: 1 January-31 December (starting 1973)','986491d5da5f7e642b2dad11b4894a013321631efeb1b25600c508a761017551','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aac9ee58d4f62c0834793762fb16896458c5919349981138bd3f3be3f434b14',1967,'SD','Sudan','economy',418,'GDP: $4.3 billion at current prices (1977), $230 per capita
at current prices
Agriculture: main crops—sorghum, millet, wheat, sesame,
peanuts, beans, barley; not self-sufficient in food production;
main cash crops—cotton, gum arabic, peanuts, sesame
Major industries: cotton ginning, textiles, brewery,
cement, edible oils, soap, distilling, shoes, pharmaceuticals
Electric power: 231,800 kW capacity (1977); 672 million
kWh produced (1977), 40 kWh per capita
Exports: $660 million (f.o.b., 1977); cotton (51%), gum
arabic, peanuts, sesame; $57.5 million exports to Communist
countries (FY76)
Imports: $1.058 billion (c.i.f., 1977); textiles, petroleum
products, vehicles, tea, wheat; $75 million imports from
Communist countries (FY76)
Major trade partners: U.K., West Germany, Italy, India,
China, France, Japan
Monetary conversion rate: 1 Sudanese pound=US$2.87
(official); 0.348. Sudanese pound=US$1
Fiscal year: 1 July-30 June
195
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SUDAN/SURINAME','c889384213207941ac1fe93da8a2039406388ef7b6aac9390fa3d2f319ea3872','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0019fddaa5577bbcc01145d38799cb0b64d790e8f905085a97b29aaf226580d9',1967,'SE','Sweden','economy',422,'GDP: $78.5 billion, $9,530 per capita (1977); 53.8%
consumption, 20.3% investment, 28.7% government; —0.4%
inventory change; — 2.4% net imports of goods and services;
1977 growth rate —2.5% in constant prices
Agriculture: animal husbandry predominates with milk
and dairy products accounting for 40% of farm income;
main crops—grains, sugar beets, potatoes; 80% self-suffi-
cient; food shortages—oils and fats, tropical products; caloric
intake, 2,903 calories per day per capita (1975)
Fishing: catch 173,700 metric tons (1977), exports $36
million, imports $169 million
Major industries: iron and steel, precision equipment
(bearings, radio and telephone parts, armaments), shipbuild-
ing, wood pulp and paper products, processed foods, textiles,
chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 4.0 million metric tons produced (1977), 490
kg per capita
Electric power: 25,000,000 kW capacity (1977); 91.0
billion kWh produced (1977), 11,025 kWh per capita
Exports: $18,839 million (f.0.b., 1977); machinery, motor
vehicles and ships, wood pulp, paper products, iron and steel
products, metal ores and scrap, chemicals
Imports: $20,022 million (c.i-f., 1977); machinery, motor
vehicles, petroleum and petroleum products, textile yarn
and fabrics, iron and steel, chemicals, food, and live animals
Major trade partners: (1977) 15% West Germany, 11%
U.K., 6% U.S., 9% Norway, 8% Denmark; 49% EC-9; 6%
U.S.S.R. and Eastern Europe
Aid: donor: economic aid authorized (ODA and OOF),
$1,978 million (1970-76)
Budget: (1976/77) revenues $22.7 billion, expenditures
$23.8 billion
Monetary conversion rate: 4.4816 kroner=US$1 average
exchange rate 1977
Fiscal year: 1 July-30 June','5b471c99fd161fb25a8e17e5df4206ce1d43e48732bd1910f2c2495d69dc7c79','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab0962d2b42541e466c97f4f3672244ed42f10391806578acaa7bab7272366d0',1967,'CH','Switzerland','economy',426,'GNP: $63.37 billion (1977 at 1977 prices), $9,870 per
capita; 60.4% consumption, 20.3% investment, 12.8% gov-
ernment, net foreign balance 6.5% (1977); 1970-76 average
growth rate 1.8%, constant prices
Agriculture: dairy farming predominates; less than 50%
self-sufficient; food shortages—fish, refined sugar, fats and
oils (other than butter), grains, eggs, fruits, vegetables, meat;
caloric intake, 3,190 calories per day per capita (1969-70)
Major industries: machinery, chemicals, watches, textiles,
precision instruments
- Shortages: practically ail important raw materials except
hydroelectric energy
Electric power: 12,000,000 kW capacity (1977); 44.7
billion kWh produced (1977), 7,090 kWh per capita
Exports: $17.54 billion (f.o.b., 1977); principal items—
machinery and equipment, chemicals, precision instruments,
metal products, textiles, foodstuffs
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SWITZERLAND/SYRIA
Imports: $17.90 billion (c.if., 1977); principal items—
machinery and transportation equipment, metals and metal
products, foodstuffs, chemicals, textile fibers and yarns
Major trade partners: 56% EC (22% West Germany, 11%
France, 9% Italy, 7% U.K.); 9% EFTA (5% Austria); 7% U.S.;
5% Communist countries (1977)
Aid: donor: bilateral economic aid authorized (ODA and
OOF), $321 million (1970-76)
Budget: receipts, $5,836 million, expenditures, $6,446
million, deficit, $610 million (1977)
Monetary conversion rate: 2.4035 Swiss francs=US$1
(average 1977, floating)
Fiscal year: calendar year
GDP: $5.9 billion (1976), $780 per capita; real GDP
growth rate 8%, 1976
Agriculture: main crops—cotton, wheat, barley and
tobacco; sheep and goat raising; self-sufficient in most foods
in years of good weather
Major industries: textiles, food processing, beverages,
tobacco; petroleum (180,000 b/d production (1977), 117,000
b/d refining capacity)
Electric power: 1,700,000 kW capacity (1977); 2.5 billion
kWh produced (1977), 310 kWh per capita
Exports: $1.1 billion projected (f.0.b., 1977); petroleum,
textiles and textile products, tobacco, fruits and vegetables,
cotton ,
Imports: $2.6 billion (c.i.f., 1977); machinery and metal
products, textiles, fuels, foodstuffs
Major trade partners: exports—Italy, West Germany,
U.S.S.R., Yugoslovia; imports—Switzerland, West Germany,
Italy, Saudi Arabia
Budget: 1978 official plan—revenues $4.6 billion (includ-
ing Arab aid payments), expenditures $4.6 billion
Monetary conversion rate: 3.95 Syrian pounds=US$1
Fiscal year: calendar year
Mainland:
GDP: $2.8 billion (1977), about $170 per capita; real
average annual growth rate, 4.2% (1970-77)
Agriculture: main crops—cotton, coffee, sisal. on mainland
Fishing: catch 180,746 metric tons (1975); exports valued
at $638,000, imports $1.1 million (1975)
Major industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond mine, oil
refinery, shoes, cement, textiles, wood products
Electric power: 365,000 kW capacity (1977); 1,278
million kWh produced (1977), 80 kWh per capita
Exports: $168 million (f.0.b., 1978 projected); coffee,
cotton, sisal, cashew nuts, meat, diamonds, cloves, tobacco,
tea
Imports: $574 million (c.if., 1978 projected); manufac-
tured goods, machinery and transport equipment, cotton
piece goods, crude oil, foodstuffs
Major trade partners: exports—China, U.K., Hong Kong,
India, U.S.; imports—U.K., China, West Germany, U.S.,
Japan .
Budget: (1977 est.) receipts including grants, $872 million,
expenditures, $833 million; recurrent and development
expenditure $1,014 million
Monetary conversion rate: 7.96 Tanzanian _ shil-
lings=US$1
Fiscal year: 1 July-30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops—cloves, coconuts
Industries: agricultural processing
Electric power: see Tanzania (above)
Exports: $504 million (f.0.b., .1977); cloves and clove
products, coconut products
Imports: $723 million (c.i.f., 1977); mainly foodstuffs and
consumer goods
Major trade partners: imports—China, Japan, and
mainland Tanzania; exports—Singapore, China, Hong Kong,
Indonesia, India, Pakistan ; ;
Aid: U.K. principal source of aid until 1964; U.S. $86
million FY58-73; China is currently major source
Exchange rate: 7.96 Tanzanian shillings=US$1
Fiscal year: 1 July-30 June
203
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TANZANIA/THAILAND','cb4882dc236d5b57d0d245a140200ee2c85f9d33acc84932ac50b9af0a77648c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('935f5997c5401c2769ea3992fcfff99394412b4ef4abdfe0184d02d454dca487',1967,'TH','Thailand','economy',430,'GNP: $18.1 billion (1977), $410 per capita; 5.8% real
growth in 1977 (6.6% real growth, 1973-77)
Agriculture: main crops—rice, sugar, corn, rubber,
tapioca
Fishing: catch 1.6 million metric tons (1976); major
fishery export, shrimp, 15,218 metric tons, about $66
million, total marine export, about $118 million (1976)
Major industries: agricultural] processing, textiles, wood
and wood products, cement, tin and tungsten ore mining;
world’s second largest tungsten producer and third largest tin
producer
Shortages: fuel] sources, including coal, petroleum; scrap
iron, and fertilizer :
Electric power: 2,904,000 kW capacity (1977); 11.3
billion kWh produced (1977), 255 kWh per capita
Exports: $3.6 billion (f.o.b., 1977); rice, sugar, corn,
rubber, tin, tapioca, kenaf-
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Da nc et a i a et i ae en i, a
eS ae
eT ON OE OE Ere
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
THAILAND/TOGO
Imports: $4.6 billion (c.if., 1977); machinery and
transport equipment, fuels and lubricants, base metals,
chemicals, and fertilizer ;
Major trade partners: exports—Japan, U.S., Singapore,
Netherlands, Hong Kong, Malaysia; imports—Japan, U.S.,
West Germany, U.K.; about 1% or less trade with
Communist countries
Budget: (FY79) planned receipts $4,509 million; 20.6%
military, 79.4% civilian
Monetary conversion rate: 20.2 baht=US$1 (September
1978)
Fiscal year: 1 October-30 September
GNP: $7.3 billion (1977), approximately $140 per capita;
real growth less than 5% annually ,
222
Agriculture: main crops—rice, rubber, fruits and vegeta-
bles, mainly in the south; some corn, manioc,-and sugarcane;
major food imports—wheat, dairy products
Fishing: catch 1,013,500 metric tons (1976), of which
600,000 metric tons sea
Major industries: food processing, textiles, machine
building, mining, cement, chemical fertilizer, glass, tires
Shortages: foodgrains, petroleum, capital goods and
’ machinery, fertilizer
Electric power: 1,392,700 kW capacity (1977); 3.4 billion
kWh produced (1977), 70 kWh per capita
Exports: $300 million (1977); agricultural and handicraft
products, coal, minerals, ores
Imports: $900 million (1977); petroleum, steel products,
railroad equipment, chemicals, medicines, raw cotton,
’ fertilizer, grain
Major trade partners: exports—U.S.S.R., East European
countries, Japan, other Asian markets; imports—U.S.S.R.,
’ East Europe, China, Japan
Aid: accurate data on aid since April 1975 unification
. unavailable; estimated annual commitments of economic aid
are—U.S.S.R., $500 million; East European countries, $150
million; China, $300 million; non-Communist countries,
$230 million; international institutions, $75 million; military
aid deliveries since end of war in April 1975 are minimal
Monetary conversion rate (official): 2.19 dong=US$1
Fiscal year: calendar year','0c2439855e4264c5521dc85c2075ac314b27c2bc7a7983270f5703e085f51b51','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18c2bb4a7762e196a265fdbca1b63b42b52ef4e6321307bf37f793e01db0880',1967,'TG','Togo','economy',434,'GDP: $780 million (1978 est.), about $300 per capita;
estimated real growth 1970-77, 2.2%
Agriculture: main cash crops—coffee, cocoa, cotton;
major food crops—yams, cassava, corn, beans, rice, millet,
some
sorghum, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural process-
ing, handicrafts, textiles, beverages
‘Electric power: 30,000 kW capacity (1977); 110 million
kWh produced (1977), 50° kWh per capita
Exports: $202 million (f.0.b., 1977); phosphates, cocoa,
coffee, palm kernels, and cassava
Imports: $298 million (c.i.f., 1977); consumer goods, fuels,
machinery, -tobacco, foodstuffs
Major trade partners: mostly with France and other EC’
countries
Budget: (1978 proposed), revenues and expenditures,
$247 million :
Monetary conversion rate: Communaute Financiere
Africaine 245.67 francs=US$1 (1977)
Fiscal year: calendar year','5946d9a5872c474e994610e0c9e3ee0a526ec2257d5feaa0098c4e61c8ee35f1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66036af0e87ee8b47b039346e9ac8e77e131e8971c44c2d90bf211e0370306ce',1967,'TO','Tonga','economy',438,'GNP: $39 -million (1975), $400 per capita
Agriculture: largely dominated by coconut and banana
production with subsistence crops of taro, yams, sweet
potatoes, and bread fruit
Electric power: 4,000 kW capacity (1977); 8 million kWh
produced (1977), 70 kWh per capita
Exports: $10 million (f.0.b., 1975); 65% copra, 7% coconut
: products, 8% bananas
Imports: $28 million (c.i.f., 1975); food, machinery, and
petroleum
Major trade partners: (FY74) exports—25% Netherlands,
22% Australia, 20% New Zealand, 11% Norway; imports—
63% New Zealand and Australia
Budget: (FY76) revenues $6.7 million, expenditures $8.3
million :
Monetary conversion rate: 1 Tonga dollar=US$1.40
(1976)
Fiscal year: 1 July-30 June','ca4368d3d3192a67c471d810e21d0ee5628c0d078659bac0c8d092f20ee2c59a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a59d8b236ff4509ae0296d8d647df7f05b1d3e46dd1df042018bbc9ddb51625a',1967,'TT','Trinidad and Tobago','economy',442,'GDP: $3,159 million (1977), $3,040 per capita; 49%
mining and petroleum, 6% manufacturing, 4% agriculture,
41% other; growth rate 1977, 7.7% est.
Agriculture: main crops—sugarcane, cocoa, coffee, rice,
’ citrus, bananas; largely dependent upon imports of food
Fishing: catch 4,322 metric tons (1976); exports $1.1
million (1975), imports $4.5 million (1975)
Major industries: petroleum, tourism, food processing,
cement _ ; ; ,
Electric power: 375,000 kW capacity (1977); 1.6 billion
kWh produced (1977), 1,540 kWh per capita
_Exports: $2.2 billion (f.0.b., 1977); petroleum and
petroleum products (91%), sugar, cocoa (2.0%)
‘Imports: $1.9 billion (c.i.f., 1977); crude petroleum (46%),
machinery, fabricated metals, transportation equipment,
manufactured goods, food
Major trade partners: imports—Saudi Arabia 24%, U.S.
21%, Indonesia 10%, U.K. 10%, Iran 9%, Japan 4%; exports—
U.S. 72%, U.K. 2%, Netherlands 2%
208 °
Aid: economic—bilateral commitments including Ex-Im
(1970-76), U.S., $50.6 million; other Western countries,
$23.8 million
Budget: (1977) central government revenues $1 billion,
expenditures $1 billion (current $487 million, investment
$156 million, development project funds, $371 million)
Monetary conversion rate: tied to US dollar in 1976;
TT$2.40=US$1
Fiscal year: calendar year','49d9e18e999a5eb7b2c1cb2971e33184d1c7ba04bc58d9793b8735e339f419b8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2541cd250a64f00f1426ea020ae37f2df2be1a9e1357b44305429765fd005f83',1967,'TN','Tunisia','economy',446,'GDP: $5.7 billion (1978 est.), $930 per capita; average
annual growth (1973-76), 7.2%
Agriculture: cereal farming and livestock herding pre-
dominate; main crops—wheat, barley, olives, fruits (espe-
cially citrus), viticulture, vegetables, dates
Major sectors: tourism, mining, food processing, textiles
and leather, light manufacturing, construction materials,
chemical fertilizers, petroleum
Electric power: 540,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 270 kWh per capita
Exports: $1.1 billion (f.o.b., 1978); 25% petroleum, 20%
phosphates, 18% olive oil
Imports: $2.1 billion (c.i.f., 1978); 36% raw materials, 23%
machinery and equipment, 14% consumer goods, 19% food
and beverages, 3% energy, 5% other .
Major trade partners: exports—France, Italy, West','a8421010d10c2df6938bfa20194496dd6127bf071e2f22a6881c41128d3fb903','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27954e2342a99423a45fb05888f567f4121a8774b49a00c627bd78280fb5e117',1967,'UG','Uganda','economy',453,'GDP: $886 million (1976, at constant prices), $70 per
capita; 0% real growth between 1970-74
‘Agriculture: main cash crops—coffee, cotton; other cash
’ crops—tobacco, tea, sugar, fish, livestock
Fishing: catch 152,400 metric tons (1976)
Major industries: agricultural processing (textiles, sugar,
coffee, plywood, beer), cement, copper smelter, corrugated
iron sheet, shoes, fertilizer
Electric power: 228,500 kW capacity (1977); 1,028
million kWh produced (1977), 80 kWh per capita
. Exports: $339 million (f.o.b., 1976); coffee, cotton, tea,
copper (1971)
Imports: $249 million (c.i.f., 1976); petroleum products,
machinery, cotton piece goods, metals, transport equipment
Major trade partners: U.K., U.S., Kenya
Monetary conversion rate: 7.95 Uganda shillings=US$1
Fiscal year: 1 July-30 June
- GNP: $1,034.3 billion (197, in 1977 U. S. prices), $3,990
per capita; in 1977 percentage shares were—57% consump-
tion, 29% investment, 14% government and other, including
defense (based on 1970 GNP in rubles at adjusted factor
cost); average annual growth rate of real GNP (1971-77),
3.8%, average annual growth rate (1976-77), 3.8%
Agriculture: principal food crops—grain (especially
wheat), potatoes; main industrial crops—sugar, cotton,
sunflowers, and flax; degree of self-sufficiency depends.on
fluctuations in crop yields; calorie intake, 3,250 calories per
day per capita in recent: years
Fishing: catch 9.7 million metric tons (1977); exports
403,800 metric tons (1977), imports 32,500 metric tons
(1977)
. Major industries: diversified, highly developed capital
goods industries; consumer goods industries comparatively
less developed :
Shortages: natural rubber, bauxite and alumina, tantalum,
tin, tungsten, fluorspar, and molybdenum
Crude steel: 160 million metric ton capacity as of 1
January 1978; 147 million metric tons produced in 1977, 570
kg per capita
Electric power: 239,800,000 kW capacity (1977); 1,152
billion kWh produced (1977), 4,440 kWh per capita
213
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
U.S.S.R./;UNITED ARAB EMIRATES
Exports: $45,228.6 million (f.0.b., 1977); fuels (particu-
larly petroleum and derivatives), metals, agricultural prod-
ucts (timber, grain), and a wide variety of manufactured
goods (primarily capital goods)
Imports: $40,931.9 million (f.0.b., 1977); specialized and
complex machinery and equipment, textile fibers, consumer
manufactures, steel products (particularly large diameter
pipe), and any significant shortages in domestic production
(for example, grain imported following poor domestic
harvests)
Major trade partners: $86.2 billion (1977 total turnover);
trade 57% with Communist countries, 30% with industrial-
ized West, and 13% with less developed countries
Aid: economic—to less developed countries (total ex-
tended 1977) $392 million; recipients included India $340
million; Jamaica, $30 million; Tanzania, $19 million;
economic extensions, $12.9 ‘billion (1954-77); military—
(total extended 1977) $4.0 billion; principal recipients were
Syria, $0.9 billion; Algeria, $0.8 billion; Ethiopia, $0.7
billion; India, $0.6 billion; Libya, $0.5, billion; military
extensions, $26 billion (1955-77)
Official monetary conversion rate: 0.6641 rubles=US$1:
(September 1978)
Fiscal year: calendar year','1550c290ae85914650695dcaad409fe670257214546f5ccd987775844e9709c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df301acbcf257dc8d1423bcbcca7f2a02e1db4cd803be4e1a76df2fa3b5ce015',1967,'AE','United Arab Emirates','economy',457,'GNP: $11.9 billion est. (1977), $18,140 per capita;
Agriculture: food imported, but some dates, alfalfa,
vegetables, fruit, tobacco raised
Electric power: 1,100,000 kW capacity (1977); 2.2 billion
kWh produced (1977), 2,355 kWh per capita
Exports: $9.5 billion (f.0.b., 1977); ($9.1 billion in oil, $0.4
billion non-oil); crude petroleum, pearls, fish
Imports: $4.5 billion (c.i.f., 1977); food, consumer and
capital goods
Major trade partners: U.K., U.S., Japan, India, EC
Aid: 1974-75 foreign aid totaled $1 billion; the 1975-76
budget committed $875 million to direct foreign aid; Abu
Dhabi Fund for Arab Economic and Social Development in
1975 lent $175 million to LDC’s
Budget: total budget (1977), $2.6 billion
Monetary conversion rate: 1 U.A.E. Dirham=US$0.25
Fiscal year: calendar year','fb410ccda8da3ee33e5767958aa4787e3ac91cc08050da6ff7e92c3b413991c2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45fbdd6da337b01b3ea6357f68431c9e4718a25d2ba606acdcfc666d8a7388c6',1967,'GB','United Kingdom','economy',461,'GNP: $243.9 billion (1977 est. in 1977 prices), $4, 360 per
capita; 59.8% consumption, 18.1% investment, 21.4% gov-
ernment; 0.5% inventories, 0.2% net foreign balance, real
‘growth 0.07% (1977)
'' Agriculture: mixed farming predominates; main prod-
‘ucts—wheat, barley, potatoes, sugar beets, livestock, dairy
products; 52.2% self-sufficient; food shortages—meat, fruits,
vegetables, cereals, dairy products; caloric intake, 2,910
‘ calories per day per capita, 1975
Fishing: catch 1.06 million metric tons (1976), valued at
$332 million; 1976 exports $146.2 million, mapetts $492.5
million
Major industries: machinery and transport equipment,
metals, food processing, paper and paper products, textiles,
chemicals, clothing
216
Shortages: rubber, timber and woodpulp, textile fibers,
nonferrous metals, foodstuffs
Crude steel: 20.4 million metric tons produced (1977);
28.1 million metric tons capacity (1975), 360 kg per capita
Electric power: 83,800,000 kW capacity (1977); 283.5
billion kWh produced (1977), 5,070 kWh per capita
Exports: $58.2 billion (f.o.b., 1977); machinery, transport
equipment, chemicals, metals, nonmetallic mineral manu-
factures, textiles, beverages
Imports: $64.6 billion (f.0.b., 1977); foodstuffs, petroleum,
machinery, crude materials, chemicals, nonferrous metals
Major trade partners: 37.5% EC, 13.4% Commonwealth,
9.7% U.S., 4.2% Ireland, 3.9% Switzerland
Aid: donor: bilateral economic aid authorized (ODA and
OOF), $5,058 million (1970-76) ,
Budget (central government): forecast for FY79, $80.6
billion expenditures, $71.9 billion revenues; public sector
borrowing requirement, $16.6 billion :
Monetary conversion ‘rate: - pound sterling floating,
average daily exchange rate 1977, 0.57 pounds=US$1
Fiscal year: 1 April-31 March
GNP: $684 million (1976 est.), $110 per capita, real-
growth, 5.8% (1976) ne
Agriculture: cash crops—peanuts, shea nuts, sesame,
cotton; food crops—sorghum, millet, corn, rice; livestock;
largely self-sufficient
Fishing: catch 3,500 metric tons (1975)
Major industries: agricultural processing plants, brewery,
bottling, and brick plants; a few other light industries
Electric power: 21,500 kW capacity (1977); 57 million
kWh produced (1977), 9 kWh per capita
Exports: $92.8 million (1978 est.); livestock (on the hoof),
peanuts, shea nut products, cotton, sesame :
Imports: $246 million (1978 est.); textiles, food, and other
consumer goods, transport equipment, machinery, fuels
Major trade partners: Ivory Coast and Ghana; overseas
trade’ mainly with France and other EC countries;
preferential tariff to EC and franc zone countries |
Aid: economic—Western (non-U.S.) countries (1970-76),
$218.1 million, OPEC (ODA) (1973-76), $59.2 million;
Communist countries (1970-76) $53.4 million; U.S. (1970-76)
$39.3 million ; Sos Ae
217
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
UPPER VOLTA/URUGUAY
Budget: (1978) balanced at $131 million
Monetary conversion rate: about 245.67 Communaute
Financiere Africaine francs=US$] as of November 1977
Fiscal year: calendar year','8cfb1a914a2116f58cc3f695923f1f9417e7d2a0fd152cc9f3a1f78b507c8e6f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4cd9cc02746885106d2332f593ecd6a3682793914ef24b07dbbea9c2ee63f7a',1967,'WF','Wallis and Futuna','economy',465,'Agriculture: dominated by coconut production with
subsistence crops of yams, taro, bananas
Exports: negligible
Imports: $1.4 million (1972); largely foodstuffs and some
equipment associated with development programs
Monetary conversion rate: 70 Colonial Franc Pacifique
(CFP)=US$1','f8fd40b7a42b8cc74997bc83b305ca0ffd327eeda1a36ae94f96befff016d03f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d48fe24a9b41036d311d4176e93f28095475f42bdcf9b2a6952d2b25b100a933',1967,'ZM','Zambia','economy',469,'GNP: $2.5 billion (1977), $480 per capita; real annual
average growth rate, 0.7% (1970-77)
Agriculture: main crops—corn, tobacco, cotton; net
importer of most major agricultural’ products
Major industries; copper mining and processing
Electric power: 1,563,400 kW capacity (1977); 7.2 billion
kWh produced (1977), 1,340 kWh per capita.
Exports: $898 million (f.o.b., 1977); copper (92%), zinc,
cobalt, lead, tobacco
Imports: $817 million (c.i.f., 1977); machinery, transport
equipment, foodstuffs, fuels, manufactures
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A ae en na
= me RRR A A eR
AA a A
AON ALA
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
Major trade partners: EEC, Japan, China, South Africa
Budget: 1976 est.—revenue. $510 million, expenditures
$665 million
Monetary conversion rate: 1 Zambia kwacha=US$1.12
(official)
Fiscal year: calendar year','e688fc3b30152fb3732a6b38912a36e772929ac1cf268d9b424c6030efb77a46','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2ab92edfbdef8be39c52b2ee0b0d60229072bd54542b6e3ef210f263df39ea8',1967,'US','United States','economy',473,'GNP: $1,691.6 billion (1976); 64% private consumption,
-13.5% private investment, 21% government; $7,860 per
capita; 1976 growth rate, 10.2%
Fishing: catch 2.8 million metric tons (1975); imports
$1,381 million (1975); exports $298 million (1975)
Crude steel: 116.1 million metric tons produced (1976;,
540 ke per capita
Electric power: 557,012,300 kW capacity (1977); 2
trillion (net) kWh produced (1977), 9,750 kWh per capita
est.
Exports: $114.8 billion (f.o.b., 1976); machinery and
transport equipment, chemicals, cereals, mineral fuels
Imports: $129.6 billion (c.i.f., 1976); transport equipment,
machinery, mineral fuels, steel, nonferrous metals, metal
ores
Major trade partners: 22% Canada, 8% Japan, 5% West
Germany, 5% U.K. (1975)
Official development assistance (aid): obligations and
loan authorizations (FY76), economic $3.9 billion, military
$2.7 billion
231
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January. 1979
Budget: National Accounts Basis, expenditures $323.7
billion, revenues $287.6 billion
Fiscal year: -1 October-30 September','ca24e91eb515ce06b06ee9cefc42bab8c847f1110ac68c74e4f911ebe4a2adab','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

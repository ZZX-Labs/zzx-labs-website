SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca1d9b8f8ccad96e3bb20a4e6f5dd3065907bb9798129eb5dfe8406f2ad62f2c',1967,'AU','Australia','transportation',334,'Pipelines: natural gas, 785 km
Ports: 3 major
Civil air: about 40 major transport aircraft
Airfields: 193 total, 183 usable; 23 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m, 49 with
‘runways 1,220-2,439 m; 5 seaplane stations
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NEW ZEALAND/NICARAGUA.-
Telecommunications: excellent international and domes-
tic systems; 1,570,000 telephones (52 per 100 popl.); 60 AM
stations in 31 cities, no FM, 11 TV stations, and 129
repeaters; submarine cables extend to Australia and Fiji
Islands; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 773,000; 716,000 fit for
military service; average number reaching military age (20)
annually about 30,000
Military budget: proposed for fiscal year ending 31
March 1979, $281.8 million; about 3.6% of central govern-
ment budget','3a5f9510e202f3d05e234666b5271ce7ff4ed621bd558a9fcc23b0f4dd0b6716','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19de300acc29b6093c47d104a2050b1e1a88af82da6e2659bcf2a5e02891ee68',1967,'NI','Nicaragua','transportation',335,'(See reference map {1}
LAND
147,900 km’; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 200
nm; continental shelf, including sovereignty over superjacent
waters)
Coastline: 910 km','d8920f7f9f4097b73fc5790548a24889a974640892d1c05292754bb1347eed82','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f9926489684a750d900cb21a7c9ed95f96a23cd8163eccf01dd7e080623ac78',2008,'','','raw',1,'CENTRAL INTELLIGENCE AGENCY
Civic Center Ref Desk
R 910. 3 CIA
The CIA world fact book
31111028118816
S/rf
IHb
WORLD
FACTBOOK
2008
CENTRAL INTELLIGENCE AGENCY
Skyhorse Publishing
■ f j, j f f . • . \\ » 1 L. >
''"**••* ; j yy
‘ 1 t V )
I MC \\ r , - * I
. 1 • i ■ h ; i j I ij ! i
h n i\\ *rJ |. C ! '' !
• >t SW-t* •># ^ - * ^ '' 41
v ( rs .''s''
''''•**** '' f ,
j ‘ | s i < i,
| b ! ; I
MW $«<!*-
fi << t- • . J ffjj H&I »
Copyright ©2007 by Skyhorse Publishing
The Central Intelligence Agency (CIA) publishes The World Factbook in printed and Internet
versions and has placed it in the public domain. In general, information available as of
June 2007 was used in the preparation of this edition.
All rights reserved. No part of this book may be reproduced in any manner without the express
written consent of the publisher, except in the case of brief excerpts in critical reviews or
articles. Material in the text prepared by the CIA is not copyrighted except for format
and where modified by Skyhorse Publishing. All inquiries should be addressed to
Skyhorse Publishing, 555 Eighth Avenue, Suite 903, New York, NY 10018.
www.skyhorsepublishing.com
ISBN 10: 1-60239-080-0
ISBN 13: 978-1-60239-080-5
10 9 8 7 6 5 4 3 2 1
Printed in the United States of America
TABLE OF CONTENTS','e327edb37a3144fd857bfb1cf129bb2833d114d24bf5525d679f822f69a2db24','internet-archive','ciaworldfactbook00cent','txt','37f498620c7eef367019d81dbac65c13c679b49efc3d1b8d8fd45320aa24a835','https://archive.org/download/ciaworldfactbook00cent/ciaworldfactbook00cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cabfd38fa5cc6521e022317d3aac70f954ae1e9287ba0a94a3270511dcee8056',2008,'','','raw',1,'■ M. !
MUNAsC INGUiW
PrfRRt a j| , I AW AIM ON ;
'' ''i» .! •< Burma M/Rumm ^ v £)i>m o,mi
BOSTON PUBLIC LIBRARY
3 9999 04976 323 6
AAla: maaalA Cck": A \\ ImAaP" Co
BAAi . He
lEAL&$& a''! 44,;^% k) a '' Hot f ''\\Q
jltkpaGyJi^N ! >la i A f > .. I uv./AJN H
AC ftl Ife
■ } it : r
Li Fa
Pu \\Hl) - ARM ft''
BRITISH V 1 RCAK isfcANfi
|ii It k; t t:f i ti
f§ ETIitOfUAkFAy
IIMt CAJ 1 MEA-
PtMYA K.IRIR
A £ X \\ CO*
is 141
: 1 tt
FK’D rut $< h;th amjavk i
li iiilis iBi c \\!-. os ill
iiililliiiplil
TWV I A A
IkLkA M\\Vj b
COK jA s I) ''■*
Art ''A
:1QX\\ BRlflSH VtUUA
'' "• • - A''”
WORLD
Factbook
Central intelligence Agency^
The Government Printing Office has assumed production of The World Factbook
print edition. The CIA has decided to focus Factbook resources exclusively on the
World Wide Web online edition, which is updated with new material every two
weeks. US Government officials may obtain sales information about printed copies
from the following:
US Government Printing Office
732 N. Capitol St.
Washington, DC 20401
Hours: Monday-Friday 7:00 AM-6:30 PM Eastern Standard Time (EST)
Telephone: [1] (202) 512-1800; toll free: [1] (866) 512-1800
FAX: [1] (202) 512-2104
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Hours: Monday-Friday 8:00 AM-6:00 PM Eastern Standard Time (EST)
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1 ] (703) 605-6900
http://www.ntis.gov/
The World Factbook can be accessed on the Internet at:
https://www.cia.qov/library/publications/the-world-factbook/
index.html
For sale by the Superintendent of Documents. U.S. Government Printing Office
Internet: bookstore.gpo.gov Phone: toll free (866) 512-1800; DC area (202) 512-1800
Fax: (202) 512-2104 Mail: Stop IDCC, Washington, DC 20402-0001
ISBN 978-0-16-082969-7
Central
Intelligence
Agency
The
World
Factbook
2008
In general, information available as of 1 January 2008 was used in the
preparation of this edition.
The World Factbook is prepared by the Central Intelligence Agency for the
use of US Government officials, and the style, format, coverage, and
content are designed to meet their specific requirements. Information is
provided by Antarctic Information Program (National Science Foundation),
Bureau of the Census (Department of Commerce), Bureau of Labor
Statistics (Department of Labor), Central Intelligence Agency, Council of
Managers of National Antarctic Programs, Defense Intelligence Agency
(Department of Defense), Department of Energy, Department of State,
Fish and Wildlife Service (Department of the Interior), Maritime
Administration (Department of Transportation), National Center for Medical
Intelligence (Department of Defense), National Geospatial-Intelligence
Agency (Department of Defense), Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs (Department of the
Interior), Office of Naval Intelligence (Department of Defense), US Board
on Geographic Names (Department of the Interior), US Transportation
Command (Department of Defense), Oil & Gas Journal, and other public
and private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA). The
official seal of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50 U.S.C. section
403m). Misuse of the official seal of the CIA could result in civil and
criminal penalties.
Citation model:
The World Factbook 2008. Washington, DC: Central Intelligence
Agency, 2008.
https://www.cia.aov/library/publications/the-world-factbook/index.html
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Hours: Monday-Friday 8:00 AM-4:30 PM Eastern Standard
Time (EST)
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
RECEIVED
1
JUN 1 2 2009
Klrstefn Business Branch
A Brief History of Basic Intelligence and
The World Factbook
The Intelligence Cycle is the process by which information
is acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source, data
that may be fragmentary, contradictory, unreliable,
ambiguous, deceptive, or wrong. Intelligence is information
that has been collected, integrated, evaluated, analyzed, and
interpreted. Finished intelligence is the final product of the
Intelligence Cycle ready to be delivered to the policymaker.
The three types of finished intelligence are: basic,
current, and estimative. Basic intelligence provides the
fundamental and factual reference material on a country or
issue. Current intelligence reports on new developments.
Estimative intelligence judges probable outcomes. The
three are mutually supportive: basic intelligence is the
foundation on which the other two are constructed; current
intelligence continually updates the inventory of knowledge;
and estimative intelligence revises overall interpretations of
country and issue prospects for guidance of basic and
current intelligence. The World Factbook, The President''s
Daily Brief, and the National Intelligence Estimates are
examples of the three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington but only
since World War II have they been coordinated on a
government-wide basis. Three programs have highlighted
the development of coordinated basic intelligence since that
time: (1 ) the Joint Army Navy Intelligence Studies (JANIS),
(2) the National Intelligence Survey (NIS), and (3) The World
Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different components of
the US Government resulted in a great duplication of effort
and conflicting information. The Japanese attack on Pearl
Harbor in 1 941 brought home to leaders in Congress and the
executive branch the need for integrating departmental
reports to national policymakers. Detailed and coordinated
information was needed not only on such major powers as
Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and
Marines had to launch amphibious operations against many
islands about which information was unconfirmed or
nonexistent. Intelligence authorities resolved that the United
States should never again be caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train
(Office of Naval Intelligence - ONI), and Gen. William J.
Donovan (Director of the Office of Strategic Services - OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS
was the first interdepartmental basic intelligence program to
fulfill the needs of the US Government for an authoritative
and coordinated appraisal of strategic basic intelligence.
Between April 1943 and July 1947, the board published 34
JANIS studies. JANIS performed well in the war effort, and
numerous letters of commendation were received, including
a statement from Adm. Forrest Sherman, Chief of Staff,
Pacific Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based
planners."
The need for more comprehensive basic intelligence in
the postwar world was well expressed in 1946 by George S.
Pettee, a noted author on national security. He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1 946, page 46) that world leadership in peace requires
even more elaborate intelligence than in war. "The conduct of
peace involves all countries, all human activities - not just the
enemy and his war production."
The Central Intelligence Agency was established on
26 July 1947 and officially began operating on
18 September 1947. Effective 1 October 1947, the Director
of Central Intelligence assumed operational responsibility
for JANIS. On 13 January 1948, the National Security
Council issued Intelligence Directive (NSCID) No. 3, which
authorized the National Intelligence Survey (NIS) program
as a peacetime replacement for the wartime JANIS
program. Before adequate NIS country sections could be
produced, government agencies had to develop more
comprehensive gazetteers and better maps. The US Board
on Geographic Names (BGN) compiled the names; the
Department of the Interior produced the gazetteers; and CIA
produced the maps.
The Hoover Commission''s Clark Committee, set up in
1954 to study the structure and administration of the CIA,
reported to Congress in 1955 that: "The National
Intelligence Survey is an invaluable publication which
provides the essential elements of basic intelligence on all
areas of the world. There will always be a continuing
requirement for keeping the Survey up-to-date." The
Factbook was created as an annual summary and update to
the encyclopedic NIS studies. The first classified Factbook
was published in August 1962, and the first unclassified
version was published in June 1971. The NIS program was
terminated in 1973 except for the Factbook, map, and
gazetteer components. The 1975 Factbook was the first to
be made available to the public with sales through the US
Government Printing Office (GPO). The Factbook was first
made available on the Internet in June 1 997. The year 2008
marks the 61st anniversary of the establishment of the
Central Intelligence Agency and the 65th year of continuous
basic intelligence support to the US Government by The
World Factbook and its two predecessor programs.
The Evolution of
The World Factbook
National Basic Intelligence Factbook produced semiannually until 1980. Country entries include sections on Land, Water,
People, Government, Economy, Communications, and Defense Forces.
1981 - Publication becomes an annual product and is renamed The World Factbook. A total of 165 nations are covered on
225 pages.
1983 - Appendices (Conversion Factors, International Organizations) first introduced.
1984 - Appendices expanded; now include: A. The United Nations, B. Selected United Nations Organizations, C. Selected
International Organizations, D. Country Membership in Selected Organizations, E. Conversion Factors.
1987 - A new Geography section replaces the former separate Land and Water sections. UN Organizations and Selected
International Organizations appendices merged into a new International Organizations appendix. First multi-color-cover
Factbook.
1 988 - More than 40 new geographic entities added to provide complete world coverage without overlap or omission. Among
the new entities are Antarctica, oceans (Arctic, Atlantic, Indian, Pacific), and the World. The front-of-the-book explanatory
introduction expanded and retitled to Notes, Definitions, and Abbreviations. Two new Appendices added: Weights and Measures
(in place of Conversion Factors) and a Cross-Reference List of Geographic Names. Factbook size reaches 300 pages.
1989 - Economy section completely revised and now includes an Overview briefly describing a country’s economy. New
entries added under People, Government, and Communications.
1990 - The Government section revised and considerably expanded with new entries.
1991 - A new International Organizations and Groups appendix added. Factbook size reaches 405 pages.
1 992 - Twenty new successor state entries replace those of the Soviet Union and Yugoslavia. New countries are respectively:
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan; and Bosnia and Hercegovina, Croatia, Macedonia, Serbia and Montenegro, Slovenia.
Number of nations in the Factbook rises to 188.
1993 - Czechoslovakia’s split necessitates new Czech Republic and Slovakia entries. New Eritrea entry added after it
secedes from Ethiopia. Substantial enhancements made to Geography section.
1994 - Two new appendices address Selected International Environmental Agreements. The gross domestic product (GDP)
of most developing countries changed to a purchasing power parity (PPP) basis rather than an exchange rate basis. Factbook
size up to 512 pages.
1995 - The GDP of all countries now presented on a PPP basis. New appendix lists estimates of GDP on an exchange rate
basis. Communications category split; Railroads, Highways, Inland waterways, Pipelines, Merchant marine, and Airports entries
now make up a new Transportation category. The World Factbook is first produced on CD-ROM.
1996 - Maps accompanying each entry now present more detail. Flags also introduced for nearly all entities. Various new
entries appear under Geography and Communications. Factbook abbreviations consolidated into a new Appendix A. Two new
appendices present a Cross-Reference List of Country Data Codes and a Cross-Reference List of Hydrogeographic Data Codes.
Geographic coordinates added to Appendix H, Cross-Reference List of Geographic Names. Factbook size expands by 95 pages
in one year to reach 652.
1997 - A special edition for the CIA’s 50th anniversary. A schema or Guide to Country Profiles introduced. New color maps
and flags now accompany each country profile. Category headings distinguished by shaded backgrounds. Number of categories
expanded to nine - the current number - with the addition of an Introduction (for only a few countries) and Transnational Issues
(which includes Disputes-international and Illicit drugs). The World Factbook introduced onto the Internet.
1998 - The Introduction category with two entries, Current issues and Historical perspective, expanded to more countries.
Last year for the production of CD-ROM versions of the Factbook.
1999 _ Historical perspective and Current issues entries in the Introduction category combined into a new Background
statement. Several new Economy entries introduced. A new physical map of the world added to the back-of-the-book reference
maps.
2000 - A new “country profile” added on the Southern Ocean. The Background statements dramatically expanded to over
200 countries and possessions. A number of new Communications entries added.
2001 - Background entries completed for all 267 entities in the Factbook. Several new HIV/AIDS entries introduced under the
People category. Revision begun on individual country maps to include elevation extremes and a partial geographic grid. Weights
and Measures appendix deleted.
2002 - New entry on Distribution of Family income - Gini index added. Revision of individual country maps continued (process
still ongoing as of 2007).
2003 - In the Economy category, petroleum entries added for oil production, consumption, exports, imports, and proved
reserves, as well as natural gas proved reserves.
The Evolution of
The World Factbook
2004 - Additional petroleum entries included for natural gas production, consumption, exports, and imports. In the
Transportation category, under Merchant marine, subfields added for foreign-owned vessels and those registered in other
countries. Descriptions of the many forms of government mentioned in the Factbook incorporated into the Notes and Definitions.
2005 - In the People category, a Major infectious diseases field added for countries deemed to pose a higher risk for travelers.
In the Economy category, entries included for Current account balance, Investment, Public debt, and Reserves of foreign
exchange and gold. The Transnational issues category expanded to include Refugees and internally displaced persons. Size of
the printed Factbook reaches 702 pages.
2006 - In the Economy category, national GDP figures now presented at Official Exchange Rates (OER) in addition to GDP
at purchasing power parity (PPP).
2007 - In the Government category, the Capital entry significantly expanded with up to four subfields, including new
information having to do with time. The subfields consist of the name of the capital itself, its geographic coordinates, the time
difference at the capital from coordinated universal time (UTC), and, if applicable, information on daylight saving time (DST).
Where appropriate, a special note is added to highlight those countries with multiple time zones. A Trafficking in persons entry
added to the Transnational issues category. A new appendix, Weights and Measures, (re)introduced to the online version of
the Factbook.
2008 - In the Geography category, two fields focus on the vital resource of water: Total renewable water resources and
Freshwater withdrawal. In the Economy category, three fields added for: Stock of direct foreign investment - at home, Stock of
direct foreign investment - abroad, and Market value of publicly traded shares. Concise descriptions of all major religions included
in the Notes and Definitions.
IV
Contents
Page
Notes and Definitions ix
Guide to Country Profiles xliv
World 1
A Afghanistan 4
Akrotiri 8
Albania 9
Algeria 1 1
American Samoa 15
Andorra 1 7
Angola 19
Anguilla 22
Antarctica 23
Antigua and Barbuda 26
Arctic Ocean 28
Argentina 29
Armenia 32
Aruba 35
Ashmore and Cartier Islands 37
Atlantic Ocean 38
Australia 39
Austria 42
Azerbaijan 45
B Bahamas, The 48
Bahrain 50
Baker Island description under
United States Pacific Island
Wildlife Refuges 52
Bangladesh 53
Barbados 55
Belarus 58
Belgium 61
Belize 64
Benin 66
Bermuda 69
Bhutan 71
Bolivia 74
Bosnia and Herzegovina 77
Botswana 80
Bouvet Island 83
Brazil 83
British Indian Ocean Territory 87
British Virgin Islands 88
Brunei _ 90
Bulgaria _ 92
Burkina Faso _ 95
Burma _ 98
Burundi 101
C Cambodia _ 104
Cameroon _ 107
Canada 110
Cape Verde 113
Page
Cayman Islands 115
Central African Republic 1 1 7
Chad 119
Chile _ 122
China (also see separate Hong Kong,
Macau, and Taiwan entries) 125
Christmas Island 129
Clipperton Island 130
Cocos (Keeling) Islands 131
Colombia 132
Comoros 1 35
Congo, Democratic Republic of the 1 38
Congo, Republic of the 141
Cook Islands 143
Coral Sea Islands 145
Costa Rica 146
Cote d''Ivoire 149
Croatia 152
Cuba 155
Cyprus 158
Czech Republic 162
D Denmark 165
Dhekelia 168
Djibouti 168
Dominica 171
Dominican Republic 173
E Ecuador 176
Egypt _ 179
El Salvador 182
Equatorial Guinea 185
Eritrea _ 187
Estonia _ 190
Ethiopia _ 192
European Union entry
follows country listing 195
F Falkland Islands (Islas Malvinas) _ 195
Faroe Islands _ 197
Fiji _ 199
Finland _ 202
France _ 205
French Polynesia 209
French Southern and Antarctic Lands 21 1
G Gabon _ 214
Gambia, The 217
Gaza Strip 219
Georgia 221
Germany 224
Ghana _ 228
Gibraltar 230
Greece _ 232
Greenland 235
Page','4ffcafcbf202b0002266c2c7079d970cb6829d4ab2429edb9c80c86e2a899582','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d579e81832598e30f76017f545033118f9cb5f8ec430a9a433f9f28f3f224fda',2008,'HK','Hong Kong','raw',2,'262
Howland Island description under
United States Pacific Island
Wildlife Refuges
264','abcd08d8e95fe259db9213373d5c9ce6860e379049da3c7298c6ee20d84ea33b','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('042d2d8d8c992463e5bd7c0d168ee8e7b72876ed263b2a180649b6f0193d72cb',2008,'JP','Japan','raw',3,'299
Jarvis Island description under
United States Pacific Island
Wildlife Refuges
302','96bf268b2563842a84aa321ec68327aec1d4b748aa2a0bc76fd77fbef70210a8','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34cb0eb8b49f95a2289bcb390696f0d0db3a081a59bc43c4924702bbce3afd24',2008,'JE','Jersey','raw',4,'302
Johnston Atoll description under
United States Pacific Island
Wildlife Refuges
303','7f86a1870c079dd75463afb41ffee08d1983cfc75ca4077250a9218b3565ffae','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed6edabffe3640f22f6a1fa02a106582203723b670664922f26d8c3c92543324',2008,'KE','Kenya','raw',5,'310
Kingman Reef description under
United States Pacific Island
Wildlife Refuges
313','faa6cba487fad4345e4e212df6cf7b06127ead95d57db56faed3b6179c89db0e','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edb8e7f7cd13818d0662ed5271f70e42dcef7f865fcdd11d2f3a42659d1dde88',2008,'FM','Micronesia, Federated States of','raw',6,'386
Midway Islands description under
United States Pacific Island
Wildlife Refuges
388
Moldova
388','13801926b414cb852a2a529d0f2fadcd6b686f6631ef688bafe88cfab1c9d092','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18fed2c80d237a187fe068a93580c2e1c85912dda7cfe337c83d7be3998a3cc5',2008,'NF','Norfolk Island','raw',7,'433
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
9 France - Clipperton Island, French Polynesia, French Southern and
Antarctic Lands, Mayotte, New Caledonia, Saint Barthelemy, Saint Martin,
Saint Pierre and Miquelon, Wallis and Futuna
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
17 UK - Akrotiri, Anguilla, Bermuda, British Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Dhekelia, Falkland Islands, Gibraltar,
Guernsey, Jersey, Isle of Man, Montserrat, Pitcairn Islands, Saint Helena,
South Georgia and the South Sandwich Islands, Turks and Caicos Islands
14 US - American Samoa, Baker Island*, Guam, Howland Island*, Jarvis
Island*, Johnston Atoll*, Kingman Reef*, Midway Islands*, Navassa
Island, Northern Mariana Islands, Palmyra Atoll*, Puerto Rico, Virgin
Islands, Wake Island
(’consolidated in United States Pacific Island Wildlife Refuges entry)
XIV
Notes and Definitions (continued)
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','553c332add36ee3539121ba36b898bae39a1f8a92cc01703c9b27e33c2254a3f','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac7b4b4a58f974b85dd854614fc44059a9791a7fc5f5b100d312eb5d1e242654',2008,'PW','Palau','raw',8,'447
Palmyra Atoll description under
United States Pacific Island
Wildlife Refuges
448','df3a53cdbef91ef63e72ab356cd1d5d32c9c275bc85cd1d31a17165de16a7446','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('493216c3458a699cc91ad9d205eca77c078bd8b09aa33507f44e0cc0c5881e1d',2008,'US','United States','raw',9,'611
United States Pacific Islands
Wildlife Refuges
615
VII
Digitized by the Internet Archive
in 2017 with funding from
Kahle/Austin Foundation
https://archive.org/details/worldfactbook20000cent_0
Notes and Definitions
In addition to the regular information updates, The World Factbook 2008 features
several new additions. In the Geography category, two new fields focus on the
increasingly vital resource of water: Total renewable water resources and
Freshwater withdrawal. In the Economy category, the Factbook has added three
fields: Stock of direct foreign investment - at home, Stock of direct foreign
investment - abroad, and Market value of publicly traded shares. Additionally, the
data for GDP at purchasing power parity (PPP) has been rebased using new PPP
conversion rates, benchmarked to the year 2005, which were released on
17 December 2007 by the International Comparison Program (ICP). The 2005
PPP data replace previous estimates, many from studies dating to 1 993 or earlier.
The preliminary ICP report provides estimates of internationally comparable price
levels and the relative purchasing power of currencies for 146 countries. The 2005
benchmark revises downward the size of the world economy in PPP terms from
the previous estimates, and changes the relative sizes of many of the world''s
economies. Concise descriptions of the major religions mentioned in the Factbook
have been added to the Notes and Definitions. France’s redesignation of some of
its overseas possessions caused the five former Indian Ocean island possessions
making up lies Eparses to be incorporated into the French Southern and Antarctic
Lands, while two new Caribbean entities, St. Barthelemy and St. Martin, were
created. Revision of some individual country maps, first introduced in the 2001
edition, is continued in this edition. The revised maps include elevation extremes
and a partial geographic grid. Several regional maps have also been updated to
reflect boundary changes and place name spelling changes.
Abbreviations: This information is included in Appendix A: Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Acronyms: An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up solely from
the first letter of the major words in the expanded form is rendered in all capital
letters (NATO from North Atlantic Treaty Organization; an exception would be
ASEAN for Association of Southeast Asian Nations). In general, an acronym made
up of more than the first letter of the major words in the expanded form is rendered
with only an initial capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned Movement). Hybrid
forms are sometimes used to distinguish between initially identical terms (ICC for
International Chamber of Commerce and ICCt for International Criminal Court).
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by the BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group ( 0-14 years, 15-64 years, 65
years and over). The age structure of a population affects a nation''s key
socioeconomic issues. Countries with young populations (high percentage under
age 15) need to invest more in schools, while countries with older populations
(high percentage ages 65 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential political issues. For
example, the rapid growth of a young adult population unable to find employment
can lead to unrest.
IX
Notes and Definitions (continued)
Agriculture - products: This entry is an ordered listing of major crops and
products starting with the most important.
Airports: This entry gives the total number of airports or airfields recognizable
from the air. The runway(s) may be paved (concrete or asphalt surfaces) or
unpaved (grass, earth, sand, or gravel surfaces) but may include closed or
abandoned installations. Airports or airfields that are no longer recognizable
(overgrown, no facilities, etc.) are not included. Note that not all airports have
accommodations for refueling, maintenance, or air traffic control.
Airports - with paved runways: This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces) by length. For airports with more
than one runway, only the longest runway is included according to the following five
groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to
l, 523 m, and (5) under 914 m. Only airports with usable runways are included in
this listing. Not all airports have facilities for refueling, maintenance, or air traffic
control.
Airports - with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces) by length. For airports
with more than one runway, only the longest runway is included according to the
following five groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1,524 to 2,437
m, (4) 914 to 1,523 m, and (5) under 91 4 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control.
Appendixes: This section includes Factbook-re\\ate6 material by topic.
Area: This entry includes three subfields. Total area is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is
the sum of the surfaces of all inland water bodies, such as lakes, reservoirs, or
rivers, as delimited by international boundaries and/or coastlines.
Area - comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and current
issues and may include a statement about one or two key future trends.
Birth rate: This entry gives the average annual number of births during a year per
1,000 persons in the population at midyear; also known as crude birth rate. The
birth rate is usually the dominant factor in determining the rate of population
growth. It depends on both the level of fertility and the age structure of the
population.
Budget: This entry includes revenues, expenditures, and capital expenditures.
These figures are calculated on an exchange rate basis, i.e., not in purchasing
power parity (PPP) terms.
x
Notes and Definitions (continued)
Capital: This entry gives the name of the seat of government, its geographic
coordinates, the time difference relative to Coordinated Universal Time (UTC)
and the time observed in Washington, DC, and, if applicable, information on
daylight saving time (DST). Where appropriate, a special note has been added to
highlight those countries that have multiple time zones.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging information
and includes the telephone, radio, television, and Internet host entries.
Communications - note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Coordinated Universal Time (UTC): UTC is the international atomic time scale
that serves as the basis of timekeeping for most of the world. The hours, minutes,
and seconds expressed by UTC represent the time of day at the Prime Meridian
(0s longitude) located near Greenwich, England as reckoned from midnight. UTC
is calculated by the Bureau International des Poids et Measures (BIPM) in Sevres,
France. The BIPM averages data collected from more than 200 atomic time and
frequency standards located at about 50 laboratories worldwide. UTC is the basis
for all civil time with the Earth divided into time zones expressed as positive or
negative differences from UTC. UTC is also referred to as "Zulu time." See the
Standard Time Zones of the World map included with the Reference Maps.
Country data codes: see Data codes.
Country map: Most versions of the Factbook provide a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
Country name: This entry includes all forms of the country''s name approved by
the US Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica Italiana), local short form (Italia), former (Kingdom of Italy), as well as
the abbreviation. Also see the Terminology note.
Crude oil: See entry for oil.
Current account balance: This entry records a country''s net trade in goods and
services, plus net earnings from rents, interest, profits, and dividends, and net
transfer payments (such as pension funds and worker remittances) to and from the
rest of the world during the period specified. These figures are calculated on an
exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
XI
Notes and Definitions (continued)
Data codes: This information is presented in Appendix D: Cross-Reference
List of Country Data Codes and Appendix E: Cross-Reference List of
Hydrographic Data Codes.
Date of information: In general, information available as of 1 January 2007 was
used in the preparation of this edition.
Daylight Saving Time (DST): This entry is included for those entities that have
adopted a policy of adjusting the official local time forward, usually one hour, from
Standard Time during summer months. Such policies are most common in
mid-latitude regions.
Death rate: This entry gives the average annual number of deaths during a year
per 1 ,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show a
rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt - external: This entry gives the total public and private debt owed to
nonresidents repayable in foreign currency, goods, or services. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power parity (PPP)
terms.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
189 independent states, including 187 of the 192 UN members (excluded UN
members are Bhutan, Cuba, Iran, North Korea, and the US itself). In addition, the
US has diplomatic relations with 2 independent states that are not in the UN, the
Holy See and Kosovo, as well as with the EU.
Diplomatic representation from the US: This entry includes the chief of mission,
embassy address, mailing address, telephone number, FAX'' number, branch office
locations, consulate general locations, and consulate locations.
Diplomatic representation in the US: This entry includes the chief of mission,
chancery, telephone, FAX, consulate general locations, and consulate locations.
Disputes - international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
XII
Notes and Definitions (continued)
Distribution of family income ■ Gini index: This index measures the degree of
inequality in the distribution of family income in a country. The index is calculated
from the Lorenz curve, in which cumulative family income is plotted against the
number of families arranged from the poorest to the richest. The index is the ratio
of (a) the area between a country''s Lorenz curve and the 45 degree helping line to
(b) the entire triangular area under the 45 degree line. The more nearly equal a
country''s income distribution, the closer its Lorenz curve to the 45 degree line and
the lower its Gini index, e.g., a Scandinavian country with an index of 25. The more
unequal a country''s income distribution, the farther its Lorenz curve from the 45
degree line and the higher its Gini index, e.g., a Sub-Saharan country with an index
of 50. If income were distributed with perfect equality, the Lorenz curve would
coincide with the 45 degree line and the index would be zero; if income were
distributed with perfect inequality, the Lorenz curve would coincide with the
horizontal axis and the right vertical axis and the index would be 100.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview: This entry briefly describes the type of economy, including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Electricity - consumption: This entry consists of total electricity generated
annually plus imports and minus exports, expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in transmission and
distribution.
Electricity - exports: This entry is the total exported electricity in kilowatt-hours.
Electricity - imports: This entry is the total imported electricity in kilowatt-hours.
Electricity - production: This entry is the annual electricity generated expressed
in kilowatt-hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted for as
loss in transmission and distribution.
Elevation extremes: This entry includes both the highest point and the lowest
point.
Entities: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government. "Independent
state" refers to a people politically organized into a sovereign state with a definite
territory. "Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an independent
state. "Country" names used in the table of contents or for page headings are
usually the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a total of 266 separate
geographic entities in The World Factbook that may be categorized as follows:
xiii
Notes and Definitions (continued)
INDEPENDENT STATES
1 94 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kosovo,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
OTHER
2 Taiwan, European Union
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald Islands,','7c6091c918bf622eab4acb256ab7079a0fe919e211e403047c4440dbbdccaaa3','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e55397bd82d937b905990fbd7d90879cb32ba442ee4cdfa4f9f5ca5f8251e5',2008,'VU','Vanuatu','raw',10,'623
Vatican City (see Holy See)
Venezuela
625
Vietnam
629
Virgin Islands
632
W
Wake Island
634','da897e21a9a198c69f29380fae00c5a07862ceddb8460c0abea7e88401ffdeca','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86fc56a49759ef04e628573618e208720f4b830164da6836e31c31063f00a3b0',2008,'EH','Western Sahara','raw',11,'639
Y
OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
266 total
Environment - current issues: This entry lists the most pressing and important
environmental problems. The following terms and abbreviations are used
throughout the entry:
Acidification - the lowering of soil and water pH due to acid precipitation
and deposition usually through precipitation; this process disrupts ecosystem
nutrient flows and may kill freshwater fish and plants dependent on more neutral
or alkaline conditions (see acid rain).
Acid rain - characterized as containing harmful levels of sulfur dioxide or
nitrogen oxide; acid rain is damaging and potentially deadly to the earth''s fragile
ecosystems; acidity is measured using the pH scale where 7 is neutral, values
greater than 7 are considered alkaline, and values below 5.6 are considered acid
precipitation; note - a pH of 2.4 (the acidity of vinegar) has been measured in
rainfall in New England.
Aerosol - a collection of airborne particles dispersed in a gas, smoke, or fog.
Afforestation - converting a bare or agricultural space by planting trees and
plants; reforestation involves replanting trees on areas that have been cut or
destroyed by fire.
Asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in particulate form.
Biodiversity - also biological diversity; the relative number of species,
diverse in form and function, at the genetic, organism, community, and ecosystem
level; loss of biodiversity reduces an ecosystem''s ability to recover from natural or
man-induced disruption.
Bio-indicators - a plant or animal species whose presence, abundance, and
health reveal the general condition of its habitat.
Biomass - the total weight or volume of living matter in a given area or volume.
Carbon cycle - the term used to describe the exchange of carbon (in
various forms, e.g., as carbon dioxide) between the atmosphere, ocean, terrestrial
biosphere, and geological deposits.
Catchments - assemblages used to capture and retain rainwater and
runoff; an important water management technique in areas with limited freshwater
resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless insecticide
that has toxic effects on most animals; the use of DDT was banned in the US in
1972.
Defoliants - chemicals which cause plants to lose their leaves artificially;
often used in agricultural practices for weed control, and may have detrimental
impacts on human and ecosystem health.
Deforestation - the destruction of vast areas of forest (e.g., unsustainable
forestry practices, agricultural and range land clearing, and the over exploitation of
wood products for use as fuel) without planting new growth.
Desertification - the spread of desert-like conditions in arid or semi-arid
areas, due to overgrazing, loss of agriculturally productive soils, or climate change.
xv
Notes and Definitions (continued)
Dredging - the practice of deepening an existing waterway; also, a
technique used for collecting bottom-dwelling marine organisms (e.g., shellfish) or
harvesting coral, often causing significant destruction of reef and ocean-floor
ecosystems.
Drift-net fishing - done with a net, miles in extent, that is generally anchored
to a boat and left to float with the tide; often results in an over harvesting and waste
of large populations of non-commercial marine species (by-catch) by its effect of
"sweeping the ocean clean."
Ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
Effluents - waste materials, such as smoke, sewage, or industrial waste
which are released into the environment, subsequently polluting it.
Endangered species - a species that is threatened with extinction either by
direct hunting or habitat destruction.
Freshwater - water with very low soluble mineral content; sources include
lakes, streams, rivers, glaciers, and underground aquifers.
Greenhouse gas - a gas that "traps" infrared radiation in the lower
atmosphere causing surface warming; water vapor, carbon dioxide, nitrous oxide,
methane, hydrofluorocarbons, and ozone are the primary greenhouse gases in the
Earth''s atmosphere.
Groundwater - water sources found below the surface of the earth often in
naturally occurring reservoirs in permeable rock strata; the source for wells and
natural springs.
Highlands Water Project - a series of dams constructed jointly by Lesotho
and South Africa to redirect Lesotho''s abundant water supply into a rapidly
growing area in South Africa; while it is the largest infrastructure project in
southern Africa, it is also the most costly and controversial; objections to the
project include claims that it forces people from their homes, submerges
farmlands, and squanders economic resources.
Inuit Circumpolar Conference (ICC) - represents the 145,000 Inuits of
Russia, Alaska, Canada, and Greenland in international environmental issues; a
General Assembly convenes every three years to determine the focus of the ICC;
the most current concerns are long-range transport of pollutants, sustainable
development, and climate change.
Metallurgical plants - industries which specialize in the science, technology,
and processing of metals; these plants produce highly concentrated and toxic
wastes which can contribute to pollution of ground water and air when not properly
disposed.
Noxious substances - injurious, very harmful to living beings.
Overgrazing - the grazing of animals on plant material faster than it can
naturally regrow leading to the permanent loss of plant cover, a common effect of
too many animals grazing limited range land.
Ozone shield - a layer of the atmosphere composed of ozone gas (03) that
resides approximately 25 miles above the Earth''s surface and absorbs solar
ultraviolet radiation that can be harmful to living organisms.
Poaching - the illegal killing of animals or fish, a great concern with respect
to endangered or threatened species.
Pollution - the contamination of a healthy environment by man-made waste.
Potable water - water that is drinkable, safe to be consumed.
Salination - the process through which fresh (drinkable) water becomes
salt (undrinkable) water; hence, desalination is the reverse process; also involves
the accumulation of salts in topsoil caused by evaporation of excessive irrigation
water, a process that can eventually render soil incapable of supporting crops.
Siltation - occurs when water channels and reservoirs become clotted with
silt and mud, a side effect of deforestation and soil erosion.
XVI
Notes and Definitions (continued)
Slash-and-bum agriculture - a rotating cultivation technique in which trees
are cut down and burned in order to clear land for temporary agriculture; the land is
used until its productivity declines at which point a new plot is selected and the
process repeats; this practice is sustainable while population levels are low and time
is permitted for regrowth of natural vegetation; conversely, where these conditions do
not exist, the practice can have disastrous consequences for the environment.
Soil degradation - damage to the land''s productive capacity because of
poor agricultural practices such as the excessive use of pesticides or fertilizers,
soil compaction from heavy equipment, or erosion of topsoil, eventually resulting
in reduced ability to produce agricultural products.
Soil erosion - the removal of soil by the action of water or wind, compounded
by poor agricultural practices, deforestation, overgrazing, and desertification.
Ultraviolet (UV) radiation - a portion of the electromagnetic energy emitted
by the sun and naturally filtered in the upper atmosphere by the ozone layer; UV
radiation can be harmful to living organisms and has been linked to increasing
rates of skin cancer in humans.
Waterborne diseases - those in which bacteria survive in, and are transmitted
through, water; always a serious threat in areas with an untreated water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two levels - party to
and signed, but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements: This information is presented in Appendix C:
Selected International Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides an ordered listing of ethnic groups starting
with the largest and normally includes the percent of total population.
Exchange rates: This entry provides the official value of a country''s monetary unit
at a given date or over a given period of time, as expressed in units of local
currency per US dollar and as determined by international market forces or official
fiat. The International Organization for Standardization (ISO) 4217 alphabetic
currency code for the national medium of exchange is presented in parenthesis.
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government. Head of government includes the name and title of
the top administrative leader who is designated to manage the day-to-day activities
of the government. For example, in the UK, the monarch is the chief of state, and
the prime minister is the head of government. In the US, the president is both the
chief of state and the head of government. Cabinet includes the official name for
this body of high-ranking advisers and the method for selection of members.
Elections include the nature of election process or accession to power, date of the
last election, and date of the next election. Election results includes the percent of
vote for each candidate in the last election.
Exports: This entry provides the total US dollar amount of merchandise exports
on an f.o.b. (free on board) basis. These figures are calculated on an exchange
rate basis, i.e., not in purchasing power parity (PPP) terms.
XVII
Notes and Definitions (continued)
Exports - commodities: This entry provides a listing of the highest-valued
exported products; it sometimes includes the percent of total dollar value.
Exports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Flag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile. The flag graphics were produced from actual flags or the best
information available at the time of preparation. The flags of independent states
are used by their dependencies unless there is an officially recognized local flag.
Some disputed and other areas do not have flags.
Freshwater withdrawal (domestic/industrial/agricultural): This entry provides
the annual quantity of water in cubic kilometers removed from available sources
for use in any purpose. Water drawn-off is not necessarily entirely consumed and
some portion may be returned for further use downstream. Domestic sector use
refers to water supplied by public distribution systems. Note that some of this total
may be used for small industrial and/or limited agricultural purposes. Industrial
sector use is the quantity of water used by self-supplied industries not connected
to a public distribution system. Agricultural sector use includes water used for
irrigation and livestock watering, and does not account for agriculture directly
dependent on rainfall. Included are figures for total annual water withdrawal and
per capita water withdrawal.
GDP (official exchange rate): This entry gives the gross domestic product (GDP)
or value of all final goods and services produced within a nation in a given year. A
nation''s GDP at official exchange rates (OER) is the home-currency-denominated
annual GDP figure divided by the bilateral average US exchange rate with that
country in that year. The measure is simple to compute and gives a precise
measure of the value of output. Many economists prefer this measure when
gauging the economic power an economy maintains vis-a-vis its neighbors,
judging that an exchange rate captures the purchasing power a nation enjoys in
the international marketplace. Official exchange rates, however, can be artificially
fixed and/or subject to manipulation - resulting in claims of the country having an
under- or over-valued currency - and are not necessarily the equivalent of a
market-determined exchange rate. Moreover, even if the official exchange rate is
market-determined, market exchange rates are frequently established by a
relatively small set of goods and services (the ones the country trades) and may
not capture the value of the larger set of goods the country produces. Furthermore,
OER-converted GDP is not well suited to comparing domestic GDP over time,
since appreciation/depreciation from one year to the next will make the OER GDP
value rise/fall regardless of whether home-currency-denominated GDP changed.
GDP (purchasing power parity): This entry gives the gross domestic product
(GDP) or value of all final goods and services produced within a nation in a given
year. A nation''s GDP at purchasing power parity (PPP) exchange rates is the sum
value of all goods and services produced in the country valued at prices prevailing
in the United States. This is the measure most economists prefer when looking at
per-capita welfare and when comparing living conditions or use of resources
xviii
Notes and Definitions (continued)
across countries. The measure is difficult to compute, as a US dollar value has to
be assigned to all goods and services in the country regardless of whether these
goods and services have a direct equivalent in the United States (for example, the
value of an ox-cart or non-US military equipment); as a result, PPP estimates for
some countries are based on a small and sometimes different set of goods and
services. In addition, many countries do not formally participate in the World
Bank''s PPP project that calculates these measures, so the resulting GDP
estimates for these countries may lack precision. For many developing countries,
PPP-based GDP measures are multiples of the official exchange rate (OER)
measure. The difference between the OER- and PPP-denominated GDP values
for most of the wealthy industrialized countries are generally much smaller.
GDP - composition by sector: This entry gives the percentage contribution of
agriculture, industry, and services to total GDP. The distribution will total less than
100 percent if the data are incomplete.
GDP - per capita (PPP): This entry shows GDP on a purchasing power parity
basis divided by population as of 1 July for the same year.
GDP - real growth rate: This entry gives GDP growth on an annual basis adjusted
for inflation and expressed as a percent.
GDP methodology: In the Economy category, GDP dollar estimates for countries
are reported both on an official exchange rate (OER) and a purchasing power
parity (PPP) basis. Both measures contain information that is useful to the reader.
The PPP method involves the use of standardized international dollar price
weights, which are applied to the quantities of final goods and services produced
in a given economy. The data derived from the PPP method probably provide the
best available starting point for comparisons of economic strength and well-being
between countries. In contrast, the currency exchange rate method involves a
variety of international and domestic financial forces that may not capture the value
of domestic output. Whereas PPP estimates for OECD countries are quite reliable,
PPP estimates for developing countries are often rough approximations. In
developing countries with weak currencies, the exchange rate estimate of GDP in
dollars is typically one-fourth to one-half the PPP estimate. Most of the GDP
estimates for developing countries are based on extrapolation of PPP numbers
published by the UN International Comparison Program (UNICP) and by
Professors Robert Summers and Alan Heston of the University of Pennsylvania
and their colleagues. GDP derived using the OER method should be used for the
purpose of calculating the share of items such as exports, imports, military
expenditures, external debt, or the current account balance, because the dollar
values presented in the Factbook for these items have been converted at official
exchange rates, not at PPP. One should use the OER GDP figure to calculate the
proportion of, say, Chinese defense expenditures in GDP, because that share will
be the same as one calculated in local currency units. Comparison of OER GDP
with PPP GDP may also indicate whether a currency is over- or under-valued. If
OER GDP is smaller than PPP GDP, the official exchange rate may be
undervalued, and vice versa. However, there is no strong historical evidence that
market exchange rates move in the direction implied by the PPP rate, at least not
in the short- or medium-term. Note: the numbers for GDP and other economic data
should not be chained together from successive volumes of the Factbook because
of changes in the US dollar measuring rod, revisions of data by statistical
agencies, use of new or different sources of information, and changes in national
statistical methods and practices.
XIX
Notes and Definitions (continued)
Geographic coordinates: This entry includes rounded latitude and longitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the locations provided in the Geographic Names Server (GNS),
maintained by the National Geospatial-Intelligence Agency on behalf of the US
Board on Geographic Names.
Geographic names: This information is presented in Appendix F:
Cross-Reference List of Geographic Names. It includes a listing of various
alternate names, former names, local names, and regional names referenced to
one or more related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
Gini index: See entry for Distribution of family income - Gini index
GNP: Gross national product (GNP) is the value of all final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad,
minus income earned by foreigners from domestic production. The Factbook,
following current practice, uses GDP rather than GNP to measure national
production. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to national well-being.
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
Government - note: This entry includes miscellaneous government information of
significance not included elsewhere.
Government type: This entry gives the basic form of government. Definitions of
the major governmental terms are as follows. (Note that for some countries more
than one definition applies.):
Absolute monarchy - a form of government where the monarch rules
unhindered, i.e., without any laws, constitution, or legally organized opposition.
Anarchy - a condition of lawlessness or political disorder brought about by
the absence of governmental authority.
Authoritarian - a form of government in which state authority is imposed
onto many aspects of citizens'' lives.
Commonwealth - a nation, state, or other political entity founded on law and
united by a compact of the people for the common good.
Communist - a system of government in which the state plans and controls
the economy and a single - often authoritarian - party holds power; state controls
are imposed with the elimination of private ownership of property or capital while
claiming to make progress toward a higher social order in which all goods are
equally shared by the people (i.e., a classless society).
Confederacy (Confederation) - a union by compact or treaty between
states, provinces, or territories, that creates a central government with limited
powers; the constituent entities retain supreme authority over all matters except
those delegated to the central government.
xx
Notes and Definitions (continued)
Constitutional - a government by or operating under an authoritative
document (constitution) that sets forth the system of fundamental laws and
principles that determines the nature, functions, and limits of that government.
Constitutional democracy - a form of government in which the sovereign
power of the people is spelled out in a governing constitution.
Constitutional monarchy - a system of government in which a monarch is
guided by a constitution whereby his/her rights, duties, and responsibilities are
spelled out in written law or by custom.
Democracy - a form of government in which the supreme power is retained
by the people, but which is usually exercised indirectly through a system of
representation and delegated authority periodically renewed.
Democratic republic - a state in which the supreme power rests in the body
of citizens entitled to vote for officers and representatives responsible to them.
Dictatorship - a form of government in which a ruler or small clique wield
absolute power (not restricted by a constitution or laws).
Ecclesiastical - a government administrated by a church.
Emirate - similar to a monarchy or sultanate, but a government in which the
supreme power is in the hands of an emir (the ruler of a Muslim state); the emir may be
an absolute overlord or a sovereign with constitutionally limited authority.
Federal (Federation) - a form of government in which sovereign power is
formally divided - usually by means of a constitution - between a central authority
and a number of constituent regions (states, colonies, or provinces) so that each
region retains some management of its internal affairs; differs from a confederacy
in that the central government exerts influence directly upon both individuals as
well as upon the regional units.
Federal republic - a state in which the powers of the central government are
restricted and in which the component parts (states, colonies, or provinces) retain
a degree of self-government; ultimate sovereign power rests with the voters who
chose their governmental representatives.
Islamic republic - a particular form of government adopted by some Muslim
states; although such a state is, in theory, a theocracy, it remains a republic, but its
laws are required to be compatible with the laws of Islam.
Maoism - the theory and practice of Marxism-Leninism developed in China
by Mao Zedong (Mao Tse-tung), which states that a continuous revolution is
necessary if the leaders of a communist state are to keep in touch with the people.
Marxism - the political, economic, and social principles espoused by 19th
century economist Karl Marx; he viewed the struggle of workers as a progression
of historical forces that would proceed from a class struggle of the proletariat
(workers) exploited by capitalists (business owners), to a socialist “dictatorship of
the proletaria','d88456017d19d7b1331405f7b7e4a6e99c1fc428b6231145dfcdbbb64864ce4a','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3be82c1fb85a945c146e47989382dcd3d46058b5709fb64ad21705a65b2cee45',2008,'EH','Western Sahara','raw',12,'t," to, finally, a classless society - Communism.
Marxism-Leninism - an expanded form of communism developed by Lenin from
doctrines of Karl Marx; Lenin saw imperialism as the final stage of capitalism and
shifted the focus of workers'' struggle from developed to underdeveloped countries.
Monarchy - a government in which the supreme power is lodged in the
hands of a monarch who reigns over a state or territory, usually for life and by
hereditary right; the monarch may be either a sole absolute ruler or a sovereign -
such as a king, queen, or prince - with constitutionally limited authority.
Oligarchy - a government in which control is exercised by a small group of
individuals whose authority generally is based on wealth or power.
Parliamentary democracy - a political system in which the legislature
(parliament) selects the government - a prime minister, premier, or chancellor
along with the cabinet ministers - according to party strength as expressed in
elections; by this system, the government acquires a dual responsibility: to the
people as well as to the parliament.
XXI
Notes and Definitions (continued)
Parliamentary government (Cabinet-Parliamentary government) - a
government in which members of an executive branch (the cabinet and its
leader - a prime minister, premier, or chancellor) are nominated to their
positions by a legislature or parliament, and are directly responsible to it; this
type of government can be dissolved at will by the parliament (legislature) by
means of a no confidence vote or the leader of the cabinet may dissolve the
parliament if it can no longer function.
Parliamentary monarchy - a state headed by a monarch who is not actively
involved in policy formation or implementation (i.e., the exercise of sovereign
powers by a monarch in a ceremonial capacity); true governmental leadership is
carried out by a cabinet and its head - a prime minister, premier, or chancellor -
who are drawn from a legislature (parliament).
Presidential - a system of government where the executive branch exists
separately from a legislature (to which it is generally not accountable).
Republic - a representative democracy in which the people''s elected
deputies (representatives), not the people themselves, vote on legislation.
Socialism - a government in which the means of planning, producing, and
distributing goods is controlled by a central government that theoretically seeks a
more just and equitable distribution of property and labor; in actuality, most
socialist governments have ended up being no more than dictatorships over
workers by a ruling elite.
Sultanate - similar to a monarchy, but a government in which the supreme
power is in the hands of a sultan (the head of a Muslim state); the sultan may be
an absolute ruler or a sovereign with constitutionally limited authority.
Theocracy - a form of government in which a Deity is recognized as the
supreme civil ruler, but the Deity''s laws are interpreted by ecclesiastical authorities
(bishops, mullahs, etc.); a government subject to religious authority.
Totalitarian - a government that seeks to subordinate the individual to the
state by controlling not only all political and economic matters, but also the
attitudes, values, and beliefs of its population.
Greenwich Mean Time (GMT): The mean solar time at the Greenwich Meridian,
Greenwich, England, with the hours and days, since 1925, reckoned from
midnight. GMT is now a historical term having been replaced by UTC on 1 January
1972. See Coordinated Universal Time.
Gross domestic product: see GDP
Gross national product: see GNP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Gross world product: see GWP
Heliports: This entry gives the total number of heliports with hard-surface
runways, helipads, or landing areas that support routine sustained helicopter
operations exclusively and have support facilities including one or more of the
following facilities: lighting, fuel, passenger handling, or maintenance. It includes
former airports used exclusively for helicopter operations but excludes heliports
limited to day operations and natural clearings that could support helicopter
landings and takeoffs.
XXII
Notes and Definitions (continued)
HIV/AIDS ■ adult prevalence rate: This entry gives an estimate of the percentage
of adults (aged 1 5-49) living with HIV/AIDS. The adult prevalence rate is calculated
by dividing the estimated number of adults living with HIV/AIDS at yearend by the
total adult population at yearend.
HIV/AIDS - deaths: This entry gives an estimate of the number of adults and
children who died of AIDS during a given calendar year.
HIV/AIDS - people living with HIV/AIDS: This entry gives an estimate of all
people (adults and children) alive at yearend with HIV infection , whether or not they
have developed symptoms of AIDS.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted for
household size. Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a more unequal
distribution than surveys based on consumption. The quality of surveys is
improving with time, yet caution is still necessary in making inter-country
comparisons.
Hydrographic data codes: see Data codes
Illicit drugs: This entry gives information on the five categories of illicit drugs -
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis ( Cannabis sativa ) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which comes
from cacao seeds and is used in making chocolate, cocoa, and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness,
and emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(POP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaf of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia and Africa.
xxiii
Notes and Definitions (continued)
Narcotics are drugs that relieve pain, often induce sleep, and refer to
opium, opium derivatives, and synthetic substitutes. Natural narcotics include
opium (paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol
with codeine, Empirin with codeine, Robitussin AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw is the entire cut and dried opium poppy-plant material, other
than the seeds. Opium is extracted from poppy straw in commercial operations that
produce the drug for medical use.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and
activity, and include cocaine (coke, snow, crack), amphetamines (Desoxyn,
Dexedrine), ephedrine, ecstasy (clarity, essence, doctor, Adam), phenmetrazine
(Preludin), methylphenidate (Ritalin), and others (Cylert, Sanorex, Tenuate).
Imports: This entry provides the total US dollar amount of merchandise imports
on a c.i.f. (cost, insurance, and freight) or f.o.b. (free on board) basis. These figures
are calculated on an exchange rate basis, i.e., not in purchasing power parity
(PPP) terms.
Imports - commodities: This entry provides a listing of the highest-valued
imported products; it sometimes includes the percent of total dollar value.
Imports - partners: This entry provides a rank ordering of trading partners starting
with the most important; it sometimes includes the percent of total dollar value.
Independence: For most countries, this entry gives the date that sovereignty was
achieved and from which nation, empire, or trusteeship. For the other countries,
the date given may not represent "independence" in the strict sense, but rather
some significant nationhood event such as the traditional founding date or the date
of unification, federation, confederation, establishment, fundamental change in the
form of government, or state succession. Dependent areas include the notation
"none" followed by the nature of their dependency status. Also see the
Terminology note.
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1 ,000 live births in the same year; included is the total
death rate, and deaths by sex, male and female. This rate is often used as an
indicator of the level of health in a country.
XXIV
Notes and Definitions (continued)
Inflation rate (consumer prices): This entry furnishes the annual percent change
in consumer prices compared with the previous year''s consumer prices.
International disputes: see Disputes - international
International organization participation: This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
International organizations: This information is presented in Appendix B:
International Organizations and Groups which includes the name, abbreviation,
date established, aim, and members by category.
Internet country code: This entry includes the two-letter codes maintained by the
International Organization for Standardization (ISO) in the ISO 3166 Alpha-2 list
and used by the Internet Assigned Numbers Authority (IANA) to establish
country-coded top-level domains (ccTLDs).
Internet hosts: This entry lists the number of Internet hosts available within a
country. An Internet host is a computer connected directly to the Internet; normally
an Internet Service Provider''s (ISP) computer is a host. Internet users may use
either a hard-wired terminal, at an institution with a mainframe computer
connected directly to the Internet, or may connect remotely by way of a modem via
telephone line, cable, or satellite to the Internet Service Provider''s host computer.
The number of hosts is one indicator of the extent of Internet connectivity.
Internet users: This entry gives the number of users within a country that access
the Internet. Statistics vary from country to country and may include users who
access the Internet at least several times a week to those who access it only once
within a period of several months.
Introduction: This category includes one entry, Background.
Investment (gross fixed): This entry records total business spending on fixed
assets, such as factories, machinery, equipment, dwellings, and inventories of raw
materials, which provide the basis for future production. It is measured gross of the
depreciation of the assets, i.e., it includes investment that merely replaces
worn-out or scrapped capital.
Irrigated land: This entry gives the number of square kilometers of land area that
is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry lists the percentage distribution of the
labor force by occupation. The distribution will total less than 100 percent if the
data are incomplete.
xxv
Notes and Definitions (continued)
Land boundaries: This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries. When available,
official lengths published by national statistical agencies are used. Because
surveying methods may differ, country border lengths reported by contiguous
countries may differ.
Land use: This entry contains the percentage shares of total land area for three
different types of land use: arable land- land cultivated for crops like wheat, maize,
and rice that are replanted after each harvest; permanent crops - land cultivated
for crops like citrus, coffee, and rubber that are not replanted after each harvest;
includes land under flowering shrubs, fruit trees, nut trees, and vines, but excludes
land under trees grown for wood or timber; other- any land not arable or under
permanent crops; includes permanent meadows and pastures, forests and
woodlands, built-on areas, roads, barren land, etc.
Languages: This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system''s
historical roots, role in government, and acceptance of International Court of
Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and term of office. Elections
includes the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as indicating the potential return on investment in human capital and is necessary
for the calculation of various actuarial measures.
Literacy: This entry includes a definition of literacy and Census Bureau
percentages for the total population , males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition - the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
Location: This entry identifies the country''s regional location, neighboring
countries, and adjacent bodies of water.
Major infectious diseases: This entry lists major infectious diseases likely to be
encountered in countries where the risk of such diseases is assessed to be very
high as compared to the United States. These infectious diseases represent risks
to US government personnel traveling to the specified country for a period of less
XXVI
Notes and Definitions (continued)
than three years. The degree ofrisk''\\s assessed by considering the foreign nature
of these infectious diseases, their severity, and the probability of being affected by
the diseases present. The diseases listed do not necessarily represent the total
disease burden experienced by the local population.
The risk to an individual traveler varies considerably by the specific location,
visit duration, type of activities, type of accommodations, time of year, and other
factors. Consultation with a travel medicine physician is needed to evaluate individual
risk and recommend appropriate preventive measures such as vaccines.
Diseases are organized into the following six exposure categories shown in
italics and listed in typical descending order of risk. Note: The sequence of exposure
categories listed in individual country entries may vary according to local conditions,
food or waterborne diseases acquired through eating or drinking on the local','501354bce93094b617279e17c96a3c6e032dda4dddbc4ca3222f09af9b0e85fa','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7fc7cf4442d2103f8a59f97cde0bf7ef35f4eb55f560af9d5850aeafc187f90',2008,'ZW','Zimbabwe','raw',13,'646
Taiwan
649
European Union
652
VI
Appendixes
Page
Appendixes
A: Abbreviations
657
B: International Organizations and Groups
665
C: Selected International Environmental Agreements
669
D: Cross-Reference List of Country Data Codes
671
E: Cross-Reference List of Hydrographic Data Codes
679
F: Cross-Reference List of Geographic Names
680
G: Weights and Measures
712
Country Flags
713
Reference Maps Africa
Antarctic Region
Arctic Region
Asia
Central America and the Caribbean
Central Balkan Region
Europe
Middle East
North America
Oceania
Physical Map of the World
Political Map of the World
South America
Southeast Asia
Standard Time Zones of the World','2796049ec1c1a1c1e557dff891f27fe36ef07df9b311a0ba55b94dd4ce432734','internet-archive','worldfactbook20000cent_0','txt','fb2564400de15d9d737d11cdd582afe436fc1f35f5eb9a405e09cb0762e175e0','https://archive.org/download/worldfactbook20000cent_0/worldfactbook20000cent_0_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fa027adbd29180b11fd9934b5763a694466bc1e9297ce2f81fc1d3052957fac',2008,'','','raw',1,'The Project Gutenberg EBook of The 2008 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2008 CIA World Factbook
Author: United States. Central Intelligence Agency.
Release Date: June 25, 2009 [EBook #29233]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2008 CIA WORLD FACTBOOK ***
Produced by Al Haines
THE CIA WORLD FACTBOOK 2008
CONTENTS
Countries and Locations
Field Listings
Rank Orders
Appendixes
Notes and Definitions
History of the World Factbook
Contributors and Copyright Information
Purchasing Information
Frequently Asked Questions (FAQs)
What''s New
- Country information has been updated as of 18 December 2008.
- In the People category, two new fields provide information on
education in terms of opportunity and resources. "School Life
Expectancy" is an estimate of the total number of years of schooling
(primary to tertiary) that a child can expect to receive, assuming
that the probability of his or her being enrolled in school at any
particular future age is equal to the current enrollment ratio at
that age. "Education expenditures" provides an estimate of the public
expenditure on education as a percent of Gross Domestic Product (GDP).
- In order to help policymakers understand the nature and global
dimensions of the current financial crisis, The World Factbook has
added five new fields to the Economy category. "Central bank discount
rate" provides the annualized interest rate a country''s central bank
charges commercial, depository banks for loans to meet temporary
shortages of funds. "Commercial bank prime lending rate" provides a
simple average of annualized interest rates commercial banks charge
on new loans, denominated in the national currency, to their most
credit-worthy customers. "Stock of money" also known as "M1," comprises
the total quantity of currency in circulation (notes and coins) plus
demand deposits denominated in the national currency, held by nonbank
financial institutions, state and local governments, nonfinancial
public enterprises, and the private sector of the economy. "Stock of
quasi money" comprises the total quantity of time and savings deposits
denominated in the national currency, held by nonbank financial
institutions, state and local governments, nonfinancial public
enterprises, and the private sector of the economy. When added together
with "M1" the total money supply is known as "M2." "Stock of domestic
credit" is the total quantity of credit, denominated in the domestic
currency, provided by banks to nonbanking institutions.
- In the Geography category, two new fields focus on the increasingly
vital resource of water: "Total renewable water resources" and
"Freshwater withdrawal."
- Revision of some individual country maps, first introduced in the
2001 edition, is continued in this edition. Several regional maps have
also been updated to reflect boundary changes and place name spelling
changes.
======================================================================
The World Factbook (2008) - Country Listing
[Transcriber''s note: To search on a country in this file, prefix the
country''s name with "@", e.g. "@Afghanistan". "Afghanistan" will find
all occurrences; prefixing it with "@" will find the correct location.]
World
A','f1c75590bdbf5152a69d6f0e288e230eb5c54b49166a04baaa7a4b478678fe2a','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aac52fa94b18c92f56bd37a4ee596587e3a5393422163d1f2d58b95c6329cd74',2008,'FM','Micronesia, Federated States of','raw',2,'Midway Islands description under United States Pacific Island Wildlife Refuges
Moldova','11c0f19bc8fff35dddf05d93f6b7f9f4f005e64731aac019bbf520aac4209331','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30b79330e32a727f8681d2386a020d1ceeacf127817d586f8aed387215023410',2008,'ZW','Zimbabwe','raw',3,'Taiwan
European Union
=====================================================================
Code Field Description
2001 GDP (purchasing power parity)
2002 Population growth rate (%)
2003 GDP - real growth rate (%)
2004 GDP - per capita (PPP)
2006 Dependency status
2007 Diplomatic representation from the US
2008 Transportation - note
2010 Age structure (%)
2011 Geographic coordinates
2012 GDP - composition by sector (%)
2013 Radio broadcast stations
2015 Television broadcast stations
2018 Sex ratio (male(s)/female)
2019 Heliports
2020 Elevation extremes (m)
2021 Natural hazards
2022 People - note
2023 Area - comparative
2024 Military service age and obligation (years of age)
2025 Manpower fit for military service
2026 Manpower reaching militarily significant age annually
2028 Background
2030 Airports - with paved runways
2031 Airports - with unpaved runways
2032 Environment - current issues
2033 Environment - international agreements
2034 Military expenditures (% of GDP)
2038 Electricity - production (kWh)
2042 Electricity - consumption (kWh)
2043 Electricity - imports (kWh)
2044 Electricity - exports (kWh)
2046 Population below poverty line (%)
2047 Household income or consumption by percentage share (%)
2048 Labor force - by occupation (%)
2049 Exports - commodities (%)
2050 Exports - partners (%)
2051 Administrative divisions
2052 Agriculture - products
2053 Airports
2054 Birth rate (births/1,000 population)
2055 Military branches
2056 Budget
2057 Capital
2058 Imports - commodities (%)
2059 Climate
2060 Coastline (km)
2061 Imports - partners (%)
2062 Economic aid - donor
2063 Constitution
2064 Economic aid - recipient
2065 Currency (code)
2066 Death rate (deaths/1,000 population)
2068 Dependent areas
2070 Disputes - international
2075 Ethnic groups (%)
2076 Exchange rates
2077 Executive branch
2078 Exports
2079 Debt - external
2080 Fiscal year
2081 Flag description
2085 Roadways (km)
2086 Illicit drugs
2087 Imports
2088 Independence
2089 Industrial production growth rate (%)
2090 Industries
2091 Infant mortality rate (deaths/1,000 live births)
2092 Inflation rate (consumer prices) (%)
2093 Waterways (km)
2094 Judicial branch
2095 Labor force
2096 Land boundaries (km)
2097 Land use (%)
2098 Languages (%)
2100 Legal system
2101 Legislative branch
2102 Life expectancy at birth (years)
2103 Literacy (%)
2105 Manpower available for military service
2106 Maritime claims
2107 International organization participation
2108 Merchant marine
2109 National holiday
2110 Nationality
2111 Natural resources
2112 Net migration rate (migrant(s)/1,000 population)
2113 Geography - note
2115 Political pressure groups and leaders
2116 Economy - overview
2117 Pipelines (km)
2118 Political parties and leaders
2119 Population
2120 Ports and terminals
2121 Railways (km)
2122 Religions (%)
2123 Suffrage
2124 Telephone system
2125 Terrain
2127 Total fertility rate (children born/woman)
2128 Government type
2129 Unemployment rate (%)
2137 Military - note
2138 Communications - note
2140 Government - note
2142 Country name
2144 Location
2145 Map references
2146 Irrigated land (sq km)
2147 Area (sq km)
2149 Diplomatic representation in the US
2150 Telephones - main lines in use
2151 Telephones - mobile cellular
2153 Internet users
2154 Internet country code
2155 HIV/AIDS - adult prevalence rate (%)
2156 HIV/AIDS - people living with HIV/AIDS
2157 HIV/AIDS - deaths
2172 Distribution of family income - Gini index
2173 Oil - production (bbl/day)
2174 Oil - consumption (bbl/day)
2175 Oil - imports (bbl/day)
2176 Oil - exports (bbl/day)
2177 Median age (years)
2178 Oil - proved reserves (bbl)
2179 Natural gas - proved reserves (cu m)
2180 Natural gas - production (cu m)
2181 Natural gas - consumption (cu m)
2182 Natural gas - imports (cu m)
2183 Natural gas - exports (cu m)
2184 Internet hosts
2185 Investment (gross fixed) (% of GDP)
2186 Public debt (% of GDP)
2187 Current account balance
2188 Reserves of foreign exchange and gold
2193 Major infectious diseases
2194 Refugees and internally displaced persons
2195 GDP (official exchange rate)
2196 Trafficking in persons
2198 Stock of direct foreign investment - at home
2199 Stock of direct foreign investment - abroad
2200 Market value of publicly traded shares
2201 Total renewable water resources (cu km)
2202 Freshwater withdrawal (domestic/industrial/agricultural) ()
2203 Geographic overview
2204 Economy of the area administered by Turkish Cypriots
2205 School life expectancy (primary to tertiary education) (years)
2206 Education expenditures (% of GDP)
2207 Central bank discount rate (%)
2208 Commercial bank prime lending rate (%)
2209 Stock of money
2210 Stock of quasi money
2211 Stock of domestic credit
======================================================================
Rank Orders
[Transcriber''s note: To search on a rank order in this file, prefix
the rank''s name with "@", e.g. "@Population". "Population" will find
all occurrences; prefixing it with "@" will find the correct location.]
Rank Order pages are presorted lists of data from selected Factbook
data fields. Rank Order pages are generally given in descending order -
highest to lowest - such as Population and Area. The two exceptions are
Unemployment Rate and Inflation Rate, which are in ascending - lowest
to highest - order. Rank Order pages are available for the following 55
fields in six of the nine Factbook categories.','41a2d838523b99b1ea4eeb696b9fddedebea0fc6f8243b9283d105867f1e7d83','internet-archive','theciaworldfactb29233gut','txt','dbb79b9d8922993c50cf3fd66897410e90d9091538a068a7b9afed1316e2c4e4','https://archive.org/download/theciaworldfactb29233gut/29233.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
